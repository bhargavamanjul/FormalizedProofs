module

public import Elliptic
public meta import Lean.Elab.Command
public meta import Lean.Util.CollectAxioms

open Lean Elab Command in
elab "audit_project" : command => do
  let env ← getEnv
  let selected := env.constants.toList.filter fun (n, _) =>
    let s := n.toString
    s.startsWith "Elliptic." || s.startsWith "Artin." ||
      s.startsWith "_private.Elliptic." || s.startsWith "_private.Artin."
  if selected.isEmpty then throwError "No project declarations were loaded."
  for (n, ci) in selected do
    match ci with
    | .defnInfo d =>
      if d.safety == .unsafe then throwError "Unsafe project declaration: {n}"
    | _ => pure ()
    let axioms ← Lean.collectAxioms n
    for a in axioms do
      unless a == ``propext || a == ``Classical.choice || a == ``Quot.sound do
        throwError "Unapproved axiom {a} in {n}"
    let names := String.intercalate "," (axioms.toList.map Name.toString)
    logInfo m!"AUDIT|{n}|{names}"
  logInfo m!"AUDIT_TOTAL|{selected.length}"

audit_project
