module

public import Elliptic.MainCurveFamily
public import Elliptic.MainCurveHeight

/-!
# Specialization to the actual curve and point in Theorem 1

Every group, point, candidate factorization, and denominator sequence in this
file is specified. The remaining original counting obligation is the lower
bound for the explicitly defined candidate set, and the remaining division
arithmetic is the field degree/discriminant/prime-ideal injection. The rational-point reduction fact is separately exposed. The
quadratic height bound has been proved in `MainCurveHeight`.
No final density statement is asserted without these hypotheses.
-/

@[expose] public section

noncomputable section

namespace Elliptic

open Filter
open scoped Topology

def mainEligible (p : ℕ) : Prop := p % 8 = 3

/-- The exact candidate factorization used by the main-curve argument.
Its large prime is explicitly bigger than `x^(9/10)`, although the index
cover itself only needs the cofactor bound. -/
def mainCandidate (ε Y x : ℝ) (p : ℕ) : Prop :=
  ∃ r Q : ℕ, 0 < r ∧ Q.Prime ∧ x ^ ((9 : ℝ) / 10) < (Q : ℝ) ∧
    p + 1 = 4 * r * Q ∧ r ≤ ⌊x ^ ε⌋₊ ∧
    ∀ q : ℕ, q.Prime → q ∣ r → ⌊Y⌋₊ < q

def mainCofactor (ε Y x : ℝ) (p : ℕ) : ℕ := by
  classical
  exact if h : mainCandidate ε Y x p then Classical.choose h else 1

def mainLargePrime (ε Y x : ℝ) (p : ℕ) : ℕ := by
  classical
  exact if h : mainCandidate ε Y x p then Classical.choose (Classical.choose_spec h) else 2

theorem mainCandidate_factor_data {ε Y x : ℝ} {p : ℕ}
    (h : mainCandidate ε Y x p) :
    0 < mainCofactor ε Y x p ∧ (mainLargePrime ε Y x p).Prime ∧
    x ^ ((9 : ℝ) / 10) < (mainLargePrime ε Y x p : ℝ) ∧
    p + 1 = 4 * mainCofactor ε Y x p * mainLargePrime ε Y x p ∧
    mainCofactor ε Y x p ≤ ⌊x ^ ε⌋₊ ∧
    ∀ q : ℕ, q.Prime → q ∣ mainCofactor ε Y x p → ⌊Y⌋₊ < q := by
  simpa only [mainCofactor, mainLargePrime, dite_eq_left h] using
    Classical.choose_spec (Classical.choose_spec h)

/-- The actual point has odd index. This uses the proved two-torsion and
non-doubling calculations; no finite-field elliptic structure theorem is
required. -/
theorem mainCurveFamily_odd_index (p : ℕ) [hp : Fact p.Prime] (hp8 : p % 8 = 3) :
    Odd (pointIndex (mainCurveFamily.point p)) := by
  obtain ⟨T, _hTzero, hT⟩ := mainCurveFamily_two_torsion p hp8
  have htwo : Nat.card (TwoTorsion (mainCurveGroup p)) ≤ 2 :=
    card_twoTorsion_le_two T (fun R hR => (hT R).mp hR)
  exact odd_pointIndex_of_two_torsion_bound (mainCurvePoint p)
    htwo (mainCurveFamily_not_double p hp8)

/-- Every arithmetic fact needed for the candidate cover is proved for the
specified candidate set and the actual finite-field group. -/
theorem mainCandidateArithmetic :
    CandidateArithmeticObligation mainCurveFamily mainEligible
      mainCandidate mainCofactor mainLargePrime 4 := by
  intro ε Y x _hε _hY hx p hp hcand
  obtain ⟨hpprime, hpel, _, _⟩ := mem_dyadic_eligible (by linarith) hp
  let : Fact p.Prime := ⟨hpprime⟩
  have hp8 : p % 8 = 3 := hpel
  have hp4 : p % 4 = 3 := by omega
  obtain ⟨hr, hQ, _hQlarge, hfactor, hrR, hrough⟩ := mainCandidate_factor_data hcand
  exact ⟨mainCurveFamily_odd_index p hp8,
    hr, hQ, (mainCurveFamily_card p hp4).trans hfactor, hrR,
    fun q hq hqr _ => hrough q hq hqr⟩

/-- Compatibility wrapper: the cyclicity premise is no longer needed. -/
theorem mainCandidateArithmetic_of_cyclicity
    (_hcyclic : ∀ p : ℕ, p.Prime → mainEligible p →
      IsAddCyclic (mainCurveFamily.Group p)) :
    CandidateArithmeticObligation mainCurveFamily mainEligible
      mainCandidate mainCofactor mainLargePrime 4 := mainCandidateArithmetic

/-- The remaining reduction fact refers to denominators computed from the
actual rational elliptic multiples and orders in the actual reduced group.
It is not a bound on an arbitrary auxiliary sequence. -/
def MainReductionDenominatorObligation : Prop :=
  ∀ p : ℕ, p.Prime → mainEligible p →
    p ∣ exampleMultipleDenominator (addOrderOf (mainCurveFamily.point p))

theorem mainDenominatorArithmetic {C : ℝ}
    (hheight : ExampleQuadraticHeightBound C)
    (hreduction : MainReductionDenominatorObligation) :
    DenominatorArithmeticObligation mainCurveFamily mainEligible
      exampleMultipleDenominator C := by
  refine ⟨?_, hreduction⟩
  intro n hn
  exact ⟨exampleMultipleDenominator_pos n, exampleMultipleDenominator_log_le hheight hn⟩

def MainPrimitivePrime (p : ℕ) : Prop :=
  eligibleGenerator mainCurveFamily mainEligible p

/-- The predicate counted in the conclusion means generation by the actual
reduction of `(2,2)`, not by an unspecified point of an abstract group. -/
theorem mainPrimitivePrime_iff (p : ℕ) [hp : Fact p.Prime] (hp8 : p % 8 = 3) :
    MainPrimitivePrime p ↔
      AddSubgroup.zmultiples (reductionPoint p (by omega : p ≠ 2)) = ⊤ := by
  have hp2 : p ≠ 2 := by omega
  let e := mainCurveGroupEquiv p hp2
  change (mainEligible p ∧ AddSubgroup.zmultiples (mainCurvePoint p) = ⊤) ↔ _
  have helig : mainEligible p := hp8
  simp only [helig, true_and]
  constructor
  · intro h
    have hm := congrArg (fun S : AddSubgroup (mainCurveGroup p) => S.map e.toAddMonoidHom) h
    rw [AddMonoidHom.map_zmultiples, AddSubgroup.map_top_of_surjective _ e.surjective] at hm
    change AddSubgroup.zmultiples (e (mainCurvePoint p)) = ⊤ at hm
    rw [show e (mainCurvePoint p) = reductionPoint p hp2 from
      mainCurveGroupEquiv_point p hp2] at hm
    exact hm
  · intro h
    have hm := congrArg (fun S : AddSubgroup (reductionCurve p).toAffine.Point =>
      S.map e.symm.toAddMonoidHom) h
    rw [AddMonoidHom.map_zmultiples,
      AddSubgroup.map_top_of_surjective _ e.symm.surjective] at hm
    have hpoint : e.symm (reductionPoint p hp2) = mainCurvePoint p :=
      (e.symm_apply_eq).mpr (mainCurveGroupEquiv_point p hp2).symm
    change AddSubgroup.zmultiples (e.symm (reductionPoint p hp2)) = ⊤ at hm
    rw [hpoint] at hm
    exact hm

/-- The assembled endpoint for the actual curve and point. It remains
conditional on the explicitly identified original candidate-sieve and
division-field obligations, in addition to the stated classical arithmetic
and analytic facts and the Dedekind zero-free hypothesis. It does not assume
the intermediate density estimate or an arbitrary favorable-prime predicate.
-/
theorem main_curve_quantitative_prime_proportion
    (K : ℕ → Type) [∀ q, Field (K q)] [∀ q, NumberField (K q)]
    (r : ℕ → ℕ) (f : SplittingSmoothing)
    (A A₀ B₀ R₀ T D Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hA₀ : 0 ≤ A₀) (hB₀ : 0 ≤ B₀)
    (hR₀ : 0 ≤ R₀) (hD : 0 ≤ D)
    (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hcandidate : CandidateMassObligation mainEligible mainCandidate A Y₀ ε₀)
    (hfields : DivisionFieldArithmeticObligation mainCurveFamily mainEligible K r D Y₀)
    (hreduction : MainReductionDenominatorObligation)
    (hcount : ClassicalDyadicZeroCount A₀)
    (hdecay : ClassicalMellinDecay f B₀)
    (hformula : ClassicalSmoothedExplicitFormula f R₀ T) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x := by
  obtain ⟨Hheight, hheightC, hheight⟩ := exists_example_quadratic_height_bound
  exact quantitative_generator_proportion_of_source_and_arithmetic_obligations
    mainCurveFamily mainEligible mainCandidate mainCofactor mainLargePrime
    exampleMultipleDenominator K r f 4 2 A A₀ B₀ R₀ T D Hheight Y₀ ε₀
    (by norm_num) hA hA₀ hB₀ hR₀ hD hheightC.le hY₀ hε₀
    mainCandidateArithmetic hcandidate hfields
    (mainDenominatorArithmetic hheight hreduction) hcount hdecay hformula

end Elliptic
