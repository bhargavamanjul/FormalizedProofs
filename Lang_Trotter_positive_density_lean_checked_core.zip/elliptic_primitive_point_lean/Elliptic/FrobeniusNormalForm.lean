module

public import Elliptic.AffineFixedPoints
public import Mathlib.LinearAlgebra.AffineSpace.AffineEquiv
public import Mathlib.LinearAlgebra.Basis.Fin
public import Mathlib.LinearAlgebra.Trace
public import Mathlib.LinearAlgebra.Determinant
public import Mathlib.Tactic.LinearCombination

/-!
# The two-dimensional Frobenius normal form

This file derives the affine normal form from the actual linear trace zero
and determinant minus one in characteristic different from two. The change
of coordinates is constructed explicitly, rather than supplied as an
unproved conjugacy. Identifying the trace and determinant of the elliptic
Frobenius representation remains a separate arithmetic input.
-/

@[expose] public section

noncomputable section

namespace Elliptic

variable {k : Type*} [Field k]

/-- Coordinates along the two eigenlines when the upper-right matrix
entry is nonzero. This map is invertible without any eigenbasis assumption.
-/
def eigenCoordinates (a b : k) (h2 : (2 : k) ≠ 0) (hb : b ≠ 0) :
    (k × k) ≃ₗ[k] (k × k) where
  toFun z := ((a + 1) * z.1 + b * z.2, (1 - a) * z.1 - b * z.2)
  invFun z := ((z.1 + z.2) / 2, ((1 - a) * z.1 - (a + 1) * z.2) / (2 * b))
  left_inv z := by
    apply Prod.ext <;> dsimp
    · field_simp; ring
    · field_simp; ring
  right_inv z := by
    apply Prod.ext <;> dsimp
    · field_simp; ring
    · field_simp; ring
  map_add' z w := by
    apply Prod.ext <;> simp only [Prod.fst_add, Prod.snd_add] <;> ring
  map_smul' t z := by
    apply Prod.ext <;> simp only [Prod.smul_fst, Prod.smul_snd, smul_eq_mul,
      RingHom.id_apply] <;> ring

/-- The shear required when the upper-right entry vanishes. -/
def shearCoordinates (t : k) : (k × k) ≃ₗ[k] (k × k) where
  toFun z := (z.1, z.2 + t * z.1)
  invFun z := (z.1, z.2 - t * z.1)
  left_inv z := by
    apply Prod.ext
    · rfl
    · dsimp; ring
  right_inv z := by
    apply Prod.ext
    · rfl
    · dsimp; ring
  map_add' z w := by
    apply Prod.ext
    · rfl
    · simp only [Prod.fst_add, Prod.snd_add]; ring
  map_smul' t z := by
    apply Prod.ext
    · rfl
    · simp only [Prod.smul_fst, Prod.smul_snd, smul_eq_mul, RingHom.id_apply]; ring

theorem exists_normal_coordinates (a b c d : k) (h2 : (2 : k) ≠ 0)
    (htrace : a + d = 0) (hdet : a * d - b * c = -1) :
    ∃ e : (k × k) ≃ₗ[k] (k × k), ∀ z : k × k,
      e (a * z.1 + b * z.2, c * z.1 + d * z.2) = ((e z).1, -(e z).2) := by
  have hd : d = -a := eq_neg_of_add_eq_zero_right htrace
  have hrel : a ^ 2 + b * c = 1 := by rw [hd] at hdet; linear_combination -hdet
  by_cases hb : b = 0
  · have ha : a = 1 ∨ a = -1 := by
      have hs : (a - 1) * (a + 1) = 0 := by
        rw [hb] at hrel
        linear_combination hrel
      rcases mul_eq_zero.mp hs with h | h
      · exact Or.inl (sub_eq_zero.mp h)
      · exact Or.inr (eq_neg_of_add_eq_zero_left h)
    rcases ha with ha | ha
    · refine ⟨shearCoordinates (-c / 2), ?_⟩
      intro z
      apply Prod.ext <;> simp only [shearCoordinates, LinearEquiv.coe_mk,
        LinearMap.coe_mk, AddHom.coe_mk, ha, hb, hd]
      · ring
      · field_simp; ring
    · refine ⟨(shearCoordinates (c / 2)).trans (LinearEquiv.prodComm k k k), ?_⟩
      intro z
      apply Prod.ext <;> simp only [LinearEquiv.trans_apply, shearCoordinates,
        LinearEquiv.coe_mk, LinearMap.coe_mk, AddHom.coe_mk,
        LinearEquiv.prodComm_apply, ha, hb, hd] <;> dsimp
      · field_simp; ring
      · ring
  · refine ⟨eigenCoordinates a b h2 hb, ?_⟩
    intro z
    apply Prod.ext <;> simp only [eigenCoordinates, LinearEquiv.coe_mk,
      LinearMap.coe_mk, AddHom.coe_mk, hd]
    · linear_combination z.1 * hrel
    · linear_combination -z.1 * hrel

theorem linearMap_pair_coordinates (L : (k × k) →ₗ[k] (k × k)) (z : k × k) :
    L z = ((L (1, 0)).1 * z.1 + (L (0, 1)).1 * z.2,
      (L (1, 0)).2 * z.1 + (L (0, 1)).2 * z.2) := by
  have hz : z = z.1 • ((1, 0) : k × k) + z.2 • ((0, 1) : k × k) := by
    ext <;> simp
  conv_lhs => rw [hz, map_add, map_smul, map_smul]
  ext <;> simp [mul_comm]

theorem trace_pair_coordinates (L : (k × k) →ₗ[k] (k × k)) :
    LinearMap.trace k (k × k) L = (L (1, 0)).1 + (L (0, 1)).2 := by
  rw [LinearMap.trace_eq_matrix_trace k (Module.Basis.finTwoProd k), Matrix.trace_fin_two]
  simp [LinearMap.toMatrix_apply]

theorem det_pair_coordinates (L : (k × k) →ₗ[k] (k × k)) :
    LinearMap.det L = (L (1, 0)).1 * (L (0, 1)).2 -
      (L (0, 1)).1 * (L (1, 0)).2 := by
  rw [← LinearMap.det_toMatrix (Module.Basis.finTwoProd k), Matrix.det_fin_two]
  simp [LinearMap.toMatrix_apply]

/-- Genuine linear normal form deduced from trace and determinant. -/
theorem exists_linear_normal_form (L : (k × k) →ₗ[k] (k × k))
    (h2 : (2 : k) ≠ 0) (htrace : LinearMap.trace k (k × k) L = 0)
    (hdet : LinearMap.det L = -1) :
    ∃ e : (k × k) ≃ₗ[k] (k × k), ∀ z,
      e (L z) = ((e z).1, -(e z).2) := by
  rw [trace_pair_coordinates] at htrace
  rw [det_pair_coordinates] at hdet
  obtain ⟨e, he⟩ := exists_normal_coordinates
    (L (1, 0)).1 (L (0, 1)).1 (L (1, 0)).2 (L (0, 1)).2 h2 htrace hdet
  exact ⟨e, fun z => by rw [linearMap_pair_coordinates L z]; exact he z⟩

/-- The affine normal form follows by transporting the translation vector
through the constructed linear change of coordinates. -/
theorem exists_affine_normal_form (f : (k × k) ≃ᵃ[k] (k × k))
    (h2 : (2 : k) ≠ 0)
    (htrace : LinearMap.trace k (k × k) f.linear.toLinearMap = 0)
    (hdet : LinearMap.det f.linear.toLinearMap = -1) :
    ∃ e : (k × k) ≃ₗ[k] (k × k), ∃ b₁ b₂ : k,
      ∀ z, e (f z) = affineNormalForm b₁ b₂ (e z) := by
  obtain ⟨e, he⟩ := exists_linear_normal_form f.linear.toLinearMap h2 htrace hdet
  refine ⟨e, (e (f 0)).1, (e (f 0)).2, ?_⟩
  intro z
  have hf : f z = f.linear z + f 0 := by
    have h := congrFun f.toAffineMap.decomp z
    exact h
  have hez : e (f.linear z) = ((e z).1, -(e z).2) := he z
  rw [hf, map_add, hez]
  rfl

end Elliptic
