module

public import Artin.MarkedSource
public import Artin.BuchstabSieve
public import Artin.PrimeDistribution
public import Elliptic.SmoothedFormula

/-!
# Exact imported analytic statements

The cited unsigned source statements are retained byte-for-byte in the
`Artin` dependency modules, including the literal mn-1 weights and every
uniformity quantifier. They are hypotheses, not additional global axioms.
The signed mn+1 replacement bound remains an original proof obligation;
this record deliberately contains no such bound or candidate estimate.

See docs/accepted-inputs.txt for source versions, equations and the precise
distinction between source theorems and the sign extension of their proof.
-/

@[expose] public section
namespace Elliptic

/-- The exact OpenAI estimates cited by the candidate sieve. None of these
fields asserts that the signed adaptation has already been established. -/
structure OpenAIUnsignedAnalyticStatements : Prop where
  /-- Artin companion Lemma 10.2, uniform scalar marked criterion (10.5)-(10.6). -/
  scalarCriterion : Artin.MarkedSource.SourceLemma10_2
  /-- Artin companion Proposition 10.3, transform estimates for rough discrepancy. -/
  roughTransforms : Artin.MarkedSource.SourceProposition10_3
  /-- Artin companion Lemma 11.1, finite weighted block sieve. -/
  blockSieve : Artin.BuchstabSieve.SourceLemma11_1

/-- Classical analytic inputs for progression and smoothing; their definitions
give actual prime sums, characters and Fourier integrals, not abstract errors.
Further classical Mertens/Buchstab inputs are enumerated in the source ledger
and must be retained when the rest of the successor sieve is connected. -/
structure ClassicalProgressionAnalyticStatements : Prop where
  bombieriVinogradov : Artin.PrimeDistribution.BombieriVinogradovSource
  fixedModulusPNT : Artin.PrimeDistribution.FixedModulusPNTSource
  reciprocalBandMass : Artin.MarkedSource.ClassicalBandMass
  fourierInversion : Artin.MarkedSource.ClassicalFourierInversion

/-- The exact three classical number-field analytic statements used by the
checked QRH deduction. The constants and threshold precede all number fields. -/
structure ClassicalDedekindAnalyticStatements (f : SplittingSmoothing) where
  zeroCountConstant : ℝ
  mellinDecayConstant : ℝ
  remainderConstant : ℝ
  threshold : ℝ
  zeroCountConstant_nonneg : 0 ≤ zeroCountConstant
  mellinDecayConstant_nonneg : 0 ≤ mellinDecayConstant
  remainderConstant_nonneg : 0 ≤ remainderConstant
  zeroCount : ClassicalDyadicZeroCount zeroCountConstant
  mellinDecay : ClassicalMellinDecay f mellinDecayConstant
  explicitFormula : ClassicalSmoothedExplicitFormula f remainderConstant threshold

/-- The zero-free input is separately parameterized; a numerical value is
never asserted by this project. -/
def CuretonThornerZeroFreeInput (N : ℝ) : Prop := DedekindQRH N

end Elliptic
