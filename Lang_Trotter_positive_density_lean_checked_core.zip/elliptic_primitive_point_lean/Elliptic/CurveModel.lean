module

public import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
public import Mathlib.Tactic.NormNum

/-!
# The concrete elliptic curve and rational point in Theorem 1

The curve and points in this file use mathlib's actual `WeierstrassCurve`
and `WeierstrassCurve.Affine.Point` definitions and group law. We verify
the discriminant, nonsingularity, the point `(2,2)`, and its double.
The later module `InfiniteOrder` proves that the point has infinite order
directly by rational 2-adic valuations. `CurveReduction` checks the actual
finite-field cardinality and non-doubling assertions used in the application.
-/

@[expose] public section

namespace Elliptic

/-- The rational curve `y² = x³ - 2x` in Theorem 1. -/
def exampleCurve : WeierstrassCurve ℚ :=
  ⟨0, 0, 0, -2, 0⟩

theorem exampleCurve_discriminant : exampleCurve.Δ = 512 := by
  norm_num [exampleCurve, WeierstrassCurve.Δ, WeierstrassCurve.b₂,
    WeierstrassCurve.b₄, WeierstrassCurve.b₆, WeierstrassCurve.b₈]

theorem exampleCurve_discriminant_ne_zero : exampleCurve.Δ ≠ 0 := by
  rw [exampleCurve_discriminant]
  norm_num

instance exampleCurve_isElliptic : exampleCurve.IsElliptic :=
  ⟨isUnit_iff_ne_zero.mpr exampleCurve_discriminant_ne_zero⟩

theorem exampleCurve_j : exampleCurve.j = 1728 := by
  rw [WeierstrassCurve.j_eq, exampleCurve_discriminant]
  norm_num [exampleCurve, WeierstrassCurve.c₄, WeierstrassCurve.b₂,
    WeierstrassCurve.b₄]

theorem examplePoint_equation : exampleCurve.toAffine.Equation 2 2 := by
  rw [WeierstrassCurve.Affine.equation_iff]
  norm_num [exampleCurve]

theorem examplePoint_nonsingular : exampleCurve.toAffine.Nonsingular 2 2 :=
  WeierstrassCurve.Affine.equation_iff_nonsingular.mp examplePoint_equation

/-- The actual rational point `P = (2,2)`. -/
def examplePoint : exampleCurve.toAffine.Point :=
  .mk examplePoint_equation

theorem examplePoint_ne_zero : examplePoint ≠ 0 := by
  simp [examplePoint, WeierstrassCurve.Affine.Point.mk]

theorem exampleDouble_equation : exampleCurve.toAffine.Equation (9 / 4) (-21 / 8) := by
  rw [WeierstrassCurve.Affine.equation_iff]
  norm_num [exampleCurve]

/-- The actual group-law computation `2P = (9/4,-21/8)`. -/
theorem examplePoint_double :
    examplePoint + examplePoint =
      WeierstrassCurve.Affine.Point.mk exampleDouble_equation := by
  norm_num [examplePoint, WeierstrassCurve.Affine.Point.mk,
    WeierstrassCurve.Affine.Point.add_def, WeierstrassCurve.Affine.Point.add,
    WeierstrassCurve.Affine.slope, WeierstrassCurve.Affine.addX,
    WeierstrassCurve.Affine.addY, WeierstrassCurve.Affine.negAddY,
    WeierstrassCurve.Affine.negY, exampleCurve]

/-- The doubled point has nonintegral first coordinate. A separate
Nagell--Lutz theorem would turn this into an infinite-order proof; no such
theorem is assumed or declared as an axiom here. -/
theorem exampleDouble_x_not_integral : ¬ ∃ n : ℤ, (n : ℚ) = 9 / 4 := by
  rintro ⟨n, hn⟩
  have hden := congrArg Rat.den hn
  norm_num at hden

theorem rationalTwoTorsion_equation : exampleCurve.toAffine.Equation 0 0 := by
  rw [WeierstrassCurve.Affine.equation_iff]
  norm_num [exampleCurve]

/-- The nonidentity rational point of order two visible in the equation. -/
def rationalTwoTorsion : exampleCurve.toAffine.Point :=
  .mk rationalTwoTorsion_equation

theorem rationalTwoTorsion_ne_zero : rationalTwoTorsion ≠ 0 := by
  simp [rationalTwoTorsion, WeierstrassCurve.Affine.Point.mk]

theorem rationalTwoTorsion_double : rationalTwoTorsion + rationalTwoTorsion = 0 := by
  norm_num [rationalTwoTorsion, WeierstrassCurve.Affine.Point.mk,
    WeierstrassCurve.Affine.Point.add_def, WeierstrassCurve.Affine.Point.add,
    WeierstrassCurve.Affine.negY, exampleCurve]

end Elliptic
