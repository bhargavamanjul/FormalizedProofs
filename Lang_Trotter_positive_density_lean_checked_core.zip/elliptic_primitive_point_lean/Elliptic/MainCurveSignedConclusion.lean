module

public import Elliptic.MainCurveGeometricConclusion
public import Elliptic.Sieve.SuccessorCandidateAssembly

/-!
# Actual main-curve endpoint after completing the successor sieve

The candidate, rough, semiprime, tail and weighted distribution estimates
are now deductions. The original signed scalar criterion remains explicit:
its complete operator-moment proof is not yet formalized. The geometric
arithmetic inputs are also explicit classical statements on actual fields.
Consequently this file does not assert certification from OpenAI and
Cureton--Thorner alone.
-/

@[expose] public section
noncomputable section
namespace Elliptic
open Filter Arithmetic
open scoped Topology

/-- The full counting conclusion with no candidate-counting premise.
The sole remaining original analytic premise is SignedScalarCriterion. -/
theorem main_curve_proportion_from_signed_and_geometric_sources
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (D : MainGeometricDivisionFamily) (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : D.GlobalInputs S Yarith) (hlocal : MainGeometricLocalInputs D Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x := by
  obtain ⟨A, Ysieve, ε₀, hA, _hYsieve, hε₀, hcand⟩ :=
    Sieve.SuccessorCandidateAssembly.main_candidate_mass_of_signed_criterion signed sources
  let Y₀ := max 2 (max Ysieve Yarith)
  have hY2 : 2 ≤ Y₀ := le_max_left _ _
  have hYs : Ysieve ≤ Y₀ := (le_max_left _ _).trans (le_max_right _ _)
  have hYa : Yarith ≤ Y₀ := (le_max_right _ _).trans (le_max_right _ _)
  apply main_curve_proportion_of_geometric_inputs D S f A Y₀ ε₀ hA hY2 hε₀
  · intro q hq hYq
    exact hglobal q hq (hYa.trans_lt hYq)
  · intro q hq hYq
    exact hlocal q hq (hYa.trans_lt hYq)
  · intro ε Y hε hεmax hY hY1
    exact hcand ε Y hε hεmax (hYs.trans hY) hY1
  · exact hanalytic

/-- Infinitude for the actual pair, with the same explicitly conditional
source boundary and one specified Dedekind zero-free instance. -/
theorem main_curve_infinitely_many_from_signed_and_geometric_sources
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (D : MainGeometricDivisionFamily) (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : D.GlobalInputs S Yarith) (hlocal : MainGeometricLocalInputs D Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_signed_and_geometric_sources signed sources D S Yarith
      hglobal hlocal f hanalytic) hN hQRH

end Elliptic
