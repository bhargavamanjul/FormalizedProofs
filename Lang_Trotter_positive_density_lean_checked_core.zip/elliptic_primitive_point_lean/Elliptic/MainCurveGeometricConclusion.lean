module

public import Elliptic.MainCurveGaloisConclusion
public import Elliptic.Arithmetic.GeometricFamily

/-!
# Main-curve conclusion from actual geometric arithmetic inputs

No abstract affine representation, full-translation assertion, Frobenius
trace/determinant condition, rational torsion count, or affine fixed-point
condition is an assumption of this endpoint. They are derived from the
actual division fields, Ribet's Kummer surjectivity, the determinant
character, and the classical Frobenius polynomial and specialization maps.

Existence of these geometric fields and the precise standard arithmetic
inputs is still explicit. The separate candidate estimate is supplied in `MainCurveSignedConclusion`
from the signed scalar criterion, whose operator proof remains unfinished.
-/

@[expose] public section
noncomputable section

namespace Elliptic

open Arithmetic Filter
open scoped Topology

abbrev MainGeometricDivisionFamily := GeometricDivisionFamily exampleCurve examplePoint

/-- Good-reduction geometry at each eligible p and each smaller q. This
contains actual specialization maps and the classical characteristic
polynomial, and no numerical bound on the set of such primes. -/
def MainGeometricLocalInputs (D : MainGeometricDivisionFamily) (Y₀ : ℝ) : Prop :=
  ∀ n : ℕ, n.Prime → Y₀ < (n : ℝ) →
    ∀ p : ℕ, ∀ hp : p.Prime, ∀ hp8 : p % 8 = 3, n < p →
      letI : Fact p.Prime := ⟨hp⟩
      Nonempty ((D n).LocalInputs p (reductionCurve p)
        (reductionPoint p (by omega : p ≠ 2)))

/-- Point index is invariant under an actual additive group equivalence. -/
theorem pointIndex_addEquiv {G H : Type*} [AddGroup G] [AddGroup H]
    (e : G ≃+ H) (P : G) : pointIndex (e P) = pointIndex P := by
  simpa [pointIndex] using (AddSubgroup.zmultiples P).index_map_equiv e

theorem mainGeometric_localArithmetic (D : MainGeometricDivisionFamily)
    {Y₀ : ℝ} (hY₀ : 2 ≤ Y₀) (hlocal : MainGeometricLocalInputs D Y₀) :
    D.toGaloisFamily.LocalArithmetic mainCurveFamily mainEligible Y₀ := by
  intro n hn hYn p hp hpel hnp hindex
  let : Fact p.Prime := ⟨hp⟩
  have hp8 : p % 8 = 3 := hpel
  have hp2 : p ≠ 2 := by omega
  obtain ⟨d⟩ := hlocal n hn hYn p hp hp8 hnp
  let : Finite (CurvePoints (reductionCurve p) (ZMod p)) := by
    change Finite (reductionCurve p).toAffine.Point
    infer_instance
  have hqval : (primeParameter n).val = n := primeParameter_val_of_prime hn
  have h2 : (2 : ZMod (primeParameter n).val) ≠ 0 := by
    have hn2 : 2 < n := by exact_mod_cast hY₀.trans_lt hYn
    intro hz
    have hd : (primeParameter n).val ∣ 2 := (ZMod.natCast_eq_zero_iff _ _).1 hz
    rw [hqval] at hd
    have hle := Nat.le_of_dvd (by norm_num : 0 < 2) hd
    omega
  have hpointcount : Nat.card (CurvePoints (reductionCurve p) (ZMod p)) = p + 1 := by
    change Nat.card (reductionCurve p).toAffine.Point = p + 1
    exact card_reduction_points p (by omega)
  have hindex' : (primeParameter n).val ∣ pointIndex (reductionPoint p hp2) := by
    rw [hqval, ← mainCurveGroupEquiv_point p hp2,
      pointIndex_addEquiv (mainCurveGroupEquiv p hp2)]
    exact hindex
  obtain ⟨hχ, htrace, hdet, hfixed⟩ :=
    (D n).localConditions p (reductionCurve p) (reductionPoint p hp2)
      d h2 hpointcount hindex'
  exact ⟨d.frobenius, d.primeData, hχ, htrace, hdet, hfixed⟩

/-- The original arithmetic interface is discharged from source-facing
geometric data for the actual curve and point. -/
theorem mainGeometric_arithmeticInputs (D : MainGeometricDivisionFamily)
    (S : Finset ℕ) {Y₀ : ℝ} (hY₀ : 2 ≤ Y₀)
    (hglobal : D.GlobalInputs S Y₀) (hlocal : MainGeometricLocalInputs D Y₀) :
    MainCurveArithmeticInputs D.toGaloisFamily S Y₀ :=
  ⟨D.globalArithmetic S hY₀ hglobal, mainGeometric_localArithmetic D hY₀ hlocal⟩

/-- Quantitative positive proportion with all affine and local finite-group
conditions proved from the actual geometric source data. -/
theorem main_curve_proportion_of_geometric_inputs
    (D : MainGeometricDivisionFamily) (S : Finset ℕ) (f : SplittingSmoothing)
    (A Y₀ ε₀ : ℝ) (hA : 0 < A) (hY₀ : 2 ≤ Y₀) (hε₀ : 0 < ε₀)
    (hglobal : D.GlobalInputs S Y₀) (hlocal : MainGeometricLocalInputs D Y₀)
    (hcandidate : CandidateMassObligation mainEligible mainCandidate A Y₀ ε₀)
    (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x := by
  exact main_curve_proportion_of_explicit_galois_data D.toGaloisFamily S f A Y₀ ε₀
    hA (by linarith) hε₀ (mainGeometric_arithmeticInputs D S hY₀ hglobal hlocal)
    hcandidate hanalytic

theorem main_curve_infinitely_many_of_geometric_inputs
    (D : MainGeometricDivisionFamily) (S : Finset ℕ) (f : SplittingSmoothing)
    (A Y₀ ε₀ : ℝ) (hA : 0 < A) (hY₀ : 2 ≤ Y₀) (hε₀ : 0 < ε₀)
    (hglobal : D.GlobalInputs S Y₀) (hlocal : MainGeometricLocalInputs D Y₀)
    (hcandidate : CandidateMassObligation mainEligible mainCandidate A Y₀ ε₀)
    (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_of_geometric_inputs D S f A Y₀ ε₀ hA hY₀ hε₀
      hglobal hlocal hcandidate hanalytic) hN hQRH

end Elliptic
