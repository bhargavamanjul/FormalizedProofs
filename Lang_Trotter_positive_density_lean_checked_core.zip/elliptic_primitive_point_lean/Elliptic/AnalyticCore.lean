module

/- Adapted from the earlier Artin formalization, Splitting.lean.
The statements in this module are generic and do not assert an elliptic
prime-count estimate. See docs/source-boundary-audit.txt. -/

public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Topology.Algebra.InfiniteSum.ENNReal
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

/-!
# The normalization and summation in Section 10

These are proved inequalities, not axioms for splitting estimates. The
smoothed explicit formula, the uniform bound on its zero contribution, and
the interpretation of split primes as positive terms in its ideal sum must
be supplied to `smoothed_split_normalization`. Its variables `n`, `d`, `L`,
and `E` represent the degree, logarithmic discriminant, `log x`, and
`x ^ (1 - δ)`, respectively.

The finite prime summation uses mathlib's proved Chebyshev upper bound.
The number-field inputs remain separate analytic/algebraic obligations.
The reciprocal prime tail is proved separately in `ReciprocalPrimeTail`.
-/

@[expose] public section

namespace Elliptic

open scoped BigOperators

/-- Apply a common zero-free bound to a summable family of Mellin weights.
For a zero `ρ`, take `beta ρ = ρ.re` and `w ρ = ‖fhat ρ‖`. The summability
and total mass bound are the analytic inputs; the bound on `beta` is QRH.
-/
theorem zero_weighted_sum_bound {ι : Type*} {x δ H : ℝ}
    (beta w : ι → ℝ) (hx : 1 ≤ x)
    (hbeta : ∀ ρ, beta ρ ≤ 1 - δ) (hw0 : ∀ ρ, 0 ≤ w ρ)
    (hw : Summable w) (hH : ∑' ρ, w ρ ≤ H) :
    Summable (fun ρ => x ^ beta ρ * w ρ) ∧
      (∑' ρ, x ^ beta ρ * w ρ) ≤ x ^ (1 - δ) * H := by
  have hx0 : 0 ≤ x := by linarith
  have hmajor : ∀ ρ, x ^ beta ρ * w ρ ≤ x ^ (1 - δ) * w ρ :=
    fun ρ => mul_le_mul_of_nonneg_right
      (Real.rpow_le_rpow_of_exponent_le hx (hbeta ρ)) (hw0 ρ)
  have hconst : Summable (fun ρ => x ^ (1 - δ) * w ρ) := hw.mul_left _
  have hvar : Summable (fun ρ => x ^ beta ρ * w ρ) :=
    Summable.of_nonneg_of_le
      (fun ρ => mul_nonneg (Real.rpow_nonneg hx0 _) (hw0 ρ)) hmajor hconst
  refine ⟨hvar, ?_⟩
  calc
    (∑' ρ, x ^ beta ρ * w ρ) ≤ ∑' ρ, x ^ (1 - δ) * w ρ :=
      hvar.tsum_le_tsum hmajor hconst
    _ = x ^ (1 - δ) * ∑' ρ, w ρ := hw.tsum_mul_left _
    _ ≤ x ^ (1 - δ) * H :=
      mul_le_mul_of_nonneg_left hH (Real.rpow_nonneg hx0 _)

/-- The real explicit formula gives an upper bound after bounding its zero
term and remainder in absolute value. This lemma neither assumes a
splitting-prime estimate nor conceals one in an axiom.
-/
theorem smoothed_formula_upper_bound {S m X Z R E C d n L : ℝ}
    (hformula : S = m * X - Z + R)
    (hzeros : |Z| ≤ E * C * (d + n)) (hrest : |R| ≤ C * n * L) :
    S ≤ m * X + E * C * (d + n) + C * n * L := by
  have hZ := neg_le_abs Z
  have hR := le_abs_self R
  linarith

/-- Divide the positive smoothed ideal-sum bound by `n * log x`.

`hdominance` is the contribution of completely split primes. `hformula`
is the upper estimate furnished by the smoothed explicit formula together
with the bound on the sum over zeros. The archimedean remainder is retained.
-/
theorem smoothed_split_normalization
    {n L X E B S m C d : ℝ} (hn : 0 < n) (hL : 0 < L)
    (hdominance : n * L * B ≤ S)
    (hformula : S ≤ m * X + E * C * (d + n) + C * n * L) :
    B ≤ m * X / (n * L) + C * E / L * (d / n + 1) + C := by
  calc
    B ≤ (m * X + E * C * (d + n) + C * n * L) / (n * L) := by
      apply (le_div_iff₀ (mul_pos hn hL)).2
      nlinarith [hdominance.trans hformula]
    _ = m * X / (n * L) + C * E / L * (d / n + 1) + C := by
      field_simp

/-- Absorb the remaining absolute constant when `log x ≤ x ^ (1 - δ)`.
The constants in this algebraic deduction do not depend on `n` or `δ`.
-/
theorem smoothed_split_bound_absorbed
    {n L X E B S m C d : ℝ} (hn : 0 < n) (hL : 0 < L)
    (hC : 0 ≤ C) (hLE : L ≤ E)
    (hdominance : n * L * B ≤ S)
    (hformula : S ≤ m * X + E * C * (d + n) + C * n * L) :
    B ≤ m * X / (n * L) + C * E / L * (d / n + 2) := by
  have hCE : C ≤ C * E / L := by
    apply (le_div_iff₀ hL).2
    exact mul_le_mul_of_nonneg_left hLE hC
  calc
    B ≤ m * X / (n * L) + C * E / L * (d / n + 1) + C :=
      smoothed_split_normalization hn hL hdominance hformula
    _ ≤ m * X / (n * L) + C * E / L * (d / n + 1) + C * E / L :=
      add_le_add le_rfl hCE
    _ = m * X / (n * L) + C * E / L * (d / n + 2) := by ring

/-- A uniform elementary bound sufficient to absorb the archimedean
remainder for every `δ ≤ 1/2` and `x ≥ 1`. -/
theorem log_le_twice_splitting_power {x δ : ℝ}
    (hx : 1 ≤ x) (hδ : δ ≤ 1 / 2) :
    Real.log x ≤ 2 * x ^ (1 - δ) := by
  have hlog := Real.log_le_rpow_div (show 0 ≤ x by linarith)
    (show (0 : ℝ) < 1 / 2 by norm_num)
  have hpow : x ^ (1 / 2 : ℝ) ≤ x ^ (1 - δ) :=
    Real.rpow_le_rpow_of_exponent_le hx (by linarith)
  nlinarith

/-- The bound with the actual zero-free exponent and an absolute constant
`3` in the normalized discriminant term. No threshold depends on `δ`.
The smoothed analytic estimate remains an explicit hypothesis.
-/
theorem smoothed_split_bound_uniform
    {n x δ B S m C d : ℝ} (hn : 0 < n) (hx : 1 < x)
    (hδ : δ ≤ 1 / 2) (hC : 0 ≤ C)
    (hdominance : n * Real.log x * B ≤ S)
    (hformula : S ≤ m * x + x ^ (1 - δ) * C * (d + n) + C * n * Real.log x) :
    B ≤ m * x / (n * Real.log x) +
      C * x ^ (1 - δ) / Real.log x * (d / n + 3) := by
  have hL : 0 < Real.log x := Real.log_pos hx
  have hCL : C ≤ 2 * (C * x ^ (1 - δ) / Real.log x) := by
    have hmul := mul_le_mul_of_nonneg_left (log_le_twice_splitting_power hx.le hδ) hC
    calc
      C ≤ C * (2 * x ^ (1 - δ)) / Real.log x := (le_div_iff₀ hL).2 hmul
      _ = 2 * (C * x ^ (1 - δ) / Real.log x) := by ring
  calc
    B ≤ m * x / (n * Real.log x) +
        C * x ^ (1 - δ) / Real.log x * (d / n + 1) + C :=
      smoothed_split_normalization hn hL hdominance hformula
    _ ≤ m * x / (n * Real.log x) +
        C * x ^ (1 - δ) / Real.log x * (d / n + 1) +
        2 * (C * x ^ (1 - δ) / Real.log x) := add_le_add le_rfl hCL
    _ = m * x / (n * Real.log x) +
        C * x ^ (1 - δ) / Real.log x * (d / n + 3) := by ring

/-- The full inequality deduction from the explicitly listed analytic inputs.

Here `Z` is the real zero contribution, `beta` lists the zeros' real parts,
and `w` lists the nonnegative absolute Mellin weights. The assumptions are
the exact smoothed formula, positivity for split primes, QRH, the Mellin
mass estimate, the triangle inequality for the zero contribution, and the
archimedean remainder estimate. The conclusion is a proved consequence of
those inputs, uniform in the degree and in `δ ≤ 1/2`.
-/
theorem splitting_from_smoothed_inputs {ι : Type*}
    {n x δ B S m C d Z R : ℝ} (beta w : ι → ℝ)
    (hn : 0 < n) (hx : 1 < x) (hδ : δ ≤ 1 / 2) (hC : 0 ≤ C)
    (hdominance : n * Real.log x * B ≤ S)
    (hformula : S = m * x - Z + R)
    (hbeta : ∀ ρ, beta ρ ≤ 1 - δ) (hw0 : ∀ ρ, 0 ≤ w ρ)
    (hw : Summable w) (hmass : ∑' ρ, w ρ ≤ C * (d + n))
    (hzero : |Z| ≤ ∑' ρ, x ^ beta ρ * w ρ)
    (hrest : |R| ≤ C * n * Real.log x) :
    B ≤ m * x / (n * Real.log x) +
      C * x ^ (1 - δ) / Real.log x * (d / n + 3) := by
  have hzeros : |Z| ≤ x ^ (1 - δ) * C * (d + n) := by
    simpa [mul_assoc] using hzero.trans
      (zero_weighted_sum_bound beta w hx.le hbeta hw0 hw hmass).2
  exact smoothed_split_bound_uniform hn hx hδ hC hdominance
    (smoothed_formula_upper_bound hformula hzeros hrest)

/-- Sum two nonnegative multiples of independently controlled functions. -/
theorem sum_two_component_bounds {ι : Type*} (s : Finset ι)
    (B u v : ι → ℝ) {M E U V : ℝ} (hM : 0 ≤ M) (hE : 0 ≤ E)
    (hB : ∀ q ∈ s, B q ≤ M * u q + E * v q)
    (hU : ∑ q ∈ s, u q ≤ U) (hV : ∑ q ∈ s, v q ≤ V) :
    ∑ q ∈ s, B q ≤ M * U + E * V := by
  calc
    ∑ q ∈ s, B q ≤ ∑ q ∈ s, (M * u q + E * v q) :=
      Finset.sum_le_sum hB
    _ = M * (∑ q ∈ s, u q) + E * (∑ q ∈ s, v q) := by
      rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
    _ ≤ M * U + E * V :=
      add_le_add (mul_le_mul_of_nonneg_left hU hM)
        (mul_le_mul_of_nonneg_left hV hE)

/-- The summation which preserves the logarithm in the denominator.

For Kummer fields, `u q = 1 / (q * (q - 1))` and the normalized
discriminant bound has the form `2 * log q + A`. A bound just for the
number of primes would lose a logarithm here; `hlog` is also needed.
-/
theorem sum_splitting_bounds {ι : Type*} (s : Finset ι)
    (B u ell : ι → ℝ) {M E H A D T : ℝ}
    (hM : 0 ≤ M) (hE : 0 ≤ E) (hA : 0 ≤ A)
    (hB : ∀ q ∈ s, B q ≤ M * u q + E * (2 * ell q + A))
    (hreciprocal : ∑ q ∈ s, u q ≤ H)
    (hlog : ∑ q ∈ s, ell q ≤ D * T)
    (hcard : (s.card : ℝ) ≤ T) :
    ∑ q ∈ s, B q ≤ M * H + E * ((2 * D + A) * T) := by
  apply sum_two_component_bounds s B u (fun q => 2 * ell q + A)
    hM hE hB hreciprocal
  calc
    ∑ q ∈ s, (2 * ell q + A) = 2 * (∑ q ∈ s, ell q) + s.card * A := by
      simp [Finset.sum_add_distrib, Finset.mul_sum]
    _ ≤ 2 * (D * T) + T * A :=
      add_le_add (mul_le_mul_of_nonneg_left hlog (by norm_num))
        (mul_le_mul_of_nonneg_right hcard hA)
    _ = (2 * D + A) * T := by ring

/-- Chebyshev's bound for any finite family of primes bounded by `T`.
This is deduced from the theorem already proved in mathlib. -/
theorem sum_log_primes_le (s : Finset ℕ) {T : ℝ} (hT : 0 ≤ T)
    (hprime : ∀ q ∈ s, q.Prime) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T) :
    ∑ q ∈ s, Real.log (q : ℝ) ≤ Real.log 4 * T := by
  apply le_trans ?_ (Chebyshev.theta_le_log4_mul_x hT)
  unfold Chebyshev.theta
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_Ioc]
    exact ⟨⟨(hprime q hq).pos, (Nat.le_floor_iff hT).2 (hupper q hq)⟩,
      hprime q hq⟩
  · intro q _ _
    exact Real.log_natCast_nonneg q

/-- An elementary cardinality bound for a finite set of positive integers. -/
theorem card_le_real_upper_bound (s : Finset ℕ) {T : ℝ} (hT : 0 ≤ T)
    (hpos : ∀ q ∈ s, 0 < q) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T) :
    (s.card : ℝ) ≤ T := by
  have hsub : s ⊆ Finset.Ioc 0 ⌊T⌋₊ := by
    intro q hq
    exact Finset.mem_Ioc.2 ⟨hpos q hq, (Nat.le_floor_iff hT).2 (hupper q hq)⟩
  have hcard : s.card ≤ ⌊T⌋₊ := by
    simpa using Finset.card_le_card hsub
  exact (Nat.cast_le.2 hcard).trans (Nat.floor_le hT)

/-- Combine the preceding two proved bounds in the splitting-prime sum.
Only the reciprocal tail and the individual splitting bounds are inputs.
-/
theorem sum_splitting_bounds_for_primes (s : Finset ℕ)
    (B u : ℕ → ℝ) {M E H A T : ℝ}
    (hM : 0 ≤ M) (hE : 0 ≤ E) (hA : 0 ≤ A) (hT : 0 ≤ T)
    (hprime : ∀ q ∈ s, q.Prime) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T)
    (hB : ∀ q ∈ s, B q ≤ M * u q + E * (2 * Real.log (q : ℝ) + A))
    (hreciprocal : ∑ q ∈ s, u q ≤ H) :
    ∑ q ∈ s, B q ≤ M * H + E * ((2 * Real.log 4 + A) * T) := by
  exact sum_splitting_bounds s B u (fun q => Real.log (q : ℝ))
    hM hE hA hB hreciprocal (sum_log_primes_le s hT hprime hupper)
    (card_le_real_upper_bound s hT (fun q hq => (hprime q hq).pos) hupper)

/-- The exponent in the summed splitting error is `1 - δ + ε`. -/
theorem splitting_error_power_identity {x : ℝ} (hx : 0 < x)
    (δ ε C : ℝ) :
    (x ^ (1 - δ) / Real.log x) * (C * x ^ ε) =
      C * x ^ (1 - δ + ε) / Real.log x := by
  rw [Real.rpow_add hx]
  ring

/-- The margin which permits Bombieri--Vinogradov at the rescaled variable. -/
theorem bv_level_margin (ε κ : ℝ) :
    (1 - ε) * (1 / 2 - (κ - ε) / 4) - (1 / 2 - κ / 2) =
      (κ - ε) * (1 + ε) / 4 := by ring

/-- This margin is strictly positive whenever `0 ≤ ε < κ`. -/
theorem bv_level_margin_pos {ε κ : ℝ} (hε : 0 ≤ ε) (hεκ : ε < κ) :
    1 / 2 - κ / 2 < (1 - ε) * (1 / 2 - (κ - ε) / 4) := by
  have hmargin : 0 < (κ - ε) * (1 + ε) / 4 := by positivity
  rw [← bv_level_margin ε κ] at hmargin
  linarith

end Elliptic
