module

public import Elliptic.AnalyticCore

/-!
# Elliptic division-field normalization and summation

The new denominator is the number of fixed embeddings, not the field degree.
The analytic estimates below are proved from the displayed smoothed-formula
inputs. Constructing the actual division field, its embeddings and the
prime-ideal injection remains a separate, explicitly uncompleted obligation.
No input here is asserted to hold for the manuscript's elliptic curve.
-/

@[expose] public section
namespace Elliptic
open scoped BigOperators

/-- Uniform explicit-formula bound with multiplicity `r` different from
the field degree `n`. This generic algebraic lemma allows a remainder
`C*n*log x`. The concrete number-field endpoint in `SmoothedFormula` instead
uses the manuscript-compatible bound `R*(log |D|+n)` and absorbs it directly;
it does not assume this lemma's discriminant-free remainder bound. -/
theorem partial_splitting_bound {ι : Type*}
    {r n x δ B S mass C d Z R : ℝ} (beta w : ι → ℝ)
    (hr : 0 < r) (hn : 0 ≤ n) (hx : 1 < x)
    (hδ : δ ≤ 1 / 2) (hC : 0 ≤ C)
    (hdominance : r * Real.log x * B ≤ S)
    (hformula : S = mass * x - Z + R)
    (hbeta : ∀ ρ, beta ρ ≤ 1 - δ) (hw0 : ∀ ρ, 0 ≤ w ρ)
    (hw : Summable w) (hmass : ∑' ρ, w ρ ≤ C * (d + n))
    (hzero : |Z| ≤ ∑' ρ, x ^ beta ρ * w ρ)
    (hrest : |R| ≤ C * n * Real.log x) :
    B ≤ mass * x / (r * Real.log x) +
      C * x ^ (1 - δ) / Real.log x * (d / r + 3 * n / r) := by
  have hL : 0 < Real.log x := Real.log_pos hx
  have hzeros : |Z| ≤ x ^ (1 - δ) * C * (d + n) := by
    simpa [mul_assoc] using hzero.trans
      (zero_weighted_sum_bound beta w hx.le hbeta hw0 hw hmass).2
  have hS := smoothed_formula_upper_bound hformula hzeros hrest
  have hrest' : C * n * Real.log x ≤ 2 * C * n * x ^ (1 - δ) := by
    have h := mul_le_mul_of_nonneg_left
      (log_le_twice_splitting_power hx.le hδ) (mul_nonneg hC hn)
    nlinarith
  have hupper : r * Real.log x * B ≤
      mass * x + x ^ (1 - δ) * C * (d + n) + 2 * C * n * x ^ (1 - δ) := by
    linarith
  calc
    B ≤ (mass * x + x ^ (1 - δ) * C * (d + n) +
        2 * C * n * x ^ (1 - δ)) / (r * Real.log x) := by
      apply (le_div_iff₀ (mul_pos hr hL)).2
      nlinarith [hupper]
    _ = _ := by field_simp; ring

/-- The elliptic degree/multiplicity ratio is `q`, while the main-term
divisor is `q(q-1)/2`. Keeping these two roles separate is essential. -/
theorem division_normalization {q x δ mass C d n r B D : ℝ}
    (hq : 1 < q) (hx : 1 < x) (hC : 0 ≤ C)
    (hr : r = q * (q - 1) / 2) (hn : n = q * r)
    (hd : d ≤ n * (D * Real.log q))
    (hB : B ≤ mass * x / (r * Real.log x) +
      C * x ^ (1 - δ) / Real.log x * (d / r + 3 * n / r)) :
    B ≤ (2 * mass * (x / Real.log x)) * (1 / (q * (q - 1))) +
      (C * x ^ (1 - δ) / Real.log x) * (q * (D * Real.log q + 3)) := by
  have hqp : 0 < q := by linarith
  have hrp : 0 < r := by rw [hr]; positivity
  have hdn : d / r ≤ q * (D * Real.log q) := by
    apply (div_le_iff₀ hrp).2
    rw [hn] at hd
    nlinarith [hd]
  have hnratio : n / r = q := by rw [hn]; exact mul_div_cancel_right₀ q hrp.ne'
  have hcoef : 0 ≤ C * x ^ (1 - δ) / Real.log x := by
    have hxp : 0 ≤ x := by linarith
    have hL := (Real.log_pos hx).le
    positivity
  calc
    B ≤ mass * x / (r * Real.log x) +
        C * x ^ (1 - δ) / Real.log x * (d / r + 3 * n / r) := hB
    _ ≤ mass * x / (r * Real.log x) +
        C * x ^ (1 - δ) / Real.log x * (q * (D * Real.log q + 3)) := by
      apply add_le_add le_rfl
      apply mul_le_mul_of_nonneg_left _ hcoef
      rw [show 3 * n / r = 3 * (n / r) by ring, hnratio]
      nlinarith
    _ = _ := by
      have hqone : q - 1 ≠ 0 := sub_ne_zero.mpr (ne_of_gt hq)
      rw [hr]
      field_simp [hqp.ne', hqone, (Real.log_pos hx).ne']

/-- Chebyshev controls the weighted sum required in the elliptic error. -/
theorem sum_prime_mul_log_le (s : Finset ℕ) {T : ℝ} (hT : 0 ≤ T)
    (hprime : ∀ q ∈ s, q.Prime) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T) :
    ∑ q ∈ s, (q : ℝ) * Real.log q ≤ Real.log 4 * T ^ 2 := by
  calc
    ∑ q ∈ s, (q : ℝ) * Real.log q ≤ ∑ q ∈ s, T * Real.log q := by
      apply Finset.sum_le_sum
      intro q hq
      exact mul_le_mul_of_nonneg_right (hupper q hq) (Real.log_natCast_nonneg q)
    _ = T * ∑ q ∈ s, Real.log q := by rw [Finset.mul_sum]
    _ ≤ T * (Real.log 4 * T) :=
      mul_le_mul_of_nonneg_left (sum_log_primes_le s hT hprime hupper) hT
    _ = _ := by ring

/-- Absorb the linear `q` term into `q log q` uniformly for prime `q`. -/
theorem sum_division_error_le (s : Finset ℕ) {T D : ℝ}
    (hT : 0 ≤ T) (hD : 0 ≤ D)
    (hprime : ∀ q ∈ s, q.Prime) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T) :
    ∑ q ∈ s, (q : ℝ) * (D * Real.log q + 3) ≤
      ((D + 3 / Real.log 2) * Real.log 4) * T ^ 2 := by
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hcoef : 0 ≤ D + 3 / Real.log 2 := by positivity
  calc
    ∑ q ∈ s, (q : ℝ) * (D * Real.log q + 3) ≤
        ∑ q ∈ s, (D + 3 / Real.log 2) * ((q : ℝ) * Real.log q) := by
      apply Finset.sum_le_sum
      intro q hq
      have hq2 : (2 : ℝ) ≤ q := by exact_mod_cast (hprime q hq).two_le
      have hl : Real.log (2 : ℝ) ≤ Real.log q :=
        Real.log_le_log (by norm_num) hq2
      have hh := mul_le_mul_of_nonneg_left hl (show 0 ≤ 3 / Real.log 2 by positivity)
      have hcancel : 3 / Real.log 2 * Real.log 2 = (3 : ℝ) :=
        div_mul_cancel₀ _ hlog2.ne'
      rw [hcancel] at hh
      have hq0 : (0 : ℝ) ≤ q := Nat.cast_nonneg q
      nlinarith [mul_le_mul_of_nonneg_left hh hq0]
    _ = (D + 3 / Real.log 2) * ∑ q ∈ s, (q : ℝ) * Real.log q := by
      rw [Finset.mul_sum]
    _ ≤ (D + 3 / Real.log 2) * (Real.log 4 * T ^ 2) :=
      mul_le_mul_of_nonneg_left (sum_prime_mul_log_le s hT hprime hupper) hcoef
    _ = _ := by ring

/-- The sum over the growing range of small division primes. The only
prime-tail hypothesis is the displayed ordinary reciprocal-prime estimate. -/
theorem sum_division_bounds (s : Finset ℕ) (B : ℕ → ℝ)
    {M E H Y D T : ℝ} (hM : 0 ≤ M) (hE : 0 ≤ E)
    (hD : 0 ≤ D) (hT : 0 ≤ T)
    (hprime : ∀ q ∈ s, q.Prime) (hupper : ∀ q ∈ s, (q : ℝ) ≤ T)
    (hB : ∀ q ∈ s, B q ≤ M * (1 / ((q : ℝ) * (q - 1))) +
      E * ((q : ℝ) * (D * Real.log q + 3)))
    (htail : ∑ q ∈ s, 1 / ((q : ℝ) * (q - 1)) ≤ H / (Y * Real.log Y)) :
    ∑ q ∈ s, B q ≤ M * (H / (Y * Real.log Y)) +
      E * (((D + 3 / Real.log 2) * Real.log 4) * T ^ 2) := by
  exact sum_two_component_bounds s B (fun q => 1 / ((q : ℝ) * (q - 1)))
    (fun q => (q : ℝ) * (D * Real.log q + 3)) hM hE hB htail
    (sum_division_error_le s hT hD hprime hupper)

/-- Substituting the cofactor range gives the exponent `1-δ+2ε`. -/
theorem division_error_power_identity {x : ℝ} (hx : 0 < x) (δ ε C : ℝ) :
    (x ^ (1 - δ) / Real.log x) * (C * (x ^ ε) ^ (2 : ℕ)) =
      C * x ^ (1 - δ + 2 * ε) / Real.log x := by
  have hpow : (x ^ ε) ^ (2 : ℕ) = x ^ (2 * ε) := by
    rw [pow_two, ← Real.rpow_add hx]
    congr 1
    ring
  rw [hpow, Real.rpow_add hx]
  ring

end Elliptic
