module

public import Elliptic.MainCurveUnramifiedConclusion
public import Elliptic.Arithmetic.DeterminantFromLocal

/-!
# Main-curve endpoint with determinant surjectivity deduced from local data

The existing local input supplies the Frobenius polynomial at every prime
p=3 mod 8 above the torsion prime q. Dirichlet and CRT therefore imply
the actual determinant character is onto. The main endpoint here requires
no separate determinant-surjectivity or Weil-pairing premise. The global
arithmetic still supplied is Kummer surjectivity and the local-different
estimate with fixed bad prime 2. Geometric division and the full local
specialization/Frobenius inputs remain explicit.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false

namespace Elliptic

open Filter Arithmetic
open scoped Topology

/-- The local input already has sufficiently many Frobenius elements to
force determinant surjectivity. It is not restricted to candidate primes
or primes satisfying an index condition. -/
theorem MainUnramifiedLocalInputs.character_surjective
    {D : MainGeometricDivisionFamily} {Y : ℝ} (hY : 2 ≤ Y)
    (hlocal : MainUnramifiedLocalInputs D Y)
    {n : ℕ} (hn : n.Prime) (hYn : Y < (n : ℝ)) :
    Function.Surjective (D n).character := by
  have hn2 : 2 < n := by exact_mod_cast hY.trans_lt hYn
  have hq2 : (primeParameter n).val ≠ 2 := by
    rw [primeParameter_val_of_prime hn]
    omega
  apply (D n).character_surjective_of_progression_polynomials hq2 n
  intro p hnp hp hp8
  let : Fact p.Prime := ⟨hp⟩
  obtain ⟨d⟩ := hlocal n hn hYn p hp hp8 hnp
  exact ⟨d.toLocalInputs.frobenius,
    Nat.card (CurvePoints (reductionCurve p) (ZMod p)),
    d.toLocalInputs.characteristicPolynomial⟩

/-- Complete the old global interface without assuming its determinant
field. The fixed bad-prime set is explicitly {2}. -/
theorem MainUnramifiedLocalInputs.globalInputs_two
    {D : MainGeometricDivisionFamily} {Y : ℝ} (hY : 2 ≤ Y)
    (hlocal : MainUnramifiedLocalInputs D Y)
    (hKummer : ∀ n : ℕ, n.Prime → Y < (n : ℝ) →
      Function.Surjective (D n).kummer)
    (hdifferent : ∀ n : ℕ, n.Prime → Y < (n : ℝ) →
      LocalDifferentEstimateAt (D n).ambient {n, 2}) :
    D.GlobalInputs {2} Y := by
  intro n hn hYn
  refine ⟨hlocal.character_surjective hY hn hYn, hKummer n hn hYn, ?_,
    hdifferent n hn hYn⟩
  intro p hp
  have hp2 : p = 2 := Finset.mem_singleton.mp hp
  subst p
  refine ⟨Nat.prime_two, ?_⟩
  have hn2 : (2 : ℝ) < n := hY.trans_lt hYn
  exact_mod_cast hn2.le

/-- Updated conditional counting endpoint: determinant surjectivity is
now a deduction from the already required local arithmetic, not an
additional global assumption. All constants retain their previous order. -/
theorem main_curve_proportion_from_kummer_and_unramified_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2 ≤ Yarith)
    (hKummer : ∀ n : ℕ, n.Prime → Yarith < (n : ℝ) →
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀ n : ℕ, n.Prime → Yarith < (n : ℝ) →
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n, 2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x :=
  main_curve_proportion_from_constructed_unramified_fields signed sources d {2} Yarith
    (hlocal.globalInputs_two hYarith hKummer hdifferent) hlocal f hanalytic

theorem main_curve_infinitely_many_from_kummer_and_unramified_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2 ≤ Yarith)
    (hKummer : ∀ n : ℕ, n.Prime → Yarith < (n : ℝ) →
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀ n : ℕ, n.Prime → Yarith < (n : ℝ) →
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n, 2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_kummer_and_unramified_fields signed sources d Yarith hYarith
      hKummer hdifferent hlocal f hanalytic) hN hQRH

end Elliptic
