module

public import Elliptic.MainCurveConclusion
public import Elliptic.Infinitude

/-! # Infinitude consequence for the actual primitive-point predicate

The quantitative estimate remains the conditional theorem established in
`MainCurveConclusion`; this file checks the infinitude deduction and does
not assert or import a new candidate or division-field estimate.
-/

@[expose] public section
namespace Elliptic
open Filter
open scoped Topology

theorem main_curve_infinitely_many_of_quantitative_bound
    (hbound : ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} := by
  obtain ⟨κ, hκ, h⟩ := hbound
  apply infinite_good_primes_of_positive_proportion MainPrimitivePrime
  refine ⟨κ / (N * Real.log N), ?_, h N hN hQRH⟩
  have hNp : 0 < N := by linarith
  have hlog : 0 < Real.log N := Real.log_pos (by linarith)
  positivity

end Elliptic
