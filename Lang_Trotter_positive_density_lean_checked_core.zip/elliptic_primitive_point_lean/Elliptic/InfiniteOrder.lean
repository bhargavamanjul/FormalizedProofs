module

public import Elliptic.CurveModel
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.GroupTheory.OrderOfElement
public import Mathlib.Tactic

/-!
# Infinite order of the actual point (2,2)

We use the actual elliptic group law and the rational 2-adic valuation.
Once the x-coordinate has negative valuation, doubling decreases that
valuation by two. The point 2P=(9/4,-21/8) starts this process. Thus its
successive doubles are distinct, which rules out finite order directly.
No Nagell--Lutz or torsion-integrality premise is needed.
-/

@[expose] public section
namespace Elliptic

def examplePointX : exampleCurve.toAffine.Point → ℚ
  | .zero => 0
  | .some x _ _ => x

theorem val_two : padicValRat 2 (2 : ℚ) = 1 := by
  exact padicValRat.self (by norm_num)

theorem negative_val_x_ne_zero {x : ℚ} (hx : padicValRat 2 x < 0) : x ≠ 0 := by
  intro h
  simp [h] at hx

theorem negative_val_square_sub_two {x : ℚ} (hx : padicValRat 2 x < 0) :
    x ^ 2 - 2 ≠ 0 ∧ padicValRat 2 (x ^ 2 - 2) = 2 * padicValRat 2 x := by
  have hx0 := negative_val_x_ne_zero hx
  have hval : padicValRat 2 (x ^ 2) < padicValRat 2 (-2 : ℚ) := by
    rw [padicValRat.pow, padicValRat.neg, val_two]
    omega
  have hne : x ^ 2 + (-2) ≠ 0 := by
    intro h
    have he : x ^ 2 = 2 := by linarith
    have hv := congrArg (padicValRat 2) he
    rw [padicValRat.pow, val_two] at hv
    omega
  refine ⟨by simpa [sub_eq_add_neg] using hne, ?_⟩
  simpa [sub_eq_add_neg, padicValRat.pow] using
    (padicValRat.add_eq_of_lt hne (pow_ne_zero 2 hx0) (by norm_num) hval)

theorem negative_val_square_add_two {x : ℚ} (hx : padicValRat 2 x < 0) :
    padicValRat 2 (x ^ 2 + 2) = 2 * padicValRat 2 x := by
  have hne : x ^ 2 + 2 ≠ 0 := by nlinarith [sq_nonneg x]
  have hval : padicValRat 2 (x ^ 2) < padicValRat 2 (2 : ℚ) := by
    rw [padicValRat.pow, val_two]
    omega
  simpa [padicValRat.pow] using
    (padicValRat.add_eq_of_lt hne (pow_ne_zero 2 (negative_val_x_ne_zero hx))
      (by norm_num) hval)

theorem example_equation_short {x y : ℚ}
    (h : exampleCurve.toAffine.Equation x y) : y ^ 2 = x * (x ^ 2 - 2) := by
  rw [WeierstrassCurve.Affine.equation_iff] at h
  norm_num [exampleCurve] at h
  nlinarith [h]

theorem example_y_ne_zero_of_negative_val {x y : ℚ}
    (h : exampleCurve.toAffine.Equation x y) (hx : padicValRat 2 x < 0) : y ≠ 0 := by
  have he := example_equation_short h
  have hn := mul_ne_zero (negative_val_x_ne_zero hx) (negative_val_square_sub_two hx).1
  intro hy
  apply hn
  rw [← he, hy]
  norm_num

theorem example_y_val_of_negative_val {x y : ℚ}
    (h : exampleCurve.toAffine.Equation x y) (hx : padicValRat 2 x < 0) :
    2 * padicValRat 2 y = 3 * padicValRat 2 x := by
  have hv := congrArg (padicValRat 2) (example_equation_short h)
  rw [padicValRat.pow,
    padicValRat.mul (negative_val_x_ne_zero hx) (negative_val_square_sub_two hx).1,
    (negative_val_square_sub_two hx).2] at hv
  omega

theorem examplePointX_double_formula {x y : ℚ}
    (h : exampleCurve.toAffine.Nonsingular x y) (hy : y ≠ 0) :
    examplePointX (.some x y h + .some x y h) =
      (x ^ 2 + 2) ^ 2 / (4 * y ^ 2) := by
  have hyn : y ≠ exampleCurve.toAffine.negY x y := by
    simp only [WeierstrassCurve.Affine.negY, exampleCurve]
    intro hneg
    apply hy
    linarith
  rw [WeierstrassCurve.Affine.Point.add_self_of_Y_ne hyn]
  change exampleCurve.toAffine.addX x x (exampleCurve.toAffine.slope x x y y) = _
  rw [WeierstrassCurve.Affine.addX_self_of_Y_ne h.1 hyn,
    WeierstrassCurve.Affine.den_duplication_eq h.1]
  norm_num [exampleCurve, WeierstrassCurve.b₄, WeierstrassCurve.b₆,
    WeierstrassCurve.b₈]
  ring

theorem examplePointX_double_val {Q : exampleCurve.toAffine.Point}
    (hQ : padicValRat 2 (examplePointX Q) < 0) :
    padicValRat 2 (examplePointX (Q + Q)) = padicValRat 2 (examplePointX Q) - 2 := by
  cases Q with
  | zero => simp [examplePointX] at hQ
  | some x y h =>
    change padicValRat 2 x < 0 at hQ
    have hy := example_y_ne_zero_of_negative_val h.1 hQ
    rw [examplePointX_double_formula h hy]
    have hnum : x ^ 2 + 2 ≠ 0 := by nlinarith [sq_nonneg x]
    have hfour : padicValRat 2 (4 : ℚ) = 2 := by
      rw [show (4 : ℚ) = 2 ^ 2 by norm_num, padicValRat.pow, val_two]
      norm_num
    rw [padicValRat.div (pow_ne_zero 2 hnum) (mul_ne_zero (by norm_num) (pow_ne_zero 2 hy)),
      padicValRat.pow, negative_val_square_add_two hQ,
      padicValRat.mul (by norm_num : (4 : ℚ) ≠ 0) (pow_ne_zero 2 hy),
      hfour, padicValRat.pow]
    have hval := example_y_val_of_negative_val h.1 hQ
    change 2 * (2 * padicValRat 2 x) - (2 + 2 * padicValRat 2 y) = padicValRat 2 x - 2
    omega

def exampleDoublingSequence (n : ℕ) : exampleCurve.toAffine.Point :=
  (2 ^ (n + 1)) • examplePoint

theorem exampleDoublingSequence_zero : exampleDoublingSequence 0 = examplePoint + examplePoint := by
  norm_num [exampleDoublingSequence, two_nsmul]

theorem exampleDoublingSequence_succ (n : ℕ) :
    exampleDoublingSequence (n + 1) = exampleDoublingSequence n + exampleDoublingSequence n := by
  unfold exampleDoublingSequence
  rw [pow_succ', mul_nsmul, two_nsmul]
  rw [nsmul_add]

theorem exampleDouble_x_val : padicValRat 2 (9 / 4 : ℚ) = -2 := by
  have hn : padicValRat 2 (9 : ℚ) = 0 := by
    change padicValRat 2 (↑(9 : ℕ)) = 0
    rw [padicValRat.of_nat]
    norm_cast
    rw [padicValNat.eq_zero_iff]
    norm_num
  have hd : padicValRat 2 (4 : ℚ) = 2 := by
    rw [show (4 : ℚ) = 2 ^ 2 by norm_num, padicValRat.pow, val_two]
    norm_num
  rw [padicValRat.div (by norm_num : (9 : ℚ) ≠ 0) (by norm_num : (4 : ℚ) ≠ 0), hn, hd]
  norm_num

theorem exampleDoublingSequence_val (n : ℕ) :
    padicValRat 2 (examplePointX (exampleDoublingSequence n)) = -2 * ((n : ℤ) + 1) := by
  induction n with
  | zero =>
    rw [exampleDoublingSequence_zero, examplePoint_double]
    change padicValRat 2 (9 / 4 : ℚ) = _
    simpa using exampleDouble_x_val
  | succ n ih =>
    have hneg : padicValRat 2 (examplePointX (exampleDoublingSequence n)) < 0 := by
      rw [ih]
      omega
    rw [exampleDoublingSequence_succ, examplePointX_double_val hneg, ih]
    push_cast
    ring

theorem exampleDoublingSequence_injective : Function.Injective exampleDoublingSequence := by
  intro m n h
  have hv := congrArg (fun Q => padicValRat 2 (examplePointX Q)) h
  rw [exampleDoublingSequence_val, exampleDoublingSequence_val] at hv
  omega

/-- The actual point `(2,2)` has infinite order, proved directly from
the elliptic group law and the rational 2-adic valuation. -/
theorem examplePoint_infinite_order : ¬ IsOfFinAddOrder examplePoint := by
  intro hfin
  have hfinite := hfin.finite_multiples
  obtain ⟨m, n, hmn, heq⟩ := hfinite.exists_lt_map_eq_of_forall_mem
    (f := exampleDoublingSequence) (fun n => by
      change (2 ^ (n + 1)) • examplePoint ∈ AddSubmonoid.multiples examplePoint
      exact ⟨2 ^ (n + 1), rfl⟩)
  exact (Nat.ne_of_lt hmn) (exampleDoublingSequence_injective heq)

theorem examplePoint_addOrderOf : addOrderOf examplePoint = 0 :=
  addOrderOf_eq_zero_iff.mpr examplePoint_infinite_order

end Elliptic
