module

public import Elliptic.DivisionAction

/-!
# From the division-point action to embeddings of an actual fixed field

This file constructs the ordinary Galois correspondence between cosets of
a subgroup and embeddings of its fixed field. It then transports the
division-point action to actual field embeddings, including its fixed-point
multiplicity. No fixed-embedding count is postulated.

The remaining local arithmetic bridge identifies Frobenius-fixed embeddings
with degree-one prime ideals at an unramified prime. It is not proved here.
-/

@[expose] public section

namespace Elliptic

section Restrictions

variable {F L : Type*} [Field F] [Field L] [Algebra F L]
    [FiniteDimensional F L] [IsGalois F L]

/-- Restriction of an actual Galois automorphism to a subgroup's fixed field. -/
def galoisRestriction (H : Subgroup Gal(L/F)) (g : Gal(L/F)) :
    IntermediateField.fixedField H →ₐ[F] L :=
  g.toAlgHom.comp (IntermediateField.fixedField H).val

omit [IsGalois F L] in
theorem galoisRestriction_eq_iff (H : Subgroup Gal(L/F)) (g h : Gal(L/F)) :
    galoisRestriction H g = galoisRestriction H h ↔ g⁻¹ * h ∈ H := by
  conv_rhs =>
    rw [← IntermediateField.fixingSubgroup_fixedField H,
      IntermediateField.mem_fixingSubgroup_iff]
  constructor
  · intro heq x hx
    have hv := DFunLike.congr_fun heq (⟨x, hx⟩ : IntermediateField.fixedField H)
    change g x = h x at hv
    change g.symm (h x) = x
    rw [← hv, g.symm_apply_apply]
  · intro hfix
    ext x
    have hv := hfix x x.property
    change g.symm (h x) = x at hv
    have hv' := congrArg g hv
    change g (x : L) = h (x : L)
    simpa only [g.apply_symm_apply] using hv'.symm

omit [FiniteDimensional F L] in
/-- Every embedding of the fixed field extends to the normal ambient field. -/
theorem galoisRestriction_surjective (H : Subgroup Gal(L/F)) :
    Function.Surjective (galoisRestriction H) := by
  intro φ
  let a := φ.liftNormal L
  let g : Gal(L/F) := AlgEquiv.ofBijective a (a.normal_bijective F L L)
  refine ⟨g, ?_⟩
  ext x
  exact φ.liftNormal_commutes L x

/-- The well-defined restriction map from left cosets. -/
def quotientRestriction (H : Subgroup Gal(L/F)) (a : Gal(L/F) ⧸ H) :
    IntermediateField.fixedField H →ₐ[F] L :=
  Quotient.liftOn' a (galoisRestriction H) (fun g h hgh =>
    (galoisRestriction_eq_iff H g h).2 (QuotientGroup.leftRel_apply.1 hgh))

theorem quotientRestriction_bijective (H : Subgroup Gal(L/F)) :
    Function.Bijective (quotientRestriction H) := by
  constructor
  · intro a b
    refine Quotient.inductionOn₂' a b ?_
    intro g h heq
    exact Quotient.sound' (QuotientGroup.leftRel_apply.2
      ((galoisRestriction_eq_iff H g h).1 heq))
  · intro φ
    obtain ⟨g, hg⟩ := galoisRestriction_surjective H φ
    exact ⟨QuotientGroup.mk g, hg⟩

/-- The actual embeddings-cosets equivalence, with no counting hypothesis. -/
noncomputable def quotientFixedFieldEmbeddingsEquiv (H : Subgroup Gal(L/F)) :
    (Gal(L/F) ⧸ H) ≃ (IntermediateField.fixedField H →ₐ[F] L) :=
  Equiv.ofBijective (quotientRestriction H) (quotientRestriction_bijective H)

@[simp]
theorem quotientFixedFieldEmbeddingsEquiv_mk (H : Subgroup Gal(L/F))
    (g : Gal(L/F)) :
    quotientFixedFieldEmbeddingsEquiv H (QuotientGroup.mk g) =
      galoisRestriction H g := rfl

omit [FiniteDimensional F L] [IsGalois F L] in
theorem galoisRestriction_mul (H : Subgroup Gal(L/F)) (g h : Gal(L/F)) :
    galoisRestriction H (g * h) = g.toAlgHom.comp (galoisRestriction H h) := rfl

end Restrictions

section DivisionEmbeddings

variable {F L k : Type*} [Field F] [Field L] [Algebra F L]
    [FiniteDimensional F L] [IsGalois F L] [Field k]
variable (ρ : Gal(L/F) →* ((k × k) ≃ᵃ[k] (k × k)))
    (χ : Gal(L/F) →* kˣ)
    (hχ : Function.Surjective χ) (htr : HasFullTranslations ρ χ)
    (z : (k × k) × RealCyclotomicLabels k)

/-- The cosets of the stabilizer are the whole division-point product. -/
noncomputable def quotientDivisionEquiv :
    (Gal(L/F) ⧸ divisionStabilizer ρ χ z) ≃
      ((k × k) × RealCyclotomicLabels k) := by
  let := divisionMulAction ρ χ
  refine Equiv.ofBijective (MulAction.ofQuotientStabilizer Gal(L/F) z) ⟨?_, ?_⟩
  · exact MulAction.injective_ofQuotientStabilizer Gal(L/F) z
  · intro w
    obtain ⟨g, hg⟩ := divisionAction_transitive ρ χ hχ htr z w
    exact ⟨QuotientGroup.mk g, hg⟩

omit [FiniteDimensional F L] [IsGalois F L] in
@[simp]
theorem quotientDivisionEquiv_mk (g : Gal(L/F)) :
    quotientDivisionEquiv ρ χ hχ htr z (QuotientGroup.mk g) =
      divisionAction ρ χ g z := rfl

/-- A concrete equivalence from actual fixed-field embeddings to the
division-point/cyclotomic-label product. -/
noncomputable def divisionEmbeddingsEquiv :
    (IntermediateField.fixedField (divisionStabilizer ρ χ z) →ₐ[F] L) ≃
      ((k × k) × RealCyclotomicLabels k) :=
  (quotientFixedFieldEmbeddingsEquiv (divisionStabilizer ρ χ z)).symm.trans
    (quotientDivisionEquiv ρ χ hχ htr z)

@[simp]
theorem divisionEmbeddingsEquiv_restriction (g : Gal(L/F)) :
    divisionEmbeddingsEquiv ρ χ hχ htr z
      (galoisRestriction (divisionStabilizer ρ χ z) g) =
      divisionAction ρ χ g z := by
  change quotientDivisionEquiv ρ χ hχ htr z
    ((quotientFixedFieldEmbeddingsEquiv (divisionStabilizer ρ χ z)).symm
      (galoisRestriction (divisionStabilizer ρ χ z) g)) = _
  rw [← quotientFixedFieldEmbeddingsEquiv_mk, Equiv.symm_apply_apply,
    quotientDivisionEquiv_mk]

/-- The equivalence intertwines Galois composition on actual embeddings
with the previously constructed division-point action. -/
theorem divisionEmbeddingsEquiv_equivariant (g : Gal(L/F))
    (φ : IntermediateField.fixedField (divisionStabilizer ρ χ z) →ₐ[F] L) :
    divisionEmbeddingsEquiv ρ χ hχ htr z (g.toAlgHom.comp φ) =
      divisionAction ρ χ g (divisionEmbeddingsEquiv ρ χ hχ htr z φ) := by
  obtain ⟨h, rfl⟩ := galoisRestriction_surjective (divisionStabilizer ρ χ z) φ
  rw [← galoisRestriction_mul, divisionEmbeddingsEquiv_restriction,
    divisionEmbeddingsEquiv_restriction]
  let := divisionMulAction ρ χ
  exact mul_smul g h z

include hχ htr in
/-- Exactly `q(q-1)/2` actual field embeddings are fixed by an automorphism
whose affine action has the required normal form and character `-1`. -/
theorem card_fixed_division_embeddings [Fintype k] [DecidableEq k]
    {g : Gal(L/F)} (h_two : (2 : k) ≠ 0) (hgχ : χ g = -1) (b₂ : k)
    (hρ : ∀ w, ρ g w = affineNormalForm 0 b₂ w) :
    Nat.card {φ : IntermediateField.fixedField (divisionStabilizer ρ χ z) →ₐ[F] L //
      g.toAlgHom.comp φ = φ} =
      Fintype.card k * (Fintype.card k - 1) / 2 := by
  calc
    _ = Nat.card {w : (k × k) × RealCyclotomicLabels k //
        divisionAction ρ χ g w = w} :=
      Nat.card_congr (fixedPointsEquivOfConjugacy
        (divisionEmbeddingsEquiv ρ χ hχ htr z)
        (fun φ => g.toAlgHom.comp φ) (divisionAction ρ χ g)
        (divisionEmbeddingsEquiv_equivariant ρ χ hχ htr z g))
    _ = _ := card_fixed_divisionAction ρ χ h_two hgχ b₂ hρ

include hχ htr in
/-- A Frobenius-dependent coordinate change suffices. The fixed field and
its original affine representation do not change with the automorphism. -/
theorem card_fixed_division_embeddings_of_conjugacy [Fintype k] [DecidableEq k]
    {g : Gal(L/F)} (h_two : (2 : k) ≠ 0) (hgχ : χ g = -1)
    (e : (k × k) ≃ (k × k)) (b₁ b₂ : k)
    (hρ : ∀ w, e (ρ g w) = affineNormalForm b₁ b₂ (e w))
    (hfixed : ∃ w, ρ g w = w) :
    Nat.card {φ : IntermediateField.fixedField (divisionStabilizer ρ χ z) →ₐ[F] L //
      g.toAlgHom.comp φ = φ} =
      Fintype.card k * (Fintype.card k - 1) / 2 := by
  calc
    _ = Nat.card {w : (k × k) × RealCyclotomicLabels k //
        divisionAction ρ χ g w = w} :=
      Nat.card_congr (fixedPointsEquivOfConjugacy
        (divisionEmbeddingsEquiv ρ χ hχ htr z)
        (fun φ => g.toAlgHom.comp φ) (divisionAction ρ χ g)
        (divisionEmbeddingsEquiv_equivariant ρ χ hχ htr z g))
    _ = _ := card_fixed_divisionAction_of_conjugacy ρ χ h_two hgχ e b₁ b₂ hρ hfixed

end DivisionEmbeddings

end Elliptic
