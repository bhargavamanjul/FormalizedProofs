module
public import Elliptic.MainCurveLocalDeterminantConclusion
public import Elliptic.Operator.SignedSourceEnergy
public import Elliptic.Operator.SignedMajorArcSaving

/-! The main-curve endpoint after the actual source-energy reconstruction.
The literal unrestricted normalized major sum is displayed as an intermediate
predicate and then proved from the derivative-test and unchanged source inputs.
All global and local arithmetic hypotheses retain their existing types. -/
@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic
open Filter Arithmetic
open scoped BigOperators Topology
open Artin Artin.MarkedSource
open Operator.SignedCauchyExpansion Operator.SignedDyadicCauchy
open Operator.SignedSourceDyads Operator.SignedSmoothDyads
open Operator.SignedEnergyReconstruction

/-- The original major-arc obligation on the actual source labels and
coefficients. This explicit predicate is not added to the accepted sources. -/
def ActualNormalizedScalarMajorSaving : Prop :=
  ∀δ C A G c₁ c₂ : ℝ,0<δ→0<C→0<A→0≤G→0<c₁→0<c₂→
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→∀b : Bands K,
    ∀(J : Type) (Hm Hn : ℝ→J→ℝ) (active : ℝ→J→Prop),
    ScaleFamily δ c₁ c₂ Hm Hn active→∀α : ℝ→J→ℕ→ℂ,
    ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j)→
    (∀ᶠx : ℝ in atTop,∀j,active x j→∀n : ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→
      ‖α x j n‖≤(Real.log x)^C ∧ (α x j n≠0→Artin.MarkedCriterion.IsRough (W x) n))→
    ∀ᶠx : ℝ in atTop,∀j,active x j→∀s t : Finset ℕ,
    IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→∀β : ℕ→ℂ,CoefficientOn x C t β→
    ∀d∈sourceDyads b x,
      ‖(massNormalization b x:ℂ)^2*scalarMajorSum b x ((2:ℝ)^d)
        ((Real.log x)^G) s t weight determinantCutoff (α x j) β‖≤
          (Hm x j*Hn x j)*(2:ℝ)^d*(Real.log x)^(-A)

/-- The scalar criterion is deduced from the proved source-energy argument
and the one remaining actual major-arc estimate. -/
theorem signed_scalar_criterion_from_actual_major
    (hPD : Operator.SourceRootCount.RootCountContract)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (hmajor : ActualNormalizedScalarMajorSaving) :
    Sieve.SignedReplacement.SignedScalarCriterion :=
  Operator.SignedSourceEnergy.signedScalarCriterion_of_normalized_major hPD
    sources.bandLower sources.bandUpper sources.divisorSquareMoment hmajor

/-- Quantitative main-curve conclusion with the signed criterion derived,
and the original geometric, Kummer, and local arithmetic inputs unchanged. -/
theorem main_curve_proportion_from_actual_major_and_unramified_fields
    (hPD : Operator.SourceRootCount.RootCountContract)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (hmajor : ActualNormalizedScalarMajorSaving)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2≤Yarith)
    (hKummer : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n,2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃κ : ℝ,0<κ ∧ ∀N : ℝ,2≤N→DedekindQRH N→
      ∀ᶠx : ℝ in atTop,
        (κ/(N*Real.log N))*(Nat.primeCounting ⌊x⌋₊:ℝ)≤
          goodPrimeCount MainPrimitivePrime x :=
  main_curve_proportion_from_kummer_and_unramified_fields
    (signed_scalar_criterion_from_actual_major hPD sources hmajor) sources d Yarith hYarith
    hKummer hdifferent hlocal f hanalytic

theorem main_curve_infinitely_many_from_actual_major_and_unramified_fields
    (hPD : Operator.SourceRootCount.RootCountContract)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (hmajor : ActualNormalizedScalarMajorSaving)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2≤Yarith)
    (hKummer : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n,2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2≤N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_actual_major_and_unramified_fields hPD sources hmajor d
      Yarith hYarith hKummer hdifferent hlocal f hanalytic) hN hQRH

/-- The actual major-arc estimate closes the original signed criterion.
The accepted source record is unchanged. -/
theorem signed_scalar_criterion_from_rootcount_and_derivative_test
    (hPD : Operator.SourceRootCount.RootCountContract)
    (hvdC : Operator.ClassicalDerivativeTest.FixedOrderDerivativeTest)
    (sources : Sieve.AcceptedSuccessorSieveSources) :
    Sieve.SignedReplacement.SignedScalarCriterion :=
  signed_scalar_criterion_from_actual_major hPD sources
    (Operator.SignedMajorArcSaving.actual_normalized_scalar_major_saving
      sources.bandLower hvdC sources.divisorSquareMoment)

/-- Main-curve quantitative conclusion with all original signed analytic
intermediate obligations discharged. The arithmetic inputs remain explicit. -/
theorem main_curve_proportion_from_rootcount_derivative_and_unramified_fields
    (hPD : Operator.SourceRootCount.RootCountContract)
    (hvdC : Operator.ClassicalDerivativeTest.FixedOrderDerivativeTest)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2≤Yarith)
    (hKummer : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n,2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃κ : ℝ,0<κ ∧ ∀N : ℝ,2≤N→DedekindQRH N→
      ∀ᶠx : ℝ in atTop,
        (κ/(N*Real.log N))*(Nat.primeCounting ⌊x⌋₊:ℝ)≤
          goodPrimeCount MainPrimitivePrime x :=
  main_curve_proportion_from_kummer_and_unramified_fields
    (signed_scalar_criterion_from_rootcount_and_derivative_test hPD hvdC sources)
    sources d Yarith hYarith hKummer hdifferent hlocal f hanalytic

theorem main_curve_infinitely_many_from_rootcount_derivative_and_unramified_fields
    (hPD : Operator.SourceRootCount.RootCountContract)
    (hvdC : Operator.ClassicalDerivativeTest.FixedOrderDerivativeTest)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (Yarith : ℝ) (hYarith : 2≤Yarith)
    (hKummer : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      Function.Surjective (d.toGeometricDivisionFamily n).kummer)
    (hdifferent : ∀n : ℕ,n.Prime→Yarith<(n:ℝ)→
      LocalDifferentEstimateAt (d.toGeometricDivisionFamily n).ambient {n,2})
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2≤N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_rootcount_derivative_and_unramified_fields
      hPD hvdC sources d Yarith hYarith hKummer hdifferent hlocal f hanalytic) hN hQRH

end Elliptic
