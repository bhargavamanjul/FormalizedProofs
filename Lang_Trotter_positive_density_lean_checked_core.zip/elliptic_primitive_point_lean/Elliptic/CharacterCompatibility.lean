module

public import Mathlib.LinearAlgebra.Basis.VectorSpace
public import Mathlib.LinearAlgebra.Isomorphisms
public import Mathlib.Algebra.Field.ZMod
public import Mathlib.Data.Fin.VecNotation

/-!
# The linear-algebraic squareclass compatibility criterion

This file checks the algebraic descent in the proof of the manuscript's
general theorem. It proves that prescribed values on a finite collection
of vectors extend to a linear functional precisely when every relation
between the vectors respects those values.

The specialization uses four vectors over `ZMod 2`, with desired values
`1, 1, 1, 0`. In the manuscript the vectors are the squareclasses of
`κ, D, u, -3`. The identification with rational squareclasses, quadratic
characters, multiquadratic Galois groups, and arithmetic progressions is
not formalized in this file.
-/

@[expose] public section

namespace Elliptic

section LinearDescent

variable {K V W : Type*} [DivisionRing K]
variable [AddCommGroup V] [Module K V] [AddCommGroup W] [Module K W]

/-- A scalar-valued linear map descends along `f`, and extends to its entire
target vector space, exactly when it vanishes on the kernel of `f`. -/
theorem ker_le_ker_iff_exists_functional (f : V →ₗ[K] W) (g : V →ₗ[K] K) :
    LinearMap.ker f ≤ LinearMap.ker g ↔
      ∃ h : W →ₗ[K] K, h.comp f = g := by
  constructor
  · intro hfg
    let k : LinearMap.range f →ₗ[K] K :=
      ((LinearMap.ker f).liftQ g hfg).comp f.quotKerEquivRange.symm.toLinearMap
    obtain ⟨h, hh⟩ := k.exists_extend
    refine ⟨h, ?_⟩
    ext x
    have he := congrArg
      (fun t : LinearMap.range f →ₗ[K] K => t ⟨f x, f.mem_range_self x⟩) hh
    change h (f x) = ((LinearMap.ker f).liftQ g hfg)
      (f.quotKerEquivRange.symm ⟨f x, f.mem_range_self x⟩) at he
    rw [f.quotKerEquivRange_symm_apply_image] at he
    exact he
  · rintro ⟨h, hh⟩
    rw [← hh]
    exact LinearMap.ker_le_ker_comp f h

end LinearDescent

section FourSquareclasses

variable {S : Type*} [AddCommGroup S] [Module (ZMod 2) S]

/-- The coefficient space for the four squareclasses in the manuscript. -/
abbrev FourCoefficients := Fin 4 → ZMod 2

/-- Send a coefficient vector to the corresponding sum of squareclasses. -/
def squareclassCombination (v : Fin 4 → S) : FourCoefficients →ₗ[ZMod 2] S where
  toFun e := e 0 • v 0 + e 1 • v 1 + e 2 • v 2 + e 3 • v 3
  map_add' e f := by
    simp [add_smul, add_assoc, add_left_comm]
  map_smul' a e := by
    simp [smul_add, smul_smul]

/-- The required sign relation: the first three exponents sum to zero. -/
def desiredSignParity : FourCoefficients →ₗ[ZMod 2] ZMod 2 where
  toFun e := e 0 + e 1 + e 2
  map_add' e f := by
    simp [add_assoc, add_left_comm, add_comm]
  map_smul' a e := by
    simp [mul_add]

/-- The algebraic form of the manuscript's squareclass hypothesis. -/
def SquareclassCompatible (v : Fin 4 → S) : Prop :=
  ∀ e : FourCoefficients,
    squareclassCombination v e = 0 → e 0 + e 1 + e 2 = 0

/-- A relation criterion is equivalent to the kernel inclusion needed for descent. -/
theorem squareclassCompatible_iff_kernel (v : Fin 4 → S) :
    SquareclassCompatible v ↔
      LinearMap.ker (squareclassCombination v) ≤ LinearMap.ker desiredSignParity := by
  rfl

/-- Precisely the compatible quadruples admit the prescribed quadratic signs.

Here the additive values `1, 1, 1, 0` encode the multiplicative signs
`-1, -1, -1, +1`, respectively. -/
theorem squareclassCompatible_iff_character (v : Fin 4 → S) :
    SquareclassCompatible v ↔
      ∃ χ : S →ₗ[ZMod 2] ZMod 2,
        χ (v 0) = 1 ∧ χ (v 1) = 1 ∧ χ (v 2) = 1 ∧ χ (v 3) = 0 := by
  rw [squareclassCompatible_iff_kernel]
  rw [ker_le_ker_iff_exists_functional (K := ZMod 2)
    (squareclassCombination v) desiredSignParity]
  constructor
  · rintro ⟨χ, hχ⟩
    refine ⟨χ, ?_, ?_, ?_, ?_⟩
    · have h := congrArg (fun f : FourCoefficients →ₗ[ZMod 2] ZMod 2 =>
        f ![1, 0, 0, 0]) hχ
      simpa [squareclassCombination, desiredSignParity] using h
    · have h := congrArg (fun f : FourCoefficients →ₗ[ZMod 2] ZMod 2 =>
        f ![0, 1, 0, 0]) hχ
      simpa [squareclassCombination, desiredSignParity] using h
    · have h := congrArg (fun f : FourCoefficients →ₗ[ZMod 2] ZMod 2 =>
        f ![0, 0, 1, 0]) hχ
      simpa [squareclassCombination, desiredSignParity] using h
    · have h := congrArg (fun f : FourCoefficients →ₗ[ZMod 2] ZMod 2 =>
        f ![0, 0, 0, 1]) hχ
      simpa [squareclassCombination, desiredSignParity] using h
  · rintro ⟨χ, h0, h1, h2, h3⟩
    refine ⟨χ, ?_⟩
    ext e
    simp [squareclassCombination, desiredSignParity, h0, h1, h2, h3]

/-- If the first and fourth squareclasses coincide, the required signs conflict.
This is the linear-algebraic obstruction when the CM squareclass is `[-3]`. -/
theorem not_squareclassCompatible_of_first_eq_fourth (v : Fin 4 → S)
    (heq : v 0 = v 3) : ¬ SquareclassCompatible v := by
  intro hv
  obtain ⟨χ, h0, _, _, h3⟩ := (squareclassCompatible_iff_character v).mp hv
  have h10 : (1 : ZMod 2) = 0 := by
    calc
      1 = χ (v 0) := h0.symm
      _ = χ (v 3) := congrArg χ heq
      _ = 0 := h3
  exact one_ne_zero h10

end FourSquareclasses

end Elliptic
