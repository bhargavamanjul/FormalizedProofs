module

public import Elliptic.HeightCounting
public import Elliptic.DivisionAction
public import Mathlib.NumberTheory.NumberField.Discriminant.Different

/-!
# The discriminant bound for the division-field subextension

The standard local different bound is kept in its explicit valuation form.
The deduction `log |D_T| ≤ 14 [T:Q] log q` is proved, using `[L:Q] ≤ q⁶`.
The tower inequality is not an input: it follows from mathlib's exact
discriminant/different formula for actual number fields.

The arithmetic proof that the ambient division field is unramified outside
`2,q`, and the local different theorem producing the displayed valuation
bound, remain separate standard arithmetic inputs. No final `O(log q)`
discriminant estimate is postulated.
-/

@[expose] public section

namespace Elliptic

theorem valuation_mul_log_le_log {d p : ℕ} (hd : 0 < d) (hp : p.Prime) :
    (d.factorization p : ℝ) * Real.log p ≤ Real.log d := by
  have hdiv : p ^ d.factorization p ∣ d :=
    (hp.pow_dvd_iff_le_factorization hd.ne').2 le_rfl
  have hle : p ^ d.factorization p ≤ d := Nat.le_of_dvd hd hdiv
  calc
    (d.factorization p : ℝ) * Real.log p =
        Real.log ((p : ℝ) ^ d.factorization p) := (Real.log_pow ..).symm
    _ ≤ Real.log d := by
      apply Real.log_le_log (pow_pos (by exact_mod_cast hp.pos) _)
      exact_mod_cast hle

/-- The dependence on the ambient degree is removed using its polynomial
bound. This numerical lemma is uniform in every number field. -/
theorem two_prime_different_sum_le {d q : ℕ} (hd : 0 < d) (hq : q.Prime)
    (hdegree : d ≤ q ^ 6) :
    (1 + (d.factorization 2 : ℝ)) * Real.log 2 +
      (1 + (d.factorization q : ℝ)) * Real.log q ≤ 14 * Real.log q := by
  have h2 := valuation_mul_log_le_log hd Nat.prime_two
  norm_num only [Nat.cast_ofNat] at h2
  have hqv := valuation_mul_log_le_log hd hq
  have hlog2 : Real.log 2 ≤ Real.log (q : ℝ) := by
    apply Real.log_le_log (by norm_num)
    exact_mod_cast hq.two_le
  have hlogd : Real.log (d : ℝ) ≤ 6 * Real.log (q : ℝ) := by
    calc
      Real.log (d : ℝ) ≤ Real.log ((q : ℝ) ^ 6) := by
        apply Real.log_le_log (by exact_mod_cast hd)
        exact_mod_cast hdegree
      _ = 6 * Real.log (q : ℝ) := by rw [Real.log_pow]; norm_num
  nlinarith

/-- The same local calculation with any finite ramification set. Once `q`
exceeds its fixed primes, the constant is uniform in `q`. -/
theorem finite_prime_different_sum_le {d q : ℕ} (S : Finset ℕ)
    (hd : 0 < d) (_hq : q.Prime) (hdegree : d ≤ q ^ 6)
    (hS : ∀ p ∈ S, p.Prime ∧ p ≤ q) :
    (∑ p ∈ S, (1 + (d.factorization p : ℝ)) * Real.log p) ≤
      7 * (S.card : ℝ) * Real.log q := by
  have hlogd : Real.log (d : ℝ) ≤ 6 * Real.log (q : ℝ) := by
    calc
      Real.log (d : ℝ) ≤ Real.log ((q : ℝ) ^ 6) := by
        apply Real.log_le_log (by exact_mod_cast hd)
        exact_mod_cast hdegree
      _ = 6 * Real.log (q : ℝ) := by rw [Real.log_pow]; norm_num
  have hfactor : ∀ p ∈ S,
      (1 + (d.factorization p : ℝ)) * Real.log p ≤ 7 * Real.log q := by
    intro p hp
    have hv := valuation_mul_log_le_log hd (hS p hp).1
    have hl : Real.log (p : ℝ) ≤ Real.log (q : ℝ) := by
      apply Real.log_le_log (by exact_mod_cast (hS p hp).1.pos)
      exact_mod_cast (hS p hp).2
    nlinarith
  calc
    _ ≤ ∑ _p ∈ S, 7 * Real.log (q : ℝ) := Finset.sum_le_sum hfactor
    _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul]; ring

section NumberFields

variable (T L : Type*) [Field T] [NumberField T] [Field L] [NumberField L]
    [Algebra T L]

/-- The discriminant tower formula yields the exact power divisibility. -/
theorem natAbs_discr_pow_dvd :
    (NumberField.discr T).natAbs ^ Module.finrank T L ∣
      (NumberField.discr L).natAbs := by
  rw [NumberField.natAbs_discr_eq_absNorm_differentIdeal_mul_natAbs_discr_pow
    T (NumberField.RingOfIntegers T) L (NumberField.RingOfIntegers L)]
  exact dvd_mul_left _ _

/-- Root-discriminant monotonicity in logarithmic form, proved from the
actual tower discriminant formula rather than assumed. -/
theorem log_root_discr_le :
    Real.log ((NumberField.discr T).natAbs : ℝ) / Module.finrank ℚ T ≤
      Real.log ((NumberField.discr L).natAbs : ℝ) / Module.finrank ℚ L := by
  have hT : 0 < (NumberField.discr T).natAbs :=
    Int.natAbs_pos.mpr (NumberField.discr_ne_zero T)
  have hL : 0 < (NumberField.discr L).natAbs :=
    Int.natAbs_pos.mpr (NumberField.discr_ne_zero L)
  have hle := Nat.le_of_dvd hL (natAbs_discr_pow_dvd T L)
  have hlog : (Module.finrank T L : ℝ) *
      Real.log ((NumberField.discr T).natAbs : ℝ) ≤
        Real.log ((NumberField.discr L).natAbs : ℝ) := by
    calc
      _ = Real.log (((NumberField.discr T).natAbs : ℝ) ^ Module.finrank T L) :=
        (Real.log_pow ..).symm
      _ ≤ _ := by
        apply Real.log_le_log (pow_pos (by exact_mod_cast hT) _)
        exact_mod_cast hle
  have hn : (0 : ℝ) < Module.finrank ℚ T := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := T)
  have hd : (0 : ℝ) < Module.finrank ℚ L := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := L)
  have htower : (Module.finrank ℚ T : ℝ) * Module.finrank T L =
      Module.finrank ℚ L := by
    exact_mod_cast Module.finrank_mul_finrank ℚ T L
  apply (div_le_div_iff₀ hn hd).2
  calc
    Real.log ((NumberField.discr T).natAbs : ℝ) * (Module.finrank ℚ L : ℝ) =
        (Module.finrank ℚ T : ℝ) *
          ((Module.finrank T L : ℝ) * Real.log ((NumberField.discr T).natAbs : ℝ)) := by
      rw [← htower]
      ring
    _ ≤ (Module.finrank ℚ T : ℝ) * Real.log ((NumberField.discr L).natAbs : ℝ) :=
      mul_le_mul_of_nonneg_left hlog hn.le
    _ = _ := by ring

/-- Transfer any ambient logarithmic root-discriminant bound to a subfield. -/
theorem log_discr_subfield_le_of_ambient_bound {C : ℝ}
    (hL : Real.log ((NumberField.discr L).natAbs : ℝ) ≤
      (Module.finrank ℚ L : ℝ) * C) :
    Real.log ((NumberField.discr T).natAbs : ℝ) ≤
      (Module.finrank ℚ T : ℝ) * C := by
  have hd : (0 : ℝ) < Module.finrank ℚ L := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := L)
  have hn : (0 : ℝ) < Module.finrank ℚ T := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := T)
  have hLratio : Real.log ((NumberField.discr L).natAbs : ℝ) /
      Module.finrank ℚ L ≤ C := by
    apply (div_le_iff₀ hd).2
    simpa only [mul_comm] using hL
  have hT := (log_root_discr_le T L).trans hLratio
  have hT' := (div_le_iff₀ hn).1 hT
  simpa only [mul_comm] using hT'

/-- The literal standard local different estimate for ramification only at
`2,q`. This predicate records that classical input; it is not asserted here.
Its degree and discriminant are the actual invariants of `L`. -/
def LocalDifferentEstimateTwoPrimes (q : ℕ) : Prop :=
  Real.log ((NumberField.discr L).natAbs : ℝ) ≤
    (Module.finrank ℚ L : ℝ) *
      ((1 + ((Module.finrank ℚ L).factorization 2 : ℝ)) * Real.log 2 +
       (1 + ((Module.finrank ℚ L).factorization q : ℝ)) * Real.log q)

/-- The general standard local different estimate, with the ramification
set displayed explicitly and actual number-field invariants throughout. -/
def LocalDifferentEstimateAt (S : Finset ℕ) : Prop :=
  Real.log ((NumberField.discr L).natAbs : ℝ) ≤
    (Module.finrank ℚ L : ℝ) *
      ∑ p ∈ S, (1 + ((Module.finrank ℚ L).factorization p : ℝ)) * Real.log p

/-- A uniform discriminant constant for a fixed finite set of bad primes,
as needed for the more general elliptic curves in Theorem 2. -/
theorem log_discr_subfield_le_of_finite_bad_primes {q : ℕ} (S : Finset ℕ)
    (hq : q.Prime) (hS : ∀ p ∈ S, p.Prime ∧ p ≤ q)
    (hdegree : Module.finrank ℚ L ≤ q ^ 6)
    (hlocal : LocalDifferentEstimateAt L (insert q S)) :
    Real.log ((NumberField.discr T).natAbs : ℝ) ≤
      (Module.finrank ℚ T : ℝ) *
        ((7 * ((S.card : ℝ) + 1)) * Real.log q) := by
  have hset : ∀ p ∈ insert q S, p.Prime ∧ p ≤ q := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hp
    · exact ⟨hq, le_rfl⟩
    · exact hS p hp
  have hsum := finite_prime_different_sum_le (insert q S)
    (Module.finrank_pos (R := ℚ) (M := L)) hq hdegree hset
  have hcard : ((insert q S).card : ℝ) ≤ (S.card : ℝ) + 1 := by
    exact_mod_cast Finset.card_insert_le q S
  have hlog : 0 ≤ Real.log (q : ℝ) := Real.log_natCast_nonneg q
  have hsize : 7 * ((insert q S).card : ℝ) * Real.log q ≤
      (7 * ((S.card : ℝ) + 1)) * Real.log q :=
    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hcard (by norm_num)) hlog
  apply log_discr_subfield_le_of_ambient_bound T L
  exact hlocal.trans (mul_le_mul_of_nonneg_left (hsum.trans hsize) (Nat.cast_nonneg _))

/-- The manuscript's uniform subfield discriminant estimate, derived from
the explicit local different input and the proved tower inequality. -/
theorem log_discr_subfield_le_of_local_different {q : ℕ} (hq : q.Prime)
    (hdegree : Module.finrank ℚ L ≤ q ^ 6)
    (hlocal : LocalDifferentEstimateTwoPrimes L q) :
    Real.log ((NumberField.discr T).natAbs : ℝ) ≤
      (Module.finrank ℚ T : ℝ) * (14 * Real.log q) := by
  have hsum := two_prime_different_sum_le
    (Module.finrank_pos (R := ℚ) (M := L)) hq hdegree
  have hd : (0 : ℝ) < Module.finrank ℚ L := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := L)
  have hn : (0 : ℝ) < Module.finrank ℚ T := by
    exact_mod_cast Module.finrank_pos (R := ℚ) (M := T)
  have hL : Real.log ((NumberField.discr L).natAbs : ℝ) ≤
      (Module.finrank ℚ L : ℝ) * (14 * Real.log q) :=
    hlocal.trans (mul_le_mul_of_nonneg_left hsum hd.le)
  have hLratio : Real.log ((NumberField.discr L).natAbs : ℝ) /
      Module.finrank ℚ L ≤ 14 * Real.log q := by
    apply (div_le_iff₀ hd).2
    simpa only [mul_comm] using hL
  have hT := (log_root_discr_le T L).trans hLratio
  have hT' := (div_le_iff₀ hn).1 hT
  simpa only [mul_comm] using hT'

/-- In a Galois extension, faithfulness of the affine action proves the
ambient degree bound by the Galois degree formula and three-point evaluation. -/
theorem finrank_le_sixth_power_of_faithful_affine_action [IsGalois ℚ L]
    {k : Type*} [Field k] [Fintype k]
    (ρ : Gal(L/ℚ) →* ((k × k) ≃ᵃ[k] (k × k)))
    (hfaithful : Function.Injective ρ) :
    Module.finrank ℚ L ≤ Fintype.card k ^ 6 := by
  rw [← IsGalois.card_aut_eq_finrank ℚ L]
  exact card_group_le_sixth_power ρ hfaithful

/-- The complete elementary discriminant deduction: neither the polynomial
degree bound nor the root-discriminant tower inequality is assumed. Only
faithfulness of the actual affine Galois representation and the literal
standard local different estimate remain arithmetic inputs. -/
theorem log_discr_subfield_le_of_faithful_affine_action [IsGalois ℚ L]
    (q : ℕ) [Fact q.Prime]
    (ρ : Gal(L/ℚ) →* ((ZMod q × ZMod q) ≃ᵃ[ZMod q] (ZMod q × ZMod q)))
    (hfaithful : Function.Injective ρ)
    (hlocal : LocalDifferentEstimateTwoPrimes L q) :
    Real.log ((NumberField.discr T).natAbs : ℝ) ≤
      (Module.finrank ℚ T : ℝ) * (14 * Real.log q) := by
  apply log_discr_subfield_le_of_local_different T L (Fact.out : q.Prime) _ hlocal
  simpa only [ZMod.card] using finrank_le_sixth_power_of_faithful_affine_action L ρ hfaithful

/-- Theorem 2's finite-bad-prime version, deriving the ambient polynomial
degree bound directly from the faithful affine action as well. -/
theorem log_discr_subfield_le_of_faithful_affine_action_finite_bad_primes
    [IsGalois ℚ L] (q : ℕ) [Fact q.Prime] (S : Finset ℕ)
    (hS : ∀ p ∈ S, p.Prime ∧ p ≤ q)
    (ρ : Gal(L/ℚ) →* ((ZMod q × ZMod q) ≃ᵃ[ZMod q] (ZMod q × ZMod q)))
    (hfaithful : Function.Injective ρ)
    (hlocal : LocalDifferentEstimateAt L (insert q S)) :
    Real.log ((NumberField.discr T).natAbs : ℝ) ≤
      (Module.finrank ℚ T : ℝ) *
        ((7 * ((S.card : ℝ) + 1)) * Real.log q) := by
  apply log_discr_subfield_le_of_finite_bad_primes T L S
    (Fact.out : q.Prime) hS _ hlocal
  simpa only [ZMod.card] using finrank_le_sixth_power_of_faithful_affine_action L ρ hfaithful

end NumberFields

end Elliptic
