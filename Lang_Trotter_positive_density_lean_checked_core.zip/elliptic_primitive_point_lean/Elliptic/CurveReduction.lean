module

public import Elliptic.CurveModel
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.LegendreSymbol.QuadraticReciprocity
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Data.Fintype.Option
public import Lean.Elab.Tactic.Omega
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.LinearCombination

/-!
# The actual reduction of the main example

This file constructs `y² = x³ - 2x` and `(2,2)` over `ZMod p`, using the
mathlib elliptic-curve definitions. The point-count argument below is an
elementary quadratic-character cancellation, not an assumed CM theorem.
-/

@[expose] public section

noncomputable section

namespace Elliptic

open scoped BigOperators

/-- The integral equation from Theorem 1, reduced modulo `p`. -/
def reductionCurve (p : ℕ) : WeierstrassCurve (ZMod p) :=
  ⟨0, 0, 0, -2, 0⟩

theorem reductionCurve_discriminant (p : ℕ) : (reductionCurve p).Δ = 512 := by
  norm_num [reductionCurve, WeierstrassCurve.Δ, WeierstrassCurve.b₂,
    WeierstrassCurve.b₄, WeierstrassCurve.b₆, WeierstrassCurve.b₈]

theorem two_ne_zero_mod_prime (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) :
    (2 : ZMod p) ≠ 0 := by
  intro h
  have hd : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp h
  exact hp2 ((Nat.dvd_prime Nat.prime_two).mp hd |>.resolve_left hp.out.ne_one)

theorem reductionCurve_isElliptic (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    (reductionCurve p).IsElliptic := by
  constructor
  apply isUnit_iff_ne_zero.mpr
  rw [reductionCurve_discriminant]
  have hpow : (512 : ZMod p) = 2 ^ 9 := by norm_num
  rw [hpow]
  exact pow_ne_zero _ (two_ne_zero_mod_prime p hp2)

theorem reductionCurve_equation_iff (p : ℕ) (x y : ZMod p) :
    (reductionCurve p).toAffine.Equation x y ↔ y ^ 2 = x ^ 3 - 2 * x := by
  rw [WeierstrassCurve.Affine.equation_iff]
  simp [reductionCurve, sub_eq_add_neg]

theorem reductionPoint_equation (p : ℕ) :
    (reductionCurve p).toAffine.Equation 2 2 := by
  rw [reductionCurve_equation_iff]
  norm_num

theorem reductionPoint_nonsingular (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    (reductionCurve p).toAffine.Nonsingular 2 2 := by
  let := reductionCurve_isElliptic p hp2
  exact WeierstrassCurve.Affine.equation_iff_nonsingular.mp (reductionPoint_equation p)

/-- The actual reduction of `P=(2,2)` at every odd prime. -/
def reductionPoint (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    (reductionCurve p).toAffine.Point :=
  .some 2 2 (reductionPoint_nonsingular p hp2)

theorem reductionPoint_ne_zero (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    reductionPoint p hp2 ≠ 0 := by
  simp [reductionPoint]

noncomputable instance reductionCurvePointFintype (p : ℕ) [Fact p.Prime] :
    Fintype (reductionCurve p).toAffine.Point := by
  classical
  letI : Fintype (WithZero {xy : ZMod p × ZMod p //
      (reductionCurve p).toAffine.Nonsingular xy.1 xy.2}) :=
    inferInstanceAs (Fintype (Option {xy : ZMod p × ZMod p //
      (reductionCurve p).toAffine.Nonsingular xy.1 xy.2}))
  exact Fintype.ofEquiv _ ((reductionCurve p).toAffine.nonsingularPointEquiv).symm

/-- Separate the `x` coordinate from the square-root fiber. -/
def reductionEquationEquivSqrt (p : ℕ) :
    {xy : ZMod p × ZMod p // (reductionCurve p).toAffine.Equation xy.1 xy.2} ≃
      Σ x : ZMod p, {y : ZMod p // y ^ 2 = x ^ 3 - 2 * x} where
  toFun z := ⟨z.1.1, z.1.2, (reductionCurve_equation_iff p _ _).1 z.2⟩
  invFun z := ⟨(z.1, z.2.1), (reductionCurve_equation_iff p _ _).2 z.2.2⟩
  left_inv z := by apply Subtype.ext; rfl
  right_inv z := by cases z; rfl

theorem reduction_quadraticChar_sum (p : ℕ) [Fact p.Prime] (hp4 : p % 4 = 3) :
    ∑ x : ZMod p, quadraticChar (ZMod p) (x ^ 3 - 2 * x) = 0 := by
  have hp2 : p ≠ 2 := by omega
  have hchar : ringChar (ZMod p) ≠ 2 := by rw [ZMod.ringChar_zmod_n]; exact hp2
  have hnegone : quadraticChar (ZMod p) (-1) = -1 := by
    rw [quadraticChar_neg_one hchar, ZMod.card, ZMod.χ₄_nat_three_mod_four hp4]
  have hneg (x : ZMod p) :
      quadraticChar (ZMod p) ((-x) ^ 3 - 2 * (-x)) =
        -quadraticChar (ZMod p) (x ^ 3 - 2 * x) := by
    rw [show (-x) ^ 3 - 2 * (-x) = (-1) * (x ^ 3 - 2 * x) by ring,
      map_mul, hnegone, neg_one_mul]
  have hperm := Equiv.sum_comp (Equiv.neg (ZMod p))
    (fun x => quadraticChar (ZMod p) (x ^ 3 - 2 * x))
  simp only [Equiv.neg_apply, hneg, Finset.sum_neg_distrib] at hperm
  omega

/-- The affine equation has exactly `p` solutions for `p ≡ 3 (mod 4)`. -/
theorem card_reduction_affine (p : ℕ) [Fact p.Prime] (hp4 : p % 4 = 3) :
    Nat.card {xy : ZMod p × ZMod p //
      (reductionCurve p).toAffine.Equation xy.1 xy.2} = p := by
  classical
  have hp2 : p ≠ 2 := by omega
  have hchar : ringChar (ZMod p) ≠ 2 := by rw [ZMod.ringChar_zmod_n]; exact hp2
  have hsqrt (x : ZMod p) :
      (Fintype.card {y : ZMod p // y ^ 2 = x ^ 3 - 2 * x} : ℤ) =
        quadraticChar (ZMod p) (x ^ 3 - 2 * x) + 1 := by
    have h := quadraticChar_card_sqrts hchar (x ^ 3 - 2 * x)
    rw [Set.toFinset_card, ← Nat.card_eq_fintype_card] at h
    rw [← Nat.card_eq_fintype_card]
    exact h
  rw [Nat.card_eq_fintype_card, Fintype.card_congr (reductionEquationEquivSqrt p),
    Fintype.card_sigma]
  apply Int.natCast_inj.mp
  push_cast
  simp_rw [hsqrt]
  rw [Finset.sum_add_distrib, reduction_quadraticChar_sum p hp4]
  simp

/-- The actual group of points has order `p+1` for `p ≡ 3 (mod 4)`. -/
theorem card_reduction_points (p : ℕ) [Fact p.Prime] (hp4 : p % 4 = 3) :
    Nat.card (reductionCurve p).toAffine.Point = p + 1 := by
  classical
  have hp2 : p ≠ 2 := by omega
  let := reductionCurve_isElliptic p hp2
  let : Fintype (WithZero {xy : ZMod p × ZMod p //
      (reductionCurve p).toAffine.Equation xy.1 xy.2}) :=
    inferInstanceAs (Fintype (Option {xy : ZMod p × ZMod p //
      (reductionCurve p).toAffine.Equation xy.1 xy.2}))
  rw [Nat.card_eq_fintype_card,
    Fintype.card_congr ((reductionCurve p).toAffine.pointEquiv)]
  change Fintype.card (Option {xy : ZMod p × ZMod p //
    (reductionCurve p).toAffine.Equation xy.1 xy.2}) = p + 1
  rw [Fintype.card_option]
  rw [← Nat.card_eq_fintype_card, card_reduction_affine p hp4]

/-- The duplication formula makes the first coordinate of every nonzero
double a square on `y²=x³-2x`. -/
theorem reduction_double_x_square_formula (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (x y : ZMod p) (heq : (reductionCurve p).toAffine.Equation x y) (hy : y ≠ 0) :
    (reductionCurve p).toAffine.addX x x
        ((reductionCurve p).toAffine.slope x x y y) = ((x ^ 2 + 2) / (2 * y)) ^ 2 := by
  have htwo := two_ne_zero_mod_prime p hp2
  have hyneg : y ≠ (reductionCurve p).toAffine.negY x y := by
    intro h
    have h' : y = -y := by simpa [WeierstrassCurve.Affine.negY, reductionCurve] using h
    apply mul_ne_zero htwo hy
    linear_combination h'
  rw [WeierstrassCurve.Affine.slope_of_Y_ne rfl hyneg]
  have heq' := (reductionCurve_equation_iff p x y).1 heq
  simp only [WeierstrassCurve.Affine.addX, WeierstrassCurve.Affine.negY,
    reductionCurve, zero_mul, mul_zero, add_zero, sub_zero, sub_neg_eq_add]
  rw [show y + y = 2 * y by ring]
  field_simp [htwo, hy]
  linear_combination -8 * x * heq'

/-- At primes `p ≡ 3 (mod 8)`, the actual reduced point `(2,2)` is not a
double in the actual elliptic-curve group. -/
theorem reductionPoint_not_double (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hp8 : p % 8 = 3) (R : (reductionCurve p).toAffine.Point) :
    R + R ≠ reductionPoint p hp2 := by
  have hnonsquare : ¬ IsSquare (2 : ZMod p) := by
    rw [ZMod.exists_sq_eq_two_iff hp2]
    omega
  intro h
  cases R with
  | zero =>
      change (0 : (reductionCurve p).toAffine.Point) + 0 = reductionPoint p hp2 at h
      exact reductionPoint_ne_zero p hp2 (by simpa using h.symm)
  | some x y hR =>
      by_cases hy : y = 0
      · have hdouble : WeierstrassCurve.Affine.Point.some x y hR +
            WeierstrassCurve.Affine.Point.some x y hR = 0 :=
          WeierstrassCurve.Affine.Point.add_self_of_Y_eq
            (by simp [WeierstrassCurve.Affine.negY, reductionCurve, hy])
        exact reductionPoint_ne_zero p hp2 (hdouble.symm.trans h).symm
      · have hyneg : y ≠ (reductionCurve p).toAffine.negY x y := by
          intro hyneg
          have h' : y = -y := by
            simpa [WeierstrassCurve.Affine.negY, reductionCurve] using hyneg
          apply mul_ne_zero (two_ne_zero_mod_prime p hp2) hy
          linear_combination h'
        rw [WeierstrassCurve.Affine.Point.add_self_of_Y_ne hyneg, reductionPoint] at h
        have hx := (WeierstrassCurve.Affine.Point.some.inj h).1
        apply hnonsquare
        refine ⟨(x ^ 2 + 2) / (2 * y), ?_⟩
        rw [← pow_two, ← reduction_double_x_square_formula p hp2 x y hR.1 hy, hx]

theorem reductionTwoTorsion_equation (p : ℕ) :
    (reductionCurve p).toAffine.Equation 0 0 := by
  rw [reductionCurve_equation_iff]
  simp

def reductionTwoTorsion (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    (reductionCurve p).toAffine.Point := by
  let := reductionCurve_isElliptic p hp2
  exact .mk (reductionTwoTorsion_equation p)

theorem reductionTwoTorsion_ne_zero (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    reductionTwoTorsion p hp2 ≠ 0 := by
  simp [reductionTwoTorsion, WeierstrassCurve.Affine.Point.mk]

theorem reductionTwoTorsion_double (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    reductionTwoTorsion p hp2 + reductionTwoTorsion p hp2 = 0 := by
  apply WeierstrassCurve.Affine.Point.add_self_of_Y_eq
  simp [WeierstrassCurve.Affine.negY, reductionCurve]

/-- For these primes `(0,0)` is the only nonidentity rational 2-torsion
point. This does not alone assert cyclicity of the full group. -/
theorem reduction_two_torsion_iff (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hp8 : p % 8 = 3) (R : (reductionCurve p).toAffine.Point) :
    R + R = 0 ↔ R = 0 ∨ R = reductionTwoTorsion p hp2 := by
  constructor
  · intro h
    cases R with
    | zero => exact Or.inl rfl
    | some x y hR =>
        right
        have hneg := eq_neg_of_add_eq_zero_left h
        rw [WeierstrassCurve.Affine.Point.neg_some] at hneg
        have hy := (WeierstrassCurve.Affine.Point.some.inj hneg).2
        have hy' : y = -y := by
          simpa [WeierstrassCurve.Affine.negY, reductionCurve] using hy
        have htwo_y : (2 : ZMod p) * y = 0 := by linear_combination hy'
        have hyzero : y = 0 := (mul_eq_zero.mp htwo_y).resolve_left (two_ne_zero_mod_prime p hp2)
        have heq := (reductionCurve_equation_iff p x y).1 hR.1
        have hprod : x * (x ^ 2 - 2) = 0 := by
          rw [hyzero] at heq
          linear_combination -heq
        have hxzero : x = 0 := by
          rcases mul_eq_zero.mp hprod with hx | hx
          · exact hx
          · have hsquare : IsSquare (2 : ZMod p) :=
              ⟨x, by rw [← pow_two]; exact (sub_eq_zero.mp hx).symm⟩
            rw [ZMod.exists_sq_eq_two_iff hp2] at hsquare
            omega
        subst x
        subst y
        rfl
  · rintro (rfl | rfl)
    · simp
    · exact reductionTwoTorsion_double p hp2

end Elliptic
