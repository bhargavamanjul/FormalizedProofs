module

public import Elliptic.Arithmetic.FiniteFieldIndex
public import Elliptic.HeightCounting
public import Elliptic.FinalReduction
public import Elliptic.SmoothedFormula
public import Elliptic.ReciprocalPrimeTail

/-!
# Assembly of the elliptic counting argument

The groups and generated subgroups below are actual finite additive groups.
The passage from the individual division-field estimate and the denominator
height bound to the manuscript's intermediate dyadic estimate is proved.

The candidate lower bound is deliberately named `CandidateMassObligation`:
it is an original sieve deduction still to be established from the precise
marked-distribution inputs, and is not an accepted external theorem.
Likewise, arithmetic hypotheses about reductions, division fields, and
denominators are explicit obligations, not silently supplied axioms.
-/

@[expose] public section

noncomputable section

namespace Elliptic

open Filter
open scoped BigOperators Topology

/-- A family of actual finite additive groups with specified points. It can
be instantiated with elliptic reductions, extended by a trivial group at
excluded parameters. -/
structure FinitePointFamily where
  Group : ℕ → Type
  group : ∀ p, AddGroup (Group p)
  finite : ∀ p, Finite (Group p)
  point : ∀ p, Group p

instance (F : FinitePointFamily) (p : ℕ) : AddGroup (F.Group p) := F.group p
instance (F : FinitePointFamily) (p : ℕ) : Finite (F.Group p) := F.finite p

def FinitePointFamily.Generates (F : FinitePointFamily) (p : ℕ) : Prop :=
  AddSubgroup.zmultiples (F.point p) = ⊤

def eligibleGenerator (F : FinitePointFamily) (Eligible : ℕ → Prop) (p : ℕ) : Prop :=
  Eligible p ∧ F.Generates p

def indexPrimes (F : FinitePointFamily) (Eligible : ℕ → Prop) (q : ℕ) (x : ℝ) :
    Finset ℕ := by
  classical
  exact (dyadicGoodPrimes Eligible x).filter (fun p => q ∣ pointIndex (F.point p))

def indexPrimeCount (F : FinitePointFamily) (Eligible : ℕ → Prop) (q : ℕ) (x : ℝ) : ℝ :=
  (indexPrimes F Eligible q x).card

def smallOrderPrimes (F : FinitePointFamily) (Eligible : ℕ → Prop) (M : ℕ) (x : ℝ) :
    Finset ℕ := by
  classical
  exact (dyadicGoodPrimes Eligible x).filter (fun p => addOrderOf (F.point p) ≤ M)

def candidateCount (Eligible : ℕ → Prop) (Candidate : ℝ → ℝ → ℝ → ℕ → Prop)
    (ε Y x : ℝ) : ℝ := by
  classical
  exact (((dyadicGoodPrimes Eligible x).filter (Candidate ε Y x)).card : ℝ)

theorem mem_dyadic_eligible {Eligible : ℕ → Prop} {p : ℕ} {x : ℝ}
    (hx : 0 ≤ x) (hp : p ∈ dyadicGoodPrimes Eligible x) :
    p.Prime ∧ Eligible p ∧ x < (p : ℝ) ∧ (p : ℝ) ≤ 2 * x := by
  classical
  simp only [dyadicGoodPrimes, goodPrimesUpTo, Finset.mem_filter, Nat.mem_primesLE] at hp
  refine ⟨hp.1.1.2, hp.1.2, hp.2, ?_⟩
  exact (Nat.cast_le.mpr hp.1.1.1).trans (Nat.floor_le (by positivity))

theorem primeIndexWindow_real_bounds {ε Y x : ℝ} {q : ℕ}
    (hx : 0 ≤ x) (hq : q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊) :
    q.Prime ∧ Y < (q : ℝ) ∧ (q : ℝ) ≤ x ^ ε := by
  obtain ⟨hprime, hlower, hupper⟩ := mem_primeIndexWindow.mp hq
  exact ⟨hprime, Nat.lt_of_floor_lt hlower,
    (Nat.cast_le.mpr hupper).trans (Nat.floor_le (Real.rpow_nonneg hx ε))⟩

/-- Pure arithmetic input needed only on the chosen candidates. This is a
definition of an outstanding obligation for a specific elliptic family. -/
def CandidateArithmeticObligation (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (Candidate : ℝ → ℝ → ℝ → ℕ → Prop)
    (cofactor largePrime : ℝ → ℝ → ℝ → ℕ → ℕ) (c : ℕ) : Prop :=
  ∀ ε Y x : ℝ, 0 < ε → 1 < Y → 1 < x →
    ∀ p ∈ dyadicGoodPrimes Eligible x, Candidate ε Y x p →
      Odd (pointIndex (F.point p)) ∧
      0 < cofactor ε Y x p ∧ (largePrime ε Y x p).Prime ∧
      Nat.card (F.Group p) = c * cofactor ε Y x p * largePrime ε Y x p ∧
      cofactor ε Y x p ≤ ⌊x ^ ε⌋₊ ∧
      (∀ q : ℕ, q.Prime → q ∣ cofactor ε Y x p → q ≠ 2 → ⌊Y⌋₊ < q)

theorem candidate_count_cover (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (Candidate : ℝ → ℝ → ℝ → ℕ → Prop)
    (cofactor largePrime : ℝ → ℝ → ℝ → ℕ → ℕ) {c k : ℕ}
    (hc : c = 2 ^ k)
    (harith : CandidateArithmeticObligation F Eligible Candidate cofactor largePrime c)
    {ε Y x : ℝ} (hε : 0 < ε) (hY : 1 < Y) (hx : 1 < x) :
    candidateCount Eligible Candidate ε Y x ≤
      dyadicGoodPrimeCount (eligibleGenerator F Eligible) x +
      (∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊, indexPrimeCount F Eligible q x) +
      ((smallOrderPrimes F Eligible (c * ⌊x ^ ε⌋₊) x).card : ℝ) := by
  classical
  have h := card_candidates_le_generators_add_exceptions_of_odd_index F.Group F.point
    (dyadicGoodPrimes Eligible x) (Candidate ε Y x)
    (cofactor ε Y x) (largePrime ε Y x) c k ⌊Y⌋₊ ⌊x ^ ε⌋₊ (c * ⌊x ^ ε⌋₊) hc ?_
  · have hfilter : (dyadicGoodPrimes Eligible x).filter
        (fun p => AddSubgroup.zmultiples (F.point p) = ⊤) =
        dyadicGoodPrimes (eligibleGenerator F Eligible) x := by
      ext p
      simp only [dyadicGoodPrimes, goodPrimesUpTo, Finset.mem_filter,
        eligibleGenerator, FinitePointFamily.Generates]
      tauto
    rw [hfilter] at h
    unfold candidateCount dyadicGoodPrimeCount indexPrimeCount indexPrimes smallOrderPrimes
    exact_mod_cast h
  · intro p hp hpc
    obtain ⟨hodd, hr, hQ, hfactor, hrR, hrough⟩ :=
      harith ε Y x hε hY hx p hp hpc
    exact ⟨hodd, hr, hQ, hfactor, hrR,
      Nat.mul_le_mul_left c hrR, hrough⟩

/-- The individual counting statement whose arithmetic/analytic derivation
is supplied separately. The moving prime range is simultaneous in `q`.
This is not an additional accepted external input. -/
def IndividualDivisionEstimateObligation (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (m E D Y₀ : ℝ) : Prop :=
  ∀ N : ℝ, 2 ≤ N → DedekindQRH N → ∀ᶠ x : ℝ in atTop,
    ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → (q : ℝ) < x →
      indexPrimeCount F Eligible q x ≤
        (m * (x / Real.log x)) * (1 / ((q : ℝ) * ((q : ℝ) - 1))) +
        (E * x ^ (1 - 1 / N) / Real.log x) *
          ((q : ℝ) * (D * Real.log q + 3))

theorem small_index_sum_bound (F : FinitePointFamily) (Eligible : ℕ → Prop)
    {ε Y x N m E D H : ℝ} (hx : 1 < x)
    (hm : 0 ≤ m) (hE : 0 ≤ E) (hD : 0 ≤ D)
    (hi : ∀ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊,
      indexPrimeCount F Eligible q x ≤
        (m * (x / Real.log x)) * (1 / ((q : ℝ) * ((q : ℝ) - 1))) +
        (E * x ^ (1 - 1 / N) / Real.log x) *
          ((q : ℝ) * (D * Real.log q + 3)))
    (htail : ∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊,
      1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤ H / (Y * Real.log Y)) :
    (∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊, indexPrimeCount F Eligible q x) ≤
      ((m * H) / (Y * Real.log Y)) * (x / Real.log x) +
      (E * ((D + 3 / Real.log 2) * Real.log 4)) *
        x ^ (1 - 1 / N + 2 * ε) / Real.log x := by
  have hx0 : 0 < x := by linarith
  have hlog : 0 < Real.log x := Real.log_pos hx
  have h := sum_division_bounds (primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊)
    (fun q => indexPrimeCount F Eligible q x)
    (M := m * (x / Real.log x)) (E := E * x ^ (1 - 1 / N) / Real.log x)
    (H := H) (Y := Y) (D := D) (T := x ^ ε)
    (by positivity) (by positivity) hD (Real.rpow_nonneg hx0.le ε)
    (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).1)
    (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).2.2) hi htail
  have hpow := division_error_power_identity hx0 (1 / N) ε
    ((D + 3 / Real.log 2) * Real.log 4)
  calc
    _ ≤ (m * (x / Real.log x)) * (H / (Y * Real.log Y)) +
        (E * x ^ (1 - 1 / N) / Real.log x) *
          (((D + 3 / Real.log 2) * Real.log 4) * (x ^ ε) ^ (2 : ℕ)) := h
    _ = _ := by
      calc
        _ = ((m * H) / (Y * Real.log Y)) * (x / Real.log x) +
            E * ((x ^ (1 - 1 / N) / Real.log x) *
              (((D + 3 / Real.log 2) * Real.log 4) * (x ^ ε) ^ (2 : ℕ))) := by ring
        _ = _ := by rw [hpow]; ring

/-- The arithmetic statement needed about the denominators of nonzero
multiples of the rational point. This is an outstanding elliptic obligation;
the elementary prime-counting consequence is proved below. -/
def DenominatorArithmeticObligation (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (den : ℕ → ℕ) (H : ℝ) : Prop :=
  (∀ n : ℕ, 0 < n → 0 < den n ∧ Real.log (den n : ℝ) ≤ H * (n : ℝ) ^ 2) ∧
  (∀ p : ℕ, p.Prime → Eligible p → p ∣ den (addOrderOf (F.point p)))

theorem small_order_count_bound (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (den : ℕ → ℕ) {H ε x : ℝ} (c : ℕ) (hH : 0 ≤ H)
    (hden : DenominatorArithmeticObligation F Eligible den H) (hx : 1 < x) :
    ((smallOrderPrimes F Eligible (c * ⌊x ^ ε⌋₊) x).card : ℝ) ≤
      (H * (c : ℝ) ^ 3) * x ^ (3 * ε) / Real.log x := by
  classical
  have hx0 : 0 < x := by linarith
  have h := denominator_primes_card_le_of_cutoff
    (B := den) (S := smallOrderPrimes F Eligible (c * ⌊x ^ ε⌋₊) x)
    (M := c * ⌊x ^ ε⌋₊) (T := (c : ℝ) * x ^ ε) hx hH ?_ ?_ ?_ ?_
  · have hpow : (x ^ ε) ^ (3 : ℕ) = x ^ (3 * ε) := by
      rw [← Real.rpow_mul_natCast hx0.le]
      congr 1
      ring
    simpa only [mul_pow, hpow, mul_assoc] using h
  · rw [Nat.cast_mul]
    exact mul_le_mul_of_nonneg_left (Nat.floor_le (Real.rpow_nonneg hx0.le ε))
      (Nat.cast_nonneg c)
  · intro n hn
    exact (hden.1 n (Finset.mem_Icc.mp hn).1).1
  · intro n hn
    exact (hden.1 n (Finset.mem_Icc.mp hn).1).2
  · intro p hp
    obtain ⟨hpambient, hporder⟩ := Finset.mem_filter.mp hp
    obtain ⟨hpprime, hpeligible, hpx, _⟩ := mem_dyadic_eligible hx0.le hpambient
    exact ⟨hpprime, hpx.le, addOrderOf (F.point p),
      Finset.mem_Icc.mpr ⟨addOrderOf_pos (F.point p), hporder⟩,
      hden.2 p hpprime hpeligible⟩

/-- ORIGINAL SIEVE OBLIGATION: the lower bound for the varying-cofactor
candidate set. This proposition is not asserted here and is not an accepted
external substitute for OpenAI's marked-distribution theorem. In particular,
proving it for the chosen candidates remains part of the manuscript's proof.
-/
def CandidateMassObligation (Eligible : ℕ → Prop)
    (Candidate : ℝ → ℝ → ℝ → ℕ → Prop) (A Y₀ ε₀ : ℝ) : Prop :=
  ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
    ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧ ∀ᶠ x : ℝ in atTop,
      (A * ε / Real.log Y + e x) * (x / Real.log x) ≤
        candidateCount Eligible Candidate ε Y x

/-- Assemble the proved group-theoretic cover, the summed individual
division estimates, and the cubic denominator bound. This discharges the
master intermediate estimate from smaller, separately named obligations.
The reciprocal-prime tail is already proved from mathlib's Chebyshev bound;
the candidate and arithmetic obligations remain explicit original work.
-/
theorem intermediate_estimate_of_candidate_division_and_height
    (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (Candidate : ℝ → ℝ → ℝ → ℕ → Prop)
    (cofactor largePrime : ℝ → ℝ → ℝ → ℕ → ℕ) (den : ℕ → ℕ)
    (c k : ℕ) (A m E D Hheight Y₀ ε₀ : ℝ)
    (hc : c = 2 ^ k) (hm : 0 ≤ m) (hE : 0 ≤ E)
    (hD : 0 ≤ D) (hheight : 0 ≤ Hheight)
    (harith : CandidateArithmeticObligation F Eligible Candidate cofactor largePrime c)
    (hcandidate : CandidateMassObligation Eligible Candidate A Y₀ ε₀)
    (hindividual : IndividualDivisionEstimateObligation F Eligible m E D Y₀)
    (hden : DenominatorArithmeticObligation F Eligible den Hheight) :
    IntermediateDyadicEstimate (dyadicGoodPrimeCount (eligibleGenerator F Eligible))
      A (m * (8 * Real.log 4)) Y₀ ε₀ := by
  intro N hN hQRH ε Y hε hε₀ h2ε _h3ε hY hY1
  obtain ⟨e, he, hcand⟩ := hcandidate ε Y hε hε₀ hY hY1
  refine ⟨E * ((D + 3 / Real.log 2) * Real.log 4),
    Hheight * (c : ℝ) ^ 3, e, he, ?_⟩
  have hNpos : 0 < N := by linarith
  have hNinv : 1 / N ≤ (1 : ℝ) := (div_le_one hNpos).mpr (by linarith)
  have hε1 : ε < 1 := by linarith
  filter_upwards [hcand, hindividual N hN hQRH,
    eventually_gt_atTop (1 : ℝ)] with x hcx hix hx
  have hx0 : 0 < x := by linarith
  have hcover := candidate_count_cover F Eligible Candidate cofactor largePrime
    hc harith hε hY1 hx
  have hsmall := small_index_sum_bound F Eligible hx hm hE hD
    (N := N) (H := 8 * Real.log 4) (ε := ε) (Y := Y) ?_ ?_
  · have hlarge := small_order_count_bound F Eligible den c hheight hden hx (ε := ε)
    have hmain : (A * ε / Real.log Y + e x) * (x / Real.log x) -
        ((m * (8 * Real.log 4)) / (Y * Real.log Y)) * (x / Real.log x) =
        ((A * ε - m * (8 * Real.log 4) / Y) / Real.log Y + e x) *
          (x / Real.log x) := by ring
    linarith
  · intro q hq
    have hb := primeIndexWindow_real_bounds hx0.le hq
    have hpow : x ^ ε < x := by
      simpa only [Real.rpow_one] using Real.rpow_lt_rpow_of_exponent_lt hx hε1
    exact hix q hb.1 (hY.trans_lt hb.2.1) (hb.2.2.trans_lt hpow)
  · exact reciprocalPrimeTail_eight_log_four Y hY1 _
      (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).1)
      (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).2.1)

/-- ORIGINAL ARITHMETIC OBLIGATION: construct the auxiliary number fields,
prove their degree/discriminant bounds, and inject each bad rational prime
with its fixed-embedding multiplicity into actual prime ideals of that field.
The injection is simultaneous for the moving range `q < x`. No Chebotarev
counting statement is assumed in this definition. -/
def DivisionFieldArithmeticObligation (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (K : ℕ → Type) [∀ q, Field (K q)] [∀ q, NumberField (K q)]
    (r : ℕ → ℕ) (D Y₀ : ℝ) : Prop :=
  ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    0 < r q ∧ (r q : ℝ) = (q : ℝ) * (q - 1) / 2 ∧
    (Module.finrank ℚ (K q) : ℝ) = (q : ℝ) * r q ∧
    Real.log ((NumberField.discr (K q)).natAbs : ℝ) ≤
      (Module.finrank ℚ (K q) : ℝ) * (D * Real.log q) ∧
    ∀ x : ℝ, 1 < x → (q : ℝ) < x →
      ∃ embed : ({p // p ∈ indexPrimes F Eligible q x} × Fin (r q)) ↪
          DedekindPrimeIdeal (K q),
        ∀ v, Ideal.absNorm (embed v).1 = v.1.1

/-- The actual individual bad-prime count follows from QRH, the separately
stated standard analytic estimates, and explicit field arithmetic. The
positive main-term coefficient is harmlessly enlarged to avoid introducing
any extra assumption on the sign of the Mellin mass. -/
theorem individual_estimate_of_division_fields
    (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (K : ℕ → Type) [∀ q, Field (K q)] [∀ q, NumberField (K q)]
    (r : ℕ → ℕ) (f : SplittingSmoothing) (A₀ B₀ R₀ T D Y₀ : ℝ)
    (hA₀ : 0 ≤ A₀) (hB₀ : 0 ≤ B₀) (hR₀ : 0 ≤ R₀)
    (hcount : ClassicalDyadicZeroCount A₀)
    (hdecay : ClassicalMellinDecay f B₀)
    (hformula : ClassicalSmoothedExplicitFormula f R₀ T)
    (hfields : DivisionFieldArithmeticObligation F Eligible K r D Y₀) :
    IndividualDivisionEstimateObligation F Eligible
      (2 * |f.mass| + 1) (2 * A₀ * B₀ + R₀) D Y₀ := by
  intro N hN hQRH
  filter_upwards [eventually_gt_atTop (max 1 T)] with x hx
  have hx1 : 1 < x := lt_of_le_of_lt (le_max_left _ _) hx
  have hTx : T ≤ x := (le_max_right _ _).trans hx.le
  have hx0 : 0 < x := by linarith
  intro q hq hqY hqx
  obtain ⟨hr, hrr, hn, hd, hinject⟩ := hfields q hq hqY
  obtain ⟨embed, hnorm⟩ := hinject x hx1 hqx
  have hq1 : (1 : ℝ) < q := by exact_mod_cast hq.one_lt
  have hbound := elliptic_prime_count_bound (K q) f (indexPrimes F Eligible q x)
    q (r q) hq1 hr hx1 hTx hN hQRH hA₀ hB₀ hR₀ hcount hdecay hformula
    (fun p hp => by
      have hp' := mem_dyadic_eligible hx0.le (Finset.mem_filter.mp hp).1
      exact ⟨hp'.2.2.1.le, hp'.2.2.2⟩)
    embed hnorm hrr hn hd
  change ((indexPrimes F Eligible q x).card : ℝ) ≤ _
  refine hbound.trans ?_
  have hcoef : 2 * f.mass ≤ 2 * |f.mass| + 1 := by
    have := le_abs_self f.mass
    linarith
  have hscale : 0 ≤ x / Real.log x := (div_pos hx0 (Real.log_pos hx1)).le
  have hweight : 0 ≤ 1 / ((q : ℝ) * ((q : ℝ) - 1)) := by positivity
  exact add_le_add
    (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hcoef hscale) hweight) le_rfl

/-- The final positive-proportion deduction now assumes the concrete
candidate and field/denominator obligations, rather than a preassembled
intermediate prime count. This is conditional progress, not a claim that
these original obligations have been proved for the elliptic curve. -/
theorem quantitative_generator_proportion_of_source_and_arithmetic_obligations
    (F : FinitePointFamily) (Eligible : ℕ → Prop)
    (Candidate : ℝ → ℝ → ℝ → ℕ → Prop)
    (cofactor largePrime : ℝ → ℝ → ℝ → ℕ → ℕ) (den : ℕ → ℕ)
    (K : ℕ → Type) [∀ q, Field (K q)] [∀ q, NumberField (K q)]
    (r : ℕ → ℕ) (f : SplittingSmoothing)
    (c k : ℕ) (A A₀ B₀ R₀ T D Hheight Y₀ ε₀ : ℝ)
    (hc : c = 2 ^ k) (hA : 0 < A) (hA₀ : 0 ≤ A₀)
    (hB₀ : 0 ≤ B₀) (hR₀ : 0 ≤ R₀) (hD : 0 ≤ D)
    (hheight : 0 ≤ Hheight) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (harith : CandidateArithmeticObligation F Eligible Candidate cofactor largePrime c)
    (hcandidate : CandidateMassObligation Eligible Candidate A Y₀ ε₀)
    (hfields : DivisionFieldArithmeticObligation F Eligible K r D Y₀)
    (hden : DenominatorArithmeticObligation F Eligible den Hheight)
    (hcount : ClassicalDyadicZeroCount A₀)
    (hdecay : ClassicalMellinDecay f B₀)
    (hformula : ClassicalSmoothedExplicitFormula f R₀ T) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount (eligibleGenerator F Eligible) x := by
  have hm : 0 < 2 * |f.mass| + 1 := by positivity
  have hE : 0 ≤ 2 * A₀ * B₀ + R₀ := by positivity
  have hH : 0 < 8 * Real.log (4 : ℝ) := by
    have := Real.log_pos (show (1 : ℝ) < 4 by norm_num)
    positivity
  have hi := individual_estimate_of_division_fields F Eligible K r f A₀ B₀ R₀ T D Y₀
    hA₀ hB₀ hR₀ hcount hdecay hformula hfields
  have hmaster := intermediate_estimate_of_candidate_division_and_height
    F Eligible Candidate cofactor largePrime den c k A (2 * |f.mass| + 1)
    (2 * A₀ * B₀ + R₀) D Hheight Y₀ ε₀ hc hm.le hE hD hheight
    harith hcandidate hi hden
  exact quantitative_prime_proportion_of_intermediate_estimate
    (eligibleGenerator F Eligible) A ((2 * |f.mass| + 1) * (8 * Real.log 4)) Y₀ ε₀
    hA (mul_pos hm hH) hY₀ hε₀ hmaster

end Elliptic
