module

public import Elliptic.MainCurveSignedConclusion
public import Elliptic.Arithmetic.DivisionFieldConstruction

/-!
# Main-curve conclusion for the constructed division fields

The finite Galois field family is constructed inside the actual algebraic
closure. Its finiteness, normality, full torsion descent and generation are
proved, rather than supplied as geometric hypotheses. The geometric
existence of division points and a rank-two torsion basis, and the stated
classical global/local arithmetic facts on the constructed fields, remain
explicit. The original SignedScalarCriterion remains unproved.
-/

@[expose] public section
noncomputable section
namespace Elliptic
open Filter Arithmetic
open scoped Topology

/-- The actual counting conclusion, using the constructed coordinate
fields instead of assuming a family of finite Galois division fields. -/
theorem main_curve_proportion_from_constructed_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : d.toGeometricDivisionFamily.GlobalInputs S Yarith)
    (hlocal : MainGeometricLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x :=
  main_curve_proportion_from_signed_and_geometric_sources signed sources
    d.toGeometricDivisionFamily S Yarith hglobal hlocal f hanalytic

/-- Infinitude for the actual pair and constructed division fields, with
all remaining inputs exposed in the theorem statement. -/
theorem main_curve_infinitely_many_from_constructed_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : d.toGeometricDivisionFamily.GlobalInputs S Yarith)
    (hlocal : MainGeometricLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_constructed_fields signed sources d S Yarith
      hglobal hlocal f hanalytic) hN hQRH

end Elliptic
