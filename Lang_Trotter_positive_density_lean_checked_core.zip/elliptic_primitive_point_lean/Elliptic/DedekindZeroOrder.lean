module

/- Reused from the Artin formalization: finite multiplicity of continued zeros. -/

public import Elliptic.DedekindHypothesis
public import Mathlib.Analysis.Analytic.Order

/-!
# Finite multiplicities of the actual continued Dedekind zeros

An infinite-order zero would force the continued function to vanish on the
punctured plane. Its prescribed nonzero residue rules this out. Thus natural
analytic order really is the multiplicity used by the zero-indexing type.
-/

@[expose] public section

namespace Elliptic

open Filter
open scoped Topology

theorem DedekindContinuation.analyticOrderAt_ne_top
    {K : Type*} [Field K] [NumberField K]
    (Z : DedekindContinuation K) {s : ℂ} (hs : s ≠ 1) :
    analyticOrderAt Z.zeta s ≠ ⊤ := by
  intro htop
  have hf := Z.holomorphic.analyticOnNhd isOpen_compl_singleton
  have hg : AnalyticOnNhd ℂ (fun _ : ℂ => (0 : ℂ)) ({1}ᶜ : Set ℂ) :=
    analyticOnNhd_const
  have hconn : IsPreconnected ({1}ᶜ : Set ℂ) :=
    (isConnected_compl_singleton_of_one_lt_rank (by simp) (1 : ℂ)).isPreconnected
  have hzero : Z.zeta =ᶠ[𝓝 s] (fun _ => (0 : ℂ)) := analyticOrderAt_eq_top.mp htop
  have hall : Set.EqOn Z.zeta (fun _ => (0 : ℂ)) ({1}ᶜ : Set ℂ) :=
    hf.eqOn_of_preconnected_of_eventuallyEq hg hconn (by simpa using hs) hzero
  have hlimit : Tendsto (fun z : ℂ => (z - 1) * Z.zeta z) (𝓝[≠] (1 : ℂ)) (𝓝 0) := by
    have heq : (fun z : ℂ => (z - 1) * Z.zeta z) =ᶠ[𝓝[≠] (1 : ℂ)]
        (fun _ => (0 : ℂ)) := by
      filter_upwards [self_mem_nhdsWithin] with z hz
      rw [hall hz, mul_zero]
    exact tendsto_const_nhds.congr' heq.symm
  exact Z.residue_nonzero (tendsto_nhds_unique Z.residue hlimit)

end Elliptic
