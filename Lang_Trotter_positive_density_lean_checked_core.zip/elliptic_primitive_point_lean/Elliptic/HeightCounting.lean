module

public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Algebra.Order.Ring.Basic
public import Mathlib.Order.Interval.Finset.Nat
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

/-!
# The cubic height-counting estimate

This file proves the elementary counting deduction used for the large-index
prime. If the positive denominators `B n` satisfy `log (B n) ≤ C * n²`, then
the number of primes at least `x` dividing one of `B 1, ..., B M` is at most
`C * M³ / log x`.

The elliptic-curve facts identifying these denominators, giving their
quadratic height bound, and relating their prime divisors to reduction of
`n • P` are not assumed to be formalized here. The precise numerical
hypotheses below are the boundary for those separate arithmetic results.
-/

open scoped BigOperators

@[expose] public section

namespace Elliptic

/-- The product containing all prime divisors of the first `M` denominators. -/
def denominatorProduct (B : ℕ → ℕ) (M : ℕ) : ℕ :=
  ∏ n ∈ Finset.Icc 1 M, B n

theorem denominatorProduct_pos {B : ℕ → ℕ} {M : ℕ}
    (hB : ∀ n ∈ Finset.Icc 1 M, 0 < B n) :
    0 < denominatorProduct B M := by
  exact Finset.prod_pos hB

/-- A quadratic logarithmic height bound sums to a cubic bound. -/
theorem log_denominatorProduct_le {B : ℕ → ℕ} {M : ℕ} {C : ℝ}
    (hC : 0 ≤ C)
    (hB : ∀ n ∈ Finset.Icc 1 M, 0 < B n)
    (hlog : ∀ n ∈ Finset.Icc 1 M,
      Real.log (B n : ℝ) ≤ C * (n : ℝ) ^ 2) :
    Real.log (denominatorProduct B M : ℝ) ≤ C * (M : ℝ) ^ 3 := by
  have hfactor : ∀ n ∈ Finset.Icc 1 M,
      Real.log (B n : ℝ) ≤ C * (M : ℝ) ^ 2 := by
    intro n hn
    refine (hlog n hn).trans (mul_le_mul_of_nonneg_left ?_ hC)
    apply pow_le_pow_left₀ (Nat.cast_nonneg n)
    exact_mod_cast (Finset.mem_Icc.mp hn).2
  calc
    Real.log (denominatorProduct B M : ℝ) =
        ∑ n ∈ Finset.Icc 1 M, Real.log (B n : ℝ) := by
      rw [denominatorProduct, Nat.cast_prod]
      apply Real.log_prod
      intro n hn
      exact_mod_cast (hB n hn).ne'
    _ ≤ ∑ n ∈ Finset.Icc 1 M, C * (M : ℝ) ^ 2 :=
      Finset.sum_le_sum hfactor
    _ = C * (M : ℝ) ^ 3 := by
      simp only [Finset.sum_const, Nat.card_Icc, Nat.add_sub_cancel,
        nsmul_eq_mul]
      ring

/-- Distinct prime divisors of a positive integer have total logarithm at most
the logarithm of that integer. -/
theorem prime_divisors_card_mul_log_le {S : Finset ℕ} {n : ℕ} {x : ℝ}
    (hn : 0 < n) (hx : 0 < x)
    (hS : ∀ p ∈ S, p.Prime ∧ p ∣ n ∧ x ≤ (p : ℝ)) :
    (S.card : ℝ) * Real.log x ≤ Real.log (n : ℝ) := by
  have hsub : S ⊆ n.primeFactors := by
    intro p hp
    exact (hS p hp).1.mem_primeFactors (hS p hp).2.1 hn.ne'
  have hdvd : (∏ p ∈ S, p) ∣ n :=
    (Finset.prod_dvd_prod_of_subset S n.primeFactors id hsub).trans
      (Nat.prod_primeFactors_dvd n)
  have hpPos : ∀ p ∈ S, 0 < (p : ℝ) := by
    intro p hp
    exact_mod_cast (hS p hp).1.pos
  have hprodPos : 0 < ∏ p ∈ S, (p : ℝ) := Finset.prod_pos hpPos
  calc
    (S.card : ℝ) * Real.log x = ∑ p ∈ S, Real.log x := by simp
    _ ≤ ∑ p ∈ S, Real.log (p : ℝ) := by
      apply Finset.sum_le_sum
      intro p hp
      exact Real.log_le_log hx (hS p hp).2.2
    _ = Real.log (∏ p ∈ S, (p : ℝ)) := by
      symm
      exact Real.log_prod (fun p hp => (hpPos p hp).ne')
    _ ≤ Real.log (n : ℝ) := by
      apply Real.log_le_log hprodPos
      rw [← Nat.cast_prod]
      exact_mod_cast Nat.le_of_dvd hn hdvd

theorem prime_divisors_card_le {S : Finset ℕ} {n : ℕ} {x : ℝ}
    (hn : 0 < n) (hx : 1 < x)
    (hS : ∀ p ∈ S, p.Prime ∧ p ∣ n ∧ x ≤ (p : ℝ)) :
    (S.card : ℝ) ≤ Real.log (n : ℝ) / Real.log x := by
  exact (le_div_iff₀ (Real.log_pos hx)).mpr
    (prime_divisors_card_mul_log_le hn (lt_trans zero_lt_one hx) hS)

/-- Divisibility by one denominator implies divisibility by their product. -/
theorem prime_dvd_denominatorProduct {B : ℕ → ℕ} {p M : ℕ}
    (h : ∃ n ∈ Finset.Icc 1 M, p ∣ B n) :
    p ∣ denominatorProduct B M := by
  obtain ⟨n, hn, hdiv⟩ := h
  exact hdiv.trans (Finset.dvd_prod_of_mem B hn)

/-- The cubic exceptional-prime estimate, with all arithmetic hypotheses
stated explicitly and no analytic input. -/
theorem denominator_primes_card_le {B : ℕ → ℕ} {S : Finset ℕ}
    {M : ℕ} {x C : ℝ} (hx : 1 < x) (hC : 0 ≤ C)
    (hB : ∀ n ∈ Finset.Icc 1 M, 0 < B n)
    (hlog : ∀ n ∈ Finset.Icc 1 M,
      Real.log (B n : ℝ) ≤ C * (n : ℝ) ^ 2)
    (hS : ∀ p ∈ S, p.Prime ∧ x ≤ (p : ℝ) ∧
      ∃ n ∈ Finset.Icc 1 M, p ∣ B n) :
    (S.card : ℝ) ≤ C * (M : ℝ) ^ 3 / Real.log x := by
  have hfirst : (S.card : ℝ) ≤
      Real.log (denominatorProduct B M : ℝ) / Real.log x := by
    apply prime_divisors_card_le (denominatorProduct_pos hB) hx
    intro p hp
    obtain ⟨hpp, hpx, hpB⟩ := hS p hp
    exact ⟨hpp, prime_dvd_denominatorProduct hpB, hpx⟩
  exact hfirst.trans (div_le_div_of_nonneg_right
    (log_denominatorProduct_le hC hB hlog) (Real.log_pos hx).le)

/-- A real upper cutoff can replace the integer cutoff in the cubic bound. -/
theorem denominator_primes_card_le_of_cutoff {B : ℕ → ℕ} {S : Finset ℕ}
    {M : ℕ} {x C T : ℝ} (hx : 1 < x) (hC : 0 ≤ C)
    (hMT : (M : ℝ) ≤ T)
    (hB : ∀ n ∈ Finset.Icc 1 M, 0 < B n)
    (hlog : ∀ n ∈ Finset.Icc 1 M,
      Real.log (B n : ℝ) ≤ C * (n : ℝ) ^ 2)
    (hS : ∀ p ∈ S, p.Prime ∧ x ≤ (p : ℝ) ∧
      ∃ n ∈ Finset.Icc 1 M, p ∣ B n) :
    (S.card : ℝ) ≤ C * T ^ 3 / Real.log x := by
  refine (denominator_primes_card_le hx hC hB hlog hS).trans ?_
  apply div_le_div_of_nonneg_right _ (Real.log_pos hx).le
  exact mul_le_mul_of_nonneg_left
    (pow_le_pow_left₀ (Nat.cast_nonneg M) hMT 3) hC

end Elliptic
