module

public import Elliptic.Parameters
public import Elliptic.DedekindHypothesis
public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.Tactic.FieldSimp

/-!
# The conditional final analytic deduction

This module proves parameter selection, normalization of both elliptic power
errors, and passage from a dyadic count to a lower proportion of all primes.

`IntermediateDyadicEstimate` is not an accepted external source or a globally
assumed axiom. The subsequent module `Assembly` derives it from the separately
specified candidate-sieve and field/denominator obligations. The module
`MainCurveConclusion` instantiates the groups, points and candidate predicate
to the actual main curve. The outstanding candidate and arithmetic obligations
must still be discharged to obtain the manuscript theorem from the agreed
external sources alone.

The numerical endpoints in this module take the intermediate estimate as an
explicit argument; the later assembly supplies that argument. The guard is
the actual `DedekindQRH` proposition, and no numerical instance is asserted.
The finite counts here use a general predicate `Good`; its actual elliptic
specialization is proved in `MainCurveConclusion`.
-/

@[expose] public section

namespace Elliptic

open Filter
open scoped Topology

/-- The precise intermediate estimate whose proof remains to be formalized.
The constants `A`, `C`, `Y₀`, and `ε₀` precede `N`. The two power-error
constants, vanishing error, and eventual threshold can depend on `N`, `ε`,
and `Y`. The unnormalized exponents are the elliptic exponents `1-1/N+2ε`
and `3ε`. This definition supplies no proof of the estimate. -/
def IntermediateDyadicEstimate (f : ℝ → ℝ) (A C Y₀ ε₀ : ℝ) : Prop :=
  ∀ N : ℝ, 2 ≤ N → DedekindQRH N → ∀ ε Y : ℝ,
    0 < ε → ε < ε₀ → 2 * ε < 1 / N → 3 * ε < 1 → Y₀ ≤ Y → 1 < Y →
      ∃ B₁ B₂ : ℝ, ∃ e₀ : ℝ → ℝ, Tendsto e₀ atTop (𝓝 0) ∧
        ∀ᶠ x : ℝ in atTop,
          ((A * ε - C / Y) / Real.log Y + e₀ x) * (x / Real.log x) -
            B₁ * x ^ (1 - 1 / N + 2 * ε) / Real.log x -
            B₂ * x ^ (3 * ε) / Real.log x ≤ f x

/-- Normalize the two displayed power errors and prove that their sum tends
to zero. This is a deduction from the explicitly supplied intermediate
estimate; it does not establish that estimate from external source results. -/
theorem normalized_bound_of_intermediate_estimate
    (f : ℝ → ℝ) (A C Y₀ ε₀ : ℝ)
    (hEst : IntermediateDyadicEstimate f A C Y₀ ε₀)
    (N : ℝ) (hN : 2 ≤ N) (hQRH : DedekindQRH N)
    (ε Y : ℝ) (hε : 0 < ε) (hε₀ : ε < ε₀)
    (h2ε : 2 * ε < 1 / N) (h3ε : 3 * ε < 1)
    (hY : Y₀ ≤ Y) (hY1 : 1 < Y) :
    ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧
      ∀ᶠ x : ℝ in atTop,
        ((A * ε - C / Y) / Real.log Y + e x) * (x / Real.log x) ≤ f x := by
  obtain ⟨B₁, B₂, e₀, he₀, hcount⟩ :=
    hEst N hN hQRH ε Y hε hε₀ h2ε h3ε hY hY1
  let e : ℝ → ℝ := fun x => e₀ x -
    (B₁ * x ^ (-(1 / N) + 2 * ε) + B₂ * x ^ (3 * ε - 1))
  have he : Tendsto e atTop (𝓝 0) := by
    have herr := tendsto_exception_error_zero h2ε h3ε B₁ B₂
    simpa only [e, sub_zero] using he₀.sub herr
  refine ⟨e, he, ?_⟩
  filter_upwards [hcount, eventually_ge_atTop (2 : ℝ)] with x hx hx2
  have hxp : 0 < x := by linarith
  have hpower₁ : x ^ (1 - 1 / N + 2 * ε) = x ^ (-(1 / N) + 2 * ε) * x := by
    have hexp : 1 - 1 / N + 2 * ε = (-(1 / N) + 2 * ε) + 1 := by ring
    rw [hexp, Real.rpow_add hxp, Real.rpow_one]
  have hpower₂ : x ^ (3 * ε) = x ^ (3 * ε - 1) * x := by
    calc
      x ^ (3 * ε) = x ^ ((3 * ε - 1) + 1) := by congr 1; ring
      _ = x ^ (3 * ε - 1) * x := by rw [Real.rpow_add hxp, Real.rpow_one]
  rw [hpower₁, hpower₂] at hx
  have heq :
      ((A * ε - C / Y) / Real.log Y + e x) * (x / Real.log x) =
      ((A * ε - C / Y) / Real.log Y + e₀ x) * (x / Real.log x) -
        B₁ * (x ^ (-(1 / N) + 2 * ε) * x) / Real.log x -
        B₂ * (x ^ (3 * ε - 1) * x) / Real.log x := by
    dsimp [e]
    ring
  rw [heq]
  exact hx

/-- Conditional quantitative dyadic bound. The positive constant `c` is
chosen before `N`; the threshold may depend on `N`. The intermediate analytic
estimate remains an explicit, unresolved argument of this theorem. -/
theorem quantitative_dyadic_bound_of_intermediate_estimate
    (f : ℝ → ℝ) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : IntermediateDyadicEstimate f A C Y₀ ε₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop, (c / (N * Real.log N)) * (x / Real.log x) ≤ f x := by
  obtain ⟨θ, D, c, _hθ, _hD, hc, hparams⟩ :=
    exists_uniform_parameters A C Y₀ ε₀ hA hC hY₀ hε₀
  refine ⟨c, hc, ?_⟩
  intro N hN hQRH
  obtain ⟨hε, hεsmall, h2ε, h3ε, hY, hY1, hbalance⟩ := hparams N hN
  obtain ⟨e, he, hcount⟩ := normalized_bound_of_intermediate_estimate
    f A C Y₀ ε₀ hEst N hN hQRH (θ / N) (D * N) hε hεsmall h2ε h3ε hY hY1
  have hNp : 0 < N := by linarith
  have hlogNp : 0 < Real.log N := Real.log_pos (by linarith)
  have hk : 0 < c / (N * Real.log N) := by positivity
  have hbalance' : 2 * (c / (N * Real.log N)) ≤
      (A * (θ / N) - C / (D * N)) / Real.log (D * N) := by
    convert hbalance using 1; ring_nf
  have hscale : ∀ᶠ x : ℝ in atTop, 0 ≤ x / Real.log x := by
    filter_upwards [eventually_ge_atTop (2 : ℝ)] with x hx
    have hxpos : 0 < x := by linarith
    have hxlog : 0 < Real.log x := Real.log_pos (by linarith)
    exact (div_pos hxpos hxlog).le
  exact eventually_lower_bound_from_vanishing_error hk hbalance' he hscale hcount

noncomputable def goodPrimesUpTo (Good : ℕ → Prop) (x : ℝ) : Finset ℕ := by
  classical
  exact (Nat.primesLE ⌊x⌋₊).filter Good

noncomputable def dyadicGoodPrimes (Good : ℕ → Prop) (x : ℝ) : Finset ℕ := by
  classical
  exact (goodPrimesUpTo Good (2 * x)).filter (fun p => x < (p : ℝ))

noncomputable def goodPrimeCount (Good : ℕ → Prop) (x : ℝ) : ℝ :=
  (goodPrimesUpTo Good x).card

noncomputable def dyadicGoodPrimeCount (Good : ℕ → Prop) (x : ℝ) : ℝ :=
  (dyadicGoodPrimes Good x).card

/-- A positive eventual lower proportion, relative to all primes. This property
does not assert that a limiting density exists. -/
def HasPositivePrimeProportion (Good : ℕ → Prop) : Prop :=
  ∃ d : ℝ, 0 < d ∧ ∀ᶠ x : ℝ in atTop,
    d * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ goodPrimeCount Good x

theorem dyadic_count_le_global (Good : ℕ → Prop) (x : ℝ) :
    dyadicGoodPrimeCount Good (x / 2) ≤ goodPrimeCount Good x := by
  classical
  unfold dyadicGoodPrimeCount goodPrimeCount dyadicGoodPrimes
  have heq : 2 * (x / 2) = x := by ring
  rw [heq]
  exact_mod_cast Finset.card_filter_le (goodPrimesUpTo Good x)
    (fun p => x / 2 < (p : ℝ))

/-- The analytic scale loses at most a factor two when the dyadic interval is
`(x/2,x]`. -/
theorem half_scale_lower_bound {x : ℝ} (hx : 4 ≤ x) :
    x / (2 * Real.log x) ≤ (x / 2) / Real.log (x / 2) := by
  have hxp : 0 < x := by linarith
  have hhalf : 1 < x / 2 := by linarith
  have hloghalf : 0 < Real.log (x / 2) := Real.log_pos hhalf
  have hlogx : 0 < Real.log x := Real.log_pos (by linarith)
  have hlogle : Real.log (x / 2) ≤ Real.log x :=
    Real.log_le_log (by linarith) (by linarith)
  calc
    x / (2 * Real.log x) = (x / 2) / Real.log x := by ring
    _ ≤ (x / 2) / Real.log (x / 2) :=
      div_le_div_of_nonneg_left (by positivity) hloghalf hlogle

/-- A dyadic lower bound gives an actual positive proportion. The classical
prime-counting upper bound is already a proved mathlib theorem. -/
theorem relative_bound_of_dyadic_bound (Good : ℕ → Prop) {d : ℝ} (hd : 0 < d)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      d * (x / Real.log x) ≤ dyadicGoodPrimeCount Good x) :
    ∀ᶠ x : ℝ in atTop,
      (d / (2 * (Real.log 4 + 1))) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
        ≤ goodPrimeCount Good x := by
  obtain ⟨x₀, hx₀⟩ := (eventually_atTop.1 hdyadic)
  have hB : 0 < Real.log (4 : ℝ) + 1 := by
    have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
    linarith
  filter_upwards [eventually_ge_atTop (max 4 (2 * x₀)),
    Chebyshev.eventually_primeCounting_le (show (0 : ℝ) < 1 by norm_num)] with x hx hpi
  have hx4 : 4 ≤ x := le_trans (le_max_left _ _) hx
  have hxhalf : x₀ ≤ x / 2 := by
    have := le_trans (le_max_right _ _) hx
    linarith
  have hscaled := mul_le_mul_of_nonneg_left (half_scale_lower_bound hx4) hd.le
  have hpi' := mul_le_mul_of_nonneg_left hpi
    (show 0 ≤ d / (2 * (Real.log 4 + 1)) by positivity)
  have heq : d / (2 * (Real.log 4 + 1)) *
      ((Real.log 4 + 1) * x / Real.log x) = d * (x / (2 * Real.log x)) := by
    field_simp
  rw [heq] at hpi'
  exact hpi'.trans (hscaled.trans ((hx₀ (x / 2) hxhalf).trans
    (dyadic_count_le_global Good x)))

theorem positive_prime_proportion_of_dyadic_bound (Good : ℕ → Prop)
    (h : ∃ d : ℝ, 0 < d ∧ ∀ᶠ x : ℝ in atTop,
      d * (x / Real.log x) ≤ dyadicGoodPrimeCount Good x) :
    HasPositivePrimeProportion Good := by
  obtain ⟨d, hd, hdyadic⟩ := h
  refine ⟨d / (2 * (Real.log 4 + 1)), ?_, relative_bound_of_dyadic_bound Good hd hdyadic⟩
  have : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  positivity

/-- Conditional lower proportion among actual primes satisfying `Good`.
This proves the limiting deduction from the intermediate estimate, not its
derivation for elliptic curves. The positive constant is uniform in `N`. -/
theorem quantitative_prime_proportion_of_intermediate_estimate
    (Good : ℕ → Prop) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : IntermediateDyadicEstimate (dyadicGoodPrimeCount Good) A C Y₀ ε₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ goodPrimeCount Good x := by
  obtain ⟨c, hc, hbound⟩ := quantitative_dyadic_bound_of_intermediate_estimate
    (dyadicGoodPrimeCount Good) A C Y₀ ε₀ hA hC hY₀ hε₀ hEst
  have hB : 0 < 2 * (Real.log (4 : ℝ) + 1) := by
    have := Real.log_pos (show (1 : ℝ) < 4 by norm_num)
    positivity
  refine ⟨c / (2 * (Real.log 4 + 1)), div_pos hc hB, ?_⟩
  intro N hN hQRH
  have hNp : 0 < N := by linarith
  have hlog : 0 < Real.log N := Real.log_pos (by linarith)
  have hd : 0 < c / (N * Real.log N) := by positivity
  have hb := relative_bound_of_dyadic_bound Good hd (hbound N hN hQRH)
  have heq : (c / (N * Real.log N)) / (2 * (Real.log 4 + 1)) =
      (c / (2 * (Real.log 4 + 1))) / (N * Real.log N) := by ring
  simpa only [heq] using hb

/-- The specialization to width `1/32`, conditional on both the actual
Dedekind zero-free statement and the unresolved intermediate estimate. -/
theorem positive_prime_proportion_at_32_of_intermediate_estimate
    (Good : ℕ → Prop) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : IntermediateDyadicEstimate (dyadicGoodPrimeCount Good) A C Y₀ ε₀)
    (h32 : DedekindQRH 32) : HasPositivePrimeProportion Good := by
  obtain ⟨c, hc, hb⟩ := quantitative_prime_proportion_of_intermediate_estimate
    Good A C Y₀ ε₀ hA hC hY₀ hε₀ hEst
  refine ⟨c / ((32 : ℝ) * Real.log 32), ?_, hb 32 (by norm_num) h32⟩
  have hlog : 0 < Real.log (32 : ℝ) := Real.log_pos (by norm_num)
  positivity

end Elliptic
