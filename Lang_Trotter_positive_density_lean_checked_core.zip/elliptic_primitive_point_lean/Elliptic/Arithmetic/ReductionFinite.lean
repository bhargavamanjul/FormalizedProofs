module

public import Elliptic.Arithmetic.ReductionRationals
public import Elliptic.CurveReduction
public import Elliptic.ActualDenominators

/-!
# Reduction of finite multiples of the actual point

These lemmas transport the actual affine group law across the residue map
when the addition slope has a unit denominator. They make no assumption
that reduction is a group homomorphism.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic
open WeierstrassCurve.Affine

variable (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)

include hp2

theorem reduceIntegralPoint_nonsingular (x y : primeIntegralRationals p)
    (h : exampleCurve.toAffine.Nonsingular (x : ℚ) (y : ℚ)) :
    (reductionCurve p).toAffine.Nonsingular
      (primeIntegralReduction p x) (primeIntegralReduction p y) := by
  let := reductionCurve_isElliptic p hp2
  apply equation_iff_nonsingular.mp
  rw [reductionCurve_equation_iff]
  have he : y ^ 2 = x ^ 3 - 2 * x := by
    apply Subtype.ext
    change (y : ℚ) ^ 2 = (x : ℚ) ^ 3 - 2 * (x : ℚ)
    simpa [equation_iff, exampleCurve, sub_eq_add_neg] using h.1
  have hr := congrArg (primeIntegralReduction p) he
  simpa only [map_pow, map_sub, map_mul, map_ofNat] using hr

def reduceIntegralPoint (x y : primeIntegralRationals p)
    (h : exampleCurve.toAffine.Nonsingular (x : ℚ) (y : ℚ)) :
    (reductionCurve p).toAffine.Point :=
  .some _ _ (reduceIntegralPoint_nonsingular p hp2 x y h)

/-- A finite rational point has integral coordinates and the specified
finite reduction. This relation includes the coordinate witnesses. -/
def FiniteReduces (R : exampleCurve.toAffine.Point)
    (S : (reductionCurve p).toAffine.Point) : Prop :=
  ∃ (x y : primeIntegralRationals p)
    (h : exampleCurve.toAffine.Nonsingular (x : ℚ) (y : ℚ)),
    R = .some _ _ h ∧ S = reduceIntegralPoint p hp2 x y h

theorem finiteReduces_point :
    FiniteReduces p hp2 examplePoint (reductionPoint p hp2) := by
  refine ⟨2, 2, examplePoint_nonsingular, rfl, ?_⟩
  simp only [reduceIntegralPoint, map_ofNat]
  rfl

theorem finiteReduces_add_point_of_x_ne (x y : primeIntegralRationals p)
    (h : exampleCurve.toAffine.Nonsingular (x : ℚ) (y : ℚ))
    (hx : primeIntegralReduction p x ≠ 2) :
    FiniteReduces p hp2 (.some _ _ h + examplePoint)
      (reduceIntegralPoint p hp2 x y h + reductionPoint p hp2) := by
  let r := primeIntegralReduction p
  have hx0 : r (x - 2) ≠ 0 := by simpa only [r, map_sub, map_ofNat, sub_ne_zero] using hx
  let l := (y - 2) * primeIntegralInv p (x - 2) hx0
  let X := l ^ 2 - x - 2
  let Y := -(l * (X - x) + y)
  have hxQ : (x : ℚ) ≠ 2 := by
    intro he
    apply hx
    change ((x : ℚ) : ZMod p) = 2
    rw [he]
    norm_num
  have hlQ : (l : ℚ) = ((y : ℚ) - 2) / ((x : ℚ) - 2) := by
    simp [l, div_eq_mul_inv]
    rfl
  have hXQ : (X : ℚ) = exampleCurve.toAffine.addX (x : ℚ) 2
      (exampleCurve.toAffine.slope (x : ℚ) 2 (y : ℚ) 2) := by
    simp [X, hlQ, slope_of_X_ne hxQ, exampleCurve]
    rfl
  have hYQ : (Y : ℚ) = exampleCurve.toAffine.addY (x : ℚ) 2 (y : ℚ)
      (exampleCurve.toAffine.slope (x : ℚ) 2 (y : ℚ) 2) := by
    simp [Y, hXQ, hlQ, slope_of_X_ne hxQ, addY, negAddY, negY, exampleCurve]
  have hnew : exampleCurve.toAffine.Nonsingular (X : ℚ) (Y : ℚ) := by
    rw [hXQ, hYQ]
    exact nonsingular_add h examplePoint_nonsingular (fun hxy => hxQ hxy.1)
  refine ⟨X, Y, hnew, ?_, ?_⟩
  · change Point.some _ _ h + Point.some 2 2 examplePoint_nonsingular = _
    rw [Point.add_of_X_ne hxQ]
    rw [Point.some.injEq]
    exact ⟨hXQ.symm, hYQ.symm⟩
  · have hlr : r l = (r y - 2) / (r x - 2) := by
      simp only [l, map_mul, map_sub, map_ofNat, primeIntegralReduction_inv,
        div_eq_mul_inv, r]
    change Point.some _ _ _ + Point.some 2 2 _ = Point.some _ _ _
    rw [Point.add_of_X_ne hx]
    rw [Point.some.injEq]
    constructor
    · simp only [slope_of_X_ne hx, addX, reductionCurve]
      simp only [X, map_sub, map_pow, map_ofNat, ← hlr, r]
      ring
    · simp only [slope_of_X_ne hx, addY, negAddY, negY, addX, reductionCurve]
      simp only [Y, X, map_neg, map_add, map_mul, map_sub, map_pow, map_ofNat, ← hlr, r]
      ring

theorem finiteReduces_add_point {R : exampleCurve.toAffine.Point}
    {S : (reductionCurve p).toAffine.Point} (hred : FiniteReduces p hp2 R S)
    (hplus : S ≠ reductionPoint p hp2) (hminus : S ≠ -reductionPoint p hp2) :
    FiniteReduces p hp2 (R + examplePoint) (S + reductionPoint p hp2) := by
  obtain ⟨x, y, h, rfl, rfl⟩ := hred
  apply finiteReduces_add_point_of_x_ne
  intro hx
  have he := (Point.X_eq_iff
    (h₁ := reduceIntegralPoint_nonsingular p hp2 x y h)
    (h₂ := reductionPoint_nonsingular p hp2)).mp hx
  exact he.elim hplus hminus

theorem finiteReduces_double :
    FiniteReduces p hp2 (2 • examplePoint) (2 • reductionPoint p hp2) := by
  have htwo := two_ne_zero_mod_prime p hp2
  have hfour : (4 : ZMod p) ≠ 0 := by
    convert mul_ne_zero htwo htwo using 1
    norm_num
  have height : (8 : ZMod p) ≠ 0 := by
    convert mul_ne_zero hfour htwo using 1
    norm_num
  have h4 : ¬p ∣ 4 := fun hd => hfour ((ZMod.natCast_eq_zero_iff 4 p).2 hd)
  have h8 : ¬p ∣ 8 := fun hd => height ((ZMod.natCast_eq_zero_iff 8 p).2 hd)
  let x : primeIntegralRationals p := ⟨9/4, by norm_num [mem_primeIntegralRationals]; exact h4⟩
  let y : primeIntegralRationals p := ⟨-21/8, by norm_num [mem_primeIntegralRationals]; exact h8⟩
  have h : exampleCurve.toAffine.Nonsingular (x : ℚ) (y : ℚ) :=
    equation_iff_nonsingular.mp exampleDouble_equation
  refine ⟨x, y, h, ?_, ?_⟩
  · rw [two_nsmul, examplePoint_double]
    rfl
  · have hx : primeIntegralReduction p x = (9 : ZMod p) / 4 := by
      norm_num [primeIntegralReduction_apply, x, Rat.cast_def]
    have hy : primeIntegralReduction p y = (-21 : ZMod p) / 8 := by
      norm_num [primeIntegralReduction_apply, y, Rat.cast_def]
    have hn : (2 : ZMod p) ≠ (reductionCurve p).toAffine.negY 2 2 := by
      simp only [negY, reductionCurve, zero_mul, sub_zero]
      intro he
      apply hfour
      linear_combination he
    rw [two_nsmul]
    change Point.some 2 2 _ + Point.some 2 2 _ = Point.some _ _ _
    rw [Point.add_self_of_Y_ne hn, Point.some.injEq]
    rw [slope_of_Y_ne rfl hn]
    simp only [addX, addY, negAddY, negY, reductionCurve,
      hx, hy, zero_mul, add_zero, sub_zero]
    constructor <;> ring_nf <;> field_simp <;> ring

end Elliptic
