module

public import Elliptic.Arithmetic.DivisionTorsor
public import Elliptic.InfiniteOrder
public import Mathlib.NumberTheory.Zsqrtd.GaussianInt
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic
public import Mathlib.Algebra.Polynomial.SpecificDegree
public import Mathlib.Tactic

/-!
# The concrete complex multiplication action on the main elliptic curve

For every characteristic-zero field containing a square root `i` of `-1`,
the literal map `(x,y) ↦ (-x,i*y)` is an additive automorphism of
`y²=x³-2*x`. Its square is the actual group negation. The final theorem
checks independence of the base-changed rational point under this action.

This does not assert the classification of all geometric endomorphisms,
or the Kummer theorem of Ribet.
-/

@[expose] public section
noncomputable section

namespace Elliptic.Arithmetic.MainCurveCM

open WeierstrassCurve

variable {K : Type*} [Field K] [Algebra ℚ K] [DecidableEq K]

abbrev curve := exampleCurve.toAffine.baseChange K
abbrev Points := CurvePoints exampleCurve K

instance : (curve (K:=K)).IsElliptic := by
  change (exampleCurve.map (algebraMap ℚ K)).IsElliptic
  infer_instance

omit [DecidableEq K] in
theorem negY_eq (x y : K) : (curve (K:=K)).negY x y = -y := by
  simp [curve, exampleCurve, Affine.negY, Affine.baseChange]

omit [DecidableEq K] in
theorem equation_iff (x y : K) :
    (curve (K:=K)).Equation x y ↔ y ^ 2 = x ^ 3 - 2 * x := by
  rw [Affine.equation_iff]
  simp [curve, exampleCurve, Affine.baseChange]
  ring_nf

omit [DecidableEq K] in
theorem transformed_nonsingular (i : K) (hi : i ^ 2 = -1) {x y : K}
    (h : (curve (K:=K)).Nonsingular x y) :
    (curve (K:=K)).Nonsingular (-x) (i * y) := by
  apply Affine.equation_iff_nonsingular.mp
  rw [equation_iff]
  have hxy := (equation_iff x y).mp h.1
  rw [mul_pow, hi, hxy]
  ring

/-- The genuine map on affine points, including the point at infinity. -/
def rotation (i : K) (hi : i ^ 2 = -1) : Points (K:=K) → Points (K:=K)
  | .zero => .zero
  | .some x y h => .some (-x) (i * y) (transformed_nonsingular i hi h)

omit [DecidableEq K] in
@[simp] theorem rotation_zero (i : K) (hi : i ^ 2 = -1) :
    rotation i hi 0 = 0 := rfl

omit [DecidableEq K] in
@[simp] theorem rotation_some (i : K) (hi : i ^ 2 = -1) (x y : K)
    (h : (curve (K:=K)).Nonsingular x y) :
    rotation i hi (.some x y h) =
      .some (-x) (i * y) (transformed_nonsingular i hi h) := rfl

omit [DecidableEq K] in
theorem rotation_square (i : K) (hi : i ^ 2 = -1) (P : Points (K:=K)) :
    rotation i hi (rotation i hi P) = -P := by
  cases P with
  | zero => rfl
  | some x y h =>
    simp only [rotation_some, Affine.Point.neg_some, Affine.Point.some.injEq,
      neg_neg, negY_eq, true_and]
    calc i * (i * y) = i ^ 2 * y := by ring
         _ = -y := by rw [hi]; ring

theorem rotation_slope (i : K) (hi : i ^ 2 = -1) (x₁ x₂ y₁ y₂ : K) :
    (curve (K:=K)).slope (-x₁) (-x₂) (i*y₁) (i*y₂) =
      -i * (curve (K:=K)).slope x₁ x₂ y₁ y₂ := by
  have hi0 : i ≠ 0 := by intro h; simp [h] at hi
  have hinv : i⁻¹ = -i := by
    apply inv_eq_of_mul_eq_one_right
    calc i * -i = -(i ^ 2) := by ring
         _ = 1 := by rw [hi]; ring
  have hy : i * y₁ = -(i * y₂) ↔ y₁ = -y₂ := by
    rw [← mul_neg, mul_right_inj' hi0]
  simp only [Affine.slope, negY_eq, neg_inj, hy]
  split_ifs
  · simp
  · simp [curve, exampleCurve, Affine.baseChange, div_eq_mul_inv]
    ring_nf
    rw [hinv]
    ring
  · rw [show -x₁ - -x₂ = -(x₁-x₂) by ring, div_neg, ← mul_sub, mul_div_assoc]
    ring

omit [DecidableEq K] in
theorem rotation_addX (i : K) (hi : i ^ 2 = -1) (x₁ x₂ s : K) :
    (curve (K:=K)).addX (-x₁) (-x₂) (-i*s) =
      -(curve (K:=K)).addX x₁ x₂ s := by
  simp only [Affine.addX]
  simp [curve, exampleCurve, Affine.baseChange,
    mul_pow, hi]
  ring

omit [DecidableEq K] in
theorem rotation_addY (i : K) (hi : i ^ 2 = -1) (x₁ x₂ y₁ s : K) :
    (curve (K:=K)).addY (-x₁) (-x₂) (i*y₁) (-i*s) =
      i * (curve (K:=K)).addY x₁ x₂ y₁ s := by
  simp only [Affine.addY, negY_eq, Affine.negAddY, rotation_addX i hi]
  ring

theorem rotation_add (i : K) (hi : i ^ 2 = -1) (P Q : Points (K:=K)) :
    rotation i hi (P+Q) = rotation i hi P + rotation i hi Q := by
  have hi0 : i ≠ 0 := by intro h; simp [h] at hi
  cases P with
  | zero => rfl
  | some x₁ y₁ h₁ =>
    cases Q with
    | zero => rfl
    | some x₂ y₂ h₂ =>
      by_cases hxy : x₁ = x₂ ∧ y₁ = (curve (K:=K)).negY x₂ y₂
      · rw [Affine.Point.add_of_Y_eq hxy.1 hxy.2, rotation_zero,
          rotation_some, rotation_some, Affine.Point.add_of_Y_eq]
        · exact congrArg Neg.neg hxy.1
        · simpa only [negY_eq, ← mul_neg] using congrArg (i * ·) hxy.2
      · have hxy' : ¬(-x₁ = -x₂ ∧ i*y₁ = (curve (K:=K)).negY (-x₂) (i*y₂)) := by
          simpa only [negY_eq, neg_inj, ← mul_neg, mul_right_inj' hi0] using hxy
        rw [Affine.Point.add_some hxy, rotation_some, rotation_some, rotation_some,
          Affine.Point.add_some hxy']
        simp only [rotation_slope i hi, rotation_addX i hi, rotation_addY i hi]

/-- The CM endomorphism is proved additive from the actual chord-and-tangent law. -/
def rotationHom (i : K) (hi : i ^ 2 = -1) : Points (K:=K) →+ Points (K:=K) where
  toFun := rotation i hi
  map_zero' := rotation_zero i hi
  map_add' := rotation_add i hi

@[simp] theorem rotationHom_apply (i : K) (hi : i ^ 2 = -1) (P : Points (K:=K)) :
    rotationHom i hi P = rotation i hi P := rfl

/-- Its inverse is negative rotation, as follows from its square being [-1]. -/
def rotationEquiv (i : K) (hi : i ^ 2 = -1) : Points (K:=K) ≃+ Points (K:=K) where
  toAddHom := rotationHom i hi
  invFun P := -(rotationHom i hi P)
  left_inv P := by simp [rotation_square]
  right_inv P := by
    change rotationHom i hi (-(rotationHom i hi P)) = P
    rw [map_neg]
    simp [rotation_square]

/-- The endomorphism labelled by the Gaussian integer `a+b*i`. -/
def gaussianAction (i : K) (hi : i ^ 2 = -1) (a b : ℤ) :
    Points (K:=K) →+ Points (K:=K) :=
  a • AddMonoidHom.id _ + b • rotationHom i hi

@[simp] theorem gaussianAction_apply (i : K) (hi : i ^ 2 = -1)
    (a b : ℤ) (P : Points (K:=K)) :
    gaussianAction i hi a b P = a • P + b • rotationHom i hi P := rfl

/-- Gaussian conjugation gives the usual integer norm on the actual point group. -/
theorem gaussianAction_norm (i : K) (hi : i ^ 2 = -1)
    (a b : ℤ) (P : Points (K:=K)) :
    gaussianAction i hi a (-b) (gaussianAction i hi a b P) =
      (a ^ 2 + b ^ 2) • P := by
  simp only [gaussianAction_apply, map_add, map_zsmul, smul_add, smul_smul,
    rotationHom_apply, rotation_square, smul_neg, neg_smul]
  module

/-- No nonzero Gaussian label annihilates a non-torsion point. -/
theorem gaussianAction_eq_zero_iff (i : K) (hi : i ^ 2 = -1)
    {P : Points (K:=K)} (hP : ¬ IsOfFinAddOrder P) (a b : ℤ) :
    gaussianAction i hi a b P = 0 ↔ a = 0 ∧ b = 0 := by
  constructor
  · intro h
    have hn : (a ^ 2 + b ^ 2) • P = 0 := by
      rw [← gaussianAction_norm i hi a b P, h, map_zero]
    have hn0 : a ^ 2 + b ^ 2 = 0 := by
      by_contra hn0
      exact hP (isOfFinAddOrder_iff_zsmul_eq_zero.mpr ⟨_, hn0, hn⟩)
    constructor <;> nlinarith [sq_nonneg a, sq_nonneg b]
  · rintro ⟨rfl, rfl⟩
    simp

/-- The already proved non-torsion assertion survives every field extension. -/
theorem examplePoint_baseChange_infinite_order :
    ¬ IsOfFinAddOrder (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K examplePoint) := by
  intro h
  obtain ⟨n, hn, he⟩ := isOfFinAddOrder_iff_zsmul_eq_zero.mp h
  apply examplePoint_infinite_order
  apply isOfFinAddOrder_iff_zsmul_eq_zero.mpr
  refine ⟨n, hn, ?_⟩
  apply Affine.Point.map_injective (W':=exampleCurve.toAffine) (Algebra.ofId ℚ K)
  change (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K) (n • examplePoint) =
    (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K) 0
  exact (map_zsmul (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K) n
    (examplePoint : CurvePoints exampleCurve ℚ)).trans
      (he.trans (map_zero (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K)).symm)

/-- The precise one-point independence calculation needed over the CM base. -/
theorem examplePoint_gaussian_independent (i : K) (hi : i ^ 2 = -1) (a b : ℤ) :
    gaussianAction i hi a b
      (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K examplePoint) = 0 ↔
      a = 0 ∧ b = 0 :=
  gaussianAction_eq_zero_iff i hi examplePoint_baseChange_infinite_order a b

/-- The Gaussian action is an actual ring homomorphism into point-group
endomorphisms. Multiplicativity is checked using the square relation. -/
def gaussianEndomorphisms (i : K) (hi : i ^ 2 = -1) :
    GaussianInt →+* AddMonoid.End (Points (K:=K)) where
  toFun z := gaussianAction i hi z.re z.im
  map_one' := by
    ext P
    change (1 : ℤ) • P + (0 : ℤ) • rotationHom i hi P = P
    simp
  map_zero' := by
    ext P
    change (0 : ℤ) • P + (0 : ℤ) • rotationHom i hi P = 0
    simp
  map_add' z w := by
    ext P
    change gaussianAction i hi (z+w).re (z+w).im P =
      gaussianAction i hi z.re z.im P + gaussianAction i hi w.re w.im P
    simp only [Zsqrtd.re_add, Zsqrtd.im_add, gaussianAction_apply,
      add_zsmul]
    abel
  map_mul' z w := by
    ext P
    change gaussianAction i hi (z*w).re (z*w).im P =
      gaussianAction i hi z.re z.im (gaussianAction i hi w.re w.im P)
    simp only [Zsqrtd.re_mul, Zsqrtd.im_mul, gaussianAction_apply,
      map_add, map_zsmul, smul_add, smul_smul,
      rotationHom_apply, rotation_square, smul_neg]
    module

/-- The Gaussian ring really embeds: its distinct labels are distinguished
already by their values at the non-torsion rational point. -/
theorem gaussianEndomorphisms_injective (i : K) (hi : i ^ 2 = -1) :
    Function.Injective (gaussianEndomorphisms i hi) := by
  intro z w h
  have hzero : gaussianEndomorphisms i hi (z-w) = 0 := by
    rw [map_sub, h, sub_self]
  have hp := congrArg (fun f : AddMonoid.End (Points (K:=K)) =>
    f (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K examplePoint)) hzero
  change gaussianAction i hi (z-w).re (z-w).im
    (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ K examplePoint) = 0 at hp
  obtain ⟨hr, hi'⟩ := (examplePoint_gaussian_independent i hi _ _).mp hp
  apply sub_eq_zero.mp
  exact Zsqrtd.ext hr hi'

/-- The literal subfield Q(i) of C, rather than a root-of-minus-one premise. -/
def cmField : IntermediateField ℚ ℂ := IntermediateField.adjoin ℚ {Complex.I}

def cmI : cmField := ⟨Complex.I, IntermediateField.subset_adjoin _ _ (by simp)⟩

theorem cmI_sq : cmI ^ 2 = -1 := by
  apply Subtype.ext
  exact Complex.I_sq

theorem cmI_integral : IsIntegral ℚ Complex.I := by
  apply IsIntegral.of_pow (n:=2) (by omega)
  rw [Complex.I_sq]
  exact isIntegral_one.neg

instance cmField_finiteDimensional : FiniteDimensional ℚ cmField :=
  IntermediateField.adjoin.finiteDimensional cmI_integral

theorem cm_minpoly : minpoly ℚ Complex.I = Polynomial.X ^ 2 + 1 := by
  symm
  apply minpoly.eq_of_irreducible_of_monic
  · apply Polynomial.irreducible_of_degree_le_three_of_not_isRoot
    · norm_num
    · intro x hx
      simp only [Polynomial.IsRoot, Polynomial.eval_add, Polynomial.eval_pow,
        Polynomial.eval_X, Polynomial.eval_one] at hx
      nlinarith [sq_nonneg x]
  · simp
  · exact Polynomial.monic_X_pow_add_C _ (by omega)

/-- The specified CM field has its required quadratic degree over Q. -/
theorem cmField_finrank : Module.finrank ℚ cmField = 2 := by
  rw [show cmField = IntermediateField.adjoin ℚ {Complex.I} by rfl,
    IntermediateField.adjoin.finrank cmI_integral, cm_minpoly]
  norm_num

/-- A premise-free CM action on the concrete curve over the concrete CM field. -/
def cmRotation : Points (K:=cmField) ≃+ Points (K:=cmField) := by
  classical
  exact rotationEquiv cmI cmI_sq

theorem cmPoint_independent (a b : ℤ) :
    a • (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ cmField examplePoint) +
      b • cmRotation
        (Affine.Point.baseChange (W':=exampleCurve.toAffine) ℚ cmField examplePoint) = 0 ↔
    a = 0 ∧ b = 0 := by
  classical
  exact examplePoint_gaussian_independent cmI cmI_sq a b

end Elliptic.Arithmetic.MainCurveCM
