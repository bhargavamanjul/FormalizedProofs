module

public import Elliptic.SquareclassSignRealization
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.NormNum.IsSquare
public import Mathlib.Tactic.FinCases

/-!
# Exact arithmetic checks for the main curve and six manuscript examples

The coordinates below use the model `y² = x(x² + A*x + B)` required by
Theorem 2. For table rows 4 and 5 the changes of coordinates are respectively
`x_new = x_old + 7` and `x_new = x_old - 4`.

This file proves the point equations, nonsingularity discriminants, the
numerical j-invariants, and the exact rational squareclass compatibility
condition. It does not infer complex multiplication or infinite order from
these elementary checks, and is not an instantiation of Theorem 2.
-/

@[expose] public section

namespace Elliptic.Examples

structure Datum where
  kappa : ℚ
  A : ℚ
  B : ℚ
  u : ℚ
  v : ℚ
  j : ℚ

def data : Fin 7 → Datum := ![
  ⟨-1, 0, -2, 2, 2, 1728⟩,
  ⟨-1, 0, -6, 3, 3, 1728⟩,
  ⟨-1, 0, 14, 2, 6, 1728⟩,
  ⟨-2, 4, 2, -2, 2, 8000⟩,
  ⟨-7, -21, 112, 8, 8, -3375⟩,
  ⟨-2, 12, 18, -2, 2, 8000⟩,
  ⟨-7, 42, -7, -7, 42, 16581375⟩]

def discriminantFactor (d : Datum) : ℚ := d.A ^ 2 - 4 * d.B

/-- The translation used for the example with j = -3375. -/
theorem row_four_coordinate_translation (x : ℚ) :
    (x + 7) * ((x + 7) ^ 2 - 21 * (x + 7) + 112) = x ^ 3 - 35 * x + 98 := by
  ring

/-- The translation used for the second Q(sqrt(-2)) example. -/
theorem row_five_coordinate_translation (x : ℚ) :
    (x - 4) * ((x - 4) ^ 2 + 12 * (x - 4) + 18) = x ^ 3 - 30 * x + 56 := by
  ring

/-- Each displayed point lies on the required two-torsion model. -/
theorem point_equation (i : Fin 7) :
    (data i).v ^ 2 = (data i).u *
      ((data i).u ^ 2 + (data i).A * (data i).u + (data i).B) := by
  fin_cases i <;> norm_num [data]

/-- The Weierstrass discriminant `16 B²(A² - 4B)` is nonzero. -/
theorem discriminant_ne_zero (i : Fin 7) :
    16 * (data i).B ^ 2 * discriminantFactor (data i) ≠ 0 := by
  fin_cases i <;> norm_num [data, discriminantFactor]

/-- The claimed numerical j-invariant agrees with the standard formula
for this Weierstrass model. No CM classification is presumed here. -/
theorem j_invariant_formula (i : Fin 7) :
    256 * ((data i).A ^ 2 - 3 * (data i).B) ^ 3 /
      ((data i).B ^ 2 * discriminantFactor (data i)) = (data i).j := by
  fin_cases i <;> norm_num [data, discriminantFactor]

def squareclassParameters (i : Fin 7) : Fin 4 → ℚ :=
  ![(data i).kappa, discriminantFactor (data i), (data i).u, -3]

theorem parameters_ne_zero (i : Fin 7) (j : Fin 4) :
    squareclassParameters i j ≠ 0 := by
  fin_cases i <;> fin_cases j <;>
    norm_num [squareclassParameters, data, discriminantFactor]

def parameterUnits (i : Fin 7) (j : Fin 4) : ℚˣ :=
  Units.mk0 (squareclassParameters i j) (parameters_ne_zero i j)

/-- The exact 16-case relation test, on actual rational numbers rather
than merely claimed squareclass representatives. -/
theorem square_relation_parity (i : Fin 7) (a b c d : ZMod 2)
    (hsq : IsSquare ((data i).kappa ^ a.val *
      discriminantFactor (data i) ^ b.val * (data i).u ^ c.val * (-3 : ℚ) ^ d.val)) :
    a + b + c = 0 := by
  fin_cases i <;> fin_cases a <;> fin_cases b <;> fin_cases c <;> fin_cases d <;>
    norm_num [data, discriminantFactor, ZMod.val] at hsq
  all_goals decide

/-- All seven actual quadruples satisfy the exact squareclass hypothesis
of the manuscript's general theorem. -/
theorem squareclass_compatible (i : Fin 7) :
    SquareclassCompatible (fun j => rationalSquareclass (parameterUnits i j)) := by
  intro e he
  obtain ⟨b, hb⟩ := (rationalSquareclass_combination_eq_zero_iff _ _).mp he
  apply square_relation_parity i (e 0) (e 1) (e 2) (e 3)
  refine ⟨b, ?_⟩
  simpa [parameterUnits, squareclassParameters, pow_two] using hb.symm

/-- Consequently the prescribed signs `-1,-1,-1,+1` extend to an actual
linear character on the rational squareclass group. -/
theorem exists_squareclass_character (i : Fin 7) :
    ∃ χ : RationalSquareclass →ₗ[ZMod 2] ZMod 2,
      χ (rationalSquareclass (parameterUnits i 0)) = 1 ∧
      χ (rationalSquareclass (parameterUnits i 1)) = 1 ∧
      χ (rationalSquareclass (parameterUnits i 2)) = 1 ∧
      χ (rationalSquareclass (parameterUnits i 3)) = 0 :=
  (squareclassCompatible_iff_character _).mp (squareclass_compatible i)

/-- The actual seven parameter quadruples therefore have the required
progressions, including avoidance of any specified finite set of primes. -/
theorem exists_compatible_progression (i : Fin 7)
    (B : Finset ℕ) (hB : ∀ q ∈ B, q.Prime) :
    ∃ M b c : ℕ, 0 < M ∧ (c = 2 ∨ c = 4 ∨ c = 8) ∧
      Nat.Coprime b M ∧ 2 * c ∣ M ∧
      Nat.Coprime ((b + 1) / c) (M / c) ∧ (∀ q ∈ B, q ∣ M) ∧
      ∀ p (hp : p.Prime), 5 ≤ p → Nat.ModEq M p b →
        p % 3 = 1 ∧ padicValNat 2 (p + 1) = padicValNat 2 c ∧
        primeRationalQuadraticSymbol p hp (parameterUnits i 0) = -1 ∧
        primeRationalQuadraticSymbol p hp (parameterUnits i 1) = -1 ∧
        primeRationalQuadraticSymbol p hp (parameterUnits i 2) = -1 ∧
        primeRationalQuadraticSymbol p hp (parameterUnits i 3) = 1 := by
  apply manuscript_progression_lemma (parameterUnits i) _ (squareclass_compatible i) B hB
  apply Units.ext
  rfl

end Elliptic.Examples
