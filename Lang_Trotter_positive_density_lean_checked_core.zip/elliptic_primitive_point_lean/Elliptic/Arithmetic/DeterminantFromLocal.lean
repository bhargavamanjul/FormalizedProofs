module

public import Elliptic.Arithmetic.GeometricFamily
public import Mathlib.NumberTheory.LSeries.PrimesInAP

/-!
# Determinant surjectivity from the existing local Frobenius polynomials

For an odd torsion prime q, Dirichlet's theorem and CRT provide primes
p=3 mod 8 in any unit residue class modulo q. The constant coefficient
of the actual Frobenius polynomial identifies its determinant with p.
Consequently the local polynomial input already implies surjectivity of
the actual determinant character. No Weil pairing is needed for this
deduction, and no extra local theorem is assumed beyond the polynomial
at the eligible primes.
-/

@[expose] public section
noncomputable section

namespace Elliptic.Arithmetic

open Polynomial

/-- Every nonzero torsion residue is attained by arbitrarily large primes
in the actual progression used for the main curve. -/
theorem exists_prime_three_mod_eight_and_unit_residue
    {q : ℕ} [Fact q.Prime] (hq2 : q ≠ 2) (u : (ZMod q)ˣ) (bound : ℕ) :
    ∃ p : ℕ, bound < p ∧ p.Prime ∧ p % 8 = 3 ∧ (p : ZMod q) = u := by
  have hq := (Fact.out : q.Prime)
  have h8q : Nat.Coprime 8 q := by
    simpa using (Nat.coprime_two_left.mpr (hq.odd_of_ne_two hq2)).pow_left 3
  let r := Nat.chineseRemainder h8q 3 (u : ZMod q).val
  have hr8 : (r.val : ZMod 8) = 3 :=
    (ZMod.natCast_eq_natCast_iff _ _ _).2 r.property.1
  have hrq : (r.val : ZMod q) = u := by
    exact ((ZMod.natCast_eq_natCast_iff _ _ _).2 r.property.2).trans
      (ZMod.natCast_zmod_val _)
  have hu8 : IsUnit (3 : ZMod 8) := by
    refine ⟨⟨3, 3, by decide, by decide⟩, rfl⟩
  have hrcoprime : r.val.Coprime (8*q) := by
    apply Nat.Coprime.mul_right
    · exact (ZMod.isUnit_iff_coprime _ _).1 (hr8.symm ▸ hu8)
    · exact (ZMod.isUnit_iff_coprime _ _).1 (hrq.symm ▸ u.isUnit)
  obtain ⟨p, hpbound, hp, hpr⟩ := Nat.forall_exists_prime_gt_and_modEq bound
    (Nat.mul_ne_zero (by decide) hq.ne_zero) hrcoprime
  refine ⟨p, hpbound, hp, ?_, ?_⟩
  · have he := (hpr.of_dvd (dvd_mul_right 8 q)).trans r.property.1
    exact he
  · have he := (hpr.of_dvd (dvd_mul_left q 8)).trans r.property.2
    simpa only [ZMod.natCast_zmod_val] using (ZMod.natCast_eq_natCast_iff _ _ _).2 he

/-- Only the constant coefficient is needed; the trace and reduced point
count are unrestricted in this determinant deduction. -/
theorem determinant_of_elliptic_frobenius_polynomial
    {q p n : ℕ} [Fact q.Prime]
    (f : (ZMod q × ZMod q) →ₗ[ZMod q] (ZMod q × ZMod q))
    (hpoly : f.charpoly = X^2 - C ((p : ZMod q)+1-n)*X + C (p : ZMod q)) :
    LinearMap.det f = (p : ZMod q) := by
  have hdim : Module.finrank (ZMod q) (ZMod q × ZMod q) = 2 := by simp
  rw [LinearMap.det_eq_sign_charpoly_coeff, hdim, hpoly]
  simp

/-- Actual local polynomials on the progression imply the actual
determinant character is onto. A fixed finite lower cutoff is harmless. -/
theorem GeometricDivisionField.character_surjective_of_progression_polynomials
    {W : WeierstrassCurve ℚ} {P : CurvePoints W ℚ}
    {q : ℕ} [Fact q.Prime] (D : GeometricDivisionField W P q)
    (hq2 : q ≠ 2) (bound : ℕ)
    (hlocal : ∀ p : ℕ, bound < p → p.Prime → p % 8 = 3 →
      ∃ (g : Gal(D.ambient/ℚ)) (n : ℕ),
        (D.affine g).linear.toLinearMap.charpoly =
          X^2 - C ((p : ZMod q)+1-n)*X + C (p : ZMod q)) :
    Function.Surjective D.character := by
  intro u
  obtain ⟨p, hpb, hp, hp8, hpu⟩ :=
    exists_prime_three_mod_eight_and_unit_residue hq2 u bound
  obtain ⟨g, n, hpoly⟩ := hlocal p hpb hp hp8
  refine ⟨g, Units.ext ?_⟩
  have hd := determinant_of_elliptic_frobenius_polynomial
    (D.affine g).linear.toLinearMap hpoly
  simpa [GeometricDivisionField.character, coordinateDeterminantCharacter,
    GeometricDivisionField.affine] using hd.trans hpu

end Elliptic.Arithmetic
