module

public import Elliptic.Arithmetic.ReductionExceptional
public import Elliptic.MainCurveConclusion

/-!
# Actual reduction proves denominator divisibility

We follow the actual rational multiples of `P=(2,2)` until the first
multiple that is zero modulo `p`. Every intermediate addition has unit
slope denominator, apart from the separately computed doubling. The last
addition is covered by the denominator-forcing lemma. No reduction
homomorphism or denominator-divisibility assertion is a hypothesis.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic

variable (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)

theorem finiteReduces_nsmul_before_order {n : ℕ} (hn : 0 < n)
    (hlt : n < addOrderOf (reductionPoint p hp2)) :
    FiniteReduces p hp2 (n • examplePoint) (n • reductionPoint p hp2) := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    by_cases h1 : n = 1
    · subst n
      simpa using finiteReduces_point p hp2
    by_cases h2 : n = 2
    · subst n
      exact finiteReduces_double p hp2
    have hn3 : 3 ≤ n := by omega
    have hm0 : 0 < n - 1 := by omega
    have hm : n - 1 < n := by omega
    have hmlt : n - 1 < addOrderOf (reductionPoint p hp2) := by omega
    have hr1 : 1 < addOrderOf (reductionPoint p hp2) := by omega
    have hred := ih (n - 1) hm hm0 hmlt
    have hplus : (n - 1) • reductionPoint p hp2 ≠ reductionPoint p hp2 := by
      intro he
      have heq : n - 1 = 1 := nsmul_injOn_Iio_addOrderOf hmlt hr1 (by simpa using he)
      omega
    have hminus : (n - 1) • reductionPoint p hp2 ≠ -reductionPoint p hp2 := by
      intro he
      have hz : n • reductionPoint p hp2 = 0 := by
        rw [← Nat.sub_add_cancel (by omega : 1 ≤ n), add_nsmul, one_nsmul, he]
        simp
      exact (nsmul_ne_zero_of_lt_addOrderOf (by omega : n ≠ 0) hlt) hz
    have hout := finiteReduces_add_point p hp2 hred hplus hminus
    simpa only [← succ_nsmul, Nat.sub_add_cancel (by omega : 1 ≤ n)] using hout

/-- Every odd prime divides the actual rational denominator sequence
evaluated at the order of the reduced point. -/
theorem prime_dvd_example_denominator_at_reduction_order :
    p ∣ exampleMultipleDenominator (addOrderOf (reductionPoint p hp2)) := by
  let r := addOrderOf (reductionPoint p hp2)
  have hr0 : 0 < r := addOrderOf_pos _
  have hr1 : 1 < r := by
    have hne : r ≠ 1 := by
      intro he
      exact reductionPoint_ne_zero p hp2 ((AddMonoid.addOrderOf_eq_one_iff).mp he)
    omega
  have hred := finiteReduces_nsmul_before_order p hp2
    (n := r - 1) (by omega) (by dsimp [r]; omega)
  have he : (r - 1) • reductionPoint p hp2 = -reductionPoint p hp2 := by
    apply eq_neg_iff_add_eq_zero.mpr
    rw [← succ_nsmul,
      Nat.sub_add_cancel (by omega : 1 ≤ r)]
    exact addOrderOf_nsmul_eq_zero _
  rw [he] at hred
  have hR : (r - 1) • examplePoint ≠ -examplePoint := by
    intro heq
    apply exampleMultiple_ne_zero hr0
    rw [← Nat.sub_add_cancel (by omega : 1 ≤ r), add_nsmul, one_nsmul, heq]
    simp
  have hout := denominator_add_point_of_reduces_neg p hp2 hred hR
  rw [← succ_nsmul,
    Nat.sub_add_cancel (by omega : 1 ≤ r)] at hout
  exact hout

/-- The previously exposed reduction-denominator obligation is proved for
the actual main-curve family. It is no longer an arithmetic input. -/
theorem mainReductionDenominator : MainReductionDenominatorObligation := by
  intro p hp helig
  let : Fact p.Prime := ⟨hp⟩
  have hp2 : p ≠ 2 := by unfold mainEligible at helig; omega
  have hord := (mainCurveGroupEquiv p hp2).addOrderOf_eq (mainCurvePoint p)
  rw [mainCurveGroupEquiv_point] at hord
  change p ∣ exampleMultipleDenominator (addOrderOf (mainCurvePoint p))
  rw [← hord]
  exact prime_dvd_example_denominator_at_reduction_order p hp2

end Elliptic
