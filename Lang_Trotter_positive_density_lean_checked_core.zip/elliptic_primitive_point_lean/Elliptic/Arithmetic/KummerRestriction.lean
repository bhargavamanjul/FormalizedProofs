module

public import Elliptic.Arithmetic.DivisionTorsor
public import Elliptic.Arithmetic.GeometricFamily
public import Mathlib.FieldTheory.Normal.Basic

/-!
# Descending full Kummer translations from an auxiliary base field

Let F lie in both K and L, and embed K and L into M. When L/F is normal,
an automorphism of M fixing K restricts to an automorphism of L fixing F.
We prove the compatibility of this restriction with the actual elliptic
coordinate action, then descend full translations on a division fiber.

There is no hypothesis K <= L and no assumed surjectivity of restriction.
For the CM application one takes F=Q and K=Q(i); the translation assertion
over K is the classical Ribet input. This file proves its restriction
step, not Ribet's theorem or the CM hypotheses of that theorem.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Arithmetic

open WeierstrassCurve

variable {F K L M : Type*}
variable [Field F] [Field K] [Field L] [Field M]
variable [Algebra F K] [Algebra F L] [Algebra F M]
variable [Algebra K M] [Algebra L M]
variable [IsScalarTower F K M] [IsScalarTower F L M]
variable [Normal F L]
variable [DecidableEq L] [DecidableEq M]

/-- Restriction along two towers, without requiring K to be a subfield of L. -/
def normalRestrictionFromBase (σ : Gal(M/K)) : Gal(L/F) :=
  (σ.restrictScalars F).restrictNormal L

omit [DecidableEq L] [DecidableEq M] in
@[simp] theorem normalRestrictionFromBase_commutes (σ : Gal(M/K)) (x : L) :
    algebraMap L M (normalRestrictionFromBase (F:=F) (L:=L) σ x) =
      σ (algebraMap L M x) :=
  AlgEquiv.restrictNormal_commutes (σ.restrictScalars F) L x

/-- The coordinate inclusion commutes with the genuinely restricted
Galois action; no equivariance premise is supplied. -/
theorem normalRestrictionFromBase_point (W : WeierstrassCurve F)
    (σ : Gal(M/K)) (T : CurvePoints W L) :
    Affine.Point.baseChange L M
      (pointGaloisMap W (normalRestrictionFromBase (F:=F) (L:=L) σ) T) =
      pointGaloisMap W (σ.restrictScalars F) (Affine.Point.baseChange L M T) := by
  cases T with
  | zero => rfl
  | some x y h =>
      simp only [pointGaloisMap, Affine.Point.baseChange, Affine.Point.map_some,
        Affine.Point.some.injEq]
      exact ⟨normalRestrictionFromBase_commutes σ x,
        normalRestrictionFromBase_commutes σ y⟩

/-- The natural inclusion of actual torsion into the larger ambient field. -/
def torsionTowerBaseChange (W : WeierstrassCurve F) (q : ℕ) :
    curveTorsion W L q → curveTorsion W M q :=
  fun T => ⟨Affine.Point.baseChange L M T.val, by
    rw [mem_curveTorsion, ← map_nsmul, T.property, map_zero]⟩

omit [Normal F L] in
theorem torsionTowerBaseChange_injective (W : WeierstrassCurve F) (q : ℕ) :
    Function.Injective (torsionTowerBaseChange (M:=M) W q (L:=L)) := by
  intro T U h
  apply Subtype.ext
  exact Affine.Point.map_injective (Algebra.ofId L M) (congrArg Subtype.val h)

/-- A torsion-fixing automorphism over K restricts to an automorphism
fixing every actual torsion point over L. -/
def restrictTorsionFixing (W : WeierstrassCurve F) (q : ℕ)
    (σ : Gal(M/K))
    (hσ : ∀ T : curveTorsion W M q,
      pointGaloisMap W (σ.restrictScalars F) T.val = T.val) :
    torsionFixingSubgroup W q (L:=L) := by
  refine ⟨normalRestrictionFromBase (F:=F) (L:=L) σ, ?_⟩
  intro T
  apply Affine.Point.map_injective (Algebra.ofId L M)
  rw [normalRestrictionFromBase_point]
  exact hσ (torsionTowerBaseChange (M:=M) W q T)

/-- The standard full-translation conclusion over the auxiliary base K,
written on the actual geometric torsion and one actual division point.
For a CM curve this is supplied by Ribet after checking his hypotheses.
It asserts neither surjectivity of restriction nor the desired conclusion
on Gal(L/F). -/
def AuxiliaryKummerTranslations (W : WeierstrassCurve F) (q : ℕ)
    (R : CurvePoints W M) : Prop :=
  ∀ T : curveTorsion W M q, ∃ σ : Gal(M/K),
    (∀ U : curveTorsion W M q,
      pointGaloisMap W (σ.restrictScalars F) U.val = U.val) ∧
    pointGaloisMap W (σ.restrictScalars F) R - R = T.val

/-- The auxiliary translation assertion does not depend on which division
point is chosen in the same fiber. This connects a classical chosen
origin to the independently chosen origin in the constructed field. -/
theorem AuxiliaryKummerTranslations.change_origin
    (W : WeierstrassCurve F) (q : ℕ) (R S : CurvePoints W M)
    (hdiv : q • R = q • S)
    (hK : AuxiliaryKummerTranslations (K:=K) W q R) :
    AuxiliaryKummerTranslations (K:=K) W q S := by
  intro T
  obtain ⟨σ, hσ, hR⟩ := hK T
  refine ⟨σ, hσ, ?_⟩
  let U : curveTorsion W M q := ⟨S - R, by
    rw [mem_curveTorsion, nsmul_sub, hdiv, sub_self]⟩
  have hfix := hσ U
  change pointGaloisMap W (σ.restrictScalars F) (S - R) = S - R at hfix
  rw [map_sub] at hfix
  calc
    pointGaloisMap W (σ.restrictScalars F) S - S =
        (pointGaloisMap W (σ.restrictScalars F) R - R) +
          ((pointGaloisMap W (σ.restrictScalars F) S -
            pointGaloisMap W (σ.restrictScalars F) R) - (S - R)) := by abel
    _ = T.val := by rw [hfix, sub_self, add_zero, hR]

/-- Full translations over K imply surjectivity of the genuine Kummer
map over F on the normal field L. The only translation input is upstairs;
equivariance and torsion-fixing after restriction are proved above. -/
theorem kummerMap_surjective_of_auxiliary_translations
    (W : WeierstrassCurve F) (q : ℕ) (P : CurvePoints W L)
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (hK : AuxiliaryKummerTranslations (K:=K) W q
      (Affine.Point.baseChange L M R.val)) :
    Function.Surjective (kummerMap W q P hP R) := by
  intro T
  obtain ⟨σ, hσ, hR⟩ := hK (torsionTowerBaseChange (M:=M) W q T)
  refine ⟨restrictTorsionFixing W q σ hσ, ?_⟩
  apply Subtype.ext
  apply Affine.Point.map_injective (Algebra.ofId L M)
  change Affine.Point.baseChange L M
    (pointGaloisMap W (normalRestrictionFromBase (F:=F) (L:=L) σ) R.val - R.val) =
      Affine.Point.baseChange L M T.val
  rw [map_sub, normalRestrictionFromBase_point]
  exact hR

/-- A classical origin in M may be used without first identifying it with
the constructed field's chosen division point. Equality of its q-multiple
is enough, and the origin change is proved rather than assumed. -/
theorem kummerMap_surjective_of_auxiliary_fiber
    (W : WeierstrassCurve F) (q : ℕ) (P : CurvePoints W L)
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (S : CurvePoints W M) (hS : q • S = Affine.Point.baseChange L M P)
    (hK : AuxiliaryKummerTranslations (K:=K) W q S) :
    Function.Surjective (kummerMap W q P hP R) := by
  apply kummerMap_surjective_of_auxiliary_translations (K:=K) (M:=M) W q P hP R
  apply AuxiliaryKummerTranslations.change_origin W q S _ ?_ hK
  rw [← map_nsmul, R.property, hS]

section Rational
variable {W : WeierstrassCurve ℚ} {P : CurvePoints W ℚ}
variable {q : ℕ} [Fact q.Prime]

/-- Application to the actual geometric field interface consumed by the
main theorem. The supplied source input concerns translations over K;
the required field-specific Kummer surjectivity is the conclusion. -/
theorem GeometricDivisionField.kummer_surjective_of_auxiliary_fiber
    (D : GeometricDivisionField W P q)
    {K M : Type*} [Field K] [Field M]
    [Algebra ℚ K] [Algebra ℚ M] [Algebra K M]
    [IsScalarTower ℚ K M]
    [Algebra D.ambient M] [IsScalarTower ℚ D.ambient M] [DecidableEq M]
    (S : CurvePoints W M)
    (hS : q • S = Affine.Point.baseChange D.ambient M D.point)
    (hK : AuxiliaryKummerTranslations (K:=K) W q S) :
    Function.Surjective D.kummer :=
  kummerMap_surjective_of_auxiliary_fiber W q D.point
    (rationalPoint_galois_fixed W P) D.divisionPoint S hS hK

end Rational

end Elliptic.Arithmetic
