module

public import Elliptic.Arithmetic.DivisionTorsor
public import Elliptic.Arithmetic.FiniteFieldIndex
public import Elliptic.FrobeniusNormalForm
public import Mathlib.LinearAlgebra.Charpoly.ToMatrix
public import Mathlib.LinearAlgebra.Charpoly.BaseChange
public import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
public import Mathlib.FieldTheory.Perfect

/-!
# Deductions from the classical elliptic Frobenius polynomial

Trace zero and determinant minus one are deduced from the usual Frobenius
polynomial and the already determined point count. The local fixed-point
step is then separated into a proved finite-group deduction and the
geometric specialization of the actual q-division fiber.
-/

@[expose] public section
noncomputable section

namespace Elliptic.Arithmetic

open Polynomial

/-- The coefficient form of the standard elliptic Frobenius polynomial
implies the trace and determinant required by the affine normal form. -/
theorem trace_det_of_elliptic_frobenius_polynomial
    {q p n : ℕ} [Fact q.Prime]
    (f : (ZMod q × ZMod q) →ₗ[ZMod q] (ZMod q × ZMod q))
    (hpoly : f.charpoly = X ^ 2 - C ((p : ZMod q) + 1 - n) * X + C (p : ZMod q))
    (hcard : n = p + 1) (hq : q ∣ p + 1) :
    LinearMap.trace (ZMod q) (ZMod q × ZMod q) f = 0 ∧ LinearMap.det f = -1 := by
  have hdim : Module.finrank (ZMod q) (ZMod q × ZMod q) = 2 := by simp
  have hpoly' : f.charpoly = X ^ 2 + C (p : ZMod q) := by
    simpa only [hcard, Nat.cast_add, Nat.cast_one, sub_self, map_zero, zero_mul,
      sub_zero] using hpoly
  have hp : (p : ZMod q) = -1 := by
    have hzero : ((p + 1 : ℕ) : ZMod q) = 0 := (ZMod.natCast_eq_zero_iff _ _).2 hq
    simpa only [Nat.cast_add, Nat.cast_one, add_eq_zero_iff_eq_neg] using hzero
  constructor
  · let b := Module.Free.chooseBasis (ZMod q) (ZMod q × ZMod q)
    have hnonempty : Nonempty (Module.Free.ChooseBasisIndex (ZMod q) (ZMod q × ZMod q)) := by
      apply Fintype.card_pos_iff.mp
      rw [← Module.finrank_eq_card_chooseBasisIndex, hdim]
      norm_num
    let := hnonempty
    rw [LinearMap.trace_eq_matrix_trace (ZMod q) b, Matrix.trace_eq_neg_charpoly_coeff,
      LinearMap.charpoly_toMatrix, ← Module.finrank_eq_card_chooseBasisIndex, hdim,
      hpoly']
    norm_num
  · rw [LinearMap.det_eq_sign_charpoly_coeff, hdim, hpoly']
    simpa using hp

variable {F L k K : Type*} [Field F] [Field L] [Algebra F L] [DecidableEq L]
    [Field k] [Field K] [Algebra k K] [DecidableEq k] [DecidableEq K]

/-- A geometric specialization map on the complete actual division fiber,
commuting with Frobenius. This is the precise classical prime-to-residue-
characteristic good-reduction input used below. It contains no existence
of fixed points and no prime-count conclusion. -/
structure DivisionSpecialization
    (W : WeierstrassCurve F) (V : WeierstrassCurve k) (q : ℕ)
    (P : CurvePoints W L) (Q : CurvePoints V k)
    (σ : Gal(L/F)) (φ : Gal(K/k)) where
  specialization : DivisionFiber W q P ≃
    DivisionFiber V q (WeierstrassCurve.Affine.Point.baseChange k K Q)
  equivariant : ∀ (R : DivisionFiber W q P) (S : DivisionFiber W q P),
    pointGaloisMap W σ R.1 = S.1 →
      pointGaloisMap V φ (specialization R).1 = (specialization S).1

/-- A rational division point in the reduced group lifts to a fixed point
of the original Frobenius action, by the specialization bijection. -/
theorem division_fixed_of_rational_division
    (W : WeierstrassCurve F) (V : WeierstrassCurve k) (q : ℕ)
    (P : CurvePoints W L) (Q : CurvePoints V k)
    (σ : Gal(L/F)) (φ : Gal(K/k))
    (hP : pointGaloisMap W σ P = P)
    (s : DivisionSpecialization W V q P Q σ φ)
    (hdivision : ∃ U : CurvePoints V k, q • U = Q) :
    ∃ R : DivisionFiber W q P, pointGaloisMap W σ R.1 = R.1 := by
  obtain ⟨U, hU⟩ := hdivision
  let U' : DivisionFiber V q (WeierstrassCurve.Affine.Point.baseChange k K Q) :=
    ⟨WeierstrassCurve.Affine.Point.baseChange k K U, by rw [← map_nsmul, hU]⟩
  let R := s.specialization.symm U'
  let S : DivisionFiber W q P := ⟨pointGaloisMap W σ R.1, by
    rw [← map_nsmul, R.property, hP]⟩
  have hS := s.equivariant R S rfl
  have hRU : s.specialization R = U' := s.specialization.apply_symm_apply U'
  rw [hRU] at hS
  change pointGaloisMap V φ
    (WeierstrassCurve.Affine.Point.baseChange k K U) = (s.specialization S).1 at hS
  rw [rationalPoint_galois_fixed] at hS
  have hRS : R = S := s.specialization.injective (by
    apply Subtype.ext
    exact (congrArg Subtype.val hRU).trans hS)
  exact ⟨R, congrArg Subtype.val hRS.symm⟩

/-- The local affine fixed point is now a consequence of a prime dividing
the actual point index, the rational torsion count, and classical geometric
specialization. It is not assumed as an affine condition. -/
theorem coordinate_fixed_of_index_divisibility
    (W : WeierstrassCurve F) (V : WeierstrassCurve k) (q : ℕ)
    (P : CurvePoints W L) (Q : CurvePoints V k)
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    [Finite (CurvePoints V k)] (σ : Gal(L/F)) (φ : Gal(K/k))
    (s : DivisionSpecialization W V q P Q σ φ)
    (hq : q.Prime)
    (hcard : Nat.card {T : CurvePoints V k // q • T = 0} = q)
    (hindex : q ∣ pointIndex Q) :
    ∃ v, coordinateDivisionRepresentation W q P hP R e σ v = v := by
  apply (coordinate_fixed_iff_division_point_fixed W q P hP R e σ).2
  apply division_fixed_of_rational_division W V q P Q σ φ (hP σ) s
  exact (prime_dvd_pointIndex_iff_divisible Q hq hcard).1 hindex

/-- Specialization transports the entire fixed-point set, with no
cardinality or existence assumption about that set. -/
def DivisionSpecialization.fixedEquiv
    {W : WeierstrassCurve F} {V : WeierstrassCurve k} {q : ℕ}
    {P : CurvePoints W L} {Q : CurvePoints V k}
    {σ : Gal(L/F)} {φ : Gal(K/k)}
    (s : DivisionSpecialization W V q P Q σ φ)
    (hP : pointGaloisMap W σ P = P) :
    {R : DivisionFiber W q P // pointGaloisMap W σ R.1 = R.1} ≃
      {R : DivisionFiber V q (WeierstrassCurve.Affine.Point.baseChange k K Q) //
        pointGaloisMap V φ R.1 = R.1} :=
  Equiv.ofBijective
    (fun R => ⟨s.specialization R.1, s.equivariant R.1 R.1 R.2⟩) (by
      constructor
      · intro R S h
        apply Subtype.ext
        exact s.specialization.injective (congrArg Subtype.val h)
      · intro U
        let R := s.specialization.symm U.1
        let S : DivisionFiber W q P := ⟨pointGaloisMap W σ R.1, by
          rw [← map_nsmul, R.property, hP]⟩
        have hRS : R = S := by
          apply s.specialization.injective
          apply Subtype.ext
          have hs := s.equivariant R S rfl
          have hRU : s.specialization R = U.1 := s.specialization.apply_symm_apply U.1
          rw [hRU, U.2] at hs
          exact (congrArg Subtype.val hRU).trans hs
        refine ⟨⟨R, congrArg Subtype.val hRS.symm⟩, ?_⟩
        apply Subtype.ext
        exact s.specialization.apply_symm_apply U.1)

/-- The linear part of the constructed affine representation is the
coordinate action on actual elliptic q-torsion. -/
theorem coordinateLinear_apply
    (W : WeierstrassCurve F) (q : ℕ) (P : CurvePoints W L)
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (σ : Gal(L/F)) (T : curveTorsion W L q) :
    (coordinateDivisionRepresentation W q P hP R e σ).linear (e T) =
      e (torsionGaloisLinearEquiv W q σ T) := by
  change e (torsionGaloisLinearEquiv W q σ (e.symm (e T))) = _
  rw [e.symm_apply_apply]

/-- Trace zero and determinant minus one give exactly q Frobenius-fixed
points in the actual geometric q-torsion group. -/
theorem fixed_torsion_card_of_trace_det
    (W : WeierstrassCurve F) (q : ℕ) [Fact q.Prime] (P : CurvePoints W L)
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (σ : Gal(L/F)) (h2 : (2 : ZMod q) ≠ 0)
    (htrace : LinearMap.trace (ZMod q) (ZMod q × ZMod q)
      (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = 0)
    (hdet : LinearMap.det
      (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = -1) :
    Nat.card {T : curveTorsion W L q // pointGaloisMap W σ T.1 = T.1} = q := by
  classical
  let f := (coordinateDivisionRepresentation W q P hP R e σ).linear
  let t := torsionGaloisLinearEquiv W q σ
  let : Fintype (curveTorsion W L q) := Fintype.ofEquiv _ e.symm.toEquiv
  obtain ⟨c, b₁, b₂, hc⟩ := exists_affine_normal_form f.toAffineEquiv h2 htrace hdet
  have hconj : ∀ T, (e.toEquiv.trans c.toEquiv) (t T) =
      affineNormalForm b₁ b₂ ((e.toEquiv.trans c.toEquiv) T) := by
    intro T
    change c (e (t T)) = affineNormalForm b₁ b₂ (c (e T))
    rw [← coordinateLinear_apply W q P hP R e σ T]
    exact hc (e T)
  have hcount := card_fixedPoints_of_affineConjugacy_of_exists
    (e.toEquiv.trans c.toEquiv) t b₁ b₂ h2 hconj ⟨0, map_zero t⟩
  have hpred : ∀ T : curveTorsion W L q,
      pointGaloisMap W σ T.1 = T.1 ↔ t T = T := by
    intro T
    exact ⟨fun h => Subtype.ext h, fun h => congrArg Subtype.val h⟩
  calc
    _ = Nat.card {T : curveTorsion W L q // t T = T} :=
      Nat.card_congr (Equiv.subtypeEquivRight hpred)
    _ = q := by simpa only [Nat.card_eq_fintype_card, ZMod.card] using hcount

/-- The rational q-torsion count is a consequence of geometric
specialization, Frobenius fixed-field descent, and the proved normal form.
The standard finite-field elliptic group classification is not used. -/
theorem rational_torsion_card_of_specialization
    (W : WeierstrassCurve F) (V : WeierstrassCurve k) (q : ℕ) [Fact q.Prime]
    (P : CurvePoints W L) (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (σ : Gal(L/F)) (φ : Gal(K/k))
    (s : DivisionSpecialization W V q 0 0 σ φ)
    (hfield : ∀ x : K, φ x = x → ∃ a : k, algebraMap k K a = x)
    (h2 : (2 : ZMod q) ≠ 0)
    (htrace : LinearMap.trace (ZMod q) (ZMod q × ZMod q)
      (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = 0)
    (hdet : LinearMap.det
      (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = -1) :
    Nat.card {T : CurvePoints V k // q • T = 0} = q := by
  let e₀ := s.fixedEquiv (map_zero (pointGaloisMap W σ))
  have h0 : (WeierstrassCurve.Affine.Point.baseChange k K (0 : CurvePoints V k)) = 0 :=
    map_zero _
  have hcard := Nat.card_congr e₀
  have hdesc := Nat.card_congr (rationalTorsionFixedEquiv V q φ hfield)
  have hgeom := fixed_torsion_card_of_trace_det W q P hP R e σ h2 htrace hdet
  change Nat.card (curveTorsion V k q) = q
  rw [hdesc]
  change Nat.card {T : DivisionFiber V q 0 // pointGaloisMap V φ T.1 = T.1} = q
  rw [← h0, ← hcard]
  exact hgeom

section PrimeFieldFrobenius

variable (p : ℕ) [Fact p.Prime] (K : Type*) [Field K] [CharP K p]
    [PerfectRing K p] [Algebra (ZMod p) K]

/-- The actual p-power arithmetic Frobenius over the prime field. -/
def primeFieldFrobenius : Gal(K/ZMod p) where
  __ := frobeniusEquiv K p
  commutes' a := by
    change (algebraMap (ZMod p) K a) ^ p = algebraMap (ZMod p) K a
    rw [← map_pow]
    congr 1
    simpa only [ZMod.card] using FiniteField.pow_card a

@[simp]
theorem primeFieldFrobenius_apply (x : K) : primeFieldFrobenius p K x = x ^ p := rfl

/-- Descent of Frobenius-fixed field elements to F_p is proved from
mathlib's characterization of the prime subfield. -/
theorem primeFieldFrobenius_fixed_descends (x : K)
    (hx : primeFieldFrobenius p K x = x) :
    ∃ a : ZMod p, algebraMap (ZMod p) K a = x := by
  have hbot : x ∈ (⊥ : Subfield K) := (Subfield.mem_bot_iff_pow_eq_self K p).2 hx
  obtain ⟨n, hn⟩ := (mem_bot_iff_intCast p K).1 hbot
  refine ⟨(n : ZMod p), ?_⟩
  simpa only [map_intCast] using hn

end PrimeFieldFrobenius

/-- Complete local deduction from the standard Frobenius polynomial and
prime-to-p specialization of the actual torsion and division fibers.
Trace, determinant, rational torsion count and the affine fixed point are
all proved consequences. The point-index divisibility is the original
bad-prime condition being tested, not an additional counting assumption. -/
theorem frobenius_conditions_of_geometry
    (p q : ℕ) [Fact p.Prime] [Fact q.Prime]
    (W : WeierstrassCurve F) (V : WeierstrassCurve (ZMod p))
    (P : CurvePoints W L) (Q : CurvePoints V (ZMod p))
    (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)
    (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    [Finite (CurvePoints V (ZMod p))]
    (K : Type*) [Field K] [CharP K p] [PerfectRing K p]
    [Algebra (ZMod p) K] [DecidableEq K]
    (σ : Gal(L/F))
    (sT : DivisionSpecialization W V q 0 0 σ (primeFieldFrobenius p K))
    (sP : DivisionSpecialization W V q P Q σ (primeFieldFrobenius p K))
    (h2 : (2 : ZMod q) ≠ 0)
    (hpoly : (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap.charpoly =
      X ^ 2 - C ((p : ZMod q) + 1 - Nat.card (CurvePoints V (ZMod p))) * X + C (p : ZMod q))
    (hpointcount : Nat.card (CurvePoints V (ZMod p)) = p + 1)
    (hindex : q ∣ pointIndex Q) :
    coordinateDeterminantCharacter W q P hP R e σ = -1 ∧
    LinearMap.trace (ZMod q) (ZMod q × ZMod q)
      (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = 0 ∧
    LinearMap.det (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap = -1 ∧
    ∃ v, coordinateDivisionRepresentation W q P hP R e σ v = v := by
  have hqcard : q ∣ Nat.card (CurvePoints V (ZMod p)) :=
    hindex.trans (AddSubgroup.zmultiples Q).index_dvd_card
  rw [hpointcount] at hqcard
  obtain ⟨htrace, hdet⟩ := trace_det_of_elliptic_frobenius_polynomial
    (coordinateDivisionRepresentation W q P hP R e σ).linear.toLinearMap
    hpoly hpointcount hqcard
  have htorsion := rational_torsion_card_of_specialization W V q P hP R e
    σ (primeFieldFrobenius p K) sT (primeFieldFrobenius_fixed_descends p K)
    h2 htrace hdet
  refine ⟨?_, htrace, hdet, ?_⟩
  · apply Units.ext
    simpa [coordinateDeterminantCharacter] using hdet
  · exact coordinate_fixed_of_index_divisibility W V q P Q hP R e
      σ (primeFieldFrobenius p K) sP (Fact.out : q.Prime) htorsion hindex

end Elliptic.Arithmetic
