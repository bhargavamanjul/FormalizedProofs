module

public import Elliptic.DivisionAction
public import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
public import Mathlib.Algebra.Module.ZMod
public import Mathlib.LinearAlgebra.Determinant

/-!
# The actual elliptic division torsor and its affine Galois action

The objects in this file are the nonsingular points on an actual
Weierstrass curve after field extension. The Galois action is the map on
coordinates supplied by mathlib. We construct its restriction to q-torsion
and, after choosing a q-division point, the corresponding affine action.

Existence of all q-torsion and of a division point, and the rank-two torsion
theorem, are not asserted. They are classical geometric inputs to any
specialization; the affine representation itself is a deduction.
-/

@[expose] public section
noncomputable section

namespace Elliptic.Arithmetic

open WeierstrassCurve

variable {F L : Type*} [Field F] [Field L] [Algebra F L] [DecidableEq L]

abbrev CurvePoints (W : WeierstrassCurve F) (L : Type*) [Field L] [Algebra F L] :=
  (W.toAffine.baseChange L).Point

/-- The actual map on elliptic points induced by a Galois automorphism. -/
abbrev pointGaloisMap (W : WeierstrassCurve F) (σ : Gal(L/F)) :
    CurvePoints W L →+ CurvePoints W L :=
  WeierstrassCurve.Affine.Point.map σ.toAlgHom

@[simp]
theorem pointGaloisMap_one (W : WeierstrassCurve F) (P : CurvePoints W L) :
    pointGaloisMap W (1 : Gal(L/F)) P = P := by
  exact WeierstrassCurve.Affine.Point.map_id P

@[simp]
theorem pointGaloisMap_mul (W : WeierstrassCurve F) (σ τ : Gal(L/F))
    (P : CurvePoints W L) :
    pointGaloisMap W (σ * τ) P = pointGaloisMap W σ (pointGaloisMap W τ P) := by
  exact (WeierstrassCurve.Affine.Point.map_map τ.toAlgHom σ.toAlgHom P).symm

/-- The actual q-torsion subgroup, not an abstract two-dimensional model. -/
def curveTorsion (W : WeierstrassCurve F) (L : Type*) [Field L] [Algebra F L] [DecidableEq L]
    (q : ℕ) : AddSubgroup (CurvePoints W L) where
  carrier := {T | q • T = 0}
  zero_mem' := nsmul_zero q
  add_mem' := by intro T U hT hU; simp_all only [Set.mem_ofPred_eq, nsmul_add, add_zero]
  neg_mem' := by intro T hT; simp_all only [Set.mem_ofPred_eq, smul_neg, neg_zero]

@[simp]
theorem mem_curveTorsion (W : WeierstrassCurve F) (q : ℕ) (T : CurvePoints W L) :
    T ∈ curveTorsion W L q ↔ q • T = 0 := Iff.rfl

instance curveTorsionModule (W : WeierstrassCurve F) (q : ℕ) :
    Module (ZMod q) (curveTorsion W L q) :=
  AddCommGroup.zmodModule (fun T => by apply Subtype.ext; exact T.property)

/-- Restriction of the actual coordinate action to q-torsion. -/
def torsionGaloisEquiv (W : WeierstrassCurve F) (q : ℕ) (σ : Gal(L/F)) :
    curveTorsion W L q ≃+ curveTorsion W L q where
  toFun T := ⟨pointGaloisMap W σ T, by
    rw [mem_curveTorsion, ← map_nsmul, T.property, map_zero]⟩
  invFun T := ⟨pointGaloisMap W σ⁻¹ T, by
    rw [mem_curveTorsion, ← map_nsmul, T.property, map_zero]⟩
  left_inv T := by
    apply Subtype.ext
    change pointGaloisMap W σ⁻¹ (pointGaloisMap W σ T) = T
    rw [← pointGaloisMap_mul, inv_mul_cancel, pointGaloisMap_one]
  right_inv T := by
    apply Subtype.ext
    change pointGaloisMap W σ (pointGaloisMap W σ⁻¹ T) = T
    rw [← pointGaloisMap_mul, mul_inv_cancel, pointGaloisMap_one]
  map_add' T U := by apply Subtype.ext; exact map_add (pointGaloisMap W σ) (T : CurvePoints W L) (U : CurvePoints W L)

/-- Linearity over the prime residue ring follows from additivity; it is
not part of the Galois representation input. -/
def torsionGaloisLinearEquiv (W : WeierstrassCurve F) (q : ℕ) (σ : Gal(L/F)) :
    curveTorsion W L q ≃ₗ[ZMod q] curveTorsion W L q :=
  { torsionGaloisEquiv W q σ with map_smul' := ZMod.map_smul (torsionGaloisEquiv W q σ) }

variable (W : WeierstrassCurve F) (q : ℕ) (P : CurvePoints W L)

/-- The actual q-division fiber above the specified elliptic point. -/
abbrev DivisionFiber := {R : CurvePoints W L // q • R = P}

/-- Coordinates on a nonempty division fiber by translation from one
chosen division point. -/
def torsionDivisionEquiv (R : DivisionFiber W q P) :
    curveTorsion W L q ≃ DivisionFiber W q P where
  toFun T := ⟨T.1 + R.1, by rw [nsmul_add, T.property, R.property, zero_add]⟩
  invFun S := ⟨S.1 - R.1, by rw [mem_curveTorsion, nsmul_sub, S.property, R.property, sub_self]⟩
  left_inv T := by apply Subtype.ext; exact add_sub_cancel_right T.1 R.1
  right_inv S := by apply Subtype.ext; exact sub_add_cancel S.1 R.1

variable (hP : ∀ σ : Gal(L/F), pointGaloisMap W σ P = P)

/-- The Kummer cocycle computed from an actual elliptic division point. -/
def divisionCocycle (R : DivisionFiber W q P) (σ : Gal(L/F)) :
    curveTorsion W L q :=
  ⟨pointGaloisMap W σ R.1 - R.1, by
    rw [mem_curveTorsion, nsmul_sub, ← map_nsmul, R.property, hP σ, sub_self]⟩

/-- The affine action on the actual torsion group, constructed from the
coordinate Galois action and the actual division point. -/
def divisionAffineEquiv (R : DivisionFiber W q P) (σ : Gal(L/F)) :
    curveTorsion W L q ≃ᵃ[ZMod q] curveTorsion W L q :=
  (torsionGaloisLinearEquiv W q σ).toAffineEquiv.trans
    (AffineEquiv.constVAdd (ZMod q) (curveTorsion W L q) (divisionCocycle W q P hP R σ))

@[simp]
theorem divisionAffineEquiv_coe (R : DivisionFiber W q P) (σ : Gal(L/F))
    (T : curveTorsion W L q) :
    (divisionAffineEquiv W q P hP R σ T : CurvePoints W L) =
      pointGaloisMap W σ (T.1 + R.1) - R.1 := by
  change (pointGaloisMap W σ R.1 - R.1) + pointGaloisMap W σ T = _
  rw [map_add]
  abel

/-- The representation law follows from composition of the actual maps
on points, including the Kummer cocycle law. -/
def divisionAffineRepresentation (R : DivisionFiber W q P) :
    Gal(L/F) →* (curveTorsion W L q ≃ᵃ[ZMod q] curveTorsion W L q) where
  toFun := divisionAffineEquiv W q P hP R
  map_one' := by
    apply AffineEquiv.ext
    intro T
    apply Subtype.ext
    simp only [divisionAffineEquiv_coe, pointGaloisMap_one]
    exact add_sub_cancel_right T.1 R.1
  map_mul' σ τ := by
    apply AffineEquiv.ext
    intro T
    apply Subtype.ext
    change (divisionAffineEquiv W q P hP R (σ * τ) T : CurvePoints W L) =
      (divisionAffineEquiv W q P hP R σ (divisionAffineEquiv W q P hP R τ T) :
        CurvePoints W L)
    simp only [divisionAffineEquiv_coe, sub_add_cancel, pointGaloisMap_mul]

/-- The Galois subgroup fixing all actual q-torsion points. For a division
field this is `Gal(L/F(E[q]))`; the definition does not use a coordinate model. -/
def torsionFixingSubgroup : Subgroup Gal(L/F) where
  carrier := {σ | ∀ T : curveTorsion W L q, pointGaloisMap W σ T = T}
  one_mem' := fun T => pointGaloisMap_one W (T : CurvePoints W L)
  mul_mem' := by
    intro σ τ hσ hτ T
    rw [pointGaloisMap_mul, hτ T, hσ T]
  inv_mem' := by
    intro σ hσ T
    have h := congrArg (pointGaloisMap W σ⁻¹) (hσ T)
    rw [← pointGaloisMap_mul, inv_mul_cancel, pointGaloisMap_one] at h
    exact h.symm

/-- The genuine Kummer map on automorphisms fixing the elliptic q-torsion.
Its surjectivity is the precise classical input provided by Ribet's CM
division theorem for all sufficiently large primes, after constructing the
division fields and checking non-torsion of the rational point. -/
def kummerMap (R : DivisionFiber W q P) :
    torsionFixingSubgroup W q (L := L) → curveTorsion W L q :=
  fun σ => divisionCocycle W q P hP R σ.1

theorem kummerMap_mul (R : DivisionFiber W q P)
    (σ τ : torsionFixingSubgroup W q (L := L)) :
    kummerMap W q P hP R (σ * τ) =
      kummerMap W q P hP R σ + kummerMap W q P hP R τ := by
  apply Subtype.ext
  change pointGaloisMap W (σ.1 * τ.1) R.1 - R.1 =
    (pointGaloisMap W σ.1 R.1 - R.1) + (pointGaloisMap W τ.1 R.1 - R.1)
  have hfix := σ.property (divisionCocycle W q P hP R τ.1)
  change pointGaloisMap W σ.1 (pointGaloisMap W τ.1 R.1 - R.1) =
    pointGaloisMap W τ.1 R.1 - R.1 at hfix
  rw [map_sub, ← pointGaloisMap_mul] at hfix
  rw [sub_eq_iff_eq_add.mp hfix]
  abel

/-- The two-dimensional affine representation in chosen coordinates on
the actual elliptic q-torsion. The coordinates are the standard rank-two
torsion theorem's data; all affine compatibility is proved here. -/
def coordinateDivisionRepresentation (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q)) :
    Gal(L/F) →* ((ZMod q × ZMod q) ≃ᵃ[ZMod q] (ZMod q × ZMod q)) where
  toFun σ := e.symm.toAffineEquiv.trans
    ((divisionAffineEquiv W q P hP R σ).trans e.toAffineEquiv)
  map_one' := by
    apply AffineEquiv.ext
    intro v
    change e (divisionAffineRepresentation W q P hP R 1 (e.symm v)) = v
    rw [map_one]
    exact e.apply_symm_apply v
  map_mul' σ τ := by
    apply AffineEquiv.ext
    intro v
    change e (divisionAffineRepresentation W q P hP R (σ * τ) (e.symm v)) =
      e (divisionAffineRepresentation W q P hP R σ
        (e.symm (e (divisionAffineRepresentation W q P hP R τ (e.symm v)))))
    rw [map_mul, e.symm_apply_apply]
    rfl

@[simp]
theorem coordinateDivisionRepresentation_apply (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (σ : Gal(L/F)) (v : ZMod q × ZMod q) :
    coordinateDivisionRepresentation W q P hP R e σ v =
      e (divisionAffineEquiv W q P hP R σ (e.symm v)) := rfl

/-- Existence of a fixed point in the affine model is exactly existence
of an actual Frobenius-fixed elliptic division point. -/
theorem coordinate_fixed_iff_division_point_fixed (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q)) (σ : Gal(L/F)) :
    (∃ v, coordinateDivisionRepresentation W q P hP R e σ v = v) ↔
      ∃ S : DivisionFiber W q P, pointGaloisMap W σ S.1 = S.1 := by
  constructor
  · rintro ⟨v, hv⟩
    refine ⟨torsionDivisionEquiv W q P R (e.symm v), ?_⟩
    have he := congrArg e.symm hv
    simp only [coordinateDivisionRepresentation_apply, e.symm_apply_apply] at he
    have he' := congrArg Subtype.val he
    rw [divisionAffineEquiv_coe] at he'
    exact sub_eq_iff_eq_add.mp he'
  · rintro ⟨S, hS⟩
    let T := (torsionDivisionEquiv W q P R).symm S
    refine ⟨e T, ?_⟩
    rw [coordinateDivisionRepresentation_apply, e.symm_apply_apply]
    congr 1
    apply Subtype.ext
    rw [divisionAffineEquiv_coe]
    change pointGaloisMap W σ (S.1 - R.1 + R.1) - R.1 = S.1 - R.1
    rw [sub_add_cancel, hS]

/-- The determinant character of the constructed elliptic representation.
The classical Weil pairing identifies this character with the cyclotomic
character; that arithmetic identification is a separate theorem. -/
def coordinateDeterminantCharacter (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q)) :
    Gal(L/F) →* (ZMod q)ˣ :=
  LinearEquiv.det.comp (AffineEquiv.linearHom.comp
    (coordinateDivisionRepresentation W q P hP R e))

/-- An automorphism fixing the torsion acts by its actual Kummer
translation on the division fiber. -/
theorem coordinate_action_of_torsion_fixed (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (σ : torsionFixingSubgroup W q (L := L)) (v : ZMod q × ZMod q) :
    coordinateDivisionRepresentation W q P hP R e σ.1 v =
      v + e (kummerMap W q P hP R σ) := by
  rw [coordinateDivisionRepresentation_apply]
  have hT : divisionAffineEquiv W q P hP R σ.1 (e.symm v) =
      e.symm v + kummerMap W q P hP R σ := by
    apply Subtype.ext
    rw [divisionAffineEquiv_coe, map_add, σ.property (e.symm v)]
    change (e.symm v : CurvePoints W L) + pointGaloisMap W σ.1 R.1 - R.1 =
      (e.symm v : CurvePoints W L) + (pointGaloisMap W σ.1 R.1 - R.1)
    abel
  rw [hT, map_add, e.apply_symm_apply]

/-- Ribet's geometric Kummer surjectivity implies precisely the full
translation condition used by the field-degree proof. Both the affine
action and determinant-one assertion are deductions here. -/
theorem fullTranslations_of_kummer_surjective [Fact q.Prime] (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (hKummer : Function.Surjective (kummerMap W q P hP R)) :
    HasFullTranslations (coordinateDivisionRepresentation W q P hP R e)
      (coordinateDeterminantCharacter W q P hP R e) := by
  intro v
  obtain ⟨σ, hσ⟩ := hKummer (e.symm v)
  have hact : ∀ w, coordinateDivisionRepresentation W q P hP R e σ.1 w = w + v := by
    intro w
    rw [coordinate_action_of_torsion_fixed, hσ, e.apply_symm_apply]
  refine ⟨σ.1, ?_, hact⟩
  have hrep : coordinateDivisionRepresentation W q P hP R e σ.1 =
      AffineEquiv.constVAdd (ZMod q) (ZMod q × ZMod q) v := by
    apply AffineEquiv.ext
    intro w
    rw [hact]
    exact add_comm w v
  change LinearEquiv.det
    (coordinateDivisionRepresentation W q P hP R e σ.1).linear = 1
  rw [hrep]
  exact map_one LinearEquiv.det

/-- Rational points become Galois-fixed after extension of the base field;
the fixed-base-point condition used above need not be assumed separately. -/
theorem rationalPoint_galois_fixed [DecidableEq F]
    (P₀ : CurvePoints W F) (σ : Gal(L/F)) :
    pointGaloisMap W σ
      (WeierstrassCurve.Affine.Point.baseChange F L P₀) =
      WeierstrassCurve.Affine.Point.baseChange F L P₀ :=
  WeierstrassCurve.Affine.Point.map_baseChange σ.toAlgHom P₀

/-- Actual x- and y-coordinates of all q-division points of P. -/
def divisionCoordinates : Set L :=
  {a | ∃ x y : L, ∃ h : (W.toAffine.baseChange L).Nonsingular x y,
    q • WeierstrassCurve.Affine.Point.some x y h = P ∧ (a = x ∨ a = y)}

/-- If a Galois automorphism fixes every actual division point, it fixes
the field generated by their coordinates. -/
theorem galois_eq_one_of_division_points_fixed
    (hgenerate : IntermediateField.adjoin F (divisionCoordinates W q P) = ⊤)
    (σ : Gal(L/F))
    (hfixed : ∀ S : DivisionFiber W q P, pointGaloisMap W σ S.1 = S.1) : σ = 1 := by
  have hcoords : ∀ a ∈ divisionCoordinates W q P, σ • a = a := by
    rintro a ⟨x, y, h, hq, hxy⟩
    have hpoint := hfixed ⟨WeierstrassCurve.Affine.Point.some x y h, hq⟩
    change WeierstrassCurve.Affine.Point.some (σ x) (σ y) _ =
      WeierstrassCurve.Affine.Point.some x y h at hpoint
    obtain ⟨hx, hy⟩ := WeierstrassCurve.Affine.Point.some.inj hpoint
    rcases hxy with rfl | rfl
    · exact hx
    · exact hy
  have hall := (IntermediateField.forall_mem_adjoin_smul_eq_self_iff F σ).2 hcoords
  rw [hgenerate] at hall
  apply AlgEquiv.ext
  intro a
  exact hall a IntermediateField.mem_top

/-- Faithfulness is derived from the defining property of the actual
division field. It is not an extra affine-representation hypothesis. -/
theorem coordinateDivisionRepresentation_injective (R : DivisionFiber W q P)
    (e : curveTorsion W L q ≃ₗ[ZMod q] (ZMod q × ZMod q))
    (hgenerate : IntermediateField.adjoin F (divisionCoordinates W q P) = ⊤) :
    Function.Injective (coordinateDivisionRepresentation W q P hP R e) := by
  apply (injective_iff_map_eq_one _).2
  intro σ hσ
  apply galois_eq_one_of_division_points_fixed W q P hgenerate σ
  intro S
  let T := (torsionDivisionEquiv W q P R).symm S
  have hact := DFunLike.congr_fun hσ (e T)
  change coordinateDivisionRepresentation W q P hP R e σ (e T) = e T at hact
  rw [coordinateDivisionRepresentation_apply, e.symm_apply_apply] at hact
  have ht := e.injective hact
  have htv := congrArg Subtype.val ht
  rw [divisionAffineEquiv_coe] at htv
  change pointGaloisMap W σ (S.1 - R.1 + R.1) - R.1 = S.1 - R.1 at htv
  rw [sub_add_cancel] at htv
  exact sub_left_injective htv

/-- Fixed elliptic points descend whenever fixed field elements descend.
This is proved on the actual affine coordinates, including the point at
infinity. The field-level hypothesis is satisfied by finite-field Frobenius. -/
theorem exists_basePoint_of_galois_fixed [DecidableEq F]
    (σ : Gal(L/F))
    (hfield : ∀ x : L, σ x = x → ∃ a : F, algebraMap F L a = x)
    (S : CurvePoints W L) (hS : pointGaloisMap W σ S = S) :
    ∃ T : CurvePoints W F,
      WeierstrassCurve.Affine.Point.baseChange F L T = S := by
  cases S with
  | zero => exact ⟨0, rfl⟩
  | @some x y h =>
    obtain ⟨hx, hy⟩ := WeierstrassCurve.Affine.Point.some.inj hS
    obtain ⟨a, ha⟩ := hfield x hx
    obtain ⟨b, hb⟩ := hfield y hy
    have hbase : (W.toAffine.baseChange F).Nonsingular a b := by
      apply (W.toAffine.baseChange_nonsingular (Algebra.ofId F L).injective a b).mp
      simpa only [Algebra.ofId_apply, ha, hb] using h
    refine ⟨WeierstrassCurve.Affine.Point.some a b hbase, ?_⟩
    change WeierstrassCurve.Affine.Point.some (algebraMap F L a) (algebraMap F L b) _ = _
    subst x y
    rfl

/-- Base extension on the actual q-torsion groups. -/
def torsionBaseChange [DecidableEq F] : curveTorsion W F q →+ curveTorsion W L q where
  toFun T := ⟨WeierstrassCurve.Affine.Point.baseChange F L T.1, by
    rw [mem_curveTorsion, ← map_nsmul, T.property, map_zero]⟩
  map_zero' := by apply Subtype.ext; rfl
  map_add' T U := by
    apply Subtype.ext
    exact map_add (WeierstrassCurve.Affine.Point.baseChange F L) T.1 U.1

theorem torsionBaseChange_injective [DecidableEq F] :
    Function.Injective (torsionBaseChange W q (L := L)) := by
  intro T U h
  apply Subtype.ext
  exact WeierstrassCurve.Affine.Point.map_injective (Algebra.ofId F L)
    (congrArg Subtype.val h)

/-- Actual rational torsion is exactly Frobenius-fixed geometric torsion,
deduced from fixed-field descent of coordinates. -/
def rationalTorsionFixedEquiv [DecidableEq F] (σ : Gal(L/F))
    (hfield : ∀ x : L, σ x = x → ∃ a : F, algebraMap F L a = x) :
    curveTorsion W F q ≃
      {T : curveTorsion W L q // pointGaloisMap W σ T.1 = T.1} :=
  Equiv.ofBijective
    (fun T => ⟨torsionBaseChange W q T, rationalPoint_galois_fixed W T.1 σ⟩) (by
      constructor
      · intro T U h
        exact torsionBaseChange_injective W q (congrArg Subtype.val h)
      · intro S
        obtain ⟨T, hT⟩ := exists_basePoint_of_galois_fixed W σ hfield S.1.1 S.2
        have hqT : q • T = 0 := by
          apply WeierstrassCurve.Affine.Point.map_injective (Algebra.ofId F L)
          rw [map_nsmul, map_zero, hT]
          exact S.1.property
        refine ⟨⟨T, hqT⟩, ?_⟩
        apply Subtype.ext
        apply Subtype.ext
        exact hT)

end Elliptic.Arithmetic
