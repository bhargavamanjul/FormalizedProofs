module

public import Elliptic.Arithmetic.GeometricFamily
public import Elliptic.Arithmetic.FrobeniusConstruction

/-!
# Actual unramified residue fields supply the local Frobenius package

The residue field is the quotient by the chosen prime ideal, and Frobenius
is the unique lift of its p-power map. The only elliptic inputs below are
the actual good-reduction specialization bijections and characteristic
polynomial; these are not proved in this module.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Arithmetic

open NumberField
open scoped Classical

attribute [local instance] rationalPrime_isPrime rationalPrime_isMaximal
  rationalResidue_field residue_field residue_finite rationalResidue_fintype

variable (L : Type*) [Field L] [NumberField L] [IsGalois ℚ L]
variable (p : ℕ) [Fact p.Prime] (P : Ideal (𝓞 L)) [P.IsMaximal]
  [P.LiesOver (Ideal.span {(p : ℤ)})]

/-- The canonical prime-field algebra on the actual ideal quotient. -/
noncomputable abbrev residueZModAlgebra : Algebra (ZMod p) (𝓞 L ⧸ P) :=
  ((algebraMap (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 L ⧸ P)).comp
    (Int.quotientSpanNatEquivZMod p).symm.toRingHom).toAlgebra

attribute [local instance] residueZModAlgebra

omit [IsGalois ℚ L] in
theorem residue_charP : CharP (𝓞 L ⧸ P) p :=
  charP_of_injective_algebraMap' (ZMod p) p

/-- The p-power automorphism of the actual quotient, viewed over F_p. -/
def residuePrimeFieldFrobenius : Gal((𝓞 L ⧸ P)/ZMod p) := by
  let : CharP (𝓞 L ⧸ P) p := residue_charP L p P
  exact primeFieldFrobenius p (𝓞 L ⧸ P)

omit [IsGalois ℚ L] in
theorem residuePrimeFieldFrobenius_apply (x : 𝓞 L ⧸ P) :
    residuePrimeFieldFrobenius L p P x = x ^ p := rfl

variable {W : WeierstrassCurve ℚ} {Q₀ : CurvePoints W ℚ} {q : ℕ} [Fact q.Prime]

/-- Remaining elliptic reduction facts on the constructed residue field.
There is no chosen Galois automorphism or assumed decomposition generator:
both are constructed from unramifiedness at the actual prime ideal. -/
structure GeometricDivisionField.UnramifiedLocalInputs
    (D : GeometricDivisionField W Q₀ q) (p : ℕ) [Fact p.Prime]
    (V : WeierstrassCurve (ZMod p)) (Q : CurvePoints V (ZMod p)) where
  primeIdeal : Ideal (𝓞 D.ambient)
  [maximal : primeIdeal.IsMaximal]
  [liesOver : primeIdeal.LiesOver (Ideal.span {(p : ℤ)})]
  [unramified : Algebra.IsUnramifiedAt ℤ primeIdeal]
  torsionSpecialization : DivisionSpecialization W V q 0 0
    (arithmeticFrobenius D.ambient p primeIdeal)
    (residuePrimeFieldFrobenius D.ambient p primeIdeal)
  divisionSpecialization : DivisionSpecialization W V q D.point Q
    (arithmeticFrobenius D.ambient p primeIdeal)
    (residuePrimeFieldFrobenius D.ambient p primeIdeal)
  characteristicPolynomial :
    (D.affine (arithmeticFrobenius D.ambient p primeIdeal)).linear.toLinearMap.charpoly =
      Polynomial.X ^ 2 - Polynomial.C ((p : ZMod q) + 1 - Nat.card (CurvePoints V (ZMod p))) *
        Polynomial.X + Polynomial.C (p : ZMod q)

attribute [instance] GeometricDivisionField.UnramifiedLocalInputs.maximal
  GeometricDivisionField.UnramifiedLocalInputs.liesOver
  GeometricDivisionField.UnramifiedLocalInputs.unramified

/-- Assemble the old local arithmetic package, with the residue field and
the selected prime now definitionally linked by the ideal quotient. -/
def GeometricDivisionField.UnramifiedLocalInputs.toLocalInputs
    {D : GeometricDivisionField W Q₀ q} {p : ℕ} [Fact p.Prime]
    {V : WeierstrassCurve (ZMod p)} {Q : CurvePoints V (ZMod p)}
    (d : D.UnramifiedLocalInputs p V Q) : D.LocalInputs p V Q := by
  classical
  let : CharP (𝓞 D.ambient ⧸ d.primeIdeal) p := residue_charP D.ambient p d.primeIdeal
  exact
    { residue := 𝓞 D.ambient ⧸ d.primeIdeal
      frobenius := arithmeticFrobenius D.ambient p d.primeIdeal
      primeData := arithmeticFrobeniusPrimeData D.ambient p d.primeIdeal
      torsionSpecialization := d.torsionSpecialization
      divisionSpecialization := d.divisionSpecialization
      characteristicPolynomial := d.characteristicPolynomial }

end Elliptic.Arithmetic
