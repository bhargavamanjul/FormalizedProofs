module

public import Mathlib.Data.Rat.Cast.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.Algebra.Group.Subgroup.Defs
public import Mathlib.Tactic

/-!
# Rational numbers integral at a prime

The subring consists of actual rational numbers whose reduced denominators
are not divisible by `p`. Reduction to `ZMod p` is proved to be a ring
homomorphism, using the denominator-controlled rational cast identities.
-/

@[expose] public section
noncomputable section
namespace Elliptic

variable (p : ℕ) [hp : Fact p.Prime]

def primeIntegralRationals : Subring ℚ where
  carrier := {q | ¬p ∣ q.den}
  zero_mem' := by simp [hp.out.ne_one]
  one_mem' := by simp [hp.out.ne_one]
  add_mem' := by
    intro a b ha hb hab
    exact ((hp.out.dvd_mul).mp (hab.trans (Rat.add_den_dvd a b))).elim ha hb
  neg_mem' := by intro a ha; simpa using ha
  mul_mem' := by
    intro a b ha hb hab
    exact ((hp.out.dvd_mul).mp (hab.trans (Rat.mul_den_dvd a b))).elim ha hb

@[simp] theorem mem_primeIntegralRationals (q : ℚ) :
    q ∈ primeIntegralRationals p ↔ ¬p ∣ q.den := Iff.rfl

@[simp, norm_cast] theorem primeIntegral_coe_ofNat (n : ℕ) [n.AtLeastTwo] :
    ((OfNat.ofNat n : primeIntegralRationals p) : ℚ) = (OfNat.ofNat n : ℚ) := rfl

theorem primeIntegral_den_ne_zero (q : primeIntegralRationals p) :
    ((q : ℚ).den : ZMod p) ≠ 0 := by
  simpa only [mem_primeIntegralRationals, ne_eq, ZMod.natCast_eq_zero_iff] using q.property

def primeIntegralReduction : primeIntegralRationals p →+* ZMod p where
  toFun q := (q : ℚ)
  map_zero' := by simp
  map_one' := by simp
  map_add' a b := Rat.cast_add_of_ne_zero
    (primeIntegral_den_ne_zero p a) (primeIntegral_den_ne_zero p b)
  map_mul' a b := Rat.cast_mul_of_ne_zero
    (primeIntegral_den_ne_zero p a) (primeIntegral_den_ne_zero p b)

@[simp] theorem primeIntegralReduction_apply (q : primeIntegralRationals p) :
    primeIntegralReduction p q = ((q : ℚ) : ZMod p) := rfl

theorem primeIntegral_num_ne_zero (q : primeIntegralRationals p)
    (hq : primeIntegralReduction p q ≠ 0) : ((q : ℚ).num : ZMod p) ≠ 0 := by
  intro h
  apply hq
  simp [primeIntegralReduction_apply, Rat.cast_def, h]

theorem primeIntegral_inv_mem (q : primeIntegralRationals p)
    (hq : primeIntegralReduction p q ≠ 0) : (q : ℚ)⁻¹ ∈ primeIntegralRationals p := by
  have hnum := primeIntegral_num_ne_zero p q hq
  have hq0 : (q : ℚ) ≠ 0 := by
    intro heq
    apply hq
    simp [primeIntegralReduction_apply, heq]
  rw [mem_primeIntegralRationals, Rat.den_inv_of_ne_zero hq0]
  intro hd
  apply hnum
  apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).2
  exact Int.natCast_dvd.mpr hd

def primeIntegralInv (q : primeIntegralRationals p)
    (hq : primeIntegralReduction p q ≠ 0) : primeIntegralRationals p :=
  ⟨(q : ℚ)⁻¹, primeIntegral_inv_mem p q hq⟩

@[simp] theorem primeIntegralInv_coe (q : primeIntegralRationals p)
    (hq : primeIntegralReduction p q ≠ 0) :
    (primeIntegralInv p q hq : ℚ) = (q : ℚ)⁻¹ := rfl

@[simp] theorem primeIntegralReduction_inv (q : primeIntegralRationals p)
    (hq : primeIntegralReduction p q ≠ 0) :
    primeIntegralReduction p (primeIntegralInv p q hq) =
      (primeIntegralReduction p q)⁻¹ :=
  Rat.cast_inv_of_ne_zero (primeIntegral_num_ne_zero p q hq)

theorem primeIntegral_of_pow_mem {q : ℚ} {n : ℕ} (hn : n ≠ 0)
    (hq : q ^ n ∈ primeIntegralRationals p) : q ∈ primeIntegralRationals p := by
  rw [mem_primeIntegralRationals, Rat.den_pow] at hq
  intro hd
  exact hq (dvd_pow hd hn)

end Elliptic
