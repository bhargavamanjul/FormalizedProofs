module

public import Elliptic.FrobeniusPrimeBridge
public import Mathlib.FieldTheory.Finite.Basic
public import Mathlib.RingTheory.Invariant.Basic
public import Mathlib.Data.ZMod.QuotientRing
public import Mathlib.NumberTheory.RamificationInertia.Unramified

/-!
# Arithmetic Frobenius at an actual unramified prime

The decomposition group is identified with the residue-field Galois group
using the actual quotient action. Its arithmetic Frobenius and the cyclic
decomposition-group property are constructed from unramifiedness.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Arithmetic

open NumberField
open scoped Pointwise

variable (L : Type*) [Field L] [NumberField L] [IsGalois ℚ L]
variable (p : ℕ) [hp : Fact p.Prime]
variable (P : Ideal (𝓞 L)) [P.IsMaximal]
  [P.LiesOver (Ideal.span {(p : ℤ)})]

theorem rationalPrime_isPrime : (Ideal.span {(p : ℤ)}).IsPrime :=
  (Ideal.span_singleton_prime (Int.ofNat_ne_zero.mpr hp.out.ne_zero)).mpr
    (Nat.prime_iff_prime_int.mp hp.out)

attribute [local instance] rationalPrime_isPrime

theorem rationalPrime_isMaximal : (Ideal.span {(p : ℤ)}).IsMaximal :=
  Ideal.IsPrime.isMaximal inferInstance
    (by simpa only [ne_eq, Ideal.span_singleton_eq_bot] using
      (Int.ofNat_ne_zero.mpr hp.out.ne_zero))

attribute [local instance] rationalPrime_isMaximal

include p in
theorem inertia_eq_bot_of_unramified [Algebra.IsUnramifiedAt ℤ P] :
    P.inertia Gal(L/ℚ) = ⊥ := by
  apply Subgroup.card_eq_one.mp
  rw [Ideal.card_inertia_eq_ramificationIdxIn (G := Gal(L/ℚ)) (Ideal.span {(p : ℤ)}) P,
    Ideal.ramificationIdxIn_eq_ramificationIdx (Ideal.span {(p : ℤ)}) P Gal(L/ℚ),
    Ideal.ramificationIdx_eq_one_of_isUnramifiedAt]

theorem residue_stabilizerHom_bijective [Algebra.IsUnramifiedAt ℤ P] :
    Function.Bijective
      (Ideal.Quotient.stabilizerHom P (Ideal.span {(p : ℤ)}) Gal(L/ℚ)) := by
  refine ⟨?_, Ideal.Quotient.stabilizerHom_surjective Gal(L/ℚ)
    (Ideal.span {(p : ℤ)}) P⟩
  apply (MonoidHom.ker_eq_bot_iff _).mp
  rw [Ideal.Quotient.ker_stabilizerHom]
  apply le_antisymm _ bot_le
  intro σ hσ
  change σ = 1
  apply Subtype.ext
  change σ.val = (1 : Gal(L/ℚ))
  have h : σ.val ∈ P.inertia Gal(L/ℚ) := hσ
  simpa only [inertia_eq_bot_of_unramified L p P, Subgroup.mem_bot] using h

attribute [local instance] Ideal.Quotient.field

noncomputable abbrev rationalResidue_field :
    Field (ℤ ⧸ Ideal.span {(p : ℤ)}) := Ideal.Quotient.field _

noncomputable abbrev residue_field : Field (𝓞 L ⧸ P) := Ideal.Quotient.field _

attribute [local instance] rationalResidue_field residue_field

omit [IsGalois ℚ L] in
theorem residue_finite : Finite (𝓞 L ⧸ P) :=
  Ring.HasFiniteQuotients.finiteQuotient (Ideal.IsMaximal.ne_bot_of_isIntegral_int P)

attribute [local instance] residue_finite

noncomputable abbrev rationalResidue_fintype :
    Fintype (ℤ ⧸ Ideal.span {(p : ℤ)}) := Fintype.ofFinite _

attribute [local instance] rationalResidue_fintype

/-- At an unramified prime, the actual quotient action identifies the
decomposition group with the residue-field Galois group. -/
def residueStabilizerEquiv [Algebra.IsUnramifiedAt ℤ P] :
    MulAction.stabilizer Gal(L/ℚ) P ≃*
      Gal((𝓞 L ⧸ P)/(ℤ ⧸ Ideal.span {(p : ℤ)})) :=
  MulEquiv.ofBijective (Ideal.Quotient.stabilizerHom P (Ideal.span {(p : ℤ)}) Gal(L/ℚ))
    (residue_stabilizerHom_bijective L p P)

/-- The lift of the actual residue-field Frobenius to the decomposition group. -/
def arithmeticFrobeniusStabilizer
    (L : Type*) [Field L] [NumberField L] [IsGalois ℚ L]
    (p : ℕ) [Fact p.Prime] (P : Ideal (𝓞 L)) [P.IsMaximal]
    [P.LiesOver (Ideal.span {(p : ℤ)})] [Algebra.IsUnramifiedAt ℤ P] :
    MulAction.stabilizer Gal(L/ℚ) P :=
  (residueStabilizerEquiv L p P).symm
    (FiniteField.frobeniusAlgEquivOfAlgebraic (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 L ⧸ P))

/-- Arithmetic Frobenius as an actual automorphism of the number field. -/
def arithmeticFrobenius
    (L : Type*) [Field L] [NumberField L] [IsGalois ℚ L]
    (p : ℕ) [Fact p.Prime] (P : Ideal (𝓞 L)) [P.IsMaximal]
    [P.LiesOver (Ideal.span {(p : ℤ)})] [Algebra.IsUnramifiedAt ℤ P] : Gal(L/ℚ) :=
  (arithmeticFrobeniusStabilizer L p P).val

theorem arithmeticFrobenius_residue [Algebra.IsUnramifiedAt ℤ P] :
    Ideal.Quotient.stabilizerHom P (Ideal.span {(p : ℤ)}) Gal(L/ℚ)
      (arithmeticFrobeniusStabilizer L p P) =
      FiniteField.frobeniusAlgEquivOfAlgebraic (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 L ⧸ P) :=
  (residueStabilizerEquiv L p P).apply_symm_apply _

theorem arithmeticFrobenius_mod_prime [Algebra.IsUnramifiedAt ℤ P] (a : 𝓞 L) :
    Ideal.Quotient.mk P (arithmeticFrobenius L p P • a) =
      (Ideal.Quotient.mk P a) ^ p := by
  have hcard : Fintype.card (ℤ ⧸ Ideal.span {(p : ℤ)}) = p := by
    rw [← Nat.card_eq_fintype_card,
      Nat.card_congr (Int.quotientSpanNatEquivZMod p).toEquiv, Nat.card_zmod]
  have h := DFunLike.congr_fun (arithmeticFrobenius_residue L p P) (Ideal.Quotient.mk P a)
  simpa only [Ideal.Quotient.stabilizerHom_apply,
    FiniteField.coe_frobeniusAlgEquivOfAlgebraic, hcard,
    MulAction.subgroup_smul_def, arithmeticFrobenius] using h

/-- The lift is uniquely characterized by preserving the chosen prime and
acting as the p-power map on its residue field. -/
theorem arithmeticFrobenius_unique [Algebra.IsUnramifiedAt ℤ P]
    (σ : Gal(L/ℚ)) (hσ : σ ∈ MulAction.stabilizer Gal(L/ℚ) P)
    (hmod : ∀ a : 𝓞 L, Ideal.Quotient.mk P (σ • a) = (Ideal.Quotient.mk P a) ^ p) :
    σ = arithmeticFrobenius L p P := by
  have heq : (residueStabilizerEquiv L p P) ⟨σ, hσ⟩ =
      (residueStabilizerEquiv L p P) (arithmeticFrobeniusStabilizer L p P) := by
    apply AlgEquiv.ext
    intro x
    obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective x
    change Ideal.Quotient.mk P (σ • a) =
      Ideal.Quotient.mk P (arithmeticFrobenius L p P • a)
    rw [hmod, arithmeticFrobenius_mod_prime]
  exact congrArg Subtype.val ((residueStabilizerEquiv L p P).injective heq)

/-- The arithmetic Frobenius generates the entire decomposition group;
this conclusion is proved from unramifiedness, not supplied as local data. -/
theorem stabilizer_eq_zpowers_arithmeticFrobenius [Algebra.IsUnramifiedAt ℤ P] :
    MulAction.stabilizer Gal(L/ℚ) P = Subgroup.zpowers (arithmeticFrobenius L p P) := by
  apply le_antisymm
  · intro σ hσ
    obtain ⟨n, hn⟩ := (FiniteField.bijective_frobeniusAlgEquivOfAlgebraic_pow
      (ℤ ⧸ Ideal.span {(p : ℤ)}) (𝓞 L ⧸ P)).surjective
        (residueStabilizerEquiv L p P ⟨σ, hσ⟩)
    have heq : arithmeticFrobeniusStabilizer L p P ^ n.val = ⟨σ, hσ⟩ := by
      apply (residueStabilizerEquiv L p P).injective
      rw [map_pow]
      simpa only [arithmeticFrobeniusStabilizer, MulEquiv.apply_symm_apply] using hn
    refine Subgroup.mem_zpowers_iff.mpr ⟨(n.val : ℤ), ?_⟩
    simpa only [zpow_natCast, Subgroup.coe_pow, arithmeticFrobenius] using congrArg Subtype.val heq
  · exact Subgroup.zpowers_le.mpr (arithmeticFrobeniusStabilizer L p P).property

/-- The local prime-ideal package used by the counting proof, now
constructed at every actual unramified prime of a Galois number field. -/
def arithmeticFrobeniusPrimeData [Algebra.IsUnramifiedAt ℤ P] :
    FrobeniusPrimeData L (arithmeticFrobenius L p P) p where
  primeIdeal := P
  maximal := inferInstance
  liesOver := inferInstance
  decomposition_eq := stabilizer_eq_zpowers_arithmeticFrobenius L p P

end Elliptic.Arithmetic
