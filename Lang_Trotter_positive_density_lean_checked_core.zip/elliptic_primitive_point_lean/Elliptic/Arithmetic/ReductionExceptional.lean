module

public import Elliptic.Arithmetic.ReductionFinite

/-!
# The final addition forces a denominator divisible by p

If an integral rational point reduces to `-P`, adding `P` has a slope
whose denominator vanishes and numerator is `-4` modulo an odd prime.
If its new x-coordinate were integral, the square of that slope, and
hence the slope itself, would be integral. Reduction then gives `0=-4`.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic
open WeierstrassCurve.Affine

variable (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)

theorem denominator_add_point_of_reduces_neg
    {R : exampleCurve.toAffine.Point}
    (hred : FiniteReduces p hp2 R (-reductionPoint p hp2))
    (hR : R ≠ -examplePoint) :
    p ∣ (examplePointX (R + examplePoint)).den := by
  obtain ⟨x, y, h, rfl, hred⟩ := hred
  have hcoords : (2 : ZMod p) = primeIntegralReduction p x ∧
      (-2 : ZMod p) = primeIntegralReduction p y := by
    simpa only [reductionPoint, Point.neg_some, negY, reductionCurve,
      zero_mul, sub_zero, reduceIntegralPoint, Point.some.injEq] using hred
  have hfour : (4 : ZMod p) ≠ 0 := by
    convert mul_ne_zero (two_ne_zero_mod_prime p hp2) (two_ne_zero_mod_prime p hp2)
      using 1
    norm_num
  have hxQ : (x : ℚ) ≠ 2 := by
    intro hx
    have he := (Point.X_eq_iff (h₁ := h) (h₂ := examplePoint_nonsingular)).mp hx
    rcases he with he | he
    · have he' : (x : ℚ) = 2 ∧ (y : ℚ) = 2 := by
        simpa only [Point.some.injEq] using he
      have hyQ : (y : ℚ) = 2 := he'.2
      have hy : primeIntegralReduction p y = 2 := by
        change ((y : ℚ) : ZMod p) = 2
        rw [hyQ]
        norm_num
      have he2 := hcoords.2.trans hy
      apply hfour
      linear_combination -he2
    · exact hR he
  have hX : examplePointX (Point.some _ _ h + examplePoint) =
      (((y : ℚ) - 2) / ((x : ℚ) - 2)) ^ 2 - (x : ℚ) - 2 := by
    change examplePointX (Point.some _ _ h + Point.some 2 2 examplePoint_nonsingular) = _
    rw [Point.add_of_X_ne hxQ]
    simp [examplePointX, slope_of_X_ne hxQ, exampleCurve]
  by_contra hden
  have hnew : (((y : ℚ) - 2) / ((x : ℚ) - 2)) ^ 2 - (x : ℚ) - 2 ∈
      primeIntegralRationals p := by
    simpa only [mem_primeIntegralRationals, hX] using hden
  have hsquare : (((y : ℚ) - 2) / ((x : ℚ) - 2)) ^ 2 ∈ primeIntegralRationals p := by
    have ht := (primeIntegralRationals p).add_mem
      ((primeIntegralRationals p).add_mem hnew x.property)
      (2 : primeIntegralRationals p).property
    change (((y : ℚ) - 2) / ((x : ℚ) - 2)) ^ 2 - (x : ℚ) - 2 + (x : ℚ) + 2 ∈
      primeIntegralRationals p at ht
    convert ht using 1
    ring
  let l : primeIntegralRationals p :=
    ⟨((y : ℚ) - 2) / ((x : ℚ) - 2), primeIntegral_of_pow_mem p (by decide : 2 ≠ 0) hsquare⟩
  have hmul : l * (x - 2) = y - 2 := by
    apply Subtype.ext
    change (((y : ℚ) - 2) / ((x : ℚ) - 2)) * ((x : ℚ) - 2) = (y : ℚ) - 2
    exact div_mul_cancel₀ _ (sub_ne_zero.mpr hxQ)
  have hr := congrArg (primeIntegralReduction p) hmul
  simp only [map_mul, map_sub, map_ofNat, ← hcoords.1, ← hcoords.2,
    sub_self, mul_zero] at hr
  apply hfour
  linear_combination hr

end Elliptic
