module

public import Elliptic.CyclicReduction
public import Mathlib.GroupTheory.Perm.Cycle.Type

/-!
# Odd point index from the proved two-torsion calculation

The counting argument does not require the full finite-field elliptic group
structure theorem. In a finite abelian group with at most two points killed
by two, any point which is not a double has odd subgroup index. This follows
by applying doubling to the quotient by that point's cyclic subgroup.
-/

@[expose] public section

namespace Elliptic

/-- A finite abelian group needs no cyclicity assumption for this deduction.
The two-torsion bound and the non-doubling statement suffice. -/
theorem odd_pointIndex_of_two_torsion_bound {G : Type*} [AddCommGroup G] [Finite G]
    (P : G) (htwo : Nat.card (TwoTorsion G) ≤ 2)
    (hnotdouble : ¬ ∃ R : G, (2 : ℕ) • R = P) :
    Odd (pointIndex P) := by
  classical
  let d : G →+ G := nsmulAddMonoidHom 2
  have hP : P ∉ d.range := by
    simpa only [AddMonoidHom.mem_range, d, nsmulAddMonoidHom_apply] using hnotdouble
  have hind : d.range.index = 2 := by
    have hle : d.range.index ≤ 2 := by
      rw [AddSubgroup.index_range]
      exact htwo
    have hpos := Nat.pos_of_ne_zero d.range.index_ne_zero_of_finite
    have hne : d.range.index ≠ 1 := by
      intro h
      exact hP (by rw [d.range.index_eq_one.mp h]; trivial)
    omega
  let K := AddSubgroup.zmultiples P
  let π : G →+ G ⧸ K := QuotientAddGroup.mk' K
  have hPzero : π P = 0 := by
    exact (QuotientAddGroup.eq_zero_iff P).mpr (AddSubgroup.mem_zmultiples P)
  have hsurj : Function.Surjective (nsmulAddMonoidHom 2 : (G ⧸ K) →+ (G ⧸ K)) := by
    intro z
    obtain ⟨x, rfl⟩ := QuotientAddGroup.mk'_surjective K z
    by_cases hx : x ∈ d.range
    · obtain ⟨R, hR⟩ := hx
      refine ⟨π R, ?_⟩
      change (2 : ℕ) • π R = π x
      rw [← map_nsmul]
      exact congrArg π hR
    · have hxP : x + P ∈ d.range :=
        (d.range.add_mem_iff_of_index_two hind).mpr (by simp [hx, hP])
      obtain ⟨R, hR⟩ := hxP
      refine ⟨π R, ?_⟩
      change (2 : ℕ) • π R = π x
      rw [← map_nsmul, show (2 : ℕ) • R = x + P from hR, map_add, hPzero, add_zero]
  have hinj := (Finite.injective_iff_surjective).mpr hsurj
  rw [← Nat.not_even_iff_odd, even_iff_two_dvd]
  intro hdiv
  have : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  obtain ⟨z, hz⟩ := exists_prime_addOrderOf_dvd_card' (G := G ⧸ K) 2 hdiv
  have hz2 : (2 : ℕ) • z = 0 := by rw [← hz]; exact addOrderOf_nsmul_eq_zero z
  have hz0 : z = 0 := hinj (by simpa only [nsmulAddMonoidHom_apply, smul_zero] using hz2)
  simp only [hz0, addOrderOf_zero, Nat.reduceEqDiff] at hz

/-- Prime-index failure is equivalent to divisibility of the selected point
when the rational q-torsion has exactly q elements. Full cyclicity is not
required; this is the group step needed by the local Frobenius argument. -/
theorem prime_dvd_pointIndex_iff_divisible
    {G : Type*} [AddCommGroup G] [Finite G] (P : G) {q : ℕ}
    (hq : q.Prime)
    (hcard : Nat.card {R : G // q • R = 0} = q) :
    q ∣ pointIndex P ↔ ∃ R : G, q • R = P := by
  classical
  let d : G →+ G := nsmulAddMonoidHom q
  have hind : d.range.index = q := by
    rw [AddSubgroup.index_range]
    exact hcard
  constructor
  · intro hdiv
    by_contra hnot
    have hP : P ∉ d.range := hnot
    let K := AddSubgroup.zmultiples P
    let π : G →+ G ⧸ K := QuotientAddGroup.mk' K
    let ψ : G →+ G ⧸ d.range := QuotientAddGroup.mk' d.range
    have hPzero : π P = 0 :=
      (QuotientAddGroup.eq_zero_iff P).mpr (AddSubgroup.mem_zmultiples P)
    have hPnonzero : ψ P ≠ 0 := by
      exact fun h => hP ((QuotientAddGroup.eq_zero_iff P).mp h)
    have : Fact q.Prime := ⟨hq⟩
    have hsurj : Function.Surjective
        (nsmulAddMonoidHom q : (G ⧸ K) →+ (G ⧸ K)) := by
      intro z
      obtain ⟨x, rfl⟩ := QuotientAddGroup.mk'_surjective K z
      have hx : ψ x ∈ AddSubgroup.zmultiples (ψ P) :=
        mem_zmultiples_of_prime_card hind hPnonzero
      obtain ⟨j, hj⟩ := AddSubgroup.mem_zmultiples_iff.mp hx
      have hxP : x - j • P ∈ d.range := by
        apply (QuotientAddGroup.eq_zero_iff _).mp
        change ψ (x - j • P) = 0
        rw [map_sub, map_zsmul, hj, sub_self]
      obtain ⟨R, hR⟩ := hxP
      refine ⟨π R, ?_⟩
      change q • π R = π x
      rw [← map_nsmul, show q • R = x - j • P from hR,
        map_sub, map_zsmul, hPzero, smul_zero, sub_zero]
    have hinj := (Finite.injective_iff_surjective).mpr hsurj
    obtain ⟨z, hz⟩ := exists_prime_addOrderOf_dvd_card' (G := G ⧸ K) q hdiv
    have hzq : q • z = 0 := by rw [← hz]; exact addOrderOf_nsmul_eq_zero z
    have hz0 : z = 0 := hinj (by simpa only [nsmulAddMonoidHom_apply, smul_zero] using hzq)
    have : 1 = q := by simpa only [hz0, addOrderOf_zero] using hz
    exact hq.ne_one this.symm
  · intro hP
    have hle : AddSubgroup.zmultiples P ≤ d.range :=
      AddSubgroup.zmultiples_le.mpr hP
    exact hind ▸ AddSubgroup.index_dvd_of_le hle

/-- The candidate cover only uses odd index. Cyclicity is unnecessary. -/
theorem card_candidates_le_generators_add_exceptions_of_odd_index
    (G : ℕ → Type*) [∀ p, AddGroup (G p)] [∀ p, Finite (G p)]
    (P : ∀ p, G p) (s : Finset ℕ) (Candidate : ℕ → Prop)
    [DecidablePred Candidate]
    (cofactor largePrime : ℕ → ℕ) (c k Y R B : ℕ)
    (hc : c = 2 ^ k)
    (hdata : ∀ p ∈ s, Candidate p →
      Odd (pointIndex (P p)) ∧
      0 < cofactor p ∧ (largePrime p).Prime ∧
      Nat.card (G p) = c * cofactor p * largePrime p ∧
      cofactor p ≤ R ∧ c * cofactor p ≤ B ∧
      (∀ q : ℕ, q.Prime → q ∣ cofactor p → q ≠ 2 → Y < q)) :
    letI : DecidablePred (fun p => AddSubgroup.zmultiples (P p) = ⊤) :=
      Classical.decPred _
    (s.filter Candidate).card ≤
      (s.filter (fun p => AddSubgroup.zmultiples (P p) = ⊤)).card +
      (∑ q ∈ primeIndexWindow Y R,
        (s.filter (fun p => q ∣ pointIndex (P p))).card) +
      (s.filter (fun p => addOrderOf (P p) ≤ B)).card := by
  classical
  have h := card_candidates_le_index_one_add_exceptions s Candidate
    (fun p => addOrderOf (P p)) (fun p => pointIndex (P p))
    cofactor largePrime c k Y R B hc ?_
  · have hfilter : s.filter (fun p => pointIndex (P p) = 1) =
        s.filter (fun p => AddSubgroup.zmultiples (P p) = ⊤) := by
      ext p
      simp only [Finset.mem_filter, pointIndex_eq_one_iff]
    simpa only [hfilter] using h
  · intro p hps hpc
    obtain ⟨hodd, hr, hQ, hfactor, hrR, hcB, hrough⟩ := hdata p hps hpc
    exact ⟨pointIndex_pos (P p), hodd, hr, hQ,
      (addOrder_mul_pointIndex (P p)).trans hfactor, hrR, hcB, hrough⟩

end Elliptic
