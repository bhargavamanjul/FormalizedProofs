module

public import Elliptic.Arithmetic.GeometricFamily
public import Mathlib.NumberTheory.Cyclotomic.Gal
public import Mathlib.FieldTheory.Normal.Basic

/-!+# Cyclotomic surjectivity from a primitive root and its Galois action

In a normal extension of Q containing a primitive n-th root, every unit
modulo n occurs as a Galois power on that root. We prove this from the
cyclotomic minimal polynomial and normality, rather than assuming a
surjective cyclotomic character or a surjective restriction map.

The elliptic specialization deduces surjectivity of the actual determinant
character from the precise primitive-root covariance supplied by a Weil
pairing. The root and its covariance are explicit classical inputs: this
file does not construct the elliptic Weil pairing or prove its properties.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Arithmetic

variable {L : Type*} [Field L] [Algebra ℚ L] [Normal ℚ L]
variable {n : ℕ} [NeZero n] {ζ : L}

/-- Every coprime power of an actual primitive root is reached by an
automorphism of the ambient normal field. The ambient field need not
itself be a cyclotomic extension. -/
theorem exists_galois_primitive_root_power (hζ : IsPrimitiveRoot ζ n)
    (u : (ZMod n)ˣ) :
    ∃ σ : Gal(L/ℚ), σ ζ = ζ ^ (u : ZMod n).val := by
  have hu := hζ.pow_of_coprime _ (ZMod.val_coe_unit_coprime u)
  have hirr := Polynomial.cyclotomic.irreducible_rat (NeZero.pos n)
  have hm : minpoly ℚ ζ = minpoly ℚ (ζ ^ (u : ZMod n).val) :=
    (hζ.minpoly_eq_cyclotomic_of_irreducible hirr).symm.trans
      (hu.minpoly_eq_cyclotomic_of_irreducible hirr)
  apply minpoly.exists_algEquiv_of_root' (Algebra.IsAlgebraic.isAlgebraic ζ)
  rw [hm]
  exact minpoly.aeval ℚ _

/-- The genuine root-of-unity character of the ambient normal extension
of Q is surjective. This conclusion is proved from cyclotomic arithmetic,
not included among the input hypotheses. -/
theorem primitiveRoot_autToPow_surjective (hζ : IsPrimitiveRoot ζ n) :
    Function.Surjective (hζ.autToPow ℚ) := by
  intro u
  obtain ⟨σ, hσ⟩ := exists_galois_primitive_root_power hζ u
  refine ⟨σ, Units.ext (ZMod.val_injective n ?_)⟩
  exact hζ.pow_inj (ZMod.val_lt _) (ZMod.val_lt _)
    ((hζ.autToPow_spec ℚ σ).trans hσ)

omit [Normal ℚ L] in
/-- A character giving the actual action on a primitive root equals the
root-of-unity character. This is an equality of the two actual maps,
not an assumed equivalence of their surjectivity statements. -/
theorem character_eq_autToPow_of_primitive_root_covariance
    (χ : Gal(L/ℚ) →* (ZMod n)ˣ) (hζ : IsPrimitiveRoot ζ n)
    (hcov : ∀ σ : Gal(L/ℚ), σ ζ = ζ ^ (χ σ : ZMod n).val) :
    χ = hζ.autToPow ℚ := by
  apply MonoidHom.ext
  intro σ
  apply Units.ext
  apply ZMod.val_injective n
  exact hζ.pow_inj (ZMod.val_lt _) (ZMod.val_lt _)
    ((hcov σ).symm.trans (hζ.autToPow_spec ℚ σ).symm)

/-- Root covariance and normality over Q imply character surjectivity.
No Galois-group size or surjectivity premise is required. -/
theorem character_surjective_of_primitive_root_covariance
    (χ : Gal(L/ℚ) →* (ZMod n)ˣ) (hζ : IsPrimitiveRoot ζ n)
    (hcov : ∀ σ : Gal(L/ℚ), σ ζ = ζ ^ (χ σ : ZMod n).val) :
    Function.Surjective χ := by
  rw [character_eq_autToPow_of_primitive_root_covariance χ hζ hcov]
  exact primitiveRoot_autToPow_surjective hζ

/-- Application to the determinant of the actual elliptic torsion action.
For a chosen torsion basis, the classical Weil pairing supplies the
primitive root and this covariance formula. Constructing that pairing
and checking its covariance remain separate from the deduction proved
here. In particular no full GL(2) Galois image is assumed. -/
theorem GeometricDivisionField.character_surjective_of_primitive_root_covariance
    {W : WeierstrassCurve ℚ} {P : CurvePoints W ℚ}
    {q : ℕ} [Fact q.Prime] (D : GeometricDivisionField W P q)
    (ζ : D.ambient) (hζ : IsPrimitiveRoot ζ q)
    (hcov : ∀ σ : Gal(D.ambient/ℚ), σ ζ = ζ ^ (D.character σ : ZMod q).val) :
    Function.Surjective D.character :=
  Elliptic.Arithmetic.character_surjective_of_primitive_root_covariance D.character hζ hcov

end Elliptic.Arithmetic
