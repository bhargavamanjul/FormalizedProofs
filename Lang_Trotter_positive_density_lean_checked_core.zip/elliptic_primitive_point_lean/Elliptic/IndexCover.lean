module

public import Mathlib.Algebra.BigOperators.Group.Finset.Basic
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.NumberTheory.PrimeCounting
public import Mathlib.Tactic.Tauto

/-!
# The elementary index decomposition and finite exceptional-set cover

These results use only arithmetic of natural numbers and finite sets.  In an
elliptic-curve application, `o` is the order of the reduced point and `i` is
its index in the group of rational points.  The product identity, oddness of
the index, and identification of index one with generation must be supplied
by the arithmetic of the curve; they are not axioms in this file.
-/

@[expose] public section

namespace Elliptic

open scoped BigOperators

/-- A prime divisor of a power of two is two. -/
theorem prime_dvd_two_pow {q k : ℕ} (hq : q.Prime)
    (hqc : q ∣ 2 ^ k) : q = 2 := by
  exact (Nat.prime_dvd_prime_iff_eq hq Nat.prime_two).mp
    (hq.dvd_of_dvd_pow hqc)

/-- A positive divisor cannot exceed the positive integer that it divides.
Applied to the large prime divisor of the index, this forces small order.
The primality of `Q` is unnecessary here. -/
theorem order_le_cofactor_of_large_dvd_index {o i c r Q : ℕ}
    (hi : 0 < i) (hQ : 0 < Q) (hprod : o * i = c * r * Q)
    (hQi : Q ∣ i) : o ≤ c * r := by
  have hle : Q ≤ i := Nat.le_of_dvd hi hQi
  have hmul : o * Q ≤ o * i := Nat.mul_le_mul_left o hle
  exact Nat.le_of_mul_le_mul_right (by simpa only [hprod] using hmul) hQ

/-- A nontrivial odd index has an odd prime divisor which divides the
cofactor or is the distinguished large prime.  This assertion needs no
roughness assumption on the cofactor. -/
theorem exists_prime_index_divisor {o i c r Q k : ℕ}
    (hi1 : i ≠ 1) (hiodd : Odd i) (hc : c = 2 ^ k)
    (hQ : Q.Prime) (hprod : o * i = c * r * Q) :
    ∃ q : ℕ, q.Prime ∧ q ≠ 2 ∧ q ∣ i ∧ (q ∣ r ∨ q = Q) := by
  obtain ⟨q, hq, hqi⟩ := Nat.exists_prime_and_dvd hi1
  have hnot2 : ¬ 2 ∣ i := by
    simpa only [← even_iff_two_dvd, Nat.not_even_iff_odd] using hiodd
  have hq2 : q ≠ 2 := by
    intro heq
    exact hnot2 (heq ▸ hqi)
  refine ⟨q, hq, hq2, hqi, ?_⟩
  have hqdvd : q ∣ c * r * Q := by
    rw [← hprod]
    exact dvd_mul_of_dvd_right hqi o
  rcases hq.dvd_mul.mp hqdvd with hqcr | hqQ
  · rcases hq.dvd_mul.mp hqcr with hqc | hqr
    · exact False.elim (hq2 (prime_dvd_two_pow hq (hc ▸ hqc)))
    · exact Or.inl hqr
  · exact Or.inr ((Nat.prime_dvd_prime_iff_eq hq hQ).mp hqQ)

/-- The elementary exceptional-set dichotomy: a nontrivial odd index
has a prime divisor in the rough cofactor, or the order is small.
The exponent of two can be arbitrary, so this includes `c = 2, 4, 8`.
-/
theorem index_factor_dichotomy {o i c r Q k Y : ℕ}
    (hi : 0 < i) (hi1 : i ≠ 1) (hiodd : Odd i)
    (hc : c = 2 ^ k) (hr : 0 < r) (hQ : Q.Prime)
    (hprod : o * i = c * r * Q)
    (hrough : ∀ q : ℕ, q.Prime → q ∣ r → q ≠ 2 → Y < q) :
    (∃ q : ℕ, q.Prime ∧ Y < q ∧ q ≤ r ∧ q ∣ i ∧ q ∣ r) ∨
      o ≤ c * r := by
  obtain ⟨q, hq, hq2, hqi, hqr | hqQ⟩ :=
    exists_prime_index_divisor hi1 hiodd hc hQ hprod
  · exact Or.inl ⟨q, hq, hrough q hq hqr hq2,
      Nat.le_of_dvd hr hqr, hqi, hqr⟩
  · exact Or.inr (order_le_cofactor_of_large_dvd_index hi hQ.pos hprod
      (hqQ ▸ hqi))

/-- The finite set of possible small prime divisors of the index. -/
noncomputable def primeIndexWindow (Y R : ℕ) : Finset ℕ := by
  classical
  exact (Nat.primesLE R).filter (fun q => Y < q)

theorem mem_primeIndexWindow {Y R q : ℕ} :
    q ∈ primeIndexWindow Y R ↔ q.Prime ∧ Y < q ∧ q ≤ R := by
  classical
  simp only [primeIndexWindow, Finset.mem_filter, Nat.mem_primesLE]
  tauto

/-- A finite union bound without any disjointness assertion.  A candidate
may have several small prime obstructions; it is still counted only once
on the left. -/
theorem card_candidates_le_good_add_sum_add_large
    {α β : Type*} [DecidableEq α] [DecidableEq β]
    (s : Finset α) (qs : Finset β)
    (Candidate Good Large : α → Prop) (Bad : β → α → Prop)
    [DecidablePred Candidate] [DecidablePred Good] [DecidablePred Large]
    [∀ q, DecidablePred (Bad q)]
    (hcover : ∀ p ∈ s, Candidate p →
      Good p ∨ (∃ q ∈ qs, Bad q p) ∨ Large p) :
    (s.filter Candidate).card ≤ (s.filter Good).card +
      (∑ q ∈ qs, (s.filter (Bad q)).card) + (s.filter Large).card := by
  have hsub : s.filter Candidate ⊆
      (s.filter Good ∪ qs.biUnion (fun q => s.filter (Bad q))) ∪ s.filter Large := by
    intro p hp
    obtain ⟨hps, hpc⟩ := Finset.mem_filter.mp hp
    rcases hcover p hps hpc with hg | ⟨q, hq, hb⟩ | hl
    · exact Finset.mem_union_left _
        (Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hps, hg⟩))
    · exact Finset.mem_union_left _ (Finset.mem_union_right _
        (Finset.mem_biUnion.mpr ⟨q, hq, Finset.mem_filter.mpr ⟨hps, hb⟩⟩))
    · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨hps, hl⟩)
  calc
    (s.filter Candidate).card ≤
        ((s.filter Good ∪ qs.biUnion (fun q => s.filter (Bad q))) ∪
          s.filter Large).card := Finset.card_le_card hsub
    _ ≤ (s.filter Good ∪ qs.biUnion (fun q => s.filter (Bad q))).card +
        (s.filter Large).card := Finset.card_union_le _ _
    _ ≤ ((s.filter Good).card +
        (qs.biUnion (fun q => s.filter (Bad q))).card) +
        (s.filter Large).card := Nat.add_le_add_right (Finset.card_union_le _ _) _
    _ ≤ _ := Nat.add_le_add_right
        (Nat.add_le_add_left (Finset.card_biUnion_le (s := qs)
          (t := fun q => s.filter (Bad q))) _) _

/-- The candidate count is bounded by the index-one count and the two
exceptional ranges. All arithmetic hypotheses are required only for actual
candidates. This is suitable for a family of varying elliptic reductions.
-/
theorem card_candidates_le_index_one_add_exceptions
    (s : Finset ℕ) (Candidate : ℕ → Prop) [DecidablePred Candidate]
    (ord index cofactor largePrime : ℕ → ℕ) (c k Y R B : ℕ)
    (hc : c = 2 ^ k)
    (hdata : ∀ p ∈ s, Candidate p →
      0 < index p ∧ Odd (index p) ∧ 0 < cofactor p ∧
      (largePrime p).Prime ∧
      ord p * index p = c * cofactor p * largePrime p ∧
      cofactor p ≤ R ∧ c * cofactor p ≤ B ∧
      (∀ q : ℕ, q.Prime → q ∣ cofactor p → q ≠ 2 → Y < q)) :
    (s.filter Candidate).card ≤
      (s.filter (fun p => index p = 1)).card +
      (∑ q ∈ primeIndexWindow Y R, (s.filter (fun p => q ∣ index p)).card) +
      (s.filter (fun p => ord p ≤ B)).card := by
  classical
  apply card_candidates_le_good_add_sum_add_large s (primeIndexWindow Y R)
    Candidate (fun p => index p = 1) (fun p => ord p ≤ B)
    (fun q p => q ∣ index p)
  intro p hps hpc
  by_cases hi1 : index p = 1
  · exact Or.inl hi1
  · obtain ⟨hi, hiodd, hr, hQ, hprod, hrR, hcB, hrough⟩ := hdata p hps hpc
    rcases index_factor_dichotomy hi hi1 hiodd hc hr hQ hprod hrough with
      ⟨q, hq, hqY, hqr, hqi, _⟩ | hsmall
    · exact Or.inr (Or.inl ⟨q,
        mem_primeIndexWindow.mpr ⟨hq, hqY, hqr.trans hrR⟩, hqi⟩)
    · exact Or.inr (Or.inr (hsmall.trans hcB))

end Elliptic
