module

public import Mathlib.Data.Fintype.Card
public import Mathlib.Data.Fintype.Prod
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.Ring

/-!
# Fixed points of the elliptic affine normal form

For a field of characteristic different from two, the affine transformation
`(x,y) ↦ (x+b₁,-y+b₂)` has no fixed points when `b₁ ≠ 0`, and its fixed
points are explicitly parametrized by the first coordinate when `b₁ = 0`.
Over a finite field of cardinality `q`, the latter number is therefore `q`.
Adding a factor on which the transformation acts trivially multiplies the
fixed-point count and the total number of points by its cardinality.

This proves the finite combinatorial calculation, not the arithmetic bridge
identifying a division torsor and its Frobenius action with this normal form,
nor the assertion that a real cyclotomic factor has trivial Frobenius action.
Those assertions must be supplied separately when applying these theorems.
-/

@[expose] public section

namespace Elliptic

section Field

variable {k : Type*} [Field k]

/-- The affine normal form whose linear part has eigenvalues `1` and `-1`.
The affine transformation itself need not be an involution. -/
def affineNormalForm (b₁ b₂ : k) (z : k × k) : k × k :=
  (z.1 + b₁, -z.2 + b₂)

/-- Both fixed-point equations are solved explicitly. The hypothesis on two
is exactly the characteristic restriction needed to solve the second one. -/
theorem affineNormalForm_fixed_iff (b₁ b₂ : k) (z : k × k)
    (h_two : (2 : k) ≠ 0) :
    affineNormalForm b₁ b₂ z = z ↔ b₁ = 0 ∧ z.2 = b₂ / 2 := by
  constructor
  · intro h
    have hx := congrArg Prod.fst h
    have hy := congrArg Prod.snd h
    dsimp [affineNormalForm] at hx hy
    constructor
    · exact add_left_cancel (show z.1 + b₁ = z.1 + 0 by simpa using hx)
    · apply (eq_div_iff h_two).2
      linear_combination -hy
  · rintro ⟨hb, hy⟩
    apply Prod.ext
    · simp [affineNormalForm, hb]
    · dsimp [affineNormalForm]
      rw [hy]
      field_simp
      ring

/-- The explicit parametrization proving that there are exactly `q` fixed
points, rather than an assumed fixed-point count. -/
def affineFixedPointsEquiv (b₂ : k) (h_two : (2 : k) ≠ 0) :
    {z : k × k // affineNormalForm 0 b₂ z = z} ≃ k where
  toFun z := z.1.1
  invFun x := ⟨(x, b₂ / 2),
    (affineNormalForm_fixed_iff 0 b₂ (x, b₂ / 2) h_two).2 ⟨rfl, rfl⟩⟩
  left_inv z := by
    apply Subtype.ext
    apply Prod.ext
    · rfl
    · exact ((affineNormalForm_fixed_iff 0 b₂ z.1 h_two).1 z.2).2.symm
  right_inv x := rfl

/-- A nonzero translation in the invariant direction rules out fixed points. -/
theorem affineNormalForm_not_fixed {b₁ b₂ : k} (hb : b₁ ≠ 0)
    (z : k × k) : affineNormalForm b₁ b₂ z ≠ z := by
  intro h
  have hx := congrArg Prod.fst h
  dsimp [affineNormalForm] at hx
  exact hb (add_left_cancel (show z.1 + b₁ = z.1 + 0 by simpa using hx))

variable [Fintype k] [DecidableEq k]

theorem card_affineFixedPoints_zero (b₂ : k) (h_two : (2 : k) ≠ 0) :
    Fintype.card {z : k × k // affineNormalForm 0 b₂ z = z} = Fintype.card k :=
  Fintype.card_congr (affineFixedPointsEquiv b₂ h_two)

theorem card_affineFixedPoints_nonzero {b₁ b₂ : k} (hb : b₁ ≠ 0) :
    Fintype.card {z : k × k // affineNormalForm b₁ b₂ z = z} = 0 := by
  have : IsEmpty {z : k × k // affineNormalForm b₁ b₂ z = z} :=
    ⟨fun z => affineNormalForm_not_fixed hb z.1 z.2⟩
  exact Fintype.card_eq_zero

/-- The complete zero-or-`q` dichotomy. -/
theorem card_affineFixedPoints (b₁ b₂ : k) (h_two : (2 : k) ≠ 0) :
    Fintype.card {z : k × k // affineNormalForm b₁ b₂ z = z} =
      if b₁ = 0 then Fintype.card k else 0 := by
  by_cases hb : b₁ = 0
  · subst b₁
    simpa using card_affineFixedPoints_zero b₂ h_two
  · simpa [hb] using card_affineFixedPoints_nonzero (b₂ := b₂) hb

/-- Once there is one fixed point, there are exactly `q`. -/
theorem card_affineFixedPoints_of_exists (b₁ b₂ : k) (h_two : (2 : k) ≠ 0)
    (h_exists : ∃ z, affineNormalForm b₁ b₂ z = z) :
    Fintype.card {z : k × k // affineNormalForm b₁ b₂ z = z} = Fintype.card k := by
  obtain ⟨z, hz⟩ := h_exists
  have hb := ((affineNormalForm_fixed_iff b₁ b₂ z h_two).1 hz).1
  subst b₁
  exact card_affineFixedPoints_zero b₂ h_two

end Field

/-- A change of coordinates transports fixed points explicitly. Thus a later
arithmetic construction may supply the normal-form conjugacy, rather than
postulating the fixed-point cardinality as a separate assumption. -/
def fixedPointsEquivOfConjugacy {α β : Type*} (e : α ≃ β)
    (f : α → α) (g : β → β) (h : ∀ x, e (f x) = g (e x)) :
    {x : α // f x = x} ≃ {y : β // g y = y} where
  toFun x := ⟨e x.1, (h x.1).symm.trans (congrArg e x.2)⟩
  invFun y := ⟨e.symm y.1, by
    apply e.injective
    rw [h, e.apply_symm_apply, y.2]⟩
  left_inv x := by apply Subtype.ext; exact e.symm_apply_apply x.1
  right_inv y := by apply Subtype.ext; exact e.apply_symm_apply y.1

/-- The `q`-point count for an arbitrary finite torsor once its affine
normal-form identification has been established. -/
theorem card_fixedPoints_of_affineConjugacy {α k : Type*}
    [Fintype α] [DecidableEq α] [Field k] [Fintype k] [DecidableEq k]
    (e : α ≃ k × k) (f : α → α) (b₂ : k) (h_two : (2 : k) ≠ 0)
    (h : ∀ x, e (f x) = affineNormalForm 0 b₂ (e x)) :
    Fintype.card {x : α // f x = x} = Fintype.card k := by
  calc
    _ = Fintype.card {z : k × k // affineNormalForm 0 b₂ z = z} :=
      Fintype.card_congr (fixedPointsEquivOfConjugacy e f (affineNormalForm 0 b₂) h)
    _ = _ := card_affineFixedPoints_zero b₂ h_two

/-- The form needed for a division torsor: existence of a rational division
point gives one fixed point, and a normal-form conjugacy forces `q` of them. -/
theorem card_fixedPoints_of_affineConjugacy_of_exists {α k : Type*}
    [Fintype α] [DecidableEq α] [Field k] [Fintype k] [DecidableEq k]
    (e : α ≃ k × k) (f : α → α) (b₁ b₂ : k) (h_two : (2 : k) ≠ 0)
    (h : ∀ x, e (f x) = affineNormalForm b₁ b₂ (e x))
    (h_exists : ∃ x, f x = x) :
    Fintype.card {x : α // f x = x} = Fintype.card k := by
  have h_normal : ∃ z, affineNormalForm b₁ b₂ z = z := by
    obtain ⟨x, hx⟩ := h_exists
    exact ⟨e x, (h x).symm.trans (congrArg e hx)⟩
  calc
    _ = Fintype.card {z : k × k // affineNormalForm b₁ b₂ z = z} :=
      Fintype.card_congr (fixedPointsEquivOfConjugacy e f (affineNormalForm b₁ b₂) h)
    _ = _ := card_affineFixedPoints_of_exists b₁ b₂ h_two h_normal

/-- A factor with trivial action simply decorates each fixed point. -/
def fixedPointsWithTrivialFactorEquiv {α β : Type*} (f : α → α) :
    {z : α × β // (f z.1, z.2) = z} ≃ ({a : α // f a = a} × β) where
  toFun z := (⟨z.1.1, congrArg Prod.fst z.2⟩, z.1.2)
  invFun z := ⟨(z.1.1, z.2), Prod.ext z.1.2 rfl⟩
  left_inv z := by apply Subtype.ext; rfl
  right_inv z := by cases z; rfl

section Decorated

variable {k M : Type*} [Field k] [Fintype k] [DecidableEq k]
    [Fintype M] [DecidableEq M]

/-- In the application, `M` models the real cyclotomic embeddings after
their Frobenius action has independently been shown to be trivial. -/
theorem card_decoratedAffineFixedPoints (b₂ : k) (h_two : (2 : k) ≠ 0) :
    Fintype.card {z : (k × k) × M //
      (affineNormalForm 0 b₂ z.1, z.2) = z} =
      Fintype.card k * Fintype.card M := by
  calc
    _ = Fintype.card ({z : k × k // affineNormalForm 0 b₂ z = z} × M) :=
      Fintype.card_congr (fixedPointsWithTrivialFactorEquiv (affineNormalForm 0 b₂))
    _ = _ := by rw [Fintype.card_prod, card_affineFixedPoints_zero b₂ h_two]

end Decorated

/-- The underlying product has `q² m` points. -/
theorem card_decoratedAffineSpace {k M : Type*} [Fintype k] [Fintype M] :
    Fintype.card ((k × k) × M) = Fintype.card k ^ 2 * Fintype.card M := by
  simp only [Fintype.card_prod, pow_two]

end Elliptic
