module

public import Elliptic.MainCurveInfinitude
public import Elliptic.ArithmeticAssembly
public import Elliptic.ImportedAnalyticStatements
public import Elliptic.Arithmetic.ReductionDenominator

/-!
# Actual-curve endpoint with the arithmetic inputs lowered to Galois data

This is a lower-level assembled endpoint of this development. The auxiliary
fields are actual fixed fields; their degree, discriminant bound and norm-p
prime-ideal multiplicity are proved in ArithmeticAssembly. The height bound
for actual multiples of (2,2) and the oddness of the candidate point index
are also proved, as is the actual reduction-denominator criterion.
No full finite-group-structure or reduction input is needed.

The original candidate lower bound and the specified CM/Kummer realization
data remain explicit obligations. In particular the unsigned OpenAI source
record is NOT sufficient to invoke this theorem until the signed successor
sieve and its original signed criterion are supplied. `MainCurveSignedConclusion`
now supplies the candidate sieve from that criterion. This theorem does not assert a completed formalization
of the manuscript from the announced analytic inputs alone.
-/

@[expose] public section
namespace Elliptic
open Filter
open scoped Topology

/-- Precisely the still-uninstantiated arithmetic facts for the actual main
curve. All field-degree, prime-count and height consequences are deductions. -/
structure MainCurveArithmeticInputs (G : DivisionGaloisFamily)
    (S : Finset ℕ) (Y₀ : ℝ) : Prop where
  globalGaloisData : G.GlobalArithmetic S Y₀
  localGaloisData : G.LocalArithmetic mainCurveFamily mainEligible Y₀

/-- The constant is chosen before N. The remaining original candidate-sieve
obligation is deliberately visible in the theorem's arguments. -/
theorem main_curve_proportion_of_explicit_galois_data
    (G : DivisionGaloisFamily) (S : Finset ℕ) (f : SplittingSmoothing)
    (A Y₀ ε₀ : ℝ) (hA : 0 < A) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (harith : MainCurveArithmeticInputs G S Y₀)
    (hcandidate : CandidateMassObligation mainEligible mainCandidate A Y₀ ε₀)
    (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x := by
  apply main_curve_quantitative_prime_proportion
    G.Auxiliary divisionMultiplicity f A
    hanalytic.zeroCountConstant hanalytic.mellinDecayConstant
    hanalytic.remainderConstant hanalytic.threshold
    (7 * ((S.card : ℝ) + 1)) Y₀ ε₀
    hA hanalytic.zeroCountConstant_nonneg hanalytic.mellinDecayConstant_nonneg
    hanalytic.remainderConstant_nonneg (by positivity) hY₀ hε₀
    hcandidate
  · exact divisionFieldArithmetic_of_galois_data G mainCurveFamily mainEligible
      S Y₀ harith.globalGaloisData harith.localGaloisData
  · exact mainReductionDenominator
  · exact hanalytic.zeroCount
  · exact hanalytic.mellinDecay
  · exact hanalytic.explicitFormula

/-- Infinitely many actual primitive-point primes, under exactly the same
explicit obligations and one specified instance of the zero-free input. -/
theorem main_curve_infinitely_many_of_explicit_galois_data
    (G : DivisionGaloisFamily) (S : Finset ℕ) (f : SplittingSmoothing)
    (A Y₀ ε₀ : ℝ) (hA : 0 < A) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (harith : MainCurveArithmeticInputs G S Y₀)
    (hcandidate : CandidateMassObligation mainEligible mainCandidate A Y₀ ε₀)
    (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} := by
  exact main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_of_explicit_galois_data G S f A Y₀ ε₀ hA hY₀ hε₀
      harith hcandidate hanalytic) hN hQRH

end Elliptic
