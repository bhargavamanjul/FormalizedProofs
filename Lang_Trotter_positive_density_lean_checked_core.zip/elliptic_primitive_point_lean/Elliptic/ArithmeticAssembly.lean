module

public import Elliptic.Assembly
public import Elliptic.DivisionFieldBridge
public import Elliptic.DiscriminantBound
public import Elliptic.FrobeniusNormalForm
public import Elliptic.FrobeniusPrimeBridge

/-!
# Arithmetic assembly using actual fixed fields

The auxiliary number field is defined as the fixed field of the stabilizer
of a division-point/cyclotomic label. Its degree, discriminant estimate and
Frobenius-fixed embedding multiplicity are deductions, not inputs.

The lower-level elliptic realization data are kept explicit: a faithful
affine representation with full translations, the cyclotomic character,
its Frobenius trace and determinant, and the classical local different
estimate. These hypotheses still have to be established for a particular
elliptic curve and point. The prime-ideal map is the actual contraction map
constructed in `FrobeniusPrimeBridge`.
-/

@[expose] public section

noncomputable section

namespace Elliptic

/-- Actual ambient Galois fields and affine representations, total in the
integer parameter. No arithmetic properties are bundled into this data. -/
structure DivisionGaloisFamily where
  ambient : ℕ → Type
  [ambientField : ∀ q, Field (ambient q)]
  [ambientNumberField : ∀ q, NumberField (ambient q)]
  [ambientGalois : ∀ q, IsGalois ℚ (ambient q)]
  residue : ℕ → Type
  [residueField : ∀ q, Field (residue q)]
  [residueFintype : ∀ q, Fintype (residue q)]
  affine : ∀ q, Gal(ambient q/ℚ) →*
    ((residue q × residue q) ≃ᵃ[residue q] (residue q × residue q))
  character : ∀ q, Gal(ambient q/ℚ) →* (residue q)ˣ
  baseLabel : ∀ q, ((residue q) × (residue q)) × RealCyclotomicLabels (residue q)

attribute [instance] DivisionGaloisFamily.ambientField
  DivisionGaloisFamily.ambientNumberField DivisionGaloisFamily.ambientGalois
  DivisionGaloisFamily.residueField DivisionGaloisFamily.residueFintype

/-- The actual field used in the counting argument. -/
abbrev DivisionGaloisFamily.auxiliary (A : DivisionGaloisFamily) (q : ℕ) :
    IntermediateField ℚ (A.ambient q) :=
  IntermediateField.fixedField
    (divisionStabilizer (A.affine q) (A.character q) (A.baseLabel q))

abbrev DivisionGaloisFamily.Auxiliary (A : DivisionGaloisFamily) (q : ℕ) : Type :=
  A.auxiliary q

def divisionMultiplicity (q : ℕ) : ℕ := q * ((q - 1) / 2)

/-- Lower-level global representation and ramification inputs. Neither a
field degree nor the desired discriminant estimate is an input. -/
def DivisionGaloisFamily.GlobalArithmetic (A : DivisionGaloisFamily)
    (S : Finset ℕ) (Y₀ : ℝ) : Prop :=
  ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    Fintype.card (A.residue q) = q ∧
    (2 : A.residue q) ≠ 0 ∧
    Function.Injective (A.affine q) ∧
    Function.Surjective (A.character q) ∧
    HasFullTranslations (A.affine q) (A.character q) ∧
    (∀ p ∈ S, p.Prime ∧ p ≤ q) ∧
    LocalDifferentEstimateAt (A.ambient q) (insert q S)

theorem DivisionGaloisFamily.degree_and_discriminant (A : DivisionGaloisFamily)
    (S : Finset ℕ) (Y₀ : ℝ) (hglobal : A.GlobalArithmetic S Y₀)
    {q : ℕ} (hq : q.Prime) (hY : Y₀ < (q : ℝ)) :
    0 < divisionMultiplicity q ∧
    (divisionMultiplicity q : ℝ) = (q : ℝ) * (q - 1) / 2 ∧
    (Module.finrank ℚ (A.Auxiliary q) : ℝ) = (q : ℝ) * divisionMultiplicity q ∧
    Real.log ((NumberField.discr (A.Auxiliary q)).natAbs : ℝ) ≤
      (Module.finrank ℚ (A.Auxiliary q) : ℝ) *
        ((7 * ((S.card : ℝ) + 1)) * Real.log q) := by
  classical
  obtain ⟨hcard, htwo, hfaithful, hχ, htr, hS, hlocal⟩ := hglobal q hq hY
  have hdiv : 2 ∣ q - 1 := by
    rw [← hcard]
    exact two_dvd_card_sub_one (A.residue q) htwo
  have hlabel : 0 < (q - 1) / 2 := by
    rw [← hcard, ← card_realCyclotomicLabels (A.residue q) htwo]
    exact Nat.card_pos (α := RealCyclotomicLabels (A.residue q))
  have hmul : 0 < divisionMultiplicity q :=
    Nat.mul_pos hq.pos hlabel
  have hreal : (divisionMultiplicity q : ℝ) = (q : ℝ) * (q - 1) / 2 := by
    rw [divisionMultiplicity, Nat.cast_mul, Nat.cast_div hdiv (by norm_num : (2:ℝ)≠0),
      Nat.cast_sub hq.one_le, Nat.cast_one, Nat.cast_ofNat]
    ring
  have hdeg : Module.finrank ℚ (A.Auxiliary q) = q * divisionMultiplicity q := by
    change Module.finrank ℚ (IntermediateField.fixedField _) = _
    rw [finrank_division_fixedField (A.affine q) (A.character q) htwo hχ htr
      (A.baseLabel q), hcard, Nat.mul_div_assoc _ hdiv, divisionMultiplicity]
    ring
  have hambient : Module.finrank ℚ (A.ambient q) ≤ q ^ 6 := by
    simpa only [hcard] using
      finrank_le_sixth_power_of_faithful_affine_action (A.ambient q) (A.affine q) hfaithful
  refine ⟨hmul, hreal, ?_, ?_⟩
  · exact_mod_cast hdeg
  · exact log_discr_subfield_le_of_finite_bad_primes
      (A.Auxiliary q) (A.ambient q) S hq hS hambient hlocal

/-- The local CM and Kummer realization obligations. The Frobenius is an
actual automorphism, with a prime above `p` and the specified decomposition
group. Trace and determinant are the actual linear invariants. -/
def DivisionGaloisFamily.LocalArithmetic (A : DivisionGaloisFamily)
    (F : FinitePointFamily) (Eligible : ℕ → Prop) (Y₀ : ℝ) : Prop :=
  ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    ∀ p : ℕ, p.Prime → Eligible p → q < p → q ∣ pointIndex (F.point p) →
      ∃ σ : Gal(A.ambient q/ℚ), ∃ _d : FrobeniusPrimeData (A.ambient q) σ p,
        A.character q σ = -1 ∧
        LinearMap.trace (A.residue q) (A.residue q × A.residue q)
          (A.affine q σ).linear.toLinearMap = 0 ∧
        LinearMap.det (A.affine q σ).linear.toLinearMap = -1 ∧
        ∃ w, A.affine q σ w = w

/-- Frobenius trace zero and determinant minus one imply the exact number
of fixed embeddings of the actual auxiliary field. The normal form is
proved by `FrobeniusNormalForm`, not assumed here. -/
theorem DivisionGaloisFamily.fixed_embedding_count (A : DivisionGaloisFamily)
    (S : Finset ℕ) (Y₀ : ℝ) (hglobal : A.GlobalArithmetic S Y₀)
    {q : ℕ} (hq : q.Prime) (hY : Y₀ < (q : ℝ))
    (σ : Gal(A.ambient q/ℚ)) (hχσ : A.character q σ = -1)
    (htrace : LinearMap.trace (A.residue q) (A.residue q × A.residue q)
      (A.affine q σ).linear.toLinearMap = 0)
    (hdet : LinearMap.det (A.affine q σ).linear.toLinearMap = -1)
    (hfixed : ∃ w, A.affine q σ w = w) :
    Nat.card {φ : A.Auxiliary q →ₐ[ℚ] A.ambient q // σ.toAlgHom.comp φ = φ} =
      divisionMultiplicity q := by
  classical
  obtain ⟨hcard, htwo, _, hχ, htr, _, _⟩ := hglobal q hq hY
  obtain ⟨e, b₁, b₂, he⟩ := exists_affine_normal_form (A.affine q σ) htwo htrace hdet
  have hcount := card_fixed_division_embeddings_of_conjugacy
    (A.affine q) (A.character q) hχ htr (A.baseLabel q)
    htwo hχσ e.toEquiv b₁ b₂ he hfixed
  have hdiv : 2 ∣ q - 1 := by
    rw [← hcard]
    exact two_dvd_card_sub_one (A.residue q) htwo
  simpa only [hcard, Nat.mul_div_assoc _ hdiv, divisionMultiplicity] using hcount

/-- Transport the proved injective canonical actual-prime map to a finite
labelled fiber. No prime-ideal multiplicity or injectivity is an input. -/
theorem DivisionGaloisFamily.prime_fiber_embedding (A : DivisionGaloisFamily)
    (S : Finset ℕ) (Y₀ : ℝ) (hglobal : A.GlobalArithmetic S Y₀)
    {q p : ℕ} (hq : q.Prime) (hY : Y₀ < (q : ℝ)) (hp : p.Prime)
    (σ : Gal(A.ambient q/ℚ)) (d : FrobeniusPrimeData (A.ambient q) σ p)
    (hχσ : A.character q σ = -1)
    (htrace : LinearMap.trace (A.residue q) (A.residue q × A.residue q)
      (A.affine q σ).linear.toLinearMap = 0)
    (hdet : LinearMap.det (A.affine q σ).linear.toLinearMap = -1)
    (hfixed : ∃ w, A.affine q σ w = w) :
    ∃ e : Fin (divisionMultiplicity q) ↪ DedekindPrimeIdeal (A.Auxiliary q),
      ∀ i, Ideal.absNorm (e i).1 = p := by
  classical
  let : Fact p.Prime := ⟨hp⟩
  let T := {φ : A.Auxiliary q →ₐ[ℚ] A.ambient q // σ.toAlgHom.comp φ = φ}
  let : Fintype T := Fintype.ofFinite T
  have hcard : Fintype.card T = divisionMultiplicity q := by
    simpa only [T, Nat.card_eq_fintype_card] using
      A.fixed_embedding_count S Y₀ hglobal hq hY σ hχσ htrace hdet hfixed
  let e : T ≃ Fin (divisionMultiplicity q) := Fintype.equivFinOfCardEq hcard
  refine ⟨{
    toFun := fun i => ⟨d.fixedEmbeddingPrime (e.symm i),
      inferInstance, d.fixedEmbeddingPrime_ne_bot (e.symm i)⟩
    inj' := ?_ }, ?_⟩
  · intro i j hij
    apply e.symm.injective
    exact d.fixedEmbeddingPrime_injective_fixedField
      (divisionStabilizer (A.affine q) (A.character q) (A.baseLabel q))
      (congrArg Subtype.val hij)
  · intro i
    exact d.fixedEmbeddingPrime_absNorm (e.symm i)

/-- Distinct rational prime norms make the local prime-ideal fibers
disjoint. This is the global injection required by the analytic count. -/
theorem prime_fiber_union_embedding {K : Type} [Field K] [NumberField K]
    (I : Finset ℕ) (r : ℕ)
    (hfiber : ∀ p ∈ I, ∃ e : Fin r ↪ DedekindPrimeIdeal K,
      ∀ i, Ideal.absNorm (e i).1 = p) :
    ∃ e : ({p // p ∈ I} × Fin r) ↪ DedekindPrimeIdeal K,
      ∀ v, Ideal.absNorm (e v).1 = v.1.1 := by
  classical
  let e (p : {p // p ∈ I}) : Fin r ↪ DedekindPrimeIdeal K := (hfiber p.1 p.2).choose
  have he (p : {p // p ∈ I}) (i : Fin r) : Ideal.absNorm (e p i).1 = p.1 :=
    (hfiber p.1 p.2).choose_spec i
  refine ⟨{ toFun := fun v => e v.1 v.2, inj' := ?_ }, ?_⟩
  · rintro ⟨p, i⟩ ⟨s, j⟩ hij
    have hps : p = s := by
      apply Subtype.ext
      calc
        p.1 = Ideal.absNorm (e p i).1 := (he p i).symm
        _ = Ideal.absNorm (e s j).1 := congrArg (fun P : DedekindPrimeIdeal K => Ideal.absNorm P.1) hij
        _ = s.1 := he s j
    subst s
    exact congrArg (fun k => (p, k)) ((e p).injective hij)
  · rintro ⟨p, i⟩
    exact he p i

/-- Assembly into the exact arithmetic input consumed by the analytic
explicit-formula theorem. Every auxiliary field is the actual fixed field
of its division stabilizer. -/
theorem divisionFieldArithmetic_of_galois_data (A : DivisionGaloisFamily)
    (F : FinitePointFamily) (Eligible : ℕ → Prop) (S : Finset ℕ) (Y₀ : ℝ)
    (hglobal : A.GlobalArithmetic S Y₀)
    (hlocal : A.LocalArithmetic F Eligible Y₀) :
    DivisionFieldArithmeticObligation F Eligible A.Auxiliary divisionMultiplicity
      (7 * ((S.card : ℝ) + 1)) Y₀ := by
  classical
  intro q hq hY
  obtain ⟨hpos, hmul, hdeg, hdisc⟩ := A.degree_and_discriminant S Y₀ hglobal hq hY
  refine ⟨hpos, hmul, hdeg, hdisc, ?_⟩
  intro x hx hqx
  apply prime_fiber_union_embedding
  intro p hp
  have hpmem : p ∈ dyadicGoodPrimes Eligible x := (Finset.mem_filter.mp hp).1
  have hindex : q ∣ pointIndex (F.point p) := (Finset.mem_filter.mp hp).2
  obtain ⟨hpprime, hpEligible, hxp, _⟩ := mem_dyadic_eligible (by linarith) hpmem
  have hqp : q < p := by exact_mod_cast hqx.trans hxp
  obtain ⟨σ, d, hχσ, htrace, hdet, hfixed⟩ :=
    hlocal q hq hY p hpprime hpEligible hqp hindex
  exact A.prime_fiber_embedding S Y₀ hglobal hq hY hpprime
    σ d hχσ htrace hdet hfixed

end Elliptic
