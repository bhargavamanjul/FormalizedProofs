module

public import Elliptic.Operator.OriginalResidueEncoding
public import Elliptic.Operator.RootIntegratedBonferroni

/-!
# Numerical full residue averages equal original independent averages

This connects the actual fullAverage used by the signed Bonferroni root
comparison to the grouped independentAverage used by the complete boundary
schedule identity. Both numerical and grouped prime alphabets are literal.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalIndependentCRT
open scoped BigOperators
open OriginalLifespanSchedule IndependentLineNormalization RootRecordEncoding
open RootIntegratedBonferroni RootRecordGap
attribute [local instance] Classical.propDecidable
local instance originalNumericDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {Z : Type} [Fintype Z]
variable {P : Fin K→Type} [∀i,Fintype (P i)]

/-- Finite distributivity evaluates the full numerical line average. -/
theorem fullAverage_eq_product (rec : OriginalPathWeights.Record K J N R Q)
    (S : Finset ℕ) [∀p : S,Fact p.val.Prime] (η : ℕ→ℝ) :
    fullAverage rec S η =
      ((∏p : S,lineAverage (Finset.range (N+1)) (OriginalPathWeights.activeVisits rec p)
        (fun j=>primeResidueAnchor p (OriginalPathWeights.positionAt rec j)) η : ℝ):ℂ) := by
  have h := independent_line_average_factorization (fun p : S=>Option (ZMod p.val))
    (fun _=>Finset.range (N+1)) (fun p=>OriginalPathWeights.activeVisits rec p)
    (fun p j=>primeResidueAnchor p (OriginalPathWeights.positionAt rec j)) (fun _=>η)
  rw [Finset.prod_inv_distrib] at h
  have hc := congrArg (fun t : ℝ=>(t:ℂ)) h
  simp only [Complex.ofReal_mul,Complex.ofReal_inv,Complex.ofReal_prod,Complex.ofReal_sum,
    Complex.ofReal_natCast] at hc
  rw [mul_comm] at hc
  unfold fullAverage average
  simp only [Fintype.card_pi,Nat.cast_prod,div_eq_mul_inv]
  convert hc using 1
  congr 1
  · apply Finset.sum_congr
    · ext ℓ; simp only [Finset.mem_univ]
    · intro ℓ _
      unfold OriginalPathWeights.residueFactor
      rw [←Finset.prod_coe_sort]
      simp only [Complex.ofReal_prod]
      apply Finset.prod_congr rfl
      intro p _
      simp only [extendLines,dif_pos p.property]
  · simp only [Complex.ofReal_prod]

/-- Exact bridge from the full numeric mean to the complete original
independent-line model, retaining every active and inactive visit. -/
theorem fullAverage_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime]
    [∀p : ↥(Finset.univ.image (fun s : Sigma P=>value s.1 s.2)),Fact p.val.Prime]
    (r : OriginalPath (Fin K) Z P J N) (η : ℕ→ℝ) :
    fullAverage (encode position value hvalue r)
      (Finset.univ.image (fun s : Sigma P=>value s.1 s.2)) η =
      (r.independentAverage (fun z i p=>primeResidueAnchor (value i p) (position z).val) η:ℂ) := by
  rw [fullAverage_eq_product]
  congr 1
  rw [←Equiv.prod_comp (primePoolEquiv value hinj)]
  unfold OriginalPath.independentAverage
  rw [Fintype.prod_sigma]
  apply Finset.prod_congr rfl
  intro i _
  apply Finset.prod_congr rfl
  intro p _
  let s : Sigma P := ⟨i,p⟩
  simp only [primePoolEquiv_val]
  rw [activeVisits_encode position value hvalue hinj]
  unfold lineAverage
  simp only [Fintype.card_option,ZMod.card]
  apply congrArg (fun t : ℝ=>((value i p+1:ℕ):ℝ)⁻¹*t)
  apply Finset.sum_congr rfl
  intro ℓ _
  unfold lineFactor
  congr 1
  · apply Finset.prod_congr rfl
    intro t ht
    dsimp only
    simp only [positionAt_encode position value hvalue r t
      (Finset.mem_range.mp ((Finset.filter_subset _ _) ht))]
    split_ifs <;> rfl
  · apply Finset.prod_congr rfl
    intro t ht
    unfold Elliptic.PrimewiseMemory.hitWeight
    dsimp only
    simp only [positionAt_encode position value hvalue r t
      (Finset.mem_range.mp (Finset.mem_sdiff.mp ht).1)]
    split_ifs <;> rfl

end Elliptic.Operator.OriginalIndependentCRT
