module

public import Elliptic.Operator.SignedDyadicCauchy

/-! The exact expanded-square and determinant algebra for the successor
shift. In particular the target determinant is a-b, so the sign change
from the prime-predecessor paper is retained literally. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDeterminantReduction
open scoped BigOperators ComplexConjugate
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDyadicCauchy
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The common cofactor equations are equivalent to the signed
 determinant equation when the two selected label products are coprime. -/
theorem successor_determinant_iff (a b m n r s : ℕ) (ha : 0<a) (hb : 0<b)
    (hab : a.Coprime b) :
    (∃h : ℕ,0<h ∧ m*n+1=a*h ∧ r*s+1=b*h) ↔
      (b:ℤ)*m*n-(a:ℤ)*r*s=(a:ℤ)-b := by
  constructor
  · rintro ⟨h,_,hm,hr⟩
    have hm' : (m:ℤ)*n+1=(a:ℤ)*h := by exact_mod_cast hm
    have hr' : (r:ℤ)*s+1=(b:ℤ)*h := by exact_mod_cast hr
    nlinarith [congrArg (fun t : ℤ=>(b:ℤ)*t) hm',congrArg (fun t : ℤ=>(a:ℤ)*t) hr']
  · intro hdet
    have he : b*(m*n+1)=a*(r*s+1) := by
      exact_mod_cast (show (b:ℤ)*((m:ℤ)*n+1)=(a:ℤ)*((r:ℤ)*s+1) by nlinarith)
    have had : a∣m*n+1 := hab.dvd_of_dvd_mul_left (he ▸ dvd_mul_right a (r*s+1))
    let h := (m*n+1)/a
    have hah : a*h=m*n+1 := Nat.mul_div_cancel' had
    have hbh : b*h=r*s+1 := by
      apply Nat.eq_of_mul_eq_mul_left ha
      calc
        a*(b*h)=b*(a*h) := by ring
        _ = b*(m*n+1) := by rw [hah]
        _ = a*(r*s+1) := he
    refine ⟨h,?_,hah.symm,hbh.symm⟩
    exact Nat.div_pos (Nat.le_of_dvd (by omega) had) ha

/-- Exact equality of the two literal quotient cofactors; no abstract
incidence predicate or changed sign is hidden in this step. -/
theorem cofactor_eq_iff_determinant (a b m n r s : ℕ) (ha : 0<a) (hb : 0<b)
    (had : a∣m*n+1) (hbd : b∣r*s+1) :
    (m*n+1)/a=(r*s+1)/b ↔
      (b:ℤ)*m*n-(a:ℤ)*r*s=(a:ℤ)-b := by
  have hah := Nat.mul_div_cancel' had
  have hbh := Nat.mul_div_cancel' hbd
  have hah' : (a:ℤ)*(((m*n+1)/a:ℕ):ℤ)=((m:ℤ)*n+1) := by exact_mod_cast hah
  have hbh' : (b:ℤ)*(((r*s+1)/b:ℕ):ℤ)=((r:ℤ)*s+1) := by exact_mod_cast hbh
  constructor
  · intro h
    have h' : (((m*n+1)/a:ℕ):ℤ)=((r*s+1)/b:ℕ) := by exact_mod_cast h
    rw [h'] at hah'
    nlinarith [congrArg (fun t : ℤ=>(b:ℤ)*t) hah',congrArg (fun t : ℤ=>(a:ℤ)*t) hbh']
  · intro hdet
    have he : (a:ℤ)*b*(((m*n+1)/a:ℕ):ℤ)=(a:ℤ)*b*(((r*s+1)/b:ℕ):ℤ) := by
      nlinarith [congrArg (fun t : ℤ=>(b:ℤ)*t) hah',congrArg (fun t : ℤ=>(a:ℤ)*t) hbh']
    have hab0 : (a:ℤ)*b≠0 := mul_ne_zero (by exact_mod_cast ha.ne') (by exact_mod_cast hb.ne')
    exact_mod_cast mul_left_cancel₀ hab0 he

theorem finite_square_expansion {R : Type*} (s : Finset R) (c : R→ℂ) :
    (‖∑r∈s,c r‖^2:ℂ)=∑r∈s,∑u∈s,c r*conj (c u) := by
  rw [←Complex.mul_conj',map_sum,Finset.sum_mul_sum]

/-- The actual fiber energy from Cauchy is the nonnegative real quantity
whose complex expansion gives every pair of original scalar records. -/
theorem actual_fiber_square_expansion {K : ℕ} (b : Bands K) (x Y : ℝ)
    (s t : Finset ℕ) (η : ℝ→ℂ) (α β : ℕ→ℂ) :
    ((∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2:ℝ):ℂ)=
      ∑h∈dyadicCofactors b x Y s t η,
        ∑r∈(dyadicRecords b x Y s t η).filter (fun r=>cofactor b x s t r=h),
        ∑u∈(dyadicRecords b x Y s t η).filter (fun u=>cofactor b x s t u=h),
          undampedCoefficient b x Y s t η α β r*conj (undampedCoefficient b x Y s t η α β u) := by
  push_cast
  apply Finset.sum_congr rfl
  intro h _
  exact finite_square_expansion _ _

/-- On the actual selected-divisor records, the cofactor constraint is
literally the determinant equation with the successor sign. -/
theorem actual_record_cofactor_iff {K : ℕ} (b : Bands K) (x : ℝ) (s t : Finset ℕ)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (r u : Record b x s t) (hr : r∈records b x s t) (hu : u∈records b x s t) :
    cofactor b x s t r=cofactor b x s t u ↔
      (labelProduct b x u.2.2:ℤ)*r.1.val*r.2.1.val-
        (labelProduct b x r.2.2:ℤ)*u.1.val*u.2.1.val=
        (labelProduct b x r.2.2:ℤ)-labelProduct b x u.2.2 := by
  exact cofactor_eq_iff_determinant _ _ _ _ _ _ (labelProduct_pos b x r.2.2)
    (labelProduct_pos b x u.2.2)
    (labelProduct_dvd b x r.2.2 hdisjoint _ (Finset.mem_filter.mp hr).2)
    (labelProduct_dvd b x u.2.2 hdisjoint _ (Finset.mem_filter.mp hu).2)

end Elliptic.Operator.SignedDeterminantReduction
