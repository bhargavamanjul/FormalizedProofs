module

public import Elliptic.Operator.IndependentLineNormalization
public import Elliptic.Operator.LifespanVisitCoefficients
public import Elliptic.Operator.ProjectiveCoordinates

/-!
# The independent-line leaf weights are literal lifespan coefficients

The signed ghost endpoints and internal hit damping are recovered from
`lifespanVisitFactor`, rather than supplied as a coefficient identity. The
normalizing baselines over the actual finite prime families lie in `(0,1]`
in the source parameter range. These are local exact identities; the
integer-root expansion and the analytic norm bound remain separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.IndependentLifespanCoefficient
open scoped BigOperators
open Elliptic.PrimewiseMemory IndependentLineNormalization
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {N : ℕ} {Line : Type*} [DecidableEq Line]

/-- A normalized lifespan has its two literal signed endpoints and its
inactive internal hit damping. The visit set may be any finite set that
contains the two endpoints. -/
theorem lifespan_product (L : PrimeLifespan N) (visits : Finset ℕ)
    (hb : L.birth ∈ visits) (hd : L.death ∈ visits)
    (line : ℕ → Line) (η : ℕ → ℝ) (ℓ : Line) :
    (∏ j ∈ visits, L.lifespanVisitFactor 1 η (fun j => 1-η j)
      (fun j => line j = ℓ) j) =
    (if L.death ∈ L.active then 1 else -η L.death) *
      (∏ j ∈ visits with L.birth < j ∧ j < L.death ∧ j ∉ L.active,
        (1-hitWeight line η j ℓ)) *
      (if L.birth ∈ L.active then 1 else -η L.birth) := by
  have hbirth :
      (∏ j ∈ visits, if L.ghostBorn j then -η j else 1) =
        if L.birth ∈ L.active then 1 else -η L.birth := by
    by_cases ha : L.birth ∈ L.active
    · have he : ∀ j, ¬ L.ghostBorn j := by
        rintro j ⟨rfl,hj⟩
        exact hj ha
      simp [he,ha]
    · have he : ∀ j, L.ghostBorn j ↔ j=L.birth := by
        intro j
        exact ⟨And.left, fun h => ⟨h, h ▸ ha⟩⟩
      simp_rw [he]
      simp [hb,ha]
  have hdeath :
      (∏ j ∈ visits, if L.ghostDies j then -η j else 1) =
        if L.death ∈ L.active then 1 else -η L.death := by
    by_cases ha : L.death ∈ L.active
    · have he : ∀ j, ¬ L.ghostDies j := by
        rintro j ⟨rfl,hj⟩
        exact hj ha
      simp [he,ha]
    · have he : ∀ j, L.ghostDies j ↔ j=L.death := by
        intro j
        exact ⟨And.left, fun h => ⟨h, h ▸ ha⟩⟩
      simp_rw [he]
      simp [hd,ha]
  have hmid :
      (∏ j ∈ visits,
        if L.birth < j ∧ j < L.death ∧ j ∉ L.active ∧ line j = ℓ
        then 1-η j else 1) =
      ∏ j ∈ visits with L.birth < j ∧ j < L.death ∧ j ∉ L.active,
        (1-hitWeight line η j ℓ) := by
    rw [Finset.prod_filter]
    apply Finset.prod_congr rfl
    intro j hj
    by_cases ht : line j = ℓ <;>
      by_cases h : L.birth < j ∧ j < L.death ∧ j ∉ L.active <;>
      simp [hitWeight,ht,h]
  simp only [PrimeLifespan.lifespanVisitFactor,mul_one,Finset.prod_mul_distrib]
  rw [hbirth,hdeath,hmid]

/-- The inactive independent-line term with two distinct ghost endpoints
is exactly the corresponding normalized lifespan product. -/
theorem ghostOnly_product (visits : Finset ℕ) (b d : ℕ)
    (hbd : b<d) (hdN : d≤N) (hb : b∈visits) (hd : d∈visits)
    (line : ℕ → Line) (η : ℕ → ℝ) :
    (∏ j ∈ visits, (ghostOnlyLifespan N b d hbd hdN).lifespanVisitFactor
      1 η (fun j => 1-η j) (fun j => line j=line d) j) =
    η d * η b * ∏ j ∈ visits with b<j ∧ j<d,
      (1-hitWeight line η j (line d)) := by
  rw [lifespan_product _ visits hb hd]
  simp only [ghostOnlyLifespan,Finset.notMem_empty,ite_false,not_false_eq_true,and_true]
  ring

/-- Normalization preserves the ghost leaf with the actual endpoint-line
incidence condition, including its zero value when the endpoints differ. -/
theorem normalized_ghostOnly_leaf (visits : Finset ℕ) (b d : ℕ)
    (hbd : b<d) (hdN : d≤N) (hb : b∈visits) (hd : d∈visits)
    (line : ℕ → Line) (η : ℕ → ℝ) (n : ℝ) :
    normalizedLineMass visits η n *
      (if line b=line d then η d * η b *
        ∏ j ∈ visits with b<j ∧ j<d, (1-hitWeight line η j (line d)) else 0) =
    normalizedLineMass visits η n *
      (if line b=line d then
        ∏ j ∈ visits, (ghostOnlyLifespan N b d hbd hdN).lifespanVisitFactor
          1 η (fun j => 1-η j) (fun j => line j=line d) j else 0) := by
  rw [ghostOnly_product visits b d hbd hdN hb hd]

/-- The complete inactive one-prime average is the baseline plus the
sum of all actual two-ghost lifespans. Distinct endpoints are enforced by
the finite index type, and the retained-line incidence indicator remains. -/
theorem inactive_lineAverage_lifespans [Fintype Line]
    (visits : Finset ℕ) (hvisits : ∀ j∈visits, j≤N)
    (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ) ≠ 0)
    (hbase : (Fintype.card Line : ℝ) - ∑ j∈visits, η j ≠ 0) :
    lineAverage visits ∅ line η =
      baseline visits η (Fintype.card Line) *
      (1 + normalizedLineMass visits η (Fintype.card Line) *
        ∑ d : visits, ∑ b : visits.filter (·<d.val),
          if line b.val=line d.val then
            ∏ j∈visits, (ghostOnlyLifespan N b.val d.val
              (Finset.mem_filter.mp b.property).2 (hvisits d.val d.property)).lifespanVisitFactor
                1 η (fun j => 1-η j) (fun j => line j=line d.val) j
          else 0) := by
  have hs :
      (∑ d∈visits, ∑ b∈visits with b<d,
        if line b=line d then η d * η b *
          ∏ j∈visits with b<j ∧ j<d, (1-hitWeight line η j (line d)) else 0) =
      ∑ d : visits, ∑ b : visits.filter (·<d.val),
        if line b.val=line d.val then
          ∏ j∈visits, (ghostOnlyLifespan N b.val d.val
            (Finset.mem_filter.mp b.property).2 (hvisits d.val d.property)).lifespanVisitFactor
              1 η (fun j => 1-η j) (fun j => line j=line d.val) j
        else 0 := by
    rw [← Finset.sum_coe_sort visits]
    apply Finset.sum_congr rfl
    intro d hd
    rw [← Finset.sum_coe_sort (visits.filter (·<d.val))]
    apply Finset.sum_congr rfl
    intro b hb
    rw [ghostOnly_product visits b.val d.val (Finset.mem_filter.mp b.property).2
      (hvisits d.val d.property) (Finset.mem_filter.mp b.property).1 d.property]
  rw [inactive_lineAverage visits line η hn hbase,hs]

/-- Splitting the interior of a lifespan at its first and last active
visits gives exactly the three regions in the independent-line expansion. -/
theorem inactive_interval_split (visits active : Finset ℕ) (b a c d : ℕ)
    (hba : b≤a) (hac : a≤c) (hcd : c≤d)
    (ha : a∈active) (hc : c∈active) (f : ℕ → ℝ) :
    (∏ j ∈ visits with b<j ∧ j<d ∧ j∉active, f j) =
      (∏ j ∈ visits \ active with b<j ∧ j<a, f j) *
      (∏ j ∈ visits \ active with a≤j ∧ j≤c, f j) *
      (∏ j ∈ visits \ active with c<j ∧ j<d, f j) := by
  rw [product_three_visit_regions _ a c hac]
  have hl : (visits.filter (fun j => b<j ∧ j<d ∧ j∉active)).filter (·<a) =
      (visits \ active).filter (fun j => b<j ∧ j<a) := by
    ext j
    by_cases hjv : j∈visits <;> by_cases hja : j∈active <;>
      simp [hjv,hja]; omega
  have hm : (visits.filter (fun j => b<j ∧ j<d ∧ j∉active)).filter
      (fun j => a≤j ∧ j≤c) =
      (visits \ active).filter (fun j => a≤j ∧ j≤c) := by
    ext j
    have hja : j∉active → j≠a := fun hj he => hj (he ▸ ha)
    have hjc : j∉active → j≠c := fun hj he => hj (he ▸ hc)
    by_cases hjv : j∈visits
    · by_cases hjmem : j∈active
      · simp [hjv,hjmem]
      · have hne_a := hja hjmem
        have hne_c := hjc hjmem
        simp only [Finset.mem_filter,Finset.mem_sdiff,hjv,hjmem,not_false_eq_true,
          true_and,and_true]
        omega
    · simp [hjv]
  have hr : (visits.filter (fun j => b<j ∧ j<d ∧ j∉active)).filter (c<·) =
      (visits \ active).filter (fun j => c<j ∧ j<d) := by
    ext j
    by_cases hjv : j∈visits <;> by_cases hja : j∈active <;>
      simp [hjv,hja]; omega
  rw [hl,hm,hr]

/-- Every active optional-endpoint leaf equals the normalized product of
its actual canonical lifespan factors when the chosen ghost endpoints
lie on the retained line. No coefficient formula is assumed. -/
theorem activeChoice_product (visits active : Finset ℕ)
    (hvisits : ∀ j∈visits, j≤N) (hactive : active⊆visits)
    (a c : ℕ) (ha : a∈active) (hc : c∈active)
    (hull : ∀ j∈active, a≤j ∧ j≤c)
    (b : LeftGhostChoice (visits \ active) a)
    (d : RightGhostChoice (visits \ active) c)
    (line : ℕ → Line) (η : ℕ → ℝ)
    (hbline : b.elim True (fun t => line t.val=line a))
    (hdline : d.elim True (fun t => line t.val=line a)) :
    (∏ j ∈ visits, (activeChoiceLifespan N visits active hvisits hactive
      a c ha hc hull b d).lifespanVisitFactor 1 η (fun j => 1-η j)
        (fun j => line j=line a) j) =
      leftGhostWeight (visits \ active) a (fun j => hitWeight line η j (line a)) b *
      (∏ j ∈ visits \ active with a≤j ∧ j≤c, (1-hitWeight line η j (line a))) *
      rightGhostWeight (visits \ active) c (fun j => hitWeight line η j (line a)) d := by
  have hac := (hull a ha).2
  have hempty (x : ℕ) : (visits \ active).filter (fun j => x<j ∧ j<x) = ∅ := by
    apply Finset.filter_eq_empty_iff.mpr
    intro j hj h
    omega
  have hbmem : (activeChoiceLifespan N visits active hvisits hactive
      a c ha hc hull b d).birth ∈ visits := by
    cases b with
    | none => exact hactive ha
    | some b => exact (Finset.mem_sdiff.mp b.property.1).1
  have hdmem : (activeChoiceLifespan N visits active hvisits hactive
      a c ha hc hull b d).death ∈ visits := by
    cases d with
    | none => exact hactive hc
    | some d => exact (Finset.mem_sdiff.mp d.property.1).1
  rw [lifespan_product _ visits hbmem hdmem]
  cases b with
  | none =>
    cases d with
    | none =>
      simp only [activeChoiceLifespan,Option.elim_none,ha,hc,ite_true,
        leftGhostWeight,rightGhostWeight,one_mul,mul_one]
      rw [inactive_interval_split visits active a a c c le_rfl hac le_rfl ha hc]
      simp only [hempty,Finset.prod_empty,one_mul,mul_one]
    | some d =>
      have hdn := (Finset.mem_sdiff.mp d.property.1).2
      have hcd := d.property.2
      simp only [Option.elim_some] at hdline
      simp only [activeChoiceLifespan,Option.elim_none,Option.elim_some,ha,hdn,
        ite_true,ite_false,leftGhostWeight,rightGhostWeight,one_mul,mul_one]
      rw [inactive_interval_split visits active a a c d.val le_rfl hac hcd.le ha hc]
      simp only [hempty,Finset.prod_empty,one_mul]
      simp [hitWeight,hdline]
      ring
  | some b =>
    have hbn := (Finset.mem_sdiff.mp b.property.1).2
    have hba := b.property.2
    simp only [Option.elim_some] at hbline
    cases d with
    | none =>
      simp only [activeChoiceLifespan,Option.elim_none,Option.elim_some,hbn,hc,
        ite_true,ite_false,leftGhostWeight,rightGhostWeight,one_mul,mul_one]
      rw [inactive_interval_split visits active b.val a c c hba.le hac le_rfl ha hc]
      simp only [hempty,Finset.prod_empty,mul_one,hitWeight,hbline,ite_true]
      ring
    | some d =>
      have hdn := (Finset.mem_sdiff.mp d.property.1).2
      have hcd := d.property.2
      simp only [Option.elim_some] at hdline
      simp only [activeChoiceLifespan,Option.elim_some,hbn,hdn,
        ite_false,leftGhostWeight,rightGhostWeight]
      rw [inactive_interval_split visits active b.val a c d.val hba.le hac hcd.le ha hc]
      simp only [hitWeight,hbline,hdline,ite_true]
      ring

/-- The total active leaf identity includes the endpoint incidence
indicator. An incompatible ghost endpoint has zero literal hit weight. -/
theorem activeChoice_leaf (visits active : Finset ℕ)
    (hvisits : ∀ j∈visits, j≤N) (hactive : active⊆visits)
    (a c : ℕ) (ha : a∈active) (hc : c∈active)
    (hull : ∀ j∈active, a≤j ∧ j≤c)
    (b : LeftGhostChoice (visits \ active) a)
    (d : RightGhostChoice (visits \ active) c)
    (line : ℕ → Line) (η : ℕ → ℝ) :
    leftGhostWeight (visits \ active) a (fun j => hitWeight line η j (line a)) b *
      (∏ j ∈ visits \ active with a≤j ∧ j≤c, (1-hitWeight line η j (line a))) *
      rightGhostWeight (visits \ active) c (fun j => hitWeight line η j (line a)) d =
    if b.elim True (fun t => line t.val=line a) ∧
        d.elim True (fun t => line t.val=line a) then
      ∏ j ∈ visits, (activeChoiceLifespan N visits active hvisits hactive
        a c ha hc hull b d).lifespanVisitFactor 1 η (fun j => 1-η j)
          (fun j => line j=line a) j
    else 0 := by
  by_cases hb : b.elim True (fun t => line t.val=line a)
  · by_cases hd : d.elim True (fun t => line t.val=line a)
    · simp only [hb,hd,and_self,ite_true]
      exact (activeChoice_product visits active hvisits hactive a c ha hc hull b d
        line η hb hd).symm
    · have hz : rightGhostWeight (visits \ active) c
          (fun j => hitWeight line η j (line a)) d = 0 := by
        cases d with
        | none => exact False.elim (hd trivial)
        | some d =>
          simp only [Option.elim_some] at hd
          simp [rightGhostWeight,hitWeight,hd]
      simp [hd,hz]
  · have hz : leftGhostWeight (visits \ active) a
        (fun j => hitWeight line η j (line a)) b = 0 := by
      cases b with
      | none => exact False.elim (hb trivial)
      | some b =>
        simp only [Option.elim_some] at hb
        simp [leftGhostWeight,hitWeight,hb]
    simp [hb,hz]

/-- The complete active one-prime average is a sum of actual lifespan
products, retaining both the active-line and ghost-endpoint indicators. -/
theorem active_lineAverage_lifespans [Fintype Line]
    (visits active : Finset ℕ)
    (hvisits : ∀ j∈visits, j≤N) (hactive : active⊆visits)
    (a c : ℕ) (ha : a∈active) (hc : c∈active)
    (hull : ∀ j∈active, a≤j ∧ j≤c) (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ) ≠ 0)
    (hbase : (Fintype.card Line : ℝ) - ∑ j∈visits, η j ≠ 0) :
    lineAverage visits active line η =
      baseline visits η (Fintype.card Line) * normalizedLineMass visits η (Fintype.card Line) *
      (if ∀ j∈active, line j=line a then
        ∑ b : LeftGhostChoice (visits \ active) a,
        ∑ d : RightGhostChoice (visits \ active) c,
          if b.elim True (fun t => line t.val=line a) ∧
              d.elim True (fun t => line t.val=line a) then
            ∏ j∈visits, (activeChoiceLifespan N visits active hvisits hactive
              a c ha hc hull b d).lifespanVisitFactor 1 η (fun j => 1-η j)
                (fun j => line j=line a) j
          else 0
      else 0) := by
  rw [active_lineAverage visits active line η a c ha (hull a ha).2 hn hbase]
  simp_rw [activeChoice_leaf visits active hvisits hactive a c ha hc hull]

/-- Baseline bounds multiply over all actual finite prime groups. -/
theorem grouped_baseline_pos_le_one
    {I : Type*} [Fintype I] {P : I → Type*} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (visits : ∀ i, P i → Finset ℕ)
    (η : ∀ i, P i → ℕ → ℝ)
    (hη : ∀ i p j, j∈visits i p → 0≤η i p j ∧ η i p j≤1)
    (hsize : ∀ i p, ((visits i p).card : ℝ) < (value i p : ℝ)+1) :
    0 < (∏ i, ∏ p, baseline (visits i p) (η i p) ((value i p : ℝ)+1)) ∧
      (∏ i, ∏ p, baseline (visits i p) (η i p) ((value i p : ℝ)+1)) ≤ 1 := by
  have hloc := fun i p => baseline_pos_le_one (visits i p) (η i p)
    (value i p) (hη i p) (hsize i p)
  constructor
  · exact Finset.prod_pos (fun i hi => Finset.prod_pos (fun p hp => (hloc i p).1))
  · apply Finset.prod_le_one₀
    · intro i hi
      exact Finset.prod_nonneg (fun p hp => (hloc i p).1.le)
    · intro i hi
      exact Finset.prod_le_one₀ (fun p hp => (hloc i p).1.le)
        (fun p hp => (hloc i p).2)

/-- For the actual projective-line model the group product lies in
`(0,1]` whenever every visit set is shorter than the smallest line count.
The literal finite cardinalities are reduced to `p+1`, not postulated. -/
theorem grouped_actual_baseline_pos_le_one
    {I : Type*} [Fintype I] {P : I → Type*} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) [∀ i p, Fact (value i p).Prime]
    (visits : ∀ i, P i → Finset ℕ) (η : ∀ i, P i → ℕ → ℝ)
    (pmin : ℕ) (hmin : ∀ i p, pmin ≤ value i p)
    (hη : ∀ i p j, j∈visits i p → 0≤η i p j ∧ η i p j≤1)
    (hsize : ∀ i p, ((visits i p).card : ℝ) < (pmin : ℝ)+1) :
    0 < (∏ i, ∏ p, baseline (visits i p) (η i p)
      (Fintype.card (Option (ZMod (value i p))))) ∧
      (∏ i, ∏ p, baseline (visits i p) (η i p)
        (Fintype.card (Option (ZMod (value i p))))) ≤ 1 := by
  simp only [Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one]
  apply grouped_baseline_pos_le_one value visits η hη
  intro i p
  exact (hsize i p).trans_le (by exact_mod_cast Nat.add_le_add_right (hmin i p) 1)

end Elliptic.Operator.IndependentLifespanCoefficient
