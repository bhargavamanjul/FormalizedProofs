module

public import Elliptic.Operator.DirtySchur

/-!
# Weighted geometric dirty raw rows

The row sums one distinguished indexed OLD promotion, the actual
omission/product/target-coordinate set, and all other indexed promotions
with their numeric product fixed. Every promotion has the literal
MemoryEdges coefficient and Schur ratio. The bound uses geometric phase
uniqueness and outgoing damping; it does not assume a weighted-row bound.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

abbrev RawDirtyCoordinate (K M : ℕ) := ((Fin K → Fin M) × ℕ) × ℤ

/-- The coordinate set is a disjoint union over its omission/product pair. -/
theorem rawChoiceCoordinates_sum {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β : ℝ) (F : RawDirtyCoordinate K M → ℝ) :
    (∑ c ∈ rawChoiceCoordinates label newProducts p T σ h₀ β, F c) =
      ∑ oz ∈ Finset.univ.product newProducts,
        ∑ h ∈ (targetIntegers β (rawChoiceDeterminant label p T σ oz)).filter
          (fun h => (p : ℤ) ∣ h-h₀), F (oz,h) := by
  classical
  unfold rawChoiceCoordinates
  rw [Finset.sum_biUnion]
  · apply Finset.sum_congr rfl
    intro oz _
    exact Finset.sum_image (fun _ _ _ _ h => (Prod.mk.inj h).2)
  · intro oz _ oz' _ hne
    apply Finset.disjoint_left.mpr
    intro c hc hc'
    obtain ⟨h, _, he⟩ := Finset.mem_image.mp hc
    obtain ⟨h', _, he'⟩ := Finset.mem_image.mp hc'
    exact hne (congrArg Prod.fst (he.trans he'.symm))

/-- Without good-state separation, each omission/product pair still has
at most 33 geometric positions. Nonnegative product weights are retained. -/
theorem rawChoiceCoordinates_sum_product_weight_le {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β : ℝ) (f : ℕ → ℝ) (hf : ∀ Z, 0 ≤ f Z) :
    (∑ c ∈ rawChoiceCoordinates label newProducts p T σ h₀ β, f c.1.2) ≤
      33 * (M : ℝ)^K * ∑ Z ∈ newProducts, f Z := by
  rw [rawChoiceCoordinates_sum]
  calc
    _ ≤ ∑ oz ∈ Finset.univ.product newProducts, 33 * f oz.2 := by
      apply Finset.sum_le_sum
      intro oz _
      simp only [Finset.sum_const, nsmul_eq_mul]
      apply mul_le_mul_of_nonneg_right _ (hf oz.2)
      have hc := (Finset.card_filter_le (targetIntegers β (rawChoiceDeterminant label p T σ oz))
        (fun h => (p : ℤ) ∣ h-h₀)).trans (targetIntegers_card_le β _)
      exact_mod_cast hc
    _ = _ := by
      have he := Finset.sum_product (Finset.univ : Finset (Fin K → Fin M)) newProducts
        (fun oz : (Fin K → Fin M) × ℕ => (33 : ℝ) * f oz.2)
      change (∑ oz ∈ Finset.univ.product newProducts, (33 : ℝ) * f oz.2) = _ at he
      rw [he]
      simp only [Finset.mul_sum, Finset.sum_const, nsmul_eq_mul, Finset.card_univ,
        Fintype.card_fun, Fintype.card_fin, Nat.cast_pow]
      ring_nf

section WeightedRaw
variable {K M B : ℕ} {I : Type*} [Fintype I]
variable {P₀ : Type*} {Line₀ : P₀ → Type*}
variable {P : I → Type*} {Line : ∀ i, P i → Type*}

/-- Actual memory-choice weights attached to the concrete geometric row.
The source unshared prime may depend on its omission tuple, and target
anchors may depend on the actual target coordinate. -/
def indexedRawPromotionRow
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (T : ℕ) (σ : ℤ) (β : ℝ)
    (value₀ : P₀ → ℕ) (ν₀ : P₀ → ℝ) (V₀ : ℝ)
    (sourceAnchor₀ : ∀ p, Line₀ p)
    (m₀ : MemoryState (AnchoredParticle P₀ Line₀) B)
    (store₀ : Bool) (h₀ : Fin m₀.size → ℤ)
    (sourcePrime₀ : (Fin K → Fin M) → P₀)
    (targetAnchor₀ : Fin m₀.size → RawDirtyCoordinate K M → ∀ p, Line₀ p)
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (sourceAnchor : ∀ i p, Line i p)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (sourcePrime : (Fin K → Fin M) → ∀ i, P i)
    (targetAnchor : Fin m₀.size → RawDirtyCoordinate K M → ∀ i p, Line i p)
    (ρ v0 : ℝ) : ℝ :=
  ∑ b : Fin m₀.size,
    ∑ c ∈ rawChoiceCoordinates label newProducts (value₀ (m₀.values b).1) T σ (h₀ b) β,
      edgeWeightedChoice ν₀ V₀ ρ v0 sourceAnchor₀ (targetAnchor₀ b c)
        (sourcePrime₀ c.1.1) m₀ (store₀, Sum.inl b) *
      edgePromotionProductFiber value ν V ρ v0 sourceAnchor (targetAnchor b c)
        (sourcePrime c.1.1) m store c.1.2 * (1 / (M : ℝ)^K)

/-- The actual weighted row inherits `33 B/M^K` with explicit store,
promotion, Schur and pending-damping constants. -/
theorem indexedRawPromotionRow_le
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (T : ℕ) (σ : ℤ) (β δ : ℝ)
    (value₀ : P₀ → ℕ) (ν₀ : P₀ → ℝ) (V₀ : ℝ)
    (sourceAnchor₀ : ∀ p, Line₀ p)
    (m₀ : MemoryState (AnchoredParticle P₀ Line₀) B)
    (store₀ : Bool) (h₀ : Fin m₀.size → ℤ)
    (sourcePrime₀ : (Fin K → Fin M) → P₀)
    (targetAnchor₀ : Fin m₀.size → RawDirtyCoordinate K M → ∀ p, Line₀ p)
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (sourceAnchor : ∀ i p, Line i p)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (sourcePrime : (Fin K → Fin M) → ∀ i, P i)
    (targetAnchor : Fin m₀.size → RawDirtyCoordinate K M → ∀ i p, Line i p)
    (ρ v0 : ℝ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : ∀ b, 0 < value₀ (m₀.values b).1) (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : ∀ b, 2*(16/(value₀ (m₀.values b).1 : ℝ)) < δ)
    (hV₀ : 0 ≤ V₀)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    indexedRawPromotionRow label newProducts T σ β value₀ ν₀ V₀ sourceAnchor₀ m₀
      store₀ h₀ sourcePrime₀ targetAnchor₀ value ν V sourceAnchor m store sourcePrime targetAnchor ρ v0 ≤
      (V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
        (∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1-ρ)) *
        (33 * (B : ℝ) / (M : ℝ)^K) := by
  let C₀ : ℝ := V₀⁻¹ * (v0 ^ store₀.toNat / v0)
  let C : ℝ := ∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1-ρ)
  have hC₀ : 0 ≤ C₀ := by dsimp [C₀]; positivity
  have hC : 0 ≤ C := by
    exact Finset.prod_nonneg fun i _ => by have := hV i; positivity
  have hgeom := rawChoiceCoordinates_sum_averaged_mass_le label newProducts
    (fun b : Fin m₀.size => value₀ (m₀.values b).1) T σ h₀ β δ
    hprime hinj hban hp hσ hsep hwidth
  have hb : (33 : ℝ) * m₀.size / (M : ℝ)^K ≤ 33 * B / (M : ℝ)^K := by
    gcongr
    exact_mod_cast m₀.size_le
  unfold indexedRawPromotionRow
  calc
    _ ≤ ∑ b : Fin m₀.size,
        ∑ _c ∈ rawChoiceCoordinates label newProducts (value₀ (m₀.values b).1) T σ (h₀ b) β,
          C₀ * C * (1 / (M : ℝ)^K) := by
      apply Finset.sum_le_sum
      intro b _
      apply Finset.sum_le_sum
      intro c _
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      apply mul_le_mul
      · exact edgeWeightedChoice_promotion_le_coefficient ν₀ V₀ ρ v0 sourceAnchor₀
          (targetAnchor₀ b c) (sourcePrime₀ c.1.1) m₀ store₀ b hV₀ hρ0 hρ1.le hv0
      · exact edgePromotionProductFiber_le value ν V ρ v0 sourceAnchor (targetAnchor b c)
          (sourcePrime c.1.1) m store c.1.2 hν hV hρ0 hρ1 hv0
      · exact edgePromotionProductFiber_nonneg value ν V ρ v0 sourceAnchor (targetAnchor b c)
          (sourcePrime c.1.1) m store c.1.2 hν hV hρ0 hv0.le
      · exact hC₀
    _ = C₀ * C * (∑ b : Fin m₀.size,
        ∑ _c ∈ rawChoiceCoordinates label newProducts (value₀ (m₀.values b).1) T σ (h₀ b) β,
          1 / (M : ℝ)^K) := by simp only [Finset.mul_sum]
    _ ≤ C₀ * C * (33 * (B : ℝ) / (M : ℝ)^K) :=
      mul_le_mul_of_nonneg_left (hgeom.trans hb) (mul_nonneg hC₀ hC)
    _ = _ := rfl

/-- The same literal row has a crude bound on every fresh draw. It needs
no phase separation, primality, or source distinctness. -/
theorem indexedRawPromotionRow_le_crude
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (T : ℕ) (σ : ℤ) (β : ℝ)
    (value₀ : P₀ → ℕ) (ν₀ : P₀ → ℝ) (V₀ : ℝ)
    (sourceAnchor₀ : ∀ p, Line₀ p)
    (m₀ : MemoryState (AnchoredParticle P₀ Line₀) B)
    (store₀ : Bool) (h₀ : Fin m₀.size → ℤ)
    (sourcePrime₀ : (Fin K → Fin M) → P₀)
    (targetAnchor₀ : Fin m₀.size → RawDirtyCoordinate K M → ∀ p, Line₀ p)
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (sourceAnchor : ∀ i p, Line i p)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (sourcePrime : (Fin K → Fin M) → ∀ i, P i)
    (targetAnchor : Fin m₀.size → RawDirtyCoordinate K M → ∀ i p, Line i p)
    (ρ v0 : ℝ) (hM : 0 < M)
    (hV₀ : 0 ≤ V₀) (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    indexedRawPromotionRow label newProducts T σ β value₀ ν₀ V₀ sourceAnchor₀ m₀
      store₀ h₀ sourcePrime₀ targetAnchor₀ value ν V sourceAnchor m store sourcePrime targetAnchor ρ v0 ≤
      (V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
        (∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0)) *
        (33 * (B : ℝ) ^ (Fintype.card I + 1)) := by
  let C₀ : ℝ := V₀⁻¹ * (v0 ^ store₀.toNat / v0)
  let C : ℝ := ∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0)
  let f := promotionProductMultiplicity value m
  have hC₀ : 0 ≤ C₀ := by dsimp [C₀]; positivity
  have hC : 0 ≤ C := by
    exact Finset.prod_nonneg fun i _ => by have := hV i; positivity
  have hf : ∀ Z, 0 ≤ f Z := promotionProductMultiplicity_nonneg value m
  have hmass := promotionProductMultiplicity_sum_le value m newProducts
  have hM0 : (M : ℝ)^K ≠ 0 := pow_ne_zero _ (by exact_mod_cast hM.ne')
  have hper (b : Fin m₀.size) :
      (∑ c ∈ rawChoiceCoordinates label newProducts (value₀ (m₀.values b).1) T σ (h₀ b) β,
        edgeWeightedChoice ν₀ V₀ ρ v0 sourceAnchor₀ (targetAnchor₀ b c)
          (sourcePrime₀ c.1.1) m₀ (store₀, Sum.inl b) *
        edgePromotionProductFiber value ν V ρ v0 sourceAnchor (targetAnchor b c)
          (sourcePrime c.1.1) m store c.1.2 * (1 / (M : ℝ)^K)) ≤
        C₀ * C * (33 * (B : ℝ)^Fintype.card I) := by
    have hgeom := rawChoiceCoordinates_sum_product_weight_le label newProducts
      (value₀ (m₀.values b).1) T σ (h₀ b) β f hf
    calc
      _ ≤ ∑ c ∈ rawChoiceCoordinates label newProducts (value₀ (m₀.values b).1) T σ (h₀ b) β,
          C₀ * (f c.1.2 * C) * (1 / (M : ℝ)^K) := by
        apply Finset.sum_le_sum
        intro c _
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        apply mul_le_mul
        · exact edgeWeightedChoice_promotion_le_coefficient ν₀ V₀ ρ v0 sourceAnchor₀
            (targetAnchor₀ b c) (sourcePrime₀ c.1.1) m₀ store₀ b hV₀ hρ0 hρ1 hv0
        · exact edgePromotionProductFiber_le_crude value ν V ρ v0 sourceAnchor (targetAnchor b c)
            (sourcePrime c.1.1) m store c.1.2 hν hV hρ0 hρ1 hv0
        · exact edgePromotionProductFiber_nonneg value ν V ρ v0 sourceAnchor (targetAnchor b c)
            (sourcePrime c.1.1) m store c.1.2 hν hV hρ0 hv0.le
        · exact hC₀
      _ = C₀ * C * (∑ c ∈ rawChoiceCoordinates label newProducts
          (value₀ (m₀.values b).1) T σ (h₀ b) β, f c.1.2) / (M : ℝ)^K := by
        simp only [Finset.mul_sum, Finset.sum_div]
        apply Finset.sum_congr rfl
        intro c _
        ring
      _ ≤ C₀ * C * (33 * (M : ℝ)^K * (B : ℝ)^Fintype.card I) / (M : ℝ)^K := by
        gcongr
        exact hgeom.trans (mul_le_mul_of_nonneg_left hmass (by positivity))
      _ = _ := by field_simp [hM0]
  unfold indexedRawPromotionRow
  calc
    _ ≤ ∑ _b : Fin m₀.size, C₀ * C * (33 * (B : ℝ)^Fintype.card I) :=
      Finset.sum_le_sum fun b _ => hper b
    _ = C₀ * C * (33 * (B : ℝ)^Fintype.card I) * m₀.size := by simp; ring
    _ ≤ C₀ * C * (33 * (B : ℝ)^Fintype.card I) * B := by
      gcongr
      exact_mod_cast m₀.size_le
    _ = _ := by rw [pow_succ]; ring

end WeightedRaw
end Elliptic.Operator
