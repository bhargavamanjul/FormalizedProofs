module

public import Elliptic.Operator.GlobalBirthFibers
public import Elliptic.Operator.SourceMemoryEdges
public import Artin.MarkedSource

/-!
# Numerical distinctness of all actual births

The disjoint prime bands convert groupwise label identities into identities
of numerical primes. Initial active labels, later fresh active labels and
ghost labels are partition addresses, not interchangeable ordering fibers.
Only the ghost batches carry the factorials from their actual tuple choices.
The eventual band-separation threshold below is for each fixed family of
exponents; no uniform separation in arbitrarily close exponents is claimed.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
open Filter
attribute [local instance] Classical.propDecidable

/-- The three different sources of a prime's unique birth. -/
inductive NumericBirthKind where
  | initialActive
  | freshActive
  | ghost
  deriving DecidableEq, Fintype

/-- The actual birth address, keeping initial and later active births
separate from ghost batches. -/
def numericBirthKind {N : ℕ} (L : PrimeLifespan N) : NumericBirthKind :=
  if L.birth ∈ L.active then
    if L.birth = 0 then .initialActive else .freshActive
  else .ghost

/-- The three-way birth partition at one visit. Active births have no
ordering-fiber factorial attached by this definition. -/
def numericBirthSet {P : Type*} {N : ℕ} (S : Finset P)
    (L : P → PrimeLifespan N) (j : ℕ) (k : NumericBirthKind) : Finset P :=
  S.filter (fun p => (L p).birth = j ∧ numericBirthKind (L p) = k)

theorem numericBirthSet_initial {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    numericBirthSet S L j .initialActive =
      if j = 0 then LifespanSchedule.activeBirths S L j else ∅ := by
  classical
  ext p
  by_cases hb : (L p).birth = j
  · subst j
    by_cases ha : (L p).birth ∈ (L p).active <;>
      by_cases hz : (L p).birth = 0 <;>
      simp_all [numericBirthSet, numericBirthKind, LifespanSchedule.activeBirths,
        PrimeLifespan.freshActive]
  · by_cases hj : j = 0
    · subst j
      simp [numericBirthSet, LifespanSchedule.activeBirths, PrimeLifespan.freshActive,
        hb, Ne.symm hb]
    · simp [numericBirthSet, hb, hj]

theorem numericBirthSet_fresh {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    numericBirthSet S L j .freshActive =
      if j = 0 then ∅ else LifespanSchedule.activeBirths S L j := by
  classical
  ext p
  by_cases hb : (L p).birth = j
  · subst j
    by_cases ha : (L p).birth ∈ (L p).active <;>
      by_cases hz : (L p).birth = 0 <;>
      simp_all [numericBirthSet, numericBirthKind, LifespanSchedule.activeBirths,
        PrimeLifespan.freshActive]
  · by_cases hj : j = 0
    · subst j
      simp [numericBirthSet, hb]
    · simp [numericBirthSet, LifespanSchedule.activeBirths, PrimeLifespan.freshActive,
        hb, Ne.symm hb, hj]

theorem numericBirthSet_ghost {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    numericBirthSet S L j .ghost = LifespanSchedule.births S L j := by
  classical
  ext p
  by_cases hb : (L p).birth = j
  · subst j
    by_cases ha : (L p).birth ∈ (L p).active <;>
      by_cases hz : (L p).birth = 0 <;>
      simp_all [numericBirthSet, numericBirthKind, LifespanSchedule.births,
        PrimeLifespan.ghostBorn]
  · simp [numericBirthSet, LifespanSchedule.births, PrimeLifespan.ghostBorn,
      hb, Ne.symm hb]

/-- All births, as addresses with their actual group label. -/
abbrev NumericBirthAddress {P : Type*} {N : ℕ} (S : Finset P)
    (L : P → PrimeLifespan N) :=
  {a : Fin (N+1) × NumericBirthKind × P //
    a.2.2 ∈ numericBirthSet S L a.1.val a.2.1}

/-- Every prime has exactly one chronological birth address. This proves
uniqueness across the three kinds as well as across distinct visits. -/
theorem numericBirthAddress_label_injective {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) :
    Function.Injective (fun a : NumericBirthAddress S L => a.val.2.2) := by
  intro a b h
  have ha := (Finset.mem_filter.mp a.property).2
  have hb := (Finset.mem_filter.mp b.property).2
  apply Subtype.ext
  apply Prod.ext
  · exact Fin.ext (ha.1.symm.trans ((congrArg (fun p => (L p).birth) h).trans hb.1))
  · exact Prod.ext (ha.2.symm.trans ((congrArg (fun p => numericBirthKind (L p)) h).trans hb.2)) h

/-- No support prime is lost from the chronological three-way partition. -/
theorem numericBirthAddress_label_range {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (p : P) :
    (∃ a : NumericBirthAddress S L, a.val.2.2 = p) ↔ p ∈ S := by
  constructor
  · rintro ⟨a,rfl⟩
    exact (Finset.mem_filter.mp a.property).1
  · intro hp
    refine ⟨⟨⟨⟨(L p).birth, Nat.lt_succ_of_le
      ((L p).birth_le_death.trans (L p).death_le)⟩, numericBirthKind (L p), p⟩, ?_⟩,rfl⟩
    exact Finset.mem_filter.mpr ⟨hp,rfl,rfl⟩

/-- Active births are individual partition addresses. Only ghost births
are indexed by the slots of the actual fresh tuple. -/
abbrev MixedBirthOccurrence {P : Type*} {N : ℕ} (S : Finset P)
    (L : P → PrimeLifespan N) :=
  {a : NumericBirthAddress S L // a.val.2.1 ≠ .ghost} ⊕
    ((j : Fin (N+1)) × Fin (LifespanSchedule.births S L j.val).card)

/-- Turn actual ghost tuple slots and the initial/fresh active labels into
the same chronological partition, without assigning factorials to active births. -/
def mixedBirthAddress {P : Type*} {N : ℕ} (S : Finset P)
    (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val)) :
    MixedBirthOccurrence S L → NumericBirthAddress S L
  | .inl a => a.val
  | .inr ji => ⟨⟨ji.1, .ghost, (x ji.1).val ji.2⟩, by
      rw [numericBirthSet_ghost]
      exact ((x ji.1).property.2 _).mpr ⟨ji.2,rfl⟩⟩

/-- Different actual ghost tuple slots, or different initial/fresh active
birth addresses, cannot name the same chronological birth. -/
theorem mixedBirthAddress_injective {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val)) :
    Function.Injective (mixedBirthAddress S L x) := by
  intro a b h
  cases a with
  | inl a =>
    cases b with
    | inl b => exact congrArg Sum.inl (Subtype.ext h)
    | inr b =>
      have hk := congrArg (fun z : NumericBirthAddress S L => z.val.2.1) h
      exact (a.property hk).elim
  | inr a =>
    cases b with
    | inl b =>
      have hk := congrArg (fun z : NumericBirthAddress S L => z.val.2.1) h
      exact (b.property hk.symm).elim
    | inr b =>
      have hj := congrArg (fun z : NumericBirthAddress S L => z.val.1) h
      change a.1 = b.1 at hj
      rcases a with ⟨j,k⟩
      rcases b with ⟨j',k'⟩
      dsimp only at hj
      subst j'
      have hp := congrArg (fun z : NumericBirthAddress S L => z.val.2.2) h
      have hk : k = k' := (x j).property.1 hp
      subst k'
      rfl

/-- Actual ordering choices preserve global label distinctness when all
three kinds of birth are present. -/
theorem mixedBirth_label_injective {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val)) :
    Function.Injective (fun a : MixedBirthOccurrence S L =>
      (mixedBirthAddress S L x a).val.2.2) :=
  (numericBirthAddress_label_injective S L).comp (mixedBirthAddress_injective S L x)

/-- Every chronological address occurs among the actual active labels
or in an actual ghost tuple slot. -/
theorem mixedBirthAddress_surjective {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val)) :
    Function.Surjective (mixedBirthAddress S L x) := by
  intro a
  by_cases hk : a.val.2.1 = .ghost
  · have hp : a.val.2.2 ∈ LifespanSchedule.births S L a.val.1.val := by
      have h := a.property
      rw [hk, numericBirthSet_ghost] at h
      exact h
    obtain ⟨k,hk'⟩ := ((x a.val.1).property.2 _).mp hp
    refine ⟨.inr ⟨a.val.1,k⟩, ?_⟩
    apply Subtype.ext
    exact Prod.ext rfl (Prod.ext hk.symm hk')
  · exact ⟨.inl ⟨a,hk⟩,rfl⟩

/-- Exact equivalence between actual birth occurrences and support labels.
No operation coefficient is asserted here; this is the birth partition. -/
def mixedBirthSupportEquiv {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val)) :
    MixedBirthOccurrence S L ≃ ↥S :=
  Equiv.ofBijective
    (fun a => ⟨(mixedBirthAddress S L x a).val.2.2,
      (Finset.mem_filter.mp (mixedBirthAddress S L x a).property).1⟩)
    ⟨fun _ _ h => mixedBirth_label_injective S L x (congrArg Subtype.val h), by
      intro p
      obtain ⟨a,ha⟩ := (numericBirthAddress_label_range S L p.val).mpr p.property
      obtain ⟨b,rfl⟩ := mixedBirthAddress_surjective S L x a
      exact ⟨b, Subtype.ext ha⟩⟩

/-- Each support prime contributes exactly one birth mass when the product
is taken over all actual active labels and ghost tuple slots. -/
theorem mixedBirth_product {P R : Type*} {N : ℕ} [Fintype P] [CommMonoid R]
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) => LifespanSchedule.births S L j.val))
    (ν : P → R) :
    (∏ a : MixedBirthOccurrence S L, ν (mixedBirthAddress S L x a).val.2.2) =
      ∏ p ∈ S, ν p := by
  classical
  calc
    _ = ∏ p : ↥S, ν p.val :=
      Fintype.prod_equiv (mixedBirthSupportEquiv S L x) _ _ (fun _ => rfl)
    _ = _ := Finset.prod_coe_sort S ν

/-- Numerical values recover the group as well as the subtype label,
because the actual groups are disjoint. -/
theorem disjointGroup_value_injective {I : Type*} (groups : I → Finset ℕ)
    (hdis : Pairwise (fun i j => Disjoint (groups i) (groups j))) :
    Function.Injective (fun p : (i : I) × (groups i : Type) => p.2.val) := by
  rintro ⟨i,p⟩ ⟨j,q⟩ hpq
  change p.val = q.val at hpq
  have hij : i = j := by
    by_contra hne
    exact Finset.disjoint_left.mp (hdis hne) p.property (hpq.symm ▸ q.property)
  subst j
  have hp : p = q := Subtype.ext hpq
  subst q
  rfl

/-- The numerical restriction on all births follows from the concrete
bands and the actual unique chronological birth partition. -/
theorem disjointGroup_numericBirth_injective {I : Type*} {N : ℕ}
    (groups : I → Finset ℕ)
    (hdis : Pairwise (fun i j => Disjoint (groups i) (groups j)))
    (S : ∀ i, Finset (groups i : Type))
    (L : ∀ i, ↥(groups i) → PrimeLifespan N) :
    Function.Injective (fun a : (i : I) × NumericBirthAddress (S i) (L i) =>
      a.2.val.2.2.val) := by
  rintro ⟨i,a⟩ ⟨j,b⟩ hab
  have hij : i = j := by
    have he := disjointGroup_value_injective groups hdis
      (a₁:=⟨i,a.val.2.2⟩) (a₂:=⟨j,b.val.2.2⟩) hab
    exact congrArg Sigma.fst he
  subst j
  have hp : a.val.2.2 = b.val.2.2 := Subtype.ext hab
  have ha := numericBirthAddress_label_injective (S i) (L i) hp
  subst b
  rfl

/-- The actual combined birth restriction, including every ghost tuple
slot and each initial/fresh active label, uses numerical primes globally. -/
theorem disjointGroup_mixedBirth_injective {I : Type*} {N : ℕ}
    (groups : I → Finset ℕ)
    (hdis : Pairwise (fun i j => Disjoint (groups i) (groups j)))
    (S : ∀ i, Finset (groups i : Type))
    (L : ∀ i, ↥(groups i) → PrimeLifespan N)
    (x : ∀ i, GlobalBirthFiber (fun j : Fin (N+1) =>
      LifespanSchedule.births (S i) (L i) j.val)) :
    Function.Injective (fun a : (i : I) × MixedBirthOccurrence (S i) (L i) =>
      (mixedBirthAddress (S a.1) (L a.1) (x a.1) a.2).val.2.2.val) := by
  rintro ⟨i,a⟩ ⟨j,b⟩ hab
  have he := disjointGroup_numericBirth_injective groups hdis S L
    (a₁:=⟨i,mixedBirthAddress (S i) (L i) (x i) a⟩)
    (a₂:=⟨j,mixedBirthAddress (S j) (L j) (x j) b⟩) hab
  have hij : i = j := congrArg Sigma.fst he
  subst j
  have haddr : mixedBirthAddress (S i) (L i) (x i) a =
      mixedBirthAddress (S i) (L i) (x i) b := by
    exact eq_of_heq (Sigma.mk.inj_iff.mp he).2
  have ha := mixedBirthAddress_injective (S i) (L i) (x i) haddr
  subst b
  rfl

/-- The literal closed source intervals are eventually disjoint for each
fixed family of strictly increasing exponents. -/
theorem sourceBands_eventually_disjoint {K : ℕ} (bands : Artin.MarkedSource.Bands K) :
    ∀ᶠ x : ℝ in atTop, Pairwise (fun i j =>
      Disjoint (bands.group x i) (bands.group x j)) := by
  have h := Artin.MarkedBandTail.eventual_bands_disjoint Finset.univ bands.exponent
    (fun _ _ _ _ he => bands.increasing.injective he)
  filter_upwards [h] with x hx
  intro i j hij
  simpa only [Artin.MarkedSource.Bands.group_eq_markedBandTail] using
    hx i (Finset.mem_univ _) j (Finset.mem_univ _) hij

/-- One threshold precedes all support sets and all lifespan assignments
for the fixed actual source bands. It gives global numerical distinctness
simultaneously for initial active, fresh active, and ghost births. -/
theorem sourceBands_eventually_numericBirth_injective {K : ℕ}
    (bands : Artin.MarkedSource.Bands K) :
    ∀ᶠ x : ℝ in atTop, ∀ N : ℕ,
      ∀ S : ∀ i, Finset (bands.group x i : Type),
      ∀ L : ∀ i, ↥(bands.group x i) → PrimeLifespan N,
      Function.Injective (fun a : (i : Fin K) × NumericBirthAddress (S i) (L i) =>
        a.2.val.2.2.val) := by
  filter_upwards [sourceBands_eventually_disjoint bands] with x hx
  intro N S L
  exact disjointGroup_numericBirth_injective (bands.group x) hx S L

/-- Specialization to the actual manuscript bands, uniformly in every
support, lifespan assignment and actual ghost-batch ordering once the fixed
bands have separated. -/
theorem sourceBands_eventually_mixedBirth_injective {K : ℕ}
    (bands : Artin.MarkedSource.Bands K) :
    ∀ᶠ x : ℝ in atTop, ∀ N : ℕ,
      ∀ S : ∀ i, Finset (bands.group x i : Type),
      ∀ L : ∀ i, ↥(bands.group x i) → PrimeLifespan N,
      ∀ tuples : ∀ i, GlobalBirthFiber (fun j : Fin (N+1) =>
        LifespanSchedule.births (S i) (L i) j.val),
      Function.Injective (fun a : (i : Fin K) × MixedBirthOccurrence (S i) (L i) =>
        (mixedBirthAddress (S a.1) (L a.1) (tuples a.1) a.2).val.2.2.val) := by
  filter_upwards [sourceBands_eventually_disjoint bands] with x hx
  intro N S L tuples
  exact disjointGroup_mixedBirth_injective (bands.group x) hx S L tuples

/-- The actual numerical cross-edge ban excludes redrawing any source
active label as the new unshared target. No global value injectivity is
assumed: the contradiction is within the literal cross-edge label map. -/
theorem sourceCrossEdgeBan_target_not_source {I : Type*} {P : I → Type*} {J : ℕ}
    (value : ∀ i, P i → ℕ) {a b : PhysicalActiveLists P J}
    (hban : sourceCrossEdgeBan value a b) (i : I) (k : Fin (J+1)) :
    b i (Fin.last J) ≠ a i k := by
  refine Fin.lastCases ?_ (fun t => ?_) k
  · intro he
    have hv := congrArg (value i) he
    have ht := hban.2 (a₁:=(i,Sum.inr true)) (a₂:=(i,Sum.inr false)) hv
    have hs := congrArg Prod.snd ht
    simp only [Sum.inr.injEq] at hs
    cases hs
  · intro he
    have hv := congrArg (value i) he
    have ht := hban.2 (a₁:=(i,Sum.inr true)) (a₂:=(i,Sum.inl t)) hv
    have hs := congrArg Prod.snd ht
    cases hs

end Elliptic.Operator
