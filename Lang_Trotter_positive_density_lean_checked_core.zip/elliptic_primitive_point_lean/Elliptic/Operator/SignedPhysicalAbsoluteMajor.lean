module
public import Elliptic.Operator.SignedPhysicalPairSquare
public import Elliptic.Operator.ProductDirichletMeanSquare
public import Elliptic.Operator.MajorArcMeasure

/-! Absolute major-arc control through the actual divisor-square moment.
The determinant strip has bounded degree on the product indices mn and rs. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteMajor
open scoped BigOperators ComplexConjugate
open SignedPhysicalPairBridge
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- The elementary number of integers in any real interval of radius C. -/
theorem interval_card_le (s : Finset ℕ) (c C : ℝ) (hC : 0≤C)
    (hs : ∀v∈s,|(v:ℝ)-c|≤C) : (s.card:ℝ)≤2*C+1 := by
  let t : Finset ℤ := Finset.Icc ⌈c-C⌉ ⌊c+C⌋
  have hh : s.image (fun v : ℕ=>(v:ℤ))⊆t := by
    intro v hv
    obtain ⟨n,hn,rfl⟩ := Finset.mem_image.mp hv
    have h := abs_le.mp (hs n hn)
    exact Finset.mem_Icc.mpr ⟨Int.ceil_le.mpr (by exact_mod_cast (by linarith : c-C≤(n:ℝ))),
      Int.le_floor.mpr (by exact_mod_cast (by linarith : (n:ℝ)≤c+C))⟩
  have hcard : s.card≤t.card := by
    calc
      _ = (s.image (fun v : ℕ=>(v:ℤ))).card :=
        (Finset.card_image_of_injective _ (by intro m n h; change (m:ℤ)=(n:ℤ) at h; exact_mod_cast h)).symm
      _ ≤ _ := Finset.card_le_card hh
  apply (show (s.card:ℝ)≤t.card by exact_mod_cast hcard).trans
  dsimp only [t]
  rw [Int.card_Icc]
  by_cases hnon : 0≤⌊c+C⌋+1-⌈c-C⌉
  · have he : ((⌊c+C⌋+1-⌈c-C⌉).toNat:ℝ)=((⌊c+C⌋+1-⌈c-C⌉:ℤ):ℝ) := by
      exact_mod_cast Int.toNat_of_nonneg hnon
    rw [he]
    have hl := Int.le_ceil (c-C)
    have hu := Int.floor_le (c+C)
    push_cast
    linarith
  · rw [Int.toNat_of_nonpos (by omega)]
    norm_num
    linarith

/-- A strip |bu-av|≤CY has at most 2C+1 neighbors at each product index. -/
theorem strip_row_card (s : Finset ℕ) (a b u : ℕ) (C Y : ℝ)
    (hC : 0≤C) (hY : 0<Y) (ha : Y≤(a:ℝ)) :
    ((s.filter (fun v : ℕ=>|(b:ℝ)*u-(a:ℝ)*(v:ℝ)|≤C*Y)).card:ℝ)≤2*C+1 := by
  have ha0 : (0:ℝ)<a := hY.trans_le ha
  apply interval_card_le _ ((b:ℝ)*u/a) C hC
  intro v hv
  have hh := (Finset.mem_filter.mp hv).2
  have he : |(v:ℝ)-(b:ℝ)*u/a|=|(b:ℝ)*u-(a:ℝ)*v|/a := by
    calc
      _ = |((a:ℝ)*v-(b:ℝ)*u)/a| := by
        congr 1
        field_simp
      _ = _ := by rw [abs_div,abs_of_pos ha0,abs_sub_comm]
  rw [he]
  exact (div_le_iff₀ ha0).mpr (hh.trans (mul_le_mul_of_nonneg_left ha hC))

/-- Bounded degree gives an L2 bound with no dependence on the length of
this product interval. -/
theorem bounded_degree_sum (s : Finset ℕ) (R : ℕ→ℕ→Prop) (f : ℕ→ℝ) (D : ℝ)
    (hrow : ∀u∈s,((s.filter (R u)).card:ℝ)≤D)
    (hcol : ∀v∈s,((s.filter (fun u=>R u v)).card:ℝ)≤D) :
    (∑u∈s,∑v∈s,if R u v then f u*f v else 0)≤D*∑u∈s,(f u)^2 := by
  have hfirst : (∑u∈s,∑v∈s,if R u v then (f u)^2 else 0)≤D*∑u∈s,(f u)^2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro u hu
    rw [←Finset.sum_filter]
    simpa using mul_le_mul_of_nonneg_right (hrow u hu) (sq_nonneg (f u))
  have hsecond : (∑u∈s,∑v∈s,if R u v then (f v)^2 else 0)≤D*∑v∈s,(f v)^2 := by
    rw [Finset.sum_comm,Finset.mul_sum]
    apply Finset.sum_le_sum
    intro v hv
    rw [←Finset.sum_filter]
    simpa using mul_le_mul_of_nonneg_right (hcol v hv) (sq_nonneg (f v))
  have hh : 2*(∑u∈s,∑v∈s,if R u v then f u*f v else 0)≤
      (∑u∈s,∑v∈s,if R u v then (f u)^2 else 0)+
      (∑u∈s,∑v∈s,if R u v then (f v)^2 else 0) := by
    simp only [Finset.mul_sum,←Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro u hu
    apply Finset.sum_le_sum
    intro v hv
    by_cases hr : R u v <;> simp only [hr,ite_true,ite_false,mul_zero,add_zero] <;>
      nlinarith [sq_nonneg (f u-f v)]
  linarith

/-- Literal divisor weights on the actual determinant strip. -/
theorem divisor_strip_sum (N a b : ℕ) (C Y : ℝ) (hC : 0≤C) (hY : 0<Y)
    (ha : Y≤(a:ℝ)) (hb : Y≤(b:ℝ)) :
    (∑u∈Finset.Icc 1 N,∑v∈Finset.Icc 1 N,
      if |(b:ℝ)*u-(a:ℝ)*v|≤C*Y then (u.divisors.card:ℝ)*v.divisors.card else 0)≤
      (2*C+1)*∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2 := by
  apply bounded_degree_sum
  · intro u hu
    exact strip_row_card _ a b u C Y hC hY ha
  · intro v hv
    have he : (fun u : ℕ=>|(b:ℝ)*u-(a:ℝ)*v|≤C*Y)=
        (fun u : ℕ=>|(a:ℝ)*v-(b:ℝ)*u|≤C*Y) := by
      funext u
      rw [abs_sub_comm]
    simp only [he]
    exact strip_row_card _ b a v C Y hC hY hb

/-- Exact grouping of coefficient indices by their product. -/
theorem sum_product_fibers (s t : Finset ℕ) (N : ℕ)
    (hprod : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N) (F : ℕ→ℝ) :
    (∑m∈s,∑n∈t,F (m*n))=
      ∑u∈Finset.Icc 1 N,(ProductDirichletMeanSquare.fiber s t u).card*F u := by
  have hmap : ∀p∈s×ˢt,p.1*p.2∈Finset.Icc 1 N := by
    intro p hp
    exact hprod p.1 (Finset.mem_product.mp hp).1 p.2 (Finset.mem_product.mp hp).2
  calc
    _ = ∑p∈s×ˢt,F (p.1*p.2) := by rw [Finset.sum_product]
    _ = ∑u∈Finset.Icc 1 N,∑p∈(s×ˢt).filter (fun p=>p.1*p.2=u),F (p.1*p.2) := by
      symm
      exact Finset.sum_fiberwise_of_maps_to hmap _
    _ = _ := by
      apply Finset.sum_congr rfl
      intro u hu
      calc
        _ = ∑p∈(s×ˢt).filter (fun p=>p.1*p.2=u),F u := by
          apply Finset.sum_congr rfl
          intro p hp
          rw [(Finset.mem_filter.mp hp).2]
        _ = _ := by simp [ProductDirichletMeanSquare.fiber]

/-- The actual number of four coefficient indices in the determinant strip. -/
theorem coefficient_strip_count (s t : Finset ℕ) (N a b : ℕ)
    (hs : ∀m∈s,0<m) (hprod : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)
    (C Y : ℝ) (hC : 0≤C) (hY : 0<Y) (ha : Y≤(a:ℝ)) (hb : Y≤(b:ℝ)) :
    (∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      if |(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ)|≤C*Y then (1:ℝ) else 0)≤
      (2*C+1)*∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2 := by
  let R := fun u v : ℕ=>|(b:ℝ)*u-(a:ℝ)*v|≤C*Y
  change (∑m∈s,∑n∈t,∑r∈s,∑q∈t,if R (m*n) (r*q) then (1:ℝ) else 0)≤_
  rw [sum_product_fibers s t N hprod (fun u=>∑r∈s,∑q∈t,if R u (r*q) then (1:ℝ) else 0)]
  have hi (u : ℕ) := sum_product_fibers s t N hprod (fun v=>if R u v then (1:ℝ) else 0)
  simp only [hi]
  calc
    _ = ∑u∈Finset.Icc 1 N,∑v∈Finset.Icc 1 N,
        if R u v then ((ProductDirichletMeanSquare.fiber s t u).card:ℝ)*
          (ProductDirichletMeanSquare.fiber s t v).card else (0:ℝ) := by
      simp only [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro u hu
      apply Finset.sum_congr rfl
      intro v hv
      split_ifs <;> simp
    _ ≤ ∑u∈Finset.Icc 1 N,∑v∈Finset.Icc 1 N,
        if R u v then (u.divisors.card:ℝ)*v.divisors.card else 0 := by
      apply Finset.sum_le_sum
      intro u hu
      apply Finset.sum_le_sum
      intro v hv
      split_ifs
      · exact mul_le_mul
          (by exact_mod_cast ProductDirichletMeanSquare.fiber_card_le_divisors s t u (Finset.mem_Icc.mp hu).1 hs)
          (by exact_mod_cast ProductDirichletMeanSquare.fiber_card_le_divisors s t v (Finset.mem_Icc.mp hv).1 hs)
          (by positivity) (by positivity)
      · rfl
    _ ≤ _ := divisor_strip_sum N a b C Y hC hY ha hb

/-- Pointwise major norm including its actual determinant-strip support. -/
theorem scalarMajor_norm_le (a b m n r q : ℕ) (Y H C : ℝ)
    (hY : 0<Y) (hH : 0≤H) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (Aη Aψ A B : ℝ) (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hψsupp : ∀v,ψ v≠0→|v|≤C)
    (hm : ‖α m‖≤A) (hr : ‖α r‖≤A) (hn : ‖β n‖≤B) (hq : ‖β q‖≤B) :
    ‖scalarMajor a b m n r q Y H η ψ α β‖≤
      (Aη^2*A^2*B^2*Aψ*(4*H^3/Y))*
        (if |(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ)|≤C*Y then 1 else 0) := by
  have hcast : (scalarDet a b m n r q:ℝ)=(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ) := by
    simp only [scalarDet,Int.cast_sub,Int.cast_mul,Int.cast_natCast,Nat.cast_mul]
    ring
  by_cases ht : |(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ)|≤C*Y
  · rw [ite_eq_left ht,mul_one]
    unfold scalarMajor
    simp only [norm_mul,Complex.norm_conj]
    have hF := MajorArcMeasure.sourceMajorArcs_fourier_norm_le H Y hH hY (scalarDet a b m n r q+b-a)
    calc
      _ ≤ Aη*Aη*A*B*A*B*Aψ*(4*H^3/Y) := by
        gcongr <;> first | exact hη _ | exact hψ _ | assumption
      _ = _ := by ring
  · have hzero : ψ ((scalarDet a b m n r q:ℝ)/Y)=0 := by
      by_contra hn
      have hh := hψsupp _ hn
      rw [abs_div,abs_of_pos hY,hcast] at hh
      exact ht ((div_le_iff₀ hY).mp hh)
    rw [ite_eq_right ht]
    simp [scalarMajor,hzero]

/-- Absolute scalar major sum for a fixed pair of selected products.
Its dependence on Y is the required reciprocal factor. -/
theorem scalarMajor_sum_le (s t : Finset ℕ) (N a b : ℕ)
    (hs : ∀m∈s,0<m) (hprod : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)
    (C Y H : ℝ) (hC : 0≤C) (hY : 0<Y) (hH : 0≤H)
    (ha : Y≤(a:ℝ)) (hb : Y≤(b:ℝ)) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (Aη Aψ A B : ℝ) (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ) (hψsupp : ∀v,ψ v≠0→|v|≤C)
    (hα : ∀m∈s,‖α m‖≤A) (hβ : ∀n∈t,‖β n‖≤B) :
    (∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarMajor a b m n r q Y H η ψ α β‖)≤
      (Aη^2*A^2*B^2*Aψ*(4*H^3/Y))*(2*C+1)*
        ∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2 := by
  let M := Aη^2*A^2*B^2*Aψ*(4*H^3/Y)
  have hM : 0≤M := by dsimp [M]; positivity
  calc
    _ ≤ ∑m∈s,∑n∈t,∑r∈s,∑q∈t,M*
        (if |(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ)|≤C*Y then 1 else 0) := by
      apply Finset.sum_le_sum
      intro m hm
      apply Finset.sum_le_sum
      intro n hn
      apply Finset.sum_le_sum
      intro r hr
      apply Finset.sum_le_sum
      intro q hq
      exact scalarMajor_norm_le a b m n r q Y H C hY hH η ψ α β Aη Aψ A B hAη hAψ hA hB
        hη hψ hψsupp (hα m hm) (hα r hr) (hβ n hn) (hβ q hq)
    _ = M*(∑m∈s,∑n∈t,∑r∈s,∑q∈t,
        if |(b:ℝ)*(m*n:ℕ)-(a:ℝ)*(r*q:ℕ)|≤C*Y then (1:ℝ) else 0) := by
      simp only [Finset.mul_sum]
    _ ≤ M*((2*C+1)*∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2) :=
      mul_le_mul_of_nonneg_left (coefficient_strip_count s t N a b hs hprod C Y hC hY ha hb) hM
    _ = _ := by ring

/-- Injective selected products leave at most 4Y labels on the cutoff support. -/
theorem supported_label_card {ι : Type*} [Fintype ι] (p : ι→ℕ)
    (hinj : Function.Injective p) (Y : ℝ) (hY : 0<Y) (η : ℝ→ℂ)
    (hηsupp : ∀v,η v≠0→1≤v ∧ v≤4) :
    ((Finset.univ.filter (fun i=>η ((p i:ℝ)/Y)≠0)).card:ℝ)≤4*Y := by
  let s := Finset.univ.filter (fun i=>η ((p i:ℝ)/Y)≠0)
  have hsub : s.image p⊆Finset.Icc 1 ⌊4*Y⌋₊ := by
    intro a ha
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp ha
    have hh := hηsupp _ (Finset.mem_filter.mp hi).2
    have hlo : Y≤(p i:ℝ) := by simpa using (le_div_iff₀ hY).mp hh.1
    have hhi : (p i:ℝ)≤4*Y := (div_le_iff₀ hY).mp hh.2
    exact Finset.mem_Icc.mpr ⟨by exact_mod_cast (hY.trans_le hlo),Nat.le_floor hhi⟩
  have hc : s.card≤⌊4*Y⌋₊ := by
    calc
      _ = (s.image p).card := (Finset.card_image_of_injective _ hinj).symm
      _ ≤ (Finset.Icc 1 ⌊4*Y⌋₊).card := Finset.card_le_card hsub
      _ = _ := by simp
  exact (show (s.card:ℝ)≤⌊4*Y⌋₊ by exact_mod_cast hc).trans (Nat.floor_le (by positivity))

/-- Absolute major bound summed over every actual selected label pair.
The product labels are counted by injectivity, never by a tuple-count hypothesis. -/
theorem all_labels_scalarMajor_sum_le {ι : Type*} [Fintype ι]
    (p : ι→ℕ) (hinj : Function.Injective p)
    (s t : Finset ℕ) (N : ℕ) (hs : ∀m∈s,0<m)
    (hprod : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)
    (C Y H : ℝ) (hC : 0≤C) (hY : 0<Y) (hH : 0≤H)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (Aη Aψ A B : ℝ) (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hηsupp : ∀v,η v≠0→1≤v ∧ v≤4) (hψsupp : ∀v,ψ v≠0→|v|≤C)
    (hα : ∀m∈s,‖α m‖≤A) (hβ : ∀n∈t,‖β n‖≤B) :
    (∑a : ι,∑b : ι,∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      ‖scalarMajor (p a) (p b) m n r q Y H η ψ α β‖)≤
      64*(2*C+1)*Aη^2*A^2*B^2*Aψ*H^3*Y*
        ∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2 := by
  let P := Finset.univ.filter (fun i=>η ((p i:ℝ)/Y)≠0)
  let F := fun a b=>∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      ‖scalarMajor (p a) (p b) m n r q Y H η ψ α β‖
  let M := (Aη^2*A^2*B^2*Aψ*(4*H^3/Y))*(2*C+1)*
        ∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2
  have hM : 0≤M := by dsimp [M]; positivity
  have hzero (a b : ι) (hz : η ((p a:ℝ)/Y)=0 ∨ η ((p b:ℝ)/Y)=0) : F a b=0 := by
    rcases hz with hz|hz <;> simp [F,scalarMajor,hz]
  have he : (∑a : ι,∑b : ι,F a b)=∑a∈P,∑b∈P,F a b := by
    calc
      _ = ∑a∈P,∑b : ι,F a b := by
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro a ha hn
        apply Finset.sum_eq_zero
        intro b hb
        exact hzero a b (Or.inl (by simpa [P] using hn))
      _ = _ := by
        apply Finset.sum_congr rfl
        intro a ha
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro b hb hn
        exact hzero a b (Or.inr (by simpa [P] using hn))
  change (∑a : ι,∑b : ι,F a b)≤_
  rw [he]
  have hbnd : (∑a∈P,∑b∈P,F a b)≤(P.card:ℝ)^2*M := by
    calc
      _ ≤ ∑a∈P,∑b∈P,M := by
        apply Finset.sum_le_sum
        intro a ha
        apply Finset.sum_le_sum
        intro b hb
        have ha' := (hηsupp _ (Finset.mem_filter.mp ha).2).1
        have hb' := (hηsupp _ (Finset.mem_filter.mp hb).2).1
        exact scalarMajor_sum_le s t N (p a) (p b) hs hprod C Y H hC hY hH
          (by simpa using (le_div_iff₀ hY).mp ha') (by simpa using (le_div_iff₀ hY).mp hb')
          η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hψsupp hα hβ
      _ = _ := by simp; ring
  apply hbnd.trans
  have hc := supported_label_card p hinj Y hY η hηsupp
  have hsq : (P.card:ℝ)^2≤(4*Y)^2 := pow_le_pow_left₀ (by positivity) hc 2
  calc
    _ ≤ (4*Y)^2*M := mul_le_mul_of_nonneg_right hsq hM
    _ = _ := by
      dsimp only [M]
      generalize (∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2)=Z
      field_simp [hY.ne']
      ring

/-- The literal selected-prime product map is injective across disjoint groups. -/
theorem selectedProduct_injective {K : ℕ} (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j)) :
    Function.Injective (fun a : ∀i,groups i=>∏i,(a i).val) := by
  intro a b he
  dsimp only at he
  funext i
  apply Subtype.ext
  have hpa := hp i (a i).val (a i).property
  have hd : (a i).val∣∏j,(b j).val := by
    rw [←he]
    exact Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
  obtain ⟨j,hj,hdj⟩ := (hpa.prime.dvd_finsetProd_iff (fun j=>(b j).val)).mp hd
  have heq : (a i).val=(b j).val :=
    (Nat.prime_dvd_prime_iff_eq hpa (hp j (b j).val (b j).property)).mp hdj
  have hij : i=j := by
    by_contra hn
    exact Finset.disjoint_left.mp (hdis i j hn) (a i).property (heq ▸ (b j).property)
  subst j
  exact heq

/-- The only analytic input in the absolute major estimate is the unchanged
classical divisor-square moment, with a threshold uniform in all labels,
coefficient sets, cutoff functions and coefficient functions. -/
theorem uniform_absolute_major_of_divisor_moment
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment) :
    ∃D:ℝ,0<D∧∃N₀:ℕ,∀N:ℕ,N₀≤N→
    ∀(ι : Type*) [Fintype ι] (p : ι→ℕ),Function.Injective p→
    ∀(s t : Finset ℕ), (∀m∈s,0<m)→
    (∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)→
    ∀C Y H:ℝ,0≤C→0<Y→0≤H→
    ∀(η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ),
    0≤Aη→0≤Aψ→0≤A→0≤B→
    (∀v,‖η v‖≤Aη)→(∀v,‖ψ v‖≤Aψ)→
    (∀v,η v≠0→1≤v ∧ v≤4)→(∀v,ψ v≠0→|v|≤C)→
    (∀m∈s,‖α m‖≤A)→(∀n∈t,‖β n‖≤B)→
    (∑a : ι,∑b : ι,∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      ‖scalarMajor (p a) (p b) m n r q Y H η ψ α β‖)≤
      64*D*(2*C+1)*Aη^2*A^2*B^2*Aψ*H^3*N*Y*(Real.log (N:ℝ))^3 := by
  obtain ⟨D,hD,N₀,hN₀⟩ := ProductDirichletMeanSquare.uniform_integer_divisor_moment hD
  refine ⟨D,hD,N₀,?_⟩
  intro N hN ι _ p hinj s t hs hprod C Y H hC hY hH η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hηsupp hψsupp hα hβ
  apply (all_labels_scalarMajor_sum_le p hinj s t N hs hprod C Y H hC hY hH η ψ α β
    Aη Aψ A B hAη hAψ hA hB hη hψ hηsupp hψsupp hα hβ).trans
  have hh := mul_le_mul_of_nonneg_left (hN₀ N hN)
    (show 0≤64*(2*C+1)*Aη^2*A^2*B^2*Aψ*H^3*Y by positivity)
  convert hh using 1 <;> ring

end Elliptic.Operator.SignedPhysicalAbsoluteMajor
