module

public import Elliptic.Operator.RootRecordGap

/-! # Signed Bonferroni comparison with actual Lebesgue root integration -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootIntegratedBonferroni
open scoped BigOperators
open MeasureTheory SourceBonferroni RootRecordBonferroni RootRecordGap
open OriginalPathWeights RootGridMeasure RootArchimedeanTransfer
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

def average {X : Type*} [Fintype X] (f : X→ℂ) : ℂ :=
  (∑x,f x)/(Fintype.card X:ℂ)

theorem average_sub {X : Type*} [Fintype X] (f g : X→ℂ) :
    average f-average g=average (fun x=>f x-g x) := by
  simp only [average,Finset.sum_sub_distrib,sub_div]

theorem average_norm_le {X : Type*} [Fintype X] (f : X→ℂ) (b : X→ℝ)
    (hb : ∀x,‖f x‖≤b x) : ‖average f‖≤uniformAverage b := by
  rw [average,norm_div,Complex.norm_natCast]
  calc
    _ ≤ (∑x,b x)/(Fintype.card X:ℝ) :=
      div_le_div_of_nonneg_right ((norm_sum_le _ _).trans (Finset.sum_le_sum (fun x _=>hb x)))
        (Nat.cast_nonneg _)
    _ = _ := by unfold uniformAverage; ring

def fullAverage (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ) : ℂ :=
  average (fun ℓ : ∀p : primes,Option (ZMod p)=>
    (residueFactor rec primes η (extendLines primes ℓ):ℂ))

def truncatedAverage (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ) (T : ℕ) : ℂ :=
  average (fun ℓ : ∀p : primes,Option (ZMod p)=>
    ∑s∈BonferroniMonomialCount.truncatedSubsets primes T,
      subsetTest rec η s (fun p=>extendLines primes ℓ p))

theorem average_remainder (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (hA : activePrimes rec⊆primes)
    (η : ℕ→ℝ) (hη : ∀j<N+1,0≤η j ∧ η j≤1) (m : ℕ) :
    ‖fullAverage rec primes η-truncatedAverage rec primes η (2*m)‖ ≤
      gap rec primes η (2*m+1) := by
  unfold fullAverage truncatedAverage gap
  rw [average_sub]
  apply average_norm_le
  intro ℓ
  simpa only [one_mul] using residue_remainder rec primes hA η hη
    (extendLines primes ℓ) m 1 (by norm_num)

theorem norm_integral_rootBox (G : RootGridMeasure.RootPoint→ℂ) (hG : ∀q,‖G q‖≤1) :
    ‖∫q in rootBox,G q‖≤15 := by
  letI : IsFiniteMeasure (volume.restrict rootBox) := ⟨by
    rw [Measure.restrict_apply_univ,rootBox_volume]
    norm_num⟩
  have h := norm_integral_le_of_norm_le_const (μ:=volume.restrict rootBox)
    (Filter.Eventually.of_forall hG)
  simpa [Measure.real,Measure.restrict_apply_univ,rootBox_volume] using h

/-- The signed geometry survives the comparison. Only its proved unit
norm is used to dominate the independent-line Bonferroni tail. -/
theorem integrated_remainder (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (hA : activePrimes rec⊆primes)
    (η : ℕ→ℝ) (hη : ∀j<N+1,0≤η j ∧ η j≤1) (m : ℕ)
    (U V : ℝ) (hUV : 0≤U*V) (G : RootGridMeasure.RootPoint→ℂ) (hG : ∀q,‖G q‖≤1) :
    ‖((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫q in rootBox,G q)*fullAverage rec primes η -
      ((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫q in rootBox,G q)*truncatedAverage rec primes η (2*m)‖ ≤
      (15*(U*V/(Real.pi^2/6)))*gap rec primes η (2*m+1) := by
  rw [←mul_sub,norm_mul,norm_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg (div_nonneg hUV (by positivity))]
  have hgap := gap_nonneg rec primes η hη (2*m+1)
  have h := mul_le_mul (norm_integral_rootBox G hG) (average_remainder rec primes hA η hη m)
    (norm_nonneg _) (by norm_num : (0:ℝ)≤15)
  have hh := mul_le_mul_of_nonneg_left h
    (show 0≤U*V/(Real.pi^2/6) from div_nonneg hUV (by positivity))
  convert hh using 1 <;> ring

end Elliptic.Operator.RootIntegratedBonferroni
