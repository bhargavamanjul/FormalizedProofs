module

public import Elliptic.Operator.RootArchimedeanGrid
public import Elliptic.Operator.SourceMemoryEdges
public import Mathlib.Analysis.Normed.Group.AddCircle
public import Mathlib.Topology.Order.IntermediateValue

/-!
# Literal source good-test boundaries in the root coordinate

For a primitive position and a chosen integral unimodular complement,
the phase is the source ratio `tau(w)/tau(z)`. Its exact fractional-linear
difference proves injectivity away from the pole. A circle norm threshold
for any nonzero integer multiple can therefore occur only at an explicit
finite list of roots, with a cardinality proved from the integer-translate
range. The root grid then gives a concrete boundary-volume bound.

This handles the scalar circle equalities. Enumeration of all products,
fresh draws, and weighted exceptional-probability tests is still separate,
as are the curved physical box faces in the other two root coordinates.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGoodBoundary
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def phase (z w : ℤ × ℤ) (r : ℝ) : ℝ := latticeTau r w / latticeTau r z

theorem tau_cross_difference (z w : ℤ × ℤ) (r s : ℝ) :
    latticeTau s w*latticeTau r z-latticeTau r w*latticeTau s z =
      (s-r)*(latticeDet z w:ℝ) := by
  simp only [latticeTau,latticeDet,Int.cast_sub,Int.cast_mul]
  ring

/-- This exact identity is the source derivative computation without
any calculus assumptions, and works on either side of the pole. -/
theorem phase_sub (z w : ℤ × ℤ) (hzw : latticeDet z w=1) (r s : ℝ)
    (hr : latticeTau r z ≠ 0) (hs : latticeTau s z ≠ 0) :
    phase z w s-phase z w r = (s-r)/(latticeTau s z*latticeTau r z) := by
  have h := tau_cross_difference z w r s
  rw [hzw,Int.cast_one,mul_one] at h
  dsimp [phase]
  field_simp
  linear_combination h

theorem phase_injective_off_pole (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (r s : ℝ) (hr : latticeTau r z ≠ 0) (hs : latticeTau s z ≠ 0)
    (he : phase z w r = phase z w s) : r=s := by
  have h := phase_sub z w hzw r s hr hs
  rw [←he,sub_self] at h
  have hh := (div_eq_zero_iff).mp h.symm
  rcases hh with hh|hh
  · linarith
  · exact False.elim ((mul_ne_zero hs hr) hh)

theorem phase_strictMono (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (r s : ℝ) (hrs : r<s) (hr : 0<latticeTau r z) (hs : 0<latticeTau s z) :
    phase z w r < phase z w s := by
  have h := phase_sub z w hzw r s hr.ne' hs.ne'
  have hp : 0 < (s-r)/(latticeTau s z*latticeTau r z) := by positivity
  linarith

/-- The candidate is harmlessly defined even for a zero denominator;
the next lemma shows that a genuine threshold never has that denominator. -/
def endpoint (z w : ℤ × ℤ) (a : ℝ) : ℝ :=
  (a*(z.1:ℝ)-(w.1:ℝ))/((w.2:ℝ)-a*(z.2:ℝ))

theorem threshold_denominator_ne (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (r a : ℝ) (hr : latticeTau r z ≠ 0) (ha : phase z w r=a) :
    (w.2:ℝ)-a*(z.2:ℝ) ≠ 0 := by
  have he : latticeTau r w = a*latticeTau r z := (div_eq_iff hr).mp ha
  have hdet : (z.1:ℝ)*(w.2:ℝ)-(z.2:ℝ)*(w.1:ℝ)=1 := by
    exact_mod_cast hzw
  dsimp [latticeTau] at he
  intro hh
  have hw1 : (w.1:ℝ)=a*(z.1:ℝ) := by linear_combination he-r*hh
  have hw2 : (w.2:ℝ)=a*(z.2:ℝ) := by linarith
  rw [hw1,hw2] at hdet
  ring_nf at hdet
  norm_num at hdet

theorem threshold_eq_endpoint (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (r a : ℝ) (hr : latticeTau r z ≠ 0) (ha : phase z w r=a) :
    r=endpoint z w a := by
  have hd := threshold_denominator_ne z w hzw r a hr ha
  have he : latticeTau r w = a*latticeTau r z := (div_eq_iff hr).mp ha
  apply (eq_div_iff hd).mpr
  dsimp [latticeTau] at he
  nlinarith

/-- Integer translates sufficient for a phase bounded by `R`.
The actual phase-multiple bound is retained, so no sign of the integer
multiple or of the original shift is assumed. -/
def translations (m : ℤ) (R ε : ℝ) : Finset ℤ :=
  Finset.Icc ⌈-(|(m:ℝ)| *R+ε)⌉ ⌊|(m:ℝ)| *R+ε⌋

theorem mem_translations (m k : ℤ) (R ε : ℝ) :
    k ∈ translations m R ε ↔ |(k:ℝ)| ≤ |(m:ℝ)| *R+ε := by
  simp only [translations,Finset.mem_Icc,Int.ceil_le,Int.le_floor,abs_le]

theorem translations_card (m : ℤ) (R ε : ℝ) :
    ((translations m R ε).card:ℝ) ≤ max 0 (2*(|(m:ℝ)| *R+ε)+1) := by
  have hcast (q:ℤ) : (q.toNat:ℝ)=max (q:ℝ) 0 := by
    exact_mod_cast (Int.toNat_eq_max q)
  rw [translations,Int.card_Icc,hcast,max_comm]
  apply max_le_max (by rfl)
  have hlow := Int.le_ceil (-(|(m:ℝ)| *R+ε))
  have hupp := Int.floor_le (|(m:ℝ)| *R+ε)
  push_cast
  linarith

def circleEndpoints (z w : ℤ × ℤ) (m : ℤ) (R ε : ℝ) : Finset ℝ :=
  ((translations m R ε).image fun k : ℤ => endpoint z w (((k:ℝ)+ε)/(m:ℝ))) ∪
    ((translations m R ε).image fun k : ℤ => endpoint z w (((k:ℝ)-ε)/(m:ℝ)))

theorem circleEndpoints_card (z w : ℤ × ℤ) (m : ℤ) (R ε : ℝ) :
    (circleEndpoints z w m R ε).card ≤ 2*(translations m R ε).card := by
  exact (Finset.card_union_le _ _).trans (by
    have h1 := Finset.card_image_le (s:=translations m R ε)
      (f:=fun k : ℤ => endpoint z w (((k:ℝ)+ε)/(m:ℝ)))
    have h2 := Finset.card_image_le (s:=translations m R ε)
      (f:=fun k : ℤ => endpoint z w (((k:ℝ)-ε)/(m:ℝ)))
    omega)

/-- Every actual circle threshold in the bounded physical phase lies
in the displayed finite endpoint set. There is no generic boundary
regularity or cardinality hypothesis here. -/
theorem circle_threshold_mem (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (m : ℤ) (hm : m≠0) (R ε r : ℝ) (hr : latticeTau r z ≠ 0)
    (hR : |phase z w r| ≤ R)
    (he : ‖((((m:ℝ)*phase z w r):ℝ):AddCircle (1:ℝ))‖ = ε) :
    r ∈ circleEndpoints z w m R ε := by
  have hmR : (m:ℝ)≠0 := by exact_mod_cast hm
  let k : ℤ := round ((m:ℝ)*phase z w r)
  have habs : |(m:ℝ)*phase z w r-(k:ℝ)|=ε := by
    simpa only [AddCircle.norm_eq,inv_one,one_mul,mul_one] using he
  have hk : |(k:ℝ)| ≤ |(m:ℝ)| *R+ε := by
    calc
      |(k:ℝ)| = |(m:ℝ)*phase z w r-((m:ℝ)*phase z w r-(k:ℝ))| := by ring_nf
      _ ≤ |(m:ℝ)*phase z w r|+|(m:ℝ)*phase z w r-(k:ℝ)| := abs_sub _ _
      _ ≤ |(m:ℝ)| *R+ε := by rw [abs_mul,habs]; gcongr
  have hkmem : k ∈ translations m R ε := (mem_translations m k R ε).mpr hk
  have hε : 0 ≤ ε := he ▸ norm_nonneg _
  rcases (abs_eq hε).mp habs with hp|hn
  · apply Finset.mem_union_left
    apply Finset.mem_image.mpr
    refine ⟨k,hkmem,?_⟩
    symm
    apply threshold_eq_endpoint z w hzw r _ hr
    apply (eq_div_iff hmR).mpr
    nlinarith
  · apply Finset.mem_union_right
    apply Finset.mem_image.mpr
    refine ⟨k,hkmem,?_⟩
    symm
    apply threshold_eq_endpoint z w hzw r _ hr
    apply (eq_div_iff hmR).mpr
    nlinarith

/-- The source first-coordinate box automatically excludes the pole;
this is the lower bound on `tau` used by its root replacement proof. -/
theorem physical_tau_bounds (u v r U W : ℝ) (hU : 0<U)
    (hu : U≤u) (hu' : u≤16*U) (z : ℤ × ℤ)
    (hz : sourcePhysicalPositionAllowed u v r U W z) :
    1/16 ≤ latticeTau r z ∧ latticeTau r z ≤ 16 := by
  have hlo : U ≤ u*latticeTau r z := hz.2.1
  have hhi : u*latticeTau r z ≤ 16*U := hz.2.2.1
  have hup : 0<u := hU.trans_le hu
  have ht : 0<latticeTau r z := (mul_pos_iff.mp (hU.trans_le hlo)).resolve_right
    (by rintro ⟨hh,_⟩; linarith) |>.2
  constructor
  · nlinarith [mul_le_mul_of_nonneg_right hu' ht.le]
  · nlinarith [mul_le_mul_of_nonneg_right hu ht.le]

theorem phase_bound (z w : ℤ × ℤ) (r : ℝ) (hr : 0≤r) (hr' : r≤1)
    (ht : 1/16≤latticeTau r z) :
    |phase z w r| ≤ 16*(|(w.1:ℝ)|+|(w.2:ℝ)|) := by
  have htpos : 0<latticeTau r z := by linarith
  have hn : |latticeTau r w| ≤ |(w.1:ℝ)|+|(w.2:ℝ)| := by
    calc
      _ ≤ |(w.1:ℝ)|+|r*(w.2:ℝ)| := abs_add_le _ _
      _ = |(w.1:ℝ)|+r*|(w.2:ℝ)| := by rw [abs_mul,abs_of_nonneg hr]
      _ ≤ _ := by nlinarith [abs_nonneg (w.2:ℝ)]
  rw [phase,abs_div,abs_of_pos htpos]
  apply (div_le_iff₀ htpos).mpr
  have hb : 0 ≤ |(w.1:ℝ)|+|(w.2:ℝ)| := by positivity
  nlinarith

theorem physical_phase_bound (u v r U W : ℝ) (hU : 0<U)
    (hu : U≤u) (hu' : u≤16*U) (hr : 0≤r) (hr' : r≤1)
    (z w : ℤ × ℤ) (hz : sourcePhysicalPositionAllowed u v r U W z) :
    |phase z w r| ≤ 16*(|(w.1:ℝ)|+|(w.2:ℝ)|) :=
  phase_bound z w r hr hr' (physical_tau_bounds u v r U W hU hu hu' z hz).1

/-- Every cube containing a literal scalar good-test threshold is
one of the explicitly counted horizontal boundary cubes. -/
theorem threshold_cube_mem (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (m : ℤ) (hm : m≠0) (R ε : ℝ) (n : ℕ)
    (j : RootArchimedeanGrid.Index) (hj : j ∈ RootArchimedeanGrid.grid n)
    (q : ℝ × ℝ × ℝ) (hq : RootArchimedeanGrid.Contains n j q)
    (hr : latticeTau q.2.2 z ≠ 0) (hR : |phase z w q.2.2|≤R)
    (he : ‖((((m:ℝ)*phase z w q.2.2):ℝ):AddCircle (1:ℝ))‖=ε) :
    j ∈ RootArchimedeanGrid.boundaryFamily n (circleEndpoints z w m R ε) := by
  apply Finset.mem_biUnion.mpr
  refine ⟨q.2.2,circle_threshold_mem z w hzw m hm R ε q.2.2 hr hR he,?_⟩
  exact (RootArchimedeanGrid.mem_boundaryCubes n q.2.2 j).mpr ⟨hj,hq.2.2⟩

theorem circle_boundary_volume (z w : ℤ × ℤ) (m : ℤ) (R ε : ℝ)
    (n : ℕ) (hn : 0<n) :
    ∑ j ∈ RootArchimedeanGrid.boundaryFamily n (circleEndpoints z w m R ε),
      RootArchimedeanGrid.cellVolume n j ≤
        60*((translations m R ε).card:ℝ)/n := by
  have hc : ((circleEndpoints z w m R ε).card:ℝ) ≤
      2*((translations m R ε).card:ℝ) := by exact_mod_cast circleEndpoints_card z w m R ε
  calc
    _ ≤ 30*((circleEndpoints z w m R ε).card:ℝ)/n :=
      RootArchimedeanGrid.boundaryFamily_volume n hn _
    _ ≤ 30*(2*((translations m R ε).card:ℝ))/n := by gcongr
    _ = _ := by ring

/-- On an interval avoiding the explicitly constructed endpoints,
the actual scalar circle inequality is constant. This supplies the
indicator-stability assertion, rather than assuming it for the grid. -/
theorem circle_test_constant (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (m : ℤ) (hm : m≠0) (R ε a b : ℝ)
    (hpole : ∀ t ∈ Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t ∈ Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t ∈ circleEndpoints z w m R ε, t∉Set.Icc a b)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    (ε < ‖((((m:ℝ)*phase z w r):ℝ):AddCircle (1:ℝ))‖) ↔
      (ε < ‖((((m:ℝ)*phase z w s):ℝ):AddCircle (1:ℝ))‖) := by
  have hnum : Continuous (fun t : ℝ => latticeTau t w) := by
    unfold latticeTau
    fun_prop
  have hden : Continuous (fun t : ℝ => latticeTau t z) := by
    unfold latticeTau
    fun_prop
  have hphase : ContinuousOn (phase z w) (Set.Icc a b) :=
    hnum.continuousOn.div hden.continuousOn hpole
  have hcont : ContinuousOn
      (fun t : ℝ => ‖((((m:ℝ)*phase z w t):ℝ):AddCircle (1:ℝ))‖) (Set.Icc a b) :=
    ((AddCircle.continuous_mk' (1:ℝ)).comp_continuousOn
      (continuousOn_const.mul hphase)).norm
  have hno : ∀ t ∈ Set.Icc a b,
      ‖((((m:ℝ)*phase z w t):ℝ):AddCircle (1:ℝ))‖≠ε := by
    intro t ht he
    exact hends t (circle_threshold_mem z w hzw m hm R ε t
      (hpole t ht) (hbound t ht) he) ht
  constructor
  · intro hrε
    by_contra hsε
    obtain ⟨t,ht,he⟩ := isPreconnected_Icc.intermediate_value hs hr hcont
      ⟨le_of_not_gt hsε,hrε.le⟩
    exact hno t ht he
  · intro hsε
    by_contra hrε
    obtain ⟨t,ht,he⟩ := isPreconnected_Icc.intermediate_value hr hs hcont
      ⟨le_of_not_gt hrε,hsε.le⟩
    exact hno t ht he

theorem circle_test_constant_on_grid (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (m : ℤ) (hm : m≠0) (R ε : ℝ) (n : ℕ)
    (j : RootArchimedeanGrid.Index) (hj : j∈RootArchimedeanGrid.grid n)
    (hgood : j∉RootArchimedeanGrid.boundaryFamily n (circleEndpoints z w m R ε))
    (hpole : ∀ t, (RootArchimedeanGrid.cell 0 1 n j.2.2).Contains t → latticeTau t z≠0)
    (hbound : ∀ t, (RootArchimedeanGrid.cell 0 1 n j.2.2).Contains t → |phase z w t|≤R)
    (r s : ℝ) (hr : (RootArchimedeanGrid.cell 0 1 n j.2.2).Contains r)
    (hs : (RootArchimedeanGrid.cell 0 1 n j.2.2).Contains s) :
    (ε < ‖((((m:ℝ)*phase z w r):ℝ):AddCircle (1:ℝ))‖) ↔
      (ε < ‖((((m:ℝ)*phase z w s):ℝ):AddCircle (1:ℝ))‖) := by
  apply circle_test_constant z w hzw m hm R ε
    (RootArchimedeanGrid.cell 0 1 n j.2.2).lower
    (RootArchimedeanGrid.cell 0 1 n j.2.2).upper hpole hbound ?_ r s hr hs
  intro t ht htcell
  apply hgood
  apply Finset.mem_biUnion.mpr
  refine ⟨t,ht,?_⟩
  exact (RootArchimedeanGrid.mem_boundaryCubes n t j).mpr ⟨hj,htcell⟩

end Elliptic.Operator.RootGoodBoundary
