module

public import Elliptic.Operator.GroupedGhostNorm
public import Elliptic.Operator.CanonicalBoundaryAssembly
public import Elliptic.Operator.BoundaryMass
public import Elliptic.Operator.OriginalBoundaryTail

/-! Exact unnormalized empty-memory boundary norms in the physical measure. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open CanonicalBoundaryAssembly
attribute [local instance] Classical.propDecidable
local instance vacuumNormDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace MemoryState

theorem eq_empty_of_size_eq_zero {X : Type*} {B : ℕ} (m : MemoryState X B)
    (h : m.size = 0) : m = empty X B := by
  rcases m with ⟨⟨k,hk⟩,v⟩
  change k = 0 at h
  subst k
  change (⟨⟨0,hk⟩,v⟩ : MemoryState X B) = ⟨⟨0,hk⟩,Fin.elim0⟩
  exact congrArg (fun w : Fin 0 → X => (⟨⟨0,hk⟩,w⟩ : MemoryState X B)) (Subsingleton.elim _ _)

@[simp] theorem mass_empty {X : Type*} {B : ℕ} (μ : X → ℝ) :
    mass μ (empty X B) = 1 := by
  simp [mass,empty,size,values,tupleWeight]

end MemoryState

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} [∀ i p, Fintype (Line i p)] {J B : ℕ}

theorem emptyState_boundaryIndex_of_empty
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ∀ i, (s.memory P Line J B i).size = 0) :
    emptyState (Line:=Line) (B:=B) (boundaryIndex s) = s := by
  apply Subtype.ext
  change (s.val.1,s.val.2.1,fun i => MemoryState.empty (AnchoredParticle (P i) (Line i)) B) = s.val
  apply Prod.ext
  · rfl
  apply Prod.ext
  · rfl
  funext i
  exact (MemoryState.eq_empty_of_size_eq_zero _ (h i)).symm

theorem physicalGhostZeroExtension_vacuum
    (b : BoundaryIndex I Z P J → ℂ) (z : Z) (a : PhysicalActiveLists P J)
    (m : PhysicalMemories P Line B) :
    physicalGhostZeroExtension (vacuumLift (Line:=Line) (B:=B) b) z a m =
      if m = (fun i => MemoryState.empty (AnchoredParticle (P i) (Line i)) B)
      then b (z,a) else 0 := by
  have he : (∀ i, (m i).size = 0) ↔
      m = (fun i => MemoryState.empty (AnchoredParticle (P i) (Line i)) B) := by
    constructor
    · intro h
      funext i
      exact MemoryState.eq_empty_of_size_eq_zero _ (h i)
    · intro h
      subst m
      intro i
      rfl
  by_cases hm : ∀ i, (m i).size = 0
  · have em := he.mp hm
    subst m
    simp [physicalGhostZeroExtension,vacuumLift,PhysicalMemoryState.memory,
      MemoryState.empty,MemoryState.size,boundaryIndex,
      PhysicalMemoryState.position,PhysicalMemoryState.active]
  · have hem : ¬ m = (fun i => MemoryState.empty (AnchoredParticle (P i) (Line i)) B) :=
      fun h => hm (he.mpr h)
    rw [if_neg hem]
    unfold physicalGhostZeroExtension
    by_cases hc : (∑ i, (m i).size) ≤ B
    · rw [dif_pos hc]
      change (if ∀ i, (m i).size = 0 then _ else 0) = 0
      rw [if_neg hm]
    · rw [dif_neg hc]

/-- The factorial memory measure leaves exactly the initial active mass. -/
theorem vacuumLift_l2_sq (ν : ∀ i, P i → ℝ) (b : BoundaryIndex I Z P J → ℂ) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (vacuumLift (Line:=Line) (B:=B) b) =
      ∑ z : Z, ∑ a : PhysicalActiveLists P J,
        (∏ i, tupleWeight (ν i) (a i)) * ‖b (z,a)‖^2 := by
  rw [physicalGhostZeroExtension_l2_sq]
  apply Finset.sum_congr rfl
  intro z _
  apply Finset.sum_congr rfl
  intro a _
  congr 1
  simp only [finiteL2Sq,physicalGhostZeroExtension_vacuum]
  simp only [apply_ite norm, norm_zero, ite_pow, zero_pow (by omega : 2 ≠ 0), mul_ite, mul_zero]
  simp

/-- Summing all independent ordered active slots gives the exact product mass. -/
theorem active_mass_sum (ν : ∀ i, P i → ℝ) :
    (∑ a : PhysicalActiveLists P J, ∏ i, tupleWeight (ν i) (a i)) =
      ∏ i, (∑ p, ν i p)^(J+1) := by
  rw [← Fintype.prod_sum]
  apply Finset.prod_congr rfl
  intro i _
  unfold tupleWeight
  rw [← Fintype.prod_sum]
  simp

/-- A boundary vector at one fixed position is not normalized by the number
of active tuples; its norm contains their full product mass. -/
theorem vacuumLift_position_l2_sq_le
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 ≤ ν i p)
    (z₀ : Z) (a : PhysicalActiveLists P J → ℂ) (ha : ∀ t, ‖a t‖ ≤ 1) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (vacuumLift (Line:=Line) (B:=B) (fun u => if u.1 = z₀ then a u.2 else 0)) ≤
      ∏ i, (∑ p, ν i p)^(J+1) := by
  rw [vacuumLift_l2_sq]
  simp only [Prod.fst,Prod.snd]
  simp_rw [apply_ite norm, norm_zero, ite_pow, zero_pow (by omega : 2 ≠ 0), mul_ite, mul_zero]
  rw [Finset.sum_comm]
  simp only [Finset.sum_ite_eq',Finset.mem_univ,if_true]
  rw [←active_mass_sum (J:=J) ν]
  apply Finset.sum_le_sum
  intro t _
  have hp : 0 ≤ ∏ i, tupleWeight (ν i) (t i) :=
    Finset.prod_nonneg (fun i _ => Finset.prod_nonneg (fun j _ => hν i (t i j)))
  exact mul_le_of_le_one_right hp (by nlinarith [norm_nonneg (a t),ha t])

theorem vacuumLift_position_l2_le_sqrt_two
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 ≤ ν i p)
    (hmass : (∏ i, (∑ p, ν i p)^(J+1)) ≤ 2)
    (z₀ : Z) (a : PhysicalActiveLists P J → ℂ) (ha : ∀ t, ‖a t‖ ≤ 1) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (vacuumLift (Line:=Line) (B:=B) (fun u => if u.1 = z₀ then a u.2 else 0)) ≤
      Real.sqrt 2 := by
  exact Real.sqrt_le_sqrt ((vacuumLift_position_l2_sq_le ν hν z₀ a ha).trans hmass)

/-- The same exact initial mass controls the absolute left boundary
factor used in cap truncation. -/
theorem initialBoundaryNorm_position_le
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 ≤ ν i p)
    (z₀ : Z) (a : PhysicalActiveLists P J → ℂ) (ha : ∀ t, ‖a t‖ ≤ 1) :
    OriginalLifespanSchedule.initialBoundaryNorm (Line:=Line) (B:=B) ν
      (fun u => if u.1 = z₀ then a u.2 else 0) ≤
      ∏ i, (∑ p, ν i p)^(J+1) := by
  unfold OriginalLifespanSchedule.initialBoundaryNorm
  simp_rw [emptyState_mass,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg (Finset.prod_nonneg (fun i _ => Finset.prod_nonneg (fun j _ => hν i _)))]
  rw [Fintype.sum_prod_type]
  simp_rw [apply_ite norm,norm_zero,mul_ite,mul_zero]
  rw [Finset.sum_comm]
  simp only [Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  rw [←active_mass_sum (J:=J) ν]
  apply Finset.sum_le_sum
  intro t _
  have hp : 0 ≤ ∏ i, tupleWeight (ν i) (t i) :=
    Finset.prod_nonneg (fun i _ => Finset.prod_nonneg (fun j _ => hν i (t i j)))
  exact mul_le_of_le_one_right hp (ha t)

/-- Actual transformed prime bands give a uniform bound on the unnormalized
physical vacuum, independently of the memory cap and finite line encoding. -/
theorem eventually_transformed_vacuum_l2_sq_le_two (K : ℕ) :
    ∀ᶠ L : ℝ in Filter.atTop, ∀ (I Z : Type) [Fintype I] [Fintype Z],
      Fintype.card I = K → ∀ (pmin : ℝ) (η : Fin (momentLength L+1) → ℝ)
        (groups : I → Finset ℕ) (V : I → ℝ)
        (Line : ∀ i, {p // p ∈ groups i} → Type) [∀ i p, Fintype (Line i p)] (B : ℕ),
      (∀ i, 0 < V i) → (∀ i, V i = ∑ p ∈ groups i, 1/(p:ℝ)) →
      Real.exp (L^(1/10:ℝ)) ≤ pmin →
      (∀ i p, p ∈ groups i → pmin ≤ (p:ℝ)) → (∀ j, η j ≤ 1) →
      ∀ (z₀ : Z) (a : PhysicalActiveLists (fun i => {p // p ∈ groups i}) (momentPadding L) → ℂ),
      (∀ t, ‖a t‖ ≤ 1) →
      finiteL2Sq Finset.univ
        (PhysicalMemoryState.mass (fun i => {p // p ∈ groups i}) Line (momentPadding L) B
          (fun i p => transformedPrimeMass Finset.univ η (V i) p.val))
        (vacuumLift (Line:=Line) (B:=B) (fun u => if u.1 = z₀ then a u.2 else 0)) ≤ 2 := by
  filter_upwards [eventually_transformed_boundary_mass_le_two K,
    eventually_memory_visits_le_prime_cutoff] with L hmass hsize
  intro I Z _ _ hI pmin η groups V Line _ B hV hVsum hmin hp hη z₀ a ha
  have hpmin : 0 < pmin := (Real.exp_pos _).trans_le hmin
  have hν : ∀ i (p : {p // p ∈ groups i}),
      0 ≤ transformedPrimeMass Finset.univ η (V i) p.val := by
    intro i p
    exact (transformedPrimeMass_sharp_bound Finset.univ η (V i) pmin p.val
      (hV i) hpmin (hp i p.val p.property) (fun j _ => hη j)
      (by simpa using hsize.trans hmin)).1
  apply (vacuumLift_position_l2_sq_le _ hν z₀ a ha).trans
  have hm := hmass I hI pmin η groups V hV hVsum hmin hp hη
  have he i : (∑ p : {p // p ∈ groups i}, transformedPrimeMass Finset.univ η (V i) p.val) =
      ∑ p ∈ groups i, transformedPrimeMass Finset.univ η (V i) p :=
    (Finset.sum_subtype (groups i) (fun _ => Iff.rfl) _).symm
  simp only [he]
  exact hm

end Elliptic.Operator
