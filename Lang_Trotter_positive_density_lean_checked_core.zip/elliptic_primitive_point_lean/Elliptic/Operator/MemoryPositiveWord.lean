module

public import Elliptic.Operator.MemoryTruncation
public import Elliptic.Operator.CrudePhysicalRow

/-!
# Literal positive-history bounds

This file composes weighted bounds for the absolute *choice* rows, rather
than the smaller rows of the collected transition matrix. That distinction
is necessary when a global distinct-birth test is imposed. The full edge
row below is proved from the actual physical operation and the concrete
coarse row estimate, with no adjoint or unrestricted ordered-state norm.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

namespace ChoiceOperation
variable {X : Type*}

def doubledBirthRow (O : ChoiceOperation X) (w : X → ℝ) (x : X) : ℝ :=
  ∑ c : O.ValidChoice x, (2:ℝ)^(O.ghostBirths x c.val) *
    ‖O.coefficient x c.val‖ * w (O.output x c.val c.property)

theorem doubledBirthRow_eq_all_choices (O : ChoiceOperation X) (w : X → ℝ) (x : X) :
    doubledBirthRow O w x = ∑ c : O.Choice x, if hc : O.valid x c then
      (2:ℝ)^(O.ghostBirths x c) * ‖O.coefficient x c‖ * w (O.output x c hc) else 0 := by
  symm
  unfold doubledBirthRow
  rw [Finset.sum_dite]
  simp only [Finset.sum_const_zero,add_zero]
  exact (Equiv.subtypeEquivRight (by simp)).sum_comp
    (fun c : O.ValidChoice x => (2:ℝ)^(O.ghostBirths x c.val) *
      ‖O.coefficient x c.val‖ * w (O.output x c.val c.property))

/-- One actual positive-history step. All coefficients are the absolute
literal choice coefficients, including the actual doubled-birth counter. -/
theorem doubledBirthWord_cons_le (O : ChoiceOperation X) (ops : List (ChoiceOperation X))
    (F w : X → ℝ) (C R : ℝ) (hR : 0≤R)
    (hrow : ∀ x, doubledBirthRow O w x ≤ C*w x)
    (htail : ∀ x, doubledBirthWord ops F x ≤ R*w x) (x : X) :
    doubledBirthWord (O::ops) F x ≤ (C*R)*w x := by
  calc
    _ ≤ ∑ c : O.ValidChoice x, (2:ℝ)^(O.ghostBirths x c.val) *
        ‖O.coefficient x c.val‖ * (R*w (O.output x c.val c.property)) := by
      apply Finset.sum_le_sum
      intro c hc
      exact mul_le_mul_of_nonneg_left (htail _) (by positivity)
    _ = R*doubledBirthRow O w x := by
      rw [doubledBirthRow,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro c hc
      ring
    _ ≤ R*(C*w x) := mul_le_mul_of_nonneg_left (hrow x) hR
    _ = _ := by ring

end ChoiceOperation

/-- The complete literal chronological word has exactly N edge constants
and N+1 ghost constants. No norm on nonsymmetric ordered functions is used. -/
theorem memoryOperationsFrom_doubledBirthWord_le {X : Type*}
    (G E : ℕ → ChoiceOperation X) (F w : X → ℝ) (Cg Ce : ℝ)
    (hCg : 0≤Cg) (hCe : 0≤Ce)
    (hG : ∀ j x, ChoiceOperation.doubledBirthRow (G j) w x ≤ Cg*w x)
    (hE : ∀ j x, ChoiceOperation.doubledBirthRow (E j) w x ≤ Ce*w x)
    (hF : ∀ x, F x≤w x) (first N : ℕ) (x : X) :
    ChoiceOperation.doubledBirthWord (memoryOperationsFrom G E first N) F x ≤
      Cg^(N+1)*Ce^N*w x := by
  induction N generalizing first x with
  | zero =>
      simpa only [memoryOperationsFrom,Nat.zero_add,pow_zero,pow_one,mul_one] using
        ChoiceOperation.doubledBirthWord_cons_le (G first) [] F w Cg 1 (by norm_num)
          (hG first) (by simpa [ChoiceOperation.doubledBirthWord] using hF) x
  | succ N ih =>
      have htail := fun y => ih (first+1) y
      have hedge := fun y => ChoiceOperation.doubledBirthWord_cons_le
        (E first) (memoryOperationsFrom G E (first+1) N) F w Ce
        (Cg^(N+1)*Ce^N) (by positivity) (hE first) htail y
      have hghost := ChoiceOperation.doubledBirthWord_cons_le
        (G first) (E first :: memoryOperationsFrom G E (first+1) N) F w Cg
        (Ce*(Cg^(N+1)*Ce^N)) (by positivity) (hG first) hedge x
      change ChoiceOperation.doubledBirthWord
        (G first :: E first :: memoryOperationsFrom G E (first+1) N) F x ≤ _
      apply hghost.trans_eq
      rw [pow_succ, pow_succ]
      ring

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

/-- The row used in the chronological positive word is the actual full
edge choice row, with both endpoint permutation averages already included. -/
theorem physicalEdgeOperation_doubledBirthRow_le
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0≤ν i p) (hV : ∀ i, 0≤V i)
    (hρ0 : 0≤ρ) (hρ1 : ρ<1) (hv0 : 0<v0) (hG : 0≤G)
    (hgeometry : ∀ z a w b, ‖geometry z a w b‖≤G) :
    ChoiceOperation.doubledBirthRow (physicalEdgeOperation ν V ρ anchor geometry)
      (physicalMemorySchurWeight v0) s ≤
      ((Fintype.card Z:ℝ)*G*∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0) *
        physicalMemorySchurWeight v0 s := by
  rw [ChoiceOperation.doubledBirthRow_eq_all_choices]
  have h := physicalEdge_absolute_choice_weighted_sum_le ν V ρ v0 G anchor geometry s
    hν hV hρ0 hρ1 hv0 hG hgeometry
  convert h using 1
  apply Finset.sum_congr rfl
  intro c hc
  by_cases hv : c.Valid anchor s
  · simp [physicalEdgeOperation,hv]
  · simp [physicalEdgeOperation,hv]

/-- A terminal vacuum indicator has weight at most the actual positive
Schur weight, for every positive v0. -/
theorem physical_vacuum_le_schurWeight (v0 : ℝ) (hv0 : 0<v0)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    (if physicalMemorySize s=0 then (1:ℝ) else 0) ≤ physicalMemorySchurWeight v0 s := by
  by_cases hs : physicalMemorySize s=0
  · simp only [hs,↓reduceIte]
    change 1 ≤ v0 ^ physicalMemorySize s
    rw [hs,pow_zero]
  · simp only [hs,↓reduceIte]
    exact (physicalMemorySchurWeight_pos hv0 s).le

end Elliptic.Operator
