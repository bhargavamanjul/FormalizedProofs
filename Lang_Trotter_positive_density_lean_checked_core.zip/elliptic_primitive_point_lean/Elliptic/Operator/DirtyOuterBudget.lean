module

public import Elliptic.Operator.PhysicalDirtyWeighted
public import Mathlib.Logic.Equiv.Prod
public import Elliptic.Operator.BoundaryMass

/-!
# Actual outer coefficient sums for dirty edges

An ordinary mode either permits every old indexed promotion or fixes one
fresh prime.  The old-index sum has already been taken with outgoing
pending damping in `PhysicalDirtyWeighted`.  The identities here take the
remaining store and fresh-label sums with their literal coefficients.
Only one distinguished group is charged its number of old indices.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirtyOuterBudget
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance decidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The source's transformed prime law has mass at most two under the
same visit-size condition used for its exact normalization. In particular,
none of the outer bounds requires this transformed law to have mass one. -/
theorem transformed_mass_le_two {τ : Type*} (visits : Finset τ) (η : τ → ℝ)
    (primes : Finset ℕ) (V pmin : ℝ) (hV : 0 < V)
    (hVsum : V = ∑ p ∈ primes, 1/(p : ℝ)) (hpmin : 0 < pmin)
    (hp : ∀ p ∈ primes, pmin ≤ (p : ℝ))
    (hη : ∀ j ∈ visits, η j ≤ 1) (hsize : 2 * (visits.card : ℝ) ≤ pmin) :
    (∀ p : primes, 0 ≤ transformedPrimeMass visits η V p) ∧
      (∑ p : primes, transformedPrimeMass visits η V p) ≤ 2 := by
  refine ⟨fun p => (transformedPrimeMass_sharp_bound visits η V pmin p hV hpmin
    (hp p p.property) hη hsize).1, ?_⟩
  have hs := (transformedPrimeMass_sum_le visits η primes V pmin hV hVsum
    hpmin hp hη hsize).2
  have hratio : 2 * (visits.card : ℝ) / pmin ≤ 1 := (div_le_one hpmin).2 hsize
  rw [Finset.sum_coe_sort]
  linarith

section OneGroup
variable {P : Type*} {Line : P → Type*} {B : ℕ}

/-- `none` is a free indexed promotion; `some p` is a fresh draw of `p`. -/
def mode (m : MemoryState (AnchoredParticle P Line) B) (fresh : Option P) :
    Option (Fin m.size ⊕ P) := fresh.map Sum.inr

/-- Every actual group choice has precisely one store/ordinary-mode fiber.
Repeated old values remain distinct indices inside the free-promotion fiber. -/
theorem mem_choices_iff (m : MemoryState (AnchoredParticle P Line) B)
    (b : Bool) (fresh : Option P) (c : EdgeGroupChoice m) :
    c ∈ dirtyGroupChoices m b (mode m fresh) ↔
      c.1 = b ∧ (match c.2 with | .inl _ => none | .inr p => some p) = fresh := by
  rcases c with ⟨c, a | p⟩ <;> cases fresh <;>
    simp [mode, dirtyGroupChoices, Prod.mk.injEq, and_comm, eq_comm]

/-- The literal remaining coefficient of this mode. -/
def coefficient (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (b : Bool) (fresh : Option P) : ℝ :=
  dirtyGroupCoefficient ν V ρ v0 m b (mode m fresh)

@[simp] theorem coefficient_none (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (b : Bool) :
    coefficient ν V ρ v0 m b none = (V⁻¹ * (v0 ^ b.toNat / v0)) / (1 - ρ) := rfl

@[simp] theorem coefficient_some (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (b : Bool) (p : P) :
    coefficient ν V ρ v0 m b (some p) = ν p * v0 ^ b.toNat := rfl

theorem coefficient_nonneg (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (b : Bool) (fresh : Option P)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V) (hρ : ρ < 1) (hv0 : 0 ≤ v0) :
    0 ≤ coefficient ν V ρ v0 m b fresh :=
  dirtyGroupCoefficient_nonneg ν V ρ v0 m b _ hν hV hρ hv0

variable [Fintype P]

/-- The fresh sum is its actual total mass. No count of prime labels occurs. -/
theorem sum_fresh (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (b : Bool) :
    (∑ fresh : Option P, coefficient ν V ρ v0 m b fresh) =
      (V⁻¹ * (v0 ^ b.toNat / v0)) / (1 - ρ) + (∑ p, ν p) * v0 ^ b.toNat := by
  rw [Fintype.sum_option]
  simp only [coefficient_none, coefficient_some, ← Finset.sum_mul]

/-- Exact normalized budget for both store decisions and every ordinary mode. -/
theorem sum_store_fresh (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    (∑ b : Bool, ∑ fresh : Option P, coefficient ν V ρ v0 m b fresh) =
      (1 + v0) * (V⁻¹ / (v0 * (1 - ρ)) + ∑ p, ν p) := by
  simp only [sum_fresh, Fintype.sum_bool, Bool.toNat_true, Bool.toNat_false,
    pow_one, pow_zero, div_eq_mul_inv, mul_inv_rev]
  ring

/-- Fixing one old index removes its damping sum, but preserves its actual
promotion factor and both store weights. -/
theorem sum_distinguished_store (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (a : Fin m.size) :
    (∑ b : Bool, dirtyGroupCoefficient ν V ρ v0 m b (some (.inl a))) =
      (1 + v0) * V⁻¹ / v0 := by
  simp only [Fintype.sum_bool, dirtyGroupCoefficient, Bool.toNat_true,
    Bool.toNat_false, pow_one, pow_zero]
  ring

/-- This is the only old-index cardinality factor in the good dirty row. -/
theorem sum_distinguished_indices (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    (∑ a : Fin m.size, ∑ b : Bool,
      dirtyGroupCoefficient ν V ρ v0 m b (some (.inl a))) =
      m.size * ((1 + v0) * V⁻¹ / v0) := by
  simp_rw [sum_distinguished_store]
  simp

/-- The distinguished-index loss is at most the actual memory cutoff. -/
theorem sum_distinguished_indices_le (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) (hV : 0 ≤ V) (hv0 : 0 ≤ v0) :
    (∑ a : Fin m.size, ∑ b : Bool,
      dirtyGroupCoefficient ν V ρ v0 m b (some (.inl a))) ≤
      B * ((1 + v0) * V⁻¹ / v0) := by
  rw [sum_distinguished_indices]
  apply mul_le_mul_of_nonneg_right
  · exact_mod_cast m.size_le
  · positivity
end OneGroup

section IndependentGroups
variable {I : Type*} [Fintype I] [DecidableEq I] {P : I → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} {B : ℕ}

/-- Exact outer integration. The free-promotion coefficient already
contains the outgoing-damping sum, so no factor `B` appears here. -/
theorem product_sum_store_fresh (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) :
    (∑ store : I → Bool, ∑ fresh : ∀ i, Option (P i),
      ∏ i, coefficient (ν i) (V i) ρ v0 (m i) (store i) (fresh i)) =
      ∏ i, (1 + v0) * ((V i)⁻¹ / (v0 * (1 - ρ)) + ∑ p, ν i p) := by
  simp_rw [← Fintype.prod_sum]
  rw [← Fintype.prod_sum (fun i b => ∑ fresh : Option (P i),
    coefficient (ν i) (V i) ρ v0 (m i) b fresh)]
  apply Finset.prod_congr rfl
  intro i _
  exact sum_store_fresh (ν i) (V i) ρ v0 (m i)

/-- A uniform lower bound on `V`, a uniform bound on the total fresh mass, and the
literal Schur parameter give a constant per ordinary group. -/
theorem single_budget_le (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 vmin mass : ℝ)
    (i : I) (hV : vmin ≤ V i) (hmin : 0 < vmin) (hv0 : 0 < v0)
    (hρ : ρ < 1) (hmass : (∑ p, ν i p) ≤ mass) :
    (1 + v0) * ((V i)⁻¹ / (v0 * (1 - ρ)) + ∑ p, ν i p) ≤
      (1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass) := by
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  apply add_le_add _ hmass
  apply div_le_div_of_nonneg_right _ (by positivity)
  exact inv_anti₀ hmin hV

/-- Quantitative coefficient budget, independent of the number of prime
labels and independent of all ordinary groups' memory sizes. -/
theorem product_sum_store_fresh_le (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 vmin mass : ℝ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hv0 : 0 < v0) (hρ : ρ < 1) (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ store : I → Bool, ∑ fresh : ∀ i, Option (P i),
      ∏ i, coefficient (ν i) (V i) ρ v0 (m i) (store i) (fresh i)) ≤
      ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^ Fintype.card I := by
  rw [product_sum_store_fresh]
  calc
    _ ≤ ∏ _i : I, ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) := by
      apply Finset.prod_le_prod₀
      · intro i _
        have hVi : 0 < V i := hmin.trans_le (hV i)
        exact mul_nonneg (by positivity)
          (add_nonneg (by positivity) (Finset.sum_nonneg fun p _ => hν i p))
      · intro i _
        exact single_budget_le ν V ρ v0 vmin mass i (hV i) hmin hv0 hρ (hmass i)
    _ = _ := by simp
end IndependentGroups

section DistinguishedGroup
variable {I : Type*} [Fintype I] [DecidableEq I] {P : I → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} {B : ℕ}

/-- Assemble the actual store tuple from its distinguished bit and the
remaining bits. -/
def stores (i₀ : I) (b : Bool) (store : {i // i ≠ i₀} → Bool) : I → Bool :=
  (Equiv.piSplitAt i₀ (fun _ => Bool)).symm (b, store)

/-- Assemble the actual modes: one fixed indexed promotion, independent
fresh/free-promotion modes in every other group. -/
def modes (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (i₀ : I) (a : Fin (m i₀).size) (fresh : ∀ i : {i // i ≠ i₀}, Option (P i)) :
    ∀ i, Option (Fin (m i).size ⊕ P i) :=
  (Equiv.piSplitAt i₀ (fun i => Option (Fin (m i).size ⊕ P i))).symm
    (some (.inl a), fun i => mode (m i) (fresh i))

theorem prod_split_at (i₀ : I) (f : I → ℝ) :
    (∏ i, f i) = f i₀ * ∏ i : {i // i ≠ i₀}, f i := by
  rw [← Finset.mul_prod_erase Finset.univ f (Finset.mem_univ i₀)]
  congr 1
  exact Finset.prod_subtype _ (by simp) _

/-- The assembled coefficient really is the product with exactly one
fixed old index, and retains every other group's original coefficient. -/
theorem assembled_product (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (i₀ : I) (a : Fin (m i₀).size) (b : Bool)
    (store : {i // i ≠ i₀} → Bool) (fresh : ∀ i : {i // i ≠ i₀}, Option (P i)) :
    (∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0 (m i)
      (stores i₀ b store i) (modes m i₀ a fresh i)) =
      dirtyGroupCoefficient (ν i₀) (V i₀) ρ v0 (m i₀) b (some (.inl a)) *
        ∏ i : {i // i ≠ i₀}, coefficient (ν i) (V i) ρ v0 (m i) (store i) (fresh i) := by
  rw [prod_split_at i₀]
  have hstore : stores i₀ b store i₀ = b := by simp [stores, Equiv.piSplitAt]
  have hmode : modes m i₀ a fresh i₀ = some (.inl a) := by simp [modes, Equiv.piSplitAt]
  rw [hstore, hmode]
  congr 1
  apply Finset.prod_congr rfl
  intro i _
  simp [stores, modes, Equiv.piSplitAt, i.property, coefficient]

/-- Complete exact outer coefficient sum with one distinguished promoted
group. All stores, fresh labels and that old index have now been summed. -/
theorem sum_assembled_product (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) (i₀ : I) :
    (∑ a : Fin (m i₀).size, ∑ b : Bool,
      ∑ store : {i // i ≠ i₀} → Bool,
      ∑ fresh : ∀ i : {i // i ≠ i₀}, Option (P i),
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0 (m i)
        (stores i₀ b store i) (modes m i₀ a fresh i)) =
      (m i₀).size * ((1 + v0) * (V i₀)⁻¹ / v0) *
        ∏ i : {i // i ≠ i₀},
          (1 + v0) * ((V i)⁻¹ / (v0 * (1 - ρ)) + ∑ p, ν i p) := by
  calc
    _ = (∑ a : Fin (m i₀).size, ∑ b : Bool,
        dirtyGroupCoefficient (ν i₀) (V i₀) ρ v0 (m i₀) b (some (.inl a))) *
        (∑ store : {i // i ≠ i₀} → Bool,
          ∑ fresh : ∀ i : {i // i ≠ i₀}, Option (P i),
          ∏ i : {i // i ≠ i₀}, coefficient (ν i) (V i) ρ v0 (m i) (store i) (fresh i)) := by
      simp_rw [assembled_product, ← Finset.mul_sum, ← Finset.sum_mul]
    _ = _ := by
      rw [sum_distinguished_indices]
      congr 1
      exact product_sum_store_fresh (fun i : {i // i ≠ i₀} => ν i)
        (fun i => V i) ρ v0 (fun i => m i)

/-- Uniform quantitative outer budget. Only the distinguished group pays
`B`; all remaining indexed promotions were absorbed by their damping. -/
theorem sum_assembled_product_le (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 vmin mass : ℝ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) (i₀ : I)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hv0 : 0 < v0) (hρ : ρ < 1) (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ a : Fin (m i₀).size, ∑ b : Bool,
      ∑ store : {i // i ≠ i₀} → Bool,
      ∑ fresh : ∀ i : {i // i ≠ i₀}, Option (P i),
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0 (m i)
        (stores i₀ b store i) (modes m i₀ a fresh i)) ≤
      B * ((1 + v0) * vmin⁻¹ / v0) *
        ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^ Fintype.card {i // i ≠ i₀} := by
  rw [sum_assembled_product]
  have hVi : 0 < V i₀ := hmin.trans_le (hV i₀)
  have hd : ((1 + v0) * (V i₀)⁻¹ / v0) ≤ ((1 + v0) * vmin⁻¹ / v0) := by
    apply div_le_div_of_nonneg_right _ hv0.le
    exact mul_le_mul_of_nonneg_left (inv_anti₀ hmin (hV i₀)) (by positivity)
  have hm : ((m i₀).size : ℝ) * ((1 + v0) * (V i₀)⁻¹ / v0) ≤
      B * ((1 + v0) * vmin⁻¹ / v0) := by
    apply mul_le_mul (by exact_mod_cast (m i₀).size_le) hd
    · positivity
    · positivity
  apply mul_le_mul hm
  · rw [← product_sum_store_fresh (fun i : {i // i ≠ i₀} => ν i)
      (fun i => V i) ρ v0 (fun i => m i)]
    exact product_sum_store_fresh_le (fun i : {i // i ≠ i₀} => ν i)
      (fun i => V i) ρ v0 vmin mass (fun i => m i) (fun i => hν i) (fun i => hV i)
      hmin hv0 hρ (fun i => hmass i)
  · exact Finset.prod_nonneg fun i _ => by
      have hVi' : 0 < V i := hmin.trans_le (hV i)
      exact mul_nonneg (by positivity)
        (add_nonneg (by positivity) (Finset.sum_nonneg fun p _ => hν i p))
  · positivity
end DistinguishedGroup

end Elliptic.Operator.DirtyOuterBudget
