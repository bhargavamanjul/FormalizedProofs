module

public import Elliptic.Operator.ScheduledActiveBirths

/-!
# The complete forward history coefficient, with its initial measure

The constructed finite family consists of distinct actual dependent
physical histories. Here their signed sum, including the literal initial
active-list measure, is factored into the geometric/permutation product
and one normalized coefficient for each scheduled prime. Nonrecurrence
of a target in its source active list is explicit. This is the forward
coefficient theorem, not an assertion that these histories exhaust the
original primewise operator expansion.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ScheduledPhysicalPath
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance scheduledHistoryCoefficientDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}
variable (d : ScheduledPhysicalPath anchor N J B)
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

def ghostScalar (i : I) (j : ℕ) : ℝ :=
  scheduledGhostFactor (d.primes i) (d.lifespan i) ρ (V i) η q
    (fun p t => d.retained i p = anchor (d.position t) i p) j *
    (∏ p ∈ births (d.primes i) (d.lifespan i) j, ν i p)

def edgeScalar (i : I) (j : ℕ) : ℝ :=
  scheduledEdgeFactor (d.primes i) (d.lifespan i) ρ (V i)
    (fun p t => d.retained i p = anchor (d.position t) i p) j *
    (∏ p ∈ activeBirths (d.primes i) (d.lifespan i) (j+1), ν i p)

def initialScalar (i : I) : ℝ :=
  ∏ p ∈ activeBirths (d.primes i) (d.lifespan i) 0, ν i p

def geometricFactor (j : ℕ) : ℂ := (endpointPermutationWeight I J : ℂ) *
  geometry j (d.position j) (d.sourceLists j) (d.position (j+1)) (d.targetLists j)

theorem summedGhostFactor_eq_scalar (j : ℕ) :
    d.summedGhostFactor ν V η q ρ j = ∏ i, (d.ghostScalar ν V η q ρ i j : ℂ) := rfl

theorem edgeFactor_eq_scalar (j : ℕ) (hj : j<N)
    (hnew : ∀ i k, d.targetPrime j i ≠ d.active j i k) :
    d.edgeFactor ν V ρ geometry j =
      d.geometricFactor geometry j * ∏ i, (d.edgeScalar ν V ρ i j : ℂ) :=
  d.edgeFactor_eq_scheduled ν V ρ geometry j hj hnew

/-- The literal initial state measure has no pending-memory factorial
and equals exactly the product of initial active birth masses. -/
theorem initialState_mass_eq_scalar :
    PhysicalMemoryState.mass P Line J B ν d.initialState = ∏ i, d.initialScalar ν i := by
  unfold PhysicalMemoryState.mass
  apply Finset.prod_congr rfl
  intro i _
  simp only [initialState,PhysicalMemoryState.memory,PhysicalMemoryState.active,
    MemoryState.mass,MemoryState.empty,MemoryState.size,MemoryState.values,
    tupleWeight,Fin.prod_univ_zero,Nat.factorial_zero,Nat.cast_one,div_one,mul_one]
  exact d.initial_active_mass ν i

theorem summedCoefficientProduct_flat (n j : ℕ) :
    d.summedCoefficientProduct ν V η q ρ geometry n j =
      (∏ k ∈ Finset.range (n+1), d.summedGhostFactor ν V η q ρ (j+k)) *
      (∏ k ∈ Finset.range n, d.edgeFactor ν V ρ geometry (j+k)) := by
  induction n generalizing j with
  | zero => simp [summedCoefficientProduct]
  | succ n ih =>
      have hg : (∏ k ∈ Finset.range (n+1+1), d.summedGhostFactor ν V η q ρ (j+k)) =
          (∏ k ∈ Finset.range (n+1), d.summedGhostFactor ν V η q ρ ((j+1)+k)) *
            d.summedGhostFactor ν V η q ρ j := by
        rw [Finset.prod_range_succ']
        simp only [Nat.add_zero]
        congr 1
        apply Finset.prod_congr rfl
        intro k _
        congr 1
        omega
      have he : (∏ k ∈ Finset.range (n+1), d.edgeFactor ν V ρ geometry (j+k)) =
          (∏ k ∈ Finset.range n, d.edgeFactor ν V ρ geometry ((j+1)+k)) *
            d.edgeFactor ν V ρ geometry j := by
        rw [Finset.prod_range_succ']
        simp only [Nat.add_zero]
        congr 1
        apply Finset.prod_congr rfl
        intro k _
        congr 1
        omega
      rw [summedCoefficientProduct,ih,hg,he]
      ring

/-- All geometry and endpoint permutations stay outside the per-group
real scalar products when the actual finite history fiber is summed. -/
theorem finiteHistory_sum_separated
    (hnew : ∀ j, j<N → ∀ i k, d.targetPrime j i ≠ d.active j i k) :
    (∑ x : d.BirthFamily, (d.finiteHistory ν V η q ρ geometry x).weight) =
      (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
      ∏ i, (((∏ j ∈ Finset.range N, d.edgeScalar ν V ρ i j) *
        (∏ j ∈ Finset.range (N+1), d.ghostScalar ν V η q ρ i j) : ℝ) : ℂ) := by
  rw [d.finiteHistory_weight_sum_eq_summedCoefficient,d.summedCoefficientProduct_flat]
  simp only [Nat.zero_add,d.summedGhostFactor_eq_scalar]
  have he : (∏ j ∈ Finset.range N, d.edgeFactor ν V ρ geometry j) =
      (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
        ∏ j ∈ Finset.range N, ∏ i, (d.edgeScalar ν V ρ i j : ℂ) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro j hj
    exact d.edgeFactor_eq_scalar ν V ρ geometry j (Finset.mem_range.mp hj)
      (hnew j (Finset.mem_range.mp hj))
  rw [he,Finset.prod_comm (s:=Finset.range (N+1)),
    Finset.prod_comm (s:=Finset.range N)]
  simp only [Complex.ofReal_mul,Complex.ofReal_prod,Finset.prod_mul_distrib]
  ring

/-- For one group the complete initial/edge/ghost scalar is exactly the
primewise lifespan coefficient, with all birth masses counted once. -/
theorem group_scalar_primewise (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0)
    (hV : ∀ i, V i ≠ 0) (hν : ∀ i p, p ∈ d.primes i → V i*ν i p=μ i p) (i : I) :
    d.initialScalar ν i *
      ((∏ j ∈ Finset.range N, d.edgeScalar ν V ρ i j) *
       (∏ j ∈ Finset.range (N+1), d.ghostScalar ν V η q ρ i j)) =
    ∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
      (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
        (fun t => d.retained i p = anchor (d.position t) i p) j) := by
  have hend : ∀ p ∈ d.primes i, ∀ j≤N,
      (d.lifespan i p).ghostBorn j ∨ (d.lifespan i p).ghostDies j →
      d.retained i p = anchor (d.position j) i p := by
    intro p hp j hj h
    rcases h with hb | hd
    · exact d.birth_line j hj i p (Finset.mem_filter.mpr ⟨hp,hb⟩)
    · exact d.death_line j hj i p (Finset.mem_filter.mpr ⟨hp,hd⟩)
  rw [← complete_scheduled_coefficient (d.primes i) (d.lifespan i)
    ρ (V i) (ν i) (μ i) hρ (hV i) (hν i) η q
    (fun p t => d.retained i p = anchor (d.position t) i p) hend]
  simp only [initialScalar,edgeScalar,ghostScalar,Finset.prod_mul_distrib]
  rw [Finset.prod_range_succ' (fun j =>
    ∏ p ∈ activeBirths (d.primes i) (d.lifespan i) j, ν i p)]
  ring

/-- Complete coefficient identity for the forward-constructed physical
history fiber, with the actual initial state measure. -/
theorem finiteHistory_complete_coefficient (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0)
    (hV : ∀ i, V i ≠ 0) (hν : ∀ i p, p ∈ d.primes i → V i*ν i p=μ i p)
    (hnew : ∀ j, j<N → ∀ i k, d.targetPrime j i ≠ d.active j i k) :
    (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ) *
      (∑ x : d.BirthFamily, (d.finiteHistory ν V η q ρ geometry x).weight) =
    (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
      ∏ i, ((∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
        (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t => d.retained i p = anchor (d.position t) i p) j) : ℝ) : ℂ) := by
  rw [d.initialState_mass_eq_scalar,d.finiteHistory_sum_separated ν V η q ρ geometry hnew]
  rw [mul_left_comm,Complex.ofReal_prod,← Finset.prod_mul_distrib]
  apply congrArg (fun z : ℂ => (∏ j ∈ Finset.range N, d.geometricFactor geometry j) * z)
  apply Finset.prod_congr rfl
  intro i _
  rw [← Complex.ofReal_mul,d.group_scalar_primewise ν V η q ρ μ hρ hV hν i]

/-- The actual numerical cross-edge ban supplies the nonrecurrence input
of the complete forward coefficient identity, including across groups. -/
theorem finiteHistory_complete_coefficient_of_crossEdgeBan
    (value : ∀ i, P i → ℕ) (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0)
    (hV : ∀ i, V i ≠ 0) (hν : ∀ i p, p ∈ d.primes i → V i*ν i p=μ i p)
    (hban : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j)) :
    (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ) *
      (∑ x : d.BirthFamily, (d.finiteHistory ν V η q ρ geometry x).weight) =
    (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
      ∏ i, ((∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
        (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t => d.retained i p = anchor (d.position t) i p) j) : ℝ) : ℂ) :=
  d.finiteHistory_complete_coefficient ν V η q ρ geometry μ hρ hV hν
    (fun j hj => d.target_not_active_of_crossEdgeBan value j (hban j hj))

end Elliptic.Operator.ScheduledPhysicalPath
