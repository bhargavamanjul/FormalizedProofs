module

public import Elliptic.Operator.GhostSymmetricAdjoint

/-!
# Distinct fresh batches and their actual factorial ordering fibers

A finite set of distinct prime labels has exactly `card!` ordered tuple
representatives.  This file proves the literal fiber equivalence, then
cancels the factorial fresh-batch measure.  Arbitrary multiset continuations
may be attached to old survivors, so the identity applies to the actual
symmetric ghost memory action.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- A tuple lists exactly the finite set `T`, each label once. -/
def EnumeratesDistinct {P : Type*} (T : Finset P) (x : Fin T.card → P) : Prop :=
  Function.Injective x ∧ ∀ p, p ∈ T ↔ ∃ i, x i = p

/-- The literal fiber of ordered distinct birth tuples. -/
abbrev DistinctBirthTuple {P : Type*} (T : Finset P) :=
  {x : Fin T.card → P // EnumeratesDistinct T x}

/-- Actual tuple representatives are precisely bijections of the index set
onto the selected finite set. -/
def distinctBirthTupleEquiv {P : Type*} (T : Finset P) :
    DistinctBirthTuple T ≃ (Fin T.card ≃ T) where
  toFun x := Equiv.ofBijective
    (fun i => (⟨x.val i, (x.property.2 _).mpr ⟨i,rfl⟩⟩ : T))
    ⟨fun i j h => x.property.1 (congrArg Subtype.val h), by
      intro p
      obtain ⟨i, hi⟩ := (x.property.2 p.val).mp p.property
      exact ⟨i, Subtype.ext hi⟩⟩
  invFun e := ⟨fun i => (e i).val, by
    constructor
    · exact Subtype.val_injective.comp e.injective
    · intro p
      constructor
      · intro hp
        obtain ⟨i,hi⟩ := e.surjective ⟨p,hp⟩
        exact ⟨i,congrArg Subtype.val hi⟩
      · rintro ⟨i,rfl⟩
        exact (e i).property⟩
  left_inv x := by apply Subtype.ext; rfl
  right_inv e := by apply Equiv.ext; intro i; apply Subtype.ext; rfl

/-- The cardinality is derived from the bijection fiber and the permutation
count, rather than supplied as a factorial multiplicity assumption. -/
theorem distinctBirthTuple_card {P : Type*} [Fintype P] (T : Finset P) :
    Fintype.card (DistinctBirthTuple T) = T.card.factorial := by
  classical
  rw [Fintype.card_congr (distinctBirthTupleEquiv T)]
  simpa only [Fintype.card_fin] using Fintype.card_equiv T.equivFin.symm

/-- Every ordering has the actual prime product measure of the selected set. -/
theorem distinctBirthTuple_weight {P R : Type*} [Fintype P] [CommMonoid R]
    (T : Finset P) (ν : P → R) (x : DistinctBirthTuple T) :
    tupleWeight ν x.val = ∏ p ∈ T, ν p := by
  classical
  have h := Equiv.prod_comp (distinctBirthTupleEquiv T x) (fun p : T => ν p.val)
  change tupleWeight ν x.val = _ at h
  exact h.trans (Finset.prod_coe_sort T ν)

/-- An arbitrary particle-label map gives the same multiset for every
ordering in the literal tuple fiber. -/
theorem distinctBirthTuple_bag {P X : Type*} [Fintype P]
    (T : Finset P) (f : P → X) (x : DistinctBirthTuple T) :
    tupleBag (fun i => f (x.val i)) = T.val.map f := by
  classical
  rw [← selectedBag_eq_map T f]
  exact Equiv.sum_comp (distinctBirthTupleEquiv T x) (fun p : T => ({f p.val} : Multiset X))

/-- The factorial denominator cancels the complete actual ordering fiber,
including an arbitrary symmetric continuation after old survivor particles. -/
theorem distinct_birth_batch_sum {P X R : Type*} [Fintype P] [Field R] [CharZero R]
    (T : Finset P) (ν : P → R) (f : P → X)
    (survivors : Multiset X) (F : Multiset X → R) :
    (∑ x : DistinctBirthTuple T,
      (tupleWeight ν x.val / (T.card.factorial : R)) *
        F (survivors + tupleBag (fun i => f (x.val i)))) =
      (∏ p ∈ T, ν p) * F (survivors + T.val.map f) := by
  classical
  simp_rw [distinctBirthTuple_weight, distinctBirthTuple_bag]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, distinctBirthTuple_card]
  have hfac : (T.card.factorial : R) ≠ 0 := Nat.cast_ne_zero.mpr T.card.factorial_ne_zero
  field_simp

/-- The same identity as a sum over all actual ordered prime tuples, with
an explicit test selecting the distinct-set fiber. -/
theorem distinct_birth_batch_sum_all_tuples {P X R : Type*} [Fintype P]
    [Field R] [CharZero R]
    (T : Finset P) (ν : P → R) (f : P → X)
    (survivors : Multiset X) (F : Multiset X → R) :
    (∑ x : Fin T.card → P, if EnumeratesDistinct T x then
      (tupleWeight ν x / (T.card.factorial : R)) *
        F (survivors + tupleBag (fun i => f (x i))) else 0) =
      (∏ p ∈ T, ν p) * F (survivors + T.val.map f) := by
  classical
  rw [← Finset.sum_filter]
  rw [Finset.sum_subtype (p := EnumeratesDistinct T) _ (fun x => by simp) (fun x =>
    (tupleWeight ν x / (T.card.factorial : R)) *
      F (survivors + tupleBag (fun i => f (x i))))]
  exact distinct_birth_batch_sum T ν f survivors F

/-- Specialization to the actual retained anchor of a ghost fresh batch. -/
theorem distinct_anchored_birth_batch_sum {P R : Type*} [Fintype P]
    {Line : P → Type*} [Field R] [CharZero R]
    (T : Finset P) (ν : P → R) (anchor : ∀ p, Line p)
    (survivors : Multiset (AnchoredParticle P Line))
    (F : Multiset (AnchoredParticle P Line) → R) :
    (∑ x : Fin T.card → P, if EnumeratesDistinct T x then
      (tupleWeight ν x / (T.card.factorial : R)) *
        F (survivors + tupleBag (fun i => anchorPrime anchor (x i))) else 0) =
      (∏ p ∈ T, ν p) * F (survivors + T.val.map (anchorPrime anchor)) :=
  distinct_birth_batch_sum_all_tuples T ν (anchorPrime anchor) survivors F

/-- Put a literal ordered representative of a finite fresh set into the
actual ghost-choice constructor. -/
def distinctFreshGhostChoice {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size))
    (T : Finset P) (hT : T.card ≤ B) (x : Fin T.card → P) : GhostChoice m :=
  (S, ⟨⟨T.card, Nat.lt_succ_of_le hT⟩, x⟩)

theorem distinctFreshGhostChoice_valid {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (S : Finset (Fin m.size)) (T : Finset P) (hT : T.card ≤ B)
    (hS : S ⊆ memoryHits anchor m) (hcut : Sᶜ.card + T.card ≤ B)
    (x : Fin T.card → P) :
    GhostChoice.Valid anchor m (distinctFreshGhostChoice m S T hT x) :=
  ⟨hS, hcut⟩

/-- Direct application to the actual signed ghost coefficient and output.
After summing its distinct-birth ordering fiber, only the prime-set product
measure remains; all old deletion and survival factors stay exact. -/
theorem distinct_birth_actual_ghost_sum {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size))
    (T : Finset P) (hT : T.card ≤ B)
    (hS : S ⊆ memoryHits anchor m) (hcut : Sᶜ.card + T.card ≤ B)
    (F : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ x : DistinctBirthTuple T,
      (ghostChoiceWeight ν V η q ρ anchor m (distinctFreshGhostChoice m S T hT x.val) : ℂ) *
        F (tupleBag (ghostOutput anchor m (distinctFreshGhostChoice m S T hT x.val)
          (distinctFreshGhostChoice_valid anchor m S T hT hS hcut x.val)).values)) =
      (((-η/ρ)^S.card * (q/ρ^2)^(memoryHits anchor m \ S).card *
        (-η*V/ρ)^T.card : ℝ) : ℂ) *
        (∏ p ∈ T, (ν p : ℂ)) *
          F (survivorBag S m.values + T.val.map (anchorPrime anchor)) := by
  classical
  let C : ℂ := (((-η/ρ)^S.card * (q/ρ^2)^(memoryHits anchor m \ S).card *
    (-η*V/ρ)^T.card : ℝ) : ℂ)
  calc
    _ = C * ∑ x : DistinctBirthTuple T,
        (tupleWeight (fun p => (ν p : ℂ)) x.val / (T.card.factorial : ℂ)) *
          F (survivorBag S m.values + tupleBag (fun i => anchorPrime anchor (x.val i))) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x hx
      rw [ghostOutput_tupleBag]
      simp only [distinctFreshGhostChoice, ghostChoiceWeight, MemoryState.size,
        MemoryState.values, tupleWeight, C, Complex.ofReal_div, Complex.ofReal_mul,
        Complex.ofReal_pow, Complex.ofReal_prod, Complex.ofReal_natCast]
      ring
    _ = _ := by
      rw [distinct_birth_batch_sum]
      exact (mul_assoc _ _ _).symm

end Elliptic.Operator
