module

public import Elliptic.Operator.WeightedSchur

/-! Finite sums of actual measured operators, with an explicit cardinality
loss. This is used only for the fixed finite family of store/promotion masks. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

 theorem finiteL2Sq_sum_le {ι κ : Type*} (s : Finset ι) (m : Finset κ)
    (μ : ι → ℝ) (hμ : ∀ i∈s,0≤μ i) (f : κ → ι → ℂ) :
    finiteL2Sq s μ (fun i=>∑ j∈m,f j i) ≤ (m.card:ℝ)*∑j∈m,finiteL2Sq s μ (f j) := by
  have hpoint (i : ι) : ‖∑j∈m,f j i‖^2 ≤ (m.card:ℝ)*∑j∈m,‖f j i‖^2 := by
    have hc : (∑j∈m,‖f j i‖)^2 ≤ (∑_j∈m,(1:ℝ)) * ∑j∈m,‖f j i‖^2 := by
      apply Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul m
        (fun _ _=>by positivity) (fun _ _=>sq_nonneg _)
      intro j hj
      simp only [one_mul,le_refl]
    exact (pow_le_pow_left₀ (norm_nonneg _) (norm_sum_le _ _) 2).trans (by simpa using hc)
  unfold finiteL2Sq
  calc
    _ ≤ ∑i∈s,μ i*((m.card:ℝ)*∑j∈m,‖f j i‖^2) :=
      Finset.sum_le_sum fun i hi=>mul_le_mul_of_nonneg_left (hpoint i) (hμ i hi)
    _ = _ := by
      simp_rw [←mul_assoc, mul_comm (μ _), mul_assoc, Finset.mul_sum]
      rw [Finset.sum_comm]
      simp only [mul_comm]

 theorem finiteL2_sum_le {ι κ : Type*} (s : Finset ι) (m : Finset κ)
    (μ : ι → ℝ) (hμ : ∀ i∈s,0≤μ i) (f : κ → ι → ℂ)
    (C : κ → ℝ) (N : ℝ) (hN : 0≤N) (hC : ∀j∈m,0≤C j)
    (hf : ∀j∈m,finiteL2 s μ (f j)≤C j*N) :
    finiteL2 s μ (fun i=>∑j∈m,f j i) ≤
      Real.sqrt ((m.card:ℝ)*∑j∈m,(C j)^2)*N := by
  have hs (j : κ) (hj : j∈m) : finiteL2Sq s μ (f j)≤(C j)^2*N^2 := by
    have h := pow_le_pow_left₀ (Real.sqrt_nonneg _) (hf j hj) 2
    simpa only [finiteL2,Real.sq_sqrt (finiteL2Sq_nonneg s μ hμ (f j)),mul_pow] using h
  calc
    _ ≤ Real.sqrt ((m.card:ℝ)*∑j∈m,finiteL2Sq s μ (f j)) :=
      Real.sqrt_le_sqrt (finiteL2Sq_sum_le s m μ hμ f)
    _ ≤ Real.sqrt ((m.card:ℝ)*∑j∈m,(C j)^2*N^2) :=
      Real.sqrt_le_sqrt (mul_le_mul_of_nonneg_left (Finset.sum_le_sum hs) (by positivity))
    _ = Real.sqrt (((m.card:ℝ)*∑j∈m,(C j)^2)*N^2) := by rw [←Finset.sum_mul,mul_assoc]
    _ = _ := by rw [Real.sqrt_mul (by positivity),Real.sqrt_sq hN]

end Elliptic.Operator
