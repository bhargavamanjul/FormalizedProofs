module

public import Elliptic.Operator.PrescribedPrimeTuple
public import Elliptic.Operator.PhysicalEdgeReindexing
public import Elliptic.Operator.PhysicalEdgeAdjoint
public import Elliptic.Operator.SingleEdgeRow

/-!
# Actual physical edge rows with prescribed fresh prime values

Every prescribed edge birth must use the literal fresh branch. The
geometric target sum is performed after fixing all labels. This preserves
one prime atom per prescription, without conditioning on a later endpoint.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrescribedEdgeRow
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance prescribedEdgeDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- A prescribed value must be newly drawn, rather than promoted. -/
def Prescribed {P : Type*} {Line : P → Type*} {B : ℕ}
    (value : P → ℕ) (b : ℕ) {m : MemoryState (AnchoredParticle P Line) B}
    (c : EdgeGroupChoice m) : Prop := ∃ p, c.2 = Sum.inr p ∧ value p = b

/-- Drop both hit dampings and retain the literal fresh prime atom. -/
def localMajorant {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V v0 : ℝ) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) : ℝ :=
  v0^c.1.toNat * (match c.2 with | .inl _ => V⁻¹/v0 | .inr p => ν p)

theorem localMajorant_nonneg {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V v0 : ℝ) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) (hν : ∀ p,0≤ν p) (hV : 0≤V) (hv0 : 0≤v0) :
    0≤localMajorant ν V v0 m c := by
  rcases c with ⟨b,k|p⟩
  · simp only [localMajorant]
    positivity
  · exact mul_nonneg (pow_nonneg hv0 _) (hν p)

theorem weightedChoice_le_localMajorant {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p,Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hν : ∀ p,0≤ν p) (hV : 0≤V) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m c ≤
      localMajorant ν V v0 m c := by
  rcases c with ⟨b,k|p⟩
  · apply (edgeWeightedChoice_promotion_le_coefficient ν V ρ v0 sourceAnchor targetAnchor
      sourcePrime m b k hV hρ0 hρ1 hv0).trans_eq
    simp only [localMajorant]
    ring
  · apply (edgeWeightedChoice_fresh_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m b p
      hν hρ0 hρ1 hv0).trans_eq
    simp only [localMajorant]
    ring

/-- Unprescribed local choices cost at most the old-index count and the
actual total fresh mass. No geometric factor enters this local sum. -/
theorem localMajorant_sum {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V v0 : ℝ) (m : MemoryState (AnchoredParticle P Line) B) :
    (∑ c : EdgeGroupChoice m, localMajorant ν V v0 m c) =
      (1+v0)*((m.size : ℝ)*V⁻¹/v0+∑ p,ν p) := by
  simp only [Fintype.sum_prod_type,Fintype.sum_sum_type,localMajorant,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,← Finset.mul_sum]
  simp [Bool.toNat]
  ring

/-- The exact prescribed fresh-branch sum has one atom and both optional
store choices, even if the requested numerical value belongs to no label. -/
theorem localMajorant_prescribed_sum {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V v0 : ℝ) (m : MemoryState (AnchoredParticle P Line) B)
    (value : P → ℕ) (b : ℕ) :
    (∑ c : EdgeGroupChoice m, if Prescribed value b c then localMajorant ν V v0 m c else 0) =
      (1+v0)*(∑ p,if value p=b then ν p else 0) := by
  simp only [Fintype.sum_prod_type,Fintype.sum_sum_type,Prescribed,Sum.inl_ne_inr,false_and,
    exists_false,ite_false,Finset.sum_const_zero,zero_add,Sum.inr.injEq]
  simp only [exists_eq_left,localMajorant]
  simp [Bool.toNat,Finset.mul_sum,mul_ite]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p _
  split_ifs <;> ring

variable {I Z : Type*} [Fintype I] [Fintype Z]
variable {P : I → Type*} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i → Type*} {J B : ℕ}

/-- The local majorant including the actual fresh-branch prescription. -/
def selectedMajorant (ν : ∀ i,P i→ℝ) (V : I→ℝ) (v0 : ℝ)
    (value : ∀ i,P i→ℕ) (S : Finset I) (target : I→ℕ)
    (m : PhysicalMemories P Line B) (i : I) (c : EdgeGroupChoice (m i)) : ℝ :=
  if (i∈S → Prescribed (value i) (target i) c) then localMajorant (ν i) (V i) v0 (m i) c else 0

/-- Every label is fixed before summing target positions. The two uniform
endpoint averages then cancel exactly, for arbitrary geometric restrictions. -/
theorem geometry_majorant_sum_le
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (M : (∀ i,EdgeGroupChoice (s.memory P Line J B i)) → ℝ)
    (hM : ∀ c,0≤M c) (G : ℝ)
    (hgeometry : ∀ a b, (∑ z : Z, ‖geometry (s.position P Line J B) a z b‖)≤G) :
    (∑ c : PhysicalEdgeChoice s, endpointPermutationWeight I J *
      ‖geometry (s.position P Line J B) c.sourceLists c.target c.targetLists‖ * M c.group) ≤
      G * ∑ c, M c := by
  let n : ℝ := Fintype.card (I→Equiv.Perm (Fin (J+1)))
  have hn : n≠0 := by
    dsimp [n]
    exact_mod_cast (Fintype.card_pos_iff.mpr ⟨fun _ : I => Equiv.refl (Fin (J+1))⟩).ne'
  have hw : 0≤endpointPermutationWeight I J := by unfold endpointPermutationWeight; positivity
  have hfixed (π : I→Equiv.Perm (Fin (J+1)))
      (c : ∀ i,EdgeGroupChoice (s.memory P Line J B i)) :
      (∑ z : Z, ∑ _τ : I→Equiv.Perm (Fin (J+1)),
        endpointPermutationWeight I J *
        ‖geometry (s.position P Line J B) (fun i j => s.active P Line J B i (π i j)) z
          (PhysicalEdgeAdjoint.targetLists (s.active P Line J B) π
            (fun i => edgeTargetPrime (s.memory P Line J B i) (c i)))‖ * M c) ≤
      n*endpointPermutationWeight I J*G*M c := by
    simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
    calc
      _ = (n*endpointPermutationWeight I J*M c) *
          (∑ z : Z, ‖geometry (s.position P Line J B) (fun i j => s.active P Line J B i (π i j)) z
          (PhysicalEdgeAdjoint.targetLists (s.active P Line J B) π
            (fun i => edgeTargetPrime (s.memory P Line J B i) (c i)))‖) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro z _
        dsimp [n]
        ring
      _ ≤ (n*endpointPermutationWeight I J*M c)*G :=
        mul_le_mul_of_nonneg_left (hgeometry _ _) (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) hw) (hM c))
      _ = _ := by ring
  simp only [Fintype.sum_prod_type,PhysicalEdgeChoice.sourceLists,PhysicalEdgeChoice.targetLists,
    PhysicalEdgeChoice.sourcePerm,PhysicalEdgeChoice.target,PhysicalEdgeChoice.group]
  rw [Finset.sum_comm]
  calc
    _ ≤ ∑ _π : I→Equiv.Perm (Fin (J+1)), ∑ c : ∀ i,EdgeGroupChoice (s.memory P Line J B i),
        n*endpointPermutationWeight I J*G*M c := by
      apply Finset.sum_le_sum
      intro π _
      rw [Finset.sum_comm]
      exact Finset.sum_le_sum (fun c _ => hfixed π c)
    _ = G * ∑ c, M c := by
      simp only [← Finset.mul_sum,Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
      change (n*endpointPermutationWeight I J*G)*(n*(∑ c,M c)) = _
      unfold endpointPermutationWeight
      change (n*n⁻¹^2*G)*(n*(∑ c,M c)) = _
      field_simp

/-- Actual normalized absolute choice row with the specified nonpivot
edge births required to be fresh and to carry their prescribed values. -/
def choiceRow (ν : ∀ i,P i→ℝ) (V : I→ℝ) (ρ v0 : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value : ∀ i,P i→ℕ) (S : Finset I) (target : I→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    if (∀i∈S,Prescribed (value i) (target i) (c.group i)) then
      ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
        (physicalMemorySchurWeight v0 (c.output anchor s hc)/physicalMemorySchurWeight v0 s) else 0
  else 0

/-- Source (4.48) before replacing bounded group constants by one C_K.
Every prescribed group contributes exactly the atom bound Δ. -/
theorem choiceRow_le
    (ν : ∀ i,P i→ℝ) (V : I→ℝ) (ρ v0 G Δ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value : ∀ i,P i→ℕ) (hinj : ∀i,Function.Injective (value i))
    (S : Finset I) (target : I→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (hv0 : 0<v0) (hG : 0≤G) (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ)
    (hgeometry : ∀ a b, (∑ z : Z, ‖geometry (s.position P Line J B) a z b‖)≤G) :
    choiceRow ν V ρ v0 anchor geometry value S target s ≤
      G * ∏ i, if i∈S then (1+v0)*Δ else
        (1+v0)*((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p) := by
  let M := fun c : ∀i,EdgeGroupChoice (s.memory P Line J B i) =>
    ∏i,selectedMajorant ν V v0 value S target (s.memory P Line J B) i (c i)
  have hsel i c : 0≤selectedMajorant ν V v0 value S target (s.memory P Line J B) i c := by
    unfold selectedMajorant
    split_ifs
    · exact localMajorant_nonneg (ν i) (V i) v0 _ c (hν i) (hV i) hv0.le
    · exact le_rfl
  have hM : ∀c,0≤M c := fun c => Finset.prod_nonneg (fun i _ => hsel i (c i))
  have hw : 0≤endpointPermutationWeight I J := by unfold endpointPermutationWeight; positivity
  have hpoint (c : PhysicalEdgeChoice s) :
      (if hc : c.Valid anchor s then
        if (∀i∈S,Prescribed (value i) (target i) (c.group i)) then
          ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
            (physicalMemorySchurWeight v0 (c.output anchor s hc)/physicalMemorySchurWeight v0 s) else 0 else 0) ≤
      endpointPermutationWeight I J *
        ‖geometry (s.position P Line J B) c.sourceLists c.target c.targetLists‖ * M c.group := by
    by_cases hc : c.Valid anchor s
    · rw [dite_eq_left hc]
      by_cases hp : ∀i∈S,Prescribed (value i) (target i) (c.group i)
      · rw [ite_eq_left hp,physicalEdgeChoiceWeight_norm_mul_ratio ν V ρ v0 anchor geometry s c hc hν hV hρ0]
        apply mul_le_mul_of_nonneg_left _ (mul_nonneg hw (norm_nonneg _))
        apply Finset.prod_le_prod₀
        · intro i _
          exact edgeWeightedChoice_nonneg _ _ _ _ _ _ _ _ _ (hν i) (hV i) hρ0 hv0.le
        · intro i _
          have hi : i∈S → Prescribed (value i) (target i) (c.group i) := hp i
          simp only [selectedMajorant,ite_eq_left hi]
          exact weightedChoice_le_localMajorant _ _ _ _ _ _ _ _ _ (hν i) (hV i) hρ0 hρ1 hv0
      · rw [ite_eq_right hp]
        exact mul_nonneg (mul_nonneg hw (norm_nonneg _)) (hM c.group)
    · rw [dite_eq_right hc]
      exact mul_nonneg (mul_nonneg hw (norm_nonneg _)) (hM c.group)
  unfold choiceRow
  apply (Finset.sum_le_sum (fun c _ => hpoint c)).trans
  apply (geometry_majorant_sum_le geometry s M hM G hgeometry).trans
  apply mul_le_mul_of_nonneg_left _ hG
  rw [← Fintype.prod_sum]
  apply Finset.prod_le_prod₀
  · intro i _
    exact Finset.sum_nonneg (fun c _ => hsel i c)
  · intro i _
    by_cases hi : i∈S
    · simp only [selectedMajorant,hi,true_implies,ite_true]
      rw [localMajorant_prescribed_sum]
      exact mul_le_mul_of_nonneg_left
        (PrescribedPrimeTuple.atom_sum_le (ν i) (value i) (hinj i) Δ hΔ (hatom i) (target i)) (by positivity)
    · simp only [selectedMajorant,hi,false_implies,ite_true,ite_false]
      rw [localMajorant_sum]
      have hVi : 0≤(V i)⁻¹ := inv_nonneg.mpr (hV i)
      gcongr
      exact (s.memory P Line J B i).size_le

/-- A uniform product constant isolates exactly one Δ per prescribed
fresh group, with no cardinality loss from the prime alphabets. -/
theorem choiceRow_le_atoms
    (ν : ∀ i,P i→ℝ) (V : I→ℝ) (ρ v0 G Δ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value : ∀ i,P i→ℕ) (hinj : ∀i,Function.Injective (value i))
    (S : Finset I) (target : I→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (hv0 : 0<v0) (hG : 0≤G) (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ)
    (hgeometry : ∀ a b, (∑ z : Z, ‖geometry (s.position P Line J B) a z b‖)≤G) :
    choiceRow ν V ρ v0 anchor geometry value S target s ≤
      G * (∏ i, (1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)) * Δ^S.card := by
  apply (choiceRow_le ν V ρ v0 G Δ anchor geometry value hinj S target s
    hν hV hρ0 hρ1 hv0 hG hΔ hatom hgeometry).trans
  have hp : (∏ i, if i∈S then (1+v0)*Δ else
      (1+v0)*((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)) ≤
      (∏ i, (1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)) * Δ^S.card := by
    calc
      _ ≤ ∏ i, ((1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)) *
          (if i∈S then Δ else 1) := by
        apply Finset.prod_le_prod₀
        · intro i _
          have hVi := inv_nonneg.mpr (hV i)
          have hm : 0≤∑p,ν i p := Finset.sum_nonneg (fun p _ => hν i p)
          split_ifs <;> positivity
        · intro i _
          by_cases hi : i∈S
          · simp only [hi,ite_true]
            have hmax := le_max_left (1:ℝ) ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)
            have h := mul_le_mul_of_nonneg_left hmax (show 0≤1+v0 by linarith)
            simpa only [mul_one] using mul_le_mul_of_nonneg_right h hΔ
          · simp only [hi,ite_false,mul_one]
            exact mul_le_mul_of_nonneg_left (le_max_right _ _) (by linarith)
      _ = _ := by
        rw [Finset.prod_mul_distrib]
        simp only [Finset.prod_ite_mem,Finset.univ_inter,Finset.prod_const]
  exact (mul_le_mul_of_nonneg_left hp hG).trans_eq (by ring)

omit [Fintype Z] in
/-- Literal source (4.48): the actual raw and comparison geometry has its
proved target-count bound, so no geometric-row estimate remains assumed. -/
theorem source_choiceRow_le_atoms
    (positions : Finset (ℤ×ℤ))
    (ν : ∀ i,P i→ℝ) (V : I→ℝ) (ρ v0 Δ : ℝ)
    (anchor : positions→∀i p,Line i p)
    (value : ∀ i,P i→ℕ) (hinj : ∀i,Function.Injective (value i))
    (S : Finset I) (target : I→ℕ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y H C : ℝ) (η ψ : ℝ→ℂ) (σ : ℤ)
    (s : PhysicalMemoryState (Z:=positions) P Line J B)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (hv0 : 0<v0) (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hη : ∀t,‖η t‖≤1) (hψ : ∀t,‖ψ t‖≤1)
    (hψsupport : ∀t,ψ t≠0 → |t|≤C) :
    choiceRow ν V ρ v0 anchor
      (fun z a w b => sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
        (sourceMajorArcs H Y) σ z.val a w.val b) value S target s ≤
      (33+132*(2*C+1)*H^3) *
        (∏ i, (1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)) * Δ^S.card := by
  apply choiceRow_le_atoms ν V ρ v0 _ Δ anchor _ value hinj S target s
    hν hV hρ0 hρ1 hv0 (by positivity) hΔ hatom
  intro a b
  by_cases hz : sourcePhysicalPositionAllowed u v r U W (s.position P Line J B).val
  · have hh := SingleEdgeRow.sum_geometry_norm_le value good u v r U W d₀ Y H C η ψ σ
      hU hd hY hH hC hη hψ hψsupport _ hz a b positions
    convert hh using 1
    exact Finset.sum_coe_sort positions (fun w => ‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ (sourceMajorArcs H Y) σ (s.position P Line J B).val a w b‖)
  · have hzero (w : positions) :
        sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
          (sourceMajorArcs H Y) σ (s.position P Line J B).val a w.val b = 0 := by
      have hn : ¬sourcePhysicalEdgeAllowed value good u v r U W d₀
          (s.position P Line J B).val a w.val b := fun h => hz h.1
      simp only [sourcePhysicalEdgeGeometry,ite_eq_right hn]
    simp only [hzero,norm_zero,Finset.sum_const_zero]
    positivity

end Elliptic.Operator.PrescribedEdgeRow
