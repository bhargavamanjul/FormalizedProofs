module

public import Elliptic.Operator.MemoryTransitions
public import Mathlib.Data.Fin.Tuple.Basic

/-!
# Concrete store and promotion edges

The local rule is the edge of source §4.2, with one unshared active slot
per group (`M = J+1`). Choices promote an indexed OLD particle or draw a
fresh prime. The source unshared prime can independently be stored. A new
store is appended only after promotion, so cannot be promoted on the same
edge. Both endpoint hit factors and every prime integration are literal.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

/-- Independent store choice and target choice: an old index or fresh prime. -/
abbrev EdgeGroupChoice {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) := Bool × (Fin m.size ⊕ P)

/-- The promoted OLD indices. There is one unshared target slot per group. -/
def edgePromotedIndices {P : Type*} {Line : P → Type*} {B : ℕ}
    {m : MemoryState (AnchoredParticle P Line) B} (c : EdgeGroupChoice m) :
    Finset (Fin m.size) := match c.2 with
  | .inl i => {i}
  | .inr _ => ∅

/-- The actual unshared target prime, retaining its group. -/
def edgeTargetPrime {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m) : P :=
  match c.2 with
  | .inl i => (m.values i).1
  | .inr p => p

/-- A promotion must hit the target line. Fresh draws have no anchor test. -/
def edgePromotionHits {P : Type*} {Line : P → Type*} {B : ℕ}
    (targetAnchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) : Prop := match c.2 with
  | .inl i => particleHits targetAnchor (m.values i)
  | .inr _ => True

/-- The output length is determined by actual promoted indices and the store. -/
def edgeGroupOutputSize {P : Type*} {Line : P → Type*} {B : ℕ}
    {m : MemoryState (AnchoredParticle P Line) B} (c : EdgeGroupChoice m) : ℕ :=
  (edgePromotedIndices c)ᶜ.card + c.1.toNat

/-- The literal local conditions, including the memory cutoff. -/
def EdgeGroupChoice.Valid {P : Type*} {Line : P → Type*} {B : ℕ}
    (targetAnchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) : Prop :=
  edgePromotionHits targetAnchor m c ∧ edgeGroupOutputSize c ≤ B

/-- Survivors keep their old order; a new store is appended after them. -/
def edgeGroupOutput {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) : MemoryState (AnchoredParticle P Line) B :=
  ⟨⟨edgeGroupOutputSize c, Nat.lt_succ_of_le hc⟩,
    Fin.append (ghostSurvivors m (edgePromotedIndices c))
      (fun _ : Fin c.1.toNat => anchorPrime sourceAnchor sourcePrime)⟩

@[simp] theorem edgeGroupOutput_size {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) :
    (edgeGroupOutput sourceAnchor sourcePrime m c hc).size = edgeGroupOutputSize c := rfl

theorem edgeGroupOutputSize_eq {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m) :
    edgeGroupOutputSize c = m.size - (edgePromotedIndices c).card + c.1.toNat := by
  unfold edgeGroupOutputSize
  rw [Finset.card_compl, Fintype.card_fin]

@[simp] theorem edgeGroupOutput_old {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) (j : Fin (edgePromotedIndices c)ᶜ.card) :
    (edgeGroupOutput sourceAnchor sourcePrime m c hc).values (j.castAdd c.1.toNat) =
      m.values ((edgePromotedIndices c)ᶜ.orderEmbOfFin rfl j) := by
  change Fin.append (ghostSurvivors m (edgePromotedIndices c))
    (fun _ : Fin c.1.toNat => anchorPrime sourceAnchor sourcePrime) (j.castAdd c.1.toNat) = _
  rw [Fin.append_left]
  rfl

@[simp] theorem edgeGroupOutput_store {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) (j : Fin c.1.toNat) :
    (edgeGroupOutput sourceAnchor sourcePrime m c hc).values
      (j.natAdd (edgePromotedIndices c)ᶜ.card) = anchorPrime sourceAnchor sourcePrime := by
  change Fin.append (ghostSurvivors m (edgePromotedIndices c))
    (fun _ : Fin c.1.toNat => anchorPrime sourceAnchor sourcePrime)
    (j.natAdd (edgePromotedIndices c)ᶜ.card) = _
  rw [Fin.append_right]

/-- Promotion pays `1/V`; a fresh target is integrated with its prime mass. -/
def edgeTargetWeight {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V : ℝ) {m : MemoryState (AnchoredParticle P Line) B}
    (c : EdgeGroupChoice m) : ℝ := match c.2 with
  | .inl _ => V⁻¹
  | .inr p => ν p

/-- The exact two endpoint damping factors and target integration. -/
def edgeGroupWeight {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) (hc : edgeGroupOutputSize c ≤ B) : ℝ :=
  ρ ^ (memoryHits sourceAnchor m).card * edgeTargetWeight ν V c *
    ρ ^ (memoryHits targetAnchor (edgeGroupOutput sourceAnchor sourcePrime m c hc)).card

/-- The local row sums the actual finite choices, with their deterministic outputs. -/
def edgeGroupApply {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P)
    (F : P × MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) : ℂ := by
  classical
  exact ∑ c : EdgeGroupChoice m,
    if hc : EdgeGroupChoice.Valid targetAnchor m c then
      (edgeGroupWeight ν V ρ sourceAnchor targetAnchor sourcePrime m c hc.2 : ℂ) *
        F (edgeTargetPrime m c, edgeGroupOutput sourceAnchor sourcePrime m c hc.2)
    else 0

/-- Collecting equal outputs retains all indexed choice multiplicities. -/
def edgeGroupTransition {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (n : P × MemoryState (AnchoredParticle P Line) B) : ℂ := by
  classical
  exact edgeGroupApply ν V ρ sourceAnchor targetAnchor sourcePrime
    (fun out => if out = n then 1 else 0) m

theorem edgeGroupApply_eq_transition_sum {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (F : P × MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    edgeGroupApply ν V ρ sourceAnchor targetAnchor sourcePrime F m =
      ∑ n, edgeGroupTransition ν V ρ sourceAnchor targetAnchor sourcePrime m n * F n := by
  classical
  unfold edgeGroupTransition edgeGroupApply
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  split_ifs <;> simp

/-- Exact membership in the surviving old ordered tuple. -/
theorem ghostSurvivors_exists_iff {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size))
    (x : AnchoredParticle P Line) :
    (∃ j, ghostSurvivors m S j = x) ↔ ∃ i, i ∉ S ∧ m.values i = x := by
  constructor
  · rintro ⟨j,hj⟩
    refine ⟨Sᶜ.orderEmbOfFin rfl j, ?_, hj⟩
    exact Finset.mem_compl.mp (Finset.orderEmbOfFin_mem _ _ _)
  · rintro ⟨i,hi,hx⟩
    have hi' : i ∈ Set.range (Sᶜ.orderEmbOfFin rfl) := by
      rw [Finset.range_orderEmbOfFin]
      exact Finset.mem_compl.mpr hi
    rcases hi' with ⟨j,hj⟩
    refine ⟨j, ?_⟩
    change m.values (Sᶜ.orderEmbOfFin rfl j) = x
    rwa [hj]

/-- Literal edge output membership: an unpromoted old particle or the new
source store. This assertion permits repeated particle values. -/
theorem edgeGroupOutput_exists_iff {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) (x : AnchoredParticle P Line) :
    (∃ j, (edgeGroupOutput sourceAnchor sourcePrime m c hc).values j = x) ↔
      (∃ i, i ∉ edgePromotedIndices c ∧ m.values i = x) ∨
        (c.1 = true ∧ anchorPrime sourceAnchor sourcePrime = x) := by
  constructor
  · rintro ⟨j,hj⟩
    change Fin.append (ghostSurvivors m (edgePromotedIndices c))
      (fun _ : Fin c.1.toNat => anchorPrime sourceAnchor sourcePrime) j = x at hj
    revert hj
    refine Fin.addCases (fun i hi => ?_) (fun i hi => ?_) j
    · left
      apply (ghostSurvivors_exists_iff m (edgePromotedIndices c) x).mp
      exact ⟨i, by simpa only [Fin.append_left] using hi⟩
    · right
      have ht : c.1 = true := by
        cases hb : c.1
        · have hi0 := i.isLt
          simp [hb] at hi0
        · rfl
      exact ⟨ht, by simpa only [Fin.append_right] using hi⟩
  · rintro (h | ⟨hs,hx⟩)
    · obtain ⟨j,hj⟩ := (ghostSurvivors_exists_iff m (edgePromotedIndices c) x).mpr h
      exact ⟨j.castAdd c.1.toNat, (edgeGroupOutput_old _ _ _ _ _ _).trans hj⟩
    · have hpos : 0 < c.1.toNat := by simp [hs]
      exact ⟨(⟨0,hpos⟩ : Fin c.1.toNat).natAdd (edgePromotedIndices c)ᶜ.card,
        (edgeGroupOutput_store _ _ _ _ _ _).trans hx⟩

end Elliptic.Operator
