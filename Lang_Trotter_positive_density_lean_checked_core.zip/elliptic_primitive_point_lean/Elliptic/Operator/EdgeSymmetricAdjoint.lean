module

public import Elliptic.Operator.GhostSymmetricAdjoint
public import Elliptic.Operator.PhysicalMemoryEdges

/-!
# Factorial symmetric edge transfers

An edge deletes at most one indexed particle into its target active slot
and stores at most one source active label. For fixed endpoint labels,
these are the singleton-supported deletion and birth kernels below.
The pairing reversal exchanges the store and promotion coefficients.
The conversion from these symmetric kernels to the complete grouped,
endpoint-permuted physical row is a separate assembly step.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- A fixed target label is fresh (empty deletion) or promoted (one deletion). -/
def edgePromotionBatch {X R : Type*} [Field R]
    (x : X) (primeMass promotion : R) (s : Multiset X) : R :=
  if s=0 then primeMass else if s={x} then promotion else 0

/-- The empty birth drops the source label. A singleton stores it, with
the reciprocal prime mass canceling its actual particle integration. -/
def edgeStoreBatch {X R : Type*} [Field R]
    (x : X) (primeMass store : R) (s : Multiset X) : R :=
  if s=0 then 1 else if s={x} then store/primeMass else 0

theorem edgePromotionBatch_eq_mass_mul {X R : Type*} [Field R]
    (x : X) (v a : R) (hv : v≠0) :
    edgePromotionBatch x v a = fun s => v*edgeStoreBatch x v a s := by
  funext s
  unfold edgePromotionBatch edgeStoreBatch
  split_ifs
  · simp
  · field_simp
  · simp

theorem bagDeletion_const_mul {X R : Type*} [CommSemiring R]
    (a : R) (D F : Multiset X → R) (s : Multiset X) :
    bagDeletion (fun t => a*D t) F s = a*bagDeletion D F s := by
  classical
  unfold bagDeletion
  simp only [mul_left_comm (F _) a, Multiset.sum_map_mul_left]

theorem symmetricMemoryIntegral_const_mul {X R : Type*} [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (a : R) (F : Multiset X → R) :
    symmetricMemoryIntegral B μ (fun s => a*F s) = a*symmetricMemoryIntegral B μ F := by
  unfold symmetricMemoryIntegral
  simp only [mul_left_comm (tupleWeight _ _) a, ← Finset.mul_sum, mul_div_assoc]

/-- The genuine fixed-label symmetric transfer with both endpoint hit
multipliers. Its birth/deletion support permits only zero or one particle. -/
def bagEdgeTransfer {X R : Type*} [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (source target : X) (sourceMass targetMass store promote : R)
    (sourceDamping targetDamping F : Multiset X → R) (s : Multiset X) : R :=
  sourceDamping s *
    bagDeletion (edgePromotionBatch target targetMass promote)
      (bagBirth B μ (edgeStoreBatch source sourceMass store)
        (fun t => targetDamping t * F t)) s

/-- Exact local factorial pairing reversal: store and promotion coefficients
exchange places, and the two endpoint damping factors exchange roles. -/
theorem bagEdgeTransfer_adjoint {X R : Type*} [Fintype X] [Field R] [CharZero R]
    (B : ℕ) (μ : X → R) (source target : X) (sourceMass targetMass store promote : R)
    (hs : sourceMass ≠ 0) (ht : targetMass ≠ 0)
    (sourceDamping targetDamping F G : Multiset X → R) :
    sourceMass * symmetricMemoryIntegral B μ (fun s =>
      G s * bagEdgeTransfer B μ source target sourceMass targetMass store promote
        sourceDamping targetDamping F s) =
    targetMass * symmetricMemoryIntegral B μ (fun s =>
      F s * bagEdgeTransfer B μ target source targetMass sourceMass promote store
        targetDamping sourceDamping G s) := by
  unfold bagEdgeTransfer
  rw [edgePromotionBatch_eq_mass_mul target targetMass promote ht,
    edgePromotionBatch_eq_mass_mul source sourceMass store hs]
  simp only [bagDeletion_const_mul]
  have h := symmetric_ghost_adjoint B μ
    (edgeStoreBatch target targetMass promote) (edgeStoreBatch source sourceMass store)
    (fun _ => 1) (fun s => targetDamping s * F s) (fun s => sourceDamping s * G s)
  simp only [one_mul] at h
  calc
    _ = sourceMass * (targetMass * symmetricMemoryIntegral B μ (fun s =>
        (sourceDamping s * G s) * bagDeletion (edgeStoreBatch target targetMass promote)
          (bagBirth B μ (edgeStoreBatch source sourceMass store)
            (fun t => targetDamping t * F t)) s)) := by
      congr 1
      rw [← symmetricMemoryIntegral_const_mul]
      congr 1
      funext s
      ring
    _ = targetMass * (sourceMass * symmetricMemoryIntegral B μ (fun s =>
        (targetDamping s * F s) * bagDeletion (edgeStoreBatch source sourceMass store)
          (bagBirth B μ (edgeStoreBatch target targetMass promote)
            (fun t => sourceDamping t * G t)) s)) := by rw [h]; ring
    _ = _ := by
      congr 1
      rw [← symmetricMemoryIntegral_const_mul]
      congr 1
      funext s
      ring

/-- The singleton store kernel really is the optional deterministic store:
its reciprocal mass cancels the actual particle measure, and batches of
all other sizes contribute zero. -/
theorem memoryBirthIntegral_edgeStoreBatch {X R : Type*} [Fintype X]
    [Field R] [CharZero R] (μ : X → R) (x : X) (store : R) (hx : μ x ≠ 0)
    (F : Multiset X → R) (s : Multiset X) (a : ℕ) :
    memoryBirthIntegral a μ (edgeStoreBatch x (μ x) store) F s =
      if a=0 then F s else if a=1 then store*F (s+{x}) else 0 := by
  classical
  by_cases ha0 : a=0
  · subst a
    simp [memoryBirthIntegral, edgeStoreBatch, tupleBag, tupleWeight]
  by_cases ha1 : a=1
  · subst a
    simp only [memoryBirthIntegral, Nat.factorial_one, Nat.cast_one, div_one,
      Nat.one_ne_zero, ite_false, ite_true]
    have he : (∑ y : Fin 1 → X, tupleWeight μ y *
        edgeStoreBatch x (μ x) store (tupleBag y) * F (s+tupleBag y)) =
        ∑ y : X, μ y * edgeStoreBatch x (μ x) store {y} * F (s+{y}) := by
      apply Fintype.sum_equiv (Equiv.funUnique (Fin 1) X)
      intro y
      simp [tupleWeight, tupleBag, Equiv.funUnique, Equiv.piUnique]
    rw [he]
    simp only [edgeStoreBatch, Multiset.singleton_ne_zero, ite_false,
      Multiset.singleton_inj, mul_ite, mul_zero, ite_mul, zero_mul]
    simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true]
    field_simp
  · have hz (y : Fin a → X) : edgeStoreBatch x (μ x) store (tupleBag y) = 0 := by
      have hc := tupleBag_card y
      have hne0 : tupleBag y ≠ 0 := by
        intro h
        have := congrArg Multiset.card h
        simp only [tupleBag_card, Fintype.card_fin, Multiset.card_zero] at this
        exact ha0 this
      have hne1 : tupleBag y ≠ {x} := by
        intro h
        have := congrArg Multiset.card h
        simp only [tupleBag_card, Fintype.card_fin, Multiset.card_singleton] at this
        exact ha1 this
      simp [edgeStoreBatch, hne0, hne1]
    simp [memoryBirthIntegral, hz, ha0, ha1]

theorem bagBirth_edgeStoreBatch {X R : Type*} [Fintype X]
    [Field R] [CharZero R] (B : ℕ) (μ : X → R) (x : X) (store : R) (hx : μ x ≠ 0)
    (F : Multiset X → R) (s : Multiset X) :
    bagBirth B μ (edgeStoreBatch x (μ x) store) F s =
      (if s.card ≤ B then F s else 0) +
        (if s.card+1 ≤ B then store*F (s+{x}) else 0) := by
  unfold bagBirth
  simp_rw [memoryBirthIntegral_edgeStoreBatch μ x store hx]
  have hi (a : ℕ) : (if a=0 then F s else if a=1 then store*F (s+{x}) else 0) =
      (if a=0 then F s else 0)+(if a=1 then store*F (s+{x}) else 0) := by
    by_cases h0 : a=0 <;> by_cases h1 : a=1 <;> simp_all
  simp_rw [hi]
  simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_range]
  have h0 : 0 < B+1-s.card ↔ s.card ≤ B := by omega
  have h1 : 1 < B+1-s.card ↔ s.card+1 ≤ B := by omega
  simp only [h0,h1]

/-- Actual indexed retrieval multiplicity, expressed by a multiset map. -/
def bagPointRemoval {X R : Type*} [AddCommMonoid R]
    (x : X) (F : Multiset X → R) (s : Multiset X) : R := by
  classical
  exact (s.map (fun y => if y=x then F (s-{y}) else 0)).sum

theorem bagPointRemoval_tupleBag {ι X R : Type*} [Fintype ι]
    [DecidableEq ι] [AddCommMonoid R]
    (x : X) (F : Multiset X → R) (a : ι → X) :
    bagPointRemoval x F (tupleBag a) =
      ∑ i, if a i=x then F (survivorBag {i} a) else 0 := by
  classical
  unfold bagPointRemoval
  conv_lhs => arg 1; arg 2; rw [tupleBag_eq_map]
  simp only [Multiset.map_map]
  change (∑ i, if a i=x then F (tupleBag a-{a i}) else 0) = _
  apply Finset.sum_congr rfl
  intro i _
  rw [survivorBag_eq_sub]
  simp [selectedBag]

theorem bagDeletionCard_edgePromotionBatch {X R : Type*} [Field R]
    (x : X) (v promotion : R) (F : Multiset X → R) (s : Multiset X) (a : ℕ) :
    bagDeletionCard a (edgePromotionBatch x v promotion) F s =
      if a=0 then v*F s else if a=1 then promotion*bagPointRemoval x F s else 0 := by
  classical
  by_cases ha0 : a=0
  · subst a
    simp [bagDeletionCard, edgePromotionBatch, Multiset.powersetCard_zero_left, mul_comm]
  by_cases ha1 : a=1
  · subst a
    simp only [bagDeletionCard, Multiset.powersetCard_one, Multiset.map_map,
      Function.comp_def, edgePromotionBatch, Multiset.singleton_ne_zero, ite_false,
      Multiset.singleton_inj, Nat.one_ne_zero, ite_true]
    unfold bagPointRemoval
    rw [← Multiset.sum_map_mul_left]
    apply congrArg Multiset.sum
    apply Multiset.map_congr rfl
    intro y _
    split_ifs <;> ring
  · simp only [ha0, ha1, ite_false]
    unfold bagDeletionCard
    apply Multiset.sum_eq_zero
    intro y hy
    rcases Multiset.mem_map.mp hy with ⟨t,ht,rfl⟩
    have htcard := (Multiset.mem_powersetCard.mp ht).2
    have hne0 : t ≠ 0 := by
      intro h
      simp only [h, Multiset.card_zero] at htcard
      exact ha0 htcard.symm
    have hne1 : t ≠ {x} := by
      intro h
      simp only [h, Multiset.card_singleton] at htcard
      exact ha1 htcard.symm
    simp [edgePromotionBatch, hne0, hne1]

/-- Exact fresh-or-indexed-promotion decomposition. -/
theorem bagDeletion_edgePromotionBatch {X R : Type*} [Field R]
    (x : X) (v promotion : R) (F : Multiset X → R) (s : Multiset X) :
    bagDeletion (edgePromotionBatch x v promotion) F s =
      v*F s + promotion*bagPointRemoval x F s := by
  rw [bagDeletion_eq_sum_card]
  simp_rw [bagDeletionCard_edgePromotionBatch]
  have hi (a : ℕ) : (if a=0 then v*F s else
      if a=1 then promotion*bagPointRemoval x F s else 0) =
      (if a=0 then v*F s else 0)+(if a=1 then promotion*bagPointRemoval x F s else 0) := by
    by_cases h0 : a=0 <;> by_cases h1 : a=1 <;> simp_all
  simp_rw [hi]
  simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_range,
    Nat.zero_lt_succ, ite_true]
  by_cases hs : s=0
  · subst s
    simp [bagPointRemoval]
  · have : 1 < s.card+1 := by
      have := Multiset.card_pos.mpr hs
      omega
    simp [this]

theorem symmetricMemoryIntegral_sum {ι X R : Type*}
    [Fintype ι] [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (F : ι → Multiset X → R) :
    symmetricMemoryIntegral B μ (fun s => ∑ i, F i s) =
      ∑ i, symmetricMemoryIntegral B μ (F i) := by
  unfold symmetricMemoryIntegral
  simp only [Finset.mul_sum, Finset.sum_div]
  conv_lhs => arg 2; ext n; rw [Finset.sum_comm]
  rw [Finset.sum_comm]

/-- Symmetric fixed-position edge with a completely general joint endpoint
label multiplier. This retains restrictions involving both active labels. -/
def bagLabelEdgeApply {P R : Type*} [Fintype P] {Line : P → Type*}
    [∀ p, Fintype (Line p)] [Field R]
    (B : ℕ) (ν : P → R) (sourceAnchor targetAnchor : ∀ p, Line p)
    (store promote : R)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (geometry : P → P → R) (F : P → Multiset (AnchoredParticle P Line) → R)
    (p : P) (s : Multiset (AnchoredParticle P Line)) : R :=
  ∑ q, geometry p q * bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
    (anchorPrime sourceAnchor p) (anchorPrime targetAnchor q) (ν p) (ν q) store promote
    sourceDamping targetDamping (F q) s

/-- Integration over actual active prime labels reverses the entire local
symmetric edge, transposing arbitrary joint endpoint restrictions. -/
theorem bagLabelEdgeApply_adjoint {P R : Type*} [Fintype P] {Line : P → Type*}
    [∀ p, Fintype (Line p)] [Field R] [CharZero R]
    (B : ℕ) (ν : P → R) (hν : ∀ p, ν p ≠ 0)
    (sourceAnchor targetAnchor : ∀ p, Line p) (store promote : R)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (geometry : P → P → R) (F G : P → Multiset (AnchoredParticle P Line) → R) :
    (∑ p, ν p * symmetricMemoryIntegral B (fun x : AnchoredParticle P Line => ν x.1)
      (fun s => G p s * bagLabelEdgeApply B ν sourceAnchor targetAnchor store promote
        sourceDamping targetDamping geometry F p s)) =
    ∑ q, ν q * symmetricMemoryIntegral B (fun x : AnchoredParticle P Line => ν x.1)
      (fun s => F q s * bagLabelEdgeApply B ν targetAnchor sourceAnchor promote store
        targetDamping sourceDamping (fun q p => geometry p q) G q s) := by
  unfold bagLabelEdgeApply
  simp only [Finset.mul_sum, symmetricMemoryIntegral_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q _
  apply Finset.sum_congr rfl
  intro p _
  have h := bagEdgeTransfer_adjoint B (fun x : AnchoredParticle P Line => ν x.1)
    (anchorPrime sourceAnchor p) (anchorPrime targetAnchor q) (ν p) (ν q) store promote
    (hν p) (hν q) sourceDamping targetDamping (F q) (G p)
  calc
    _ = geometry p q * (ν p * symmetricMemoryIntegral B
        (fun x : AnchoredParticle P Line => ν x.1)
        (fun s => G p s * bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
          (anchorPrime sourceAnchor p) (anchorPrime targetAnchor q)
          (ν p) (ν q) store promote sourceDamping targetDamping (F q) s)) := by
      rw [← mul_assoc, mul_comm (geometry p q) (ν p), mul_assoc]
      congr 1
      rw [← symmetricMemoryIntegral_const_mul]
      congr 1
      funext s
      ring
    _ = geometry p q * (ν q * symmetricMemoryIntegral B
        (fun x : AnchoredParticle P Line => ν x.1)
        (fun s => F q s * bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
          (anchorPrime targetAnchor q) (anchorPrime sourceAnchor p)
          (ν q) (ν p) promote store targetDamping sourceDamping (G p) s)) := by rw [h]
    _ = _ := by
      rw [← mul_assoc, mul_comm (geometry p q) (ν q), mul_assoc]
      congr 1
      rw [← symmetricMemoryIntegral_const_mul]
      congr 1
      funext s
      ring

end Elliptic.Operator
