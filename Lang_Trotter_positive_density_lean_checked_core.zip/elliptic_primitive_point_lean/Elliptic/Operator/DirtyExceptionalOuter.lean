module

public import Elliptic.Operator.DirtyModePattern
public import Elliptic.Operator.PhysicalDirtyGoodFiber

/-!
# Literal exceptional outer-key integration

The ordinary modes are reindexed by their actual promotion pattern and
fresh tuple. This exposes precisely the fresh law in the source's second
good-state test, including the transformed prime weights.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirtyExceptionalOuter
open scoped BigOperators
open PhysicalDirtyPartition PhysicalDirtyOuter
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- Admissibility is maximality of the distinguished promoted group. -/
def Admissible (i : Fin K) (k : Key value s i) : Prop :=
  ∀ j ∈ keyPromotedGroups value s i k, j ≤ i

/-- Reconstruct the original outer key from a pattern and actual fresh tuple. -/
def assembleKey (i : Fin K) (I : DirtyModePattern.Pattern i)
    (a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size)
    (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
    (fresh : DirtyModePattern.Fresh (P:=P) I.1) : Key value s i :=
  (a,b,store,DirtyModePattern.assemble i I fresh)

theorem assembleKey_pattern (i : Fin K) (I : DirtyModePattern.Pattern i)
    (a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size)
    (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
    (fresh : DirtyModePattern.Fresh (P:=P) I.1) :
    keyPromotedGroups value s i (assembleKey value s i I a b store fresh) = I.1 :=
  by
    simpa only [keyPromotedGroups, assembleKey, DirtyModePattern.promotedSet] using
      DirtyModePattern.promotedSet_assemble i I fresh

theorem assembleKey_freshProduct (i : Fin K) (I : DirtyModePattern.Pattern i)
    (a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size)
    (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
    (fresh : DirtyModePattern.Fresh (P:=P) I.1) :
    keyFreshProduct value s i (assembleKey value s i I a b store fresh) =
      freshPrimeTupleProduct (fun j : {j : Fin K // j ∉ I.1} => value j) fresh := by
  unfold keyFreshProduct assembleKey
  have h := DirtyModePattern.assemble_product i I fresh value
  unfold freshPrimeTupleProduct
  rw [← h]
  apply Finset.prod_congr rfl
  intro j _
  dsimp only
  cases he : DirtyModePattern.assemble i I fresh j <;> simp [he]

/-- Store and promoted-mode factors, with no fresh mass included. -/
def oldStoreFactor (V : Fin K → ℝ) (ρ v0 : ℝ) (i : Fin K)
    (I : Finset (Fin K)) (b : Bool) (store : {j : Fin K // j ≠ i} → Bool) : ℝ :=
  (V i)⁻¹ * (v0 ^ b.toNat / v0) *
    ∏ j : {j : Fin K // j ≠ i}, v0 ^ (store j).toNat *
      (if j.1 ∈ I then (V j)⁻¹ / (v0*(1-ρ)) else 1)

variable [∀ i, Fintype (P i)]

/-- Exact factorization of the old-index/store coefficient into its
fresh-independent oldStoreFactor and the literal independent fresh mass. -/
theorem assembleKey_coefficient (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (i : Fin K) (I : DirtyModePattern.Pattern i)
    (a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size)
    (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
    (fresh : DirtyModePattern.Fresh (P:=P) I.1) :
    coefficient value s ν V ρ v0 i (assembleKey value s i I a b store fresh) =
      oldStoreFactor V ρ v0 i I.1 b store *
        freshPrimeTupleMass (fun j : {j : Fin K // j ∉ I.1} => ν j) fresh := by
  unfold coefficient assembleKey
  rw [DirtyOuterBudget.assembled_product]
  have hp :
      (∏ j : {j : Fin K // j ≠ i}, DirtyOuterBudget.coefficient (ν j) (V j) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B j) (store j)
        (DirtyModePattern.assemble i I fresh j)) =
      (∏ j : {j : Fin K // j ≠ i}, v0 ^ (store j).toNat *
        (if j.1 ∈ I.1 then (V j)⁻¹ / (v0*(1-ρ)) else 1)) *
        freshPrimeTupleMass (fun j : {j : Fin K // j ∉ I.1} => ν j) fresh := by
    unfold freshPrimeTupleMass
    rw [← DirtyModePattern.assemble_product i I fresh ν]
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro j _
    by_cases hj : j.1 ∈ I.1
    · simp [DirtyModePattern.assemble,hj,DirtyOuterBudget.coefficient,
        DirtyOuterBudget.mode,dirtyGroupCoefficient,div_eq_mul_inv]
      ring
    · simp [DirtyModePattern.assemble,hj,DirtyOuterBudget.coefficient,
        DirtyOuterBudget.mode,dirtyGroupCoefficient]
      ring
  rw [hp]
  unfold oldStoreFactor dirtyGroupCoefficient
  ring

/-- Exact exceptional fresh integration for one promoted set, one old
index and fixed stores. No exceptional-mass estimate is assumed here. -/
theorem sum_fresh_exceptional (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 d₀ β δ : ℝ)
    (i : Fin K) (I : DirtyModePattern.Pattern i)
    (a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size)
    (b : Bool) (store : {j : Fin K // j ≠ i} → Bool) :
    (∑ fresh : DirtyModePattern.Fresh (P:=P) I.1,
      if PhysicalDirtyGoodFiber.Separated value s d₀ β δ i
          (assembleKey value s i I a b store fresh) then 0 else
        coefficient value s ν V ρ v0 i (assembleKey value s i I a b store fresh)) =
      oldStoreFactor V ρ v0 i I.1 b store *
        SourceSecondGoodState.exceptionalMass (SourceSecondGoodState.trialProducts value
          (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) d₀ I.1 i)
          (fun j : {j : Fin K // j ∉ I.1} => value j)
          (fun j : {j : Fin K // j ∉ I.1} => ν j) β δ := by
  unfold SourceSecondGoodState.exceptionalMass
  rw [Finset.mul_sum]
  apply Finset.sum_congr
  · ext fresh; simp
  intro fresh _
  unfold PhysicalDirtyGoodFiber.Separated
  rw [assembleKey_pattern,assembleKey_freshProduct,assembleKey_coefficient]
  split_ifs <;> simp


/-- Exact reindexing of all admissible exceptional keys. The finite sum
on the right is over genuine promoted patterns and their fresh laws. -/
theorem sum_keys_exceptional (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 d₀ β δ : ℝ)
    (i : Fin K) :
    (∑ k : Key value s i,
      if Admissible value s i k ∧ ¬PhysicalDirtyGoodFiber.Separated value s d₀ β δ i k
        then coefficient value s ν V ρ v0 i k else 0) =
      ∑ a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size,
        ∑ b : Bool, ∑ store : {j : Fin K // j ≠ i} → Bool,
          ∑ I : DirtyModePattern.Pattern i,
            if (∀ j ∈ I.1, j ≤ i) then oldStoreFactor V ρ v0 i I.1 b store *
              SourceSecondGoodState.exceptionalMass (SourceSecondGoodState.trialProducts value
                (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
                  d₀ I.1 i)
                (fun j : {j : Fin K // j ∉ I.1} => value j)
                (fun j : {j : Fin K // j ∉ I.1} => ν j) β δ else 0 := by
  unfold Key
  simp only [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  apply Finset.sum_congr rfl
  intro store _
  rw [DirtyModePattern.sum_modes]
  apply Finset.sum_congr rfl
  intro I _
  by_cases hmax : ∀ j ∈ I.1, j ≤ i
  · rw [ite_eq_left hmax]
    rw [← sum_fresh_exceptional value s ν V ρ v0 d₀ β δ i I a b store]
    apply Finset.sum_congr rfl
    intro fresh _
    change (if Admissible value s i (assembleKey value s i I a b store fresh) ∧ _ then _ else _) = _
    have had : Admissible value s i (assembleKey value s i I a b store fresh) := by
      simpa only [Admissible,assembleKey_pattern] using hmax
    simp only [assembleKey] at had ⊢
    simp [had,ite_not]
  · rw [ite_eq_right hmax]
    apply Finset.sum_eq_zero
    intro fresh _
    change (if Admissible value s i (assembleKey value s i I a b store fresh) ∧ _ then _ else _) = _
    have had : ¬Admissible value s i (assembleKey value s i I a b store fresh) := by
      simpa only [Admissible,assembleKey_pattern] using hmax
    simp [had]

/-- Exact integration of all store bits in one promotion pattern. -/
theorem sum_stores (V : Fin K → ℝ) (ρ v0 : ℝ) (i : Fin K) (I : Finset (Fin K)) :
    (∑ b : Bool, ∑ store : {j : Fin K // j ≠ i} → Bool,
      oldStoreFactor V ρ v0 i I b store) =
      ((1+v0)*(V i)⁻¹/v0) * ∏ j : {j : Fin K // j ≠ i},
        (1+v0) * (if j.1 ∈ I then (V j)⁻¹/(v0*(1-ρ)) else 1) := by
  have hstore : (∑ store : {j : Fin K // j ≠ i} → Bool,
      ∏ j : {j : Fin K // j ≠ i}, v0^(store j).toNat *
        (if j.1 ∈ I then (V j)⁻¹/(v0*(1-ρ)) else 1)) =
      ∏ j : {j : Fin K // j ≠ i},
        (1+v0) * (if j.1 ∈ I then (V j)⁻¹/(v0*(1-ρ)) else 1) := by
    have hs := Fintype.prod_sum (fun (j : {j : Fin K // j ≠ i}) (b : Bool) =>
      v0^b.toNat * (if j.1 ∈ I then (V j)⁻¹/(v0*(1-ρ)) else 1))
    rw [← hs]
    apply Finset.prod_congr rfl
    intro j _
    simp only [Fintype.sum_bool,Bool.toNat_true,Bool.toNat_false,pow_one,pow_zero]
    ring
  unfold oldStoreFactor
  simp only [← Finset.mul_sum,hstore,← Finset.sum_mul,Fintype.sum_bool,
    Bool.toNat_true,Bool.toNat_false,pow_one,pow_zero]
  ring

/-- The old/store factor is nonnegative under the actual Schur parameters. -/
theorem oldStoreFactor_nonneg (V : Fin K → ℝ) (ρ v0 : ℝ) (i : Fin K)
    (I : Finset (Fin K)) (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
    (hV : ∀ j, 0 ≤ V j) (hρ : ρ<1) (hv0 : 0≤v0) :
    0 ≤ oldStoreFactor V ρ v0 i I b store := by
  unfold oldStoreFactor
  apply mul_nonneg
  · have := hV i; positivity
  · apply Finset.prod_nonneg
    intro j _
    have := hV j
    apply mul_nonneg (by positivity)
    split_ifs <;> positivity

/-- A pattern costs only a fixed constant per ordinary group. -/
theorem sum_stores_le (V : Fin K → ℝ) (ρ v0 vmin : ℝ) (i : Fin K)
    (I : Finset (Fin K)) (hV : ∀ j, vmin ≤ V j)
    (hmin : 0<vmin) (hv0 : 0<v0) (hρ : ρ<1) :
    (∑ b : Bool, ∑ store : {j : Fin K // j ≠ i} → Bool,
      oldStoreFactor V ρ v0 i I b store) ≤
      ((1+v0)*vmin⁻¹/v0) *
        ((1+v0)*max 1 (vmin⁻¹/(v0*(1-ρ)))) ^ Fintype.card {j : Fin K // j ≠ i} := by
  rw [sum_stores]
  apply mul_le_mul
  · apply div_le_div_of_nonneg_right _ hv0.le
    exact mul_le_mul_of_nonneg_left (inv_anti₀ hmin (hV i)) (by positivity)
  · calc
      _ ≤ ∏ _j : {j : Fin K // j ≠ i},
          (1+v0)*max 1 (vmin⁻¹/(v0*(1-ρ))) := by
        apply Finset.prod_le_prod₀
        · intro j _
          have hVi := hmin.trans_le (hV j)
          apply mul_nonneg (by positivity)
          split_ifs <;> positivity
        · intro j _
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          split_ifs
          · exact (div_le_div_of_nonneg_right (inv_anti₀ hmin (hV j)) (by positivity)).trans
              (le_max_right _ _)
          · exact le_max_left _ _
      _ = _ := by simp
  · apply Finset.prod_nonneg
    intro j _
    have hVi := hmin.trans_le (hV j)
    apply mul_nonneg (by positivity)
    split_ifs <;> positivity
  · positivity


/-- Uniform store budget for a fixed promotion pattern. -/
def storeBudget (ρ v0 vmin : ℝ) (i : Fin K) : ℝ :=
  ((1+v0)*vmin⁻¹/v0) *
    ((1+v0)*max 1 (vmin⁻¹/(v0*(1-ρ)))) ^ Fintype.card {j : Fin K // j ≠ i}

theorem pattern_card_le (i : Fin K) :
    Fintype.card (DirtyModePattern.Pattern i) ≤ 2^K := by
  have h := Fintype.card_subtype_le (fun I : Finset (Fin K) => i ∈ I)
  simpa only [Fintype.card_finset,Fintype.card_fin] using h

/-- Integrate a bound for the actual fresh-law exceptional mass over
all ordinary stores, patterns and the one distinguished old index. -/
theorem sum_exceptional_le_of_mass
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin d₀ β δ E : ℝ)
    (i : Fin K) (hV : ∀ j, vmin ≤ V j) (hmin : 0<vmin)
    (hv0 : 0<v0) (hρ : ρ<1) (hE : 0≤E)
    (hν : ∀ j p, 0≤ν j p)
    (hmass : ∀ I : DirtyModePattern.Pattern i, (∀ j ∈ I.1, j ≤ i) →
      SourceSecondGoodState.exceptionalMass (SourceSecondGoodState.trialProducts value
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) d₀ I.1 i)
        (fun j : {j : Fin K // j ∉ I.1} => value j)
        (fun j : {j : Fin K // j ∉ I.1} => ν j) β δ ≤ E) :
    (∑ k : Key value s i,
      if Admissible value s i k ∧ ¬PhysicalDirtyGoodFiber.Separated value s d₀ β δ i k
        then coefficient value s ν V ρ v0 i k else 0) ≤
      B*(2:ℝ)^K*storeBudget ρ v0 vmin i*E := by
  let mass := fun I : DirtyModePattern.Pattern i =>
    SourceSecondGoodState.exceptionalMass (SourceSecondGoodState.trialProducts value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) d₀ I.1 i)
      (fun j : {j : Fin K // j ∉ I.1} => value j)
      (fun j : {j : Fin K // j ∉ I.1} => ν j) β δ
  let term := fun (b : Bool) (store : {j : Fin K // j ≠ i} → Bool)
      (I : DirtyModePattern.Pattern i) =>
    if (∀ j ∈ I.1, j ≤ i) then oldStoreFactor V ρ v0 i I.1 b store * mass I else 0
  have hswap : (∑ b, ∑ store, ∑ I, term b store I) =
      ∑ I, ∑ b, ∑ store, term b store I := by
    calc
      _ = ∑ b, ∑ I, ∑ store, term b store I := by
        apply Finset.sum_congr rfl
        intro b _
        exact Finset.sum_comm
      _ = _ := Finset.sum_comm
  have hbudget : 0≤storeBudget ρ v0 vmin i := by unfold storeBudget; positivity
  have hI (I : DirtyModePattern.Pattern i) :
      (∑ b, ∑ store, term b store I) ≤ storeBudget ρ v0 vmin i*E := by
    by_cases hmax : ∀ j ∈ I.1, j ≤ i
    · have ht (b : Bool) (store : {j : Fin K // j ≠ i} → Bool) :
          term b store I = oldStoreFactor V ρ v0 i I.1 b store * mass I := by
        exact ite_eq_left hmax
      simp only [ht, ← Finset.sum_mul]
      apply mul_le_mul
      · exact sum_stores_le V ρ v0 vmin i I.1 hV hmin hv0 hρ
      · exact hmass I hmax
      · exact SourceSecondGoodState.exceptionalMass_nonneg _ _ _ _ _ (fun j p => hν j p)
      · exact hbudget
    · simp only [term,hmax,ite_false,Finset.sum_const_zero]
      exact mul_nonneg hbudget hE
  have htotal : (∑ I, ∑ b, ∑ store, term b store I) ≤
      (2:ℝ)^K*storeBudget ρ v0 vmin i*E := by
    calc
      _ ≤ ∑ _I : DirtyModePattern.Pattern i, storeBudget ρ v0 vmin i*E :=
        Finset.sum_le_sum fun I _ => hI I
      _ = (Fintype.card (DirtyModePattern.Pattern i):ℝ)*(storeBudget ρ v0 vmin i*E) := by simp
      _ ≤ (2:ℝ)^K*(storeBudget ρ v0 vmin i*E) := by
        apply mul_le_mul_of_nonneg_right _ (mul_nonneg hbudget hE)
        exact_mod_cast pattern_card_le i
      _ = _ := by ring
  rw [sum_keys_exceptional value s ν V ρ v0 d₀ β δ i]
  change (∑ _a : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size,
    ∑ b, ∑ store, ∑ I, term b store I) ≤ _
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  rw [hswap]
  calc
    _ ≤ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i).size:ℝ)*
        ((2:ℝ)^K*storeBudget ρ v0 vmin i*E) :=
      mul_le_mul_of_nonneg_left htotal (Nat.cast_nonneg _)
    _ ≤ B*((2:ℝ)^K*storeBudget ρ v0 vmin i*E) := by
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      exact_mod_cast (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size_le
    _ = _ := by ring

/-- The source second good test, together with the pointwise prime-law
comparison, bounds the actual exceptional coefficient sum. No assumed
row bound or assumed exceptional bound under the transformed law enters. -/
theorem sum_exceptional_le_source
    (ν μ : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin d₀ β L : ℝ)
    (a : Fin K → ℝ) (i : Fin K)
    (hgood : SourceSecondGoodState.SecondGoodTest value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
      μ d₀ β L a)
    (hV : ∀ j, vmin ≤ V j) (hmin : 0<vmin) (hv0 : 0<v0) (hρ : ρ<1)
    (hν : ∀ j p, 0≤ν j p) (hνμ : ∀ j p, ν j p ≤ 2*μ j p) :
    (∑ k : Key value s i,
      if Admissible value s i k ∧ ¬PhysicalDirtyGoodFiber.Separated value s d₀ β
        (100*Real.exp (-(L^a i))) i k then coefficient value s ν V ρ v0 i k else 0) ≤
      B*(2:ℝ)^K*storeBudget ρ v0 vmin i*
        ((2:ℝ)^K*Real.exp (-(L^a i)/4)) := by
  apply sum_exceptional_le_of_mass value s ν V ρ v0 vmin d₀ β _ _ i
    hV hmin hv0 hρ (by positivity) hν
  intro I hmax
  have htransfer := SourceSecondGoodState.exceptionalMass_le
    (SourceSecondGoodState.trialProducts value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) d₀ I.1 i)
    (fun j : {j : Fin K // j ∉ I.1} => value j)
    (fun j : {j : Fin K // j ∉ I.1} => ν j)
    (fun j : {j : Fin K // j ∉ I.1} => μ j)
    (fun _ => (2:ℝ)) β (100*Real.exp (-(L^a i)))
    (fun j p => hν j p) (fun j p => hνμ j p)
  have hcount : Fintype.card {j : Fin K // j ∉ I.1} ≤ K := by
    simpa only [Fintype.card_fin] using Fintype.card_subtype_le (fun j : Fin K => j ∉ I.1)
  have hpow : (2:ℝ)^Fintype.card {j : Fin K // j ∉ I.1} ≤ (2:ℝ)^K :=
    pow_le_pow_right₀ (by norm_num) hcount
  simp only [Finset.prod_const,Finset.card_univ] at htransfer
  exact htransfer.trans ((mul_le_mul_of_nonneg_left (hgood I.1 i I.property hmax)
    (by positivity)).trans (mul_le_mul_of_nonneg_right hpow (Real.exp_pos _).le))


/-- Specialization to the literal transformed prime law from the source
independent-line normalization. Its comparison with the original law is
proved from the displayed visit-size bound. -/
theorem sum_exceptional_le_transformed {τ : Type*}
    (visits : Finset τ) (η : τ → ℝ) (V : Fin K → ℝ)
    (ρ v0 vmin d₀ β L pmin : ℝ) (a : Fin K → ℝ) (i : Fin K)
    (hgood : SourceSecondGoodState.SecondGoodTest value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
      (fun j p => 1/(V j*(value j p:ℝ))) d₀ β L a)
    (hV : ∀ j, vmin ≤ V j) (hmin : 0<vmin) (hv0 : 0<v0) (hρ : ρ<1)
    (hpmin : 0<pmin) (hp : ∀ j p, pmin ≤ (value j p:ℝ))
    (hη : ∀ t ∈ visits, η t ≤ 1) (hsize : 2*(visits.card:ℝ)≤pmin) :
    (∑ k : Key value s i,
      if Admissible value s i k ∧ ¬PhysicalDirtyGoodFiber.Separated value s d₀ β
        (100*Real.exp (-(L^a i))) i k then
        coefficient value s (fun j p => transformedPrimeMass visits η (V j) (value j p))
          V ρ v0 i k else 0) ≤
      B*(2:ℝ)^K*storeBudget ρ v0 vmin i*((2:ℝ)^K*Real.exp (-(L^a i)/4)) := by
  apply sum_exceptional_le_source value s
    (fun j p => transformedPrimeMass visits η (V j) (value j p))
    (fun j p => 1/(V j*(value j p:ℝ))) V ρ v0 vmin d₀ β L a i
    hgood hV hmin hv0 hρ
  · intro j p
    exact (SourceSecondGoodState.transformedPrimeMass_le_twice visits η (V j) pmin
      (value j p) (hmin.trans_le (hV j)) hpmin (hp j p) hη hsize).1
  · intro j p
    exact (SourceSecondGoodState.transformedPrimeMass_le_twice visits η (V j) pmin
      (value j p) (hmin.trans_le (hV j)) hpmin (hp j p) hη hsize).2

end Elliptic.Operator.DirtyExceptionalOuter
