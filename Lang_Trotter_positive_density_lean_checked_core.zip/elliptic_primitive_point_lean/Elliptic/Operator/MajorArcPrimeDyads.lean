module
public import Elliptic.Operator.MajorArcCenteredEndpointSaving
public import Elliptic.Operator.WeightedSchur
public import Mathlib.Data.Nat.Log

/-! Exact dyadic decomposition of the isolated prime and its finite energy budget. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcPrimeDyads
open Filter MeasureTheory Set
open scoped BigOperators
open MellinPrimeSeparation
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

def indices (S : Finset ℕ) : Finset ℕ := S.image (Nat.log 2)
def block (S : Finset ℕ) (j : ℕ) : Finset ℕ := S.filter (fun p=>Nat.log 2 p=j)
def scale (j : ℕ) : ℝ := (2:ℝ)^j

 theorem sum_blocks {A : Type*} [AddCommMonoid A] (S : Finset ℕ) (f : ℕ→A) :
    (∑p∈S,f p)=∑j∈indices S,∑p∈block S j,f p := by
  symm
  exact Finset.sum_fiberwise_of_maps_to (fun p hp=>Finset.mem_image.mpr ⟨p,hp,rfl⟩) f

 theorem block_mem (S : Finset ℕ) (hS : ∀p∈S,0<p) (j p : ℕ) (hp : p∈block S j) :
    p∈S ∧ scale j≤p ∧ (p:ℝ)<2*scale j := by
  obtain ⟨hp,hj⟩ := Finset.mem_filter.mp hp
  have h1 := Nat.pow_log_le_self 2 (hS p hp).ne'
  have h2 := Nat.lt_pow_succ_log_self (by norm_num : 1<2) p
  rw [hj] at h1 h2
  refine ⟨hp,by unfold scale;exact_mod_cast h1,?_⟩
  have hh : (p:ℝ)<(2:ℝ)^(j+1) := by exact_mod_cast h2
  simpa only [pow_succ,mul_comm,scale] using hh

 theorem block_scale_log_bounds (S : Finset ℕ) (hS : ∀p∈S,0<p) (a b : ℝ)
    (hlog : ∀p∈S,a≤Real.log p ∧ Real.log p≤b) (j : ℕ) (hj : j∈indices S) :
    a-Real.log 2≤Real.log (scale j) ∧ Real.log (scale j)≤b := by
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hj
  have hb := block_mem S hS (Nat.log 2 p) p (Finset.mem_filter.mpr ⟨hp,rfl⟩)
  have hsc : 0<scale (Nat.log 2 p) := by unfold scale;positivity
  have hlo := Real.log_le_log (show (0:ℝ)<p by exact_mod_cast hS p hp) hb.2.2.le
  have hhi := Real.log_le_log hsc hb.2.1
  rw [Real.log_mul (by norm_num : (2:ℝ)≠0) hsc.ne'] at hlo
  constructor <;> linarith [(hlog p hp).1,(hlog p hp).2]

 theorem indices_card_le (S : Finset ℕ) (hS : ∀p∈S,0<p) (T : ℝ) (hT : 0≤T)
    (hheight : ∀p∈S,(p:ℝ)≤Real.exp T) :
    ((indices S).card:ℝ)≤T/Real.log 2+2 := by
  have hl2 : 0<Real.log (2:ℝ) := by positivity
  have hsub : indices S⊆Finset.range (⌈T/Real.log 2⌉₊+1) := by
    intro j hj
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hj
    have hcast : (2:ℝ)^(Nat.log 2 p)≤p := by exact_mod_cast Nat.pow_log_le_self 2 (hS p hp).ne'
    have hpow : (2:ℝ)^(Nat.log 2 p)≤Real.exp T := hcast.trans (hheight p hp)
    have hh := Real.log_le_log (by positivity : (0:ℝ)<(2:ℝ)^(Nat.log 2 p)) hpow
    rw [Real.log_pow,Real.log_exp] at hh
    have hj : (Nat.log 2 p:ℝ)≤T/Real.log 2 := (le_div_iff₀ hl2).mpr hh
    have hnat : Nat.log 2 p≤⌈T/Real.log 2⌉₊ := by exact_mod_cast hj.trans (Nat.le_ceil _)
    exact Finset.mem_range.mpr (by omega)
  have hc : ((indices S).card:ℝ)≤(⌈T/Real.log 2⌉₊:ℝ)+1 := by
    have hh := Finset.card_le_card hsub
    simp only [Finset.card_range] at hh
    exact_mod_cast hh
  have hh := Nat.ceil_lt_add_one (show 0≤T/Real.log 2 by positivity)
  linarith

 theorem source_indices_card (S : Finset ℕ) (hS : ∀p∈S,0<p) (C L : ℝ) (hC : 0≤C) (hL : 1≤L)
    (hheight : ∀p∈S,(p:ℝ)≤Real.exp (C*L^(1/5:ℝ))) :
    ((indices S).card:ℝ)≤(C/Real.log 2+2)*L^(1/5:ℝ) := by
  apply (indices_card_le S hS _ (by positivity) hheight).trans
  have hpow : 1≤L^(1/5:ℝ) := Real.one_le_rpow hL (by norm_num)
  calc
    _ = (C/Real.log 2)*L^(1/5:ℝ)+2 := by ring
    _ ≤ _ := by nlinarith

 theorem endpoint_partition (S R : Finset ℕ) (c d : ℕ→ℂ) (η : ℝ→ℂ) (lam Y t : ℝ) :
    endpoint S R c d η lam Y t=∑j∈indices S,endpoint (block S j) R c d η lam Y t := by
  exact sum_blocks S _

/-- Weighted finite energy summation; no disjointness of the functions is assumed. -/
 theorem finite_energy_sum {A : Type*} (s : Finset A) (w : A→ℂ) (F : A→ℝ→ℂ)
    (hF : ∀i∈s,Continuous (F i)) (a b E : ℝ)
    (henergy : ∀i∈s,(∫v in Icc a b,‖F i v‖^2)≤E) :
    (∫v in Icc a b,‖∑i∈s,w i*F i v‖^2)≤(∑i∈s,‖w i‖)^2*E := by
  let W := ∑i∈s,‖w i‖
  have hW : 0≤W := Finset.sum_nonneg (fun i _=>norm_nonneg _)
  have hi (i:A) (h:i∈s) : IntegrableOn (fun v=>‖F i v‖^2) (Icc a b) :=
    ((hF i h).norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  have hsumc : Continuous (fun v=>∑i∈s,w i*F i v) := by
    apply continuous_finsetSum
    intro i hi
    exact continuous_const.mul (hF i hi)
  have hiw : IntegrableOn (fun v=>∑i∈s,‖w i‖*‖F i v‖^2) (Icc a b) := by
    exact integrable_finsetSum s (fun i h=>(hi i h).const_mul (‖w i‖))
  calc
    _ ≤ ∫v in Icc a b,W*(∑i∈s,‖w i‖*‖F i v‖^2) := by
      apply setIntegral_mono_on (hsumc.norm.pow 2 |>.continuousOn.integrableOn_compact isCompact_Icc)
        (hiw.const_mul W) measurableSet_Icc
      intro v hv
      apply (pow_le_pow_left₀ (norm_nonneg _) (norm_sum_le _ _) 2).trans
      simp only [norm_mul]
      have hh := weighted_sum_sq_le s (fun i=>‖w i‖) (fun _=>1) (fun i=>‖F i v‖)
        (fun i _=>norm_nonneg _) (by intros;norm_num)
      simpa only [mul_one,div_one,W] using hh
    _ = W*(∑i∈s,‖w i‖*(∫v in Icc a b,‖F i v‖^2)) := by
      rw [integral_const_mul,integral_finsetSum s (fun i h=>(hi i h).const_mul (‖w i‖))]
      simp only [integral_const_mul]
    _ ≤ W*(∑i∈s,‖w i‖*E) := by
      apply mul_le_mul_of_nonneg_left _ hW
      exact Finset.sum_le_sum (fun i h=>mul_le_mul_of_nonneg_left (henergy i h) (norm_nonneg _))
    _ = _ := by rw [←Finset.sum_mul];dsimp [W];ring


/-- Uniform source budgets for every nonempty isolated-prime dyad. -/
 theorem eventually_source_blocks (c C : ℝ) (hc : 0<c) (hC : 0≤C) :
    ∀ᶠL:ℝ in atTop,∀S:Finset ℕ,(∀p∈S,0<p)→
      (∀p∈S,c*L^(1/10:ℝ)≤Real.log p ∧ Real.log p≤C*L^(1/5:ℝ))→
      ((indices S).card:ℝ)≤L ∧ ∀j∈indices S,
        (c/2)*L^(1/10:ℝ)≤Real.log (scale j) ∧ Real.log (scale j)≤C*L^(1/5:ℝ) := by
  filter_upwards [MajorArcSparseAsymptotics.eventually_mul_rpow_le (C/Real.log 2+2) 1 (1/5) 1
    (by norm_num) (by norm_num),
    MajorArcSparseAsymptotics.eventually_mul_rpow_le (Real.log 2) (c/2) 0 (1/10)
      (by linarith) (by norm_num),eventually_ge_atTop (1:ℝ)] with L hcard hlog2 hL
  intro S hS hlog
  simp only [Real.rpow_zero,mul_one] at hlog2
  simp only [Real.rpow_one,one_mul] at hcard
  constructor
  · apply (source_indices_card S hS C L hC hL _).trans hcard
    intro p hp
    simpa only [Real.exp_log (show (0:ℝ)<p by exact_mod_cast hS p hp)] using Real.exp_le_exp.mpr (hlog p hp).2
  · intro j hj
    have hh := block_scale_log_bounds S hS (c*L^(1/10:ℝ)) (C*L^(1/5:ℝ)) hlog j hj
    exact ⟨by linarith,hh.2⟩

/-- Summing at most L actual dyadic energies costs only two logarithmic powers. -/
 theorem finite_energy_sum_saving {A : Type*} (s : Finset A) (F : A→ℝ→ℂ)
    (hF : ∀i∈s,Continuous (F i)) (a b L E : ℝ) (hL : 0<L)
    (hcard : (s.card:ℝ)≤L)
    (henergy : ∀i∈s,(∫v in Icc a b,‖F i v‖^2)≤L^(-E-2)) :
    (∫v in Icc a b,‖∑i∈s,F i v‖^2)≤L^(-E) := by
  have hh := finite_energy_sum s (fun _=>(1:ℂ)) F hF a b (L^(-E-2)) henergy
  simp only [one_mul,norm_one,Finset.sum_const,nsmul_eq_mul,mul_one] at hh
  apply hh.trans
  calc
    _ ≤ L^2*L^(-E-2) := mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (Nat.cast_nonneg _) hcard 2) (Real.rpow_nonneg hL.le _)
    _ = _ := by
      rw [←Real.rpow_natCast L 2,←Real.rpow_add hL]
      congr 1
      norm_num

end Elliptic.Operator.MajorArcPrimeDyads
