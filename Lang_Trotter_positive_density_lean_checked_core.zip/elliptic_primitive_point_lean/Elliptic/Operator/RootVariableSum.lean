module

public import Elliptic.Operator.RootGridPartition

/-!
# Root-dependent tests: exact partition and boundary domination

The test is evaluated at the literal normalized integer root and its
full determinant-one residue matrix. A half-open grid gives an exact
partition. Its bad-cell error is dominated by actual closed-box root
counts, without assuming an abstract integer-root discrepancy theorem.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootVariableSum
open SourceRootCount SourceRootTransfer RootArchimedeanGrid RootGridPartition
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

abbrev RootPoint := ℝ × ℝ × ℝ

def normalizedRoot (U V : ℝ) (t : RootTriple) : RootPoint :=
  ((t.1:ℝ)/U,(t.2.1:ℝ)/V,(t.2.2:ℝ)/t.1)

def InIntervals (I₁ I₂ I₃ : RootInterval) (q : RootPoint) : Prop :=
  I₁.Contains q.1 ∧ I₂.Contains q.2.1 ∧ I₃.Contains q.2.2

def variableRootSum (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) : ℂ :=
  ∑ t∈rootCandidates U V,
    if ht : Canonical t then
      if InIntervals I₁ I₂ I₃ (normalizedRoot U V t) then
        F (normalizedRoot U V t)
          (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod S)) (canonicalSL2 t ht))
      else 0
    else 0

def boxRootCount (U V : ℝ) (I₁ I₂ I₃ : RootInterval) : ℕ :=
  ((rootCandidates U V).filter fun t =>
    Canonical t ∧ InIntervals I₁ I₂ I₃ (normalizedRoot U V t)).card

theorem variableRootSum_eq_weighted (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (f : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀ q, InIntervals I₁ I₂ I₃ q → ∀ g, F q g=f g) :
    variableRootSum U V S I₁ I₂ I₃ F=weightedRootSum U V S I₁ I₂ I₃ f := by
  unfold variableRootSum weightedRootSum
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    by_cases hbox : InIntervals I₁ I₂ I₃ (normalizedRoot U V t)
    · have hbox' : I₁.Contains ((t.1:ℝ)/U) ∧ I₂.Contains ((t.2.1:ℝ)/V) ∧
          I₃.Contains ((t.2.2:ℝ)/t.1) := hbox
      rw [ite_eq_left hbox,ite_eq_left hbox',hF _ hbox]
    · have hbox' : ¬(I₁.Contains ((t.1:ℝ)/U) ∧ I₂.Contains ((t.2.1:ℝ)/V) ∧
          I₃.Contains ((t.2.2:ℝ)/t.1)) := hbox
      rw [ite_eq_right hbox,ite_eq_right hbox']
  · simp [hcan]

theorem variableRootSum_constant (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval)
    (f : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) :
    variableRootSum U V S I₁ I₂ I₃ (fun _ => f)=weightedRootSum U V S I₁ I₂ I₃ f :=
  variableRootSum_eq_weighted U V S I₁ I₂ I₃ (fun _ => f) f (fun _ _ _ => rfl)


theorem weightedRootSum_one (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval) :
    weightedRootSum U V S I₁ I₂ I₃ (fun _ => 1)=(boxRootCount U V I₁ I₂ I₃:ℂ) := by
  unfold weightedRootSum boxRootCount
  rw [Finset.card_eq_sum_ones]
  push_cast
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp [hcan,InIntervals,normalizedRoot]
  · simp [hcan]

theorem variableRootSum_norm_le_count (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀ q g, ‖F q g‖≤1) :
    ‖variableRootSum U V S I₁ I₂ I₃ F‖≤(boxRootCount U V I₁ I₂ I₃:ℝ) := by
  unfold variableRootSum boxRootCount
  rw [Finset.card_eq_sum_ones]
  push_cast
  rw [Finset.sum_filter]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan,hcan,true_and]
    by_cases hbox : InIntervals I₁ I₂ I₃ (normalizedRoot U V t)
    · simp only [ite_eq_left hbox]
      exact hF _ _
    · simp [hbox]
  · simp [hcan]

theorem part_count_le_closed (U V : ℝ) (n : ℕ) (j : Index) :
    boxRootCount U V (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) ≤
      boxRootCount U V (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) := by
  apply Finset.card_le_card
  intro t ht
  obtain ⟨ht,hcan,hbox⟩ := Finset.mem_filter.mp ht
  exact Finset.mem_filter.mpr ⟨ht,hcan,
    partCell_subset _ _ _ _ _ hbox.1,partCell_subset _ _ _ _ _ hbox.2.1,
    partCell_subset _ _ _ _ _ hbox.2.2⟩

theorem variableRootSum_partition (n : ℕ) (hn : 0<n) (U V : ℝ) (S : ℕ)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) :
    variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) F =
      ∑ j∈grid n, variableRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) F := by
  unfold variableRootSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    have h := grid_partition_sum n hn (normalizedRoot U V t)
      (F (normalizedRoot U V t)
        (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod S)) (canonicalSL2 t hcan)))
    simp only [PartContains,InRootBox,fullInterval,InIntervals,normalizedRoot,
      RootInterval.Contains,ite_true,and_assoc] at h ⊢
    by_cases hbox : 1≤(t.1:ℝ)/U ∧ (t.1:ℝ)/U≤16 ∧
        1≤(t.2.1:ℝ)/V ∧ (t.2.1:ℝ)/V≤2 ∧
        0≤(t.2.2:ℝ)/t.1 ∧ (t.2.2:ℝ)/t.1≤1
    · rw [ite_eq_left hbox] at h ⊢
      exact h.symm
    · rw [ite_eq_right hbox] at h ⊢
      exact h.symm
  · simp [hcan]

def offBoundaryTest (S : ℕ) (bad : Finset Index)
    (f : Index→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (j : Index) (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) : ℂ :=
  if j∈bad then 0 else f j g

theorem weightedRootSum_zero (U V : ℝ) (S : ℕ) (I₁ I₂ I₃ : RootInterval) :
    weightedRootSum U V S I₁ I₂ I₃ (fun _ => 0)=0 := by
  simp [weightedRootSum]

theorem closed_count_sum_eq_norm (U V : ℝ) (S : ℕ) (n : ℕ) (s : Finset Index) :
    (∑ j∈s, (boxRootCount U V (cell 1 16 n j.1) (cell 1 2 n j.2.1)
      (cell 0 1 n j.2.2):ℝ)) =
        ‖∑ j∈s, weightedRootSum U V S
          (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (fun _ => 1)‖ := by
  simp only [weightedRootSum_one,←Nat.cast_sum,Complex.norm_natCast]

/-- The exact discrete error from deleting the boundary cells is at
most their literal closed-box root mass. No discrepancy assumption is
used in this finite inequality. -/
theorem boundary_root_error (n : ℕ) (hn : 0<n) (bad : Finset Index)
    (hbad : bad⊆grid n) (U V : ℝ) (S : ℕ)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (f : Index→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀ q g, ‖F q g‖≤1)
    (hstable : ∀ j∈grid n, j∉bad → ∀ q, PartContains n j q → ∀ g, F q g=f j g) :
    ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) F -
      ∑ j∈grid n, weightedRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2)
          (offBoundaryTest S bad f j)‖ ≤
      ‖∑ j∈bad, weightedRootSum U V S
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (fun _ => 1)‖ := by
  rw [variableRootSum_partition n hn U V S F,←Finset.sum_sub_distrib,
    ←closed_count_sum_eq_norm]
  calc
    _ ≤ ∑ j∈grid n, ‖variableRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) F -
      weightedRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2)
          (offBoundaryTest S bad f j)‖ := norm_sum_le _ _
    _ ≤ ∑ j∈grid n, if j∈bad then
        (boxRootCount U V (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2):ℝ) else 0 := by
      apply Finset.sum_le_sum
      intro j hj
      by_cases hjbad : j∈bad
      · have he : offBoundaryTest S bad f j=(fun _ => 0) := by
          funext g
          exact ite_eq_left hjbad
        rw [he,weightedRootSum_zero,sub_zero,ite_eq_left hjbad]
        exact (variableRootSum_norm_le_count U V S
          (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) F hF).trans
          (by exact_mod_cast part_count_le_closed U V n j)
      · have he : offBoundaryTest S bad f j=f j := by
          funext g
          exact ite_eq_right hjbad
        rw [he,ite_eq_right hjbad]
        rw [variableRootSum_eq_weighted U V S _ _ _ F (f j)
          (fun q hq g => hstable j hj hjbad q hq g),sub_self,norm_zero]
    _ = _ := by
      rw [←Finset.sum_filter]
      congr 1
      ext j
      simp only [Finset.mem_filter]
      exact ⟨fun h => h.2,fun h => ⟨hbad h,h⟩⟩

end Elliptic.Operator.RootVariableSum
