module

public import Elliptic.Operator.GroupedGhostNorm
public import Elliptic.Operator.SymmetricTensorNorm

/-!
# The uniform ghost norm on the actual physical memory space

The one-group factorial norm is tensorized only on separately symmetric
tests, then compressed by the actual total-memory cutoff.  Positions and
active lists are integrated with their actual unchanged measures.  The
result has no cutoff-dependent constant and no assumed row, column,
adjoint, or tensor estimate.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalGhostNormDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

theorem groupedGhostTensor_symmetric_l2_sq_uniform [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : ∀ i p, Line i p)
    (H : (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    finiteL2Sq Finset.univ
      (fun m : PhysicalMemories P Line B => ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i))
      (groupedGhostTensorApply ν V η q ρ anchor (fun m => H (fun i => tupleBag (m i).values))) ≤
      ((Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I))^2 *
        finiteL2Sq Finset.univ
          (fun m : PhysicalMemories P Line B => ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i))
          (fun m => H (fun i => tupleBag (m i).values)) := by
  let X := fun i => MemoryState (AnchoredParticle (P i) (Line i)) B
  let bag := fun i (m : X i) => tupleBag m.values
  let μ := fun i (m : X i) => MemoryState.mass (anchoredParticleMass (ν i)) m
  let K := fun i => ghostTransition (ν i) (V i) η q ρ (anchor i) (B:=B)
  let C := Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ)
  have hμ : ∀ i m, 0 ≤ μ i m := by
    intro i m
    dsimp [μ, MemoryState.mass, anchoredParticleMass]
    exact div_nonneg (Finset.prod_nonneg (fun j _ => hν i _)) (by positivity)
  have hK : ∀ i, QuotientKernelSqBound (bag i) (μ i) (K i) (C^2) := by
    intro i F
    have h := ghostApply_symmetric_l2_sq_uniform (ν i) (V i) η q ρ Q Vmax s
      (anchor i) F (B:=B) (hν i) (hs i) hs0 hρ hQ hq0 hqQ hη0 hη1 (hV0 i) (hVmax i)
    unfold finiteL2Sq at h
    simp_rw [ghostApply_eq_transition_sum] at h
    exact h
  have ht := quotient_tensor_sq X (fun i => Multiset (AnchoredParticle (P i) (Line i)))
    bag μ K (fun _ => C^2) hμ (fun _ => sq_nonneg _) hK H
  rw [Finset.prod_pow] at ht
  simp only [Finset.prod_const, Finset.card_univ] at ht
  have heq (m : PhysicalMemories P Line B) : quotientTensorApply bag K H m =
      groupedGhostTensorApply ν V η q ρ anchor (fun m => H (fun i => tupleBag (m i).values)) m := by
    rw [groupedGhostTensorApply_eq_transition_sum]
    rfl
  simp_rw [heq] at ht
  exact ht

def physicalBagFunction
    (H : Z → PhysicalActiveLists P J →
      (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (t : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  H (t.position P Line J B) (t.active P Line J B)
    (fun i => tupleBag (t.memory P Line J B i).values)

set_option maxHeartbeats 800000 in
theorem physicalGhostOperation_symmetric_l2_sq_uniform [Fintype Z]
    [∀ i, Fintype (P i)] [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (H : Z → PhysicalActiveLists P J →
      (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      ((physicalGhostOperation ν V η q ρ anchor).apply (physicalBagFunction H)) ≤
      ((Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I))^2 *
        finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H) := by
  let F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ := physicalBagFunction H
  let C := (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I)
  let μ := fun m : PhysicalMemories P Line B =>
    ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i)
  have hμ : ∀ m, 0 ≤ μ m := by
    intro m
    apply Finset.prod_nonneg
    intro i _
    unfold MemoryState.mass anchoredParticleMass
    exact div_nonneg (Finset.prod_nonneg (fun j _ => hν i _)) (by positivity)
  have hfiber (z : Z) (a : PhysicalActiveLists P J) :
      finiteL2Sq Finset.univ μ
        (physicalGhostZeroExtension ((physicalGhostOperation ν V η q ρ anchor).apply F) z a) ≤
        C^2*finiteL2Sq Finset.univ μ (physicalGhostZeroExtension F z a) := by
    let Hb : (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ := fun b =>
      if (∑ i, (b i).card) ≤ B then H z a b else 0
    have hin (m : PhysicalMemories P Line B) :
        physicalGhostZeroExtension F z a m = Hb (fun i => tupleBag (m i).values) :=
      physicalGhostZeroExtension_bag_test H z a m
    have hout (m : PhysicalMemories P Line B) :
        physicalGhostZeroExtension ((physicalGhostOperation ν V η q ρ anchor).apply F) z a m =
        if (∑ i, (m i).size) ≤ B then
          groupedGhostTensorApply ν V η q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m else 0 := by
      unfold physicalGhostZeroExtension
      split_ifs with hm
      · rw [physicalGhostOperation_eq_compressed_tensor]
        change groupedGhostTensorApply ν V η q ρ (anchor z)
          (physicalGhostZeroExtension F z a) m = _
        congr 1
        exact funext hin
      · rfl
    rw [funext hout]
    have hcut : finiteL2Sq Finset.univ μ
        (fun m : PhysicalMemories P Line B => if (∑ i, (m i).size) ≤ B then
          groupedGhostTensorApply ν V η q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m else 0) ≤
        finiteL2Sq Finset.univ μ
          (groupedGhostTensorApply ν V η q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values))) := by
      apply Finset.sum_le_sum
      intro m _
      dsimp only
      split_ifs
      · exact le_rfl
      · simpa only [norm_zero, zero_pow (by decide : 2 ≠ 0), mul_zero] using
          mul_nonneg (hμ m) (sq_nonneg ‖groupedGhostTensorApply ν V η q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m‖)
    refine hcut.trans ?_
    rw [show physicalGhostZeroExtension F z a =
      (fun m => Hb (fun i => tupleBag (m i).values)) from funext hin]
    exact groupedGhostTensor_symmetric_l2_sq_uniform ν V η q ρ Q Vmax s (anchor z) Hb
      hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax
  change finiteL2Sq Finset.univ _ ((physicalGhostOperation ν V η q ρ anchor).apply F) ≤
    C^2 * finiteL2Sq Finset.univ _ F
  rw [physicalGhostZeroExtension_l2_sq, physicalGhostZeroExtension_l2_sq, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro z _
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro a _
  have ha : 0 ≤ ∏ i, tupleWeight (ν i) (a i) :=
    Finset.prod_nonneg (fun i _ => Finset.prod_nonneg (fun j _ => hν i _))
  have h := mul_le_mul_of_nonneg_left (hfiber z a) ha
  simpa only [mul_left_comm] using h

theorem physicalGhostOperation_symmetric_l2_uniform [Fintype Z]
    [∀ i, Fintype (P i)] [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (H : Z → PhysicalActiveLists P J →
      (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      ((physicalGhostOperation ν V η q ρ anchor).apply (physicalBagFunction H)) ≤
      (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I) *
        finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H) := by
  unfold finiteL2
  apply (Real.sqrt_le_sqrt (physicalGhostOperation_symmetric_l2_sq_uniform
    ν V η q ρ Q Vmax s anchor H hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax)).trans_eq
  rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (by positivity)]

end Elliptic.Operator
