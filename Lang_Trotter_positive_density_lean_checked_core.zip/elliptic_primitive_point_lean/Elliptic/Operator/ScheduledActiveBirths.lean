module

public import Elliptic.Operator.NumericBirthDistinctness
public import Elliptic.Operator.ScheduledHistory
public import Elliptic.Operator.ScheduledCoefficientFactorization

/-!
# Actual active draws and chronological birth masses

The initial active-list measure is kept outside the history weight. Later
fresh target draws are identified with active births using the raw condition
that the target unshared label is absent from the source active list.
The actual source cross-edge ban establishes this exclusion below. Applying
it on nonzero geometric support still requires extracting the ban from the
concrete geometric multiplier.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ScheduledPhysicalPath
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance scheduledActiveBirthsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I]
variable {P : I → Type}
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}
variable (d : ScheduledPhysicalPath anchor N J B)

/-- The initial active labels are exactly the active birth set at visit zero. -/
theorem activeBirths_zero (i : I) :
    activeBirths (d.primes i) (d.lifespan i) 0 = Finset.univ.image (d.active 0 i) := by
  ext p
  simp only [activeBirths,Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and,
    PrimeLifespan.freshActive]
  constructor
  · rintro ⟨hp,_,ha⟩
    exact (d.active_lifespan 0 (Nat.zero_le N) i p).mp ⟨hp,ha⟩
  · intro hp
    obtain ⟨hmem,ha⟩ := (d.active_lifespan 0 (Nat.zero_le N) i p).mpr hp
    exact ⟨hmem,by have := ((d.lifespan i p).active_bounds 0 ha).1; omega,ha⟩

/-- The initial list measure supplies each initial active birth mass once. -/
theorem initial_active_mass {R : Type*} [CommMonoid R] (ν : ∀ i, P i → R) (i : I) :
    (∏ k : Fin (J+1), ν i (d.active 0 i k)) =
      ∏ p ∈ activeBirths (d.primes i) (d.lifespan i) 0, ν i p := by
  rw [d.activeBirths_zero]
  exact (Finset.prod_image (fun _ _ _ _ h =>
    d.active_distinct 0 (Nat.zero_le N) i h)).symm

/-- The prescribed target really occurs in the next physical active list. -/
theorem targetPrime_active_next (j : ℕ) (hj : j < N) (i : I) :
    d.targetPrime j i ∈ d.primes i ∧ j+1 ∈ (d.lifespan i (d.targetPrime j i)).active := by
  apply (d.active_lifespan (j+1) hj i _).mpr
  refine ⟨(d.targetPerm j i).symm (Fin.last J), ?_⟩
  rw [d.active_next j hj]
  simp

/-- Any prime newly active at the next visit is the single target label. -/
theorem newly_active_eq_target (j : ℕ) (hj : j < N) (i : I) (p : P i)
    (hp : p ∈ d.primes i) (hnext : j+1 ∈ (d.lifespan i p).active)
    (hprev : j ∉ (d.lifespan i p).active) : p = d.targetPrime j i := by
  obtain ⟨k,hk⟩ := (d.active_lifespan (j+1) hj i p).mp ⟨hp,hnext⟩
  rw [d.active_next j hj i k] at hk
  by_cases hlast : d.targetPerm j i k = Fin.last J
  · simpa only [hlast,Fin.lastCases_last] using hk.symm
  · obtain ⟨t,ht⟩ := Fin.eq_castSucc_of_ne_last hlast
    rw [← ht,Fin.lastCases_castSucc] at hk
    have ha := (d.active_lifespan j hj.le i p).mpr ⟨d.sourcePerm j i t.castSucc,hk⟩
    exact (hprev ha.2).elim

/-- The target starts a new active run if it is absent from the source list. -/
theorem targetPrime_not_active (j : ℕ) (hj : j < N) (i : I)
    (hnew : ∀ k, d.targetPrime j i ≠ d.active j i k) :
    j ∉ (d.lifespan i (d.targetPrime j i)).active := by
  intro ha
  obtain ⟨k,hk⟩ := (d.active_lifespan j hj.le i _).mp
    ⟨(d.targetPrime_active_next j hj i).1,ha⟩
  exact hnew k hk.symm

/-- Freshness in the actual edge is exactly the active-birth singleton;
a promoted target begins an old prime's next run instead. -/
theorem activeBirths_succ (j : ℕ) (hj : j < N) (i : I)
    (hnew : ∀ k, d.targetPrime j i ≠ d.active j i k) :
    activeBirths (d.primes i) (d.lifespan i) (j+1) =
      optionalPrimeSet (!(d.promote j i)) (d.targetPrime j i) := by
  have ht := d.targetPrime_active_next j hj i
  have hn := d.targetPrime_not_active j hj i hnew
  have hprom : (d.lifespan i (d.targetPrime j i)).promoted j ↔ d.promote j i = true := by
    have hset := d.promote_set j hj i
    have hmem : d.targetPrime j i ∈ promotions (d.primes i) (d.lifespan i) j ↔
        d.promote j i = true := by
      rw [hset]
      cases hh : d.promote j i <;> simp [optionalPrimeSet]
    simpa only [promotions,Finset.mem_filter,ht.1,true_and] using hmem
  have hclass : (d.lifespan i (d.targetPrime j i)).freshActive (j+1) ↔
      d.promote j i = false := by
    constructor
    · intro hf
      cases hh : d.promote j i
      · rfl
      · exact ((d.lifespan i (d.targetPrime j i)).freshActive_not_promoted j
          ⟨hf,hprom.mpr hh⟩).elim
    · intro hh
      rcases (d.lifespan i (d.targetPrime j i)).active_run_start_succ j ht.2 hn with hf | hp
      · exact hf
      · have := hprom.mp hp
        simp_all
  ext p
  constructor
  · intro hp
    obtain ⟨hp,hfresh⟩ := Finset.mem_filter.mp hp
    have hn' : j ∉ (d.lifespan i p).active := by
      intro ha
      have hb := ((d.lifespan i p).active_bounds j ha).1
      have hb' := hfresh.1
      omega
    have he := d.newly_active_eq_target j hj i p hp hfresh.2 hn'
    subst p
    have hh := hclass.mp hfresh
    simp [optionalPrimeSet,hh]
  · intro hp
    have hh : d.promote j i = false := by
      cases h : d.promote j i <;> simp_all [optionalPrimeSet]
    have he : p = d.targetPrime j i := by simpa [optionalPrimeSet,hh] using hp
    subst p
    exact Finset.mem_filter.mpr ⟨ht.1,hclass.mpr hh⟩

/-- The exact promoted/fresh target coefficient splits into its promotion
normalization and the mass of the actual active-birth set. -/
theorem edge_target_mass {R : Type*} [Field R] (ν : ∀ i, P i → R) (V : I → R)
    (j : ℕ) (hj : j < N) (i : I)
    (hnew : ∀ k, d.targetPrime j i ≠ d.active j i k) :
    (if d.promote j i then (V i)⁻¹ else ν i (d.targetPrime j i)) =
      ((V i)⁻¹)^(promotions (d.primes i) (d.lifespan i) j).card *
        (∏ p ∈ activeBirths (d.primes i) (d.lifespan i) (j+1), ν i p) := by
  rw [d.promote_set j hj i,d.activeBirths_succ j hj i hnew]
  cases h : d.promote j i <;> simp [optionalPrimeSet]

/-- Include the initial boundary measure when accounting for all target
draws. Every actual fresh active birth then occurs exactly once. -/
theorem initial_and_target_masses {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (V : I → R) (i : I)
    (hnew : ∀ j, j < N → ∀ k, d.targetPrime j i ≠ d.active j i k) :
    (∏ k : Fin (J+1), ν i (d.active 0 i k)) *
      (∏ j ∈ Finset.range N, if d.promote j i then (V i)⁻¹ else ν i (d.targetPrime j i)) =
    (∏ j ∈ Finset.range (N+1), ∏ p ∈ activeBirths (d.primes i) (d.lifespan i) j, ν i p) *
      (∏ j ∈ Finset.range N, ((V i)⁻¹)^(promotions (d.primes i) (d.lifespan i) j).card) := by
  rw [d.initial_active_mass]
  have hfactor : (∏ j ∈ Finset.range N,
      if d.promote j i then (V i)⁻¹ else ν i (d.targetPrime j i)) =
      ∏ j ∈ Finset.range N,
        ((V i)⁻¹)^(promotions (d.primes i) (d.lifespan i) j).card *
          (∏ p ∈ activeBirths (d.primes i) (d.lifespan i) (j+1), ν i p) := by
    apply Finset.prod_congr rfl
    intro j hj
    exact d.edge_target_mass ν V j (Finset.mem_range.mp hj) i
      (hnew j (Finset.mem_range.mp hj))
  rw [hfactor,Finset.prod_mul_distrib,Finset.prod_range_succ']
  ring

/-- The literal source ban, after the prescribed source permutation,
provides the required exclusion from the entire original source list. -/
theorem target_not_active_of_crossEdgeBan (value : ∀ i, P i → ℕ) (j : ℕ)
    (hban : sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j)) :
    ∀ i k, d.targetPrime j i ≠ d.active j i k := by
  intro i k
  have h := sourceCrossEdgeBan_target_not_source value hban i ((d.sourcePerm j i).symm k)
  simpa only [sourceLists,targetLists,Fin.lastCases_last,Equiv.apply_symm_apply] using h

/-- The concrete chronological edge coefficient is the already-proved
scheduled transition factor times the fresh active birth masses, retaining
both geometric and endpoint permutation multipliers exactly. -/
theorem edgeFactor_eq_scheduled [Fintype Z] [∀ i, Fintype (P i)] (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (j : ℕ) (hj : j < N)
    (hnew : ∀ i k, d.targetPrime j i ≠ d.active j i k) :
    d.edgeFactor ν V ρ geometry j =
      (endpointPermutationWeight I J : ℂ) *
        geometry j (d.position j) (d.sourceLists j) (d.position (j+1)) (d.targetLists j) *
      ∏ i, ((scheduledEdgeFactor (d.primes i) (d.lifespan i) ρ (V i)
        (fun p t => d.retained i p = anchor (d.position t) i p) j *
          (∏ p ∈ activeBirths (d.primes i) (d.lifespan i) (j+1), ν i p) : ℝ) : ℂ) := by
  unfold edgeFactor
  congr 1
  apply Finset.prod_congr rfl
  intro i hi
  apply congrArg (fun z : ℝ => (z : ℂ))
  rw [d.edge_target_mass ν V j hj i (hnew i)]
  unfold scheduledEdgeFactor
  ring

end Elliptic.Operator.ScheduledPhysicalPath
