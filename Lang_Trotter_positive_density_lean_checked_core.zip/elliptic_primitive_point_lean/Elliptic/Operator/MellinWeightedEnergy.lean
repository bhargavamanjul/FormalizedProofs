module
public import Elliptic.Operator.MellinModulationBounds
public import Mathlib.MeasureTheory.Integral.Prod

/-! Weighted Cauchy and Fubini for the source one-prime Mellin integral. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinWeightedEnergy
open MeasureTheory Set
set_option maxHeartbeats 500000
set_option backward.isDefEq.respectTransparency false

 theorem weighted_square {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (k f : Ω→ℝ) (hk : ∀x,0≤k x) (hi : Integrable k μ)
    (hif : Integrable (fun x=>k x*f x) μ) (hif2 : Integrable (fun x=>k x*(f x)^2) μ) :
    (∫x,k x*f x ∂μ)^2≤(∫x,k x ∂μ)*(∫x,k x*(f x)^2 ∂μ) := by
  let I := ∫x,k x ∂μ
  let J := ∫x,k x*f x ∂μ
  let H := ∫x,k x*(f x)^2 ∂μ
  have hI : 0≤I := integral_nonneg hk
  by_cases he : I=0
  · have hae : k=ᵐ[μ] 0 := (integral_eq_zero_iff_of_nonneg hk hi).mp he
    have hj : J=0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [hae] with x hx
      simp [hx]
    change J^2≤I*H
    rw [he,hj]
    norm_num
  · have hIp : 0<I := lt_of_le_of_ne hI (Ne.symm he)
    have hpoly : (∫x,k x*(I*f x-J)^2 ∂μ)=I^2*H-2*I*J^2+J^2*I := by
      calc
        _ = ∫x,I^2*(k x*(f x)^2)-(2*I*J)*(k x*f x)+J^2*k x ∂μ := by
          apply integral_congr_ae
          filter_upwards [] with x
          ring
        _ = _ := by
          rw [integral_add
            (show Integrable (fun x=>I^2*(k x*(f x)^2)-(2*I*J)*(k x*f x)) μ from
              (hif2.const_mul _).sub (hif.const_mul _)) (hi.const_mul (J^2)),
            integral_sub (hif2.const_mul (I^2)) (hif.const_mul (2*I*J)),
            integral_const_mul,integral_const_mul,integral_const_mul]
          dsimp [I,J,H]
          ring
    have hh : 0≤I*(I*H-J^2) := by
      have := integral_nonneg (μ:=μ) (fun x=>mul_nonneg (hk x) (sq_nonneg (I*f x-J)))
      rw [hpoly] at this
      nlinarith only [this]
    have := (mul_nonneg_iff_of_pos_left hIp).mp hh
    change J^2≤I*H
    linarith

/-- A bounded continuous complex family can be integrated against any integrable
continuous kernel; its output energy costs the square of the kernel L1 mass. -/
 theorem kernel_energy (K : ℝ→ℂ) (F : ℝ→ℝ→ℂ)
    (hK : Continuous K) (hiK : Integrable K) (hF : Continuous (Function.uncurry F))
    (B E a b : ℝ) (hB : 0≤B) (hbound : ∀ξ t,‖F ξ t‖≤B)
    (henergy : ∀ξ,(∫t in Icc a b,‖F ξ t‖^2)≤E) :
    (∫t in Icc a b,‖∫ξ:ℝ,K ξ*F ξ t‖^2)≤(∫ξ:ℝ,‖K ξ‖)^2*E := by
  let M := ∫ξ:ℝ,‖K ξ‖
  have hM : 0≤M := integral_nonneg (fun ξ=>norm_nonneg _)
  have hi1 (t:ℝ) : Integrable (fun ξ=>‖K ξ‖*‖F ξ t‖) := by
    apply (hiK.norm.mul_const B).mono' ((hK.norm.mul
      ((hF.comp (continuous_id.prodMk continuous_const)).norm)).aestronglyMeasurable)
    filter_upwards [] with ξ
    change ‖‖K ξ‖*‖F ξ t‖‖≤‖K ξ‖*B
    rw [Real.norm_of_nonneg (mul_nonneg (norm_nonneg _) (norm_nonneg _))]
    exact mul_le_mul_of_nonneg_left (hbound ξ t) (norm_nonneg _)
  have hi2 (t:ℝ) : Integrable (fun ξ=>‖K ξ‖*‖F ξ t‖^2) := by
    apply (hiK.norm.mul_const (B^2)).mono' ((hK.norm.mul
      ((hF.comp (continuous_id.prodMk continuous_const)).norm.pow 2)).aestronglyMeasurable)
    filter_upwards [] with ξ
    change ‖‖K ξ‖*‖F ξ t‖^2‖≤‖K ξ‖*B^2
    rw [Real.norm_of_nonneg (mul_nonneg (norm_nonneg _) (sq_nonneg _))]
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (norm_nonneg _) (hbound ξ t) 2) (norm_nonneg _)
  have hpoint (t:ℝ) : ‖∫ξ:ℝ,K ξ*F ξ t‖^2≤M*(∫ξ:ℝ,‖K ξ‖*‖F ξ t‖^2) := by
    have hh := weighted_square volume (fun ξ=>‖K ξ‖) (fun ξ=>‖F ξ t‖)
      (fun ξ=>norm_nonneg _) hiK.norm (hi1 t) (hi2 t)
    apply (pow_le_pow_left₀ (norm_nonneg _) (norm_integral_le_integral_norm _) 2).trans
    simpa only [norm_mul,M] using hh
  have hGc : Continuous (fun p:ℝ×ℝ=>‖K p.1‖*‖F p.1 p.2‖^2) :=
    (hK.comp continuous_fst).norm.mul (hF.norm.pow 2)
  have hG : Integrable (fun p:ℝ×ℝ=>‖K p.1‖*‖F p.1 p.2‖^2)
      (volume.prod (volume.restrict (Icc a b))) := by
    apply (hiK.norm.mul_prod (show Integrable (fun _:ℝ=>B^2) (volume.restrict (Icc a b)) from
      continuous_const.continuousOn.integrableOn_compact isCompact_Icc)).mono' hGc.aestronglyMeasurable
    filter_upwards [] with p
    rw [Real.norm_of_nonneg (by positivity)]
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (norm_nonneg _) (hbound p.1 p.2) 2) (norm_nonneg _)
  have hout : AEStronglyMeasurable (fun t=>‖∫ξ:ℝ,K ξ*F ξ t‖^2) (volume.restrict (Icc a b)) :=
    (((hK.comp continuous_fst).mul hF).stronglyMeasurable.integral_prod_left').norm.pow 2 |>.aestronglyMeasurable
  have houti : Integrable (fun t=>‖∫ξ:ℝ,K ξ*F ξ t‖^2) (volume.restrict (Icc a b)) := by
    apply (hG.integral_prod_right.const_mul M).mono' hout
    filter_upwards [] with t
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    exact hpoint t
  calc
    _ ≤ ∫t in Icc a b,M*(∫ξ:ℝ,‖K ξ‖*‖F ξ t‖^2) := integral_mono houti
      (hG.integral_prod_right.const_mul M) hpoint
    _ = M*(∫ξ:ℝ,‖K ξ‖*(∫t in Icc a b,‖F ξ t‖^2)) := by
      rw [integral_const_mul,←integral_integral_swap hG]
      congr 1
      apply integral_congr_ae
      filter_upwards [] with ξ
      rw [integral_const_mul]
    _ ≤ M*(∫ξ:ℝ,‖K ξ‖*E) := by
      apply mul_le_mul_of_nonneg_left _ hM
      apply integral_mono _ (hiK.norm.mul_const E) (fun ξ=>mul_le_mul_of_nonneg_left (henergy ξ) (norm_nonneg _))
      convert hG.integral_prod_left using 1
      funext ξ
      simp only [integral_const_mul]
    _ = _ := by rw [integral_mul_const];dsimp [M];ring

end Elliptic.Operator.MellinWeightedEnergy
