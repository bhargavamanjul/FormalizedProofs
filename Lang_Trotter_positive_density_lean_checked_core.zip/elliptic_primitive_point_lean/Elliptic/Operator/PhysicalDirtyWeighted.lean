module

public import Elliptic.Operator.PhysicalDirtyCoordinates

/-!
# Indexed weighted fibers of actual dirty physical edges

The choice modes below retain old particles as indexed entries. A free
promotion mode sums all those entries, so repeated numeric labels retain
their actual multiplicity and outgoing damping. Fixed fresh draws retain
their prime mass. No weighted-row estimate is an input.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalDirtyWeightedDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

section GroupModes
variable {P : Type*} {Line : P → Type*} {B : ℕ}

/-- `none` permits every indexed old promotion; `some` fixes an old
index or a fresh prime, according to the sum branch. -/
def dirtyGroupChoices (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (mode : Option (Fin m.size ⊕ P)) : Finset (EdgeGroupChoice m) :=
  match mode with
  | none => Finset.univ.image (fun a => (store, Sum.inl a))
  | some c => {(store,c)}

def dirtyGroupCoefficient (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (mode : Option (Fin m.size ⊕ P)) : ℝ :=
  match mode with
  | none => (V⁻¹ * (v0 ^ store.toNat / v0)) / (1-ρ)
  | some (.inl _) => V⁻¹ * (v0 ^ store.toNat / v0)
  | some (.inr p) => ν p * v0 ^ store.toNat

theorem dirtyGroupCoefficient_nonneg (ν : P → ℝ) (V ρ v0 : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (mode : Option (Fin m.size ⊕ P))
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V) (hρ : ρ < 1) (hv0 : 0 ≤ v0) :
    0 ≤ dirtyGroupCoefficient ν V ρ v0 m store mode := by
  cases mode with
  | none => dsimp [dirtyGroupCoefficient]; positivity
  | some c =>
      cases c with
      | inl a => dsimp [dirtyGroupCoefficient]; positivity
      | inr p => exact mul_nonneg (hν p) (pow_nonneg hv0 _)

/-- Actual finite indexed choice sum, with its original damping and
Schur ratio. No distinctness of old particle values is required. -/
theorem dirtyGroupChoices_sum_le (ν : P → ℝ) (V ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (mode : Option (Fin m.size ⊕ P))
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c ∈ dirtyGroupChoices m store mode,
      edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m c) ≤
      dirtyGroupCoefficient ν V ρ v0 m store mode := by
  cases mode with
  | none =>
      simp only [dirtyGroupChoices, dirtyGroupCoefficient]
      rw [Finset.sum_image (fun _ _ _ _ h => Sum.inl.inj (congrArg Prod.snd h))]
      exact edgeWeightedChoice_promotion_sum_le ν V ρ v0 sourceAnchor targetAnchor
        sourcePrime m store hV hρ0 hρ1 hv0
  | some c =>
      cases c with
      | inl a =>
          simpa only [dirtyGroupChoices, dirtyGroupCoefficient, Finset.sum_singleton] using
            edgeWeightedChoice_promotion_le_coefficient ν V ρ v0 sourceAnchor targetAnchor
              sourcePrime m store a hV hρ0 hρ1.le hv0
      | inr p =>
          simpa only [dirtyGroupChoices, dirtyGroupCoefficient, Finset.sum_singleton] using
            edgeWeightedChoice_fresh_le ν V ρ v0 sourceAnchor targetAnchor
              sourcePrime m store p hν hρ0 hρ1.le hv0
end GroupModes

/-- Independent indexed group choices give a product bound with the
actual fixed stores, old/fresh modes and fresh-prime masses retained. -/
theorem dirtyGroupChoices_product_sum_le {I : Type*} [Fintype I] [DecidableEq I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (mode : ∀ i, Option (Fin (m i).size ⊕ P i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c ∈ Fintype.piFinset (fun i => dirtyGroupChoices (m i) (store i) (mode i)),
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
        (sourcePrime i) (m i) (c i)) ≤
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0 (m i) (store i) (mode i) := by
  rw [← Finset.prod_univ_sum]
  apply Finset.prod_le_prod₀
  · intro i _
    exact Finset.sum_nonneg fun c _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
      (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) c (hν i) (hV i) hρ0 hv0.le
  · intro i _
    exact dirtyGroupChoices_sum_le (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i) (mode i) (hν i) (hV i) hρ0 hρ1 hv0

namespace PhysicalDirtyWeighted
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- The literal product of the group Schur-weighted coefficients; the
raw geometric indicator is imposed by the choice set being summed. -/
def choiceWeight (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (c : PhysicalEdgeChoice s) : ℝ :=
  ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0
    (fun p => primeResidueAnchor (value i p)
      (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
    (fun p => primeResidueAnchor (value i p) (position c.target))
    (c.sourcePrime i) (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (c.group i)

theorem choiceWeight_nonneg (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (c : PhysicalEdgeChoice s) (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0) :
    0 ≤ choiceWeight value position s ν V ρ v0 c := by
  exact Finset.prod_nonneg fun i _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
    _ _ _ _ _ (hν i) (hV i) hρ hv0

/-- Fixing the retained-slot permutation, an equal omission tuple forces
the entire source permutation to agree. -/
theorem sourcePerm_eq_of_targetData_eq (c d : PhysicalEdgeChoice s) (i₀ : Fin K)
    (hd : PhysicalDirtyCoordinates.targetData value position s c i₀ =
      PhysicalDirtyCoordinates.targetData value position s d i₀)
    (hr : (groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2 =
      (groupLastSlotPermutationEquiv (Fin K) J d.sourcePerm).2) :
    c.sourcePerm = d.sourcePerm := by
  apply (groupLastSlotPermutationEquiv (Fin K) J).injective
  apply Prod.ext
  · rw [groupLastSlotPermutationEquiv_fst,groupLastSlotPermutationEquiv_fst]
    exact congrArg (fun x : ((Fin K → Fin (J+1)) × ℕ) × (ℤ × ℤ) => x.1.1) hd
  · exact hr

/-- On one actual target-data fiber, fixed retained and target
permutations leave precisely the indexed group choices to sum. Their
original coefficients and outgoing damping give the product bound.
The position map is explicitly injective at this counting step. -/
theorem targetData_fiber_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (i₀ : Fin K) (S : Finset (PhysicalEdgeChoice s))
    (hdata : ∀ c ∈ S, ∀ d ∈ S,
      PhysicalDirtyCoordinates.targetData value position s c i₀ =
        PhysicalDirtyCoordinates.targetData value position s d i₀)
    (hret : ∀ c ∈ S, ∀ d ∈ S,
      (groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2 =
        (groupLastSlotPermutationEquiv (Fin K) J d.sourcePerm).2)
    (htarget : ∀ c ∈ S, ∀ d ∈ S, c.targetPerm = d.targetPerm)
    (hmode : ∀ c ∈ S, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  by_cases he : S = ∅
  · rw [he,Finset.sum_empty]
    exact Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg (ν i) (V i) ρ v0
      _ _ _ (hν i) (hV i) hρ1 hv0.le
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hpos (c) (hc : c ∈ S) : c.target = c₀.target :=
    hposition (congrArg (fun x : ((Fin K → Fin (J+1)) × ℕ) × (ℤ × ℤ) => x.2)
      (hdata c hc c₀ hc₀))
  have hperm (c) (hc : c ∈ S) : c.sourcePerm = c₀.sourcePerm :=
    sourcePerm_eq_of_targetData_eq value position s c c₀ i₀ (hdata c hc c₀ hc₀)
      (hret c hc c₀ hc₀)
  let F := fun (g : ∀ i, EdgeGroupChoice
      (s.memory P (fun i p => Option (ZMod (value i p))) J B i)) =>
    ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0
      (fun p => primeResidueAnchor (value i p)
        (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
      (fun p => primeResidueAnchor (value i p) (position c₀.target))
      (c₀.sourcePrime i) (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (g i)
  have hweight (c) (hc : c ∈ S) : choiceWeight value position s ν V ρ v0 c = F c.group := by
    simp only [choiceWeight,F,hpos c hc,PhysicalEdgeChoice.sourcePrime,
      PhysicalEdgeChoice.sourceLists,hperm c hc]
  have hi : Set.InjOn (fun c : PhysicalEdgeChoice s => c.group) S := by
    intro c hc d hd hgroup
    have hp := (hpos c hc).trans (hpos d hd).symm
    have hs := (hperm c hc).trans (hperm d hd).symm
    exact Prod.ext hp (Prod.ext hs (Prod.ext hgroup (htarget c hc d hd)))
  have hsub : S.image (fun c => c.group) ⊆ Fintype.piFinset
      (fun i => dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)) := by
    intro g hg
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hg
    exact Fintype.mem_piFinset.mpr (hmode c hc)
  calc
    _ = ∑ c ∈ S, F c.group := by
      exact Finset.sum_congr rfl hweight
    _ = ∑ g ∈ S.image (fun c => c.group), F g := by
      exact (Finset.sum_image hi).symm
    _ ≤ ∑ g ∈ Fintype.piFinset (fun i => dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)), F g := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hsub
      intro g _ _
      exact Finset.prod_nonneg fun i _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
        _ _ _ _ _ (hν i) (hV i) hρ0 hv0.le
    _ ≤ _ := by
      dsimp only [F]
      exact dirtyGroupChoices_product_sum_le ν V ρ v0
        (fun i p => primeResidueAnchor (value i p)
          (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
        (fun i p => primeResidueAnchor (value i p) (position c₀.target)) c₀.sourcePrime
        (s.memory P (fun i p => Option (ZMod (value i p))) J B) store mode hν hV hρ0 hρ1 hv0

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- The actual raw weighted row on a fixed store/fresh mode, distinguished
old index, fresh product, and retained source/target permutations. Other
old promotions are summed with their indexed multiplicities and damping.
Further coupled restrictions may be retained by taking any subset `S`.
The phase-separation test remains explicit. -/
theorem rawChoices_weighted_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ)
    (hsep : PhaseSeparated
      (dirtyProductSupport
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (PhysicalDirtyCoordinates.rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T))
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hret : ∀ c ∈ S, ∀ d ∈ S,
      (groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2 =
        (groupLastSlotPermutationEquiv (Fin K) J d.sourcePerm).2)
    (htarget : ∀ c ∈ S, ∀ d ∈ S, c.targetPerm = d.targetPerm)
    (hmode : ∀ c ∈ S, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      33 * ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  let data := fun c => PhysicalDirtyCoordinates.targetData value position s c i₀
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hC : 0 ≤ C := Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg
    (ν i) (V i) ρ v0 _ _ _ (hν i) (hV i) hρ1 hv0.le
  have hcard : (S.image data).card ≤ 33 := by
    apply (Finset.card_le_card (Finset.image_subset_image hS)).trans
    exact PhysicalDirtyCoordinates.rawTargetDataImage_card_le value position s hprime
      good u v r U W d₀ σ hU hσ i₀ a₀ T w hzw δ hsep hwidth
  have hf (x) : (∑ c ∈ S.filter (fun c => data c = x),
      choiceWeight value position s ν V ρ v0 c) ≤ C := by
    apply targetData_fiber_sum_le value position s hposition ν V ρ v0 store mode i₀
    · intro c hc d hd
      exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm
    · intro c hc d hd
      exact hret c (Finset.mem_filter.mp hc).1 d (Finset.mem_filter.mp hd).1
    · intro c hc d hd
      exact htarget c (Finset.mem_filter.mp hc).1 d (Finset.mem_filter.mp hd).1
    · intro c hc
      exact hmode c (Finset.mem_filter.mp hc).1
    · exact hν
    · exact hV
    · exact hρ0
    · exact hρ1
    · exact hv0
  calc
    _ = ∑ x ∈ S.image data, ∑ c ∈ S.filter (fun c => data c = x),
        choiceWeight value position s ν V ρ v0 c :=
      (Finset.sum_fiberwise_of_maps_to (fun c hc => Finset.mem_image_of_mem data hc) _).symm
    _ ≤ ∑ _x ∈ S.image data, C := Finset.sum_le_sum fun x _ => hf x
    _ = (S.image data).card * C := by simp
    _ ≤ 33 * C := mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) hC

/-- Both literal endpoint permutation factors are now summed. The
target-permutation count cancels one endpoint average; the retained
source count leaves exactly the omission factor `(J+1)^(-K)`.
Stores, branch modes, distinguished old index, and fresh product remain
fixed; all other indexed promotion multiplicities have been summed. -/
theorem rawChoices_endpoint_averaged_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ)
    (hsep : PhaseSeparated
      (dirtyProductSupport
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (PhysicalDirtyCoordinates.rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T))
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hmode : ∀ c ∈ S, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      (33 * ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)) /
          (J+1 : ℝ)^K := by
  let Key := (Fin K → Equiv.Perm (Fin J)) × (Fin K → Equiv.Perm (Fin (J+1)))
  let key : PhysicalEdgeChoice s → Key := fun c =>
    ((groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2,c.targetPerm)
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hf (k : Key) : (∑ c ∈ S.filter (fun c => key c = k),
      choiceWeight value position s ν V ρ v0 c) ≤ 33*C := by
    apply rawChoices_weighted_sum_le value position s hposition hprime ν V ρ v0 store mode
      good u v r U W d₀ σ hU hσ i₀ a₀ T w hzw δ hsep hwidth
    · exact fun c hc => hS (Finset.mem_filter.mp hc).1
    · intro c hc d hd
      exact congrArg (fun x : Key => x.1)
        ((Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm)
    · intro c hc d hd
      exact congrArg (fun x : Key => x.2)
        ((Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm)
    · intro c hc
      exact hmode c (Finset.mem_filter.mp hc).1
    · exact hν
    · exact hV
    · exact hρ0
    · exact hρ1
    · exact hv0
  have hsum : (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      ∑ _k : Key, 33*C := by
    rw [← Finset.sum_fiberwise_of_maps_to (fun c (_hc : c ∈ S) => Finset.mem_univ (key c))
      (choiceWeight value position s ν V ρ v0)]
    exact Finset.sum_le_sum fun k _ => hf k
  let n : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin (J+1)))
  let m : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin J))
  have hn : n = (J+1 : ℝ)^K * m := by
    simp only [n,m,Fintype.card_fun,Fintype.card_perm,Fintype.card_fin,Nat.factorial_succ,
      Nat.cast_pow,Nat.cast_mul,Nat.cast_add,Nat.cast_one,mul_pow]
  have hm : m ≠ 0 := by dsimp [m]; positivity
  have hj : (J+1 : ℝ)^K ≠ 0 := by positivity
  have hk : (Fintype.card Key : ℝ) = m*n := by
    simp only [Key,Fintype.card_prod,Nat.cast_mul,m,n]
  calc
    _ ≤ endpointPermutationWeight (Fin K) J * (∑ _k : Key, 33*C) :=
      mul_le_mul_of_nonneg_left hsum (by unfold endpointPermutationWeight; positivity)
    _ = n⁻¹^2 * ((m*n)*(33*C)) := by
      rw [Finset.sum_const,nsmul_eq_mul,Finset.card_univ,hk]
      simp only [endpointPermutationWeight,n,Fintype.card_fun,Fintype.card_perm,Fintype.card_fin]
    _ = 33*C/(J+1 : ℝ)^K := by
      rw [hn]
      field_simp

end PhysicalDirtyWeighted
end Elliptic.Operator
