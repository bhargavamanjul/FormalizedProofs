module

public import Elliptic.Operator.ActualHistoryLifespans
public import Elliptic.Operator.ActualHistoryObservation
public import Elliptic.Operator.ActualHistoryPending

/-!
# Exact events recovered from actual pending-support changes

Every lifespan event is one of the four differences of consecutive pending
sets. The corresponding identities below read literal ghost/edge choices;
no schedule or prescribed event set is assumed. In particular, stores and
promotions are recovered from the old and new pending support alone.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
attribute [local instance] Classical.propDecidable
local instance actualHistoryEventsDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace PrimeLifespan
variable {N : ℕ} (L : PrimeLifespan N)

theorem stored_iff_pending_difference (j : ℕ) :
    L.stored j ↔ L.beforeGhost (j+1) ∧ ¬ L.afterGhost j := by
  unfold stored beforeGhost afterGhost
  have ha := L.active_bounds
  constructor
  · rintro ⟨hj,hd,hn⟩
    have hb := (ha j hj).1
    exact ⟨⟨by omega,by omega,hn⟩,fun h => h.2.2 hj⟩
  · rintro ⟨⟨hb,hd,hn⟩,h⟩
    have hj : j ∈ L.active := by
      by_contra hj
      exact h ⟨by omega,by omega,hj⟩
    exact ⟨hj,by omega,hn⟩

theorem promoted_iff_pending_difference (j : ℕ) :
    L.promoted j ↔ L.afterGhost j ∧ ¬ L.beforeGhost (j+1) := by
  unfold promoted afterGhost beforeGhost
  have ha := L.active_bounds
  constructor
  · rintro ⟨hn,hb,hj⟩
    have hd := (ha (j+1) hn).2
    exact ⟨⟨by omega,by omega,hj⟩,fun h => h.2.2 hn⟩
  · rintro ⟨⟨hb,hd,hj⟩,h⟩
    have hn : j+1 ∈ L.active := by
      by_contra hn
      exact h ⟨by omega,by omega,hn⟩
    exact ⟨hn,by omega,hj⟩

theorem ghostBorn_iff_pending_difference (j : ℕ) :
    L.ghostBorn j ↔ L.afterGhost j ∧ ¬ L.beforeGhost j := by
  constructor
  · intro h
    have hd := L.ghostBorn_birth_lt_death h
    have he := h.1
    exact ⟨⟨by omega,by omega,h.2⟩,fun hb => by have := hb.1; omega⟩
  · rintro ⟨⟨hb,hd,ha⟩,h⟩
    refine ⟨?_,ha⟩
    by_contra he
    exact h ⟨by omega,hd.le,ha⟩

theorem ghostDies_iff_pending_difference (j : ℕ) :
    L.ghostDies j ↔ L.beforeGhost j ∧ ¬ L.afterGhost j := by
  constructor
  · intro h
    have hb := L.ghostDies_birth_lt_death h
    have he := h.1
    exact ⟨⟨by omega,by omega,h.2⟩,fun ha => by have := ha.2.1; omega⟩
  · rintro ⟨⟨hb,hd,ha⟩,h⟩
    refine ⟨?_,ha⟩
    by_contra he
    exact h ⟨hb.le,by omega,ha⟩
end PrimeLifespan

namespace LifespanSchedule
variable {P : Type*} {N : ℕ}

theorem stores_eq_pending_difference (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    stores S L j = before S L (j+1) \ after S L j := by
  ext p
  simp only [stores,before,after,Finset.mem_filter,Finset.mem_sdiff,
    PrimeLifespan.stored_iff_pending_difference]
  tauto

theorem promotions_eq_pending_difference (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    promotions S L j = after S L j \ before S L (j+1) := by
  ext p
  simp only [promotions,before,after,Finset.mem_filter,Finset.mem_sdiff,
    PrimeLifespan.promoted_iff_pending_difference]
  tauto

theorem births_eq_pending_difference (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    births S L j = after S L j \ before S L j := by
  ext p
  simp only [births,before,after,Finset.mem_filter,Finset.mem_sdiff,
    PrimeLifespan.ghostBorn_iff_pending_difference]
  tauto

theorem deaths_eq_pending_difference (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    deaths S L j = before S L j \ after S L j := by
  ext p
  simp only [deaths,before,after,Finset.mem_filter,Finset.mem_sdiff,
    PrimeLifespan.ghostDies_iff_pending_difference]
  tauto
end LifespanSchedule

namespace ActualHistoryEvents
variable {P : Type*} {Line : P → Type*} {B : ℕ}

/-- Literal prime support of an ordered pending memory. -/
def pendingSupport (m : MemoryState (AnchoredParticle P Line) B) : Finset P :=
  Finset.univ.image (fun k => (m.values k).1)

@[simp] theorem mem_pendingSupport (m : MemoryState (AnchoredParticle P Line) B) (p : P) :
    p ∈ pendingSupport m ↔ ∃ k, (m.values k).1 = p := by
  simp [pendingSupport]

/-- A stored source is exactly a new pending prime, without a supplied schedule. -/
theorem edge_store_iff_pending_difference
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B)
    (hsource : ∀ k, source ≠ (m.values k).1) (p : P) :
    c.1 = true ∧ source = p ↔
      p ∈ pendingSupport (edgeGroupOutput anchor source m c hc) ∧
        p ∉ pendingSupport m := by
  simp only [mem_pendingSupport]
  rw [edgeGroupOutput_prime_exists_iff]
  constructor
  · intro h
    refine ⟨Or.inr h,?_⟩
    rintro ⟨k,hk⟩
    exact hsource k (h.2.trans hk.symm)
  · rintro ⟨h,hn⟩
    rcases h with ⟨k,_,hk⟩ | hs
    · exact False.elim (hn ⟨k,hk⟩)
    · exact hs

/-- The promoted target is exactly a disappearing pending prime. This needs
only the old prime injectivity and disjointness of the source-active prime. -/
theorem edge_promote_iff_pending_difference
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B)
    (hm : Function.Injective (fun k => (m.values k).1))
    (hsource : ∀ k, source ≠ (m.values k).1) (p : P) :
    (∃ k, c.2 = Sum.inl k ∧ (m.values k).1 = p) ↔
      p ∈ pendingSupport m ∧
        p ∉ pendingSupport (edgeGroupOutput anchor source m c hc) := by
  simp only [mem_pendingSupport]
  rw [edgeGroupOutput_prime_exists_iff]
  constructor
  · rintro ⟨k,hk,hp⟩
    refine ⟨⟨k,hp⟩,?_⟩
    rintro (⟨l,hl,hlp⟩ | ⟨_,hsp⟩)
    · have hlk : l = k := hm (hlp.trans hp.symm)
      apply hl
      simp [edgePromotedIndices,hk,hlk]
    · exact hsource k (hsp.trans hp.symm)
  · rintro ⟨⟨k,hk⟩,hn⟩
    have hprom : k ∈ edgePromotedIndices c := by
      by_contra h
      exact hn (Or.inl ⟨k,h,hk⟩)
    cases he : c.2 with
    | inl l =>
        have hkl : k = l := by simpa [edgePromotedIndices,he] using hprom
        exact ⟨l,rfl,by simpa [hkl] using hk⟩
    | inr q => simp [edgePromotedIndices,he] at hprom

/-- Literal fresh ghost draws are precisely the new pending support. -/
theorem ghost_birth_iff_pending_difference
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c)
    (hfresh : ∀ k l, (m.values k).1 ≠ c.2.values l) (p : P) :
    (∃ k, c.2.values k = p) ↔
      p ∈ pendingSupport (ghostOutput anchor m c hc) ∧ p ∉ pendingSupport m := by
  simp only [mem_pendingSupport]
  rw [ghostOutput_prime_exists_iff]
  constructor
  · intro h
    refine ⟨Or.inr h,?_⟩
    obtain ⟨l,hl⟩ := h
    rintro ⟨k,hk⟩
    exact hfresh k l (hk.trans hl.symm)
  · rintro ⟨h,hn⟩
    rcases h with ⟨k,_,hk⟩ | hf
    · exact False.elim (hn ⟨k,hk⟩)
    · exact hf

/-- Actual ghost deletion indices are precisely the lost pending support.
The fresh-old exclusion prevents a deletion from being disguised by rebirth. -/
theorem ghost_death_iff_pending_difference
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c)
    (hm : Function.Injective (fun k => (m.values k).1))
    (hfresh : ∀ k l, (m.values k).1 ≠ c.2.values l) (p : P) :
    (∃ k, k ∈ c.1 ∧ (m.values k).1 = p) ↔
      p ∈ pendingSupport m ∧ p ∉ pendingSupport (ghostOutput anchor m c hc) := by
  simp only [mem_pendingSupport]
  rw [ghostOutput_prime_exists_iff]
  constructor
  · rintro ⟨k,hk,hp⟩
    refine ⟨⟨k,hp⟩,?_⟩
    rintro (⟨l,hl,hlp⟩ | ⟨l,hl⟩)
    · exact hl ((hm (hlp.trans hp.symm)).symm ▸ hk)
    · exact hfresh k l (hp.trans hl.symm)
  · rintro ⟨⟨k,hk⟩,hn⟩
    refine ⟨k,?_,hk⟩
    by_contra h
    exact hn (Or.inl ⟨k,h,hk⟩)

/-- Exact finite-set store identity for the actual grouped edge choice. -/
theorem edge_stores_eq_pending_difference
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B)
    (hsource : ∀ k, source ≠ (m.values k).1) :
    optionalPrimeSet c.1 source =
      pendingSupport (edgeGroupOutput anchor source m c hc) \ pendingSupport m := by
  ext p
  rw [Finset.mem_sdiff,← edge_store_iff_pending_difference anchor source m c hc hsource p]
  cases c.1 <;> simp [optionalPrimeSet,eq_comm]

/-- Exact finite-set promotion identity, including the fresh-target branch. -/
theorem edge_promotions_eq_pending_difference
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B)
    (hm : Function.Injective (fun k => (m.values k).1))
    (hsource : ∀ k, source ≠ (m.values k).1) :
    optionalPrimeSet (match c.2 with | .inl _ => true | .inr _ => false)
        (edgeTargetPrime m c) =
      pendingSupport m \ pendingSupport (edgeGroupOutput anchor source m c hc) := by
  ext p
  rw [Finset.mem_sdiff,← edge_promote_iff_pending_difference anchor source m c hc hm hsource p]
  cases he : c.2 <;> simp [he,optionalPrimeSet,edgeTargetPrime,eq_comm]

/-- Ghost births retain their actual tuple multiplicities at the choice level;
this identity concerns precisely its image, not an assumed distinct batch. -/
theorem ghost_births_eq_pending_difference
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c)
    (hfresh : ∀ k l, (m.values k).1 ≠ c.2.values l) :
    Finset.univ.image c.2.values =
      pendingSupport (ghostOutput anchor m c hc) \ pendingSupport m := by
  ext p
  simpa only [Finset.mem_image,Finset.mem_univ,true_and,Finset.mem_sdiff] using
    ghost_birth_iff_pending_difference anchor m c hc hfresh p

/-- The actual deleted-index image agrees exactly with the pending loss. -/
theorem ghost_deaths_eq_pending_difference
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c)
    (hm : Function.Injective (fun k => (m.values k).1))
    (hfresh : ∀ k l, (m.values k).1 ≠ c.2.values l) :
    c.1.image (fun k => (m.values k).1) =
      pendingSupport m \ pendingSupport (ghostOutput anchor m c hc) := by
  ext p
  simpa only [Finset.mem_image,Finset.mem_sdiff] using
    ghost_death_iff_pending_difference anchor m c hc hm hfresh p



/-- An injective tuple's bag is precisely the multiset underlying its image. -/
theorem tupleBag_eq_image_val {α Q : Type*} [Fintype α]
    (f : α → Q) (hf : Function.Injective f) :
    tupleBag f = (Finset.univ.image f).val := by
  rw [tupleBag_eq_map,Finset.image_val_of_injOn hf.injOn]

section Physical
variable {I Z : Type} [Fintype I]
variable {P : I → Type} {Line : ∀ i, P i → Type} {J B : ℕ}

/-- A literal physical store is recovered from the actual pending change.
Both endpoint permutations are already part of the actual source prime. -/
theorem physical_edge_stores_eq_pending_difference
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (hs : s.LiveDistinct) (i : I) :
    optionalPrimeSet (c.group i).1 (c.sourcePrime i) =
      pendingSupport ((c.output anchor s hc).memory P Line J B i) \
        pendingSupport (s.memory P Line J B i) := by
  exact edge_stores_eq_pending_difference _ _ _ _ (hc.1 i).2
    ((hs i).2.2 (c.sourcePerm i (Fin.last J)))

/-- Promotions, including the negative fresh branch, are recovered without
any local freshness assumption on the target draw. -/
theorem physical_edge_promotions_eq_pending_difference
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (hs : s.LiveDistinct) (i : I) :
    optionalPrimeSet (match (c.group i).2 with | .inl _ => true | .inr _ => false)
        (edgeTargetPrime (s.memory P Line J B i) (c.group i)) =
      pendingSupport (s.memory P Line J B i) \
        pendingSupport ((c.output anchor s hc).memory P Line J B i) := by
  rw [PhysicalEdgeChoice.output_memory]
  convert edge_promotions_eq_pending_difference (anchor (s.position P Line J B) i)
    (c.sourcePrime i) _ _ (hc.1 i).2
    (hs i).2.1 ((hs i).2.2 (c.sourcePerm i (Fin.last J))) using 1
  cases (c.group i).2 <;> rfl
end Physical

section ActualGhost
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}
variable (value : ∀ i, P i → ℕ)
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Fresh-old disjointness for the current literal ghost is a consequence of
future-birth avoidance. It is not an independent reconstruction premise. -/
theorem firstGhost_fresh_old_disjoint (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) (k : Fin (s.memory P Line J B i).size)
    (l : Fin ((ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size) :
    ((s.memory P Line J B i).values k).1 ≠
      ((ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h).val i).2.values l := by
  intro he
  apply hav.2 i k
  refine ⟨.inl (0,i,⟨l.val,lt_of_lt_of_le l.isLt
    ((ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size_le⟩),?_⟩
  rw [he]
  exact ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry n j s h i l

/-- Current actual ghost births from the future-avoidance invariant. -/
theorem firstGhost_births_eq_pending_difference (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) :
    let c := ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h
    Finset.univ.image (c.val i).2.values =
      pendingSupport ((c.val.output anchor s c.property).memory P Line J B i) \
        pendingSupport (s.memory P Line J B i) := by
  exact ghost_births_eq_pending_difference _ _ _
    ((ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h).property.1 i)
    (firstGhost_fresh_old_disjoint value ν V η q ρ anchor geometry n j s h hav i)

/-- Current actual ghost deletion image from the proved support invariants. -/
theorem firstGhost_deaths_eq_pending_difference (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (hs : s.LiveDistinct)
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) :
    let c := ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h
    (c.val i).1.image (fun k => ((s.memory P Line J B i).values k).1) =
      pendingSupport (s.memory P Line J B i) \
        pendingSupport ((c.val.output anchor s c.property).memory P Line J B i) := by
  exact ghost_deaths_eq_pending_difference _ _ _
    ((ActualHistorySupport.firstGhost ν V η q ρ anchor geometry n j s h).property.1 i) (hs i).2.1
    (firstGhost_fresh_old_disjoint value ν V η q ρ anchor geometry n j s h hav i)

open ScheduledPhysicalPath ActualHistoryObservation

/-- Every actual edge store is recovered from its observed pending change. -/
theorem edgeAt_stores_eq_pending_difference (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin n) (i : I) :
    optionalPrimeSet ((edgeAt ν V η q ρ anchor geometry n j s h k).store i)
        ((beforeStateAt ν V η q ρ geometry n j s h k.castSucc).active P Line J B i
          ((edgeAt ν V η q ρ anchor geometry n j s h k).sourcePerm i (Fin.last J))) =
      pendingSupport ((beforeStateAt ν V η q ρ geometry n j s h k.succ).memory P Line J B i) \
        pendingSupport ((afterStateAt ν V η q ρ geometry n j s h k.castSucc).memory P Line J B i) := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · change optionalPrimeSet (h.2.1.val.group i).1
          (s.active P Line J B i (h.2.1.val.sourcePerm i (Fin.last J))) =
            pendingSupport ((beforeStateAt ν V η q ρ geometry n (j+1) _ h.2.2 0).memory P Line J B i) \ _
        rw [ActualHistoryLifespans.beforeStateAt_zero]
        exact physical_edge_stores_eq_pending_difference anchor _ h.2.1.val h.2.1.property hl.2.1 i
      · exact ih (j+1) _ h.2.2 hl.2.2 t

/-- Every actual promotion is exactly the observed pending loss across its edge. -/
theorem edgeAt_promotions_eq_pending_difference (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin n) (i : I) :
    optionalPrimeSet ((edgeAt ν V η q ρ anchor geometry n j s h k).promote i)
        ((edgeAt ν V η q ρ anchor geometry n j s h k).targetPrime i) =
      pendingSupport ((afterStateAt ν V η q ρ geometry n j s h k.castSucc).memory P Line J B i) \
        pendingSupport ((beforeStateAt ν V η q ρ geometry n j s h k.succ).memory P Line J B i) := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · change optionalPrimeSet ((record h.2.1.val).promote i)
          ((record h.2.1.val).targetPrime i) = _ \
            pendingSupport ((beforeStateAt ν V η q ρ geometry n (j+1) _ h.2.2 0).memory P Line J B i)
        rw [ActualHistoryLifespans.beforeStateAt_zero]
        convert physical_edge_promotions_eq_pending_difference anchor _ h.2.1.val h.2.1.property hl.2.1 i using 1
        · cases he : (h.2.1.val.group i).2 <;> simp [record,he]
        · rfl
      · exact ih (j+1) _ h.2.2 hl.2.2 t

/-- Literal images of the performed ghost birth tuples, at all visits. -/
def ghostBirthSetAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin (n+1) → ∀ i, Finset (P i)
  | 0,_,_,h,_ ,i => Finset.univ.image (h.1.val i).2.values
  | n+1,j,_,h,k,i => Fin.cases (Finset.univ.image (h.1.val i).2.values)
      (fun t => ghostBirthSetAt n (j+1) _ h.2.2 t i) k

/-- Literal images of the performed ghost deletion indices, at all visits. -/
def ghostDeathSetAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin (n+1) → ∀ i, Finset (P i)
  | 0,_,s,h,_ ,i => (h.1.val i).1.image (fun a => ((s.memory P Line J B i).values a).1)
  | n+1,j,s,h,k,i => Fin.cases
      ((h.1.val i).1.image (fun a => ((s.memory P Line J B i).values a).1))
      (fun t => ghostDeathSetAt n (j+1) _ h.2.2 t i) k

/-- Both ghost event images are recovered at every visit from the proved
future-distinctness and support invariants. -/
theorem ghostAt_events_eq_pending_differences (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (k : Fin (n+1)) (i : I) :
    ghostBirthSetAt ν V η q ρ anchor geometry n j s h k i =
      pendingSupport ((afterStateAt ν V η q ρ geometry n j s h k).memory P Line J B i) \
        pendingSupport ((beforeStateAt ν V η q ρ geometry n j s h k).memory P Line J B i) ∧
    ghostDeathSetAt ν V η q ρ anchor geometry n j s h k i =
      pendingSupport ((beforeStateAt ν V η q ρ geometry n j s h k).memory P Line J B i) \
        pendingSupport ((afterStateAt ν V η q ρ geometry n j s h k).memory P Line J B i) := by
  induction n generalizing j s with
  | zero => exact ⟨firstGhost_births_eq_pending_difference value ν V η q ρ anchor geometry 0 j s h hav i,
      firstGhost_deaths_eq_pending_difference value ν V η q ρ anchor geometry 0 j s h hl.1 hav i⟩
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · exact ⟨firstGhost_births_eq_pending_difference value ν V η q ρ anchor geometry (n+1) j s h hav i,
          firstGhost_deaths_eq_pending_difference value ν V η q ρ anchor geometry (n+1) j s h hl.1 hav i⟩
      · have hf := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
        exact ih (j+1) _ h.2.2 hf.1 hl.2.2 hf.2.2.2 t

/-- Global numerical birth distinctness and empty initial memories suffice
for all literal ghost event identities. No event/freshness premise remains. -/
theorem ghostAt_events_of_birthsDistinct (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    ghostBirthSetAt ν V η q ρ anchor geometry N 0 s h k i =
      pendingSupport ((afterStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) \
        pendingSupport ((beforeStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) ∧
    ghostDeathSetAt ν V η q ρ anchor geometry N 0 s h k i =
      pendingSupport ((beforeStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) \
        pendingSupport ((afterStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) := by
  have hf := ActualHistoryLifespans.initial_future_conditions ν V η q ρ anchor geometry value N s h hd hinitial
  exact ghostAt_events_eq_pending_differences value ν V η q ρ anchor geometry N 0 s h hf.1
    (ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial) hf.2 k i



/-- The finite deletion image agrees with the deletion field of the actual
observed ghost record, independently of any schedule. -/
theorem ghostAt_deleted_eq_deathSet (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) :
    (ghostAt ν V η q ρ anchor geometry n j s h k).deleted i =
      ghostDeathSetAt ν V η q ρ anchor geometry n j s h k i := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih => exact Fin.cases rfl (fun t => ih (j+1) _ h.2.2 t) k

/-- Under distinct performed births, the actual fresh bag has no
multiplicity loss when passing to its finite prime image. -/
theorem ghostAt_fresh_eq_birthSet_of_future_distinct (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (k : Fin (n+1)) (i : I) :
    (ghostAt ν V η q ρ anchor geometry n j s h k).fresh i =
      (ghostBirthSetAt ν V η q ρ anchor geometry n j s h k i).val := by
  induction n generalizing j s with
  | zero =>
      exact tupleBag_eq_image_val _
        (ActualHistorySupport.firstGhost_injective value ν V η q ρ anchor geometry 0 j s h hd i)
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · exact tupleBag_eq_image_val _
          (ActualHistorySupport.firstGhost_injective value ν V η q ρ anchor geometry (n+1) j s h hd i)
      · apply ih (j+1) _ h.2.2
        intro a b p ha hb
        apply ActualHistorySupport.tailAddress_injective n
        apply hd _ _ p
        · simpa only [ActualHistorySupport.futureLabels_tail] using ha
        · simpa only [ActualHistorySupport.futureLabels_tail] using hb

open ActualHistoryPending LifespanSchedule

/-- The store field of the extracted schedule is the literal actual store
choice. Only global birth distinctness and empty pending boundaries occur. -/
theorem extracted_stores_eq_actual (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin N) (i : I) :
    stores (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
    optionalPrimeSet ((edgeAt ν V η q ρ anchor geometry N 0 s h k).store i)
      ((beforeStateAt ν V η q ρ geometry N 0 s h k.castSucc).active P Line J B i
        ((edgeAt ν V η q ρ anchor geometry N 0 s h k).sourcePerm i (Fin.last J))) := by
  rw [stores_eq_pending_difference]
  have hb := extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k.succ i
  have ha := extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k.castSucc i
  simp only [Fin.val_succ,Fin.val_castSucc] at hb ha
  rw [hb,ha]
  exact (edgeAt_stores_eq_pending_difference ν V η q ρ anchor geometry N 0 s h
    (ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial) k i).symm

/-- The extracted promotion set recovers the literal promote/fresh branch. -/
theorem extracted_promotions_eq_actual (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin N) (i : I) :
    promotions (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
    optionalPrimeSet ((edgeAt ν V η q ρ anchor geometry N 0 s h k).promote i)
      ((edgeAt ν V η q ρ anchor geometry N 0 s h k).targetPrime i) := by
  rw [promotions_eq_pending_difference]
  have hb := extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k.succ i
  have ha := extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k.castSucc i
  simp only [Fin.val_succ,Fin.val_castSucc] at hb ha
  rw [ha,hb]
  exact (edgeAt_promotions_eq_pending_difference ν V η q ρ anchor geometry N 0 s h
    (ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial) k i).symm

/-- The extracted ghost-birth set is the image of the actually drawn batch. -/
theorem extracted_births_eq_actual (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    births (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
      ghostBirthSetAt ν V η q ρ anchor geometry N 0 s h k i := by
  rw [births_eq_pending_difference]
  rw [extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i,
    extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
  exact (ghostAt_events_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial k i).1.symm

/-- The extracted death set is the image of the actually deleted indices. -/
theorem extracted_deaths_eq_actual (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    deaths (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
      ghostDeathSetAt ν V η q ρ anchor geometry N 0 s h k i := by
  rw [deaths_eq_pending_difference]
  rw [extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i,
    extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
  exact (ghostAt_events_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial k i).2.symm


/-- The observed actual deletion record equals the extracted lifespan death
set at every visit, including both boundaries. -/
theorem ghostAt_deleted_eq_extracted_deaths (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    (ghostAt ν V η q ρ anchor geometry N 0 s h k).deleted i =
      deaths (observedPrimes ν V η q ρ geometry s h i)
        (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val := by
  rw [ghostAt_deleted_eq_deathSet]
  exact (extracted_deaths_eq_actual value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i).symm

/-- The actual fresh multiset is exactly the extracted birth set's multiset.
In particular, multiplicity is proved from actual birth distinctness rather
than silently discarded while constructing the schedule. -/
theorem ghostAt_fresh_eq_extracted_births (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    (ghostAt ν V η q ρ anchor geometry N 0 s h k).fresh i =
      (births (observedPrimes ν V η q ρ geometry s h i)
        (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val).val := by
  rw [extracted_births_eq_actual value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i]
  have hf := ActualHistoryLifespans.initial_future_conditions ν V η q ρ anchor geometry value N s h hd hinitial
  exact ghostAt_fresh_eq_birthSet_of_future_distinct value ν V η q ρ anchor geometry N 0 s h hf.1 k i

end ActualGhost

end ActualHistoryEvents
end Elliptic.Operator
