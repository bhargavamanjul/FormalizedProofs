module

public import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier
public import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
public import Elliptic.Operator.MellinPrimeSeparation

/-!
# A proved two-derivative L1 bound for the Mellin kernel

This is ordinary Fourier analysis: the actual Fourier transform is bounded
by the L1 norm of the function and by the L1 norm of its second derivative.
The integrable majorant (1+t²)^(-1) then controls the full Fourier L1 norm.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.FourierL1Control
open MeasureTheory FourierTransform Real Complex
set_option backward.isDefEq.respectTransparency false

/-- Two derivatives supply a coefficient-free integrable Fourier majorant. -/
theorem fourier_norm_le_two_derivatives (f : ℝ→ℂ)
    (hf : Integrable f) (hf' : Integrable (deriv f)) (hf'' : Integrable (deriv (deriv f)))
    (hdf : Differentiable ℝ f) (hdf' : Differentiable ℝ (deriv f)) (v : ℝ) :
    ‖𝓕 f v‖≤((∫x:ℝ,‖f x‖)+(2*Real.pi)^(-2:ℤ)*(∫x:ℝ,‖deriv (deriv f) x‖))*(1+v^2)⁻¹ := by
  have h0 := Real.norm_fourier_le_integral_norm f v
  have h2 := Real.norm_fourier_le_integral_norm (deriv (deriv f)) v
  rw [Real.fourier_deriv hf' hdf' hf'',Real.fourier_deriv hf hdf hf'] at h2
  simp only [smul_eq_mul,norm_mul,Complex.norm_I,Complex.norm_real,Real.norm_eq_abs,
    Complex.norm_ofNat,abs_of_pos Real.pi_pos,mul_one] at h2
  have hp : 0<2*Real.pi := by positivity
  have hs : v^2*‖𝓕 f v‖≤(2*Real.pi)^(-2:ℤ)*(∫x:ℝ,‖deriv (deriv f) x‖) := by
    rw [zpow_neg,zpow_ofNat,show (2*Real.pi:ℝ)^2=(2*Real.pi)*(2*Real.pi) by ring]
    apply (le_inv_mul_iff₀ (mul_pos hp hp)).mpr
    calc
      _ = 2*Real.pi*|v| *(2*Real.pi*|v| *‖𝓕 f v‖) := by rw [←sq_abs v]; ring
      _ ≤ _ := h2
  have hd : 0<1+v^2 := by positivity
  rw [←div_eq_mul_inv]
  apply (le_div_iff₀ hd).mpr
  nlinarith

/-- The actual Fourier L1 bound, with no Fourier-decay hypothesis. -/
theorem fourier_L1_le_two_derivatives (f : ℝ→ℂ)
    (hf : Integrable f) (hf' : Integrable (deriv f)) (hf'' : Integrable (deriv (deriv f)))
    (hdf : Differentiable ℝ f) (hdf' : Differentiable ℝ (deriv f))
    (hF : Integrable (𝓕 f)) :
    (∫v:ℝ,‖𝓕 f v‖)≤Real.pi*((∫x:ℝ,‖f x‖)+
      (2*Real.pi)^(-2:ℤ)*(∫x:ℝ,‖deriv (deriv f) x‖)) := by
  have hh := integral_mono hF.norm
    (integrable_inv_one_add_sq.const_mul ((∫x:ℝ,‖f x‖)+
      (2*Real.pi)^(-2:ℤ)*(∫x:ℝ,‖deriv (deriv f) x‖)))
    (fourier_norm_le_two_derivatives f hf hf' hf'' hdf hdf')
  rw [integral_const_mul,integral_univ_inv_one_add_sq] at hh
  simpa only [mul_comm] using hh

/-- Every smooth compact profile satisfies the two-derivative Fourier L1 bound. -/
theorem compact_profile_fourier_L1 (f : ℝ→ℂ) (hc : HasCompactSupport f)
    (hd : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) f) :
    (∫v:ℝ,‖𝓕 f v‖)≤Real.pi*((∫x:ℝ,‖f x‖)+
      (2*Real.pi)^(-2:ℤ)*(∫x:ℝ,‖deriv (deriv f) x‖)) := by
  let F := hc.toSchwartzMap hd
  have he : (SchwartzMap.derivCLM ℂ ℂ F : ℝ→ℂ)=deriv f := by
    funext x
    rw [SchwartzMap.derivCLM_apply]
    rfl
  have he2 : (SchwartzMap.derivCLM ℂ ℂ (SchwartzMap.derivCLM ℂ ℂ F) : ℝ→ℂ)=deriv (deriv f) := by
    funext x
    rw [SchwartzMap.derivCLM_apply,he]
  have hdF : Integrable (deriv f) := he ▸ (SchwartzMap.derivCLM ℂ ℂ F).integrable
  have hddF : Integrable (deriv (deriv f)) := he2 ▸
      (SchwartzMap.derivCLM ℂ ℂ (SchwartzMap.derivCLM ℂ ℂ F)).integrable
  have hdiff : Differentiable ℝ (deriv f) := he ▸ (SchwartzMap.derivCLM ℂ ℂ F).differentiable
  apply fourier_L1_le_two_derivatives f F.integrable hdF hddF F.differentiable hdiff
  exact (𝓕 F).integrable

/-- The source Mellin kernel is the usual Fourier transform of the logarithmic
profile with its exact 1/(2π) normalization and frequency rescaling. -/
theorem fourierKernel_eq (η : ℝ→ℂ) (v : ℝ) :
    Artin.MarkedSource.fourierKernel η v=
      (((2*Real.pi:ℝ)⁻¹):ℂ)*𝓕 (fun x:ℝ=>η (Real.exp x)) (v/(2*Real.pi)) := by
  unfold Artin.MarkedSource.fourierKernel
  congr 1
  rw [Real.fourier_eq']
  apply integral_congr_ae
  filter_upwards [] with x
  simp only [smul_eq_mul,RCLike.inner_apply',conj_trivial]
  rw [mul_comm (η (Real.exp x))]
  congr 2
  push_cast
  field_simp

/-- The source normalization preserves the L1 norm after the change of frequency. -/
theorem fourierKernel_L1_eq (η : ℝ→ℂ) :
    (∫v:ℝ,‖Artin.MarkedSource.fourierKernel η v‖)=
      ∫v:ℝ,‖𝓕 (fun x:ℝ=>η (Real.exp x)) v‖ := by
  simp_rw [fourierKernel_eq]
  simp only [norm_mul,norm_inv,Complex.norm_real,Real.norm_eq_abs,
    abs_inv,abs_of_pos (show 0<2*Real.pi by positivity),div_eq_mul_inv]
  rw [integral_const_mul,
    Measure.integral_comp_mul_right (fun v:ℝ=>‖𝓕 (fun x:ℝ=>η (Real.exp x)) v‖) ((2*Real.pi)⁻¹)]
  simp only [inv_inv,abs_of_pos (show 0<2*Real.pi by positivity),smul_eq_mul]
  field_simp
  simp [abs_of_pos Real.pi_pos]

/-- The positive scaling phase has modulus one, uniformly in Y. -/
theorem scaledKernel_norm (η : ℝ→ℂ) (Y v : ℝ) :
    ‖Artin.MarkedSource.scaledKernel η Y v‖=‖Artin.MarkedSource.fourierKernel η v‖ := by
  rw [Artin.MarkedSource.scaledKernel,norm_mul]
  have he : Complex.exp (-Complex.I*(v:ℂ)*(Real.log Y:ℂ))=
      Complex.exp (Complex.I*((-v*Real.log Y:ℝ):ℂ)) := by congr 1; push_cast; ring
  rw [he,Complex.norm_exp_I_mul_ofReal,mul_one]

end Elliptic.Operator.FourierL1Control
