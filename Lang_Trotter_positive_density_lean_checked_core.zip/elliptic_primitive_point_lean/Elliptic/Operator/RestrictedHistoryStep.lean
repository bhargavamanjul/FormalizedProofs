module
public import Elliptic.Operator.ChronologicalPrescription

/-! # One-step integration of a restriction on actual dependent histories -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ChronologicalPrescription
open scoped BigOperators
attribute [local instance 100000] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {X : Type*}

theorem restricted_cons_le (O : ChoiceOperation X) (ops : List (ChoiceOperation X))
    (w F : X→ℝ) (x:X) (A : O.ValidChoice x→Prop)
    (T : ∀c:O.ValidChoice x,ChoiceOperation.History ops (O.output x c.val c.property)→Prop)
    (C D : ℝ) (hD : 0≤D)
    (hrow : (∑c:O.ValidChoice x,if A c then ‖O.coefficient x c.val‖*w (O.output x c.val c.property) else 0)≤C*w x)
    (htail : ∀c:O.ValidChoice x,
      (∑h:ChoiceOperation.History ops (O.output x c.val c.property),
        if T c h then ‖h.weight‖*F h.final else 0)≤D*w (O.output x c.val c.property)) :
    (∑h:ChoiceOperation.History (O::ops) x,
      if A h.1 ∧ T h.1 h.2 then ‖h.weight‖*F h.final else 0)≤C*D*w x := by
  change (∑h:(Σc:O.ValidChoice x,ChoiceOperation.History ops (O.output x c.val c.property)),
    if A h.1 ∧ T h.1 h.2 then ‖O.coefficient x h.1.val*h.2.weight‖*F h.2.final else 0)≤_
  rw [Fintype.sum_sigma]
  calc
    _ ≤ ∑c:O.ValidChoice x,if A c then ‖O.coefficient x c.val‖*(D*w (O.output x c.val c.property)) else 0 := by
      apply Finset.sum_le_sum
      intro c _
      by_cases hc:A c
      · simp only [hc,true_and,ite_true,norm_mul]
        have he : (∑h:ChoiceOperation.History ops (O.output x c.val c.property),
            if T c h then ‖O.coefficient x c.val‖*‖h.weight‖*F h.final else 0)=
            ‖O.coefficient x c.val‖*(∑h:ChoiceOperation.History ops (O.output x c.val c.property),
              if T c h then ‖h.weight‖*F h.final else 0) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro h _
          split_ifs <;> ring
        rw [he]
        exact mul_le_mul_of_nonneg_left (htail c) (norm_nonneg _)
      · simp [hc]
    _ = D*(∑c:O.ValidChoice x,if A c then ‖O.coefficient x c.val‖*w (O.output x c.val c.property) else 0) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro c _
      split_ifs <;> ring
    _ ≤ D*(C*w x) := mul_le_mul_of_nonneg_left hrow hD
    _ = _ := by ring

end Elliptic.Operator.ChronologicalPrescription
