module

public import Elliptic.Operator.PhysicalDirtyOuter

/-!
# A canonical partition of the actual dirty raw choices

The distinguished group is the largest group which promotes an old indexed
particle. The key reads its old index and every store and fresh/free mode
from the edge itself. Thus no partition, mode support or fresh-product
identity is supplied as a new hypothesis. Both endpoint permutations and
the actual raw geometric support remain in the fibers.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyPartition
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance decidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- The fresh/free mode is read from the actual sum-type branch. -/
def freshMode (c : PhysicalEdgeChoice s) (i : Fin K) : Option (P i) :=
  match (c.group i).2 with
  | .inl _ => none
  | .inr p => some p

/-- Every dirty choice has a canonical largest promoted group. -/
def distinguished (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) : Fin K :=
  c.promotedGroups.max' h

theorem distinguished_mem (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    distinguished value s c h ∈ c.promotedGroups := Finset.max'_mem _ _

theorem promoted_le_distinguished (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty)
    (i : Fin K) (hi : i ∈ c.promotedGroups) : i ≤ distinguished value s c h :=
  Finset.le_max' _ _ hi

/-- The selected payload is its original memory index, even if several
memory positions carry the same prime. -/
def oldIndex (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B
      (distinguished value s c h)).size :=
  Classical.choose (show ∃ a, (c.group (distinguished value s c h)).2 = Sum.inl a from
    (Finset.mem_filter.mp (distinguished_mem value s c h)).2)

theorem oldIndex_spec (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    (c.group (distinguished value s c h)).2 = Sum.inl (oldIndex value s c h) :=
  Classical.choose_spec (show ∃ a, (c.group (distinguished value s c h)).2 = Sum.inl a from
    (Finset.mem_filter.mp (distinguished_mem value s c h)).2)

/-- Literal key of a dirty edge. -/
def key (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    PhysicalDirtyOuter.Key value s (distinguished value s c h) :=
  (oldIndex value s c h, (c.group (distinguished value s c h)).1,
    (fun i => (c.group i).1), fun i => freshMode value s c i)

/-- All dirty choices are assigned one actual outer key; clean choices
have no dirty key. -/
def classify (c : PhysicalEdgeChoice s) :
    Option (Σ i, PhysicalDirtyOuter.Key value s i) :=
  if h : c.promotedGroups.Nonempty then
    some ⟨distinguished value s c h, key value s c h⟩ else none

theorem classify_eq_none_iff (c : PhysicalEdgeChoice s) :
    classify value s c = none ↔ ¬ c.promotedGroups.Nonempty := by
  simp [classify]

theorem classify_some_iff (c : PhysicalEdgeChoice s) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) :
    classify value s c = some ⟨i,k⟩ ↔
      ∃ h : c.promotedGroups.Nonempty,
        (⟨distinguished value s c h, key value s c h⟩ :
          Σ j, PhysicalDirtyOuter.Key value s j) = ⟨i,k⟩ := by
  by_cases h : c.promotedGroups.Nonempty <;> simp [classify, h]

/-- Stores reconstructed from the canonical key are exactly the stores
of the input choice. -/
theorem key_stores (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    DirtyOuterBudget.stores (distinguished value s c h)
      (key value s c h).2.1 (key value s c h).2.2.1 = fun i => (c.group i).1 := by
  exact (Equiv.piSplitAt (distinguished value s c h) (fun _ => Bool)).symm_apply_apply
    (fun i => (c.group i).1)

/-- The canonical key gives the exact singleton distinguished promotion
and ordinary fresh/free-promotion support in every other group. -/
theorem key_mode_mem (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) (i : Fin K) :
    c.group i ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B i)
      (DirtyOuterBudget.stores (distinguished value s c h)
        (key value s c h).2.1 (key value s c h).2.2.1 i)
      (DirtyOuterBudget.modes
        (s.memory P (fun i p => Option (ZMod (value i p))) J B)
        (distinguished value s c h) (key value s c h).1 (key value s c h).2.2.2 i) := by
  rw [key_stores]
  by_cases hi : i = distinguished value s c h
  · subst i
    simp only [DirtyOuterBudget.modes, Equiv.piSplitAt, Equiv.coe_fn_symm_mk, dite_true,
      eq_self, dirtyGroupChoices, Finset.mem_singleton]
    apply Prod.ext
    · rfl
    · exact oldIndex_spec value s c h
  · simp only [DirtyOuterBudget.modes, Equiv.piSplitAt, Equiv.coe_fn_symm_mk, dite_eq_right hi]
    apply (DirtyOuterBudget.mem_choices_iff _ _ _ _).2
    constructor
    · rfl
    · change _ = freshMode value s c i
      cases he : (c.group i).2 <;> simp [freshMode, he]

/-- The fresh numeric product is determined solely by the key. -/
def keyFreshProduct (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) : ℕ :=
  ∏ j : {j : Fin K // j ≠ i}, match k.2.2.2 j with
    | none => 1
    | some p => value j p

theorem freshTargetProduct_eq_prod (c : PhysicalEdgeChoice s) :
    c.freshTargetProduct value = ∏ i, match freshMode value s c i with
      | none => 1
      | some p => value i p := by
  unfold PhysicalEdgeChoice.freshTargetProduct
  have hset : c.promotedGroupsᶜ = Finset.univ.filter (fun i => i ∉ c.promotedGroups) := by ext i; simp
  rw [hset, Finset.prod_filter]
  apply Finset.prod_congr rfl
  intro i _
  cases he : (c.group i).2 with
  | inl a => simp [PhysicalEdgeChoice.promotedGroups, freshMode, he]
  | inr p => simp [PhysicalEdgeChoice.promotedGroups, freshMode, he, edgeTargetPrime]


theorem freshTargetProduct_eq_key (c : PhysicalEdgeChoice s) (h : c.promotedGroups.Nonempty) :
    c.freshTargetProduct value =
      keyFreshProduct value s (distinguished value s c h) (key value s c h) := by
  rw [freshTargetProduct_eq_prod]
  let f : Fin K → ℕ := fun i => match freshMode value s c i with
    | none => 1
    | some p => value i p
  change (∏ i, f i) = _
  rw [← Finset.mul_prod_erase Finset.univ f (Finset.mem_univ (distinguished value s c h))]
  have hd : f (distinguished value s c h) = 1 := by
    simp [f, freshMode, oldIndex_spec]
  rw [hd, one_mul]
  simp only [keyFreshProduct, key]
  have hs : (∏ i ∈ Finset.univ.erase (distinguished value s c h), f i) =
      ∏ j : {j : Fin K // j ≠ distinguished value s c h}, f j :=
    Finset.prod_subtype _ (by simp) _
  rw [hs]
  apply Finset.prod_congr rfl
  intro j _
  cases he : freshMode value s c j <;> simp [f, he]

/-- The classification supplies all actual support conditions required
by the fixed-mode raw-coordinate estimate. -/
theorem classify_properties (c : PhysicalEdgeChoice s) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) (hc : classify value s c = some ⟨i,k⟩) :
    (c.group i).2 = Sum.inl k.1 ∧
    c.freshTargetProduct value = keyFreshProduct value s i k ∧
    (∀ j, c.group j ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B j)
      (DirtyOuterBudget.stores i k.2.1 k.2.2.1 j)
      (DirtyOuterBudget.modes
        (s.memory P (fun i p => Option (ZMod (value i p))) J B) i k.1 k.2.2.2 j)) ∧
    (∀ j ∈ c.promotedGroups, j ≤ i) := by
  obtain ⟨h, he⟩ := (classify_some_iff value s c i k).1 hc
  cases he
  exact ⟨oldIndex_spec value s c h, freshTargetProduct_eq_key value s c h,
    key_mode_mem value s c h, promoted_le_distinguished value s c h⟩

/-- Promotion pattern read from the outer key. -/
def keyPromotedGroups (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) : Finset (Fin K) :=
  {i} ∪ (Finset.univ.filter (fun j : {j : Fin K // j ≠ i} => k.2.2.2 j = none)).image
    Subtype.val

theorem promotedGroups_eq_key (c : PhysicalEdgeChoice s) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) (hc : classify value s c = some ⟨i,k⟩) :
    c.promotedGroups = keyPromotedGroups value s i k := by
  obtain ⟨h, he⟩ := (classify_some_iff value s c i k).1 hc
  cases he
  ext j
  by_cases hj : j = distinguished value s c h
  · subst j
    simp [keyPromotedGroups, distinguished_mem]
  · have hmem : j ∈ c.promotedGroups ↔ freshMode value s c j = none := by
      cases he : (c.group j).2 <;> simp [PhysicalEdgeChoice.promotedGroups, freshMode, he]
    rw [hmem]
    simp only [keyPromotedGroups, Finset.mem_union, Finset.mem_singleton, hj,
      false_or, Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · intro hp
      exact ⟨⟨j,hj⟩, hp, rfl⟩
    · rintro ⟨q,hq,rfl⟩
      exact hq

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Literal raw dirty support, before partition or any inequality. -/
def rawDirtyChoices (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) : Finset (PhysicalEdgeChoice s) :=
  Finset.univ.filter (fun c =>
    PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c ∧
      c.promotedGroups.Nonempty)

/-- A canonical raw fiber. No support or disjointness assumption enters
this definition. -/
def fiber (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) : Finset (PhysicalEdgeChoice s) :=
  Finset.univ.filter (fun c =>
    PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c ∧
      classify value s c = some ⟨i,k⟩)

/-- Every literal raw fiber lies in the previous fixed-old-index,
fixed-fresh-product support. -/
theorem fiber_subset_rawChoices (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) :
    fiber value position s good u v r U W d₀ σ i k ⊆
      PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i k.1
        (keyFreshProduct value s i k) := by
  intro c hc
  obtain ⟨hraw,hclass⟩ := (Finset.mem_filter.mp hc).2
  have h := classify_properties value s c i k hclass
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,hraw,h.1,h.2.1⟩

/-- All the fixed outer-mode memberships are proved from the fiber. -/
theorem fiber_mode_mem (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K) (k : PhysicalDirtyOuter.Key value s i)
    (c : PhysicalEdgeChoice s) (hc : c ∈ fiber value position s good u v r U W d₀ σ i k)
    (j : Fin K) :
    c.group j ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B j)
      (DirtyOuterBudget.stores i k.2.1 k.2.2.1 j)
      (DirtyOuterBudget.modes
        (s.memory P (fun i p => Option (ZMod (value i p))) J B) i k.1 k.2.2.2 j) :=
  (classify_properties value s c i k (Finset.mem_filter.mp hc).2.2).2.2.1 j

/-- Distinct outer keys have disjoint fibers, including keys with
different distinguished groups. -/
theorem fibers_disjoint (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (q t : Σ i, PhysicalDirtyOuter.Key value s i) (hne : q ≠ t) :
    Disjoint (fiber value position s good u v r U W d₀ σ q.1 q.2)
      (fiber value position s good u v r U W d₀ σ t.1 t.2) := by
  apply Finset.disjoint_left.mpr
  intro c hq hr
  apply hne
  exact Option.some.inj ((Finset.mem_filter.mp hq).2.2.symm.trans
    (Finset.mem_filter.mp hr).2.2)

/-- Exact finite sum partition of every actual raw dirty choice. The
summand may depend arbitrarily on geometry, damping and both permutations. -/
theorem sum_fibers (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (f : PhysicalEdgeChoice s → ℝ) :
    (∑ i, ∑ k : PhysicalDirtyOuter.Key value s i,
      ∑ c ∈ fiber value position s good u v r U W d₀ σ i k, f c) =
      ∑ c ∈ rawDirtyChoices value position s good u v r U W d₀ σ, f c := by
  have hs := Fintype.sum_sigma (f := fun q : Σ i, PhysicalDirtyOuter.Key value s i =>
    ∑ c ∈ fiber value position s good u v r U W d₀ σ q.1 q.2, f c)
  rw [← hs]
  simp only [fiber, rawDirtyChoices, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hr : PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c
  · simp only [hr, true_and]
    cases hc : classify value s c with
    | none =>
      have hd := (classify_eq_none_iff value s c).1 hc
      simp [hd]
    | some q =>
      have hd : c.promotedGroups.Nonempty := by
        by_contra hn
        have hh := (classify_eq_none_iff value s c).2 hn
        simp [hh] at hc
      simp [hd]
  · simp [hr]


/-- A nonempty fiber has exactly the promotion pattern encoded by its
key, including all ordinary free-promotion groups. -/
theorem fiber_promotedGroups (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K) (k : PhysicalDirtyOuter.Key value s i)
    (c : PhysicalEdgeChoice s) (hc : c ∈ fiber value position s good u v r U W d₀ σ i k) :
    c.promotedGroups = keyPromotedGroups value s i k :=
  promotedGroups_eq_key value s c i k (Finset.mem_filter.mp hc).2.2

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- The distinguished group really belongs to the key's promotion set. -/
theorem distinguished_mem_keyPromotedGroups (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) :
    i ∈ keyPromotedGroups value s i k := by
  simp [keyPromotedGroups]

/-- Nonempty fibers use a maximal promoted group, exactly as required
by the source's second good-state condition. -/
theorem fiber_key_maximal (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K) (k : PhysicalDirtyOuter.Key value s i)
    (hne : (fiber value position s good u v r U W d₀ σ i k).Nonempty) :
    ∀ j ∈ keyPromotedGroups value s i k, j ≤ i := by
  obtain ⟨c,hc⟩ := hne
  rw [← fiber_promotedGroups value position s good u v r U W d₀ σ i k c hc]
  exact (classify_properties value s c i k (Finset.mem_filter.mp hc).2.2).2.2.2

/-- Every genuine raw dirty edge belongs to exactly one fiber. -/
theorem mem_rawDirtyChoices_iff_exists_unique_fiber
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (c : PhysicalEdgeChoice s) :
    c ∈ rawDirtyChoices value position s good u v r U W d₀ σ ↔
      ∃! q : Σ i, PhysicalDirtyOuter.Key value s i,
        c ∈ fiber value position s good u v r U W d₀ σ q.1 q.2 := by
  constructor
  · intro hc
    obtain ⟨hr,hd⟩ := (Finset.mem_filter.mp hc).2
    refine ⟨⟨distinguished value s c hd, key value s c hd⟩, ?_, ?_⟩
    · simp [fiber,hr,classify,hd]
    · intro q hq
      have he := (Finset.mem_filter.mp hq).2.2
      simpa [classify,hd] using he.symm
  · rintro ⟨q,hq,_⟩
    obtain ⟨hr,hc⟩ := (Finset.mem_filter.mp hq).2
    have hd : c.promotedGroups.Nonempty := by
      by_contra hn
      have he := (classify_eq_none_iff value s c).2 hn
      simp [he] at hc
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,hr,hd⟩

/-- Exact actual product support of a canonical fiber. This image keeps
the dyadic pad restriction; it does not replace it by all possible omissions. -/
def fiberProductImage (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) : Finset ℕ :=
  (fiber value position s good u v r U W d₀ σ i k).image (fun c =>
    copiedProduct (physicalSourceLabels value
      (s.active P (fun i p => Option (ZMod (value i p))) J B))
      (fun j => c.sourcePerm j (Fin.last J)) * c.otherPromotedProduct value i)

/-- The actual weighted raw dirty row is the sum of its canonical
endpoint-averaged fibers, with no hypotheses on signs or geometry. -/
theorem endpoint_averaged_partition
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ rawDirtyChoices value position s good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) =
      ∑ i, ∑ k : PhysicalDirtyOuter.Key value s i,
        endpointPermutationWeight (Fin K) J *
          ∑ c ∈ fiber value position s good u v r U W d₀ σ i k,
            PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c := by
  rw [← sum_fibers value position s good u v r U W d₀ σ]
  simp only [Finset.mul_sum]

end Elliptic.Operator.PhysicalDirtyPartition
