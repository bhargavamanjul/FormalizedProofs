module

public import Elliptic.Operator.PhysicalRootRecordEncoding

/-!
# The actual physical closed moment is the literal numerical root sum

This completes the algebraic interface to RootFullRecordComparison.  The
record set is the injective image of all finite closed rooted paths, so it
is independent of the canonical root and keeps both endpoint permutations.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootMomentNumeric
open scoped BigOperators
open OriginalLifespanSchedule PhysicalPathGeometry PhysicalPathResidues
open PhysicalPathRootFinite PhysicalRootMomentReindex PhysicalRootRecordEncoding
open RootRecordEncoding RootRecordKernel OriginalPathWeights RootRecordComparison
open RootLiteralSum RootGridPartition RootVariableSum SourceRootCount SingleEdgeRootEncoding
attribute [local instance] Classical.propDecidable
local instance physicalNumericDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem canonical_normalized_in_box (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (t : RootTriple) (ht : t∈canonicalRoots U V) : InRootBox (normalizedRoot U V t) := by
  obtain ⟨ht,hc⟩ := Finset.mem_filter.mp ht
  have hb := (mem_rootCandidates_iff U V t hc).mp ht
  have hu : (0:ℝ)<t.1 := by exact_mod_cast hc.1
  change 1≤(t.1:ℝ)/U ∧ (t.1:ℝ)/U≤16 ∧ 1≤(t.2.1:ℝ)/V ∧ (t.2.1:ℝ)/V≤2 ∧
    0≤(t.2.2:ℝ)/t.1 ∧ (t.2.2:ℝ)/t.1≤1
  exact ⟨(le_div_iff₀ hU).mpr (by simpa using hb.1),
    (div_le_iff₀ hU).mpr hb.2.1,
    (le_div_iff₀ hV).mpr (by simpa using hb.2.2.1),
    (div_le_iff₀ hV).mpr hb.2.2.2,
    div_nonneg (by exact_mod_cast hc.2.1) hu.le,
    ((div_lt_one hu).mpr (by exact_mod_cast hc.2.2.1)).le⟩

theorem literalRootSum_eq_canonical (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (F : RootGridMeasure.RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ) :
    literalRootSum U V F=∑t∈canonicalRoots U V,if ht : Canonical t then
      F (normalizedRoot U V t) (canonicalSL2 t ht) else 0 := by
  unfold literalRootSum canonicalRoots
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hc : Canonical t
  · have hb := canonical_normalized_in_box U V hU hV t (Finset.mem_filter.mpr ⟨ht,hc⟩)
    simp only [dite_eq_left hc,ite_eq_left hc,ite_eq_left hb]
  · simp only [dite_eq_right hc,ite_eq_right hc]

theorem rootComplete_encode (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : ∀i,Function.Injective (value i)) (μ : ∀i,P i→ℝ)
    (r : FinitePath K J N R P) (adjoint : ℕ→Bool)
    (U V d₀ Y L : ℝ) (hU : 0<U) (hV : 0<V) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (η : ℕ→ℝ) :
    rootComplete (encode id value hv r) primes η U V
      (recordGeometry (encode id value hv r) (fun j=>adjoint j.val) value μ U V d₀ Y L
        exponents smooth ψ major σ) FinitePrimeCRT.integerLines =
    ∑t∈canonicalRoots U V,if ht : Canonical t then
      rootGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint (rawPath r) t*
        (rootResidue value primes η (rawPath r) (FinitePrimeCRT.integerLines (canonicalSL2 t ht)):ℂ)
      else 0 := by
  rw [rootComplete,literalRootSum_eq_canonical U V hU hV]
  apply Finset.sum_congr rfl
  intro t ht
  have hc := (Finset.mem_filter.mp ht).2
  simp only [dite_eq_left hc,recordGeometry_encode_root value hv hinj μ r adjoint
    U V d₀ Y L hU hV exponents smooth ψ major σ,
    PhysicalRootRecordEncoding.residueFactor_encode value hv]

def closedRecords (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q) : Finset (Record K J N R Q) :=
  closedFinitePaths.image (encode id value hv)

theorem closedRecords_active_subset (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (primes : Finset ℕ) (hvalues : ∀i p,value i p∈primes)
    (rec : Record K J N R Q) (hr : rec∈closedRecords value hv) :
    RootRecordBonferroni.activePrimes rec⊆primes := by
  obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hr
  intro p hp
  obtain ⟨j,i,k,hk⟩ := (RootRecordBonferroni.mem_activePrimes _ p).mp hp
  rw [←hk]
  exact hvalues i (r.active j i k)

/-- The unnormalized closed physical path moment, with original list and
endpoint-permutation normalization. -/
def physicalMoment (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (primes : Finset ℕ) (η : ℕ→ℝ) : ℂ :=
  (normalization VM J N:ℂ)*
    ∑r∈positionPaths (J:=J) (N:=N) (primitiveSources U V),
      if r.position (Fin.last N)=r.position 0 then
        pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r*
          (physicalResidue value primes η r:ℂ) else 0

/-- Exact full original-to-numerical moment identity. The only finite
radius hypothesis is the explicit geometric support ceiling. -/
theorem closed_physical_moment_eq_numerical_root_sum
    (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i))
    (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (d₀ Y L U V C : ℝ) (exponents : Fin K→ℝ) (hU : 0<U) (hV : 0<V)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (hN : 0<N) (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (hR : ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊≤R)
    (primes : Finset ℕ) (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ) :
    (normalization VM J N:ℂ)*
      (∑r∈positionPaths (J:=J) (N:=N) (primitiveSources U V),
        if r.position (Fin.last N)=r.position 0 then
          pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r*
            (physicalResidue value primes η r:ℂ) else 0) =
    (normalization VM J N:ℂ)*
      ∑rec∈closedRecords (J:=J) (N:=N) (R:=R) value hv,
        rootComplete rec primes η U V
          (recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L
            exponents smooth ψ major σ) FinitePrimeCRT.integerLines := by
  congr 1
  rw [closed_moment_eq_record_root_sum value μ d₀ Y L U V C exponents hU smooth ψ major σ adjoint
    hN hd hY hC hψ R hR primes hprime η]
  rw [←closedFinitePaths_image,Finset.sum_image rawPath_injective.injOn]
  unfold closedRecords
  rw [Finset.sum_image (encode_injective id Function.injective_id value hv hinj).injOn]
  apply Finset.sum_congr rfl
  intro r hr
  exact (rootComplete_encode value hv hinj μ r adjoint U V d₀ Y L hU hV exponents smooth ψ major σ primes η).symm

end Elliptic.Operator.PhysicalRootMomentNumeric
