module

public import Elliptic.Operator.GhostSchurRow
public import Elliptic.Operator.MemoryOutputBags
public import Mathlib.Data.Multiset.Antidiagonal
public import Mathlib.Algebra.BigOperators.Group.Finset.Powerset
public import Mathlib.Algebra.BigOperators.Intervals

/-!
# Symmetric memory and factorial adjoints

The ordered ghost transition appends a fresh batch at the end of the tuple.
Its adjoint formula therefore belongs to symmetric memory functions.  We
work with multiset functions, retaining every indexed deletion choice and
the original factorial product measure.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Symmetric deletion on a particle multiset. Multiplicities in the
multiset powerset count different indexed choices, including equal values. -/
def bagDeletion {X R : Type*} [CommSemiring R]
    (D F : Multiset X → R) (s : Multiset X) : R := by
  classical
  exact (s.powerset.map fun t => F (s - t) * D t).sum

/-- The part with a prescribed number of deleted coordinates. -/
def bagDeletionCard {X R : Type*} [CommSemiring R]
    (a : ℕ) (D F : Multiset X → R) (s : Multiset X) : R := by
  classical
  exact ((s.powersetCard a).map fun t => F (s - t) * D t).sum

theorem tupleBag_eq_map {ι X : Type*} [Fintype ι] (x : ι → X) :
    tupleBag x = (Finset.univ.val.map x) := by
  classical
  simp only [tupleBag, Finset.sum]
  simpa only [Multiset.map_map, Function.comp_def] using
    (Multiset.sum_map_singleton (Finset.univ.val.map x))

theorem selectedBag_eq_map {ι X : Type*} [Fintype ι] (S : Finset ι) (x : ι → X) :
    selectedBag S x = S.val.map x := by
  classical
  unfold selectedBag
  rw [← Finset.sum_subtype S (fun i => Iff.rfl) (fun i => ({x i} : Multiset X))]
  simp only [Finset.sum]
  simpa only [Multiset.map_map, Function.comp_def] using
    (Multiset.sum_map_singleton (S.val.map x))

theorem survivorBag_add_selectedBag {ι X : Type*} [Fintype ι] [DecidableEq ι]
    (S : Finset ι) (x : ι → X) : survivorBag S x + selectedBag S x = tupleBag x := by
  exact (tupleBag_split ((Equiv.sumComm _ _).trans
    (Equiv.sumCompl (fun i => i ∈ S))) x).symm

theorem survivorBag_eq_sub {ι X : Type*} [Fintype ι] [DecidableEq ι] [DecidableEq X]
    (S : Finset ι) (x : ι → X) : survivorBag S x = tupleBag x - selectedBag S x := by
  classical
  rw [← survivorBag_add_selectedBag S x, add_tsub_cancel_right]

theorem tupleBag_card {ι X : Type*} [Fintype ι] (x : ι → X) :
    (tupleBag x).card = Fintype.card ι := by
  rw [tupleBag_eq_map, Multiset.card_map]
  exact Finset.card_univ

/-- Fixed-length multiset deletion is exactly the existing indexed sum. -/
theorem bagDeletionCard_eq_indexedDeletion {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (D F : Multiset X → R) (x : Fin (k+a) → X) :
    bagDeletionCard a D F (tupleBag x) = indexedDeletion k a F D x := by
  classical
  unfold bagDeletionCard indexedDeletion
  rw [tupleBag_eq_map, Multiset.powersetCard_map]
  rw [← Finset.map_val_val_powersetCard]
  simp only [Multiset.map_map, Finset.sum]
  apply congrArg Multiset.sum
  apply Multiset.map_congr rfl
  intro S hS
  dsimp only [Function.comp_def]
  rw [← tupleBag_eq_map, ← selectedBag_eq_map, ← survivorBag_eq_sub]

theorem multiset_powerset_map {X Y : Type*} (f : X → Y) (s : Multiset X) :
    (s.map f).powerset = s.powerset.map (Multiset.map f) := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons x s ih => simp [Multiset.powerset_cons, ih, Multiset.map_map]

theorem finset_map_val_powerset {ι : Type*} (s : Finset ι) :
    s.powerset.val.map Finset.val = s.val.powerset := by
  classical
  simp [Finset.powerset, Multiset.map_pmap, Multiset.pmap_eq_map, Multiset.map_id']

theorem bagDeletion_eq_indexed {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [CommSemiring R]
    (D F : Multiset X → R) (x : ι → X) :
    bagDeletion D F (tupleBag x) =
      ∑ S : Finset ι, F (survivorBag S x) * D (selectedBag S x) := by
  classical
  unfold bagDeletion
  rw [tupleBag_eq_map, multiset_powerset_map, ← finset_map_val_powerset]
  simp only [Multiset.map_map]
  have hp : (Finset.univ : Finset ι).powerset = Finset.univ := by ext; simp
  rw [hp]
  change _ = (Finset.univ.val.map _).sum
  apply congrArg Multiset.sum
  apply Multiset.map_congr rfl
  intro S hS
  dsimp only [Function.comp_def]
  rw [← tupleBag_eq_map, ← selectedBag_eq_map, ← survivorBag_eq_sub]

/-- Fixed-length adjoint equality, now stated for symmetric multiset operators. -/
theorem bagDeletionCard_factorial_adjoint {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (k a : ℕ) (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : Fin (k+a) → X, tupleWeight μ x * F (tupleBag x) *
      bagDeletionCard a D G (tupleBag x)) / ((k+a).factorial : R) =
    (∑ u : Fin k → X, tupleWeight μ u * G (tupleBag u) *
      memoryBirthIntegral a μ D F (tupleBag u)) / (k.factorial : R) := by
  simp_rw [bagDeletionCard_eq_indexedDeletion]
  exact memory_birth_deletion_adjoint k a μ F G D

/-- Deletion decomposes by the number of actual selected coordinates. -/
theorem bagDeletion_eq_sum_card {X R : Type*} [CommSemiring R]
    (D F : Multiset X → R) (s : Multiset X) :
    bagDeletion D F s = ∑ a ∈ Finset.range (s.card + 1), bagDeletionCard a D F s := by
  classical
  unfold bagDeletion bagDeletionCard
  rw [← Multiset.bind_powerset_len s, Multiset.map_bind, Multiset.sum_bind]
  rfl

/-- Factorial product-measure integration of a symmetric memory function. -/
def symmetricMemoryIntegral {X R : Type*} [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (F : Multiset X → R) : R :=
  ∑ n ∈ Finset.range (B+1),
    (∑ x : Fin n → X, tupleWeight μ x * F (tupleBag x)) / (n.factorial : R)

/-- Birth into the actual memory cutoff. -/
def bagBirth {X R : Type*} [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (D F : Multiset X → R) (s : Multiset X) : R :=
  ∑ a ∈ Finset.range (B+1-s.card), memoryBirthIntegral a μ D F s

theorem sum_memory_triangle {R : Type*} [AddCommMonoid R]
    (B : ℕ) (f : ℕ → ℕ → R) :
    (∑ n ∈ Finset.range (B+1), ∑ a ∈ Finset.range (n+1), f (n-a) a) =
      ∑ k ∈ Finset.range (B+1), ∑ a ∈ Finset.range (B+1-k), f k a := by
  rw [Finset.sum_sigma', Finset.sum_sigma']
  apply Finset.sum_nbij' (fun x => ⟨x.1-x.2,x.2⟩) (fun x => ⟨x.1+x.2,x.2⟩)
  · intro x hx
    simp only [Finset.mem_sigma, Finset.mem_range] at hx ⊢
    omega
  · intro x hx
    simp only [Finset.mem_sigma, Finset.mem_range] at hx ⊢
    omega
  · intro x hx
    simp only [Finset.mem_sigma, Finset.mem_range] at hx
    apply Sigma.ext
    · dsimp; omega
    · rfl
  · intro x hx
    apply Sigma.ext
    · dsimp; omega
    · rfl
  · intro x hx
    rfl

/-- The complete deletion/birth adjoint identity, with the finite memory
cutoff and actual factorial tensor measure. -/
theorem bagDeletion_bagBirth_adjoint {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (B : ℕ) (μ : X → R) (F G D : Multiset X → R) :
    symmetricMemoryIntegral B μ (fun s => F s * bagDeletion D G s) =
      symmetricMemoryIntegral B μ (fun s => G s * bagBirth B μ D F s) := by
  classical
  unfold symmetricMemoryIntegral
  simp_rw [bagDeletion_eq_sum_card, tupleBag_card, Fintype.card_fin,
    Finset.mul_sum]
  conv_lhs => arg 2; ext n; rw [Finset.sum_comm]
  simp_rw [Finset.sum_div]
  have hterm (n a : ℕ) (ha : a ≤ n) :
      (∑ x : Fin n → X, tupleWeight μ x *
        (F (tupleBag x) * bagDeletionCard a D G (tupleBag x))) / (n.factorial : R) =
      (∑ u : Fin (n-a) → X, tupleWeight μ u * G (tupleBag u) *
        memoryBirthIntegral a μ D F (tupleBag u)) / ((n-a).factorial : R) := by
    obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le ha
    rw [Nat.add_sub_cancel_left, Nat.add_comm a k]
    simpa only [mul_assoc] using bagDeletionCard_factorial_adjoint k a μ F G D
  calc
    _ = ∑ n ∈ Finset.range (B+1), ∑ a ∈ Finset.range (n+1),
        (∑ u : Fin (n-a) → X, tupleWeight μ u * G (tupleBag u) *
          memoryBirthIntegral a μ D F (tupleBag u)) / ((n-a).factorial : R) := by
      apply Finset.sum_congr rfl
      intro n hn
      apply Finset.sum_congr rfl
      intro a ha
      rw [← Finset.sum_div]
      exact hterm n a (by simpa only [Finset.mem_range, Nat.lt_succ_iff] using ha)
    _ = ∑ k ∈ Finset.range (B+1), ∑ a ∈ Finset.range (B+1-k),
        (∑ u : Fin k → X, tupleWeight μ u * G (tupleBag u) *
          memoryBirthIntegral a μ D F (tupleBag u)) / (k.factorial : R) :=
      sum_memory_triangle B (fun k a =>
        (∑ u : Fin k → X, tupleWeight μ u * G (tupleBag u) *
          memoryBirthIntegral a μ D F (tupleBag u)) / (k.factorial : R))
    _ = _ := by
      simp only [bagBirth, tupleBag_card, Fintype.card_fin, Finset.mul_sum, Finset.sum_div]
      apply Finset.sum_congr rfl
      intro k hk
      rw [Finset.sum_comm]
      simp only [mul_assoc]

/-- On symmetric memory the full delete--survive--birth action has the
adjoint obtained by exchanging birth and deletion; the survival multiplier
is untouched. All three operators are the actual finite sums above. -/
theorem symmetric_ghost_adjoint {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (B : ℕ) (μ : X → R) (D A H F G : Multiset X → R) :
    symmetricMemoryIntegral B μ (fun s => G s *
      bagDeletion D (fun u => H u * bagBirth B μ A F u) s) =
    symmetricMemoryIntegral B μ (fun s => F s *
      bagDeletion A (fun u => H u * bagBirth B μ D G u) s) := by
  rw [bagDeletion_bagBirth_adjoint, bagDeletion_bagBirth_adjoint]
  congr 1
  funext s
  ring

/-- Every particle of this batch is at the current anchor. -/
def bagHits {P : Type*} {Line : P → Type*}
    (anchor : ∀ p, Line p) (s : Multiset (AnchoredParticle P Line)) : Prop :=
  ∀ x ∈ s, particleHits anchor x

/-- A batch coefficient, zero unless every particle hits. -/
def anchorBatch {P R : Type*} {Line : P → Type*} [CommSemiring R]
    (anchor : ∀ p, Line p) (d : R) (s : Multiset (AnchoredParticle P Line)) : R := by
  classical
  exact if bagHits anchor s then d ^ s.card else 0

def bagSurvival {P R : Type*} {Line : P → Type*} [CommSemiring R]
    (anchor : ∀ p, Line p) (r : R) (s : Multiset (AnchoredParticle P Line)) : R := by
  classical
  exact r ^ (s.filter (particleHits anchor)).card

@[simp] theorem bagHits_tupleBag {ι P : Type*} [Fintype ι]
    {Line : P → Type*} (anchor : ∀ p, Line p) (x : ι → AnchoredParticle P Line) :
    bagHits anchor (tupleBag x) ↔ ∀ i, particleHits anchor (x i) := by
  simp [bagHits, tupleBag_eq_map]

/-- Integrating particles forced to the current anchors leaves exactly
one prime measure per coordinate, with no factor for the number of lines. -/
theorem sum_anchored_tuples {ι P R : Type*} [Fintype ι] [DecidableEq ι] [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] [CommSemiring R]
    (anchor : ∀ p, Line p) (ν : P → R)
    (F : (ι → AnchoredParticle P Line) → R) :
    (∑ x : ι → AnchoredParticle P Line,
      if ∀ i, particleHits anchor (x i) then tupleWeight (fun z => ν z.1) x * F x else 0) =
    ∑ p : ι → P, tupleWeight ν p * F (fun i => anchorPrime anchor (p i)) := by
  classical
  rw [← Finset.sum_filter]
  apply Finset.sum_bij (fun x _ => fun i => (x i).1)
  · intro x hx; exact Finset.mem_univ _
  · intro x hx y hy hxy
    have hx' := (Finset.mem_filter.mp hx).2
    have hy' := (Finset.mem_filter.mp hy).2
    funext i
    have hi := congrFun hxy i
    have ex : x i = anchorPrime anchor (x i).1 := by
      exact Sigma.ext rfl (heq_of_eq (hx' i))
    have ey : y i = anchorPrime anchor (y i).1 := by
      exact Sigma.ext rfl (heq_of_eq (hy' i))
    rw [ex, ey, hi]
  · intro p hp
    refine ⟨(fun i => anchorPrime anchor (p i)), ?_, rfl⟩
    simp [particleHits, anchorPrime]
  · intro x hx
    have hx' := (Finset.mem_filter.mp hx).2
    have ex : x = fun i => anchorPrime anchor (x i).1 := by
      funext i
      exact Sigma.ext rfl (heq_of_eq (hx' i))
    congr 1
    exact congrArg F ex

theorem memoryBirthIntegral_anchorBatch {P R : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] [Field R]
    (anchor : ∀ p, Line p) (ν : P → R) (b : R) (a : ℕ)
    (F : Multiset (AnchoredParticle P Line) → R)
    (s : Multiset (AnchoredParticle P Line)) :
    memoryBirthIntegral a (fun z : AnchoredParticle P Line => ν z.1)
      (anchorBatch anchor b) F s =
    (∑ p : Fin a → P, tupleWeight ν p * b^a *
      F (s + tupleBag (fun i => anchorPrime anchor (p i)))) / (a.factorial : R) := by
  classical
  unfold memoryBirthIntegral
  congr 1
  have he (x : Fin a → AnchoredParticle P Line) :
      tupleWeight (fun z : AnchoredParticle P Line => ν z.1) x *
        anchorBatch anchor b (tupleBag x) * F (s + tupleBag x) =
      if ∀ i, particleHits anchor (x i) then
        tupleWeight (fun z : AnchoredParticle P Line => ν z.1) x *
          (b^a * F (s + tupleBag x)) else 0 := by
    simp only [anchorBatch, bagHits_tupleBag, tupleBag_card, Fintype.card_fin]
    split_ifs <;> simp [mul_assoc]
  simp_rw [he]
  convert sum_anchored_tuples (ι := Fin a) anchor ν (fun x => b^a * F (s + tupleBag x)) using 1
  · apply Finset.sum_congr rfl
    intro x hx
    split_ifs <;> rfl
  · apply Finset.sum_congr rfl
    intro x hx
    exact mul_assoc _ _ _

/-- The literal ghost operation expressed on symmetric particle multisets. -/
def bagGhost {P R : Type*} [Fintype P] {Line : P → Type*}
    [∀ p, Fintype (Line p)] [Field R]
    (B : ℕ) (anchor : ∀ p, Line p) (ν : P → R) (d r b : R)
    (F : Multiset (AnchoredParticle P Line) → R)
    (s : Multiset (AnchoredParticle P Line)) : R :=
  bagDeletion (anchorBatch anchor d)
    (fun u => bagSurvival anchor r u *
      bagBirth B (fun z : AnchoredParticle P Line => ν z.1) (anchorBatch anchor b) F u) s

/-- Source adjoint coefficient swap, with actual anchor-forced prime
integration and with the factorial measure and cutoff proved above. -/
theorem bagGhost_adjoint {P R : Type*} [Fintype P] {Line : P → Type*}
    [∀ p, Fintype (Line p)] [Field R] [CharZero R]
    (B : ℕ) (anchor : ∀ p, Line p) (ν : P → R) (d r b : R)
    (F G : Multiset (AnchoredParticle P Line) → R) :
    symmetricMemoryIntegral B (fun z : AnchoredParticle P Line => ν z.1)
      (fun s => G s * bagGhost B anchor ν d r b F s) =
    symmetricMemoryIntegral B (fun z : AnchoredParticle P Line => ν z.1)
      (fun s => F s * bagGhost B anchor ν b r d G s) :=
  symmetric_ghost_adjoint B _ _ _ _ F G

/-- Generic coefficients for the same actual indexed ghost choices. -/
def ghostCoefficientApply {P R : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    [Field R] (ν : P → R) (d r b : R) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) : R := by
  classical
  exact ∑ c : GhostChoice m, if hc : GhostChoice.Valid anchor m c then
    (d^c.1.card * r^(memoryHits anchor m \ c.1).card * b^c.2.size *
      tupleWeight ν c.2.values / (c.2.size.factorial : R)) *
      F (tupleBag (ghostOutput anchor m c hc).values) else 0

theorem sum_memoryState_by_length_generic {P R : Type*} [Fintype P]
    [AddCommMonoid R] (B : ℕ) (F : (l : ℕ) → (Fin l → P) → R) :
    (∑ fresh : MemoryState P B, F fresh.size fresh.values) =
      ∑ l ∈ Finset.range (B+1), ∑ fresh : Fin l → P, F l fresh := by
  rw [Fintype.sum_sigma]
  simpa [MemoryState.size, MemoryState.values] using
    (Fin.sum_univ_eq_sum_range (fun l => ∑ fresh : Fin l → P, F l fresh) (B+1))

theorem sum_range_cutoff {R : Type*} [AddCommMonoid R] (B k : ℕ) (F : ℕ → R) :
    (∑ l ∈ Finset.range (B+1), if k+l ≤ B then F l else 0) =
      ∑ l ∈ Finset.range (B+1-k), F l := by
  rw [← Finset.sum_filter]
  congr 1
  ext l
  simp only [Finset.mem_filter, Finset.mem_range]
  omega

theorem survivorBag_eq_compl_map {ι X : Type*} [Fintype ι] [DecidableEq ι]
    (S : Finset ι) (x : ι → X) : survivorBag S x = Sᶜ.val.map x := by
  unfold survivorBag
  rw [← Finset.sum_subtype Sᶜ (fun i => Finset.mem_compl) (fun i => ({x i} : Multiset X))]
  simp only [Finset.sum]
  simpa only [Multiset.map_map, Function.comp_def] using
    (Multiset.sum_map_singleton (Sᶜ.val.map x))

theorem survivorBag_card {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size)) :
    (survivorBag S m.values).card = m.size - S.card := by
  rw [survivorBag_eq_compl_map, Multiset.card_map]
  change Sᶜ.card = m.size - S.card
  simpa only [Fintype.card_fin] using Finset.card_compl S

theorem selectedBag_card {ι X : Type*} [Fintype ι] (S : Finset ι) (x : ι → X) :
    (selectedBag S x).card = S.card := by
  rw [selectedBag_eq_map, Multiset.card_map]
  rfl

theorem survivorBag_hits_card {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (S : Finset (Fin m.size)) :
    ((survivorBag S m.values).filter (particleHits anchor)).card =
      (memoryHits anchor m \ S).card := by
  classical
  rw [survivorBag_eq_compl_map, Multiset.filter_map, Multiset.card_map]
  change (Sᶜ.filter (fun i => particleHits anchor (m.values i))).card = _
  congr 1
  ext i
  simp only [memoryHits, Finset.mem_filter, Finset.mem_compl, Finset.mem_sdiff,
    Finset.mem_univ, true_and]
  exact and_comm

theorem bagHits_selectedBag {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (S : Finset (Fin m.size)) :
    bagHits anchor (selectedBag S m.values) ↔ S ⊆ memoryHits anchor m := by
  classical
  simp only [bagHits, selectedBag_eq_map, Multiset.mem_map, Finset.mem_val]
  constructor
  · intro h i hi
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, h _ ⟨i, hi, rfl⟩⟩
  · intro h x hx
    obtain ⟨i, hi, rfl⟩ := hx
    exact (Finset.mem_filter.mp (h hi)).2

/-- Exact connection of the actual indexed ghost choices with the
symmetric deletion--survival--birth operation. No kernel identity is a premise. -/
theorem ghostCoefficientApply_eq_bagGhost {P R : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ} [Field R]
    (ν : P → R) (d r b : R) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostCoefficientApply ν d r b anchor F m =
      bagGhost B anchor ν d r b F (tupleBag m.values) := by
  classical
  unfold ghostCoefficientApply bagGhost
  rw [bagDeletion_eq_indexed, Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro S hS
  simp only [anchorBatch, bagHits_selectedBag, selectedBag_card]
  by_cases hhit : S ⊆ memoryHits anchor m
  · rw [ite_eq_left hhit]
    simp only [ghostOutput_tupleBag, GhostChoice.Valid, hhit, true_and,
      Finset.card_compl, Fintype.card_fin, dite_eq_ite]
    rw [sum_memoryState_by_length_generic B (fun l fresh =>
      if m.size-S.card+l ≤ B then
        (d^S.card * r^(memoryHits anchor m \ S).card * b^l *
          tupleWeight ν fresh / (l.factorial : R)) *
          F (survivorBag S m.values + tupleBag (fun j => anchorPrime anchor (fresh j)))
      else 0)]
    simp_rw [Finset.sum_ite_irrel, Finset.sum_const_zero]
    rw [sum_range_cutoff]
    simp only [bagSurvival, survivorBag_hits_card, bagBirth, survivorBag_card,
      memoryBirthIntegral_anchorBatch]
    simp only [Finset.mul_sum, Finset.sum_mul, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro l hl
    apply Finset.sum_congr rfl
    intro fresh hfresh
    ring
  · rw [ite_eq_right hhit, mul_zero]
    apply Finset.sum_eq_zero
    intro fresh hfresh
    have hnot : ¬ GhostChoice.Valid anchor m (S, fresh) := fun h => hhit h.1
    simp only [dite_eq_right hnot]

/-- The factorial integral is precisely the actual ordered-state measure. -/
theorem symmetricMemoryIntegral_eq_sum_states {X R : Type*} [Fintype X] [Field R]
    (B : ℕ) (μ : X → R) (F : Multiset X → R) :
    symmetricMemoryIntegral B μ F =
      ∑ m : MemoryState X B, m.mass μ * F (tupleBag m.values) := by
  symm
  unfold MemoryState.mass
  rw [sum_memoryState_by_length_generic B (fun n x =>
    tupleWeight μ x / (n.factorial : R) * F (tupleBag x))]
  unfold symmetricMemoryIntegral
  simp only [Finset.sum_div, div_mul_eq_mul_div]

/-- The signed source ghost action uses exactly the generic coefficients
whose symmetric adjoint was calculated above. -/
theorem ghostApply_eq_coefficientApply {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostApply ν V η q ρ anchor (fun n => F (tupleBag n.values)) m =
      ghostCoefficientApply (fun p => (ν p : ℂ))
        ((-η / ρ : ℝ) : ℂ) ((q / ρ^2 : ℝ) : ℂ) ((-η*V / ρ : ℝ) : ℂ) anchor F m := by
  classical
  unfold ghostApply ghostCoefficientApply
  apply Finset.sum_congr rfl
  intro c hc
  split_ifs with h
  · congr 1
    simp only [ghostChoiceWeight, tupleWeight, Complex.ofReal_div, Complex.ofReal_mul,
      Complex.ofReal_pow, Complex.ofReal_prod, Complex.ofReal_natCast]
  · rfl

theorem ghostApply_eq_bagGhost {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostApply ν V η q ρ anchor (fun n => F (tupleBag n.values)) m =
      bagGhost B anchor (fun p => (ν p : ℂ))
        ((-η / ρ : ℝ) : ℂ) ((q / ρ^2 : ℝ) : ℂ) ((-η*V / ρ : ℝ) : ℂ)
        F (tupleBag m.values) := by
  rw [ghostApply_eq_coefficientApply, ghostCoefficientApply_eq_bagGhost]

/-- The actual choice-sum bilinear adjoint, on the actual factorial state
measure. The identity is proved from indexed deletion and prime integration. -/
theorem ghostCoefficientApply_adjoint {P R : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] [Field R] [CharZero R]
    (B : ℕ) (ν : P → R) (d r b : R) (anchor : ∀ p, Line p)
    (F G : Multiset (AnchoredParticle P Line) → R) :
    (∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun z => ν z.1) * G (tupleBag m.values) *
        ghostCoefficientApply ν d r b anchor F m) =
    ∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun z => ν z.1) * F (tupleBag m.values) *
        ghostCoefficientApply ν b r d anchor G m := by
  have h := bagGhost_adjoint B anchor ν d r b F G
  rw [symmetricMemoryIntegral_eq_sum_states, symmetricMemoryIntegral_eq_sum_states] at h
  simpa only [ghostCoefficientApply_eq_bagGhost, mul_assoc] using h

theorem memoryState_mass_complex {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (m : MemoryState (AnchoredParticle P Line) B) :
    m.mass (fun z : AnchoredParticle P Line => (ν z.1 : ℂ)) =
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) := by
  simp only [MemoryState.mass, tupleWeight, anchoredParticleMass,
    Complex.ofReal_div, Complex.ofReal_prod, Complex.ofReal_natCast]

/-- Weak bilinear adjoint identity for the exact signed source action.
It applies to symmetric tests on memory; the reversed action exchanges
`-η/ρ` and `-η*V/ρ`, with the same survival factor. -/
theorem ghostApply_symmetric_bilinear_adjoint {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)]
    (B : ℕ) (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F G : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) * G (tupleBag m.values) *
        ghostApply ν V η q ρ anchor (fun n => F (tupleBag n.values)) m) =
    ∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) * F (tupleBag m.values) *
        ghostCoefficientApply (fun p => (ν p : ℂ))
          ((-η*V/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((-η/ρ : ℝ) : ℂ) anchor G m := by
  simpa only [ghostApply_eq_coefficientApply, memoryState_mass_complex] using
    ghostCoefficientApply_adjoint B (fun p => (ν p : ℂ))
      ((-η/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((-η*V/ρ : ℝ) : ℂ) anchor F G

/-- The same proved adjoint identity for `MemoryTransitions.ghostKernel`
with its actual factorial density denominator. -/
theorem ghostKernel_symmetric_bilinear_adjoint {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)]
    (B : ℕ) (ν : P → ℝ) (hν : ∀ p, 0 < ν p) (V η q ρ : ℝ)
    (anchor : ∀ p, Line p) (F G : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) * G (tupleBag m.values) *
        finiteKernelApply Finset.univ (MemoryState.mass (anchoredParticleMass ν))
          (ghostKernel ν V η q ρ anchor) (fun n => F (tupleBag n.values)) m) =
    ∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) * F (tupleBag m.values) *
        ghostCoefficientApply (fun p => (ν p : ℂ))
          ((-η*V/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((-η/ρ : ℝ) : ℂ) anchor G m := by
  simp_rw [finiteKernelApply_ghostKernel ν hν]
  exact ghostApply_symmetric_bilinear_adjoint B ν V η q ρ anchor F G

open scoped ComplexConjugate

/-- Conjugation commutes with the actual choice sum when its coefficients
and prime measure are real. -/
theorem ghostCoefficientApply_conj {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (d r b : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostCoefficientApply (fun p => (ν p : ℂ)) (d : ℂ) (r : ℂ) (b : ℂ)
      anchor (fun s => conj (F s)) m =
    conj (ghostCoefficientApply (fun p => (ν p : ℂ)) (d : ℂ) (r : ℂ) (b : ℂ)
      anchor F m) := by
  classical
  unfold ghostCoefficientApply
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro c hc
  split_ifs with h
  · simp [tupleWeight]
  · simp

/-- Hermitian adjoint identity for the actual measured source ghost kernel
on symmetric functions. Its adjoint is the actual choice operation with
birth and deletion coefficients exchanged. -/
theorem ghostKernel_symmetric_adjoint {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)]
    (B : ℕ) (ν : P → ℝ) (hν : ∀ p, 0 < ν p) (V η q ρ : ℝ)
    (anchor : ∀ p, Line p) (F G : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) * conj (G (tupleBag m.values)) *
        finiteKernelApply Finset.univ (MemoryState.mass (anchoredParticleMass ν))
          (ghostKernel ν V η q ρ anchor) (fun n => F (tupleBag n.values)) m) =
    ∑ m : MemoryState (AnchoredParticle P Line) B,
      ((m.mass (anchoredParticleMass ν) : ℝ) : ℂ) *
        conj (ghostCoefficientApply (fun p => (ν p : ℂ))
          ((-η*V/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((-η/ρ : ℝ) : ℂ) anchor G m) *
          F (tupleBag m.values) := by
  rw [ghostKernel_symmetric_bilinear_adjoint B ν hν V η q ρ anchor F
    (fun s => conj (G s))]
  simp_rw [ghostCoefficientApply_conj]
  apply Finset.sum_congr rfl
  intro m hm
  ring

end Elliptic.Operator
