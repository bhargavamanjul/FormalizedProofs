module

public import Elliptic.Operator.CanonicalHistoryKey
public import Elliptic.Operator.ActualHistoryEvents

/-!
# The restricted finite-key fiber of a fixed schedule

The converse uses actual global birth distinctness and empty pending
boundaries. A finite key alone does not record repeated rebirths, so these
restrictions cannot simply be dropped. No compatible schedule is assumed
in the extraction premises: the supplied schedule is compared only with
the finite key of the actual history.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.CanonicalHistoryFiber
open scoped BigOperators
open ScheduledPhysicalPath ActualHistoryObservation ActualHistoryPending
open ActualHistoryLifespans LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance canonicalFiberDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- An ordered memory of size zero is the unique empty memory. -/
theorem memory_eq_empty_of_size_zero {X : Type*} {B : ℕ}
    (m : MemoryState X B) (hm : m.size = 0) : m = MemoryState.empty X B := by
  rcases m with ⟨⟨k,hk⟩,f⟩
  change k = 0 at hm
  subst k
  change (⟨⟨0,hk⟩,f⟩ : MemoryState X B) = ⟨⟨0,hk⟩,Fin.elim0⟩
  exact congrArg (fun g : Fin 0 → X => (⟨⟨0,hk⟩,g⟩ : MemoryState X B))
    (funext (fun i => Fin.elim0 i))

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- The before-zero condition fixes the entire initial state, including
the literal ordered empty memory. No extra initial-state equality is needed. -/
theorem before_initial_state_eq (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s) : s = d.initialState := by
  apply Subtype.ext
  apply Prod.ext hs.1
  apply Prod.ext hs.2.1
  funext i
  apply memory_eq_empty_of_size_zero
  have hh := memoryEnumeratesSet_size _ _ _ (hs.2.2 i)
  simpa only [before_zero,Finset.card_empty,PhysicalMemoryState.memory] using hh

/-- The directly extracted key has exactly the observed used-prime set. -/
theorem actualKey_primes
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (i : I) :
    (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h).primes i =
      observedPrimes ν V η q ρ geometry s h i := by
  ext p
  simp [CanonicalHistoryKey.primes,ActualHistoryObservation.canonicalKey,
    observedPrimes,Finset.filter_nonempty_iff]

/-- Equal finite keys identify the used-prime support without assuming
compatibility or global schedule coverage. -/
theorem primes_of_key_eq (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hk : ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey)
    (i : I) : observedPrimes ν V η q ρ geometry s h i = d.primes i := by
  rw [← actualKey_primes ν V η q ρ anchor geometry s h i,hk,d.canonicalKey_primes]

/-- Equal finite keys identify every used extracted lifespan. The interval
property is deduced from actual distinct births and the boundary conditions. -/
theorem lifespan_of_key_eq (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (hk : ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) :
    extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p = d.lifespan i p := by
  have hdp : p ∈ d.primes i := (primes_of_key_eq ν V η q ρ anchor geometry d s h hk i) ▸ hp
  rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp]
  apply PrimeLifespan.eq_of_observable_traces
  · intro j hj
    let k : Fin (N+1) := ⟨j,by omega⟩
    have ha := congrArg (fun t : CanonicalHistoryKey I Z P J N => t.active k) hk
    change (beforeStateAt ν V η q ρ geometry N 0 s h k).active P Line J B = d.active j at ha
    have hh := observedLifespan_active ν V η q ρ anchor geometry N s h hinitial hfinal i p hp k
    have hrec : observedActive ν V η q ρ geometry N 0 s h k i p ↔ j ∈ (d.lifespan i p).active := by
      unfold observedActive
      rw [ha]
      simpa only [hdp,true_and] using (d.active_lifespan j hj i p).symm
    exact hh.trans hrec
  · intro j hj
    let k : Fin (N+1) := ⟨j,by omega⟩
    have hol := observedLifespan_live ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp j
    dsimp only at hol
    have hl := congrArg (fun t : CanonicalHistoryKey I Z P J N => t.live i p) hk
    have hm := Finset.ext_iff.mp hl k
    have ht : observedLive ν V η q ρ geometry N 0 s h k i p ↔
        (d.lifespan i p).birth ≤ j ∧ j ≤ (d.lifespan i p).death := by
      simpa only [ActualHistoryObservation.canonicalKey,ScheduledPhysicalPath.canonicalKey,
        Finset.mem_filter,Finset.mem_univ,true_and,hdp,k] using hm
    rw [(d.lifespan i p).live_iff]
    exact hol.trans ((mem_observedLiveVisits ν V η q ρ anchor geometry N s h i p k).trans ht)

/-- Every filtered lifespan event or pending set transfers once the used
support and used lifespans have been recovered. -/
theorem filtered_lifespan_of_key_eq (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (hk : ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey)
    (i : I) (Q : PrimeLifespan N → Prop) :
    (observedPrimes ν V η q ρ geometry s h i).filter
      (fun p => Q (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p)) =
      (d.primes i).filter (fun p => Q (d.lifespan i p)) := by
  have hp := primes_of_key_eq ν V η q ρ anchor geometry d s h hk i
  conv_rhs => rw [← hp]
  apply Finset.filter_congr
  intro p hpi
  rw [lifespan_of_key_eq ν V η q ρ anchor geometry value d s h hd hinitial hfinal hk i p hpi]

/-- The missing fixed-schedule converse: a globally restricted actual
history with the same finite key satisfies every literal compatibility
test. No geometry or retained-line hypothesis is needed for this converse. -/
theorem compatible_of_key_eq (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (hk : ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey) :
    d.Compatible ν V η q ρ geometry N 0 s h := by
  apply compatible_of_records ν V η q ρ anchor geometry d N 0 s h
  · intro k
    constructor
    · intro i
      have hg := ActualHistoryEvents.ghostAt_deleted_eq_extracted_deaths
        value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i
      have he := filtered_lifespan_of_key_eq ν V η q ρ anchor geometry value d s h
        hd hinitial hfinal hk i (fun L => L.ghostDies k.val)
      exact hg.trans (by simpa only [deaths,Nat.zero_add] using he)
    · intro i
      have hg := ActualHistoryEvents.ghostAt_fresh_eq_extracted_births
        value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i
      have he := filtered_lifespan_of_key_eq ν V η q ρ anchor geometry value d s h
        hd hinitial hfinal hk i (fun L => L.ghostBorn k.val)
      simpa only [births,Nat.zero_add] using hg.trans (congrArg Finset.val he)
  · intro k
    dsimp only [EdgeMatches]
    simp only [Nat.zero_add]
    refine ⟨?_,?_,?_,?_,?_,?_⟩
    · have hp := congrArg (fun t : CanonicalHistoryKey I Z P J N => t.position k.succ) hk
      exact (next_position ν V η q ρ anchor geometry N 0 s h k).symm.trans hp
    · exact congrArg (fun t : CanonicalHistoryKey I Z P J N => t.sourcePerm k) hk
    · exact congrArg (fun t : CanonicalHistoryKey I Z P J N => t.targetPerm k) hk
    · exact congrArg (fun t : CanonicalHistoryKey I Z P J N => t.store k) hk
    · exact congrArg (fun t : CanonicalHistoryKey I Z P J N => t.promote k) hk
    · exact congrArg (fun t : CanonicalHistoryKey I Z P J N => t.targetPrime k) hk

/-- On the actual globally restricted histories, a key fiber is precisely
the independently defined compatible-history fiber. -/
theorem key_eq_iff_compatible (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0) :
    ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ↔
      d.Compatible ν V η q ρ geometry N 0 s h :=
  ⟨compatible_of_key_eq ν V η q ρ anchor geometry value d s h hd hinitial hfinal,
    canonicalKey_of_compatible ν V η q ρ anchor geometry d s hs h⟩

/-- Concrete restrictions from the original history expansion, retained in
both fibers until their invariance under birth reordering is proved. -/
def Restricted (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s) : Prop :=
  BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h) ∧
    ∀ i, (h.final.memory P Line J B i).size = 0

/-- Exact equality of the two selected predicates. The compatibility
predicate is the conclusion on the forward direction, not a premise. -/
theorem restricted_key_iff_compatible (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s) :
    (Restricted ν V η q ρ anchor geometry value s h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey) ↔
    (Restricted ν V η q ρ anchor geometry value s h ∧
      d.Compatible ν V η q ρ geometry N 0 s h) := by
  constructor
  · rintro ⟨hr,hk⟩
    exact ⟨hr,compatible_of_key_eq ν V η q ρ anchor geometry value d s h hr.1 hinitial hr.2 hk⟩
  · rintro ⟨hr,hc⟩
    exact ⟨hr,canonicalKey_of_compatible ν V η q ρ anchor geometry d s hs h hc⟩

/-- The exact weighted fiber identity keeps arbitrary global history
weights, initial factors and endpoint factors without any independence
or coefficient-constancy assumption. Both sides retain the restriction. -/
theorem sum_restricted_key_eq_compatible {R : Type*} [AddCommMonoid R]
    (value : ∀ i, P i → ℕ) (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (W : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s → R) :
    (∑ h, if Restricted ν V η q ρ anchor geometry value s h ∧
        ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey
      then W h else 0) =
    ∑ h, if Restricted ν V η q ρ anchor geometry value s h ∧
      d.Compatible ν V η q ρ geometry N 0 s h then W h else 0 := by
  apply Finset.sum_congr rfl
  intro h _
  simp only [restricted_key_iff_compatible ν V η q ρ anchor geometry value d s hs hinitial h]

/-- Explicit equivalence of the two restricted fibers. It preserves the
entire literal history, including all ordered intermediate memories. -/
def restrictedFiberEquiv (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0) :
    {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
      Restricted ν V η q ρ anchor geometry value s h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey} ≃
    {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
      Restricted ν V η q ρ anchor geometry value s h ∧
      d.Compatible ν V η q ρ geometry N 0 s h} :=
  Equiv.subtypeEquivRight (restricted_key_iff_compatible ν V η q ρ anchor geometry value d s hs hinitial)

/-- The same exact equality as a finite fiber sum rather than a zero-one
selector sum; weights may depend on the whole literal history. -/
theorem sum_restricted_fibers {R : Type*} [AddCommMonoid R]
    (value : ∀ i, P i → ℕ) (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (W : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s → R) :
    (∑ h : {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
        Restricted ν V η q ρ anchor geometry value s h ∧
        ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey}, W h.val) =
    ∑ h : {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
        Restricted ν V η q ρ anchor geometry value s h ∧
        d.Compatible ν V η q ρ geometry N 0 s h}, W h.val := by
  exact Equiv.sum_comp (restrictedFiberEquiv ν V η q ρ anchor geometry value d s hs hinitial)
    (fun h => W h.val)

end Elliptic.Operator.CanonicalHistoryFiber
