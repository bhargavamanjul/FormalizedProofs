module

public import Elliptic.Operator.MinorArcApproximation
public import Elliptic.Operator.SourceGeometryBounds
public import Mathlib.MeasureTheory.Group.AddCircle

/-!
# The actual major-circle measure bound

Reduce every rational numerator modulo its denominator. The literal
source major arcs are covered by at most floor(H)^2 circle balls of
radius 2H/Y, giving measure at most 4H^3/Y. This proves the comparison
multiplier's required small supremum from the actual arc definition.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcMeasure
open scoped BigOperators ENNReal
open MeasureTheory Set
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

theorem productCircleMeasure_eq_volume : productCircleMeasure=volume := by
  have h := AddCircle.volume_eq_smul_haarAddCircle (T:=(1 : ℝ))
  simpa using h.symm

/-- Rational circle centers depend only on the numerator residue. -/
theorem rational_center_emod (c : ℤ) (d : ℕ) (hd : 0<d) :
    (((c : ℝ)/(d : ℝ) : ℝ) : ProductCircle) =
      ((((c % (d : ℤ) : ℤ) : ℝ)/(d : ℝ) : ℝ) : ProductCircle) := by
  have hdR : (d : ℝ)≠0 := by exact_mod_cast hd.ne'
  have he : (c : ℝ)/(d : ℝ)=((c%(d : ℤ) : ℤ) : ℝ)/(d : ℝ)+((c/(d : ℤ) : ℤ) : ℝ) := by
    apply (div_eq_iff hdR).mpr
    have h := congrArg (fun n : ℤ => (n : ℝ)) (Int.emod_add_ediv_mul c (d : ℤ))
    push_cast at h
    field_simp
    nlinarith
  rw [he,AddCircle.coe_add,integer_coe_circle_zero,add_zero]

/-- A finite cover with explicit floor(H)^2 centers; no reduced-fraction
counting estimate or disjointness of arcs is assumed. -/
theorem sourceMajorArcs_subset (H Y : ℝ) :
    sourceMajorArcs H Y ⊆ ⋃d : Finset.Icc 1 ⌊H⌋₊,
      ⋃c : Finset.range ⌊H⌋₊,
        Metric.closedBall ((((c : ℕ) : ℝ)/(d : ℕ) : ℝ) : ProductCircle) (2*H/Y) := by
  intro θ hθ
  obtain ⟨c,d,hd,hdH,_,hdist⟩ := hθ
  have hdmem : d∈Finset.Icc 1 ⌊H⌋₊ := Finset.mem_Icc.mpr ⟨hd,Nat.le_floor hdH⟩
  have hmod0 : 0≤c%(d : ℤ) := Int.emod_nonneg c (by exact_mod_cast hd.ne')
  have hmod : c%(d : ℤ)<d := Int.emod_lt_of_pos c (by exact_mod_cast hd)
  have hk : (c%(d : ℤ)).toNat<⌊H⌋₊ := by
    have : (c%(d : ℤ)).toNat<d := by omega
    exact this.trans_le (Nat.le_floor hdH)
  refine Set.mem_iUnion.mpr ⟨⟨d,hdmem⟩,Set.mem_iUnion.mpr ⟨⟨_,Finset.mem_range.mpr hk⟩,?_⟩⟩
  rw [Metric.mem_closedBall]
  have hemod : ((c%(d : ℤ)).toNat : ℝ)=((c%(d : ℤ) : ℤ) : ℝ) := by
    exact_mod_cast Int.toNat_of_nonneg hmod0
  simpa only [rational_center_emod c d hd,hemod] using hdist

/-- The exact source major arc measure is at most 4H^3/Y. -/
theorem sourceMajorArcs_measure_le (H Y : ℝ) (hH : 0≤H) (hY : 0<Y) :
    productCircleMeasure (sourceMajorArcs H Y) ≤ ENNReal.ofReal (4*H^3/Y) := by
  rw [productCircleMeasure_eq_volume]
  apply (measure_mono (sourceMajorArcs_subset H Y)).trans
  calc
    _ ≤ ∑d : Finset.Icc 1 ⌊H⌋₊, ∑c : Finset.range ⌊H⌋₊,
        volume (Metric.closedBall ((((c : ℕ) : ℝ)/(d : ℕ) : ℝ) : ProductCircle) (2*H/Y)) :=
      (measure_iUnion_fintype_le _ _).trans (Finset.sum_le_sum fun _ _ => measure_iUnion_fintype_le _ _)
    _ ≤ ∑_d : Finset.Icc 1 ⌊H⌋₊, ∑_c : Finset.range ⌊H⌋₊, ENNReal.ofReal (4*H/Y) := by
      apply Finset.sum_le_sum
      intro d _
      apply Finset.sum_le_sum
      intro c _
      rw [AddCircle.volume_closedBall]
      apply ENNReal.ofReal_le_ofReal
      calc
        _ ≤ 2*(2*H/Y) := min_le_right _ _
        _ = _ := by ring
    _ = ENNReal.ofReal ((⌊H⌋₊ : ℝ)^2*(4*H/Y)) := by
      simp only [Finset.sum_const,Finset.card_univ,Fintype.card_coe,Finset.card_range,
        Nat.card_Icc,nsmul_eq_mul]
      simp only [Nat.add_sub_cancel]
      rw [ENNReal.ofReal_mul (by positivity),ENNReal.ofReal_pow (by positivity)]
      simp
      ring
    _ ≤ _ := ENNReal.ofReal_le_ofReal (by
      have hfloor := Nat.floor_le hH
      have hnon : (0:ℝ)≤⌊H⌋₊ := by positivity
      have hs : (⌊H⌋₊ : ℝ)^2≤H^2 := by nlinarith
      have hm := mul_le_mul_of_nonneg_right hs (show 0≤4*H/Y by positivity)
      convert hm using 1
      ring)

/-- The Fourier comparison kernel is bounded by the actual major mass. -/
theorem minorFourierTransform_norm_le_measure (arcs : Set ProductCircle) (n : ℤ) :
    ‖minorFourierTransform arcs n‖≤productCircleMeasure.real arcs := by
  have h : ‖∫ θ in arcs, fourier n θ ∂productCircleMeasure‖ ≤
      1*(productCircleMeasure.restrict arcs).real Set.univ :=
    norm_integral_le_of_norm_le_const
      (Filter.Eventually.of_forall (fun θ => by simp [fourier_apply]))
  simpa only [minorFourierTransform,one_mul,Measure.real,Measure.restrict_apply_univ] using h

theorem sourceMajorArcs_fourier_norm_le (H Y : ℝ) (hH : 0≤H) (hY : 0<Y) (n : ℤ) :
    ‖minorFourierTransform (sourceMajorArcs H Y) n‖≤4*H^3/Y := by
  apply (minorFourierTransform_norm_le_measure _ n).trans
  exact (ENNReal.toReal_le_toReal (measure_ne_top _ _) ENNReal.ofReal_ne_top).mpr
    (sourceMajorArcs_measure_le H Y hH hY) |>.trans_eq
      (ENNReal.toReal_ofReal (by positivity))

end Elliptic.Operator.MajorArcMeasure
