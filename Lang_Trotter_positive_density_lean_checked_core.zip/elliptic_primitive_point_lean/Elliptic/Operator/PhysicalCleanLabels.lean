module
public import Elliptic.Operator.PhysicalCleanNorm
public import Elliptic.Operator.PhysicalCleanBlocks

/-! The actual prime-subtype tuple is identified with the positive
prime-choice space used by the proved determinant bound. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators SchwartzMap
attribute [local instance] Classical.propDecidable
local instance physicalCleanLabelsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Exact measured transport to a finite embedded support. -/
theorem finiteMeasuredBilinearBound_embedding {X Y U V : Type*}
    (s : Finset X) (t : Finset Y) (e : X ↪ U) (f : Y ↪ V)
    (μ : U → ℝ) (ν : V → ℝ) (K : U → V → ℂ) (M : ℝ)
    (hK : FiniteMeasuredBilinearBound (s.map e) (t.map f) μ ν K M) :
    FiniteMeasuredBilinearBound s t (fun x => μ (e x)) (fun y => ν (f y))
      (fun x y => K (e x) (f y)) M := by
  intro a b
  have h := hK (Function.extend e a (fun _ => 0)) (Function.extend f b (fun _ => 0))
  simpa only [finiteMeasuredPairing,finiteKernelApply,finiteL2,finiteL2Sq,
    Finset.sum_map,e.injective.extend_apply,f.injective.extend_apply] using h

namespace PhysicalCleanLabels
variable {I : Type*} [Fintype I]

/-- Actual one-prime-per-band tuples, including their dependent types. -/
def primeChoiceEquiv (groups : I → Finset ℕ) :
    (∀ i, groups i) ≃ PrimeChoice Finset.univ groups where
  toFun p := ⟨fun i => (p i.val).val, by
    rw [Fintype.mem_piFinset]
    intro i
    exact (p i.val).property⟩
  invFun q := fun i => ⟨q.val ⟨i,Finset.mem_univ i⟩,
    (Fintype.mem_piFinset.mp q.property) ⟨i,Finset.mem_univ i⟩⟩
  left_inv p := by funext i; rfl
  right_inv q := by apply Subtype.ext; funext i; rfl

theorem primeChoiceEquiv_product (groups : I → Finset ℕ) (p : ∀ i, groups i) :
    primeChoiceProduct Finset.univ groups (primeChoiceEquiv groups p)=∏ i, (p i).val := by
  exact Finset.prod_coe_sort Finset.univ (fun i => (p i).val)

theorem primeChoiceEquiv_mass (groups : I → Finset ℕ) (ν : I → ℕ → ℝ) (p : ∀ i, groups i) :
    primeChoiceMass Finset.univ groups ν (primeChoiceEquiv groups p)=∏ i, ν i (p i).val := by
  exact Finset.prod_coe_sort Finset.univ (fun i => ν i (p i).val)

/-- Position and prime labels are both transported injectively. -/
def padLabelEmbedding (groups : I → Finset ℕ) (z : ℤ×ℤ) (D : ℤ) :
    (PadPosition z D × (∀ i, groups i)) ↪ (PadPosition z D × PrimeChoice Finset.univ groups) :=
  Function.Embedding.prodMap (Function.Embedding.refl _) (primeChoiceEquiv groups).toEmbedding

@[simp] theorem padLabelEmbedding_apply (groups : I → Finset ℕ) (z : ℤ×ℤ) (D : ℤ)
    (p : PadPosition z D × (∀ i, groups i)) :
    padLabelEmbedding groups z D p=(p.1,primeChoiceEquiv groups p.2) := rfl

/-- Literal subtype prime weights and label products in a physical pad
box, with the sharp determinant budget and no enlarged-label norm premise. -/
theorem actual_subtype_clean_pad_box_bound
    (groups : I → Finset ℕ)
    (hprime : ∀ i, ∀ p∈groups i, p.Prime)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (ν : I → ℕ → ℝ) (C : I → ℝ) (hC : ∀ i, 0≤C i)
    (hν : ∀ i, ∀ p∈groups i, 0≤ν i p)
    (hνbound : ∀ i, ∀ p∈groups i, ν i p≤C i/p)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1) (D : ℤ) (hD : D≠0)
    (b₁ b₂ : ℤ×ℤ) (hb : latticeDet b₁ b₂=1)
    (s t : Finset (PadPosition z D × (∀ i, groups i)))
    (ψ : 𝓢(ℝ,ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1≤H) (hY : 0<Y)
    (hsbox : ∀ p∈s, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A)))
    (htbox : ∀ p∈t, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A)))
    (hs : ∀ p∈s, Y≤((∏ i, (p.2 i).val):ℕ))
    (ht : ∀ p∈t, Y≤((∏ i, (p.2 i).val):ℕ)) (σ : ℤ) (hσ : σ=1 ∨ σ= -1) :
    FiniteMeasuredBilinearBound s t
      (fun p => ∏ i, ν i (p.2 i).val) (fun p => ∏ i, ν i (p.2 i).val)
      (fun p q => ψ ((padDeterminant z D p.1 q.1:ℝ)/Y)*
        minorFourierTransform (sourceMajorArcs H Y)ᶜ
          (padDeterminant z D p.1 q.1-σ*(∏ i, (p.2 i).val)+σ*(∏ i, (q.2 i).val)))
      ((∏ i, C i)*smoothedDeterminantBudget ψ A B H Y k) := by
  let e := padLabelEmbedding groups z D
  have h := actual_measured_signed_clean_pad_box_bound Finset.univ groups
    (fun i _ => hprime i) (fun i _ j _ hij => hdis i j hij) ν C (fun i _ => hC i)
    (fun i _ => hν i) (fun i _ => hνbound i) z w hzw D hD b₁ b₂ hb
    (s.map e) (t.map e) ψ A B a b H Y k hH hY
    (by intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp; exact hsbox q hq)
    (by intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp; exact htbox q hq)
    (by intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp; simpa only [e,padLabelEmbedding_apply,primeChoiceEquiv_product] using hs q hq)
    (by intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp; simpa only [e,padLabelEmbedding_apply,primeChoiceEquiv_product] using ht q hq)
    σ hσ
  have hh := finiteMeasuredBilinearBound_embedding s t e e _ _ _ _ h
  simpa only [e,padLabelEmbedding_apply,
    primeChoiceEquiv_mass,actualSignedCleanKernel,primeChoiceEquiv_product,Finset.prod_coe_sort] using hh

end PhysicalCleanLabels
end Elliptic.Operator
