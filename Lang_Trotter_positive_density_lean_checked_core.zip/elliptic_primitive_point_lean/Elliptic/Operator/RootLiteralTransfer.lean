module

public import Elliptic.Operator.RootLiteralGeometry
public import Elliptic.Operator.RootSourceScale
public import Elliptic.Operator.RootArchimedeanTransfer

/-!
# Integer-root replacement for the literal finite source path kernel

This is the actual product of oriented source edge multipliers, with
both original good-state tests and the physical box projections, times
an arbitrary bounded residue test. Every root-geometric and measurable
input to the root/integral comparison is proved here from the definitions.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootLiteralTransfer
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootArchimedeanGrid RootGridPartition RootBoundaryCover RootGridMeasure
open RootArchimedeanTransfer RootLiteralGeometry RootVariableSum
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

abbrev RootPoint := ℝ × ℝ × ℝ
variable {K J N : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def pathGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : Fin N→Bool)
    (z : Fin (N+1)→ℤ×ℤ) (a : Fin (N+1)→PhysicalActiveLists P J) (q : RootPoint) : ℂ :=
  ∏ e : Fin N, geometry (adjoint e) value μ U V d₀ Y L exponents η ψ major σ
    (z e.castSucc) (a e.castSucc) (z e.succ) (a e.succ) q

def pathKernel (S : ℕ) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : Fin N→Bool)
    (z : Fin (N+1)→ℤ×ℤ) (a : Fin (N+1)→PhysicalActiveLists P J)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (q : RootPoint) (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) : ℂ :=
  pathGeometry value μ U V d₀ Y L exponents η ψ major σ adjoint z a q * ρ g

theorem pathGeometry_measurable (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : Fin N→Bool)
    (z : Fin (N+1)→ℤ×ℤ) (a : Fin (N+1)→PhysicalActiveLists P J) :
    Measurable (pathGeometry value μ U V d₀ Y L exponents η ψ major σ adjoint z a) :=
  Finset.measurable_prod _ (fun e _=>geometry_measurable (adjoint e) value μ U V d₀ Y L exponents
    η ψ major σ (z e.castSucc) (a e.castSucc) (z e.succ) (a e.succ))

theorem pathGeometry_norm_le_one (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (hη : ∀t, ‖η t‖≤1) (hψ : ∀t, ‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) (adjoint : Fin N→Bool)
    (z : Fin (N+1)→ℤ×ℤ) (a : Fin (N+1)→PhysicalActiveLists P J) (q : RootPoint) :
    ‖pathGeometry value μ U V d₀ Y L exponents η ψ major σ adjoint z a q‖≤1 := by
  unfold pathGeometry
  rw [norm_prod]
  calc
    _ ≤ ∏ _e : Fin N, (1:ℝ) := Finset.prod_le_prod₀ (fun _ _=>norm_nonneg _)
      (fun e _=>geometry_norm_le_one (adjoint e) value μ U V d₀ Y L hd exponents
        η ψ hη hψ major hmajor σ (z e.castSucc) (a e.castSucc) (z e.succ) (a e.succ) q)
    _ = 1 := by simp

theorem pathKernel_norm_le_one (S : ℕ) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (hη : ∀t, ‖η t‖≤1) (hψ : ∀t, ‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) (adjoint : Fin N→Bool)
    (z : Fin (N+1)→ℤ×ℤ) (a : Fin (N+1)→PhysicalActiveLists P J)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) (hρ : ∀g, ‖ρ g‖≤1)
    (q : RootPoint) (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) :
    ‖pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ q g‖≤1 := by
  rw [pathKernel,norm_mul]
  have h := mul_le_mul (pathGeometry_norm_le_one value μ U V d₀ Y L hd exponents η ψ hη hψ
    major hmajor σ adjoint z a q) (hρ g) (norm_nonneg _) (by norm_num : (0:ℝ)≤1)
  simpa only [one_mul] using h

theorem pathKernel_constant (S : ℕ) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (adjoint : Fin N→Bool) (z : Fin (N+1)→ℤ×ℤ) (hz : ∀i,z i∈integerPositionBox R)
    (a : Fin (N+1)→PhysicalActiveLists P J)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q)
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) :
    pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ p g =
      pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ q g := by
  unfold pathKernel pathGeometry
  congr 1
  exact Finset.prod_congr rfl (fun e _=>oriented_geometry_constant (adjoint e) value μ R Q hQ hv
    d₀ Y L exponents hY n j hj U V hU hV η ψ major σ hout
    (z e.castSucc) (z e.succ) (hz e.castSucc) (hz e.succ)
    (a e.castSucc) (a e.succ) p q hp hq)

/-- The elementary scale restriction can be removed: the actual cutoff
makes every edge zero when it fails. This also handles the empty path. -/
theorem pathKernel_constant_with_cutoff (S : ℕ) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hK : 1≤K) (hQ : 2≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : 1≤Y)
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (hsupport : ∀t,η t≠0→1/2≤t) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (adjoint : Fin N→Bool) (z : Fin (N+1)→ℤ×ℤ) (hz : ∀i,z i∈integerPositionBox R)
    (a : Fin (N+1)→PhysicalActiveLists P J)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q)
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) :
    pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ p g =
      pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ q g := by
  by_cases hscale : Y^(1/5:ℝ)≤(Q^(2*K):ℝ)
  · exact pathKernel_constant S value μ R Q (by omega) hv d₀ Y L exponents hscale
      n j hj U V hU hV η ψ major σ hout adjoint z hz a ρ p q hp hq g
  · unfold pathKernel pathGeometry
    congr 1
    apply Finset.prod_congr rfl
    intro e he
    rw [RootSourceScale.geometry_eq_zero_of_scale (adjoint e) value μ Q hK hQ hv
      U V d₀ Y L hY exponents η ψ hsupport hscale major σ
      (z e.castSucc) (a e.castSucc) (z e.succ) (a e.succ) p,
      RootSourceScale.geometry_eq_zero_of_scale (adjoint e) value μ Q hK hQ hv
      U V d₀ Y L hY exponents η ψ hsupport hscale major σ
      (z e.castSucc) (a e.castSucc) (z e.succ) (a e.succ) q]

/-- The external analytic input is only RootCountContract. Every
root-cell, physical-boundary, source-good-test and integration step for
the displayed literal path kernel is discharged by proved lemmas. -/
theorem eventually_source_path_transfer (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ K J N : ℕ, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ (n R Q : ℕ), 0<n → (n:ℝ)^3≤x^(δ/2000) → 1≤Q →
      ∀ U V d₀ Y L : ℝ, ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V → 0<d₀ →
      Y^(1/5:ℝ)≤(Q^(2*K):ℝ) →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤Q) → ∀ exponents : Fin K→ℝ,
      ∀ η ψ : ℝ→ℂ, (∀t, ‖η t‖≤1) → (∀t, ‖ψ t‖≤1) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin N→Bool, ∀ z : Fin (N+1)→ℤ×ℤ,
      (∀i,z i∈integerPositionBox R) → ∀ a : Fin (N+1)→PhysicalActiveLists P J,
      ∀ ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ, (∀g, ‖ρ g‖≤1) →
      ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1)
          (pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ) -
        rootIntegral U V S (pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ)‖ ≤
        2*(U*V/(Real.pi^2/6))*
          (((((2*R+1)^2:ℕ):ℝ)*(16864*(R:ℝ)+120)+
            30*((sourceEndpoints (J:=J) R Q Y L exponents).card:ℝ))/(n:ℝ)) +
          2*(U*V*x^(-(δ/4000))) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    eventually_physical_root_transfer hPD δ C_S hδ hCS] with x hx ht
  intro K J N P instP n R Q hn hn' hQ U V d₀ Y L S inst hU hU' hV hV' hUV hd hY hS hSq hSize
    value μ hv exponents η ψ hη hψ major hmajor σ adjoint z hz a ρ hρ
  have hUp : 0<U := (Real.rpow_pos_of_pos hx δ).trans_le hU
  have hVp : 0<V := (Real.rpow_pos_of_pos hx δ).trans_le hV
  have h := ht n hn hn' (integerPositionBox R) (sourceEndpoints (J:=J) R Q Y L exponents)
    U V R S hU hU' hV hV' hUV (fun z hz=>(position_coordinate_bounds R z hz).2)
    hS hSq hSize (pathKernel S value μ U V d₀ Y L exponents η ψ major σ adjoint z a ρ)
    (pathKernel_norm_le_one S value μ U V d₀ Y L hd exponents η ψ hη hψ major hmajor σ adjoint z a ρ hρ)
    (fun g=>(pathGeometry_measurable value μ U V d₀ Y L exponents η ψ major σ adjoint z a).mul_const (ρ g))
    (fun j hj hout p q hp hq g=>pathKernel_constant S value μ R Q hQ hv d₀ Y L exponents hY
      n j hj U V hUp hVp η ψ major σ hout adjoint z hz a ρ p q hp hq g)
  simpa only [integerPositionBox_card] using h

end Elliptic.Operator.RootLiteralTransfer
