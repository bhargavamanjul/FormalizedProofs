module

public import Elliptic.Operator.RootPhysicalTransfer
public import Elliptic.Operator.RootVariableSum
public import Elliptic.Operator.RootGridMeasure

/-!
# Transfer of an actual root-dependent kernel to a Lebesgue integral

The discrete sum is partitioned exactly into half-open cells. On cells
outside the explicit boundary cover its kernel is constant in the root.
The discarded cells are charged twice: once by their actual integer-root
mass, once by their actual Lebesgue volume. The intermediate step-function
transfer is the accepted root-count contract, with one uniform threshold.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootArchimedeanTransfer
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootArchimedeanGrid RootGridPartition RootGridTransfer RootGridMeasure
open RootVariableSum RootBoundaryCover RootPhysicalTransfer
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

abbrev RootPoint := ℝ × ℝ × ℝ

theorem integral_constant_on_part (n : ℕ) (j : Index)
    (F : RootPoint→ℂ) (c : ℂ) (h : ∀ q∈partSet n j, F q=c) :
    (∫ q in partSet n j, F q)=(cellVolume n j:ℂ)*c := by
  rw [setIntegral_congr_fun (partSet_measurable n j) h,integral_const]
  simp only [Measure.real,Measure.restrict_apply_univ,partSet_volume,
    ENNReal.toReal_ofReal (by positivity : 0≤15/(n:ℝ)^3),Complex.real_smul,cellVolume_eq]

/-- Exact analytic cost of deleting the same half-open boundary cells
used by the integer-root sum. -/
theorem boundary_integral_error (n : ℕ) (hn : 0<n) (bad : Finset Index)
    (hbad : bad⊆grid n) (F : RootPoint→ℂ) (f : Index→ℂ)
    (hF : ∀ q, ‖F q‖≤1) (hInt : IntegrableOn F rootBox)
    (hstable : ∀ j∈grid n, j∉bad → ∀ q∈partSet n j, F q=f j) :
    ‖(∫ q in rootBox, F q) -
      ∑ j∈grid n, (cellVolume n j:ℂ)*(if j∈bad then 0 else f j)‖ ≤
        coverVolume n bad := by
  rw [integral_partition n hn F hInt,←Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ j∈grid n, ‖(∫ q in partSet n j, F q) -
        (cellVolume n j:ℂ)*(if j∈bad then 0 else f j)‖ := norm_sum_le _ _
    _ ≤ ∑ j∈grid n, if j∈bad then cellVolume n j else 0 := by
      apply Finset.sum_le_sum
      intro j hj
      by_cases hb : j∈bad
      · simp only [ite_eq_left hb,mul_zero,sub_zero]
        exact (norm_integral_partSet_le n j F (fun q _ => hF q)).trans_eq
          (cellVolume_eq n j).symm
      · simp only [ite_eq_right hb,integral_constant_on_part n j F (f j) (hstable j hj hb),
          sub_self,norm_zero,le_refl]
    _ = _ := by
      rw [←Finset.sum_filter]
      apply Finset.sum_congr
      · ext j
        simp only [Finset.mem_filter]
        exact ⟨fun h=>h.2,fun h=>⟨hbad h,h⟩⟩
      · intro j hj
        rfl

def averageKernel (S : ℕ) [Fintype (ZMod S)]
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) (q : RootPoint) : ℂ :=
  (∑ g, F q g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ)

def rootIntegral (U V : ℝ) (S : ℕ) [Fintype (ZMod S)]
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) : ℂ :=
  ((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫ q in rootBox, averageKernel S F q)

theorem averageKernel_norm_le (S : ℕ) [Fintype (ZMod S)]
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀ q g, ‖F q g‖≤1) (q : RootPoint) : ‖averageKernel S F q‖≤1 :=
  bounded_average_norm (F q) (hF q)

theorem part_rootVolume (U V : ℝ) (n : ℕ) (j : Index) :
    rootVolume U V (partCell 1 16 n j.1) (partCell 1 2 n j.2.1)
      (partCell 0 1 n j.2.2)=(U*V/(Real.pi^2/6))*cellVolume n j := by
  dsimp [rootVolume,partCell,cellVolume,RootInterval.length,cell]
  ring

theorem average_offBoundary (S : ℕ) [Fintype (ZMod S)]
    (bad : Finset Index) (f : Index→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (j : Index) :
    (∑g,offBoundaryTest S bad f j g)/
      (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ)=
        if j∈bad then 0 else (∑g,f j g)/
          (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ) := by
  by_cases hj : j∈bad <;> simp [offBoundaryTest,hj]

theorem averageKernel_integrable (S : ℕ) [Fintype (ZMod S)]
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀g, IntegrableOn (fun q=>F q g) rootBox) :
    IntegrableOn (averageKernel S F) rootBox := by
  exact (integrable_finsetSum _ (fun g _ => hF g)).div_const _

theorem boundary_average_integral_error (n : ℕ) (hn : 0<n)
    (bad : Finset Index) (hbad : bad⊆grid n) (U V : ℝ) (hU : 0≤U) (hV : 0≤V)
    (S : ℕ) [Fintype (ZMod S)]
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (f : Index→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (hF : ∀ q g, ‖F q g‖≤1)
    (hInt : IntegrableOn (averageKernel S F) rootBox)
    (hstable : ∀ j∈grid n, j∉bad → ∀ q, PartContains n j q → ∀ g, F q g=f j g) :
    ‖rootIntegral U V S F -
      ∑ j∈grid n, (rootVolume U V (partCell 1 16 n j.1)
        (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2):ℂ)*
          ((∑g,offBoundaryTest S bad f j g)/
            (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ))‖ ≤
      (U*V/(Real.pi^2/6))*coverVolume n bad := by
  have h := boundary_integral_error n hn bad hbad (averageKernel S F)
    (fun j => (∑g,f j g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ))
    (averageKernel_norm_le S F hF) hInt ?_
  · unfold rootIntegral
    simp only [part_rootVolume,Complex.ofReal_mul,average_offBoundary,mul_assoc,
      ←Finset.mul_sum,←mul_sub]
    rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (by positivity)]
    exact mul_le_mul_of_nonneg_left h (by positivity)
  · intro j hj hb q hq
    unfold averageKernel
    congr 1
    exact Finset.sum_congr rfl (fun g _ => hstable j hj hb q hq g)

/-- A root-dependent kernel with a specified finite boundary cover is
transferred to its actual Lebesgue integral. The factor two pays for
both the discrete boundary mass and its archimedean counterpart. -/
theorem eventually_variable_root_transfer (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ) (bad : Finset Index),
      0<n → bad⊆grid n → (n:ℝ)^3≤x^(δ/2000) →
      ∀ U V B : ℝ, ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → coverVolume n bad≤B →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ,
      ∀ f : Index→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ,
      (∀ q g, ‖F q g‖≤1) → (∀ j∈grid n, ∀ g, ‖f j g‖≤1) →
      IntegrableOn (averageKernel S F) rootBox →
      (∀ j∈grid n, j∉bad → ∀ q, PartContains n j q → ∀ g, F q g=f j g) →
      ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2)
          (fullInterval 0 1) F - rootIntegral U V S F‖ ≤
        2*(U*V/(Real.pi^2/6))*B + 2*(U*V*x^(-(δ/4000))) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    eventually_partition_grid_transfer hPD δ C_S hδ hCS,
    eventually_cover_root_mass hPD δ C_S hδ hCS] with x hx ht hm
  intro n bad hn hbad hn' U V B S inst hU hU' hV hV' hvol hS hSq hSize F f hF hf hInt hs
  have hUp : 0≤U := (Real.rpow_pos_of_pos hx δ).le.trans hU
  have hVp : 0≤V := (Real.rpow_pos_of_pos hx δ).le.trans hV
  have hstep := ht n (grid n) (Finset.Subset.refl _) hn' U V (fun _=>S)
    hU hU' hV hV' (fun _ _=>⟨hS,hSq,hSize⟩) (offBoundaryTest S bad f) ?_
  · have hmass := hm n bad hbad hn' U V B (fun _=>S) hU hU' hV hV' hvol
      (fun _ _=>⟨hS,hSq,hSize⟩) (fun _ _=>1) (by intros; norm_num)
    have hdiscrete := (boundary_root_error n hn bad hbad U V S F f hF hs).trans hmass
    have harch := (boundary_average_integral_error n hn bad hbad U V hUp hVp S F f hF hInt hs).trans
      (mul_le_mul_of_nonneg_left hvol (by positivity))
    have htri := norm_sub_le_norm_sub_add_norm_sub (variableRootSum U V S (fullInterval 1 16)
      (fullInterval 1 2) (fullInterval 0 1) F)
      (∑j∈grid n, weightedRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2)
          (offBoundaryTest S bad f j))
      (rootIntegral U V S F)
    have htri' := norm_sub_le_norm_sub_add_norm_sub
      (∑j∈grid n, weightedRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2)
          (offBoundaryTest S bad f j))
      (∑j∈grid n, (rootVolume U V (partCell 1 16 n j.1)
        (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2):ℂ)*
          ((∑g,offBoundaryTest S bad f j g)/
            (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ)))
      (rootIntegral U V S F)
    rw [norm_sub_rev (rootIntegral U V S F)] at harch
    linarith
  · intro j hj g
    unfold offBoundaryTest
    split_ifs
    · norm_num
    · exact hf j hj g

def representative (n : ℕ) (j : Index) : RootPoint :=
  ((cell 1 16 n j.1).lower,(cell 1 2 n j.2.1).lower,(cell 0 1 n j.2.2).lower)

theorem partCell_contains_lower (a b : ℝ) (hab : a<b) (n : ℕ) (hn : 0<n) (i : ℕ) :
    (partCell a b n i).Contains (cell a b n i).lower := by
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  have hw : (cell a b n i).lower < (cell a b n i).upper := by
    have hp : 0<(b-a)/(n:ℝ) := by positivity
    have he : (cell a b n i).upper-(cell a b n i).lower=(b-a)/(n:ℝ) := by
      dsimp [cell]
      ring
    linarith
  refine ⟨le_refl _,?_⟩
  by_cases hi : i+1=n
  · simpa [partCell,RootInterval.Contains,hi] using hw.le
  · simpa [partCell,RootInterval.Contains,hi] using hw

theorem representative_mem (n : ℕ) (hn : 0<n) (j : Index) :
    PartContains n j (representative n j) :=
  ⟨partCell_contains_lower 1 16 (by norm_num) n hn j.1,
    partCell_contains_lower 1 2 (by norm_num) n hn j.2.1,
    partCell_contains_lower 0 1 (by norm_num) n hn j.2.2⟩

theorem rootBox_volume : volume rootBox=15 := by
  have he : rootBox=(Set.Icc (1:ℝ) 16) ×ˢ (Set.Icc (1:ℝ) 2 ×ˢ Set.Icc (0:ℝ) 1) := by
    ext q
    change (1≤q.1 ∧ q.1≤16 ∧ 1≤q.2.1 ∧ q.2.1≤2 ∧ 0≤q.2.2 ∧ q.2.2≤1) ↔
      ((1≤q.1 ∧ q.1≤16) ∧ (1≤q.2.1 ∧ q.2.1≤2) ∧ (0≤q.2.2 ∧ q.2.2≤1))
    tauto
  rw [he,Measure.volume_eq_prod,Measure.prod_prod,Measure.volume_eq_prod,Measure.prod_prod]
  norm_num

theorem bounded_measurable_integrable (F : RootPoint→ℂ) (hF : Measurable F)
    (hbound : ∀q, ‖F q‖≤1) : IntegrableOn F rootBox :=
  Measure.integrableOn_of_bounded (by rw [rootBox_volume]; norm_num)
    hF.aestronglyMeasurable (Filter.Eventually.of_forall hbound)

/-- The full transfer with the literal physical-face/scalar-endpoint
cover and actual Lebesgue integral. No boundary size, cell values or
integrability is left as an independent assumption. The subdivision
count still satisfies the explicit admissibility inequality. -/
theorem eventually_physical_root_transfer (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ), 0<n → (n:ℝ)^3≤x^(δ/2000) →
      ∀ positions : Finset (ℤ × ℤ), ∀ ends : Finset ℝ, ∀ U V R : ℝ,
      ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V →
      (∀z∈positions, |(z.2:ℝ)|≤R) →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ,
      (∀q g, ‖F q g‖≤1) → (∀g, Measurable (fun q=>F q g)) →
      (∀j∈grid n, j∉combinedFaces n positions U V ends →
        ∀p q, Contains n j p → Contains n j q → ∀g, F p g=F q g) →
      ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2)
          (fullInterval 0 1) F - rootIntegral U V S F‖ ≤
        2*(U*V/(Real.pi^2/6))*
          (((positions.card:ℝ)*(16864*R+120)+30*(ends.card:ℝ))/(n:ℝ)) +
            2*(U*V*x^(-(δ/4000))) := by
  filter_upwards [eventually_variable_root_transfer hPD δ C_S hδ hCS] with x ht
  intro n hn hn' positions ends U V R S inst hU hU' hV hV' hUV hR hS hSq hSize F hF hMeas hs
  apply ht n (combinedFaces n positions U V ends) hn
    (combinedFaces_subset_grid n positions U V ends) hn' U V _ S
    hU hU' hV hV' (combinedFaces_volume n hn positions U V R ends hUV hR)
    hS hSq hSize F (fun j g=>F (representative n j) g) hF
    (fun j _ g=>hF _ g)
    (averageKernel_integrable S F (fun g=>bounded_measurable_integrable _ (hMeas g) (fun q=>hF q g)))
  intro j hj hb q hq g
  exact hs j hj hb q (representative n j) (part_subset_closed n j q hq)
    (part_subset_closed n j _ (representative_mem n hn j)) g

end Elliptic.Operator.RootArchimedeanTransfer
