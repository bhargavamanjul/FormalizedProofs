module

public import Elliptic.Operator.OriginalIndependentChoices

/-!
# Global independent-line expectation and the actual finite boundary sum

The original finite path sum is identified with the complete chronological
boundary pairing after multiplication by the exact extracted baseline.
Every prime's optional interval is reindexed, all endpoint permutations and
all normalizing powers are retained, and the memory cutoff is explicit.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalBoundaryAssembly SourceHistoryCoefficient
open IndependentLineNormalization OriginalIntervalAverage
attribute [local instance] Classical.propDecidable
local instance independentBoundaryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace OriginalPath

/-- Complete original path coefficient outside its independent line factors. -/
def boundaryFactor
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (V : I → ℝ) (a b : BoundaryIndex I Z P J → ℂ) (r : OriginalPath I Z P J N) : ℂ :=
  conj (a (r.positionAt 0,r.activeAt 0)) * (pathNormalization V J N : ℂ) *
    (∏ j∈Finset.range N, geometry j (r.positionAt j) (r.sourceLists j)
      (r.positionAt (j+1)) (r.targetLists j)) * b (r.positionAt N,r.activeAt N)

/-- The actual independent product of the one-prime uniform line averages. -/
def independentAverage [∀ i p,Fintype (Line i p)]
    (anchor : Z → ∀ i p, Line i p) (η : ℕ → ℝ) (r : OriginalPath I Z P J N) : ℝ :=
  ∏ i, ∏ p, lineAverage (Finset.range (N+1)) (r.activeVisits i p)
    (fun j=>anchor (r.positionAt j) i p) η

end OriginalPath

namespace OriginalLeaf
variable (value : ∀ i,P i→ℕ)

/-- Equality of the original leaf's entire path coefficient, including both
endpoint vectors, with the complete independent choice weight. -/
theorem boundaryFactor_primeChoices
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (μ : ∀ i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ)
    (a b : BoundaryIndex I Z P J → ℂ) (e : SourceLeaves anchor value J B N) :
    conj (a (keyInitial (sourceKey value e))) *
        primewiseCoefficient anchor geometry μ V η (fun j=>1-η j)
          (e.val.toSchedule anchor e.property.valid) * b (keyFinal (sourceKey value e)) =
      e.val.toOriginalPath.boundaryFactor geometry V a b *
        (e.val.toOriginalPath.choicesWeight anchor η μ (e.val.primeChoices e.property.valid) : ℂ) := by
  let d := e.val.toSchedule anchor e.property.valid
  have hsource (j : ℕ) (hj : j<N) : d.sourceLists j=e.val.sourceLists j := by
    have h := ofSchedule_sourceLists d j hj
    rw [ofSchedule_toSchedule] at h
    exact h.symm
  have htarget (j : ℕ) (hj : j<N) : d.targetLists j=e.val.targetLists j := by
    have h := ofSchedule_targetLists d j hj
    rw [ofSchedule_toSchedule] at h
    exact h.symm
  have hban : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j) := by
    intro j hj
    rw [hsource j hj,htarget j hj]
    exact e.property.crossEdgeBan j hj
  have hgeo : (∏ j∈Finset.range N, geometry j (d.position j) (d.sourceLists j)
      (d.position (j+1)) (d.targetLists j)) =
      ∏ j∈Finset.range N, geometry j (e.val.positionAt j) (e.val.sourceLists j)
        (e.val.positionAt (j+1)) (e.val.targetLists j) := by
    apply Finset.prod_congr rfl
    intro j hj
    rw [hsource j (Finset.mem_range.mp hj),htarget j (Finset.mem_range.mp hj)]
    rfl
  have hi : keyInitial (sourceKey value e)=(e.val.positionAt 0,e.val.activeAt 0) := rfl
  have hf : keyFinal (sourceKey value e)=(e.val.positionAt N,e.val.activeAt N) := by
    simp only [keyFinal,sourceKey,key,toSchedule,canonicalKey]
    rfl
  change conj (a (keyInitial (sourceKey value e))) *
      primewiseCoefficient anchor geometry μ V η (fun j=>1-η j) d * b (keyFinal (sourceKey value e)) = _
  rw [primewiseCoefficient_eq_pathNormalization d value hban,hgeo,hi,hf,
    primeChoices_weight]
  unfold OriginalPath.boundaryFactor
  dsimp only [d,toSchedule]
  ring

/-- The full actual boundary pairing equals the complete independent
optional-interval sum over original source paths. All finite birth and
memory bookkeeping has been discharged. -/
theorem boundaryPairing_eq_all_independent_choices
    (ν μ : ∀ i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z c w d,geometry j z c w d≠0 → ∀ i (k : Fin J),
      anchor z i (c i k.castSucc)=anchor w i (c i k.castSucc))
    (hban : ∀ j z c w d,geometry j z c w d≠0 → sourceCrossEdgeBan value c d)
    (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hν : ∀ i p,V i*ν i p=μ i p)
    (hB : (∑ i,Fintype.card (P i))≤B)
    (a b : BoundaryIndex I Z P J → ℂ) :
    boundaryPairing (B:=B) ν V η (fun j=>1-η j) ρ anchor geometry value N a b =
      ∑ r : OriginalPath.SourcePaths (Z:=Z) value J N,
        r.val.boundaryFactor geometry V a b *
          ∑ C : r.val.PrimeChoices,(r.val.choicesWeight anchor η μ C : ℂ) := by
  rw [boundaryPairing_eq_originalLeaf_coefficients value ν V η (fun j=>1-η j) ρ geometry
    hvalue hshared hban μ hρ hV hν]
  simp_rw [boundaryFactor_primeChoices value geometry μ V η a b]
  exact sourceLeaves_weighted_sum value η μ hB (OriginalPath.boundaryFactor geometry V a b)

end OriginalLeaf

/-- Exact global independent-line / boundary identification. The scalar
baseline and all normalizing powers are literal source quantities. The large
cutoff hypothesis is stated explicitly; a smaller cutoff needs a tail bound. -/
theorem independent_path_sum_eq_baseline_boundary [∀ i p,Fintype (Line i p)]
    (value : ∀ i,P i→ℕ) (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z c w d,geometry j z c w d≠0 → ∀ i (k : Fin J),
      anchor z i (c i k.castSucc)=anchor w i (c i k.castSucc))
    (hban : ∀ j z c w d,geometry j z c w d≠0 → sourceCrossEdgeBan value c d)
    (hρ : ρ≠0) (hV : ∀ i,V i≠0)
    (hn : ∀ i p,(Fintype.card (Line i p) : ℝ)≠0)
    (hbase : ∀ i p,(Fintype.card (Line i p) : ℝ)-∑j∈Finset.range (N+1),η j≠0)
    (hν : ∀ i p,V i*ν i p=normalizedLineMass (Finset.range (N+1)) η (Fintype.card (Line i p)))
    (hB : (∑ i,Fintype.card (P i))≤B)
    (a b : BoundaryIndex I Z P J → ℂ) :
    (∑ r : OriginalPath.SourcePaths (Z:=Z) value J N,
      r.val.boundaryFactor geometry V a b * (r.val.independentAverage anchor η : ℂ)) =
      ((∏ i, ∏ p,baseline (Finset.range (N+1)) η (Fintype.card (Line i p)) : ℝ) : ℂ) *
        boundaryPairing (B:=B) ν V η (fun j=>1-η j) ρ anchor geometry value N a b := by
  rw [OriginalLeaf.boundaryPairing_eq_all_independent_choices value ν _ V η ρ geometry
    hvalue hshared hban hρ hV hν hB]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  rw [OriginalPath.independentAverage,OriginalPath.independent_average_eq_choices r.val η hn hbase]
  simp only [Complex.ofReal_mul,Complex.ofReal_sum]
  ring

end Elliptic.Operator.OriginalLifespanSchedule
