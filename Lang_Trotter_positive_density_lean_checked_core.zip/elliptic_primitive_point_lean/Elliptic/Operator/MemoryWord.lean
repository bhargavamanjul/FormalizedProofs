module

public import Elliptic.Operator.MemoryTransitions
public import Elliptic.Operator.KernelComposition
public import Mathlib.Data.Fintype.Sigma
public import Mathlib.Data.Fintype.BigOperators

/-!
# Literal operation-choice histories

A history below is a dependent sequence of actual valid choices: its next
choice type is evaluated at the state produced by the preceding choice.
The exact expansion is proved by finite distributivity.  It applies to the
concrete ghost operation, and subsequently to the store/promote edge
operation.  It is not an assumed identification with primewise lifespans;
that separate combinatorial identification is still required.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
universe u v

/-- A literal finite operation, before choices with equal output are collected. -/
structure ChoiceOperation (X : Type u) where
  Choice : X → Type v
  finiteChoice : ∀ x, Fintype (Choice x)
  valid : (x : X) → Choice x → Prop
  output : (x : X) → (c : Choice x) → valid x c → X
  coefficient : (x : X) → Choice x → ℂ
  ghostBirths : (x : X) → Choice x → ℕ := fun _ _ => 0
  stores : (x : X) → Choice x → ℕ := fun _ _ => 0

attribute [instance] ChoiceOperation.finiteChoice

namespace ChoiceOperation
variable {X : Type u}

abbrev ValidChoice (O : ChoiceOperation X) (x : X) :=
  {c : O.Choice x // O.valid x c}

def apply (O : ChoiceOperation X) (F : X → ℂ) (x : X) : ℂ :=
  ∑ c : O.ValidChoice x, O.coefficient x c.val * F (O.output x c.val c.property)

/-- The same operation with its validity condition inside the finite sum. -/
theorem apply_eq_all_choices (O : ChoiceOperation X) (F : X → ℂ) (x : X) :
    O.apply F x = ∑ c : O.Choice x, if hc : O.valid x c then
      O.coefficient x c * F (O.output x c hc) else 0 := by
  symm
  unfold apply
  rw [Finset.sum_dite]
  simp only [Finset.sum_const_zero, add_zero]
  exact (Equiv.subtypeEquivRight (by simp)).sum_comp
    (fun c : O.ValidChoice x => O.coefficient x c.val * F (O.output x c.val c.property))

/-- Actual choices are dependent on the preceding output state. -/
def History : List (ChoiceOperation.{u,v} X) → X → Type v
  | [], _ => PUnit
  | O :: ops, x => Σ c : O.ValidChoice x, History ops (O.output x c.val c.property)

instance historyNilUnique (x : X) : Unique (History ([] : List (ChoiceOperation.{u,v} X)) x) :=
  inferInstanceAs (Unique PUnit)

instance historyFintype (ops : List (ChoiceOperation X)) (x : X) : Fintype (History ops x) := by
  induction ops generalizing x with
  | nil => exact inferInstanceAs (Fintype PUnit)
  | cons O ops ih =>
      letI := fun y => ih y
      exact inferInstanceAs (Fintype (Σ c : O.ValidChoice x,
        History ops (O.output x c.val c.property)))

def History.final : {ops : List (ChoiceOperation X)} → {x : X} → History ops x → X
  | [], x, _ => x
  | _ :: _, _, h => h.2.final

def History.weight : {ops : List (ChoiceOperation X)} → {x : X} → History ops x → ℂ
  | [], _, _ => 1
  | O :: _, x, h => O.coefficient x h.1.val * h.2.weight

def History.ghostBirths : {ops : List (ChoiceOperation X)} → {x : X} → History ops x → ℕ
  | [], _, _ => 0
  | O :: _, x, h => O.ghostBirths x h.1.val + h.2.ghostBirths

def History.stores : {ops : List (ChoiceOperation X)} → {x : X} → History ops x → ℕ
  | [], _, _ => 0
  | O :: _, x, h => O.stores x h.1.val + h.2.stores

def History.peakSize (size : X → ℕ) :
    {ops : List (ChoiceOperation X)} → {x : X} → History ops x → ℕ
  | [], x, _ => size x
  | _ :: _, x, h => max (size x) (h.2.peakSize size)

/-- Size accounting for literal dependent choices, before any weights
are estimated. Its one-step premise is supplied by actual output formulas. -/
theorem History.peakSize_le (size : X → ℕ) (ops : List (ChoiceOperation X))
    (hstep : ∀ O ∈ ops, ∀ x (c : O.ValidChoice x),
      size (O.output x c.val c.property) ≤ size x + O.ghostBirths x c.val + O.stores x c.val)
    (x : X) (h : History ops x) :
    h.peakSize size ≤ size x + h.ghostBirths + h.stores := by
  induction ops generalizing x with
  | nil => simp [History.peakSize, History.ghostBirths, History.stores]
  | cons O ops ih =>
      have hnow := hstep O (by simp) x h.1
      have htail := ih (fun O hO => hstep O (by simp [hO])) _ h.2
      simp only [History.peakSize, History.ghostBirths, History.stores]
      omega

/-- Exceeding the cutoff forces actual ghost births after paying for all
stores. No truncation error estimate is assumed. -/
theorem History.ghostBirths_large_of_peak (size : X → ℕ)
    (ops : List (ChoiceOperation X))
    (hstep : ∀ O ∈ ops, ∀ x (c : O.ValidChoice x),
      size (O.output x c.val c.property) ≤ size x + O.ghostBirths x c.val + O.stores x c.val)
    (x : X) (h : History ops x) (B S : ℕ)
    (hzero : size x=0) (hstores : h.stores≤S) (hSB : S≤B) (hpeak : B<h.peakSize size) :
    B-S < h.ghostBirths := by
  have hp := History.peakSize_le size ops hstep x h
  omega

def wordApply : List (ChoiceOperation X) → (X → ℂ) → X → ℂ
  | [], F => F
  | O :: ops, F => O.apply (wordApply ops F)

/-- Exact chronological expansion, including all repeated output multiplicities. -/
theorem wordApply_eq_history_sum (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X) :
    wordApply ops F x = ∑ h : History ops x, h.weight * F h.final := by
  induction ops generalizing x with
  | nil =>
      simp only [wordApply, History.weight, History.final, one_mul,
        Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      rw [Fintype.card_unique]
      simp
  | cons O ops ih =>
      change (∑ c : O.ValidChoice x,
        O.coefficient x c.val * wordApply ops F (O.output x c.val c.property)) =
        ∑ h : (Σ c : O.ValidChoice x, History ops (O.output x c.val c.property)),
          O.coefficient x h.1.val * h.2.weight * F h.2.final
      rw [Fintype.sum_sigma]
      apply Finset.sum_congr rfl
      intro c hc
      rw [ih, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro h hh
      simp [History.weight, History.final, mul_assoc]

/-- Exact boundary pairing with a literal initial mass and initial vector. -/
theorem boundary_eq_history_sum [Fintype X] (ops : List (ChoiceOperation X))
    (μ : X → ℝ) (a b : X → ℂ) :
    (∑ x : X, (μ x : ℂ)*a x*wordApply ops b x) =
      ∑ x : X, ∑ h : History ops x, (μ x : ℂ)*a x*h.weight*b h.final := by
  simp_rw [wordApply_eq_history_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x hx
  apply Finset.sum_congr rfl
  intro h hh
  ring

end ChoiceOperation

/-- The concrete ghost operation, with its actual indexed choice and coefficient. -/
def ghostChoiceOperation {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p) :
    ChoiceOperation (MemoryState (AnchoredParticle P Line) B) where
  Choice m := GhostChoice m
  finiteChoice _ := inferInstance
  valid := GhostChoice.Valid anchor
  output := ghostOutput anchor
  coefficient m c := (ghostChoiceWeight ν V η q ρ anchor m c : ℝ)
  ghostBirths _ c := c.2.size

/-- The generic action is exactly the existing concrete ghost choice sum. -/
theorem ghostChoiceOperation_apply {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (V η q ρ : ℝ)
    (anchor : ∀ p, Line p)
    (F : MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    (ghostChoiceOperation ν V η q ρ anchor).apply F m =
      ghostApply ν V η q ρ anchor F m := by
  rw [ChoiceOperation.apply_eq_all_choices]
  rfl

end Elliptic.Operator
