module

public import Elliptic.Operator.ActualBirthHighRank
public import Elliptic.Operator.BirthRankCounting
public import Elliptic.Operator.MomentBounds

/-! Explicit uniform constants for the actual physical high-rank term. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualBirthHighRank
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthRegistry
attribute [local instance] Classical.propDecidable
local instance highRankUniformDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I Z:Type} [Fintype I] [Fintype Z]
variable {P:I→Type} [∀i,Fintype (P i)] {Line:∀i,P i→Type} {J B N:ℕ}
local instance (priority := 100000) highRankUniformAddressDecEq :
    DecidableEq (ActualHistoryBirths.Address I J B N) := Classical.typeDecidableEq _

/-- A fixed per-prescribed-birth factor is separated from the ordinary
exponential ghost factor before summing over ranks. -/
theorem prescribed_ghostFactor_le (ν:∀i,P i→ℝ) (V:I→ℝ) (η ρ v0 D s:ℝ)
    (plan:PivotPlan I J B) (j:ℕ)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:0≤η) (hρ:0<ρ) (hv:0≤v0)
    (hD:0≤D) (hs:∀i,(∑p,ν i p)≤s)
    (hbase:∀i,(η*V i/ρ)*v0≤D):
    PhysicalBirthRegistry.ghostFactor ν V η ρ v0 plan j ≤
      D^(∑i,(plan.ghostSlots j i).card)*(Real.exp (D*s))^(Fintype.card I):=by
  unfold PhysicalBirthRegistry.ghostFactor
  calc
    _ ≤ ∏i,D^(plan.ghostSlots j i).card*Real.exp (D*s):=by
      apply Finset.prod_le_prod₀
      · intro i _
        exact mul_nonneg (pow_nonneg (mul_nonneg (div_nonneg (mul_nonneg hη (hV i)) hρ.le) hv) _) (Real.exp_pos _).le
      · intro i _
        apply mul_le_mul
        · exact pow_le_pow_left₀ (mul_nonneg (div_nonneg (mul_nonneg hη (hV i)) hρ.le) hv) (hbase i) _
        · apply Real.exp_le_exp.mpr
          exact mul_le_mul (hbase i) (hs i) (Finset.sum_nonneg (fun p _=>hν i p)) hD
        · exact (Real.exp_pos _).le
        · exact pow_nonneg hD _
    _ = _:=by
      rw [Finset.prod_mul_distrib,←Finset.prod_pow_eq_pow_sum]
      simp

def edgeBudget (K B:ℕ) (G v0 vmin s:ℝ):ℝ:=
  G*((1+v0)*max 1 ((B:ℝ)*vmin⁻¹/v0+s))^K

theorem prescribed_edgeFactor_le (ν:∀i,P i→ℝ) (V:I→ℝ) (v0 vmin G s:ℝ)
    (hv:0<v0) (hmin:0<vmin) (hV:∀i,vmin≤V i) (hG:0≤G)
    (hs:∀i,(∑p,ν i p)≤s):
    PhysicalBirthRegistry.edgeFactor ν V v0 G B≤edgeBudget (Fintype.card I) B G v0 vmin s:=by
  unfold PhysicalBirthRegistry.edgeFactor edgeBudget
  apply mul_le_mul_of_nonneg_left ?_ hG
  calc
    _ ≤ ∏_i:I,(1+v0)*max 1 ((B:ℝ)*vmin⁻¹/v0+s):=by
      apply Finset.prod_le_prod₀
      · intro i _
        exact mul_nonneg (by linarith) (le_trans (by norm_num) (le_max_left _ _))
      · intro i _
        apply mul_le_mul_of_nonneg_left ?_ (by linarith)
        apply max_le_max le_rfl
        exact add_le_add
          (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (inv_anti₀ hmin (hV i)) (Nat.cast_nonneg _)) hv.le)
          (hs i)
    _ = _:=by simp

/-- All dependence on the causal plan is confined to D raised to its
exact named-coordinate count. -/
theorem wordFactor_le_uniform
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η:ℕ→ℝ) (ρ v0 D s G vmin:ℝ)
    (plan:PivotPlan I J B)
    (hν:∀i p,0≤ν i p) (hη:∀j,0≤η j) (hρ:0<ρ) (hv:0<v0)
    (hD:1≤D) (hmin:0<vmin) (hV:∀i,vmin≤V i) (hG:0≤G)
    (hs:∀i,(∑p,ν i p)≤s) (hbase:∀j i,(η j*V i/ρ)*v0≤D) (n j:ℕ):
    plan.wordFactor ν V η ρ v0 (fun _=>G) j n ≤
      ((Real.exp (D*s))^(Fintype.card I)*max 1 (edgeBudget (Fintype.card I) B G v0 vmin s))^(n+1)*
        D^(plan.futureCount j n):=by
  let Cg:=(Real.exp (D*s))^(Fintype.card I)
  let Ce:=max 1 (edgeBudget (Fintype.card I) B G v0 vmin s)
  have hCg:0≤Cg:=by dsimp [Cg];positivity
  have hCe:1≤Ce:=le_max_left _ _
  have hC:0≤Cg*Ce:=mul_nonneg hCg (by linarith)
  have hV0:∀i,0≤V i:=fun i=>hmin.le.trans (hV i)
  have hg j:PhysicalBirthRegistry.ghostFactor ν V (η j) ρ v0 plan j≤
      Cg*D^(∑i,(plan.ghostSlots j i).card):=by
    simpa only [Cg,mul_comm] using prescribed_ghostFactor_le ν V (η j) ρ v0 D s plan j
      hν hV0 (hη j) hρ hv.le (by linarith) hs (hbase j)
  have he:PhysicalBirthRegistry.edgeFactor ν V v0 G B≤Ce:=
    (prescribed_edgeFactor_le ν V v0 vmin G s hv hmin hV hG hs).trans (le_max_right _ _)
  change _≤(Cg*Ce)^(n+1)*D^(plan.futureCount j n)
  induction n generalizing j with
  | zero=>
    simp only [PivotPlan.wordFactor,PivotPlan.futureCount,Nat.zero_add,pow_one]
    exact (hg j).trans (mul_le_mul_of_nonneg_right
      (by nlinarith : Cg≤Cg*Ce) (pow_nonneg (by linarith) _))
  | succ n ih=>
    rw [PivotPlan.wordFactor,PivotPlan.futureCount]
    have htail:0≤plan.wordFactor ν V η ρ v0 (fun _=>G) (j+1) n:=
      wordFactor_nonneg ν V η ρ v0 (fun _=>G) plan hV0 hη hρ.le hv.le (fun _=>hG) _ _
    have hstep:=mul_le_mul (hg j)
      (mul_le_mul he (ih (j+1)) htail (by linarith : 0≤Ce))
      (mul_nonneg (by unfold PhysicalBirthRegistry.edgeFactor;positivity) htail)
      (mul_nonneg hCg (pow_nonneg (by linarith) _))
    refine hstep.trans ?_
    calc
      _ = (Cg*Ce)^(n+1+1)*D^((∑i,(plan.ghostSlots j i).card)+plan.futureCount (j+1) n):=by
        rw [pow_succ,pow_add]
        ring
      _ ≤ _:=mul_le_mul_of_nonneg_left (pow_le_pow_right₀ hD (by omega)) (pow_nonneg hC _)


theorem initial_remaining_mass_le (ν:∀i,P i→ℝ) (slots:I→Finset ℕ) (s:ℝ)
    (hν:∀i p,0≤ν i p) (hs:∀i,(∑p,ν i p)≤s) (hs1:1≤s):
    (∏i,(∑p,ν i p)^((J+1)-(slots i).card))≤s^(Fintype.card I*(J+1)):=by
  calc
    _ ≤ ∏_i:I,s^(J+1):=by
      apply Finset.prod_le_prod₀
      · intro i _
        exact pow_nonneg (Finset.sum_nonneg (fun p _=>hν i p)) _
      · intro i _
        exact (pow_le_pow_left₀ (Finset.sum_nonneg (fun p _=>hν i p)) (hs i) _).trans
          (pow_le_pow_right₀ hs1 (Nat.sub_le _ _))
    _ = _:=by simp only [Finset.prod_const,Finset.card_univ,←pow_mul];rw [Nat.mul_comm]

/-- Every actual signed permutation term, including impossible cross-band
permutations, has one uniform atom factor per exact cycle rank. -/
theorem term_norm_le_uniform
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ v0 Δ D s G vmin:ℝ)
    (anchor:Z→∀i p,Line i p)
    (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value:∀i,P i→ℕ) (hinj:Function.Injective (fun p:Sigma P=>value p.1 p.2))
    (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (hν:∀i p,0≤ν i p) (hη:∀j,0≤η j) (hq:∀j,0≤q j)
    (hρ:0<ρ) (hρ1:ρ≤1) (hv:0<v0) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ)
    (hp:∀j,q j/ρ^2+η j/(ρ*v0)≤1)
    (hD:1≤D) (hmin:0<vmin) (hV:∀i,vmin≤V i) (hG:0≤G)
    (hs:∀i,(∑p,ν i p)≤s) (hs1:1≤s) (hbase:∀j i,(η j*V i/ρ)*v0≤D)
    (hgeometry:∀j z a b,(∑w:Z,‖geometry j z a w b‖)≤G)
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (hF:∀t,‖F t‖≤physicalMemorySchurWeight v0 t) (z:Z):
    ‖term ν V η q ρ anchor geometry value σ F z‖ ≤
      (((Real.exp (D*s))^(Fintype.card I)*max 1 (edgeBudget (Fintype.card I) B G v0 vmin s))^(N+1)*
        s^(Fintype.card I*(J+1)))*(D*Δ)^(birthCycleRank σ):=by
  let C:=((Real.exp (D*s))^(Fintype.card I)*max 1 (edgeBudget (Fintype.card I) B G v0 vmin s))^(N+1)
  have hC:0≤C:=by dsimp [C];positivity
  have hs0:0≤s:=by linarith
  have hD0:0≤D:=by linarith
  by_cases hg:∀a,addressGroup (σ a)=addressGroup a
  · have hi:∀i,Function.Injective (value i):=by
      intro i p q hpq
      have he:(⟨i,p⟩:Sigma P)=⟨i,q⟩:=hinj hpq
      simpa only [Sigma.mk.inj_iff,heq_eq_eq,true_and] using he
    have ht:=term_norm_le ν V η q ρ v0 Δ anchor geometry value hi σ hg (fun _=>G)
      hν (fun i=>hmin.le.trans (hV i)) hη hq hρ hρ1 hv hΔ hatom hp (fun _=>hG)
      hgeometry F hF z
    have hw:=wordFactor_le_uniform ν V η ρ v0 D s G vmin (BirthPermutationPlan.plan σ hg)
      hν hη hρ hv hD hmin hV hG hs hbase N 0
    have hc:(BirthPermutationPlan.plan σ hg).futureCount 0 N≤birthCycleRank σ:=by
      rw [←BirthPermutationPlan.total_count_eq_rank σ hg]
      omega
    have hw':(BirthPermutationPlan.plan σ hg).wordFactor ν V η ρ v0 (fun _=>G) 0 N≤
        C*D^(birthCycleRank σ):=
      hw.trans (mul_le_mul_of_nonneg_left (pow_le_pow_right₀ hD hc) hC)
    have hm:=initial_remaining_mass_le (J:=J) ν (BirthPermutationPlan.initialSlots σ) s hν hs hs1
    refine ht.trans ?_
    calc
      _ ≤ (C*D^(birthCycleRank σ))*Δ^(birthCycleRank σ)*s^(Fintype.card I*(J+1)):=by
        apply mul_le_mul
        · exact mul_le_mul_of_nonneg_right hw' (pow_nonneg hΔ (birthCycleRank σ))
        · exact hm
        · exact Finset.prod_nonneg (fun i _=>pow_nonneg (Finset.sum_nonneg (fun p _=>hν i p)) _)
        · exact mul_nonneg (mul_nonneg hC (pow_nonneg hD0 _)) (pow_nonneg hΔ _)
      _ = _:=by rw [mul_pow];ring
  · have hz:=mass_eq_zero_of_not_group ν V η q ρ anchor geometry value hinj σ hg (fun t=>‖F t‖) z
    have ht:=term_norm_le_mass ν V η q ρ anchor geometry value σ F hν z
    rw [hz] at ht
    refine ht.trans ?_
    exact mul_nonneg (mul_nonneg hC (pow_nonneg hs0 _)) (pow_nonneg (mul_nonneg hD0 hΔ) _)

end Elliptic.Operator.ActualBirthHighRank
