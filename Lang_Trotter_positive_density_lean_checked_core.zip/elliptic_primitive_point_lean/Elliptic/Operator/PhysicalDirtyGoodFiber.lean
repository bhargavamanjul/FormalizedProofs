module

public import Elliptic.Operator.PhysicalDirtyRestricted
public import Elliptic.Operator.PhysicalDirtyPartition

/-!
# The source second-test support gives the sharp actual dirty-fiber bound

The canonical key supplies the promoted pattern, old index, fresh product,
and all group modes. The phase test is only the dyadic source trial set.
The separated part is then summed over all keys with the original weights.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyGoodFiber
open scoped BigOperators
open PhysicalDirtyPartition PhysicalDirtyOuter
attribute [local instance] Classical.propDecidable
local instance goodFiberDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Exact source trial separation for the promotion pattern and fresh
product of this canonical key. -/
def Separated (d₀ β δ : ℝ) (i : Fin K) (k : Key value s i) : Prop :=
  PhaseSeparated (SourceSecondGoodState.trialProducts value
    (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
    d₀ (keyPromotedGroups value s i k) i)
    ((keyFreshProduct value s i k : ℝ) * β) δ

/-- The source's restricted trial separation bounds the actual canonical
fiber, with both endpoint permutations, all old multiplicities and damping. -/
theorem fiber_endpoint_averaged_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i : Fin K) (k : Key value s i) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ)
    (hsep : Separated value s d₀ (latticeTau r w /
      latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) δ i k)
    (hwidth : 2 * (16 / (value i
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i).values k.1).1 : ℝ)) < δ)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ fiber value position s good u v r U W d₀ σ i k,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * coefficient value s ν V ρ v0 i k / (J+1 : ℝ)^K := by
  apply PhysicalDirtyRestricted.endpoint_averaged_sum_le value position s hposition hprime ν V ρ v0
    (DirtyOuterBudget.stores i k.2.1 k.2.2.1)
    (DirtyOuterBudget.modes (s.memory P (fun i p => Option (ZMod (value i p))) J B) i k.1 k.2.2.2)
    good u v r U W d₀ σ hU hσ i k.1 (keyFreshProduct value s i k) w hzw _ δ
  · apply SourceSecondGoodState.actual_product_image_phaseSeparated value position s
      good u v r U W d₀ σ (keyPromotedGroups value s i k) i
    · intro c hc
      exact (Finset.mem_filter.mp hc).2.1
    · intro c hc
      exact promotedGroups_eq_key value s c i k (Finset.mem_filter.mp hc).2.2
    · exact hsep
  · exact hwidth
  · exact fiber_subset_rawChoices value position s good u v r U W d₀ σ i k
  · exact fiber_mode_mem value position s good u v r U W d₀ σ i k
  · exact hν
  · exact hV
  · exact hρ0
  · exact hρ1
  · exact hv0

/-- The part of the actual dirty fiber on separated fresh draws. -/
def separatedFiber (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ β : ℝ) (σ : ℤ) (δ : ∀ i, Key value s i → ℝ)
    (i : Fin K) (k : Key value s i) : Finset (PhysicalEdgeChoice s) :=
  if Separated value s d₀ β (δ i k) i k then
    fiber value position s good u v r U W d₀ σ i k else ∅

/-- The complementary part retains precisely the exceptional fresh draws. -/
def exceptionalFiber (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ β : ℝ) (σ : ℤ) (δ : ∀ i, Key value s i → ℝ)
    (i : Fin K) (k : Key value s i) : Finset (PhysicalEdgeChoice s) :=
  if Separated value s d₀ β (δ i k) i k then ∅ else
    fiber value position s good u v r U W d₀ σ i k

/-- Exact split into separated and exceptional contributions, with no
loss of raw choices or silent omission of the exceptional draws. -/
theorem sum_separated_add_exceptional
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ β : ℝ) (σ : ℤ) (δ : ∀ i, Key value s i → ℝ)
    (f : PhysicalEdgeChoice s → ℝ) :
    (∑ i, ∑ k : Key value s i,
      ∑ c ∈ separatedFiber value position s good u v r U W d₀ β σ δ i k, f c) +
    (∑ i, ∑ k : Key value s i,
      ∑ c ∈ exceptionalFiber value position s good u v r U W d₀ β σ δ i k, f c) =
      ∑ c ∈ rawDirtyChoices value position s good u v r U W d₀ σ, f c := by
  rw [← sum_fibers value position s good u v r U W d₀ σ f, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro k _
  unfold separatedFiber exceptionalFiber
  split_ifs <;> simp

/-- All separated keys together have the sharp one-cutoff-loss bound.
Separation is tested internally on the source trial support, never assumed
for the exceptional keys. -/
theorem separated_outer_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin mass : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i : Fin K) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ∀ i, Key value s i → ℝ)
    (hwidth : ∀ k : Key value s i, 2 * (16 / (value i
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i).values k.1).1 : ℝ)) < δ i k)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i)
    (hmin : 0 < vmin) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ k : Key value s i, endpointPermutationWeight (Fin K) J *
      ∑ c ∈ separatedFiber value position s good u v r U W d₀
        (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
        σ δ i k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      (33 * (B * ((1 + v0) * vmin⁻¹ / v0) *
        ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^
          Fintype.card {j : Fin K // j ≠ i})) / (J+1 : ℝ)^K := by
  have hf (k : Key value s i) :
      endpointPermutationWeight (Fin K) J *
        (∑ c ∈ separatedFiber value position s good u v r U W d₀
          (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
          σ δ i k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
        (33 * coefficient value s ν V ρ v0 i k) / (J+1 : ℝ)^K := by
    unfold separatedFiber
    split_ifs with hs
    · exact fiber_endpoint_averaged_sum_le value position s hposition hprime ν V ρ v0
        good u v r U W d₀ σ hU hσ i k w hzw (δ i k) hs (hwidth k)
        hν (fun j => (hmin.trans_le (hV j)).le) hρ0 hρ1 hv0
    · simp only [Finset.sum_empty, mul_zero]
      apply div_nonneg
      · apply mul_nonneg (by norm_num)
        exact Finset.prod_nonneg fun j _ => dirtyGroupCoefficient_nonneg
          (ν j) (V j) ρ v0 _ _ _ (hν j) (hmin.trans_le (hV j)).le hρ1 hv0.le
      · positivity
  calc
    _ ≤ ∑ k : Key value s i,
        (33 * coefficient value s ν V ρ v0 i k) / (J+1 : ℝ)^K :=
      Finset.sum_le_sum fun k _ => hf k
    _ = (33 * ∑ k : Key value s i, coefficient value s ν V ρ v0 i k) /
        (J+1 : ℝ)^K := by rw [← Finset.sum_div, ← Finset.mul_sum]
    _ ≤ _ := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact sum_coefficient_le value s ν V ρ v0 vmin mass i hν hV hmin hv0 hρ1 hmass

end Elliptic.Operator.PhysicalDirtyGoodFiber
