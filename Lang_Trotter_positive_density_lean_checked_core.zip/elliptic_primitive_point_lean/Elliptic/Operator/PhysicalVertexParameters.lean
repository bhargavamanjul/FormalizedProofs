module
public import Elliptic.Operator.PhysicalVertexDamping

/-! Fixed memory parameters for the actual endpoint/interior vertex damping. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalVertexParameters
open PhysicalVertexDamping

 theorem momentDamping_bounds (θ : ℝ) (N : ℕ) (hθ0 : 0≤θ) (hθ1 : θ≤1) :
    (∀j,0≤momentDamping θ N j) ∧ (∀j,momentDamping θ N j≤1) ∧
      (∀j,1-momentDamping θ N j≤1-θ) := by
  have hs : θ^2≤θ := by nlinarith [mul_nonneg hθ0 (sub_nonneg.mpr hθ1)]
  refine ⟨?_,?_,?_⟩ <;> intro j <;> unfold momentDamping <;> split_ifs <;> nlinarith [sq_nonneg (1-θ)]

 theorem one_sub_sqrt_bounds (q : ℝ) (hq0 : 0<q) (hq1 : q<1) :
    0<1-Real.sqrt q ∧ 1-Real.sqrt q<1 := by
  have hs0 := Real.sqrt_pos.mpr hq0
  have hs1 : Real.sqrt q<1 := by simpa only [Real.sqrt_one] using Real.sqrt_lt_sqrt hq0.le hq1
  constructor <;> linarith

 theorem exists_memory_parameter (q : ℝ) (hq0 : 0<q) (hq1 : q<1) :
    ∃ρ : ℝ,0<ρ ∧ ρ<1 ∧ Real.sqrt q<ρ^2 := by
  have hs0 := Real.sqrt_pos.mpr hq0
  have hs1 : Real.sqrt q<1 := by simpa only [Real.sqrt_one] using Real.sqrt_lt_sqrt hq0.le hq1
  let t := (1+Real.sqrt q)/2
  have ht0 : 0<t := by dsimp [t];linarith
  have ht1 : t<1 := by dsimp [t];linarith
  refine ⟨Real.sqrt t,Real.sqrt_pos.mpr ht0,(by simpa only [Real.sqrt_one] using Real.sqrt_lt_sqrt ht0.le ht1),?_⟩
  rw [Real.sq_sqrt ht0.le]
  dsimp [t]
  linarith

 theorem source_momentDamping_bounds (q : ℝ) (hq0 : 0<q) (hq1 : q<1) (N : ℕ) :
    (∀j,0≤momentDamping (1-Real.sqrt q) N j) ∧
    (∀j,momentDamping (1-Real.sqrt q) N j≤1) ∧
    (∀j,1-momentDamping (1-Real.sqrt q) N j≤Real.sqrt q) := by
  have hθ := one_sub_sqrt_bounds q hq0 hq1
  have h := momentDamping_bounds (1-Real.sqrt q) N hθ.1.le hθ.2.le
  simpa only [sub_sub_cancel] using h

end Elliptic.Operator.PhysicalVertexParameters
