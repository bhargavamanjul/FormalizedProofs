module

public import Elliptic.Operator.RootArchimedeanGrid

/-!
# A disjoint partition on the same root grid

The closed grid remains the conservative boundary cover. Here each cell
is made upper-open except in the last interval, giving unique assignment
of every point of the normalized root box. The interval endpoints and
volumes do not change, so the external root count applies to this exact
partition using its explicit endpoint conventions.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGridPartition
open SourceRootCount RootArchimedeanGrid
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

def partCell (a b : ℝ) (n i : ℕ) : RootInterval :=
  { cell a b n i with upperClosed := decide (i+1=n) }

theorem partCell_subset (a b : ℝ) (n i : ℕ) (t : ℝ)
    (ht : (partCell a b n i).Contains t) : (cell a b n i).Contains t := by
  refine ⟨ht.1,?_⟩
  by_cases hi : i+1=n
  · simpa [partCell,cell,RootInterval.Contains,hi] using ht.2
  · exact (show t<(cell a b n i).upper by
      simpa [partCell,RootInterval.Contains,hi] using ht.2).le

theorem partCell_inRange (a b : ℝ) (hab : a≤b) (n i : ℕ) (hi : i<n) :
    (partCell a b n i).InRange a b := cell_inRange a b hab n i hi

theorem partCell_length (a b : ℝ) (n i : ℕ) :
    (partCell a b n i).length=(b-a)/n := cell_length a b n i

theorem partCell_unique (a b : ℝ) (hab : a<b) (n i j : ℕ)
    (hi : i<n) (hj : j<n) (t : ℝ)
    (hti : (partCell a b n i).Contains t)
    (htj : (partCell a b n j).Contains t) : i=j := by
  have hn : (0:ℝ)<n := by exact_mod_cast Nat.zero_lt_of_lt hi
  have hnot (i j : ℕ) (hj : j<n)
      (hti : (partCell a b n i).Contains t)
      (htj : (partCell a b n j).Contains t) : ¬i<j := by
    intro hij
    have hilast : i+1≠n := by omega
    have hu : t<a+(b-a)*((i:ℝ)+1)/n := by
      simpa [partCell,cell,RootInterval.Contains,hilast] using hti.2
    have hl : a+(b-a)*(j:ℝ)/n≤t := htj.1
    have hord : a+(b-a)*((i:ℝ)+1)/n ≤ a+(b-a)*(j:ℝ)/n := by
      gcongr
      exact_mod_cast Nat.succ_le_of_lt hij
    linarith
  have h1 := hnot i j hj hti htj
  have h2 := hnot j i hi htj hti
  omega

theorem partCell_cover (a b : ℝ) (hab : a<b) (n : ℕ) (hn : 0<n)
    (t : ℝ) (ht : a≤t) (ht' : t≤b) :
    ∃ i∈Finset.range n, (partCell a b n i).Contains t := by
  obtain ⟨i,hi,hci⟩ := cell_cover a b hab n hn t ht ht'
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  by_cases hiLast : i+1=n
  · exact ⟨i,hi,by simpa [partCell,cell,RootInterval.Contains,hiLast] using hci⟩
  · by_cases hstrict : t<(cell a b n i).upper
    · exact ⟨i,hi,hci.1,by simpa [partCell,RootInterval.Contains,hiLast] using hstrict⟩
    · have heq : t=(cell a b n i).upper := le_antisymm hci.2 (le_of_not_gt hstrict)
      have hiN := Finset.mem_range.mp hi
      have hnext : i+1<n := by omega
      refine ⟨i+1,Finset.mem_range.mpr hnext,?_,?_⟩
      · dsimp [partCell,cell]
        rw [heq]
        dsimp [cell]
        simp
      · have hwidth : 0<(b-a)/(n:ℝ) := by positivity
        have hlt : t<(cell a b n (i+1)).upper := by
          rw [heq]
          dsimp [cell]
          push_cast
          have he :
              (a+(b-a)*((i:ℝ)+1+1)/(n:ℝ))-(a+(b-a)*((i:ℝ)+1)/(n:ℝ)) =
                (b-a)/(n:ℝ) := by ring
          linarith
        by_cases hnLast : (i+1)+1=n
        · simpa [partCell,RootInterval.Contains,hnLast] using hlt.le
        · simpa [partCell,RootInterval.Contains,hnLast] using hlt

def PartContains (n : ℕ) (j : Index) (q : ℝ × ℝ × ℝ) : Prop :=
  (partCell 1 16 n j.1).Contains q.1 ∧
    (partCell 1 2 n j.2.1).Contains q.2.1 ∧
      (partCell 0 1 n j.2.2).Contains q.2.2

theorem part_subset_closed (n : ℕ) (j : Index) (q : ℝ × ℝ × ℝ)
    (hq : PartContains n j q) : Contains n j q :=
  ⟨partCell_subset _ _ _ _ _ hq.1,partCell_subset _ _ _ _ _ hq.2.1,
    partCell_subset _ _ _ _ _ hq.2.2⟩

theorem grid_partition_cover (n : ℕ) (hn : 0<n) (q : ℝ × ℝ × ℝ)
    (hq : 1≤q.1 ∧ q.1≤16 ∧ 1≤q.2.1 ∧ q.2.1≤2 ∧ 0≤q.2.2 ∧ q.2.2≤1) :
    ∃ j∈grid n, PartContains n j q := by
  obtain ⟨i,hi,hqi⟩ := partCell_cover 1 16 (by norm_num) n hn q.1 hq.1 hq.2.1
  obtain ⟨j,hj,hqj⟩ := partCell_cover 1 2 (by norm_num) n hn q.2.1 hq.2.2.1 hq.2.2.2.1
  obtain ⟨k,hk,hqk⟩ := partCell_cover 0 1 (by norm_num) n hn q.2.2 hq.2.2.2.2.1 hq.2.2.2.2.2
  exact ⟨(i,j,k),by simp [grid,hi,hj,hk],hqi,hqj,hqk⟩

theorem grid_partition_unique (n : ℕ) (j k : Index) (hj : j∈grid n) (hk : k∈grid n)
    (q : ℝ × ℝ × ℝ) (hjq : PartContains n j q) (hkq : PartContains n k q) : j=k := by
  simp only [grid,Finset.mem_product,Finset.mem_range] at hj hk
  have h1 := partCell_unique 1 16 (by norm_num) n j.1 k.1 hj.1 hk.1 q.1 hjq.1 hkq.1
  have h2 := partCell_unique 1 2 (by norm_num) n j.2.1 k.2.1 hj.2.1 hk.2.1 q.2.1 hjq.2.1 hkq.2.1
  have h3 := partCell_unique 0 1 (by norm_num) n j.2.2 k.2.2 hj.2.2 hk.2.2 q.2.2 hjq.2.2 hkq.2.2
  exact Prod.ext h1 (Prod.ext h2 h3)

def InRootBox (q : ℝ × ℝ × ℝ) : Prop :=
  1≤q.1 ∧ q.1≤16 ∧ 1≤q.2.1 ∧ q.2.1≤2 ∧ 0≤q.2.2 ∧ q.2.2≤1

theorem part_inRootBox (n : ℕ) (j : Index) (hj : j∈grid n) (q : ℝ × ℝ × ℝ)
    (hq : PartContains n j q) : InRootBox q := by
  have hI := grid_inRange n j hj
  have hq' := part_subset_closed n j q hq
  exact ⟨hI.1.1.trans hq'.1.1,hq'.1.2.trans hI.1.2.2,
    hI.2.1.1.trans hq'.2.1.1,hq'.2.1.2.trans hI.2.1.2.2,
    hI.2.2.1.trans hq'.2.2.1,hq'.2.2.2.trans hI.2.2.2.2⟩

theorem grid_partition_sum (n : ℕ) (hn : 0<n) (q : ℝ × ℝ × ℝ) (c : ℂ) :
    (∑ j∈grid n, if PartContains n j q then c else 0) =
      if InRootBox q then c else 0 := by
  by_cases hq : InRootBox q
  · obtain ⟨j,hj,hjq⟩ := grid_partition_cover n hn q hq
    rw [ite_eq_left hq]
    calc
      _ = if PartContains n j q then c else 0 := by
        apply Finset.sum_eq_single j
        · intro k hk hkj
          rw [ite_eq_right (by intro hkq; exact hkj (grid_partition_unique n k j hk hj q hkq hjq))]
        · exact fun hj' => False.elim (hj' hj)
      _ = c := ite_eq_left hjq
  · rw [ite_eq_right hq]
    apply Finset.sum_eq_zero
    intro j hj
    rw [ite_eq_right (by intro hjq; exact hq (part_inRootBox n j hj q hjq))]

def fullInterval (a b : ℝ) : RootInterval := ⟨a,b,true,true⟩

/-- Exact root-sum decomposition with every grid face assigned once.
The identity is finite algebra; the external root-count input is not
used, and no unproved root multiplicity assertion is needed. -/
theorem weightedRootSum_partition (n : ℕ) (hn : 0<n) (U V : ℝ) (S : ℕ)
    (f : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) :
    SourceRootTransfer.weightedRootSum U V S
      (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) f =
      ∑ j∈grid n, SourceRootTransfer.weightedRootSum U V S
        (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) f := by
  classical
  unfold SourceRootTransfer.weightedRootSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    have h := grid_partition_sum n hn
      ((t.1:ℝ)/U,(t.2.1:ℝ)/V,(t.2.2:ℝ)/t.1)
      (f (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod S)) (canonicalSL2 t hcan)))
    simp only [PartContains,InRootBox,fullInterval,RootInterval.Contains,ite_true,and_assoc]
      at h ⊢
    by_cases hbox : 1≤(t.1:ℝ)/U ∧ (t.1:ℝ)/U≤16 ∧
        1≤(t.2.1:ℝ)/V ∧ (t.2.1:ℝ)/V≤2 ∧
        0≤(t.2.2:ℝ)/t.1 ∧ (t.2.2:ℝ)/t.1≤1
    · rw [ite_eq_left hbox] at h ⊢
      exact h.symm
    · rw [ite_eq_right hbox] at h ⊢
      exact h.symm
  · simp [hcan]

end Elliptic.Operator.RootGridPartition
