module

public import Elliptic.Operator.RestrictedHistoryTruncation
public import Elliptic.Operator.BirthDistinctness
public import Mathlib.Data.Fintype.Prod
public import Mathlib.Data.Fintype.Sum
public import Mathlib.Data.Fintype.Perm

/-!
# Performed birth addresses of literal physical histories

The address space is fixed before a history is chosen. It contains all
initial active slots, B possible ghost slots per group and visit, and one
possible fresh active slot per group and edge. Unused slots have value none.
Promotions and stores do not create births. The logger reads the actual
dependent choices and does not take a lifespan schedule as input.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance actualBirthDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

namespace ActualHistoryBirths

abbrev operations (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (j n : ℕ) : List (ChoiceOperation (PhysicalMemoryState (Z:=Z) P Line J B)) :=
  memoryOperationsFrom
    (fun k => physicalGhostOperation ν V (η k) (q k) ρ anchor)
    (fun k => physicalEdgeOperation ν V ρ anchor (geometry k)) j n

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- A ghost batch is padded by absent addresses up to the actual cutoff. -/
def ghostSlot {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalGhostChoice s) (i : I) (a : Fin B) : Option (P i) :=
  if h : a.val < (c i).2.size then some ((c i).2.values ⟨a.val,h⟩) else none

/-- A fresh target is a birth. An old-index promotion is not. -/
def freshSlot {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalEdgeChoice s) (i : I) : Option (P i) :=
  match (c.group i).2 with
  | .inl _ => none
  | .inr p => some p

/-- Read the actual ghost choice at a visit, following actual outputs. -/
def ghostAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s →
    Fin (n+1) → (i : I) → Fin B → Option (P i)
  | 0,_,_,h,_ => ghostSlot h.1.val
  | n+1,j,_,h,k => Fin.cases (ghostSlot h.1.val)
      (fun t => ghostAt n (j+1) _ h.2.2 t) k

/-- Read the fresh/old target flag and value of the actual edge choice. -/
def freshAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s →
    Fin n → (i : I) → Option (P i)
  | 0,_,_,_,k => Fin.elim0 k
  | n+1,j,_,h,k => Fin.cases (freshSlot h.2.1.val)
      (fun t => freshAt n (j+1) _ h.2.2 t) k

/-- Fixed addresses; ghost and active slots are never identified. -/
abbrev Address (I : Type) (J B N : ℕ) :=
  (I × Fin (J+1)) ⊕ ((Fin (N+1) × I × Fin B) ⊕ (Fin N × I))

instance addressFintype (N : ℕ) : Fintype (Address I J B N) :=
  inferInstanceAs (Fintype ((I × Fin (J+1)) ⊕ ((Fin (N+1) × I × Fin B) ⊕ (Fin N × I))))

instance addressPermFintype (N : ℕ) : Fintype (Equiv.Perm (Address I J B N)) :=
  @Equiv.instFintype (Address I J B N) (Address I J B N) inferInstance inferInstance
    (addressFintype N) (addressFintype N)

/-- Numerical values at every performed address in the actual history.
The caller's numerical label map permits the actual prime-band values. -/
def labels (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    Address I J B N → Option ℕ
  | .inl a => some (value a.1 (s.active P Line J B a.1 a.2))
  | .inr (.inl a) => (ghostAt ν V η q ρ anchor geometry N 0 s h a.1 a.2.1 a.2.2).map
      (value a.2.1)
  | .inr (.inr a) => (freshAt ν V η q ρ anchor geometry N 0 s h a.1 a.2).map (value a.2)

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem ghostSlot_eq_some_iff {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalGhostChoice s) (i : I) (a : Fin B) (p : P i) :
    ghostSlot c i a = some p ↔
      ∃ h : a.val < (c i).2.size, (c i).2.values ⟨a.val,h⟩ = p := by
  unfold ghostSlot
  split_ifs with h <;> simp [h]

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem freshSlot_eq_some_iff {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalEdgeChoice s) (i : I) (p : P i) :
    freshSlot c i = some p ↔ (c.group i).2 = .inr p := by
  unfold freshSlot
  cases (c.group i).2 <;> simp

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem ghostSlot_performed_count {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalGhostChoice s) (i : I) :
    (∑ a : Fin B, if (ghostSlot c i a).isSome then 1 else 0 : ℕ) = (c i).2.size := by
  have hbound : (c i).2.size ≤ B := Nat.le_of_lt_succ (c i).2.1.isLt
  have ht (a : Fin B) :
      (if (ghostSlot c i a).isSome then 1 else 0 : ℕ) =
        if a.val < (c i).2.size then 1 else 0 := by
    unfold ghostSlot
    by_cases h : a.val < (c i).2.size <;> simp [h]
  simp_rw [ht]
  rw [Fin.sum_univ_eq_sum_range (fun a => if a < (c i).2.size then (1 : ℕ) else 0) B]
  rw [Finset.sum_boole]
  have he : (Finset.range B).filter (fun a => a < (c i).2.size) =
      Finset.range (c i).2.size := by
    ext a
    simp only [Finset.mem_filter, Finset.mem_range]
    omega
  rw [he, Finset.card_range]
  simp

/-- The logger records exactly the ghost births counted by the operation
word. This holds without a schedule, distinctness, or any norm estimate. -/
theorem ghostAt_performed_count (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s) :
    (∑ k : Fin (n+1), ∑ i, ∑ a : Fin B,
      if (ghostAt ν V η q ρ anchor geometry n j s h k i a).isSome then 1 else 0 : ℕ)
        = h.ghostBirths := by
  induction n generalizing j s with
  | zero =>
      simp only [ghostAt, ghostSlot_performed_count]
      simp only [ChoiceOperation.History.ghostBirths, operations,
        memoryOperationsFrom, physicalGhostOperation, add_zero]
      simp
  | succ n ih =>
      rw [Fin.sum_univ_succ]
      simp only [ghostAt, Fin.cases_zero, Fin.cases_succ, ghostSlot_performed_count]
      rw [ih]
      change _ = (∑ i, (h.1.val i).2.size) + (0 + h.2.2.ghostBirths)
      omega

/-- Actual numerical birth distinctness already forces distinct initial
active labels, including labels in different groups. -/
theorem initial_labels_injective (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (labels ν V η q ρ anchor geometry value N s h)) :
    Function.Injective (fun a : I × Fin (J+1) => value a.1 (s.active P Line J B a.1 a.2)) := by
  intro a b hab
  have he := hd (.inl a) (.inl b) _ rfl (by simpa [labels] using congrArg some hab.symm)
  exact Sum.inl.inj he

/-- Restore distinctness inside the literal physical history sum. The
weight may include arbitrary global selectors, empty terminal memory,
the actual history coefficient and the two boundary functions. -/
theorem weighted_distinctness_expansion (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (W : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s → ℂ) :
    (∑ h, if BirthsDistinct (labels ν V η q ρ anchor geometry value N s h) then W h else 0) =
      ∑ σ : Equiv.Perm (Address I J B N), (permutationSign σ : ℂ) *
        ∑ h, if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
          then W h else 0 := by
  simpa using weighted_birth_distinctness_expansion Finset.univ
    (labels ν V η q ρ anchor geometry value N s) W

end ActualHistoryBirths
end Elliptic.Operator
