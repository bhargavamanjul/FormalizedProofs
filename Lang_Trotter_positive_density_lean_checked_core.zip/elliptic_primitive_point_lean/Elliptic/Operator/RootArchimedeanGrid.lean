module

public import Elliptic.Operator.RootBoxFamily
public import Mathlib.Data.Int.Interval

/-!
# A literal root grid and its horizontal boundary cells

The grid is constructed on the actual three normalized root coordinates
`[1,16] × [1,2] × [0,1]`. Closed cubes are used for a conservative cover;
their interiors are disjoint, and their overlaps can only enlarge the
boundary majorant. A plane `r = t` meets at most `2*n^2` cubes. Thus a
finite, explicitly supplied set of such planes has total cube volume at
most `30 * card / n`. This is an actual counting conclusion, not an
assumed cardinality bound for an abstract partition.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootArchimedeanGrid
open SourceRootCount SourceRootTransfer
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def cell (a b : ℝ) (n i : ℕ) : RootInterval :=
  ⟨a+(b-a)*(i:ℝ)/n, a+(b-a)*((i:ℝ)+1)/n, true, true⟩

theorem cell_contains (a b : ℝ) (n i : ℕ) (t : ℝ) :
    (cell a b n i).Contains t ↔
      a+(b-a)*(i:ℝ)/n ≤ t ∧ t ≤ a+(b-a)*((i:ℝ)+1)/n := by
  rfl

theorem cell_length (a b : ℝ) (n i : ℕ) :
    (cell a b n i).length = (b-a)/n := by
  dsimp [cell, RootInterval.length]
  ring

theorem cell_inRange (a b : ℝ) (hab : a ≤ b) (n i : ℕ) (hi : i < n) :
    (cell a b n i).InRange a b := by
  have hn : (0:ℝ) < n := by exact_mod_cast (Nat.zero_lt_of_lt hi)
  have hi' : (i:ℝ)+1 ≤ n := by exact_mod_cast (Nat.succ_le_of_lt hi)
  dsimp [cell, RootInterval.InRange]
  refine ⟨?_, ?_, ?_⟩
  · have hh : 0 ≤ (b-a)*(i:ℝ)/n := by positivity
    linarith
  · gcongr; linarith
  · have hh : (b-a)*((i:ℝ)+1)/n ≤ b-a := by
      apply (div_le_iff₀ hn).mpr
      nlinarith
    linarith

theorem unit_cover (n : ℕ) (hn : 0 < n) (t : ℝ) (ht : 0 ≤ t) (ht' : t ≤ n) :
    ∃ i ∈ Finset.range n, (i:ℝ) ≤ t ∧ t ≤ (i:ℝ)+1 := by
  by_cases he : t = n
  · have hh : ((n-1:ℕ):ℝ)+1 = n := by exact_mod_cast (Nat.sub_add_cancel hn)
    refine ⟨n-1, Finset.mem_range.mpr (by omega), ?_, ?_⟩ <;> linarith
  · refine ⟨⌊t⌋₊, Finset.mem_range.mpr ((Nat.floor_lt ht).mpr (lt_of_le_of_ne ht' he)),
      Nat.floor_le ht, (Nat.lt_floor_add_one t).le⟩

theorem cell_cover (a b : ℝ) (hab : a < b) (n : ℕ) (hn : 0 < n)
    (t : ℝ) (ht : a ≤ t) (ht' : t ≤ b) :
    ∃ i ∈ Finset.range n, (cell a b n i).Contains t := by
  have hnR : (0:ℝ) < n := by exact_mod_cast hn
  have hba : 0 < b-a := sub_pos.mpr hab
  have ht0 : 0 ≤ (t-a)*(n:ℝ)/(b-a) := by positivity
  have htN : (t-a)*(n:ℝ)/(b-a) ≤ n := by
    apply (div_le_iff₀ hba).mpr
    nlinarith
  obtain ⟨i,hi,hil,hiu⟩ := unit_cover n hn _ ht0 htN
  refine ⟨i,hi,?_,?_⟩
  · apply (le_div_iff₀ hba).mp at hil
    dsimp [cell]
    have hh : (b-a)*(i:ℝ)/n ≤ t-a := (div_le_iff₀ hnR).mpr (by nlinarith)
    linarith
  · apply (div_le_iff₀ hba).mp at hiu
    dsimp [cell]
    have hh : t-a ≤ (b-a)*((i:ℝ)+1)/n := (le_div_iff₀ hnR).mpr (by nlinarith)
    linarith

abbrev Index := ℕ × ℕ × ℕ

def grid (n : ℕ) : Finset Index :=
  Finset.range n ×ˢ (Finset.range n ×ˢ Finset.range n)

def Contains (n : ℕ) (j : Index) (q : ℝ × ℝ × ℝ) : Prop :=
  (cell 1 16 n j.1).Contains q.1 ∧
    (cell 1 2 n j.2.1).Contains q.2.1 ∧
      (cell 0 1 n j.2.2).Contains q.2.2

theorem grid_card (n : ℕ) : (grid n).card = n^3 := by
  simp [grid, pow_succ, mul_assoc]

theorem grid_inRange (n : ℕ) (j : Index) (hj : j ∈ grid n) :
    (cell 1 16 n j.1).InRange 1 16 ∧
      (cell 1 2 n j.2.1).InRange 1 2 ∧
        (cell 0 1 n j.2.2).InRange 0 1 := by
  simp only [grid, Finset.mem_product, Finset.mem_range] at hj
  exact ⟨cell_inRange _ _ (by norm_num) _ _ hj.1,
    cell_inRange _ _ (by norm_num) _ _ hj.2.1,
    cell_inRange _ _ (by norm_num) _ _ hj.2.2⟩

theorem grid_cover (n : ℕ) (hn : 0 < n) (q : ℝ × ℝ × ℝ)
    (hq : 1 ≤ q.1 ∧ q.1 ≤ 16 ∧ 1 ≤ q.2.1 ∧ q.2.1 ≤ 2 ∧
      0 ≤ q.2.2 ∧ q.2.2 ≤ 1) :
    ∃ j ∈ grid n, Contains n j q := by
  obtain ⟨i,hi,hqi⟩ := cell_cover 1 16 (by norm_num) n hn q.1 hq.1 hq.2.1
  obtain ⟨j,hj,hqj⟩ := cell_cover 1 2 (by norm_num) n hn q.2.1 hq.2.2.1 hq.2.2.2.1
  obtain ⟨k,hk,hqk⟩ := cell_cover 0 1 (by norm_num) n hn q.2.2 hq.2.2.2.2.1 hq.2.2.2.2.2
  exact ⟨(i,j,k), by simp [grid,hi,hj,hk], hqi,hqj,hqk⟩

def cellVolume (n : ℕ) (j : Index) : ℝ :=
  (cell 1 16 n j.1).length * (cell 1 2 n j.2.1).length *
    (cell 0 1 n j.2.2).length

theorem cellVolume_eq (n : ℕ) (j : Index) : cellVolume n j = 15/(n:ℝ)^3 := by
  simp only [cellVolume, cell_length]
  norm_num
  ring

def boundaryLayers (n : ℕ) (t : ℝ) : Finset ℕ :=
  (Finset.range n).filter fun i => (cell 0 1 n i).Contains t

theorem boundaryLayers_card (n : ℕ) (hn : 0 < n) (t : ℝ) :
    (boundaryLayers n t).card ≤ 2 := by
  have hnR : (0:ℝ) < n := by exact_mod_cast hn
  have hc : (boundaryLayers n t).card ≤
      (Finset.Icc (⌊t*(n:ℝ)⌋-1) ⌊t*(n:ℝ)⌋).card := by
    apply Finset.card_le_card_of_injOn (fun i : ℕ => (i:ℤ))
    · intro i hi
      have hm := (Finset.mem_filter.mp hi).2
      simp only [cell_contains, sub_zero, one_mul, zero_add] at hm
      have hil : (i:ℝ) ≤ t*(n:ℝ) := (div_le_iff₀ hnR).mp hm.1
      have hiu : t*(n:ℝ) ≤ (i:ℝ)+1 := (le_div_iff₀ hnR).mp hm.2
      apply Finset.mem_Icc.mpr
      refine ⟨?_, Int.le_floor.mpr (by exact_mod_cast hil)⟩
      change ⌊t*(n:ℝ)⌋-1 ≤ (i:ℤ)
      have hh : ⌊t*(n:ℝ)⌋ ≤ (i:ℤ)+1 := by
        have hle := (Int.floor_le (t*(n:ℝ))).trans hiu
        exact_mod_cast hle
      omega
    · intro i _ j _ hij
      exact Int.ofNat_inj.mp hij
  simpa [Int.card_Icc, show ⌊t*(n:ℝ)⌋+1-(⌊t*(n:ℝ)⌋-1) = 2 by omega] using hc

def boundaryCubes (n : ℕ) (t : ℝ) : Finset Index :=
  Finset.range n ×ˢ (Finset.range n ×ˢ boundaryLayers n t)

theorem mem_boundaryCubes (n : ℕ) (t : ℝ) (j : Index) :
    j ∈ boundaryCubes n t ↔ j ∈ grid n ∧ (cell 0 1 n j.2.2).Contains t := by
  simp only [boundaryCubes, grid, boundaryLayers, Finset.mem_product, Finset.mem_filter]
  tauto

theorem boundaryCubes_card (n : ℕ) (hn : 0 < n) (t : ℝ) :
    (boundaryCubes n t).card ≤ 2*n^2 := by
  simp only [boundaryCubes, Finset.card_product, Finset.card_range]
  have h := Nat.mul_le_mul_left (n*n) (boundaryLayers_card n hn t)
  nlinarith

def boundaryFamily (n : ℕ) (ends : Finset ℝ) : Finset Index :=
  ends.biUnion (boundaryCubes n)

theorem boundaryFamily_card (n : ℕ) (hn : 0 < n) (ends : Finset ℝ) :
    (boundaryFamily n ends).card ≤ 2*ends.card*n^2 := by
  calc
    _ ≤ ∑ t ∈ ends, (boundaryCubes n t).card := Finset.card_biUnion_le
    _ ≤ ∑ _t ∈ ends, 2*n^2 := Finset.sum_le_sum (fun _ _ => boundaryCubes_card n hn _)
    _ = _ := by simp; ring

theorem boundaryFamily_subset_grid (n : ℕ) (ends : Finset ℝ) :
    boundaryFamily n ends ⊆ grid n := by
  intro j hj
  obtain ⟨t,_,hjt⟩ := Finset.mem_biUnion.mp hj
  exact ((mem_boundaryCubes n t j).mp hjt).1

/-- The sum is the actual sum of the constructed cube volumes; it
majorizes the volume of their union even where closed faces overlap. -/
theorem boundaryFamily_volume (n : ℕ) (hn : 0 < n) (ends : Finset ℝ) :
    ∑ j ∈ boundaryFamily n ends, cellVolume n j ≤ 30*(ends.card:ℝ)/n := by
  simp only [cellVolume_eq, Finset.sum_const, nsmul_eq_mul]
  have hnR : (0:ℝ) < n := by exact_mod_cast hn
  have hc : ((boundaryFamily n ends).card:ℝ) ≤ 2*(ends.card:ℝ)*(n:ℝ)^2 := by
    exact_mod_cast boundaryFamily_card n hn ends
  calc
    _ ≤ (2*(ends.card:ℝ)*(n:ℝ)^2)*(15/(n:ℝ)^3) :=
      mul_le_mul_of_nonneg_right hc (by positivity)
    _ = _ := by field_simp; ring

end Elliptic.Operator.RootArchimedeanGrid
