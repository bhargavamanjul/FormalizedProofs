module
public import Elliptic.Operator.MajorArcFullEndpointSaving

/-! The full endpoint energy for the literal manuscript prime bands. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcBandEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest MajorArcLabelMass
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000

 theorem uniform_band_endpoint_energy
    (hbands : ClassicalBandMass) (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η) (hsupp : ∀y,η y≠0→1≤y ∧ y≤4)
    (δ Ccoef J E Alam A₀ c₁ c₂ : ℝ)
    (hδ : 0<δ) (hcoef : 0≤Ccoef) (hJ : 0≤J) (hE : 0≤E) (hAlam : 0≤Alam) (hA₀ : 0<A₀)
    {I : Type} (Hm Hn : ℝ→I→ℝ) (active : ℝ→I→Prop) (α : ℝ→I→ℕ→ℂ)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel : ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα : ∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^Ccoef)
    (K : ℕ) (hK : 1≤K) (bands : Bands K) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→∀(q:ℕ)(χ:DirichletCharacter ℂ q),
      ∀s t:Finset ℕ,IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^Ccoef)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀l:ℕ,
      ∀(χm:DirichletCharacter ℂ k)(χn:DirichletCharacter ℂ l),
      ∀lam Y:ℝ,0<Y→|lam|≤(Real.log x)^Alam→∀u:ℝ,|u|≤(Hm x j*Hn x j)*(Real.log x)^J→
      (∫v in Icc (u-(Hm x j*Hn x j)*(Real.log x)^J) (u+(Hm x j*Hn x j)*(Real.log x)^J),
        ‖fullEndpoint (bands.group x) χ η lam Y v*
          longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2)≤(Real.log x)^(-E) := by
  have henergy := MajorArcFullEndpointSaving.uniform_full_endpoint_energy hvdC hD η hη hsupp
    δ 1 2 Ccoef J E Alam A₀ c₁ c₂ hδ (by norm_num) (by norm_num) hcoef hJ hE hAlam hA₀
    Hm Hn active α hscale hcancel hα
  have hl2 : 0<Real.log (2:ℝ) := by positivity
  filter_upwards [henergy,hbands K bands,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop ((Real.log 2/2)⁻¹)),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ))] with x henergy hmass hLinv hL
  intro j hj q χ s t hs ht β hβ k hk hkmax l χm χn lam Y hY hlam u hu
  let i₀ : Fin K := ⟨0,by omega⟩
  have hpos (i:Fin K) : 0<bands.mass x i := (half_pos hl2).trans_le (hmass i)
  have hmass' (i:Fin K) : (∑p∈bands.group x i,(p:ℝ)⁻¹)≠0 := (hpos i).ne'
  have hinv : (∑p∈bands.group x i₀,(p:ℝ)⁻¹)⁻¹≤Real.log x :=
    ((inv_le_inv₀ (hpos i₀) (half_pos hl2)).mpr (hmass i₀)).trans hLinv
  have hlog : ∀p∈bands.group x i₀,
      1*(Real.log x)^(1/10:ℝ)≤Real.log p ∧ Real.log p≤2*(Real.log x)^(1/5:ℝ) := by
    intro p hp
    have hb := Artin.MarkedBandTail.primeBand_properties (bands.exponent i₀) x
      (by simpa only [bands.group_eq_markedBandTail] using hp)
    have hp0 : (0:ℝ)<p := by exact_mod_cast hb.1.pos
    have hlo := Real.log_le_log (Real.exp_pos _) hb.2.1
    have hhi := Real.log_le_log hp0 hb.2.2
    rw [Real.log_exp] at hlo hhi
    constructor
    · simpa only [one_mul] using (Real.rpow_le_rpow_of_exponent_le hL (bands.lower i₀).le).trans hlo
    · exact hhi.trans (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hL (bands.upper i₀).le) (by norm_num))
  exact henergy j hj (Fin K) (bands.group x) i₀
    (fun i p hp=>(bands.group_prime x hp).pos) hmass' (fun p hp=>bands.group_prime x hp) hinv hlog
    q χ s t hs ht β hβ k hk hkmax l χm χn lam Y hY hlam u hu

end Elliptic.Operator.MajorArcBandEndpointSaving
