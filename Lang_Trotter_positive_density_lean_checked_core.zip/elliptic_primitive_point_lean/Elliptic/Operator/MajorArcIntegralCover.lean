module
public import Elliptic.Operator.MajorArcMeasure
public import Elliptic.Operator.SignedMajorCharacter

/-! Parameterization of the literal major arcs and their finite integral
budget. Overlaps require no disjoint-arc premise. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcIntegralCover
open scoped BigOperators
open MeasureTheory Set
open MajorArcMeasure
attribute [local instance] Classical.propDecidable
set_option maxHeartbeats 600000

 theorem circle_ball_integral (f : ProductCircle→ℝ) (a r : ℝ) (hr : 0≤r) (hr' : r<1/2) :
    (∫θ in Metric.closedBall (a:ProductCircle) r,f θ)=
      ∫t in (a-r)..(a+r),f (t:ProductCircle) := by
  let s := Metric.closedBall (a:ProductCircle) r
  let I := Ioc (a-1/2) (a+1/2)
  have he : (∫θ in s,f θ)=∫t in I,s.indicator f (t:ProductCircle) := by
    rw [←integral_indicator measurableSet_closedBall]
    have h := AddCircle.integral_preimage (1:ℝ) (a-1/2) (s.indicator f)
    dsimp only [I]
    simpa only [show a-1/2+1=a+1/2 by ring] using h.symm
  have hi (t : ℝ) (ht : t∈I) :
      s.indicator f (t:ProductCircle)=(Icc (a-r) (a+r)).indicator (fun t:ℝ=>f (t:ProductCircle)) t := by
    have ht' : |t-a|≤1/2 := by
      dsimp [I] at ht
      exact abs_le.mpr ⟨by linarith [ht.1],by linarith [ht.2]⟩
    have hd : dist (t:ProductCircle) (a:ProductCircle)=|t-a| := by
      rw [dist_eq_norm,←AddCircle.coe_sub]
      exact (AddCircle.norm_coe_eq_abs_iff (1:ℝ) (by norm_num : (1:ℝ)≠0)).mpr (by simpa using ht')
    have hm : (t:ProductCircle)∈s ↔ t∈Icc (a-r) (a+r) := by
      simp only [s,Metric.mem_closedBall,hd,abs_le,mem_Icc]
      constructor <;> intro h <;> constructor <;> linarith [h.1,h.2]
    by_cases hs : (t:ProductCircle)∈s
    · rw [Set.indicator_of_mem hs,Set.indicator_of_mem (hm.mp hs)]
    · rw [Set.indicator_of_notMem hs,Set.indicator_of_notMem (fun h=>hs (hm.mpr h))]
  rw [he,setIntegral_congr_fun measurableSet_Ioc hi,integral_indicator measurableSet_Icc,
    Measure.restrict_restrict measurableSet_Icc]
  have hsub : Icc (a-r) (a+r)⊆I := by
    intro t ht
    change a-1/2<t ∧ t≤a+1/2
    constructor <;> linarith [ht.1,ht.2]
  rw [inter_eq_left.mpr hsub,integral_Icc_eq_integral_Ioc,
    intervalIntegral.integral_of_le (by linarith : a-r≤a+r)]

 theorem circle_ball_scaled_integral (f : ProductCircle→ℝ) (a H Y : ℝ)
    (hH : 0≤H) (hY : 0<Y) (hsmall : 2*H/Y<1/2) :
    (∫θ in Metric.closedBall (a:ProductCircle) (2*H/Y),f θ)=
      Y⁻¹*(∫lam in (-2*H)..(2*H),f ((a+lam/Y:ℝ):ProductCircle)) := by
  rw [circle_ball_integral f a (2*H/Y) (by positivity) hsmall]
  have h := intervalIntegral.inv_smul_integral_comp_add_div
    (fun t:ℝ=>f (t:ProductCircle)) (a:= -2*H) (b:=2*H) Y a
  simpa only [smul_eq_mul,neg_mul,neg_div,sub_eq_add_neg] using h.symm

 theorem integral_le_sum_cover {X ι : Type*} [MeasurableSpace X] [Fintype ι]
    (μ : Measure X) (s : Set X) (hs : MeasurableSet s) (t : ι→Set X)
    (ht : ∀i,MeasurableSet (t i)) (hcover : s⊆⋃i,t i)
    (f : X→ℝ) (hf : Integrable f μ) (hfn : ∀x,0≤f x) :
    (∫x in s,f x ∂μ)≤∑i,∫x in t i,f x ∂μ := by
  have hp (x : X) : s.indicator f x≤∑i,(t i).indicator f x := by
    by_cases hx : x∈s
    · obtain ⟨i,hi⟩ := Set.mem_iUnion.mp (hcover hx)
      rw [Set.indicator_of_mem hx]
      apply (show f x=(t i).indicator f x by rw [Set.indicator_of_mem hi]).le.trans
      exact Finset.single_le_sum (f:=fun j=>(t j).indicator f x)
        (fun j _=>by by_cases h:x∈t j <;> simp [h,hfn]) (Finset.mem_univ i)
    · rw [Set.indicator_of_notMem hx]
      exact Finset.sum_nonneg (fun i _=>by by_cases h:x∈t i <;> simp [h,hfn])
  have hh := integral_mono (hf.indicator hs) (integrable_finsetSum _ (fun i _=>hf.indicator (ht i))) hp
  rw [integral_indicator hs,integral_finsetSum _ (fun i _=>hf.indicator (ht i))] at hh
  simpa only [integral_indicator (ht _)] using hh

 theorem major_integral_cover (H Y : ℝ) (hH : 0≤H) (hY : 0<Y) (hsmall : 2*H/Y<1/2)
    (F : ProductCircle→ℂ) (hF : Integrable F productCircleMeasure) :
    ‖∫θ in sourceMajorArcs H Y,F θ ∂productCircleMeasure‖≤
      Y⁻¹*∑d : Finset.Icc 1 ⌊H⌋₊,∑c : Finset.range ⌊H⌋₊,
        ∫lam in (-2*H)..(2*H),‖F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)‖ := by
  rw [productCircleMeasure_eq_volume] at hF ⊢
  apply (norm_integral_le_integral_norm _).trans
  let S := (Finset.Icc 1 ⌊H⌋₊)×(Finset.range ⌊H⌋₊)
  have hc : sourceMajorArcs H Y⊆⋃i:S,
      Metric.closedBall ((((i.2:ℕ):ℝ)/(i.1:ℕ):ℝ):ProductCircle) (2*H/Y) := by
    intro θ hθ
    obtain ⟨d,hd⟩ := Set.mem_iUnion.mp (sourceMajorArcs_subset H Y hθ)
    obtain ⟨c,hc⟩ := Set.mem_iUnion.mp hd
    exact Set.mem_iUnion.mpr ⟨(d,c),hc⟩
  have hh := integral_le_sum_cover volume (sourceMajorArcs H Y) (sourceMajorArcs_measurable H Y)
    (fun i:S=>Metric.closedBall ((((i.2:ℕ):ℝ)/(i.1:ℕ):ℝ):ProductCircle) (2*H/Y))
    (fun _=>measurableSet_closedBall) hc (fun θ=>‖F θ‖) hF.norm (fun _=>norm_nonneg _)
  apply hh.trans_eq
  rw [Fintype.sum_prod_type]
  simp_rw [circle_ball_scaled_integral _ _ H Y hH hY hsmall]
  simp only [Finset.mul_sum]

/-- Uniform local arc saving pays the exact floor(H)^2 cover budget. -/
 theorem major_integral_le (H Y E : ℝ) (hH : 0≤H) (hY : 0<Y) (hE : 0≤E)
    (hsmall : 2*H/Y<1/2) (F : ProductCircle→ℂ) (hF : Integrable F productCircleMeasure)
    (hlocal : ∀d : Finset.Icc 1 ⌊H⌋₊,∀c : Finset.range ⌊H⌋₊,
      (∫lam in (-2*H)..(2*H),‖F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)‖)≤E) :
    ‖∫θ in sourceMajorArcs H Y,F θ ∂productCircleMeasure‖≤H^2*E/Y := by
  apply (major_integral_cover H Y hH hY hsmall F hF).trans
  have hs : (∑d : Finset.Icc 1 ⌊H⌋₊,∑c : Finset.range ⌊H⌋₊,
      ∫lam in (-2*H)..(2*H),‖F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)‖)≤(⌊H⌋₊:ℝ)^2*E := by
    calc
      _ ≤ ∑_d : Finset.Icc 1 ⌊H⌋₊,∑_c : Finset.range ⌊H⌋₊,E :=
        Finset.sum_le_sum (fun d _=>Finset.sum_le_sum (fun c _=>hlocal d c))
      _ = _ := by simp [pow_two];ring
  have hfloor : (⌊H⌋₊:ℝ)^2≤H^2 := by
    have hh := Nat.floor_le hH
    have h0 : (0:ℝ)≤⌊H⌋₊ := Nat.cast_nonneg _
    nlinarith
  have ht := mul_le_mul_of_nonneg_left
    (hs.trans (mul_le_mul_of_nonneg_right hfloor hE)) (inv_nonneg.mpr hY.le)
  simpa only [div_eq_mul_inv,mul_comm,mul_left_comm,mul_assoc] using ht

 theorem integral_norm_sum_le {ι : Type*} [Fintype ι]
    (a b E : ℝ) (hab : a≤b) (c : ι→ℂ) (G : ι→ℝ→ℂ)
    (hG : ∀i,IntervalIntegrable (G i) volume a b)
    (hbound : ∀i,(∫t in a..b,‖G i t‖)≤E) :
    (∫t in a..b,‖∑i,c i*G i t‖)≤(∑i,‖c i‖)*E := by
  have hleft : IntervalIntegrable (fun t=>∑i,c i*G i t) volume a b := by
    convert IntervalIntegrable.sum Finset.univ (fun i _=>(hG i).const_mul (c i)) using 1
    funext t
    simp
  have hright : IntervalIntegrable (fun t=>∑i,‖c i‖*‖G i t‖) volume a b := by
    convert IntervalIntegrable.sum Finset.univ (fun i _=>(hG i).norm.const_mul ‖c i‖) using 1
    funext t
    simp
  have hh := intervalIntegral.integral_mono_on hab hleft.norm hright
    (fun t _=>by simpa only [norm_mul] using norm_sum_le Finset.univ (fun i=>c i*G i t))
  rw [intervalIntegral.integral_finsetSum (fun i _=>(hG i).norm.const_mul ‖c i‖)] at hh
  simp_rw [intervalIntegral.integral_const_mul] at hh
  apply hh.trans
  rw [Finset.sum_mul]
  exact Finset.sum_le_sum (fun i _=>mul_le_mul_of_nonneg_left (hbound i) (norm_nonneg _))

 theorem signed_character_integral_le (k : ℕ) [NeZero k] (h σ : ℤ)
    (a b E : ℝ) (hab : a≤b) (hE : 0≤E)
    (G : SignedMajorCharacter.CharacterTuple k 6→ℝ→ℂ)
    (hG : ∀χ,IntervalIntegrable (G χ) volume a b)
    (hbound : ∀χ,(∫t in a..b,‖G χ t‖)≤E) :
    (∫t in a..b,‖∑χ,SignedMajorCharacter.coefficient k 6
      (SignedMajorCharacter.signedRationalPhase k h σ) χ*G χ t‖)≤(k:ℝ)^6*E := by
  apply (integral_norm_sum_le a b E hab _ G hG hbound).trans
  apply mul_le_mul_of_nonneg_right _ hE
  apply (SignedMajorCharacter.coefficient_l1_le k 6 _
    (fun u=>(SignedMajorCharacter.signedRationalPhase_norm k h σ u).le)).trans
  exact pow_le_pow_left₀ (Nat.cast_nonneg _) (by exact_mod_cast Nat.totient_le k) _

/-- The exact six-character cost and the actual rational cover cost are H^8. -/
 theorem major_integral_le_character_budget (H Y E : ℝ) (hH : 0≤H) (hY : 0<Y) (hE : 0≤E)
    (hsmall : 2*H/Y<1/2) (F : ProductCircle→ℂ) (hF : Integrable F productCircleMeasure)
    (hlocal : ∀d : Finset.Icc 1 ⌊H⌋₊,∀c : Finset.range ⌊H⌋₊,
      (∫lam in (-2*H)..(2*H),‖F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)‖)≤(d:ℝ)^6*E) :
    ‖∫θ in sourceMajorArcs H Y,F θ ∂productCircleMeasure‖≤H^8*E/Y := by
  have hh := major_integral_le H Y (H^6*E) hH hY (by positivity) hsmall F hF (by
    intro d c
    apply (hlocal d c).trans
    apply mul_le_mul_of_nonneg_right _ hE
    apply pow_le_pow_left₀ (Nat.cast_nonneg _)
    exact (show ((d:ℕ):ℝ)≤⌊H⌋₊ by exact_mod_cast (Finset.mem_Icc.mp d.property).2).trans (Nat.floor_le hH))
  convert hh using 1 <;> ring

end Elliptic.Operator.MajorArcIntegralCover
