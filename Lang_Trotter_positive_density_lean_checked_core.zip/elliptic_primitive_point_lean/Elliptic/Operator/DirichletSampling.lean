module

public import Elliptic.Operator.GrowingPrimeMeanSquare
public import Mathlib.Analysis.InnerProductSpace.Calculus
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.DistLEIntegral

/-!
# Separated samples of actual Dirichlet polynomials

A local fundamental-theorem-of-calculus estimate converts the proved
continuous mean square into a coefficient-independent separated-sample
estimate. The frequency samples are arbitrary real numbers.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirichletMeanSquare
open scoped BigOperators
open MeasureTheory Set
attribute [local instance] Classical.propDecidable
local instance dirichletSamplingDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- A unit-interval Sobolev bound, proved directly from the FTC. -/
theorem point_energy_le_local_integral (F F' : ℝ→ℂ) (hF : Continuous F)
    (hF' : Continuous F') (hd : ∀t,HasDerivAt F (F' t) t) (t : ℝ) :
    ‖F t‖^2≤2*(∫s in t..t+1,‖F s‖^2)+(∫s in t..t+1,‖F' s‖^2) := by
  let g : ℝ→ℝ := fun s=>‖F s‖^2
  let H : ℝ→ℝ := fun s=>‖F s‖^2+‖F' s‖^2
  have hgc : Continuous g := hF.norm.pow 2
  have hHc : Continuous H := (hF.norm.pow 2).add (hF'.norm.pow 2)
  have hHpos (s : ℝ) : 0≤H s := add_nonneg (sq_nonneg _) (sq_nonneg _)
  have hderiv (s : ℝ) : ‖deriv g s‖≤H s := by
    rw [(hd s).norm_sq.deriv]
    calc
      ‖2*inner ℝ (F s) (F' s)‖ = 2*|inner ℝ (F s) (F' s)| := by
        rw [norm_mul,Real.norm_eq_abs,abs_of_pos (by norm_num : (0:ℝ)<2),Real.norm_eq_abs]
      _ ≤ 2*(‖F s‖*‖F' s‖) := mul_le_mul_of_nonneg_left (abs_real_inner_le_norm _ _) (by norm_num)
      _ ≤ H s := by dsimp [H]; nlinarith [sq_nonneg (‖F s‖-‖F' s‖)]
  have hpoint (s : ℝ) (hs : s∈Icc t (t+1)) :
      g t≤g s+(∫u in t..t+1,H u) := by
    have hdist := norm_sub_le_integral_of_norm_deriv_le_of_le hs.1
      hgc.continuousOn (fun u _=>(hd u).norm_sq.differentiableAt.differentiableWithinAt)
      (Filter.Eventually.of_forall fun u _=>hderiv u) (hHc.intervalIntegrable t s)
    have hmono := intervalIntegral.integral_mono_interval (μ:=volume) (le_refl t) hs.1 hs.2
      (Filter.Eventually.of_forall hHpos) (hHc.intervalIntegrable t (t+1))
    have habs : g t-g s≤‖g s-g t‖ := by rw [Real.norm_eq_abs,abs_sub_comm]; exact le_abs_self _
    linarith
  have hi := intervalIntegral.integral_mono_on (show t≤t+1 by linarith)
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ=>g t) volume t (t+1))
    ((hgc.add continuous_const).intervalIntegrable t (t+1)) hpoint
  change (∫s in t..t+1,g t)≤(∫s in t..t+1,g s+(∫u in t..t+1,H u)) at hi
  rw [intervalIntegral.integral_const,
    intervalIntegral.integral_add (hgc.intervalIntegrable t (t+1)) intervalIntegrable_const,
    intervalIntegral.integral_const] at hi
  simp only [add_sub_cancel_left,one_smul] at hi
  have he : (∫u in t..t+1,H u)=
      (∫u in t..t+1,‖F u‖^2)+(∫u in t..t+1,‖F' u‖^2) :=
    intervalIntegral.integral_add ((hF.norm.pow 2).intervalIntegrable t (t+1))
      ((hF'.norm.pow 2).intervalIntegrable t (t+1))
  rw [he] at hi
  dsimp [g] at hi
  linarith

/-- Disjoint unit intervals under separated samples fit in one extended interval. -/
theorem sum_local_integrals_le {ι : Type*} (s : Finset ι) (τ : ι→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hsep : ∀i∈s,∀j∈s,i≠j→1≤|τ i-τ j|)
    (f : ℝ→ℝ) (hf : Continuous f) (hfpos : ∀t,0≤f t) :
    (∑i∈s,∫t in τ i..τ i+1,f t)≤∫t in a..b+1,f t := by
  by_cases hs : s.Nonempty
  · have hab : a≤b+1 := by obtain ⟨i,hi⟩:=hs; have ht:=hτ i hi; linarith
    have hdis : Set.Pairwise (↑s) (fun i j=>Disjoint (Ioc (τ i) (τ i+1)) (Ioc (τ j) (τ j+1))) := by
      intro i hi j hj hij
      have hh := hsep i hi j hj hij
      rcases le_total (τ i) (τ j) with he|he
      · apply Set.Ioc_disjoint_Ioc_of_le
        rw [abs_of_nonpos (sub_nonpos.mpr he)] at hh
        linarith
      · apply Disjoint.symm
        apply Set.Ioc_disjoint_Ioc_of_le
        rw [abs_of_nonneg (sub_nonneg.mpr he)] at hh
        linarith
    have hsub : (⋃i∈s,Ioc (τ i) (τ i+1))⊆Ioc a (b+1) := by
      intro t ht
      obtain ⟨i,hi,ht⟩ := Set.mem_iUnion₂.mp ht
      have hh := hτ i hi
      exact ⟨hh.1.trans_lt ht.1,ht.2.trans (by linarith)⟩
    have he (i : ι) : (∫t in τ i..τ i+1,f t)=(∫t in Ioc (τ i) (τ i+1),f t) :=
      intervalIntegral.integral_of_le (by linarith)
    simp_rw [he]
    rw [intervalIntegral.integral_of_le hab,
      ←integral_biUnion_finset s (fun _ _=>measurableSet_Ioc) hdis
        (fun i _=>(hf.integrableOn_Icc).mono_set Ioc_subset_Icc_self)]
    exact setIntegral_mono_set (hf.integrableOn_Icc.mono_set Ioc_subset_Icc_self)
      (Filter.Eventually.of_forall hfpos) (Filter.Eventually.of_forall hsub)
  · simp only [Finset.not_nonempty_iff_eq_empty.mp hs,Finset.sum_empty]
    exact intervalIntegral.integral_nonneg_of_forall (by linarith) hfpos

/-- The local FTC estimate summed over separated arbitrary real samples. -/
theorem separated_energy_le_integrals {ι : Type*} (s : Finset ι) (τ : ι→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hsep : ∀i∈s,∀j∈s,i≠j→1≤|τ i-τ j|)
    (F F' : ℝ→ℂ) (hF : Continuous F) (hF' : Continuous F')
    (hd : ∀t,HasDerivAt F (F' t) t) :
    (∑i∈s,‖F (τ i)‖^2)≤
      2*(∫t in a..b+1,‖F t‖^2)+(∫t in a..b+1,‖F' t‖^2) := by
  calc
    _ ≤ ∑i∈s,(2*(∫t in τ i..τ i+1,‖F t‖^2)+(∫t in τ i..τ i+1,‖F' t‖^2)) :=
      Finset.sum_le_sum fun i _=>point_energy_le_local_integral F F' hF hF' hd (τ i)
    _ = 2*(∑i∈s,∫t in τ i..τ i+1,‖F t‖^2)+(∑i∈s,∫t in τ i..τ i+1,‖F' t‖^2) := by
      rw [Finset.sum_add_distrib,Finset.mul_sum]
    _ ≤ _ := add_le_add
      (mul_le_mul_of_nonneg_left
        (sum_local_integrals_le s τ a b hab hτ hsep _ (hF.norm.pow 2) (fun _=>sq_nonneg _))
        (by norm_num))
      (sum_local_integrals_le s τ a b hab hτ hsep _ (hF'.norm.pow 2) (fun _=>sq_nonneg _))

/-- The differentiated polynomial has the actual coefficients i log(n)c(n). -/
theorem polynomial_hasDerivAt (Y : ℕ) (c : ℕ→ℂ) (t : ℝ) :
    HasDerivAt (polynomial Y c)
      (polynomial Y (fun n=>c n*(Complex.I*(Real.log (n:ℝ):ℂ))) t) t := by
  unfold polynomial
  apply HasDerivAt.fun_sum
  intro n hn
  unfold Artin.MarkedReplacement.archimedeanPhase
  have h := ((((hasDerivAt_id t).mul_const (Real.log (n:ℝ))).ofReal_comp).const_mul Complex.I).cexp.const_mul (c n)
  convert h using 1 <;> simp only [id_eq,one_mul,Complex.ofReal_mul] <;> ring

/-- Multiplication by the logarithmic derivative costs at most log(Y)^2 in energy. -/
theorem derivative_coefficient_energy_le (Y : ℕ) (c : ℕ→ℂ) :
    (∑n∈Finset.Icc 1 Y,‖c n*(Complex.I*(Real.log (n:ℝ):ℂ))‖^2)≤
      (Real.log (Y:ℝ))^2*(∑n∈Finset.Icc 1 Y,‖c n‖^2) := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro n hn
  have hn' := Finset.mem_Icc.mp hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast hn'.1
  have hlog0 : 0≤Real.log (n:ℝ) := Real.log_nonneg (by exact_mod_cast hn'.1)
  have hlog : Real.log (n:ℝ)≤Real.log (Y:ℝ) :=
    Real.log_le_log hn0 (by exact_mod_cast hn'.2)
  rw [norm_mul,norm_mul,Complex.norm_I,one_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg hlog0,mul_pow]
  calc
    _ ≤ ‖c n‖^2*(Real.log (Y:ℝ))^2 :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlog0 hlog 2) (sq_nonneg _)
    _ = _ := mul_comm _ _

/-- A coefficient-independent separated mean square with explicit constants.
The only sample assumptions are their range and unit separation. -/
theorem separated_mean_square {ι : Type*} (s : Finset ι) (τ : ι→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hsep : ∀i∈s,∀j∈s,i≠j→1≤|τ i-τ j|)
    (Y : ℕ) (hY : 1≤Y) (c : ℕ→ℂ) :
    (∑i∈s,‖polynomial Y c (τ i)‖^2)≤
      (2+(Real.log (Y:ℝ))^2)*(b+1-a+4*(Y:ℝ)*(1+Real.log (Y:ℝ)))*
        (∑n∈Finset.Icc 1 Y,‖c n‖^2) := by
  let c' : ℕ→ℂ := fun n=>c n*(Complex.I*(Real.log (n:ℝ):ℂ))
  let R := b+1-a+4*(Y:ℝ)*(1+Real.log (Y:ℝ))
  have hR : 0≤R := by
    have hl : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast hY)
    dsimp [R]
    have : 0≤b+1-a := by linarith
    positivity
  calc
    _ ≤ 2*(∫t in a..b+1,‖polynomial Y c t‖^2)+
        (∫t in a..b+1,‖polynomial Y c' t‖^2) :=
      separated_energy_le_integrals s τ a b hab hτ hsep _ _
        (polynomial_continuous Y c) (polynomial_continuous Y c') (polynomial_hasDerivAt Y c)
    _ ≤ 2*(R*(∑n∈Finset.Icc 1 Y,‖c n‖^2))+
        R*(∑n∈Finset.Icc 1 Y,‖c' n‖^2) :=
      add_le_add (mul_le_mul_of_nonneg_left
        (continuous_mean_square a (b+1) (by linarith) Y hY c) (by norm_num))
        (continuous_mean_square a (b+1) (by linarith) Y hY c')
    _ ≤ 2*(R*(∑n∈Finset.Icc 1 Y,‖c n‖^2))+
        R*((Real.log (Y:ℝ))^2*(∑n∈Finset.Icc 1 Y,‖c n‖^2)) :=
      add_le_add_right (mul_le_mul_of_nonneg_left (derivative_coefficient_energy_le Y c) hR) _
    _ = _ := by dsimp [R]; ring

end Elliptic.Operator.DirichletMeanSquare
