module

public import Elliptic.Operator.RootRecordAccumulation
public import Elliptic.Operator.OriginalPathSupport

/-!
# Exact encoding of original paths by numerical root-transfer records

The source endpoint permutation is retained. The target permutation is
inverted, exactly matching the two modules' conventions. Only active
labels are encoded; the actual fresh-prime alphabet and its probability
weights remain unchanged in every good-state test.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordEncoding
open RootRecordGood RootRecordKernel RootLiteralGeometry OriginalPathWeights
open OriginalLifespanSchedule
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {Z : Type} [Fintype Z]
variable {P : Fin K→Type} [∀i,Fintype (P i)]

def encodeLists (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (a : PhysicalActiveLists P J) : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J :=
  fun i k=>⟨value i (a i k),hvalue i (a i k)⟩

def encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (r : OriginalPath (Fin K) Z P J N) : Record K J N R Q :=
  (fun j=>position (r.position j),fun j=>encodeLists value hvalue (r.active j),
    r.sourcePerm,fun e i=>(r.targetPerm e i).symm)

theorem encode_injective (position : Z→↥(integerPositionBox R))
    (hposition : Function.Injective position) (value : ∀i,P i→ℕ)
    (hvalue : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i)) :
    Function.Injective (encode (J:=J) (N:=N) position value hvalue) := by
  intro r s he
  apply OriginalPath.ext
  · funext j
    exact hposition (congrArg (fun rec : Record K J N R Q=>rec.1 j) he)
  · funext j i k
    apply hinj i
    exact congrArg (fun rec : Record K J N R Q=>(rec.2.1 j i k).val) he
  · exact congrArg (fun rec : Record K J N R Q=>rec.2.2.1) he
  · funext e i
    have hh := congrArg (fun rec : Record K J N R Q=>(rec.2.2.2 e i).symm) he
    simpa only [encode,Equiv.symm_symm] using hh

theorem crossEdgeBan_encode (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : ∀i,Function.Injective (value i)) (a b : PhysicalActiveLists P J) :
    sourceCrossEdgeBan (numericValue K Q) (encodeLists value hvalue a) (encodeLists value hvalue b) ↔
      sourceCrossEdgeBan value a b := by
  have he : sourceCrossEdgeLabels (numericValue K Q) (encodeLists value hvalue a)
      (encodeLists value hvalue b)=sourceCrossEdgeLabels value a b := by
    funext x
    rcases x with ⟨i,j|k⟩ <;> rfl
  unfold sourceCrossEdgeBan
  rw [he]
  apply and_congr _ Iff.rfl
  constructor
  · intro h i k
    exact hinj i (congrArg Fin.val (h i k))
  · intro h i k
    exact Fin.ext (congrArg (value i) (h i k))

theorem freshGood_encode (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (μ : ∀i,P i→ℝ) (d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (q : RootPhysicalCell.RootPoint) (z : ℤ×ℤ) (a : PhysicalActiveLists P J) :
    freshGood value μ d₀ Y L exponents q z (encodeLists value hvalue a) ↔
      sourceGood value μ d₀ Y L exponents q z a := Iff.rfl

theorem source_geometry_encode (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : ∀i,Function.Injective (value i)) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J)
    (q : RootPhysicalCell.RootPoint) :
    sourcePhysicalEdgeGeometry (numericValue K Q) (freshGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z (encodeLists value hvalue a) w (encodeLists value hvalue b) =
    sourcePhysicalEdgeGeometry value (sourceGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b := by
  have ha : sourcePhysicalEdgeAllowed (numericValue K Q) (freshGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ z (encodeLists value hvalue a) w (encodeLists value hvalue b) ↔
    sourcePhysicalEdgeAllowed value (sourceGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ z a w b := by
    simp only [sourcePhysicalEdgeAllowed,freshGood_encode,crossEdgeBan_encode value hvalue hinj]
    rfl
  unfold sourcePhysicalEdgeGeometry
  rw [propext ha]
  rfl

theorem geometry_encode (adjoint : Bool) (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : ∀i,Function.Injective (value i)) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J)
    (q : RootPhysicalCell.RootPoint) :
    freshGeometry adjoint value μ U V d₀ Y L exponents η ψ major σ
      z (encodeLists value hvalue a) w (encodeLists value hvalue b) q =
    geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b q := by
  cases adjoint
  · exact source_geometry_encode value hvalue hinj μ U V d₀ Y L exponents η ψ major σ z w a b q
  · exact congrArg star (source_geometry_encode value hvalue hinj μ U V d₀ Y L exponents η ψ major σ w z b a q)

theorem sourceLists_fin (r : OriginalPath (Fin K) Z P J N) (e : Fin N) :
    r.sourceLists e.val = fun i k=>r.active e.castSucc i (r.sourcePerm e i k) := by
  have hv : OriginalPath.visit (N:=N) e.val=e.castSucc := by
    apply Fin.ext
    exact Nat.min_eq_left e.isLt.le
  funext i k
  change r.active (OriginalPath.visit e.val) i (r.sourcePermAt e.val i k)=_
  rw [hv]
  simp only [OriginalPath.sourcePermAt,dite_eq_left e.isLt]

theorem targetLists_fin (r : OriginalPath (Fin K) Z P J N) (e : Fin N) :
    r.targetLists e.val = fun i k=>r.active e.succ i ((r.targetPerm e i).symm k) := by
  have hv : OriginalPath.visit (N:=N) (e.val+1)=e.succ := by
    apply Fin.ext
    exact Nat.min_eq_left (Nat.succ_le_of_lt e.isLt)
  funext i k
  change r.active (OriginalPath.visit (e.val+1)) i ((r.targetPermAt e.val i).symm k)=_
  rw [hv]
  simp only [OriginalPath.targetPermAt,dite_eq_left e.isLt]

theorem leftList_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (r : OriginalPath (Fin K) Z P J N) (e : Fin N) :
    leftList (encode position value hvalue r) e=encodeLists value hvalue (r.sourceLists e.val) := by
  rw [sourceLists_fin]
  rfl

theorem rightList_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (r : OriginalPath (Fin K) Z P J N) (e : Fin N) :
    rightList (encode position value hvalue r) e=encodeLists value hvalue (r.targetLists e.val) := by
  rw [targetLists_fin]
  rfl

theorem recordGeometry_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i))
    (r : OriginalPath (Fin K) Z P J N) (adjoint : Fin N→Bool)
    (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootPhysicalCell.RootPoint) :
    recordGeometry (encode position value hvalue r) adjoint value μ U V d₀ Y L exponents η ψ major σ q =
      ∏e : Fin N, geometry (adjoint e) value μ U V d₀ Y L exponents η ψ major σ
        (position (r.position e.castSucc)).val (r.sourceLists e.val)
        (position (r.position e.succ)).val (r.targetLists e.val) q := by
  unfold recordGeometry
  apply Finset.prod_congr rfl
  intro e he
  rw [edgeGeometry_eq,leftList_encode,rightList_encode]
  exact geometry_encode (adjoint e) value hvalue hinj μ U V d₀ Y L exponents η ψ major σ _ _ _ _ q

theorem normalization_eq (VM : Fin K→ℝ) (J N : ℕ) :
    normalization VM J N=OriginalLifespanSchedule.pathNormalization VM J N := rfl

theorem encoded_sum (position : Z→↥(integerPositionBox R))
    (hposition : Function.Injective position) (value : ∀i,P i→ℕ)
    (hvalue : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i))
    (paths : Finset (OriginalPath (Fin K) Z P J N)) (F : Record K J N R Q→ℂ) :
    (∑ rec∈paths.image (encode position value hvalue),F rec)=
      ∑ r∈paths,F (encode position value hvalue r) :=
  Finset.sum_image (fun _ _ _ _ he=>encode_injective position hposition value hvalue hinj he)

def originalGeometry (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (adjoint : ℕ→Bool)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (q : RootPhysicalCell.RootPoint)
    (j : ℕ) (z : Z) (a : PhysicalActiveLists P J) (w : Z) (b : PhysicalActiveLists P J) : ℂ :=
  geometry (adjoint j) value μ U V d₀ Y L exponents η ψ major σ
    (position z).val a (position w).val b q

theorem recordGeometry_encode_range (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i))
    (r : OriginalPath (Fin K) Z P J N) (adjoint : ℕ→Bool)
    (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootPhysicalCell.RootPoint) :
    recordGeometry (encode position value hvalue r) (fun e=>adjoint e.val) value μ
      U V d₀ Y L exponents η ψ major σ q =
      ∏j∈Finset.range N, originalGeometry position value μ adjoint U V d₀ Y L exponents η ψ major σ q
        j (r.positionAt j) (r.sourceLists j) (r.positionAt (j+1)) (r.targetLists j) := by
  rw [recordGeometry_encode position value hvalue hinj,
    ←Fin.prod_univ_eq_prod_range]
  apply Finset.prod_congr rfl
  intro e he
  have hv : OriginalPath.visit (N:=N) e.val=e.castSucc := by
    apply Fin.ext
    exact Nat.min_eq_left e.isLt.le
  have hv' : OriginalPath.visit (N:=N) (e.val+1)=e.succ := by
    apply Fin.ext
    exact Nat.min_eq_left (Nat.succ_le_of_lt e.isLt)
  simp only [originalGeometry,OriginalPath.positionAt,hv,hv']

/-- The entire original boundary summand, including both endpoint
vectors and exact normalization, agrees with the encoded record. -/
theorem boundaryFactor_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q) (hinj : ∀i,Function.Injective (value i))
    (r : OriginalPath (Fin K) Z P J N) (adjoint : ℕ→Bool)
    (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootPhysicalCell.RootPoint)
    (VM : Fin K→ℝ) (a b : CanonicalBoundaryAssembly.BoundaryIndex (Fin K) Z P J→ℂ) :
    r.boundaryFactor (originalGeometry position value μ adjoint U V d₀ Y L exponents η ψ major σ q) VM a b =
      star (a (r.positionAt 0,r.activeAt 0)) * (normalization VM J N:ℂ) *
        recordGeometry (encode position value hvalue r) (fun e=>adjoint e.val) value μ
          U V d₀ Y L exponents η ψ major σ q * b (r.positionAt N,r.activeAt N) := by
  rw [recordGeometry_encode_range position value hvalue hinj,normalization_eq]
  rfl

end Elliptic.Operator.RootRecordEncoding
