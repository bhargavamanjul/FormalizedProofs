module

public import Elliptic.Operator.ScheduledActiveBirths

/-!
# Exact active-run normalization of an actual physical schedule

The initial list starts J+1 runs. The source target/source exclusion
starts exactly one new run at each of the N edges, whether its target
is freshly drawn or promoted. Summing actual lifespan run counts thus
gives J+1+N, with no abstract run-count premise.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ScheduledPhysicalPath
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I]
variable {P : I → Type}
variable {Line : ∀i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀i p, Line i p}
variable (d : ScheduledPhysicalPath anchor N J B)

/-- The literal labels whose maximal active runs begin at this visit. -/
def runStarts (i : I) (j : ℕ) : Finset (P i) :=
  (d.primes i).filter (fun p => (d.lifespan i p).runStart j)

theorem runStarts_zero (i : I) :
    d.runStarts i 0 = Finset.univ.image (d.active 0 i) := by
  simpa only [runStarts,PrimeLifespan.runStart_zero_iff,LifespanSchedule.activeBirths]
    using d.activeBirths_zero i

/-- A fresh target and a promoted target each start exactly one new run.
The same literal source exclusion treats both cases. -/
theorem runStarts_succ (j : ℕ) (hj : j<N) (i : I)
    (hnew : ∀k, d.targetPrime j i ≠ d.active j i k) :
    d.runStarts i (j+1) = {d.targetPrime j i} := by
  ext p
  simp only [runStarts,Finset.mem_filter,PrimeLifespan.runStart,Finset.mem_singleton]
  constructor
  · intro hp
    exact d.newly_active_eq_target j hj i p hp.1 hp.2.1 hp.2.2
  · intro hp
    subst p
    exact ⟨(d.targetPrime_active_next j hj i).1,
      (d.targetPrime_active_next j hj i).2,d.targetPrime_not_active j hj i hnew⟩

theorem runStarts_zero_card (i : I) : (d.runStarts i 0).card=J+1 := by
  rw [d.runStarts_zero,Finset.card_image_of_injective _ (d.active_distinct 0 (Nat.zero_le N) i)]
  simp

theorem runStarts_succ_card (j : ℕ) (hj : j<N) (i : I)
    (hnew : ∀k, d.targetPrime j i ≠ d.active j i k) :
    (d.runStarts i (j+1)).card=1 := by
  rw [d.runStarts_succ j hj i hnew,Finset.card_singleton]

/-- The exact exponent of the group normalizer in the primewise lifespan
coefficient, deduced from the actual active lists and edge targets. -/
theorem activeRunCount_sum (i : I)
    (hnew : ∀j, j<N → ∀k, d.targetPrime j i ≠ d.active j i k) :
    (∑p∈d.primes i, (d.lifespan i p).activeRunCount) = J+1+N := by
  simp only [PrimeLifespan.activeRunCount]
  rw [Finset.sum_comm]
  have hcount (j : ℕ) : (∑p∈d.primes i,
      if (d.lifespan i p).runStart j then 1 else 0 : ℕ) = (d.runStarts i j).card := by
    simp only [Finset.sum_boole,Nat.cast_id,runStarts]
  simp_rw [hcount]
  rw [Finset.sum_range_succ',d.runStarts_zero_card]
  have hs : (∑j∈Finset.range N, (d.runStarts i (j+1)).card)=N := by
    calc
      _ = ∑_j∈Finset.range N, 1 := Finset.sum_congr rfl
        (fun j hj => d.runStarts_succ_card j (Finset.mem_range.mp hj) i
          (hnew j (Finset.mem_range.mp hj)))
      _ = N := by simp
  rw [hs]
  omega

/-- Exact normalization holds in any commutative coefficient monoid. -/
theorem prod_pow_activeRunCount {R : Type*} [CommMonoid R] (i : I) (b : R)
    (hnew : ∀j, j<N → ∀k, d.targetPrime j i ≠ d.active j i k) :
    (∏p∈d.primes i, b^(d.lifespan i p).activeRunCount) = b^(J+1+N) := by
  rw [Finset.prod_pow_eq_pow_sum,d.activeRunCount_sum i hnew]

/-- The source inverse-V factors agree exactly with the path exponent. -/
theorem prod_inverse_pow_activeRunCount {R : Type*} [CommMonoid R] [Inv R]
    (i : I) (V : R)
    (hnew : ∀j, j<N → ∀k, d.targetPrime j i ≠ d.active j i k) :
    (∏p∈d.primes i, (V⁻¹)^(d.lifespan i p).activeRunCount) = (V⁻¹)^(J+1+N) :=
  d.prod_pow_activeRunCount i (V⁻¹) hnew

/-- The literal source cross-edge ban supplies the exclusion hypothesis
for every group, so the exponent identity applies on original support. -/
theorem activeRunCount_sum_of_crossEdgeBan (value : ∀i, P i → ℕ)
    (hban : ∀j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j)) (i : I) :
    (∑p∈d.primes i, (d.lifespan i p).activeRunCount)=J+1+N :=
  d.activeRunCount_sum i (fun j hj => d.target_not_active_of_crossEdgeBan value j (hban j hj) i)

end Elliptic.Operator.ScheduledPhysicalPath
