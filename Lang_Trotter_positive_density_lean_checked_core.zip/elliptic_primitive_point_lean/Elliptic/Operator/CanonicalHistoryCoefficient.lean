module

public import Elliptic.Operator.CanonicalHistoryFiber
public import Elliptic.Operator.CompatibleBirthDistinctness
public import Elliptic.Operator.ActualScheduleConstruction

/-!
# Coefficients of the actual restricted finite-key fibers

The finite-key restriction is compared with a complete compatible-history
fiber before the proved birth-order factorial cancellation is applied.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.CanonicalHistoryCoefficient
open scoped BigOperators
open ScheduledPhysicalPath CanonicalHistoryFiber
attribute [local instance] Classical.propDecidable
local instance canonicalCoefficientDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem initial_empty (d : ScheduledPhysicalPath anchor N J B) :
    ∀ i, (d.initialState.memory P Line J B i).size = 0 := fun _ => rfl

theorem compatible_final_empty (d : ScheduledPhysicalPath anchor N J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h) :
    ∀ i, (h.final.memory P Line J B i).size = 0 := by
  have hm := d.compatibleHistory_memory_empty ν V η q ρ geometry ⟨h,hc⟩
  intro i
  have hi := Finset.single_le_sum (fun j _ => Nat.zero_le ((h.final.memory P Line J B j).size))
    (Finset.mem_univ i)
  change (∑ j, (h.final.memory P Line J B j).size) = 0 at hm
  exact Nat.eq_zero_of_le_zero (hi.trans hm.le)

theorem sum_compatible_indicator {R : Type*} [AddCommMonoid R]
    (d : ScheduledPhysicalPath anchor N J B)
    (W : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState → R) :
    (∑ h, if d.Compatible ν V η q ρ geometry N 0 d.initialState h then W h else 0) =
      ∑ h : d.CompatibleHistory ν V η q ρ geometry, W h.val := by
  rw [Finset.sum_ite]
  simp only [Finset.sum_const_zero,add_zero]
  exact Finset.sum_subtype _ (fun _ => by simp) _

/-- A compatible nonzero literal history supplies every scheduled
geometric support condition, at the actual pre-permutation lists. -/
theorem compatible_nonzero_geometry (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (hw : h.weight ≠ 0)
    (k : Fin N) :
    geometry k.val (d.position k.val) (d.sourceLists k.val)
      (d.position (k.val+1)) (d.targetLists k.val) ≠ 0 := by
  have hg := ActualHistoryObservation.nonzero_geometry_at ν V η q ρ anchor geometry
    N 0 s h (ActualHistoryObservation.allGeometryNonzero_of_weight_ne_zero
      ν V η q ρ anchor geometry N 0 s h hw) k
  have hv := (d.compatible_observed_states ν V η q ρ geometry N 0 (by omega) s hs h hc k.castSucc).1
  have he := ActualHistoryObservation.compatible_edgeAt ν V η q ρ anchor geometry d N 0 s h hc k
  dsimp only at hg
  simp only [Nat.zero_add,Fin.val_castSucc] at hv he hg
  change geometry k.val (d.position k.val)
    (fun i l => d.active k.val i (d.sourcePerm k.val i l)) (d.position (k.val+1))
    (fun i => Fin.lastCases (d.targetPrime k.val i)
      (fun l : Fin J => d.active k.val i (d.sourcePerm k.val i l.castSucc))) ≠ 0
  simpa only [hv.1,hv.2.1,he.1,he.2.1,he.2.2.2.2.2] using hg

/-- In particular the numerical cross-edge ban is derived from support,
not supplied afresh for the schedule recovered from the history. -/
theorem compatible_crossEdgeBan (value : ∀ i, P i → ℕ)
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (hw : h.weight ≠ 0) :
    ∀ j, j < N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j) := by
  intro j hj
  exact hgeometry j _ _ _ _
    (compatible_nonzero_geometry ν V η q ρ anchor geometry d s hs h hc hw ⟨j,hj⟩)

/-- One distinct-birth member certifies the whole compatible fiber. Thus
the restriction is removed only after proving its invariance, not from
the unqualified finite key alone. -/
theorem restricted_key_iff_compatible_of_witness (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (h₀ : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState)
    (hc₀ : d.Compatible ν V η q ρ geometry N 0 d.initialState h₀)
    (hd₀ : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N d.initialState h₀))
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState) :
    (Restricted ν V η q ρ anchor geometry value d.initialState h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry d.initialState h = d.canonicalKey) ↔
      d.Compatible ν V η q ρ geometry N 0 d.initialState h := by
  constructor
  · rintro ⟨hr,hk⟩
    exact compatible_of_key_eq ν V η q ρ anchor geometry value d d.initialState h
      hr.1 (initial_empty anchor d) hr.2 hk
  · intro hc
    refine ⟨⟨?_,compatible_final_empty ν V η q ρ anchor geometry d h hc⟩,?_⟩
    · exact (CompatibleBirthDistinctness.birthsDistinct_iff_of_compatible value ν V η q ρ
        anchor geometry d d.initialState h₀ h hc₀ hc).mp hd₀
    · exact ActualHistoryObservation.canonicalKey_of_compatible ν V η q ρ anchor geometry
        d d.initialState d.initialState_before h hc

/-- Exact coefficient of a globally restricted key fiber, with the whole
compatible birth-order fiber and all ghost factorials now accounted for. -/
theorem restricted_key_weight_sum (value : ∀ i, P i → ℕ)
    (d : ScheduledPhysicalPath anchor N J B)
    (h₀ : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState)
    (hc₀ : d.Compatible ν V η q ρ geometry N 0 d.initialState h₀)
    (hd₀ : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N d.initialState h₀)) :
    (∑ h, if Restricted ν V η q ρ anchor geometry value d.initialState h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry d.initialState h = d.canonicalKey
      then h.weight else 0) = d.summedCoefficientProduct ν V η q ρ geometry N 0 := by
  simp_rw [restricted_key_iff_compatible_of_witness ν V η q ρ anchor geometry value d h₀ hc₀ hd₀]
  rw [sum_compatible_indicator]
  exact d.compatibleHistory_weight_sum ν V η q ρ geometry

/-- The complete primewise coefficient for the actual selected key fiber,
including initial mass, geometry and endpoint permutation normalization. -/
theorem restricted_key_complete_coefficient (value : ∀ i, P i → ℕ)
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (d : ScheduledPhysicalPath anchor N J B)
    (h₀ : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState)
    (hc₀ : d.Compatible ν V η q ρ geometry N 0 d.initialState h₀)
    (hd₀ : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N d.initialState h₀))
    (hw₀ : h₀.weight ≠ 0)
    (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0) (hV : ∀ i, V i ≠ 0)
    (hν : ∀ i p, p ∈ d.primes i → V i * ν i p = μ i p) :
    (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ) *
      (∑ h, if Restricted ν V η q ρ anchor geometry value d.initialState h ∧
        ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry d.initialState h = d.canonicalKey
        then h.weight else 0) =
    (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
      ∏ i, ((∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
        (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t => d.retained i p = anchor (d.position t) i p) j) : ℝ) : ℂ) := by
  simp_rw [restricted_key_iff_compatible_of_witness ν V η q ρ anchor geometry value d h₀ hc₀ hd₀]
  rw [sum_compatible_indicator]
  exact d.compatibleHistory_complete_coefficient_of_crossEdgeBan ν V η q ρ geometry
    value μ hρ hV hν (compatible_crossEdgeBan ν V η q ρ anchor geometry value hgeometry
      d d.initialState d.initialState_before h₀ hc₀ hw₀)

/-- The independently specified selected coefficient of one finite key. -/
def keyWeightSum (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (k : CanonicalHistoryKey I Z P J N) : ℂ :=
  ∑ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
    if Restricted ν V η q ρ anchor geometry value s h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = k
    then h.weight else 0

theorem sum_keyWeightSum (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    (∑ k : CanonicalHistoryKey I Z P J N, keyWeightSum ν V η q ρ anchor geometry value s k) =
      ∑ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
        if Restricted ν V η q ρ anchor geometry value s h then h.weight else 0 := by
  unfold keyWeightSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro h _
  by_cases hr : Restricted ν V η q ρ anchor geometry value s h <;> simp [hr]

/-- Empty or zero-coefficient fibers contribute zero. Existence of a
nonzero selected member is the only prerequisite for extracting a path. -/
theorem keyWeightSum_zero (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (k : CanonicalHistoryKey I Z P J N)
    (hn : ¬ ∃ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
      Restricted ν V η q ρ anchor geometry value s h ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = k ∧ h.weight ≠ 0) :
    keyWeightSum ν V η q ρ anchor geometry value s k = 0 := by
  apply Finset.sum_eq_zero
  intro h _
  split_ifs with hh
  · by_contra hw
    exact hn ⟨h,hh.1,hh.2,hw⟩
  · rfl

/-- A complete schedule and its exact key coefficient are obtained from
an actual nonzero selected history. No schedule or compatibility assertion
is a premise of this endpoint. -/
theorem exists_schedule_keyWeightSum (value : ∀ i, P i → ℕ)
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hr : Restricted ν V η q ρ anchor geometry value s h) (hw : h.weight ≠ 0) :
    ∃ d : ScheduledPhysicalPath anchor N J B,
      d.initialState = s ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ∧
      d.ActiveBirthAnchored ∧
      keyWeightSum ν V η q ρ anchor geometry value s
        (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h) =
        d.summedCoefficientProduct ν V η q ρ geometry N 0 := by
  obtain ⟨d,hs,hc,hi,hk,ha⟩ := ActualScheduleConstruction.exists_schedule_of_weight_ne_zero
    ν V η q ρ anchor geometry value N hgeometry s h hr.1 hinitial hr.2 hw
  refine ⟨d,hi,hk,ha,?_⟩
  subst s
  rw [hk]
  exact restricted_key_weight_sum ν V η q ρ anchor geometry value d h hc hr.1

/-- The same actual key fiber has the complete primewise coefficient,
including the true initial measure. Both support properties are proved
for the oriented source geometry; no counting estimate is used here. -/
theorem exists_schedule_complete_keyWeightSum (value : ∀ i, P i → ℕ)
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hr : Restricted ν V η q ρ anchor geometry value s h) (hw : h.weight ≠ 0)
    (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0) (hV : ∀ i, V i ≠ 0)
    (hν : ∀ i p, V i * ν i p = μ i p) :
    ∃ d : ScheduledPhysicalPath anchor N J B,
      d.initialState = s ∧
      ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ∧
      d.ActiveBirthAnchored ∧
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) *
        keyWeightSum ν V η q ρ anchor geometry value s
          (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h) =
      (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
        ∏ i, ((∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
          (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
            (fun t => d.retained i p = anchor (d.position t) i p) j) : ℝ) : ℂ) := by
  obtain ⟨d,hs,hc,hi,hk,ha⟩ := ActualScheduleConstruction.exists_schedule_of_weight_ne_zero
    ν V η q ρ anchor geometry value N hshared s h hr.1 hinitial hr.2 hw
  refine ⟨d,hi,hk,ha,?_⟩
  subst s
  rw [hk]
  exact restricted_key_complete_coefficient ν V η q ρ anchor geometry value hban d h hc hr.1 hw
    μ hρ hV (fun i p _ => hν i p)

/-- Finite keys containing an actual nonzero selected summand. This does
not ask whether a formal schedule has already been supplied. -/
def NonzeroKey (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (k : CanonicalHistoryKey I Z P J N) : Prop :=
  ∃ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
    Restricted ν V η q ρ anchor geometry value s h ∧
    ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = k ∧ h.weight ≠ 0

/-- Full finite reindexing of the actual restricted signed history sum.
Exactly one representative schedule is chosen per nonzero finite key;
unused raw schedule data cannot create overcounting. -/
theorem exists_schedule_family_sum (value : ∀ i, P i → ℕ)
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0) :
    ∃ D : {k : CanonicalHistoryKey I Z P J N // NonzeroKey ν V η q ρ anchor geometry value s k} →
        ScheduledPhysicalPath anchor N J B,
      (∀ k, (D k).initialState = s ∧ (D k).canonicalKey = k.val ∧
        (D k).ActiveBirthAnchored ∧ keyWeightSum ν V η q ρ anchor geometry value s k.val =
          (D k).summedCoefficientProduct ν V η q ρ geometry N 0) ∧
      (∑ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
        if Restricted ν V η q ρ anchor geometry value s h then h.weight else 0) =
        ∑ k, (D k).summedCoefficientProduct ν V η q ρ geometry N 0 := by
  have hex : ∀ k : {k : CanonicalHistoryKey I Z P J N // NonzeroKey ν V η q ρ anchor geometry value s k},
      ∃ d : ScheduledPhysicalPath anchor N J B,
        d.initialState = s ∧ d.canonicalKey = k.val ∧ d.ActiveBirthAnchored ∧
        keyWeightSum ν V η q ρ anchor geometry value s k.val =
          d.summedCoefficientProduct ν V η q ρ geometry N 0 := by
    intro k
    obtain ⟨h,hr,hk,hw⟩ := k.property
    obtain ⟨d,hi,hkd,ha,hcoef⟩ := exists_schedule_keyWeightSum
      ν V η q ρ anchor geometry value hshared s hinitial h hr hw
    exact ⟨d,hi,hkd.symm.trans hk,ha,by simpa only [hk] using hcoef⟩
  choose D hD using hex
  refine ⟨D,hD,?_⟩
  rw [← sum_keyWeightSum ν V η q ρ anchor geometry value s]
  calc
    _ = ∑ k : CanonicalHistoryKey I Z P J N,
        if NonzeroKey ν V η q ρ anchor geometry value s k
        then keyWeightSum ν V η q ρ anchor geometry value s k else 0 := by
      apply Finset.sum_congr rfl
      intro k _
      by_cases hk : NonzeroKey ν V η q ρ anchor geometry value s k
      · simp only [hk,ite_true]
      · simp only [hk,ite_false]
        exact keyWeightSum_zero ν V η q ρ anchor geometry value s k hk
    _ = ∑ k : {k : CanonicalHistoryKey I Z P J N // NonzeroKey ν V η q ρ anchor geometry value s k},
        keyWeightSum ν V η q ρ anchor geometry value s k.val := by
      rw [Finset.sum_ite]
      simp only [Finset.sum_const_zero,add_zero]
      exact Finset.sum_subtype _ (fun _ => by simp) _
    _ = _ := by
      apply Finset.sum_congr rfl
      intro k _
      exact (hD k).2.2.2

end Elliptic.Operator.CanonicalHistoryCoefficient
