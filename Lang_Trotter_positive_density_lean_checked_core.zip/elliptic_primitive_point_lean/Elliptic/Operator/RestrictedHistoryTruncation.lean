module

public import Elliptic.Operator.MemoryTruncationBound

/-!
# Truncation before removing global history restrictions

The multiplier may depend on the entire dependent choice history. In particular
it need not be a product of local projections. Absolute values are taken before
summing histories, so no cancellation of the unrestricted word is used.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

namespace ChoiceOperation
variable {X : Type*}

def selectedHistorySum (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X)
    (χ : History ops x → ℂ) : ℂ :=
  ∑ h : History ops x, χ h * h.weight * F h.final

def selectedCutoffHistorySum (size : X → ℕ) (T : ℕ)
    (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X)
    (χ : History ops x → ℂ) : ℂ :=
  ∑ h : History ops x, if h.peakSize size ≤ T then χ h * h.weight * F h.final else 0

theorem selected_sub_cutoff_eq_tail (size : X → ℕ) (T : ℕ)
    (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X)
    (χ : History ops x → ℂ) :
    selectedHistorySum ops F x χ - selectedCutoffHistorySum size T ops F x χ =
      ∑ h : History ops x, if T < h.peakSize size then χ h * h.weight * F h.final else 0 := by
  unfold selectedHistorySum selectedCutoffHistorySum
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro h hh
  by_cases hp : h.peakSize size ≤ T
  · simp [hp, Nat.not_lt.mpr hp]
  · simp [hp, Nat.lt_of_not_ge hp]

/-- The same concrete positive majorant controls every bounded multiplier
on complete histories, uniformly in that multiplier. -/
theorem norm_selected_sub_cutoff_le_doubledBirthWord
    (size : X → ℕ) (T S : ℕ) (ops : List (ChoiceOperation X))
    (hstep : ∀ O ∈ ops, ∀ x (c : O.ValidChoice x),
      size (O.output x c.val c.property) ≤
        size x + O.ghostBirths x c.val + O.stores x c.val)
    (F : X → ℂ) (x : X) (χ : History ops x → ℂ) (hχ : ∀ h, ‖χ h‖ ≤ 1)
    (hzero : size x=0) (hstores : ∀ h : History ops x, h.stores≤S) (hST : S≤T) :
    ‖selectedHistorySum ops F x χ - selectedCutoffHistorySum size T ops F x χ‖ ≤
      ((2:ℝ)^(T-S))⁻¹ * doubledBirthWord ops (fun y => ‖F y‖) x := by
  rw [selected_sub_cutoff_eq_tail, doubledBirthWord_eq_history_sum, Finset.mul_sum]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro h hh
  by_cases hp : T < h.peakSize size
  · simp only [hp, ↓reduceIte]
    have hg := h.ghostBirths_large_of_peak size ops hstep x T S hzero (hstores h) hST hp
    have hpowers : (2:ℝ)^(T-S) ≤ (2:ℝ)^h.ghostBirths :=
      pow_le_pow_right₀ (by norm_num) hg.le
    have hdiv : (1:ℝ) ≤ ((2:ℝ)^(T-S))⁻¹ * (2:ℝ)^h.ghostBirths :=
      (one_le_inv_mul₀ (by positivity)).mpr hpowers
    calc
      _ = ‖χ h‖ * (‖h.weight‖ * ‖F h.final‖) := by rw [norm_mul, norm_mul]; ring
      _ ≤ 1 * (‖h.weight‖ * ‖F h.final‖) :=
        mul_le_mul_of_nonneg_right (hχ h) (by positivity)
      _ ≤ (((2:ℝ)^(T-S))⁻¹ * (2:ℝ)^h.ghostBirths) *
          (‖h.weight‖ * ‖F h.final‖) :=
        mul_le_mul_of_nonneg_right hdiv (by positivity)
      _ = _ := by ring
  · simp only [hp, ↓reduceIte, norm_zero]
    positivity

/-- Any global predicate is permitted, including distinctness of birth
labels once that predicate is instantiated on actual choices. -/
theorem history_indicator_norm_le_one (ops : List (ChoiceOperation X)) (x : X)
    (R : History ops x → Prop) (h : History ops x) :
    ‖(if R h then (1:ℂ) else 0)‖ ≤ 1 := by split_ifs <;> norm_num

end ChoiceOperation

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

theorem physical_selected_memory_truncation_bound
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N T : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (χ : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s → ℂ)
    (hχ : ∀ h, ‖χ h‖ ≤ 1)
    (hempty : physicalMemorySize s=0) (hT : Fintype.card I*N≤T) :
    ‖ChoiceOperation.selectedHistorySum (physicalMemoryOperations ν V η q ρ anchor geometry N) F s χ -
      ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) F s χ‖ ≤
      ((2:ℝ)^(T-Fintype.card I*N))⁻¹ *
        ChoiceOperation.doubledBirthWord
          (physicalMemoryOperations ν V η q ρ anchor geometry N) (fun y => ‖F y‖) s := by
  apply ChoiceOperation.norm_selected_sub_cutoff_le_doubledBirthWord
    physicalMemorySize T (Fintype.card I*N) _ _ F s χ hχ hempty _ hT
  · exact memoryOperationsFrom_step_size physicalMemorySize _ _
      (fun _ s c => physicalGhostOperation_size ν V _ _ ρ anchor s c)
      (fun _ s c => physicalEdgeOperation_size ν V ρ anchor _ s c) 0 N
  · exact physical_history_stores_le ν V η q ρ anchor geometry N s

/-- Both constants are derived from the literal choices. The selector is
quantified after all constants and can depend on the whole history. -/
theorem physical_selected_memory_truncation_explicit_bound
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ Q Vmax s G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N T : ℕ) (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (χ : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) m → ℂ)
    (hν : ∀ i p,0≤ν i p) (hs : ∀ i,(∑ p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤q j) (hqQ : ∀ j,q j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hVmax : ∀ i,V i≤Vmax)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (hF : ∀ t,‖F t‖≤physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) t)
    (hχ : ∀ h, ‖χ h‖ ≤ 1)
    (hempty : physicalMemorySize m=0) (hT : Fintype.card I*N≤T) :
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    ‖ChoiceOperation.selectedHistorySum (physicalMemoryOperations ν V η q ρ anchor geometry N) F m χ -
      ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) F m χ‖ ≤
      ((2:ℝ)^(T-Fintype.card I*N))⁻¹ * (Cghost^(N+1)*Cedge^N) := by
  dsimp only
  have htail := physical_selected_memory_truncation_bound ν V η q ρ anchor geometry N T m F χ hχ hempty hT
  have hword := physical_doubledBirthWord_le ν V η q ρ Q Vmax s G anchor geometry N m
    (fun t => ‖F t‖) hν hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0 hVmax hG hgeometry hF
  have hw : physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) m = 1 := by
    change (ghostSchurWeight ρ Q (2*Vmax))^physicalMemorySize m=1
    rw [hempty,pow_zero]
  simp only [hw,mul_one] at hword
  exact htail.trans (mul_le_mul_of_nonneg_left hword (by positivity))

end Elliptic.Operator
