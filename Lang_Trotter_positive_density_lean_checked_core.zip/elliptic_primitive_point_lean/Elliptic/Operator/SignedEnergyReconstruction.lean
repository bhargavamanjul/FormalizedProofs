module
public import Elliptic.Operator.SignedPhysicalPairSquare
public import Elliptic.Operator.SignedMajorCollision

/-! Reindexing the literal cofactor energy into fresh-label scalar sums.
The final finite inequality retains the normalization explicitly. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedEnergyReconstruction
open scoped BigOperators ComplexConjugate
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDyadicCauchy
open SignedPhysicalPairBridge SignedMajorCollision
attribute [local instance] Classical.propDecidable
local instance energyDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000
variable {K : ℕ}

theorem sum_four_subtypes (s t : Finset ℕ) (F : ℕ→ℕ→ℕ→ℕ→ℂ) :
    (∑m:s,∑n:t,∑r:s,∑q:t,F m.val n.val r.val q.val)=
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,F m n r q := by
  rw [Finset.sum_coe_sort s (fun m=>∑n:t,∑r:s,∑q:t,F m n.val r.val q.val)]
  apply Finset.sum_congr rfl
  intro m hm
  rw [Finset.sum_coe_sort t (fun n=>∑r:s,∑q:t,F m n r.val q.val)]
  apply Finset.sum_congr rfl
  intro n hn
  rw [Finset.sum_coe_sort s (fun r=>∑q:t,F m n r q.val)]
  apply Finset.sum_congr rfl
  intro r hr
  exact Finset.sum_coe_sort t (fun q=>F m n r q)

def scalarPairSum (b : Bands K) (x : ℝ) (s t : Finset ℕ)
    (F : LabelTuple b x→LabelTuple b x→ℕ→ℕ→ℕ→ℕ→ℂ) : ℂ :=
  ∑a : LabelTuple b x,∑c : LabelTuple b x,∑m∈s,∑n∈t,∑r∈s,∑q∈t,F a c m n r q

theorem record_pair_reindex (b : Bands K) (x : ℝ) (s t : Finset ℕ)
    (F : LabelTuple b x→LabelTuple b x→ℕ→ℕ→ℕ→ℕ→ℂ) :
    (∑r : Record b x s t,∑u : Record b x s t,F r.2.2 u.2.2 r.1.val r.2.1.val u.1.val u.2.1.val)=
      scalarPairSum b x s t F := by
  let e : (Record b x s t×Record b x s t) ≃
      (LabelTuple b x×LabelTuple b x×s×t×s×t) :=
    {toFun := fun ru=>(ru.1.2.2,ru.2.2.2,ru.1.1,ru.1.2.1,ru.2.1,ru.2.2.1)
     invFun := fun ac=>((ac.2.2.1,ac.2.2.2.1,ac.1),(ac.2.2.2.2.1,ac.2.2.2.2.2,ac.2.1))
     left_inv := fun _=>rfl
     right_inv := fun _=>rfl}
  rw [←Fintype.sum_prod_type (fun ru : Record b x s t×Record b x s t=>
    F ru.1.2.2 ru.2.2.2 ru.1.1.val ru.1.2.1.val ru.2.1.val ru.2.2.1.val)]
  rw [Fintype.sum_equiv e
    (fun ru : Record b x s t×Record b x s t=>F ru.1.2.2 ru.2.2.2 ru.1.1.val ru.1.2.1.val ru.2.1.val ru.2.2.1.val)
    (fun ac=>F ac.1 ac.2.1 ac.2.2.1.val ac.2.2.2.1.val ac.2.2.2.2.1.val ac.2.2.2.2.2.val)
    (fun _=>rfl)]
  simp only [Fintype.sum_prod_type,scalarPairSum]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro c hc
  exact sum_four_subtypes s t (F a c)

theorem scalarPairSum_add (b : Bands K) (x : ℝ) (s t : Finset ℕ)
    (F G : LabelTuple b x→LabelTuple b x→ℕ→ℕ→ℕ→ℕ→ℂ) :
    scalarPairSum b x s t (fun a c m n r q=>F a c m n r q+G a c m n r q)=
      scalarPairSum b x s t F+scalarPairSum b x s t G := by
  simp only [scalarPairSum,Finset.sum_add_distrib]

theorem scalarPairSum_const_mul (b : Bands K) (x : ℝ) (s t : Finset ℕ) (z : ℂ)
    (F : LabelTuple b x→LabelTuple b x→ℕ→ℕ→ℕ→ℕ→ℂ) :
    scalarPairSum b x s t (fun a c m n r q=>z*F a c m n r q)=z*scalarPairSum b x s t F := by
  simp only [scalarPairSum,Finset.mul_sum]

def scalarErrorSum (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  scalarPairSum b x s t (fun a c m n r q=>
    if (labelProduct b x a).Coprime (labelProduct b x c) then
      scalarError (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β else 0)

def scalarMajorSum (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  scalarPairSum b x s t (fun a c m n r q=>
    scalarMajor (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β)

def majorCollisionSum (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  scalarPairSum b x s t (fun a c m n r q=>
    if ¬(labelProduct b x a).Coprime (labelProduct b x c) then
      scalarMajor (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β else 0)

theorem majorCollisionSum_norm_le (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    ‖majorCollisionSum b x Y H s t η ψ α β‖≤
      ∑a : LabelTuple b x,∑c : LabelTuple b x,
        if ¬(labelProduct b x a).Coprime (labelProduct b x c) then
          pairAbsolute b x Y H s t η ψ α β a c else 0 := by
  unfold majorCollisionSum scalarPairSum
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro a ha
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro c hc
  by_cases h : ¬(labelProduct b x a).Coprime (labelProduct b x c)
  · simp only [ite_eq_left h]
    unfold pairAbsolute
    exact (norm_sum_le _ _).trans (Finset.sum_le_sum (fun m hm=>
      (norm_sum_le _ _).trans (Finset.sum_le_sum (fun n hn=>
        (norm_sum_le _ _).trans (Finset.sum_le_sum (fun r hr=>norm_sum_le _ _))))))
  · simp only [ite_eq_right h,Finset.sum_const_zero,norm_zero,le_refl]

def selectedCollision (b : Bands K) (x Y : ℝ) (s t : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  ∑r∈dyadicRecords b x Y s t η,∑u∈dyadicRecords b x Y s t η,
    if ¬(labelProduct b x r.2.2).Coprime (labelProduct b x u.2.2) then
      recordRaw b x Y s t η α β r u else 0

theorem record_coprime_reindex (b : Bands K) (x : ℝ) (s t : Finset ℕ) (z : ℂ)
    (F : LabelTuple b x→LabelTuple b x→ℕ→ℕ→ℕ→ℕ→ℂ) :
    (∑r : Record b x s t,∑u : Record b x s t,
      if (labelProduct b x r.2.2).Coprime (labelProduct b x u.2.2) then
        z*F r.2.2 u.2.2 r.1.val r.2.1.val u.1.val u.2.1.val else 0)=
      z*scalarPairSum b x s t (fun a c m n r q=>
        if (labelProduct b x a).Coprime (labelProduct b x c) then F a c m n r q else 0) := by
  rw [record_pair_reindex b x s t (fun a c m n r q=>
    if (labelProduct b x a).Coprime (labelProduct b x c) then z*F a c m n r q else 0),
    ←scalarPairSum_const_mul]
  congr 1
  funext a c m n r q
  split_ifs <;> simp only [mul_zero]

theorem coprimeMajor_eq_sub (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    scalarPairSum b x s t (fun a c m n r q=>
      if (labelProduct b x a).Coprime (labelProduct b x c) then
        scalarMajor (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β else 0)=
      scalarMajorSum b x Y H s t η ψ α β-majorCollisionSum b x Y H s t η ψ α β := by
  apply eq_sub_iff_add_eq.mpr
  rw [majorCollisionSum,←scalarPairSum_add]
  unfold scalarMajorSum
  congr 1
  funext a c m n r q
  by_cases h : (labelProduct b x a).Coprime (labelProduct b x c) <;> simp [h]

theorem energy_eq_scalar_sums (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hηreal : ∀t,conj (η t)=η t)
    (hflat : ∀a c : ℕ,η ((a:ℝ)/Y)≠0→η ((c:ℝ)/Y)≠0→ψ ((((a:ℤ)-c:ℤ):ℝ)/Y)=1) :
    ((∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2:ℝ):ℂ)=
      selectedCollision b x Y s t η α β+
        (massNormalization b x:ℂ)^2*scalarErrorSum b x Y H s t η ψ α β+
        (massNormalization b x:ℂ)^2*(scalarMajorSum b x Y H s t η ψ α β-
          majorCollisionSum b x Y H s t η ψ α β) := by
  rw [fiber_square_eq_collision_error_major b x Y H s t η ψ α β hdis hηreal hflat,
    record_coprime_reindex b x s t _ (fun a c m n r q=>
      scalarError (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β),
    record_coprime_reindex b x s t _ (fun a c m n r q=>
      scalarMajor (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β),coprimeMajor_eq_sub]
  rfl

theorem norm_add_mul_sub_le (u v z m c : ℂ) :
    ‖u+v+z*(m-c)‖≤‖u‖+‖v‖+‖z*m‖+‖z‖*‖c‖ := by
  have h1 := norm_add_le (u+v) (z*(m-c))
  have h2 := norm_add_le u v
  have h3 := mul_le_mul_of_nonneg_left (norm_sub_le m c) (norm_nonneg z)
  simp only [norm_mul] at h1 ⊢
  nlinarith

/-- The exact finite target for the remaining asymptotic estimates. -/
theorem energy_le_four_errors (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hηreal : ∀t,conj (η t)=η t)
    (hflat : ∀a c : ℕ,η ((a:ℝ)/Y)≠0→η ((c:ℝ)/Y)≠0→ψ ((((a:ℤ)-c:ℤ):ℝ)/Y)=1) :
    (∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2)≤
      ‖selectedCollision b x Y s t η α β‖+
      ‖(massNormalization b x:ℂ)^2*scalarErrorSum b x Y H s t η ψ α β‖+
      ‖(massNormalization b x:ℂ)^2*scalarMajorSum b x Y H s t η ψ α β‖+
      (massNormalization b x)^2*(∑a : LabelTuple b x,∑c : LabelTuple b x,
        if ¬(labelProduct b x a).Coprime (labelProduct b x c) then
          pairAbsolute b x Y H s t η ψ α β a c else 0) := by
  have he := energy_eq_scalar_sums b x Y H s t η ψ α β hdis hηreal hflat
  have hn := norm_add_mul_sub_le (selectedCollision b x Y s t η α β)
    ((massNormalization b x:ℂ)^2*scalarErrorSum b x Y H s t η ψ α β)
    ((massNormalization b x:ℂ)^2) (scalarMajorSum b x Y H s t η ψ α β)
    (majorCollisionSum b x Y H s t η ψ α β)
  rw [←he] at hn
  have hp : 0≤∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2 := by positivity
  simp only [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hp,norm_pow,sq_abs] at hn
  exact hn.trans (add_le_add le_rfl
    (mul_le_mul_of_nonneg_left (majorCollisionSum_norm_le b x Y H s t η ψ α β)
      (sq_nonneg _)))

end Elliptic.Operator.SignedEnergyReconstruction
