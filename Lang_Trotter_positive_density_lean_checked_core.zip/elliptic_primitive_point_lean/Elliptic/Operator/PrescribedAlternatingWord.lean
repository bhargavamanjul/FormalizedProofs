module

public import Elliptic.Operator.PhysicalPrescriptionSteps

/-! # Exact atom exponent in the chronological physical word

This is a positive sum over the original dependent operation choices. It
allows prescribed values to depend on the earlier registry and retains one
atom for every named birth, with N edge steps and N+1 ghost steps.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ChronologicalPrescription
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {X R : Type*} {w : X→ℝ} {Δ : ℝ}

/-- The literal alternating order G_j,E_j,...,G_(j+n). -/
def alternating (G E : ℕ→Step X R w Δ) : ℕ→ℕ→List (Step X R w Δ)
  | j,0 => [G j]
  | j,n+1 => G j::E j::alternating G E (j+1) n

/-- The certified list has exactly the original underlying operation word. -/
theorem operations_alternating (G E : ℕ→Step X R w Δ) (j n : ℕ) :
    operations (alternating G E j n)=
      memoryOperationsFrom (fun k=>(G k).operation) (fun k=>(E k).operation) j n := by
  induction n generalizing j with
  | zero => rfl
  | succ n ih => simp only [alternating,operations,List.map_cons,memoryOperationsFrom]; exact congrArg (fun l => (G j).operation::(E j).operation::l) (ih (j+1))

/-- Exact count of the named coordinates, including the final ghost visit. -/
theorem count_alternating (G E : ℕ→Step X R w Δ) (j n : ℕ) :
    count (alternating G E j n) =
      (∑k : Fin (n+1),(G (j+k.val)).count) + (∑k : Fin n,(E (j+k.val)).count) := by
  induction n generalizing j with
  | zero => simp [alternating,count]
  | succ n ih =>
      have hc : count (alternating G E j (n+1))=
          (G j).count+(E j).count+count (alternating G E (j+1) n) := by simp [alternating,count,Nat.add_assoc]
      rw [hc,ih,Fin.sum_univ_succ (f := fun k : Fin (n+1+1) => (G (j+k.val)).count),
        Fin.sum_univ_succ (f := fun k : Fin (n+1) => (E (j+k.val)).count)]
      simp only [Fin.val_zero,Fin.val_succ,Nat.add_zero]
      have he : ∀k : ℕ,j+1+k=j+(k+1) := fun k=>by omega
      simp only [he]
      omega

/-- Exact product of local constants; endpoint permutations are already
averaged inside each actual edge factor. -/
theorem factor_alternating (G E : ℕ→Step X R w Δ) (j n : ℕ) :
    factor (alternating G E j n) =
      (∏k : Fin (n+1),(G (j+k.val)).factor) * (∏k : Fin n,(E (j+k.val)).factor) := by
  induction n generalizing j with
  | zero => simp [alternating,factor]
  | succ n ih =>
      have hc : factor (alternating G E j (n+1))=
          (G j).factor*(E j).factor*factor (alternating G E (j+1) n) := by simp [alternating,factor,mul_assoc]
      rw [hc,ih,Fin.prod_univ_succ (f := fun k : Fin (n+1+1) => (G (j+k.val)).factor),
        Fin.prod_univ_succ (f := fun k : Fin (n+1) => (E (j+k.val)).factor)]
      simp only [Fin.val_zero,Fin.val_succ,Nat.add_zero]
      have he : ∀k : ℕ,j+1+k=j+(k+1) := fun k=>by omega
      simp only [he]
      ring

/-- Chronological source estimate before the elementary polynomial bounds
on explicit constants. Every named birth contributes one prime atom. -/
theorem alternating_history_sum_le (G E : ℕ→Step X R w Δ) (hΔ : 0≤Δ)
    (F : X→ℝ) (hF : ∀x,F x≤w x) (j n : ℕ) (x:X) (r:R) :
    (∑h : ChoiceOperation.History (operations (alternating G E j n)) x,
      if Allowed (alternating G E j n) x r h then ‖h.weight‖*F h.final else 0) ≤
      ((∏k : Fin (n+1),(G (j+k.val)).factor) * (∏k : Fin n,(E (j+k.val)).factor)) *
      Δ^((∑k : Fin (n+1),(G (j+k.val)).count)+(∑k : Fin n,(E (j+k.val)).count))*w x := by
  simpa only [factor_alternating,count_alternating] using
    history_sum_le (alternating G E j n) hΔ F hF x r

end Elliptic.Operator.ChronologicalPrescription
