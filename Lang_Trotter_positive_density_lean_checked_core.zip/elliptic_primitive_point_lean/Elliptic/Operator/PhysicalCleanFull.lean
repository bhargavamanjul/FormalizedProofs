module
public import Elliptic.Operator.PhysicalCleanOperator
public import Elliptic.Operator.PhysicalCleanEligible

/-! The actual clean physical bag-state operator, with the literal
source geometry, eligibility projections, shared-list and unchanged-bag
conditioning, and both endpoint permutation averages. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanFull
open scoped BigOperators SchwartzMap
open PhysicalCleanOperator PhysicalCleanLocalGeometry PhysicalCleanBlocks PhysicalCleanEligible
attribute [local instance] Classical.propDecidable
local instance physicalCleanFullDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1600000
variable {I : Type*} [Fintype I] {J : ℕ}

/-- The source good test is needed only at eligible physical endpoints
and at a pad in the actual dyad. This is a scalar Diophantine condition. -/
def FirstProjection (groups : I→Finset ℕ)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (u v r U W d₀ Y : ℝ) : Prop :=
  ∀z a,sourcePhysicalPositionAllowed u v r U W z→good z a→
    (∀i,Function.Injective (a i))→
    d₀≤(sourcePadProduct (fun _ p=>p.val) a:ℝ)→
    (sourcePadProduct (fun _ p=>p.val) a:ℝ)<2*d₀→
    ∃w,latticeDet z w=1 ∧ SourceGoodState.FirstGoodTest
      ((sourcePadProduct (fun _ p=>p.val) a:ℝ)*latticeTau r w/latticeTau r z) Y

/-- Full finite geometric support: all ineligible endpoints and inactive
pad dyads are literal zero entries, so their removal is lossless. -/
theorem source_bound
    (groups : I→Finset ℕ)
    (hprime : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j))
    (ν : I→ℕ→ℝ) (Cweight : I→ℝ) (hCweight : ∀i,0≤Cweight i)
    (hν : ∀i,∀p∈groups i,0≤ν i p) (hνbound : ∀i,∀p∈groups i,ν i p≤Cweight i/p)
    (shared : PhysicalActiveReindex.SharedLists (fun i=>groups i) J)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (u v r U W d₀ Y C : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U) (hd : 0<d₀) (hY : 1≤Y) (hC : 0≤C)
    (hfirst : FirstProjection groups good u v r U W d₀ Y)
    (s t : Finset ((ℤ×ℤ)×(∀i,groups i)))
    (η : ℝ→ℂ) (hη : ∀x,‖η x‖≤1) (hηsupport : ∀x,η x≠0→1≤x)
    (ψ : 𝓢(ℝ,ℂ)) (H : ℝ) (hH : 1≤H) (k : ℕ)
    (Aψ Cmass δ M : ℝ) (hAψ : 0≤Aψ) (hψ : ∀x,‖ψ x‖≤Aψ)
    (hψsupport : ∀x,ψ x≠0→|x|≤C)
    (hmassC : 1≤Cmass) (hδ : 0≤δ) (hM : 0≤M)
    (hmass : ∀i,∑p:groups i,ν i p.val≤Cmass)
    (hatom : ∀i,∀p∈groups i,ν i p≤δ) (σ : ℤ) (hσ : σ=1∨σ= -1)
    (hbudget : ∀A B:ℕ,Y^(1/5:ℝ)≤A→Y^(1/5:ℝ)≤B→
      (A:ℝ)*B≤72*(256*((⌈512*C+1⌉₊:ℝ)+1))^2*Y→
      budget groups Cweight ψ ((⌈512*C+1⌉₊:ℝ)+1) H Y Aψ Cmass δ k A B≤M) :
    FiniteMeasuredBilinearBound s t
      (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
      (fun p q=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good u v r U W d₀ Y η ψ
        (sourceMajorArcs H Y) σ p.1 (assemble shared p.2) q.1 (assemble shared q.2))
      ((2*⌈512*C+1⌉₊+1:ℕ)*M) := by
  let K := fun p q : (ℤ×ℤ)×(∀i,groups i)=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good
    u v r U W d₀ Y η ψ (sourceMajorArcs H Y) σ p.1 (assemble shared p.2) q.1 (assemble shared q.2)
  have hzero (hn : ¬(d₀≤(sharedProduct groups shared:ℝ) ∧ (sharedProduct groups shared:ℝ)<2*d₀)) :
      ∀p q,K p q=0 := by
    intro p q
    have ha : ¬sourcePhysicalEdgeAllowed (fun _ p=>p.val) good u v r U W d₀ p.1
        (assemble shared p.2) q.1 (assemble shared q.2) := by
      intro ha
      apply hn
      constructor
      · simpa only [padProduct_assemble] using ha.2.2.2.2.2.1
      · simpa only [padProduct_assemble] using ha.2.2.2.2.2.2.1
    simp only [K,sourcePhysicalEdgeGeometry,ite_eq_right ha]
  by_cases hdyad : d₀≤(sharedProduct groups shared:ℝ) ∧ (sharedProduct groups shared:ℝ)<2*d₀
  swap
  · intro a b
    change ‖finiteMeasuredPairing s t _ _ K a b‖≤_
    simp only [finiteMeasuredPairing,finiteKernelApply,hzero hdyad,mul_zero,zero_mul,Finset.sum_const_zero,norm_zero]
    exact mul_nonneg (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) hM) (Real.sqrt_nonneg _)) (Real.sqrt_nonneg _)
  let E := fun p : (ℤ×ℤ)×(∀i,groups i)=>endpointEligible (fun _ p=>p.val) good u v r U W Y p.1 (assemble shared p.2)
  apply finiteMeasuredBilinearBound_of_filter s t _ _ E E K _
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property))
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property)) (mul_nonneg (Nat.cast_nonneg _) hM)
  · intro p hp q hq hn
    by_contra hk
    apply hn
    exact source_geometry_nonzero_eligible (fun i (p:groups i)=>p.val) good u v r U W d₀ Y
      η ψ (sourceMajorArcs H Y) σ (by linarith) hηsupport p.1 q.1
      (assemble shared p.2) (assemble shared q.2) hk
  apply finiteMeasuredBilinearBound_of_kernel_bound _ _ _ _
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property)) _ _
  apply global_source_bound groups hprime hdis ν Cweight hCweight hν hνbound shared good
    u v r U W d₀ Y C hU hu hu' hd hdyad.1 hdyad.2 hY hC (s.filter E) (t.filter E)
    (fun p hp=>(Finset.mem_filter.mp hp).2.1) (fun p hp=>(Finset.mem_filter.mp hp).2.1)
    (fun p hp=>(Finset.mem_filter.mp hp).2.2.1) (fun p hp=>(Finset.mem_filter.mp hp).2.2.1)
    (fun p hp=>(Finset.mem_filter.mp hp).2.2.2.1) (fun p hp=>(Finset.mem_filter.mp hp).2.2.2.1)
    ?_ ?_ ?_ η hη ψ H hH k Aψ Cmass δ M hAψ hψ hψsupport hmassC hδ hM hmass hatom σ hσ hbudget
  · intro p hp
    have he := (Finset.mem_filter.mp hp).2
    have hh := hfirst p.1 (assemble shared p.2) he.1 he.2.1 he.2.2.1
    simpa only [padProduct_assemble] using hh (by simpa using hdyad.1) (by simpa using hdyad.2)
  · intro p hp
    simpa only [freshProduct_assemble] using (Finset.mem_filter.mp hp).2.2.2.2
  · intro p hp
    simpa only [freshProduct_assemble] using (Finset.mem_filter.mp hp).2.2.2.2

/-- Actual bag-state clean norm. Shared lists, unchanged memory bags,
position labels, endpoint eligibility, and endpoint permutation averages
have all been assembled; the fixed nearby-slope count is the only loss. -/
theorem clean_source_kernel_bound
    (positions : Finset (ℤ×ℤ)) (groups : I→Finset ℕ)
    (hprime : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j))
    (ν : I→ℕ→ℝ) (Cweight : I→ℝ) (hCweight : ∀i,0≤Cweight i)
    (hν : ∀i,∀p∈groups i,0<ν i p) (hνbound : ∀i,∀p∈groups i,ν i p≤Cweight i/p)
    (Line : ∀i,groups i→Type*) [∀i p,Fintype (Line i p)] (B : ℕ)
    (V : I→ℝ) (ρ : ℝ) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (anchor : positions→∀i p,Line i p)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (u v r U W d₀ Y C : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U) (hd : 0<d₀) (hY : 1≤Y) (hC : 0≤C)
    (hfirst : FirstProjection groups good u v r U W d₀ Y)
    (η : ℝ→ℂ) (hη : ∀x,‖η x‖≤1) (hηsupport : ∀x,η x≠0→1≤x)
    (ψ : 𝓢(ℝ,ℂ)) (H : ℝ) (hH : 1≤H) (k : ℕ)
    (Aψ Cmass δ M : ℝ) (hAψ : 0≤Aψ) (hψ : ∀x,‖ψ x‖≤Aψ)
    (hψsupport : ∀x,ψ x≠0→|x|≤C)
    (hmassC : 1≤Cmass) (hδ : 0≤δ) (hM : 0≤M)
    (hmass : ∀i,∑p:groups i,ν i p.val≤Cmass)
    (hatom : ∀i,∀p∈groups i,ν i p≤δ) (σ : ℤ) (hσ : σ=1∨σ= -1)
    (hbudget : ∀A B:ℕ,Y^(1/5:ℝ)≤A→Y^(1/5:ℝ)≤B→
      (A:ℝ)*B≤72*(256*((⌈512*C+1⌉₊:ℝ)+1))^2*Y→
      budget groups Cweight ψ ((⌈512*C+1⌉₊:ℝ)+1) H Y Aψ Cmass δ k A B≤M) :
    FiniteMeasuredBilinearBound Finset.univ Finset.univ
      (PhysicalMaskedKernel.mass (B:=B) (fun i (p:groups i)=>ν i p.val))
      (PhysicalMaskedKernel.mass (B:=B) (fun i (p:groups i)=>ν i p.val))
      (fun s t=>PhysicalMaskedSchur.originalKernel (fun i (p:groups i)=>ν i p.val) V
        (fun _=>false) (fun _=>false) ρ anchor
        (fun z a w b=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good u v r U W d₀ Y η ψ
          (sourceMajorArcs H Y) σ z.val a w.val b) s t /
        ((PhysicalMaskedKernel.mass (fun i (p:groups i)=>ν i p.val) t:ℝ):ℂ))
      ((2*⌈512*C+1⌉₊+1:ℕ)*M) := by
  apply clean_kernel_bound_of_shared_geometry (fun i (p:groups i)=>ν i p.val)
    (fun i p=>hν i p.val p.property) V ρ _ hρ0 hρ1 (mul_nonneg (Nat.cast_nonneg _) hM) anchor
  intro shared
  let e : (positions×(∀i,groups i))↪((ℤ×ℤ)×(∀i,groups i)) :=
    (Function.Embedding.subtype _).prodMap (Function.Embedding.refl _)
  have hh := source_bound groups hprime hdis ν Cweight hCweight
    (fun i p hp=>(hν i p hp).le) hνbound shared good u v r U W d₀ Y C hU hu hu' hd hY hC hfirst
    ((Finset.univ : Finset (positions×(∀i,groups i))).map e)
    ((Finset.univ : Finset (positions×(∀i,groups i))).map e)
    η hη hηsupport ψ H hH k Aψ Cmass δ M hAψ hψ hψsupport hmassC hδ hM hmass hatom σ hσ hbudget
  have ht := finiteMeasuredBilinearBound_embedding Finset.univ Finset.univ e e _ _ _ _ hh
  exact ht

/-- The measured density is exactly the action of the original physical
matrix. Positivity of the original mass permits the exact cancellation. -/
theorem density_operator_bound {X : Type*} [Fintype X]
    (μ : X→ℝ) (hμ : ∀x,0<μ x) (K : X→X→ℂ) (M : ℝ) (hM : 0≤M)
    (hK : FiniteMeasuredBilinearBound Finset.univ Finset.univ μ μ
      (fun x y=>K x y/(μ y:ℂ)) M) (F : X→ℂ) :
    finiteL2 Finset.univ μ (fun x=>∑y,K x y*F y)≤M*finiteL2 Finset.univ μ F := by
  have hb := finiteKernelBound_of_measured_bilinear Finset.univ Finset.univ μ μ
    (fun x _=>(hμ x).le) (fun x y=>K x y/(μ y:ℂ)) M hM hK F
  have he : finiteKernelApply Finset.univ μ (fun x y=>K x y/(μ y:ℂ)) F =
      (fun x=>∑y,K x y*F y) := by
    funext x
    unfold finiteKernelApply
    apply Finset.sum_congr rfl
    intro y hy
    have hn : (μ y:ℂ)≠0 := by exact_mod_cast (hμ y).ne'
    field_simp
  rwa [he] at hb

end Elliptic.Operator.PhysicalCleanFull
