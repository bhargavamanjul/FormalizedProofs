module

public import Elliptic.Operator.CanonicalHistoryCoefficient

/-!
# Actual empty-memory boundary pairing and finite schedule assembly

Initial vacuum states have a finite position and active-tuple index even
when retained-line types are infinite. The history selector is the actual
global birth restriction. The right boundary vector imposes empty final
memory. Both endpoint vectors and the actual initial mass are retained
through the proved finite-key and schedule reindexing.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.CanonicalBoundaryAssembly
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalHistoryFiber CanonicalHistoryCoefficient
attribute [local instance] Classical.propDecidable
local instance canonicalBoundaryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The finite coordinates of an empty-memory boundary state. -/
abbrev BoundaryIndex (I Z : Type) (P : I → Type) (J : ℕ) :=
  Z × (∀ i, Fin (J+1) → P i)

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}

instance boundaryIndexFintype : Fintype (BoundaryIndex I Z P J) :=
  inferInstanceAs (Fintype (Z × (∀ i, Fin (J+1) → P i)))

/-- Literal empty-memory state with the prescribed position and active tuple. -/
def emptyState (u : BoundaryIndex I Z P J) : PhysicalMemoryState (Z:=Z) P Line J B :=
  ⟨(u.1,u.2,fun i => MemoryState.empty (AnchoredParticle (P i) (Line i)) B),by
    simp [MemoryState.empty,MemoryState.size]⟩

/-- Read position and ordered active tuples from a physical state. -/
def boundaryIndex (s : PhysicalMemoryState (Z:=Z) P Line J B) : BoundaryIndex I Z P J :=
  (s.position P Line J B,s.active P Line J B)

omit [Fintype Z] [∀ i, Fintype (P i)] in
@[simp] theorem emptyState_boundaryIndex (u : BoundaryIndex I Z P J) :
    boundaryIndex (emptyState (Line:=Line) (B:=B) u) = u := by cases u; rfl

omit [Fintype Z] [∀ i, Fintype (P i)] in
@[simp] theorem emptyState_memory (u : BoundaryIndex I Z P J) (i : I) :
    ((emptyState (Line:=Line) (B:=B) u).memory P Line J B i).size = 0 := rfl

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- The initial physical measure is exactly the product of the active
prime masses; no pending factorial or line multiplicity remains. -/
theorem emptyState_mass (ν : ∀ i, P i → ℝ) (u : BoundaryIndex I Z P J) :
    PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) =
      ∏ i, ∏ j : Fin (J+1), ν i (u.2 i j) := by
  simp [PhysicalMemoryState.mass,emptyState,PhysicalMemoryState.active,
    PhysicalMemoryState.memory,MemoryState.mass,MemoryState.empty,MemoryState.size,
    MemoryState.values,tupleWeight]

/-- Arbitrary terminal boundary data, supported on actual empty memory. -/
def vacuumLift (b : BoundaryIndex I Z P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  if ∀ i, (s.memory P Line J B i).size = 0 then b (boundaryIndex s) else 0

/-- Finite key initial endpoint. -/
def keyInitial (k : CanonicalHistoryKey I Z P J N) : BoundaryIndex I Z P J :=
  (k.position 0,k.active 0)

/-- Finite key terminal endpoint. -/
def keyFinal (k : CanonicalHistoryKey I Z P J N) : BoundaryIndex I Z P J :=
  (k.position (Fin.last N),k.active (Fin.last N))

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- The last post-ghost observation is the literal final state of the word. -/
theorem afterStateAt_last (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s) :
    afterStateAt ν V η q ρ geometry n j s h (Fin.last n) = h.final := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih =>
      change afterStateAt ν V η q ρ geometry n (j+1) _ h.2.2 (Fin.last n) = h.2.2.final
      exact ih (j+1) _ h.2.2

/-- No endpoint-position hypothesis is imported: the key reads the actual
initial position and active lists directly. -/
theorem actualKey_initial
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    keyInitial (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h) =
      boundaryIndex s := by
  change boundaryIndex (beforeStateAt ν V η q ρ geometry N 0 s h 0) = boundaryIndex s
  exact congrArg boundaryIndex (ActualHistoryLifespans.beforeStateAt_zero ν V η q ρ anchor geometry N 0 s h)

/-- The final ghost changes neither position nor active lists, so the last
key visit evaluates the actual terminal boundary vector. -/
theorem actualKey_final
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    keyFinal (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h) =
      boundaryIndex h.final := by
  unfold keyFinal ActualHistoryObservation.canonicalKey boundaryIndex
  rw [← afterStateAt_last ν V η q ρ anchor geometry N 0 s h]
  rw [ActualHistoryObservation.before_after_position,
    ActualHistoryObservation.before_after_active]

/-- A realized finite key records its unique actual initial index. This
prevents an initial-state boundary factor from being changed during reindexing. -/
theorem nonzeroKey_initial (value : ∀ i, P i → ℕ)
    (u : BoundaryIndex I Z P J) (k : CanonicalHistoryKey I Z P J N)
    (hk : NonzeroKey ν V η q ρ anchor geometry value (emptyState (Line:=Line) (B:=B) u) k) :
    keyInitial k = u := by
  obtain ⟨h,_,hh,_⟩ := hk
  rw [← hh,actualKey_initial ν V η q ρ anchor geometry (emptyState (Line:=Line) (B:=B) u) h]
  exact emptyState_boundaryIndex u

/-- The actual right-vacuum history sum includes precisely distinct births
and empty final memory, with the endpoint evaluated on the finite key. -/
theorem selected_vacuum_eq_key_weighted (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (b : BoundaryIndex I Z P J → ℂ) :
    ChoiceOperation.selectedHistorySum
      (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) s
      (fun h => if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h)
        then 1 else 0) =
      ∑ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
        if Restricted ν V η q ρ anchor geometry value s h then
          h.weight * b (keyFinal (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h))
        else 0 := by
  unfold ChoiceOperation.selectedHistorySum
  apply Finset.sum_congr rfl
  intro h _
  rw [actualKey_final ν V η q ρ anchor geometry s h]
  unfold Restricted vacuumLift
  by_cases hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h)
  · by_cases hf : ∀ i, (h.final.memory P Line J B i).size = 0 <;> simp [hd,hf]
  · simp [hd]

/-- Any function of the whole finite key can be retained through the exact
fiber partition. In particular both endpoint indicators are permitted. -/
theorem sum_key_weighted (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : CanonicalHistoryKey I Z P J N → ℂ) :
    (∑ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
      if Restricted ν V η q ρ anchor geometry value s h then
        h.weight * F (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h)
      else 0) =
    ∑ k : CanonicalHistoryKey I Z P J N,
      keyWeightSum ν V η q ρ anchor geometry value s k * F k := by
  unfold keyWeightSum
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro h _
  by_cases hr : Restricted ν V η q ρ anchor geometry value s h <;> simp [hr]

/-- Keys with no nonzero selected summand vanish even after multiplication
by arbitrary finite-key boundary data. -/
theorem sum_key_weighted_nonzero (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : CanonicalHistoryKey I Z P J N → ℂ) :
    (∑ k : CanonicalHistoryKey I Z P J N,
      keyWeightSum ν V η q ρ anchor geometry value s k * F k) =
    ∑ k : {k : CanonicalHistoryKey I Z P J N // NonzeroKey ν V η q ρ anchor geometry value s k},
      keyWeightSum ν V η q ρ anchor geometry value s k.val * F k.val := by
  calc
    _ = ∑ k : CanonicalHistoryKey I Z P J N,
        if NonzeroKey ν V η q ρ anchor geometry value s k then
          keyWeightSum ν V η q ρ anchor geometry value s k * F k else 0 := by
      apply Finset.sum_congr rfl
      intro k _
      by_cases hk : NonzeroKey ν V η q ρ anchor geometry value s k
      · simp only [hk,ite_true]
      · simp only [hk,ite_false,keyWeightSum_zero ν V η q ρ anchor geometry value s k hk,zero_mul]
    _ = _ := by
      rw [Finset.sum_ite]
      simp only [Finset.sum_const_zero,add_zero]
      exact Finset.sum_subtype _ (fun _ => by simp) _

/-- The literal boundary pairing: actual initial mass, conjugated left
vector, birth restriction on the fully expanded history, and terminal vacuum. -/
def boundaryPairing (value : ∀ i, P i → ℕ) (N : ℕ)
    (a b : BoundaryIndex I Z P J → ℂ) : ℂ :=
  ∑ u : BoundaryIndex I Z P J,
    (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ) * conj (a u) *
      ChoiceOperation.selectedHistorySum
        (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) (emptyState (Line:=Line) (B:=B) u)
        (fun h => if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
          (emptyState (Line:=Line) (B:=B) u) h) then 1 else 0)

/-- Before any geometric reconstruction, the actual boundary pairing is
already an exact finite-key sum with the literal initial measure. -/
theorem boundaryPairing_eq_finite_key_sum (value : ∀ i, P i → ℕ)
    (a b : BoundaryIndex I Z P J → ℂ) :
    boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b =
      ∑ u : BoundaryIndex I Z P J, ∑ k : CanonicalHistoryKey I Z P J N,
        (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ) *
          conj (a u) * keyWeightSum ν V η q ρ anchor geometry value
            (emptyState (Line:=Line) (B:=B) u) k * b (keyFinal k) := by
  unfold boundaryPairing
  apply Finset.sum_congr rfl
  intro u _
  rw [selected_vacuum_eq_key_weighted ν V η q ρ anchor geometry value (emptyState u) b,
    sum_key_weighted ν V η q ρ anchor geometry value (emptyState u) (fun k => b (keyFinal k)),
    Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  ring

/-- Exact finite schedule assembly of the actual boundary pairing. The
family exists by reconstruction from actual nonzero histories, and its
coefficients are already proved rather than supplied as a new hypothesis.
Initial-state indices remain explicit and dependent history fibers are not
identified across different initial states. -/
theorem exists_boundary_schedule_sum (value : ∀ i, P i → ℕ)
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (a b : BoundaryIndex I Z P J → ℂ) :
    ∃ D : ∀ u : BoundaryIndex I Z P J,
        {k : CanonicalHistoryKey I Z P J N // NonzeroKey ν V η q ρ anchor geometry value (emptyState (Line:=Line) (B:=B) u) k} →
          ScheduledPhysicalPath anchor N J B,
      (∀ u k, (D u k).initialState = emptyState (Line:=Line) (B:=B) u ∧ (D u k).canonicalKey = k.val ∧
        (D u k).ActiveBirthAnchored ∧ keyWeightSum ν V η q ρ anchor geometry value (emptyState (Line:=Line) (B:=B) u) k.val =
          (D u k).summedCoefficientProduct ν V η q ρ geometry N 0) ∧
      boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b =
        ∑ u : BoundaryIndex I Z P J, ∑ k,
          (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ) * conj (a (keyInitial k.val)) *
            (D u k).summedCoefficientProduct ν V η q ρ geometry N 0 * b (keyFinal k.val) := by
  have hex := fun u : BoundaryIndex I Z P J =>
    exists_schedule_family_sum (N:=N) ν V η q ρ anchor geometry value hshared (emptyState (Line:=Line) (B:=B) u)
      (fun i => emptyState_memory u i)
  choose D hD using hex
  refine ⟨D,(fun u k => (hD u).1 k),?_⟩
  unfold boundaryPairing
  apply Finset.sum_congr rfl
  intro u _
  rw [selected_vacuum_eq_key_weighted ν V η q ρ anchor geometry value (emptyState u) b,
    sum_key_weighted ν V η q ρ anchor geometry value (emptyState u) (fun k => b (keyFinal k)),
    sum_key_weighted_nonzero ν V η q ρ anchor geometry value (emptyState u) (fun k => b (keyFinal k))]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  rw [(hD u).1 k |>.2.2.2,nonzeroKey_initial ν V η q ρ anchor geometry value u k.val k.property]
  ring

end Elliptic.Operator.CanonicalBoundaryAssembly
