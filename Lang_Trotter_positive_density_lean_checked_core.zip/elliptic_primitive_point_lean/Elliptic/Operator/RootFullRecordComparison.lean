module

public import Elliptic.Operator.RootFullRecordTransfer

/-!
# Complete signed root-to-independent-line replacement for original records

The full inactive prime product is restored after the actual sparse
comparison. The error includes the proved geometric boundary cover, all
original records and both endpoint permutations, all Bonferroni subsets,
and both signed/positive remainders. No grid, coefficient-mass, expected-
gap, CRT-independence or polynomial-discrepancy hypothesis is left.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootFullRecordComparison
open scoped BigOperators
open Filter MeasureTheory SourceRootCount RootRecordComparison RootRecordKernel
open RootFullRecordTransfer RootRecordGap RootRecordBonferroni RootDiscreteBudget
open OriginalPathWeights IntegerRootReplacement BonferroniBudget
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- One threshold precedes all finite prime alphabets, original record
families, dyads and source tests. The finite reciprocal-prime mass is the
standard explicit sieve input; the gap itself is proved. -/
theorem eventually_full_comparison (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ vmin B A : ℝ)
    (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) (hB : 0≤B) (hA : 0≤A) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ records : Finset (SourceRecord K C (Real.log x)),
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact p.val.Prime],
      (∀r∈records,activePrimes r⊆primes) →
      (∀p∈primes,(p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      (∑p∈primes,1/((p:ℝ)+1)≤B) →
      ∀ damping : ℕ→ℝ, (∀j<momentLength (Real.log x)+1,0≤damping j ∧ damping j≤1) →
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤U*V → 0<d₀ → 1≤Y → ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀t,‖smooth t‖≤1) → (∀t,‖ψ t‖≤1) → (∀t,smooth t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin (momentLength (Real.log x))→Bool,
      let G := fun rec=>recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ
      ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
        ((∑r∈records,rootComplete r primes damping U V (G r) FinitePrimeCRT.integerLines)-
          ∑r∈records,integralComplete r primes damping U V (G r))‖ ≤
      U*V*(2*x^(-(δ/64000))+(30/(Real.pi^2/6))*(Real.log x)^(-A*(momentLength (Real.log x):ℝ))) := by
  filter_upwards [eventually_polynomial_transfer hPD K hK C δ vmin hC hδ hmin,
    eventually_gap_transfer hPD K C δ vmin hC hδ hmin,
    Real.tendsto_log_atTop.eventually (eventually_accumulated_gap K C B A vmin hC hB hA hmin),
    Real.tendsto_log_atTop.eventually ((tendsto_rpow_atTop (by norm_num : (0:ℝ)<76/100)).eventually
      (eventually_ge_atTop (2:ℝ)))] with x hp hg hl hdpth
  intro P instP records primes instPrime hactive hbounds hmass damping hdamping U V d₀ Y hU hU' hV hV'
    hUV hd hY VM hVM value μ hv exponents smooth ψ hsmooth hψ hsupport major hmajor σ adjoint
  dsimp only
  let G := fun rec : SourceRecord K C (Real.log x)=>
    recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ
  let m := truncationIndex (Real.log x)
  have hdepth := (depth_bounds (Real.log x) hdpth).2
  have hpoly := hp P records primes hactive hbounds (2*m) (by dsimp [m]; omega)
    damping hdamping U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM value μ hv exponents smooth ψ
    hsmooth hψ hsupport major hmajor σ adjoint
  have hgap := hg records primes hactive hbounds (2*m+1) (2*m+1) le_rfl hdepth damping hdamping
    U V hU hU' hV hV' VM hVM
  have hline := hl records primes damping hdamping hmass VM hVM
  have hG (rec : SourceRecord K C (Real.log x)) (_ : rec∈records) (q) : ‖G rec q‖≤1 :=
    recordGeometry_norm_le_one rec adjoint value μ U V d₀ Y (Real.log x) hd exponents
      smooth ψ hsmooth hψ major hmajor σ q
  have h := comparison records primes hactive damping hdamping m U V
    (normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)))
    (by linarith : 0≤U*V) G hG FinitePrimeCRT.integerLines
    (U*V*x^(-(δ/64000))) (U*V*x^(-(δ/64000))) hpoly hgap
  apply h.trans
  calc
    _ ≤ U*V*x^(-(δ/64000))+U*V*x^(-(δ/64000))+
        2*(15*(U*V/(Real.pi^2/6)))*(Real.log x)^(-A*(momentLength (Real.log x):ℝ)) := by
      exact add_le_add le_rfl (mul_le_mul_of_nonneg_left hline (by positivity))
    _ = _ := by ring


/-- The explicit error is smaller than every requested growing-moment
logarithmic target, after increasing the fixed tail exponent by one. -/
theorem eventually_comparison_cost (δ A : ℝ) (hδ : 0<δ) (hA : 0≤A) :
    ∀ᶠ x : ℝ in atTop,
      2*x^(-(δ/64000))+(30/(Real.pi^2/6))*(Real.log x)^(-(A+1)*(momentLength (Real.log x):ℝ)) ≤
        (Real.log x)^(-A*(momentLength (Real.log x):ℝ)) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (2+30/(Real.pi^2/6))),
    Real.tendsto_log_atTop.eventually (RootErrorBudget.eventually_power_saving_le_moment
      (A+1) (δ/16) (by linarith) (by positivity))] with x hx hL hC hp
  have hL0 : 0<Real.log x := by linarith
  have hn : (1:ℝ)≤momentLength (Real.log x) := by
    exact_mod_cast momentLength_pos hL0
  have hpow : x^(-(δ/64000))≤(Real.log x)^(-(A+1)*(momentLength (Real.log x):ℝ)) := by
    rw [Real.rpow_def_of_pos hx]
    convert hp using 1 <;> congr 1 <;> ring
  calc
    _ ≤ (2+30/(Real.pi^2/6))*(Real.log x)^(-(A+1)*(momentLength (Real.log x):ℝ)) := by nlinarith
    _ ≤ (Real.log x)^(momentLength (Real.log x):ℝ)*
        (Real.log x)^(-(A+1)*(momentLength (Real.log x):ℝ)) :=
      mul_le_mul_of_nonneg_right (hC.trans (Real.self_le_rpow_of_one_le hL hn)) (by positivity)
    _ = _ := by rw [←Real.rpow_add hL0]; congr 1; ring

/-- Complete normalized literal-root replacement at the growing-moment
scale. Only the root count and standard reciprocal prime mass remain
external; all finite/geometric/Bonferroni deductions are checked. -/
theorem eventually_full_moment_comparison (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ vmin B A : ℝ)
    (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) (hB : 0≤B) (hA : 0≤A) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ records : Finset (SourceRecord K C (Real.log x)),
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact p.val.Prime],
      (∀r∈records,activePrimes r⊆primes) →
      (∀p∈primes,(p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      (∑p∈primes,1/((p:ℝ)+1)≤B) →
      ∀ damping : ℕ→ℝ, (∀j<momentLength (Real.log x)+1,0≤damping j ∧ damping j≤1) →
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤U*V → 0<d₀ → 1≤Y → ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀t,‖smooth t‖≤1) → (∀t,‖ψ t‖≤1) → (∀t,smooth t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin (momentLength (Real.log x))→Bool,
      let G := fun rec=>recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ
      ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
        ((∑r∈records,rootComplete r primes damping U V (G r) FinitePrimeCRT.integerLines)-
          ∑r∈records,integralComplete r primes damping U V (G r))‖ ≤
      U*V*(Real.log x)^(-A*(momentLength (Real.log x):ℝ)) := by
  filter_upwards [eventually_full_comparison hPD K hK C δ vmin B (A+1)
    hC hδ hmin hB (by linarith),eventually_comparison_cost δ A hδ hA] with x ht hc
  intro P instP records primes instPrime hactive hbounds hmass damping hdamping U V d₀ Y hU hU' hV hV'
    hUV hd hY VM hVM value μ hv exponents smooth ψ hsmooth hψ hsupport major hmajor σ adjoint
  have h := ht P records primes hactive hbounds hmass damping hdamping U V d₀ Y hU hU' hV hV'
    hUV hd hY VM hVM value μ hv exponents smooth ψ hsmooth hψ hsupport major hmajor σ adjoint
  exact h.trans (mul_le_mul_of_nonneg_left hc (by linarith))

end Elliptic.Operator.RootFullRecordComparison
