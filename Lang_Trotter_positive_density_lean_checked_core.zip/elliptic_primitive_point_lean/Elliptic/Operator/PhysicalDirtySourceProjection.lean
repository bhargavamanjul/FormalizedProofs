module

public import Elliptic.Operator.PhysicalCleanGoodProjection
public import Elliptic.Operator.PhysicalDirtySignedSchur

/-! Literal source-good tests discharge both physical dirty projections.
The additional endpoint conditions are already forced by every allowed
edge, so this sharpening leaves the original signed geometry unchanged. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtySourceProjection
open scoped BigOperators
open RootLiteralGeometry RootEndpointBudget RootGoodBoundary
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000
variable {K J : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
variable (value : ∀i,P i→ℕ)

 def admissibleGood (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop) (d₀ : ℝ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : Prop :=
  good z a ∧ Function.Injective (physicalSourceLabels value a) ∧
    d₀≤(sourcePadProduct value a:ℝ) ∧ (sourcePadProduct value a:ℝ)<2*d₀

 theorem allowed_admissible_iff (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ : ℝ) (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J) :
    sourcePhysicalEdgeAllowed value (admissibleGood value good d₀) u v r U W d₀ z a w b ↔
      sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
  constructor
  · intro h
    exact ⟨h.1,h.2.1,h.2.2.1.1,h.2.2.2.1.1,h.2.2.2.2⟩
  · intro h
    have hr := (sourcePhysicalEdgeAllowed_swap value good u v r U W d₀ z a w b).mp h
    have ha : admissibleGood value good d₀ z a :=
      ⟨h.2.2.1,physicalSourceLabels_injective_of_ban value a b h.2.2.2.2.1,
        h.2.2.2.2.2.1,h.2.2.2.2.2.2.1⟩
    have hb : admissibleGood value good d₀ w b :=
      ⟨hr.2.2.1,physicalSourceLabels_injective_of_ban value b a hr.2.2.2.2.1,
        hr.2.2.2.2.2.1,hr.2.2.2.2.2.2.1⟩
    exact ⟨h.1,h.2.1,ha,hb,h.2.2.2.2⟩

 theorem geometry_admissible_eq (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J) :
    sourcePhysicalEdgeGeometry value (admissibleGood value good d₀) u v r U W d₀ Y η ψ major σ z a w b=
      sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b := by
  simp only [sourcePhysicalEdgeGeometry,allowed_admissible_iff]

 theorem first_projection (μ : ∀i,P i→ℝ) (d₀ Y L : ℝ) (a : Fin K→ℝ)
    (q : RootPhysicalCell.RootPoint) :
    PhysicalComparisonChoices.GoodProjection (J:=J) value q.2.2 Y
      (admissibleGood value (sourceGood value μ d₀ Y L a q) d₀) := by
  intro z b hz hb
  refine ⟨chosenComplement z,(chosenComplement_spec z hz).1,?_⟩
  exact PhysicalCleanGoodProjection.sourceGood_first_chosen value μ d₀ Y L a q z b
    hb.2.1 hb.2.2.1 hb.2.2.2 hb.1

 theorem second_projection (μ : ∀i,P i→ℝ) (d₀ Y L : ℝ) (a : Fin K→ℝ)
    (q : RootPhysicalCell.RootPoint) :
    PhysicalRawGlobalRow.GoodProjection (J:=J) value μ d₀ q.2.2 L a
      (admissibleGood value (sourceGood value μ d₀ Y L a q) d₀) := by
  intro z b hz hb
  refine ⟨chosenComplement z,(chosenComplement_spec z hz).1,?_⟩
  exact hb.1.2

end Elliptic.Operator.PhysicalDirtySourceProjection
