module

public import Elliptic.Operator.RootShortComplement
public import Elliptic.Operator.SourceSecondGoodState

/-!
# A single finite endpoint family for all bounded integer circle tests

Enumerating every bounded integer multiplier also covers all products and
fresh draws in the good-state tests. Between these endpoints, their finite
weighted exceptional probabilities are exactly constant.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootTestEndpoints
open scoped BigOperators
open RootGoodBoundary
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

def multipliers (H : ℕ) : Finset ℤ := Finset.Icc (-(H:ℤ)) H

theorem mem_multipliers (H : ℕ) (m : ℤ) :
    m ∈ multipliers H ↔ |m| ≤ (H:ℤ) := by
  simp [multipliers,abs_le]

theorem multipliers_card (H : ℕ) : (multipliers H).card = 2*H+1 := by
  simp [multipliers,Int.card_Icc]
  omega

def endpoints (z w : ℤ × ℤ) (H : ℕ) (R : ℝ) (eps : Finset ℝ) : Finset ℝ :=
  (multipliers H).biUnion fun m => eps.biUnion fun ε => circleEndpoints z w m R ε

theorem circleEndpoints_subset (z w : ℤ × ℤ) (H : ℕ) (R : ℝ)
    (eps : Finset ℝ) (m : ℤ) (hm : |m| ≤ (H:ℤ)) (ε : ℝ) (hε : ε ∈ eps) :
    circleEndpoints z w m R ε ⊆ endpoints z w H R eps := by
  intro t ht
  exact Finset.mem_biUnion.mpr ⟨m,(mem_multipliers H m).mpr hm,
    Finset.mem_biUnion.mpr ⟨ε,hε,ht⟩⟩

theorem circleEndpoints_card_le (z w : ℤ × ℤ) (H : ℕ) (R E : ℝ)
    (hR : 0 ≤ R) (hE : 0 ≤ E) (m : ℤ) (hm : |m| ≤ (H:ℤ))
    (ε : ℝ) (hε : ε ≤ E) :
    ((circleEndpoints z w m R ε).card:ℝ) ≤ 4*(H:ℝ)*R+4*E+2 := by
  have hmR : |(m:ℝ)| ≤ (H:ℝ) := by exact_mod_cast hm
  have hc : ((circleEndpoints z w m R ε).card:ℝ) ≤
      2*((translations m R ε).card:ℝ) := by exact_mod_cast RootGoodBoundary.circleEndpoints_card z w m R ε
  have ht := translations_card m R ε
  have hb : max 0 (2*(|(m:ℝ)| * R+ε)+1) ≤ 2*((H:ℝ)*R+E)+1 := by
    apply max_le
    · positivity
    · nlinarith [mul_le_mul_of_nonneg_right hmR hR]
  linarith

/-- The actual finite endpoint cardinality is charged explicitly. -/
theorem endpoints_card_le (z w : ℤ × ℤ) (H : ℕ) (R E : ℝ)
    (hR : 0≤R) (hE : 0≤E) (eps : Finset ℝ) (heps : ∀ ε∈eps, ε≤E) :
    ((endpoints z w H R eps).card:ℝ) ≤
      (2*(H:ℝ)+1)*(eps.card:ℝ)*(4*(H:ℝ)*R+4*E+2) := by
  have hc : (endpoints z w H R eps).card ≤
      ∑ m ∈ multipliers H, ∑ ε ∈ eps, (circleEndpoints z w m R ε).card := by
    unfold endpoints
    exact (Finset.card_biUnion_le).trans (Finset.sum_le_sum fun m _ => Finset.card_biUnion_le)
  have hcR : ((endpoints z w H R eps).card:ℝ) ≤
      ∑ m ∈ multipliers H, ∑ ε ∈ eps, ((circleEndpoints z w m R ε).card:ℝ) := by
    exact_mod_cast hc
  calc
    _ ≤ ∑ m ∈ multipliers H, ∑ ε ∈ eps, ((circleEndpoints z w m R ε).card:ℝ) := hcR
    _ ≤ ∑ _m ∈ multipliers H, ∑ _ε ∈ eps, (4*(H:ℝ)*R+4*E+2) := by
      apply Finset.sum_le_sum
      intro m hm
      apply Finset.sum_le_sum
      intro ε hε
      exact circleEndpoints_card_le z w H R E hR hE m ((mem_multipliers H m).mp hm) ε (heps ε hε)
    _ = _ := by simp [multipliers_card]; ring

/-- A bounded-multiplier circle inequality, including its boundary, is
constant on any interval missing the explicitly enumerated endpoints. -/
theorem circle_le_constant (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (H : ℕ) (R a b : ℝ) (eps : Finset ℝ)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w H R eps, t∉Set.Icc a b)
    (m : ℤ) (hm : |m|≤(H:ℤ)) (ε : ℝ) (hε : ε∈eps)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    (ε≤‖(((m:ℝ)*phase z w r : ℝ):AddCircle (1:ℝ))‖) ↔
      (ε≤‖(((m:ℝ)*phase z w s : ℝ):AddCircle (1:ℝ))‖) := by
  by_cases hm0 : m=0
  · simp [hm0]
  have hsub := circleEndpoints_subset z w H R eps m hm ε hε
  have hno (t : ℝ) (ht : t∈Set.Icc a b) :
      ‖(((m:ℝ)*phase z w t : ℝ):AddCircle (1:ℝ))‖ ≠ ε := by
    intro he
    exact hends t (hsub (circle_threshold_mem z w hzw m hm0 R ε t
      (hpole t ht) (hbound t ht) he)) ht
  have hh := circle_test_constant z w hzw m hm0 R ε a b hpole hbound
    (fun t ht => hends t (hsub ht)) r s hr hs
  simpa only [le_iff_lt_or_eq, (hno r hr).symm, (hno s hs).symm, or_false] using hh

theorem circle_lt_constant (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (H : ℕ) (R a b : ℝ) (eps : Finset ℝ)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w H R eps, t∉Set.Icc a b)
    (m : ℤ) (hm : |m|≤(H:ℤ)) (ε : ℝ) (hε : ε∈eps)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    (ε<‖(((m:ℝ)*phase z w r : ℝ):AddCircle (1:ℝ))‖) ↔
      (ε<‖(((m:ℝ)*phase z w s : ℝ):AddCircle (1:ℝ))‖) := by
  by_cases hm0 : m=0
  · simp [hm0]
  exact circle_test_constant z w hzw m hm0 R ε a b hpole hbound
    (fun t ht => hends t (circleEndpoints_subset z w H R eps m hm ε hε ht)) r s hr hs

theorem phase_distance (d e T : ℕ) (β : ℝ) :
    dist ((((d:ℝ)*((T:ℝ)*β)):ℝ):AddCircle (1:ℝ))
      ((((e:ℝ)*((T:ℝ)*β)):ℝ):AddCircle (1:ℝ)) =
      ‖((((((d:ℤ)-(e:ℤ))*(T:ℤ):ℤ):ℝ)*β : ℝ):AddCircle (1:ℝ))‖ := by
  rw [dist_eq_norm,←AddCircle.coe_sub]
  congr 2
  push_cast
  ring

/-- All pairwise tests, and hence separation of the actual finite trial
set, are constant between the same universal endpoints. -/
theorem phaseSeparated_constant (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (H : ℕ) (R a b : ℝ) (eps : Finset ℝ)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w H R eps, t∉Set.Icc a b)
    (trials : Finset ℕ) (T : ℕ) (δ : ℝ) (hδ : δ∈eps)
    (hm : ∀ d∈trials, ∀ e∈trials, |((d:ℤ)-(e:ℤ))*(T:ℤ)|≤(H:ℤ))
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    PhaseSeparated trials ((T:ℝ)*phase z w r) δ ↔
      PhaseSeparated trials ((T:ℝ)*phase z w s) δ := by
  unfold PhaseSeparated
  simp only [phase_distance]
  apply forall_congr'
  intro d
  apply forall_congr'
  intro hd
  apply forall_congr'
  intro e
  apply forall_congr'
  intro he
  apply imp_congr_right
  intro hde
  exact circle_le_constant z w hzw H R a b eps hpole hbound hends
    _ (hm d hd e he) δ hδ r s hr hs

/-- The entire weighted exceptional probability is constant, not only
its individual circle indicators. No size bound on the fresh tuple count
or regularity of their weights is supplied. -/
theorem exceptionalMass_constant {F : Type*} [Fintype F]
    {Q : F → Type*} [∀ i, Fintype (Q i)]
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (H : ℕ) (R a b : ℝ) (eps : Finset ℝ)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w H R eps, t∉Set.Icc a b)
    (trials : Finset ℕ) (value : ∀ i, Q i → ℕ) (μ : ∀ i, Q i → ℝ)
    (δ : ℝ) (hδ : δ∈eps)
    (hm : ∀ f : ∀ i, Q i, ∀ d∈trials, ∀ e∈trials,
      |((d:ℤ)-(e:ℤ))*(freshPrimeTupleProduct value f:ℤ)|≤(H:ℤ))
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    SourceSecondGoodState.exceptionalMass trials value μ (phase z w r) δ =
      SourceSecondGoodState.exceptionalMass trials value μ (phase z w s) δ := by
  unfold SourceSecondGoodState.exceptionalMass
  apply Finset.sum_congr rfl
  intro f _
  rw [phaseSeparated_constant z w hzw H R a b eps hpole hbound hends
    trials (freshPrimeTupleProduct value f) δ hδ (hm f) r s hr hs]

end Elliptic.Operator.RootTestEndpoints
