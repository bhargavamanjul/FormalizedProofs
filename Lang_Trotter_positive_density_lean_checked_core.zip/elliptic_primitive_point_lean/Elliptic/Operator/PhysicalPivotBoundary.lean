module

public import Elliptic.Operator.PhysicalPivotRow
public import Elliptic.Operator.PhysicalPivotInitial

/-! # Initial integration and actual chronological prescribed-birth mass -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance 100000] Classical.propDecidable
local instance physicalPivotBoundaryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 20000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B : ℕ}

/-- Literal initial physical state with no pending particles. -/
def vacuumState (z:Z) (a:PhysicalActiveLists P J) : PhysicalMemoryState (Z:=Z) P Line J B :=
  ⟨(z,a,fun i=>MemoryState.empty (AnchoredParticle (P i) (Line i)) B),by simp [MemoryState.empty,MemoryState.size]⟩

@[simp] theorem vacuumState_active (z:Z) (a:PhysicalActiveLists P J) :
    (vacuumState (Line:=Line) (B:=B) z a).active P Line J B=a := rfl

@[simp] theorem vacuumState_schur (v0:ℝ) (z:Z) (a:PhysicalActiveLists P J) :
    physicalMemorySchurWeight v0 (vacuumState (Line:=Line) (B:=B) z a)=1 := by
  simp [physicalMemorySchurWeight,vacuumState,PhysicalMemoryState.memory,MemoryState.empty,MemoryState.size]

/-- The completed actual registry retains every initial vacuum-list entry. -/
theorem record_vacuum_initial
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (N:ℕ) (z:Z) (a:PhysicalActiveLists P J)
    (h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (vacuumState (Line:=Line) (B:=B) z a)) (i:I) (k:Fin (J+1)) :
    record ν V η q ρ anchor geometry value N 0
      (vacuumState (Line:=Line) (B:=B) z a) h
      (initial value (vacuumState (Line:=Line) (B:=B) z a)) (.inl (i,k)) =
      some (value i (a i k)) := by
  exact record_initial ν V η q ρ anchor geometry value N 0
    (vacuumState (Line:=Line) (B:=B) z a) h
    (initial value (vacuumState (Line:=Line) (B:=B) z a)) (i,k)

/-- Initial performed-pivot equalities in the same completed registry. -/
def InitialPlan.Equalities (plan:InitialPlan I J B) (f:Registry I J B) : Prop :=
  ∀i k (hk:k∈plan.slots i),∃v,
    f (.inl (i,⟨k,Finset.mem_range.mp (plan.bounded i hk)⟩))=some v ∧
    f (plan.pivot (.inl (i,⟨k,Finset.mem_range.mp (plan.bounded i hk)⟩)))=some v

/-- Explicit source mass bound with all initial and later prescriptions.
The only geometric premise is the elementary fixed-label target sum,
which source_choiceRow_le_atoms discharges for the source geometry. -/
theorem boundary_sum_le
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ v0 Δ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (hinj:∀i,Function.Injective (value i))
    (plan:PivotPlan I J B) (initialPlan:InitialPlan I J B) (G:ℕ → ℝ)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:∀j,0≤η j) (hq:∀j,0≤q j)
    (hρ:0<ρ) (hρ1:ρ≤1) (hv0:0<v0) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ)
    (hp:∀j,q j/ρ^2+η j/(ρ*v0)≤1) (hG:∀j,0≤G j)
    (hgeometry:∀j z a b,(∑w:Z,‖geometry j z a w b‖)≤G j)
    (F:PhysicalMemoryState (Z:=Z) P Line J B → ℝ)
    (hF0:∀s,0≤F s) (hF:∀s,F s≤physicalMemorySchurWeight v0 s)
    (N:ℕ) (z:Z) :
    (∑a:PhysicalActiveLists P J,(∏i,tupleWeight (ν i) (a i))*
      (∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
        (vacuumState (Line:=Line) (B:=B) z a),
        if initialPlan.Equalities
            (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a))) ∧
          plan.Equalities (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a)))
        then ‖h.weight‖*F h.final else 0)) ≤
      plan.wordFactor ν V η ρ v0 G 0 N *
        Δ^((∑i,(initialPlan.slots i).card)+plan.futureCount 0 N) *
        ∏i,(∑p,ν i p)^((J+1)-(initialPlan.slots i).card) := by
  let C:=plan.wordFactor ν V η ρ v0 G 0 N*Δ^(plan.futureCount 0 N)
  have hC:0≤C:=mul_nonneg
    (wordFactor_nonneg ν V η ρ v0 G plan hV hη hρ.le hv0.le hG 0 N) (pow_nonneg hΔ _)
  have hm (a:PhysicalActiveLists P J):0≤∏i,tupleWeight (ν i) (a i):=Finset.prod_nonneg (fun i _=>Finset.prod_nonneg (fun k _=>hν i (a i k)))
  have hrow (a:PhysicalActiveLists P J) :
      (∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
        (vacuumState (Line:=Line) (B:=B) z a),
        if initialPlan.Equalities (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a))) ∧
          plan.Equalities (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a)))
        then ‖h.weight‖*F h.final else 0) ≤ if initialPlan.Allowed value a then C else 0 := by
    by_cases ha:initialPlan.Allowed value a
    · rw [ite_eq_left ha]
      have hsum := actual_history_sum_le ν V η q ρ v0 Δ anchor geometry value hinj plan G
        hν hV hη hq hρ hρ1 hv0 hΔ hatom hp hG hgeometry F hF N 0
        (vacuumState (Line:=Line) (B:=B) z a) (initial value (vacuumState (Line:=Line) (B:=B) z a))
      simp only [vacuumState_schur,mul_one] at hsum
      apply le_trans (b := (∑h:ChoiceOperation.History
        (physicalMemoryOperations ν V η q ρ anchor geometry N)
        (vacuumState (Line:=Line) (B:=B) z a),
        if plan.Allowed ν V η q ρ anchor geometry value N 0 _ h
          (initial value (vacuumState (Line:=Line) (B:=B) z a)) then ‖h.weight‖*F h.final else 0)) ?_ hsum
      apply Finset.sum_le_sum
      intro h _
      by_cases he:initialPlan.Equalities (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a))) ∧
          plan.Equalities (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a)))
      · have hh:=allowed_from_initial ν V η q ρ anchor geometry value plan N (vacuumState (Line:=Line) (B:=B) z a) h he.2
        simp only [ite_eq_left he,ite_eq_left hh]
        exact le_rfl
      · rw [ite_eq_right he]
        split_ifs
        · exact mul_nonneg (norm_nonneg _) (hF0 _)
        · exact le_rfl
    · rw [ite_eq_right ha]
      apply le_of_eq
      apply Finset.sum_eq_zero
      intro h _
      apply ite_eq_right
      intro he
      apply ha
      apply initial_allowed value initialPlan a
        (record ν V η q ρ anchor geometry value N 0 (vacuumState (Line:=Line) (B:=B) z a) h (initial value (vacuumState (Line:=Line) (B:=B) z a))) ?_ he.1
      exact record_vacuum_initial ν V η q ρ anchor geometry value N z a h
  calc
    _ ≤ ∑a:PhysicalActiveLists P J,(∏i,tupleWeight (ν i) (a i))*(if initialPlan.Allowed value a then C else 0) :=
      by
        exact Finset.sum_le_sum (fun a _=>mul_le_mul_of_nonneg_left (hrow a) (hm a))
    _ = C*(∑a:PhysicalActiveLists P J,if initialPlan.Allowed value a then ∏i,tupleWeight (ν i) (a i) else 0) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a _
      split_ifs <;> ring
    _ ≤ C*(Δ^(∑i,(initialPlan.slots i).card)*∏i,(∑p,ν i p)^((J+1)-(initialPlan.slots i).card)) :=
      by
        have hmass := initial_mass_le ν value hinj initialPlan Δ hν hΔ hatom
        apply mul_le_mul_of_nonneg_left ?_ hC
        with_reducible convert hmass using 1
        with_reducible refine Finset.sum_congr ?_ ?_
        · ext a
          simp only [Finset.mem_univ]
        · intro a _
          by_cases ha : initialPlan.Allowed value a
          · simp only [ite_eq_left ha]
          · simp only [ite_eq_right ha]
    _ = _ := by
      dsimp [C]
      rw [pow_add]
      ring

end Elliptic.Operator.PhysicalBirthRegistry
