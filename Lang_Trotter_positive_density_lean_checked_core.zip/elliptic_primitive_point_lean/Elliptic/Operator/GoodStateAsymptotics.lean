module

public import Elliptic.Operator.GoodStateCounting

/-!
# Asymptotic absorption in the literal good-state root estimate

Fixed ordered prime-band exponents force the trial pairs to be sparse
relative to the largest promoted scale. All thresholds are chosen before
the varying finite prime types, source labels, fresh laws and pad dyads.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.GoodStateAsymptotics
open scoped BigOperators Topology ENNReal
open Filter MeasureTheory
open SourceFirstGoodMeasure GoodStateCounting
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Uniform elementary envelope for the logarithm of the omission count. -/
def baseExponent (K : ℕ) (L : ℝ) : ℝ := (K : ℝ)*(Real.log 2+Real.log L)

def trialExponent {K : ℕ} (a : Fin K → ℝ) (c : Configuration K) (L : ℝ) : ℝ :=
  baseExponent K L + 2*∑ i ∈ c.1.1.erase c.1.2, L ^ a i

theorem rpow_ratio_tendsto_zero {a b : ℝ} (hab : b<a) :
    Tendsto (fun L : ℝ => L^b/L^a) atTop (𝓝 0) := by
  have h := tendsto_rpow_neg_atTop (sub_pos.mpr hab)
  apply h.congr'
  filter_upwards [eventually_gt_atTop (0 : ℝ)] with L hL
  rw [← Real.rpow_sub hL]
  congr 1
  ring

theorem baseExponent_ratio_tendsto_zero (K : ℕ) {a : ℝ} (ha : 0<a) :
    Tendsto (fun L : ℝ => baseExponent K L/L^a) atTop (𝓝 0) := by
  have hlog := (isLittleO_log_rpow_atTop ha).tendsto_div_nhds_zero
  have hc : Tendsto (fun L : ℝ => Real.log 2/L^a) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop (tendsto_rpow_atTop ha)
  convert (hc.add hlog).const_mul (K : ℝ) using 1 <;> simp [baseExponent, add_div, mul_div_assoc]

theorem other_group_lt {K : ℕ} (c : Configuration K) (i : Fin K)
    (hi : i ∈ c.1.1.erase c.1.2) : i < c.1.2 := by
  have h := Finset.mem_erase.mp hi
  exact lt_of_le_of_ne (c.2.2 i h.2) h.1

theorem trialExponent_ratio_tendsto_zero {K : ℕ} (a : Fin K → ℝ)
    (ha : StrictMono a) (hpos : ∀ i, 0<a i) (c : Configuration K) :
    Tendsto (fun L : ℝ => trialExponent a c L/L^(a c.1.2)) atTop (𝓝 0) := by
  have hs := tendsto_finsetSum (c.1.1.erase c.1.2)
    (fun i hi => rpow_ratio_tendsto_zero (ha (other_group_lt c i hi)))
  have hs' : Tendsto (fun L : ℝ => ∑ i ∈ c.1.1.erase c.1.2, L^a i/L^a c.1.2)
      atTop (𝓝 0) := by simpa using hs
  convert (baseExponent_ratio_tendsto_zero K (hpos c.1.2)).add (hs'.const_mul 2) using 1
  · ext L
    simp [trialExponent, add_div, mul_div_assoc, Finset.sum_div]
  · simp

theorem eventually_trialExponent_le {K : ℕ} (a : Fin K → ℝ)
    (ha : StrictMono a) (hpos : ∀ i, 0<a i) :
    ∀ᶠ L : ℝ in atTop, ∀ c : Configuration K, trialExponent a c L ≤ L^(a c.1.2)/8 := by
  have he (c : Configuration K) : ∀ᶠ L : ℝ in atTop,
      trialExponent a c L ≤ L^(a c.1.2)/8 := by
    filter_upwards [(trialExponent_ratio_tendsto_zero a ha hpos c).eventually_lt_const
      (show (0 : ℝ)<1/8 by norm_num), eventually_gt_atTop (0 : ℝ)] with L h hL
    have hp : 0<L^(a c.1.2) := Real.rpow_pos_of_pos hL _
    have hx := (div_lt_iff₀ hp).mp h
    linarith
  exact Filter.eventually_all.mpr he

/-- The literal M is retained in the count, then bounded by an exponential
whose ratio to every positive power of L tends to zero. -/
theorem multiplicity_pow_le_exp (K : ℕ) {L : ℝ} (hL : 1≤L) :
    (momentMultiplicity L : ℝ)^K ≤ Real.exp (baseExponent K L) := by
  have hL0 : 0<L := by linarith
  calc
    _ ≤ (2*L)^K := pow_le_pow_left₀ (Nat.cast_nonneg _) (momentMultiplicity_le hL) K
    _ = _ := by
      rw [baseExponent, Real.exp_nat_mul, Real.exp_add, Real.exp_log (by norm_num : (0:ℝ)<2),
        Real.exp_log hL0]

/-- Actual finite band-card bounds imply the trial-count envelope, with no
source path, list, probability law or modulus in the constant. -/
theorem trial_card_le_exp {K : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (a : Fin K → ℝ) {L : ℝ} (hL : 1≤L)
    (label : Fin K × Fin (momentMultiplicity L) → ℕ) (d₀ : ℝ)
    (hcard : ∀ i, (Fintype.card (P i) : ℝ) ≤ Real.exp (2*L^(a i))) (c : Configuration K) :
    ((SourceSecondGoodState.trialProducts value label d₀ c.1.1 c.1.2).card : ℝ) ≤
      Real.exp (trialExponent a c L) := by
  have hc := SourceSecondGoodState.trialProducts_card_le value label d₀ c.1.1 c.1.2
  have hcR : ((SourceSecondGoodState.trialProducts value label d₀ c.1.1 c.1.2).card : ℝ) ≤
      (momentMultiplicity L : ℝ)^K *
        ∏ i : {i // i ∈ c.1.1.erase c.1.2}, (Fintype.card (P i.1) : ℝ) := by exact_mod_cast hc
  refine hcR.trans ?_
  calc
    _ ≤ Real.exp (baseExponent K L) *
        ∏ i : {i // i ∈ c.1.1.erase c.1.2}, Real.exp (2*L^(a i.1)) := by
      gcongr
      · exact multiplicity_pow_le_exp K hL
      · exact hcard _
    _ = _ := by
      rw [← Real.exp_sum, ← Real.exp_add]
      congr 1
      simp only [trialExponent, Finset.mul_sum]
      exact congrArg (fun t => baseExponent K L+t)
        (Finset.sum_coe_sort (c.1.1.erase c.1.2) (fun i => 2*L^(a i)))

/-- The square of the actual trial count is absorbed with the source's
quarter-exponent margin. -/
theorem trial_pair_error_le {K : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (a : Fin K → ℝ) {L : ℝ} (hL : 1≤L)
    (ha : ∀ i, (1/10 : ℝ) ≤ a i)
    (label : Fin K × Fin (momentMultiplicity L) → ℕ) (d₀ : ℝ)
    (hcard : ∀ i, (Fintype.card (P i) : ℝ) ≤ Real.exp (2*L^(a i)))
    (c : Configuration K) (hexp : trialExponent a c L ≤ L^(a c.1.2)/8) :
    200*((SourceSecondGoodState.trialProducts value label d₀ c.1.1 c.1.2).card : ℝ)^2 *
      Real.exp (-(3*(L^a c.1.2)/4)) ≤ 200*Real.exp (-(L^(1/10 : ℝ)/2)) := by
  have ht := (trial_card_le_exp value a hL label d₀ hcard c).trans
    (Real.exp_le_exp.mpr hexp)
  have hs := pow_le_pow_left₀ (by positivity :
    0 ≤ ((SourceSecondGoodState.trialProducts value label d₀ c.1.1 c.1.2).card : ℝ)) ht 2
  calc
    _ ≤ 200*(Real.exp (L^(a c.1.2)/8))^2*Real.exp (-(3*(L^a c.1.2)/4)) := by gcongr
    _ = 200*Real.exp (-(L^a c.1.2/2)) := by
      rw [← Real.exp_nat_mul, mul_assoc, ← Real.exp_add]
      congr 2
      ring
    _ ≤ _ := by
      gcongr
      exact ha c.1.2

/-- The first test contributes its literal omitted-pad count times
`2Y^(-1/2)`, as asserted in the source. -/
theorem first_error_le {K : ℕ} {L Y : ℝ} (hL : 1≤L)
    (hY : Real.exp (L^(1/10 : ℝ)) ≤ Y)
    (label : Fin K × Fin (momentMultiplicity L) → ℕ) (d₀ : ℝ) :
    ((SourceSecondGoodState.omissionProducts label d₀).card : ℝ) *
      ((testLengths (Y^(1/5 : ℝ))).card : ℝ) * (2*(Y^(-(7/10) : ℝ))) ≤
        2*Real.exp (baseExponent K L)*Real.exp (-(L^(1/10 : ℝ)/2)) := by
  have hYpos : 0<Y := (Real.exp_pos _).trans_le hY
  have hd : ((SourceSecondGoodState.omissionProducts label d₀).card : ℝ) ≤
      (momentMultiplicity L : ℝ)^K := by exact_mod_cast omissionProducts_card_le label d₀
  have hlen := testLengths_card_le (Y^(1/5 : ℝ)) (by positivity)
  have hy := Real.rpow_le_rpow_of_nonpos (Real.exp_pos (L^(1/10 : ℝ))) hY
    (show (-(1/2) : ℝ) ≤ 0 by norm_num)
  rw [Real.rpow_def_of_pos (Real.exp_pos _), Real.log_exp] at hy
  calc
    _ ≤ (momentMultiplicity L : ℝ)^K * Y^(1/5 : ℝ) * (2*Y^(-(7/10) : ℝ)) := by gcongr
    _ = 2*(momentMultiplicity L : ℝ)^K * Y^(-(1/2) : ℝ) := by
      rw [show (-(1/2) : ℝ) = 1/5 + -(7/10) by norm_num, Real.rpow_add hYpos]
      ring
    _ ≤ 2*Real.exp (baseExponent K L)*Real.exp (-(L^(1/10 : ℝ)/2)) := by
      have hy' : Y^(-(1/2) : ℝ) ≤ Real.exp (-(L^(1/10 : ℝ)/2)) := by
        convert hy using 1
        congr 1
        ring
      gcongr
      exact multiplicity_pow_le_exp K hL

/-- Every fixed counting factor is absorbed into the quarter-exponent
margin. This threshold depends only on K. -/
theorem eventually_prefactor_absorbed (K : ℕ) :
    ∀ᶠ L : ℝ in atTop,
      (2*Real.exp (baseExponent K L)+200*((2^K-1 : ℕ) : ℝ)) *
        Real.exp (-(L^(1/10 : ℝ)/2)) ≤ Real.exp (-(L^(1/10 : ℝ)/4)) := by
  let C : ℝ := 2+200*((2^K-1 : ℕ) : ℝ)
  have hC : 0<C := by dsimp [C]; positivity
  have hQ := (tendsto_rpow_atTop (by norm_num : (0 : ℝ)<1/10)).eventually_ge_atTop
    (8*Real.log C)
  filter_upwards [(baseExponent_ratio_tendsto_zero K (a:=1/10) (by norm_num)).eventually_lt_const
    (show (0 : ℝ)<1/8 by norm_num), hQ, eventually_ge_atTop (1 : ℝ)] with L hb hq hL
  have hQpos : 0<L^(1/10 : ℝ) := Real.rpow_pos_of_pos (by linarith) _
  have hb' : baseExponent K L ≤ L^(1/10 : ℝ)/8 := by
    have h := (div_lt_iff₀ hQpos).mp hb
    linarith
  have hc : C ≤ Real.exp (L^(1/10 : ℝ)/8) := by
    rw [← Real.exp_log hC]
    apply Real.exp_le_exp.mpr
    linarith
  have hone : 1 ≤ Real.exp (L^(1/10 : ℝ)/8) := Real.one_le_exp (by positivity)
  have hpref : 2*Real.exp (baseExponent K L)+200*((2^K-1 : ℕ) : ℝ) ≤
      Real.exp (L^(1/10 : ℝ)/4) := by
    calc
      _ ≤ C*Real.exp (L^(1/10 : ℝ)/8) := by
        have he := Real.exp_le_exp.mpr hb'
        have hc' := mul_le_mul_of_nonneg_left hone (show 0≤200*((2^K-1 : ℕ) : ℝ) by positivity)
        dsimp [C]
        nlinarith
      _ ≤ Real.exp (L^(1/10 : ℝ)/8)*Real.exp (L^(1/10 : ℝ)/8) := by gcongr
      _ = Real.exp (L^(1/10 : ℝ)/4) := by rw [← Real.exp_add]; congr 1; ring
  calc
    _ ≤ Real.exp (L^(1/10 : ℝ)/4)*Real.exp (-(L^(1/10 : ℝ)/2)) := by gcongr
    _ = _ := by rw [← Real.exp_add]; congr 1; ring

/-- Assembly of both finite good-test estimates into their common
exponential envelope, with all varying data still literal. -/
theorem allBadRoots_le_envelope {K : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (a : Fin K → ℝ) {L : ℝ} (hL : 1≤L)
    (ha : ∀ i, (1/10 : ℝ) ≤ a i)
    (label : Fin K × Fin (momentMultiplicity L) → ℕ) (μ : ∀ i, P i → ℝ)
    (d₀ Y : ℝ) (hY : Real.exp (L^(1/10 : ℝ)) ≤ Y)
    (hlabel : ∀ ij, (label ij).Prime) (hp : ∀ i p, value i p ≠ 0)
    (hμ : ∀ i p, 0≤μ i p) (hmass : ∀ i, ∑ p, μ i p=1)
    (hcard : ∀ i, (Fintype.card (P i) : ℝ) ≤ Real.exp (2*L^(a i)))
    (hexp : ∀ c : Configuration K, trialExponent a c L ≤ L^(a c.1.2)/8) :
    volume (allBadRoots value label μ d₀ Y L a) ≤
      ENNReal.ofReal ((2*Real.exp (baseExponent K L)+200*((2^K-1 : ℕ) : ℝ)) *
        Real.exp (-(L^(1/10 : ℝ)/2))) := by
  have hfinite := allBadRoots_measure_le value label μ d₀ Y L a
    (omissionProducts_ne_zero label hlabel d₀) hp hμ hmass
  refine hfinite.trans ?_
  calc
    _ ≤ ENNReal.ofReal (2*Real.exp (baseExponent K L)*Real.exp (-(L^(1/10 : ℝ)/2))) +
        ∑ _c : Configuration K, ENNReal.ofReal (200*Real.exp (-(L^(1/10 : ℝ)/2))) := by
      apply add_le_add
      · have he : ((SourceSecondGoodState.omissionProducts label d₀).card : ℝ≥0∞) *
          ((testLengths (Y^(1/5 : ℝ))).card : ℝ≥0∞) *
          ENNReal.ofReal (2*(Y^(-(7/10) : ℝ))) =
          ENNReal.ofReal (((SourceSecondGoodState.omissionProducts label d₀).card : ℝ) *
            ((testLengths (Y^(1/5 : ℝ))).card : ℝ) * (2*(Y^(-(7/10) : ℝ)))) := by
          rw [ENNReal.ofReal_mul (by positivity), ENNReal.ofReal_mul (by positivity)]
          simp
        rw [he]
        exact ENNReal.ofReal_le_ofReal (first_error_le hL hY label d₀)
      · exact Finset.sum_le_sum fun c _ => ENNReal.ofReal_le_ofReal
          (trial_pair_error_le value a hL ha label d₀ hcard c (hexp c))
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, configuration_card]
      rw [← ENNReal.ofReal_natCast (2^K-1), ← ENNReal.ofReal_mul (by positivity),
        ← ENNReal.ofReal_add (by positivity) (by positivity)]
      congr 1
      ring

/-- Source Lemma 3.2 at the explicit constant `c=1/4`. The threshold is
chosen before any prime family, labels, probability law, Y or dyad varies.
It may depend on K and the fixed ordered exponents, including their gaps. -/
theorem eventually_allBadRoots_small {K : ℕ} (a : Fin K → ℝ)
    (hmono : StrictMono a) (ha : ∀ i, (1/10 : ℝ) ≤ a i) :
    ∀ᶠ L : ℝ in atTop, ∀ (P : Fin K → Type) [∀ i, Fintype (P i)]
      (value : ∀ i, P i → ℕ) (label : Fin K × Fin (momentMultiplicity L) → ℕ)
      (μ : ∀ i, P i → ℝ) (d₀ Y : ℝ),
      Real.exp (L^(1/10 : ℝ)) ≤ Y → (∀ ij, (label ij).Prime) →
      (∀ i p, value i p ≠ 0) → (∀ i p, 0≤μ i p) → (∀ i, ∑ p, μ i p=1) →
      (∀ i, (Fintype.card (P i) : ℝ) ≤ Real.exp (2*L^(a i))) →
      volume (allBadRoots value label μ d₀ Y L a) ≤
        ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/4))) := by
  have hpos : ∀ i, 0<a i := fun i => lt_of_lt_of_le (by norm_num) (ha i)
  filter_upwards [eventually_trialExponent_le a hmono hpos, eventually_prefactor_absorbed K,
    eventually_ge_atTop (1 : ℝ)] with L ht hpref hL
  intro P _ value label μ d₀ Y hY hlabel hp hμ hmass hcard
  exact (allBadRoots_le_envelope value a hL ha label μ d₀ Y hY hlabel hp hμ hmass hcard ht).trans
    (ENNReal.ofReal_le_ofReal hpref)

end Elliptic.Operator.GoodStateAsymptotics


