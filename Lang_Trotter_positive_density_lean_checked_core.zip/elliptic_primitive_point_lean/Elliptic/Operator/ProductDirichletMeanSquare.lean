module

public import Elliptic.Operator.DirichletMeanSquare
public import Elliptic.Sieve.RoughPairNormalization

/-!
# Actual long-polynomial product mean square

The coefficient of an index u is the literal sum over mn=u. Its norm is
bounded by the actual divisor count, then the previously proved continuous
mean square applies. The sole arithmetic input used for the final
logarithmic coefficient bound is the unchanged classical divisor-square
moment already present in `AcceptedSuccessorSources`.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ProductDirichletMeanSquare
open scoped BigOperators
open Artin.MarkedReplacement
open MeasureTheory Filter
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- Actual multiplicative-convolution fiber. -/
def fiber (s t : Finset ℕ) (u : ℕ) : Finset (ℕ×ℕ) :=
  (s×ˢt).filter (fun p=>p.1*p.2=u)

def coefficient (s t : Finset ℕ) (c d : ℕ→ℂ) (u : ℕ) : ℂ :=
  ∑p∈fiber s t u,c p.1*d p.2

def polynomial (s : Finset ℕ) (c : ℕ→ℂ) (v : ℝ) : ℂ :=
  ∑n∈s,c n*archimedeanPhase v n

/-- Unique recovery of the second factor embeds each fiber in the divisor set. -/
theorem fiber_card_le_divisors (s t : Finset ℕ) (u : ℕ) (hu : 0<u)
    (hs : ∀m∈s,0<m) : (fiber s t u).card≤u.divisors.card := by
  have hinj : Set.InjOn (Prod.fst : ℕ×ℕ→ℕ) (↑(fiber s t u) : Set (ℕ×ℕ)) := by
    intro p hp q hq he
    have hp' := Finset.mem_filter.mp hp
    have hq' := Finset.mem_filter.mp hq
    have hpm := hs p.1 (Finset.mem_product.mp hp'.1).1
    apply Prod.ext he
    apply Nat.eq_of_mul_eq_mul_left hpm
    simpa only [he] using hp'.2.trans hq'.2.symm
  have hsub : (fiber s t u).image Prod.fst⊆u.divisors := by
    intro m hm
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hm
    exact Nat.mem_divisors.mpr ⟨⟨p.2,(Finset.mem_filter.mp hp).2.symm⟩,hu.ne'⟩
  calc
    _ = ((fiber s t u).image Prod.fst).card := (Finset.card_image_of_injOn hinj).symm
    _ ≤ _ := Finset.card_le_card hsub

/-- The actual convolution coefficient is bounded by AB times d(u). -/
theorem coefficient_norm_le (s t : Finset ℕ) (c d : ℕ→ℂ) (u : ℕ) (hu : 0<u)
    (hs : ∀m∈s,0<m) (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hc : ∀m∈s,‖c m‖≤A) (hd : ∀n∈t,‖d n‖≤B) :
    ‖coefficient s t c d u‖≤A*B*(u.divisors.card:ℝ) := by
  calc
    _ ≤ ∑p∈fiber s t u,‖c p.1*d p.2‖ := norm_sum_le _ _
    _ ≤ ∑_p∈fiber s t u,A*B := by
      apply Finset.sum_le_sum
      intro p hp
      have hp' := Finset.mem_product.mp (Finset.mem_filter.mp hp).1
      rw [norm_mul]
      exact mul_le_mul (hc p.1 hp'.1) (hd p.2 hp'.2) (norm_nonneg _) hA
    _ = ((fiber s t u).card:ℝ)*(A*B) := by simp
    _ ≤ (u.divisors.card:ℝ)*(A*B) :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast fiber_card_le_divisors s t u hu hs) (mul_nonneg hA hB)
    _ = _ := mul_comm _ _

/-- Exact product-to-convolution identity, using the literal positive supports. -/
theorem polynomial_product (s t : Finset ℕ) (U V : ℕ)
    (hs : s⊆Finset.Icc 1 U) (ht : t⊆Finset.Icc 1 V)
    (c d : ℕ→ℂ) (v : ℝ) :
    polynomial s c v*polynomial t d v=
      DirichletMeanSquare.polynomial (U*V) (coefficient s t c d) v := by
  have hmap : ∀p∈s×ˢt,p.1*p.2∈Finset.Icc 1 (U*V) := by
    intro p hp
    have hp' := Finset.mem_product.mp hp
    have hm := Finset.mem_Icc.mp (hs hp'.1)
    have hn := Finset.mem_Icc.mp (ht hp'.2)
    exact Finset.mem_Icc.mpr ⟨Nat.mul_pos hm.1 hn.1,Nat.mul_le_mul hm.2 hn.2⟩
  calc
    _ = ∑p∈s×ˢt,c p.1*d p.2*archimedeanPhase v (p.1*p.2) := by
      unfold polynomial
      rw [Finset.sum_mul_sum,Finset.sum_product]
      apply Finset.sum_congr rfl
      intro m hm
      apply Finset.sum_congr rfl
      intro n hn
      rw [archimedeanPhase_mul v (Nat.ne_zero_of_lt (Finset.mem_Icc.mp (hs hm)).1)
        (Nat.ne_zero_of_lt (Finset.mem_Icc.mp (ht hn)).1)]
      ring
    _ = ∑u∈Finset.Icc 1 (U*V),∑p∈fiber s t u,c p.1*d p.2*archimedeanPhase v (p.1*p.2) := by
      symm
      exact Finset.sum_fiberwise_of_maps_to hmap _
    _ = _ := by
      unfold DirichletMeanSquare.polynomial coefficient
      apply Finset.sum_congr rfl
      intro u hu
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro p hp
      rw [(Finset.mem_filter.mp hp).2]

/-- Coefficient L2 mass is controlled by the actual divisor-square sum. -/
theorem coefficient_energy_le (s t : Finset ℕ) (c d : ℕ→ℂ) (Y : ℕ)
    (hs : ∀m∈s,0<m) (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hc : ∀m∈s,‖c m‖≤A) (hd : ∀n∈t,‖d n‖≤B) :
    (∑u∈Finset.Icc 1 Y,‖coefficient s t c d u‖^2)≤
      (A*B)^2*(∑u∈Finset.Icc 1 Y,(u.divisors.card:ℝ)^2) := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro u hu
  have hh := pow_le_pow_left₀ (norm_nonneg _)
    (coefficient_norm_le s t c d u (Finset.mem_Icc.mp hu).1 hs A B hA hB hc hd) 2
  simpa only [mul_pow] using hh

/-- Continuous mean square of the actual product, uniform in interval translates. -/
theorem product_mean_square (s t : Finset ℕ) (U V : ℕ) (hU : 1≤U) (hV : 1≤V)
    (hs : s⊆Finset.Icc 1 U) (ht : t⊆Finset.Icc 1 V)
    (c d : ℕ→ℂ) (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hc : ∀m∈s,‖c m‖≤A) (hd : ∀n∈t,‖d n‖≤B)
    (a b : ℝ) (hab : a≤b) :
    (∫v in a..b,‖polynomial s c v*polynomial t d v‖^2)≤
      (b-a+4*(U*V:ℕ)*(1+Real.log (U*V:ℕ)))*(A*B)^2*
        (∑u∈Finset.Icc 1 (U*V),(u.divisors.card:ℝ)^2) := by
  have hUV : 1≤U*V := Nat.mul_pos hU hV
  simp_rw [polynomial_product s t U V hs ht c d]
  have hh := DirichletMeanSquare.continuous_mean_square a b hab (U*V) hUV (coefficient s t c d)
  have hcoef := coefficient_energy_le s t c d (U*V)
    (fun m hm=>(Finset.mem_Icc.mp (hs hm)).1) A B hA hB hc hd
  have hR : 0≤b-a+4*(U*V:ℕ)*(1+Real.log (U*V:ℕ)) := by
    have hl : 0≤Real.log (U*V:ℕ) := Real.log_nonneg (by exact_mod_cast hUV)
    have ha : 0≤b-a := sub_nonneg.mpr hab
    positivity
  exact hh.trans (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hcoef hR)

/-- The unchanged classical divisor moment supplies one uniform integer threshold. -/
theorem uniform_integer_divisor_moment
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment) :
    ∃D:ℝ,0<D∧∃Y₀:ℕ,∀Y:ℕ,Y₀≤Y→
      (∑u∈Finset.Icc 1 Y,(u.divisors.card:ℝ)^2)≤D*Y*(Real.log (Y:ℝ))^3 := by
  obtain ⟨D,hD,h⟩ := hD
  obtain ⟨y₀,hy₀⟩ := Filter.eventually_atTop.mp h
  refine ⟨D,hD,⌈max y₀ 0⌉₊,?_⟩
  intro Y hY
  have hh : y₀≤(Y:ℝ) := (le_max_left _ _).trans
    ((Nat.le_ceil (max y₀ 0)).trans (by exact_mod_cast hY))
  simpa using hy₀ (Y:ℝ) hh

end Elliptic.Operator.ProductDirichletMeanSquare
