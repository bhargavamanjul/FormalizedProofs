module

public import Elliptic.Operator.EdgeMaskedAdjoint
public import Elliptic.Operator.PhysicalComparisonAnchor
public import Elliptic.Operator.PhysicalDirtyCrude
public import Elliptic.Operator.SingleEdgeTargetCount

/-! Literal comparison choice fibers retain one old-particle line. The
cross-edge ban proves that its prime is coprime to the actual pad. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalComparisonChoices
open scoped BigOperators
open PhysicalEdgeAdjoint
attribute [local instance] Classical.propDecidable
local instance compChoiceDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i,P i→ℕ) (position : Z→ℤ×ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p=>Option (ZMod (value i p))) J B)

/-- The precise determinant-cutoff support of comparison choices. -/
def Support (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C : ℝ) (c : PhysicalEdgeChoice s) : Prop :=
  c.Valid (fun z i p=>primeResidueAnchor (value i p) (position z)) s ∧
  sourcePhysicalEdgeAllowed value good u v r U W d₀
    (position (s.position P (fun i p=>Option (ZMod (value i p))) J B)) c.sourceLists
    (position c.target) c.targetLists ∧
  |((latticeDet (position (s.position P (fun i p=>Option (ZMod (value i p))) J B))
      (position c.target)/(sourcePadProduct value c.sourceLists:ℤ):ℤ):ℝ)|≤C*Y

/-- Exactly the first-good test needed for each physical omission pad. -/
def GoodProjection (r Y : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop) : Prop :=
  ∀z b,IsCoprime z.1 z.2→good z b→∃w,latticeDet z w=1 ∧
    SourceGoodState.FirstGoodTest ((sourcePadProduct value b:ℝ)*latticeTau r w/latticeTau r z) Y

theorem target_prime_coprime_pad (hprime : ∀i p,(value i p).Prime)
    (a b : PhysicalActiveLists P J) (hban : sourceCrossEdgeBan value a b) (i : Fin K) :
    (value i (b i (Fin.last J))).Coprime (sourcePadProduct value a) := by
  apply Nat.Coprime.prod_right
  intro k hk
  apply Nat.Coprime.prod_right
  intro j hj
  apply (Nat.coprime_primes (hprime i _) (hprime k _)).mpr
  exact (physicalSourceLabels_ne_target_of_ban value a b hban (k,j.castSucc) i).symm

 theorem support_slope (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 0≤Y) (hC : 0≤C) (c : PhysicalEdgeChoice s)
    (hc : Support value position s good u v r U W d₀ Y C c) :
    |latticeSlope r (position c.target)-
      latticeSlope r (position (s.position P (fun i p=>Option (ZMod (value i p))) J B))|≤
      (512*C)*d₀*Y := by
  have hz := sourcePhysicalPosition_tau_bounds u v r U W _ hU hu hu' hc.2.1.1
  have ht := sourcePhysicalPosition_tau_bounds u v r U W _ hU hu hu' hc.2.1.2.1
  have hD := hc.2.1.2.2.2.2.2.1
  have hDu := hc.2.1.2.2.2.2.2.2.1
  have he := Int.ediv_mul_cancel hc.2.1.2.2.2.2.2.2.2
  have he' : ((latticeDet (position (s.position P (fun i p=>Option (ZMod (value i p))) J B)) (position c.target) : ℤ):ℝ)=
      (((latticeDet (position (s.position P (fun i p=>Option (ZMod (value i p))) J B)) (position c.target)/(sourcePadProduct value c.sourceLists:ℤ):ℤ):ℝ)*(sourcePadProduct value c.sourceLists:ℝ)) := by
    exact_mod_cast he.symm
  have hdet : |((latticeDet (position (s.position P (fun i p=>Option (ZMod (value i p))) J B)) (position c.target):ℤ):ℝ)|≤2*d₀*Y*C := by
    rw [he',abs_mul,abs_of_nonneg (show (0:ℝ)≤sourcePadProduct value c.sourceLists by positivity)]
    calc
      _ ≤ (C*Y)*(2*d₀) := mul_le_mul hc.2.2 hDu.le (by positivity) (mul_nonneg hC hY)
      _ = _ := by ring
  have hh := latticeSlope_step_le r (1/16) (2*d₀*Y*C) _ _ (by norm_num)
    (by positivity) hz.1 ht.1 hdet
  convert hh using 1 <;> ring

/-- Fixed literal data have a retained-anchor target saving. The supplied
set may have arbitrary additional restrictions. -/
theorem fixed_key_card_le
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ)) (hg : GoodProjection value r Y good)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀c∈S,Support value position s good u v r U W d₀ Y C c)
    (hkey : ∀c∈S,∀d∈S,PhysicalDirtyCrude.key value s c=PhysicalDirtyCrude.key value s d)
    (hprom : ∀c∈S,∃i,edgeChoicePromotes (c.group i)=true) :
    (S.card:ℝ)≤72*(256*(512*C))^2*Y*(R⁻¹+Y^(-(1/5:ℝ))) := by
  by_cases he : S=∅
  · subst S
    simp only [Finset.card_empty,Nat.cast_zero]
    positivity
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hs₀ := hS c₀ hc₀
  obtain ⟨i,hi⟩ := hprom c₀ hc₀
  obtain ⟨a₀,ha₀⟩ : ∃a₀,(c₀.group i).2=Sum.inl a₀ := by
    cases he : (c₀.group i).2 with
    | inl a => exact ⟨a,rfl⟩
    | inr p => simp [edgeChoicePromotes,he] at hi
  let p := value i ((s.memory P (fun i p=>Option (ZMod (value i p))) J B i).values a₀).1
  let z := position (s.position P (fun i p=>Option (ZMod (value i p))) J B)
  let D := sourcePadProduct value c₀.sourceLists
  let : Fact p.Prime := ⟨hprime i _⟩
  have hpD : (D:ZMod p)≠0 := by
    have hh := target_prime_coprime_pad value hprime c₀.sourceLists c₀.targetLists hs₀.2.1.2.2.2.2.1 i
    simp only [PhysicalEdgeChoice.targetLists_last,edgeTargetPrime,ha₀] at hh
    exact fun hz=>(Nat.Prime.coprime_iff_not_dvd (hprime i _)).mp hh ((ZMod.natCast_eq_zero_iff D p).mp hz)
  obtain ⟨w,hw,hgood⟩ := hg z c₀.sourceLists hs₀.2.1.1.1 hs₀.2.1.2.2.1
  have hsource (c) (hc : c∈S) : c.sourceLists=c₀.sourceLists := by
    have hh := congrArg Prod.fst (hkey c hc c₀ hc₀)
    change c.sourcePerm=c₀.sourcePerm at hh
    funext k j
    simp only [PhysicalEdgeChoice.sourceLists,hh]
  have hgroup (c) (hc : c∈S) : c.group=c₀.group :=
    congrArg (fun k : PhysicalDirtyCrude.Key value s=>k.2.1) (hkey c hc c₀ hc₀)
  have hinj : Set.InjOn (fun c : PhysicalEdgeChoice s=>position c.target) S := by
    intro c hc d hd h
    exact Prod.ext (hposition h) (hkey c hc d hd)
  have hh := PhysicalComparisonAnchor.actual_anchor_count p z w hw (D:ℤ)
    (by simpa only [Int.cast_natCast] using hpD) u v r U W d₀ Y (512*C)
    hU hu hu' hd hs₀.2.1.2.2.2.2.2.1 hY (by linarith) hs₀.2.1.1 hgood
    ((s.memory P (fun i p=>Option (ZMod (value i p))) J B i).values a₀).2
    (S.image (fun c=>position c.target))
    (by intro t ht;obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp ht;exact (hS c hc).2.1.2.1)
    (by intro t ht;obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp ht
        have hh := (hS c hc).2.1.2.2.2.2.2.2.2
        rw [hsource c hc] at hh
        exact hh)
    (by intro t ht;obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp ht
        exact support_slope value position s good u v r U W d₀ Y C hU hu hu' hd (by linarith) (by linarith) c (hS c hc))
    (by intro t ht;obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp ht
        have hh := ((hS c hc).1.1 i).1
        rw [hgroup c hc] at hh
        simp only [edgePromotionHits,ha₀,particleHits] at hh
        exact hh.symm)
  rw [Finset.card_image_of_injOn hinj] at hh
  apply hh.trans
  have hp : R≤(p:ℝ) := hband i _
  gcongr

/-- The opposite comparison row has a uniform O(Y) target count before
the comparison Fourier factor is applied. No goodness test is needed. -/
theorem fixed_key_card_le_coarse
    (hposition : Function.Injective position)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C : ℝ) (hU : 0<U) (hY : 1≤Y) (hC : 0≤C)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀c∈S,Support value position s good u v r U W d₀ Y C c)
    (hkey : ∀c∈S,∀d∈S,PhysicalDirtyCrude.key value s c=PhysicalDirtyCrude.key value s d) :
    (S.card:ℝ)≤33*(2*C+1)*Y := by
  by_cases he : S=∅
  · subst S
    simp only [Finset.card_empty,Nat.cast_zero]
    positivity
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hs₀ := hS c₀ hc₀
  obtain ⟨w,hw⟩ := exists_unimodular_complement hs₀.2.1.1.1
  have hinj : Set.InjOn (fun c : PhysicalEdgeChoice s=>position c.target) S := by
    intro c hc d hd h
    exact Prod.ext (hposition h) (hkey c hc d hd)
  rw [←Finset.card_image_of_injOn hinj]
  apply SingleEdgeTargetCount.comparison_targets_card_le hw r
    (sourcePhysicalPositionAllowed_ratio_le u v r U W _ _ hU hs₀.2.1.1 hs₀.2.1.2.1).1
    (sourcePadProduct value c₀.sourceLists:ℤ) C Y hC hY
  intro t ht
  obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp ht
  have hh := congrArg Prod.fst (hkey c hc c₀ hc₀)
  change c.sourcePerm=c₀.sourcePerm at hh
  have he : c.sourceLists=c₀.sourceLists := by
    funext i j
    simp only [PhysicalEdgeChoice.sourceLists,hh]
  have hs := hS c hc
  refine ⟨?_,?_,(sourcePhysicalPositionAllowed_ratio_le u v r U W _ _ hU hs.2.1.1 hs.2.1.2.1).2⟩
  · simpa only [he] using hs.2.1.2.2.2.2.2.2.2
  · simpa only [he] using hs.2.2

end Elliptic.Operator.PhysicalComparisonChoices
