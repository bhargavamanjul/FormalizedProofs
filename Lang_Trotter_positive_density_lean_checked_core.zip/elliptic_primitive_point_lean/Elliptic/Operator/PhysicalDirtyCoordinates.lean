module

public import Elliptic.Operator.DirtyAnchoredRaw
public import Elliptic.Operator.PhysicalEdgeReindexing
public import Mathlib.Algebra.BigOperators.Fin

/-!
# Literal physical products and dirty raw integer coordinates

This identifies the source omission product and full source product from
the actual endpoint permutation. It then derives the raw determinant and
integer tube from the physical edge equation and physical boxes. These
are coordinate/support deductions; a sharp weighted row bound is separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalDirtyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {P : Fin K → Type} {Line : ∀ i, P i → Type}

/-- Numeric source labels before either endpoint permutation. -/
def physicalSourceLabels (value : ∀ i, P i → ℕ) (a : PhysicalActiveLists P J) :
    Fin K × Fin (J+1) → ℕ := fun ij => value ij.1 (a ij.1 ij.2)

/-- Source slot inclusion into the cross-edge labels: the final source
slot is the false branch, distinct from the final target slot. -/
def sourceCrossSlot : Fin (J+1) → Fin J ⊕ Bool :=
  Fin.lastCases (.inr false) Sum.inl

theorem sourceCrossSlot_injective : Function.Injective (sourceCrossSlot (J:=J)) := by
  let read : Fin J ⊕ Bool → Fin (J+1) := Sum.elim Fin.castSucc (fun _ => Fin.last J)
  have h : Function.LeftInverse read sourceCrossSlot := by
    intro j
    refine Fin.lastCases ?_ (fun k => ?_) j <;> simp [read, sourceCrossSlot]
  exact h.injective

theorem physicalSourceLabels_eq_cross (value : ∀ i, P i → ℕ)
    (a b : PhysicalActiveLists P J) (ij : Fin K × Fin (J+1)) :
    physicalSourceLabels value a ij = sourceCrossEdgeLabels value a b
      (ij.1, sourceCrossSlot ij.2) := by
  rcases ij with ⟨i,j⟩
  refine Fin.lastCases ?_ (fun k => ?_) j <;> simp [physicalSourceLabels, sourceCrossEdgeLabels, sourceCrossSlot]

/-- The literal numeric cross-edge ban supplies full numeric source
injectivity, including collisions between different groups. -/
theorem physicalSourceLabels_injective_of_ban (value : ∀ i, P i → ℕ)
    (a b : PhysicalActiveLists P J) (hban : sourceCrossEdgeBan value a b) :
    Function.Injective (physicalSourceLabels value a) := by
  intro ij kl h
  have he : (ij.1, sourceCrossSlot ij.2) = (kl.1, sourceCrossSlot kl.2) := by
    apply hban.2
    simpa only [← physicalSourceLabels_eq_cross] using h
  have h₁ : ij.1 = kl.1 := congrArg (fun x : Fin K × (Fin J ⊕ Bool) => x.1) he
  have h₂ : ij.2 = kl.2 := sourceCrossSlot_injective
    (congrArg (fun x : Fin K × (Fin J ⊕ Bool) => x.2) he)
  exact Prod.ext h₁ h₂

/-- A numeric source label cannot equal any numeric unshared target. -/
theorem physicalSourceLabels_ne_target_of_ban (value : ∀ i, P i → ℕ)
    (a b : PhysicalActiveLists P J) (hban : sourceCrossEdgeBan value a b)
    (ij : Fin K × Fin (J+1)) (i : Fin K) :
    physicalSourceLabels value a ij ≠ value i (b i (Fin.last J)) := by
  intro h
  have he : (ij.1, sourceCrossSlot ij.2) = (i, Sum.inr true) := by
    apply hban.2
    rw [← physicalSourceLabels_eq_cross]
    exact h
  have hh := congrArg Prod.snd he
  rcases ij with ⟨k,j⟩
  revert hh
  refine Fin.lastCases ?_ (fun l => ?_) j <;> simp [sourceCrossSlot]

/-- Groupwise source permutations give an actual slot bijection. -/
def physicalSlotPermEquiv (τ : Fin K → Equiv.Perm (Fin (J+1))) :
    (Fin K × Fin (J+1)) ≃ (Fin K × Fin (J+1)) where
  toFun ij := (ij.1,τ ij.1 ij.2)
  invFun ij := (ij.1,(τ ij.1).symm ij.2)
  left_inv ij := by simp
  right_inv ij := by simp

/-- The ban after the actual source permutation implies injectivity of
the original source labels used by the dirty omission coordinates. -/
theorem physicalSourceLabels_original_injective (value : ∀ i, P i → ℕ)
    (a b : PhysicalActiveLists P J) (τ : Fin K → Equiv.Perm (Fin (J+1)))
    (hban : sourceCrossEdgeBan value (fun i j => a i (τ i j)) b) :
    Function.Injective (physicalSourceLabels value a) := by
  have hi := physicalSourceLabels_injective_of_ban value _ b hban
  intro x y h
  have he : (physicalSlotPermEquiv τ).symm x = (physicalSlotPermEquiv τ).symm y := by
    apply hi
    simpa only [physicalSourceLabels, physicalSlotPermEquiv, Equiv.coe_fn_symm_mk,
      Equiv.apply_symm_apply] using h
  exact (physicalSlotPermEquiv τ).symm.injective he

/-- The copied pad is exactly the omission product, even though the
retained slots have an arbitrary order. -/
theorem sourcePadProduct_eq_copiedProduct
    (value : ∀ i, P i → ℕ) (a : PhysicalActiveLists P J)
    (τ : Fin K → Equiv.Perm (Fin (J+1)))
    (hinj : Function.Injective (physicalSourceLabels value a)) :
    sourcePadProduct value (fun i j => a i (τ i j)) =
      copiedProduct (physicalSourceLabels value a) (fun i => τ i (Fin.last J)) := by
  rw [copiedProduct_eq_slot_product _ hinj]
  simp only [sourcePadProduct, Finset.prod_filter, Fintype.prod_prod_type, physicalSourceLabels]
  apply Finset.prod_congr rfl
  intro i _
  have h := Equiv.prod_comp (τ i)
    (fun j => if j ≠ τ i (Fin.last J) then value i (a i j) else 1)
  rw [← h, Fin.prod_univ_castSucc]
  simp only [(τ i).injective.ne_iff, Fin.castSucc_ne_last, ne_eq, not_false_eq_true,
    ite_true, not_true_eq_false, ite_false, mul_one]

/-- The actual pad times the actual unshared source slots gives the
original full numeric source product, independent of source permutations. -/
theorem sourcePadProduct_mul_unshared_eq_fullSourceProduct
    (value : ∀ i, P i → ℕ) (a : PhysicalActiveLists P J)
    (τ : Fin K → Equiv.Perm (Fin (J+1)))
    (hinj : Function.Injective (physicalSourceLabels value a)) :
    sourcePadProduct value (fun i j => a i (τ i j)) *
      sourceUnsharedProduct value (fun i j => a i (τ i j)) =
      fullSourceProduct (physicalSourceLabels value a) := by
  rw [fullSourceProduct_eq_slot_product _ hinj]
  simp only [sourcePadProduct, sourceUnsharedProduct, physicalSourceLabels,
    Fintype.prod_prod_type, ← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  rw [← Fin.prod_univ_castSucc (fun j => value i (a i (τ i j)))]
  exact Equiv.prod_comp (τ i) (fun j => value i (a i j))

/-- Both actual physical boxes imply the exact ratio tube used in the
integer target-coordinate count. No separate tube hypothesis is imposed. -/
theorem sourcePhysicalPositionAllowed_ratio_le
    (u v r U W : ℝ) (z w : ℤ × ℤ) (hU : 0 < U)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hw : sourcePhysicalPositionAllowed u v r U W w) :
    latticeTau r z ≠ 0 ∧ |latticeTau r w / latticeTau r z| ≤ 16 := by
  have hzlo : U ≤ u * latticeTau r z := hz.2.1
  have hwlo : U ≤ u * latticeTau r w := hw.2.1
  have hwhi : u * latticeTau r w ≤ 16 * U := hw.2.2.1
  have hzpos : 0 < u * latticeTau r z := hU.trans_le hzlo
  have hwpos : 0 < u * latticeTau r w := hU.trans_le hwlo
  have hu : u ≠ 0 := by intro hu; simp [hu] at hzpos
  have hzt : latticeTau r z ≠ 0 := by intro ht; simp [ht] at hzpos
  refine ⟨hzt, ?_⟩
  have hr : latticeTau r w / latticeTau r z =
      (u * latticeTau r w) / (u * latticeTau r z) := by field_simp
  rw [hr, abs_of_pos (div_pos hwpos hzpos)]
  apply (div_le_iff₀ hzpos).mpr
  linarith

/-- The source normalized raw equation is exactly the determinant
equation in the omission/product coordinates. -/
theorem physical_raw_determinant
    (value : ∀ i, P i → ℕ) (a : PhysicalActiveLists P J)
    (τ : Fin K → Equiv.Perm (Fin (J+1)))
    (hinj : Function.Injective (physicalSourceLabels value a))
    (b : PhysicalActiveLists P J) (z w : ℤ × ℤ) (σ : ℤ) (p Z T : ℕ)
    (hdiv : (sourcePadProduct value (fun i j => a i (τ i j)) : ℤ) ∣ latticeDet z w)
    (hraw : latticeDet z w / (sourcePadProduct value (fun i j => a i (τ i j)) : ℤ) =
      σ * ((sourceUnsharedProduct value (fun i j => a i (τ i j)) : ℤ) -
        (sourceUnsharedProduct value b : ℤ)))
    (htarget : sourceUnsharedProduct value b = p * Z * T) :
    latticeDet z w = rawChoiceDeterminant (physicalSourceLabels value a) p T σ
      ((fun i => τ i (Fin.last J)), Z) := by
  have hm := Int.ediv_mul_cancel hdiv
  rw [hraw] at hm
  have hp := sourcePadProduct_mul_unshared_eq_fullSourceProduct value a τ hinj
  have hpz : (sourcePadProduct value (fun i j => a i (τ i j)) : ℤ) *
      (sourceUnsharedProduct value (fun i j => a i (τ i j)) : ℤ) =
      (fullSourceProduct (physicalSourceLabels value a) : ℤ) := by exact_mod_cast hp
  unfold rawChoiceDeterminant
  rw [← sourcePadProduct_eq_copiedProduct value a τ hinj, ← hpz]
  rw [htarget] at hm
  push_cast at hm
  dsimp only
  linear_combination -hm

namespace PhysicalEdgeChoice
variable {Z : Type} {s : PhysicalMemoryState (Z:=Z) P Line J B}

/-- The actual groups selecting old indexed particles. -/
def promotedGroups (c : PhysicalEdgeChoice s) : Finset (Fin K) :=
  Finset.univ.filter (fun i => ∃ a, (c.group i).2 = Sum.inl a)

/-- The numeric product of all other actual promoted targets. -/
def otherPromotedProduct (value : ∀ i, P i → ℕ) (c : PhysicalEdgeChoice s)
    (i₀ : Fin K) : ℕ :=
  ∏ i ∈ c.promotedGroups.erase i₀, value i (edgeTargetPrime (s.memory P Line J B i) (c.group i))

/-- The numeric product of all actual fresh target draws. -/
def freshTargetProduct (value : ∀ i, P i → ℕ) (c : PhysicalEdgeChoice s) : ℕ :=
  ∏ i ∈ c.promotedGroupsᶜ, value i (edgeTargetPrime (s.memory P Line J B i) (c.group i))

/-- Exact factorization of the actual unshared target product. No product
decomposition is imposed as an extra hypothesis. -/
theorem targetProduct_split_promoted
    (value : ∀ i, P i → ℕ) (c : PhysicalEdgeChoice s) (i₀ : Fin K)
    (a₀ : Fin (s.memory P Line J B i₀).size) (hc : (c.group i₀).2 = Sum.inl a₀) :
    sourceUnsharedProduct value c.targetLists =
      value i₀ ((s.memory P Line J B i₀).values a₀).1 *
        c.otherPromotedProduct value i₀ * c.freshTargetProduct value := by
  have hi : i₀ ∈ c.promotedGroups := by simp [promotedGroups,hc]
  have hp := Finset.mul_prod_erase c.promotedGroups
    (fun i => value i (edgeTargetPrime (s.memory P Line J B i) (c.group i))) hi
  have hs := Finset.prod_mul_prod_compl c.promotedGroups
    (fun i => value i (edgeTargetPrime (s.memory P Line J B i) (c.group i)))
  unfold sourceUnsharedProduct otherPromotedProduct freshTargetProduct
  simp only [targetLists_last]
  rw [← hs, ← hp]
  simp only [edgeTargetPrime, hc]

/-- All numeric source labels are different from any promoted target;
the actual source permutation is inverted, with no value-map injectivity. -/
theorem original_source_ne_target (value : ∀ i, P i → ℕ) (c : PhysicalEdgeChoice s)
    (hban : sourceCrossEdgeBan value c.sourceLists c.targetLists)
    (ij : Fin K × Fin (J+1)) (i : Fin K) :
    physicalSourceLabels value (s.active P Line J B) ij ≠
      value i (edgeTargetPrime (s.memory P Line J B i) (c.group i)) := by
  have hh := physicalSourceLabels_ne_target_of_ban value c.sourceLists c.targetLists hban
    (ij.1,(c.sourcePerm ij.1).symm ij.2) i
  simpa only [physicalSourceLabels, sourceLists, targetLists_last, Equiv.apply_symm_apply] using hh

/-- The actual cross-edge ban supplies the coprimality required by the
old/new product uniqueness argument for the other promoted targets. -/
theorem fullSourceProduct_coprime_otherPromotedProduct
    (value : ∀ i, P i → ℕ) (hprime : ∀ i p, (value i p).Prime)
    (c : PhysicalEdgeChoice s)
    (hban : sourceCrossEdgeBan value c.sourceLists c.targetLists) (i₀ : Fin K) :
    (fullSourceProduct (physicalSourceLabels value (s.active P Line J B))).Coprime
      (c.otherPromotedProduct value i₀) := by
  apply Nat.Coprime.prod_left
  intro p hp
  obtain ⟨ij,_,rfl⟩ := Finset.mem_image.mp hp
  apply Nat.Coprime.prod_right
  intro i hi
  exact (Nat.coprime_primes (hprime ij.1 _) (hprime i _)).mpr
    (c.original_source_ne_target value hban ij i)

end PhysicalEdgeChoice

namespace PhysicalDirtyCoordinates
variable {Z : Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- The raw coordinate is read from the literal edge: omission slots,
other promoted numeric product, and the target's integral h coordinate. -/
def coordinate (c : PhysicalEdgeChoice s) (i₀ : Fin K) (w : ℤ × ℤ) :
    RawDirtyCoordinate K (J+1) :=
  ((fun i => c.sourcePerm i (Fin.last J), c.otherPromotedProduct value i₀),
    latticeDet (position c.target) w)

/-- The physical data counted after removing old-index and retained-slot
multiplicities: actual omission, promoted product and integer target. -/
def targetData (c : PhysicalEdgeChoice s) (i₀ : Fin K) :
    ((Fin K → Fin (J+1)) × ℕ) × (ℤ × ℤ) :=
  ((fun i => c.sourcePerm i (Fin.last J), c.otherPromotedProduct value i₀), position c.target)

/-- Every valid raw physical edge lies in the actual anchored coordinate
set. The determinant/product/tube/retained-line conditions are all derived
from the literal physical choice, its raw equation and the physical boxes.
Only membership in the chosen numeric product support is supplied. -/
theorem coordinate_mem_anchored
    (c : PhysicalEdgeChoice s) (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (hpromote : (c.group i₀).2 = Sum.inl a₀)
    (hvalid : c.Valid (fun z i p => primeResidueAnchor (value i p) (position z)) s)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (hallowed : sourcePhysicalEdgeAllowed value good u v r U W d₀
      (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) c.sourceLists
      (position c.target) c.targetLists)
    (hraw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B))
        (position c.target) / (sourcePadProduct value c.sourceLists : ℤ) =
      σ * ((sourceUnsharedProduct value c.sourceLists : ℤ) -
        (sourceUnsharedProduct value c.targetLists : ℤ)))
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (newProducts : Finset ℕ) (hproducts : c.otherPromotedProduct value i₀ ∈ newProducts) :
    coordinate value position s c i₀ w ∈ anchoredRawChoiceCoordinates
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
      newProducts (value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1)
      (c.freshTargetProduct value) σ
      (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
      (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).2 := by
  let z := position (s.position P (fun i p => Option (ZMod (value i p))) J B)
  have hban := hallowed.2.2.2.2.1
  have hinj := physicalSourceLabels_original_injective value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c.targetLists c.sourcePerm hban
  have hdet := physical_raw_determinant value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c.sourcePerm hinj c.targetLists
    z (position c.target) σ
    (value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1)
    (c.otherPromotedProduct value i₀) (c.freshTargetProduct value)
    hallowed.2.2.2.2.2.2.2 hraw (c.targetProduct_split_promoted value i₀ a₀ hpromote)
  have hratio := sourcePhysicalPositionAllowed_ratio_le u v r U W z (position c.target)
    hU hallowed.1 hallowed.2.1
  apply (mem_anchoredRawChoiceCoordinates _ _ _ _ _ _ _ _ _ _).mpr
  refine ⟨hproducts, ?_, ?_⟩
  · change |(latticeDet (position c.target) w : ℝ) +
        (rawChoiceDeterminant _ _ _ σ _ : ℝ) * (latticeTau r w / latticeTau r z)| ≤ 16
    dsimp only [coordinate]
    rw [← hdet]
    rw [← latticeTau_ratio_coordinates hzw r hratio.1 (position c.target)]
    exact hratio.2
  · change primeResidueAnchor _ (targetVector z w (rawChoiceDeterminant _ _ _ σ _)
        (latticeDet (position c.target) w)) = _
    dsimp only [coordinate]
    rw [← hdet, targetVector_decomposition hzw]
    have hh := (hvalid.1 i₀).1
    simp only [edgePromotionHits,hpromote,particleHits] at hh
    exact hh.symm

/-- Literal raw physical support, before any estimates or counting.
The equality is the raw indicator in sourcePhysicalEdgeGeometry. -/
def RawSupport (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (c : PhysicalEdgeChoice s) : Prop :=
  c.Valid (fun z i p => primeResidueAnchor (value i p) (position z)) s ∧
  sourcePhysicalEdgeAllowed value good u v r U W d₀
    (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) c.sourceLists
    (position c.target) c.targetLists ∧
  latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B))
      (position c.target) / (sourcePadProduct value c.sourceLists : ℤ) =
    σ * ((sourceUnsharedProduct value c.sourceLists : ℤ) -
      (sourceUnsharedProduct value c.targetLists : ℤ))

/-- Recover the actual integer target from its dirty coordinate. The
fresh product is fixed here exactly as in the raw row integration. -/
theorem target_eq_coordinate_reconstruction
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (c : PhysicalEdgeChoice s)
    (hc : RawSupport value position s good u v r U W d₀ σ c)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (hpromote : (c.group i₀).2 = Sum.inl a₀)
    (T : ℕ) (hT : c.freshTargetProduct value = T) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1) :
    position c.target = targetVector
      (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w
      (rawChoiceDeterminant
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1)
        T σ (coordinate value position s c i₀ w).1)
      (coordinate value position s c i₀ w).2 := by
  have hi := physicalSourceLabels_original_injective value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c.targetLists c.sourcePerm
    hc.2.1.2.2.2.2.1
  have hd := physical_raw_determinant value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c.sourcePerm hi c.targetLists
    (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) (position c.target) σ
    (value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1)
    (c.otherPromotedProduct value i₀) (c.freshTargetProduct value)
    hc.2.1.2.2.2.2.2.2.2 hc.2.2 (c.targetProduct_split_promoted value i₀ a₀ hpromote)
  rw [hT] at hd
  dsimp only [coordinate]
  rw [← hd, targetVector_decomposition hzw]

/-- Two actual raw choices with equal dirty coordinates have equal
omission/product/integer-target data. Indexed memory particles may still
differ and are deliberately not identified by this theorem. -/
theorem targetData_eq_of_coordinate_eq
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (c d : PhysicalEdgeChoice s)
    (hc : RawSupport value position s good u v r U W d₀ σ c)
    (hd : RawSupport value position s good u v r U W d₀ σ d)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (hpc : (c.group i₀).2 = Sum.inl a₀) (hpd : (d.group i₀).2 = Sum.inl a₀)
    (T : ℕ) (hTc : c.freshTargetProduct value = T) (hTd : d.freshTargetProduct value = T)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (heq : coordinate value position s c i₀ w = coordinate value position s d i₀ w) :
    targetData value position s c i₀ = targetData value position s d i₀ := by
  apply Prod.ext
  · exact congrArg (fun x : RawDirtyCoordinate K (J+1) => x.1) heq
  · change position c.target = position d.target
    rw [target_eq_coordinate_reconstruction value position s good u v r U W d₀ σ c hc i₀ a₀ hpc T hTc w hzw,
      target_eq_coordinate_reconstruction value position s good u v r U W d₀ σ d hd i₀ a₀ hpd T hTd w hzw,
      heq]

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- The actual raw choices with a fixed distinguished old index and
fixed numeric fresh product. Both endpoint permutations remain present. -/
def rawChoices (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size) (T : ℕ) :
    Finset (PhysicalEdgeChoice s) :=
  Finset.univ.filter (fun c => RawSupport value position s good u v r U W d₀ σ c ∧
    (c.group i₀).2 = Sum.inl a₀ ∧ c.freshTargetProduct value = T)

/-- Numeric other-promotion products actually realized by these choices. -/
def rawOtherProducts (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size) (T : ℕ) :
    Finset ℕ :=
  (rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
    (fun c => c.otherPromotedProduct value i₀)

/-- The coordinate image loses no distinct integer target positions.
This uses the raw physical determinant equation, not injectivity of the
ambient map from state positions into integer vectors. -/
theorem rawTargetDataImage_card_eq
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1) :
    ((rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
      (fun c => targetData value position s c i₀)).card =
    ((rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
      (fun c => coordinate value position s c i₀ w)).card := by
  let encode : (((Fin K → Fin (J+1)) × ℕ) × (ℤ × ℤ)) → RawDirtyCoordinate K (J+1) :=
    fun x => (x.1, latticeDet x.2 w)
  have hi : Set.InjOn encode
      ((rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
        (fun c => targetData value position s c i₀)) := by
    intro x hx y hy he
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨d,hd,rfl⟩ := Finset.mem_image.mp hy
    have hc' := (Finset.mem_filter.mp hc).2
    have hd' := (Finset.mem_filter.mp hd).2
    exact targetData_eq_of_coordinate_eq value position s good u v r U W d₀ σ c d
      hc'.1 hd'.1 i₀ a₀ hc'.2.1 hd'.2.1 T hc'.2.2 hd'.2.2 w hzw he
  have hh := (Finset.card_image_of_injOn hi).symm
  rw [Finset.image_image] at hh
  exact hh

/-- A sharp coordinate-image count for the actual finite physical raw
choices. Source injectivity, old/new coprimality and the promoted anchor
test are derived, leaving only the explicit phase-separation test and its
numeric width. This counts distinct omission/product/target coordinates,
not indexed-promotion or retained-permutation multiplicities. -/
theorem rawCoordinateImage_card_le
    (hprime : ∀ i p, (value i p).Prime)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ)
    (hsep : PhaseSeparated
      (dirtyProductSupport
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T))
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ) :
    ((rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
      (fun c => coordinate value position s c i₀ w)).card ≤ 33 := by
  let C := rawChoices value position s good u v r U W d₀ σ i₀ a₀ T
  by_cases he : C = ∅
  · simp only [← show C = rawChoices value position s good u v r U W d₀ σ i₀ a₀ T from rfl,
      he,Finset.image_empty,Finset.card_empty,Nat.zero_le]
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hc₀' := (Finset.mem_filter.mp hc₀).2
  let label := physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)
  let products := rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T
  let p := value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1
  let z := position (s.position P (fun i p => Option (ZMod (value i p))) J B)
  let β := latticeTau r w / latticeTau r z
  let : Fact p.Prime := ⟨hprime i₀ _⟩
  have hi : Function.Injective label := physicalSourceLabels_original_injective value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c₀.targetLists c₀.sourcePerm
    hc₀'.1.2.1.2.2.2.2.1
  have hban : ∀ ij, label ij ≠ p := by
    intro ij
    have hh := c₀.original_source_ne_target value hc₀'.1.2.1.2.2.2.2.1 ij i₀
    simpa only [edgeTargetPrime,hc₀'.2.1] using hh
  have hcoprime : ∀ n ∈ products, (fullSourceProduct label).Coprime n := by
    intro n hn
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hn
    exact c.fullSourceProduct_coprime_otherPromotedProduct value hprime
      (Finset.mem_filter.mp hc).2.1.2.1.2.2.2.2.1 i₀
  have hsub : C.image (fun c => coordinate value position s c i₀ w) ⊆
      anchoredRawChoiceCoordinates label products p T σ β z w
        ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).2 := by
    intro x hx
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hx
    have hc' := (Finset.mem_filter.mp hc).2
    have hh := coordinate_mem_anchored value position s c i₀ a₀ hc'.2.1 hc'.1.1
      good u v r U W d₀ σ hU hc'.1.2.1 hc'.1.2.2 w hzw products
      (Finset.mem_image.mpr ⟨c,hc,rfl⟩)
    simpa only [hc'.2.2] using hh
  exact (Finset.card_le_card hsub).trans
    (anchoredRawChoiceCoordinates_card_le label products p T σ β δ hzw _
      (fun ij => hprime ij.1 _) hi hban hcoprime hσ hsep hwidth)

/-- At most 33 distinct actual omission/product/integer-target triples
occur in a phase-separated fixed-fresh-product raw physical fiber. -/
theorem rawTargetDataImage_card_le
    (hprime : ∀ i p, (value i p).Prime)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ)
    (hsep : PhaseSeparated
      (dirtyProductSupport
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T))
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ) :
    ((rawChoices value position s good u v r U W d₀ σ i₀ a₀ T).image
      (fun c => targetData value position s c i₀)).card ≤ 33 := by
  rw [rawTargetDataImage_card_eq value position s good u v r U W d₀ σ i₀ a₀ T w hzw]
  exact rawCoordinateImage_card_le value position s hprime good u v r U W d₀ σ hU hσ
    i₀ a₀ T w hzw δ hsep hwidth

end PhysicalDirtyCoordinates

end Elliptic.Operator
