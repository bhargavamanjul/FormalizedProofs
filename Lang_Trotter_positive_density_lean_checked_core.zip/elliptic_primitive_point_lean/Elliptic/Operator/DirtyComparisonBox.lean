module

public import Elliptic.Operator.SourceMemoryEdges
public import Mathlib.Data.Int.CardIntervalMod
import Mathlib.Tactic

/-!
# Actual lattice-box counts for a prescribed residue line

This proves the congruence count in PD (4.40) for the literal integer
rectangle, then applies it to the project's actual projective anchors
after an integer basis change invertible modulo the promoted prime.
No target-count or Schur estimate is assumed. Constructing the short
good-state lattice basis and summing the full memory edge are separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

/-- One residue class in an arbitrary integer interval has the expected
length divided by the modulus, with an absolute endpoint error one. -/
theorem integer_interval_residue_card_le (p : ℕ) (hp : 0 < p)
    (a b v : ℤ) (hab : a ≤ b) :
    (((Finset.Ico a b).filter (fun x => x ≡ v [ZMOD (p : ℤ)])).card : ℝ) ≤
      ((b : ℝ) - a) / p + 1 := by
  have hpq : (0 : ℚ) < p := by exact_mod_cast hp
  have habq : (a : ℚ) ≤ b := by exact_mod_cast hab
  have hc := Int.Ico_filter_modEq_card a b (r := (p : ℤ)) (by exact_mod_cast hp) v
  have hceil : ⌈((a : ℚ) - v) / p⌉ ≤ ⌈((b : ℚ) - v) / p⌉ :=
    Int.ceil_mono (div_le_div_of_nonneg_right (sub_le_sub_right habq _) hpq.le)
  have hcq :
      (((Finset.Ico a b).filter (fun x => x ≡ v [ZMOD (p : ℤ)])).card : ℚ) =
        (⌈((b : ℚ) - v) / p⌉ : ℚ) - ⌈((a : ℚ) - v) / p⌉ := by
    norm_num only [Int.cast_natCast, Int.cast_sub] at hc
    rw [max_eq_left (sub_nonneg.mpr hceil)] at hc
    exact_mod_cast hc
  have hq :
      (((Finset.Ico a b).filter (fun x => x ≡ v [ZMOD (p : ℤ)])).card : ℚ) ≤
        ((b : ℚ) - a) / p + 1 := by
    rw [hcq]
    have htop := Int.ceil_lt_add_one (((b : ℚ) - v) / p)
    have hbot := Int.le_ceil (((a : ℚ) - v) / p)
    have heq : ((b : ℚ) - a) / p = ((b : ℚ) - v) / p - ((a : ℚ) - v) / p := by ring
    rw [heq]
    linarith
  exact_mod_cast hq

/-- The same estimate for a literal `ZMod` residue. -/
theorem integer_interval_zmod_card_le (p : ℕ) [NeZero p]
    (a b : ℤ) (hab : a ≤ b) (v : ZMod p) :
    (((Finset.Ico a b).filter (fun x : ℤ => (x : ZMod p) = v)).card : ℝ) ≤
      ((b : ℝ) - a) / p + 1 := by
  have heq : (fun x : ℤ => (x : ZMod p) = v) =
      (fun x : ℤ => x ≡ (v.val : ℤ) [ZMOD (p : ℤ)]) := by
    funext x
    rw [← ZMod.intCast_eq_intCast_iff]
    simp
  have hset : (Finset.Ico a b).filter (fun x : ℤ => (x : ZMod p) = v) =
      (Finset.Ico a b).filter (fun x => x ≡ (v.val : ℤ) [ZMOD (p : ℤ)]) := by
    apply Finset.filter_congr
    intro x hx
    exact Iff.of_eq (congrFun heq x)
  rw [hset]
  exact integer_interval_residue_card_le p (NeZero.pos p) a b v.val hab

/-- Integer rectangle cut out by one literal affine congruence. -/
def integerCongruenceBox (p : ℕ) (a b c d : ℤ) (A B t : ZMod p) :
    Finset (ℤ × ℤ) :=
  ((Finset.Ico a b) ×ˢ (Finset.Ico c d)).filter
    (fun z : ℤ × ℤ => A * (z.1 : ZMod p) + B * (z.2 : ZMod p) = t)

theorem integerCongruenceBox_card_eq_sum (p : ℕ) (a b c d : ℤ) (A B t : ZMod p) :
    (integerCongruenceBox p a b c d A B t).card =
      ∑ x ∈ Finset.Ico a b,
        ((Finset.Ico c d).filter
          (fun y : ℤ => A * (x : ZMod p) + B * (y : ZMod p) = t)).card := by
  classical
  simp only [integerCongruenceBox, Finset.card_eq_sum_ones, Finset.sum_filter,
    Finset.sum_product]

/-- Slicing in a coordinate with nonzero coefficient gives a sharp area
term and just one side-length error. -/
theorem integerCongruenceBox_card_le_of_second_ne_zero
    (p : ℕ) [Fact p.Prime] (a b c d : ℤ) (hab : a ≤ b) (hcd : c ≤ d)
    (A B t : ZMod p) (hB : B ≠ 0) :
    ((integerCongruenceBox p a b c d A B t).card : ℝ) ≤
      ((b : ℝ) - a) * ((d : ℝ) - c) / p + ((b : ℝ) - a) := by
  classical
  have hf (x : ℤ) :
      (Finset.Ico c d).filter
          (fun y : ℤ => A * (x : ZMod p) + B * (y : ZMod p) = t) =
        (Finset.Ico c d).filter
          (fun y : ℤ => (y : ZMod p) = (t - A * (x : ZMod p)) / B) := by
    apply Finset.filter_congr
    intro y hy
    rw [eq_div_iff hB]
    constructor <;> intro h <;> linear_combination h
  have hs : ∀ x : ℤ,
      (((Finset.Ico c d).filter
          (fun y : ℤ => A * (x : ZMod p) + B * (y : ZMod p) = t)).card : ℝ) ≤
        ((d : ℝ) - c) / p + 1 := by
    intro x
    rw [hf]
    exact integer_interval_zmod_card_le p c d hcd _
  rw [integerCongruenceBox_card_eq_sum, Nat.cast_sum]
  calc
    _ ≤ ∑ x ∈ Finset.Ico a b, (((d : ℝ) - c) / p + 1) :=
      Finset.sum_le_sum (fun x hx => hs x)
    _ = _ := by
      simp only [Finset.sum_const, nsmul_eq_mul, Int.card_Ico]
      have hc : ((b - a).toNat : ℝ) = (b : ℝ) - a := by
        exact_mod_cast Int.toNat_of_nonneg (sub_nonneg.mpr hab)
      rw [hc]
      ring

theorem integerCongruenceBox_card_swap (p : ℕ) (a b c d : ℤ) (A B t : ZMod p) :
    (integerCongruenceBox p a b c d A B t).card =
      (integerCongruenceBox p c d a b B A t).card := by
  classical
  simp only [integerCongruenceBox, Finset.card_eq_sum_ones, Finset.sum_filter,
    Finset.sum_product]
  rw [Finset.sum_comm]
  simp only [add_comm]

/-- The literal count in source (4.40), without an unspecified target-count
assumption. It applies also to affine residue lines and translated boxes. -/
theorem integerCongruenceBox_card_le
    (p : ℕ) [Fact p.Prime] (a b c d : ℤ) (hab : a ≤ b) (hcd : c ≤ d)
    (A B t : ZMod p) (hne : A ≠ 0 ∨ B ≠ 0) :
    ((integerCongruenceBox p a b c d A B t).card : ℝ) ≤
      ((b : ℝ) - a) * ((d : ℝ) - c) / p + max ((b : ℝ) - a) ((d : ℝ) - c) := by
  rcases hne with hA | hB
  · rw [integerCongruenceBox_card_swap]
    exact (integerCongruenceBox_card_le_of_second_ne_zero p c d a b hcd hab B A t hA).trans
      (by rw [mul_comm ((d : ℝ) - c)]; gcongr; exact le_max_right _ _)
  · exact (integerCongruenceBox_card_le_of_second_ne_zero p a b c d hab hcd A B t hB).trans
      (by gcongr; exact le_max_left _ _)

/-- The actual integer vector in coordinates of two integer basis columns. -/
def integerBasisVector (u v : ℤ × ℤ) (z : ℤ × ℤ) : ℤ × ℤ :=
  (u.1 * z.1 + v.1 * z.2, u.2 * z.1 + v.2 * z.2)

/-- The linear equation of the literal affine projective-line coordinate. -/
def residueLineCoefficients (p : ℕ) (u v : ℤ × ℤ) :
    Option (ZMod p) → ZMod p × ZMod p
  | none => (u.2, v.2)
  | some r => ((u.1 : ZMod p) - r * u.2, (v.1 : ZMod p) - r * v.2)

/-- A basis invertible modulo p gives a nonzero line equation for every
projective anchor, including the line at infinity. -/
theorem residueLineCoefficients_nonzero (p : ℕ) [Fact p.Prime]
    (u v : ℤ × ℤ) (hdet : (latticeDet u v : ZMod p) ≠ 0)
    (anchor : Option (ZMod p)) :
    (residueLineCoefficients p u v anchor).1 ≠ 0 ∨
      (residueLineCoefficients p u v anchor).2 ≠ 0 := by
  have hd : (u.1 : ZMod p) * v.2 - (u.2 : ZMod p) * v.1 ≠ 0 := by
    simpa only [latticeDet, Int.cast_sub, Int.cast_mul] using hdet
  by_contra h
  push Not at h
  cases anchor with
  | none =>
    simp only [residueLineCoefficients] at h
    apply hd
    simp [h.1, h.2]
  | some r =>
    simp only [residueLineCoefficients] at h
    apply hd
    linear_combination (v.2 : ZMod p) * h.1 - (u.2 : ZMod p) * h.2

/-- Retaining an actual anchor imposes its explicit homogeneous congruence.
Allowing the zero vector on the congruence side only enlarges the set. -/
theorem anchor_basis_implies_linear_congruence
    (p : ℕ) [Fact p.Prime] (u v z : ℤ × ℤ) (anchor : Option (ZMod p))
    (h : primeResidueAnchor p (integerBasisVector u v z) = anchor) :
    (residueLineCoefficients p u v anchor).1 * (z.1 : ZMod p) +
      (residueLineCoefficients p u v anchor).2 * (z.2 : ZMod p) = 0 := by
  have hy : ((integerBasisVector u v z).2 : ZMod p) =
      (u.2 : ZMod p) * z.1 + (v.2 : ZMod p) * z.2 := by
    simp [integerBasisVector]
  have hx : ((integerBasisVector u v z).1 : ZMod p) =
      (u.1 : ZMod p) * z.1 + (v.1 : ZMod p) * z.2 := by
    simp [integerBasisVector]
  cases anchor with
  | none =>
    have hz : ((integerBasisVector u v z).2 : ZMod p) = 0 := by
      by_contra hn
      simp [primeResidueAnchor, hn] at h
    simpa only [residueLineCoefficients, hy] using hz
  | some r =>
    have hz : ((integerBasisVector u v z).2 : ZMod p) ≠ 0 := by
      intro hn
      simp [primeResidueAnchor, hn] at h
    simp only [primeResidueAnchor, hz, ite_false, Option.some.injEq] at h
    have hh : ((integerBasisVector u v z).1 : ZMod p) =
        r * ((integerBasisVector u v z).2 : ZMod p) := by
      apply (div_eq_iff hz).mp
      simpa only [div_eq_mul_inv] using h
    rw [hx, hy] at hh
    simp only [residueLineCoefficients]
    linear_combination hh

/-- The actual box of integer lattice coordinates whose physical vectors
retain a specified projective line. -/
def anchoredIntegerBox (p : ℕ) (a b c d : ℤ) (u v : ℤ × ℤ)
    (anchor : Option (ZMod p)) : Finset (ℤ × ℤ) :=
  ((Finset.Ico a b) ×ˢ (Finset.Ico c d)).filter
    (fun z => primeResidueAnchor p (integerBasisVector u v z) = anchor)

/-- Source (4.40) for literal projective anchors after an integer basis
change. The determinant condition is exactly invertibility modulo p. -/
theorem anchoredIntegerBox_card_le (p : ℕ) [Fact p.Prime]
    (a b c d : ℤ) (hab : a ≤ b) (hcd : c ≤ d)
    (u v : ℤ × ℤ) (hdet : (latticeDet u v : ZMod p) ≠ 0)
    (anchor : Option (ZMod p)) :
    ((anchoredIntegerBox p a b c d u v anchor).card : ℝ) ≤
      ((b : ℝ) - a) * ((d : ℝ) - c) / p + max ((b : ℝ) - a) ((d : ℝ) - c) := by
  have hs : anchoredIntegerBox p a b c d u v anchor ⊆
      integerCongruenceBox p a b c d
        (residueLineCoefficients p u v anchor).1
        (residueLineCoefficients p u v anchor).2 0 := by
    intro z hz
    simp only [anchoredIntegerBox, Finset.mem_filter] at hz
    exact Finset.mem_filter.mpr ⟨hz.1,
      anchor_basis_implies_linear_congruence p u v z anchor hz.2⟩
  have hc : ((anchoredIntegerBox p a b c d u v anchor).card : ℝ) ≤
      ((integerCongruenceBox p a b c d
        (residueLineCoefficients p u v anchor).1
        (residueLineCoefficients p u v anchor).2 0).card : ℝ) := by
    exact_mod_cast Finset.card_le_card hs
  exact hc.trans (integerCongruenceBox_card_le p a b c d hab hcd _ _ 0
    (residueLineCoefficients_nonzero p u v hdet anchor))

/-- A shared-pad determinant gives the required invertibility directly
from the cross-edge exclusion of the promoted prime. -/
theorem anchoredIntegerBox_card_le_of_pad (p D : ℕ) [Fact p.Prime]
    (a b c d : ℤ) (hab : a ≤ b) (hcd : c ≤ d)
    (u v : ℤ × ℤ) (hdet : latticeDet u v = (D : ℤ)) (hpD : ¬p ∣ D)
    (anchor : Option (ZMod p)) :
    ((anchoredIntegerBox p a b c d u v anchor).card : ℝ) ≤
      ((b : ℝ) - a) * ((d : ℝ) - c) / p + max ((b : ℝ) - a) ((d : ℝ) - c) := by
  apply anchoredIntegerBox_card_le p a b c d hab hcd u v _ anchor
  rw [hdet, Int.cast_natCast]
  exact fun h => hpD ((ZMod.natCast_eq_zero_iff D p).mp h)

/-- Once the actual lattice box has area at most `C*Y` and both sides
at least `R`, its retained-anchor count is at most
`C*Y*(1/p+1/R)`. Taking `R=Y^.1` yields source (4.40). -/
theorem anchoredIntegerBox_scaled_card_le (p : ℕ) [Fact p.Prime]
    (a b c d : ℤ) (hab : a ≤ b) (hcd : c ≤ d)
    (u v : ℤ × ℤ) (hdet : (latticeDet u v : ZMod p) ≠ 0)
    (anchor : Option (ZMod p)) (C Y R : ℝ) (hR : 0 < R)
    (hwidth₁ : R ≤ (b : ℝ) - a) (hwidth₂ : R ≤ (d : ℝ) - c)
    (harea : ((b : ℝ) - a) * ((d : ℝ) - c) ≤ C * Y) :
    ((anchoredIntegerBox p a b c d u v anchor).card : ℝ) ≤
      C * Y * ((p : ℝ)⁻¹ + R⁻¹) := by
  have hx : 0 ≤ (b : ℝ) - a := hR.le.trans hwidth₁
  have hy : 0 ≤ (d : ℝ) - c := hR.le.trans hwidth₂
  have hm : max ((b : ℝ) - a) ((d : ℝ) - c) ≤ C * Y / R := by
    apply (le_div_iff₀ hR).mpr
    rcases le_total ((b : ℝ) - a) ((d : ℝ) - c) with h | h
    · rw [max_eq_right h]
      exact (by nlinarith : ((d : ℝ) - c) * R ≤
        ((b : ℝ) - a) * ((d : ℝ) - c)).trans harea
    · rw [max_eq_left h]
      exact (mul_le_mul_of_nonneg_left hwidth₂ hx).trans harea
  calc
    _ ≤ ((b : ℝ) - a) * ((d : ℝ) - c) / p +
        max ((b : ℝ) - a) ((d : ℝ) - c) :=
      anchoredIntegerBox_card_le p a b c d hab hcd u v hdet anchor
    _ ≤ C * Y / p + C * Y / R := by
      gcongr
    _ = _ := by ring

end Elliptic.Operator
