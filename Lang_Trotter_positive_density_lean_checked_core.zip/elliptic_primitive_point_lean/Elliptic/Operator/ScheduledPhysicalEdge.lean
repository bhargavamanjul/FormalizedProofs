module

public import Elliptic.Operator.ScheduledEdgeStep
public import Elliptic.Operator.PhysicalMemoryEdges

/-!
# Scheduled edges in the actual grouped physical state space

The input consists of pending prime sets, their actual ordered memory
representatives, and literal endpoint permutations.  The total cutoff on
the scheduled output derives all local cutoffs and actual physical edge
validity.  Output active lists, pending sets, and the complete signed
coefficient are identified without an assumed history identity.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- Raw scheduled data. In particular, the source unshared prime is not
a supplied independent label: it will be read from the actual active list
after the supplied source permutation. -/
structure ScheduledPhysicalEdgeData
    (s : PhysicalMemoryState (Z:=Z) P Line J B) where
  pending : ∀ i, Finset (P i)
  retained : ∀ i p, Line i p
  enumerates : ∀ i, MemoryEnumeratesSet (pending i) (retained i) (s.memory P Line J B i)
  targetPosition : Z
  sourcePerm : ∀ _i : I, Equiv.Perm (Fin (J+1))
  targetPerm : ∀ _i : I, Equiv.Perm (Fin (J+1))
  store : I → Bool
  promote : I → Bool
  targetPrime : ∀ i, P i
  promoted_mem : ∀ i, promote i = true → targetPrime i ∈ pending i

namespace ScheduledPhysicalEdgeData
variable {s : PhysicalMemoryState (Z:=Z) P Line J B}

/-- An actual physical edge choice, including both endpoint permutations. -/
def choice (d : ScheduledPhysicalEdgeData s) : PhysicalEdgeChoice s :=
  (d.targetPosition, (d.sourcePerm,
    (fun i => scheduledEdgeChoice (d.pending i) (d.retained i)
      (s.memory P Line J B i) (d.enumerates i) (d.store i) (d.promote i)
      (d.targetPrime i) (d.promoted_mem i), d.targetPerm)))

/-- The departing source prime is the actual pre-permuted final slot. -/
def sourcePrime (d : ScheduledPhysicalEdgeData s) (i : I) : P i :=
  d.choice.sourcePrime i

@[simp] theorem sourcePrime_eq (d : ScheduledPhysicalEdgeData s) (i : I) :
    d.sourcePrime i = s.active P Line J B i (d.sourcePerm i (Fin.last J)) := rfl

/-- The prescribed next pending set, after promotion and then storage. -/
def nextSet (d : ScheduledPhysicalEdgeData s) (i : I) : Finset (P i) :=
  (d.pending i \ optionalPrimeSet (d.promote i) (d.targetPrime i)) ∪
    optionalPrimeSet (d.store i) (d.sourcePrime i)

theorem nextSet_card (d : ScheduledPhysicalEdgeData s)
    (hs : ∀ i, d.store i = true → d.sourcePrime i ∉ d.pending i) (i : I) :
    (d.nextSet i).card =
      (d.pending i \ optionalPrimeSet (d.promote i) (d.targetPrime i)).card +
        (d.store i).toNat := by
  have hd : Disjoint (d.pending i \ optionalPrimeSet (d.promote i) (d.targetPrime i))
      (optionalPrimeSet (d.store i) (d.sourcePrime i)) := by
    cases hstore : d.store i <;> simp_all [optionalPrimeSet,Finset.disjoint_singleton_right]
  rw [nextSet,Finset.card_union_of_disjoint hd,optionalPrimeSet_card]

/-- Actual ordered output lengths equal the scheduled output-set sizes. -/
theorem choice_outputSize (d : ScheduledPhysicalEdgeData s)
    (hs : ∀ i, d.store i = true → d.sourcePrime i ∉ d.pending i) (i : I) :
    edgeGroupOutputSize (d.choice.group i) = (d.nextSet i).card := by
  rw [d.nextSet_card hs i]
  exact scheduledEdgeChoice_size (d.pending i) (d.retained i)
    (s.memory P Line J B i) (d.enumerates i) (d.store i) (d.promote i)
    (d.targetPrime i) (d.promoted_mem i)

/-- The total scheduled cutoff derives every per-group cutoff and the
actual physical edge's total cutoff. -/
theorem choice_valid (d : ScheduledPhysicalEdgeData s)
    (anchor : Z → ∀ i p, Line i p)
    (hs : ∀ i, d.store i = true → d.sourcePrime i ∉ d.pending i)
    (hmatch : ∀ i, d.promote i = true →
      d.retained i (d.targetPrime i) = anchor d.targetPosition i (d.targetPrime i))
    (hcut : (∑ i, (d.nextSet i).card) ≤ B) :
    PhysicalEdgeChoice.Valid anchor s d.choice := by
  refine ⟨?_,?_⟩
  · intro i
    apply scheduledEdgeChoice_valid (d.pending i) (d.retained i)
      (anchor d.targetPosition i) (s.memory P Line J B i) (d.enumerates i)
      (d.store i) (d.promote i) (d.targetPrime i) (d.promoted_mem i) (hmatch i)
    rw [← d.nextSet_card hs i]
    exact (Finset.single_le_sum (fun j _ => Nat.zero_le ((d.nextSet j).card))
      (Finset.mem_univ i)).trans hcut
  · simpa only [d.choice_outputSize hs] using hcut

/-- Before the target permutation, all shared source slots survive and
the last slot is exactly the scheduled promoted or fresh target prime. -/
theorem choice_targetLists (d : ScheduledPhysicalEdgeData s) (i : I) :
    d.choice.targetLists i =
      Fin.lastCases (d.targetPrime i)
        (fun j : Fin J => s.active P Line J B i (d.sourcePerm i j.castSucc)) := by
  change (Fin.lastCases
    (edgeTargetPrime (s.memory P Line J B i)
      (scheduledEdgeChoice (d.pending i) (d.retained i)
        (s.memory P Line J B i) (d.enumerates i) (d.store i) (d.promote i)
        (d.targetPrime i) (d.promoted_mem i)))
    (fun j : Fin J => s.active P Line J B i (d.sourcePerm i j.castSucc)) : Fin (J+1) → P i) = _
  rw [scheduledEdgeChoice_target]

/-- The output active lists are the literal pre-permutation lists followed
by the supplied target permutations. -/
theorem output_active (d : ScheduledPhysicalEdgeData s)
    (anchor : Z → ∀ i p, Line i p) (hc : PhysicalEdgeChoice.Valid anchor s d.choice)
    (i : I) (j : Fin (J+1)) :
    (d.choice.output anchor s hc).active P Line J B i j =
      Fin.lastCases (d.targetPrime i)
        (fun k : Fin J => s.active P Line J B i (d.sourcePerm i k.castSucc))
        (d.targetPerm i j) := by
  rw [PhysicalEdgeChoice.output_active,d.choice_targetLists]
  rfl

/-- Every actual output memory is an ordered representative of its next
scheduled set. No reordering or new representative is chosen. -/
theorem output_enumerates [∀ i, Fintype (P i)] (d : ScheduledPhysicalEdgeData s)
    (anchor : Z → ∀ i p, Line i p)
    (hs : ∀ i, d.store i = true → d.sourcePrime i ∉ d.pending i)
    (hmatch : ∀ i, d.store i = true →
      d.retained i (d.sourcePrime i) = anchor (s.position P Line J B) i (d.sourcePrime i))
    (hc : PhysicalEdgeChoice.Valid anchor s d.choice) (i : I) :
    MemoryEnumeratesSet (d.nextSet i) (d.retained i)
      ((d.choice.output anchor s hc).memory P Line J B i) :=
  scheduledEdgeChoice_output_enumerates (d.pending i) (d.retained i)
    (anchor (s.position P Line J B) i) (s.memory P Line J B i) (d.enumerates i)
    (d.store i) (d.promote i) (d.sourcePrime i) (d.targetPrime i)
    (d.promoted_mem i) (hs i) (hmatch i) (hc.1 i).2

/-- Complete physical coefficient, retaining the actual geometric factor
and both uniform endpoint permutation weights. -/
theorem choice_weight [∀ i, Fintype (P i)] (d : ScheduledPhysicalEdgeData s)
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hs : ∀ i, d.store i = true → d.sourcePrime i ∉ d.pending i)
    (hmatch : ∀ i, d.store i = true →
      d.retained i (d.sourcePrime i) = anchor (s.position P Line J B) i (d.sourcePrime i))
    (hc : PhysicalEdgeChoice.Valid anchor s d.choice) :
    physicalEdgeChoiceWeight ν V ρ anchor geometry s d.choice hc =
      (endpointPermutationWeight I J : ℂ) *
        geometry (s.position P Line J B) d.choice.sourceLists d.targetPosition d.choice.targetLists *
        ∏ i, ((ρ ^ ((d.pending i).filter
          (fun p => d.retained i p = anchor (s.position P Line J B) i p)).card *
          (if d.promote i then (V i)⁻¹ else ν i (d.targetPrime i)) *
          ρ ^ ((d.nextSet i).filter
            (fun p => d.retained i p = anchor d.targetPosition i p)).card : ℝ) : ℂ) := by
  unfold physicalEdgeChoiceWeight
  apply congrArg (fun z : ℂ =>
    (endpointPermutationWeight I J : ℂ) *
      geometry (s.position P Line J B) d.choice.sourceLists d.targetPosition d.choice.targetLists * z)
  apply Finset.prod_congr rfl
  intro i _
  exact congrArg (fun r : ℝ => (r : ℂ))
    (scheduledEdgeChoice_weight (ν i) (V i) ρ (d.pending i) (d.retained i)
      (anchor (s.position P Line J B) i) (anchor d.targetPosition i)
      (s.memory P Line J B i) (d.enumerates i) (d.store i) (d.promote i)
      (d.sourcePrime i) (d.targetPrime i) (d.promoted_mem i) (hs i) (hmatch i) (hc.1 i).2)

end ScheduledPhysicalEdgeData
end Elliptic.Operator
