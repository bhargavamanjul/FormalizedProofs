module

public import Elliptic.Operator.RootGoodProductBounds
public import Mathlib.MeasureTheory.Constructions.BorelSpace.Order

/-! Measurability of the literal first and weighted second source tests.
Every finite fresh-tuple summand retains its original weight. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGoodMeasurable
open MeasureTheory Set SourceSecondGoodState
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- No arithmetic nondegeneracy is needed for this measurability fact. -/
theorem phaseSeparated_closed (s : Finset ℕ) (T δ : ℝ) :
    IsClosed {β : ℝ | PhaseSeparated s (T*β) δ} := by
  simp only [PhaseSeparated,Set.setOf_forall]
  refine isClosed_iInter fun a => isClosed_iInter fun _ha =>
    isClosed_iInter fun b => isClosed_iInter fun _hb => isClosed_iInter fun _hne => ?_
  exact isClosed_le continuous_const (by fun_prop)

theorem noSmallMultiple_measurable (D L ε : ℝ) :
    MeasurableSet {β : ℝ | SourceGoodState.NoSmallMultiple (D*β) L ε} := by
  simp only [SourceGoodState.NoSmallMultiple,Set.setOf_forall]
  refine MeasurableSet.iInter fun l => MeasurableSet.iInter fun _hl =>
    MeasurableSet.iInter fun _hL => ?_
  exact measurableSet_lt measurable_const (by fun_prop)

variable {F : Type*} [Fintype F] {Q : F→Type*} [∀ i,Fintype (Q i)]

theorem exceptionalMass_measurable (trials : Finset ℕ)
    (value : ∀ i,Q i→ℕ) (μ : ∀ i,Q i→ℝ) (δ : ℝ) :
    Measurable (fun β : ℝ => exceptionalMass trials value μ β δ) := by
  unfold exceptionalMass
  exact Finset.measurable_sum _ (fun f _ =>
    Measurable.ite (phaseSeparated_closed trials (freshPrimeTupleProduct value f) δ).measurableSet
      measurable_const measurable_const)

variable {K M : ℕ} {P : Fin K→Type} [∀ i,Fintype (P i)]

theorem secondGoodTest_measurable (value : ∀ i,P i→ℕ)
    (label : Fin K×Fin M→ℕ) (μ : ∀ i,P i→ℝ) (d₀ L : ℝ) (a : Fin K→ℝ) :
    MeasurableSet {β : ℝ | SecondGoodTest value label μ d₀ β L a} := by
  simp only [SecondGoodTest,Set.setOf_forall]
  refine MeasurableSet.iInter fun I => MeasurableSet.iInter fun i₀ =>
    MeasurableSet.iInter fun _hi => MeasurableSet.iInter fun _hm => ?_
  exact measurableSet_le (exceptionalMass_measurable _ _ _ _) measurable_const

/-- The exact conjunction used by the source physical state is measurable. -/
theorem bothGoodTests_measurable (value : ∀ i,P i→ℕ)
    (label : Fin K×Fin M→ℕ) (μ : ∀ i,P i→ℝ) (d₀ Y L : ℝ) (a : Fin K→ℝ) :
    MeasurableSet {β : ℝ | (∀ D∈omissionProducts label d₀,
      SourceGoodState.NoSmallMultiple ((D:ℝ)*β) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) ∧
      SecondGoodTest value label μ d₀ β L a} := by
  apply MeasurableSet.inter _ (secondGoodTest_measurable value label μ d₀ L a)
  change MeasurableSet {β : ℝ | ∀ D∈omissionProducts label d₀,
    SourceGoodState.NoSmallMultiple ((D:ℝ)*β) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))}
  simp only [Set.setOf_forall]
  apply MeasurableSet.iInter
  intro D
  apply MeasurableSet.iInter
  intro _
  exact noSmallMultiple_measurable _ _ _

theorem phase_measurable (z w : ℤ×ℤ) :
    Measurable (RootGoodBoundary.phase z w) := by
  unfold RootGoodBoundary.phase latticeTau
  fun_prop

/-- Pullback along the actual complementary root phase; the total real
quotient is measurable even at its pole, so no omitted exceptional set is hidden. -/
theorem bothGoodTests_root_measurable (value : ∀ i,P i→ℕ)
    (label : Fin K×Fin M→ℕ) (μ : ∀ i,P i→ℝ) (d₀ Y L : ℝ) (a : Fin K→ℝ)
    (z w : ℤ×ℤ) :
    MeasurableSet {r : ℝ | (∀ D∈omissionProducts label d₀,
      SourceGoodState.NoSmallMultiple ((D:ℝ)*RootGoodBoundary.phase z w r)
        (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) ∧
      SecondGoodTest value label μ d₀ (RootGoodBoundary.phase z w r) L a} :=
  (bothGoodTests_measurable value label μ d₀ Y L a).preimage (phase_measurable z w)

end Elliptic.Operator.RootGoodMeasurable
