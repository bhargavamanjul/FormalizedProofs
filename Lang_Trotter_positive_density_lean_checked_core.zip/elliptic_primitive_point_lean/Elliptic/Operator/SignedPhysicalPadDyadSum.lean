module
public import Elliptic.Operator.SignedPhysicalPadReindex
public import Elliptic.Operator.SignedPadDyads

/-! Summing the divided physical pairings over the literal pad dyads
recovers precisely the allowed-pad scalar pairing. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open SignedPadDyads SignedPhysicalPadMass SingleEdgePhysicalRestoration
open Artin Artin.MarkedCriterion Artin.MarkedSource
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Exact pad dyad partition including the compensating division by d₀. -/
theorem padDyads_div_partition (Θ : ℝ) (D : ℕ) (hD : 0<D) (hheight : (D:ℝ)≤Real.exp Θ) (F : ℂ) :
    (∑j∈padDyads Θ,
      (if (2:ℝ)^j≤D ∧ (D:ℝ)<2*(2:ℝ)^j then (((2:ℝ)^j:ℝ):ℂ)*F else 0)/(((2:ℝ)^j:ℝ):ℂ))=F := by
  have hp := congrArg (fun x : ℝ=>(x:ℂ)) (padDyads_partition Θ D hD hheight)
  simp only [Complex.ofReal_sum,apply_ite,Complex.ofReal_one,Complex.ofReal_zero] at hp
  calc
    _ = (∑j∈padDyads Θ,if (2:ℝ)^j≤D ∧ (D:ℝ)<2*(2:ℝ)^j then (1:ℂ) else 0)*F := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro j hj
      have hd : (((2:ℝ)^j:ℝ):ℂ)≠0 := by exact_mod_cast (pow_ne_zero j (by norm_num : (2:ℝ)≠0))
      split_ifs <;> simp [hd]
    _ = _ := by rw [hp,one_mul]

theorem sum_padDyads_originalPairing_div {K J : ℕ} (hK : 0<K)
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (W : ℝ) (hsmall : ∀i,∀p∈groups i,(p:ℝ)≤W)
    (S T : Finset ℕ) (Hm Hn : ℝ) (hHm : 0≤Hm) (hHn : 0≤Hn)
    (hS : InDyad Hm S) (hT : InDyad Hn T)
    (α β : ℕ→ℂ)
    (hroughS : ∀m∈S,α m≠0→IsRough W m) (hroughT : ∀n∈T,β n≠0→IsRough W n)
    (Vmass : Fin K→ℝ) (Θ Y H C : ℝ) (hY : 0<Y) (hCY : C*Y≤W)
    (η ψ : ℝ→ℂ) (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hψ : ∀t,ψ t≠0→|t|≤C)
    (hheight : ∀(pads : ∀i,Fin J→groups i) (a : ∀i,groups i),
      ((∏i,∏j,(pads i j).val:ℕ):ℝ)≤Real.exp Θ) :

    (∑j∈padDyads Θ,
      originalPairing (J:=J) (fun i=>fun p : groups i=>p.val) Vmass (fun _ _=>True)
        ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
        (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
        (((2:ℝ)^j:ℝ):ℂ))=
    ∑pads : ∀i,Fin J→groups i,∑a : ∀i,groups i,∑b : ∀i,groups i,
      ∑m∈S,∑q∈T,∑r∈S,∑n∈T,
      if sourceCrossEdgeBan (fun _ p=>p.val) (assembledLists pads a) (assembledLists pads b) then
        ((∏i,∏j,1/(Vmass i*((pads i j).val:ℝ)):ℝ):ℂ)*
          ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*
          scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β else 0 := by
  have he (j : ℕ) := originalPairing_eq_pad_sum (J:=J) hK groups hp hdis W hsmall S T Hm Hn hHm hHn
    hS hT α β hroughS hroughT Vmass ((2:ℝ)^j) Y H C (by positivity) hY hCY η ψ hη hψ
  simp_rw [he,Finset.sum_div]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro pads hpads
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro r hr
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hban : sourceCrossEdgeBan (fun _ p=>p.val) (assembledLists pads a) (assembledLists pads b)
  · simp only [hban,true_and,ite_true]
    have hD : 0<(∏i,∏j,(pads i j).val:ℕ) :=
      Finset.prod_pos (fun i _=>Finset.prod_pos (fun j _=>(hp i (pads i j).val (pads i j).property).pos))
    simpa only [Nat.cast_prod,mul_assoc] using padDyads_div_partition Θ (∏i,∏j,(pads i j).val) hD
      (hheight pads a) (((∏i,∏j,1/(Vmass i*((pads i j).val:ℝ)):ℝ):ℂ)*
        ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β)
  · simp only [hban,false_and,ite_false,zero_div,Finset.sum_const_zero]

theorem sum_padDyads_originalPairing_div_eq_padded {K J : ℕ} (hK : 0<K)
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (W : ℝ) (hsmall : ∀i,∀p∈groups i,(p:ℝ)≤W)
    (S T : Finset ℕ) (Hm Hn : ℝ) (hHm : 0≤Hm) (hHn : 0≤Hn)
    (hS : InDyad Hm S) (hT : InDyad Hn T)
    (α β : ℕ→ℂ)
    (hroughS : ∀m∈S,α m≠0→IsRough W m) (hroughT : ∀n∈T,β n≠0→IsRough W n)
    (Vmass : Fin K→ℝ) (Θ Y H C : ℝ) (hY : 0<Y) (hCY : C*Y≤W)
    (η ψ : ℝ→ℂ) (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hψ : ∀t,ψ t≠0→|t|≤C)
    (hheight : ∀(pads : ∀i,Fin J→groups i) (a : ∀i,groups i),
      ((∏i,∏j,(pads i j).val:ℕ):ℝ)≤Real.exp Θ) :

    (∑j∈padDyads Θ,
      originalPairing (J:=J) (fun i=>fun p : groups i=>p.val) Vmass (fun _ _=>True)
        ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
        (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
        (((2:ℝ)^j:ℝ):ℂ))=
    ∑pads : ∀i,Fin J→groups i,∑a : ∀i,groups i,∑b : ∀i,groups i,
      if sourceCrossEdgeBan (fun _ p=>p.val) (assembledLists pads a) (assembledLists pads b) then
        (orderedWeight (harmonicMass (fun i=>fun p : groups i=>p.val) Vmass) pads:ℂ)*
          (((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*
            ∑m∈S,∑q∈T,∑r∈S,∑n∈T,
              scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β) else 0 := by
  rw [sum_padDyads_originalPairing_div hK groups hp hdis W hsmall S T Hm Hn hHm hHn hS hT α β
    hroughS hroughT Vmass Θ Y H C hY hCY η ψ hη hψ hheight]
  apply Finset.sum_congr rfl
  intro pads hpads
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro b hb
  by_cases hban : sourceCrossEdgeBan (fun _ p=>p.val) (assembledLists pads a) (assembledLists pads b)
  · simp only [hban,ite_true,orderedWeight,padWeight,harmonicMass,Finset.mul_sum,mul_assoc]
  · simp only [hban,ite_false,Finset.sum_const_zero]

end Elliptic.Operator.SignedPhysicalPairBridge
