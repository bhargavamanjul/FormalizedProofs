module

public import Elliptic.Operator.CleanPhysicalTransport
public import Elliptic.Operator.FourierFiber

/-!
# Signed clean bounds on actual prime-labelled physical states

This file connects the minor-arc determinant-fiber estimate to the actual
positive prime labels and their tensor-product measure. The integer product
coordinate is introduced by an injective map, treated using exact Parseval,
and then restricted back to the actual labels. The source normalization
`1/Y` cancels the atom bound `C/Y` exactly.

The only analytic bound required here is the normalized determinant-fiber
bound on the measurable minor arcs. No integrated enlarged clean estimate
or signed physical moment estimate is assumed.
-/

@[expose] public section

namespace Elliptic.Operator

open scoped BigOperators
open MeasureTheory Elliptic.SourceContracts

/-- The raw integrated clean kernel on actual positive prime tuples, with
either shift sign. -/
noncomputable def actualSignedCleanKernel {ζ ξ ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ) (minor : Set ProductCircle)
    (cutoff : ζ → ξ → ℂ) (det : ζ → ξ → ℤ) (σ : ℤ)
    (p : ζ × PrimeChoice I groups) (q : ξ × PrimeChoice I groups) : ℂ :=
  cutoff p.1 q.1 * minorFourierTransform minor
    (det p.1 q.1 - σ * (primeChoiceProduct I groups p.2 : ℤ) +
      σ * (primeChoiceProduct I groups q.2 : ℤ))

/-- The image of the actual labelled states lies in the rectangle formed
from its actual geometric and integer-product coordinate projections. -/
theorem labelledStateEmbedding_subset_rectangle {ζ ι : Type*}
    [DecidableEq ζ] [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (s : Finset (ζ × PrimeChoice I groups)) :
    s.map (labelledStateEmbedding I groups hprime hdisjoint) ⊆
      (s.image Prod.fst) ×ˢ
        ((s.map (labelledStateEmbedding I groups hprime hdisjoint)).image Prod.snd) := by
  intro P hP
  rcases Finset.mem_map.mp hP with ⟨p, hp, rfl⟩
  apply Finset.mem_product.mpr
  constructor
  · exact Finset.mem_image.mpr ⟨p, hp, rfl⟩
  · exact Finset.mem_image.mpr
      ⟨labelledStateEmbedding I groups hprime hdisjoint p,
        Finset.mem_map.mpr ⟨p, hp, rfl⟩, rfl⟩

/-- Determinant-fiber bounds on the actual geometric projections imply
the integrated counting bound on actual prime labels, for either sign.
No cardinality factor for the prime tuples or integer products appears. -/
theorem actual_label_signed_clean_counting_bound {ζ ξ ι : Type*}
    [DecidableEq ζ] [DecidableEq ξ] [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (s : Finset (ζ × PrimeChoice I groups)) (t : Finset (ξ × PrimeChoice I groups))
    (minor : Set ProductCircle) (hminor : MeasurableSet minor)
    (cutoff : ζ → ξ → ℂ) (det : ζ → ξ → ℤ) (M : ℝ) (hM : 0 ≤ M)
    (hG : ∀ θ ∈ minor, FiniteBilinearBound (s.image Prod.fst) (t.image Prod.fst)
      (fun i j => cutoff i j * fourier (det i j) θ) M)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    FiniteBilinearBound s t (actualSignedCleanKernel I groups minor cutoff det σ) M := by
  let e : (ζ × PrimeChoice I groups) ↪ (ζ × ℤ) :=
    labelledStateEmbedding I groups hprime hdisjoint
  let f : (ξ × PrimeChoice I groups) ↪ (ξ × ℤ) :=
    labelledStateEmbedding I groups hprime hdisjoint
  have henlarged := signedIntegerCleanKernel_bound_restrict
    (s.image Prod.fst) (t.image Prod.fst)
    ((s.map e).image Prod.snd) ((t.map f).image Prod.snd)
    (s.map e) (t.map f)
    (labelledStateEmbedding_subset_rectangle I groups hprime hdisjoint s)
    (labelledStateEmbedding_subset_rectangle I groups hprime hdisjoint t)
    minor cutoff det M hM hminor hG σ hσ
  have h := finiteBilinearBound_embedding s t e f
    (signedIntegerCleanKernel minor cutoff det σ) M henlarged
  have heq : (fun p q => signedIntegerCleanKernel minor cutoff det σ (e p) (f q)) =
      actualSignedCleanKernel I groups minor cutoff det σ := by
    funext p q
    rfl
  rwa [heq] at h

/-- The actual measured raw signed clean kernel has bound `(prod A_i)*M`
from the normalized determinant-fiber bound on the minor arcs. This is the
combined product-label, Fourier, restriction, and measure-normalization
step in the clean-edge argument. -/
theorem actual_measured_signed_clean_bound {ζ ξ ι : Type*}
    [DecidableEq ζ] [DecidableEq ξ] [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (ν : ι → ℕ → ℝ) (A : ι → ℝ) (hA : ∀ i ∈ I, 0 ≤ A i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hνbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ A i / p)
    (s : Finset (ζ × PrimeChoice I groups)) (t : Finset (ξ × PrimeChoice I groups))
    (minor : Set ProductCircle) (hminor : MeasurableSet minor)
    (cutoff : ζ → ξ → ℂ) (det : ζ → ξ → ℤ)
    (Y M : ℝ) (hY : 0 < Y) (hM : 0 ≤ M)
    (hs : ∀ z ∈ s, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (ht : ∀ z ∈ t, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (hG : ∀ θ ∈ minor, FiniteBilinearBound (s.image Prod.fst) (t.image Prod.fst)
      (fun i j => ((Y : ℂ)⁻¹ * cutoff i j) * fourier (det i j) θ) M)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    FiniteMeasuredBilinearBound s t
      (fun z => primeChoiceMass I groups ν z.2)
      (fun z => primeChoiceMass I groups ν z.2)
      (actualSignedCleanKernel I groups minor cutoff det σ)
      ((∏ i : I, A i) * M) := by
  have hcounting := actual_label_signed_clean_counting_bound I groups hprime hdisjoint
    s t minor hminor (fun i j => (Y : ℂ)⁻¹ * cutoff i j) det M hM hG σ hσ
  apply measured_clean_bound_of_normalized_counting s t _ _ _ Y (∏ i : I, A i) M hY
    (Finset.prod_nonneg fun i _ => hA i i.property) hM
    (fun z _ => primeChoiceMass_nonneg I groups ν hν z.2)
    (fun z _ => primeChoiceMass_nonneg I groups ν hν z.2)
    (fun z hz => primeChoiceMass_le_of_product_lower I groups ν A hA hν hνbound
      z.2 Y hY (hs z hz))
    (fun z hz => primeChoiceMass_le_of_product_lower I groups ν A hA hν hνbound
      z.2 Y hY (ht z hz))
  have heq : actualSignedCleanKernel I groups minor (fun i j => (Y : ℂ)⁻¹ * cutoff i j) det σ =
      fun p q => (Y : ℂ)⁻¹ * actualSignedCleanKernel I groups minor cutoff det σ p q := by
    funext p q
    unfold actualSignedCleanKernel
    ring
  rwa [heq] at hcounting

end Elliptic.Operator
