module

public import Elliptic.Operator.PhysicalComparisonMaskedRow
public import Elliptic.Operator.PhysicalMaskScaling
public import Elliptic.Operator.CountingKernelSchur

/-! Actual two-sided comparison Schur bound, with 1/Y canceled against
the target count and with store/promotion reversal proved literally. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalComparisonSchur
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalComparisonMaskedRow PhysicalMaskScaling
attribute [local instance] Classical.propDecidable
local instance comparisonSchurDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {K J B : ℕ} {Z : Type} {P : Fin K→Type}
variable [Fintype Z] [∀i,Fintype (P i)]
variable (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
variable [∀i p,Fintype (ZMod (value i p))]

 def comparisonKernel (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (S I : Fin K→Bool) (ρ : ℝ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop) (u v r U W d₀ Y C : ℝ)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)) : ℂ :=
  originalKernel ν V S I ρ (anchor value position)
    (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b) s t

 theorem masked_comparison_schur
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ) (S I : Fin K→Bool)
    (ρ v0 A : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ))
    (hg : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hV : ∀i,0<V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) (hA : 0≤A)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (hamp : ∀z a w b,sourceComparisonAllowed value good u v r U W d₀ Y C z a w b→‖amplitude z a w b‖≤A/Y)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s=>∑t,comparisonKernel value position ν V S I ρ good u v r U W d₀ Y C amplitude s t*F t)≤
    Real.sqrt ((A*(countFactor Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))*
      (reverseFactor V I S*A*(countFactor Y C R S*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0)))*
      finiteL2 Finset.univ (mass ν) F := by
  let geometry := fun z b w c=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) b (position w) c
  let T := reverseFactor V I S
  have hT : 0<T := reverseFactor_pos V hV I S
  have hP : 0≤PhysicalChoiceFiberWeight.budget (B:=B) ν V v0 := by
    unfold PhysicalChoiceFiberWeight.budget
    apply Finset.prod_nonneg
    intro i _
    have hv := hV i
    have hn : 0≤∑p,ν i p := Finset.sum_nonneg fun p _=>(hνpos i p).le
    positivity
  let reverse := fun s t=>(T:ℂ)*originalKernel (B:=B) ν V I S ρ (anchor value position)
    (fun z b w c=>geometry w c z b) s t
  have hamp' : ∀z b w c,sourceComparisonAllowed value good u v r U W d₀ Y C z b w c→
      ‖amplitude w c z b‖≤A/Y := by
    intro z b w c hc
    exact hamp w c z b ((sourceComparisonAllowed_swap value good u v r U W d₀ Y C z b w c).mp hc)
  have hgeo : (fun z b w c=>geometry w c z b)=
      (fun z b w c=>sourceComparisonGeometry value good u v r U W d₀ Y C
        (fun z b w c=>amplitude w c z b) (position z) b (position w) c) := by
    funext z b w c
    exact sourceComparisonGeometry_swap value good u v r U W d₀ Y C amplitude _ _ _ _
  apply countingKernel_schur (mass ν) (weight v0)
    (comparisonKernel value position ν V S I ρ good u v r U W d₀ Y C amplitude) reverse
    (A*(countFactor Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))
    (T*A*(countFactor Y C R S*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))
    (mass_pos ν hνpos) (weight_pos hv0)
    (mul_nonneg hA (mul_nonneg (countFactor_nonneg Y C R I (by linarith) (by linarith) hR.le) hP))
    (mul_nonneg (mul_nonneg hT.le hA) (mul_nonneg (countFactor_nonneg Y C R S (by linarith) (by linarith) hR.le) hP))
  · intro s t
    have hh := original_norm_balance ν hνpos V hV S I ρ (anchor value position) geometry s t
    simpa only [comparisonKernel,reverse,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hT] using hh
  · intro s
    have hh := normalized_row_le value position hposition hprime ν hνpos V S I ρ v0 A good
      u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband hg (fun i=>(hV i).le) hρ0 hρ1 hv0 hA amplitude hamp s
    apply (le_of_eq ?_).trans hh
    unfold row comparisonKernel
    apply Finset.sum_congr
    · ext t
      simp only [Finset.mem_univ]
    · intro t _
      rfl
  · intro s
    have hh := normalized_row_le value position hposition hprime ν hνpos V I S ρ v0 A good
      u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband hg (fun i=>(hV i).le) hρ0 hρ1 hv0 hA
      (fun z b w c=>amplitude w c z b) hamp' s
    simp only [reverse,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hT]
    simp_rw [mul_assoc]
    rw [←Finset.mul_sum,hgeo]
    have hhh := mul_le_mul_of_nonneg_left hh hT.le
    apply (le_of_eq ?_).trans (hhh.trans_eq (by ring))
    apply congrArg (fun x : ℝ=>T*x)
    unfold row
    apply Finset.sum_congr
    · ext t
      simp only [Finset.mem_univ]
    · intro t _
      rfl

end Elliptic.Operator.PhysicalComparisonSchur
