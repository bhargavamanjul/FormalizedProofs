module
public import Elliptic.Operator.SignedPhysicalAbsoluteRaw

/-! Absolute coprime scalar error: raw and major parts are bounded before
pad recovery, with the actual injective selected-prime products. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteError
open scoped BigOperators
open Filter SignedPhysicalPairBridge SignedPhysicalAbsoluteMajor SignedPhysicalAbsoluteRaw
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Finite support counting for an arbitrary nonnegative selected-pair cost. -/
theorem supported_pair_sum_le {ι : Type*} [Fintype ι] (p : ι→ℕ)
    (hinj : Function.Injective p) (Y : ℝ) (hY : 0<Y) (η : ℝ→ℂ)
    (hηsupp : ∀v,η v≠0→1≤v ∧ v≤4) (R : ι→ι→Prop) [DecidableRel R] (F : ι→ι→ℝ)
    (M : ℝ) (hM : 0≤M)
    (hzero : ∀a b,η ((p a:ℝ)/Y)=0 ∨ η ((p b:ℝ)/Y)=0→F a b=0)
    (hbnd : ∀a b,η ((p a:ℝ)/Y)≠0→η ((p b:ℝ)/Y)≠0→R a b→F a b≤M) :
    (∑a : ι,∑b : ι,if R a b then F a b else 0)≤16*Y^2*M := by
  let P := Finset.univ.filter (fun i=>η ((p i:ℝ)/Y)≠0)
  let G := fun a b=>if R a b then F a b else 0
  have hz (a b : ι) (h : η ((p a:ℝ)/Y)=0 ∨ η ((p b:ℝ)/Y)=0) : G a b=0 := by
    simp [G,hzero a b h]
  have he : (∑a : ι,∑b : ι,G a b)=∑a∈P,∑b∈P,G a b := by
    calc
      _ = ∑a∈P,∑b : ι,G a b := by
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro a ha hn
        apply Finset.sum_eq_zero
        intro b hb
        exact hz a b (Or.inl (by simpa [P] using hn))
      _ = _ := by
        apply Finset.sum_congr rfl
        intro a ha
        symm
        apply Finset.sum_subset (Finset.filter_subset _ _)
        intro b hb hn
        exact hz a b (Or.inr (by simpa [P] using hn))
  change (∑a : ι,∑b : ι,G a b)≤_
  rw [he]
  calc
    _ ≤ ∑a∈P,∑b∈P,M := by
      apply Finset.sum_le_sum
      intro a ha
      apply Finset.sum_le_sum
      intro b hb
      by_cases hr : R a b
      · exact (ite_eq_left hr).le.trans (hbnd a b (Finset.mem_filter.mp ha).2 (Finset.mem_filter.mp hb).2 hr)
      · simpa [G,hr] using hM
    _ = (P.card:ℝ)^2*M := by simp; ring
    _ ≤ (4*Y)^2*M := mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (by positivity) (supported_label_card p hinj Y hY η hηsupp) 2) hM
    _ = _ := by ring

/-- Uniform absolute raw sum over every coprime selected pair. -/
theorem eventually_all_labels_scalarRaw_sum_le (D : ℝ) (hD : 0≤D) :
    ∀ᶠx : ℝ in atTop,∀(ι : Type*) [Fintype ι] (p : ι→ℕ),Function.Injective p→
    (∀a,(p a:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)))→
    ∀(s t : Finset ℕ) (Y : ℝ), (∀m∈s,0<m)→(∀m∈s,∀n∈t,0<m*n)→
    (∀m∈s,∀n∈t,(m*n+1:ℕ)≤x)→0<Y→
    ∀(η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ),
    0≤Aη→0≤Aψ→0≤A→0≤B→
    (∀v,‖η v‖≤Aη)→(∀v,‖ψ v‖≤Aψ)→
    (∀v,η v≠0→1≤v ∧ v≤4)→
    (∀m∈s,‖α m‖≤A)→(∀n∈t,‖β n‖≤B)→
    (∑a : ι,∑b : ι,if (p a).Coprime (p b) then
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarRaw (p a) (p b) m n r q Y η ψ α β‖ else 0)≤
      512*Aη^2*A^2*B^2*Aψ*x*Y*(1+Real.log (8*x))^3 := by
  filter_upwards [eventually_scalarRaw_sum_le D hD,eventually_ge_atTop (1:ℝ)] with x hx hx1
  intro ι _ p hinj hsmall s t Y hs hpos hprod hY η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hηsupp hα hβ
  have hx0 : 0<x := by linarith
  have hlog : 0≤Real.log (8*x) := Real.log_nonneg (by linarith)
  let M := (Aη^2*A^2*B^2*Aψ)*(32*(x/Y)*(1+Real.log (8*x))^3)
  have hM : 0≤M := by dsimp only [M]; positivity
  apply (supported_pair_sum_le p hinj Y hY η hηsupp (fun a b=>(p a).Coprime (p b))
    (fun a b=>∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarRaw (p a) (p b) m n r q Y η ψ α β‖) M hM
    (by intro a b hz; rcases hz with hz|hz <;> simp [scalarRaw,hz])
    (by
      intro a b ha hb hab
      have ha' := hηsupp _ ha
      have hb' := hηsupp _ hb
      exact hx s t (p a) (p b) Y hs hpos hprod hY
        (by simpa using (le_div_iff₀ hY).mp ha'.1) ((div_le_iff₀ hY).mp ha'.2)
        (by simpa using (le_div_iff₀ hY).mp hb'.1) ((div_le_iff₀ hY).mp hb'.2)
        hab (hsmall a) (hsmall b) η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hα hβ)).trans
  exact le_of_eq (by dsimp only [M]; field_simp [hY.ne']; ring)

/-- The complete absolute scalar error is bounded by the coprime raw
part and the unrestricted major part, before any cancellation is used. -/
theorem coprime_scalarError_sum_le_raw_add_major {ι : Type*} [Fintype ι]
    (p : ι→ℕ) (s t : Finset ℕ) (Y H : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    (∑a : ι,∑b : ι,if (p a).Coprime (p b) then
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarError (p a) (p b) m n r q Y H η ψ α β‖ else 0)≤
    (∑a : ι,∑b : ι,if (p a).Coprime (p b) then
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarRaw (p a) (p b) m n r q Y η ψ α β‖ else 0)+
    ∑a : ι,∑b : ι,∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      ‖scalarMajor (p a) (p b) m n r q Y H η ψ α β‖ := by
  rw [←Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro a ha
  rw [←Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro b hb
  by_cases hc : (p a).Coprime (p b)
  · rw [ite_eq_left hc,ite_eq_left hc]
    simp only [←Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro m hm
    apply Finset.sum_le_sum
    intro n hn
    apply Finset.sum_le_sum
    intro r hr
    apply Finset.sum_le_sum
    intro q hq
    rw [scalarError_eq_raw_sub_major]
    exact norm_sub_le _ _
  · rw [ite_eq_right hc,ite_eq_right hc,zero_add]
    positivity

end Elliptic.Operator.SignedPhysicalAbsoluteError
