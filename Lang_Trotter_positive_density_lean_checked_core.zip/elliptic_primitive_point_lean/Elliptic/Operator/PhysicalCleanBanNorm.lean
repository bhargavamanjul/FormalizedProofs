module
public import Elliptic.Operator.CleanRestriction
public import Elliptic.Operator.CleanBanGeometry
public import Elliptic.Operator.CleanCrossBan
public import Elliptic.Operator.SourceMinorArc

/-! The literal coincidence ban is restored to the sharp physical clean
estimate. Its error is proved by actual determinant counting and small
prime atoms; all endpoint supports remain the original finite supports. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanBanNorm
open scoped BigOperators SchwartzMap
open PhysicalPadLattice
attribute [local instance] Classical.propDecidable
local instance physicalCleanBanNormDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1600000
variable {I : Type*} [Fintype I]

def kernel (groups : I → Finset ℕ) (z : ℤ×ℤ) (D : ℤ)
    (ψ : 𝓢(ℝ,ℂ)) (H Y : ℝ) (σ : ℤ)
    (p q : PadPosition z D × (∀ i, groups i)) : ℂ :=
  ψ ((padDeterminant z D p.1 q.1:ℝ)/Y)*
    minorFourierTransform (sourceMajorArcs H Y)ᶜ
      (padDeterminant z D p.1 q.1-σ*(∏ i, (p.2 i).val)+σ*(∏ i, (q.2 i).val))

def bannedKernel (groups : I → Finset ℕ) (z : ℤ×ℤ) (D : ℤ)
    (ψ : 𝓢(ℝ,ℂ)) (H Y : ℝ) (σ : ℤ)
    (p q : PadPosition z D × (∀ i, groups i)) : ℂ :=
  if ∀ i, p.2 i≠q.2 i then kernel groups z D ψ H Y σ p q else 0

/-- The actual minor-arc coincidence error on a physical pad, with
literal finite position cardinalities and actual product prime masses. -/
theorem pad_coincidence_bound
    (groups : I → Finset ℕ) (ν : I → ℕ → ℝ)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1) (D : ℤ)
    (s t : Finset (PadPosition z D))
    (u v r U W : ℝ) (hU : 0<U)
    (hspos : ∀ p∈s, sourcePhysicalPositionAllowed u v r U W p.val)
    (htpos : ∀ p∈t, sourcePhysicalPositionAllowed u v r U W p.val)
    (ψ : 𝓢(ℝ,ℂ)) (H Y Aψ Cgeo : ℝ)
    (hH : 0≤H) (hY : 0<Y) (hAψ : 0≤Aψ) (hgeo : 0≤Cgeo)
    (hψ : ∀ x, ‖ψ x‖≤Aψ) (hs : (s.card:ℝ)≤Cgeo*Y) (ht : (t.card:ℝ)≤Cgeo*Y)
    (Cmass δ : ℝ) (hν : ∀ i, ∀ p∈groups i, 0≤ν i p)
    (hmassC : 1≤Cmass) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ p : groups i, ν i p.val≤Cmass)
    (hatom : ∀ i, ∀ p∈groups i, ν i p≤δ) (σ : ℤ) :
    FiniteMeasuredBilinearBound (s×ˢ(Finset.univ : Finset (∀ i, groups i))) (t×ˢ(Finset.univ : Finset (∀ i, groups i)))
      (fun p => ∏ i, ν i (p.2 i).val) (fun p => ∏ i, ν i (p.2 i).val)
      (fun p q => if ∃ i, q.2 i=p.2 i then kernel groups z D ψ H Y σ p q else 0)
      ((Aψ*(33+4*Cgeo*H^3))*((Fintype.card I:ℝ)*δ*Cmass^(Fintype.card I))) := by
  let e : PadPosition z D ↪ ℤ×ℤ := Function.Embedding.subtype _
  let e' := e.prodMap (Function.Embedding.refl (∀ i, groups i))
  have hs' : ∀ p∈s.map e, sourcePhysicalPositionAllowed u v r U W p := by
    intro p hp
    obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp
    exact hspos q hq
  have ht' : ∀ p∈t.map e, sourcePhysicalPositionAllowed u v r U W p := by
    intro p hp
    obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp
    exact htpos q hq
  have hp : ∀ p∈s.map e, ∀ q∈t.map e, D∣latticeDet p q := by
    intro p hp q hq
    obtain ⟨p,hp,rfl⟩ := Finset.mem_map.mp hp
    obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hq
    exact ⟨_,(PhysicalPadLattice.padCoordinates_det z w hzw D p.val q.val p.property q.property).symm⟩
  have hh := CleanBanGeometry.actual_pad_coincidence_bound
    (s.map e) (t.map e) D r
    (fun p hp => (hs' p hp).1) (fun p hp => (ht' p hp).1)
    (fun p hp => (sourcePhysicalPositionAllowed_ratio_le u v r U W p p hU (hs' p hp) (hs' p hp)).1)
    (fun p hp => (sourcePhysicalPositionAllowed_ratio_le u v r U W p p hU (ht' p hp) (ht' p hp)).1)
    hp
    (fun p hp q hq => (sourcePhysicalPositionAllowed_ratio_le u v r U W p q hU (hs' p hp) (ht' q hq)).2)
    (fun p hp q hq => (sourcePhysicalPositionAllowed_ratio_le u v r U W q p hU (ht' q hq) (hs' p hp)).2)
    H Y Aψ Cgeo hH hY hAψ hgeo (by simpa using hs) (by simpa using ht)
    (fun i (p : groups i) => ν i p.val) Cmass δ
    (fun i p => hν i p.val p.property) hmassC hδ hmass (fun i p => hatom i p.val p.property)
    (fun p => (∏ i, (p i).val : ℕ)) σ
    (fun p q => ψ ((latticeDet p.1 q.1/D:ℤ)/Y))
    (fun _ _ _ _ _ _ => hψ _)
  have hm : ((s×ˢ(Finset.univ : Finset (∀ i, groups i))).map e')=
      (s.map e)×ˢFinset.univ := by
    simp only [e',Finset.prodMap_map_product,Finset.map_refl]
  have hm' : ((t×ˢ(Finset.univ : Finset (∀ i, groups i))).map e')=
      (t.map e)×ˢFinset.univ := by
    simp only [e',Finset.prodMap_map_product,Finset.map_refl]
  rw [← hm,← hm'] at hh
  have hh' := finiteMeasuredBilinearBound_embedding (s×ˢFinset.univ) (t×ˢFinset.univ) e' e' _ _ _ _ hh
  have he' (p : PadPosition z D × (∀ i, groups i)) : e' p=(p.1.val,p.2) := rfl
  simpa only [he',CleanCoincidence.tupleMass,kernel,padDeterminant,
    CleanBanGeometry.bracket,source_raw_comparison_eq_minor _ (sourceMajorArcs_measurable H Y)] using hh'

/-- The sharp balanced-box norm with the actual fresh-coordinate ban.
The only cost of restoring the ban is the explicit small-atom error. -/
theorem actual_banned_pad_box_bound
    (groups : I → Finset ℕ)
    (hprime : ∀ i, ∀ p∈groups i, p.Prime)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (ν : I → ℕ → ℝ) (C : I → ℝ) (hC : ∀ i, 0≤C i)
    (hν : ∀ i, ∀ p∈groups i, 0≤ν i p)
    (hνbound : ∀ i, ∀ p∈groups i, ν i p≤C i/p)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1) (D : ℤ) (hD : D≠0)
    (b₁ b₂ : ℤ×ℤ) (hb : latticeDet b₁ b₂=1)
    (s t : Finset (PadPosition z D × (∀ i, groups i)))
    (u v r U W : ℝ) (hU : 0<U)
    (hspos : ∀ p∈s, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (htpos : ∀ p∈t, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (ψ : 𝓢(ℝ,ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1≤H) (hY : 0<Y)
    (hsbox : ∀ p∈s, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A)))
    (htbox : ∀ p∈t, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A)))
    (hs : ∀ p∈s, Y≤((∏ i, (p.2 i).val):ℕ))
    (ht : ∀ p∈t, Y≤((∏ i, (p.2 i).val):ℕ))
    (Aψ Cgeo Cmass δ : ℝ) (hAψ : 0≤Aψ) (hgeo : 0≤Cgeo)
    (hψ : ∀ x, ‖ψ x‖≤Aψ) (harea : (A:ℝ)*B≤Cgeo*Y)
    (hmassC : 1≤Cmass) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ p : groups i, ν i p.val≤Cmass)
    (hatom : ∀ i, ∀ p∈groups i, ν i p≤δ) (σ : ℤ) (hσ : σ=1 ∨ σ= -1) :
    FiniteMeasuredBilinearBound s t
      (fun p => ∏ i, ν i (p.2 i).val) (fun p => ∏ i, ν i (p.2 i).val)
      (bannedKernel groups z D ψ H Y σ)
      ((∏ i, C i)*smoothedDeterminantBudget ψ A B H Y k +
        (Aψ*(33+4*Cgeo*H^3))*((Fintype.card I:ℝ)*δ*Cmass^(Fintype.card I))) := by
  let sp := s.image Prod.fst
  let tp := t.image Prod.fst
  have hsp : ∀ p∈sp, sourcePhysicalPositionAllowed u v r U W p.val := by
    intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp; exact hspos q hq
  have htp : ∀ p∈tp, sourcePhysicalPositionAllowed u v r U W p.val := by
    intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp; exact htpos q hq
  have hspc : (sp.card:ℝ)≤Cgeo*Y := by
    apply (CleanBanGeometry.pad_cell_card_le z w hzw D b₁ b₂ hb A B a b sp ?_).trans harea
    intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp; exact hsbox q hq
  have htpc : (tp.card:ℝ)≤Cgeo*Y := by
    apply (CleanBanGeometry.pad_cell_card_le z w hzw D b₁ b₂ hb A B a b tp ?_).trans harea
    intro p hp; obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp; exact htbox q hq
  have he := pad_coincidence_bound groups ν z w hzw D sp tp u v r U W hU hsp htp
    ψ H Y Aψ Cgeo (by linarith) hY hAψ hgeo hψ hspc htpc Cmass δ hν hmassC hδ hmass hatom σ
  have hss : s⊆sp×ˢ(Finset.univ : Finset (∀ i, groups i)) := by
    intro p hp; exact Finset.mem_product.mpr ⟨Finset.mem_image.mpr ⟨p,hp,rfl⟩,Finset.mem_univ _⟩
  have htt : t⊆tp×ˢ(Finset.univ : Finset (∀ i, groups i)) := by
    intro p hp; exact Finset.mem_product.mpr ⟨Finset.mem_image.mpr ⟨p,hp,rfl⟩,Finset.mem_univ _⟩
  have he' := finiteMeasuredBilinearBound_restrict _ s _ t hss htt _ _ _ _ he
  have hk := PhysicalCleanLabels.actual_subtype_clean_pad_box_bound groups hprime hdis ν C hC hν hνbound
    z w hzw D hD b₁ b₂ hb s t ψ A B a b H Y k hH hY hsbox htbox hs ht σ hσ
  have hh := finiteMeasuredBilinearBound_sub s t _ _ _ _ _ _ hk he'
  have heq : (fun p q => kernel groups z D ψ H Y σ p q -
      (if ∃ i, q.2 i=p.2 i then kernel groups z D ψ H Y σ p q else 0)) =
      bannedKernel groups z D ψ H Y σ := by
    funext p q
    by_cases h : ∃ i, q.2 i=p.2 i
    · have hn : ¬∀ i, p.2 i≠q.2 i := by
        obtain ⟨i,hi⟩ := h; intro hall; exact hall i hi.symm
      simp [h,bannedKernel,hn]
    · have hn : ∀ i, p.2 i≠q.2 i := by
        intro i hi; exact h ⟨i,hi.symm⟩
      simp [h,bannedKernel,hn]
  change FiniteMeasuredBilinearBound s t _ _ (fun p q => kernel groups z D ψ H Y σ p q - _) _ at hh
  rw [heq] at hh
  exact hh

/-- The actual first good-state test supplies balanced widths and the
ban-restored clean bound on arbitrary finite supports in one physical cell. -/
theorem actual_banned_good_pad_cell_bound
    (groups : I → Finset ℕ)
    (hprime : ∀ i, ∀ p∈groups i, p.Prime)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (ν : I → ℕ → ℝ) (Cweight : I → ℝ) (hCweight : ∀ i, 0≤Cweight i)
    (hν : ∀ i, ∀ p∈groups i, 0≤ν i p)
    (hνbound : ∀ i, ∀ p∈groups i, ν i p≤Cweight i/p)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1) (D : ℤ)
    (u v r U W d₀ Y Ccell : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hD : d₀≤(D:ℝ)) (hY : 1≤Y) (hCcell : 1≤Ccell)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest ((D:ℝ)*latticeTau r w/latticeTau r z) Y)
    (s t : Finset (PadPosition z D × (∀ i, groups i)))
    (hspos : ∀ p∈s, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (htpos : ∀ p∈t, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (hscell : ∀ p∈s, |latticeSlope r p.1.val-latticeSlope r z|≤Ccell*d₀*Y)
    (htcell : ∀ p∈t, |latticeSlope r p.1.val-latticeSlope r z|≤Ccell*d₀*Y)
    (hs : ∀ p∈s, Y≤((∏ i, (p.2 i).val):ℕ))
    (ht : ∀ p∈t, Y≤((∏ i, (p.2 i).val):ℕ))
    (ψ : 𝓢(ℝ,ℂ)) (H : ℝ) (hH : 1≤H) (k : ℕ)
    (Aψ Cmass δ : ℝ) (hAψ : 0≤Aψ) (hψ : ∀ x, ‖ψ x‖≤Aψ)
    (hmassC : 1≤Cmass) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ p : groups i, ν i p.val≤Cmass)
    (hatom : ∀ i, ∀ p∈groups i, ν i p≤δ) (σ : ℤ) (hσ : σ=1 ∨ σ= -1) :
    ∃ A B : ℕ, Y^(1/5:ℝ)≤A ∧ Y^(1/5:ℝ)≤B ∧
      (A:ℝ)*B≤72*(256*Ccell)^2*Y ∧
      FiniteMeasuredBilinearBound s t
        (fun p => ∏ i, ν i (p.2 i).val) (fun p => ∏ i, ν i (p.2 i).val)
        (bannedKernel groups z D ψ H Y σ)
        ((∏ i, Cweight i)*smoothedDeterminantBudget ψ A B H Y k +
          (Aψ*(33+4*(72*(256*Ccell)^2)*H^3))*((Fintype.card I:ℝ)*δ*Cmass^(Fintype.card I))) := by
  obtain ⟨b₁,b₂,a,b,c,d,hb,hab,hcd,hwidth,hwidth',harea,hcontain⟩ :=
    PhysicalPadLattice.physical_pad_cell_balanced_box z w hzw D u v r U W d₀ Y Ccell
      hU hu hu' hd hD hY hCcell hz hg
  let A : ℕ := (d-c).toNat
  let B : ℕ := (b-a).toNat
  have hAcast : (A:ℤ)=d-c := Int.toNat_of_nonneg (by omega)
  have hBcast : (B:ℤ)=b-a := Int.toNat_of_nonneg (by omega)
  have hAR : (A:ℝ)=(d:ℝ)-c := by exact_mod_cast hAcast
  have hBR : (B:ℝ)=(b:ℝ)-a := by exact_mod_cast hBcast
  have hD0 : D≠0 := by
    have hDp : (0:ℝ)<D := hd.trans_le hD
    exact_mod_cast hDp.ne'
  have harea' : (A:ℝ)*B≤72*(256*Ccell)^2*Y := by
    rw [hAR,hBR,mul_comm]; exact harea
  refine ⟨A,B,?_,?_,harea',?_⟩
  · rwa [hAR]
  · rwa [hBR]
  apply actual_banned_pad_box_bound groups hprime hdis ν Cweight hCweight hν hνbound
    z w hzw D hD0 b₁ b₂ hb s t u v r U W hU hspos htpos ψ A B a c H Y k hH
    (by linarith) ?_ ?_ hs ht Aψ (72*(256*Ccell)^2) Cmass δ hAψ (by positivity)
    hψ harea' hmassC hδ hmass hatom σ hσ
  · intro p hp
    have h := hcontain p.1.val (hspos p hp) p.1.property (hscell p hp)
    change SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D p.1.val) ∈
      (Finset.Ico a (a+(B:ℤ)))×ˢ(Finset.Ico c (c+(A:ℤ)))
    simpa only [hAcast,hBcast,add_sub_cancel] using h
  · intro p hp
    have h := hcontain p.1.val (htpos p hp) p.1.property (htcell p hp)
    change SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D p.1.val) ∈
      (Finset.Ico a (a+(B:ℤ)))×ˢ(Finset.Ico c (c+(A:ℤ)))
    simpa only [hAcast,hBcast,add_sub_cancel] using h

end Elliptic.Operator.PhysicalCleanBanNorm
