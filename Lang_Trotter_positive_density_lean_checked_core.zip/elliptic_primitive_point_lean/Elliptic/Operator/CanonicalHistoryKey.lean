module

public import Elliptic.Operator.CanonicalScheduleUniqueness
public import Elliptic.Operator.ActualHistoryObservation
public import Mathlib.Tactic.DeriveFintype
public import Mathlib.Data.Fintype.Perm

/-!
# Finite observable keys for histories and schedules

The key retains only the visit and edge data inside the finite horizon.
A prime's used support and lifespan are encoded by its finite live trace;
its active trace is read from the active lists. Retained lines are fixed
at the first observed visit, so no unobserved line choices are present.

A key has a genuinely finite type even when the line types are infinite.
Raw schedule extraction remains a separate theorem. In particular, the
weighted partition by keys below must not be confused with identifying
every key fiber with a scheduled birth-order fiber.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance canonicalKeyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Only finite observed data. Empty live traces mean unused prime labels;
there is no arbitrary lifespan or retained-line datum for those labels. -/
@[ext] structure CanonicalHistoryKey (I Z : Type) (P : I → Type) (J N : ℕ) where
  position : Fin (N+1) → Z
  active : Fin (N+1) → ∀ i, Fin (J+1) → P i
  live : ∀ i, P i → Finset (Fin (N+1))
  sourcePerm : Fin N → ∀ _i : I, Equiv.Perm (Fin (J+1))
  targetPerm : Fin N → ∀ _i : I, Equiv.Perm (Fin (J+1))
  store : Fin N → I → Bool
  promote : Fin N → I → Bool
  targetPrime : Fin N → ∀ i, P i

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

set_option synthInstance.maxSize 4096 in
instance canonicalHistoryKeyFintype : Fintype (CanonicalHistoryKey I Z P J N) :=
  derive_fintype% _

namespace CanonicalHistoryKey

variable (k : CanonicalHistoryKey I Z P J N)

/-- Used prime labels are exactly those with nonempty live traces. -/
def primes (i : I) : Finset (P i) := Finset.univ.filter (fun p => (k.live i p).Nonempty)

/-- A birth address exists only on the used support. -/
def birth (i : I) (p : P i) : Option (Fin (N+1)) :=
  if h : (k.live i p).Nonempty then some ((k.live i p).min' h) else none

/-- A death address exists only on the used support. -/
def death (i : I) (p : P i) : Option (Fin (N+1)) :=
  if h : (k.live i p).Nonempty then some ((k.live i p).max' h) else none

/-- Active visits retain the literal active-slot order in the key. -/
def activeVisits (i : I) (p : P i) : Finset (Fin (N+1)) :=
  Finset.univ.filter (fun j => ∃ a, k.active j i a = p)

/-- Canonical retained lines are derived from the first observed visit;
there is no line attached to an unused prime. -/
def retained (anchor : Z → ∀ i p, Line i p) (i : I) (p : P i) : Option (Line i p) :=
  (k.birth i p).map (fun j => anchor (k.position j) i p)

omit [Fintype I] [Fintype Z] in
@[simp] theorem mem_primes (i : I) (p : P i) :
    p ∈ k.primes i ↔ (k.live i p).Nonempty := by simp [primes]

omit [Fintype I] [Fintype Z] in
@[simp] theorem birth_eq_none (i : I) (p : P i) :
    k.birth i p = none ↔ p ∉ k.primes i := by
  unfold birth
  by_cases h : (k.live i p).Nonempty <;> simp [h]

omit [Fintype I] [Fintype Z] in
@[simp] theorem death_eq_none (i : I) (p : P i) :
    k.death i p = none ↔ p ∉ k.primes i := by
  unfold death
  by_cases h : (k.live i p).Nonempty <;> simp [h]

omit [Fintype I] [Fintype Z] in
@[simp] theorem retained_eq_none (anchor : Z → ∀ i p, Line i p) (i : I) (p : P i) :
    k.retained anchor i p = none ↔ p ∉ k.primes i := by
  simp [retained]

end CanonicalHistoryKey

namespace ScheduledPhysicalPath
variable (d : ScheduledPhysicalPath anchor N J B)

/-- Forget unused and off-horizon schedule fields. Birth lines are recovered
from this key; arbitrary raw retained coordinates are not stored. -/
def canonicalKey : CanonicalHistoryKey I Z P J N where
  position j := d.position j.val
  active j := d.active j.val
  live i p := Finset.univ.filter (fun j => p ∈ d.primes i ∧
    (d.lifespan i p).birth ≤ j.val ∧ j.val ≤ (d.lifespan i p).death)
  sourcePerm j := d.sourcePerm j.val
  targetPerm j := d.targetPerm j.val
  store j := d.store j.val
  promote j := d.promote j.val
  targetPrime j := d.targetPrime j.val

omit [Fintype Z] in
@[simp] theorem canonicalKey_primes (i : I) : d.canonicalKey.primes i = d.primes i := by
  ext p
  simp only [CanonicalHistoryKey.mem_primes, canonicalKey, Finset.filter_nonempty_iff,
    Finset.mem_univ, true_and]
  constructor
  · rintro ⟨j,hp,_⟩; exact hp
  · intro hp
    let j : Fin (N+1) := ⟨(d.lifespan i p).birth, by
      have := (d.lifespan i p).birth_le_death
      have := (d.lifespan i p).death_le
      omega⟩
    exact ⟨j,hp,le_rfl,(d.lifespan i p).birth_le_death⟩

omit [Fintype Z] in
/-- The first live key visit recovers the actual schedule birth. -/
theorem canonicalKey_birth (i : I) (p : P i) (hp : p ∈ d.primes i) :
    d.canonicalKey.birth i p = some ⟨(d.lifespan i p).birth,
      Nat.lt_succ_of_le ((d.lifespan i p).birth_le_death.trans (d.lifespan i p).death_le)⟩ := by
  have hn : (d.canonicalKey.live i p).Nonempty :=
    (CanonicalHistoryKey.mem_primes _ i p).mp (by simpa using hp)
  rw [CanonicalHistoryKey.birth, dite_eq_left hn]
  congr 1
  apply le_antisymm
  · apply Finset.min'_le
    simp [canonicalKey,hp]
    exact (d.lifespan i p).birth_le_death
  · exact (Finset.mem_filter.mp (Finset.min'_mem _ hn)).2.2.1

omit [Fintype Z] in
/-- The final live key visit recovers the actual schedule death. -/
theorem canonicalKey_death (i : I) (p : P i) (hp : p ∈ d.primes i) :
    d.canonicalKey.death i p = some ⟨(d.lifespan i p).death,
      Nat.lt_succ_of_le (d.lifespan i p).death_le⟩ := by
  have hn : (d.canonicalKey.live i p).Nonempty :=
    (CanonicalHistoryKey.mem_primes _ i p).mp (by simpa using hp)
  rw [CanonicalHistoryKey.death, dite_eq_left hn]
  congr 1
  apply le_antisymm
  · exact (Finset.mem_filter.mp (Finset.max'_mem _ hn)).2.2.2
  · apply Finset.le_max'
    simp [canonicalKey,hp]
    exact (d.lifespan i p).birth_le_death

omit [Fintype Z] in
/-- On birth-normalized schedules, the derived retained key line is the
actual retained line of every used prime. -/
theorem canonicalKey_retained (hanchor : d.ActiveBirthAnchored)
    (i : I) (p : P i) (hp : p ∈ d.primes i) :
    d.canonicalKey.retained anchor i p = some (d.retained i p) := by
  rw [CanonicalHistoryKey.retained, d.canonicalKey_birth i p hp]
  simp only [Option.map_some, canonicalKey]
  rw [d.retained_eq_birth_anchor hanchor i p hp]

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- Canonicalizing the raw retained coordinates leaves the finite key
unchanged, including the always-active case. -/
@[simp] theorem canonicalizeRetained_canonicalKey :
    d.canonicalizeRetained.canonicalKey = d.canonicalKey := rfl

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- The ordered active arrays recover the used prime's active visits. -/
theorem canonicalKey_activeVisits (i : I) (p : P i) (hp : p ∈ d.primes i) :
    d.canonicalKey.activeVisits i p =
      Finset.univ.filter (fun j : Fin (N+1) => j.val ∈ (d.lifespan i p).active) := by
  apply Finset.filter_congr
  intro j _
  change (∃ a, d.active j.val i a = p) ↔ j.val ∈ (d.lifespan i p).active
  simpa only [hp,true_and] using (d.active_lifespan j.val (by omega) i p).symm

omit [Fintype Z] in
/-- Equality of keys determines every used lifespan, independently of any
history. Thus the key has forgotten no used lifespan information. -/
theorem canonicalKey_lifespan_unique (e : ScheduledPhysicalPath anchor N J B)
    (hk : d.canonicalKey = e.canonicalKey) (i : I) (p : P i) (hp : p ∈ d.primes i) :
    d.lifespan i p = e.lifespan i p := by
  have hs : d.primes i = e.primes i := by
    simpa only [canonicalKey_primes] using congrArg (fun k => k.primes i) hk
  have hep : p ∈ e.primes i := hs ▸ hp
  apply PrimeLifespan.eq_of_observable_traces
  · intro j hj
    let t : Fin (N+1) := ⟨j,by omega⟩
    have ha : d.canonicalKey.activeVisits i p = e.canonicalKey.activeVisits i p :=
      congrArg (fun k => k.activeVisits i p) hk
    rw [d.canonicalKey_activeVisits i p hp,e.canonicalKey_activeVisits i p hep] at ha
    have hm := Finset.ext_iff.mp ha t
    simpa only [Finset.mem_filter,Finset.mem_univ,true_and,t] using hm
  · intro j hj
    let t : Fin (N+1) := ⟨j,by omega⟩
    have hl : d.canonicalKey.live i p = e.canonicalKey.live i p :=
      congrArg (fun k => k.live i p) hk
    have hm := Finset.ext_iff.mp hl t
    rw [(d.lifespan i p).live_iff,(e.lifespan i p).live_iff]
    simpa only [canonicalKey,Finset.mem_filter,Finset.mem_univ,true_and,hp,hep,t] using hm

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Compatible schedules have exactly the same finite key. No existence
of a schedule for an arbitrary history is asserted here. -/
theorem compatible_canonicalKey_unique (e : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hsd : d.Before 0 s) (hse : e.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hcd : d.Compatible ν V η q ρ geometry N 0 s h)
    (hce : e.Compatible ν V η q ρ geometry N 0 s h) : d.canonicalKey = e.canonicalKey := by
  have hp := d.compatible_primes_unique ν V η q ρ geometry e s hsd hse h hcd hce
  have hv := d.compatible_visit_data_unique ν V η q ρ geometry e s hsd hse h hcd hce
  have he := d.compatible_edge_data_unique e ν V η q ρ geometry N 0 s h hcd hce
  apply CanonicalHistoryKey.ext
  · funext j
    exact (hv j.val (by omega)).1
  · funext j
    exact (hv j.val (by omega)).2
  · funext i p
    change Finset.filter _ Finset.univ = Finset.filter _ Finset.univ
    by_cases hpi : p ∈ d.primes i
    · have hl := d.compatible_lifespan_unique ν V η q ρ geometry e s hsd hse h hcd hce i p hpi
      simp only [hp,hl]
    · have hpei : p ∉ e.primes i := by simpa only [← hp] using hpi
      simp [hpi,hpei]
  · funext j
    simpa only [canonicalKey,Nat.zero_add] using (he j.val j.isLt).2.1
  · funext j
    simpa only [canonicalKey,Nat.zero_add] using (he j.val j.isLt).2.2.1
  · funext j
    simpa only [canonicalKey,Nat.zero_add] using (he j.val j.isLt).2.2.2.1
  · funext j
    simpa only [canonicalKey,Nat.zero_add] using (he j.val j.isLt).2.2.2.2.2
  · funext j
    simpa only [canonicalKey,Nat.zero_add] using (he j.val j.isLt).2.2.2.2.1

end ScheduledPhysicalPath

namespace ActualHistoryObservation
open ScheduledPhysicalPath
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Extract a finite key directly from the literal history. No schedule,
lineage, geometry, or distinctness assumption is supplied. -/
def canonicalKey
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s) :
    CanonicalHistoryKey I Z P J N where
  position j := (beforeStateAt ν V η q ρ geometry N 0 s h j).position P Line J B
  active j := (beforeStateAt ν V η q ρ geometry N 0 s h j).active P Line J B
  live i p := Finset.univ.filter (fun j => observedLive ν V η q ρ geometry N 0 s h j i p)
  sourcePerm j := (edgeAt ν V η q ρ anchor geometry N 0 s h j).sourcePerm
  targetPerm j := (edgeAt ν V η q ρ anchor geometry N 0 s h j).targetPerm
  store j := (edgeAt ν V η q ρ anchor geometry N 0 s h j).store
  promote j := (edgeAt ν V η q ρ anchor geometry N 0 s h j).promote
  targetPrime j := (edgeAt ν V η q ρ anchor geometry N 0 s h j).targetPrime

/-- The independently extracted actual key equals that of every compatible
schedule. The same arbitrary initial ordered memory is used on both sides. -/
theorem canonicalKey_of_compatible (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) :
    canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey := by
  have hv := d.compatible_observed_states ν V η q ρ geometry N 0 (by omega) s hs h hc
  have he := compatible_edgeAt ν V η q ρ anchor geometry d N 0 s h hc
  apply CanonicalHistoryKey.ext
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (hv j).1.1
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (hv j).1.2.1
  · funext i p
    apply Finset.filter_congr
    intro j _
    simpa only [Nat.zero_add] using
      d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hs h hc j i p
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (he j).2.1
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (he j).2.2.1
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (he j).2.2.2.1
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (he j).2.2.2.2.1
  · funext j
    simpa only [canonicalKey,ScheduledPhysicalPath.canonicalKey,Nat.zero_add] using (he j).2.2.2.2.2

/-- The key partition is exact for arbitrary coupled, signed, or globally
selected weights. No multiplicativity or constancy on a fiber is assumed. -/
theorem sum_key_fibers {R : Type*} [AddCommMonoid R]
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (W : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s → R) :
    (∑ k : CanonicalHistoryKey I Z P J N,
      ∑ h : {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
        canonicalKey ν V η q ρ anchor geometry s h = k}, W h.val) = ∑ h, W h := by
  exact Fintype.sum_fiberwise (canonicalKey ν V η q ρ anchor geometry s) W

/-- A finite family of initial states is kept as a genuine dependent sum.
This retains all initial-state multiplicities and permits a global weight
including the initial measure and both boundary factors. -/
theorem sum_dependent_initial_key_fibers {A R : Type*} [Fintype A] [AddCommMonoid R]
    (s : A → PhysicalMemoryState (Z:=Z) P Line J B)
    (W : (Σ a, ChoiceOperation.History
      (operations (anchor:=anchor) ν V η q ρ geometry 0 N) (s a)) → R) :
    (∑ k : CanonicalHistoryKey I Z P J N,
      ∑ h : {h : (Σ a, ChoiceOperation.History
          (operations (anchor:=anchor) ν V η q ρ geometry 0 N) (s a)) //
        canonicalKey ν V η q ρ anchor geometry (s h.1) h.2 = k}, W h.val) =
      ∑ a, ∑ h : ChoiceOperation.History
        (operations (anchor:=anchor) ν V η q ρ geometry 0 N) (s a), W ⟨a,h⟩ := by
  rw [Fintype.sum_fiberwise]
  exact Fintype.sum_sigma W

/-- The zero-one selector can impose distinct births, empty terminal
memory, geometric support, and endpoint conditions simultaneously. -/
theorem sum_selected_key_fibers {R : Type*} [AddCommMonoid R]
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (S : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s → Prop)
    (W : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s → R) :
    (∑ k : CanonicalHistoryKey I Z P J N,
      ∑ h : {h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s //
        canonicalKey ν V η q ρ anchor geometry s h = k}, if S h.val then W h.val else 0) =
      ∑ h, if S h then W h else 0 := by
  exact sum_key_fibers ν V η q ρ anchor geometry s (fun h => if S h then W h else 0)

end ActualHistoryObservation
end Elliptic.Operator
