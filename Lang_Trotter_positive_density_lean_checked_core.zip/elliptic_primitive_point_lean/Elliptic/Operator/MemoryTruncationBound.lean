module

public import Elliptic.Operator.MemoryPositiveWord
public import Elliptic.Operator.GroupedGhostChoiceRow

/-!
# A concrete bound for the actual truncated physical word

Both positive choice rows are derived: the ghost row from its actual
factorial deletion/birth coefficients, and the edge row from its actual
store/promotion/fresh choices and normalized endpoint permutations.
Consequently no row, column, operator norm, or truncation estimate is a
premise of the final theorem. The explicit finite position cardinality
and geometric supremum still have to be estimated in the growing source
parameter regime; this is not the full memory-moment theorem.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

theorem physicalGhostOperation_doubledBirthRow_le
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0≤ν i p) (hs : ∀ i, (∑ p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hQ : Q<ρ^2) (hq0 : 0≤q) (hqQ : q≤Q)
    (hη0 : 0≤η) (hη1 : η≤1) (hV0 : ∀ i,0≤V i) (hVmax : ∀ i,V i≤Vmax) :
    ChoiceOperation.doubledBirthRow (physicalGhostOperation ν V η q ρ anchor)
      (physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax))) m ≤
      (Real.exp (ghostSchurWeight ρ Q (2*Vmax)*max 1 (2*Vmax)*s/ρ))^(Fintype.card I) *
        physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) m := by
  rw [ChoiceOperation.doubledBirthRow_eq_all_choices]
  exact physicalGhost_doubled_birth_choice_row_uniform ν V η q ρ Q Vmax s anchor m
    hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax

/-- Explicit weighted bound for the actual positive history sum with
doubled ghost births, uniform in the ambient pending-memory cutoff B. -/
theorem physical_doubledBirthWord_le
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ Q Vmax s G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N : ℕ) (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℝ)
    (hν : ∀ i p,0≤ν i p) (hs : ∀ i,(∑ p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤q j) (hqQ : ∀ j,q j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hVmax : ∀ i,V i≤Vmax)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (hF : ∀ t,F t≤physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) t) :
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    ChoiceOperation.doubledBirthWord (physicalMemoryOperations ν V η q ρ anchor geometry N) F m ≤
      Cghost^(N+1)*Cedge^N*physicalMemorySchurWeight v0 m := by
  dsimp only
  apply memoryOperationsFrom_doubledBirthWord_le _ _ F
    (physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)))
    ((Real.exp (ghostSchurWeight ρ Q (2*Vmax)*max 1 (2*Vmax)*s/ρ))^(Fintype.card I))
    ((Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ
      (ghostSchurWeight ρ Q (2*Vmax)))
  · positivity
  · exact mul_nonneg (mul_nonneg (Nat.cast_nonneg _) hG)
      (Finset.prod_nonneg fun i _ => physicalEdgeLocalRowConstant_nonneg
        (ν i) (V i) ρ _ (hν i) (hV0 i) hρ1 (ghostSchurWeight_pos ρ Q (2*Vmax) hρ hQ))
  · intro j t
    exact physicalGhostOperation_doubledBirthRow_le ν V (η j) (q j) ρ Q Vmax s anchor t
      hν hs hs0 hρ hQ (hq0 j) (hqQ j) (hη0 j) (hη1 j) hV0 hVmax
  · intro j t
    exact physicalEdgeOperation_doubledBirthRow_le ν V ρ _ G anchor (geometry j) t
      hν hV0 hρ.le hρ1 (ghostSchurWeight_pos ρ Q (2*Vmax) hρ hQ) hG (hgeometry j)
  · exact hF

/-- A bound for the difference between the actual chronological physical
word and its literal size-T projection at every intermediate state. -/
theorem physical_memory_truncation_explicit_bound
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ Q Vmax s G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N T : ℕ) (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (hν : ∀ i p,0≤ν i p) (hs : ∀ i,(∑ p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤q j) (hqQ : ∀ j,q j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hVmax : ∀ i,V i≤Vmax)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (hF : ∀ t,‖F t‖≤physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) t)
    (hempty : physicalMemorySize m=0) (hT : Fintype.card I*N≤T) :
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    ‖ChoiceOperation.wordApply (physicalMemoryOperations ν V η q ρ anchor geometry N) F m -
      ChoiceOperation.cutoffWordApply physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) F m‖ ≤
      ((2:ℝ)^(T-Fintype.card I*N))⁻¹ * (Cghost^(N+1)*Cedge^N) := by
  dsimp only
  have htail := physical_memory_truncation_bound ν V η q ρ anchor geometry N T m F hempty hT
  have hword := physical_doubledBirthWord_le ν V η q ρ Q Vmax s G anchor geometry N m
    (fun t => ‖F t‖) hν hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0 hVmax hG hgeometry hF
  have hw : physicalMemorySchurWeight (ghostSchurWeight ρ Q (2*Vmax)) m = 1 := by
    change (ghostSchurWeight ρ Q (2*Vmax))^physicalMemorySize m=1
    rw [hempty,pow_zero]
  simp only [hw,mul_one] at hword
  exact htail.trans (mul_le_mul_of_nonneg_left hword (by positivity))

/-- The actual final empty-memory vector meets the terminal-weight condition;
there is no boundary-vector bound left as a hypothesis in this version. -/
theorem physical_memory_vacuum_truncation_explicit_bound
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ Q Vmax s G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N T : ℕ) (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p,0≤ν i p) (hs : ∀ i,(∑ p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤q j) (hqQ : ∀ j,q j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hVmax : ∀ i,V i≤Vmax)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (hempty : physicalMemorySize m=0) (hT : Fintype.card I*N≤T) :
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    let vacuum := fun t : PhysicalMemoryState (Z:=Z) P Line J B =>
      if physicalMemorySize t=0 then (1:ℂ) else 0
    ‖ChoiceOperation.wordApply (physicalMemoryOperations ν V η q ρ anchor geometry N) vacuum m -
      ChoiceOperation.cutoffWordApply physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) vacuum m‖ ≤
      ((2:ℝ)^(T-Fintype.card I*N))⁻¹ * (Cghost^(N+1)*Cedge^N) := by
  apply physical_memory_truncation_explicit_bound ν V η q ρ Q Vmax s G anchor geometry N T m _
    hν hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0 hVmax hG hgeometry _ hempty hT
  intro t
  have h := physical_vacuum_le_schurWeight (ghostSchurWeight ρ Q (2*Vmax))
    (ghostSchurWeight_pos ρ Q (2*Vmax) hρ hQ) t
  by_cases ht : physicalMemorySize t=0
  · simpa only [ht,↓reduceIte,norm_one] using h
  · simpa only [ht,↓reduceIte,norm_zero] using h

end Elliptic.Operator
