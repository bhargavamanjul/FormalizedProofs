module

public import Elliptic.Operator.RootCRT
public import Elliptic.Operator.SourceMemoryEdges

/-!
# Actual projective-line coordinates for residue memory

The affine chart is first coordinate divided by second coordinate;
`none` is the line with second coordinate zero. The resulting equivalence
identifies the project's concrete prime-residue anchors with actual
projective lines and transfers the exact joint CRT averaging identity.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootResidues

open scoped BigOperators LinearAlgebra.Projectivization Matrix
open scoped Classical

variable (k : Type*) [Field k]

/-- The ordinary affine chart, with the missing horizontal line labelled
by `none`. For the zero vector this auxiliary expression also gives none. -/
def vectorLineCoordinate (v : Fin 2 → k) : Option k :=
  if v 1 = 0 then none else some (v 0 / v 1)

theorem vectorLineCoordinate_scale
    (a b : {v : Fin 2 → k // v ≠ 0}) (t : k) (h : a.val = t • b.val) :
    vectorLineCoordinate k a.val = vectorLineCoordinate k b.val := by
  have ht : t ≠ 0 := by
    intro ht
    apply a.property
    rw [h, ht, zero_smul]
  have h0 : a.val 0 = t * b.val 0 := congrFun h 0
  have h1 : a.val 1 = t * b.val 1 := congrFun h 1
  by_cases hb : b.val 1 = 0
  · simp [vectorLineCoordinate, h1, hb]
  · simp [vectorLineCoordinate, h0, h1, hb, ht, mul_div_mul_left]

/-- The scale-independent coordinate of an actual projective point. -/
def projectiveLineCoordinate : ℙ k (Fin 2 → k) → Option k :=
  Projectivization.lift (fun v => vectorLineCoordinate k v.val)
    (vectorLineCoordinate_scale k)

@[simp]
theorem projectiveLineCoordinate_mk (v : Fin 2 → k) (hv : v ≠ 0) :
    projectiveLineCoordinate k (Projectivization.mk k v hv) =
      if v 1 = 0 then none else some (v 0 / v 1) := rfl

/-- Homogeneous representatives of the affine chart and its missing line. -/
def optionProjectiveLine : Option k → ℙ k (Fin 2 → k)
  | none => Projectivization.mk k ![1, 0]
      (by intro h; have := congrFun h 0; simp at this)
  | some a => Projectivization.mk k ![a, 1]
      (by intro h; have := congrFun h 1; simp at this)

@[simp]
theorem coordinate_optionProjectiveLine (a : Option k) :
    projectiveLineCoordinate k (optionProjectiveLine k a) = a := by
  cases a <;> simp [optionProjectiveLine]

theorem mk_eq_optionProjectiveLine (v : Fin 2 → k) (hv : v ≠ 0) :
    Projectivization.mk k v hv =
      optionProjectiveLine k (vectorLineCoordinate k v) := by
  by_cases h1 : v 1 = 0
  · simp only [vectorLineCoordinate, h1, ite_true, optionProjectiveLine]
    apply (Projectivization.mk_eq_mk_iff' k _ _ _ _).mpr
    refine ⟨v 0, ?_⟩
    ext i
    fin_cases i <;> simp [h1]
  · simp only [vectorLineCoordinate, ite_eq_right h1, optionProjectiveLine]
    apply (Projectivization.mk_eq_mk_iff' k _ _ _ _).mpr
    refine ⟨v 1, ?_⟩
    ext i
    fin_cases i <;> simp [h1, mul_div_cancel₀]

/-- The explicit projective-line equivalence used by the residue memory. -/
def projectiveLineEquivOption : ℙ k (Fin 2 → k) ≃ Option k where
  toFun := projectiveLineCoordinate k
  invFun := optionProjectiveLine k
  left_inv ℓ := by
    induction ℓ using Projectivization.ind with
    | h v hv => exact (mk_eq_optionProjectiveLine k v hv).symm
  right_inv := coordinate_optionProjectiveLine k

@[simp]
theorem projectiveLineEquivOption_mk (v : Fin 2 → k) (hv : v ≠ 0) :
    projectiveLineEquivOption k (Projectivization.mk k v hv) =
      if v 1 = 0 then none else some (v 0 / v 1) := rfl

theorem mk_eq_line_iff_mem (v : Fin 2 → k) (hv : v ≠ 0)
    (ℓ : ℙ k (Fin 2 → k)) :
    Projectivization.mk k v hv = ℓ ↔ v ∈ ℓ.submodule := by
  induction ℓ using Projectivization.ind with
  | h w hw =>
    rw [Projectivization.mk_eq_mk_iff', Projectivization.submodule_mk,
      Submodule.mem_span_singleton]

omit [Field k] in
theorem card_option_lines [Fintype k] : Fintype.card (Option k) = Fintype.card k + 1 := by
  simp

theorem card_prime_option_lines (p : ℕ) [Fact p.Prime] :
    Fintype.card (Option (ZMod p)) = p + 1 := by simp

/-- Single-prime uniform kernel-line averaging in the concrete coordinates. -/
theorem kernel_line_option_average [Fintype k] [DecidableEq k] (f : Option k → ℂ) :
    (∑ g : Matrix.SpecialLinearGroup (Fin 2) k,
        f (projectiveLineEquivOption k (kernelLine k g))) /
        (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) k) : ℂ) =
      (∑ a : Option k, f a) / ((Fintype.card k + 1 : ℕ) : ℂ) := by
  let : Fintype (ℙ k (Fin 2 → k)) := Fintype.ofEquiv (Option k)
    (projectiveLineEquivOption k).symm
  have h := kernel_line_average (fun ℓ => f (projectiveLineEquivOption k ℓ))
  rw [Equiv.sum_comp (projectiveLineEquivOption k) f, card_lines] at h
  exact h

/-- The exact joint CRT line average transfers to the literal memory
coordinates for arbitrary coupled functions of all prime lines. -/
theorem crt_kernel_option_average {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℕ) [∀ i, Fact (p i).Prime]
    (hp : Pairwise (fun i j => (p i).Coprime (p j)))
    [Fintype (ZMod (∏ i, p i))]
    (f : (∀ i, Option (ZMod (p i))) → ℂ) :
    (∑ g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i)),
        f (fun i => projectiveLineEquivOption (ZMod (p i))
          (kernelLine (ZMod (p i)) (sl2CRT p hp g i)))) /
        (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i))) : ℂ) =
      (∑ a : (∀ i, Option (ZMod (p i))), f a) / ((∏ i, (p i + 1)) : ℕ) := by
  let : ∀ i, Fintype (ℙ (ZMod (p i)) (Fin 2 → ZMod (p i))) :=
    fun i => Fintype.ofEquiv (Option (ZMod (p i)))
      (projectiveLineEquivOption (ZMod (p i))).symm
  let e : (∀ i, ℙ (ZMod (p i)) (Fin 2 → ZMod (p i))) ≃
      (∀ i, Option (ZMod (p i))) :=
    Equiv.piCongrRight fun i => projectiveLineEquivOption (ZMod (p i))
  have h := crt_kernel_average p hp (fun ℓ => f (e ℓ))
  rw [Equiv.sum_comp e f] at h
  exact h

/-- The concrete integer-vector anchor is exactly the coordinate of its
actual residue line, whenever the residue vector is nonzero. -/
theorem projectiveLineEquivOption_residue (p : ℕ) [Fact p.Prime] (z : ℤ × ℤ)
    (hz : (![ (z.1 : ZMod p), (z.2 : ZMod p)] : Fin 2 → ZMod p) ≠ 0) :
    projectiveLineEquivOption (ZMod p)
        (Projectivization.mk (ZMod p) ![(z.1 : ZMod p), (z.2 : ZMod p)] hz) =
      primeResidueAnchor p z := by
  simp only [projectiveLineEquivOption_mk, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.cons_val_fin_one, primeResidueAnchor, div_eq_mul_inv]

/-- Primitivity of the integer position prevents a zero residue vector at
every prime, including 2. This verifies the projective-line domain. -/
theorem primitive_residue_vector_ne_zero (p : ℕ) [Fact p.Prime]
    (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) :
    (![ (z.1 : ZMod p), (z.2 : ZMod p)] : Fin 2 → ZMod p) ≠ 0 := by
  intro h
  have h0 : (z.1 : ZMod p) = 0 := by simpa using congrFun h 0
  have h1 : (z.2 : ZMod p) = 0 := by simpa using congrFun h 1
  obtain ⟨a, b, hab⟩ := hz
  have hab' : (a : ZMod p) * (z.1 : ZMod p) + (b : ZMod p) * (z.2 : ZMod p) = 1 := by
    simpa only [Int.cast_add, Int.cast_mul, Int.cast_one] using
      congrArg (fun a : ℤ => (a : ZMod p)) hab
  simp [h0, h1] at hab'

/-- The actual projective reduction of a primitive integer position. -/
def primitiveResidueLine (p : ℕ) [Fact p.Prime]
    (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) : ℙ (ZMod p) (Fin 2 → ZMod p) :=
  Projectivization.mk (ZMod p) ![(z.1 : ZMod p), (z.2 : ZMod p)]
    (primitive_residue_vector_ne_zero p z hz)

@[simp]
theorem primitiveResidueLine_coordinate (p : ℕ) [Fact p.Prime]
    (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) :
    projectiveLineEquivOption (ZMod p) (primitiveResidueLine p z hz) =
      primeResidueAnchor p z :=
  projectiveLineEquivOption_residue p z _

theorem primeResidueAnchor_eq_iff_line_eq (p : ℕ) [Fact p.Prime]
    (z w : ℤ × ℤ) (hz : IsCoprime z.1 z.2) (hw : IsCoprime w.1 w.2) :
    primeResidueAnchor p z = primeResidueAnchor p w ↔
      primitiveResidueLine p z hz = primitiveResidueLine p w hw := by
  rw [← primitiveResidueLine_coordinate p z hz, ← primitiveResidueLine_coordinate p w hw]
  exact (projectiveLineEquivOption (ZMod p)).injective.eq_iff

/-- A memory line-match is exactly the marked-prime divisibility test on
the physical first coordinate of the actual integral root matrix. -/
theorem kernel_coordinate_eq_anchor_iff_dvd (p : ℕ) [Fact p.Prime]
    (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (z : ℤ × ℤ)
    (hz : IsCoprime z.1 z.2) :
    projectiveLineEquivOption (ZMod p)
        (kernelLine (ZMod p) (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod p)) g)) =
      primeResidueAnchor p z ↔
      (p : ℤ) ∣ g 0 0 * z.1 + g 0 1 * z.2 := by
  rw [← primitiveResidueLine_coordinate p z hz,
    (projectiveLineEquivOption (ZMod p)).injective.eq_iff, eq_comm]
  change Projectivization.mk (ZMod p) _ _ = _ ↔ _
  rw [mk_eq_line_iff_mem, mem_kernelLine_iff]
  change (g 0 0 : ZMod p) * (z.1 : ZMod p) +
    (g 0 1 : ZMod p) * (z.2 : ZMod p) = 0 ↔ _
  rw [← Int.cast_mul, ← Int.cast_mul, ← Int.cast_add]
  exact ZMod.intCast_zmod_eq_zero_iff_dvd _ _

end Elliptic.Operator.RootResidues
