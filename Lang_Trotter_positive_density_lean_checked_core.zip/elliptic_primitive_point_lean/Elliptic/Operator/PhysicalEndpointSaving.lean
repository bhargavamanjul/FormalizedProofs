module

public import Elliptic.Operator.PhysicalPatchedEndpoint
public import Elliptic.Operator.PhysicalEndpointNorm
public import Elliptic.Operator.PhysicalMomentSaving
public import Elliptic.Operator.PhysicalVertexParameters
public import Elliptic.Operator.PhysicalEndpointParameters

/-! Arbitrary saving for the literal physical endpoint pairing. The
ordered active-list normalization cancels before the growing moment is
taken, and slope localization removes the full-box root loss. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalEndpointSaving
open Filter
open scoped BigOperators SchwartzMap
open PhysicalRootedMoment PhysicalAdmissibleMoment PhysicalPatchedEndpoint
open PhysicalMomentIdentification PhysicalEndpointNorm PhysicalVertexParameters
open PhysicalRootMomentNumeric PhysicalVertexDamping SingleEdgeRootEncoding
open PhysicalRootIndependentMoment PhysicalRootBoundarySaving SourceRootCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

theorem patch_power_simplify (R : ℕ) (hR : 0<R)
    (X B D H M a f g : ℝ) (hX : 0≤X) (hB : 0≤B) (hD : 1≤D)
    (hH : 0≤H) (hM : 0≤M) (hf : 0≤f) (hg : 0≤g)
    (hfbound : f≤51*X*B^2) (hgbound : g≤51*X*B^2)
    (ha : a≤D^R*g^R*f^(R-1)*(H*B^2)*(X*M)) :
    a≤(51*D)^(2*R)*X^(2*R)*B^(2*(2*R))*H*M := by
  let T := 51*X*B^2
  have hT : 0≤T := by positivity
  have hBM : X*B^2≤T := by dsimp [T]; nlinarith [mul_nonneg hX (sq_nonneg B)]
  have hpowD : D^R≤D^(2*R) := pow_le_pow_right₀ hD (by omega)
  calc
    a ≤ D^R*T^R*T^(R-1)*(H*B^2)*(X*M) :=
      ha.trans (by gcongr)
    _ = D^R*(T^R*T^(R-1))*(X*B^2)*H*M := by ring
    _ ≤ D^(2*R)*(T^R*T^(R-1))*T*H*M := by
      gcongr
    _ = D^(2*R)*(T^R*T^(R-1)*T)*H*M := by ring
    _ = D^(2*R)*T^(2*R)*H*M := by
      rw [←pow_add,←pow_succ,show R+(R-1)+1=2*R by omega]
    _ = _ := by simp only [T,mul_pow,pow_mul]; ring

theorem scalar_endpoint_power (N : ℕ) (L A C X C₀ H : ℝ)
    (hL : 1≤L) (hX : 0≤X)
    (hcost : C₀^N*H≤L^N) :
    C₀^N*X^N*(L^C)^(2*N)*H*L^(-(A+2*C+2)*(N:ℝ))≤
      (X*L^(-A))^N := by
  have hLp : 0<L := by linarith
  calc
    _ = X^N*(C₀^N*H)*(L^C)^(2*N)*L^(-(A+2*C+2)*(N:ℝ)) := by ring
    _ ≤ X^N*L^N*(L^C)^(2*N)*L^(-(A+2*C+2)*(N:ℝ)) := by
      gcongr
    _ = X^N*L^((-(A+1))*(N:ℝ)) := by
      rw [←Real.rpow_natCast L N,←Real.rpow_mul_natCast hLp.le]
      simp only [Nat.cast_mul,Nat.cast_ofNat]
      rw [mul_assoc (X^N),←Real.rpow_add hLp,mul_assoc (X^N),←Real.rpow_add hLp]
      congr 2
      ring
    _ ≤ X^N*L^((-A)*(N:ℝ)) := by
      gcongr
      linarith
    _ = _ := by rw [mul_pow,←Real.rpow_mul_natCast hLp.le]

/-- The group count is selected before the cutoffs, source constants,
and coefficient family. This is the literal damped physical pairing,
with no spectral, cancellation, or patch estimates among its premises. -/
theorem exists_group_count_for_physical_endpoint (hPD : RootCountContract)
    (A C : ℝ) (hA : 0≤A) (hC : 0≤C) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(ψ : 𝓢(ℝ,ℂ)) (smooth : ℝ→ℂ) (D δ Cψ q vmin vmax : ℝ),
      0≤D→0<δ→1≤Cψ→0<q→q<1→0<vmin→
      (∀t,‖smooth t‖≤1)→(∀t,smooth t≠0→1≤t)→
      (∀t,‖ψ t‖≤1)→(∀t,ψ t≠0→|t|≤Cψ)→
      ∀ᶠx : ℝ in atTop,let L := Real.log x
      ∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀groups : Fin K→Finset ℕ,∀[∀i (p:groups i),Fact p.val.Prime],
      (∀i j,i≠j→Disjoint (groups i) (groups j))→∀VM : Fin K→ℝ,
      (∀i,vmin≤VM i)→(∀i,VM i≤vmax)→(∀i,VM i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      (∀i,∀p∈groups i,(p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))→
      ∀(U V d₀ Y : ℝ),x^δ≤U→U≤x^2→x^δ≤V→V≤x^2→1≤U*V→0<d₀→
      1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→d₀*Y≤Real.exp (D*L^(21/100:ℝ))→
      ∀(σ : ℤ),(σ=1∨σ= -1)→
      ∀(f : primitiveSources U V→ℂ), (∀z,‖f z‖≤L^C)→
      ∀(G : PhysicalRootedMoment.State (Z:=primitiveSources U V)
        (P:=fun i=>groups i) (J:=momentPadding L)→ℂ), (∀z,‖G z‖≤L^C)→
      ‖pairing VM (fun x=>f x.1) (rowApply VM
        (physicalGeometry (fun i (p:groups i)=>p.val) (fun i (p:groups i)=>1/(VM i*p.val))
          d₀ Y L U V a smooth ψ
          (sourceMajorArcs (L^(sourceContractionExponent (A+2*C+4)+6)) Y) σ
          (primePool (fun i (p:groups i)=>p.val)) (1-Real.sqrt q)) G)‖≤U*V*L^(-A) := by
  let E := A+2*C+2
  obtain ⟨K₀,hK₀,hmoment⟩ := PhysicalMomentSaving.exists_group_count_for_physical_moment hPD E (by dsimp [E]; linarith)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ψ smooth D δ Cψ q vmin vmax hD hδ hCψ hq0 hq1 hmin hsmooth hsupport hψ hsuppψ
  obtain ⟨ρ,hρ0,hρ1,hρq⟩ := exists_memory_parameter q hq0 hq1
  let Dn := (⌈2*Cψ⌉+1).toNat
  let overlap : ℝ := (2*Dn+1:ℕ)
  have hover : 1≤overlap := by dsimp [overlap]; exact_mod_cast (show 1≤2*Dn+1 by omega)
  have hC₀ : 0≤51*overlap := by positivity
  filter_upwards [hmoment K hK ψ smooth D δ Cψ ρ vmin vmax (Real.sqrt q)
      hD hδ hCψ hρ0 hρ1 hmin hρq hsmooth hsupport hψ hsuppψ,
    Real.tendsto_log_atTop.eventually (eventually_listProduct_le_scale K δ hδ),
    Real.tendsto_log_atTop.eventually (PhysicalEndpointParameters.eventually_const_exp_le_pow_moment
      (51*overlap) 16929 D hC₀ (by norm_num)),
    Real.tendsto_log_atTop.eventually PhysicalEndpointParameters.eventually_half_moment_ge_two,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),eventually_ge_atTop (1:ℝ)]
      with x hm hlist hcost hR hxL hx
  dsimp only
  let L := Real.log x
  let R := ⌈L^(1/2:ℝ)/2⌉₊
  have hR' : 2≤R := hR
  have hN : momentLength L=2*R := rfl
  have hLp : 0<L := by change 0<Real.log x; linarith
  intro a ha groups instPr hdis VM hVlo hVhi hVsum hband hupper U V d₀ Y
    hU hUhi hV hVhi' hUV hd hY hYlo hYhi hprod σ hσ f hf G hG
  letI : ∀i (p:groups i),Fact p.val.Prime := instPr
  let value := fun i (p:groups i)=>p.val
  let μ := fun i (p:groups i)=>1/(VM i*p.val)
  let F : PhysicalRootedMoment.State (Z:=primitiveSources U V)
      (P:=fun i=>groups i) (J:=momentPadding L)→ℂ := fun x=>f x.1
  let pos := fun z:primitiveSources U V=>z.val
  let major := sourceMajorArcs (L^(sourceContractionExponent (E+2)+6)) Y
  let g := physicalGeometry (J:=momentPadding L) value μ d₀ Y L U V a smooth ψ major σ
    (primePool value) (1-Real.sqrt q)
  have hVM : ∀i,0<VM i := fun i=>hmin.trans_le (hVlo i)
  have hVsum' : ∀i,VM i=∑p:groups i,1/(p.val:ℝ) := by
    intro i
    rw [hVsum i]
    exact Finset.sum_subtype (groups i) (fun _=>Iff.rfl) _
  have hxδ : x^δ=Real.exp (δ*L) := by rw [Real.rpow_def_of_pos (by linarith : 0<x)]; congr 1; ring
  have hUp : 0<U := (Real.exp_pos _).trans_le (by rwa [←hxδ])
  have hV1 : 1≤V := (Real.one_le_rpow hx hδ.le).trans hV
  have hGU : ∀b : PhysicalActiveLists (fun i=>groups i) (momentPadding L),
      (listProduct value b:ℝ)≤U :=
    @hlist (fun i=>groups i) inferInstance value (fun i p=>hupper i p.val p.property) U (by rwa [←hxδ])
  have hpF := projected_self_norm_le pos Subtype.val_injective U V (fun z=>z.property) value
    (fun i p=>Fact.out) hGU hV1 VM hVsum' hVM F (L^C) (by positivity) (fun z=>hf z.1)
  have hpG := projected_self_norm_le pos Subtype.val_injective U V (fun z=>z.property) value
    (fun i p=>Fact.out) hGU hV1 VM hVsum' hVM G (L^C) (by positivity) hG
  have hpFn := PhysicalPatchGluing.pairing_self_re_nonneg VM (fun i=>(hVM i).le) (project value pos F)
  have hpGn := PhysicalPatchGluing.pairing_self_re_nonneg VM (fun i=>(hVM i).le) (project value pos G)
  have hheight : 1≤Real.exp (D*L^(21/100:ℝ)) := Real.one_le_exp (by positivity)
  have hp := physical_patched_endpoint_power_bound (J:=momentPadding L) value μ VM (fun i=>(hVM i).le)
    d₀ Y L U V a smooth ψ major σ (primePool value)
    (fun i p=>Finset.mem_image.mpr ⟨⟨i,p⟩,Finset.mem_univ _,rfl⟩)
    (1-Real.sqrt q) (Real.exp (D*L^(21/100:ℝ))) Cψ hUp hd (by linarith) hheight hprod
    (by linarith) hsuppψ R hR (L^C) (by positivity) f hf G
  have hdam := source_momentDamping_bounds q hq0 hq1 (momentLength L)
  have hm' := @hm a ha groups instPr hdis VM hVlo hVhi hVsum hband hupper
    U V d₀ Y hU hUhi hV hVhi' hUV hd hY hYlo hYhi hprod
    (momentDamping (1-Real.sqrt q) (momentLength L)) hdam.1 hdam.2.1 hdam.2.2 alternatingAdjoint σ hσ
  rw [hN] at hm'
  have hmr := (Complex.re_le_norm _).trans hm'
  have hp' := hp.trans (mul_le_mul_of_nonneg_left hmr (by positivity))
  have hs := patch_power_simplify R (by omega) (U*V) (L^C) overlap
    (16929*Real.exp (D*L^(21/100:ℝ))) (L^(-E*(2*R:ℕ)))
    (‖pairing VM F (rowApply VM g G)‖^(2*R))
    (pairing VM (project value pos F) (project value pos F)).re
    (pairing VM (project value pos G) (project value pos G)).re
    (by linarith) (by positivity) hover (by positivity) (by positivity) hpFn hpGn
    (by simpa only [mul_assoc] using hpF) (by simpa only [mul_assoc] using hpG) hp'
  have hcost' : (51*overlap)^(2*R)*(16929*Real.exp (D*L^(21/100:ℝ)))≤L^(2*R) := by
    change (51*overlap)^(momentLength L)*16929*Real.exp (D*L^(21/100:ℝ))≤L^(momentLength L) at hcost
    simpa only [hN,mul_assoc] using hcost
  have hscalar := scalar_endpoint_power (2*R) L A C (U*V) (51*overlap)
    (16929*Real.exp (D*L^(21/100:ℝ))) hxL (by linarith) hcost'
  have hpower := hs.trans hscalar
  have hfinal := (pow_le_pow_iff_left₀ (norm_nonneg _) (by positivity : 0≤U*V*L^(-A))
    (by omega : 2*R≠0)).mp hpower
  convert hfinal using 1 <;> dsimp only [F,g,value,μ,major,E] <;> congr 6 <;> ring

end Elliptic.Operator.PhysicalEndpointSaving
