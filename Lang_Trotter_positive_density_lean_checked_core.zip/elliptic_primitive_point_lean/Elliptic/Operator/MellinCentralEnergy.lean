module
public import Elliptic.Operator.MellinPlaneUniform
public import Mathlib.MeasureTheory.Integral.Prod

/-! Central Mellin rectangles from the actual two Dirichlet mean-square estimates. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinCentralEnergy
open MeasureTheory Set
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

/-- The slice Cauchy estimate in a form avoiding square-root normalization. -/
theorem slice_bound (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (T C ε s:ℝ) (hC:0≤C)
    (hbound:∀t∈Icc (-T) T,‖K t s‖≤C)
    (henergy:(∫t in Icc (-T) T,‖Q t‖^2)≤ε)
    (henergy':(∫t in Icc (-T) T,‖Q' (s-t)‖^2)≤ε) :
    ‖∫t in Icc (-T) T,K t s*Q t*Q' (s-t)‖≤C*ε := by
  have hk : Continuous (fun t=>K t s) := hK.comp (continuous_id.prodMk continuous_const)
  have hg : Continuous (fun t=>Q' (s-t)) := hQ'.comp (continuous_const.sub continuous_id)
  have hi : IntegrableOn (fun t=>‖K t s*Q t*Q' (s-t)‖) (Icc (-T) T) :=
    ((hk.mul hQ).mul hg).norm.continuousOn.integrableOn_compact isCompact_Icc
  have hiQ : IntegrableOn (fun t=>‖Q t‖^2) (Icc (-T) T) :=
    (hQ.norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  have hiQ' : IntegrableOn (fun t=>‖Q' (s-t)‖^2) (Icc (-T) T) :=
    (hg.norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  apply (norm_integral_le_integral_norm _).trans
  calc
    _ ≤ ∫t in Icc (-T) T,(C/2)*(‖Q t‖^2+‖Q' (s-t)‖^2) := by
      apply setIntegral_mono_on hi ((hiQ.add hiQ').const_mul _) measurableSet_Icc
      intro t ht
      rw [norm_mul,norm_mul]
      change ‖K t s‖*‖Q t‖*‖Q' (s-t)‖≤(C/2)*(‖Q t‖^2+‖Q' (s-t)‖^2)
      have hm := mul_le_mul_of_nonneg_right (hbound t ht) (mul_nonneg (norm_nonneg (Q t)) (norm_nonneg (Q' (s-t))))
      have hc := mul_nonneg hC (sq_nonneg (‖Q t‖-‖Q' (s-t)‖))
      nlinarith
    _ = (C/2)*((∫t in Icc (-T) T,‖Q t‖^2)+(∫t in Icc (-T) T,‖Q' (s-t)‖^2)) := by
      rw [integral_const_mul,integral_add hiQ hiQ']
    _ ≤ C*ε := by nlinarith [mul_le_mul_of_nonneg_left (add_le_add henergy henergy') (show 0≤C/2 by positivity)]

/-- Continuity gives the actual rectangle integrability required by Fubini. -/
theorem rectangle_integrable (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q') (T S:ℝ) :
    Integrable (fun p:ℝ×ℝ=>K p.2 p.1*Q p.2*Q' (p.1-p.2))
      ((volume.restrict (Icc (-S) S)).prod (volume.restrict (Icc (-T) T))) := by
  rw [Measure.prod_restrict,←Measure.volume_eq_prod]
  exact (((hK.comp continuous_swap).mul (hQ.comp continuous_snd)).mul
    (hQ'.comp (continuous_fst.sub continuous_snd))).continuousOn.integrableOn_compact
      (isCompact_Icc.prod isCompact_Icc)

/-- The central rectangle estimate, integrating shifted slices first. -/
theorem central_rectangle_swapped (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (T S C ε:ℝ) (hS:0≤S) (hC:0≤C)
    (hbound:∀t∈Icc (-T) T,∀s∈Icc (-S) S,‖K t s‖≤C)
    (henergy:(∫t in Icc (-T) T,‖Q t‖^2)≤ε)
    (henergy':∀s∈Icc (-S) S,(∫t in Icc (-T) T,‖Q' (s-t)‖^2)≤ε) :
    ‖∫s in Icc (-S) S,∫t in Icc (-T) T,K t s*Q t*Q' (s-t)‖≤2*S*C*ε := by
  have hi := rectangle_integrable K Q Q' hK hQ hQ' T S
  apply (norm_integral_le_integral_norm _).trans
  calc
    _ ≤ ∫s in Icc (-S) S,C*ε := by
      apply setIntegral_mono_on hi.integral_prod_left.norm (continuous_const.continuousOn.integrableOn_compact isCompact_Icc) measurableSet_Icc
      intro s hs
      exact slice_bound K Q Q' hK hQ hQ' T C ε s hC (fun t ht=>hbound t ht s hs) henergy (henergy' s hs)
    _ = _ := by
      rw [setIntegral_const,Real.volume_real_Icc_of_le (by linarith : -S≤S)]
      simp only [smul_eq_mul]
      ring

/-- The same estimate in the exact order used by the Mellin separation identity. -/
theorem central_rectangle (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (T S C ε:ℝ) (hS:0≤S) (hC:0≤C)
    (hbound:∀t∈Icc (-T) T,∀s∈Icc (-S) S,‖K t s‖≤C)
    (henergy:(∫t in Icc (-T) T,‖Q t‖^2)≤ε)
    (henergy':∀s∈Icc (-S) S,(∫t in Icc (-T) T,‖Q' (s-t)‖^2)≤ε) :
    ‖∫t in Icc (-T) T,∫s in Icc (-S) S,K t s*Q t*Q' (s-t)‖≤2*S*C*ε := by
  have hi := rectangle_integrable K Q Q' hK hQ hQ' T S
  rw [←integral_integral_swap hi]
  exact central_rectangle_swapped K Q Q' hK hQ hQ' T S C ε hS hC hbound henergy henergy'

end Elliptic.Operator.MellinCentralEnergy
