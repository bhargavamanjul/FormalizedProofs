module

public import Elliptic.Operator.WeightedSchur

/-! Measured Schur estimate for matrices acting by counting sums. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
set_option maxHeartbeats 1000000

/-- A measured reverse converts the actual counting row on the reverse
matrix into the opposite column, with no cardinality or measure loss. -/
theorem countingKernel_schur {X : Type*} [Fintype X]
    (μ h : X → ℝ) (K L : X → X → ℂ) (R C : ℝ)
    (hμ : ∀ x, 0 < μ x) (hh : ∀ x, 0 < h x) (hR : 0 ≤ R) (hC : 0 ≤ C)
    (hbalance : ∀ s t, μ s * ‖K s t‖ = μ t * ‖L t s‖)
    (hrow : ∀ s, (∑ t, ‖K s t‖ * (h t / h s)) ≤ R)
    (hreverse : ∀ t, (∑ s, ‖L t s‖ * (h s / h t)) ≤ C)
    (F : X → ℂ) :
    finiteL2 Finset.univ μ (fun s => ∑ t, K s t * F t) ≤
      Real.sqrt (R*C) * finiteL2 Finset.univ μ F := by
  let A : X → X → ℂ := fun s t => K s t / (μ t:ℂ)
  have hnorm (s t : X) : ‖A s t‖ = ‖K s t‖ / μ t := by
    simp only [A,norm_div,Complex.norm_real,Real.norm_eq_abs,abs_of_pos (hμ t)]
  have hforward (s : X) : (∑ t, ‖K s t‖ * h t) ≤ R*h s := by
    have he : (∑ t, ‖K s t‖ * (h t/h s)) = (∑ t, ‖K s t‖ * h t) / h s := by
      simp only [div_eq_mul_inv,mul_assoc,Finset.sum_mul]
    have hr := hrow s
    rw [he] at hr
    exact (div_le_iff₀ (hh s)).mp hr
  have hback (t : X) : (∑ s, ‖L t s‖ * h s) ≤ C*h t := by
    have he : (∑ s, ‖L t s‖ * (h s/h t)) = (∑ s, ‖L t s‖ * h s) / h t := by
      simp only [div_eq_mul_inv,mul_assoc,Finset.sum_mul]
    have hr := hreverse t
    rw [he] at hr
    exact (div_le_iff₀ (hh t)).mp hr
  have hr : ∀ s ∈ (Finset.univ : Finset X), ∑ t ∈ (Finset.univ : Finset X),
      μ t * ‖A s t‖ * h t ≤ R*h s := by
    intro s _
    simp only [hnorm,mul_div_cancel₀ _ (hμ _).ne']
    exact hforward s
  have hc : ∀ t ∈ (Finset.univ : Finset X), ∑ s ∈ (Finset.univ : Finset X),
      μ s * ‖A s t‖ * h s ≤ C*h t := by
    intro t _
    calc
      _ = ∑ s, ‖L t s‖ * h s := by
        apply Finset.sum_congr rfl
        intro s _
        rw [hnorm]
        have he := hbalance s t
        calc
          μ s * (‖K s t‖ / μ t) * h s = (μ s * ‖K s t‖) / μ t * h s := by ring
          _ = _ := by rw [he,mul_div_cancel_left₀ _ (hμ t).ne']
      _ ≤ _ := hback t
  have he := finite_weighted_schur Finset.univ Finset.univ μ h μ h A R C
    (fun s _ => (hμ s).le) (fun s _ => (hμ s).le)
    (fun s _ => hh s) (fun s _ => hh s) hR hC hr hc F
  have happly : finiteKernelApply Finset.univ μ A F = fun s => ∑ t, K s t * F t := by
    funext s
    unfold finiteKernelApply
    apply Finset.sum_congr rfl
    intro t _
    have hm : (μ t:ℂ) ≠ 0 := by exact_mod_cast (hμ t).ne'
    dsimp only [A]
    field_simp
  rw [happly] at he
  exact he

end Elliptic.Operator
