module

public import Elliptic.Operator.PhysicalCleanLocalGeometry

/-! Endpoint eligibility is a genuine restriction of the source kernel.
Extending its estimate to the original finite supports loses no norm. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalCleanEligibleDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- A measured bound on the eligible endpoint supports extends to the
original supports when the actual kernel vanishes at every excluded pair. -/
theorem finiteMeasuredBilinearBound_of_filter {X Y : Type*}
    (s : Finset X) (t : Finset Y) (μ : X → ℝ) (ν : Y → ℝ)
    (P : X → Prop) (Q : Y → Prop) (K : X → Y → ℂ) (M : ℝ)
    (hμ : ∀ x∈s, 0≤μ x) (hν : ∀ y∈t, 0≤ν y) (hM : 0≤M)
    (hzero : ∀ x∈s, ∀ y∈t, ¬(P x ∧ Q y) → K x y=0)
    (hK : FiniteMeasuredBilinearBound (s.filter P) (t.filter Q) μ ν K M) :
    FiniteMeasuredBilinearBound s t μ ν K M := by
  intro a b
  have hp : finiteMeasuredPairing s t μ ν K a b =
      finiteMeasuredPairing (s.filter P) (t.filter Q) μ ν K a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    calc
      _ = ∑ x∈s.filter P, (μ x:ℂ)*a x*(∑ y∈t, (ν y:ℂ)*K x y*b y) := by
        apply (Finset.sum_subset (Finset.filter_subset P s) ?_).symm
        intro x hx hnot
        have hn : ¬P x := fun h => hnot (Finset.mem_filter.mpr ⟨hx,h⟩)
        have hz : ∀ y∈t, K x y=0 := fun y hy => hzero x hx y hy (fun h => hn h.1)
        have hzsum : (∑ y∈t, (ν y:ℂ)*K x y*b y)=0 :=
          Finset.sum_eq_zero (fun y hy => by rw [hz y hy,mul_zero,zero_mul])
        rw [hzsum,mul_zero]
      _ = _ := by
        apply Finset.sum_congr rfl
        intro x hx
        congr 1
        apply (Finset.sum_subset (Finset.filter_subset Q t) ?_).symm
        intro y hy hnot
        have hn : ¬Q y := fun h => hnot (Finset.mem_filter.mpr ⟨hy,h⟩)
        rw [hzero x (Finset.mem_filter.mp hx).1 y hy (fun h => hn h.2),mul_zero,zero_mul]
  have ha : finiteL2 (s.filter P) μ a≤finiteL2 s μ a := by
    apply Real.sqrt_le_sqrt
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset P s)
      (fun x hx _ => mul_nonneg (hμ x hx) (sq_nonneg _))
  have hb : finiteL2 (t.filter Q) ν b≤finiteL2 t ν b := by
    apply Real.sqrt_le_sqrt
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset Q t)
      (fun y hy _ => mul_nonneg (hν y hy) (sq_nonneg _))
  rw [hp]
  exact (hK a b).trans (mul_le_mul (mul_le_mul_of_nonneg_left ha hM) hb
    (Real.sqrt_nonneg _) (mul_nonneg hM (Real.sqrt_nonneg _)))

namespace PhysicalCleanEligible

private def edgeSlot (J : ℕ) (b : Bool) : Fin (J+1) → Fin J ⊕ Bool :=
  Fin.lastCases (.inr b) (fun k => .inl k)

private theorem edgeSlot_injective (J : ℕ) (b : Bool) :
    Function.Injective (edgeSlot J b) := by
  intro k l
  refine Fin.lastCases ?_ (fun k => ?_) k <;>
    refine Fin.lastCases ?_ (fun l => ?_) l <;> simp [edgeSlot]

/-- The literal cross-edge ban forces injectivity at both endpoints. -/
theorem crossEdgeBan_lists_injective {I : Type*} {P : I → Type*} {J : ℕ}
    (value : ∀ i, P i → ℕ) (a b : PhysicalActiveLists P J)
    (h : sourceCrossEdgeBan value a b) :
    (∀ i, Function.Injective (a i)) ∧ (∀ i, Function.Injective (b i)) := by
  have ha (i : I) (k : Fin (J+1)) :
      sourceCrossEdgeLabels value a b (i,edgeSlot J false k)=value i (a i k) := by
    refine Fin.lastCases ?_ (fun k => ?_) k <;> simp [sourceCrossEdgeLabels,edgeSlot]
  have hb (i : I) (k : Fin (J+1)) :
      sourceCrossEdgeLabels value a b (i,edgeSlot J true k)=value i (b i k) := by
    refine Fin.lastCases ?_ (fun k => ?_) k
    · simp [sourceCrossEdgeLabels,edgeSlot]
    · simp [sourceCrossEdgeLabels,edgeSlot,h.1 i k]
  constructor
  · intro i k l he
    apply edgeSlot_injective J false
    exact congrArg Prod.snd (h.2 (a₁:=(i,edgeSlot J false k))
      (a₂:=(i,edgeSlot J false l)) (by rw [ha,ha,he]))
  · intro i k l he
    apply edgeSlot_injective J true
    exact congrArg Prod.snd (h.2 (a₁:=(i,edgeSlot J true k))
      (a₂:=(i,edgeSlot J true l)) (by rw [hb,hb,he]))

variable {I : Type*} [Fintype I] {P : I → Type*} {J : ℕ}

/-- All tests needed to retain an endpoint in the clean cancellation
estimate are single-endpoint predicates. -/
def endpointEligible (value : ∀ i, P i → ℕ)
    (good : (ℤ×ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W Y : ℝ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : Prop :=
  sourcePhysicalPositionAllowed u v r U W z ∧ good z a ∧
    (∀ i, Function.Injective (a i)) ∧ Y≤(sourceUnsharedProduct value a:ℝ)

/-- Nonzero literal source geometry automatically lies on the endpoint
eligibility supports, using only the support of the actual eta cutoff. -/
theorem source_geometry_nonzero_eligible
    (value : ∀ i, P i → ℕ)
    (good : (ℤ×ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hY : 0<Y) (hη : ∀ x, η x≠0 → 1≤x)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J)
    (hn : sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b≠0) :
    endpointEligible value good u v r U W Y z a ∧
      endpointEligible value good u v r U W Y w b := by
  have ha : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
    by_contra h
    simp [sourcePhysicalEdgeGeometry,h] at hn
  have hi := crossEdgeBan_lists_injective value a b ha.2.2.2.2.1
  have hηa : η ((sourceUnsharedProduct value a:ℝ)/Y)≠0 := by
    intro he
    simp [sourcePhysicalEdgeGeometry,ha,he] at hn
  have hηb : η ((sourceUnsharedProduct value b:ℝ)/Y)≠0 := by
    intro he
    simp [sourcePhysicalEdgeGeometry,ha,he] at hn
  exact ⟨⟨ha.1,ha.2.2.1,hi.1,by simpa using (le_div_iff₀ hY).mp (hη _ hηa)⟩,
    ⟨ha.2.1,ha.2.2.2.1,hi.2,by simpa using (le_div_iff₀ hY).mp (hη _ hηb)⟩⟩

end PhysicalCleanEligible
end Elliptic.Operator
