module

public import Elliptic.PrimewiseMemory
public import Elliptic.Operator.MemoryWord

/-!+# Prime lifespans and their literal pending-memory schedule

For each prime the independent-line expansion has at most one lifespan.
Its pending state before/after a visit is determined by its birth, death
and actual active visits.  The lemmas below prove the chronological
store/promote/ghost schedule, rather than assuming a word identity.  The
identification with the full indexed multi-prime choice history will also
need its ordering/factorial multiplicities.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- One prime's lifespan, with all its actual active visits inside it.
A singleton lifespan is allowed only when the prime is active there. -/
structure PrimeLifespan (N : ℕ) where
  birth : ℕ
  death : ℕ
  birth_le_death : birth ≤ death
  death_le : death ≤ N
  active : Finset ℕ
  active_bounds : ∀ j ∈ active, birth ≤ j ∧ j ≤ death
  singleton_active : birth = death → birth ∈ active

namespace PrimeLifespan
variable {N : ℕ} (L : PrimeLifespan N)

def beforeGhost (j : ℕ) : Prop := L.birth < j ∧ j ≤ L.death ∧ j ∉ L.active
def afterGhost (j : ℕ) : Prop := L.birth ≤ j ∧ j < L.death ∧ j ∉ L.active
def ghostBorn (j : ℕ) : Prop := j = L.birth ∧ j ∉ L.active
def ghostDies (j : ℕ) : Prop := j = L.death ∧ j ∉ L.active
def stored (j : ℕ) : Prop := j ∈ L.active ∧ j < L.death ∧ j+1 ∉ L.active
def promoted (j : ℕ) : Prop := j+1 ∈ L.active ∧ L.birth < j+1 ∧ j ∉ L.active
def freshActive (j : ℕ) : Prop := j = L.birth ∧ j ∈ L.active

theorem ghostBorn_birth_lt_death {j : ℕ} (hj : L.ghostBorn j) : L.birth < L.death := by
  have hle := L.birth_le_death
  have hsingle := L.singleton_active
  rcases hj with ⟨rfl, hj⟩
  by_contra h
  exact hj (hsingle (by omega))

theorem ghostDies_birth_lt_death {j : ℕ} (hj : L.ghostDies j) : L.birth < L.death := by
  have hle := L.birth_le_death
  have hsingle := L.singleton_active
  rcases hj with ⟨rfl, hj⟩
  by_contra h
  have he : L.birth = L.death := by omega
  exact hj (he ▸ hsingle he)

/-- The actual ghost step deletes at the unique death, then appends at
the unique birth. There is no singleton ghost-only lifespan. -/
theorem afterGhost_iff (j : ℕ) :
    L.afterGhost j ↔ (L.beforeGhost j ∧ ¬ L.ghostDies j) ∨ L.ghostBorn j := by
  unfold afterGhost beforeGhost ghostDies ghostBorn
  have hle := L.birth_le_death
  have hs := L.singleton_active
  constructor
  · intro ⟨hb,hd,ha⟩
    by_cases h : j = L.birth
    · exact Or.inr ⟨h,ha⟩
    · exact Or.inl ⟨⟨by omega,hd.le,ha⟩,by omega⟩
  · rintro (⟨⟨hb,hd,ha⟩,hn⟩ | ⟨rfl,ha⟩)
    · have hne : j ≠ L.death := fun he => hn ⟨he,ha⟩
      exact ⟨hb.le,by omega,ha⟩
    · refine ⟨le_rfl,?_,ha⟩
      by_contra h
      exact ha (hs (by omega))

/-- Between consecutive visits old pending particles are promoted before
the departing source-active prime is stored. The two possibilities cannot
refer to the same prime on the same edge. -/
theorem beforeGhost_succ_iff (j : ℕ) :
    L.beforeGhost (j+1) ↔
      (L.afterGhost j ∧ ¬ L.promoted j) ∨ L.stored j := by
  unfold beforeGhost afterGhost promoted stored
  have bounds := L.active_bounds
  constructor
  · intro ⟨hb,hd,ha⟩
    by_cases hj : j ∈ L.active
    · exact Or.inr ⟨hj,by omega,ha⟩
    · exact Or.inl ⟨⟨by omega,by omega,hj⟩,by tauto⟩
  · rintro (⟨⟨hb,hd,ha⟩,hn⟩ | ⟨hj,hd,ha⟩)
    · exact ⟨by omega,by omega,fun ht => hn ⟨ht,by omega,ha⟩⟩
    · exact ⟨by have := (bounds j hj).1; omega,by omega,ha⟩

theorem stored_not_promoted (j : ℕ) : ¬ (L.stored j ∧ L.promoted j) := by
  unfold stored promoted
  tauto

theorem promoted_was_pending {j : ℕ} (hj : L.promoted j) : L.afterGhost j := by
  rcases hj with ⟨ha,hb,hn⟩
  have hd := (L.active_bounds _ ha).2
  exact ⟨by omega,by omega,hn⟩

theorem beforeGhost_zero : ¬ L.beforeGhost 0 := by simp [beforeGhost]
theorem afterGhost_final : ¬ L.afterGhost N := by
  unfold afterGhost
  have hd := L.death_le
  omega

/-- Every active run begins either with the one actual fresh active birth
or with promotion from the pending particle. -/
theorem active_run_start_succ (j : ℕ) (ha : j+1 ∈ L.active) (hprev : j ∉ L.active) :
    L.freshActive (j+1) ∨ L.promoted j := by
  have hb := (L.active_bounds _ ha).1
  by_cases he : j+1 = L.birth
  · exact Or.inl ⟨he,ha⟩
  · exact Or.inr ⟨ha,by omega,hprev⟩

end PrimeLifespan

/-- The incoming/ghost/outgoing coefficients at a pending internal visit
equal its original damping, including a miss of the retained line. -/
theorem pending_hit_coefficient (ρ η : ℂ) (hρ : ρ ≠ 0) (hit : Prop) :
    (if hit then ρ else 1) *
      (if hit then (1-η)/ρ^2 else 1) * (if hit then ρ else 1) =
      if hit then 1-η else 1 := by
  by_cases h : hit
  · simp only [ite_eq_left h]
    field_simp
  · simp [h]

theorem ghost_birth_coefficient (ρ η V : ℂ) (hρ : ρ ≠ 0) :
    (-η*V/ρ)*ρ = -η*V := by field_simp

theorem ghost_death_coefficient (ρ η : ℂ) (hρ : ρ ≠ 0) :
    ρ*(-η/ρ) = -η := by field_simp

/-- All inactive visits split into the two exterior intervals and the
inactive part of the active hull. -/
theorem product_three_visit_regions {R : Type*} [CommRing R]
    (s : Finset ℕ) (a c : ℕ) (hac : a ≤ c) (f : ℕ → R) :
    (∏ j ∈ s, f j) =
      (∏ j ∈ s with j<a, f j) *
      (∏ j ∈ s with a≤j ∧ j≤c, f j) *
      (∏ j ∈ s with c<j, f j) := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih =>
      by_cases hleft : j<a
      · have hmid : ¬(a≤j ∧ j≤c) := by omega
        have hright : ¬c<j := by omega
        simp [Finset.prod_insert, Finset.filter_insert, hj,hleft,hmid,hright,ih]
        ring
      · by_cases hright : c<j
        · have hmid : ¬(a≤j ∧ j≤c) := by omega
          simp [Finset.prod_insert, Finset.filter_insert, hj,hleft,hmid,hright,ih]
          ring
        · have hmid : a≤j ∧ j≤c := by omega
          simp [Finset.prod_insert, Finset.filter_insert, hj,hleft,hmid,hright,ih]
          ring

abbrev LeftGhostChoice (s : Finset ℕ) (a : ℕ) := Option {j // j ∈ s ∧ j<a}
abbrev RightGhostChoice (s : Finset ℕ) (c : ℕ) := Option {j // j ∈ s ∧ c<j}

instance leftGhostChoiceFintype (s : Finset ℕ) (a : ℕ) : Fintype (LeftGhostChoice s a) := by
  letI : Fintype {j // j ∈ s ∧ j<a} :=
    Fintype.ofEquiv {j // j ∈ s.filter (·<a)} (Equiv.subtypeEquivRight (by simp))
  exact inferInstance

instance rightGhostChoiceFintype (s : Finset ℕ) (c : ℕ) : Fintype (RightGhostChoice s c) := by
  letI : Fintype {j // j ∈ s ∧ c<j} :=
    Fintype.ofEquiv {j // j ∈ s.filter (c<·)} (Equiv.subtypeEquivRight (by simp))
  exact inferInstance

def leftGhostWeight {R : Type*} [CommRing R] (s : Finset ℕ) (a : ℕ)
    (η : ℕ → R) : LeftGhostChoice s a → R
  | none => 1
  | some b => -η b.val * ∏ j ∈ s with b.val<j ∧ j<a, (1-η j)

def rightGhostWeight {R : Type*} [CommRing R] (s : Finset ℕ) (c : ℕ)
    (η : ℕ → R) : RightGhostChoice s c → R
  | none => 1
  | some d => -η d.val * ∏ j ∈ s with c<j ∧ j<d.val, (1-η j)

/-- Actual optional left endpoint choices reproduce the whole left damping. -/
theorem sum_leftGhostWeight {R : Type*} [CommRing R]
    (s : Finset ℕ) (a : ℕ) (η : ℕ → R) :
    (∑ b : LeftGhostChoice s a, leftGhostWeight s a η b) =
      ∏ j ∈ s with j<a, (1-η j) := by
  letI : Fintype {j // j ∈ s ∧ j<a} :=
    Fintype.ofEquiv {j // j ∈ s.filter (·<a)} (Equiv.subtypeEquivRight (by simp))
  rw [Fintype.sum_option]
  simp only [leftGhostWeight]
  have hs := Elliptic.PrimewiseMemory.product_left_extension (s.filter (·<a)) η
  simp only [Finset.filter_filter] at hs
  have heq : (∑ b : {j // j ∈ s ∧ j<a},
      -η b.val * ∏ j ∈ s with b.val<j ∧ j<a, (1-η j)) =
      ∑ b ∈ s with b<a, -η b * ∏ j ∈ s with b<j ∧ j<a, (1-η j) := by
    exact (Finset.sum_subtype (p:=fun j => j ∈ s ∧ j<a)
      (s.filter (·<a)) (by simp)
      (fun b => -η b * ∏ j ∈ s with b<j ∧ j<a, (1-η j))).symm
  rw [heq, hs]
  simp_rw [neg_mul, Finset.sum_neg_distrib, sub_eq_add_neg]
  congr 2
  apply Finset.sum_congr rfl
  intro b hb
  congr 2
  ext j
  simp only [Finset.mem_filter]
  tauto

/-- Actual optional right endpoint choices reproduce the whole right damping. -/
theorem sum_rightGhostWeight {R : Type*} [CommRing R]
    (s : Finset ℕ) (c : ℕ) (η : ℕ → R) :
    (∑ d : RightGhostChoice s c, rightGhostWeight s c η d) =
      ∏ j ∈ s with c<j, (1-η j) := by
  letI : Fintype {j // j ∈ s ∧ c<j} :=
    Fintype.ofEquiv {j // j ∈ s.filter (c<·)} (Equiv.subtypeEquivRight (by simp))
  rw [Fintype.sum_option]
  simp only [rightGhostWeight]
  have hs := Elliptic.PrimewiseMemory.product_right_extension (s.filter (c<·)) η
  simp only [Finset.filter_filter] at hs
  have heq : (∑ d : {j // j ∈ s ∧ c<j},
      -η d.val * ∏ j ∈ s with c<j ∧ j<d.val, (1-η j)) =
      ∑ d ∈ s with c<d, -η d * ∏ j ∈ s with c<j ∧ j<d, (1-η j) := by
    exact (Finset.sum_subtype (p:=fun j => j ∈ s ∧ c<j)
      (s.filter (c<·)) (by simp)
      (fun d => -η d * ∏ j ∈ s with c<j ∧ j<d, (1-η j))).symm
  rw [heq, hs]
  simp_rw [neg_mul, Finset.sum_neg_distrib]
  ring

/-- The finite sum over two actual optional endpoints gives all inactive
damping, retaining the actual middle visits exactly. -/
theorem active_exterior_lifespan_expansion {R : Type*} [CommRing R]
    (inactive : Finset ℕ) (a c : ℕ) (hac : a≤c) (η : ℕ → R) :
    (∏ j ∈ inactive, (1-η j)) =
      ∑ b : LeftGhostChoice inactive a, ∑ d : RightGhostChoice inactive c,
        leftGhostWeight inactive a η b *
          (∏ j ∈ inactive with a≤j ∧ j≤c, (1-η j)) *
          rightGhostWeight inactive c η d := by
  rw [product_three_visit_regions inactive a c hac,
    ← sum_leftGhostWeight, ← sum_rightGhostWeight]
  simp_rw [Finset.sum_mul, Finset.mul_sum]

/-- The actual line sum for a prime with an active visit, expanded into
its two optional ghost endpoints. Incompatible active lines give zero. -/
theorem line_sum_active_lifespan_expansion {R Line : Type*} [CommRing R]
    [Fintype Line] [DecidableEq Line]
    (visits active : Finset ℕ) (line : ℕ → Line) (η : ℕ → R)
    (a c : ℕ) (ha : a ∈ active) (hac : a≤c) :
    (∑ ℓ : Line, (∏ j ∈ active, if line j=ℓ then (1 : R) else 0) *
      ∏ j ∈ visits \ active, (1-Elliptic.PrimewiseMemory.hitWeight line η j ℓ)) =
    if ∀ j ∈ active, line j=line a then
      ∑ b : LeftGhostChoice (visits \ active) a,
      ∑ d : RightGhostChoice (visits \ active) c,
        leftGhostWeight (visits \ active) a
          (fun j => Elliptic.PrimewiseMemory.hitWeight line η j (line a)) b *
        (∏ j ∈ visits \ active with a≤j ∧ j≤c,
          (1-Elliptic.PrimewiseMemory.hitWeight line η j (line a))) *
        rightGhostWeight (visits \ active) c
          (fun j => Elliptic.PrimewiseMemory.hitWeight line η j (line a)) d
    else 0 := by
  rw [Elliptic.PrimewiseMemory.line_sum_with_active_visits active line a ha]
  split_ifs
  · exact active_exterior_lifespan_expansion (visits \ active) a c hac _
  · rfl

/-- Each actual pair of optional exterior endpoints produces the canonical
one-lifespan schedule containing every active visit. -/
def activeChoiceLifespan (N : ℕ) (visits active : Finset ℕ)
    (hvisits : ∀ j ∈ visits, j≤N) (hactive : active ⊆ visits)
    (a c : ℕ) (ha : a ∈ active) (hc : c ∈ active)
    (hull : ∀ j ∈ active, a≤j ∧ j≤c)
    (b : LeftGhostChoice (visits \ active) a)
    (d : RightGhostChoice (visits \ active) c) : PrimeLifespan N := by
  let first := b.elim a Subtype.val
  let last := d.elim c Subtype.val
  have hf : first≤a := by
    cases b with
    | none => exact le_rfl
    | some b => exact b.property.2.le
  have hl : c≤last := by
    cases d with
    | none => exact le_rfl
    | some d => exact d.property.2.le
  have hn : last≤N := by
    cases d with
    | none => exact hvisits c (hactive hc)
    | some d => exact hvisits d.val (Finset.mem_sdiff.mp d.property.1).1
  have hac : a≤c := (hull a ha).2
  refine {
    birth := first
    death := last
    birth_le_death := hf.trans (hac.trans hl)
    death_le := hn
    active := active
    active_bounds := fun j hj => ⟨hf.trans (hull j hj).1,(hull j hj).2.trans hl⟩
    singleton_active := ?_ }
  intro he
  have hefirst : first=a := by omega
  simpa only [hefirst] using ha

/-- The inactive-prime branch of the expansion creates a genuine pair of
distinct ghost endpoints; its singleton term belongs to the baseline. -/
def ghostOnlyLifespan (N b d : ℕ) (hbd : b<d) (hd : d≤N) : PrimeLifespan N where
  birth := b
  death := d
  birth_le_death := hbd.le
  death_le := hd
  active := ∅
  active_bounds := by simp
  singleton_active := by omega

end Elliptic.Operator
