module

public import Elliptic.Operator.PhysicalRootIndependentMoment
public import Elliptic.Operator.PhysicalVacuumNorm
public import Elliptic.Operator.UniformMemoryTruncation
public import Mathlib.Analysis.Real.Pi.Bounds

/-! The actual root-dependent independent boundary has a uniform small-cap tail. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootIndependentMoment
open scoped BigOperators
open MeasureTheory Filter OriginalLifespanSchedule OriginalPathWeights RootRecordEncoding
open PhysicalRootRecordEncoding PhysicalRootMomentNumeric RootRecordKernel RootRecordComparison
open RootIntegratedBonferroni RootGridMeasure IndependentLineNormalization CanonicalBoundaryAssembly
open IntegerRootReplacement
attribute [local instance] Classical.propDecidable
local instance physicalIndependentTailDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q B T : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem rootEndpoint_norm (u : BoundaryIndex (Fin K) ↥(integerPositionBox R) P J) :
    ‖rootEndpoint u‖≤1 := by unfold rootEndpoint; split_ifs <;> simp

theorem originalGeometry_norm (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (adjoint : ℕ→Bool)
    (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (hsmooth : ∀t,‖smooth t‖≤1) (hψ : ∀t,‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (q : RootGridMeasure.RootPoint) (j : ℕ) (z w : ↥(integerPositionBox R)) (a b : PhysicalActiveLists P J) :
    ‖originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q j z a w b‖≤1 :=
  RootLiteralGeometry.geometry_norm_le_one (adjoint j) value μ U V d₀ Y L hd
    exponents smooth ψ hsmooth hψ major hmajor σ z.val a w.val b q

/-- Every finite-cap actual boundary is integrable, by its exact finite
original-leaf expansion. No regularity premise on a memory operator remains. -/
theorem independentBoundary_integrable (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (hVM : ∀i,VM i≠0) (damping : ℕ→ℝ) (ρ : ℝ) (hρ : ρ≠0)
    (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (hd : 0<d₀)
    (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (hsmooth : ∀t,‖smooth t‖≤1) (hψ : ∀t,‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) :
    IntegrableOn (independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) value μ VM damping ρ
      adjoint U V d₀ Y L exponents smooth ψ major σ) rootBox := by
  unfold independentBoundary
  simp_rw [OriginalLeaf.boundaryPairing_eq_originalLeaf_coefficients
    (anchor:=fun z : ↥(integerPositionBox R)=>fun i p=>primeResidueAnchor (value i p) z.val) value
    (transformedMass value VM damping N) VM damping (fun j=>1-damping j) ρ _ hinj
    (fun j z c w d h i k=>originalGeometry_shared value μ adjoint U V d₀ Y L
      exponents smooth ψ major σ _ j z w c d h i k)
    (fun j z c w d h=>originalGeometry_crossEdgeBan value μ adjoint U V d₀ Y L
      exponents smooth ψ major σ _ j z w c d h)
    (fun i p=>VM i*transformedMass value VM damping N i p) hρ hVM (fun _ _=>rfl)]
  apply integrable_finsetSum
  intro e _
  unfold SourceHistoryCoefficient.primewiseCoefficient ScheduledPhysicalPath.geometricFactor
  simp only [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_range]
  apply Integrable.mul_const
  apply Integrable.const_mul
  apply Integrable.mul_const
  apply Integrable.const_mul
  apply RootArchimedeanTransfer.bounded_measurable_integrable
  · apply Finset.measurable_prod
    intro j _
    exact RootLiteralGeometry.geometry_measurable (adjoint j) value μ U V d₀ Y L
      exponents smooth ψ major σ _ _ _ _
  · intro q
    rw [norm_prod]
    exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _)
      (fun j _=>originalGeometry_norm value μ adjoint U V d₀ Y L hd exponents
        smooth ψ hsmooth hψ major hmajor σ q j _ _ _ _)

theorem rootEndpoint_initialNorm_le (ν : ∀i,P i→ℝ) (hν : ∀i p,0≤ν i p)
    {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] (hR : 1≤R) :
    initialBoundaryNorm (Line:=Line) (B:=B) ν (rootEndpoint (J:=J) (R:=R)) ≤
      ∏i,(∑p,ν i p)^(J+1) := by
  have hmem : (1,0)∈integerPositionBox R := by
    apply mem_integerPositionBox_of_abs
    · norm_num; exact_mod_cast hR
    · norm_num
  let z₀ : ↥(integerPositionBox R) := ⟨(1,0),hmem⟩
  have he : rootEndpoint (P:=P) (J:=J) (R:=R)=fun u=>if u.1=z₀ then (1:ℂ) else 0 := by
    funext u
    simp only [rootEndpoint,z₀,Subtype.ext_iff]
  rw [he]
  have hh := initialBoundaryNorm_position_le (J:=J) (B:=B) (Line:=Line) ν hν z₀ (fun _=>1) (fun _=>by simp)
  convert hh using 2
  funext u
  split_ifs <;> rfl

theorem transformedMass_nonneg_sum_le_two (value : ∀i,P i→ℕ)
    [∀i p,Fact (value i p).Prime] (VM : Fin K→ℝ) (hVM : ∀i,0<VM i)
    (hVMsum : ∀i,VM i=∑p,1/(value i p:ℝ)) (damping : ℕ→ℝ)
    (hdamping : ∀j<N+1,damping j≤1) (hsize : ∀i p,2*(N+1)≤value i p) :
    (∀i p,0≤transformedMass value VM damping N i p) ∧
      (∀i,(∑p,transformedMass value VM damping N i p)≤2) := by
  have hb i p := transformedPrimeMass_bounds (Finset.range (N+1)) damping (VM i) (value i p)
    (hVM i) (Nat.Prime.pos (Fact.out))
    (fun j hj=>hdamping j (Finset.mem_range.mp hj))
    (by simp only [Finset.card_range]; exact_mod_cast hsize i p)
  refine ⟨fun i p=>(hb i p).1,?_⟩
  intro i
  calc
    _ ≤ ∑p,(2/VM i)/(value i p:ℝ) := Finset.sum_le_sum (fun p _=>(hb i p).2)
    _ = (2/VM i)*∑p,1/(value i p:ℝ) := by simp only [div_eq_mul_inv,one_mul,Finset.mul_sum]
    _ = 2 := by rw [←hVMsum i]; field_simp [(hVM i).ne']

theorem momentPadding_le_length {L : ℝ} (hL : 1≤L) : momentPadding L≤momentLength L := by
  have h : (momentPadding L:ℝ)≤(momentLength L:ℝ) :=
    (Nat.floor_le (Real.rpow_nonneg (by linarith) _)).trans
      ((Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/100:ℝ)≤1/2)).trans (momentLength_lower L))
  exact_mod_cast h

/-- One threshold controls the actual boundary cap error uniformly in all
alphabets, root parameters and test functions. The literal transformed
prime masses and the entire initial endpoint mass are included. -/
theorem eventually_independentBoundary_cap_tail
    (K : ℕ) (C ρ Qgap vmin vmax A : ℝ)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hgap : Qgap<ρ^2) (hmin : 0<vmin) (hA : 0≤A) :
    ∀ᶠ L : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ value : (i : Fin K)→P i→ℕ, ∀ [∀i p,Fact (value i p).Prime],
      Function.Injective (fun s : Sigma P=>value s.1 s.2) →
      ∀ μ : (i : Fin K)→P i→ℝ, ∀ VM : Fin K→ℝ,
      (∀i,vmin≤VM i) → (∀i,VM i≤vmax) → (∀i,VM i=∑p,1/(value i p:ℝ)) →
      ∀ damping : ℕ→ℝ, (∀j,0≤damping j) → (∀j,damping j≤1) →
      (∀j,1-damping j≤Qgap) → (∀i p,2*(momentLength L+1)≤value i p) →
      ∀ B : ℕ, memoryCutoff L≤B → ∀ adjoint : ℕ→Bool, ∀ U V d₀ Y : ℝ, 0<d₀ →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀t,‖smooth t‖≤1) → (∀t,‖ψ t‖≤1) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ, ∀ q : RootGridMeasure.RootPoint,
      ‖independentBoundary (J:=momentPadding L) (N:=momentLength L) (R:=rootPositionRadius C L)
          (B:=B) value μ VM damping ρ adjoint U V d₀ Y L exponents smooth ψ major σ q -
        independentBoundary (J:=momentPadding L) (N:=momentLength L) (R:=rootPositionRadius C L)
          (B:=memoryCutoff L) value μ VM damping ρ adjoint U V d₀ Y L exponents smooth ψ major σ q‖ ≤
        L^(-A*(momentLength L:ℝ)) := by
  let v0 := ghostSchurWeight ρ Qgap (2*vmax)
  let row := (1+v0)*(2+vmin⁻¹/(v0*(1-ρ)))
  let ghost := (Real.exp (v0*max 1 (2*vmax)*2/ρ))^K
  have hv0 : 0<v0 := ghostSchurWeight_pos ρ Qgap (2*vmax) hρ hgap
  have hrow : 0≤row := by dsimp [row]; positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_truncation_with_position_box K ((2:ℝ)^K*ghost) (row^K) C A
      (pow_nonneg hrow _) hA] with L hL hcut
  intro P instP value instPr hinj μ VM hVM hVMmax hVMsum damping hd0 hd1 hq
    hsize B hB adjoint U V d₀ Y hd exponents smooth ψ hsmooth hψ major hmajor σ q
  have hVMpos : ∀i,0<VM i := fun i=>hmin.trans_le (hVM i)
  obtain ⟨hν,hs⟩ := transformedMass_nonneg_sum_le_two value VM hVMpos hVMsum damping (fun j _=>hd1 j) hsize
  let ν := transformedMass value VM damping (momentLength L)
  let edge := (Fintype.card ↥(integerPositionBox (rootPositionRadius C L)):ℝ)*
    ∏i,physicalEdgeLocalRowConstant (ν i) (VM i) ρ v0
  have hedge0 : 0≤edge := mul_nonneg (Nat.cast_nonneg _)
    (Finset.prod_nonneg fun i _=>physicalEdgeLocalRowConstant_nonneg
      (ν i) (VM i) ρ v0 (hν i) (hVMpos i).le hρ1 hv0)
  have hprod : (∏i,physicalEdgeLocalRowConstant (ν i) (VM i) ρ v0)≤row^K := by
    calc
      _ ≤ ∏_i : Fin K,row := Finset.prod_le_prod₀
        (fun i _=>physicalEdgeLocalRowConstant_nonneg (ν i) (VM i) ρ v0 (hν i) (hVMpos i).le hρ1 hv0)
        (fun i _=>physicalEdgeLocalRowConstant_le_uniform (ν i) (VM i) vmin ρ v0 2
          hmin (hVM i) hρ1 hv0 (hs i))
      _ = _ := by simp
  have hedge : edge≤row^K*((integerPositionBox (rootPositionRadius C L)).card:ℝ) := by
    dsimp [edge]
    rw [Fintype.card_coe,mul_comm]
    exact mul_le_mul_of_nonneg_right hprod (Nat.cast_nonneg _)
  have htail := boundary_cap_tail_explicit (J:=momentPadding L) (N:=momentLength L) (B:=B)
    (anchor:=fun z : ↥(integerPositionBox (rootPositionRadius C L))=>fun i p=>primeResidueAnchor (value i p) z.val)
    value ν (fun i p=>VM i*ν i p) VM damping (fun j=>1-damping j) ρ Qgap vmax 2 1
    (originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q) hinj
    (fun j z c w d h i k=>originalGeometry_shared value μ adjoint U V d₀ Y L exponents smooth ψ major σ q j z w c d h i k)
    (fun j z c w d h=>originalGeometry_crossEdgeBan value μ adjoint U V d₀ Y L exponents smooth ψ major σ q j z w c d h)
    hν hs (by norm_num) hρ hρ1 hgap (fun j=>sub_nonneg.mpr (hd1 j)) hq hd0 hd1
    (fun i=>(hVMpos i).le) (fun i=>(hVMpos i).ne') hVMmax (fun _ _=>rfl)
    (by norm_num) (fun j z a w b=>originalGeometry_norm value μ adjoint U V d₀ Y L hd
      exponents smooth ψ hsmooth hψ major hmajor σ q j z w a b)
    (memoryCutoff L) hB (by simpa using hcut.1) rootEndpoint rootEndpoint rootEndpoint_norm
  have hR : 1≤rootPositionRadius C L := by
    change 1≤⌈16+4096*(momentLength L:ℝ)*Real.exp (C*L^(21/100:ℝ))⌉₊
    apply Nat.one_le_ceil_iff.mpr
    positivity
  have hi := rootEndpoint_initialNorm_le (J:=momentPadding L) (B:=B)
    (Line:=fun i p=>Option (ZMod (value i p))) ν hν hR
  have hi' : initialBoundaryNorm (Line:=fun i p=>Option (ZMod (value i p))) (B:=B) ν
      (rootEndpoint (J:=momentPadding L) (R:=rootPositionRadius C L)) ≤
      ((2:ℝ)^K)^(momentLength L+1) := by
    apply hi.trans
    calc
      _ ≤ ∏_i : Fin K,(2:ℝ)^(momentLength L+1) := Finset.prod_le_prod₀
        (fun i _=>pow_nonneg (Finset.sum_nonneg fun p _=>hν i p) _)
        (fun i _=>(pow_le_pow_left₀ (Finset.sum_nonneg fun p _=>hν i p) (hs i) _).trans
          (pow_le_pow_right₀ (by norm_num) (Nat.add_le_add_right (momentPadding_le_length hL) 1)))
      _ = _ := by simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]; rw [←pow_mul,←pow_mul,Nat.mul_comm]
  have hc := hcut.2 (Real.exp (C*L^(21/100:ℝ))) ((2:ℝ)^K*ghost) edge
    (Real.exp_pos _).le le_rfl (by dsimp [ghost]; positivity) hedge0 le_rfl hedge
  dsimp only at htail
  simp only [Fintype.card_fin,mul_one] at htail
  change ‖_ - _‖≤_ at htail
  apply htail.trans
  calc
    _ ≤ ((2:ℝ)^K)^(momentLength L+1)*
        (((2:ℝ)^(memoryCutoff L-K*momentLength L))⁻¹*(ghost^(momentLength L+1)*edge^momentLength L)) := by
      exact mul_le_mul_of_nonneg_right hi' (by positivity)
    _ = ((2:ℝ)^(memoryCutoff L-K*momentLength L))⁻¹*
        (((2:ℝ)^K*ghost)^(momentLength L+1)*edge^momentLength L) := by rw [mul_pow]; ring
    _ ≤ _ := hc

theorem baselineProduct_abs_le_one (value : ∀i,P i→ℕ) (damping : ℕ→ℝ)
    (hdamping : ∀j<N+1,0≤damping j ∧ damping j≤1) (hsize : ∀i p,N<value i p) :
    |baselineProduct value damping N|≤1 := by
  unfold baselineProduct
  rw [Finset.abs_prod]
  apply Finset.prod_le_one₀ (fun _ _=>abs_nonneg _)
  intro i _
  rw [Finset.abs_prod]
  apply Finset.prod_le_one₀ (fun _ _=>abs_nonneg _)
  intro p _
  have hb := baseline_pos_le_one (Finset.range (N+1)) damping (value i p)
    (fun j hj=>hdamping j (Finset.mem_range.mp hj))
    (by simp only [Finset.card_range,Nat.cast_add,Nat.cast_one]; exact_mod_cast Nat.succ_lt_succ (hsize i p))
  rw [abs_of_pos hb.1]
  exact hb.2

/-- Integration of the actual cap difference, with the root density and
all endpoint and prime normalizations retained. -/
theorem integrated_closed_records_small_cap_error
    (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (hVM : ∀i,VM i≠0) (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (hUV : 0≤U*V) (hd : 0<d₀)
    (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (hsmooth : ∀t,‖smooth t‖≤1) (hψ : ∀t,‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) (damping : ℕ→ℝ)
    (hdamping : ∀j<N+1,0≤damping j ∧ damping j≤1) (hsize : ∀i p,N<value i p)
    (ρ : ℝ) (hρ : ρ≠0) (hN : 0<N) (hB : (∑i,Fintype.card (P i))≤B)
    (ε : ℝ) (hε : 0≤ε)
    (htail : ∀q,‖independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) value μ VM damping ρ
        adjoint U V d₀ Y L exponents smooth ψ major σ q-
      independentBoundary (J:=J) (N:=N) (R:=R) (B:=T) value μ VM damping ρ
        adjoint U V d₀ Y L exponents smooth ψ major σ q‖≤ε) :
    ‖(normalization VM J N:ℂ)*
        (∑rec∈closedRecords (J:=J) (N:=N) (R:=R) value hv,
          integralComplete rec (primePool value) damping U V
            (recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L exponents smooth ψ major σ)) -
      ((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping N:ℂ)*
        (∫q in rootBox,independentBoundary (J:=J) (N:=N) (R:=R) (B:=T) value μ VM damping ρ
          adjoint U V d₀ Y L exponents smooth ψ major σ q)‖ ≤ U*V*(15*ε) := by
  rw [integrated_closed_records_eq_boundary value hv hinj μ VM hVM adjoint U V d₀ Y L hd
    exponents smooth ψ hsmooth hψ major hmajor σ damping (fun j hj=>(hdamping j hj).2)
    hsize ρ hρ hN hB,←mul_sub]
  have hi (B : ℕ) := independentBoundary_integrable (J:=J) (N:=N) (R:=R) (B:=B)
    value hinj μ VM hVM damping ρ hρ adjoint U V d₀ Y L hd exponents smooth ψ hsmooth hψ major hmajor σ
  rw [←integral_sub (hi B) (hi T),norm_mul]
  have hz : 1≤Real.pi^2/6 := by nlinarith [Real.pi_gt_three]
  have hscale : ‖((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping N:ℂ)‖≤U*V := by
    rw [norm_mul,Complex.norm_real,Complex.norm_real,Real.norm_eq_abs,Real.norm_eq_abs,
      abs_of_nonneg (div_nonneg hUV (by linarith))]
    calc
      _ ≤ (U*V/(Real.pi^2/6))*1 := mul_le_mul_of_nonneg_left
        (baselineProduct_abs_le_one value damping hdamping hsize) (by positivity)
      _ ≤ _ := by rw [mul_one]; exact div_le_self hUV hz
  have hint := norm_setIntegral_le_of_norm_le_const
    (show volume rootBox<⊤ by rw [RootArchimedeanTransfer.rootBox_volume]; norm_num)
    (fun q _=>htail q)
  have hint' : ‖∫q in rootBox,
      independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) value μ VM damping ρ adjoint U V d₀ Y L exponents smooth ψ major σ q-
      independentBoundary (J:=J) (N:=N) (R:=R) (B:=T) value μ VM damping ρ adjoint U V d₀ Y L exponents smooth ψ major σ q‖≤15*ε := by
    simpa only [Measure.real,RootArchimedeanTransfer.rootBox_volume,ENNReal.toReal_ofNat,mul_comm] using hint
  exact mul_le_mul hscale hint' (norm_nonneg _) hUV

theorem const_mul_rpow_moment_le {L a c : ℝ} {N : ℕ}
    (hL : 1≤L) (hc : c≤L) (hN : 1≤N) :
    c*L^(-(a+1)*(N:ℝ))≤L^(-a*(N:ℝ)) := by
  have hLp : 0<L := by linarith
  have hLN : c≤L^(N:ℝ) := by
    rw [Real.rpow_natCast]
    exact hc.trans (by simpa using pow_le_pow_right₀ hL hN)
  calc
    _ ≤ L^(N:ℝ)*L^(-(a+1)*(N:ℝ)) := mul_le_mul_of_nonneg_right hLN (by positivity)
    _ = _ := by rw [←Real.rpow_add hLp]; congr 1; ring

end Elliptic.Operator.PhysicalRootIndependentMoment
