module

public import Elliptic.Operator.ActualHistoryBirths
public import Elliptic.Operator.BirthCyclePivots

/-! Numerical birth values determine their prime band. Consequently every
permutation preserving the actual performed births preserves the band of
each address, and every chronological repetition is within that band. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualHistoryBirths
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}

def addressGroup : Address I J B N → I
  | .inl a => a.1
  | .inr (.inl a) => a.2.1
  | .inr (.inr a) => a.2

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
variable (value : ∀ i, P i → ℕ)
variable (s : PhysicalMemoryState (Z:=Z) P Line J B)
variable (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)

theorem label_mem_band (a : Address I J B N) (v : ℕ)
    (ha : labels ν V η q ρ anchor geometry value N s h a = some v) :
    ∃ p : P (addressGroup a), value _ p = v := by
  rcases a with a | a
  · exact ⟨s.active P Line J B a.1 a.2, Option.some.inj ha⟩
  · rcases a with a | a
    · obtain ⟨p,_,hp⟩ := Option.map_eq_some_iff.mp ha
      exact ⟨p,hp⟩
    · obtain ⟨p,_,hp⟩ := Option.map_eq_some_iff.mp ha
      exact ⟨p,hp⟩

theorem same_value_group
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (a b : Address I J B N) (v : ℕ)
    (ha : labels ν V η q ρ anchor geometry value N s h a = some v)
    (hb : labels ν V η q ρ anchor geometry value N s h b = some v) :
    addressGroup a = addressGroup b := by
  obtain ⟨p,hp⟩ := label_mem_band ν V η q ρ anchor geometry value s h a v ha
  obtain ⟨r,hr⟩ := label_mem_band ν V η q ρ anchor geometry value s h b v hb
  exact congrArg Sigma.fst (hvalue (a₁ := ⟨addressGroup a,p⟩) (a₂ := ⟨addressGroup b,r⟩) (hp.trans hr.symm))

theorem birthPreserving_group
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (σ : Equiv.Perm (Address I J B N))
    (hp : BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ)
    (a : Address I J B N) : addressGroup (σ a) = addressGroup a := by
  cases he : labels ν V η q ρ anchor geometry value N s h a with
  | none => rw [hp.2 a he]
  | some v =>
      exact same_value_group ν V η q ρ anchor geometry value s h hvalue
        (σ a) a v ((hp.1 a).trans he) he

theorem cycle_same_group [LinearOrder (Address I J B N)]
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (σ : Equiv.Perm (Address I J B N))
    (hp : BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ)
    {a b : Address I J B N} (hab : σ.SameCycle a b) : addressGroup a=addressGroup b :=
  BirthCyclePivots.invariant_on_cycle σ addressGroup
    (birthPreserving_group ν V η q ρ anchor geometry value s h hvalue σ hp) hab

theorem pivot_same_group [LinearOrder (Address I J B N)]
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (σ : Equiv.Perm (Address I J B N))
    (hp : BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ)
    (a : Address I J B N) (ha : a∈BirthCyclePivots.nonpivots σ) :
    addressGroup (BirthCyclePivots.pivot σ a ha) = addressGroup a :=
  cycle_same_group ν V η q ρ anchor geometry value s h hvalue σ hp
    (BirthCyclePivots.pivot_sameCycle σ a ha)

end Elliptic.Operator.ActualHistoryBirths
