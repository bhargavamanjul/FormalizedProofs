module

public import Elliptic.Operator.PhysicalDirtyGoodFiber

/-!
# Phase-free counting of actual physical dirty fibers

The exceptional fresh draws retain their exact prime weights. Only
indexed old choices are counted crudely. For a fixed source permutation,
group-choice tuple and target permutation, the raw determinant and physical
box leave at most 33 actual targets.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance crudeDirtyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- A free indexed promotion has at most B choices, and a fixed mode has
one. The harmless B+1 bound also covers B=0. -/
theorem dirtyGroupChoices_card_le {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (store : Bool)
    (mode : Option (Fin m.size ⊕ P)) :
    (dirtyGroupChoices m store mode).card ≤ B+1 := by
  cases mode with
  | none =>
    exact (Finset.card_image_le.trans (by simpa using m.size_le)).trans (Nat.le_succ _)
  | some p => simp [dirtyGroupChoices]

/-- Every literal choice in a mode is bounded by that mode's summed
coefficient, using its own outgoing damping and Schur ratio. -/
theorem edgeWeightedChoice_le_dirtyGroupCoefficient {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (store : Bool)
    (mode : Option (Fin m.size ⊕ P)) (c : EdgeGroupChoice m)
    (hc : c ∈ dirtyGroupChoices m store mode)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m c ≤
      dirtyGroupCoefficient ν V ρ v0 m store mode := by
  apply le_trans _ (dirtyGroupChoices_sum_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime
    m store mode hν hV hρ0 hρ1 hv0)
  exact Finset.single_le_sum (fun d _ => edgeWeightedChoice_nonneg ν V ρ v0
    sourceAnchor targetAnchor sourcePrime m d hν hV hρ0 hv0.le) hc

namespace PhysicalDirtyCrude
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- All literal combinatorial data except the target position. -/
abbrev Key := (Fin K → Equiv.Perm (Fin (J+1))) ×
  (∀ i, EdgeGroupChoice (s.memory P (fun i p => Option (ZMod (value i p))) J B i)) ×
  (Fin K → Equiv.Perm (Fin (J+1)))

def key (c : PhysicalEdgeChoice s) : Key value s :=
  (c.sourcePerm,c.group,c.targetPerm)

/-- The physical raw determinant is fixed by the actual combinatorial key. -/
theorem determinant_eq_of_key_eq
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (c d : PhysicalEdgeChoice s)
    (hc : PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hd : PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ d)
    (hkey : key value s c = key value s d) :
    latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) (position c.target) =
    latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) (position d.target) := by
  have hs : c.sourcePerm = d.sourcePerm := congrArg Prod.fst hkey
  have hg : c.group = d.group := congrArg (fun k : Key value s => k.2.1) hkey
  have hsource : c.sourceLists = d.sourceLists := by
    funext i j
    simp only [PhysicalEdgeChoice.sourceLists, hs]
  have htarget : c.targetLists = d.targetLists := by
    funext i j
    simp only [PhysicalEdgeChoice.targetLists, hsource, hg]
  have hcdiv := Int.ediv_mul_cancel hc.2.1.2.2.2.2.2.2.2
  have hddiv := Int.ediv_mul_cancel hd.2.1.2.2.2.2.2.2.2
  rw [hc.2.2] at hcdiv
  rw [hd.2.2] at hddiv
  rw [hsource,htarget] at hcdiv
  exact hcdiv.symm.trans hddiv

/-- Fixed literal data leave at most 33 target positions, without phase
separation or any arithmetic bound on the number of fresh primes. -/
theorem fixed_key_card_le
    (hposition : Function.Injective position)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀ c ∈ S, PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hkey : ∀ c ∈ S, ∀ d ∈ S, key value s c = key value s d) : S.card ≤ 33 := by
  by_cases he : S = ∅
  · simp [he]
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hinj : Set.InjOn (fun c : PhysicalEdgeChoice s => position c.target) S := by
    intro c hc d hd h
    have hp : c.target = d.target := hposition h
    have hk := hkey c hc d hd
    exact Prod.ext hp hk
  rw [← Finset.card_image_of_injOn hinj]
  apply physical_targets_card_le hzw r
    (sourcePhysicalPositionAllowed_ratio_le u v r U W _ _ hU
      (hS c₀ hc₀).2.1.1 (hS c₀ hc₀).2.1.2.1).1
    (latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) (position c₀.target))
  intro z hz
  obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hz
  exact ⟨determinant_eq_of_key_eq value position s good u v r U W d₀ σ c c₀
    (hS c hc) (hS c₀ hc₀) (hkey c hc c₀ hc₀),
    (sourcePhysicalPositionAllowed_ratio_le u v r U W _ _ hU
      (hS c hc).2.1.1 (hS c hc).2.1.2.1).2⟩

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Actual mode data bound every choice's literal coefficient. Fresh
masses remain in the right-hand side. -/
theorem choiceWeight_le
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (c : PhysicalEdgeChoice s)
    (hmode : ∀ i, c.group i ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c ≤
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  apply Finset.prod_le_prod₀
  · intro i _
    exact edgeWeightedChoice_nonneg (ν i) (V i) ρ v0 _ _ _ _ _ (hν i) (hV i) hρ0 hv0.le
  · intro i _
    exact edgeWeightedChoice_le_dirtyGroupCoefficient (ν i) (V i) ρ v0 _ _ _ _ _ _ _
      (hmode i) (hν i) (hV i) hρ0 hρ1 hv0

/-- A crude actual physical row bound on any fixed store/fresh/free mode.
Both endpoint permutation sums are canceled by their exact averaging
factor. Only indexed old-particle choices are counted; no prime-count
factor is introduced. -/
theorem endpoint_averaged_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀ c ∈ S, PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hmode : ∀ c ∈ S, ∀ i, c.group i ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * (B+1 : ℝ)^K * ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  let modes := Fintype.piFinset (fun i => dirtyGroupChoices
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
  let keys : Finset (Key value s) := Finset.univ.product (modes.product Finset.univ)
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hC : 0 ≤ C := Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg
    (ν i) (V i) ρ v0 _ _ _ (hν i) (hV i) hρ1 hv0.le
  have hmap : ∀ c ∈ S, key value s c ∈ keys := by
    intro c hc
    apply Finset.mem_product.mpr
    refine ⟨Finset.mem_univ _, Finset.mem_product.mpr ⟨?_,Finset.mem_univ _⟩⟩
    exact Fintype.mem_piFinset.mpr (hmode c hc)
  have hf (k : Key value s) :
      (∑ c ∈ S.filter (fun c => key value s c = k),
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤ 33*C := by
    have hc : (S.filter (fun c => key value s c = k)).card ≤ 33 := by
      apply fixed_key_card_le value position s hposition good u v r U W d₀ σ hU w hzw
      · intro c hc
        exact hS c (Finset.mem_filter.mp hc).1
      · intro c hc d hd
        exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm
    calc
      _ ≤ ∑ _c ∈ S.filter (fun c => key value s c = k), C := by
        apply Finset.sum_le_sum
        intro c hc
        exact choiceWeight_le value position s ν V ρ v0 store mode c
          (hmode c (Finset.mem_filter.mp hc).1) hν hV hρ0 hρ1 hv0
      _ = (S.filter (fun c => key value s c = k)).card * C := by simp
      _ ≤ 33*C := mul_le_mul_of_nonneg_right (by exact_mod_cast hc) hC
  have hsum : (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      keys.card * (33*C) := by
    rw [← Finset.sum_fiberwise_of_maps_to hmap (PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0)]
    calc
      _ ≤ ∑ _k ∈ keys, 33*C := Finset.sum_le_sum fun k _ => hf k
      _ = _ := by simp
  have hm : modes.card ≤ (B+1)^K := by
    rw [Fintype.card_piFinset]
    calc
      _ ≤ ∏ _i : Fin K, (B+1) := by
        apply Finset.prod_le_prod
        intro i _
        exact dirtyGroupChoices_card_le _ _ _
      _ = _ := by simp
  let n : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin (J+1)))
  have hn : n ≠ 0 := by dsimp [n]; positivity
  have hk : (keys.card : ℝ) = n * ((modes.card : ℝ) * n) := by
    have h₁ := Finset.card_product
      (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))
      (modes.product (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1)))))
    change keys.card = _ at h₁
    have h₂ := Finset.card_product modes
      (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))
    change (modes.product (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))).card = _ at h₂
    rw [h₂, Finset.card_univ] at h₁
    dsimp only [n]
    exact_mod_cast h₁
  calc
    _ ≤ endpointPermutationWeight (Fin K) J * (keys.card * (33*C)) :=
      mul_le_mul_of_nonneg_left hsum (by unfold endpointPermutationWeight; positivity)
    _ = 33 * modes.card * C := by
      rw [hk]
      simp only [endpointPermutationWeight, n, Fintype.card_fun, Fintype.card_perm, Fintype.card_fin] at *
      field_simp
    _ ≤ 33 * (B+1 : ℝ)^K * C := by
      apply mul_le_mul_of_nonneg_right _ hC
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact_mod_cast hm

/-- Every canonical dirty fiber has a phase-free bound that preserves all
fresh-prime masses in the original outer coefficient. -/
theorem fiber_endpoint_averaged_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ PhysicalDirtyPartition.fiber value position s good u v r U W d₀ σ i k,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * (B+1 : ℝ)^K * PhysicalDirtyOuter.coefficient value s ν V ρ v0 i k := by
  apply endpoint_averaged_sum_le value position s hposition ν V ρ v0
    (DirtyOuterBudget.stores i k.2.1 k.2.2.1)
    (DirtyOuterBudget.modes (s.memory P (fun i p => Option (ZMod (value i p))) J B) i k.1 k.2.2.2)
    good u v r U W d₀ σ hU w hzw
  · intro c hc
    exact (Finset.mem_filter.mp hc).2.1
  · exact PhysicalDirtyPartition.fiber_mode_mem value position s good u v r U W d₀ σ i k
  · exact hν
  · exact hV
  · exact hρ0
  · exact hρ1
  · exact hv0

end PhysicalDirtyCrude
end Elliptic.Operator
