module

public import Elliptic.Operator.PhysicalDirtyWeighted
public import Elliptic.Operator.SourceSecondGoodState

/-!
# Dirty counts using only the actual dyadic product image

The phase separation test is restricted to products attained by the
literal physical choice set. No Cartesian enlargement of omission and
promotion supports occurs. This is the interface needed by the source's
second good-state test.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance restrictedDirtyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Restriction to an arbitrary actual coordinate set requires separation
only of its attained products. -/
theorem restrictedRawCoordinates_card_le {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β δ : ℝ)
    (C : Finset (RawDirtyCoordinate K M))
    (hC : C ⊆ rawChoiceCoordinates label newProducts p T σ h₀ β)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : 0 < p) (hσ : σ = 1 ∨ σ = -1)
    (hsep : PhaseSeparated (C.image (fun c => copiedProduct label c.1.1 * c.1.2))
      ((T : ℝ)*β) δ)
    (hwidth : 2*(16/(p : ℝ)) < δ) : C.card ≤ 33 := by
  have hpair {a b : RawDirtyCoordinate K M} (ha : a ∈ C) (hb : b ∈ C) : a.1 = b.1 := by
    have ha' := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β a).mp (hC ha)
    have hb' := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β b).mp (hC hb)
    have he := phase_separated_circle_unique hsep hwidth
      (Finset.mem_image_of_mem _ ha) (Finset.mem_image_of_mem _ hb) _
      (rawChoiceCoordinates_phase_window label newProducts p T σ h₀ β hp hσ (hC ha))
      (rawChoiceCoordinates_phase_window label newProducts p T σ h₀ β hp hσ (hC hb))
    have hf := old_new_factorization_unique
      (copiedProduct_dvd_fullSourceProduct label a.1.1)
      (copiedProduct_dvd_fullSourceProduct label b.1.1)
      (copiedProduct_ne_zero label hprime a.1.1)
      (hban a.1.2 ha'.1) (hban b.1.2 hb'.1) he
    exact Prod.ext (copiedProduct_injective label hprime hinj hf.1) hf.2
  by_cases hempty : C = ∅
  · simp [hempty]
  obtain ⟨a,ha⟩ := Finset.nonempty_iff_ne_empty.mpr hempty
  have hsub : C ⊆ ({a.1} : Finset ((Fin K → Fin M) × ℕ)).product
      (targetIntegers β (rawChoiceDeterminant label p T σ a.1)) := by
    intro b hb
    have he := hpair hb ha
    have hm := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β b).mp (hC hb)
    apply Finset.mem_product.mpr
    refine ⟨Finset.mem_singleton.mpr he, ?_⟩
    rw [mem_targetIntegers]
    simpa only [he] using hm.2.1
  have hc := Finset.card_le_card hsub
  have hcard := Finset.card_product ({a.1} : Finset ((Fin K → Fin M) × ℕ))
    (targetIntegers β (rawChoiceDeterminant label p T σ a.1))
  change (({a.1} : Finset ((Fin K → Fin M) × ℕ)).product
    (targetIntegers β (rawChoiceDeterminant label p T σ a.1))).card = _ at hcard
  rw [hcard, Finset.card_singleton, one_mul] at hc
  exact hc.trans (targetIntegers_card_le _ _)

namespace PhysicalDirtyRestricted
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- Numeric products attained by this exact physical choice set. -/
def productImage (S : Finset (PhysicalEdgeChoice s)) (i₀ : Fin K) : Finset ℕ :=
  S.image (fun c => copiedProduct (physicalSourceLabels value
    (s.active P (fun i p => Option (ZMod (value i p))) J B))
      (fun i => c.sourcePerm i (Fin.last J)) * c.otherPromotedProduct value i₀)

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Coordinate encoding preserves all distinct target data on every
restricted raw fiber, independently of endpoint permutation restrictions. -/
theorem targetDataImage_card_eq
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T) :
    (S.image (fun c => PhysicalDirtyCoordinates.targetData value position s c i₀)).card =
    (S.image (fun c => PhysicalDirtyCoordinates.coordinate value position s c i₀ w)).card := by
  let encode : (((Fin K → Fin (J+1)) × ℕ) × (ℤ × ℤ)) → RawDirtyCoordinate K (J+1) :=
    fun x => (x.1, latticeDet x.2 w)
  have hi : Set.InjOn encode
      (S.image (fun c => PhysicalDirtyCoordinates.targetData value position s c i₀)) := by
    intro x hx y hy he
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨d,hd,rfl⟩ := Finset.mem_image.mp hy
    have hc' := (Finset.mem_filter.mp (hS hc)).2
    have hd' := (Finset.mem_filter.mp (hS hd)).2
    exact PhysicalDirtyCoordinates.targetData_eq_of_coordinate_eq value position s
      good u v r U W d₀ σ c d hc'.1 hd'.1 i₀ a₀ hc'.2.1 hd'.2.1
      T hc'.2.2 hd'.2.2 w hzw he
  have hh := (Finset.card_image_of_injOn hi).symm
  rw [Finset.image_image] at hh
  exact hh

/-- The exact-image separation hypothesis suffices for the sharp 33 count.
All source distinctness, anchors, determinant congruence, coprimality and
tube bounds are derived from actual physical raw support. -/
theorem coordinateImage_card_le
    (hprime : ∀ i p, (value i p).Prime)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ) (S : Finset (PhysicalEdgeChoice s))
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hsep : PhaseSeparated (productImage value s S i₀)
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ) :
    (S.image (fun c => PhysicalDirtyCoordinates.coordinate value position s c i₀ w)).card ≤ 33 := by
  by_cases he : S = ∅
  · simp [he]
  obtain ⟨c₀,hc₀⟩ := Finset.nonempty_iff_ne_empty.mpr he
  have hc₀' := (Finset.mem_filter.mp (hS hc₀)).2
  let label := physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)
  let products := PhysicalDirtyCoordinates.rawOtherProducts value position s good u v r U W d₀ σ i₀ a₀ T
  let p := value i₀ ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1
  let z := position (s.position P (fun i p => Option (ZMod (value i p))) J B)
  let β := latticeTau r w / latticeTau r z
  let : Fact p.Prime := ⟨hprime i₀ _⟩
  have hi : Function.Injective label := physicalSourceLabels_original_injective value
    (s.active P (fun i p => Option (ZMod (value i p))) J B) c₀.targetLists c₀.sourcePerm
    hc₀'.1.2.1.2.2.2.2.1
  have hban : ∀ ij, label ij ≠ p := by
    intro ij
    have hh := c₀.original_source_ne_target value hc₀'.1.2.1.2.2.2.2.1 ij i₀
    simpa only [edgeTargetPrime,hc₀'.2.1] using hh
  have hcoprime : ∀ n ∈ products, (fullSourceProduct label).Coprime n := by
    intro n hn
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hn
    exact c.fullSourceProduct_coprime_otherPromotedProduct value hprime
      (Finset.mem_filter.mp hc).2.1.2.1.2.2.2.2.1 i₀
  have hsub : S.image (fun c => PhysicalDirtyCoordinates.coordinate value position s c i₀ w) ⊆
      anchoredRawChoiceCoordinates label products p T σ β z w
        ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).2 := by
    intro x hx
    obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hx
    have hc' := (Finset.mem_filter.mp (hS hc)).2
    have hh := PhysicalDirtyCoordinates.coordinate_mem_anchored value position s c i₀ a₀
      hc'.2.1 hc'.1.1 good u v r U W d₀ σ hU hc'.1.2.1 hc'.1.2.2 w hzw products
      (Finset.mem_image.mpr ⟨c,hS hc,rfl⟩)
    simpa only [hc'.2.2] using hh
  apply restrictedRawCoordinates_card_le label products p T σ
    (anchoredRawReference label products p T σ β z w
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).2) β δ
    _ (hsub.trans (anchoredRawChoiceCoordinates_subset_raw label products p T σ β hzw _
      (fun ij => hprime ij.1 _) hban hσ)) (fun ij => hprime ij.1 _) hi hcoprime
    (Fact.out : p.Prime).pos hσ ?_ hwidth
  simpa only [Finset.image_image, PhysicalDirtyCoordinates.coordinate, productImage, label, Function.comp_def, β, z] using hsep

/-- At most 33 target data triples occur in a restricted raw fiber. -/
theorem targetDataImage_card_le
    (hprime : ∀ i p, (value i p).Prime)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ℝ) (S : Finset (PhysicalEdgeChoice s))
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hsep : PhaseSeparated (productImage value s S i₀)
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ) :
    (S.image (fun c => PhysicalDirtyCoordinates.targetData value position s c i₀)).card ≤ 33 := by
  rw [targetDataImage_card_eq value position s good u v r U W d₀ σ i₀ a₀ T w hzw S hS]
  exact coordinateImage_card_le value position s hprime good u v r U W d₀ σ hU hσ
    i₀ a₀ T w hzw δ S hS hsep hwidth

open PhysicalDirtyWeighted

/-- Actual indexed coefficients on a restricted raw fiber. The only
phase test is on products attained by this fiber. -/
theorem weighted_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s)) (δ : ℝ)
    (hsep : PhaseSeparated (productImage value s S i₀)
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ)
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hret : ∀ c ∈ S, ∀ d ∈ S,
      (groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2 =
        (groupLastSlotPermutationEquiv (Fin K) J d.sourcePerm).2)
    (htarget : ∀ c ∈ S, ∀ d ∈ S, c.targetPerm = d.targetPerm)
    (hmode : ∀ c ∈ S, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      33 * ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  let data := fun c => PhysicalDirtyCoordinates.targetData value position s c i₀
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hC : 0 ≤ C := Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg
    (ν i) (V i) ρ v0 _ _ _ (hν i) (hV i) hρ1 hv0.le
  have hcard : (S.image data).card ≤ 33 :=
    targetDataImage_card_le value position s hprime good u v r U W d₀ σ hU hσ
      i₀ a₀ T w hzw δ S hS hsep hwidth
  have hf (x) : (∑ c ∈ S.filter (fun c => data c = x),
      choiceWeight value position s ν V ρ v0 c) ≤ C := by
    apply targetData_fiber_sum_le value position s hposition ν V ρ v0 store mode i₀
    · intro c hc d hd
      exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm
    · intro c hc d hd
      exact hret c (Finset.mem_filter.mp hc).1 d (Finset.mem_filter.mp hd).1
    · intro c hc d hd
      exact htarget c (Finset.mem_filter.mp hc).1 d (Finset.mem_filter.mp hd).1
    · intro c hc
      exact hmode c (Finset.mem_filter.mp hc).1
    · exact hν
    · exact hV
    · exact hρ0
    · exact hρ1
    · exact hv0
  calc
    _ = ∑ x ∈ S.image data, ∑ c ∈ S.filter (fun c => data c = x),
        choiceWeight value position s ν V ρ v0 c :=
      (Finset.sum_fiberwise_of_maps_to (fun c hc => Finset.mem_image_of_mem data hc) _).symm
    _ ≤ ∑ _x ∈ S.image data, C := Finset.sum_le_sum fun x _ => hf x
    _ = (S.image data).card * C := by simp
    _ ≤ 33 * C := mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) hC

/-- Both literal endpoint permutation factors are now summed. The
target-permutation count cancels one endpoint average; the retained
source count leaves exactly the omission factor `(J+1)^(-K)`.
Stores, branch modes, distinguished old index, and fresh product remain
fixed; all other indexed promotion multiplicities have been summed. -/
theorem endpoint_averaged_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K)
    (a₀ : Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size)
    (T : ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s)) (δ : ℝ)
    (hsep : PhaseSeparated (productImage value s S i₀)
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ)
    (hwidth : 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values a₀).1 : ℝ)) < δ)
    (hS : S ⊆ PhysicalDirtyCoordinates.rawChoices value position s good u v r U W d₀ σ i₀ a₀ T)
    (hmode : ∀ c ∈ S, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      (33 * ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)) /
          (J+1 : ℝ)^K := by
  let Key := (Fin K → Equiv.Perm (Fin J)) × (Fin K → Equiv.Perm (Fin (J+1)))
  let key : PhysicalEdgeChoice s → Key := fun c =>
    ((groupLastSlotPermutationEquiv (Fin K) J c.sourcePerm).2,c.targetPerm)
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hsep_sub (k : Key) : PhaseSeparated
      (productImage value s (S.filter (fun c => key c = k)) i₀)
      ((T : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) δ :=
    SourceSecondGoodState.phaseSeparated_mono (Finset.image_subset_image (Finset.filter_subset _ _)) hsep
  have hf (k : Key) : (∑ c ∈ S.filter (fun c => key c = k),
      choiceWeight value position s ν V ρ v0 c) ≤ 33*C := by
    apply weighted_sum_le value position s hposition hprime ν V ρ v0 store mode
      good u v r U W d₀ σ hU hσ i₀ a₀ T w hzw _ δ (hsep_sub k) hwidth
    · exact fun c hc => hS (Finset.mem_filter.mp hc).1
    · intro c hc d hd
      exact congrArg (fun x : Key => x.1)
        ((Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm)
    · intro c hc d hd
      exact congrArg (fun x : Key => x.2)
        ((Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm)
    · intro c hc
      exact hmode c (Finset.mem_filter.mp hc).1
    · exact hν
    · exact hV
    · exact hρ0
    · exact hρ1
    · exact hv0
  have hsum : (∑ c ∈ S, choiceWeight value position s ν V ρ v0 c) ≤
      ∑ _k : Key, 33*C := by
    rw [← Finset.sum_fiberwise_of_maps_to (fun c (_hc : c ∈ S) => Finset.mem_univ (key c))
      (choiceWeight value position s ν V ρ v0)]
    exact Finset.sum_le_sum fun k _ => hf k
  let n : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin (J+1)))
  let m : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin J))
  have hn : n = (J+1 : ℝ)^K * m := by
    simp only [n,m,Fintype.card_fun,Fintype.card_perm,Fintype.card_fin,Nat.factorial_succ,
      Nat.cast_pow,Nat.cast_mul,Nat.cast_add,Nat.cast_one,mul_pow]
  have hm : m ≠ 0 := by dsimp [m]; positivity
  have hj : (J+1 : ℝ)^K ≠ 0 := by positivity
  have hk : (Fintype.card Key : ℝ) = m*n := by
    simp only [Key,Fintype.card_prod,Nat.cast_mul,m,n]
  calc
    _ ≤ endpointPermutationWeight (Fin K) J * (∑ _k : Key, 33*C) :=
      mul_le_mul_of_nonneg_left hsum (by unfold endpointPermutationWeight; positivity)
    _ = n⁻¹^2 * ((m*n)*(33*C)) := by
      rw [Finset.sum_const,nsmul_eq_mul,Finset.card_univ,hk]
      simp only [endpointPermutationWeight,n,Fintype.card_fun,Fintype.card_perm,Fintype.card_fin]
    _ = 33*C/(J+1 : ℝ)^K := by
      rw [hn]
      field_simp

end PhysicalDirtyRestricted
end Elliptic.Operator
