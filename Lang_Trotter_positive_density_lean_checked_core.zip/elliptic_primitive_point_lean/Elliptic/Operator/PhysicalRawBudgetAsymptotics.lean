module

public import Elliptic.Operator.PhysicalMaskBudgetBounds
public import Elliptic.Operator.DirtyRowAsymptotics

/-! The actual sum of raw dirty mask norms has arbitrary logarithmic
saving. K is chosen before all coefficient bounds and before every band
exponent, and one threshold covers all bounded coefficient arrays V(L). -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRawBudgetAsymptotics
open Filter PhysicalMaskBudgetBounds

 theorem exists_group_count_for_actual_raw_saving (G : ℝ) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀ρ v0 vmin vmax M A : ℝ,ρ<1→0<v0→0<vmin→0≤M→0≤A→
      ∀ᶠL : ℝ in atTop,∀a : Fin K→ℝ,(∀i,(1/10:ℝ)≤a i)→
        ∀V : Fin K→ℝ,(∀i,vmin≤V i)→(∀i,V i≤vmax)→
        PhysicalDirtyRawSchur.allMaskBudget K (momentPadding L) (memoryCutoff L)
          V ρ v0 vmin M L A a≤L^(-G) := by
  obtain ⟨K₀,hK₀,hschur⟩ := DirtyRowAsymptotics.exists_group_count_for_schur_saving G
  obtain ⟨K₁,hK₁,hrow⟩ := DirtyRowAsymptotics.exists_group_count_for_row_saving 0
  refine ⟨max K₀ K₁,hK₀.trans (le_max_left _ _),?_⟩
  intro K hK ρ v0 vmin vmax M A hρ hv0 hmin hM hA
  have hK0 : K₀≤K := (le_max_left _ _).trans hK
  have hK1 : K₁≤K := (le_max_right _ _).trans hK
  have hQ : 0≤reverseBound K vmin vmax := by unfold reverseBound;positivity
  have hT : 0≤(4:ℝ)^K*A := by positivity
  have hC : 0≤reverseBound K vmin vmax*(33*((1+v0)*M)^K+1) := by positivity
  filter_upwards [hschur K hK0 ρ v0 vmin M ((4:ℝ)^K*A)
    (reverseBound K vmin vmax*(33*((1+v0)*M)^K+1)) hρ hv0 hmin hM hT hC,
    hrow K hK1 ρ v0 vmin M hρ hv0 hmin hM] with L hs hr
  intro a ha V hlo hhi
  have he : rawSaving K (momentPadding L) (memoryCutoff L) ρ v0 vmin M L a≤1 := by
    simpa only [rawSaving,neg_zero,Real.rpow_zero] using hr a ha
  exact (raw_allMaskBudget_le K (momentPadding L) (memoryCutoff L) V ρ v0 vmin vmax M L A a
    hρ hv0 hmin hM hA hlo hhi he).trans (hs a ha)

end Elliptic.Operator.PhysicalRawBudgetAsymptotics
