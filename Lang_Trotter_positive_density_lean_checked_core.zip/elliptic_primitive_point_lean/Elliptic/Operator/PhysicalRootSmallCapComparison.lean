module

public import Elliptic.Operator.PhysicalRootIndependentTail
public import Elliptic.Operator.PhysicalRootMomentComparison

/-! Full physical closed moment replacement by the literal small-cap
independent boundary integral, with proved logarithmic errors. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootIndependentMoment
open scoped BigOperators
open MeasureTheory Filter OriginalLifespanSchedule OriginalPathWeights RootRecordEncoding
open PhysicalRootRecordEncoding PhysicalRootMomentNumeric RootRecordKernel RootRecordComparison
open RootIntegratedBonferroni RootGridMeasure IndependentLineNormalization CanonicalBoundaryAssembly
open IntegerRootReplacement SourceRootCount PhysicalRootMomentComparison
attribute [local instance] Classical.propDecidable
local instance physicalSmallCapDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

/-- The actual image pool reciprocal mass is controlled by the literal
harmonic group masses, so the root comparison needs no ambient pool budget. -/
theorem primePool_mass_le (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (VM : Fin K→ℝ)
    (hVMsum : ∀i,VM i=∑p,1/(value i p:ℝ)) (vmax : ℝ) (hVMmax : ∀i,VM i≤vmax) :
    (∑p∈primePool value,1/((p:ℝ)+1))≤(K:ℝ)*max 0 vmax := by
  dsimp only [primePool]
  rw [←Finset.sum_coe_sort,←Equiv.sum_comp (OriginalIndependentCRT.primePoolEquiv value hinj)]
  simp only [OriginalIndependentCRT.primePoolEquiv_val]
  rw [Fintype.sum_sigma]
  calc
    _ ≤ ∑i,VM i := by
      apply Finset.sum_le_sum
      intro i _
      rw [hVMsum i]
      apply Finset.sum_le_sum
      intro p _
      have hp : (0:ℝ)<value i p := by exact_mod_cast Nat.Prime.pos (Fact.out : (value i p).Prime)
      exact one_div_le_one_div_of_le hp (by linarith)
    _ ≤ ∑_i : Fin K,max 0 vmax := Finset.sum_le_sum (fun i _=>(hVMmax i).trans (le_max_right _ _))
    _ = _ := by simp

/-- The physical support radius follows directly from the determinant
height; no position-cardinality estimate is supplied by the caller. -/
theorem radius_of_height (C L d₀ Y Cψ : ℝ)
    (hheight : 2*d₀*Y*Cψ≤Real.exp (C*L^(21/100:ℝ))) :
    ⌈16+4096*(momentLength L:ℝ)*(2*d₀*Y*Cψ)⌉₊≤rootPositionRadius C L := by
  apply Nat.ceil_mono
  gcongr

/-- Complete original physical-to-small-memory replacement. The error
includes the signed root comparison and the actual large-to-small cap tail.
All finite prime-pool, geometric, integral and endpoint-mass costs are proved. -/
theorem eventually_physical_moment_small_cap
    (hPD : RootCountContract) (K : ℕ) (hK : 1≤K)
    (C δ ρ Qgap vmin vmax A : ℝ) (hC : 0≤C) (hδ : 0<δ)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hgap : Qgap<ρ^2) (hmin : 0<vmin) (hA : 0≤A) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ value : (i : Fin K)→P i→ℕ, ∀ [∀i p,Fact (value i p).Prime],
      Function.Injective (fun s : Sigma P=>value s.1 s.2) →
      (∀i p,(value i p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      (∀i p,2*(momentLength (Real.log x)+1)≤value i p) →
      ∀ μ : (i : Fin K)→P i→ℝ, ∀ VM : Fin K→ℝ,
      (∀i,vmin≤VM i) → (∀i,VM i≤vmax) → (∀i,VM i=∑p,1/(value i p:ℝ)) →
      ∀ damping : ℕ→ℝ, (∀j,0≤damping j) → (∀j,damping j≤1) → (∀j,1-damping j≤Qgap) →
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V → 0<d₀ → 1≤Y →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀t,‖smooth t‖≤1) → (∀t,‖ψ t‖≤1) → (∀t,smooth t≠0→1/2≤t) →
      ∀ Cψ : ℝ, 0≤Cψ → (∀t,ψ t≠0→|t|≤Cψ) →
      2*d₀*Y*Cψ≤Real.exp (C*(Real.log x)^(21/100:ℝ)) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ, ∀ adjoint : ℕ→Bool,
      ‖physicalMoment (J:=momentPadding (Real.log x)) (N:=momentLength (Real.log x))
          value μ VM d₀ Y (Real.log x) U V exponents smooth ψ major σ adjoint (primePool value) damping -
        ((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping (momentLength (Real.log x)):ℂ)*
          (∫q in rootBox,independentBoundary (J:=momentPadding (Real.log x))
            (N:=momentLength (Real.log x)) (R:=rootPositionRadius C (Real.log x))
            (B:=memoryCutoff (Real.log x)) value μ VM damping ρ adjoint U V d₀ Y (Real.log x)
              exponents smooth ψ major σ q)‖ ≤
        U*V*(Real.log x)^(-A*(momentLength (Real.log x):ℝ)) := by
  filter_upwards [eventually_physical_moment_comparison hPD K hK C δ vmin ((K:ℝ)*max 0 vmax) (A+1)
    hC hδ hmin (by positivity) (by linarith),
    Real.tendsto_log_atTop.eventually (eventually_independentBoundary_cap_tail K C ρ Qgap vmin vmax (A+2)
      hρ hρ1 hgap hmin (by linarith)),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (15:ℝ))] with x hcomp htail hL
  intro P instP value instPr hinj hupper hsize μ VM hVM hVMmax hVMsum damping hd0 hd1 hq
    U V d₀ Y hU hU' hV hV' hUV hd hY exponents smooth ψ hsmooth hψ hsupport
    Cψ hCψ hsuppψ hheight major hmajor σ adjoint
  let L := Real.log x
  let B := max (memoryCutoff L) (∑i,Fintype.card (P i))
  let hv := fun i p=>label_lt_rootPrimeCeiling L (value i p) (hupper i p)
  have hi : ∀i,Function.Injective (value i) := fun i a b h=>by
    exact eq_of_heq (Sigma.mk.inj_iff.mp (hinj (a₁:=⟨i,a⟩) (a₂:=⟨i,b⟩) h)).2
  have hpool : ∀i p,value i p∈primePool value := fun i p=>Finset.mem_image.mpr ⟨⟨i,p⟩,Finset.mem_univ _,rfl⟩
  have hpupper : ∀p∈primePool value,(p:ℝ)≤Real.exp (2*L^(1/5:ℝ)) := by
    intro p hp
    obtain ⟨s,_,rfl⟩ := Finset.mem_image.mp hp
    exact hupper s.1 s.2
  have hc := @hcomp P instP (primePool value) inferInstance hpupper
    (primePool_mass_le value hinj VM hVMsum vmax hVMmax) value hv hi hpool μ damping
    (fun j _=>⟨hd0 j,hd1 j⟩) U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM exponents smooth ψ
    hsmooth hψ hsupport Cψ hCψ hsuppψ (radius_of_height C L d₀ Y Cψ hheight) major hmajor σ adjoint
  have ht := integrated_closed_records_small_cap_error (J:=momentPadding L) (N:=momentLength L)
    (R:=rootPositionRadius C L) (B:=B) (T:=memoryCutoff L) value hv hinj μ VM
    (fun i=>(hmin.trans_le (hVM i)).ne') adjoint U V d₀ Y L (by linarith) hd exponents smooth ψ
    hsmooth hψ major hmajor σ damping (fun j _=>⟨hd0 j,hd1 j⟩)
    (fun i p=>by change momentLength (Real.log x)<value i p; have hh:=hsize i p; omega) ρ hρ.ne' (momentLength_pos (by change 0 < Real.log x; linarith))
    (le_max_right _ _) (L^(-(A+2)*(momentLength L:ℝ))) (by positivity)
    (fun q=>@htail P instP value instPr hinj μ VM hVM hVMmax hVMsum damping hd0 hd1 hq
      hsize B (le_max_left _ _) adjoint U V d₀ Y hd exponents smooth ψ hsmooth hψ major hmajor σ q)
  have ht' : ‖(normalization VM (momentPadding L) (momentLength L):ℂ)*
      (∑rec∈closedRecords (J:=momentPadding L) (N:=momentLength L) (R:=rootPositionRadius C L) value hv,
        integralComplete rec (primePool value) damping U V
          (recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L exponents smooth ψ major σ)) -
      ((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping (momentLength L):ℂ)*
        (∫q in rootBox,independentBoundary (J:=momentPadding L) (N:=momentLength L)
          (R:=rootPositionRadius C L) (B:=memoryCutoff L) value μ VM damping ρ adjoint U V d₀ Y L
            exponents smooth ψ major σ q)‖≤U*V*L^(-(A+1)*(momentLength L:ℝ)) := by
    apply ht.trans
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    simpa only [show A+1+1=A+2 by ring] using
      const_mul_rpow_moment_le (a:=A+1) (L:=L) (by change 1 ≤ Real.log x; linarith) hL
        (momentLength_pos (by change 0 < Real.log x; linarith))
  apply (norm_sub_le_norm_sub_add_norm_sub _ _ _).trans ((add_le_add hc ht').trans _)
  calc
    _ = U*V*(2*L^(-(A+1)*(momentLength L:ℝ))) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (const_mul_rpow_moment_le (by change _ ≤ Real.log x; linarith) (by change _ ≤ Real.log x; linarith)
        (momentLength_pos (by change 0 < Real.log x; linarith))) (by linarith)

/-- The fixed exponent needed for a compactly supported determinant test
when the actual source product scale is bounded by exp(D L^.2). -/
def sourceRadiusExponent (D Cψ : ℝ) : ℝ := D+Real.log (max 1 (2*Cψ))

theorem sourceRadiusExponent_nonneg (D Cψ : ℝ) (hD : 0≤D) :
    0≤sourceRadiusExponent D Cψ :=
  add_nonneg hD (Real.log_nonneg (le_max_left _ _))

theorem height_of_product_bound (D Cψ L d₀ Y : ℝ) (hD : 0≤D) (hCψ : 0≤Cψ)
    (hL : 1≤L) (hd : 0≤d₀) (hY : 0≤Y)
    (hprod : d₀*Y≤Real.exp (D*L^(1/5:ℝ))) :
    2*d₀*Y*Cψ≤Real.exp (sourceRadiusExponent D Cψ*L^(21/100:ℝ)) := by
  have hm : 0<max 1 (2*Cψ) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hlog : 0≤Real.log (max 1 (2*Cψ)) := Real.log_nonneg (le_max_left _ _)
  have hp : L^(1/5:ℝ)≤L^(21/100:ℝ) := Real.rpow_le_rpow_of_exponent_le hL (by norm_num)
  have hone : 1≤L^(21/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  calc
    _ = (2*Cψ)*(d₀*Y) := by ring
    _ ≤ max 1 (2*Cψ)*Real.exp (D*L^(1/5:ℝ)) :=
      mul_le_mul (le_max_right _ _) hprod (mul_nonneg hd hY) hm.le
    _ = Real.exp (Real.log (max 1 (2*Cψ))+D*L^(1/5:ℝ)) := by rw [Real.exp_add,Real.exp_log hm]
    _ ≤ _ := Real.exp_le_exp.mpr (by
      unfold sourceRadiusExponent
      nlinarith [mul_le_mul_of_nonneg_left hp hD,mul_le_mul_of_nonneg_left hone hlog])

theorem radius_of_product_bound (D Cψ L d₀ Y : ℝ) (hD : 0≤D) (hCψ : 0≤Cψ)
    (hL : 1≤L) (hd : 0≤d₀) (hY : 0≤Y)
    (hprod : d₀*Y≤Real.exp (D*L^(1/5:ℝ))) :
    ⌈16+4096*(momentLength L:ℝ)*(2*d₀*Y*Cψ)⌉₊≤
      rootPositionRadius (sourceRadiusExponent D Cψ) L :=
  radius_of_height _ _ _ _ _ (height_of_product_bound D Cψ L d₀ Y hD hCψ hL hd hY hprod)

end Elliptic.Operator.PhysicalRootIndependentMoment
