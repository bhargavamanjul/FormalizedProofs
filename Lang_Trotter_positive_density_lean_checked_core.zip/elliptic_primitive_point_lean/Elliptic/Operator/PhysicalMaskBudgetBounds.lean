module

public import Elliptic.Operator.PhysicalDirtyRawSchur
public import Elliptic.Operator.PhysicalDirtyComparisonSchur

/-! Fixed-mask losses are uniform over varying coefficients in a fixed
positive interval. All growth in the comparison row is explicitly polynomial
in the memory cutoff; the raw row keeps its actual omission saving. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskBudgetBounds
open scoped BigOperators
open PhysicalDirtyMasks PhysicalMaskScaling PhysicalRawGlobalRow
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 def reverseBound (K : ℕ) (vmin vmax : ℝ) : ℝ := (max 1 (max vmax vmin⁻¹))^K

 theorem reverseFactor_le {K : ℕ} (V : Fin K→ℝ) (S I : Fin K→Bool)
    (vmin vmax : ℝ) (hmin : 0<vmin) (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax) :
    reverseFactor V S I≤reverseBound K vmin vmax := by
  have hq1 : 1≤max 1 (max vmax vmin⁻¹) := le_max_left _ _
  have hqv : vmax≤max 1 (max vmax vmin⁻¹) := (le_max_left _ _).trans (le_max_right _ _)
  have hqi : vmin⁻¹≤max 1 (max vmax vmin⁻¹) := (le_max_right _ _).trans (le_max_right _ _)
  unfold reverseFactor reverseBound
  calc
    _ ≤ ∏_i : Fin K,max 1 (max vmax vmin⁻¹) := by
      apply Finset.prod_le_prod₀
      · intro i _
        have hi : 0<V i := hmin.trans_le (hlo i)
        positivity
      · intro i _
        have hi : V i≠0 := (hmin.trans_le (hlo i)).ne'
        have hv := (hhi i).trans hqv
        have hinv0 : (V i)⁻¹≤vmin⁻¹ := by
          simpa only [one_div] using one_div_le_one_div_of_le hmin (hlo i)
        have hinv := hinv0.trans hqi
        cases hs : S i <;> cases ht : I i <;>
          simp only [hs,ht,Bool.toNat_false,Bool.toNat_true,pow_zero,pow_one,div_one,one_div,div_self hi] <;> assumption
    _ = _ := by simp

 theorem mask_sqrt_sum_le {K : ℕ} (cost : Mask (G:=Fin K)→ℝ) (T : ℝ)
    (hT : 0≤T) (hcost0 : ∀m∈dirtyMasks,0≤cost m) (hcost : ∀m∈dirtyMasks,cost m≤T) :
    Real.sqrt (((dirtyMasks (G:=Fin K)).card:ℝ)*∑m∈dirtyMasks,(Real.sqrt (cost m))^2)≤
      (4:ℝ)^K*Real.sqrt T := by
  let n : ℝ := (dirtyMasks (G:=Fin K)).card
  have hn : 0≤n := by positivity
  have hc : (∑m∈dirtyMasks,(Real.sqrt (cost m))^2)≤n*T := by
    calc
      _ ≤ ∑_m∈dirtyMasks,T := by
        apply Finset.sum_le_sum
        intro m hm
        rw [Real.sq_sqrt (hcost0 m hm)]
        exact hcost m hm
      _ = _ := by simp [n]
  calc
    _ ≤ Real.sqrt (n*(n*T)) := Real.sqrt_le_sqrt (mul_le_mul_of_nonneg_left hc hn)
    _ = n*Real.sqrt T := by rw [←mul_assoc,←pow_two,Real.sqrt_mul (sq_nonneg n),Real.sqrt_sq hn]
    _ ≤ _ := mul_le_mul_of_nonneg_right (by
      dsimp [n]
      exact_mod_cast (show (dirtyMasks (G:=Fin K)).card≤4^K by simpa using (masks_card_le (G:=Fin K)))) (Real.sqrt_nonneg T)

 def rawSaving (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ) : ℝ :=
  PhysicalDirtyRow.separatedBudget K J B ρ v0 vmin M+PhysicalDirtyRow.exceptionalBudget K B ρ v0 vmin L a

 theorem rawSaving_nonneg (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) :
    0≤rawSaving K J B ρ v0 vmin M L a := by
  have hr : 0<1-ρ := sub_pos.mpr hρ
  unfold rawSaving PhysicalDirtyRow.separatedBudget PhysicalDirtyRow.exceptionalBudget
  apply add_nonneg
  · apply Finset.sum_nonneg
    intro i _
    positivity
  · apply mul_nonneg (by positivity)
    apply Finset.sum_nonneg
    intro i _
    unfold DirtyExceptionalOuter.storeBudget
    positivity

 theorem raw_budget_product_le (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ)
    (m : Mask (G:=Fin K)) (hm : m∈dirtyMasks)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M)
    (hs : rawSaving K J B ρ v0 vmin M L a≤1) :
    budget K J B ρ v0 vmin M L a m.2*budget K J B ρ v0 vmin M L a m.1≤
      rawSaving K J B ρ v0 vmin M L a*(33*((1+v0)*M)^K+1) := by
  have he := rawSaving_nonneg K J B ρ v0 vmin M L a hρ hv0 hmin hM
  have hc : 0≤33*((1+v0)*M)^K := by positivity
  have hdirty : (∃i,m.1 i=true) ∨ (∃i,m.2 i=true) := by
    obtain ⟨i,hi⟩ := (Finset.mem_filter.mp hm).2
    rcases hi with hi|hi
    · exact Or.inl ⟨i,hi⟩
    · exact Or.inr ⟨i,hi⟩
  unfold budget
  change (if ∃i,m.2 i=true then rawSaving K J B ρ v0 vmin M L a else _)*
    (if ∃i,m.1 i=true then rawSaving K J B ρ v0 vmin M L a else _)≤_
  split_ifs <;> first | nlinarith | tauto

 theorem raw_allMaskBudget_le (K J B : ℕ) (V : Fin K→ℝ)
    (ρ v0 vmin vmax M L A : ℝ) (a : Fin K→ℝ)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax)
    (hs : rawSaving K J B ρ v0 vmin M L a≤1) :
    PhysicalDirtyRawSchur.allMaskBudget K J B V ρ v0 vmin M L A a≤
      ((4:ℝ)^K*A)*Real.sqrt ((reverseBound K vmin vmax*(33*((1+v0)*M)^K+1))*
        rawSaving K J B ρ v0 vmin M L a) := by
  have he := rawSaving_nonneg K J B ρ v0 vmin M L a hρ hv0 hmin hM
  have hQ : 0≤reverseBound K vmin vmax := by unfold reverseBound;positivity
  have hT : 0≤A^2*(reverseBound K vmin vmax*(33*((1+v0)*M)^K+1))*rawSaving K J B ρ v0 vmin M L a := by positivity
  let cost := fun m : Mask (G:=Fin K)=>
    (A*budget K J B ρ v0 vmin M L a m.2)*(reverseFactor V m.2 m.1*A*budget K J B ρ v0 vmin M L a m.1)
  have hc0 (m : Mask (G:=Fin K)) (_ : m∈dirtyMasks) : 0≤cost m := by
    exact mul_nonneg (mul_nonneg hA (budget_nonneg K J B ρ v0 vmin M L a m.2 hρ hv0 hmin hM))
      (mul_nonneg (mul_nonneg (reverseFactor_pos V (fun i=>hmin.trans_le (hlo i)) _ _).le hA)
        (budget_nonneg K J B ρ v0 vmin M L a m.1 hρ hv0 hmin hM))
  have hc (m : Mask (G:=Fin K)) (hm : m∈dirtyMasks) : cost m≤
      A^2*(reverseBound K vmin vmax*(33*((1+v0)*M)^K+1))*rawSaving K J B ρ v0 vmin M L a := by
    have hp := raw_budget_product_le K J B ρ v0 vmin M L a m hm hρ hv0 hmin hM hs
    have hr := reverseFactor_le V m.2 m.1 vmin vmax hmin hlo hhi
    have hbi := budget_nonneg K J B ρ v0 vmin M L a m.2 hρ hv0 hmin hM
    have hbs := budget_nonneg K J B ρ v0 vmin M L a m.1 hρ hv0 hmin hM
    calc
      _ = A^2*reverseFactor V m.2 m.1*(budget K J B ρ v0 vmin M L a m.2*budget K J B ρ v0 vmin M L a m.1) := by dsimp [cost];ring
      _ ≤ A^2*reverseBound K vmin vmax*(rawSaving K J B ρ v0 vmin M L a*(33*((1+v0)*M)^K+1)) := by
        gcongr
      _ = _ := by ring
  have hh := mask_sqrt_sum_le cost _ hT hc0 hc
  apply hh.trans_eq
  rw [mul_assoc (A^2),Real.sqrt_mul (sq_nonneg A),Real.sqrt_sq hA]
  ring

/-- Uniform polynomial bound on the comparison's literal memory budget. -/
theorem comparison_memory_budget_le {K B : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (v0 vmin M : ℝ)
    (hν : ∀i p,0≤ν i p) (hv0 : 0<v0) (hmin : 0<vmin)
    (hlo : ∀i,vmin≤V i) (hmass : ∀i,(∑p,ν i p)≤M) :
    PhysicalChoiceFiberWeight.budget (B:=B) ν V v0≤
      ((1+v0)*((B:ℝ)*vmin⁻¹/v0+M))^K := by
  unfold PhysicalChoiceFiberWeight.budget
  calc
    _ ≤ ∏_i : Fin K,(1+v0)*((B:ℝ)*vmin⁻¹/v0+M) := by
      apply Finset.prod_le_prod₀
      · intro i _
        have hv : 0<V i := hmin.trans_le (hlo i)
        have hn : 0≤∑p,ν i p := Finset.sum_nonneg fun p _=>hν i p
        positivity
      · intro i _
        have hi : (V i)⁻¹≤vmin⁻¹ := by simpa only [one_div] using one_div_le_one_div_of_le hmin (hlo i)
        gcongr
        exact hmass i
    _ = _ := by simp

 def comparisonGeo (C : ℝ) : ℝ := 72*(256*(512*C))^2
 def comparisonCoarse (C : ℝ) : ℝ := 33*(2*C+1)
 def comparisonSaving (Y R : ℝ) : ℝ := R⁻¹+Y^(-(1/5:ℝ))

 theorem comparison_budget_product_le {K : ℕ} (Y C R : ℝ) (m : Mask (G:=Fin K))
    (hm : m∈dirtyMasks) (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R)
    (hs : comparisonSaving Y R≤2) :
    PhysicalComparisonMaskedRow.countFactor Y C R m.2*PhysicalComparisonMaskedRow.countFactor Y C R m.1≤
      comparisonGeo C*comparisonSaving Y R*(comparisonCoarse C+2*comparisonGeo C) := by
  have he : 0≤comparisonSaving Y R := by unfold comparisonSaving;positivity
  have hc : 0≤comparisonCoarse C := by unfold comparisonCoarse;positivity
  have hq : 0≤comparisonGeo C := by unfold comparisonGeo;positivity
  have hdirty : (∃i,m.1 i=true) ∨ (∃i,m.2 i=true) := by
    obtain ⟨i,hi⟩ := (Finset.mem_filter.mp hm).2
    rcases hi with hi|hi
    · exact Or.inl ⟨i,hi⟩
    · exact Or.inr ⟨i,hi⟩
  unfold PhysicalComparisonMaskedRow.countFactor
  change (if ∃i,m.2 i=true then comparisonGeo C*comparisonSaving Y R else comparisonCoarse C)*
    (if ∃i,m.1 i=true then comparisonGeo C*comparisonSaving Y R else comparisonCoarse C)≤_
  have hsmall : comparisonGeo C*comparisonSaving Y R≤2*comparisonGeo C := by nlinarith
  have hsmall0 := mul_nonneg hq he
  split_ifs <;> first | nlinarith | tauto

 theorem comparison_allMaskBudget_le {K B : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (v0 vmin vmax M A Y C R : ℝ)
    (hν : ∀i p,0≤ν i p) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax) (hmass : ∀i,(∑p,ν i p)≤M)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R) (hs : comparisonSaving Y R≤2) :
    PhysicalDirtyComparisonSchur.allMaskBudget B ν V v0 A Y C R≤
      ((4:ℝ)^K*A*((1+v0)*((B:ℝ)*vmin⁻¹/v0+M))^K)*
        Real.sqrt ((reverseBound K vmin vmax*comparisonGeo C*(comparisonCoarse C+2*comparisonGeo C))*
          comparisonSaving Y R) := by
  let P0 := PhysicalChoiceFiberWeight.budget (B:=B) ν V v0
  have hP0 : 0≤P0 := by
    unfold P0 PhysicalChoiceFiberWeight.budget
    apply Finset.prod_nonneg
    intro i _
    have hv : 0<V i := hmin.trans_le (hlo i)
    have hn : 0≤∑p,ν i p := Finset.sum_nonneg fun p _=>hν i p
    positivity
  have hQ : 0≤reverseBound K vmin vmax := by unfold reverseBound;positivity
  have hG : 0≤comparisonGeo C := by unfold comparisonGeo;positivity
  have hC0 : 0≤comparisonCoarse C := by unfold comparisonCoarse;positivity
  have he : 0≤comparisonSaving Y R := by unfold comparisonSaving;positivity
  let T := (A*P0)^2*(reverseBound K vmin vmax*comparisonGeo C*(comparisonCoarse C+2*comparisonGeo C))*comparisonSaving Y R
  have hT : 0≤T := by dsimp [T];positivity
  let cost := fun m : Mask (G:=Fin K)=>
    (A*(PhysicalComparisonMaskedRow.countFactor Y C R m.2*P0))*
      (reverseFactor V m.2 m.1*A*(PhysicalComparisonMaskedRow.countFactor Y C R m.1*P0))
  have hc0 (m : Mask (G:=Fin K)) (_ : m∈dirtyMasks) : 0≤cost m := by
    have hi := PhysicalComparisonMaskedRow.countFactor_nonneg Y C R m.2 hY hC hR
    have hs := PhysicalComparisonMaskedRow.countFactor_nonneg Y C R m.1 hY hC hR
    have hr := (reverseFactor_pos V (fun i=>hmin.trans_le (hlo i)) m.2 m.1).le
    dsimp [cost]
    positivity
  have hc (m : Mask (G:=Fin K)) (hm : m∈dirtyMasks) : cost m≤T := by
    have hp := comparison_budget_product_le Y C R m hm hY hC hR hs
    have hr := reverseFactor_le V m.2 m.1 vmin vmax hmin hlo hhi
    have hi := PhysicalComparisonMaskedRow.countFactor_nonneg Y C R m.2 hY hC hR
    have hj := PhysicalComparisonMaskedRow.countFactor_nonneg Y C R m.1 hY hC hR
    calc
      _ = (A*P0)^2*reverseFactor V m.2 m.1*
        (PhysicalComparisonMaskedRow.countFactor Y C R m.2*PhysicalComparisonMaskedRow.countFactor Y C R m.1) := by dsimp [cost];ring
      _ ≤ (A*P0)^2*reverseBound K vmin vmax*
        (comparisonGeo C*comparisonSaving Y R*(comparisonCoarse C+2*comparisonGeo C)) := by gcongr
      _ = T := by dsimp [T];ring
  have hh := mask_sqrt_sum_le cost T hT hc0 hc
  calc
    _ ≤ (4:ℝ)^K*Real.sqrt T := hh
    _ = ((4:ℝ)^K*A*P0)*Real.sqrt ((reverseBound K vmin vmax*comparisonGeo C*(comparisonCoarse C+2*comparisonGeo C))*comparisonSaving Y R) := by
      dsimp [T]
      rw [mul_assoc ((A*P0)^2),Real.sqrt_mul (sq_nonneg (A*P0)),Real.sqrt_sq (mul_nonneg hA hP0)]
      ring
    _ ≤ _ := by
      apply mul_le_mul_of_nonneg_right _ (Real.sqrt_nonneg _)
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg (by positivity) hA)
      exact comparison_memory_budget_le ν V v0 vmin M hν hv0 hmin hlo hmass

end Elliptic.Operator.PhysicalMaskBudgetBounds
