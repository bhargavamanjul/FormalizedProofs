module

public import Elliptic.Operator.ActualHistoryLifespans

/-!
# Finite edge observations of literal histories

Every edge record below is read from the actual dependent choice. No
scheduled path is supplied. The observations recover the active recurrence
and, when a schedule is compatible, its finite edge data.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualHistoryObservation
open ScheduledPhysicalPath
set_option backward.isDefEq.respectTransparency false

structure EdgeRecord (I Z : Type) (P : I → Type) (J : ℕ) where
  target : Z
  sourcePerm : ∀ _i : I, Equiv.Perm (Fin (J+1))
  targetPerm : ∀ _i : I, Equiv.Perm (Fin (J+1))
  store : I → Bool
  promote : I → Bool
  targetPrime : ∀ i, P i

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}

def record {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalEdgeChoice s) : EdgeRecord I Z P J where
  target := c.target
  sourcePerm := c.sourcePerm
  targetPerm := c.targetPerm
  store i := (c.group i).1
  promote i := match (c.group i).2 with | .inl _ => true | .inr _ => false
  targetPrime i := edgeTargetPrime (s.memory P Line J B i) (c.group i)

structure GhostRecord (I : Type) (P : I → Type) where
  deleted : ∀ i, Finset (P i)
  fresh : ∀ i, Multiset (P i)

def ghostRecord {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalGhostChoice s) : GhostRecord I P := by
  classical
  exact ⟨fun i => (c i).1.image (fun a => ((s.memory P Line J B i).values a).1),
    fun i => tupleBag (c i).2.values⟩

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

def edgeAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin n → EdgeRecord I Z P J
  | 0,_,_,_,k => Fin.elim0 k
  | n+1,j,_,h,k => Fin.cases (record h.2.1.val)
      (fun t => edgeAt n (j+1) _ h.2.2 t) k

def ghostAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin (n+1) → GhostRecord I P
  | 0,_,_,h,_ => ghostRecord h.1.val
  | n+1,j,_,h,k => Fin.cases (ghostRecord h.1.val)
      (fun t => ghostAt n (j+1) _ h.2.2 t) k

theorem before_after_position (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) :
    (afterStateAt ν V η q ρ geometry n j s h k).position P Line J B =
      (beforeStateAt ν V η q ρ geometry n j s h k).position P Line J B := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih => exact Fin.cases rfl (fun t => ih (j+1) _ h.2.2 t) k

theorem before_after_active (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) :
    (afterStateAt ν V η q ρ geometry n j s h k).active P Line J B =
      (beforeStateAt ν V η q ρ geometry n j s h k).active P Line J B := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih => exact Fin.cases rfl (fun t => ih (j+1) _ h.2.2 t) k

theorem next_position (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin n) :
    (beforeStateAt ν V η q ρ geometry n j s h k.succ).position P Line J B =
      (edgeAt ν V η q ρ anchor geometry n j s h k).target := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · rw [beforeStateAt]
        exact ActualHistoryLifespans.beforeStateAt_zero ν V η q ρ anchor geometry n (j+1) _ h.2.2
          |> congrArg (PhysicalMemoryState.position P Line J B)
      · exact ih (j+1) _ h.2.2 t

theorem next_active (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin n) (i : I) (a : Fin (J+1)) :
    (beforeStateAt ν V η q ρ geometry n j s h k.succ).active P Line J B i a =
      Fin.lastCases ((edgeAt ν V η q ρ anchor geometry n j s h k).targetPrime i)
        (fun t : Fin J => (beforeStateAt ν V η q ρ geometry n j s h k.castSucc).active P Line J B i
          ((edgeAt ν V η q ρ anchor geometry n j s h k).sourcePerm i t.castSucc))
        ((edgeAt ν V η q ρ anchor geometry n j s h k).targetPerm i a) := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · change (beforeStateAt ν V η q ρ geometry n (j+1) _ h.2.2 0).active P Line J B i a = _
        rw [ActualHistoryLifespans.beforeStateAt_zero]
        rfl
      · exact ih (j+1) _ h.2.2 t

theorem observed_liveDistinct (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) :
    (beforeStateAt ν V η q ρ geometry n j s h k).LiveDistinct ∧
      (afterStateAt ν V η q ρ geometry n j s h k).LiveDistinct := by
  induction n generalizing j s with
  | zero => exact hl
  | succ n ih => exact Fin.cases ⟨hl.1,hl.2.1⟩ (fun t => ih (j+1) _ h.2.2 hl.2.2 t) k

theorem compatible_edgeAt (d : ScheduledPhysicalPath anchor N J B) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin n) :
    let e := edgeAt ν V η q ρ anchor geometry n j s h k
    e.target = d.position (j+k.val+1) ∧ e.sourcePerm = d.sourcePerm (j+k.val) ∧
      e.targetPerm = d.targetPerm (j+k.val) ∧ e.store = d.store (j+k.val) ∧
      e.promote = d.promote (j+k.val) ∧ e.targetPrime = d.targetPrime (j+k.val) := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · have he := hc.2.1
        refine ⟨he.1,he.2.1,he.2.2.1,?_,?_,?_⟩
        · exact funext (fun i => (he.2.2.2 i).1)
        · exact funext (fun i => (he.2.2.2 i).2.2)
        · exact funext (fun i => (he.2.2.2 i).2.1)
      · simpa only [edgeAt, Fin.cases_succ, Fin.val_succ, Nat.add_assoc,
          Nat.add_comm 1 t.val] using ih (j+1) _ h.2.2 hc.2.2 t

/-- Support is checked at the literal lists, before endpoint permutation. -/
def AllGeometryNonzero : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s → Prop
  | 0,_,_,_ => True
  | n+1,j,s,h =>
      geometry j (s.position P Line J B) h.2.1.val.sourceLists
        h.2.1.val.target h.2.1.val.targetLists ≠ 0 ∧
      AllGeometryNonzero n (j+1) _ h.2.2

/-- Every edge of a nonzero literal coefficient lies on geometric support.
No positivity or estimate of the coefficients is used. -/
theorem allGeometryNonzero_of_weight_ne_zero (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hw : h.weight ≠ 0) : AllGeometryNonzero ν V η q ρ anchor geometry n j s h := by
  induction n generalizing j s with
  | zero => trivial
  | succ n ih =>
      have ht : h.2.2.weight ≠ 0 := (mul_ne_zero_iff.mp (mul_ne_zero_iff.mp hw).2).2
      have he := (mul_ne_zero_iff.mp (mul_ne_zero_iff.mp hw).2).1
      refine ⟨?_,ih (j+1) _ h.2.2 ht⟩
      intro hz
      apply he
      simp only [physicalEdgeOperation]
      split_ifs
      · change _ * geometry j (s.position P Line J B) h.2.1.val.sourceLists
          h.2.1.val.target h.2.1.val.targetLists * _ = 0
        rw [hz,mul_zero,zero_mul]
      · rfl

/-- The actual geometry can also be read solely from the finite edge and
visit observations, with no chosen schedule. -/
theorem nonzero_geometry_at (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hg : AllGeometryNonzero ν V η q ρ anchor geometry n j s h) (k : Fin n) :
    let e := edgeAt ν V η q ρ anchor geometry n j s h k
    let t := beforeStateAt ν V η q ρ geometry n j s h k.castSucc
    let a : PhysicalActiveLists P J := fun i l => t.active P Line J B i (e.sourcePerm i l)
    geometry (j+k.val) (t.position P Line J B) a e.target
      (fun i => Fin.lastCases (e.targetPrime i) (fun l : Fin J => a i l.castSucc)) ≠ 0 := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ?_) k
      · exact hg.1
      · simpa only [edgeAt, beforeStateAt, ← Fin.succ_castSucc, Fin.cases_succ, Fin.val_succ,
          Nat.add_assoc, Nat.add_comm 1 t.val] using
          ih (j+1) _ h.2.2 hg.2 t

def GhostMatches (d : ScheduledPhysicalPath anchor N J B) (j : ℕ)
    (g : GhostRecord I P) : Prop :=
  (∀ i, g.deleted i = LifespanSchedule.deaths (d.primes i) (d.lifespan i) j) ∧
  (∀ i, g.fresh i = (LifespanSchedule.births (d.primes i) (d.lifespan i) j).val)

def EdgeMatches (d : ScheduledPhysicalPath anchor N J B) (j : ℕ)
    (e : EdgeRecord I Z P J) : Prop :=
  e.target = d.position (j+1) ∧ e.sourcePerm = d.sourcePerm j ∧
  e.targetPerm = d.targetPerm j ∧ e.store = d.store j ∧
  e.promote = d.promote j ∧ e.targetPrime = d.targetPrime j

/-- Finite record tests suffice for the literal recursive compatibility
relation. No equality with the constructed realization is assumed. -/
theorem compatible_of_records (d : ScheduledPhysicalPath anchor N J B) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hg : ∀ k : Fin (n+1), GhostMatches anchor d (j+k.val)
      (ghostAt ν V η q ρ anchor geometry n j s h k))
    (he : ∀ k : Fin n, EdgeMatches anchor d (j+k.val)
      (edgeAt ν V η q ρ anchor geometry n j s h k)) :
    d.Compatible ν V η q ρ geometry n j s h := by
  induction n generalizing j s with
  | zero => exact hg 0
  | succ n ih =>
      refine ⟨hg 0,?_,?_⟩
      · have hh := he 0
        refine ⟨hh.1,hh.2.1,hh.2.2.1,?_⟩
        intro i
        exact ⟨congrFun hh.2.2.2.1 i,congrFun hh.2.2.2.2.2 i,
          congrFun hh.2.2.2.2.1 i⟩
      · apply ih (j+1) _ h.2.2
        · intro k
          simpa only [ghostAt,Fin.cases_succ,Fin.val_succ,Nat.add_assoc,
            Nat.add_comm 1 k.val] using hg k.succ
        · intro k
          simpa only [edgeAt,Fin.cases_succ,Fin.val_succ,Nat.add_assoc,
            Nat.add_comm 1 k.val] using he k.succ

theorem ghostMatches_of_compatible (d : ScheduledPhysicalPath anchor N J B) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) :
    GhostMatches anchor d (j+k.val) (ghostAt ν V η q ρ anchor geometry n j s h k) := by
  induction n generalizing j s with
  | zero =>
      have hk : k.val = 0 := by omega
      simpa only [hk,Nat.add_zero,GhostMatches,ghostAt,ghostRecord,
        ScheduledPhysicalPath.Compatible,ScheduledPhysicalPath.GhostObserved] using hc
  | succ n ih =>
      refine Fin.cases hc.1 (fun t => ?_) k
      simpa only [ghostAt,Fin.cases_succ,Fin.val_succ,Nat.add_assoc,
        Nat.add_comm 1 t.val] using ih (j+1) _ h.2.2 hc.2.2 t

end Elliptic.Operator.ActualHistoryObservation
