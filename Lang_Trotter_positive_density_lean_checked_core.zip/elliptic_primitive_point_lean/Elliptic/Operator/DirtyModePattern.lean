module

public import Elliptic.Operator.PhysicalDirtyPartition

/-!
# Exact fresh/free modes indexed by their promotion pattern

A mode tuple is equivalent to its finite promoted set, containing the
already distinguished promoted group, together with one actual prime
in each complementary group. No fresh coordinate or prime multiplicity
is dropped in the equivalence.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirtyModePattern
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {G : Type*} [Fintype G] [DecidableEq G] {P : G → Type*}

abbrev Modes (i : G) := ∀ j : {j : G // j ≠ i}, Option (P j)
abbrev Pattern (i : G) := {I : Finset G // i ∈ I}
abbrev Fresh (I : Finset G) := ∀ j : {j : G // j ∉ I}, P j

/-- The distinguished group and every ordinary free-promotion group. -/
def promotedSet (i : G) (mode : Modes (P:=P) i) : Finset G :=
  {i} ∪ (Finset.univ.filter (fun j : {j : G // j ≠ i} => mode j = none)).image Subtype.val

theorem mem_promotedSet (i : G) (mode : Modes (P:=P) i) (j : {j : G // j ≠ i}) :
    j.1 ∈ promotedSet i mode ↔ mode j = none := by
  simp only [promotedSet, Finset.mem_union, Finset.mem_singleton, j.property,
    false_or, Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨k,hk,hkj⟩
    have he : k = j := Subtype.ext hkj
    cases he
    exact hk
  · exact fun h => ⟨j,h,rfl⟩

theorem distinguished_mem (i : G) (mode : Modes (P:=P) i) : i ∈ promotedSet i mode := by
  simp [promotedSet]

/-- Reconstruct a literal mode tuple from its actual promoted set and
fresh-prime tuple on the complement. -/
def assemble (i : G) (I : Pattern i) (fresh : Fresh (P:=P) I.1) : Modes (P:=P) i :=
  fun j => if hj : j.1 ∈ I.1 then none else some (fresh ⟨j.1,hj⟩)

theorem promotedSet_assemble (i : G) (I : Pattern i) (fresh : Fresh (P:=P) I.1) :
    promotedSet i (assemble i I fresh) = I.1 := by
  ext j
  by_cases hji : j=i
  · subst j
    simp [distinguished_mem, I.property]
  · rw [mem_promotedSet i _ ⟨j,hji⟩]
    simp [assemble]

theorem fresh_exists (i : G) (mode : Modes (P:=P) i)
    (j : {j : G // j ∉ promotedSet i mode})
    (hji : j.1 ≠ i) : ∃ p, mode ⟨j.1,hji⟩ = some p := by
  apply Option.ne_none_iff_exists'.1
  intro hm
  exact j.property ((mem_promotedSet i mode ⟨j.1,hji⟩).2 hm)

/-- Actual fresh coordinates extracted from the mode tuple. -/
def readFresh (i : G) (mode : Modes (P:=P) i) : Fresh (P:=P) (promotedSet i mode) :=
  fun j => Classical.choose (fresh_exists i mode j (by
    intro he
    exact j.property (by rw [he]; exact distinguished_mem i mode)))

theorem readFresh_spec (i : G) (mode : Modes (P:=P) i)
    (j : {j : G // j ∉ promotedSet i mode}) (hji : j.1 ≠ i) :
    mode ⟨j.1,hji⟩ = some (readFresh i mode j) :=
  Classical.choose_spec (fresh_exists i mode j hji)

theorem assemble_injective (i : G) :
    Function.Injective (fun q : Σ I : Pattern i, Fresh (P:=P) I.1 => assemble i q.1 q.2) := by
  rintro ⟨I,f⟩ ⟨J,g⟩ h
  change assemble i I f = assemble i J g at h
  have hset : I.1 = J.1 := by
    rw [← promotedSet_assemble i I f, ← promotedSet_assemble i J g, h]
  have he : I=J := Subtype.ext hset
  cases he
  apply congrArg (Sigma.mk I)
  funext j
  have hji : j.1 ≠ i := by intro he; exact j.property (by rw [he]; exact I.property)
  have hh := congrFun h ⟨j.1,hji⟩
  simpa only [assemble, j.property, dite_false, Option.some.injEq] using hh

theorem assemble_surjective (i : G) :
    Function.Surjective (fun q : Σ I : Pattern i, Fresh (P:=P) I.1 => assemble i q.1 q.2) := by
  intro mode
  refine ⟨⟨⟨promotedSet i mode, distinguished_mem i mode⟩, readFresh i mode⟩, ?_⟩
  funext j
  dsimp [assemble]
  split_ifs with hj
  · exact ((mem_promotedSet i mode j).1 hj).symm
  · exact (readFresh_spec i mode ⟨j.1,hj⟩ j.property).symm

/-- Literal equivalence, including empty prime types or empty fresh sets. -/
def equiv (i : G) : (Σ I : Pattern i, Fresh (P:=P) I.1) ≃ Modes (P:=P) i :=
  Equiv.ofBijective _ ⟨assemble_injective i, assemble_surjective i⟩

theorem equiv_apply (i : G) (I : Pattern i) (fresh : Fresh (P:=P) I.1) :
    equiv i ⟨I,fresh⟩ = assemble i I fresh := rfl

/-- Multiplying the fresh factors of the reconstructed ordinary modes
is exactly the independent fresh product on the complementary groups. -/
theorem assemble_product {M : Type*} [CommMonoid M]
    (i : G) (I : Pattern i) (fresh : Fresh (P:=P) I.1) (weight : ∀ j, P j → M) :
    (∏ j : {j : G // j ≠ i}, (assemble i I fresh j).elim 1 (weight j)) =
      ∏ j : {j : G // j ∉ I.1}, weight j (fresh j) := by
  let f : G → M := fun j => if hj : j ∈ I.1 then 1 else weight j (fresh ⟨j,hj⟩)
  have hsplit : (∏ j, f j) = f i * ∏ j : {j : G // j ≠ i}, f j := by
    rw [← Finset.mul_prod_erase Finset.univ f (Finset.mem_univ i)]
    congr 1
    exact Finset.prod_subtype _ (by simp) _
  have hfull : (∏ j, f j) = ∏ j : {j : G // j ∉ I.1}, weight j (fresh j) := by
    have hl : (∏ j ∈ I.1, f j) = 1 := by
      apply Finset.prod_eq_one
      intro j hj
      simp only [f, hj, dite_true]
    rw [← Finset.prod_mul_prod_compl I.1 f, hl, one_mul]
    have hr : (∏ j ∈ I.1ᶜ, f j) = ∏ j : {j : G // j ∉ I.1}, f j :=
      Finset.prod_subtype _ (by simp) _
    rw [hr]
    apply Finset.prod_congr rfl
    intro j _
    simp only [f, j.property, dite_false]
  have hi : f i = 1 := by simp [f,I.property]
  rw [hsplit,hi,one_mul] at hfull
  calc
    _ = ∏ j : {j : G // j ≠ i}, f j := by
      apply Finset.prod_congr rfl
      intro j _
      by_cases hj : j.1 ∈ I.1 <;> simp [assemble,f,hj]
    _ = _ := hfull

variable [∀ i, Fintype (P i)]

/-- Exact finite integration over promotion patterns and their actual
fresh tuples, for an arbitrary coupled summand. -/
theorem sum_modes (i : G) (f : Modes (P:=P) i → ℝ) :
    (∑ mode, f mode) =
      ∑ I : Pattern i, ∑ fresh : Fresh (P:=P) I.1, f (assemble i I fresh) := by
  have hs := Fintype.sum_sigma (f := fun q : Σ I : Pattern i, Fresh (P:=P) I.1 =>
    f (assemble i q.1 q.2))
  rw [← hs]
  exact (Equiv.sum_comp (equiv (P:=P) i) f).symm

end Elliptic.Operator.DirtyModePattern
