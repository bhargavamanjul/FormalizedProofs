module

public import Elliptic.Operator.DirtyWeightedRaw

/-!
# Actual fresh-product integration in the dirty raw row

Fresh choices carry their literal product prime measure. The good-state
condition is a bound on the measure of fresh tuples that fail the
explicit circle phase-separation test; it is not an operator-norm input.
The geometric and indexed-memory bounds then give the two terms in (4.40).
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- The actual independent fresh-prime mass. -/
def freshPrimeTupleMass {F : Type*} [Fintype F] {Q : F → Type*}
    (ν : ∀ i, Q i → ℝ) (fresh : ∀ i, Q i) : ℝ := ∏ i, ν i (fresh i)

/-- Numeric product of the actual fresh-prime tuple. -/
def freshPrimeTupleProduct {F : Type*} [Fintype F] {Q : F → Type*}
    (value : ∀ i, Q i → ℕ) (fresh : ∀ i, Q i) : ℕ := ∏ i, value i (fresh i)

/-- The failed good-state test has exactly its product-law mass. -/
def dirtyPhaseExceptionalMass {K M : ℕ} {F : Type*} [Fintype F]
    {Q : F → Type*} [∀ i, Fintype (Q i)]
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (value : ∀ i, Q i → ℕ) (ν : ∀ i, Q i → ℝ) (β δ : ℝ) : ℝ :=
  ∑ fresh : ∀ i, Q i,
    if PhaseSeparated (dirtyProductSupport label newProducts)
      ((freshPrimeTupleProduct value fresh : ℝ)*β) δ then 0
    else freshPrimeTupleMass ν fresh

/-- Integration of the concrete indexed-memory row over the actual fresh
prime tuples gives a good term B/M^K and an exceptional term B^|I| ε. -/
theorem integratedIndexedRawPromotionRow_le
    {K M B : ℕ} {I F : Type*} [Fintype I] [Fintype F]
    {P₀ : Type*} {Line₀ : P₀ → Type*}
    {P : I → Type*} {Line : ∀ i, P i → Type*}
    {Q : F → Type*} [∀ i, Fintype (Q i)]
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (σ : ℤ) (β δ ε : ℝ)
    (freshValue : ∀ i, Q i → ℕ) (freshν : ∀ i, Q i → ℝ)
    (value₀ : P₀ → ℕ) (ν₀ : P₀ → ℝ) (V₀ : ℝ)
    (sourceAnchor₀ : ∀ p, Line₀ p)
    (m₀ : MemoryState (AnchoredParticle P₀ Line₀) B)
    (store₀ : Bool) (h₀ : (∀ i, Q i) → Fin m₀.size → ℤ)
    (sourcePrime₀ : (Fin K → Fin M) → P₀)
    (targetAnchor₀ : (∀ i, Q i) → Fin m₀.size → RawDirtyCoordinate K M → ∀ p, Line₀ p)
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (sourceAnchor : ∀ i p, Line i p)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (sourcePrime : (Fin K → Fin M) → ∀ i, P i)
    (targetAnchor : (∀ i, Q i) → Fin m₀.size → RawDirtyCoordinate K M → ∀ i p, Line i p)
    (ρ v0 : ℝ) (hM : 0 < M)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : ∀ b, 0 < value₀ (m₀.values b).1) (hσ : σ=1 ∨ σ= -1)
    (hwidth : ∀ b, 2*(16/(value₀ (m₀.values b).1 : ℝ)) < δ)
    (hgood : dirtyPhaseExceptionalMass label newProducts freshValue freshν β δ ≤ ε)
    (hfreshν : ∀ i p, 0 ≤ freshν i p)
    (hV₀ : 0 ≤ V₀) (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ fresh : ∀ i, Q i, freshPrimeTupleMass freshν fresh *
      indexedRawPromotionRow label newProducts (freshPrimeTupleProduct freshValue fresh) σ β
        value₀ ν₀ V₀ sourceAnchor₀ m₀ store₀ (h₀ fresh) sourcePrime₀ (targetAnchor₀ fresh)
        value ν V sourceAnchor m store sourcePrime (targetAnchor fresh) ρ v0) ≤
      ((V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
        (∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1-ρ)) *
        (33 * (B : ℝ) / (M : ℝ)^K)) * (∏ i, ∑ p, freshν i p) +
      ((V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
        (∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0)) *
        (33 * (B : ℝ) ^ (Fintype.card I + 1))) * ε := by
  classical
  let A : ℝ := (V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
    (∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1-ρ)) *
    (33 * (B : ℝ) / (M : ℝ)^K)
  let E : ℝ := (V₀⁻¹ * (v0 ^ store₀.toNat / v0)) *
    (∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0)) *
    (33 * (B : ℝ) ^ (Fintype.card I + 1))
  have hpC : 0 ≤ ∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1-ρ) :=
    Finset.prod_nonneg fun i _ => by have := hV i; positivity
  have hpE : 0 ≤ ∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0) :=
    Finset.prod_nonneg fun i _ => by have := hV i; positivity
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hE : 0 ≤ E := by dsimp [E]; positivity
  have hmass (fresh : ∀ i, Q i) : 0 ≤ freshPrimeTupleMass freshν fresh :=
    Finset.prod_nonneg fun i _ => hfreshν i (fresh i)
  calc
    _ ≤ ∑ fresh : ∀ i, Q i,
        (freshPrimeTupleMass freshν fresh * A + E *
          (if PhaseSeparated (dirtyProductSupport label newProducts)
            ((freshPrimeTupleProduct freshValue fresh : ℝ)*β) δ then 0
            else freshPrimeTupleMass freshν fresh)) := by
      apply Finset.sum_le_sum
      intro fresh _
      split_ifs with hphase
      · simp only [mul_zero, add_zero]
        exact mul_le_mul_of_nonneg_left
          (indexedRawPromotionRow_le label newProducts (freshPrimeTupleProduct freshValue fresh)
            σ β δ value₀ ν₀ V₀ sourceAnchor₀ m₀ store₀ (h₀ fresh) sourcePrime₀ (targetAnchor₀ fresh)
            value ν V sourceAnchor m store sourcePrime (targetAnchor fresh) ρ v0
            hprime hinj hban hp hσ hphase hwidth hV₀ hν hV hρ0 hρ1 hv0) (hmass fresh)
      · have hc := indexedRawPromotionRow_le_crude label newProducts
          (freshPrimeTupleProduct freshValue fresh) σ β value₀ ν₀ V₀ sourceAnchor₀ m₀ store₀
          (h₀ fresh) sourcePrime₀ (targetAnchor₀ fresh) value ν V sourceAnchor m store sourcePrime
          (targetAnchor fresh) ρ v0 hM hV₀ hν hV hρ0 hρ1.le hv0
        have hc' : freshPrimeTupleMass freshν fresh *
            indexedRawPromotionRow label newProducts (freshPrimeTupleProduct freshValue fresh) σ β
              value₀ ν₀ V₀ sourceAnchor₀ m₀ store₀ (h₀ fresh) sourcePrime₀ (targetAnchor₀ fresh)
              value ν V sourceAnchor m store sourcePrime (targetAnchor fresh) ρ v0 ≤
            E * freshPrimeTupleMass freshν fresh := by
          rw [mul_comm E]
          exact mul_le_mul_of_nonneg_left hc (hmass fresh)
        exact hc'.trans (le_add_of_nonneg_left (mul_nonneg (hmass fresh) hA))
    _ = A * (∏ i, ∑ p, freshν i p) +
        E * dirtyPhaseExceptionalMass label newProducts freshValue freshν β δ := by
      rw [Finset.sum_add_distrib, ← Finset.sum_mul, ← Finset.mul_sum]
      have hm : (∑ fresh : ∀ i, Q i, freshPrimeTupleMass freshν fresh) =
          ∏ i, ∑ p, freshν i p := (Fintype.prod_sum freshν).symm
      rw [hm]
      unfold dirtyPhaseExceptionalMass
      ring
    _ ≤ A * (∏ i, ∑ p, freshν i p) + E * ε := by
      gcongr
    _ = _ := rfl

end Elliptic.Operator
