module

public import Elliptic.Operator.BirthRankCounting
public import Mathlib.Data.Finset.Max

/-! Every nontrivial permutation cycle has one earliest pivot. All other
addresses must repeat its performed birth, and their exact number is the
cycle rank used by the high-rank bound. Chronology is an arbitrary fixed
linear order; no choice depends on the prime values drawn. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthCyclePivots
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {α : Type*} [Fintype α] [LinearOrder α]
local instance decEq : DecidableEq α := Classical.typeDecidableEq α

def laterInCycle (c : Equiv.Perm α) : Finset α :=
  c.support.filter (fun a=>∃b∈c.support,b<a)

theorem laterInCycle_subset (c : Equiv.Perm α) : laterInCycle c⊆c.support :=
  Finset.filter_subset _ _

theorem laterInCycle_eq_erase (c : Equiv.Perm α) (hc : c.support.Nonempty) :
    laterInCycle c=c.support.erase (c.support.min' hc) := by
  ext a
  simp only [laterInCycle,Finset.mem_filter,Finset.mem_erase]
  constructor
  · rintro ⟨ha,b,hb,hba⟩
    refine ⟨?_,ha⟩
    have hm := Finset.min'_le c.support b hb
    intro he
    rw [he] at hba
    exact (not_lt_of_ge hm) hba
  · rintro ⟨hne,ha⟩
    exact ⟨ha,c.support.min' hc,Finset.min'_mem c.support hc,
      lt_of_le_of_ne (Finset.min'_le c.support a ha) hne.symm⟩

theorem laterInCycle_card (c : Equiv.Perm α) :
    (laterInCycle c).card=c.support.card-1 := by
  classical
  by_cases hc : c.support.Nonempty
  · rw [laterInCycle_eq_erase c hc,Finset.card_erase_of_mem (Finset.min'_mem c.support hc)]
  · have he := Finset.not_nonempty_iff_eq_empty.mp hc
    simp [laterInCycle,he]

def nonpivots (σ : Equiv.Perm α) : Finset α :=
  σ.cycleFactorsFinset.biUnion laterInCycle

theorem nonpivots_card (σ : Equiv.Perm α) : (nonpivots σ).card=birthCycleRank σ := by
  unfold nonpivots
  rw [Finset.card_biUnion]
  · simp_rw [laterInCycle_card]
    simp only [birthCycleRank,Equiv.Perm.cycleType_def,Multiset.map_map,Function.comp_def]
    rfl
  · intro c hc d hd hcd
    exact Finset.disjoint_of_subset_left (laterInCycle_subset c)
      (Finset.disjoint_of_subset_right (laterInCycle_subset d)
        ((σ.cycleFactorsFinset_pairwise_disjoint hc hd hcd).disjoint_support))

theorem nonpivots_subset_support (σ : Equiv.Perm α) : nonpivots σ⊆σ.support := by
  intro a ha
  obtain ⟨c,hc,ha⟩ := Finset.mem_biUnion.mp ha
  have hac := laterInCycle_subset c ha
  have he := (Equiv.Perm.mem_cycleFactorsFinset_iff.mp hc).2 a hac
  exact Equiv.Perm.mem_support.mpr (fun h=>Equiv.Perm.mem_support.mp hac (he.trans h))

theorem exists_earlier_cycle_pivot (σ : Equiv.Perm α) (a : α) (ha : a∈nonpivots σ) :
    ∃b : α,b<a ∧ σ.SameCycle b a ∧ b∈σ.support := by
  obtain ⟨c,hc,ha⟩ := Finset.mem_biUnion.mp ha
  obtain ⟨hac,b,hbc,hba⟩ := Finset.mem_filter.mp ha
  have hsame : σ.SameCycle b a :=
    (Equiv.Perm.isCycleOn_support_of_mem_cycleFactorsFinset hc).2 hbc hac
  refine ⟨b,hba,hsame,?_⟩
  have he := (Equiv.Perm.mem_cycleFactorsFinset_iff.mp hc).2 b hbc
  exact Equiv.Perm.mem_support.mpr (fun h=>Equiv.Perm.mem_support.mp hbc (he.trans h))

/-- Chosen from the fixed permutation and chronological order only. -/
def pivot (σ : Equiv.Perm α) (a : α) (ha : a∈nonpivots σ) : α :=
  Classical.choose (exists_earlier_cycle_pivot σ a ha)

theorem pivot_lt (σ : Equiv.Perm α) (a : α) (ha : a∈nonpivots σ) : pivot σ a ha<a :=
  (Classical.choose_spec (exists_earlier_cycle_pivot σ a ha)).1

theorem pivot_sameCycle (σ : Equiv.Perm α) (a : α) (ha : a∈nonpivots σ) :
    σ.SameCycle (pivot σ a ha) a :=
  (Classical.choose_spec (exists_earlier_cycle_pivot σ a ha)).2.1

theorem pivot_mem_support (σ : Equiv.Perm α) (a : α) (ha : a∈nonpivots σ) :
    pivot σ a ha∈σ.support :=
  (Classical.choose_spec (exists_earlier_cycle_pivot σ a ha)).2.2

/-- Permutation invariance propagates along an entire cycle. -/
theorem invariant_on_cycle {β : Type*} (σ : Equiv.Perm α) (f : α→β)
    (hf : ∀a,f (σ a)=f a) {a b : α} (h : σ.SameCycle a b) : f a=f b := by
  obtain ⟨n,rfl⟩ := h.exists_nat_pow_eq
  have hp (n : ℕ) : f ((σ^n) a)=f a := by
    induction n with
    | zero => simp
    | succ n ih => simpa only [pow_succ',Equiv.Perm.mul_apply,hf] using ih
  exact (hp n).symm

/-- Every nonpivot is an actual performed birth of the previously seen
pivot value, including the performed-address requirement. -/
theorem birthPreserving_prescribes {β : Type*} (birth : α→Option β) (σ : Equiv.Perm α)
    (h : BirthPreserving birth σ) (a : α) (ha : a∈nonpivots σ) :
    ∃v : β,birth (pivot σ a ha)=some v ∧ birth a=some v := by
  have he := invariant_on_cycle σ birth h.1 (pivot_sameCycle σ a ha)
  cases hp : birth (pivot σ a ha) with
  | none => exact False.elim (Equiv.Perm.mem_support.mp (pivot_mem_support σ a ha) (h.2 _ hp))
  | some v => exact ⟨v,rfl,he.symm.trans hp⟩

/-- Exactly rank-many later addresses carry prescribed earlier values. -/
theorem exact_rank_prescriptions {β : Type*} (birth : α→Option β) (σ : Equiv.Perm α)
    (h : BirthPreserving birth σ) :
    ∃ S : Finset α,S.card=birthCycleRank σ ∧ ∀a∈S,
      ∃b : α,b<a ∧ ∃v : β,birth b=some v ∧ birth a=some v := by
  refine ⟨nonpivots σ,nonpivots_card σ,?_⟩
  intro a ha
  exact ⟨pivot σ a ha,pivot_lt σ a ha,birthPreserving_prescribes birth σ h a ha⟩

end Elliptic.Operator.BirthCyclePivots
