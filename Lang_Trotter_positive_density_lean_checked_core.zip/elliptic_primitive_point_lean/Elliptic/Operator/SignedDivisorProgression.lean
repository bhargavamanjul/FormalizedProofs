module

public import Mathlib.Data.Nat.ModEq
public import Mathlib.Algebra.BigOperators.Fin
public import Elliptic.Operator.DivisorFourFactors
public import Elliptic.Operator.DivisorTripleSums

/-! Elementary progression counts and largest-factor deletion for the
divisor-square estimate on the literal shifted products `l*h ± 1`. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDivisorProgression
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance progressionDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 300000

/-- The unit shift itself gives uniqueness of the cofactor residue. -/
theorem unit_shift_residue_unique (l d h k : ℕ) (σ : ℤ) (hσ : σ=1 ∨ σ= -1)
    (hh : (d:ℤ)∣(l:ℤ)*h+σ) (hk : (d:ℤ)∣(l:ℤ)*k+σ) : Nat.ModEq d h k := by
  apply Nat.modEq_iff_dvd.mpr
  have hd : (d:ℤ)∣(k:ℤ)*((l:ℤ)*h+σ)-(h:ℤ)*((l:ℤ)*k+σ) :=
    dvd_sub (dvd_mul_of_dvd_right hh _) (dvd_mul_of_dvd_right hk _)
  rcases hσ with rfl|rfl
  · convert hd using 1 <;> ring
  · have hn := dvd_neg.mpr hd
    convert hn using 1 <;> ring

/-- Any single residue class in `[1,H]` has at most `H/d+1` elements. -/
theorem residue_class_card_le (s : Finset ℕ) (H d : ℕ)
    (hs : s⊆Finset.Icc 1 H) (hres : ∀h∈s,∀k∈s,Nat.ModEq d h k) :
    s.card≤H/d+1 := by
  have hinj : Set.InjOn (fun h : ℕ=>h/d) (↑s : Set ℕ) := by
    intro h hh k hk he
    have hm := hres h hh k hk
    change h%d=k%d at hm
    have ha := Nat.mod_add_div h d
    have hb := Nat.mod_add_div k d
    change h/d=k/d at he
    rw [hm,he] at ha
    omega
  have hsub : s.image (fun h=>h/d)⊆Finset.range (H/d+1) := by
    intro q hq
    obtain ⟨h,hh,rfl⟩ := Finset.mem_image.mp hq
    exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.div_le_div_right (Finset.mem_Icc.mp (hs hh)).2))
  calc
    s.card = (s.image (fun h=>h/d)).card := (Finset.card_image_of_injOn hinj).symm
    _ ≤ (Finset.range (H/d+1)).card := Finset.card_le_card hsub
    _ = _ := Finset.card_range _

theorem unit_shift_card_le (l d H : ℕ) (σ : ℤ) (hσ : σ=1 ∨ σ= -1) :
    ((Finset.Icc 1 H).filter (fun h : ℕ=>(d:ℤ)∣(l:ℤ)*(h:ℤ)+σ)).card≤H/d+1 := by
  apply residue_class_card_le _ H d (Finset.filter_subset _ _)
  intro h hh k hk
  exact unit_shift_residue_unique l d h k σ hσ
    (Finset.mem_filter.mp hh).2 (Finset.mem_filter.mp hk).2

theorem unit_shift_card_le_real (l d H : ℕ) (hd : 0<d) (σ : ℤ) (hσ : σ=1 ∨ σ= -1) :
    (((Finset.Icc 1 H).filter (fun h : ℕ=>(d:ℤ)∣(l:ℤ)*(h:ℤ)+σ)).card:ℝ)≤(H:ℝ)/d+1 := by
  have hh : (((Finset.Icc 1 H).filter (fun h : ℕ=>(d:ℤ)∣(l:ℤ)*(h:ℤ)+σ)).card:ℝ)≤(H/d:ℕ)+1 :=
    by exact_mod_cast unit_shift_card_le l d H σ hσ
  have hc : (H/d:ℕ)≤(H:ℝ)/d := Nat.cast_div_le
  linarith

/-- Deleting a largest one of four positive factors leaves a product
whose fourth power is at most the cube of the original number. -/
theorem largest_factor_deletion (a : Fin 4→ℕ) (n : ℕ)
    (ha : ∀i,0<a i) (hprod : (∏i,a i)=n) :
    ∃i : Fin 4, let d := ∏j : Fin 3,a (i.succAbove j)
      0<d ∧ a i*d=n ∧ d^4≤n^3 := by
  obtain ⟨i,_,hi⟩ := Finset.exists_max_image Finset.univ a Finset.univ_nonempty
  let d := ∏j : Fin 3,a (i.succAbove j)
  have hd : 0<d := Finset.prod_pos (fun j _=>ha _)
  have he : a i*d=n := (Fin.prod_univ_succAbove a i).symm.trans hprod
  have hb : d≤a i^3 := by
    calc
      d ≤ ∏_j : Fin 3,a i := Finset.prod_le_prod (fun j _=>hi _ (Finset.mem_univ _))
      _ = _ := by simp
  refine ⟨i,hd,he,?_⟩
  calc
    d^4 = d*d^3 := by ring
    _ ≤ a i^3*d^3 := Nat.mul_le_mul_right _ hb
    _ = n^3 := by rw [←mul_pow,he]

open DivisorFourFactors DivisorTripleSums

def shortDivisorTriples (n X D : ℕ) : Finset (Fin 3→ℕ) :=
  (shortTriples X D).filter (fun t=>(∏j,t j)∣n)

def reconstruct (n : ℕ) (i : Fin 4) (t : Fin 3→ℕ) : Fin 4→ℕ :=
  i.insertNth (n/(∏j,t j)) t

def insertedTriples (n X D : ℕ) : Finset (Fin 4→ℕ) :=
  Finset.univ.biUnion (fun i : Fin 4=>(shortDivisorTriples n X D).image (reconstruct n i))

/-- The largest-factor decomposition is a literal finite cover. -/
theorem fourFactors_subset_insertedTriples (n X D : ℕ) (hnX : n≤X) (hD : X^3≤D^4) :
    fourFactors n⊆insertedTriples n X D := by
  intro a ha
  have hm := (mem_fourFactors n a).mp ha
  obtain ⟨i,hd,he,hpow⟩ := largest_factor_deletion a n (fun j=>(hm.1 j).1) hm.2
  have hshort : (∏j : Fin 3,a (i.succAbove j))≤D :=
    (Nat.pow_le_pow_iff_left (by norm_num : (4:ℕ)≠0)).mp
      (hpow.trans ((Nat.pow_le_pow_left hnX 3).trans hD))
  have ht : i.removeNth a∈shortDivisorTriples n X D := by
    apply Finset.mem_filter.mpr
    refine ⟨(mem_shortTriples X D _).mpr ⟨?_,hshort⟩,?_⟩
    · intro j
      exact ⟨(hm.1 _).1,(hm.1 _).2.trans hnX⟩
    · exact ⟨a i,by simpa only [Fin.removeNth_apply,mul_comm] using he.symm⟩
  apply Finset.mem_biUnion.mpr
  refine ⟨i,Finset.mem_univ _,Finset.mem_image.mpr ⟨i.removeNth a,ht,?_⟩⟩
  have hn : n/(∏j,i.removeNth a j)=a i := by
    simp only [Fin.removeNth_apply]
    rw [←he,Nat.mul_div_cancel _ hd]
  unfold reconstruct
  rw [hn,Fin.insertNth_self_removeNth]

/-- All four-factor tuples are covered by four choices of deleted largest
factor and one short triple dividing the original integer. -/
theorem fourFactors_card_le_shortTriples (n X D : ℕ) (hnX : n≤X) (hD : X^3≤D^4) :
    (fourFactors n).card≤4*((shortTriples X D).filter (fun t=>(∏j,t j)∣n)).card := by
  calc
    (fourFactors n).card ≤ (insertedTriples n X D).card :=
      Finset.card_le_card (fourFactors_subset_insertedTriples n X D hnX hD)
    _ ≤ ∑i : Fin 4,((shortDivisorTriples n X D).image (reconstruct n i)).card := Finset.card_biUnion_le
    _ ≤ ∑_i : Fin 4,(shortDivisorTriples n X D).card := Finset.sum_le_sum (fun i _=>Finset.card_image_le)
    _ = _ := by simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul]; rfl

/-- Elementary divisor-square progression estimate, uniform in the
multiplier and in either unit shift. No divisor-moment input occurs. -/
theorem divisor_square_progression_bound (n : ℕ→ℕ) (l H X D : ℕ) (σ : ℤ)
    (hσ : σ=1 ∨ σ= -1) (hX : 1≤X) (hD : X^3≤D^4)
    (hnX : ∀h∈Finset.Icc 1 H,n h≤X)
    (hshift : ∀h∈Finset.Icc 1 H,(n h:ℤ)=(l:ℤ)*h+σ) :
    (∑h∈Finset.Icc 1 H,((n h).divisors.card:ℝ)^2)≤
      4*((H:ℝ)+D)*(1+Real.log (X:ℝ))^3 := by
  have hpoint (h : ℕ) (hh : h∈Finset.Icc 1 H) :
      ((n h).divisors.card:ℝ)^2≤
        4*∑t∈shortTriples X D,if (∏j,t j)∣n h then (1:ℝ) else 0 := by
    have hc := (divisor_square_le_fourFactors (n h)).trans
      (fourFactors_card_le_shortTriples (n h) X D (hnX h hh) hD)
    have he : (∑t∈shortTriples X D,if (∏j,t j)∣n h then (1:ℝ) else 0)=
        (((shortTriples X D).filter (fun t=>(∏j,t j)∣n h)).card:ℝ) := by simp
    rw [he]
    exact_mod_cast hc
  have hcount (t : Fin 3→ℕ) (ht : t∈shortTriples X D) :
      (∑h∈Finset.Icc 1 H,if (∏j,t j)∣n h then (1:ℝ) else 0)≤
        (H:ℝ)/((∏j,t j:ℕ):ℝ)+1 := by
    let d := ∏j,t j
    have hd : 0<d := Finset.prod_pos (fun j _=>((mem_shortTriples X D t).mp ht).1 j |>.1)
    have hsub : ((Finset.Icc 1 H).filter (fun h=>d∣n h))⊆
        ((Finset.Icc 1 H).filter (fun h : ℕ=>(d:ℤ)∣(l:ℤ)*(h:ℤ)+σ)) := by
      intro h hh
      have hm := Finset.mem_filter.mp hh
      refine Finset.mem_filter.mpr ⟨hm.1,?_⟩
      rw [←hshift h hm.1]
      exact_mod_cast hm.2
    have hc : ((((Finset.Icc 1 H).filter (fun h=>d∣n h)).card):ℝ)≤
        (((Finset.Icc 1 H).filter (fun h : ℕ=>(d:ℤ)∣(l:ℤ)*(h:ℤ)+σ)).card:ℝ) :=
      by exact_mod_cast Finset.card_le_card hsub
    have hh := hc.trans (unit_shift_card_le_real l d H hd σ hσ)
    simpa only [d,Finset.sum_boole] using hh
  calc
    _ ≤ ∑h∈Finset.Icc 1 H,4*∑t∈shortTriples X D,if (∏j,t j)∣n h then (1:ℝ) else 0 :=
      Finset.sum_le_sum hpoint
    _ = 4*∑t∈shortTriples X D,∑h∈Finset.Icc 1 H,if (∏j,t j)∣n h then (1:ℝ) else 0 := by
      rw [←Finset.mul_sum,Finset.sum_comm]
    _ ≤ 4*∑t∈shortTriples X D,((H:ℝ)/((∏j,t j:ℕ):ℝ)+1) :=
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum hcount) (by norm_num)
    _ ≤ _ := by
      have hb := progression_budget X D (H:ℝ) (Nat.cast_nonneg H)
      simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hb (by norm_num : (0:ℝ)≤4)

/-- Once the cofactor interval dominates the fourth-root threshold, the
finite estimate has the expected cofactor length times log cubed. -/
theorem divisor_square_progression_long (n : ℕ→ℕ) (l H X : ℕ) (σ : ℤ)
    (hσ : σ=1 ∨ σ= -1) (hX : 1≤X) (hscale : X^3≤H^4)
    (hnX : ∀h∈Finset.Icc 1 H,n h≤X)
    (hshift : ∀h∈Finset.Icc 1 H,(n h:ℤ)=(l:ℤ)*h+σ) :
    (∑h∈Finset.Icc 1 H,((n h).divisors.card:ℝ)^2)≤
      8*(H:ℝ)*(1+Real.log (X:ℝ))^3 := by
  have hb := divisor_square_progression_bound n l H X H σ hσ hX hscale hnX hshift
  convert hb using 1 <;> ring

/-- Literal successor-problem cofactor progression `l*h-1`. -/
theorem predecessor_progression_bound (l H X : ℕ) (hl : 1≤l) (hX : 1≤X)
    (hprod : l*H≤X) (hscale : X^3≤H^4) :
    (∑h∈Finset.Icc 1 H,((l*h-1).divisors.card:ℝ)^2)≤
      8*(H:ℝ)*(1+Real.log (X:ℝ))^3 := by
  apply divisor_square_progression_long (fun h=>l*h-1) l H X (-1) (Or.inr rfl) hX hscale
  · intro h hh
    exact (Nat.sub_le _ _).trans ((Nat.mul_le_mul_left l (Finset.mem_Icc.mp hh).2).trans hprod)
  · intro h hh
    have hp : 1≤l*h := Nat.mul_pos hl (Finset.mem_Icc.mp hh).1
    simp only [Nat.cast_sub hp,Nat.cast_mul,Nat.cast_one]
    ring

/-- The opposite unit shift is covered by the same proved estimate. -/
theorem successor_progression_bound (l H X : ℕ) (hX : 1≤X)
    (hprod : l*H+1≤X) (hscale : X^3≤H^4) :
    (∑h∈Finset.Icc 1 H,((l*h+1).divisors.card:ℝ)^2)≤
      8*(H:ℝ)*(1+Real.log (X:ℝ))^3 := by
  apply divisor_square_progression_long (fun h=>l*h+1) l H X 1 (Or.inl rfl) hX hscale
  · intro h hh
    exact (Nat.add_le_add_right (Nat.mul_le_mul_left l (Finset.mem_Icc.mp hh).2) 1).trans hprod
  · intro h hh
    simp

end Elliptic.Operator.SignedDivisorProgression
