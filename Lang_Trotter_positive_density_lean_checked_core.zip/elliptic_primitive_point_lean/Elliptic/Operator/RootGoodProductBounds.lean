module

public import Elliptic.Operator.RootTestEndpoints
public import Elliptic.Operator.SourceFirstGoodMeasure

/-! Elementary numeric bounds for every multiplier in the actual source
good-state tests. We enlarge to a single interval of integers; this avoids
charging the number of fresh tuples in either probability or boundary size. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGoodProductBounds
open scoped BigOperators
open SourceSecondGoodState RootTestEndpoints RootGoodBoundary
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K M : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]

theorem subtype_product_le (pred : Fin K → Prop) (f : {i // pred i} → ℕ)
    (Q : ℕ) (hQ : 1≤Q) (hf : ∀ i, f i≤Q) :
    (∏ i, f i) ≤ Q^K := by
  have hc : Fintype.card {i // pred i} ≤ K := by
    simpa using Fintype.card_le_of_injective (fun i : {i // pred i} => i.val) Subtype.val_injective
  exact (Finset.prod_le_pow_card Finset.univ f Q (fun i _ => hf i)).trans
    (by simpa using pow_le_pow_right' hQ hc)

theorem copiedProduct_le (label : Fin K × Fin M → ℕ) (Q : ℕ) (hQ : 1≤Q)
    (hl : ∀ ij, label ij≤Q) (o : Fin K → Fin M) :
    copiedProduct label o ≤ Q^(K*M) := by
  have hc : (retainedPrimes label o).card ≤ K*M := by
    unfold retainedPrimes
    apply Finset.card_image_le.trans
    simpa using Finset.card_le_univ
      (Finset.univ.filter (fun ij : Fin K × Fin M => ij.2 ≠ o ij.1))
  unfold copiedProduct
  exact (Finset.prod_le_pow_card _ id Q (fun p hp => by
    obtain ⟨ij,_,rfl⟩ := Finset.mem_image.mp hp
    exact hl ij)).trans (pow_le_pow_right' hQ hc)

theorem omissionProduct_le (label : Fin K × Fin M → ℕ) (Q : ℕ) (hQ : 1≤Q)
    (hl : ∀ ij, label ij≤Q) (d₀ : ℝ) (D : ℕ) (hD : D∈omissionProducts label d₀) :
    D ≤ Q^(K*M) := by
  obtain ⟨o,_,rfl⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hD).1
  exact copiedProduct_le label Q hQ hl o

theorem promotionProduct_le (value : ∀ i, P i → ℕ) (Q : ℕ) (hQ : 1≤Q)
    (hv : ∀ i p, value i p≤Q) (I : Finset (Fin K)) (i₀ : Fin K)
    (Z : ℕ) (hZ : Z∈promotionProducts value I i₀) : Z≤Q^K := by
  obtain ⟨p,_,rfl⟩ := Finset.mem_image.mp hZ
  convert subtype_product_le _ (fun i => value i.val (p i)) Q hQ (fun i => hv _ _) using 1
  apply Finset.prod_congr
  · ext i; simp
  · intro i hi; rfl

theorem trialProduct_le (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ)
    (Q : ℕ) (hQ : 1≤Q) (hv : ∀ i p, value i p≤Q) (hl : ∀ ij, label ij≤Q)
    (d₀ : ℝ) (I : Finset (Fin K)) (i₀ : Fin K)
    (A : ℕ) (hA : A∈trialProducts value label d₀ I i₀) : A≤Q^(K*M+K) := by
  obtain ⟨⟨D,Z⟩,h,rfl⟩ := Finset.mem_image.mp hA
  have h' := Finset.mem_product.mp h
  calc
    _ ≤ Q^(K*M)*Q^K := Nat.mul_le_mul
      (omissionProduct_le label Q hQ hl d₀ D h'.1)
      (promotionProduct_le value Q hQ hv I i₀ Z h'.2)
    _ = _ := (pow_add _ _ _).symm

/-- Every actual pair/fresh multiplier in every promoted configuration
lies in this one explicit integer interval. -/
theorem second_multiplier_bound (value : ∀ i, P i → ℕ)
    (label : Fin K × Fin M → ℕ) (Q : ℕ) (hQ : 1≤Q)
    (hv : ∀ i p, value i p≤Q) (hl : ∀ ij, label ij≤Q)
    (d₀ : ℝ) (I : Finset (Fin K)) (i₀ : Fin K)
    (f : ∀ i : {i // i∉I}, P i.val)
    (A B : ℕ) (hA : A∈trialProducts value label d₀ I i₀)
    (hB : B∈trialProducts value label d₀ I i₀) :
    |((A:ℤ)-(B:ℤ))*(freshPrimeTupleProduct (fun i : {i // i∉I} => value i.val) f:ℤ)|
      ≤ (Q^(K*M+2*K):ℤ) := by
  have ha := trialProduct_le value label Q hQ hv hl d₀ I i₀ A hA
  have hb := trialProduct_le value label Q hQ hv hl d₀ I i₀ B hB
  have hf : freshPrimeTupleProduct (fun i : {i // i∉I} => value i.val) f ≤ Q^K := by
    unfold freshPrimeTupleProduct
    convert subtype_product_le _ (fun i => value i.val (f i)) Q hQ (fun i => hv _ _) using 1
    apply Finset.prod_congr
    · ext i; simp
    · intro i hi; rfl
  have haZ : (A:ℤ) ≤ (Q:ℤ)^(K*M+K) := by exact_mod_cast ha
  have hbZ : (B:ℤ) ≤ (Q:ℤ)^(K*M+K) := by exact_mod_cast hb
  have hab : |(A:ℤ)-(B:ℤ)| ≤ (Q^(K*M+K):ℤ) := by
    rw [abs_le]
    constructor <;> omega
  rw [abs_mul,abs_of_nonneg (Int.natCast_nonneg _)]
  calc
    _ ≤ (Q^(K*M+K):ℤ)*(Q^K:ℤ) := mul_le_mul hab (by exact_mod_cast hf)
      (Int.natCast_nonneg _) (Int.natCast_nonneg _)
    _ = _ := by norm_cast; rw [←pow_add]; congr 1; omega

/-- The finite weighted second test is constant between a single family
of endpoints for every actual omission, promotion and fresh draw. -/
theorem secondGoodTest_constant
    (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ)
    (Q : ℕ) (hQ : 1≤Q) (hv : ∀ i p, value i p≤Q) (hl : ∀ ij, label ij≤Q)
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (R a b : ℝ) (eps : Finset ℝ) (μ : ∀ i, P i → ℝ) (d₀ L : ℝ) (exponents : Fin K → ℝ)
    (heps : ∀ i, 100*Real.exp (-(L^exponents i))∈eps)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w (Q^(K*M+2*K)) R eps, t∉Set.Icc a b)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    SecondGoodTest value label μ d₀ (phase z w r) L exponents ↔
      SecondGoodTest value label μ d₀ (phase z w s) L exponents := by
  unfold SecondGoodTest
  have he (I : Finset (Fin K)) (i₀ : Fin K) :=
    exceptionalMass_constant z w hzw (Q^(K*M+2*K)) R a b eps hpole hbound hends
      (trialProducts value label d₀ I i₀)
      (fun i : {i // i∉I} => value i.val) (fun i : {i // i∉I} => μ i.val)
      (100*Real.exp (-(L^exponents i₀))) (heps i₀)
      (fun f A hA B hB => second_multiplier_bound value label Q hQ hv hl d₀ I i₀ f A B hA hB)
      r s hr hs
  simp_rw [he]

theorem first_multiplier_bound (label : Fin K × Fin M → ℕ)
    (Q : ℕ) (hQ : 1≤Q) (hl : ∀ ij, label ij≤Q) (d₀ Y : ℝ)
    (hY : Y^(1/5:ℝ) ≤ (Q^(2*K):ℝ)) (D : ℕ) (hD : D∈omissionProducts label d₀)
    (l : ℤ) (hlpos : 0<l) (hlcut : (l:ℝ)≤Y^(1/5:ℝ)) :
    |l*(D:ℤ)| ≤ (Q^(K*M+2*K):ℤ) := by
  have hdZ : (D:ℤ) ≤ (Q:ℤ)^(K*M) := by
    exact_mod_cast omissionProduct_le label Q hQ hl d₀ D hD
  have hlZ : l ≤ (Q:ℤ)^(2*K) := by exact_mod_cast hlcut.trans hY
  rw [abs_of_nonneg (mul_nonneg hlpos.le (Int.natCast_nonneg _))]
  calc
    _ ≤ (Q:ℤ)^(2*K)*(Q:ℤ)^(K*M) :=
      mul_le_mul hlZ hdZ (Int.natCast_nonneg _) (by positivity)
    _ = _ := by rw [←pow_add]; congr 1; omega

theorem firstGoodTest_constant
    (label : Fin K × Fin M → ℕ) (Q : ℕ) (hQ : 1≤Q) (hl : ∀ ij, label ij≤Q)
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (R a b : ℝ) (eps : Finset ℝ) (d₀ Y : ℝ)
    (hY : Y^(1/5:ℝ) ≤ (Q^(2*K):ℝ)) (heps : Y^(-(7/10):ℝ)∈eps)
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w (Q^(K*M+2*K)) R eps, t∉Set.Icc a b)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    (∀ D∈omissionProducts label d₀, SourceGoodState.NoSmallMultiple
      ((D:ℝ)*phase z w r) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) ↔
    (∀ D∈omissionProducts label d₀, SourceGoodState.NoSmallMultiple
      ((D:ℝ)*phase z w s) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) := by
  simp_rw [SourceGoodState.noSmallMultiple_iff_positive]
  have he (D : ℕ) (hD : D∈omissionProducts label d₀)
      (l : ℤ) (hlpos : 0<l) (hlcut : (l:ℝ)≤Y^(1/5:ℝ)) :=
    circle_lt_constant z w hzw (Q^(K*M+2*K)) R a b eps hpole hbound hends
      (l*(D:ℤ)) (first_multiplier_bound label Q hQ hl d₀ Y hY D hD l hlpos hlcut)
      (Y^(-(7/10):ℝ)) heps r s hr hs
  simp only [Int.cast_mul,Int.cast_natCast,mul_assoc] at he
  constructor
  · intro hg D hD l hlpos hlcut
    exact (he D hD l hlpos hlcut).mp (hg D hD l hlpos hlcut)
  · intro hg D hD l hlpos hlcut
    exact (he D hD l hlpos hlcut).mpr (hg D hD l hlpos hlcut)

def radii (K : ℕ) (Y L : ℝ) (a : Fin K → ℝ) : Finset ℝ :=
  insert (Y^(-(7/10):ℝ)) (Finset.univ.image fun i => 100*Real.exp (-(L^a i)))

theorem radii_card (K : ℕ) (Y L : ℝ) (a : Fin K → ℝ) :
    (radii K Y L a).card ≤ K+1 := by
  unfold radii
  exact (Finset.card_insert_le _ _).trans (Nat.add_le_add_right
    (Finset.card_image_le.trans (by simp)) 1)

theorem radii_le (K : ℕ) (Y L : ℝ) (a : Fin K → ℝ)
    (hY : 1≤Y) (hL : 0≤L) (ε : ℝ) (hε : ε∈radii K Y L a) : ε≤100 := by
  rcases Finset.mem_insert.mp hε with rfl|hε
  · have hh : Y^(-(7/10):ℝ)≤1 := Real.rpow_le_one_of_one_le_of_nonpos hY (by norm_num)
    linarith
  · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hε
    have hh : Real.exp (-(L^a i))≤1 := Real.exp_le_one_iff.mpr (by
      have hp := Real.rpow_nonneg hL (a i); linarith)
    linarith

/-- Both literal source tests, including the finite weighted exceptional
condition, are constant away from the universal endpoint family. -/
theorem bothGoodTests_constant
    (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ)
    (Q : ℕ) (hQ : 1≤Q) (hv : ∀ i p, value i p≤Q) (hl : ∀ ij, label ij≤Q)
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (R a b : ℝ) (μ : ∀ i, P i → ℝ) (d₀ Y L : ℝ) (exponents : Fin K → ℝ)
    (hY : Y^(1/5:ℝ) ≤ (Q^(2*K):ℝ))
    (hpole : ∀ t∈Set.Icc a b, latticeTau t z≠0)
    (hbound : ∀ t∈Set.Icc a b, |phase z w t|≤R)
    (hends : ∀ t∈endpoints z w (Q^(K*M+2*K)) R (radii K Y L exponents), t∉Set.Icc a b)
    (r s : ℝ) (hr : r∈Set.Icc a b) (hs : s∈Set.Icc a b) :
    ((∀ D∈omissionProducts label d₀, SourceGoodState.NoSmallMultiple
      ((D:ℝ)*phase z w r) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) ∧
      SecondGoodTest value label μ d₀ (phase z w r) L exponents) ↔
    ((∀ D∈omissionProducts label d₀, SourceGoodState.NoSmallMultiple
      ((D:ℝ)*phase z w s) (Y^(1/5:ℝ)) (Y^(-(7/10):ℝ))) ∧
      SecondGoodTest value label μ d₀ (phase z w s) L exponents) := by
  apply and_congr
  · exact firstGoodTest_constant label Q hQ hl z w hzw R a b
      (radii K Y L exponents) d₀ Y hY (by simp [radii]) hpole hbound hends r s hr hs
  · exact secondGoodTest_constant value label Q hQ hv hl z w hzw R a b
      (radii K Y L exponents) μ d₀ L exponents (fun i => by simp [radii])
      hpole hbound hends r s hr hs

end Elliptic.Operator.RootGoodProductBounds
