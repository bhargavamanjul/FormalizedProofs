module

public import Elliptic.Operator.SignedDamping
public import Mathlib.Analysis.SpecificLimits.Basic

/-! Uniform bounds and exact exceptional support for the actual damping
replacement. These estimates hold for arbitrary bounded coefficient families
and invariant selectors; no constant depends on their values. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDampingBounds
open scoped BigOperators
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDamping
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

theorem count_damping_le (q : ℝ) (hq : 0≤q) (hq1 : q<1) (n : ℕ) :
    (n:ℝ)*q^(n-1) ≤ (1-q)⁻¹ := by
  calc
    _ = ∑ j∈Finset.range n,q^(n-1) := by simp
    _ ≤ ∑ j∈Finset.range n,q^j := by
      apply Finset.sum_le_sum
      intro j hj
      exact pow_le_pow_of_le_one hq hq1.le (by have := Finset.mem_range.mp hj; omega)
    _ ≤ ∑' j : ℕ,q^j := (summable_geometric_of_lt_one hq hq1).sum_le_tsum _ (fun _ _=>pow_nonneg hq _)
    _ = _ := tsum_geometric_of_lt_one hq hq1

def weightBound (b : Bands K) (q x : ℝ) : ℝ :=
  ∏ i : Fin K, (1-q)⁻¹/b.mass x i

theorem markedWeight_bound (b : Bands K) (q x : ℝ) (hq : 0≤q) (hq1 : q<1)
    (hV : ∀i,0≤b.mass x i) (n : ℕ) :
    0≤markedWeight b q x n ∧ markedWeight b q x n≤weightBound b q x := by
  constructor
  · exact Finset.prod_nonneg (fun i _=>div_nonneg (mul_nonneg (Nat.cast_nonneg _) (pow_nonneg hq _)) (hV i))
  · apply Finset.prod_le_prod₀
    · intro i _
      exact div_nonneg (mul_nonneg (Nat.cast_nonneg _) (pow_nonneg hq _)) (hV i)
    · intro i _
      exact div_le_div_of_nonneg_right (count_damping_le q hq hq1 _) (hV i)

def replacedWeight (b : Bands K) (q x : ℝ) (n : ℕ) : ℝ :=
  ∑ p : LabelTuple b x, if Divides b x p n then
    cofactorDamping b q x (n/labelProduct b x p) else 0

def squareException (b : Bands K) (x : ℝ) (n : ℕ) : Prop :=
  ∃ i : Fin K, ∃ p∈b.group x i,p^2∣n

theorem replacedWeight_bounds (b : Bands K) (q x : ℝ) (n : ℕ) (hn : 0<n)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hq : 0≤q) (hq1 : q≤1) (hV : ∀i,0≤b.mass x i) :
    0≤replacedWeight b q x n ∧ replacedWeight b q x n≤markedWeight b q x n := by
  constructor
  · apply Finset.sum_nonneg
    intro p _
    split_ifs
    · exact Finset.prod_nonneg (fun i _=>div_nonneg (pow_nonneg hq _) (hV i))
    · exact le_rfl
  · rw [markedWeight_eq_labels b q x n hn.ne']
    apply Finset.sum_le_sum
    intro p _
    split_ifs with hp
    · exact cofactorDamping_le_damping b q x p hdisjoint n hn hp hq hq1 hV
    · exact le_rfl

theorem replacedWeight_eq_of_no_square (b : Bands K) (q x : ℝ) (n : ℕ) (hn : 0<n)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hsq : ¬squareException b x n) :
    replacedWeight b q x n=markedWeight b q x n := by
  rw [markedWeight_eq_labels b q x n hn.ne']
  apply Finset.sum_congr rfl
  intro p _
  split_ifs with hp
  · exact (damping_eq_cofactorDamping b q x p hdisjoint n hn hp
      (fun i hi=>hsq ⟨i,(p i).val,(p i).property,hi⟩)).symm
  · rfl

theorem replacement_error (b : Bands K) (q x : ℝ) (n : ℕ) (hn : 0<n)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hq : 0≤q) (hq1 : q<1) (hV : ∀i,0≤b.mass x i) :
    |markedWeight b q x n-replacedWeight b q x n| ≤
      if squareException b x n then weightBound b q x else 0 := by
  by_cases hs : squareException b x n
  · rw [if_pos hs,abs_of_nonneg (sub_nonneg.mpr (replacedWeight_bounds b q x n hn hdisjoint hq hq1.le hV).2)]
    exact (sub_le_self _ (replacedWeight_bounds b q x n hn hdisjoint hq hq1.le hV).1).trans
      (markedWeight_bound b q x hq hq1 hV n).2
  · rw [if_neg hs,replacedWeight_eq_of_no_square b q x n hn hdisjoint hs,sub_self,abs_zero]

/-- The complete bilinear damping error is supported on the actual
prime-square exceptional set, with a constant independent of F, alpha, beta. -/
theorem bilinear_replacement_error (b : Bands K) (q x : ℝ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (A B : ℝ)
    (hα : ∀m∈s,‖α m‖≤A) (hβ : ∀n∈t,‖β n‖≤B)
    (hF : ∀n,‖F n‖≤1)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hq : 0≤q) (hq1 : q<1) (hV : ∀i,0≤b.mass x i) :
    ‖Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))-
      Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ))‖ ≤
      A*B*weightBound b q x * (((s×ˢt).filter (fun mn=>squareException b x (mn.1*mn.2+1))).card:ℝ) := by
  have hw : 0≤weightBound b q x := Finset.prod_nonneg (fun i _=>div_nonneg (inv_nonneg.mpr (by linarith)) (hV i))
  have he : Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))-
      Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ)) =
      ∑ mn∈s×ˢt, α mn.1*β mn.2*F (mn.1*mn.2+1)*
        ((markedWeight b q x (mn.1*mn.2+1)-replacedWeight b q x (mn.1*mn.2+1):ℝ):ℂ) := by
    unfold Sieve.SignedReplacement.bilinear
    rw [Finset.sum_product,←Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro m _
    rw [←Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro n _
    push_cast
    ring
  rw [he]
  calc
    _ ≤ ∑ mn∈s×ˢt,‖α mn.1*β mn.2*F (mn.1*mn.2+1)*
        ((markedWeight b q x (mn.1*mn.2+1)-replacedWeight b q x (mn.1*mn.2+1):ℝ):ℂ)‖ := norm_sum_le _ _
    _ ≤ ∑ mn∈s×ˢt, if squareException b x (mn.1*mn.2+1) then A*B*weightBound b q x else 0 := by
      apply Finset.sum_le_sum
      intro mn hmn
      obtain ⟨hm,hn⟩ := Finset.mem_product.mp hmn
      have hAB : 0≤A*B := mul_nonneg ((norm_nonneg _).trans (hα _ hm)) ((norm_nonneg _).trans (hβ _ hn))
      have hco : ‖α mn.1*β mn.2*F (mn.1*mn.2+1)‖ ≤ A*B := by
        simp only [norm_mul]
        calc
          _ ≤ A*B*1 := mul_le_mul
            (mul_le_mul (hα _ hm) (hβ _ hn) (norm_nonneg _) ((norm_nonneg _).trans (hα _ hm)))
            (hF _) (norm_nonneg _) hAB
          _ = _ := mul_one _
      rw [norm_mul,Complex.norm_real,Real.norm_eq_abs]
      have herr := replacement_error b q x (mn.1*mn.2+1) (by omega) hdisjoint hq hq1 hV
      by_cases hs : squareException b x (mn.1*mn.2+1)
      · rw [if_pos hs] at herr ⊢
        exact mul_le_mul hco herr (abs_nonneg _) hAB
      · rw [if_neg hs] at herr ⊢
        have hz := le_antisymm herr (abs_nonneg _)
        rw [hz,mul_zero]
    _ = _ := by rw [←Finset.sum_filter]; simp [mul_comm]

end Elliptic.Operator.SignedDampingBounds
