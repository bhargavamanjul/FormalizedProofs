module

public import Elliptic.Operator.RootLiteralGeometry

/-!
# The first-test multiplier bound follows from the source cutoff

The support convention is eta(t) nonzero only for t at least one half.
Every nonzero edge therefore has Y at most twice its unshared prime
product. This supplies the elementary multiplier-ceiling restriction;
outside that range the literal geometric multiplier is zero.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootSourceScale
open RootLiteralGeometry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem unsharedProduct_le (value : ∀i,P i→ℕ) (Q : ℕ) (hv : ∀i p,value i p≤Q)
    (a : PhysicalActiveLists P J) : sourceUnsharedProduct value a≤Q^K := by
  unfold sourceUnsharedProduct
  simpa using Finset.prod_le_pow_card Finset.univ
    (fun i=>value i (a i (Fin.last J))) Q (fun i _=>hv i _)

theorem first_multiplier_scale (K Q : ℕ) (hK : 1≤K) (hQ : 2≤Q)
    (Y : ℝ) (hY : 1≤Y) (hupper : Y≤2*(Q^K:ℝ)) :
    Y^(1/5:ℝ)≤(Q^(2*K):ℝ) := by
  have hQ1 : 1≤Q := by omega
  have h2 : 2≤Q^K := hQ.trans (by simpa using pow_le_pow_right' hQ1 hK)
  have h2R : (2:ℝ)≤(Q:ℝ)^K := by exact_mod_cast h2
  have hp : Y^(1/5:ℝ)≤Y := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hY
      (by norm_num : (1/5:ℝ)≤1)
  apply hp.trans
  rw [show 2*K=K*2 by omega,pow_mul]
  nlinarith

theorem cutoff_nonzero_scale (value : ∀i,P i→ℕ) (Q : ℕ)
    (hK : 1≤K) (hQ : 2≤Q) (hv : ∀i p,value i p≤Q)
    (Y : ℝ) (hY : 1≤Y) (η : ℝ→ℂ) (hsupport : ∀t,η t≠0→1/2≤t)
    (a : PhysicalActiveLists P J) (hη : η ((sourceUnsharedProduct value a:ℝ)/Y)≠0) :
    Y^(1/5:ℝ)≤(Q^(2*K):ℝ) := by
  have hYpos : 0<Y := by linarith
  have hlow := (le_div_iff₀ hYpos).mp (hsupport _ hη)
  have hprod : (sourceUnsharedProduct value a:ℝ)≤(Q^K:ℝ) :=
    by exact_mod_cast unsharedProduct_le value Q hv a
  exact first_multiplier_scale K Q hK hQ Y hY (by linarith)

/-- Failure of the numerical first-test bound makes every literal edge
zero, for every root point, even before imposing the physical box. -/
theorem geometry_eq_zero_of_scale (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (Q : ℕ) (hK : 1≤K) (hQ : 2≤Q) (hv : ∀i p,value i p≤Q)
    (U V d₀ Y L : ℝ) (hY : 1≤Y) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (hsupport : ∀t,η t≠0→1/2≤t) (hscale : ¬Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (major : Set ProductCircle) (σ : ℤ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) (w : ℤ×ℤ) (b : PhysicalActiveLists P J)
    (q : RootPhysicalCell.RootPoint) :
    geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b q=0 := by
  have he (a : PhysicalActiveLists P J) : η ((sourceUnsharedProduct value a:ℝ)/Y)=0 := by
    by_contra hn
    exact hscale (cutoff_nonzero_scale value Q hK hQ hv Y hY η hsupport a hn)
  cases adjoint <;> simp [geometry,orientedSourceEdgeGeometry,sourcePhysicalEdgeGeometry,he]

end Elliptic.Operator.RootSourceScale
