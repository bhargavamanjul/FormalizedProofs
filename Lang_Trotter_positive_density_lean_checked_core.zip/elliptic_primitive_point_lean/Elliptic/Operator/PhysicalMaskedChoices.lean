module

public import Elliptic.Operator.PhysicalMaskedKernel

/-!
# Literal indexed choices for the masked physical bag kernel

All indices and all endpoint damping factors are retained. The finite
kernel identities hold for arbitrary coupled functions on output bags.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskedChoices
open scoped BigOperators
open PhysicalEdgeAdjoint
attribute [local instance] Classical.propDecidable
local instance maskedChoicesDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {P : Type*} [Fintype P] {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}

/-- Exact masked local coefficient, with both actual indexed hit counts. -/
def localCoefficient {R : Type*} [Field R]
    (ν : P → R) (store promote : R) (S I : Bool) (ρ : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m) : R :=
  if hc : EdgeGroupChoice.Valid targetAnchor m c then
    if c.1 = S ∧ edgeChoicePromotes c = I then
      store ^ c.1.toNat * (match c.2 with | .inl _ => promote | .inr p => ν p) *
        ρ ^ (memoryHits sourceAnchor m).card *
        ρ ^ (memoryHits targetAnchor (edgeGroupOutput sourceAnchor source m c hc.2)).card
    else 0
  else 0

/-- Exact one-group matrix coefficient as the literal indexed sum. -/
theorem local_kernel_eq_choices {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R) (S I : Bool) (ρ : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (t : EdgeBagOutput (P:=P) (Line:=Line) (B:=B)) :
    maskedDampedBagKernel ν store promote S I sourceAnchor targetAnchor source t.1
      (bagSurvival sourceAnchor ρ) (bagSurvival targetAnchor ρ) (memoryBagOf m) t.2 =
    ∑ c : EdgeGroupChoice m, localCoefficient ν store promote S I ρ sourceAnchor targetAnchor source m c *
      (if localOutput sourceAnchor targetAnchor source m c = t then 1 else 0) := by
  rw [maskedDampedBagKernel_eq_indexed ν hν]
  unfold dampedMaskedFixedTargetApply maskedFixedTargetApply
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : EdgeGroupChoice.Valid targetAnchor m c
  · rcases t with ⟨q,b⟩
    simp only [dite_eq_left hc,localCoefficient,localOutput,Prod.mk.injEq,
      Subtype.ext_iff,memoryBagOf,bagSurvival_tupleBag_eq_hits]
    by_cases hm : c.1 = S ∧ edgeChoicePromotes c = I
    · by_cases hq : edgeTargetPrime m c = q
      · by_cases hb : tupleBag (edgeGroupOutput sourceAnchor source m c hc.2).values = b.val
        · simp only [hm,hq,hb,true_and,ite_true,mul_one]
          ac_rfl
        · simp [hm,hq,hb]
      · simp [hm,hq]
    · simp [hm]
  · simp [hc,localCoefficient,localOutput]

variable {G : Type*} [Fintype G]
variable {Q : G → Type*} [∀ i, Fintype (Q i)]
variable {Lines : ∀ i, Q i → Type*} [∀ i p, Fintype (Lines i p)]

/-- Exact grouped indexed mask sum on arbitrary coupled output tests. -/
def groupedApply {R : Type*} [Field R]
    (ν : ∀ i, Q i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p) (source : ∀ i, Q i)
    (F : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B) → R)
    (m : PhysicalMemories Q Lines B) : R :=
  ∑ c : ∀ i, EdgeGroupChoice (m i),
    (∏ i, localCoefficient (ν i) (store i) (promote i) (S i) (I i) ρ
      (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i)) *
    F (fun i => localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i))

theorem groupedApply_eq_kernel {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p) (source : ∀ i, Q i)
    (F : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B) → R)
    (m : PhysicalMemories Q Lines B) :
    groupedApply ν store promote S I ρ sourceAnchor targetAnchor source F m =
      ∑ t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B),
        groupedMaskedBagKernel ν store promote S I sourceAnchor targetAnchor
          (fun i => bagSurvival (sourceAnchor i) ρ) (fun i => bagSurvival (targetAnchor i) ρ)
          (fun i => (source i,memoryBagOf (m i))) t * F t := by
  unfold groupedMaskedBagKernel
  simp_rw [local_kernel_eq_choices _ (hν _), Fintype.prod_sum, Finset.sum_mul]
  rw [Finset.sum_comm]
  unfold groupedApply
  apply Finset.sum_congr rfl
  intro c _
  simp_rw [Finset.prod_mul_distrib]
  have hδ (t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B)) :
      (∏ i, if localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i) = t i
        then (1:R) else 0) =
        if (fun i => localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i)) = t then 1 else 0 := by
    rw [Finset.prod_ite_zero]
    simp only [Finset.mem_univ,forall_true_left,Finset.prod_const_one,funext_iff]
  simp_rw [hδ]
  simp [mul_ite]

variable {Z : Type*} {J : ℕ}

/-- The literal full masked indexed action. The output is the actual physical
state, and local hit validity and the single total cutoff are tested explicitly. -/
def physicalApply [Fintype Z] {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → R)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → R)
    (s : PhysicalMemoryState (Z:=Z) Q Lines J B) : R :=
  ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    (Fintype.card (PhysicalMaskedKernel.Permutations (G:=G) (J:=J)) : R)⁻¹ ^ 2 *
      geometry (s.position Q Lines J B) c.sourceLists c.target c.targetLists *
      (∏ i, localCoefficient (ν i) (store i) (promote i) (S i) (I i) ρ
        (anchor (s.position Q Lines J B) i) (anchor c.target i) (c.sourcePrime i)
        (s.memory Q Lines J B i) (c.group i)) *
      F (PhysicalMaskedKernel.ofOrdered (c.output anchor s hc))
  else 0

/-- The complete output test, including target permutation and total cutoff. -/
def compressedTest {R : Type*} [Field R]
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → R)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → R)
    (sourceZ targetZ : Z) (a : PhysicalActiveLists Q J)
    (σ τ : PhysicalMaskedKernel.Permutations (G:=G) (J:=J))
    (t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B)) : R :=
  geometry sourceZ (fun i j => a i (σ i j)) targetZ
    (PhysicalEdgeAdjoint.targetLists a σ (fun i => (t i).1)) *
    if (∑ i, (t i).2.val.card) ≤ B then
      F (targetZ, (fun i j => PhysicalEdgeAdjoint.targetLists a σ
        (fun i => (t i).1) i (τ i j)), fun i => (t i).2)
    else 0

/-- Exact coefficient-and-output identity for one literal masked physical choice. -/
theorem choice_eq_compressed {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → R)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → R)
    (s : PhysicalMemoryState (Z:=Z) Q Lines J B) (z : Z)
    (σ τ : PhysicalMaskedKernel.Permutations (G:=G) (J:=J))
    (c : ∀ i, EdgeGroupChoice (s.memory Q Lines J B i)) :
    (let e : PhysicalEdgeChoice s := (z,σ,c,τ)
      if hc : e.Valid anchor s then
        geometry (s.position Q Lines J B) e.sourceLists e.target e.targetLists *
        (∏ i, localCoefficient (ν i) (store i) (promote i) (S i) (I i) ρ
          (anchor (s.position Q Lines J B) i) (anchor e.target i) (e.sourcePrime i)
          (s.memory Q Lines J B i) (e.group i)) *
        F (PhysicalMaskedKernel.ofOrdered (e.output anchor s hc))
      else 0) =
    (∏ i, localCoefficient (ν i) (store i) (promote i) (S i) (I i) ρ
      (anchor (s.position Q Lines J B) i) (anchor z i)
      (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i)) *
      compressedTest geometry F (s.position Q Lines J B) z (s.active Q Lines J B) σ τ
        (fun i => localOutput (anchor (s.position Q Lines J B) i) (anchor z i)
          (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i)) := by
  let e : PhysicalEdgeChoice s := (z,σ,c,τ)
  change (if hc : e.Valid anchor s then _ else 0) = _
  by_cases hl : ∀ i, EdgeGroupChoice.Valid (anchor z i) (s.memory Q Lines J B i) (c i)
  · have hout : (fun i => localOutput (anchor (s.position Q Lines J B) i) (anchor z i)
        (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i)) =
        fun i => (edgeTargetPrime (s.memory Q Lines J B i) (c i),
          memoryBagOf (edgeGroupOutput (anchor (s.position Q Lines J B) i)
            (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i) (hl i).2)) := by
      funext i
      simp only [localOutput,dite_eq_left (hl i)]
    rw [hout]
    unfold compressedTest
    simp only [memoryBagOf_card,edgeGroupOutput_size]
    by_cases ht : (∑ i, edgeGroupOutputSize (c i)) ≤ B
    · have hv : e.Valid anchor s := ⟨hl,ht⟩
      rw [dite_eq_left hv,ite_eq_left ht]
      have ho : PhysicalMaskedKernel.ofOrdered (e.output anchor s hv) =
          (z, (fun i j => PhysicalEdgeAdjoint.targetLists (s.active Q Lines J B) σ
            (fun i => edgeTargetPrime (s.memory Q Lines J B i) (c i)) i (τ i j)),
          fun i => memoryBagOf (edgeGroupOutput (anchor (s.position Q Lines J B) i)
            (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i) (hl i).2)) := rfl
      rw [ho]
      change _ * _ * _ = _ * (_ * _)
      ac_rfl
    · have hv : ¬ e.Valid anchor s := fun h => ht h.2
      rw [dite_eq_right hv,ite_eq_right ht]
      simp
  · obtain ⟨i,hi⟩ := not_forall.mp hl
    have hv : ¬ e.Valid anchor s := fun h => hi (h.1 i)
    have hz : (∏ i, localCoefficient (ν i) (store i) (promote i) (S i) (I i) ρ
        (anchor (s.position Q Lines J B) i) (anchor z i)
        (s.active Q Lines J B i (σ i (Fin.last J))) (s.memory Q Lines J B i) (c i)) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i) (by simp [localCoefficient,hi])
    rw [dite_eq_right hv,hz,zero_mul]

/-- Literal endpoint-averaged indexed action as a grouped bag transfer. -/
theorem physicalApply_eq_grouped [Fintype Z] {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → R)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → R)
    (s : PhysicalMemoryState (Z:=Z) Q Lines J B) :
    physicalApply ν store promote S I ρ anchor geometry F s =
      (Fintype.card (PhysicalMaskedKernel.Permutations (G:=G) (J:=J)) : R)⁻¹ ^ 2 *
      ∑ z : Z, ∑ σ : PhysicalMaskedKernel.Permutations (G:=G) (J:=J),
        ∑ τ : PhysicalMaskedKernel.Permutations (G:=G) (J:=J),
          ∑ t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B),
            groupedMaskedBagKernel ν store promote S I (anchor (s.position Q Lines J B)) (anchor z)
              (fun i => bagSurvival (anchor (s.position Q Lines J B) i) ρ)
              (fun i => bagSurvival (anchor z i) ρ)
              (fun i => (s.active Q Lines J B i (σ i (Fin.last J)),memoryBagOf (s.memory Q Lines J B i))) t *
            compressedTest geometry F (s.position Q Lines J B) z (s.active Q Lines J B) σ τ t := by
  simp_rw [← groupedApply_eq_kernel ν hν]
  unfold physicalApply groupedApply
  simp only [Fintype.sum_prod_type,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro z _
  apply Finset.sum_congr rfl
  intro σ _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro τ _
  apply Finset.sum_congr rfl
  intro c _
  have h := choice_eq_compressed ν store promote S I ρ anchor geometry F s z σ τ c
  by_cases hv : (PhysicalEdgeChoice.Valid anchor s (z,σ,c,τ))
  · simp only [dite_eq_left hv] at h ⊢
    rw [← h]
    ring
  · simp only [dite_eq_right hv] at h ⊢
    rw [← h,mul_zero]

/-- At the original normalization, a valid selected local coefficient is
exactly the original edge coefficient, including both endpoint hit counts. -/
theorem localCoefficient_original (ν : P → ℝ) (V ρ : ℝ) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : EdgeGroupChoice.Valid targetAnchor m c)
    (hm : c.1=S ∧ edgeChoicePromotes c=I) :
    localCoefficient (fun p => (ν p : ℂ)) 1 (V:ℂ)⁻¹ S I (ρ:ℂ)
      sourceAnchor targetAnchor source m c =
    (edgeGroupWeight ν V ρ sourceAnchor targetAnchor source m c hc.2 : ℂ) := by
  unfold localCoefficient edgeGroupWeight edgeTargetWeight
  rw [dite_eq_left hc,ite_eq_left hm]
  cases h : c.2 <;> simp only [one_pow,one_mul,Complex.ofReal_mul,Complex.ofReal_pow,Complex.ofReal_inv] <;> ac_rfl

/-- The exact suboperator of the original physical edge selected by the
specified store and promotion masks. -/
def originalMaskedApply [Fintype Z]
    (ν : ∀ i, Q i → ℝ) (V : G → ℝ) (S I : G → Bool) (ρ : ℝ)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → ℂ)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → ℂ)
    (s : PhysicalMemoryState (Z:=Z) Q Lines J B) : ℂ :=
  ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    if ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i then
      physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc *
        F (PhysicalMaskedKernel.ofOrdered (c.output anchor s hc))
    else 0
  else 0

/-- Literal identification with the original masked physical suboperator.
This keeps its normalization 1 for stores and 1/V for promotions. -/
theorem physicalApply_original [Fintype Z]
    (ν : ∀ i, Q i → ℝ) (V : G → ℝ) (S I : G → Bool) (ρ : ℝ)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → ℂ)
    (F : PhysicalMaskedKernel.State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B) → ℂ)
    (s : PhysicalMemoryState (Z:=Z) Q Lines J B) :
    physicalApply (fun i p => (ν i p:ℂ)) (fun _ => 1) (fun i => (V i:ℂ)⁻¹)
      S I (ρ:ℂ) anchor geometry F s = originalMaskedApply ν V S I ρ anchor geometry F s := by
  unfold physicalApply originalMaskedApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : c.Valid anchor s
  · simp only [dite_eq_left hc]
    by_cases hm : ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i
    · rw [ite_eq_left hm]
      simp_rw [localCoefficient_original _ _ _ _ _ _ _ _ _ _ (hc.1 _) (hm _)]
      simp only [physicalEdgeChoiceWeight,endpointPermutationWeight,Complex.ofReal_pow,
        Complex.ofReal_inv,Complex.ofReal_natCast,PhysicalMaskedKernel.Permutations]
    · rw [ite_eq_right hm]
      obtain ⟨i,hi⟩ := not_forall.mp hm
      have hz : (∏ i, localCoefficient (fun p => (ν i p:ℂ)) 1 (V i:ℂ)⁻¹
          (S i) (I i) (ρ:ℂ) (anchor (s.position Q Lines J B) i)
          (anchor c.target i) (c.sourcePrime i) (s.memory Q Lines J B i) (c.group i)) = 0 :=
        Finset.prod_eq_zero (Finset.mem_univ i) (by
          simp only [localCoefficient,dite_eq_left (hc.1 i),ite_eq_right hi])
      rw [hz,mul_zero,zero_mul]
  · simp only [dite_eq_right hc]

end Elliptic.Operator.PhysicalMaskedChoices
