module

public import Elliptic.Operator.RootRecordAccumulation

/-! # Uniform replacement of actual positive gap monomials

No geometric multiplier is inserted in the positive gap. The full root
box is counted directly; the literal original record/subset mass is then
absorbed. This is the separate positive transfer needed by Bonferroni.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootConstantAccumulation
open Filter SourceRootCount SourceRootTransfer RootGridPartition RootRecordAccumulation
open OriginalPathWeights RootDiscreteBudget IntegerRootReplacement
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- One bounded test on the actual full canonical root box. -/
theorem eventually_full_box (hPD : RootCountContract) (δ C_S : ℝ)
    (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ U V : ℝ, ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ,
      (∀g,‖ρ g‖≤1) →
      ‖weightedRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) ρ -
        (rootVolume U V (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1):ℂ)*
          ((∑g,ρ g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ))‖ ≤
        U*V*x^(-(δ/32000)) := by
  filter_upwards [RootBoxFamily.eventually_bounded_box_family hPD δ C_S hδ hCS,
    eventually_ge_atTop (1:ℝ)] with x hx hx1
  intro U V S inst hU hU' hV hV' hS hsq hmod ρ hρ
  have hc : (({0}:Finset ℕ).card:ℝ)≤x^(δ/2000) := by
    simpa using Real.one_le_rpow hx1 (show 0≤δ/2000 by positivity)
  have h := hx ℕ {0} U V (fun _=>S) hU hU' hV hV' hc
    (fun _=>fullInterval 1 16) (fun _=>fullInterval 1 2) (fun _=>fullInterval 0 1)
    (fun _ _=>⟨hS,hsq,hmod,by norm_num [fullInterval,RootInterval.InRange],
      by norm_num [fullInterval,RootInterval.InRange],by norm_num [fullInterval,RootInterval.InRange]⟩)
    (fun _=>ρ) (fun _ _=>hρ)
  simp only [Finset.sum_singleton] at h
  apply h.trans
  apply mul_le_mul_of_nonneg_left _ (mul_nonneg
    ((Real.rpow_pos_of_pos (by linarith : 0<x) _).le.trans hU)
    ((Real.rpow_pos_of_pos (by linarith : 0<x) _).le.trans hV))
  exact Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)

/-- Actual record/subset gap expansion, including the original scalar
normalization. The same growing families and literal moduli are used as
in the signed archimedean transfer. -/
theorem eventually_original_residue_transfer (hPD : RootCountContract)
    (K : ℕ) (C δ vmin : ℝ) (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) :
    ∀ᶠ x : ℝ in atTop,
      ∀ records : Finset (SourceRecord K C (Real.log x)), ∀ primes : Finset ℕ, ∀ T : ℕ,
      (∀rec∈records,∀j i a,(recordLabels rec j i a).Prime) →
      (∀p∈primes,p.Prime ∧ (p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      T≤⌈(Real.log x)^(76/100:ℝ)⌉₊ →
      ∀ [∀t : Term records primes T,Fintype (ZMod (recordModulus t.1.val t.2.val))],
      ∀ U V : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ ρ : (t : Term records primes T)→Matrix.SpecialLinearGroup (Fin 2)
        (ZMod (recordModulus t.1.val t.2.val))→ℂ,
      (∀t g,‖ρ t g‖≤1) →
      ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
        ((∑t : Term records primes T,
          weightedRootSum U V (recordModulus t.1.val t.2.val)
            (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) (ρ t)) -
         (∑t : Term records primes T,
          (rootVolume U V (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1):ℂ)*
            ((∑g,ρ t g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2)
              (ZMod (recordModulus t.1.val t.2.val))):ℂ))))‖ ≤ U*V*x^(-(δ/64000)) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    Real.tendsto_log_atTop.eventually (eventually_term_mass_le K C vmin hC hmin),
    eventually_accumulation_cost δ hδ,eventually_full_box hPD δ (16*K+4) hδ (by positivity)]
    with x hx hL hm hc ht
  intro records primes T hrecords hpr hT inst U V hU hU' hV hV' VM hVM ρ hρ
  have hUV : 0≤U*V := mul_nonneg
    ((Real.rpow_pos_of_pos hx _).le.trans hU) ((Real.rpow_pos_of_pos hx _).le.trans hV)
  let A (t : Term records primes T) := weightedRootSum U V (recordModulus t.1.val t.2.val)
    (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) (ρ t)
  let B (t : Term records primes T) :=
    (rootVolume U V (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1):ℂ)*
      ((∑g,ρ t g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2)
        (ZMod (recordModulus t.1.val t.2.val))):ℂ))
  have hterm (t : Term records primes T) : ‖A t-B t‖≤U*V*x^(-(δ/32000)) := by
    have hadm := recordModulus_admissible hL t.1.val primes t.2.val T
      (hrecords t.1.val t.1.property) hpr t.2.property hT
    exact ht U V _ hU hU' hV hV' hadm.1 hadm.2.1 hadm.2.2 (ρ t) (hρ t)
  have hsum : ‖(∑t,A t)-(∑t,B t)‖≤
      (Fintype.card (Term records primes T):ℝ)*(U*V*x^(-(δ/32000))) := by
    rw [←Finset.sum_sub_distrib]
    exact (norm_sum_le _ _).trans (by
      simpa using Finset.sum_le_sum (s:=Finset.univ) (fun t _=>hterm t))
  have hweight := hm records primes T (fun p hp=>(hpr p hp).2) hT VM hVM
  change ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
    ((∑t,A t)-(∑t,B t))‖≤_
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs]
  calc
    _ ≤ |normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
        ((Fintype.card (Term records primes T):ℝ)*(U*V*x^(-(δ/32000)))) :=
      mul_le_mul_of_nonneg_left hsum (abs_nonneg _)
    _ = (|normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
        (Fintype.card (Term records primes T):ℝ))*(U*V*x^(-(δ/32000))) := by ring
    _ ≤ Real.exp (12*(Real.log x)^(98/100:ℝ))*(U*V*x^(-(δ/32000))) :=
      mul_le_mul_of_nonneg_right hweight (mul_nonneg hUV (by positivity))
    _ ≤ _ := hc U V hUV

end Elliptic.Operator.RootConstantAccumulation
