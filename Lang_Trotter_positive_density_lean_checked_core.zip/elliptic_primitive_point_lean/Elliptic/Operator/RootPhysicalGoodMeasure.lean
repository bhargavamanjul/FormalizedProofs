module

public import Elliptic.Operator.RootPhaseMeasure
public import Elliptic.Operator.RootGridMeasure

/-!
# Good-state removal in the full physical root box

This lifts the one-dimensional phase estimate to the actual normalized
root coordinates. The horizontal box contributes its literal area 15.
No constancy on grid cells and no assumed good-state estimate is used.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootPhysicalGoodMeasure
open MeasureTheory Set RootPhaseMeasure RootGridMeasure RootGoodBoundary
open scoped BigOperators ENNReal
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K M : ℕ} {P : Fin K → Type} [∀i, Fintype (P i)]

/-- The actual physical box with failure of either literal source test. -/
def failedPhysicalSet (U V : ℝ) (value : ∀i, P i → ℕ)
    (label : Fin K × Fin M → ℕ) (μ : ∀i, P i → ℝ) (d₀ Y L : ℝ)
    (a : Fin K → ℝ) (z w : ℤ × ℤ) : Set RootPoint :=
  {q | q∈rootBox ∧ sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z ∧
    ¬sourceTests value label μ d₀ Y L a (phase z w q.2.2)}

theorem failedPhysicalSet_subset (U V : ℝ) (hU : 0<U) (value : ∀i, P i → ℕ)
    (label : Fin K × Fin M → ℕ) (μ : ∀i, P i → ℝ) (d₀ Y L : ℝ)
    (a : Fin K → ℝ) (z w : ℤ × ℤ) :
    failedPhysicalSet U V value label μ d₀ Y L a z w ⊆
      Icc (1 : ℝ) 16 ×ˢ (Icc (1 : ℝ) 2 ×ˢ
        {r : ℝ | r∈domain z ∧ ¬sourceTests value label μ d₀ Y L a (phase z w r)}) := by
  intro q hq
  have hbox := hq.1
  have hlo : U≤U*q.1 := by nlinarith [hbox.1]
  have hhi : U*q.1≤16*U := by nlinarith [hbox.2.1]
  refine ⟨⟨hbox.1,hbox.2.1⟩,⟨hbox.2.2.1,hbox.2.2.2.1⟩,?_,hq.2.2⟩
  exact physical_allowed_mem_domain _ _ _ U V hU hlo hhi
    hbox.2.2.2.2.1 hbox.2.2.2.2.2 z hq.2.1

/-- The exact horizontal area is 15. This estimate is valid even without
measurability hypotheses on the failure set. -/
theorem failedPhysicalSet_measure_le (U V : ℝ) (hU : 0<U) (value : ∀i, P i → ℕ)
    (label : Fin K × Fin M → ℕ) (μ : ∀i, P i → ℝ) (d₀ Y L : ℝ)
    (a : Fin K → ℝ) (z w : ℤ × ℤ) :
    volume (failedPhysicalSet U V value label μ d₀ Y L a z w) ≤
      15*volume {r : ℝ | r∈domain z ∧ ¬sourceTests value label μ d₀ Y L a (phase z w r)} := by
  apply (measure_mono (failedPhysicalSet_subset U V hU value label μ d₀ Y L a z w)).trans_eq
  rw [Measure.volume_eq_prod,Measure.prod_prod,Measure.volume_eq_prod,Measure.prod_prod]
  norm_num [Real.volume_Icc]

open Filter GoodStateCounting NumericGoodState in
/-- The full physical root-box good-state removal estimate for actual
numeric prime bands, with all varying state data quantified after the
single eventual threshold. -/
theorem eventually_numeric_failedPhysicalSet_small {K : ℕ} (a : Fin K → ℝ)
    (hmono : StrictMono a) (ha : ∀i, (1/10 : ℝ)≤a i) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (active : ∀i : Fin K, Fin (momentMultiplicity L) → numericPrimeBand L (a i))
        (d₀ Y : ℝ), Real.exp (L^(1/10 : ℝ))≤Y →
      ∀ (U V : ℝ), 0<U → ∀z w : ℤ × ℤ, latticeDet z w=1 →
      volume (failedPhysicalSet U V
        (fun i => fun p : numericPrimeBand L (a i) => (p : ℕ))
        (fun ij => (active ij.1 ij.2 : ℕ)) (fun i => bandMass L (a i)) d₀ Y L a z w) ≤
        ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/16))) := by
  have hgrowth := (Real.tendsto_exp_atTop.comp
    ((tendsto_rpow_atTop (by norm_num : (0 : ℝ)<1/10)).atTop_div_const
      (by norm_num : (0 : ℝ)<16))).eventually_ge_atTop (15 : ℝ)
  filter_upwards [eventually_numeric_failed_sourceTests_small a hmono ha,hgrowth] with L h hC
  intro active d₀ Y hY U V hU z w hzw
  apply (failedPhysicalSet_measure_le U V hU _ _ _ d₀ Y L a z w).trans
  calc
    _ ≤ 15*ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/8))) := by
      gcongr
      exact h active d₀ Y hY z w hzw
    _ = ENNReal.ofReal (15*Real.exp (-(L^(1/10 : ℝ)/8))) := by
      rw [ENNReal.ofReal_mul (by norm_num)]
      norm_num
    _ ≤ _ := ENNReal.ofReal_le_ofReal (calc
      _ ≤ Real.exp (L^(1/10 : ℝ)/16)*Real.exp (-(L^(1/10 : ℝ)/8)) :=
        mul_le_mul_of_nonneg_right hC (Real.exp_pos _).le
      _ = _ := by rw [← Real.exp_add]; congr 1; ring)

end Elliptic.Operator.RootPhysicalGoodMeasure
