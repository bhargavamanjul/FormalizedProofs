module
public import Elliptic.Operator.PhysicalCleanRootProjection
public import Elliptic.Operator.PhysicalCleanUniform

/-! Arbitrary logarithmic saving for the actual clean physical operator.
The exponent of the major-arc parameter is G+5, chosen independently of
K, J, B, the physical position set, the prime bands and the memory bags.
All good-state, ban, pad, slope and memory projections are literal. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanActualSaving
open Filter
open scoped BigOperators SchwartzMap
open PhysicalMaskedKernel PhysicalMaskedSchur RootLiteralGeometry
open PhysicalCleanFull PhysicalCleanRootProjection
attribute [local instance] Classical.propDecidable
local instance physicalCleanSavingDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1600000

/-- The original clean matrix, before dividing by the target mass. -/
def literalCleanKernel {K J B : ℕ}
    (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (Line : ∀i,groups i→Type) [∀i p,Fintype (Line i p)]
    (ν : Fin K→ℕ→ℝ) (V : Fin K→ℝ) (ρ : ℝ)
    (anchor : positions→∀i p,Line i p) (μ : ∀i,groups i→ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ) :
    State (Z:=positions) (P:=fun i=>groups i) (Line:=Line) (J:=J) (B:=B)→
      State (Z:=positions) (P:=fun i=>groups i) (Line:=Line) (J:=J) (B:=B)→ℂ :=
  originalKernel (fun i (p:groups i)=>ν i p.val) V (fun _=>false) (fun _=>false) ρ anchor
    (fun z a w b=>sourcePhysicalEdgeGeometry (fun _ p=>p.val)
      (sourceGood (fun _ p=>p.val) μ d₀ Y L exponents q)
      (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val a w.val b)

/-- A proved operator estimate for the complete literal clean matrix.
The large-L threshold is uniform in J, B, the finite prime/position sets,
all admissible root coordinates and dyads, masses, anchors and test vectors.
Only scalar prime-weight, mass and support hypotheses remain. -/
theorem eventually_actual_clean_saving
    (G : ℝ) (hG : 0≤G) (K : ℕ) (Cweight : Fin K→ℝ)
    (hCweight : ∀i,0≤Cweight i)
    (ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ Cmass Catom : ℝ)
    (hC : 0≤C) (hAψ : 0≤Aψ) (hmassC : 1≤Cmass) (hCatom : 0≤Catom)
    (hweight : ∀i,Cweight i≤Catom)
    (hη : ∀x,‖η x‖≤1) (hηsupport : ∀x,η x≠0→1≤x)
    (hψ : ∀x,‖ψ x‖≤Aψ) (hψsupport : ∀x,ψ x≠0→|x|≤C) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀ (ν : Fin K→ℕ→ℝ), (∀i,∀p∈groups i,0<ν i p)→
      (∀i,∀p∈groups i,ν i p≤Cweight i/p)→
      (∀i,∑p:groups i,ν i p.val≤Cmass)→
      (∀i,∀p∈groups i,Real.exp (L^(1/10:ℝ))≤(p:ℝ))→
      ∀ (J B : ℕ) (Line : ∀i,groups i→Type) (_ : ∀i p,Fintype (Line i p))
        (V : Fin K→ℝ) (ρ : ℝ),0≤ρ→ρ≤1→
      ∀ (anchor : positions→∀i p,Line i p) (μ : ∀i,groups i→ℝ)
        (d₀ Y : ℝ) (exponents : Fin K→ℝ) (q : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤q.1→q.1≤16→0<d₀→1≤Y→
      Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀σ : ℤ,(σ=1∨σ= -1)→
      ∀F : State (Z:=positions) (P:=fun i=>groups i) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass (fun i (p:groups i)=>ν i p.val))
        (fun s=>∑t,literalCleanKernel positions groups Line ν V ρ anchor μ d₀ Y L exponents q
          U W η ψ (L^(G+5)) σ s t*F t)≤
      L^(-G)*finiteL2 Finset.univ (mass (fun i (p:groups i)=>ν i p.val)) F := by
  filter_upwards [PhysicalCleanUniform.eventually_budget Cweight hCweight ψ C Aψ Cmass Catom G
    hC hAψ hmassC hCatom hG] with L hb
  intro positions groups hprime hdis ν hν hνbound hmass hband J B Line instLine V ρ hρ0 hρ1
    anchor μ d₀ Y exponents q U W hU hq₁ hq₁' hd hY hYlo hYhi σ hσ F
  letI : ∀i p,Fintype (Line i p) := instLine
  have hatom : ∀i,∀p∈groups i,ν i p≤Catom*Real.exp (-L^(1/10:ℝ)) := by
    intro i p hp
    exact (clean_prime_atom_le (ν i p) (Cweight i) p (L^(1/10:ℝ)) (hCweight i)
      (hband i p hp) (hνbound i p hp)).trans
      (mul_le_mul_of_nonneg_right (hweight i) (Real.exp_pos _).le)
  have hbound := clean_source_kernel_bound (J:=J) positions groups hprime hdis ν Cweight hCweight hν hνbound
    Line B V ρ hρ0 hρ1 anchor
    (sourceGood (J:=J) (fun _ p=>p.val) μ d₀ Y L exponents q)
    (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y C hU
    (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hq₁ hU.le)
    (by simpa only [mul_comm] using mul_le_mul_of_nonneg_left hq₁' hU.le) hd hY hC
    (root_sourceGood_firstProjection (J:=J) groups hdis μ d₀ Y L exponents q U W)
    η hη hηsupport ψ (L^(G+5)) hb.1 1 Aψ Cmass
    (Catom*Real.exp (-L^(1/10:ℝ))) (L^(-(G+1))) hAψ hψ hψsupport hmassC
    (mul_nonneg hCatom (Real.exp_pos _).le) hb.2.1 hmass hatom σ hσ
    (fun A B hA hB harea=>hb.2.2.2 groups Y A B hYlo hYhi hA hB harea)
  let X := State (Z:=positions) (P:=fun i=>groups i) (Line:=Line) (J:=J) (B:=B)
  let μν : X→ℝ := mass (Z:=positions) (P:=fun i=>groups i) (Line:=Line) (J:=J) (B:=B)
    (fun i (p:groups i)=>ν i p.val)
  let KL : X→X→ℂ := literalCleanKernel (J:=J) (B:=B) positions groups Line ν V ρ anchor μ
    d₀ Y L exponents q U W η ψ (L^(G+5)) σ
  have hμpos : ∀s:X,0<μν s := mass_pos (Z:=positions) (P:=fun i=>groups i) (Line:=Line)
    (J:=J) (B:=B) _ (fun i p=>hν i p.val p.property)
  have hbound' : FiniteMeasuredBilinearBound Finset.univ Finset.univ μν μν
      (fun s t=>KL s t/(μν t:ℂ)) (((2*⌈512*C+1⌉₊+1:ℕ):ℝ)*L^(-(G+1))) := by
    dsimp only [μν,KL,literalCleanKernel]
    exact finiteMeasuredBilinearBound_restrict _ Finset.univ _ Finset.univ
      (by intro x hx; simp only [Finset.mem_univ]) (by intro x hx; simp only [Finset.mem_univ])
      _ _ _ _ hbound
  have hop := density_operator_bound μν hμpos KL
    (((2*⌈512*C+1⌉₊+1:ℕ):ℝ)*L^(-(G+1)))
    (mul_nonneg (Nat.cast_nonneg _) hb.2.1) hbound' F
  exact hop.trans (mul_le_mul_of_nonneg_right hb.2.2.1 (Real.sqrt_nonneg _))

end Elliptic.Operator.PhysicalCleanActualSaving
