module

public import Elliptic.Operator.ActualHistoryLifespans

/-!
# Pending traces recovered from actual histories

The before/after pending traces are determined by the extracted lifespans.
All causal assertions below refer to literal dependent choices; no schedule
or compatibility hypothesis is supplied.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath ActualHistoryLifespans
attribute [local instance] Classical.propDecidable
local instance actualHistoryPendingDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace ActualHistoryPending
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Ghost operations leave the literal active tuple unchanged. -/
theorem observed_active_unchanged (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) :
    (afterStateAt ν V η q ρ geometry n j s h k).active P Line J B =
      (beforeStateAt ν V η q ρ geometry n j s h k).active P Line J B := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih => exact Fin.cases rfl (fun t => ih (j+1) _ h.2.2 t) k

/-- Global live distinctness can be read at any literal visit. -/
theorem allLive_at (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) :
    (beforeStateAt ν V η q ρ geometry n j s h k).LiveDistinct ∧
      (afterStateAt ν V η q ρ geometry n j s h k).LiveDistinct := by
  induction n generalizing j s with
  | zero => exact hl
  | succ n ih => exact Fin.cases ⟨hl.1,hl.2.1⟩ (fun t => ih (j+1) _ h.2.2 hl.2.2 t) k

/-- Pending primes before a visit cannot simultaneously be active. -/
theorem before_not_active (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) (i : I) (p : P i)
    (hp : observedPendingBefore ν V η q ρ geometry n j s h k i p) :
    ¬ observedActive ν V η q ρ geometry n j s h k i p := by
  obtain ⟨a,ha⟩ := hp
  rintro ⟨b,hb⟩
  exact ((allLive_at ν V η q ρ anchor geometry n j s h hl k).1 i).2.2 b a (hb.trans ha.symm)

/-- The same active/pending exclusion holds after the ghost operation. -/
theorem after_not_active (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hl : ActualHistorySupport.AllLive ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) (i : I) (p : P i)
    (hp : observedPendingAfter ν V η q ρ geometry n j s h k i p) :
    ¬ observedActive ν V η q ρ geometry n j s h k i p := by
  obtain ⟨a,ha⟩ := hp
  rintro ⟨b,hb⟩
  have hb' : (afterStateAt ν V η q ρ geometry n j s h k).active P Line J B i b = p := by
    rw [observed_active_unchanged]
    exact hb
  exact ((allLive_at ν V η q ρ anchor geometry n j s h hl k).2 i).2.2 b a (hb'.trans ha.symm)

/-- If a label is never born in a word, occurrence at a visit was already
present before its ghost operation, rather than first created there. -/
theorem before_of_no_future_birth (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i)
    (hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) (hp : observedLive ν V η q ρ geometry n j s h k i p) :
    StateHas (beforeStateAt ν V η q ρ geometry n j s h k) i p := by
  induction n generalizing j s with
  | zero =>
      exact live_origin_of_no_future_birth ν V η q ρ anchor geometry value 0 j s h i p hn k hp
  | succ n ih =>
      revert hp
      refine Fin.cases ?_ (fun k => ?_) k
      · intro hp
        exact live_origin_of_no_future_birth ν V η q ρ anchor geometry value (n+1) j s h i p hn 0 hp
      · intro hp
        apply ih (j+1) _ h.2.2 ?_ k hp
        rintro ⟨a,ha⟩
        exact hn ⟨ActualHistorySupport.tailAddress a, by
          rw [ActualHistorySupport.futureLabels_tail]
          exact ha⟩

/-- A prime seen at the first visit cannot be newly born in the suffix. -/
theorem head_avoids_tail (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j (n+1)) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry (n+1) j s h))
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry (n+1) j s h) s)
    (i : I) (p : P i)
    (hp : observedLive ν V η q ρ geometry (n+1) j s h 0 i p) :
    value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) _ h.2.2 := by
  have hi := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
  rcases hp with ⟨a,ha⟩ | ⟨a,ha⟩ | ⟨a,ha⟩
  · have hh := hi.2.1.1 i a
    change s.active P Line J B i a = p at ha
    rwa [ha] at hh
  · have hh := hi.2.1.2 i a
    change ((s.memory P Line J B i).values a).1 = p at ha
    rwa [ha] at hh
  · have hh := hi.2.2.1.2 i a
    change (((h.1.val.output anchor s h.1.property).memory P Line J B i).values a).1 = p at ha
    rwa [ha] at hh

/-- If a prime is live at an earlier visit and again now, its current
occurrence was already present before the current ghost operation. -/
theorem earlier_live_before (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) (p : P i) (a k : Fin (n+1)) (hak : a.val < k.val)
    (ha : observedLive ν V η q ρ geometry n j s h a i p)
    (hk : observedLive ν V η q ρ geometry n j s h k i p) :
    StateHas (beforeStateAt ν V η q ρ geometry n j s h k) i p := by
  induction n generalizing j s with
  | zero => omega
  | succ n ih =>
      have hi := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
      revert hak ha hk
      refine Fin.cases ?_ (fun a => ?_) a
      · refine Fin.cases ?_ (fun k => ?_) k
        · intro hak; simp at hak
        · intro _ ha hk
          exact before_of_no_future_birth ν V η q ρ anchor geometry value n (j+1) _ h.2.2 i p
            (head_avoids_tail ν V η q ρ anchor geometry value n j s h hd hav i p ha) k hk
      · refine Fin.cases ?_ (fun k => ?_) k
        · intro hak; simp at hak
        · intro hak ha hk
          exact ih (j+1) _ h.2.2 hi.1 hi.2.2.2 a k (by simpa using hak) ha hk

/-- If a prime is live now and at a later visit, its current occurrence
must survive the current ghost operation. -/
theorem later_live_after (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) (p : P i) (k c : Fin (n+1)) (hkc : k.val < c.val)
    (hk : observedLive ν V η q ρ geometry n j s h k i p)
    (hc : observedLive ν V η q ρ geometry n j s h c i p) :
    StateHas (afterStateAt ν V η q ρ geometry n j s h k) i p := by
  induction n generalizing j s with
  | zero => omega
  | succ n ih =>
      have hi := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
      revert hkc hk hc
      refine Fin.cases ?_ (fun k => ?_) k
      · refine Fin.cases ?_ (fun c => ?_) c
        · intro hkc; simp at hkc
        · intro _ hk hc
          have hn := head_avoids_tail ν V η q ρ anchor geometry value n j s h hd hav i p hk
          have hse := live_origin_of_no_future_birth ν V η q ρ anchor geometry value n (j+1) _ h.2.2 i p hn c hc
          rcases edge_has_source_or_birth anchor _ h.2.1.val h.2.1.property i p hse with hsg | hf
          · exact hsg
          · rcases hk with ⟨a,ha⟩ | ⟨a,ha⟩ | hp
            · exact Or.inl ⟨a,ha⟩
            · exfalso
              apply hav.2 i a
              change ((s.memory P Line J B i).values a).1 = p at ha
              rw [ha]
              exact ⟨.inr (0,i),ActualHistorySupport.futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hf⟩
            · exact Or.inr hp
      · refine Fin.cases ?_ (fun c => ?_) c
        · intro hkc; simp at hkc
        · intro hkc hk hc
          exact ih (j+1) _ h.2.2 hi.1 hi.2.2.2 k c (by simpa using hkc) hk hc

/-- A pending occurrence before a visit either comes from the initial
pending boundary or has an earlier live visit. -/
theorem before_has_earlier_or_initial (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i)
    (hp : observedPendingBefore ν V η q ρ geometry n j s h k i p) :
    (∃ a, ((s.memory P Line J B i).values a).1 = p) ∨
      ∃ t : Fin (n+1), t.val < k.val ∧ observedLive ν V η q ρ geometry n j s h t i p := by
  induction n generalizing j s with
  | zero => exact Or.inl hp
  | succ n ih =>
      revert hp
      refine Fin.cases ?_ (fun k => ?_) k
      · exact fun hp => Or.inl hp
      · intro hp
        rcases ih (j+1) _ h.2.2 k hp with hb | ⟨t,ht,hl⟩
        · apply Or.inr
          refine ⟨0,by simp,?_⟩
          rcases edge_pending_from_source anchor _ h.2.1.val h.2.1.property i p hb with ha | hm
          · exact Or.inl ha
          · exact Or.inr (Or.inr hm)
        · exact Or.inr ⟨t.succ,by simpa using ht,hl⟩

/-- A pending occurrence after a visit either reaches the final pending
boundary or has a later live visit. -/
theorem after_has_later_or_final (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i)
    (hp : observedPendingAfter ν V η q ρ geometry n j s h k i p) :
    (∃ a, ((h.final.memory P Line J B i).values a).1 = p) ∨
      ∃ t : Fin (n+1), k.val < t.val ∧ observedLive ν V η q ρ geometry n j s h t i p := by
  induction n generalizing j s with
  | zero => exact Or.inl hp
  | succ n ih =>
      revert hp
      refine Fin.cases ?_ (fun k => ?_) k
      · intro hp
        apply Or.inr
        refine ⟨Fin.succ 0,by simp,?_⟩
        rcases edge_pending_persists anchor _ h.2.1.val h.2.1.property i p hp with ha | hm
        · apply Or.inl
          unfold observedActive
          change ∃ a, (beforeStateAt ν V η q ρ geometry n (j+1) _ h.2.2 0).active P Line J B i a = p
          rw [beforeStateAt_zero]
          exact ha
        · apply Or.inr ∘ Or.inl
          unfold observedPendingBefore
          change ∃ a, (((beforeStateAt ν V η q ρ geometry n (j+1) _ h.2.2 0).memory P Line J B i).values a).1 = p
          rw [beforeStateAt_zero]
          exact hm
      · intro hp
        rcases ih (j+1) _ h.2.2 k hp with hf | ⟨t,ht,hl⟩
        · exact Or.inl hf
        · exact Or.inr ⟨t.succ,by simpa using ht,hl⟩

theorem mem_observedLiveVisits (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (i : I) (p : P i) (k : Fin (N+1)) :
    k.val ∈ observedLiveVisits ν V η q ρ geometry s h i p ↔
      observedLive ν V η q ρ geometry N 0 s h k i p := by
  simp only [observedLiveVisits,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨t,ht,he⟩
    exact Fin.ext he ▸ ht
  · exact fun hk => ⟨k,hk,rfl⟩

theorem mem_observedActiveVisits (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (i : I) (p : P i) (k : Fin (N+1)) :
    k.val ∈ observedActiveVisits ν V η q ρ geometry s h i p ↔
      observedActive ν V η q ρ geometry N 0 s h k i p := by
  simp only [observedActiveVisits,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨t,ht,he⟩
    exact Fin.ext he ▸ ht
  · exact fun hk => ⟨k,hk,rfl⟩

/-- The extracted active field recovers the exact literal active trace. -/
theorem observedLifespan_active (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) (k : Fin (N+1)) :
    k.val ∈ (observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp).active ↔
      observedActive ν V η q ρ geometry N 0 s h k i p :=
  mem_observedActiveVisits ν V η q ρ anchor geometry N s h i p k

/-- Exact before-pending recovery from the canonical lifespan extracted
from an actual distinct-birth history with empty boundary memories. -/
theorem observedLifespan_beforeGhost (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) (k : Fin (N+1)) :
    (observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp).beforeGhost k.val ↔
      observedPendingBefore ν V η q ρ geometry N 0 s h k i p := by
  let L := observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp
  have hlive (t : Fin (N+1)) : L.birth ≤ t.val ∧ t.val ≤ L.death ↔
      observedLive ν V η q ρ geometry N 0 s h t i p :=
    (L.live_iff t.val).symm.trans
      ((observedLifespan_live ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp t.val).trans
        (mem_observedLiveVisits ν V η q ρ anchor geometry N s h i p t))
  have hactive := observedLifespan_active ν V η q ρ anchor geometry N s h hinitial hfinal i p hp k
  have hf := initial_future_conditions ν V η q ρ anchor geometry value N s h hd hinitial
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  constructor
  · intro hb
    have hb' : L.birth < k.val ∧ k.val ≤ L.death ∧ k.val ∉ L.active := hb
    let b : Fin (N+1) := ⟨L.birth,by have := L.birth_le_death; have := L.death_le; omega⟩
    have hborn := (hlive b).mp ⟨le_rfl,L.birth_le_death⟩
    have hnow := (hlive k).mp ⟨hb'.1.le,hb'.2.1⟩
    rcases earlier_live_before ν V η q ρ anchor geometry value N 0 s h hf.1 hf.2 i p b k hb'.1 hborn hnow with ha | hm
    · exact False.elim (hb'.2.2 (hactive.mpr ha))
    · exact hm
  · intro hm
    have hnow := (hlive k).mpr (Or.inr (Or.inl hm))
    have hna := before_not_active ν V η q ρ anchor geometry N 0 s h hall k i p hm
    have hearlier : ∃ t : Fin (N+1), t.val < k.val ∧ observedLive ν V η q ρ geometry N 0 s h t i p := by
      rcases before_has_earlier_or_initial ν V η q ρ anchor geometry N 0 s h k i p hm with ⟨a,_⟩ | he
      · have hsz := hinitial i
        have hai := a.isLt
        omega
      · exact he
    obtain ⟨t,ht,hl⟩ := hearlier
    have hthen := (hlive t).mpr hl
    exact ⟨lt_of_le_of_lt hthen.1 ht,hnow.2,fun ha => hna (hactive.mp ha)⟩

/-- Exact after-pending recovery. In particular, a pending death cannot
silently be replaced by a later birth with the same numerical prime. -/
theorem observedLifespan_afterGhost (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) (k : Fin (N+1)) :
    (observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp).afterGhost k.val ↔
      observedPendingAfter ν V η q ρ geometry N 0 s h k i p := by
  let L := observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp
  have hlive (t : Fin (N+1)) : L.birth ≤ t.val ∧ t.val ≤ L.death ↔
      observedLive ν V η q ρ geometry N 0 s h t i p :=
    (L.live_iff t.val).symm.trans
      ((observedLifespan_live ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp t.val).trans
        (mem_observedLiveVisits ν V η q ρ anchor geometry N s h i p t))
  have hactive := observedLifespan_active ν V η q ρ anchor geometry N s h hinitial hfinal i p hp k
  have hf := initial_future_conditions ν V η q ρ anchor geometry value N s h hd hinitial
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  constructor
  · intro ha
    have ha' : L.birth ≤ k.val ∧ k.val < L.death ∧ k.val ∉ L.active := ha
    let d : Fin (N+1) := ⟨L.death,by have := L.death_le; omega⟩
    have hdeath := (hlive d).mp ⟨L.birth_le_death,le_rfl⟩
    have hnow := (hlive k).mp ⟨ha'.1,ha'.2.1.le⟩
    rcases later_live_after ν V η q ρ anchor geometry value N 0 s h hf.1 hf.2 i p k d ha'.2.1 hnow hdeath with hac | hm
    · have hac' : observedActive ν V η q ρ geometry N 0 s h k i p := by
        unfold observedActive
        rwa [observed_active_unchanged] at hac
      exact False.elim (ha'.2.2 (hactive.mpr hac'))
    · exact hm
  · intro hm
    have hnow := (hlive k).mpr (Or.inr (Or.inr hm))
    have hna := after_not_active ν V η q ρ anchor geometry N 0 s h hall k i p hm
    have hlater : ∃ t : Fin (N+1), k.val < t.val ∧ observedLive ν V η q ρ geometry N 0 s h t i p := by
      rcases after_has_later_or_final ν V η q ρ anchor geometry N 0 s h k i p hm with ⟨a,_⟩ | he
      · have hsz := hfinal i
        have hai := a.isLt
        omega
      · exact he
    obtain ⟨t,ht,hl⟩ := hlater
    have hthen := (hlive t).mpr hl
    exact ⟨hnow.1,lt_of_lt_of_le ht hthen.2,fun ha => hna (hactive.mp ha)⟩

/-- Totalize the extracted lifespan data. The dummy singleton at zero is
used only for labels outside the actual used-prime set, which filters all
scheduled sets. It has no mathematical effect on those sets. -/
def extractedLifespan (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) : PrimeLifespan N :=
  if hp : p ∈ observedPrimes ν V η q ρ geometry s h i then
    observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp
  else {
    birth := 0
    death := 0
    birth_le_death := le_rfl
    death_le := Nat.zero_le N
    active := {0}
    active_bounds := by intro k hk; simp only [Finset.mem_singleton] at hk; subst k; exact ⟨le_rfl,le_rfl⟩
    singleton_active := by intro; exact Finset.mem_singleton_self 0 }

theorem extractedLifespan_eq (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) :
    extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p =
      observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp := by
  simp only [extractedLifespan,dite_eq_left hp]

/-- Actual active slots determine exactly the used active lifespan set. -/
theorem extracted_active_iff (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) (p : P i) :
    (p ∈ observedPrimes ν V η q ρ geometry s h i ∧
      k.val ∈ (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p).active) ↔
      observedActive ν V η q ρ geometry N 0 s h k i p := by
  constructor
  · rintro ⟨hp,ha⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp] at ha
    exact (observedLifespan_active ν V η q ρ anchor geometry N s h hinitial hfinal i p hp k).mp ha
  · intro ha
    have hp : p ∈ observedPrimes ν V η q ρ geometry s h i :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,⟨k,Or.inl ha⟩⟩
    refine ⟨hp,?_⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp]
    exact (observedLifespan_active ν V η q ρ anchor geometry N s h hinitial hfinal i p hp k).mpr ha

/-- The full scheduled before-pending set is exactly the prime support
of the actual ordered memory. -/
theorem extracted_before_eq_pending (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    LifespanSchedule.before (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
      Finset.univ.image (fun a => (((beforeStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i).values a).1) := by
  ext p
  simp only [LifespanSchedule.before,Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨hp,hb⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp] at hb
    exact (observedLifespan_beforeGhost ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp k).mp hb
  · intro hb
    have hp : p ∈ observedPrimes ν V η q ρ geometry s h i :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,⟨k,Or.inr (Or.inl hb)⟩⟩
    refine ⟨hp,?_⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp]
    exact (observedLifespan_beforeGhost ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp k).mpr hb

/-- The full scheduled after-pending set is exactly the prime support
of the actual ordered post-ghost memory. -/
theorem extracted_after_eq_pending (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    LifespanSchedule.after (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val =
      Finset.univ.image (fun a => (((afterStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i).values a).1) := by
  ext p
  simp only [LifespanSchedule.after,Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨hp,ha⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp] at ha
    exact (observedLifespan_afterGhost ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp k).mp ha
  · intro ha
    have hp : p ∈ observedPrimes ν V η q ρ geometry s h i :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,⟨k,Or.inr (Or.inr ha)⟩⟩
    refine ⟨hp,?_⟩
    rw [extractedLifespan_eq ν V η q ρ anchor geometry N s h hinitial hfinal i p hp]
    exact (observedLifespan_afterGhost ν V η q ρ anchor geometry value N s h hd hinitial hfinal i p hp k).mpr ha

theorem extracted_before_card (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    (LifespanSchedule.before (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val).card =
      ((beforeStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i).size := by
  rw [extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  have hi := ((allLive_at ν V η q ρ anchor geometry N 0 s h hall k).1 i).2.1
  rw [Finset.card_image_of_injective _ hi]
  simp

theorem extracted_after_card (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) (i : I) :
    (LifespanSchedule.after (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val).card =
      ((afterStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i).size := by
  rw [extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  have hi := ((allLive_at ν V η q ρ anchor geometry N 0 s h hall k).2 i).2.1
  rw [Finset.card_image_of_injective _ hi]
  simp

/-- The scheduled total before-pending cutoff follows from the actual
state's total memory cutoff; it is not a reconstruction hypothesis. -/
theorem extracted_before_cutoff (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) :
    (∑ i, (LifespanSchedule.before (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val).card) ≤ B := by
  simp_rw [extracted_before_card ν V η q ρ anchor geometry value N s h hd hinitial hfinal k]
  exact (beforeStateAt ν V η q ρ geometry N 0 s h k).property

/-- The same literal total cutoff holds after every ghost operation. -/
theorem extracted_after_cutoff (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (k : Fin (N+1)) :
    (∑ i, (LifespanSchedule.after (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val).card) ≤ B := by
  simp_rw [extracted_after_card ν V η q ρ anchor geometry value N s h hd hinitial hfinal k]
  exact (afterStateAt ν V η q ρ geometry N 0 s h k).property

end ActualHistoryPending
end Elliptic.Operator
