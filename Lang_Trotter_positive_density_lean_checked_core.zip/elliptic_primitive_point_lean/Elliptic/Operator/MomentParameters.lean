module

public import Elliptic.Operator.MomentSummation
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Algebra.Order.Floor.Semiring

/-!
# The literal growing parameters in the prime-predecessor moment proof

The definitions below are (3.12), (4.11), (4.43), and (4.51) of the
September 24 prime-predecessor paper.  In particular the moment length is
`2 ceil(L^(1/2)/2)`, not of order `L/log L`.  All constants in the eventual
statements are fixed before `L` tends to infinity.

These are numerical deductions.  They do not assert the per-permutation
operator estimates, or assume a signed moment theorem.
-/

@[expose] public section
namespace Elliptic.Operator
open Filter
open scoped Topology

noncomputable def momentPadding (L : ℝ) : ℕ := ⌊L ^ (1/100 : ℝ)⌋₊
noncomputable def momentMultiplicity (L : ℝ) : ℕ := momentPadding L + 1
noncomputable def momentLength (L : ℝ) : ℕ := 2 * ⌈L ^ (1/2 : ℝ) / 2⌉₊
noncomputable def memoryCutoff (L : ℝ) : ℕ := ⌈L ^ (2 : ℕ)⌉₊
noncomputable def birthAddressBudget (K : ℕ) (L : ℝ) : ℕ :=
  K * momentMultiplicity L + K * momentLength L +
    K * (momentLength L + 1) * memoryCutoff L
noncomputable def rankCutoff (C' L : ℝ) : ℕ :=
  ⌈C' * (momentLength L : ℝ) * Real.log L / L ^ (1/10 : ℝ)⌉₊

theorem momentLength_lower (L : ℝ) :
    L ^ (1/2 : ℝ) ≤ (momentLength L : ℝ) := by
  have h := Nat.le_ceil (L ^ (1/2 : ℝ) / 2)
  simp only [momentLength, Nat.cast_mul, Nat.cast_ofNat]
  linarith

theorem momentLength_upper {L : ℝ} (hL : 0 ≤ L) :
    (momentLength L : ℝ) < L ^ (1/2 : ℝ) + 2 := by
  have h := Nat.ceil_lt_add_one (show 0 ≤ L ^ (1/2 : ℝ) / 2 by positivity)
  simp only [momentLength, Nat.cast_mul, Nat.cast_ofNat]
  linarith

theorem momentLength_pos {L : ℝ} (hL : 0 < L) : 0 < momentLength L := by
  have := (Real.rpow_pos_of_pos hL (1/2 : ℝ)).trans_le (momentLength_lower L)
  exact_mod_cast this

theorem momentLength_le_three_mul {L : ℝ} (hL : 1 ≤ L) :
    (momentLength L : ℝ) ≤ 3 * L := by
  have hpow : L ^ (1/2 : ℝ) ≤ L := by
    simpa using Real.rpow_le_rpow_of_exponent_le hL (show (1/2 : ℝ) ≤ 1 by norm_num)
  have h := momentLength_upper (by linarith : 0 ≤ L)
  linarith

theorem tendsto_momentLength :
    Tendsto (fun L : ℝ => (momentLength L : ℝ)) atTop atTop :=
  tendsto_atTop_mono momentLength_lower (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/2))

theorem rankCutoff_lower (C' L : ℝ) :
    C' * (momentLength L : ℝ) * Real.log L / L ^ (1/10 : ℝ) ≤
      (rankCutoff C' L : ℝ) := Nat.le_ceil _

theorem rankCutoff_upper {C' L : ℝ} (hC : 0 ≤ C') (hL : 1 ≤ L) :
    (rankCutoff C' L : ℝ) <
      C' * (momentLength L : ℝ) * Real.log L / L ^ (1/10 : ℝ) + 1 := by
  apply Nat.ceil_lt_add_one
  exact div_nonneg (mul_nonneg (mul_nonneg hC (Nat.cast_nonneg _))
    (Real.log_nonneg hL)) (Real.rpow_nonneg (by linarith) _)

/-- The integer rounding error is harmless even though the moment grows. -/
theorem tendsto_rankCutoff_ratio {C' : ℝ} (hC : 0 ≤ C') :
    Tendsto (fun L : ℝ => (rankCutoff C' L : ℝ) / momentLength L) atTop (𝓝 0) := by
  have hlog := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<1/10)).tendsto_div_nhds_zero
  have hinv : Tendsto (fun L : ℝ => 1 / (momentLength L : ℝ)) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop tendsto_momentLength
  have hlim : Tendsto (fun L : ℝ => C' * (Real.log L / L^(1/10:ℝ)) +
      1 / (momentLength L : ℝ)) atTop (𝓝 0) := by
    simpa using (hlog.const_mul C').add hinv
  apply squeeze_zero' (Filter.Eventually.of_forall (fun L => by positivity)) _ hlim
  filter_upwards [eventually_ge_atTop (1:ℝ)] with L hL
  have hN : 0 < (momentLength L : ℝ) := by
    exact_mod_cast momentLength_pos (by linarith : 0 < L)
  have hu := (rankCutoff_upper hC hL).le
  calc
    _ ≤ (C' * (momentLength L : ℝ) * Real.log L / L^(1/10:ℝ) + 1) /
        (momentLength L : ℝ) := div_le_div_of_nonneg_right hu hN.le
    _ = _ := by field_simp

theorem eventually_rankCutoff_le {C' δ : ℝ} (hC : 0 ≤ C') (hδ : 0 < δ) :
    ∀ᶠ L : ℝ in atTop, (rankCutoff C' L : ℝ) ≤ δ * momentLength L := by
  filter_upwards [(tendsto_rankCutoff_ratio hC).eventually_lt_const hδ,
    eventually_ge_atTop (1:ℝ)] with L h hL
  have hN : 0 < (momentLength L : ℝ) := by
    exact_mod_cast momentLength_pos (by linarith : 0 < L)
  exact ((div_lt_iff₀ hN).mp h).le

theorem memoryCutoff_lower (L : ℝ) : L^2 ≤ (memoryCutoff L : ℝ) := Nat.le_ceil _

theorem memoryCutoff_upper (L : ℝ) : (memoryCutoff L : ℝ) < L^2+1 :=
  Nat.ceil_lt_add_one (sq_nonneg L)

theorem birthAddressBudget_le {L : ℝ} (hL : 1 ≤ L) (K : ℕ) :
    (birthAddressBudget K L : ℝ) ≤ 13 * K * L^3 := by
  have hL0 : 0 ≤ L := by linarith
  have hL2 : 1 ≤ L^2 := one_le_pow₀ hL
  have hM : (momentMultiplicity L : ℝ) ≤ 2*L := by
    have hp : L^(1/100:ℝ) ≤ L := by
      simpa using Real.rpow_le_rpow_of_exponent_le hL (show (1/100:ℝ) ≤ 1 by norm_num)
    have hf := Nat.floor_le (Real.rpow_nonneg hL0 (1/100:ℝ))
    simp only [momentMultiplicity, momentPadding, Nat.cast_add, Nat.cast_one]
    linarith
  have hN := momentLength_le_three_mul hL
  have hB : (memoryCutoff L : ℝ) ≤ 2*L^2 := by
    have := memoryCutoff_upper L
    linarith
  have hprod : ((momentLength L : ℝ)+1) * (memoryCutoff L : ℝ) ≤
      8*L^3 := by
    calc
      _ ≤ (4*L) * (2*L^2) :=
        mul_le_mul (by linarith) hB (Nat.cast_nonneg _) (by positivity)
      _ = _ := by ring
  have hL3 : L ≤ L^3 := by nlinarith [sq_nonneg (L-1)]
  simp only [birthAddressBudget, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  have hK : (0:ℝ) ≤ K := Nat.cast_nonneg _
  nlinarith [mul_le_mul_of_nonneg_left hM hK, mul_le_mul_of_nonneg_left hN hK,
    mul_le_mul_of_nonneg_left hprod hK, mul_le_mul_of_nonneg_left hL3 hK]

/-- In the rank sums the entire literal address budget has a fixed polynomial bound. -/
theorem eventually_birthAddressBudget_le (K : ℕ) :
    ∀ᶠ L : ℝ in atTop, (birthAddressBudget K L : ℝ) ≤ L^4 := by
  filter_upwards [eventually_ge_atTop (1:ℝ), eventually_ge_atTop (13*(K:ℝ))] with L hL hK
  exact (birthAddressBudget_le hL K).trans (by
    nlinarith [mul_le_mul_of_nonneg_right hK (pow_nonneg (by linarith : 0 ≤ L) 3)])

/-- Fixed powers are dominated by the literal atom saving, including after
the change of variable `u = L^t`. -/
theorem tendsto_power_mul_exp_neg_rpow (a : ℝ) {b t : ℝ}
    (hb : 0 < b) (ht : 0 < t) :
    Tendsto (fun L : ℝ => L^a * Real.exp (-b * L^t)) atTop (𝓝 0) := by
  have h := (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (a/t) b hb).comp
    (tendsto_rpow_atTop ht)
  apply h.congr'
  filter_upwards [eventually_ge_atTop (0:ℝ)] with L hL
  simp only [Function.comp_apply]
  rw [← Real.rpow_mul hL, mul_div_cancel₀ _ ht.ne']

/-- The entire address-pair cost still leaves half the exponential atom
saving.  This uses the actual polynomial address bound, not a prescribed
asymptotic on a free function `Q`. -/
theorem eventually_birth_atom_ratio (K : ℕ) {D : ℝ} (hD : 0 ≤ D) :
    ∀ᶠ L : ℝ in atTop,
      (birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ))) ≤
        Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)) ∧
      (birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ))) ≤ 1/2 := by
  have hlim : Tendsto (fun L : ℝ => D*(L^(8:ℝ)*
      Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)))) atTop (𝓝 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow 8 (by norm_num : (0:ℝ)<1/2)
      (by norm_num : (0:ℝ)<1/10)).const_mul D
  have hexp : Tendsto (fun L : ℝ => Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))) atTop (𝓝 0) := by
    simpa using tendsto_power_mul_exp_neg_rpow 0 (by norm_num : (0:ℝ)<1/2)
      (by norm_num : (0:ℝ)<1/10)
  filter_upwards [eventually_birthAddressBudget_le K, eventually_ge_atTop (1:ℝ),
    hlim.eventually_lt_const (by norm_num : (0:ℝ)<1),
    hexp.eventually_lt_const (by norm_num : (0:ℝ)<1/2)] with L hQ hL hpoly he
  have hQ2 : (birthAddressBudget K L : ℝ)^2 ≤ L^8 := by
    nlinarith [sq_nonneg (L^4 - (birthAddressBudget K L : ℝ))]
  have heq : Real.exp (-L^(1/10:ℝ)) =
      Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)) * Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  have hbound : (birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ))) ≤
      Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)) := by
    calc
      _ ≤ L^8 * (D*Real.exp (-L^(1/10:ℝ))) :=
        mul_le_mul_of_nonneg_right hQ2 (by positivity)
      _ = (D*(L^(8:ℝ)*Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)))) *
          Real.exp (-(1/2:ℝ)*L^(1/10:ℝ)) := by
        rw [heq]
        norm_num [Real.rpow_natCast]
        ring
      _ ≤ _ := by nlinarith [Real.exp_pos (-(1/2:ℝ)*L^(1/10:ℝ))]
  exact ⟨hbound, hbound.trans he.le⟩

/-- The squared boundary norm majorant from (4.12), after the source
lower bound `p_min ≥ exp(L^.1)`.  Its exponent contains `M*(N+1)`.
It does not contain `M^2`. -/
noncomputable def boundaryNormMajorant (D L : ℝ) : ℝ :=
  Real.exp (D * momentMultiplicity L * ((momentLength L : ℝ)+1) *
    Real.exp (-L^(1/10:ℝ)))

theorem tendsto_boundaryNormMajorant {D : ℝ} (hD : 0 ≤ D) :
    Tendsto (boundaryNormMajorant D) atTop (𝓝 1) := by
  have hlim : Tendsto (fun L : ℝ => 8*D*(L^(2:ℝ)*Real.exp (-L^(1/10:ℝ))))
      atTop (𝓝 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow 2 (by norm_num : (0:ℝ)<1)
      (by norm_num : (0:ℝ)<1/10)).const_mul (8*D)
  have hexp : Tendsto (fun L : ℝ => D * momentMultiplicity L *
      ((momentLength L : ℝ)+1) * Real.exp (-L^(1/10:ℝ))) atTop (𝓝 0) := by
    apply squeeze_zero' (Filter.Eventually.of_forall (fun L => by positivity)) _ hlim
    filter_upwards [eventually_ge_atTop (1:ℝ)] with L hL
    have hM : (momentMultiplicity L : ℝ) ≤ 2*L := by
      have hp : L^(1/100:ℝ) ≤ L := by
        simpa using Real.rpow_le_rpow_of_exponent_le hL
          (show (1/100:ℝ) ≤ 1 by norm_num)
      have hf := Nat.floor_le (Real.rpow_nonneg (by linarith : 0 ≤ L) (1/100:ℝ))
      simp only [momentMultiplicity, momentPadding, Nat.cast_add, Nat.cast_one]
      linarith
    have hN : (momentLength L : ℝ)+1 ≤ 4*L := by
      have := momentLength_le_three_mul hL
      linarith
    have hprod := mul_le_mul hM hN (by positivity : 0 ≤ (momentLength L : ℝ)+1)
      (by linarith : 0 ≤ 2*L)
    have h := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hprod hD) (Real.exp_pos (-L^(1/10:ℝ))).le
    norm_num only [Real.rpow_ofNat]
    nlinarith
  unfold boundaryNormMajorant
  simpa only [Function.comp_def, Real.exp_zero] using (Real.continuous_exp.tendsto 0).comp hexp

theorem eventually_boundaryNormMajorant_le_two {D : ℝ} (hD : 0 ≤ D) :
    ∀ᶠ L : ℝ in atTop, boundaryNormMajorant D L ≤ 2 :=
  ((tendsto_boundaryNormMajorant hD).eventually_lt_const (by norm_num : (1:ℝ)<2)).mono
    fun _ h => h.le

/-- The small-denominator condition used in the exact boundary calculation
follows from the literal source scales. -/
theorem eventually_memory_visits_le_prime_cutoff :
    ∀ᶠ L : ℝ in atTop, 2*((momentLength L:ℝ)+1) ≤ Real.exp (L^(1/10:ℝ)) := by
  have hlim : Tendsto (fun L : ℝ => 8*(L*Real.exp (-L^(1/10:ℝ)))) atTop (𝓝 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow 1 (by norm_num : (0:ℝ)<1)
      (by norm_num : (0:ℝ)<1/10)).const_mul 8
  filter_upwards [hlim.eventually_lt_const (by norm_num : (0:ℝ)<1),
    eventually_ge_atTop (1:ℝ)] with L h hL
  have hfrac : 8*L / Real.exp (L^(1/10:ℝ)) ≤ 1 := by
    simpa [Real.exp_neg, div_eq_mul_inv, mul_assoc] using h.le
  have he := (div_le_iff₀ (Real.exp_pos (L^(1/10:ℝ)))).mp hfrac
  have hN := momentLength_le_three_mul hL
  linarith

end Elliptic.Operator
