module

public import Elliptic.Operator.RootLiteralGeometry
public import Elliptic.Operator.CleanCrossBan

/-! The literal source good-state predicate supplies the first clean
good-state test for the actual shared pad. The omission is the final
active slot in every band, with no replacement of the source predicate. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanGoodProjection
open scoped BigOperators
open RootLiteralGeometry RootEndpointBudget RootGoodBoundary
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 300000

variable {K J : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]

/-- The identity omission in the actual source list is the clean pad. -/
theorem padProduct_mem_omissionProducts
    (value : ∀ i, P i → ℕ) (a : PhysicalActiveLists P J)
    (hinj : Function.Injective (activeLabel value a)) (d₀ : ℝ)
    (hD : d₀≤(sourcePadProduct value a:ℝ))
    (hD' : (sourcePadProduct value a:ℝ)<2*d₀) :
    sourcePadProduct value a ∈
      SourceSecondGoodState.omissionProducts (activeLabel value a) d₀ := by
  have he : sourcePadProduct value a =
      copiedProduct (activeLabel value a) (fun _ => Fin.last J) := by
    convert sourcePadProduct_eq_copiedProduct value a (fun _ => Equiv.refl _) hinj using 1 <;> rfl
  rw [he] at hD hD' ⊢
  exact SourceSecondGoodState.mem_omissionProducts _ d₀ _ hD hD'

/-- Projection of the literal source tests to its actual clean pad, at
the same chosen complement used in the source definition. -/
theorem sourceGood_first_chosen
    (value : ∀ i, P i → ℕ) (μ : ∀ i, P i → ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K → ℝ) (q : RootPhysicalCell.RootPoint)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (hinj : Function.Injective (activeLabel value a))
    (hD : d₀≤(sourcePadProduct value a:ℝ))
    (hD' : (sourcePadProduct value a:ℝ)<2*d₀)
    (hg : sourceGood value μ d₀ Y L exponents q z a) :
    SourceGoodState.FirstGoodTest
      ((sourcePadProduct value a:ℝ)*latticeTau q.2.2 (chosenComplement z)/latticeTau q.2.2 z) Y := by
  have h := hg.1 _ (padProduct_mem_omissionProducts value a hinj d₀ hD hD')
  simpa only [SourceGoodState.FirstGoodTest,phase,mul_div_assoc] using h

/-- Integer changes of unimodular complement leave the clean first test
unchanged, including the actual integer pad multiplier. -/
theorem firstGood_complement_iff (z w v : ℤ×ℤ)
    (hw : latticeDet z w=1) (hv : latticeDet z v=1)
    (r Y : ℝ) (hz : latticeTau r z≠0) (D : ℤ) :
    SourceGoodState.FirstGoodTest ((D:ℝ)*latticeTau r v/latticeTau r z) Y ↔
      SourceGoodState.FirstGoodTest ((D:ℝ)*latticeTau r w/latticeTau r z) Y := by
  have he := latticeTau_ratio_coordinates hw r hz v
  rw [hv,Int.cast_one,one_mul] at he
  have he' : (D:ℝ)*latticeTau r v/latticeTau r z =
      (D:ℝ)*latticeTau r w/latticeTau r z + (D*latticeDet v w:ℤ) := by
    rw [mul_div_assoc,he,Int.cast_mul]
    ring
  rw [he']
  exact SourceGoodState.noSmallMultiple_add_int _ _ _ _

/-- The actual source good-state test supplies the clean first test for
any unimodular complement used by the physical pad coordinates. -/
theorem sourceGood_first
    (value : ∀ i, P i → ℕ) (μ : ∀ i, P i → ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K → ℝ) (q : RootPhysicalCell.RootPoint)
    (z w : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (hzprim : IsCoprime z.1 z.2) (hzw : latticeDet z w=1)
    (hz : latticeTau q.2.2 z≠0)
    (hinj : Function.Injective (activeLabel value a))
    (hD : d₀≤(sourcePadProduct value a:ℝ))
    (hD' : (sourcePadProduct value a:ℝ)<2*d₀)
    (hg : sourceGood value μ d₀ Y L exponents q z a) :
    SourceGoodState.FirstGoodTest
      ((sourcePadProduct value a:ℝ)*latticeTau q.2.2 w/latticeTau q.2.2 z) Y := by
  have h := sourceGood_first_chosen value μ d₀ Y L exponents q z a hinj hD hD' hg
  exact (firstGood_complement_iff z (chosenComplement z) w
    (chosenComplement_spec z hzprim).1 hzw q.2.2 Y hz (sourcePadProduct value a:ℤ)).mpr h

/-- Disjoint actual prime bands and endpoint list injectivity imply the
numeric injectivity needed for the source omission product. -/
theorem actual_activeLabel_injective
    (groups : Fin K → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (a : PhysicalActiveLists (fun i => groups i) J)
    (ha : ∀ i, Function.Injective (a i)) :
    Function.Injective (activeLabel (fun _ p => p.val) a) := by
  rintro ⟨i,k⟩ ⟨j,l⟩ h
  have hij : i=j := by
    by_contra hn
    exact CleanCrossBan.actual_band_separation groups hdis i j hn (a i k) (a j l) h
  subst j
  exact Prod.ext rfl (ha i (Subtype.ext h))

/-- Direct first-test projection for the actual disjoint prime-band
states used by the clean source operator. -/
theorem actual_sourceGood_first
    (groups : Fin K → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (μ : ∀ i, groups i → ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K → ℝ) (q : RootPhysicalCell.RootPoint)
    (z w : ℤ×ℤ) (a : PhysicalActiveLists (fun i => groups i) J)
    (hzprim : IsCoprime z.1 z.2) (hzw : latticeDet z w=1)
    (hz : latticeTau q.2.2 z≠0) (ha : ∀ i, Function.Injective (a i))
    (hD : d₀≤(sourcePadProduct (fun _ p => p.val) a:ℝ))
    (hD' : (sourcePadProduct (fun _ p => p.val) a:ℝ)<2*d₀)
    (hg : sourceGood (fun _ p => p.val) μ d₀ Y L exponents q z a) :
    SourceGoodState.FirstGoodTest
      ((sourcePadProduct (fun _ p => p.val) a:ℝ)*latticeTau q.2.2 w/latticeTau q.2.2 z) Y :=
  sourceGood_first (P:=fun i => (groups i : Type)) (fun _ p => p.val) μ d₀ Y L exponents q z w a hzprim hzw hz
    (actual_activeLabel_injective groups hdis a ha) hD hD' hg

end Elliptic.Operator.PhysicalCleanGoodProjection
