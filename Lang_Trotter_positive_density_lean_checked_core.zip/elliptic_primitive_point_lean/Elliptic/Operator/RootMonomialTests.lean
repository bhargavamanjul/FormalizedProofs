module

public import Elliptic.Operator.RootRecordComparison

/-! # The positive gap uses the same actual small-support tests -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootMonomialTests
open scoped BigOperators
open RootRecordBonferroni OriginalPathWeights SourceBonferroni
open BonferroniMonomialCount SignedBonferroniTransfer RootLiteralSum
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

def gapTest (rec : Record K J N R Q) (η : ℕ→ℝ) (k : ℕ) (s : Finset ℕ)
    (ℓ : ∀p : ↥(activePrimes rec∪s),Option (ZMod p)) : ℂ :=
  if s.card=k then coupledSubsetTest (fun p=>Option (ZMod p)) (activePrimes rec) s
    (fun _=>1) (loss rec η) ℓ else 0

theorem gapTest_restrict (rec : Record K J N R Q) (η : ℕ→ℝ) (k : ℕ) (s : Finset ℕ)
    (ℓ : (p : ℕ)→Option (ZMod p)) :
    gapTest rec η k s (fun p=>ℓ p) = if s.card=k then ∏p∈s,(loss rec η p (ℓ p):ℂ) else 0 := by
  simp only [gapTest,coupledSubsetTest_restrict,one_mul]

theorem gapTest_norm_le (rec : Record K J N R Q) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (k : ℕ) (s : Finset ℕ)
    (ℓ : ∀p : ↥(activePrimes rec∪s),Option (ZMod p)) : ‖gapTest rec η k s ℓ‖≤1 := by
  unfold gapTest
  split_ifs
  · exact coupledSubsetTest_norm_le _ _ _ _ _ (by intro l; norm_num)
      (fun p hp l=>loss_bounds rec η hη p l) ℓ
  · norm_num

theorem elementary_subsets (primes : Finset ℕ) (w : ℕ→ℝ) (k T : ℕ) (hk : k≤T) :
    (elementary primes w k:ℂ)=∑s∈truncatedSubsets primes T,
      if s.card=k then ∏p∈s,(w p:ℂ) else 0 := by
  have he : (truncatedSubsets primes T).filter (fun s=>s.card=k)=primes.powersetCard k := by
    ext s
    simp only [Finset.mem_filter,mem_truncatedSubsets,Finset.mem_powersetCard]
    constructor
    · rintro ⟨⟨hs,_⟩,hc⟩
      exact ⟨hs,hc⟩
    · rintro ⟨hs,hc⟩
      exact ⟨⟨hs,by omega⟩,hc⟩
  rw [←Finset.sum_filter,he]
  simp only [elementary,Complex.ofReal_sum,Complex.ofReal_prod]

theorem gap_sparse (rec : Record K J N R Q) (primes : Finset ℕ) (η : ℕ→ℝ)
    (k T : ℕ) (hk : k≤T) (ℓ : (p : ℕ)→Option (ZMod p)) :
    (elementary primes (fun p=>loss rec η p (ℓ p)) k:ℂ)=
      ∑s∈truncatedSubsets primes T,gapTest rec η k s (fun p=>ℓ p) := by
  simp_rw [gapTest_restrict]
  exact elementary_subsets _ _ k T hk

theorem literalGap_cast (U V : ℝ) (b : Matrix.SpecialLinearGroup (Fin 2) ℤ→ℝ) :
    (literalGap U V b:ℂ)=literalRootSum U V (fun _ g=>(b g:ℂ)) := by
  unfold literalGap literalRootSum
  push_cast
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : SourceRootCount.Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs <;> simp
  · simp [hcan]

theorem literalGap_sparse (rec : Record K J N R Q) (primes : Finset ℕ) (η : ℕ→ℝ)
    (k T : ℕ) (hk : k≤T) (U V : ℝ)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) :
    (RootRecordComparison.rootGap rec primes η k U V ℓ:ℂ)=
      ∑s∈truncatedSubsets primes T,literalRootSum U V (fun _ g=>gapTest rec η k s (fun p=>ℓ g p)) := by
  rw [RootRecordComparison.rootGap,literalGap_cast,←literalRootSum_sum]
  apply literalRootSum_congr
  intro q g
  exact gap_sparse _ _ _ k T hk _

end Elliptic.Operator.RootMonomialTests
