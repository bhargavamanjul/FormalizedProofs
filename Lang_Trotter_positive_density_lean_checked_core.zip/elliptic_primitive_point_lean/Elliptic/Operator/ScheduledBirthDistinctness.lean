module

public import Elliptic.Operator.CompatibleBirthDistinctness
public import Elliptic.Operator.ScheduledActiveBirths

/-!
# Distinct numerical births in actual scheduled histories

The actual padded logger counts every lifespan label exactly once: initially
active labels, ghost births, and fresh edge targets form the lifespan birth
partition. Global injectivity of the numerical labels therefore implies the
original performed-birth restriction for every compatible history, including
histories whose coefficient vanishes.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open LifespanSchedule ScheduledPhysicalPath ActualHistoryObservation
open CompatibleBirthDistinctness
attribute [local instance] Classical.propDecidable
local instance scheduledBirthDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace ScheduledBirthDistinctness

/-- The disjoint chronological birth partition gives an exact additive
accounting for each lifespan label. -/
theorem lifespan_birth_sum {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (w : P → ℕ) :
    (∑ j ∈ Finset.range (N+1),
      ((∑ p ∈ births S L j, w p) + (∑ p ∈ activeBirths S L j, w p))) = ∑ p ∈ S, w p := by
  have hu (j : ℕ) :
      (∑ p ∈ births S L j, w p) + (∑ p ∈ activeBirths S L j, w p) =
        ∑ p ∈ S.filter (fun p => (L p).birth = j), w p := by
    rw [← Finset.sum_union (births_disjoint_activeBirths S L j),birth_partition]
  calc
    _ = ∑ j ∈ Finset.range (N+1), ∑ p ∈ S.filter (fun p => (L p).birth = j), w p :=
      Finset.sum_congr rfl (fun j _ => hu j)
    _ = _ := ?_
  apply Finset.sum_fiberwise_of_maps_to
  intro p hp
  exact Finset.mem_range.mpr (Nat.lt_succ_of_le
    ((L p).birth_le_death.trans (L p).death_le))

/-- A finset's mapped multiset count is its literal numerical-label sum. -/
theorem mapped_count {P : Type*} (S : Finset P) (value : P → ℕ) (p : ℕ) :
    (S.val.map value).count p = ∑ a ∈ S, if value a = p then 1 else 0 := by
  rw [Multiset.count_map,← Finset.filter_val]
  simp only [Finset.sum_boole,Nat.cast_id,eq_comm]
  rfl

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable (anchor : Z → ∀ i p, Line i p)
variable (d : ScheduledPhysicalPath anchor N J B)

/-- Initial active slots plus later fresh targets enumerate exactly all
active births. The exclusion hypothesis is the literal target/source ban. -/
theorem active_birth_count (value : ∀ i, P i → ℕ) (i : I) (p : ℕ)
    (hnew : ∀ j, j < N → ∀ k, d.targetPrime j i ≠ d.active j i k) :
    (∑ a : Fin (J+1), if value i (d.active 0 i a) = p then 1 else 0 : ℕ) +
      (∑ j : Fin N, if (if d.promote j.val i then none else some (d.targetPrime j.val i)).map
        (value i) = some p then 1 else 0) =
      ∑ j : Fin (N+1), ∑ a ∈ activeBirths (d.primes i) (d.lifespan i) j.val,
        if value i a = p then 1 else 0 := by
  have hzero : (∑ a : Fin (J+1), if value i (d.active 0 i a) = p then 1 else 0 : ℕ) =
      ∑ a ∈ activeBirths (d.primes i) (d.lifespan i) 0,
        if value i a = p then 1 else 0 := by
    rw [d.activeBirths_zero]
    exact (Finset.sum_image (f := fun a => (if value i a = p then 1 else 0 : ℕ))
      (fun _ _ _ _ h => d.active_distinct 0 (Nat.zero_le N) i h)).symm
  have hnext (j : Fin N) :
      (if (if d.promote j.val i then none else some (d.targetPrime j.val i)).map
        (value i) = some p then 1 else 0 : ℕ) =
      ∑ a ∈ activeBirths (d.primes i) (d.lifespan i) (j.val+1),
        if value i a = p then 1 else 0 := by
    rw [d.activeBirths_succ j.val j.isLt i (hnew j.val j.isLt)]
    cases he : d.promote j.val i <;>
      by_cases hp : value i (d.targetPrime j.val i) = p <;> simp [optionalPrimeSet,Finset.filter_singleton,hp]
  simp_rw [hzero,hnext]
  rw [Fin.sum_univ_succ (fun j : Fin (N+1) =>
    ∑ a ∈ activeBirths (d.primes i) (d.lifespan i) j.val,
      if value i a = p then 1 else 0)]
  rfl

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Compatibility identifies the actual padded ghost logger with the
specified ghost-birth finset at that visit. -/
theorem ghost_count_of_compatible
    (value : ∀ i, P i → ℕ)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h)
    (k : Fin (N+1)) (i : I) (p : ℕ) :
    (∑ a : Fin B, if (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry N 0
      d.initialState h k i a).map (value i) = some p then 1 else 0 : ℕ) =
      ∑ a ∈ births (d.primes i) (d.lifespan i) k.val,
        if value i a = p then 1 else 0 := by
  rw [ghostAt_count]
  have hg := (ghostMatches_of_compatible ν V η q ρ anchor geometry d N 0
    d.initialState h hc k).2 i
  simp only [Nat.zero_add] at hg
  rw [hg,mapped_count]

/-- Compatibility identifies fresh target draws without counting promotions. -/
theorem fresh_count_of_compatible
    (value : ∀ i, P i → ℕ)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h)
    (k : Fin N) (i : I) (p : ℕ) :
    (if (ActualHistoryBirths.freshAt ν V η q ρ anchor geometry N 0
      d.initialState h k i).map (value i) = some p then 1 else 0 : ℕ) =
      if (if d.promote k.val i then none else some (d.targetPrime k.val i)).map
        (value i) = some p then 1 else 0 := by
  rw [freshAt_eq_record]
  have he := compatible_edgeAt ν V η q ρ anchor geometry d N 0 d.initialState h hc k
  rw [he.2.2.2.2.1,he.2.2.2.2.2]
  simp only [Nat.zero_add]

/-- Every lifespan label appears exactly once in the actual performed-birth
logger. This is an equality of counts, before any numerical injectivity. -/
theorem labels_count_of_compatible
    (value : ∀ i, P i → ℕ)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h)
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (p : ℕ) :
    birthCount (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
      d.initialState h) p =
      ∑ i, ∑ a ∈ d.primes i, if value i a = p then 1 else 0 := by
  rw [labels_count]
  simp_rw [ghost_count_of_compatible anchor d ν V η q ρ geometry value h hc,
    fresh_count_of_compatible anchor d ν V η q ρ geometry value h hc]
  change (∑ i, ∑ a : Fin (J+1), if value i (d.active 0 i a) = p then 1 else 0 : ℕ) +
    ((∑ k : Fin (N+1), ∑ i, ∑ a ∈ births (d.primes i) (d.lifespan i) k.val,
      if value i a = p then 1 else 0) +
     (∑ k : Fin N, ∑ i,
      if (if d.promote k.val i then none else some (d.targetPrime k.val i)).map
        (value i) = some p then 1 else 0)) = _
  rw [Finset.sum_comm (s:=Finset.univ) (t:=Finset.univ)
      (f:=fun k : Fin (N+1) => fun i => ∑ a ∈ births (d.primes i) (d.lifespan i) k.val,
        if value i a = p then 1 else 0),
    Finset.sum_comm (s:=Finset.univ) (t:=Finset.univ)
      (f:=fun k : Fin N => fun i =>
        if (if d.promote k.val i then none else some (d.targetPrime k.val i)).map
          (value i) = some p then 1 else 0)]
  rw [← Finset.sum_add_distrib,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [show (∑ a : Fin (J+1), if value i (d.active 0 i a) = p then 1 else 0 : ℕ) +
      ((∑ k : Fin (N+1), ∑ a ∈ births (d.primes i) (d.lifespan i) k.val,
        if value i a = p then 1 else 0) +
       (∑ k : Fin N, if (if d.promote k.val i then none else some (d.targetPrime k.val i)).map
          (value i) = some p then 1 else 0)) =
      (∑ k : Fin (N+1), ∑ a ∈ births (d.primes i) (d.lifespan i) k.val,
        if value i a = p then 1 else 0) +
      ((∑ a : Fin (J+1), if value i (d.active 0 i a) = p then 1 else 0) +
       (∑ k : Fin N, if (if d.promote k.val i then none else some (d.targetPrime k.val i)).map
          (value i) = some p then 1 else 0)) by omega]
  rw [active_birth_count anchor d value i p (fun j hj => hnew j hj i),
    ← Finset.sum_add_distrib]
  rw [Fin.sum_univ_eq_sum_range (fun j =>
    (∑ a ∈ births (d.primes i) (d.lifespan i) j, if value i a = p then 1 else 0) +
    (∑ a ∈ activeBirths (d.primes i) (d.lifespan i) j, if value i a = p then 1 else 0))]
  exact lifespan_birth_sum (d.primes i) (d.lifespan i) _

/-- Globally injective numerical labels have multiplicity at most one in
any selected collection of group-labelled primes. -/
theorem prime_count_le_one (value : ∀ i, P i → ℕ)
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (S : ∀ i, Finset (P i)) (p : ℕ) :
    (∑ i, ∑ a ∈ S i, if value i a = p then 1 else 0 : ℕ) ≤ 1 := by
  rw [Finset.sum_sigma']
  simp only [Finset.sum_boole,Nat.cast_id]
  apply Finset.card_le_one.mpr
  intro a ha b hb
  exact hvalue ((Finset.mem_filter.mp ha).2.trans (Finset.mem_filter.mp hb).2.symm)

/-- Global numerical injectivity and the actual cross-edge exclusion imply
performed-birth distinctness for every history compatible with the schedule. -/
theorem birthsDistinct_of_compatible
    (value : ∀ i, P i → ℕ)
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h)
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k) :
    BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
      d.initialState h) := by
  apply (birthsDistinct_iff_counts _).mpr
  intro p
  rw [labels_count_of_compatible anchor d ν V η q ρ geometry value h hc hnew]
  exact prime_count_le_one value hvalue d.primes p

/-- Every simultaneous fresh-batch ordering reconstructs a history with
distinct performed numerical births, including zero-weight histories. -/
theorem finiteHistory_birthsDistinct
    (value : ∀ i, P i → ℕ)
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (x : d.BirthFamily) :
    BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
      d.initialState (d.finiteHistory ν V η q ρ geometry x)) := by
  exact birthsDistinct_of_compatible anchor d ν V η q ρ geometry value hvalue
    (d.finiteHistory ν V η q ρ geometry x)
    (d.finiteHistory_compatible ν V η q ρ geometry x) hnew

end ScheduledBirthDistinctness
end Elliptic.Operator
