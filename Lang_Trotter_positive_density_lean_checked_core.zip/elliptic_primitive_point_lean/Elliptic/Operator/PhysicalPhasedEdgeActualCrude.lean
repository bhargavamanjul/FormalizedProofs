module

public import Elliptic.Operator.PhysicalPhasedEdgeAsymptotics
public import Elliptic.Operator.PhysicalPhasedEdgeOrderedNorm
public import Elliptic.Operator.PhysicalDirtySourceProjection

/-! A uniform polynomial norm bound for the actual source-good physical
edge with arbitrary bounded birth phases. All physical row projections
are discharged and the conclusion is in the original factorial norm. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdgeActualCrude
open Filter
open scoped BigOperators
open PhysicalPhasedWord PhysicalBirthFactors PhysicalBagNorm PhysicalDirtySourceProjection RootLiteralGeometry
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 400000

 theorem support_transport {X : Type} (s t u v : Finset X)
    (hs : ∀x,x∈s) (ht : ∀x,x∈t) (hu : ∀x,x∈u) (hv : ∀x,x∈v)
    (m : X→ℝ) (A : X→X→ℂ) (M : ℝ)
    (h : ∀F : X→ℂ,finiteL2 s m (fun x=>∑y∈t,A x y*F y)≤M*finiteL2 t m F) :
    ∀F : X→ℂ,finiteL2 u m (fun x=>∑y∈v,A x y*F y)≤M*finiteL2 v m F := by
  have hs' : s=u := Finset.ext (fun x=>iff_of_true (hs x) (hu x))
  have ht' : t=v := Finset.ext (fun x=>iff_of_true (ht x) (hv x))
  simpa only [hs',ht'] using h

 theorem norm_support_transport {X : Type} (s t : Finset X)
    (hs : ∀x,x∈s) (ht : ∀x,x∈t) (m : X→ℝ) (F T : X→ℂ) (M : ℝ)
    (h : finiteL2 s m T≤M*finiteL2 s m F) : finiteL2 t m T≤M*finiteL2 t m F := by
  have he : s=t := Finset.ext (fun x=>iff_of_true (hs x) (ht x))
  simpa only [he] using h

 theorem exists_group_count_for_actual_modified_bound :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀ρ v0 vmin vmax M Aη Aψ E C : ℝ,
      0≤ρ→ρ<1→0<v0→0<vmin→0≤M→0≤Aψ→1≤C→
      ∀ᶠL : ℝ in atTop,∀a : Fin K→ℝ,(∀i,(1/10:ℝ)≤a i)→
        ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i p,Fintype (ZMod (p:groups i).val)),
        (∀i,∀p∈groups i,p.Prime)→
        ∀(ν μ : ∀i,groups i→ℝ) (V : Fin K→ℝ),
        (∀i p,0<ν i p)→(∀i p,ν i p≤2*μ i p)→(∀i,(∑p,ν i p)≤M)→
        (∀i,vmin≤V i)→(∀i,V i≤vmax)→
        (∀i p,Real.exp (L^a i)≤((p:groups i).val:ℝ))→
        ∀(qroot : RootPhysicalCell.RootPoint) (U W d₀ Y H : ℝ) (η ψ : ℝ→ℂ) (σ : ℤ),
        0<U→1≤qroot.1→qroot.1≤16→0<d₀→Real.exp (L^(1/10:ℝ))≤Y→0≤H→H≤L^E→
        (σ=1 ∨ σ= -1)→(∀t,‖η t‖≤Aη)→(∀t,‖ψ t‖≤Aψ)→(∀t,ψ t≠0→|t|≤C)→
        ∀(phase : Fin K→Option ℕ→ℂ),(∀i b,‖phase i b‖≤1)→
        ∀F : PhysicalMemoryState (Z:=positions) (fun i=>groups i)
          (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L)→ℂ,
        IsBagFunction F→
        finiteL2 Finset.univ (PhysicalMemoryState.mass (fun i=>groups i)
          (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L) ν)
          (phasedApply (physicalEdgeOperation ν V ρ (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) Subtype.val)
            (fun (z:positions) b (w:positions) c=>sourcePhysicalEdgeGeometry (fun i (p:groups i)=>p.val)
              (sourceGood (fun i (p:groups i)=>p.val) μ d₀ Y L a qroot)
              (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val b w.val c))
            (fun _ c=>edgeFactor (fun i (p:groups i)=>p.val) (fun _=>phase) 0 c) F)≤
        L^(PhysicalPhasedEdgeAsymptotics.degree K E+1)*
          finiteL2 Finset.univ (PhysicalMemoryState.mass (fun i=>groups i)
            (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L) ν) F := by
  obtain ⟨K₀,hK₀,hbudget⟩ := PhysicalPhasedEdgeAsymptotics.exists_group_count_for_modified_budget
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ρ v0 vmin vmax M Aη Aψ E C hρ0 hρ1 hv0 hmin hM hψ0 hC
  filter_upwards [eventually_ge_atTop (1:ℝ),hbudget K hK ρ v0 vmin vmax M (Aη^2*Aψ) E C
    hρ1 hv0 hmin hM (mul_nonneg (sq_nonneg _) hψ0) (by linarith)] with L hL hb
  intro a ha positions groups instLine hprime ν μ V hν hνμ hmass hlo hhi hband
    qroot U W d₀ Y H η ψ σ hU hq1 hq16 hd hY hH hHl hσ hη hψ hsupport phase hphase F hF
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  let R := Real.exp (L^(1/10:ℝ))
  have hR : 0<R := Real.exp_pos _
  have hR1 : 1≤R := Real.one_le_exp (by positivity)
  have hY1 : 1≤Y := hR1.trans hY
  have hband' : ∀i (p:groups i),R≤(p.val:ℝ) := by
    intro i p
    apply (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (ha i))).trans
    exact hband i p
  let good := admissibleGood (fun _ (p:groups _)=>p.val)
    (sourceGood (J:=momentPadding L) (fun i (p:groups i)=>p.val) μ d₀ Y L a qroot) d₀
  let geo := fun (z:positions) b (w:positions) c=>sourcePhysicalEdgeGeometry (fun i (p:groups i)=>p.val) good
    (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val b w.val c
  have hgeo : geo=(fun (z:positions) b (w:positions) c=>sourcePhysicalEdgeGeometry (fun i (p:groups i)=>p.val)
      (sourceGood (J:=momentPadding L) (fun i (p:groups i)=>p.val) μ d₀ Y L a qroot)
      (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val b w.val c) := by
    funext z b w c
    exact geometry_admissible_eq (fun i (p:groups i)=>p.val)
      (sourceGood (J:=momentPadding L) (fun i (p:groups i)=>p.val) μ d₀ Y L a qroot)
      (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val w.val b c
  have hbound := fun f=>PhysicalPhasedEdgeNorm.actual_phased_edge_schur (B:=memoryCutoff L) (fun _ (p:groups _)=>p.val)
    (fun z:positions=>z.val) Subtype.val_injective (fun i p=>hprime i p.val p.property)
    ν μ hν V ρ v0 vmin M L a good (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y H C R
    Aη Aψ η ψ σ hU (by nlinarith) (by nlinarith) hd hY1 hH hC hR hσ hη hψ hsupport
    (first_projection (fun _ (p:groups _)=>p.val) μ d₀ Y L a qroot)
    (second_projection (fun _ (p:groups _)=>p.val) μ d₀ Y L a qroot)
    hband hband' hνμ hlo hmin hρ0 hρ1 hv0 hM hmass phase hphase f
  have hop := PhysicalPhasedEdgeOrderedNorm.phasedApply_l2_of_kernel_bound (J:=momentPadding L) (B:=memoryCutoff L) ν V ρ
    (PhysicalRawMaskedRow.anchor (fun _ (p:groups _)=>p.val) (fun z:positions=>z.val)) geo
    (fun _ (p:groups _)=>p.val) (fun i p=>(hν i p).ne') phase _ (by
      intro f
      exact support_transport _ _ _ _
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        _ _ _ hbound f) F hF
  rw [hgeo] at hop
  have hb' := hb a ha (fun i=>groups i) (fun i=>inferInstance) ν V H Y R (fun i p=>(hν i p).le)
    hmass hlo hhi hH hHl hY le_rfl
  refine le_trans ?_ (mul_le_mul_of_nonneg_right hb' (Real.sqrt_nonneg _))
  exact norm_support_transport _ _ (by intro x; simp only [Finset.mem_univ])
    (by intro x; simp only [Finset.mem_univ]) _ _ _ _ hop

end Elliptic.Operator.PhysicalPhasedEdgeActualCrude
