module

public import Elliptic.Operator.PhysicalDirtyRow
public import Elliptic.Operator.MomentParameters

/-! The actual raw dirty-row budget with growing memory and slot counts.
The number of groups needed for a given saving is independent of all
later fixed coefficient constants and band exponents. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirtyRowAsymptotics
open Filter PhysicalDirtyRow
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

/-- The fixed coefficient of the source omission gain. -/
def separatedConstant (K : ℕ) (ρ v0 vmin mass : ℝ) : ℝ :=
  ∑ i : Fin K, 33 * (((1+v0)*vmin⁻¹/v0) *
    ((1+v0)*(vmin⁻¹/(v0*(1-ρ))+mass))^Fintype.card {j : Fin K // j≠i})

theorem separatedBudget_eq (K J B : ℕ) (ρ v0 vmin mass : ℝ) :
    separatedBudget K J B ρ v0 vmin mass =
      separatedConstant K ρ v0 vmin mass * (B:ℝ)/(J+1:ℝ)^K := by
  unfold separatedBudget separatedConstant
  rw [Finset.sum_mul,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  ring

def exceptionalConstant (K : ℕ) (ρ v0 vmin : ℝ) : ℝ :=
  33 * ∑ i : Fin K, (2:ℝ)^K * DirtyExceptionalOuter.storeBudget ρ v0 vmin i * (2:ℝ)^K

theorem exceptionalBudget_le (K B : ℕ) (ρ v0 vmin L : ℝ) (a : Fin K→ℝ)
    (hL : 1≤L) (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin)
    (ha : ∀ i, (1/10:ℝ)≤a i) :
    exceptionalBudget K B ρ v0 vmin L a ≤
      exceptionalConstant K ρ v0 vmin * (B+1:ℝ)^K * B * Real.exp (-(L^(1/10:ℝ))/4) := by
  have hcoef (i : Fin K) : 0≤DirtyExceptionalOuter.storeBudget ρ v0 vmin i := by
    unfold DirtyExceptionalOuter.storeBudget
    positivity
  unfold exceptionalBudget exceptionalConstant
  calc
    _ ≤ 33*(B+1:ℝ)^K * ∑ i : Fin K,
        B*(2:ℝ)^K*DirtyExceptionalOuter.storeBudget ρ v0 vmin i *
          ((2:ℝ)^K*Real.exp (-(L^(1/10:ℝ))/4)) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply Finset.sum_le_sum
      intro i _
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg (by positivity) (hcoef i))
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply Real.exp_le_exp.mpr
      have h := Real.rpow_le_rpow_of_exponent_le hL (ha i)
      linarith
    _ = _ := by
      simp_rw [Finset.mul_sum,Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i _
      ring

theorem separatedBudget_source_le (K : ℕ) (ρ v0 vmin mass L : ℝ)
    (hL : 1≤L) (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hmass : 0≤mass) :
    separatedBudget K (momentPadding L) (memoryCutoff L) ρ v0 vmin mass ≤
      (2*separatedConstant K ρ v0 vmin mass)*L^(2-(K:ℝ)/100) := by
  have hL0 : 0<L := by linarith
  have hM : L^(1/100:ℝ)≤(momentPadding L+1:ℝ) := by
    exact (Nat.lt_floor_add_one (L^(1/100:ℝ))).le
  have hB : (memoryCutoff L:ℝ)≤2*L^2 := by
    have hh := memoryCutoff_upper L
    have h1 := one_le_pow₀ hL (n:=2)
    linarith
  have hconst : 0≤separatedConstant K ρ v0 vmin mass := by
    unfold separatedConstant
    apply Finset.sum_nonneg
    intro i _
    positivity
  rw [separatedBudget_eq]
  calc
    _ ≤ separatedConstant K ρ v0 vmin mass * (2*L^2)/(L^(1/100:ℝ))^K := by
      apply div_le_div₀ (by positivity)
        (mul_le_mul_of_nonneg_left hB hconst) (by positivity)
        (pow_le_pow_left₀ (by positivity) hM K)
    _ = _ := by
      rw [←Real.rpow_mul_natCast hL0.le]
      have he : L^2/L^((1/100:ℝ)*(K:ℝ))=L^(2-(K:ℝ)/100) := by
        rw [←Real.rpow_natCast L 2,←Real.rpow_sub hL0]
        congr 1
        norm_num
        ring
      rw [←he]
      ring

/-- Any fixed polynomial times the literal exceptional exponential has
arbitrary logarithmic decay, with one threshold for all exponents a_i≥.1. -/
theorem eventually_exceptionalBudget_small (K : ℕ) (ρ v0 vmin D : ℝ)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ a : Fin K→ℝ, (∀ i,(1/10:ℝ)≤a i) →
      exceptionalBudget K (memoryCutoff L) ρ v0 vmin L a ≤ L^(-D) := by
  let C := 2*3^K*exceptionalConstant K ρ v0 vmin
  have hC : 0≤C := by
    dsimp [C,exceptionalConstant]
    apply mul_nonneg (by positivity)
    apply mul_nonneg (by positivity)
    apply Finset.sum_nonneg
    intro i _
    unfold DirtyExceptionalOuter.storeBudget
    positivity
  have hlim : Tendsto (fun L : ℝ => C*(L^(2*(K:ℝ)+2+D)*Real.exp (-(1/4:ℝ)*L^(1/10:ℝ))))
      atTop (nhds 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow (2*K+2+D)
      (by norm_num : (0:ℝ)<1/4) (by norm_num : (0:ℝ)<1/10)).const_mul C
  have ht := hlim.eventually_lt_const (by norm_num : (0:ℝ)<1)
  filter_upwards [eventually_ge_atTop (1:ℝ),ht] with L hL ht
  intro a ha
  have hL0 : 0<L := by linarith
  have h1 := one_le_pow₀ hL (n:=2)
  have hB : (memoryCutoff L:ℝ)≤2*L^2 := by linarith [memoryCutoff_upper L]
  have hB1 : (memoryCutoff L+1:ℝ)≤3*L^2 := by linarith
  have hb := exceptionalBudget_le K (memoryCutoff L) ρ v0 vmin L a hL hρ hv0 hmin ha
  have hc0 : 0≤exceptionalConstant K ρ v0 vmin := by
    unfold exceptionalConstant
    apply mul_nonneg (by positivity)
    apply Finset.sum_nonneg
    intro i _
    unfold DirtyExceptionalOuter.storeBudget
    positivity
  have hraw : exceptionalBudget K (memoryCutoff L) ρ v0 vmin L a ≤
      C*L^(2*(K:ℝ)+2)*Real.exp (-(1/4:ℝ)*L^(1/10:ℝ)) := by
    apply hb.trans
    calc
      _ ≤ exceptionalConstant K ρ v0 vmin * (3*L^2)^K * (2*L^2) *
          Real.exp (-(L^(1/10:ℝ))/4) := by gcongr
      _ = _ := by
        rw [mul_pow,←pow_mul]
        dsimp [C]
        rw [Real.rpow_add hL0,Real.rpow_ofNat]
        have he : L^(2*(K:ℝ))=L^(2*K) := by
          rw [←Real.rpow_natCast L (2*K)]
          norm_cast
        rw [he]
        congr 1 <;> ring
  have ht' : C*L^(2*(K:ℝ)+2)*Real.exp (-(1/4:ℝ)*L^(1/10:ℝ)) ≤ L^(-D) := by
    have hp : 0<L^D := by positivity
    apply (mul_le_mul_iff_right₀ hp).mp
    rw [←Real.rpow_add hL0]
    norm_num
    calc
      _ = C*(L^(2*(K:ℝ)+2+D)*Real.exp (-(1/4:ℝ)*L^(1/10:ℝ))) := by
        rw [Real.rpow_add hL0 (2*(K:ℝ)+2) D]; ring
      _ ≤ 1 := ht.le
  exact hraw.trans ht'

/-- K is chosen solely from the requested row saving. All fixed Schur
weights, masses and exponent lists come afterward; only the onset depends
on these later constants. -/
theorem exists_group_count_for_row_saving (D : ℝ) :
    ∃ K₀ : ℕ, 1≤K₀ ∧ ∀ K : ℕ, K₀≤K →
      ∀ ρ v0 vmin mass : ℝ, ρ<1 → 0<v0 → 0<vmin → 0≤mass →
      ∀ᶠ L : ℝ in atTop, ∀ a : Fin K→ℝ, (∀ i,(1/10:ℝ)≤a i) →
        separatedBudget K (momentPadding L) (memoryCutoff L) ρ v0 vmin mass +
          exceptionalBudget K (memoryCutoff L) ρ v0 vmin L a ≤ L^(-D) := by
  refine ⟨max 1 ⌈100*(D+4)⌉₊,le_max_left _ _,?_⟩
  intro K hK ρ v0 vmin mass hρ hv0 hmin hmass
  have hK' : 100*(D+4)≤(K:ℝ) := by
    apply (Nat.le_ceil _).trans
    exact_mod_cast (le_max_right 1 ⌈100*(D+4)⌉₊).trans hK
  filter_upwards [eventually_ge_atTop (2:ℝ),
    eventually_ge_atTop (2*separatedConstant K ρ v0 vmin mass),
    eventually_exceptionalBudget_small K ρ v0 vmin (D+1) hρ hv0 hmin] with L hL hc he
  intro a ha
  have hL1 : 1≤L := by linarith
  have hL0 : 0<L := by linarith
  have hs := separatedBudget_source_le K ρ v0 vmin mass L hL1 hρ hv0 hmin hmass
  have hs' : separatedBudget K (momentPadding L) (memoryCutoff L) ρ v0 vmin mass ≤
      L^(-(D+1)) := by
    calc
      _ ≤ (2*separatedConstant K ρ v0 vmin mass)*L^(2-(K:ℝ)/100) := hs
      _ ≤ L*L^(2-(K:ℝ)/100) := mul_le_mul_of_nonneg_right hc (by positivity)
      _ = L^(3-(K:ℝ)/100) := by
        rw [show (3-(K:ℝ)/100)=1+(2-(K:ℝ)/100) by ring,Real.rpow_add hL0,Real.rpow_one]
      _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hL1 (by linarith)
  calc
    _ ≤ L^(-(D+1))+L^(-(D+1)) := add_le_add hs' (he a ha)
    _ ≤ L*L^(-(D+1)) := by nlinarith [Real.rpow_pos_of_pos hL0 (-(D+1))]
    _ = _ := by rw [show -D=1+(-(D+1)) by ring,Real.rpow_add hL0,Real.rpow_one]

/-- Fixed numbers of masks and the bounded opposite Schur side do not
enter the choice of K. This is the exact square-root loss used in the
three dirty cases. -/
theorem exists_group_count_for_schur_saving (G : ℝ) :
    ∃ K₀ : ℕ, 1≤K₀ ∧ ∀ K : ℕ, K₀≤K →
      ∀ ρ v0 vmin mass T C : ℝ, ρ<1 → 0<v0 → 0<vmin → 0≤mass → 0≤T → 0≤C →
      ∀ᶠ L : ℝ in atTop, ∀ a : Fin K→ℝ, (∀ i,(1/10:ℝ)≤a i) →
        T*Real.sqrt (C*(separatedBudget K (momentPadding L) (memoryCutoff L) ρ v0 vmin mass +
          exceptionalBudget K (memoryCutoff L) ρ v0 vmin L a)) ≤ L^(-G) := by
  obtain ⟨K₀,hK₀,h⟩ := exists_group_count_for_row_saving (2*G+4)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ρ v0 vmin mass T C hρ hv0 hmin hmass hT hC
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop (T*Real.sqrt C),
    h K hK ρ v0 vmin mass hρ hv0 hmin hmass] with L hL hc hb
  intro a ha
  have hL0 : 0<L := by linarith
  calc
    _ = (T*Real.sqrt C)*Real.sqrt
        (separatedBudget K (momentPadding L) (memoryCutoff L) ρ v0 vmin mass +
          exceptionalBudget K (memoryCutoff L) ρ v0 vmin L a) := by
      rw [Real.sqrt_mul hC]; ring
    _ ≤ L*Real.sqrt (L^(-(2*G+4))) := by
      apply mul_le_mul hc (Real.sqrt_le_sqrt (hb a ha)) (Real.sqrt_nonneg _) (by linarith)
    _ = L^(1+(-(2*G+4))*(1/2:ℝ)) := by
      rw [Real.sqrt_eq_rpow,←Real.rpow_mul hL0.le,Real.rpow_add hL0,Real.rpow_one]
    _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hL (by linarith)

end Elliptic.Operator.DirtyRowAsymptotics
