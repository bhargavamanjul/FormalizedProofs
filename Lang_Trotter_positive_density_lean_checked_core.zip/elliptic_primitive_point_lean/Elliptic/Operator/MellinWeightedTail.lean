module

public import Elliptic.Operator.MellinPlaneSums
public import Mathlib.Analysis.SpecificLimits.Normed
public import Mathlib.MeasureTheory.Measure.Lebesgue.Integral

/-! Weighted frequency tails from uniform interval mean-square estimates. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinWeightedTail
open MeasureTheory Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

/-- A summable bound on a countable cover controls the actual nonnegative integral. -/
theorem integral_cover_le {ι:Type*} [Countable ι] (s:ι→Set ℝ)
    (f:ℝ→ℝ) (hf:∀x,0≤f x) (hi:∀i,IntegrableOn f (s i))
    (B:ι→ℝ) (hB:Summable B) (hb:∀i,(∫x in s i,f x)≤B i) :
    IntegrableOn f (⋃i,s i) ∧ (∫x in ⋃i,s i,f x)≤∑'i,B i := by
  have hnn (i:ι) : 0≤∫x in s i,f x := integral_nonneg hf
  have hs : Summable (fun i=>∫x in s i,f x) :=
    hB.of_nonneg_of_le hnn hb
  have hnorm : Summable (fun i=>∫x in s i,‖f x‖) := by
    simpa only [Real.norm_eq_abs,abs_of_nonneg (hf _)] using hs
  have hint := integrableOn_iUnion_of_summable_integral_norm hi hnorm
  refine ⟨hint,?_⟩
  have hh := lintegral_iUnion_le s (fun x=>ENNReal.ofReal (f x)) (μ:=volume)
  rw [←ofReal_integral_eq_lintegral_ofReal hint (ae_of_all _ hf)] at hh
  have he (i:ι) : (∫⁻x in s i,ENNReal.ofReal (f x))=ENNReal.ofReal (∫x in s i,f x) :=
    (ofReal_integral_eq_lintegral_ofReal (hi i) (ae_of_all _ hf)).symm
  simp_rw [he] at hh
  rw [←ENNReal.ofReal_tsum_of_nonneg hnn hs] at hh
  have hreal : (∫x in ⋃i,s i,f x)≤∑'i,∫x in s i,f x :=
    (ENNReal.ofReal_le_ofReal_iff (tsum_nonneg hnn)).mp hh
  exact hreal.trans (hs.tsum_le_tsum hb hB)

/-- Dyadic shells cover the whole positive frequency tail. -/
theorem dyadic_cover (Z:ℝ) (hZ:0<Z) :
    (⋃n:ℕ,Icc (Z*2^n) (Z*2^(n+1)))=Ici Z := by
  ext t
  constructor
  · intro ht
    obtain ⟨n,hn⟩ := mem_iUnion.mp ht
    have hp : (1:ℝ)≤2^n := one_le_pow₀ (by norm_num)
    exact le_trans (by nlinarith) hn.1
  · intro ht
    obtain ⟨n,hn⟩ := exists_nat_pow_near ((le_div_iff₀ hZ).mpr (by simpa using ht)) (by norm_num : (1:ℝ)<2)
    apply mem_iUnion.mpr ⟨n,?_⟩
    constructor
    · have hh := (le_div_iff₀ hZ).mp hn.1
      nlinarith
    · have hh := (div_lt_iff₀ hZ).mp hn.2
      nlinarith

/-- Geometric dyadic tails, including integrability, from an actual interval bound. -/
theorem geometric_shell_tail (f w:ℝ→ℝ) (hf:Continuous f) (hw:Continuous w)
    (hfn:∀x,0≤f x) (hwn:∀x,0≤w x)
    (Z X A D r:ℝ) (hZ:0<Z) (hX:0<X) (hA:0≤A) (hD:0≤D)
    (hr:0≤r) (hr2:2*r<1)
    (hmean:∀n:ℕ,(∫t in Icc (Z*2^n) (Z*2^(n+1)),f t)≤A*(1+Z*2^n/X))
    (hweight:∀n:ℕ,∀t∈Icc (Z*2^n) (Z*2^(n+1)),w t≤D*r^n) :
    IntegrableOn (fun t=>w t*f t) (Ici Z) ∧
      (∫t in Ici Z,w t*f t)≤D*A*((1-r)⁻¹+(Z/X)*(1-2*r)⁻¹) := by
  let s : ℕ→Set ℝ := fun n=>Icc (Z*2^n) (Z*2^(n+1))
  let B : ℕ→ℝ := fun n=>D*A*(r^n+(Z/X)*(2*r)^n)
  have hr1 : |r|<1 := by rw [abs_of_nonneg hr]; linarith
  have hr21 : |2*r|<1 := by rw [abs_of_nonneg (by positivity)]; exact hr2
  have hsum : Summable B := ((summable_geometric_of_abs_lt_one hr1).add
    ((summable_geometric_of_abs_lt_one hr21).mul_left (Z/X))).mul_left (D*A)
  have hi (n:ℕ) : IntegrableOn (fun t=>w t*f t) (s n) :=
    (hw.mul hf).continuousOn.integrableOn_compact isCompact_Icc
  have hb (n:ℕ) : (∫t in s n,w t*f t)≤B n := by
    have hfi : IntegrableOn f (s n) := hf.continuousOn.integrableOn_compact isCompact_Icc
    have hh : (∫t in s n,w t*f t)≤D*r^n*(∫t in s n,f t) := by
      rw [←integral_const_mul]
      apply setIntegral_mono_on (hi n) (hfi.const_mul _) measurableSet_Icc
      intro t ht
      exact mul_le_mul_of_nonneg_right (hweight n t ht) (hfn t)
    apply hh.trans
    have hm := mul_le_mul_of_nonneg_left (hmean n) (show 0≤D*r^n by positivity)
    convert hm using 1 <;> dsimp [B,s]
    rw [mul_pow]
    ring
  obtain ⟨hint,hbound⟩ := integral_cover_le s (fun t=>w t*f t)
    (fun t=>mul_nonneg (hwn t) (hfn t)) hi B hsum hb
  have hs : (⋃n,s n)=Ici Z := dyadic_cover Z hZ
  rw [hs] at hint hbound
  refine ⟨hint,hbound.trans_eq ?_⟩
  dsimp [B]
  rw [tsum_mul_left,(summable_geometric_of_abs_lt_one hr1).tsum_add
    ((summable_geometric_of_abs_lt_one hr21).mul_left (Z/X)),tsum_mul_left,
    tsum_geometric_of_abs_lt_one hr1,tsum_geometric_of_abs_lt_one hr21]

/-- The polynomial frequency weight appearing after integration by parts. -/
def weight (R:ℝ) (j:ℕ) (t:ℝ) : ℝ := ((1+|t|/R)^j)⁻¹

theorem weight_continuous (R:ℝ) (hR:0<R) (j:ℕ) : Continuous (weight R j) := by
  unfold weight
  apply Continuous.inv₀
  · fun_prop
  · intro t
    apply pow_ne_zero
    positivity

theorem weight_nonneg (R:ℝ) (hR:0<R) (j:ℕ) (t:ℝ) : 0≤weight R j t := by
  unfold weight
  positivity

theorem weight_dyadic (R Z:ℝ) (hR:0<R) (hZ:0<Z) (j n:ℕ)
    (t:ℝ) (ht:Z*2^n≤t) : weight R j t≤(R/Z)^j*((2:ℝ)^j)⁻¹^n := by
  have ht0 : 0≤t := (by positivity : (0:ℝ)≤Z*2^n).trans ht
  have hb : (Z/R)*2^n≤1+|t|/R := by
    rw [abs_of_nonneg ht0]
    have hh := (div_le_div_of_nonneg_right ht hR.le)
    calc
      (Z/R)*2^n = Z*2^n/R := by ring
      _ ≤t/R := hh
      _ ≤1+t/R := by linarith
  have hh := inv_le_inv₀ (by positivity : (0:ℝ)<(1+|t|/R)^j)
    (by positivity : (0:ℝ)<((Z/R)*2^n)^j) |>.mpr (pow_le_pow_left₀ (by positivity) hb j)
  apply hh.trans_eq
  simp only [mul_pow,mul_inv_rev,inv_pow,inv_div,inv_inv]
  rw [←pow_mul,←pow_mul,Nat.mul_comm n j]
  ring_nf
  simp only [inv_inv]
  ring

/-- A polynomially weighted tail has arbitrary power saving in Z/R.
The interval estimate is uniform in translates when this is applied to
the product of the two endpoint polynomials. -/
theorem polynomial_weight_tail (f:ℝ→ℝ) (hf:Continuous f) (hfn:∀x,0≤f x)
    (R Z X A:ℝ) (hR:0<R) (hZ:0<Z) (hX:0<X) (hA:0≤A)
    (j:ℕ) (hj:2≤j)
    (hmean:∀n:ℕ,(∫t in Icc (Z*2^n) (Z*2^(n+1)),f t)≤A*(1+Z*2^n/X)) :
    IntegrableOn (fun t=>weight R j t*f t) (Ici Z) ∧
      (∫t in Ici Z,weight R j t*f t)≤2*A*(R/Z)^j*(1+Z/X) := by
  have hp : (4:ℝ)≤2^j := by
    calc
      (4:ℝ)=2^2 := by norm_num
      _ ≤2^j := pow_le_pow_right₀ (by norm_num) hj
  have hr : ((2:ℝ)^j)⁻¹≤1/4 := by
    have h := one_div_le_one_div_of_le (by norm_num : (0:ℝ)<4) hp
    simpa using h
  obtain ⟨hint,hbound⟩ := geometric_shell_tail f (weight R j) hf (weight_continuous R hR j)
    hfn (weight_nonneg R hR j) Z X A ((R/Z)^j) (((2:ℝ)^j)⁻¹)
    hZ hX hA (by positivity) (by positivity) (by linarith) hmean
    (fun n t ht=>weight_dyadic R Z hR hZ j n t ht.1)
  refine ⟨hint,hbound.trans ?_⟩
  have hd1 : (1-((2:ℝ)^j)⁻¹)⁻¹≤2 := by
    have h := one_div_le_one_div_of_le (by norm_num : (0:ℝ)<1/2)
      (show (1/2:ℝ)≤1-((2:ℝ)^j)⁻¹ by linarith)
    simpa using h
  have hd2 : (1-2*((2:ℝ)^j)⁻¹)⁻¹≤2 := by
    have h := one_div_le_one_div_of_le (by norm_num : (0:ℝ)<1/2)
      (show (1/2:ℝ)≤1-2*((2:ℝ)^j)⁻¹ by linarith)
    simpa using h
  have hh := add_le_add hd1 (mul_le_mul_of_nonneg_left hd2 (by positivity : 0≤Z/X))
  have hm := mul_le_mul_of_nonneg_left hh (show 0≤(R/Z)^j*A by positivity)
  convert hm using 1 <;> ring

/-- Reflection preserves the interval mean estimate, including its translate. -/
theorem interval_reflection (f:ℝ→ℝ) (a b:ℝ) (hab:a≤b) :
    (∫t in Icc a b,f (-t))=∫t in Icc (-b) (-a),f t := by
  rw [integral_Icc_eq_integral_Ioc,←intervalIntegral.integral_of_le hab,
    intervalIntegral.integral_comp_neg,intervalIntegral.integral_of_le (by linarith),
    integral_Icc_eq_integral_Ioc]

/-- The actual two-sided t tail, with all translated interval dependence removed. -/
theorem polynomial_weight_two_sided_tail (f:ℝ→ℝ) (hf:Continuous f) (hfn:∀x,0≤f x)
    (R Z X A:ℝ) (hR:0<R) (hZ:0<Z) (hX:0<X) (hA:0≤A)
    (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,f t)≤A*(1+(b-a)/X)) :
    IntegrableOn (fun t=>weight R j t*f t) {t:ℝ | Z≤|t|} ∧
      (∫t in {t:ℝ | Z≤|t|},weight R j t*f t)≤4*A*(R/Z)^j*(1+Z/X) := by
  have hlen (n:ℕ) : Z*2^(n+1)-Z*2^n=Z*2^n := by rw [pow_succ]; ring
  have horder (n:ℕ) : Z*2^n≤Z*2^(n+1) := by
    rw [pow_succ]
    have hh : 0≤Z*2^n := by positivity
    nlinarith
  obtain ⟨hip,hp⟩ := polynomial_weight_tail f hf hfn R Z X A hR hZ hX hA j hj
    (fun n=>by simpa only [hlen] using hmean _ _ (horder n))
  have hnegmean (n:ℕ) : (∫t in Icc (Z*2^n) (Z*2^(n+1)),f (-t))≤A*(1+Z*2^n/X) := by
    rw [interval_reflection _ _ _ (horder n)]
    have hh := hmean (-(Z*2^(n+1))) (-(Z*2^n)) (by linarith [horder n])
    have he : -(Z*2^n)-(-(Z*2^(n+1)))=Z*2^n := by rw [pow_succ]; ring
    simpa only [he] using hh
  obtain ⟨hin,hn⟩ := polynomial_weight_tail (fun t=>f (-t)) (hf.comp continuous_neg)
    (fun t=>hfn (-t)) R Z X A hR hZ hX hA j hj hnegmean
  let g : ℝ→ℝ := fun t=>weight R j t*f t
  have hineg : IntegrableOn g (Iic (-Z)) := by
    apply (MeasurePreserving.integrableOn_comp_preimage (Measure.measurePreserving_neg _)
      (Homeomorph.neg ℝ).measurableEmbedding).mp
    simpa [g,Function.comp_def,weight,neg_preimage,neg_Iic] using hin
  have hnegeq : (∫t in Iic (-Z),g t)=(∫t in Ici Z,weight R j t*f (-t)) := by
    rw [integral_Ici_eq_integral_Ioi,←integral_comp_neg_Ioi]
    simp [g,weight]
  have hs : {t:ℝ | Z≤|t|}=Iic (-Z)∪Ici Z := by
    ext t
    simp only [mem_setOf_eq,mem_union,mem_Iic,mem_Ici]
    rw [le_abs]
    constructor <;> intro h <;> rcases h with h|h <;> (first | exact Or.inl (by linarith) | exact Or.inr (by linarith))
  rw [hs]
  refine ⟨hineg.union hip,?_⟩
  have hd : Disjoint (Iic (-Z)) (Ici Z) := Set.disjoint_left.mpr (by
    intro t ht ht'; change t≤-Z at ht; change Z≤t at ht'; linarith)
  rw [setIntegral_union hd measurableSet_Ici hineg hip,hnegeq]
  dsimp [g] at hp ⊢
  linarith

theorem weight_le_one (R:ℝ) (hR:0<R) (j:ℕ) (t:ℝ) : weight R j t≤1 := by
  have hh : (1:ℝ)≤(1+|t|/R)^j := one_le_pow₀ (le_add_of_nonneg_right (by positivity))
  exact (inv_le_one₀ (by positivity)).mpr hh

/-- The full weighted t integral costs only 1+R/X, uniformly in all translates. -/
theorem polynomial_weight_full (f:ℝ→ℝ) (hf:Continuous f) (hfn:∀x,0≤f x)
    (R X A:ℝ) (hR:0<R) (hX:0<X) (hA:0≤A) (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,f t)≤A*(1+(b-a)/X)) :
    Integrable (fun t=>weight R j t*f t) ∧
      (∫t:ℝ,weight R j t*f t)≤6*A*(1+R/X) := by
  obtain ⟨hit,ht⟩ := polynomial_weight_two_sided_tail f hf hfn R R X A hR hR hX hA j hj hmean
  simp only [div_self hR.ne',one_pow,mul_one] at ht
  let g : ℝ→ℝ := fun t=>weight R j t*f t
  have hic : IntegrableOn g (Icc (-R) R) :=
    ((weight_continuous R hR j).mul hf).continuousOn.integrableOn_compact isCompact_Icc
  have hc : (∫t in Icc (-R) R,g t)≤A*(1+2*R/X) := by
    calc
      _ ≤∫t in Icc (-R) R,f t := by
        apply setIntegral_mono_on hic (hf.continuousOn.integrableOn_compact isCompact_Icc) measurableSet_Icc
        intro t ht
        exact (mul_le_mul_of_nonneg_right (weight_le_one R hR j t) (hfn t)).trans_eq (one_mul _)
      _ ≤_ := by simpa only [sub_neg_eq_add,←two_mul] using hmean (-R) R (by linarith)
  let s : Bool→Set ℝ := fun b=>if b then Icc (-R) R else {t:ℝ | R≤|t|}
  let B : Bool→ℝ := fun b=>if b then A*(1+2*R/X) else 4*A*(1+R/X)
  have hi (b:Bool) : IntegrableOn g (s b) := by cases b <;> assumption
  have hb (b:Bool) : (∫t in s b,g t)≤B b := by cases b <;> assumption
  obtain ⟨hint,hbound⟩ := integral_cover_le s g
    (fun t=>mul_nonneg (weight_nonneg R hR j t) (hfn t)) hi B (hasSum_fintype B).summable hb
  have hs : (⋃b,s b)=univ := by
    ext t
    simp only [mem_iUnion,mem_univ,iff_true]
    by_cases ht:R≤|t|
    · exact ⟨false,ht⟩
    · refine ⟨true,?_⟩
      change -R≤t ∧ t≤R
      exact abs_le.mp (le_of_not_ge ht)
  rw [hs,integrableOn_univ] at hint
  rw [hs,setIntegral_univ] at hbound
  simp [B,tsum_fintype] at hbound
  refine ⟨hint,hbound.trans ?_⟩
  have hh : 0≤A*(R/X) := by positivity
  ring_nf
  linarith

end Elliptic.Operator.MellinWeightedTail
