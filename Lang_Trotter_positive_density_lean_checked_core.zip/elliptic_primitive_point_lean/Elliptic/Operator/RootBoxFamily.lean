module

public import Elliptic.Operator.SourceRootTransfer
public import Elliptic.Operator.RootErrorBudget

/-!
# Power-saving transfer for a growing family of bounded box tests

This applies the external root count to literal integer-root sums.
The number of boxes may grow with x, and each may have its own modulus
and complex signed test. No cancellation is assumed in summing errors.
Construction of the source geometric partition is a separate obligation.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootBoxFamily
universe u
open Filter SourceRootCount SourceRootTransfer
open scoped BigOperators

/-- A single threshold covers all growing families of bounded residue
tests on physical boxes. The grid cardinality is explicit; it is not
asserted here for the regions cut out by the source good-state tests. -/
theorem eventually_bounded_box_family (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0 < δ) (hCS : 0 ≤ C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (ι : Type u) (s : Finset ι)
      (U V : ℝ) (S : ι → ℕ), ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
      (s.card:ℝ) ≤ x^(δ/2000) →
      ∀ I₁ I₂ I₃ : ι → RootInterval,
      (∀ j ∈ s, 1 ≤ S j ∧ Squarefree (S j) ∧
        (S j:ℝ) ≤ Real.exp (C_S*(Real.log x)^(98/100:ℝ)) ∧
        (I₁ j).InRange 1 16 ∧ (I₂ j).InRange 1 2 ∧ (I₃ j).InRange 0 1) →
      ∀ f : (j : ι) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j ∈ s, ∀ g, ‖f j g‖ ≤ 1) →
      ‖(∑ j ∈ s, weightedRootSum U V (S j) (I₁ j) (I₂ j) (I₃ j) (f j)) -
        ∑ j ∈ s, (rootVolume U V (I₁ j) (I₂ j) (I₃ j):ℂ) *
          ((∑ g, f j g) /
            (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ))‖ ≤
        U*V*x^(-(δ/4000)) := by
  obtain ⟨C, hC, x₀, hx₀, htransfer⟩ :=
    uniform_box_family_transfer hPD δ hδ C_S hCS
  filter_upwards [eventually_ge_atTop x₀,
    RootErrorBudget.eventually_grid_error C (4*C_S) δ hC.le hδ] with x hx hbudget
  intro ι s U V S inst hU hU' hV hV' hgrid I₁ I₂ I₃ hboxes f hf
  have hxpos : 0 < x := by linarith
  have hUpos : 0 < U := (Real.rpow_pos_of_pos hxpos δ).trans_le hU
  have hVpos : 0 < V := (Real.rpow_pos_of_pos hxpos δ).trans_le hV
  have hbound := htransfer x hx ι s (fun _ => U) (fun _ => V) S I₁ I₂ I₃
    (fun j hj => ⟨hU,hU',hV,hV',hboxes j hj⟩) f
  have hmass : ∀ j ∈ s, (∑ g, ‖f j g‖) ≤
      Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ)) := by
    intro j hj
    have hcard := RootErrorBudget.residue_card_le_exp (S j) (hboxes j hj).1
      (C_S*(Real.log x)^(98/100:ℝ)) (hboxes j hj).2.2.1
    calc
      _ ≤ ∑ _g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)), (1:ℝ) :=
        Finset.sum_le_sum (fun g _ => hf j hj g)
      _ = (Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℝ) := by
        simp [Nat.card_eq_fintype_card]
      _ ≤ _ := by simpa only [mul_assoc] using hcard
  have hsum : (∑ j ∈ s, U*V*(∑ g, ‖f j g‖)) ≤
      U*V*((s.card:ℝ)*Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ))) := by
    calc
      _ ≤ ∑ _j ∈ s, U*V*Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ)) := by
        apply Finset.sum_le_sum
        intro j hj
        exact mul_le_mul_of_nonneg_left (hmass j hj) (by positivity)
      _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]; ring
  have hb := hbudget (s.card:ℝ) (Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ)))
    (Nat.cast_nonneg _) hgrid (Real.exp_pos _).le le_rfl
  calc
    _ ≤ C*x^(-(δ/1000)) * ∑ j ∈ s, U*V*(∑ g, ‖f j g‖) := hbound
    _ ≤ C*x^(-(δ/1000)) *
        (U*V*((s.card:ℝ)*Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ)))) := by
      exact mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = U*V*(C*(s.card:ℝ)*Real.exp ((4*C_S)*(Real.log x)^(98/100:ℝ))*x^(-(δ/1000))) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hb (by positivity)

end Elliptic.Operator.RootBoxFamily
