module

public import Elliptic.Operator.LifespanHistories
public import Elliptic.Operator.CleanPhysicalTransport

/-!
# Normalized independent-line expectation and the extracted baseline

The actual finite uniform expectation is factored prime by prime. Its
inactive and active branches are normalized with one line mass per prime,
and the baseline is identified with the literal transformed prime measure.
This proves the normalization step before identifying all lifespan choices
with the complete global schedule family.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.IndependentLineNormalization
open scoped BigOperators
open Elliptic.PrimewiseMemory
attribute [local instance] Classical.propDecidable

variable {Line : Type*} [Fintype Line] [DecidableEq Line]

/-- The literal one-prime factor in the independent uniform line average. -/
def lineFactor (visits active : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ)
    (ℓ : Line) : ℝ :=
  (∏ j ∈ active, if line j = ℓ then (1 : ℝ) else 0) *
    ∏ j ∈ visits \ active, (1-hitWeight line η j ℓ)

def lineAverage (visits active : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ) : ℝ :=
  (Fintype.card Line : ℝ)⁻¹ * ∑ ℓ : Line, lineFactor visits active line η ℓ

/-- Empty and singleton subsets contribute this exact baseline. -/
def baseline (visits : Finset ℕ) (η : ℕ → ℝ) (n : ℝ) : ℝ :=
  1 - (∑ j ∈ visits, η j) / n

/-- The surviving one-line mass after extracting the baseline. -/
def normalizedLineMass (visits : Finset ℕ) (η : ℕ → ℝ) (n : ℝ) : ℝ :=
  1 / (n - ∑ j ∈ visits, η j)

theorem baseline_mul_normalizedLineMass (visits : Finset ℕ) (η : ℕ → ℝ)
    (n : ℝ) (hn : n ≠ 0) (hbase : n - ∑ j ∈ visits, η j ≠ 0) :
    baseline visits η n * normalizedLineMass visits η n = n⁻¹ := by
  unfold baseline normalizedLineMass
  field_simp

/-- The inactive branch includes only a baseline or two DISTINCT ghost
endpoints. No singleton ghost is left over after normalization. -/
theorem inactive_lineAverage (visits : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ) ≠ 0)
    (hbase : (Fintype.card Line : ℝ) - ∑ j ∈ visits, η j ≠ 0) :
    lineAverage visits ∅ line η =
      baseline visits η (Fintype.card Line) *
        (1 + normalizedLineMass visits η (Fintype.card Line) *
          ∑ c ∈ visits, ∑ b ∈ visits with b < c,
            if line b = line c then
              η c * η b * ∏ j ∈ visits with b < j ∧ j < c,
                (1-hitWeight line η j (line c))
            else 0) := by
  unfold lineAverage lineFactor
  simp only [Finset.prod_empty,Finset.sdiff_empty,one_mul]
  rw [line_sum_first_last_expansion]
  conv_rhs =>
    rw [mul_add, mul_one, ← mul_assoc, baseline_mul_normalizedLineMass visits η _ hn hbase]
  unfold baseline
  field_simp

/-- In the active branch the single line probability survives once, even
if the prime has several active visits or several separate active runs. -/
theorem active_lineAverage (visits active : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ)
    (a c : ℕ) (ha : a ∈ active) (hac : a ≤ c)
    (hn : (Fintype.card Line : ℝ) ≠ 0)
    (hbase : (Fintype.card Line : ℝ) - ∑ j ∈ visits, η j ≠ 0) :
    lineAverage visits active line η =
      baseline visits η (Fintype.card Line) * normalizedLineMass visits η (Fintype.card Line) *
        (if ∀ j ∈ active, line j = line a then
          ∑ b : LeftGhostChoice (visits \ active) a,
          ∑ d : RightGhostChoice (visits \ active) c,
            leftGhostWeight (visits \ active) a (fun j => hitWeight line η j (line a)) b *
            (∏ j ∈ visits \ active with a ≤ j ∧ j ≤ c, (1-hitWeight line η j (line a))) *
            rightGhostWeight (visits \ active) c (fun j => hitWeight line η j (line a)) d
        else 0) := by
  rw [baseline_mul_normalizedLineMass visits η _ hn hbase]
  unfold lineAverage lineFactor
  rw [line_sum_active_lifespan_expansion visits active line η a c ha hac]

/-- All prime lines are averaged independently, with their actual finite
cardinalities. The product factorization is proved by finite distributivity. -/
theorem independent_line_average_factorization
    {Prime : Type*} [Fintype Prime] (Lines : Prime → Type*)
    [∀ p, Fintype (Lines p)] [∀ p, DecidableEq (Lines p)]
    (visits active : Prime → Finset ℕ) (line : ∀ p, ℕ → Lines p)
    (η : Prime → ℕ → ℝ) :
    (∏ p, (Fintype.card (Lines p) : ℝ)⁻¹) *
      (∑ ℓ : ∀ p, Lines p, ∏ p, lineFactor (visits p) (active p) (line p) (η p) (ℓ p)) =
      ∏ p, lineAverage (visits p) (active p) (line p) (η p) := by
  unfold lineAverage
  rw [Finset.prod_mul_distrib,Fintype.prod_sum]

/-- Baseline extraction over all primes is exact, including signs and
zero factors; no positivity estimate or independence heuristic is used. -/
theorem extract_baseline_product {Prime : Type*} [Fintype Prime]
    (B T : Prime → ℝ) :
    (∏ p, B p * T p) = (∏ p, B p) * (∏ p, T p) :=
  Finset.prod_mul_distrib

/-- For the actual p+1 line count the source's transformed mass supplies
exactly the normalized one-line mass after multiplication by V. -/
theorem transformedPrimeMass_normalization
    (visits : Finset ℕ) (η : ℕ → ℝ) (V : ℝ) (p : ℕ) (hV : V ≠ 0) :
    V * transformedPrimeMass visits η V p =
      normalizedLineMass visits η ((p : ℝ)+1) := by
  rw [transformedPrimeMass_eq]
  unfold normalizedLineMass
  simp only [one_div,mul_inv_rev]
  calc
    V * ((↑p + 1 - ∑ j ∈ visits, η j)⁻¹ * V⁻¹) =
        (V * V⁻¹) * (↑p + 1 - ∑ j ∈ visits, η j)⁻¹ := by ring
    _ = _ := by rw [mul_inv_cancel₀ hV,one_mul]

/-- The actual baseline is positive and at most one in the source range. -/
theorem baseline_pos_le_one (visits : Finset ℕ) (η : ℕ → ℝ) (p : ℕ)
    (hη : ∀ j ∈ visits, 0 ≤ η j ∧ η j ≤ 1)
    (hsize : (visits.card : ℝ) < (p : ℝ)+1) :
    0 < baseline visits η ((p : ℝ)+1) ∧ baseline visits η ((p : ℝ)+1) ≤ 1 := by
  have hp : (0 : ℝ) < (p : ℝ)+1 := by positivity
  have hs0 : 0 ≤ ∑ j ∈ visits, η j := Finset.sum_nonneg (fun j hj => (hη j hj).1)
  have hs : (∑ j ∈ visits, η j) ≤ (visits.card : ℝ) := by
    calc
      _ ≤ ∑ _j ∈ visits, (1 : ℝ) := Finset.sum_le_sum (fun j hj => (hη j hj).2)
      _ = _ := by simp
  unfold baseline
  constructor
  · have h := (div_lt_one hp).mpr (hs.trans_lt hsize)
    linarith
  · have h := div_nonneg hs0 hp.le
    linarith

end Elliptic.Operator.IndependentLineNormalization
