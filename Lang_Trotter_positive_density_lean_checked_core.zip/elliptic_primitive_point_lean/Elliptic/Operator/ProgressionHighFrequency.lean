module

public import Elliptic.Operator.LogPhaseHighFrequency

/-!
# Uniform high-frequency cancellation on long residue progressions

The residue need not be a unit. Only the actual interval geometry
qM ≤ a ≤ 2qM is used, and every constant is fixed before a,q,t,M.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ProgressionHighFrequency
open scoped BigOperators
open ClassicalDerivativeTest LogPhaseDerivativeTest LogPhaseProgression LogPhaseHighFrequency
set_option backward.isDefEq.respectTransparency false

/-- Uniform derivative constants for every translate in a fixed dyadic range. -/
theorem lowerDerivative_bounds (k M : ℕ) (a q t : ℝ)
    (hM : 1≤M) (hq : 0<q) (hlo : q*(M:ℝ)≤a) (hhi : a≤2*q*M) :
    (derivativeConstant k/(2:ℝ)^k)*(|t| /(M:ℝ)^k)≤lowerDerivative k a q t ∧
      lowerDerivative k a q t≤derivativeConstant k*(|t| /(M:ℝ)^k) := by
  have hM0 : (0:ℝ)<M := by exact_mod_cast (show 0<M by omega)
  have ha : 0<a := (mul_pos hq hM0).trans_le hlo
  have hc : 0≤ |t| /(2*Real.pi)*((k-1).factorial:ℝ)*q^k := by positivity
  have hl := div_le_div_of_nonneg_left hc (pow_pos (by positivity : 0<2*a) k)
    (pow_le_pow_left₀ (by positivity : 0≤2*a) (by linarith : 2*a≤4*q*M) k)
  have hh := div_le_div_of_nonneg_left hc (pow_pos (by positivity : 0<2*q*(M:ℝ)) k)
    (pow_le_pow_left₀ (by positivity : 0≤2*q*(M:ℝ)) (by linarith : 2*q*(M:ℝ)≤2*a) k)
  constructor
  · apply le_trans ?_ hl
    unfold derivativeConstant
    rw [mul_pow,mul_pow]
    field_simp
    rw [show (4:ℝ)^k=(2:ℝ)^k*(2:ℝ)^k by rw [←mul_pow]; norm_num]
    ring_nf
    rfl
  · apply le_trans hh
    unfold derivativeConstant
    rw [mul_pow,mul_pow]
    field_simp
    rfl

/-- Power-band form of the actual derivative bounds. -/
theorem lowerDerivative_band (k M : ℕ) (hk : 2≤k) (a q t : ℝ)
    (hM : 1≤M) (hq : 0<q) (hlo : q*(M:ℝ)≤a) (hhi : a≤2*q*M)
    (htlo : (M:ℝ)^(k-2)≤ |t|) (hthi : |t|≤(M:ℝ)^(k-1)) :
    (derivativeConstant k/(2:ℝ)^k)*(M:ℝ)^(-2:ℝ)≤lowerDerivative k a q t ∧
      lowerDerivative k a q t≤derivativeConstant k*(M:ℝ)^(-1:ℝ) := by
  have hM0 : (0:ℝ)<M := by exact_mod_cast (show 0<M by omega)
  have hb := lowerDerivative_bounds k M a q t hM hq hlo hhi
  have hlow := div_le_div_of_nonneg_right htlo (pow_nonneg hM0.le k)
  have hhigh := div_le_div_of_nonneg_right hthi (pow_nonneg hM0.le k)
  have he2 : ((k-2:ℕ):ℝ)-(k:ℝ)=(-2:ℝ) := by rw [Nat.cast_sub hk]; norm_num
  have he1 : ((k-1:ℕ):ℝ)-(k:ℝ)=(-1:ℝ) := by rw [Nat.cast_sub (by omega : 1≤k)]; norm_num
  rw [←Real.rpow_natCast (M:ℝ) (k-2),←Real.rpow_natCast (M:ℝ) k,←Real.rpow_sub hM0,he2] at hlow
  rw [←Real.rpow_natCast (M:ℝ) (k-1),←Real.rpow_natCast (M:ℝ) k,←Real.rpow_sub hM0,he1] at hhigh
  simp only [Real.rpow_natCast] at hlow hhigh
  exact ⟨(mul_le_mul_of_nonneg_left hlow (div_pos (derivativeConstant_pos k) (by positivity)).le).trans hb.1,
    hb.2.trans (mul_le_mul_of_nonneg_left hhigh (derivativeConstant_pos k).le)⟩

theorem secondaryExponent_nonneg (k : ℕ) (hk : 2≤k) : 0≤secondaryExponent k := by
  have hp : (4:ℝ)≤2^k := by
    have h := pow_le_pow_right₀ (by norm_num : (1:ℝ)≤2) hk
    norm_num at h
    exact h
  unfold secondaryExponent
  have hdiv : (4:ℝ)/2^k≤1 := (div_le_iff₀ (by positivity)).mpr (by simpa using hp)
  linarith

/-- The derivative test is uniform for arbitrary shorter subintervals of
one ambient dyadic progression. -/
theorem progression_derivative_ambient (hvdC : FixedOrderDerivativeTest)
    (k : ℕ) (hk : 2≤k) : ∃C:ℝ,0<C∧∀N M:ℕ,1≤N→M≤N→∀a q t:ℝ,
      0<q→q*(N:ℝ)≤a→t≠0→
      ‖∑n∈Finset.range M,phase t (a+q*n)‖≤
        C*((N:ℝ)*(lowerDerivative k a q t)^(exponent k)+
          (N:ℝ)^(secondaryExponent k)*(lowerDerivative k a q t)^(-exponent k)) := by
  obtain ⟨C,hC,hbound⟩ := progression_derivative_bound hvdC k hk
  refine ⟨C,hC,?_⟩
  intro N M hN hMN a q t hq hlo ht
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have ha := (mul_pos hq hN0).trans_le hlo
  have hMR : (M:ℝ)≤N := by exact_mod_cast hMN
  have hlam : 0<lowerDerivative k a q t := by
    unfold lowerDerivative
    have hf : (0:ℝ)<(k-1).factorial := by exact_mod_cast Nat.factorial_pos (k-1)
    have ht0 := abs_pos.mpr ht
    positivity
  by_cases hM : M=0
  · subst M
    simp only [Finset.range_zero,Finset.sum_empty,norm_zero]
    positivity
  · have hb := hbound M (by omega) a q t ha hq
      ((mul_le_mul_of_nonneg_left hMR hq.le).trans hlo) ht
    apply hb.trans
    apply mul_le_mul_of_nonneg_left _ hC.le
    apply add_le_add
    · exact mul_le_mul_of_nonneg_right hMR (Real.rpow_nonneg hlam.le _)
    · exact mul_le_mul_of_nonneg_right
        (Real.rpow_le_rpow (Nat.cast_nonneg M) hMR (secondaryExponent_nonneg k hk))
        (Real.rpow_nonneg hlam.le _)

/-- Actual residue progression cancellation in each power band. -/
theorem progression_band_bound (hvdC : FixedOrderDerivativeTest) (k : ℕ) (hk : 3≤k) :
    ∃C:ℝ,0<C∧∀N M:ℕ,1≤N→M≤N→∀a q t:ℝ,0<q→q*(N:ℝ)≤a→a≤2*q*N→
      (N:ℝ)^(k-2)≤ |t|→ |t|≤(N:ℝ)^(k-1)→
      ‖∑n∈Finset.range M,phase t (a+q*n)‖≤C*(N:ℝ)^(1-exponent k) := by
  obtain ⟨C,hC,hbound⟩ := progression_derivative_ambient hvdC k (by omega)
  let A := derivativeConstant k/(2:ℝ)^k
  let B := derivativeConstant k
  have hA : 0<A := div_pos (derivativeConstant_pos k) (by positivity)
  have hB : 0<B := derivativeConstant_pos k
  let D := B^(exponent k)+A^(-exponent k)
  have hD : 0<D := add_pos (Real.rpow_pos_of_pos hB _) (Real.rpow_pos_of_pos hA _)
  refine ⟨C*D,mul_pos hC hD,?_⟩
  intro N M hN hMN a q t hq hlo hhi htlo hthi
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have ht := abs_pos.mp ((pow_pos hN0 (k-2)).trans_le htlo)
  have hb := hbound N M hN hMN a q t hq hlo ht
  have hd := lowerDerivative_band k N (by omega) a q t hN hq hlo hhi htlo hthi
  have hterms := derivative_terms_band k hk N (lowerDerivative k a q t) A B
    (by exact_mod_cast hN) hA hB hd.1 hd.2
  exact hb.trans (by dsimp [D]; nlinarith [mul_le_mul_of_nonneg_left hterms hC.le])

/-- The lower-frequency end uses the second derivative, still uniformly
for every shorter interval in the same ambient progression. -/
theorem progression_second_derivative (hvdC : FixedOrderDerivativeTest) :
    ∃C:ℝ,0<C∧∀N M:ℕ,1≤N→M≤N→∀a q t T:ℝ,
      0<q→q*(N:ℝ)≤a→a≤2*q*N→0<T→T≤ |t|→ |t|≤N→
      ‖∑n∈Finset.range M,phase t (a+q*n)‖≤
        C*(N:ℝ)*((N:ℝ)^(-1/2:ℝ)+T^(-1/2:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := progression_derivative_ambient hvdC 2 (by omega)
  let A := derivativeConstant 2/(2:ℝ)^2
  let B := derivativeConstant 2
  have hA : 0<A := div_pos (derivativeConstant_pos 2) (by positivity)
  have hB : 0<B := derivativeConstant_pos 2
  let D := B^(1/2:ℝ)+A^(-1/2:ℝ)
  have hD : 0<D := add_pos (Real.rpow_pos_of_pos hB _) (Real.rpow_pos_of_pos hA _)
  refine ⟨C*D,mul_pos hC hD,?_⟩
  intro N M hN hMN a q t T hq hlo hhi hT hTt htN
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have ht0 : 0< |t| := hT.trans_le hTt
  have hb := hbound N M hN hMN a q t hq hlo (abs_pos.mp ht0)
  have hd := lowerDerivative_bounds 2 N a q t hN hq hlo hhi
  have hlam := (mul_pos hA (div_pos ht0 (sq_pos_of_pos hN0))).trans_le hd.1
  have hu := Real.rpow_le_rpow hlam.le hd.2 (by norm_num : (0:ℝ)≤1/2)
  have hl := Real.rpow_le_rpow_of_nonpos (mul_pos hA (div_pos ht0 (sq_pos_of_pos hN0)))
    hd.1 (by norm_num : (-1/2:ℝ)≤0)
  change (lowerDerivative 2 a q t)^(1/2:ℝ)≤(B*(|t| /(N:ℝ)^2))^(1/2:ℝ) at hu
  change (lowerDerivative 2 a q t)^(-1/2:ℝ)≤(A*(|t| /(N:ℝ)^2))^(-1/2:ℝ) at hl
  have hepos : (B*(|t| /(N:ℝ)^2))^(1/2:ℝ)=B^(1/2:ℝ)*|t| ^(1/2:ℝ)/(N:ℝ) := by
    rw [Real.mul_rpow hB.le (div_nonneg ht0.le (sq_nonneg _)),
      Real.div_rpow ht0.le (sq_nonneg _),←Real.rpow_natCast (N:ℝ) 2,←Real.rpow_mul hN0.le]
    norm_num
    ring
  have heneg : (A*(|t| /(N:ℝ)^2))^(-1/2:ℝ)=A^(-1/2:ℝ)*|t| ^(-1/2:ℝ)*(N:ℝ) := by
    rw [Real.mul_rpow hA.le (div_nonneg ht0.le (sq_nonneg _)),
      Real.div_rpow ht0.le (sq_nonneg _),←Real.rpow_natCast (N:ℝ) 2,←Real.rpow_mul hN0.le]
    norm_num
    rw [Real.rpow_neg_one,div_inv_eq_mul]
    ring
  rw [hepos] at hu
  rw [heneg] at hl
  norm_num [exponent,secondaryExponent] at hb
  rw [show -(1/2:ℝ)=(-1/2:ℝ) by ring] at hb
  have hhpos := Real.rpow_le_rpow ht0.le htN (by norm_num : (0:ℝ)≤1/2)
  have hhneg := Real.rpow_le_rpow_of_nonpos hT hTt (by norm_num : (-1/2:ℝ)≤0)
  have hhalf : (N:ℝ)^(1/2:ℝ)=(N:ℝ)*(N:ℝ)^(-1/2:ℝ) := by
    calc
      _ = (N:ℝ)^(1+(-1/2:ℝ)) := by congr 1; ring
      _ = _ := by rw [Real.rpow_add hN0,Real.rpow_one]
  have hh1 := mul_le_mul_of_nonneg_left hhpos (Real.rpow_pos_of_pos hB (1/2:ℝ)).le
  have hh2 := mul_le_mul_of_nonneg_left hhneg (Real.rpow_pos_of_pos hA (-1/2:ℝ)).le
  rw [hhalf] at hh1
  have huN := mul_le_mul_of_nonneg_left hu hN0.le
  have hecancel : (N:ℝ)*(B^(1/2:ℝ)*|t| ^(1/2:ℝ)/(N:ℝ))=B^(1/2:ℝ)*|t| ^(1/2:ℝ) := by field_simp
  rw [hecancel] at huN
  have hc1 := mul_nonneg (Real.rpow_pos_of_pos hB (1/2:ℝ)).le (Real.rpow_pos_of_pos hT (-1/2:ℝ)).le
  have hc2 := mul_nonneg (Real.rpow_pos_of_pos hA (-1/2:ℝ)).le (Real.rpow_pos_of_pos hN0 (-1/2:ℝ)).le
  have hx := mul_le_mul_of_nonneg_left hh2 hN0.le
  have hterms : (N:ℝ)*(lowerDerivative 2 a q t)^(1/2:ℝ)+(lowerDerivative 2 a q t)^(-1/2:ℝ)≤
      D*(N:ℝ)*((N:ℝ)^(-1/2:ℝ)+T^(-1/2:ℝ)) := by
    dsimp [D]
    nlinarith [mul_nonneg hN0.le hc1,mul_nonneg hN0.le hc2]
  exact hb.trans (by nlinarith [mul_le_mul_of_nonneg_left hterms hC.le])

/-- Finitely many classical orders cover the full polynomial frequency
range on every subinterval of a dyadic residue progression. -/
theorem progression_polynomial_range (hvdC : FixedOrderDerivativeTest)
    (K : ℕ) (hK : 2≤K) :
    ∃C:ℝ,0<C∧∀N M:ℕ,1≤N→M≤N→∀a q t T:ℝ,
      0<q→q*(N:ℝ)≤a→a≤2*q*N→0<T→T≤ |t|→ |t|≤(N:ℝ)^(K-1)→
      ‖∑n∈Finset.range M,phase t (a+q*n)‖≤
        C*(N:ℝ)*((N:ℝ)^(-exponent K)+T^(-1/2:ℝ)) := by
  induction K,hK using Nat.le_induction with
  | base =>
    obtain ⟨C,hC,hbound⟩ := progression_second_derivative hvdC
    refine ⟨C,hC,?_⟩
    have he : exponent 2=(1/2:ℝ) := by norm_num [exponent]
    simpa only [he,show -(1/2:ℝ)=(-1/2:ℝ) by ring,show (2:ℕ)-1=1 by omega,pow_one] using hbound
  | succ K hK ih =>
    obtain ⟨C,hC,hbound⟩ := ih
    obtain ⟨D,hD,hband⟩ := progression_band_bound hvdC (K+1) (by omega)
    refine ⟨C+D,add_pos hC hD,?_⟩
    intro N M hN hMN a q t T hq hlo hhi hT hTt htmax
    have hN1 : (1:ℝ)≤N := by exact_mod_cast hN
    have hN0 : 0<(N:ℝ) := by linarith
    have hNpow : 0≤(N:ℝ)^(-exponent (K+1)) := Real.rpow_nonneg hN0.le _
    have hTpow : 0≤T^(-1/2:ℝ) := Real.rpow_nonneg hT.le _
    by_cases ht : |t|≤(N:ℝ)^(K-1)
    · have hb := hbound N M hN hMN a q t T hq hlo hhi hT hTt ht
      have hpow := Real.rpow_le_rpow_of_exponent_le hN1
        (neg_le_neg (exponent_antitone hK (Nat.le_succ K)))
      have hm := mul_le_mul_of_nonneg_left (add_le_add_left hpow (T^(-1/2:ℝ)))
        (mul_nonneg hC.le hN0.le)
      have hd := mul_nonneg (mul_nonneg hD.le hN0.le) (add_nonneg hNpow hTpow)
      nlinarith
    · have hlow : (N:ℝ)^((K+1)-2)≤ |t| := by
        have he : K+1-2=K-1 := by omega
        rw [he]
        exact (lt_of_not_ge ht).le
      have hb := hband N M hN hMN a q t hq hlo hhi hlow htmax
      rw [sub_eq_add_neg,Real.rpow_add hN0,Real.rpow_one] at hb
      have hc := mul_nonneg (mul_nonneg hC.le hN0.le) (add_nonneg hNpow hTpow)
      have hd := mul_nonneg (mul_nonneg hD.le hN0.le) hTpow
      nlinarith

end Elliptic.Operator.ProgressionHighFrequency
