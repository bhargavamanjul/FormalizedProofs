module

public import Elliptic.Operator.PhysicalGhostNorm
public import Elliptic.Operator.PhysicalPhasedWord

/-! Absolute coefficient majorants for the actual signed ghost operation. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance positiveGhostDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

theorem ghostPositiveApply_symmetric_l2_sq_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
      (MemoryState.mass (anchoredParticleMass ν))
      (ghostApply ν V (-η) q ρ anchor (fun m => F (tupleBag m.values))) ≤
        (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^2 *
          finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
            (MemoryState.mass (anchoredParticleMass ν)) (fun m => F (tupleBag m.values)) := by
  have hd : ‖((η/ρ : ℝ) : ℂ)‖ ≤ max 1 Vmax/ρ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_div,
      abs_of_nonneg hη0, abs_of_pos hρ]
    exact div_le_div_of_nonneg_right (hη1.trans (le_max_left _ _)) hρ.le
  have hr : ‖((q/ρ^2 : ℝ) : ℂ)‖ ≤ Q/ρ^2 := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (div_nonneg hq0 (sq_nonneg _))]
    exact div_le_div_of_nonneg_right hqQ (sq_nonneg _)
  have hb : ‖((η*V/ρ : ℝ) : ℂ)‖ ≤ max 1 Vmax/ρ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_div, abs_mul,
      abs_of_nonneg hη0, abs_of_nonneg hV0, abs_of_pos hρ]
    apply div_le_div_of_nonneg_right _ hρ.le
    exact ((mul_le_mul_of_nonneg_right hη1 hV0).trans_eq (one_mul V)).trans
      (hVmax.trans (le_max_right _ _))
  have heq : ghostApply (B := B) ν V (-η) q ρ anchor (fun m => F (tupleBag m.values)) =
      ghostCoefficientApply (fun p => (ν p : ℂ))
        ((η/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((η*V/ρ : ℝ) : ℂ) anchor F :=
    by
      funext m
      simpa only [neg_neg] using ghostApply_eq_coefficientApply ν V (-η) q ρ anchor F m
  rw [heq]
  exact ghostCoefficient_symmetric_l2_sq_bound ν _ _ _ ρ Q Vmax s anchor F
    hν hs hs0 hρ hQ hd hr hb

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

theorem groupedGhostPositiveTensor_symmetric_l2_sq_uniform [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : ∀ i p, Line i p)
    (H : (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    finiteL2Sq Finset.univ
      (fun m : PhysicalMemories P Line B => ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i))
      (groupedGhostTensorApply ν V (-η) q ρ anchor (fun m => H (fun i => tupleBag (m i).values))) ≤
      ((Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I))^2 *
        finiteL2Sq Finset.univ
          (fun m : PhysicalMemories P Line B => ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i))
          (fun m => H (fun i => tupleBag (m i).values)) := by
  let X := fun i => MemoryState (AnchoredParticle (P i) (Line i)) B
  let bag := fun i (m : X i) => tupleBag m.values
  let μ := fun i (m : X i) => MemoryState.mass (anchoredParticleMass (ν i)) m
  let K := fun i => ghostTransition (ν i) (V i) (-η) q ρ (anchor i) (B:=B)
  let C := Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ)
  have hμ : ∀ i m, 0 ≤ μ i m := by
    intro i m
    dsimp [μ, MemoryState.mass, anchoredParticleMass]
    exact div_nonneg (Finset.prod_nonneg (fun j _ => hν i _)) (by positivity)
  have hK : ∀ i, QuotientKernelSqBound (bag i) (μ i) (K i) (C^2) := by
    intro i F
    have h := ghostPositiveApply_symmetric_l2_sq_uniform (ν i) (V i) η q ρ Q Vmax s
      (anchor i) F (B:=B) (hν i) (hs i) hs0 hρ hQ hq0 hqQ hη0 hη1 (hV0 i) (hVmax i)
    unfold finiteL2Sq at h
    simp_rw [ghostApply_eq_transition_sum] at h
    exact h
  have ht := quotient_tensor_sq X (fun i => Multiset (AnchoredParticle (P i) (Line i)))
    bag μ K (fun _ => C^2) hμ (fun _ => sq_nonneg _) hK H
  rw [Finset.prod_pow] at ht
  simp only [Finset.prod_const, Finset.card_univ] at ht
  have heq (m : PhysicalMemories P Line B) : quotientTensorApply bag K H m =
      groupedGhostTensorApply ν V (-η) q ρ anchor (fun m => H (fun i => tupleBag (m i).values)) m := by
    rw [groupedGhostTensorApply_eq_transition_sum]
    rfl
  simp_rw [heq] at ht
  exact ht

set_option maxHeartbeats 800000 in
theorem physicalGhostPositiveOperation_symmetric_l2_sq_uniform [Fintype Z]
    [∀ i, Fintype (P i)] [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (H : Z → PhysicalActiveLists P J →
      (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      ((physicalGhostOperation ν V (-η) q ρ anchor).apply (physicalBagFunction H)) ≤
      ((Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I))^2 *
        finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H) := by
  let F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ := physicalBagFunction H
  let C := (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I)
  let μ := fun m : PhysicalMemories P Line B =>
    ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i)
  have hμ : ∀ m, 0 ≤ μ m := by
    intro m
    apply Finset.prod_nonneg
    intro i _
    unfold MemoryState.mass anchoredParticleMass
    exact div_nonneg (Finset.prod_nonneg (fun j _ => hν i _)) (by positivity)
  have hfiber (z : Z) (a : PhysicalActiveLists P J) :
      finiteL2Sq Finset.univ μ
        (physicalGhostZeroExtension ((physicalGhostOperation ν V (-η) q ρ anchor).apply F) z a) ≤
        C^2*finiteL2Sq Finset.univ μ (physicalGhostZeroExtension F z a) := by
    let Hb : (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ := fun b =>
      if (∑ i, (b i).card) ≤ B then H z a b else 0
    have hin (m : PhysicalMemories P Line B) :
        physicalGhostZeroExtension F z a m = Hb (fun i => tupleBag (m i).values) :=
      physicalGhostZeroExtension_bag_test H z a m
    have hout (m : PhysicalMemories P Line B) :
        physicalGhostZeroExtension ((physicalGhostOperation ν V (-η) q ρ anchor).apply F) z a m =
        if (∑ i, (m i).size) ≤ B then
          groupedGhostTensorApply ν V (-η) q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m else 0 := by
      unfold physicalGhostZeroExtension
      split_ifs with hm
      · rw [physicalGhostOperation_eq_compressed_tensor]
        change groupedGhostTensorApply ν V (-η) q ρ (anchor z)
          (physicalGhostZeroExtension F z a) m = _
        congr 1
        exact funext hin
      · rfl
    rw [funext hout]
    have hcut : finiteL2Sq Finset.univ μ
        (fun m : PhysicalMemories P Line B => if (∑ i, (m i).size) ≤ B then
          groupedGhostTensorApply ν V (-η) q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m else 0) ≤
        finiteL2Sq Finset.univ μ
          (groupedGhostTensorApply ν V (-η) q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values))) := by
      apply Finset.sum_le_sum
      intro m _
      dsimp only
      split_ifs
      · exact le_rfl
      · simpa only [norm_zero, zero_pow (by decide : 2 ≠ 0), mul_zero] using
          mul_nonneg (hμ m) (sq_nonneg ‖groupedGhostTensorApply ν V (-η) q ρ (anchor z)
            (fun m => Hb (fun i => tupleBag (m i).values)) m‖)
    refine hcut.trans ?_
    rw [show physicalGhostZeroExtension F z a =
      (fun m => Hb (fun i => tupleBag (m i).values)) from funext hin]
    exact groupedGhostPositiveTensor_symmetric_l2_sq_uniform ν V η q ρ Q Vmax s (anchor z) Hb
      hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax
  change finiteL2Sq Finset.univ _ ((physicalGhostOperation ν V (-η) q ρ anchor).apply F) ≤
    C^2 * finiteL2Sq Finset.univ _ F
  rw [physicalGhostZeroExtension_l2_sq, physicalGhostZeroExtension_l2_sq, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro z _
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro a _
  have ha : 0 ≤ ∏ i, tupleWeight (ν i) (a i) :=
    Finset.prod_nonneg (fun i _ => Finset.prod_nonneg (fun j _ => hν i _))
  have h := mul_le_mul_of_nonneg_left (hfiber z a) ha
  simpa only [mul_left_comm] using h


/-- Negating the ghost parameter gives the exact absolute coefficient. -/
theorem ghostChoiceWeight_neg_eta_eq_abs {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀p,Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m)
    (hν : ∀p,0≤ν p) (hV : 0≤V) (hη : 0≤η) (hq : 0≤q) (hρ : 0≤ρ) :
    ghostChoiceWeight ν V (-η) q ρ anchor m c = |ghostChoiceWeight ν V η q ρ anchor m c| := by
  rw [ghostChoiceWeight_abs ν V η q ρ anchor m c hν hV hη hq hρ]
  simp only [ghostChoiceWeight,neg_neg]

/-- This identity retains the literal signed ghost coefficients on the left. -/
theorem physicalGhostChoiceWeight_neg_eta_eq_norm [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ) (anchor:Z→∀i p,Line i p)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) (c:PhysicalGhostChoice s)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:0≤η) (hq:0≤q) (hρ:0≤ρ) :
    physicalGhostChoiceWeight ν V (-η) q ρ anchor s c =
      (‖physicalGhostChoiceWeight ν V η q ρ anchor s c‖:ℂ) := by
  simp only [physicalGhostChoiceWeight,norm_prod,Complex.norm_real,Real.norm_eq_abs,
    Complex.ofReal_prod]
  apply Finset.prod_congr rfl
  intro i _
  rw [ghostChoiceWeight_neg_eta_eq_abs (ν i) (V i) η q ρ _ _ _ (hν i) (hV i) hη hq hρ]

/-- Arbitrary unit-bounded choice phases are dominated by the positive
absolute ghost, without a positivity claim for the original operation. -/
theorem physicalGhostPhased_norm_le_positive [∀i,Fintype (P i)]
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ) (anchor:Z→∀i p,Line i p)
    (phase:(s:PhysicalMemoryState (Z:=Z) P Line J B)→PhysicalGhostChoice s→ℂ)
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (hphase:∀s c,‖phase s c‖≤1)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:0≤η) (hq:0≤q) (hρ:0≤ρ)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) :
    ‖PhysicalPhasedWord.phasedApply (physicalGhostOperation ν V η q ρ anchor) phase F s‖ ≤
      ‖(physicalGhostOperation ν V (-η) q ρ anchor).apply (fun t=>(‖F t‖:ℂ)) s‖ := by
  let S:ℝ := ∑c:(physicalGhostOperation ν V η q ρ anchor).ValidChoice s,
    ‖physicalGhostChoiceWeight ν V η q ρ anchor s c.val‖ *
      ‖F (c.val.output anchor s c.property)‖
  have hS:0≤S:=Finset.sum_nonneg (fun c _=>mul_nonneg (norm_nonneg _) (norm_nonneg _))
  have heq:(physicalGhostOperation ν V (-η) q ρ anchor).apply (fun t=>(‖F t‖:ℂ)) s=(S:ℂ):=by
    unfold ChoiceOperation.apply
    dsimp only [physicalGhostOperation]
    simp_rw [physicalGhostChoiceWeight_neg_eta_eq_norm ν V η q ρ anchor _ _ hν hV hη hq hρ]
    simp only [S,Complex.ofReal_sum,Complex.ofReal_mul]
    with_reducible refine Finset.sum_congr ?_ ?_
    · ext c
      simp only [Finset.mem_univ]
    · intro c _
      rfl
  rw [heq,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hS]
  unfold PhysicalPhasedWord.phasedApply
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro c _
  simp only [norm_mul]
  change ‖phase s c.val‖ * ‖physicalGhostChoiceWeight ν V η q ρ anchor s c.val‖ *
    ‖F (c.val.output anchor s c.property)‖ ≤ _
  calc
    _ ≤ 1 * ‖physicalGhostChoiceWeight ν V η q ρ anchor s c.val‖ *
        ‖F (c.val.output anchor s c.property)‖ :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (hphase s c.val)
        (norm_nonneg _)) (norm_nonneg _)
    _ = _ := by rw [one_mul]

/-- Uniform bound for the actual signed ghost with arbitrary bounded
choice phases, on the physical separately symmetric memory subspace. -/
theorem physicalGhostPhased_symmetric_l2_sq_uniform [Fintype Z]
    [∀i,Fintype (P i)] [∀i p,Fintype (Line i p)]
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ Q Vmax s:ℝ)
    (anchor:Z→∀i p,Line i p)
    (phase:(t:PhysicalMemoryState (Z:=Z) P Line J B)→PhysicalGhostChoice t→ℂ)
    (H:Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ)
    (hphase:∀t c,‖phase t c‖≤1)
    (hν:∀i p,0≤ν i p) (hs:∀i,(∑p,ν i p)≤s) (hs0:0≤s)
    (hρ:0<ρ) (hQ:Q<ρ^2) (hq0:0≤q) (hqQ:q≤Q)
    (hη0:0≤η) (hη1:η≤1) (hV0:∀i,0≤V i) (hVmax:∀i,V i≤Vmax) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (PhysicalPhasedWord.phasedApply (physicalGhostOperation ν V η q ρ anchor) phase (physicalBagFunction H)) ≤
      ((Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I))^2 *
        finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H) := by
  let Hnorm := fun z a b=>(‖H z a b‖:ℂ)
  have hb:=physicalGhostPositiveOperation_symmetric_l2_sq_uniform ν V η q ρ Q Vmax s
    anchor Hnorm hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax (B:=B)
  have heq:finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (physicalBagFunction Hnorm)=
      finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H):=by
    apply Finset.sum_congr rfl
    intro t _
    simp [physicalBagFunction,Hnorm]
  rw [heq] at hb
  apply le_trans ?_ hb
  apply Finset.sum_le_sum
  intro t _
  have hm:0≤PhysicalMemoryState.mass P Line J B ν t:=by
    unfold PhysicalMemoryState.mass
    apply Finset.prod_nonneg
    intro i _
    apply mul_nonneg (Finset.prod_nonneg (fun k _=>hν i _))
    unfold MemoryState.mass anchoredParticleMass
    exact div_nonneg (Finset.prod_nonneg (fun k _=>hν i _)) (by positivity)
  apply mul_le_mul_of_nonneg_left ?_ hm
  exact pow_le_pow_left₀ (norm_nonneg _)
    (physicalGhostPhased_norm_le_positive ν V η q ρ anchor phase (physicalBagFunction H)
      hphase hν hV0 hη0 hq0 hρ.le t) 2

/-- The phased ghost constant is independent of the memory cutoff. -/
theorem physicalGhostPhased_symmetric_l2_uniform [Fintype Z]
    [∀i,Fintype (P i)] [∀i p,Fintype (Line i p)]
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ Q Vmax s:ℝ)
    (anchor:Z→∀i p,Line i p)
    (phase:(t:PhysicalMemoryState (Z:=Z) P Line J B)→PhysicalGhostChoice t→ℂ)
    (H:Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ)
    (hphase:∀t c,‖phase t c‖≤1)
    (hν:∀i p,0≤ν i p) (hs:∀i,(∑p,ν i p)≤s) (hs0:0≤s)
    (hρ:0<ρ) (hQ:Q<ρ^2) (hq0:0≤q) (hqQ:q≤Q)
    (hη0:0≤η) (hη1:η≤1) (hV0:∀i,0≤V i) (hVmax:∀i,V i≤Vmax) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (PhysicalPhasedWord.phasedApply (physicalGhostOperation ν V η q ρ anchor) phase (physicalBagFunction H)) ≤
      (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I) *
        finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (physicalBagFunction H) := by
  unfold finiteL2
  apply (Real.sqrt_le_sqrt (physicalGhostPhased_symmetric_l2_sq_uniform ν V η q ρ Q Vmax s
    anchor phase H hphase hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax)).trans_eq
  rw [Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq (by positivity)]

end Elliptic.Operator
