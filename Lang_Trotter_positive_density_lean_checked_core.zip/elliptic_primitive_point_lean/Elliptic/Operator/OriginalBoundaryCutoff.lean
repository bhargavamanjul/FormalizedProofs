module

public import Elliptic.Operator.ScheduledHistoryCutoff

/-!
# Exact change from a large memory state space to the actual smaller cap

The whole-history peak selector is read from the actual canonical key,
then from the original finite leaf. Its complete key coefficient is
unchanged when the ambient memory cap changes. This identifies the
selected cutoff sum in the large space with the literal small-cap pairing.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalHistoryFiber CanonicalHistoryCoefficient CanonicalBoundaryAssembly
open SourceHistoryCoefficient
attribute [local instance] Classical.propDecidable
local instance boundaryCutoffDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i→Type} {J B N : ℕ}
variable {anchor : Z→∀ i p,Line i p}

namespace OriginalLeaf

/-- The original finite leaf read directly from a canonical key. -/
def ofKey (k : CanonicalHistoryKey I Z P J N) :
    OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) where
  position := k.position
  active := k.active
  sourcePerm := k.sourcePerm
  targetPerm := k.targetPerm
  interval i p := (k.birth i p).bind (fun b=>(k.death i p).map (fun d=>(b,d)))

@[simp] theorem ofKey_key (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (h : e.Valid anchor B) : ofKey (e.key anchor h)=e := by
  apply OriginalLeaf.ext
  · funext j; exact e.key_position anchor h j
  · funext j; exact e.key_active anchor h j
  · funext j; exact e.key_sourcePerm anchor h j
  · funext j; exact e.key_targetPerm anchor h j
  · funext i p; exact e.key_interval anchor h i p

variable (value : ∀ i,P i→ℕ)
variable (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

/-- Actual nonzero restricted histories have exactly the cutoff read from
all original finite positions, lists and lifespan intervals in their key. -/
theorem actual_peak_iff_key_valid
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (u : BoundaryIndex I Z P J) (T : ℕ)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (emptyState (Line:=Line) (B:=B) u))
    (hr : Restricted ν V η q ρ anchor geometry value (emptyState (B:=B) u) h)
    (hw : h.weight≠0) :
    h.peakSize physicalMemorySize≤T ↔
      (ofKey (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry (emptyState (B:=B) u) h)).Valid anchor T := by
  let k := ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry (emptyState (B:=B) u) h
  have hk : NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) k := ⟨h,hr,rfl,hw⟩
  obtain ⟨e,he⟩ := nonzeroKey_covered value ν V η q ρ geometry hshared hban u k hk
  have hi : keyInitial (sourceKey value e)=u := by
    rw [he]
    exact nonzeroKey_initial ν V η q ρ anchor geometry value u k hk
  let d := e.val.toSchedule anchor e.property.valid
  have his : d.initialState=emptyState (Line:=Line) (B:=B) u :=
    (initialState_eq_empty value e).trans (congrArg (emptyState (Line:=Line) (B:=B)) hi)
  have hs : d.Before 0 (emptyState (Line:=Line) (B:=B) u) := by
    simpa only [his] using d.initialState_before
  have hc : d.Compatible ν V η q ρ geometry N 0 (emptyState (B:=B) u) h :=
    compatible_of_key_eq ν V η q ρ anchor geometry value d _ h hr.1
      (fun i=>emptyState_memory u i) hr.2 he.symm
  have hp := e.val.compatible_peak_le_iff_valid e.property.valid ν V η q ρ geometry T _ hs h hc
  change h.peakSize physicalMemorySize≤T ↔ (ofKey k).Valid anchor T
  rw [← he]
  simpa only [sourceKey,ofKey_key] using hp

/-- Literal selected cutoff boundary action in one fixed ambient state space. -/
def cutoffBoundaryPairing (T : ℕ) (a b : BoundaryIndex I Z P J→ℂ) : ℂ :=
  ∑ u : BoundaryIndex I Z P J,
    (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ)*conj (a u)*
      ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) (emptyState (B:=B) u)
        (fun h=>if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
          (emptyState (B:=B) u) h) then 1 else 0)

/-- The actual cutoff history sum is reindexed by finite keys only after
its peak condition has been proved constant on each nonzero key fiber. -/
theorem selectedCutoff_eq_key_weighted
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (u : BoundaryIndex I Z P J) (T : ℕ) (b : BoundaryIndex I Z P J→ℂ) :
    ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
      (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) (emptyState (Line:=Line) (B:=B) u)
      (fun h=>if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
        (emptyState (B:=B) u) h) then 1 else 0) =
      ∑ k : CanonicalHistoryKey I Z P J N,
        keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) k *
          (if (ofKey k).Valid anchor T then b (keyFinal k) else 0) := by
  rw [← sum_key_weighted ν V η q ρ anchor geometry value (emptyState (B:=B) u)]
  unfold ChoiceOperation.selectedCutoffHistorySum
  apply Finset.sum_congr rfl
  intro h _
  by_cases hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N (emptyState (B:=B) u) h)
  · by_cases hf : ∀ i,(h.final.memory P Line J B i).size=0
    · have hr : Restricted ν V η q ρ anchor geometry value (emptyState (B:=B) u) h := ⟨hd,hf⟩
      by_cases hw : h.weight=0
      · simp [hw]
      · have hp := actual_peak_iff_key_valid value ν V η q ρ geometry hshared hban u T h hr hw
        by_cases hpeak : h.peakSize physicalMemorySize≤T
        · have hv := hp.mp hpeak
          simp only [hpeak,hd,hr,hv,ite_true,one_mul,vacuumLift,hf,
            actualKey_final ν V η q ρ anchor geometry (emptyState (B:=B) u) h]
          simp
        · have hv : ¬(ofKey (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry
              (emptyState (B:=B) u) h)).Valid anchor T := fun hh=>hpeak (hp.mpr hh)
          simp only [hpeak,hr,hv,ite_false,ite_true,mul_zero]
    · simp [hd,hf,Restricted,vacuumLift]
  · simp [hd,Restricted]

/-- A key multiplier is retained through the exact original-leaf reindexing,
with no factorization assumption on that multiplier. -/
theorem key_boundary_sum_eq_leaves
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (a : BoundaryIndex I Z P J→ℂ) (F : CanonicalHistoryKey I Z P J N→ℂ) :
    (∑ u : BoundaryIndex I Z P J,
      (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ)*conj (a u)*
        ∑ k : CanonicalHistoryKey I Z P J N,
          keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) k*F k) =
      ∑ e : SourceLeaves anchor value J B N,
        (PhysicalMemoryState.mass P Line J B ν
          (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) : ℂ)*
        conj (a (keyInitial (sourceKey value e)))*
        keyWeightSum ν V η q ρ anchor geometry value
          (emptyState (B:=B) (keyInitial (sourceKey value e))) (sourceKey value e)*F (sourceKey value e) := by
  simp_rw [sum_keys_eq_sourceLeaves value ν V η q ρ geometry hshared hban,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.sum_eq_single (keyInitial (sourceKey value e))]
  · ring
  · intro u _ hu
    have hk : ¬NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) (sourceKey value e) := by
      intro hh
      exact hu (nonzeroKey_initial ν V η q ρ anchor geometry value u _ hh).symm
    rw [keyWeightSum_zero ν V η q ρ anchor geometry value (emptyState (B:=B) u) _ hk]
    simp
  · simp

/-- The large-space cutoff pairing is the sum of precisely those original
leaves that satisfy the small cutoff; the full coefficient is unchanged. -/
theorem cutoffBoundaryPairing_eq_leaves
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (μ : ∀ i,P i→ℝ) (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hν : ∀ i p,V i*ν i p=μ i p)
    (T : ℕ) (a b : BoundaryIndex I Z P J→ℂ) :
    cutoffBoundaryPairing (anchor:=anchor) (N:=N) (B:=B) value ν V η q ρ geometry T a b =
      ∑ e : SourceLeaves anchor value J B N,
        if e.val.Valid anchor T then conj (a (keyInitial (sourceKey value e)))*
          primewiseCoefficient anchor geometry μ V η q (e.val.toSchedule anchor e.property.valid)*
          b (keyFinal (sourceKey value e)) else 0 := by
  unfold cutoffBoundaryPairing
  simp_rw [selectedCutoff_eq_key_weighted value ν V η q ρ geometry hshared hban]
  rw [key_boundary_sum_eq_leaves value ν V η q ρ geometry hshared hban]
  apply Finset.sum_congr rfl
  intro e _
  simp only [sourceKey,ofKey_key]
  by_cases ht : e.val.Valid anchor T
  · simp only [ht,ite_true]
    have hc := sourceLeaf_complete_coefficient value ν V η q ρ geometry hvalue μ hρ hV hν e
    rw [← hc]
    simp only [sourceKey]
    ring
  · simp [ht]

/-- Changing only the cap preserves every non-cutoff validity condition. -/
theorem valid_mono {S T : ℕ} (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (h : e.Valid anchor S) (hST : S≤T) : e.Valid anchor T :=
  ⟨h.active_distinct,h.shared,h.unused,h.ordered,h.contains_active,h.singleton_active,h.incidence,
    fun j hj=>(h.before_cutoff j hj).trans hST,fun j hj=>(h.after_cutoff j hj).trans hST⟩

/-- The cap occurs only in proofs, not in the observable finite key. -/
theorem key_cap_irrel {S T : ℕ}
    (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (hs : e.Valid anchor S) (ht : e.Valid anchor T) :
    e.key anchor hs=e.key anchor ht := by
  rfl

/-- Every explicit coefficient is independent of the ambient cap once the
same original leaf is valid in both spaces. -/
theorem coefficient_cap_irrel {S T : ℕ}
    (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (hs : e.Valid anchor S) (ht : e.Valid anchor T) (μ : ∀ i,P i→ℝ) :
    primewiseCoefficient anchor geometry μ V η q (e.toSchedule anchor hs)=
      primewiseCoefficient anchor geometry μ V η q (e.toSchedule anchor ht) := by
  rfl

/-- The actual small-cap boundary pairing equals the globally selected
small-peak history sum in any larger ambient memory state space. -/
theorem cutoffBoundaryPairing_eq_small_cap
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (μ : ∀ i,P i→ℝ) (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hν : ∀ i p,V i*ν i p=μ i p)
    (T : ℕ) (hTB : T≤B) (a b : BoundaryIndex I Z P J→ℂ) :
    cutoffBoundaryPairing (anchor:=anchor) (N:=N) (B:=B) value ν V η q ρ geometry T a b =
      boundaryPairing (B:=T) ν V η q ρ anchor geometry value N a b := by
  rw [cutoffBoundaryPairing_eq_leaves value ν V η q ρ geometry hvalue hshared hban μ hρ hV hν,
    boundaryPairing_eq_originalLeaf_coefficients value ν V η q ρ geometry hvalue hshared hban μ hρ hV hν]
  symm
  apply Finset.sum_bij_ne_zero (fun e _ _ =>
    (⟨e.val,⟨valid_mono e.val e.property.valid hTB,e.property.crossEdgeBan⟩⟩ : SourceLeaves anchor value J B N))
  · intros; exact Finset.mem_univ _
  · intro e _ _ f _ _ hef
    exact Subtype.ext (congrArg (fun x : SourceLeaves anchor value J B N=>x.val) hef)
  · intro e _ he
    have ht : e.val.Valid anchor T := by
      by_contra hn
      simp [hn] at he
    refine ⟨⟨e.val,⟨ht,e.property.crossEdgeBan⟩⟩,Finset.mem_univ _,?_,?_⟩
    · simp only [ht,ite_true] at he
      simpa only [sourceKey,key_cap_irrel e.val e.property.valid ht,
        coefficient_cap_irrel V η q geometry e.val e.property.valid ht μ] using he
    · exact Subtype.ext rfl
  · intro e _ _
    rw [if_pos e.property.valid]
    simp only [sourceKey]
    rw [key_cap_irrel e.val e.property.valid (valid_mono e.val e.property.valid hTB),
      coefficient_cap_irrel V η q geometry e.val e.property.valid (valid_mono e.val e.property.valid hTB) μ]

end OriginalLeaf
end Elliptic.Operator.OriginalLifespanSchedule
