module
public import Elliptic.Operator.BoundaryMass

/-! Elementary actual prime-mass inputs for the physical birth bounds. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualBirthHighRank
open Filter
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

/-- Exponential lower prime cutoffs survive the literal transformed measure. -/
theorem transformed_atom_le {τ : Type*} (visits : Finset τ) (η : τ → ℝ)
    (V vmin L : ℝ) (p : ℕ) (hmin : 0 < vmin) (hV : vmin ≤ V)
    (hp : Real.exp (L^(1/10:ℝ)) ≤ (p:ℝ))
    (hη : ∀ j ∈ visits, η j ≤ 1)
    (hsize : 2*(visits.card:ℝ) ≤ Real.exp (L^(1/10:ℝ))) :
    0 ≤ transformedPrimeMass visits η V p ∧
      transformedPrimeMass visits η V p ≤ (2/vmin)*Real.exp (-L^(1/10:ℝ)) := by
  have hpR : 0 < (p:ℝ) := (Real.exp_pos _).trans_le hp
  have hVp : 0 < V := hmin.trans_le hV
  have h := transformedPrimeMass_bounds visits η V p hVp
    (by exact_mod_cast hpR) hη (hsize.trans hp)
  refine ⟨h.1,h.2.trans ?_⟩
  have hcoeff : 2/V ≤ 2/vmin := div_le_div_of_nonneg_left (by norm_num) hmin hV
  calc
    _ ≤ (2/vmin)/Real.exp (L^(1/10:ℝ)) :=
      div_le_div₀ (by positivity) hcoeff (Real.exp_pos _) hp
    _ = _ := by rw [Real.exp_neg];ring

theorem transformedPrimeMass_pos {τ : Type*} (visits : Finset τ) (η : τ→ℝ)
    (V : ℝ) (p : ℕ) (hV : 0<V) (hp : 0<p)
    (hη : ∀j∈visits,η j≤1) (hsize : 2*(visits.card:ℝ)≤(p:ℝ)) :
    0<transformedPrimeMass visits η V p := by
  have hsum : (∑j∈visits,η j)≤(visits.card:ℝ) := by
    calc
      _ ≤ ∑j∈visits,(1:ℝ) := Finset.sum_le_sum hη
      _ = _ := by simp
  have hpR : (0:ℝ)<p := by exact_mod_cast hp
  rw [transformedPrimeMass_eq]
  exact one_div_pos.mpr (mul_pos hV (by linarith))

/-- Both actual row mass and atom bounds are uniform before choosing the
prime bands, their labels, and the admissible damping deficits. -/
theorem eventually_transformed_mass_parameters (vmin : ℝ) (hmin : 0 < vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ (η : Fin (momentLength L+1) → ℝ)
      (primes : Finset ℕ) (V : ℝ), vmin ≤ V →
      V = ∑ p ∈ primes, 1/(p:ℝ) →
      (∀ p ∈ primes, Real.exp (L^(1/10:ℝ)) ≤ (p:ℝ)) → (∀ j, η j ≤ 1) →
      (∀ p : primes, 0 ≤ transformedPrimeMass Finset.univ η V p.val) ∧
      (∑ p : primes, transformedPrimeMass Finset.univ η V p.val) ≤ 2 ∧
      (∀ p : primes, transformedPrimeMass Finset.univ η V p.val ≤
        (2/vmin)*Real.exp (-L^(1/10:ℝ))) := by
  filter_upwards [eventually_memory_visits_le_prime_cutoff] with L hsize
  intro η primes V hV hsum hp hη
  have hs : 2*((Finset.univ : Finset (Fin (momentLength L+1))).card:ℝ) ≤ Real.exp (L^(1/10:ℝ)) := by
    simpa only [Finset.card_univ,Fintype.card_fin,Nat.cast_add,Nat.cast_one] using hsize
  have ha (p : primes) := transformed_atom_le Finset.univ η V vmin L p.val
    hmin hV (hp p.val p.property) (fun j _ => hη j) hs
  refine ⟨fun p => (ha p).1,?_,fun p => (ha p).2⟩
  have hm := (transformedPrimeMass_sum_le Finset.univ η primes V (Real.exp (L^(1/10:ℝ)))
    (hmin.trans_le hV) hsum (Real.exp_pos _) hp (fun j _ => hη j) hs).2
  have he : 2*((Finset.univ : Finset (Fin (momentLength L+1))).card:ℝ)/Real.exp (L^(1/10:ℝ)) ≤ 1 :=
    (div_le_one (Real.exp_pos _)).mpr hs
  rw [Finset.sum_coe_sort]
  linarith

end Elliptic.Operator.ActualBirthHighRank
