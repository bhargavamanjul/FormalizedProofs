module

public import Elliptic.Operator.MemoryAdjoint
public import Elliptic.Operator.WeightedSchur
public import Mathlib.Data.Fintype.Powerset
public import Mathlib.Data.Finset.Sort
public import Mathlib.Data.Fintype.Sigma

/-!
# Actual ordered memory states and transition choices

This file gives finite, literal realizations of the ghost memory operation
in source (4.10)--(4.14). A particle consists of its prime label and a retained anchor.
Memory is an ordered tuple; deletion and promotion refer to its indices,
not its values, so repetitions remain possible. Fresh batches carry their
product prime measure divided by the batch factorial.

This file defines the ghost transition sums themselves. It does not yet define
the edge operation or identify a full operator word with primewise lifespans.
It assumes neither a memory-word identity nor an operator norm bound.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators

/-- An ordered particle tuple of length at most B. -/
abbrev MemoryState (X : Type*) (B : ℕ) := Σ k : Fin (B + 1), Fin k.val → X

namespace MemoryState

def size {X : Type*} {B : ℕ} (m : MemoryState X B) : ℕ := m.1.val

def values {X : Type*} {B : ℕ} (m : MemoryState X B) : Fin m.size → X := m.2

def empty (X : Type*) (B : ℕ) : MemoryState X B := ⟨⟨0, by omega⟩, Fin.elim0⟩

theorem size_le {X : Type*} {B : ℕ} (m : MemoryState X B) : m.size ≤ B := by
  have := m.1.isLt
  exact Nat.le_of_lt_succ this

/-- The actual factorial tensor measure of an ordered memory state. -/
def mass {X R : Type*} [Field R] {B : ℕ} (μ : X → R) (m : MemoryState X B) : R :=
  tupleWeight μ m.values / (m.size.factorial : R)

theorem mass_pos {X : Type*} {B : ℕ} (μ : X → ℝ) (hμ : ∀ x, 0 < μ x)
    (m : MemoryState X B) : 0 < m.mass μ := by
  apply div_pos
  · exact Finset.prod_pos (fun i _ => hμ (m.values i))
  · exact_mod_cast Nat.factorial_pos m.size

/-- Coordinate relabelling leaves the actual factorial tensor measure unchanged. -/
theorem mass_permute {X R : Type*} [Field R] {B : ℕ}
    (μ : X → R) (m : MemoryState X B) (σ : Equiv.Perm (Fin m.size)) :
    mass μ (⟨m.1, m.values ∘ σ⟩ : MemoryState X B) = mass μ m := by
  exact congrArg (fun t : R => t / (m.size.factorial : R)) (tupleWeight_permute σ μ m.values)

end MemoryState

/-- A pending particle retains both its prime and its anchor line. -/
abbrev AnchoredParticle (P : Type*) (Line : P → Type*) := Σ p : P, Line p

/-- Anchors have counting measure: their mass is exactly the prime mass. -/
def anchoredParticleMass {P : Type*} {Line : P → Type*}
    (ν : P → ℝ) (x : AnchoredParticle P Line) : ℝ := ν x.1

def anchorPrime {P : Type*} {Line : P → Type*} (anchor : ∀ p, Line p)
    (p : P) : AnchoredParticle P Line := ⟨p, anchor p⟩

@[simp] theorem anchoredParticleMass_anchorPrime {P : Type*} {Line : P → Type*}
    (ν : P → ℝ) (anchor : ∀ p, Line p) (p : P) :
    anchoredParticleMass ν (anchorPrime anchor p) = ν p := rfl

/-- A hit tests the retained anchor against the current position's line. -/
def particleHits {P : Type*} {Line : P → Type*} (anchor : ∀ p, Line p)
    (x : AnchoredParticle P Line) : Prop := x.2 = anchor x.1

/-- Exact indexed old-memory hits. -/
def memoryHits {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B) :
    Finset (Fin m.size) := by
  classical
  exact Finset.univ.filter (fun i => particleHits anchor (m.values i))

/-- The survivors are retained in increasing old-index order. -/
def ghostSurvivors {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size)) :
    Fin Sᶜ.card → AnchoredParticle P Line :=
  fun i => m.values (Sᶜ.orderEmbOfFin rfl i)

/-- A literal ghost operation chooses old indices and an ordered fresh batch. -/
abbrev GhostChoice {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) :=
  Finset (Fin m.size) × MemoryState P B

/-- Only hits can be deleted, and the final state obeys the cutoff. -/
def GhostChoice.Valid {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) : Prop :=
  c.1 ⊆ memoryHits anchor m ∧ c.1ᶜ.card + c.2.size ≤ B

/-- The actual output appends anchored fresh primes after surviving old particles. -/
def ghostOutput {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c) :
    MemoryState (AnchoredParticle P Line) B :=
  ⟨⟨c.1ᶜ.card + c.2.size, Nat.lt_succ_of_le hc.2⟩,
    Fin.append (ghostSurvivors m c.1) (fun j => anchorPrime anchor (c.2.values j))⟩

@[simp] theorem ghostOutput_size {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c) :
    (ghostOutput anchor m c hc).size = m.size - c.1.card + c.2.size := by
  change c.1ᶜ.card + c.2.size = m.size - c.1.card + c.2.size
  congr 1
  simpa only [Fintype.card_fin] using Finset.card_compl c.1

/-- The survival exponent is the original hit count minus the deleted
indexed hits, including when some particle values repeat. -/
theorem ghost_surviving_hits_card {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c) :
    (memoryHits anchor m \ c.1).card = (memoryHits anchor m).card - c.1.card := by
  exact Finset.card_sdiff_of_subset hc.1

/-- Exact signed coefficient from source (4.2): indexed deletion,
surviving-hit damping, and an integrated factorial fresh batch. -/
def ghostChoiceWeight {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) : ℝ :=
  (-η / ρ) ^ c.1.card * (q / ρ ^ 2) ^ (memoryHits anchor m \ c.1).card *
    (-η * V / ρ) ^ c.2.size * tupleWeight ν c.2.values / (c.2.size.factorial : ℝ)

/-- The actual finite ghost action sums operation choices; no kernel or
adjoint estimate is a premise. -/
def ghostApply {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F : MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) : ℂ := by
  classical
  exact ∑ c : GhostChoice m, if hc : GhostChoice.Valid anchor m c then
    (ghostChoiceWeight ν V η q ρ anchor m c : ℂ) * F (ghostOutput anchor m c hc) else 0

/-- The raw transition matrix is obtained by collecting choices with the
same output memory tuple. -/
def ghostTransition {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m n : MemoryState (AnchoredParticle P Line) B) : ℂ := by
  classical
  exact ghostApply ν V η q ρ anchor (fun out => if out = n then 1 else 0) m

/-- Summing the actual transition matrix reproduces the actual ghost
choice sum, including multiplicities of equal output tuples. -/
theorem ghostApply_eq_transition_sum {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F : MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostApply ν V η q ρ anchor F m =
      ∑ n : MemoryState (AnchoredParticle P Line) B,
        ghostTransition ν V η q ρ anchor m n * F n := by
  classical
  unfold ghostTransition ghostApply
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  split_ifs with hc
  · simp
  · simp

/-- Kernel density with respect to the actual factorial memory measure. -/
def ghostKernel {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m n : MemoryState (AnchoredParticle P Line) B) : ℂ :=
  ghostTransition ν V η q ρ anchor m n /
    ((MemoryState.mass (anchoredParticleMass ν) n : ℝ) : ℂ)

/-- The measured-kernel action equals the concrete ghost choice action.
Positivity here is exactly positivity of the actual prime masses. -/
theorem finiteKernelApply_ghostKernel {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (hν : ∀ p, 0 < ν p) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (F : MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    finiteKernelApply Finset.univ (MemoryState.mass (anchoredParticleMass ν))
      (ghostKernel ν V η q ρ anchor) F m = ghostApply ν V η q ρ anchor F m := by
  rw [ghostApply_eq_transition_sum]
  unfold finiteKernelApply ghostKernel
  apply Finset.sum_congr rfl
  intro n _
  have hn : ((MemoryState.mass (anchoredParticleMass ν) n : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (MemoryState.mass_pos _ (fun x => hν x.1) n).ne'
  field_simp

end Elliptic.Operator
