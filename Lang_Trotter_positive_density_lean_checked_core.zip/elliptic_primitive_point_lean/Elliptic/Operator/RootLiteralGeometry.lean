module

public import Elliptic.Operator.RootSourceGeometry
public import Elliptic.Operator.RootEndpointBudget
public import Elliptic.Operator.RootGoodMeasurable
public import Elliptic.Operator.RootPhaseMeasure
public import Elliptic.Operator.SourceMinorArc

/-!
# Literal source tests are stable on every retained physical root cell

The source test is evaluated at the canonically chosen short integral
complement. Its entire multiplier and threshold family is included in
the explicit endpoint set. Whole-cell phase bounds are deduced from the
physical projection and the constructed physical-face exclusions.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootLiteralGeometry
open RootArchimedeanGrid RootPhysicalCell RootBoundaryCover RootGoodBoundary
open RootEndpointBudget RootGoodProductBounds RootPhaseMeasure
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def activeLabel (value : ∀i,P i→ℕ) (a : PhysicalActiveLists P J) : Fin K×Fin (J+1)→ℕ :=
  fun ij=>value ij.1 (a ij.1 ij.2)

def sourceGood (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (q : RootPoint)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : Prop :=
  sourceTests value (activeLabel value a) μ d₀ Y L exponents (phase z (chosenComplement z) q.2.2)

def sourceEndpoints (R Q : ℕ) (Y L : ℝ) (exponents : Fin K→ℝ) : Finset ℝ :=
  allEndpoints R (Q^(K*(J+1)+2*K)) (radii K Y L exponents)

theorem position_coordinate_bounds (R : ℕ) (z : ℤ×ℤ) (hz : z∈integerPositionBox R) :
    |(z.1:ℝ)|≤R ∧ |(z.2:ℝ)|≤R := by
  simp only [integerPositionBox,Finset.mem_product,Finset.mem_Icc] at hz
  constructor <;> rw [abs_le]
  · exact ⟨by exact_mod_cast hz.1.1,by exact_mod_cast hz.1.2⟩
  · exact ⟨by exact_mod_cast hz.2.1,by exact_mod_cast hz.2.2⟩

theorem sourceGood_measurable (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J) :
    MeasurableSet {q : RootPoint | sourceGood value μ d₀ Y L exponents q z a} :=
  (RootGoodMeasurable.bothGoodTests_root_measurable value (activeLabel value a) μ d₀ Y L
    exponents z (chosenComplement z)).preimage (measurable_snd.comp measurable_snd)

theorem sourceGood_constant_at_physical (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z : ℤ×ℤ) (hz : z∈integerPositionBox R) (a : PhysicalActiveLists P J)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q)
    (hphys : sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z) :
    sourceGood value μ d₀ Y L exponents p z a ↔ sourceGood value μ d₀ Y L exponents q z a := by
  have hnot : j∉physicalFaces n z ((z.2:ℝ)/(U*V)) := by
    intro h
    exact hout (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨z,hz,h⟩))
  obtain ⟨hf1,hf16,_,_⟩ := (not_mem_physicalFaces n z _ j).mp hnot
  have ha := RootFirstFace.cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) p.1 hp.1
  have hnormalized := (source_allowed_iff_normalized U V hU hV p (by linarith) z).mp hphys
  have hwhole := whole_cell_phase n j hj z (chosenComplement z) hf1 hf16 p hp hnormalized.2.1
  have hcoords := position_coordinate_bounds R z hz
  have hw := chosenComplement_spec z hphys.1
  have hb1 : |((chosenComplement z).1:ℝ)|≤1+(R:ℝ) :=
    hw.2.1.trans (by gcongr; exact max_le hcoords.1 hcoords.2)
  have hb2 : |((chosenComplement z).2:ℝ)|≤1+(R:ℝ) :=
    hw.2.2.trans (by gcongr; exact max_le hcoords.1 hcoords.2)
  have hpole : ∀t∈Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper,
      latticeTau t z≠0 := fun t ht=>(hwhole t ht).1
  have hbound : ∀t∈Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper,
      |phase z (chosenComplement z) t|≤32*(1+(R:ℝ)) := by
    intro t ht
    have hh := (hwhole t ht).2
    linarith
  have hends : ∀t∈RootTestEndpoints.endpoints z (chosenComplement z)
      (Q^(K*(J+1)+2*K)) (32*(1+(R:ℝ))) (radii K Y L exponents),
      t∉Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper := by
    intro t ht hmem
    apply hout
    apply Finset.mem_union_right
    exact Finset.mem_biUnion.mpr ⟨t,endpoint_subset R _ _ z hz ht,
      (mem_boundaryCubes n t j).mpr ⟨hj,hmem⟩⟩
  exact bothGoodTests_constant value (activeLabel value a) Q hQ hv
    (fun ij=>hv _ _) z (chosenComplement z) hw.1 (32*(1+(R:ℝ)))
    (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper μ d₀ Y L exponents
    hY hpole hbound hends p.2.2 q.2.2 hp.2.2 hq.2.2

theorem sourceTests_constant_at_physical (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z : ℤ×ℤ) (hz : z∈integerPositionBox R)
    (label : Fin K×Fin (J+1)→ℕ) (hl : ∀ij,label ij≤Q)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q)
    (hphys : sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z) :
    sourceTests value label μ d₀ Y L exponents (phase z (chosenComplement z) p.2.2) ↔
      sourceTests value label μ d₀ Y L exponents (phase z (chosenComplement z) q.2.2) := by
  have hnot : j∉physicalFaces n z ((z.2:ℝ)/(U*V)) := by
    intro h
    exact hout (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨z,hz,h⟩))
  obtain ⟨hf1,hf16,_,_⟩ := (not_mem_physicalFaces n z _ j).mp hnot
  have ha := RootFirstFace.cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) p.1 hp.1
  have hnormalized := (source_allowed_iff_normalized U V hU hV p (by linarith) z).mp hphys
  have hwhole := whole_cell_phase n j hj z (chosenComplement z) hf1 hf16 p hp hnormalized.2.1
  have hcoords := position_coordinate_bounds R z hz
  have hw := chosenComplement_spec z hphys.1
  have hb1 : |((chosenComplement z).1:ℝ)|≤1+(R:ℝ) :=
    hw.2.1.trans (by gcongr; exact max_le hcoords.1 hcoords.2)
  have hb2 : |((chosenComplement z).2:ℝ)|≤1+(R:ℝ) :=
    hw.2.2.trans (by gcongr; exact max_le hcoords.1 hcoords.2)
  have hpole : ∀t∈Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper,
      latticeTau t z≠0 := fun t ht=>(hwhole t ht).1
  have hbound : ∀t∈Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper,
      |phase z (chosenComplement z) t|≤32*(1+(R:ℝ)) := by
    intro t ht
    have hh := (hwhole t ht).2
    linarith
  have hends : ∀t∈RootTestEndpoints.endpoints z (chosenComplement z)
      (Q^(K*(J+1)+2*K)) (32*(1+(R:ℝ))) (radii K Y L exponents),
      t∉Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper := by
    intro t ht hmem
    apply hout
    apply Finset.mem_union_right
    exact Finset.mem_biUnion.mpr ⟨t,endpoint_subset R _ _ z hz ht,
      (mem_boundaryCubes n t j).mpr ⟨hj,hmem⟩⟩
  exact bothGoodTests_constant value label Q hQ hv hl z (chosenComplement z) hw.1 (32*(1+(R:ℝ)))
    (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper μ d₀ Y L exponents
    hY hpole hbound hends p.2.2 q.2.2 hp.2.2 hq.2.2

/-- Physical projection and both literal good-state projections are
constant together, including cells where no physical point is allowed. -/
theorem projectedGood_constant (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z : ℤ×ℤ) (hz : z∈integerPositionBox R) (a : PhysicalActiveLists P J)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    (sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z ∧
      sourceGood value μ d₀ Y L exponents p z a) ↔
    (sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z ∧
      sourceGood value μ d₀ Y L exponents q z a) := by
  have hphys := source_allowed_constant_of_outside n j hj (integerPositionBox R)
    (sourceEndpoints (J:=J) R Q Y L exponents) U V hU hV hout z hz p q hp hq
  by_cases hpa : sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z
  · exact and_congr hphys (sourceGood_constant_at_physical value μ R Q hQ hv d₀ Y L exponents
      hY n j hj U V hU hV hout z hz a p q hp hq hpa)
  · have hqa := mt hphys.mpr hpa
    simp [hpa,hqa]

theorem edge_allowed_constant (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z w : ℤ×ℤ) (hz : z∈integerPositionBox R) (hw : w∈integerPositionBox R)
    (a b : PhysicalActiveLists P J) (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    sourcePhysicalEdgeAllowed value (sourceGood value μ d₀ Y L exponents p)
      (U*p.1) (V*p.2.1) p.2.2 U V d₀ z a w b ↔
    sourcePhysicalEdgeAllowed value (sourceGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ z a w b := by
  have hza := projectedGood_constant value μ R Q hQ hv d₀ Y L exponents hY n j hj U V hU hV
    hout z hz a p q hp hq
  have hwb := projectedGood_constant value μ R Q hQ hv d₀ Y L exponents hY n j hj U V hU hV
    hout w hw b p q hp hq
  constructor
  · rintro ⟨hzp,hwp,hzg,hwg,hrest⟩
    have hzq := hza.mp ⟨hzp,hzg⟩
    have hwq := hwb.mp ⟨hwp,hwg⟩
    exact ⟨hzq.1,hwq.1,hzq.2,hwq.2,hrest⟩
  · rintro ⟨hzq,hwq,hzg,hwg,hrest⟩
    have hzp := hza.mpr ⟨hzq,hzg⟩
    have hwp := hwb.mpr ⟨hwq,hwg⟩
    exact ⟨hzp.1,hwp.1,hzp.2,hwp.2,hrest⟩

theorem geometry_constant (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z w : ℤ×ℤ) (hz : z∈integerPositionBox R) (hw : w∈integerPositionBox R)
    (a b : PhysicalActiveLists P J) (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    sourcePhysicalEdgeGeometry value (sourceGood value μ d₀ Y L exponents p)
      (U*p.1) (V*p.2.1) p.2.2 U V d₀ Y η ψ major σ z a w b =
    sourcePhysicalEdgeGeometry value (sourceGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b := by
  have h := edge_allowed_constant value μ R Q hQ hv d₀ Y L exponents hY n j hj U V hU hV
    hout z w hz hw a b p q hp hq
  unfold sourcePhysicalEdgeGeometry
  rw [propext h]

def geometry (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (w : ℤ×ℤ) (b : PhysicalActiveLists P J) (q : RootPoint) : ℂ :=
  orientedSourceEdgeGeometry adjoint value (sourceGood value μ d₀ Y L exponents q)
    (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b

theorem oriented_geometry_constant (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R Q : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z w : ℤ×ℤ) (hz : z∈integerPositionBox R) (hw : w∈integerPositionBox R)
    (a b : PhysicalActiveLists P J) (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b p =
      geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b q := by
  cases adjoint
  · exact geometry_constant value μ R Q hQ hv d₀ Y L exponents hY n j hj U V hU hV η ψ major σ
      hout z w hz hw a b p q hp hq
  · apply congrArg star
    exact geometry_constant value μ R Q hQ hv d₀ Y L exponents hY n j hj U V hU hV η ψ major σ
      hout w z hw hz b a p q hp hq

theorem geometry_measurable (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (w : ℤ×ℤ) (b : PhysicalActiveLists P J) :
    Measurable (geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b) :=
  RootSourceGeometry.oriented_geometry_measurable value (sourceGood value μ d₀ Y L exponents)
    (sourceGood_measurable value μ d₀ Y L exponents) adjoint U V d₀ Y η ψ major σ z w a b

theorem geometry_norm_le_one (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (hη : ∀t, ‖η t‖≤1) (hψ : ∀t, ‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) (w : ℤ×ℤ) (b : PhysicalActiveLists P J)
    (q : RootPoint) : ‖geometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b q‖≤1 := by
  simpa only [geometry,one_pow,mul_one] using orientedSourceEdgeGeometry_norm_le_one_factor adjoint value
    (sourceGood value μ d₀ Y L exponents q) (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major hmajor σ
    1 1 hd (by norm_num) (by norm_num) hη hψ z a w b

end Elliptic.Operator.RootLiteralGeometry
