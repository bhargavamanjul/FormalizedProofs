module

public import Elliptic.Operator.SingleEdgeRootGood
public import Elliptic.Operator.RootRecordEncoding
public import Elliptic.Operator.PhysicalPathSupport

/-!
# Canonical integral coordinates for entire physical paths

The completion is chosen once, at the initial physical position.  All later
positions are transformed by this same integral matrix.  Active lists and
both endpoint permutations are retained.  The resulting finite reindexing
has no multiplicity, and the literal signed edge product is unchanged.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPathRootEncoding
open scoped BigOperators
open OriginalLifespanSchedule SingleEdgeRootEncoding SourceRootCount
open RootRecordGood RootLiteralGeometry
attribute [local instance] Classical.propDecidable
local instance pathRootDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z W : Type} {P : I→Type} {J N : ℕ}

/-- Change positions only; the actual active labels and permutations do
not participate in this coordinate change. -/
def mapPositions (f : Z→W) (r : OriginalPath I Z P J N) : OriginalPath I W P J N where
  position := fun j=>f (r.position j)
  active := r.active
  sourcePerm := r.sourcePerm
  targetPerm := r.targetPerm

theorem mapPositions_injective (f : Z→W) (hf : Function.Injective f) :
    Function.Injective (mapPositions (P:=P) (J:=J) (N:=N) f) := by
  intro r s h
  apply OriginalPath.ext
  · funext j
    exact hf (congrArg (fun q : OriginalPath I W P J N=>q.position j) h)
  · exact congrArg (fun q : OriginalPath I W P J N=>q.active) h
  · exact congrArg (fun q : OriginalPath I W P J N=>q.sourcePerm) h
  · exact congrArg (fun q : OriginalPath I W P J N=>q.targetPerm) h

def rootPath (t : RootTriple) (r : OriginalPath I (ℤ×ℤ) P J N) :=
  mapPositions (coordinates t) r

def physicalPath (t : RootTriple) (r : OriginalPath I (ℤ×ℤ) P J N) :=
  mapPositions (decode t) r

theorem physical_root (t : RootTriple) (ht : Canonical t)
    (r : OriginalPath I (ℤ×ℤ) P J N) : physicalPath t (rootPath t r)=r := by
  apply OriginalPath.ext
  · funext j; exact decode_coordinates t ht _
  all_goals rfl

theorem root_physical (t : RootTriple) (ht : Canonical t)
    (r : OriginalPath I (ℤ×ℤ) P J N) : rootPath t (physicalPath t r)=r := by
  apply OriginalPath.ext
  · funext j; exact coordinates_decode t ht _
  all_goals rfl

theorem rootPath_injective (t : RootTriple) (ht : Canonical t) :
    Function.Injective (rootPath (I:=I) (P:=P) (J:=J) (N:=N) t) :=
  mapPositions_injective _ (coordinatesEquiv t ht).injective

@[simp] theorem rootPath_sourceLists (t : RootTriple)
    (r : OriginalPath I (ℤ×ℤ) P J N) (j : ℕ) :
    (rootPath t r).sourceLists j=r.sourceLists j := rfl

@[simp] theorem rootPath_targetLists (t : RootTriple)
    (r : OriginalPath I (ℤ×ℤ) P J N) (j : ℕ) :
    (rootPath t r).targetLists j=r.targetLists j := rfl

@[simp] theorem rootPath_positionAt (t : RootTriple)
    (r : OriginalPath I (ℤ×ℤ) P J N) (j : ℕ) :
    (rootPath t r).positionAt j=coordinates t (r.positionAt j) := rfl

theorem rootPath_start (t : RootTriple) (ht : Canonical t)
    (r : OriginalPath I (ℤ×ℤ) P J N) (h : r.position 0=column t) :
    (rootPath t r).position 0=(1,0) := by
  change coordinates t (r.position 0)=(1,0)
  rw [h,coordinates_source t ht]

/-- All original paths are partitioned by their actual initial position,
then reindexed by their unique canonical completion and inverse image.
The target finite sets are literal images, with no extra ambient paths. -/
theorem sum_paths_reindex {A : Type*} [AddCommMonoid A]
    (U V : ℝ) (hU : 0<U) (paths : Finset (OriginalPath I (ℤ×ℤ) P J N))
    (hstart : ∀r∈paths,r.position 0∈primitiveSources U V)
    (F : OriginalPath I (ℤ×ℤ) P J N→A) :
    (∑r∈paths,F r)=
      ∑t∈canonicalRoots U V,
        ∑r∈(paths.filter (fun r=>r.position 0=column t)).image (rootPath t),
          F (physicalPath t r) := by
  have hgroup : (∑r∈paths,F r)=∑z∈primitiveSources U V,
      ∑r∈paths.filter (fun r=>r.position 0=z),F r := by
    symm
    exact Finset.sum_fiberwise_of_maps_to hstart F
  rw [hgroup,sum_sources_eq_roots U V hU]
  apply Finset.sum_congr rfl
  intro t ht
  have hc := (Finset.mem_filter.mp ht).2
  rw [Finset.sum_image (rootPath_injective t hc).injOn]
  apply Finset.sum_congr rfl
  intro r hr
  rw [physical_root t hc]

variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

/-- Both orientations of the literal projected signed edge transform
under the same canonical completion. No parity of the cutoff is used. -/
theorem oriented_geometry_coordinates (adjoint : Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (d₀ Y L : ℝ)
    (exponents : Fin K→ℝ) (t : RootTriple) (ht : Canonical t)
    (U V : ℝ) (hU : 0<U) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J) :
    orientedSourceEdgeGeometry adjoint value
      (sourceGood value μ d₀ Y L exponents (RootVariableSum.normalizedRoot U V t))
      (t.1:ℝ) (t.2.1:ℝ) ((t.2.2:ℝ)/t.1) U V d₀ Y η ψ major σ
      (coordinates t z) a (coordinates t w) b =
    orientedSourceEdgeGeometry adjoint value
      (sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U V d₀ Y η ψ major σ z a w b := by
  have h (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J) := SingleEdgeRootGood.geometry_decode value μ d₀ Y L exponents
    t ht U V hU η ψ major σ (coordinates t z) (coordinates t w) a b
  simp only [decode_coordinates t ht] at h
  cases adjoint
  · exact h z w a b
  · exact congrArg star (h w z b a)

/-- The complete original physical edge product equals the rooted edge
product, retaining each source/target permutation and shift sign. -/
theorem edge_product_coordinates (r : OriginalPath (Fin K) (ℤ×ℤ) P J N)
    (adjoint : ℕ→Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (d₀ Y L : ℝ)
    (exponents : Fin K→ℝ) (t : RootTriple) (ht : Canonical t)
    (U V : ℝ) (hU : 0<U) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) :
    (∏j∈Finset.range N,orientedSourceEdgeGeometry (adjoint j) value
      (sourceGood value μ d₀ Y L exponents (RootVariableSum.normalizedRoot U V t))
      (t.1:ℝ) (t.2.1:ℝ) ((t.2.2:ℝ)/t.1) U V d₀ Y η ψ major σ
      ((rootPath t r).positionAt j) ((rootPath t r).sourceLists j)
      ((rootPath t r).positionAt (j+1)) ((rootPath t r).targetLists j)) =
    ∏j∈Finset.range N,orientedSourceEdgeGeometry (adjoint j) value
      (sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U V d₀ Y η ψ major σ (r.positionAt j) (r.sourceLists j)
      (r.positionAt (j+1)) (r.targetLists j) := by
  apply Finset.prod_congr rfl
  intro j hj
  exact oriented_geometry_coordinates (adjoint j) value μ d₀ Y L exponents
    t ht U V hU η ψ major σ _ _ _ _

/-- The literal support of an entire original path gives the finite
integer coordinate box after one canonical change of variables.  The
endpoint permutations can vary independently at every edge. -/
theorem rootPath_mem_positionBox (r : OriginalPath (Fin K) (ℤ×ℤ) P J N)
    (adjoint : ℕ→Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L C : ℝ) (exponents : Fin K→ℝ)
    (U V : ℝ) (hU : 0<U) (t : RootTriple) (ht : t∈canonicalRoots U V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (hstart : r.position 0=column t)
    (hpositions : ∀j≤N,sourcePhysicalPositionAllowed 1 0 0 U V (r.positionAt j))
    (hedges : ∀j<N,orientedSourceEdgeGeometry (adjoint j) value
      (sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U V d₀ Y η ψ major σ (r.positionAt j) (r.sourceLists j)
      (r.positionAt (j+1)) (r.targetLists j)≠0)
    (j : ℕ) (hj : j≤N) :
    (rootPath t r).positionAt j∈integerPositionBox ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊ := by
  have hc := (Finset.mem_filter.mp ht).2
  have hb := (mem_rootCandidates_iff U V t hc).mp (Finset.mem_filter.mp ht).1
  have hu : (0:ℝ)<t.1 := by exact_mod_cast hc.1
  have hratio : |(t.2.2:ℝ)/t.1|≤1 := by
    rw [abs_of_nonneg (div_nonneg (by exact_mod_cast hc.2.1) hu.le)]
    exact (div_lt_one hu).mpr (by exact_mod_cast hc.2.2.1) |>.le
  apply physical_path_mem_positionBox (fun j=>(rootPath t r).positionAt j)
    ((t.2.2:ℝ)/t.1) (2*d₀*Y*C) N (by positivity) hratio
  · have hs := rootPath_start t hc r hstart
    have hv : OriginalPath.visit (N:=N) 0=0 := Fin.ext (by simp [OriginalPath.visit])
    change (rootPath t r).position (OriginalPath.visit 0)=(1,0)
    rw [hv]
    exact hs
  · intro k hk
    apply sourcePhysicalPosition_tau_bounds (t.1:ℝ) (t.2.1:ℝ) ((t.2.2:ℝ)/t.1)
      U V _ hU hb.1 hb.2.1
    apply (physical_allowed_decode t hc U V _).mpr
    simpa only [rootPath_positionAt,decode_coordinates t hc] using hpositions k hk
  · intro k hk
    apply oriented_geometry_nonzero_det_bound (adjoint k) value
      (sourceGood value μ d₀ Y L exponents (RootVariableSum.normalizedRoot U V t))
      (t.1:ℝ) (t.2.1:ℝ) ((t.2.2:ℝ)/t.1) U V d₀ Y C η ψ major σ
      hd hY hC hψ _ _ (r.sourceLists k) (r.targetLists k)
    simpa only [rootPath_positionAt,oriented_geometry_coordinates (adjoint k) value μ
      d₀ Y L exponents t hc U V hU η ψ major σ] using hedges k hk
  · exact hj

end Elliptic.Operator.PhysicalPathRootEncoding
