module

public import Elliptic.Operator.ScheduledHistoryCutoff

/-!
# Exact comparison of large-cap projected histories and small-cap boundaries

The cutoff is read from complete actual histories, then transported through
the finite original leaf correspondence. It is precisely the smaller leaf
validity condition. No equality of unrelated state types is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalHistoryFiber CanonicalHistoryCoefficient
open CanonicalBoundaryAssembly SourceHistoryCoefficient
attribute [local instance] Classical.propDecidable
local instance originalCutoffDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i→Type} {J B N : ℕ}
variable {anchor : Z→∀ i p,Line i p}

namespace OriginalLeaf
variable (value : ∀ i,P i→ℕ)

/-- A finite-key predicate defined from the original pending intervals. -/
def KeyCutoff (B T : ℕ) (k : CanonicalHistoryKey I Z P J N) : Prop :=
  ∃ e : SourceLeaves anchor value J B N, sourceKey value e=k ∧ e.val.Valid anchor T

@[simp] theorem keyCutoff_sourceKey (T : ℕ) (e : SourceLeaves anchor value J B N) :
    KeyCutoff (anchor:=anchor) value B T (sourceKey value e) ↔ e.val.Valid anchor T := by
  constructor
  · rintro ⟨f,hf,ht⟩
    have he := sourceKey_injective value hf
    subst f
    exact ht
  · intro ht
    exact ⟨e,rfl,ht⟩

variable (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

/-- For actual contributing histories the finite-key cutoff is the literal
maximum over all visited memory states. -/
theorem keyCutoff_iff_peak_of_nonzero
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (T : ℕ) (u : BoundaryIndex I Z P J)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (emptyState (Line:=Line) (B:=B) u))
    (hr : Restricted ν V η q ρ anchor geometry value (emptyState (B:=B) u) h)
    (hw : h.weight≠0) :
    KeyCutoff (anchor:=anchor) value B T
      (ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry (emptyState (B:=B) u) h) ↔
      h.peakSize physicalMemorySize≤T := by
  let k := ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry (emptyState (B:=B) u) h
  have hk : NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) k := ⟨h,hr,rfl,hw⟩
  obtain ⟨e,he⟩ := nonzeroKey_covered value ν V η q ρ geometry hshared hban u k hk
  have hi : (e.val.toSchedule anchor e.property.valid).initialState=emptyState (Line:=Line) (B:=B) u := by
    rw [initialState_eq_empty value e,he,nonzeroKey_initial ν V η q ρ anchor geometry value u k hk]
  have hs : (e.val.toSchedule anchor e.property.valid).Before 0 (emptyState (Line:=Line) (B:=B) u) :=
    hi ▸ (e.val.toSchedule anchor e.property.valid).initialState_before
  have hc := compatible_of_key_eq ν V η q ρ anchor geometry value
    (e.val.toSchedule anchor e.property.valid) (emptyState (B:=B) u) h hr.1
    (fun i=>emptyState_memory u i) hr.2 he.symm
  change KeyCutoff value B T k ↔ _
  rw [← he,keyCutoff_sourceKey]
  exact (e.val.compatible_peak_le_iff_valid e.property.valid ν V η q ρ geometry T _ hs h hc).symm

/-- The projected selected vacuum sum is reindexed by actual keys with the
proved cutoff predicate. Zero histories need no reconstruction witness. -/
theorem selectedCutoff_vacuum_eq_key_weighted
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (T : ℕ) (u : BoundaryIndex I Z P J) (b : BoundaryIndex I Z P J→ℂ) :
    ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
      (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) (emptyState (Line:=Line) (B:=B) u)
      (fun h=>if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
        (emptyState (B:=B) u) h) then 1 else 0) =
      ∑ k : CanonicalHistoryKey I Z P J N,
        keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) k *
          (b (keyFinal k) * if KeyCutoff (anchor:=anchor) value B T k then 1 else 0) := by
  rw [← sum_key_weighted ν V η q ρ anchor geometry value (emptyState (B:=B) u)]
  unfold ChoiceOperation.selectedCutoffHistorySum
  apply Finset.sum_congr rfl
  intro h _
  by_cases hw : h.weight=0
  · simp [hw]
  by_cases hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
      (emptyState (B:=B) u) h)
  · by_cases hf : ∀ i,(h.final.memory P Line J B i).size=0
    · have hc := keyCutoff_iff_peak_of_nonzero value ν V η q ρ geometry hshared hban T u h ⟨hd,hf⟩ hw
      rw [actualKey_final ν V η q ρ anchor geometry (emptyState (B:=B) u) h]
      by_cases ht : h.peakSize physicalMemorySize≤T
      · simp [Restricted,hd,hf,vacuumLift,ht,hc.mpr ht]
      · simp [Restricted,hd,hf,vacuumLift,ht,mt hc.mp ht]
    · simp [Restricted,hd,hf,vacuumLift]
  · simp [Restricted,hd]

end OriginalLeaf

/-- Large-state-space boundary pairing with the literal history peak cutoff. -/
def alternate_cutoffBoundaryPairing
    (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
    (anchor : Z→∀ i p,Line i p)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value : ∀ i,P i→ℕ) (N T : ℕ) (a b : BoundaryIndex I Z P J→ℂ) : ℂ :=
  ∑ u : BoundaryIndex I Z P J,
    (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ)*conj (a u)*
      ChoiceOperation.selectedCutoffHistorySum physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) (vacuumLift b) (emptyState (Line:=Line) (B:=B) u)
        (fun h=>if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
          (emptyState (B:=B) u) h) then 1 else 0)

namespace OriginalLeaf
variable (value : ∀ i,P i→ℕ)
variable (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

/-- The projected large-cap boundary is exactly the original leaf sum with
its small pending-memory condition. This retains every complex boundary factor. -/
theorem cutoffBoundaryPairing_eq_originalLeaves
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (T : ℕ) (a b : BoundaryIndex I Z P J→ℂ) :
    alternate_cutoffBoundaryPairing (B:=B) ν V η q ρ anchor geometry value N T a b =
      ∑ e : SourceLeaves anchor value J B N,
        if e.val.Valid anchor T then
          (PhysicalMemoryState.mass P Line J B ν
            (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) : ℂ)*
          conj (a (keyInitial (sourceKey value e)))*
          keyWeightSum ν V η q ρ anchor geometry value
            (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) (sourceKey value e)*
          b (keyFinal (sourceKey value e)) else 0 := by
  unfold alternate_cutoffBoundaryPairing
  simp_rw [selectedCutoff_vacuum_eq_key_weighted value ν V η q ρ geometry hshared hban T]
  simp_rw [sum_keys_eq_sourceLeaves value ν V η q ρ geometry hshared hban,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  simp only [keyCutoff_sourceKey]
  by_cases ht : e.val.Valid anchor T
  · simp only [ht,ite_true,mul_one]
    rw [Finset.sum_eq_single (keyInitial (sourceKey value e))]
    · ring
    · intro u _ hu
      have hk : ¬NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) (sourceKey value e) := by
        intro hh
        exact hu (nonzeroKey_initial ν V η q ρ anchor geometry value u _ hh).symm
      rw [keyWeightSum_zero ν V η q ρ anchor geometry value (emptyState (B:=B) u) _ hk]
      simp
    · simp
  · simp [ht]

/-- All projected original leaves carry the already proved explicit full
primewise coefficient, including when that coefficient vanishes. -/
theorem cutoffBoundaryPairing_eq_originalLeaf_coefficients
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (μ : ∀ i,P i→ℝ) (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hν : ∀ i p,V i*ν i p=μ i p)
    (T : ℕ) (a b : BoundaryIndex I Z P J→ℂ) :
    alternate_cutoffBoundaryPairing (B:=B) ν V η q ρ anchor geometry value N T a b =
      ∑ e : SourceLeaves anchor value J B N,
        if e.val.Valid anchor T then
          conj (a (keyInitial (sourceKey value e)))*
          primewiseCoefficient anchor geometry μ V η q (e.val.toSchedule anchor e.property.valid)*
          b (keyFinal (sourceKey value e)) else 0 := by
  rw [cutoffBoundaryPairing_eq_originalLeaves value ν V η q ρ geometry hshared hban T]
  apply Finset.sum_congr rfl
  intro e _
  by_cases ht : e.val.Valid anchor T
  · simp only [ht,ite_true]
    rw [← sourceLeaf_complete_coefficient value ν V η q ρ geometry hvalue μ hρ hV hν e]
    ring
  · simp [ht]

/-- Enlarging the numerical cap changes only the two proved cardinality
inequalities; all original path and prime-interval data are preserved. -/
theorem alternate_valid_mono {T : ℕ}
    (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (h : e.Valid anchor T) (hTB : T≤B) : e.Valid anchor B :=
  ⟨h.active_distinct,h.shared,h.unused,h.ordered,h.contains_active,h.singleton_active,
    h.incidence,fun j hj=>(h.before_cutoff j hj).trans hTB,
    fun j hj=>(h.after_cutoff j hj).trans hTB⟩

/-- Literal embedding of small-cap original leaves into large-cap leaves. -/
def liftCap {T : ℕ} (hTB : T≤B) (e : SourceLeaves anchor value J T N) :
    SourceLeaves anchor value J B N :=
  ⟨e.val,⟨alternate_valid_mono e.val e.property.valid hTB,e.property.crossEdgeBan⟩⟩

/-- No new histories, prime factors, normalizing constants or endpoint
permutations appear when a small-cap leaf is viewed at a larger cap. -/
theorem liftCap_coefficient {T : ℕ} (hTB : T≤B)
    (μ : ∀ i,P i→ℝ) (e : SourceLeaves anchor value J T N) :
    primewiseCoefficient anchor geometry μ V η q
      ((liftCap value hTB e).val.toSchedule anchor (liftCap value hTB e).property.valid) =
    primewiseCoefficient anchor geometry μ V η q (e.val.toSchedule anchor e.property.valid) := rfl

theorem liftCap_key {T : ℕ} (hTB : T≤B) (e : SourceLeaves anchor value J T N) :
    sourceKey value (liftCap value hTB e)=sourceKey value e := rfl

/-- Exact equality between the selected history cutoff in the large state
space and the actual boundary pairing built on the smaller state space.
The proof compares complete finite leaf fibers, not unrelated raw choices. -/
theorem cutoffBoundaryPairing_eq_smaller_cap
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (μ : ∀ i,P i→ℝ) (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hν : ∀ i p,V i*ν i p=μ i p)
    (T : ℕ) (hTB : T≤B) (a b : BoundaryIndex I Z P J→ℂ) :
    alternate_cutoffBoundaryPairing (B:=B) ν V η q ρ anchor geometry value N T a b =
      boundaryPairing (B:=T) ν V η q ρ anchor geometry value N a b := by
  rw [cutoffBoundaryPairing_eq_originalLeaf_coefficients value ν V η q ρ geometry
    hvalue hshared hban μ hρ hV hν T,
    boundaryPairing_eq_originalLeaf_coefficients value ν V η q ρ geometry
      hvalue hshared hban μ hρ hV hν]
  symm
  apply Finset.sum_bij_ne_zero (fun e _ _ => liftCap value hTB e)
  · intros; exact Finset.mem_univ _
  · intro e _ _ f _ _ he
    exact Subtype.ext (congrArg (fun f : SourceLeaves anchor value J B N=>f.val) he)
  · intro e _ he
    have ht : e.val.Valid anchor T := by
      by_contra hh
      simp only [hh,ite_false,ne_eq,not_true_eq_false] at he
    let f : SourceLeaves anchor value J T N := ⟨e.val,⟨ht,e.property.crossEdgeBan⟩⟩
    have hf : liftCap value hTB f=e := Subtype.ext rfl
    refine ⟨f,Finset.mem_univ _,?_,hf⟩
    rw [if_pos ht] at he
    exact he
  · intro e _ _
    have ht : (liftCap value hTB e).val.Valid anchor T := e.property.valid
    rw [if_pos ht,liftCap_key,liftCap_coefficient]

end OriginalLeaf
end Elliptic.Operator.OriginalLifespanSchedule
