module

public import Elliptic.Operator.OriginalIndependentCRT

/-!
# The numerical root-record residue test is the original grouped test

Global injectivity of the numerical prime labels is used to match every
active incidence, including visits in different bands. The original fresh
prime alphabet is preserved throughout the comparison.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalIndependentCRT
open scoped BigOperators
open OriginalLifespanSchedule IndependentLineNormalization RootRecordEncoding
attribute [local instance] Classical.propDecidable
local instance originalResidueDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {Z : Type} [Fintype Z]
variable {P : Fin K→Type} [∀i,Fintype (P i)]

/-- Numeric and grouped active visits agree, using the disjointness of the
actual prime bands rather than any fictitious disjoint numeric alphabet. -/
theorem activeVisits_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (r : OriginalPath (Fin K) Z P J N) (i : Fin K) (p : P i) :
    OriginalPathWeights.activeVisits (encode position value hvalue r) (value i p)=r.activeVisits i p := by
  ext t
  simp only [OriginalPathWeights.activeVisits,OriginalPath.activeVisits,Finset.mem_filter]
  apply and_congr_right
  intro ht
  have hv : OriginalPath.visit (N:=N) t=⟨t,Finset.mem_range.mp ht⟩ :=
    Fin.ext (Nat.min_eq_left (by have := Finset.mem_range.mp ht; omega))
  simp only [OriginalPath.activeAt,hv]
  constructor
  · rintro ⟨j,hj,i',k,hk⟩
    have hj' : j=⟨t,Finset.mem_range.mp ht⟩ := Fin.ext hj
    subst j
    have he := hinj (a₁:=⟨i',r.active ⟨t,Finset.mem_range.mp ht⟩ i' k⟩) (a₂:=⟨i,p⟩) (show value i' (r.active ⟨t,Finset.mem_range.mp ht⟩ i' k)=value i p from hk)
    have hi := congrArg Sigma.fst he
    dsimp only at hi
    subst i'
    have hp : r.active ⟨t,Finset.mem_range.mp ht⟩ i k=p := by simpa using he
    exact ⟨k,hp⟩
  · rintro ⟨k,hk⟩
    exact ⟨⟨t,Finset.mem_range.mp ht⟩,rfl,i,k,by simpa only [encode,encodeLists,hk]⟩

/-- The two visit conventions agree on every visit actually used. -/
theorem positionAt_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (r : OriginalPath (Fin K) Z P J N) (t : ℕ) (ht : t<N+1) :
    OriginalPathWeights.positionAt (encode position value hvalue r) t=(position (r.positionAt t)).val := by
  have hv : OriginalPath.visit (N:=N) t=⟨t,ht⟩ := Fin.ext (Nat.min_eq_left (by omega))
  simp only [OriginalPathWeights.positionAt,dif_pos ht,encode,OriginalPath.positionAt,hv]

/-- Line factors only read anchors at the actual finite visit set. -/
theorem lineFactor_congr_visits {Line : Type} [DecidableEq Line]
    (visits active : Finset ℕ) (hsub : active⊆visits) (line line' : ℕ→Line)
    (η : ℕ→ℝ) (ℓ : Line) (h : ∀j∈visits,line j=line' j) :
    lineFactor visits active line η ℓ=lineFactor visits active line' η ℓ := by
  unfold lineFactor
  congr 1
  · apply Finset.prod_congr rfl
    intro j hj
    rw [h j (hsub hj)]
  · apply Finset.prod_congr rfl
    intro j hj
    unfold Elliptic.PrimewiseMemory.hitWeight
    rw [h j (Finset.mem_sdiff.mp hj).1]

/-- The literal numerical residue factor on the complete prime pool is
exactly the grouped test used by the global independent-line identity. -/
theorem residueFactor_encode (position : Z→↥(integerPositionBox R))
    (value : ∀i,P i→ℕ) (hvalue : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (r : OriginalPath (Fin K) Z P J N) (η : ℕ→ℝ)
    (ℓ : (p : ℕ)→Option (ZMod p)) :
    (OriginalPathWeights.residueFactor (encode position value hvalue r)
      (Finset.univ.image (fun s : Sigma P=>value s.1 s.2)) η ℓ:ℂ) =
      coupledLineTest (fun z i p=>primeResidueAnchor (value i p) (position z).val) η r
        (fun s=>ℓ (value s.1 s.2)) := by
  unfold OriginalPathWeights.residueFactor coupledLineTest
  congr 1
  rw [Finset.prod_image (fun a _ b _ h=>hinj h)]
  apply Finset.prod_congr rfl
  intro s _
  rw [activeVisits_encode position value hvalue hinj]
  unfold lineFactor
  congr 1
  · apply Finset.prod_congr rfl
    intro t ht
    dsimp only
    simp only [positionAt_encode position value hvalue r t
      (Finset.mem_range.mp ((Finset.filter_subset _ _) ht))]
    split_ifs <;> rfl
  · apply Finset.prod_congr rfl
    intro t ht
    unfold Elliptic.PrimewiseMemory.hitWeight
    dsimp only
    simp only [positionAt_encode position value hvalue r t
      (Finset.mem_range.mp (Finset.mem_sdiff.mp ht).1)]
    split_ifs <;> rfl

/-- The actual band labels biject with their finite numerical prime pool. -/
def primePoolEquiv (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2)) :
    Sigma P ≃ ↥(Finset.univ.image (fun s : Sigma P=>value s.1 s.2)) :=
  Equiv.ofBijective (fun s=>⟨value s.1 s.2,Finset.mem_image.mpr ⟨s,Finset.mem_univ _,rfl⟩⟩)
    ⟨fun a b h=>hinj (congrArg Subtype.val h), by
      rintro ⟨p,hp⟩
      obtain ⟨s,hs,he⟩ := Finset.mem_image.mp hp
      exact ⟨s,Subtype.ext he⟩⟩

@[simp] theorem primePoolEquiv_val (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2)) (s : Sigma P) :
    (primePoolEquiv value hinj s).val=value s.1 s.2 := rfl

end Elliptic.Operator.OriginalIndependentCRT
