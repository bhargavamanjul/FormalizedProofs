module

public import Elliptic.Operator.PhysicalDirtyMasks
public import Elliptic.Operator.FiniteOperatorSum

/-! Exact geometric linearity of the literal physical bag matrices and a
finite measured norm bound for a difference of two actual operators. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

 theorem finiteL2_neg {ι : Type*} (s : Finset ι) (μ : ι→ℝ) (f : ι→ℂ) :
    finiteL2 s μ (fun i=>-f i)=finiteL2 s μ f := by
  simp only [finiteL2,finiteL2Sq,norm_neg]

 theorem finiteL2_sub_le_of_le {ι : Type*} (s : Finset ι) (μ : ι→ℝ)
    (hμ : ∀i∈s,0≤μ i) (f g : ι→ℂ) (R C N : ℝ)
    (hR : 0≤R) (hC : 0≤C) (hN : 0≤N)
    (hf : finiteL2 s μ f≤R*N) (hg : finiteL2 s μ g≤C*N) :
    finiteL2 s μ (fun i=>f i-g i)≤Real.sqrt (2*(R^2+C^2))*N := by
  let fs : Bool→ι→ℂ := fun b i=>if b then f i else -g i
  let cs : Bool→ℝ := fun b=>if b then R else C
  have hcs : ∀b∈(Finset.univ : Finset Bool),0≤cs b := by intro b _;cases b <;> assumption
  have hfs : ∀b∈(Finset.univ : Finset Bool),finiteL2 s μ (fs b)≤cs b*N := by
    intro b _
    cases b
    · simpa only [fs,cs,Bool.false_eq_true,ite_false,finiteL2_neg] using hg
    · exact hf
  have hh := finiteL2_sum_le s Finset.univ μ hμ fs cs N hN hcs hfs
  simpa only [fs,cs,Fintype.sum_bool,Bool.false_eq_true,ite_false,ite_true,
    Finset.card_univ,Fintype.card_bool,Nat.cast_ofNat,←sub_eq_add_neg,add_comm] using hh

namespace PhysicalKernelLinearity
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalDirtyMasks
variable {G Z : Type*} [Fintype G] [Fintype Z] {P : G→Type*} [∀i,Fintype (P i)]
variable {Line : ∀i,P i→Type*} [∀i p,Fintype (Line i p)] {J B : ℕ}

 theorem originalKernel_sub (ν : ∀i,P i→ℝ) (V : G→ℝ) (S I : G→Bool) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (f g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    originalKernel ν V S I ρ anchor (fun z a w b=>f z a w b-g z a w b) s t=
      originalKernel ν V S I ρ anchor f s t-originalKernel ν V S I ρ anchor g s t := by
  have hh π τ : term (fun i p=>(ν i p:ℂ)) (fun _=>1) (fun i=>(V i:ℂ)⁻¹) S I (ρ:ℂ)
      anchor (fun z a w b=>f z a w b-g z a w b) s t π τ=
    term (fun i p=>(ν i p:ℂ)) (fun _=>1) (fun i=>(V i:ℂ)⁻¹) S I (ρ:ℂ) anchor f s t π τ-
    term (fun i p=>(ν i p:ℂ)) (fun _=>1) (fun i=>(V i:ℂ)⁻¹) S I (ρ:ℂ) anchor g s t π τ := by
    unfold term
    split_ifs <;> ring
  unfold originalKernel kernel
  split_ifs
  · simp only [hh,Finset.sum_sub_distrib,mul_sub]
  · simp only [sub_self]

 theorem dirtyKernel_sub (ν : ∀i,P i→ℝ) (V : G→ℝ) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (f g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    dirtyKernel ν V ρ anchor (fun z a w b=>f z a w b-g z a w b) s t=
      dirtyKernel ν V ρ anchor f s t-dirtyKernel ν V ρ anchor g s t := by
  simp only [dirtyKernel,originalKernel_sub,Finset.sum_sub_distrib]

end PhysicalKernelLinearity
end Elliptic.Operator
