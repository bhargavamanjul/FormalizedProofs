module

public import Elliptic.Operator.DirichletSampling

/-!
# Elementary logarithmic-phase cancellation on actual progressions

The low-frequency sum--integral estimate is proved from the derivative
of exp(i t log x), a literal primitive, and a unit-cell comparison.
The progression is a+q k, so its first residue need not be a unit.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.LogPhaseProgression
open scoped BigOperators
open MeasureTheory Set
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- The logarithmic phase at a positive real argument. -/
def phase (t x : ℝ) : ℂ := Complex.exp (Complex.I*((t*Real.log x:ℝ):ℂ))

theorem phase_norm (t x : ℝ) : ‖phase t x‖=1 := by
  exact Complex.norm_exp_I_mul_ofReal _

theorem phase_nat (t : ℝ) (n : ℕ) : phase t n=Artin.MarkedReplacement.archimedeanPhase t n := rfl

theorem phase_hasDerivAt (t x : ℝ) (hx : x≠0) :
    HasDerivAt (phase t) (phase t x*(Complex.I*((t/x:ℝ):ℂ))) x := by
  have h := (((Real.hasDerivAt_log hx).const_mul t).ofReal_comp.const_mul Complex.I).cexp
  unfold phase
  convert h using 1 <;> simp only [div_eq_mul_inv]

theorem phase_derivative_norm (t x : ℝ) (hx : 0<x) :
    ‖phase t x*(Complex.I*((t/x:ℝ):ℂ))‖=|t|/x := by
  rw [norm_mul,phase_norm,one_mul,norm_mul,Complex.norm_I,one_mul,
    Complex.norm_real,Real.norm_eq_abs,abs_div,abs_of_pos hx]

/-- The elementary primitive has denominator 1+i t. -/
def primitive (t x : ℝ) : ℂ :=
  (x:ℂ)*phase t x/(1+Complex.I*(t:ℂ))

theorem primitive_den_ne_zero (t : ℝ) : (1+Complex.I*(t:ℂ):ℂ)≠0 := by
  intro h
  have he := congrArg Complex.re h
  simpa using he

theorem primitive_hasDerivAt (t x : ℝ) (hx : x≠0) :
    HasDerivAt (primitive t) (phase t x) x := by
  have h := ((hasDerivAt_id x).ofReal_comp.mul (phase_hasDerivAt t x hx)).div_const
    (1+Complex.I*(t:ℂ))
  convert h using 1
  · rfl
  · simp only [id_eq,Complex.ofReal_one,one_mul,Complex.ofReal_div]
    have hxC : (x:ℂ)≠0 := by exact_mod_cast hx
    field_simp [primitive_den_ne_zero t]

/-- The literal real-interval logarithmic integral is bounded by its endpoints. -/
theorem phase_integral_norm_le (t a b : ℝ) (ha : 0<a) (hab : a≤b) (ht : t≠0) :
    ‖∫x in a..b,phase t x‖≤(a+b)/|t| := by
  have hcont : ContinuousOn (phase t) (Icc a b) := by
    intro x hx
    exact (phase_hasDerivAt t x (ne_of_gt (ha.trans_le hx.1))).continuousAt.continuousWithinAt
  have hint : IntervalIntegrable (phase t) volume a b := hcont.intervalIntegrable_of_Icc hab
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun x hx=>primitive_hasDerivAt t x (ne_of_gt (ha.trans_le ((uIcc_of_le hab ▸ hx).1)))) hint
  rw [hFTC,primitive,primitive,←sub_div,norm_div]
  have hden : |t|≤‖(1+Complex.I*(t:ℂ):ℂ)‖ := by
    simpa using Complex.abs_im_le_norm (1+Complex.I*(t:ℂ))
  have hnum : ‖(b:ℂ)*phase t b-(a:ℂ)*phase t a‖≤a+b := by
    calc
      _ ≤ ‖(b:ℂ)*phase t b‖+‖(a:ℂ)*phase t a‖ := norm_sub_le _ _
      _ = a+b := by
        rw [norm_mul,norm_mul,phase_norm,phase_norm,mul_one,mul_one,
          Complex.norm_real,Complex.norm_real,Real.norm_eq_abs,Real.norm_eq_abs,
          abs_of_pos (ha.trans_le hab),abs_of_pos ha]
        ring
  exact (div_le_div_of_nonneg_right hnum (norm_nonneg _)).trans
    (div_le_div_of_nonneg_left (by linarith) (abs_pos.mpr ht) hden)

/-- A literal left-endpoint sum differs from its integral by at most M times
an upper bound for the derivative. -/
theorem sum_integral_comparison (M : ℕ) (F F' : ℝ→ℂ) (C : ℝ) (hC : 0≤C)
    (hd : ∀x∈Icc (0:ℝ) M,HasDerivAt F (F' x) x)
    (hbound : ∀x∈Icc (0:ℝ) M,‖F' x‖≤C) :
    ‖(∑k∈Finset.range M,F k)-(∫x in (0:ℝ)..M,F x)‖≤(M:ℝ)*C := by
  have hsub (k : ℕ) (hk : k<M) : Icc (k:ℝ) (k+1)⊆Icc (0:ℝ) M := by
    intro x hx
    have hkR : (k:ℝ)+1≤M := by exact_mod_cast hk
    exact ⟨(Nat.cast_nonneg k).trans hx.1,hx.2.trans hkR⟩
  have hint (k : ℕ) (hk : k<M) : IntervalIntegrable F volume (k:ℝ) (k+1) := by
    have hc : ContinuousOn F (Icc (k:ℝ) (k+1)) :=
      fun x hx=>(hd x (hsub k hk hx)).continuousAt.continuousWithinAt
    exact hc.intervalIntegrable_of_Icc (by linarith)
  have hcell (k : ℕ) (hk : k<M) :
      ‖F k-(∫x in (k:ℝ)..k+1,F x)‖≤C := by
    have he : F k-(∫x in (k:ℝ)..k+1,F x)=(∫x in (k:ℝ)..k+1,F k-F x) := by
      rw [intervalIntegral.integral_sub intervalIntegrable_const (hint k hk),intervalIntegral.integral_const]
      simp
    rw [he]
    have hh := intervalIntegral.norm_integral_le_of_norm_le_const (C:=C) (f:=fun x=>F k-F x)
      (a:=(k:ℝ)) (b:=(k:ℝ)+1) (by
        intro x hx
        have hx' : x∈Icc (k:ℝ) (k+1) := Ioc_subset_Icc_self (by simpa [uIoc_of_le (show (k:ℝ)≤k+1 by linarith)] using hx)
        have hm := Convex.norm_image_sub_le_of_norm_hasDerivWithin_le
          (fun y hy=>(hd y (hsub k hk hy)).hasDerivWithinAt)
          (fun y hy=>hbound y (hsub k hk hy)) (convex_Icc (k:ℝ) ((k:ℝ)+1))
          (show (k:ℝ)∈Icc (k:ℝ) (k+1) from ⟨le_refl _,by linarith⟩) hx'
        rw [norm_sub_rev] at hm
        apply hm.trans
        apply mul_le_of_le_one_right hC
        rw [Real.norm_eq_abs,abs_of_nonneg (sub_nonneg.mpr hx'.1)]
        linarith [hx'.2])
    simpa using hh
  have he := intervalIntegral.sum_integral_adjacent_intervals (a:=fun k:ℕ=>(k:ℝ))
    (n:=M) (f:=F) (μ:=volume) (by intro k hk; simpa using hint k hk)
  simp only [Nat.cast_zero,Nat.cast_add,Nat.cast_one] at he
  rw [←he,←Finset.sum_sub_distrib]
  calc
    _ ≤ ∑k∈Finset.range M,‖F k-(∫x in (k:ℝ)..k+1,F x)‖ := norm_sum_le _ _
    _ ≤ ∑_k∈Finset.range M,C := Finset.sum_le_sum fun k hk=>hcell k (Finset.mem_range.mp hk)
    _ = _ := by simp

/-- Derivative of the phase on an arbitrary real progression. -/
theorem progression_hasDerivAt (t a q x : ℝ) (hx : a+q*x≠0) :
    HasDerivAt (fun y=>phase t (a+q*y))
      (q*(phase t (a+q*x)*(Complex.I*((t/(a+q*x):ℝ):ℂ)))) x := by
  have hi : HasDerivAt (fun y:ℝ=>a+q*y) q x := by
    simpa only [id_eq,mul_one] using ((hasDerivAt_id x).const_mul q |>.const_add a)
  have h := ((((Real.hasDerivAt_log hx).comp x hi).const_mul t).ofReal_comp.const_mul Complex.I).cexp
  unfold phase
  convert h using 1 <;> simp only [Function.comp_apply,id_eq,mul_one,smul_eq_mul,Complex.ofReal_mul,Complex.ofReal_inv,Complex.ofReal_div,div_eq_mul_inv] <;> ring

/-- The concrete low-frequency progression estimate, valid also for nonunit
residues. It has the source shape length/|t| + |t| with explicit constants. -/
theorem progression_sum_norm_le (M : ℕ) (a q t : ℝ) (ha : 0<a) (hq : 0<q)
    (hdyad : q*M≤a) (ht : t≠0) :
    ‖∑k∈Finset.range M,phase t (a+q*k)‖≤3*a/(q*|t|)+|t| := by
  let F : ℝ→ℂ := fun x=>phase t (a+q*x)
  let F' : ℝ→ℂ := fun x=>q*(phase t (a+q*x)*(Complex.I*((t/(a+q*x):ℝ):ℂ)))
  have hxpos (x : ℝ) (hx : x∈Icc (0:ℝ) M) : 0<a+q*x := by nlinarith [hx.1]
  have hbd (x : ℝ) (hx : x∈Icc (0:ℝ) M) : ‖F' x‖≤q*|t|/a := by
    dsimp [F']
    rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hq,
      phase_derivative_norm t _ (hxpos x hx)]
    calc
      _ ≤ q*(|t|/a) := mul_le_mul_of_nonneg_left
        (div_le_div_of_nonneg_left (abs_nonneg _) ha (by nlinarith [hx.1])) hq.le
      _ = _ := by ring
  have he := sum_integral_comparison M F F' (q*|t|/a) (by positivity)
    (fun x hx=>progression_hasDerivAt t a q x (hxpos x hx).ne') hbd
  have he' : ‖(∑k∈Finset.range M,F k)-(∫x in (0:ℝ)..M,F x)‖≤|t| := by
    apply he.trans
    rw [←mul_div_assoc]
    apply (div_le_iff₀ ha).mpr
    nlinarith [mul_le_mul_of_nonneg_right hdyad (abs_nonneg t)]
  have hi : ‖∫x in (0:ℝ)..M,F x‖≤3*a/(q*|t|) := by
    dsimp [F]
    rw [intervalIntegral.integral_comp_add_mul (phase t) hq.ne',norm_smul,
      Real.norm_eq_abs,abs_inv,abs_of_pos hq]
    simp only [mul_zero,add_zero]
    calc
      _ ≤ q⁻¹*((a+(a+q*M))/|t|) :=
        mul_le_mul_of_nonneg_left
          (phase_integral_norm_le t a (a+q*M) ha (by nlinarith [Nat.cast_nonneg (α:=ℝ) M]) ht) (by positivity)
      _ ≤ 3*a/(q*|t|) := by
        have ht0 := abs_pos.mpr ht
        apply (le_div_iff₀ (mul_pos hq ht0)).mpr
        field_simp
        nlinarith
  calc
    _ ≤ ‖(∑k∈Finset.range M,F k)-(∫x in (0:ℝ)..M,F x)‖+‖∫x in (0:ℝ)..M,F x‖ := by
      have hh := norm_le_insert' (∑k∈Finset.range M,F k) (∫x in (0:ℝ)..M,F x)
      simpa only [add_comm] using hh
    _ ≤ |t|+3*a/(q*|t|) := add_le_add he' hi
    _ = _ := add_comm _ _

end Elliptic.Operator.LogPhaseProgression
