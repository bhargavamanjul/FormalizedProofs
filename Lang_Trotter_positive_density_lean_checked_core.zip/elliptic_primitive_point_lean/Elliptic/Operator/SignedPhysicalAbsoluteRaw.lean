module
public import Elliptic.Operator.SignedPhysicalAbsoluteMajor
public import Elliptic.Operator.SignedPhysicalCofactorCount

/-! Absolute raw scalar sums from the proved unit-shift divisor estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteRaw
open scoped BigOperators ComplexConjugate
open SignedPhysicalPairBridge SignedPhysicalAbsoluteMajor SignedDivisorProgression Filter
attribute [local instance 10000] Classical.propDecidable
local instance rawTermDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 150000

def scalarRaw (a b m n r q : ℕ) (Y : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  if scalarDet a b m n r q=(a:ℤ)-b then
    η ((a:ℝ)/Y)*η ((b:ℝ)/Y)*α m*β n*conj (α r)*conj (β q)*
      ψ ((scalarDet a b m n r q:ℝ)/Y) else 0

theorem scalarError_eq_raw_sub_major (a b m n r q : ℕ) (Y H : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    scalarError a b m n r q Y H η ψ α β=
      scalarRaw a b m n r q Y η ψ α β-scalarMajor a b m n r q Y H η ψ α β := by
  unfold scalarError scalarRaw scalarMajor
  split_ifs <;> ring

theorem raw_coefficient_norm_le (a b m n r q : ℕ) (Y : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hm : ‖α m‖≤A) (hr : ‖α r‖≤A) (hn : ‖β n‖≤B) (hq : ‖β q‖≤B) :
    ‖η ((a:ℝ)/Y)*η ((b:ℝ)/Y)*α m*β n*conj (α r)*conj (β q)*
      ψ ((scalarDet a b m n r q:ℝ)/Y)‖≤Aη^2*A^2*B^2*Aψ := by
  simp only [norm_mul,Complex.norm_conj]
  calc
    _ ≤ Aη*Aη*A*B*A*B*Aψ := by gcongr <;> first | exact hη _ | exact hψ _ | assumption
    _ = _ := by ring

theorem determinant_common_cofactor (s t : Finset ℕ) (a b m n r q : ℕ) (x Y : ℝ)
    (hY : 0<Y) (ha : Y≤a) (hb : Y≤b) (hab : a.Coprime b)
    (hprod : ∀m∈s,∀n∈t,(m*n+1:ℕ)≤x)
    (hm : m∈s) (hn : n∈t)
    (hdet : scalarDet a b m n r q=(a:ℤ)-b) :
    ∃h∈Finset.Icc 1 ⌊x/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h := by
  have hap : 0<a := by exact_mod_cast hY.trans_le ha
  have hbp : 0<b := by exact_mod_cast hY.trans_le hb
  obtain ⟨h,hh,he,hf⟩ := (SignedDeterminantReduction.successor_determinant_iff a b m n r q hap hbp hab).mpr hdet
  refine ⟨h,Finset.mem_Icc.mpr ⟨hh,?_⟩,he,hf⟩
  apply Nat.le_floor
  apply (le_div_iff₀ hY).mpr
  have hp := hprod m hm n hn
  have he' : (a:ℝ)*h=(m*n+1:ℕ) := by exact_mod_cast he.symm
  nlinarith [mul_le_mul_of_nonneg_right ha (Nat.cast_nonneg h : (0:ℝ)≤h)]

theorem scalarRaw_norm_le_common (s t : Finset ℕ) (a b m n r q : ℕ) (x Y : ℝ)
    (hY : 0<Y) (ha : Y≤a) (hb : Y≤b) (hab : a.Coprime b)
    (hprod : ∀m∈s,∀n∈t,(m*n+1:ℕ)≤x) (hm : m∈s) (hn : n∈t)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hαm : ‖α m‖≤A) (hαr : ‖α r‖≤A) (hβn : ‖β n‖≤B) (hβq : ‖β q‖≤B) :
    ‖scalarRaw a b m n r q Y η ψ α β‖≤(Aη^2*A^2*B^2*Aψ)*
      (if ∃h∈Finset.Icc 1 ⌊x/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0) := by
  by_cases hd : scalarDet a b m n r q=(a:ℤ)-b
  · have hc := determinant_common_cofactor s t a b m n r q x Y hY ha hb hab hprod hm hn hd
    rw [if_pos hc,mul_one]
    rw [scalarRaw,if_pos hd]
    exact raw_coefficient_norm_le a b m n r q Y η ψ α β Aη Aψ A B hAη hAψ hA hB
      hη hψ hαm hαr hβn hβq
  · rw [scalarRaw,if_neg hd,norm_zero]
    positivity

theorem sum_four_le_mul (s t : Finset ℕ) (F G : ℕ→ℕ→ℕ→ℕ→ℝ) (M : ℝ)
    (h : ∀m∈s,∀n∈t,∀r∈s,∀q∈t,F m n r q≤M*G m n r q) :
    (∑m∈s,∑n∈t,∑r∈s,∑q∈t,F m n r q)≤
      M*(∑m∈s,∑n∈t,∑r∈s,∑q∈t,G m n r q) := by
  calc
    _ ≤ ∑m∈s,∑n∈t,∑r∈s,∑q∈t,M*G m n r q :=
      Finset.sum_le_sum (fun m hm=>Finset.sum_le_sum (fun n hn=>
        Finset.sum_le_sum (fun r hr=>Finset.sum_le_sum (fun q hq=>h m hm n hn r hr q hq))))
    _ = _ := by simp only [Finset.mul_sum]

/-- Absolute raw determinant contribution for one coprime pair of literal
selected labels. The only finite arithmetic quantities remaining are the
two actual cofactor divisor-square sums. -/
theorem scalarRaw_sum_le_cofactors (s t : Finset ℕ) (a b : ℕ) (x Y : ℝ)
    (hY : 0<Y) (ha : Y≤a) (hb : Y≤b) (hab : a.Coprime b)
    (hs : ∀m∈s,0<m) (hpos : ∀m∈s,∀n∈t,0<m*n)
    (hprod : ∀m∈s,∀n∈t,(m*n+1:ℕ)≤x)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hα : ∀m∈s,‖α m‖≤A) (hβ : ∀n∈t,‖β n‖≤B) :
    (∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarRaw a b m n r q Y η ψ α β‖)≤
      (Aη^2*A^2*B^2*Aψ)*
        (((∑h∈Finset.Icc 1 ⌊x/Y⌋₊,((a*h-1).divisors.card:ℝ)^2)+
          (∑h∈Finset.Icc 1 ⌊x/Y⌋₊,((b*h-1).divisors.card:ℝ)^2))/2) := by
  have hh := sum_four_le_mul s t
    (fun m n r q=>‖scalarRaw a b m n r q Y η ψ α β‖)
    (fun m n r q=>if ∃h∈Finset.Icc 1 ⌊x/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)
    (Aη^2*A^2*B^2*Aψ)
    (fun m hm n hn r hr q hq=>scalarRaw_norm_le_common s t a b m n r q x Y hY ha hb hab hprod hm hn
      η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ (hα m hm) (hα r hr) (hβ n hn) (hβ q hq))
  exact hh.trans (mul_le_mul_of_nonneg_left (common_cofactor_count_le s t a b ⌊x/Y⌋₊ hs hpos) (by positivity))

/-- Uniform absolute raw bound for a fixed coprime pair of selected
labels, with the progression estimate fully proved. -/
theorem eventually_scalarRaw_sum_le (D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀(s t : Finset ℕ) (a b : ℕ) (Y : ℝ),
      (∀m∈s,0<m) → (∀m∈s,∀n∈t,0<m*n) →
      (∀m∈s,∀n∈t,(m*n+1:ℕ)≤x) →
      0<Y → Y≤a → (a:ℝ)≤4*Y → Y≤b → (b:ℝ)≤4*Y → a.Coprime b →
      (a:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (b:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      ∀(η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ),
      0≤Aη → 0≤Aψ → 0≤A → 0≤B →
      (∀v,‖η v‖≤Aη) → (∀v,‖ψ v‖≤Aψ) →
      (∀m∈s,‖α m‖≤A) → (∀n∈t,‖β n‖≤B) →
      (∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖scalarRaw a b m n r q Y η ψ α β‖)≤
        (Aη^2*A^2*B^2*Aψ)*(32*(x/Y)*(1+Real.log (8*x))^3) := by
  filter_upwards [eventually_predecessor_band D hD] with x hx
  intro s t a b Y hs hpos hprod hY ha ha' hb hb' hab hau hbu η ψ α β Aη Aψ A B
    hAη hAψ hA hB hη hψ hα hβ
  have hap : 1≤a := by exact_mod_cast hY.trans_le ha
  have hbp : 1≤b := by exact_mod_cast hY.trans_le hb
  have h₁ := hx a Y hap hY ha ha' hau
  have h₂ := hx b Y hbp hY hb hb' hbu
  apply (scalarRaw_sum_le_cofactors s t a b x Y hY ha hb hab hs hpos hprod
    η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hα hβ).trans
  exact mul_le_mul_of_nonneg_left (by linarith) (by positivity)

end Elliptic.Operator.SignedPhysicalAbsoluteRaw
