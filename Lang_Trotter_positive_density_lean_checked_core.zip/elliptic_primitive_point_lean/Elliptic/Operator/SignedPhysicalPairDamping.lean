module
public import Elliptic.Operator.SignedPhysicalPairBridge
public import Elliptic.Operator.PhysicalVertexDamping

/-! Artificial inactive-prime damping is identically one on the actual
rough endpoints. This is independent of the chosen damping parameter. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open PhysicalVertexDamping
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J : ℕ} {P : Fin K→Type} [∀ i,Fintype (P i)]

/-- A designated prime dividing an active-product times a rough number
is exactly one of the active labels. -/
theorem active_mul_prime_dvd_iff (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (a : PhysicalActiveLists P J)
    (m p : ℕ) (hp : p.Prime) (hm : ¬p∣m) :
    p∣activeProduct value a*m ↔ ∃ i k,value i (a i k)=p := by
  constructor
  · intro hd
    have hh := (hp.dvd_mul.mp hd).resolve_right hm
    unfold activeProduct at hh
    obtain ⟨i,_,hi⟩ := (hp.prime.dvd_finsetProd_iff (fun i=>∏j,value i (a i j))).mp hh
    obtain ⟨j,_,hj⟩ := (hp.prime.dvd_finsetProd_iff (fun j=>value i (a i j))).mp hi
    exact ⟨i,j,((Nat.prime_dvd_prime_iff_eq hp (hprime i _)).mp hj).symm⟩
  · rintro ⟨i,k,rfl⟩
    exact dvd_mul_of_dvd_left (label_dvd_activeProduct value a i k) m

/-- Complete active support makes each physical vertex factor one,
including all inactive factors and all active divisibility tests. -/
theorem vertexWeight_position_eq_one (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (primes : Finset ℕ)
    (hpool : ∀p∈primes,p.Prime) (a : PhysicalActiveLists P J)
    (m s : ℕ) (hm : ∀ p∈primes,¬p∣m) (q : ℝ) :
    vertexWeight value primes q
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s) a=1 := by
  apply Finset.prod_eq_one
  intro p hp
  have hd : ((p:ℤ)∣(position (sourcePadProduct value a)
      (sourceUnsharedProduct value a) m s).1) ↔ ∃ i k,value i (a i k)=p := by
    change ((p:ℤ)∣(sourcePadProduct value a*sourceUnsharedProduct value a*m:ℕ)) ↔ _
    rw [Int.natCast_dvd_natCast,←activeProduct_eq]
    exact active_mul_prime_dvd_iff value hprime a m p (hpool p hp) (hm p hp)
  by_cases ha : ∃ i k,value i (a i k)=p
  · simp only [vertexFactor,if_pos ha,if_pos (hd.mpr ha)]
  · simp only [vertexFactor,if_neg ha,if_neg (fun hh=>ha (hd.mp hh)),sub_zero]

/-- The entire artificial vertex damping disappears at both literal
coefficient endpoints, for every value of its parameter. -/
theorem dampedGeometry_position (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (primes : Finset ℕ)
    (hpool : ∀p∈primes,p.Prime) (a b : PhysicalActiveLists P J)
    (hcopy : ∀ i (j : Fin J),b i j.castSucc=a i j.castSucc)
    (m n r s : ℕ) (hm : ∀ p∈primes,¬p∣m) (hr : ∀ p∈primes,¬p∣r) (q : ℝ)
    (g : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ) :
    dampedGeometry value primes q g
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s) a
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n) b =
    g (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s) a
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n) b := by
  have ht := vertexWeight_position_eq_one value hprime primes hpool b r n hr q
  rw [sourcePadProduct_eq_of_copied value a b hcopy] at ht
  simp only [dampedGeometry,vertexWeight_position_eq_one value hprime primes hpool a m s hm q,
    ht,Complex.ofReal_one,one_mul,mul_one]

end Elliptic.Operator.SignedPhysicalPairBridge
