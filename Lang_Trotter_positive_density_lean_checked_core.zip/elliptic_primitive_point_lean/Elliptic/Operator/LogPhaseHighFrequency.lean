module

public import Elliptic.Operator.LogPhaseDerivativeTest
public import Elliptic.Operator.SparseFrequencyEnergy

/-!
# Fixed-order cancellation on the actual logarithmic Gram sum

The only extra input is the separately identified ordinary fixed-order
van der Corput estimate. The frequency bands, their finite covering, and
the resulting Gram-energy bounds are proved here.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.LogPhaseHighFrequency
open scoped BigOperators
open ClassicalDerivativeTest LogPhaseDerivativeTest LogPhaseProgression SparseFrequencyEnergy
set_option backward.isDefEq.respectTransparency false

/-- Numerical inequality making every order at least three save a power. -/
theorem secondary_exponent_le (k : ℕ) (hk : 3≤k) :
    secondaryExponent k+2*exponent k≤1-exponent k := by
  have hpow : (8:ℝ)≤2^k := by
    have h := pow_le_pow_right₀ (by norm_num : (1:ℝ)≤2) hk
    norm_num at h
    exact h
  have hd : 0<(2:ℝ)^k-2 := by linarith
  unfold secondaryExponent exponent
  have hh : 3/((2:ℝ)^k-2)≤4/(2:ℝ)^k := by
    apply (div_le_div_iff₀ hd (by positivity)).mpr
    nlinarith
  simp only [div_eq_mul_inv] at hh ⊢
  linarith

/-- Both terms of the derivative test have the same saving throughout one
power band. The positive constants A and B are independent of length. -/
theorem derivative_terms_band (k : ℕ) (hk : 3≤k) (N lam A B : ℝ)
    (hN : 1≤N) (hA : 0<A) (hB : 0<B)
    (hlow : A*N^(-2:ℝ)≤lam) (hhigh : lam≤B*N^(-1:ℝ)) :
    N*lam^(exponent k)+N^(secondaryExponent k)*lam^(-exponent k)≤
      (B^(exponent k)+A^(-exponent k))*N^(1-exponent k) := by
  have hN0 : 0<N := by linarith
  have he := exponent_pos k (by omega)
  have hlam : 0<lam := (mul_pos hA (Real.rpow_pos_of_pos hN0 _)).trans_le hlow
  have hu := Real.rpow_le_rpow hlam.le hhigh he.le
  rw [Real.mul_rpow hB.le (Real.rpow_nonneg hN0.le _),←Real.rpow_mul hN0.le] at hu
  have hl := Real.rpow_le_rpow_of_nonpos (mul_pos hA (Real.rpow_pos_of_pos hN0 _)) hlow (neg_nonpos.mpr he.le)
  rw [Real.mul_rpow hA.le (Real.rpow_nonneg hN0.le _),←Real.rpow_mul hN0.le] at hl
  have hfirst : N*lam^(exponent k)≤B^(exponent k)*N^(1-exponent k) := by
    calc
      _ ≤ N*(B^(exponent k)*N^((-1:ℝ)*exponent k)) := mul_le_mul_of_nonneg_left hu hN0.le
      _ = _ := by rw [sub_eq_add_neg,Real.rpow_add hN0,Real.rpow_one]; ring
  have hsecond : N^(secondaryExponent k)*lam^(-exponent k)≤A^(-exponent k)*N^(1-exponent k) := by
    calc
      _ ≤ N^(secondaryExponent k)*(A^(-exponent k)*N^((-2:ℝ)*(-exponent k))) :=
        mul_le_mul_of_nonneg_left hl (Real.rpow_nonneg hN0.le _)
      _ = A^(-exponent k)*N^(secondaryExponent k+2*exponent k) := by
        rw [Real.rpow_add hN0,show (-2:ℝ)*(-exponent k)=2*exponent k by ring]; ring
      _ ≤ _ := mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow_of_exponent_le hN (secondary_exponent_le k hk)) (Real.rpow_nonneg hA.le _)
  nlinarith

def derivativeConstant (k : ℕ) : ℝ := ((k-1).factorial:ℝ)/(2*Real.pi*(2:ℝ)^k)

theorem derivativeConstant_pos (k : ℕ) : 0<derivativeConstant k := by
  unfold derivativeConstant
  have hf : (0:ℝ)<(k-1).factorial := by exact_mod_cast Nat.factorial_pos (k-1)
  positivity

theorem lowerDerivative_dyadic (k : ℕ) (N t : ℝ) (hN : 0<N) :
    lowerDerivative k N 1 t=derivativeConstant k*(|t| /N^k) := by
  unfold lowerDerivative derivativeConstant
  rw [one_pow,mul_one,mul_pow]
  field_simp

theorem dyadic_derivative_band (k : ℕ) (hk : 2≤k) (N t : ℝ) (hN : 0<N)
    (htlow : N^(k-2)≤ |t|) (hthigh : |t|≤N^(k-1)) :
    derivativeConstant k*N^(-2:ℝ)≤lowerDerivative k N 1 t ∧
      lowerDerivative k N 1 t≤derivativeConstant k*N^(-1:ℝ) := by
  rw [lowerDerivative_dyadic k N t hN]
  have hlow := div_le_div_of_nonneg_right htlow (pow_nonneg hN.le k)
  have hhigh := div_le_div_of_nonneg_right hthigh (pow_nonneg hN.le k)
  have he2 : ((k-2:ℕ):ℝ)-(k:ℝ)=(-2:ℝ) := by rw [Nat.cast_sub hk]; norm_num
  have he1 : ((k-1:ℕ):ℝ)-(k:ℝ)=(-1:ℝ) := by rw [Nat.cast_sub (by omega : 1≤k)]; norm_num
  rw [←Real.rpow_natCast N (k-2),←Real.rpow_natCast N k,←Real.rpow_sub hN,he2] at hlow
  rw [←Real.rpow_natCast N (k-1),←Real.rpow_natCast N k,←Real.rpow_sub hN,he1] at hhigh
  simp only [Real.rpow_natCast] at hlow hhigh
  exact ⟨mul_le_mul_of_nonneg_left hlow (derivativeConstant_pos k).le,
    mul_le_mul_of_nonneg_left hhigh (derivativeConstant_pos k).le⟩

/-- Actual Gram cancellation on one growing-frequency band. -/
theorem gram_band_bound (hvdC : FixedOrderDerivativeTest) (k : ℕ) (hk : 3≤k) :
    ∃C:ℝ,0<C∧∀N:ℕ,1≤N→∀t:ℝ,(N:ℝ)^(k-2)≤ |t|→|t|≤(N:ℝ)^(k-1)→
      ‖gram N t‖≤C*(N:ℝ)^(1-exponent k) := by
  obtain ⟨C,hC,hbound⟩ := progression_derivative_bound hvdC k (by omega)
  let D := (derivativeConstant k)^(exponent k)+(derivativeConstant k)^(-exponent k)
  have hD : 0<D := add_pos (Real.rpow_pos_of_pos (derivativeConstant_pos k) _)
    (Real.rpow_pos_of_pos (derivativeConstant_pos k) _)
  refine ⟨C*D,mul_pos hC hD,?_⟩
  intro N hN t htlow hthigh
  have hN0 : 0<(N:ℝ) := by exact_mod_cast (show 0<N by omega)
  have ht : t≠0 := by
    have hp := (pow_pos hN0 (k-2)).trans_le htlow
    exact abs_pos.mp hp
  have hb := hbound N hN N 1 t hN0 (by norm_num) (by simp) ht
  have hd := dyadic_derivative_band k (by omega) N t hN0 htlow hthigh
  have hn : (1:ℝ)≤N := by exact_mod_cast hN
  have hterms := derivative_terms_band k hk N (lowerDerivative k N 1 t)
    (derivativeConstant k) (derivativeConstant k) hn (derivativeConstant_pos k)
    (derivativeConstant_pos k) hd.1 hd.2
  have hgram : (∑n∈Finset.range N,phase t ((N:ℝ)+1*n))=gram N t := by
    simp [gram]
  rw [hgram] at hb
  exact hb.trans (by dsimp [D]; nlinarith [mul_le_mul_of_nonneg_left hterms hC.le])

/-- The second derivative supplies the low end of the high-frequency range. -/
theorem gram_second_derivative (hvdC : FixedOrderDerivativeTest) :
    ∃C:ℝ,0<C∧∀N:ℕ,1≤N→∀t T:ℝ,0<T→T≤ |t|→|t|≤N→
      ‖gram N t‖≤C*(N:ℝ)*((N:ℝ)^(-1/2:ℝ)+T^(-1/2:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := progression_derivative_bound hvdC 2 (by omega)
  let a := derivativeConstant 2
  let D := a^(1/2:ℝ)+a^(-1/2:ℝ)
  have ha : 0<a := derivativeConstant_pos 2
  have hD : 0<D := add_pos (Real.rpow_pos_of_pos ha _) (Real.rpow_pos_of_pos ha _)
  refine ⟨C*D,mul_pos hC hD,?_⟩
  intro N hN t T hT hTt htN
  have hN0 : 0<(N:ℝ) := by exact_mod_cast (show 0<N by omega)
  have ht0 : 0< |t| := hT.trans_le hTt
  have hb := hbound N hN N 1 t hN0 (by norm_num) (by simp) (abs_pos.mp ht0)
  have hgram : (∑n∈Finset.range N,phase t ((N:ℝ)+1*n))=gram N t := by simp [gram]
  rw [hgram,lowerDerivative_dyadic 2 N t hN0] at hb
  norm_num [exponent,secondaryExponent] at hb
  have hepos : (a*(|t| /(N:ℝ)^2))^(1/2:ℝ)=a^(1/2:ℝ)*|t| ^(1/2:ℝ)/(N:ℝ) := by
    rw [Real.mul_rpow ha.le (div_nonneg ht0.le (sq_nonneg _)),
      Real.div_rpow ht0.le (sq_nonneg _),←Real.rpow_natCast (N:ℝ) 2,←Real.rpow_mul hN0.le]
    norm_num
    ring
  have heneg : (a*(|t| /(N:ℝ)^2))^(-1/2:ℝ)=a^(-1/2:ℝ)*|t| ^(-1/2:ℝ)*(N:ℝ) := by
    rw [Real.mul_rpow ha.le (div_nonneg ht0.le (sq_nonneg _)),
      Real.div_rpow ht0.le (sq_nonneg _),←Real.rpow_natCast (N:ℝ) 2,←Real.rpow_mul hN0.le]
    norm_num
    rw [Real.rpow_neg_one,div_inv_eq_mul]
    ring
  rw [show -(1/2:ℝ)=(-1/2:ℝ) by ring] at hb
  change ‖gram N t‖≤C*((N:ℝ)*(a*(|t| /(N:ℝ)^2))^(1/2:ℝ)+(a*(|t| /(N:ℝ)^2))^(-1/2:ℝ)) at hb
  rw [hepos,heneg] at hb
  have hhpos := Real.rpow_le_rpow ht0.le htN (by norm_num : (0:ℝ)≤1/2)
  have hhneg := Real.rpow_le_rpow_of_nonpos hT hTt (by norm_num : (-1/2:ℝ)≤0)
  have hhalf : (N:ℝ)^(1/2:ℝ)=(N:ℝ)*(N:ℝ)^(-1/2:ℝ) := by
    calc
      _ = (N:ℝ)^(1+(-1/2:ℝ)) := by congr 1; ring
      _ = _ := by rw [Real.rpow_add hN0,Real.rpow_one]
  have hh1 := mul_le_mul_of_nonneg_left hhpos (Real.rpow_pos_of_pos ha (1/2:ℝ)).le
  have hh2 := mul_le_mul_of_nonneg_left hhneg (Real.rpow_pos_of_pos ha (-1/2:ℝ)).le
  rw [hhalf] at hh1
  have hecancel : (N:ℝ)*(a^(1/2:ℝ)*|t| ^(1/2:ℝ)/(N:ℝ))=a^(1/2:ℝ)*|t| ^(1/2:ℝ) := by field_simp
  rw [hecancel] at hb
  have hc1 := mul_nonneg (Real.rpow_pos_of_pos ha (1/2:ℝ)).le (Real.rpow_pos_of_pos hT (-1/2:ℝ)).le
  have hc2 := mul_nonneg (Real.rpow_pos_of_pos ha (-1/2:ℝ)).le (Real.rpow_pos_of_pos hN0 (-1/2:ℝ)).le
  have hx := mul_le_mul_of_nonneg_left hh2 hN0.le
  have hy := mul_le_mul_of_nonneg_left (add_le_add hh1 hx) hC.le
  dsimp [D]
  nlinarith [mul_nonneg hN0.le hc1,mul_nonneg hN0.le hc2]

theorem exponent_antitone {k l : ℕ} (hk : 2≤k) (hkl : k≤l) : exponent l≤exponent k := by
  have hp : (4:ℝ)≤2^k := by
    have h := pow_le_pow_right₀ (by norm_num : (1:ℝ)≤2) hk
    norm_num at h
    exact h
  have hpow := pow_le_pow_right₀ (by norm_num : (1:ℝ)≤2) hkl
  unfold exponent
  exact one_div_le_one_div_of_le (by linarith) (by linarith)

/-- A finite number of fixed orders covers every polynomial frequency range.
The constant is chosen before N, t and the lower frequency threshold T. -/
theorem gram_polynomial_range (hvdC : FixedOrderDerivativeTest)
    (K : ℕ) (hK : 2≤K) :
    ∃C:ℝ,0<C∧∀N:ℕ,1≤N→∀t T:ℝ,0<T→T≤ |t|→ |t|≤(N:ℝ)^(K-1)→
      ‖gram N t‖≤C*(N:ℝ)*((N:ℝ)^(-exponent K)+T^(-1/2:ℝ)) := by
  induction K,hK using Nat.le_induction with
  | base =>
    obtain ⟨C,hC,hbound⟩ := gram_second_derivative hvdC
    refine ⟨C,hC,?_⟩
    have he : exponent 2=(1/2:ℝ) := by norm_num [exponent]
    simpa only [he,show -(1/2:ℝ)=(-1/2:ℝ) by ring,show (2:ℕ)-1=1 by omega,pow_one] using hbound
  | succ K hK ih =>
    obtain ⟨C,hC,hbound⟩ := ih
    obtain ⟨D,hD,hband⟩ := gram_band_bound hvdC (K+1) (by omega)
    refine ⟨C+D,add_pos hC hD,?_⟩
    intro N hN t T hT hTt htmax
    have hN1 : (1:ℝ)≤N := by exact_mod_cast hN
    have hN0 : 0<(N:ℝ) := by linarith
    have hNpow : 0≤(N:ℝ)^(-exponent (K+1)) := Real.rpow_nonneg hN0.le _
    have hTpow : 0≤T^(-1/2:ℝ) := Real.rpow_nonneg hT.le _
    by_cases ht : |t|≤(N:ℝ)^(K-1)
    · have hb := hbound N hN t T hT hTt ht
      have hpow := Real.rpow_le_rpow_of_exponent_le hN1
        (neg_le_neg (exponent_antitone hK (Nat.le_succ K)))
      have hm := mul_le_mul_of_nonneg_left (add_le_add_left hpow (T^(-1/2:ℝ)))
        (mul_nonneg hC.le hN0.le)
      have hd := mul_nonneg (mul_nonneg hD.le hN0.le) (add_nonneg hNpow hTpow)
      nlinarith
    · have hlow : (N:ℝ)^((K+1)-2)≤ |t| := by
        have he : K+1-2=K-1 := by omega
        rw [he]
        exact (lt_of_not_ge ht).le
      have hb := hband N hN t hlow htmax
      rw [sub_eq_add_neg,Real.rpow_add hN0,Real.rpow_one] at hb
      have hc := mul_nonneg (mul_nonneg hC.le hN0.le) (add_nonneg hNpow hTpow)
      have hd := mul_nonneg (mul_nonneg hD.le hN0.le) hTpow
      nlinarith

/-- The literal high-frequency Gram mass has no remaining analytic hypothesis. -/
theorem highFrequencyMass_bound (hvdC : FixedOrderDerivativeTest) (K : ℕ) (hK : 2≤K) :
    ∃C:ℝ,0<C∧∀(s:Finset ℕ)(τ:ℕ→ℝ)(N:ℕ),1≤N→∀T:ℝ,0<T→
      (∀i∈s,∀j∈s,|τ i-τ j|≤(N:ℝ)^(K-1))→
      highFrequencyMass s τ N T≤(s.card:ℝ)^2*C*(N:ℝ)*((N:ℝ)^(-exponent K)+T^(-1/2:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := gram_polynomial_range hvdC K hK
  refine ⟨C,hC,?_⟩
  intro s τ N hN T hT hdiam
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  let E := C*(N:ℝ)*((N:ℝ)^(-exponent K)+T^(-1/2:ℝ))
  have hE : 0≤E := by dsimp [E]; positivity
  unfold highFrequencyMass
  calc
    _ ≤ ∑i∈s,∑j∈s,E := by
      apply Finset.sum_le_sum
      intro i hi
      apply Finset.sum_le_sum
      intro j hj
      split_ifs with ht
      · exact hbound N hN (τ i-τ j) T hT ht.le (hdiam i hi j hj)
      · exact hE
    _ = _ := by simp [E]; ring

/-- Fully coefficient-uniform sampled β-energy with the high-frequency
cancellation inserted. All quantities are literal finite sums. -/
theorem normalized_sparse_energy (hvdC : FixedOrderDerivativeTest) (d : ℕ) (hd : 2≤d) :
    ∃C:ℝ,0<C∧∀(s:Finset ℕ)(τ:ℕ→ℝ)(K:ℕ),1≤K→s⊆Finset.Icc 1 K→∀a:ℝ,
      (∀i∈s,a+i≤τ i∧τ i≤a+i+1)→∀N:ℕ,1≤N→∀T B:ℝ,0<T→0≤B→
      (∀i∈s,∀j∈s,|τ i-τ j|≤(N:ℝ)^(d-1))→∀c:ℕ→ℂ,
      (∀n∈Finset.range N,‖c n‖≤B)→
      (∑i∈s,‖(N:ℂ)⁻¹*∑n∈Finset.range N,c n*phase (τ i) ((N:ℝ)+n)‖^2)≤
        3*B^2*(1+12*(1+Real.log (K:ℝ))+(s.card:ℝ)*T/N+
          (s.card:ℝ)^2*C*((N:ℝ)^(-exponent d)+T^(-1/2:ℝ))) := by
  obtain ⟨C,hC,hbound⟩ := highFrequencyMass_bound hvdC d hd
  refine ⟨C,hC,?_⟩
  intro s τ K hK hs a hcell N hN T B hT hB hdiam c hc
  have hh := normalized_unit_cell_energy s τ K hK hs a hcell N hN T B hT.le hB c hc
  have hg := hbound s τ N hN T hT hdiam
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have hdiv : highFrequencyMass s τ N T/N≤
      (s.card:ℝ)^2*C*((N:ℝ)^(-exponent d)+T^(-1/2:ℝ)) := by
    apply (div_le_iff₀ hN0).mpr
    nlinarith [hg]
  exact hh.trans (mul_le_mul_of_nonneg_left (by linarith) (by positivity))

end Elliptic.Operator.LogPhaseHighFrequency
