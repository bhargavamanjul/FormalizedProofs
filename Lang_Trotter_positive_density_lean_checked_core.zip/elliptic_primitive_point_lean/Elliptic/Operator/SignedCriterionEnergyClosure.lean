module
public import Elliptic.Operator.SignedSourceDyads
public import Elliptic.Operator.NumericBirthDistinctness
public import Elliptic.Sieve.SignedCriterionReduction

/-! Final uniform implication from the literal nonnegative cofactor energy
to the signed scalar criterion. The energy estimate in this theorem is an
original intermediate obligation, not an accepted external source input. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedCriterionEnergyClosure
open scoped BigOperators
open Filter Artin Artin.MarkedSource
open SignedCauchyExpansion SignedDyadicCauchy SignedEnergyAssembly
open SignedSourceDyads SignedSmoothDyads SignedDampingAsymptotics
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

/-- One group choice and one onset cover the entire scale family; the
finite dyadic partition and damping error introduce no family dependence. -/
theorem signedScalarCriterion_of_source_energy (hbands : ClassicalBandMass)
    (henergy : ∀δ C D c₁ c₂ : ℝ,0<δ→0<C→0<D→0<c₁→0<c₂→
      ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→∀b : Bands K,
      ∀(J : Type) (Hm Hn : ℝ→J→ℝ) (active : ℝ→J→Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active→∀α : ℝ→J→ℕ→ℂ,
      ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j)→
      (∀ᶠx : ℝ in atTop,∀j,active x j→∀n : ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→
        ‖α x j n‖≤(Real.log x)^C ∧ (α x j n≠0→Artin.MarkedCriterion.IsRough (W x) n))→
      ∀ᶠx : ℝ in atTop,∀j,active x j→∀s t : Finset ℕ,
      IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→∀β : ℕ→ℂ,CoefficientOn x C t β→
      ∀d∈sourceDyads b x,
        (∑h∈dyadicCofactors b x ((2:ℝ)^d) s t weight,
          ‖undampedFiber b x ((2:ℝ)^d) s t weight (α x j) β h‖^2)≤
            (Hm x j*Hn x j)*(2:ℝ)^d*(Real.log x)^(-D)) :
    Sieve.SignedReplacement.SignedScalarCriterion := by
  intro δ C D q c₁ c₂ hδ hC hD hq hq1 hc₁ hc₂
  obtain ⟨K₀,hK₀,hK⟩ := henergy δ C (2*D+4) c₁ c₂ hδ hC (by linarith) hc₁ hc₂
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b J Hm Hn active hscale α hcan hcoeff
  let R : ℝ := Real.sqrt 6
  let B : ℝ := 2*K/Real.log 2+2
  have hR : 0<R := by dsimp [R]; positivity
  have hB : 0<B := by dsimp [B]; positivity
  refine ⟨1+B*R,by positivity,?_⟩
  filter_upwards [hK K hKK b J Hm Hn active hscale α hcan hcoeff,hscale,hcoeff,
    eventually_bilinear_replacement hbands b δ C D q hδ hq.le hq1,
    sourceBands_eventually_disjoint b,
    eventually_sourceDyads_scales b (hK₀.trans hKK) δ hδ,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ))]
      with x he hsc hco herr hdis hdy hL
  intro j hj s t hs ht β hβ F hF
  have hLp : 0<Real.log x := by linarith
  obtain ⟨hHm,hHn,hxm,hxn,hlo,hhi⟩ := hsc j hj
  have hα : ∀n∈s,‖α x j n‖≤(Real.log x)^C := fun n hn=>
    (hco j hj n (hs.inDyad n hn).1 (hs.inDyad n hn).2).1
  let ε := R*(Real.log x)^(-(D+2))
  have hε : 0≤ε := by dsimp [ε]; positivity
  have hεeq : ε^2/6=(Real.log x)^(-(2*D+4)) := by
    dsimp [ε,R]
    rw [mul_pow,Real.sq_sqrt (by norm_num : (0:ℝ)≤6)]
    rw [←Real.rpow_mul_natCast hLp.le]
    norm_num
    congr 1
    ring
  have hfenergy (d : ℕ) (hd : d∈sourceDyads b x) :
      (∑h∈dyadicCofactors b x ((2:ℝ)^d) s t weight,
        ‖undampedFiber b x ((2:ℝ)^d) s t weight (α x j) β h‖^2)≤
          (Hm x j*Hn x j)*(2:ℝ)^d*ε^2/6 := by
    rw [mul_div_assoc,hεeq]
    exact he j hj s t hs ht β hβ d hd
  have hY (d : ℕ) (hd : d∈sourceDyads b x) : 0<(2:ℝ)^d ∧ (2:ℝ)^d≤Hm x j*Hn x j := by
    refine ⟨by positivity,((hdy d hd).2.trans hxm).trans ?_⟩
    exact le_mul_of_one_le_right (by linarith) hHn
  have htfinal := original_bound_of_energies (sourceDyads b x) b q x (Hm x j) (Hn x j) ε
    ((Real.log x)^(-D)) (fun d=>(2:ℝ)^d) (fun _=>weight) s t (α x j) β F hq.le hq1.le
    hF.1 hε hHm hHn hs.inDyad ht hF hdis hY
    (fun _ _ u hu=>(weight_support u hu).1.le)
    (sourceDyads_partition b (hK₀.trans hKK) x hL) hfenergy
    (herr (Hm x j) (Hn x j) hHm hHn hxn s t hs.inDyad ht (α x j) β F
      hα (fun n hn=>(hβ n hn).1) hF.1)
  have hcard := sourceDyads_card b x hL
  have hsmall : Real.log x*(Real.log x)^(-(D+2))≤(Real.log x)^(-D) := by
    calc
      _ = (Real.log x)^(1:ℝ)*(Real.log x)^(-(D+2)) := by rw [Real.rpow_one]
      _ = (Real.log x)^(-(D+1)) := by rw [←Real.rpow_add hLp]; congr 1; ring
      _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hL (by linarith)
  have herror : (Real.log x)^(-D)+(sourceDyads b x).card*ε≤(1+B*R)*(Real.log x)^(-D) := by
    have hh := mul_le_mul_of_nonneg_right hcard hε
    have hs := mul_le_mul_of_nonneg_left hsmall (mul_nonneg hB.le hR.le)
    dsimp [ε,B] at hh hs ⊢
    nlinarith
  exact htfinal.trans (by
    calc
      _ ≤ (Hm x j*Hn x j)*((1+B*R)*(Real.log x)^(-D)) :=
        mul_le_mul_of_nonneg_left herror (by positivity)
      _ = _ := by ring)

end Elliptic.Operator.SignedCriterionEnergyClosure
