module

public import Elliptic.Operator.PhysicalPathRootEncoding

/-!
# Finite whole-path root reindexing with zero-support extension

Every position in the original finite physical box is retained, as are all
active lists and both permutations.  An arbitrary summand supported in the
derived root box can be extended to the common root-record universe by zero.
This removes the root-dependent target image in the elementary bijection.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPathRootFinite
open scoped BigOperators
open OriginalLifespanSchedule SingleEdgeRootEncoding PhysicalPathRootEncoding SourceRootCount
attribute [local instance] Classical.propDecidable
local instance pathFiniteDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type} [Fintype I] {P : I→Type} [∀i,Fintype (P i)] {J N : ℕ}

/-- All paths in a literal finite position set, including all original
lists and the two independent endpoint permutations. -/
def positionPaths (Ω : Finset (ℤ×ℤ)) : Finset (OriginalPath I (ℤ×ℤ) P J N) :=
  Finset.univ.image (mapPositions (fun z : Ω=>z.val))

theorem mem_positionPaths (Ω : Finset (ℤ×ℤ)) (r : OriginalPath I (ℤ×ℤ) P J N) :
    r∈positionPaths Ω ↔ ∀j,r.position j∈Ω := by
  constructor
  · intro h
    obtain ⟨s,_,rfl⟩ := Finset.mem_image.mp h
    intro j
    exact (s.position j).property
  · intro h
    let s : OriginalPath I Ω P J N :=
      {position:=fun j=>⟨r.position j,h j⟩,active:=r.active,
       sourcePerm:=r.sourcePerm,targetPerm:=r.targetPerm}
    exact Finset.mem_image.mpr ⟨s,Finset.mem_univ _,rfl⟩

/-- A common finite root path universe. The condition at the last
position is supplied only when the intended moment is a closed path. -/
def rootedPaths (R : ℕ) : Finset (OriginalPath I (ℤ×ℤ) P J N) :=
  (positionPaths (integerPositionBox R)).filter (fun r=>r.position 0=(1,0))

theorem mem_rootedPaths (R : ℕ) (r : OriginalPath I (ℤ×ℤ) P J N) :
    r∈rootedPaths R ↔ (∀j,r.position j∈integerPositionBox R) ∧ r.position 0=(1,0) := by
  simp only [rootedPaths,Finset.mem_filter,mem_positionPaths]

theorem integerPositionBox_mono {R S : ℕ} (h : R≤S) :
    integerPositionBox R⊆integerPositionBox S := by
  intro z hz
  have hi : (R:ℤ)≤S := by exact_mod_cast h
  simp only [integerPositionBox,Finset.mem_product,Finset.mem_Icc] at hz ⊢
  exact ⟨⟨(neg_le_neg hi).trans hz.1.1,hz.1.2.trans hi⟩,
    ⟨(neg_le_neg hi).trans hz.2.1,hz.2.2.trans hi⟩⟩

/-- Canonical roots and the common finite record universe account for
every nonzero original summand exactly once. Both completeness hypotheses
are pointwise support statements, not estimates or counting assumptions. -/
theorem sum_eq_common_root_universe
    (U V : ℝ) (hU : 0<U) (R : ℕ)
    (F : OriginalPath I (ℤ×ℤ) P J N→ℂ)
    (hphysical : ∀r,F r≠0→∀j,r.position j∈primitiveSources U V)
    (hroot : ∀t∈canonicalRoots U V,∀r,
      r.position 0=column t→F r≠0→∀j,(rootPath t r).position j∈integerPositionBox R) :
    (∑r∈positionPaths (primitiveSources U V),F r)=
      ∑t∈canonicalRoots U V,∑r∈rootedPaths R,F (physicalPath t r) := by
  have hstart : ∀r∈positionPaths (I:=I) (P:=P) (J:=J) (N:=N) (primitiveSources U V),
      r.position 0∈primitiveSources U V := fun r hr=>(mem_positionPaths _ r).mp hr 0
  have hgroup : (∑r∈positionPaths (primitiveSources U V),F r)=
      ∑z∈primitiveSources U V,
        ∑r∈(positionPaths (primitiveSources U V)).filter (fun r=>r.position 0=z),F r := by
    symm
    exact Finset.sum_fiberwise_of_maps_to hstart F
  rw [hgroup,sum_sources_eq_roots U V hU]
  apply Finset.sum_congr rfl
  intro t ht
  have hc := (Finset.mem_filter.mp ht).2
  apply Finset.sum_bij_ne_zero (fun r _ _=>rootPath t r)
  · intro r hr hn
    exact (mem_rootedPaths R _).mpr
      ⟨hroot t ht r (Finset.mem_filter.mp hr).2 hn,
        rootPath_start t hc r (Finset.mem_filter.mp hr).2⟩
  · intro r hr hn s hs hsn he
    exact rootPath_injective t hc he
  · intro r hr hn
    have hp : physicalPath t r∈positionPaths (primitiveSources U V) :=
      (mem_positionPaths _ _).mpr (hphysical _ hn)
    have hs : (physicalPath t r).position 0=column t := by
      change decode t (r.position 0)=column t
      rw [(mem_rootedPaths R r).mp hr |>.2,decode_source]
    exact ⟨physicalPath t r,Finset.mem_filter.mpr ⟨hp,hs⟩,hn,root_physical t hc r⟩
  · intro r hr hn
    rw [physical_root t hc]

/-- Closed physical paths remain closed, with both ends equal to the
normalized source (1,0). This imposes no equality on endpoint lists. -/
theorem closed_rootPath (t : RootTriple) (ht : Canonical t)
    (r : OriginalPath I (ℤ×ℤ) P J N) (hs : r.position 0=column t)
    (hc : r.position (Fin.last N)=r.position 0) :
    (rootPath t r).position 0=(1,0) ∧ (rootPath t r).position (Fin.last N)=(1,0) := by
  refine ⟨rootPath_start t ht r hs,?_⟩
  change coordinates t (r.position (Fin.last N))=(1,0)
  rw [hc,hs,coordinates_source t ht]

end Elliptic.Operator.PhysicalPathRootFinite
