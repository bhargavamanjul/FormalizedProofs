module

public import Elliptic.Operator.PhysicalRootedMoment
public import Mathlib.Analysis.Matrix.PosDef

/-! Matrix identification and positivity of the actual rooted AA* moment. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootedMoment
open scoped BigOperators ComplexConjugate Matrix ComplexOrder
attribute [local instance] Classical.propDecidable
local instance rootedMomentMatrixDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I Z:Type} [Fintype I] [Fintype Z]
variable {P:I→Type} [∀i,Fintype (P i)] {J:ℕ}

abbrev matrix (V:I→ℝ) (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ):
    Matrix (State (Z:=Z) (P:=P) (J:=J)) (State (Z:=Z) (P:=P) (J:=J)) ℂ:=row V g

theorem rowApply_eq_mulVec (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    rowApply V g F=matrix V g *ᵥ F:=rfl

theorem matrix_adjoint (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ):
    matrix V (adjointGeometry g)=(matrix V g)ᴴ:=by
  funext x y
  exact row_adjoint V g x y

theorem aaStarPower_eq_matrix (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (R:ℕ) (F:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    aaStarPower V g R F=((matrix V g)*(matrix V g)ᴴ)^R *ᵥ F:=by
  induction R with
  | zero=>simp [aaStarPower]
  | succ R ih=>
    rw [aaStarPower,ih,rowApply_eq_mulVec,rowApply_eq_mulVec,matrix_adjoint,
      Matrix.mulVec_mulVec,Matrix.mulVec_mulVec,←pow_succ']

/-- Positivity belongs to the literal physical matrix power. -/
theorem aaStarMatrix_posSemidef (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (R:ℕ):
    (((matrix V g)*(matrix V g)ᴴ)^R).PosSemidef:=
  (Matrix.posSemidef_self_mul_conjTranspose (matrix V g)).pow R

theorem pairing_power_nonneg (V:I→ℝ) (hV:∀i,0≤V i)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (R:ℕ) (F:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    0≤pairing V F (aaStarPower V g R F):=by
  have hm:0 ≤ initialMass (J:=J) V:=by
    unfold initialMass
    exact Finset.prod_nonneg (fun i _=>pow_nonneg (inv_nonneg.mpr (hV i)) _)
  rw [pairing,aaStarPower_eq_matrix]
  apply mul_nonneg
  · exact_mod_cast hm
  · exact (aaStarMatrix_posSemidef V g R).dotProduct_mulVec_nonneg F

theorem rootedPowerMoment_nonneg (V:I→ℝ) (hV:∀i,0≤V i)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (R:ℕ):
    0≤rootedPowerMoment V g R:=
  Finset.sum_nonneg (fun z _=>pairing_power_nonneg V hV g R (positionVector z))

end Elliptic.Operator.PhysicalRootedMoment
