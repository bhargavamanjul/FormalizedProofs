module

public import Elliptic.Operator.ScheduledGhostStep
public import Elliptic.Operator.GroupedMemoryGhost

/-!
# Full grouped ghost steps of a prescribed lifespan schedule

The sum of next scheduled memory cardinalities is the only cutoff input.
Each group's literal indexed choice is constructed from its distinct old
memory, scheduled deaths, and a chosen ordered ghost-birth batch.  The
actual physical output has all the scheduled next bags, and the complete
product fiber retains its signed coefficient against a continuation which
may depend on the whole family of bags.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.LifespanSchedule
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {N J B : ℕ}

/-- The global physical cutoff implies each local scheduled cutoff. -/
theorem grouped_after_card_le
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B) (i : I) :
    (after (S i) (L i) j).card ≤ B :=
  (Finset.single_le_sum (fun k _ => Nat.zero_le (after (S k) (L k) j).card)
    (Finset.mem_univ i)).trans hcut

/-- One actual ghost choice per group, with genuinely ordered fresh
batches; active births belong to edge choices and do not appear here. -/
def groupedGhostChoice
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (x : ∀ i, DistinctBirthTuple (births (S i) (L i) j)) : PhysicalGhostChoice s :=
  fun i => ghostChoice (S i) (L i) j (s.memory P Line J B i)
    (grouped_after_card_le S L j hcut i) (x i)

/-- Distinct grouped birth-order families give distinct actual physical
choices, including when some or all birth sets are empty. -/
theorem groupedGhostChoice_injective
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B) :
    Function.Injective (groupedGhostChoice S L j s hcut) := by
  intro x y h
  funext i
  exact ghostChoice_injective (S i) (L i) j (s.memory P Line J B i)
    (grouped_after_card_le S L j hcut i) (congrFun h i)

/-- The literal indexed output size equals the scheduled next size. -/
theorem groupedGhostChoice_outputSize
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (x : ∀ i, DistinctBirthTuple (births (S i) (L i) j)) (i : I) :
    (groupedGhostChoice S L j s hcut x).outputSize i = (after (S i) (L i) j).card := by
  change (s.memory P Line J B i).size -
    (ghostDeletionIndices (s.memory P Line J B i) (deaths (S i) (L i) j)).card +
    (births (S i) (L i) j).card = _
  rw [ghostDeletionIndices_card (before (S i) (L i) j) (deaths (S i) (L i) j)
      (ℓ i) _ (hm i) (deaths_subset_before (S i) (L i) j),
    memoryEnumeratesSet_size (before (S i) (L i) j) (ℓ i) _ (hm i),
    ← Finset.card_sdiff_of_subset (deaths_subset_before (S i) (L i) j)]
  exact ghost_survivors_births_card (S i) (L i) j

/-- Both the actual local hit condition and the total physical cutoff
are derived from endpoint incidence and the scheduled next cardinality. -/
theorem groupedGhostChoice_valid
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hdeath : ∀ i p, p ∈ deaths (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (x : ∀ i, DistinctBirthTuple (births (S i) (L i) j)) :
    PhysicalGhostChoice.Valid anchor s (groupedGhostChoice S L j s hcut x) := by
  refine ⟨?_,?_⟩
  · intro i
    exact ghostChoice_valid (S i) (L i) j (ℓ i) (anchor (s.position P Line J B) i)
      (s.memory P Line J B i) (hm i) (hdeath i)
      (grouped_after_card_le S L j hcut i) (x i)
  · simpa only [groupedGhostChoice_outputSize S L j ℓ s hm hcut x] using hcut

/-- Every actual output memory enumerates its scheduled next pending set. -/
theorem groupedGhostChoice_output_enumerates [∀ i, Fintype (P i)]
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hdeath : ∀ i p, p ∈ deaths (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hbirth : ∀ i p, p ∈ births (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (x : ∀ i, DistinctBirthTuple (births (S i) (L i) j)) (i : I) :
    MemoryEnumeratesSet (after (S i) (L i) j) (ℓ i)
      (((groupedGhostChoice S L j s hcut x).output anchor s
        (groupedGhostChoice_valid S L j ℓ anchor s hm hdeath hcut x)).memory P Line J B i) :=
  ghostChoice_output_enumerates (S i) (L i) j (ℓ i) (anchor (s.position P Line J B) i)
    (s.memory P Line J B i) (hm i) (hdeath i) (hbirth i)
    (grouped_after_card_le S L j hcut i) (x i)

/-- The whole output bag family is independent of all fresh orderings. -/
theorem groupedGhostChoice_output_bags [∀ i, Fintype (P i)]
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hdeath : ∀ i p, p ∈ deaths (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hbirth : ∀ i p, p ∈ births (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (x : ∀ i, DistinctBirthTuple (births (S i) (L i) j)) :
    (fun i => tupleBag
      (((groupedGhostChoice S L j s hcut x).output anchor s
        (groupedGhostChoice_valid S L j ℓ anchor s hm hdeath hcut x)).memory P Line J B i).values) =
      fun i => bag (ℓ i) (after (S i) (L i) j) := by
  funext i
  exact ghostChoice_output_bag (S i) (L i) j (ℓ i) (anchor (s.position P Line J B) i)
    (s.memory P Line J B i) (hm i) (hdeath i) (hbirth i)
    (grouped_after_card_le S L j hcut i) (x i)

/-- The exact physical coefficient summed over all independent ordered
ghost-birth batches.  The continuation may depend on the entire family
of output memory bags, and all signs and prime masses are retained. -/
theorem groupedGhostChoice_coefficient_fiber [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hdeath : ∀ i p, p ∈ deaths (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hbirth : ∀ i p, p ∈ births (S i) (L i) j →
      ℓ i p = anchor (s.position P Line J B) i p)
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (F : (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ) :
    (∑ x : ∀ i, DistinctBirthTuple (births (S i) (L i) j),
      physicalGhostChoiceWeight ν V η q ρ anchor s (groupedGhostChoice S L j s hcut x) *
      F (fun i => tupleBag
        (((groupedGhostChoice S L j s hcut x).output anchor s
          (groupedGhostChoice_valid S L j ℓ anchor s hm hdeath hcut x)).memory P Line J B i).values)) =
      (∏ i, (((-η/ρ)^(deaths (S i) (L i) j).card *
        (q/ρ^2)^((before (S i) (L i) j \ deaths (S i) (L i) j).filter
          (fun p => ℓ i p = anchor (s.position P Line J B) i p)).card *
        (-η*(V i)/ρ)^(births (S i) (L i) j).card : ℝ) : ℂ) *
        (∏ p ∈ births (S i) (L i) j, (ν i p : ℂ))) *
      F (fun i => bag (ℓ i) (after (S i) (L i) j)) := by
  classical
  simp_rw [groupedGhostChoice_output_bags S L j ℓ anchor s hm hdeath hbirth hcut]
  rw [← Finset.sum_mul]
  congr 1
  change (∑ x : ∀ i, DistinctBirthTuple (births (S i) (L i) j),
    ∏ i, (ghostChoiceWeight (ν i) (V i) η q ρ (anchor (s.position P Line J B) i)
      (s.memory P Line J B i)
      (ghostChoice (S i) (L i) j (s.memory P Line J B i)
        (grouped_after_card_le S L j hcut i) (x i)) : ℂ)) = _
  rw [← Fintype.prod_sum (fun i (y : DistinctBirthTuple (births (S i) (L i) j)) =>
    (ghostChoiceWeight (ν i) (V i) η q ρ (anchor (s.position P Line J B) i)
      (s.memory P Line J B i)
      (ghostChoice (S i) (L i) j (s.memory P Line J B i)
        (grouped_after_card_le S L j hcut i) y) : ℂ))]
  apply Finset.prod_congr rfl
  intro i hi
  have hh := ghostChoice_coefficient_fiber (ν i) (V i) η q ρ
    (S i) (L i) j (ℓ i) (anchor (s.position P Line J B) i)
    (s.memory P Line J B i) (hm i) (hdeath i) (hbirth i)
    (grouped_after_card_le S L j hcut i) (fun _ => (1 : ℂ))
  simpa only [mul_one] using hh

/-- The observable local fibers determine one and only one family of
ordered ghost births for an arbitrary actual grouped physical choice. -/
theorem groupedGhostChoice_existsUnique_of_fibers
    (S : ∀ i, Finset (P i)) (L : ∀ i, P i → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ i p, Line i p) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hm : ∀ i, MemoryEnumeratesSet (before (S i) (L i) j) (ℓ i)
      (s.memory P Line J B i))
    (hcut : (∑ i, (after (S i) (L i) j).card) ≤ B)
    (c : PhysicalGhostChoice s)
    (hdeleted : ∀ i, (c i).1.image (fun a => ((s.memory P Line J B i).values a).1) =
      deaths (S i) (L i) j)
    (hfresh : ∀ i, tupleBag (c i).2.values = (births (S i) (L i) j).val) :
    ∃! x : ∀ i, DistinctBirthTuple (births (S i) (L i) j),
      groupedGhostChoice S L j s hcut x = c := by
  classical
  have hh : ∀ i, ∃ x : DistinctBirthTuple (births (S i) (L i) j),
      ghostChoice (S i) (L i) j (s.memory P Line J B i)
        (grouped_after_card_le S L j hcut i) x = c i := by
    intro i
    exact (ghostChoice_existsUnique_of_fibers (S i) (L i) j (ℓ i)
      (s.memory P Line J B i) (hm i) (grouped_after_card_le S L j hcut i)
      (c i) (hdeleted i) (hfresh i)).exists
  choose x hx using hh
  have he : groupedGhostChoice S L j s hcut x = c := funext hx
  exact ⟨x,he,fun y hy => groupedGhostChoice_injective S L j s hcut (hy.trans he.symm)⟩

end Elliptic.Operator.LifespanSchedule
