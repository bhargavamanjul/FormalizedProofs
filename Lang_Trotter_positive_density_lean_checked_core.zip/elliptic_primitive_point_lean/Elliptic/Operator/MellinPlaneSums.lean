module

public import Elliptic.Operator.MellinPlane

/-! Finite coefficient sums and support geometry for the literal determinant Mellin transform. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinPlane
open MeasureTheory FourierTransform
open scoped SchwartzMap BigOperators
set_option backward.isDefEq.respectTransparency false

/-- The determinant support bounds the logarithmic separation independently of X. -/
theorem scaled_log_ratio_le (c X w w' R : ℝ) (hc : 0<c) (hX : 0<X)
    (hw : c≤w) (hw' : c≤w') (hR : |X*(w-w')|≤R) :
    |X*Real.log (w/w')|≤R/c := by
  have hp : 0<w := hc.trans_le hw
  have hp' : 0<w' := hc.trans_le hw'
  have hlog (u v:ℝ) (hu:0<u) (hv:0<v) :
      v*(Real.log u-Real.log v)≤u-v := by
    have h := Real.log_le_sub_one_of_pos (div_pos hu hv)
    rw [Real.log_div hu.ne' hv.ne'] at h
    have hh := mul_le_mul_of_nonneg_left h hv.le
    field_simp at hh ⊢
    nlinarith
  have hb : c*|Real.log w-Real.log w'|≤|w-w'| := by
    by_cases hww : w'≤w
    · have hl : 0≤Real.log w-Real.log w' := sub_nonneg.mpr (Real.log_le_log hp' hww)
      rw [abs_of_nonneg hl,abs_of_nonneg (sub_nonneg.mpr hww)]
      exact (mul_le_mul_of_nonneg_right hw' hl).trans (hlog w w' hp hp')
    · have hww' : w≤w' := le_of_not_ge hww
      have hl : Real.log w-Real.log w'≤0 := sub_nonpos.mpr (Real.log_le_log hp hww')
      rw [abs_of_nonpos hl,abs_of_nonpos (sub_nonpos.mpr hww')]
      have hm := mul_le_mul_of_nonneg_right hw (show 0≤Real.log w'-Real.log w by linarith)
      have hh := hm.trans (hlog w' w hp' hp)
      nlinarith
  rw [Real.log_div hp.ne' hp'.ne',abs_mul,abs_of_pos hX]
  apply (le_div_iff₀ hc).mpr
  have hm := mul_le_mul_of_nonneg_left hb hX.le
  rw [abs_mul,abs_of_pos hX] at hR
  nlinarith

/-- The inserted logarithmic cutoff need only equal one on the support of ψ. -/
theorem determinantProfile_eval_on_support (ψ ρ σ : ℝ→ℂ) (X lam w w' : ℝ)
    (hX : 0<X) (hw : 0<w) (hw' : 0<w')
    (hρ : ψ (X*(w-w'))≠0→ρ (X*Real.log (w/w'))=1)
    (hσ : σ (Real.log w')=1) :
    determinantProfile ψ ρ σ X lam (vec (X*Real.log (w/w')) (Real.log w'))=
      ψ (X*(w-w'))*Elliptic.SourceContracts.additivePhase (lam*(X*(w-w'))) := by
  by_cases hψ : ψ (X*(w-w'))=0
  · have hex : X*Real.exp (Real.log w')*(Real.exp (X*Real.log (w/w')/X)-1)=X*(w-w') := by
      rw [Real.exp_log hw',mul_div_cancel_left₀ _ hX.ne',Real.exp_log (div_pos hw hw')]
      field_simp
    simp [determinantProfile,vec,hex,hψ]
  · exact determinantProfile_eval ψ ρ σ X lam w w' hX hw hw' (hρ hψ) hσ

/-- A finite linear combination of the actual Schwartz inversion formulas. -/
theorem schwartz_finite_inversion {ι:Type*} (s:Finset ι) (F:𝓢(Plane,ℂ))
    (c:ι→ℂ) (ζ z:ι→ℝ) :
    (∑i∈s,c i*F (vec (ζ i) (z i)))=
      ∫v:ℝ,∫u:ℝ,(𝓕 F) (vec v u)*
        ∑i∈s,c i*Complex.exp (Complex.I*((2*Real.pi*(v*ζ i+u*z i):ℝ):ℂ)) := by
  let f : ι→Plane→ℂ := fun i w=>c i*((𝓕 F) w*
    Complex.exp (Complex.I*((2*Real.pi*inner ℝ w (vec (ζ i) (z i)):ℝ):ℂ)))
  have hf (i:ι) : Integrable (f i) := by
    apply Integrable.const_mul
    apply ((𝓕 F).integrable (μ:=volume)).mul_bdd (c:=1)
    · apply Continuous.aestronglyMeasurable
      fun_prop
    · filter_upwards [] with w
      rw [Complex.norm_exp_I_mul_ofReal]
  have hi (i:ι) : c i*F (vec (ζ i) (z i))=∫w:Plane,f i w := by
    rw [integral_const_mul]
    congr 1
    have hinv := congrArg (fun G:𝓢(Plane,ℂ)=>G (vec (ζ i) (z i)))
      (fourierInv_fourier_eq (F:=𝓢(Plane,ℂ)) F)
    rw [SchwartzMap.fourierInv_coe,Real.fourierInv_eq'] at hinv
    simp only [smul_eq_mul] at hinv
    symm at hinv
    apply hinv.trans
    apply integral_congr_ae
    filter_upwards [] with w
    calc
      _ = (𝓕 F) w*Complex.exp (((2*Real.pi*inner ℝ w (vec (ζ i) (z i)):ℝ):ℂ)*Complex.I) := mul_comm _ _
      _ = _ := by congr 2; ring
  simp_rw [hi]
  rw [←integral_finsetSum s (fun i hi=>hf i)]
  rw [plane_integral _ (integrable_finsetSum s (fun i hi=>hf i))]
  apply integral_congr_ae
  filter_upwards [] with v
  apply integral_congr_ae
  filter_upwards [] with u
  simp only [f,inner_vec,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  ring

/-- Exact rescaling of a finite Mellin superposition, with the same X⁻¹ Jacobian. -/
theorem schwartz_finite_mellin_inversion {ι:Type*} (s:Finset ι) (F:𝓢(Plane,ℂ))
    (c:ι→ℂ) (ζ z:ι→ℝ) (X:ℝ) (hX:0<X) :
    (∑i∈s,c i*F (vec (ζ i) (z i)))=
      (X:ℂ)⁻¹*(∫t:ℝ,∫u:ℝ,mellinKernel F (t/X) u*
        ∑i∈s,c i*Complex.exp (Complex.I*((t*ζ i/X+u*z i:ℝ):ℂ))) := by
  let r : ℝ := 2*Real.pi
  have hr : 0<r := by dsimp [r]; positivity
  let g : ℝ→ℝ→ℂ := fun v u=>(𝓕 F) (vec v u)*
    ∑i∈s,c i*Complex.exp (Complex.I*((r*(v*ζ i+u*z i):ℝ):ℂ))
  have hi : (∑i∈s,c i*F (vec (ζ i) (z i)))=∫v:ℝ,∫u:ℝ,g v u :=
    schwartz_finite_inversion s F c ζ z
  have hs := rescale_double_integral g (r*X) r (mul_pos hr hX) hr
  have he (t u:ℝ) : mellinKernel F (t/X) u*
      (∑i∈s,c i*Complex.exp (Complex.I*((t*ζ i/X+u*z i:ℝ):ℂ)))=
      (((r^2:ℝ):ℂ)⁻¹)*g (t/(r*X)) (u/r) := by
    unfold mellinKernel
    dsimp [g]
    have harg : t/X/r=t/(r*X) := by field_simp
    rw [harg]
    have hp (i:ι) : t*ζ i/X+u*z i=r*(t/(r*X)*ζ i+u/r*z i) := by field_simp
    simp_rw [hp]
    dsimp [r]
    ring
  simp_rw [he]
  simp_rw [integral_const_mul]
  rw [hs,←hi]
  have hrC : (r:ℂ)≠0 := by exact_mod_cast hr.ne'
  have hXC : (X:ℂ)≠0 := by exact_mod_cast hX.ne'
  push_cast
  field_simp

/-- Finite coefficient sums separate into the two literal Dirichlet factors.
No coefficient-dependent constant or convergence premise is introduced. -/
theorem schwartz_pair_mellin_separation {ι κ:Type*} (I:Finset ι) (J:Finset κ)
    (F:𝓢(Plane,ℂ)) (a:ι→ℂ) (b:κ→ℂ) (w:ι→ℝ) (w':κ→ℝ)
    (X:ℝ) (hX:0<X) (hw:∀i∈I,0<w i) (hw':∀j∈J,0<w' j) :
    (∑i∈I,∑j∈J,a i*b j*F (vec (X*Real.log (w i/w' j)) (Real.log (w' j))))=
      (X:ℂ)⁻¹*(∫t:ℝ,∫u:ℝ,mellinKernel F (t/X) u*
        (∑i∈I,a i*LogPhaseProgression.phase t (w i))*
        (∑j∈J,b j*LogPhaseProgression.phase (u-t) (w' j))) := by
  have h := schwartz_finite_mellin_inversion (I×ˢJ) F
    (fun p=>a p.1*b p.2) (fun p=>X*Real.log (w p.1/w' p.2))
    (fun p=>Real.log (w' p.2)) X hX
  simp only [Finset.sum_product] at h
  apply h.trans
  congr 1
  apply integral_congr_ae
  filter_upwards [] with t
  apply integral_congr_ae
  filter_upwards [] with u
  rw [mul_assoc]
  congr 1
  rw [Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  rw [mellin_phase X (w i) (w' j) t u hX (hw i hi) (hw' j hj)]
  ring

/-- Coefficient-uniform finite form of source (5.15), for the literal
determinant kernel and fixed compact logarithmic cutoffs. -/
theorem determinant_pair_mellin_separation {ι κ:Type*} (I:Finset ι) (J:Finset κ)
    (ψ ρ σ:ℝ→ℂ)
    (hψ:ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ψ)
    (hρ:ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ρ)
    (hσ:ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ)
    (a:ι→ℂ) (b:κ→ℂ) (w:ι→ℝ) (w':κ→ℝ) (X lam:ℝ) (hX:0<X)
    (hw:∀i∈I,0<w i) (hw':∀j∈J,0<w' j)
    (hρone:∀i∈I,∀j∈J,ψ (X*(w i-w' j))≠0→ρ (X*Real.log (w i/w' j))=1)
    (hσone:∀j∈J,σ (Real.log (w' j))=1) :
    (∑i∈I,∑j∈J,a i*b j*
      (ψ (X*(w i-w' j))*Elliptic.SourceContracts.additivePhase (lam*(X*(w i-w' j)))))=
      (X:ℂ)⁻¹*(∫t:ℝ,∫u:ℝ,
        mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) u*
        (∑i∈I,a i*LogPhaseProgression.phase t (w i))*
        (∑j∈J,b j*LogPhaseProgression.phase (u-t) (w' j))) := by
  rw [←schwartz_pair_mellin_separation I J _ a b w w' X hX hw hw']
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  change _=a i*b j*determinantProfile ψ ρ σ X lam
    (vec (X*Real.log (w i/w' j)) (Real.log (w' j)))
  rw [determinantProfile_eval_on_support ψ ρ σ X lam (w i) (w' j)
    hX (hw i hi) (hw' j hj) (hρone i hi j hj) (hσone j hj)]

end Elliptic.Operator.MellinPlane
