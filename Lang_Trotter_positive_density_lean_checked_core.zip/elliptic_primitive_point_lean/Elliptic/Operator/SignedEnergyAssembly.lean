module

public import Elliptic.Operator.SignedPairExpansion

/-! Final finite scalar assembly from the actual cofactor energies.
The energy estimate remains a mathematical obligation: this module proves
the exact implication, including dyad count and damping error constants. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedEnergyAssembly
open scoped BigOperators
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDampingBounds
open SignedDyadicCauchy SignedPairExpansion
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

theorem dyadic_bound_of_energy (b : Bands K) (q x Y Hm Hn ε : ℝ)
    (s t : Finset ℕ) (η : ℝ→ℂ) (α β F : ℕ→ℂ)
    (hq:0≤q) (hq1:q≤1) (hF:∀h,‖F h‖≤1) (hY:0<Y) (hYX:Y≤Hm*Hn)
    (hHm:1≤Hm) (hHn:1≤Hn) (hε:0≤ε) (hs:InDyad Hm s) (ht:InDyad Hn t)
    (hη:∀u,η u≠0→1≤u)
    (hdisjoint:Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (henergy:(∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2)≤
      (Hm*Hn)*Y*ε^2/6) :
    ‖dyadicSum b q x Y s t η α β F‖≤(Hm*Hn)*ε := by
  have hX:0≤Hm*Hn:=mul_nonneg (by linarith) (by linarith)
  have hc := dyadic_cauchy b q x Y Hm Hn s t η α β F hq hq1 hF hY hYX hHm hHn
    hs ht hη hdisjoint
  have he := mul_le_mul_of_nonneg_left henergy (show 0≤6*(Hm*Hn)/Y by positivity)
  have hid: (6*(Hm*Hn)/Y)*((Hm*Hn)*Y*ε^2/6)=((Hm*Hn)*ε)^2 := by
    field_simp
    <;> ring
  rw [hid] at he
  have hn:=norm_nonneg (dyadicSum b q x Y s t η α β F)
  have hp:=mul_nonneg hX hε
  nlinarith [hc.trans he]

/-- A family of actual energy bounds gives a selector-uniform scalar
bound, paying the explicit number of dyads once and the damping error once. -/
theorem original_bound_of_energies {ι:Type*} (J:Finset ι)
    (b:Bands K) (q x Hm Hn ε error:ℝ) (Y:ι→ℝ) (η:ι→ℝ→ℂ)
    (s t:Finset ℕ) (α β F:ℕ→ℂ)
    (hq:0≤q) (hq1:q≤1) (hF:∀h,‖F h‖≤1) (hε:0≤ε)
    (hHm:1≤Hm) (hHn:1≤Hn) (hs:InDyad Hm s) (ht:InDyad Hn t)
    (hselector:InvariantSelector b x F)
    (hdisjoint:Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hY:∀j∈J,0<Y j ∧ Y j≤Hm*Hn) (hη:∀j∈J,∀u,η j u≠0→1≤u)
    (hpartition:∀p:LabelTuple b x,(∑j∈J,η j ((labelProduct b x p:ℝ)/Y j))=1)
    (henergy:∀j∈J,(∑h∈dyadicCofactors b x (Y j) s t (η j),
      ‖undampedFiber b x (Y j) s t (η j) α β h‖^2)≤(Hm*Hn)*Y j*ε^2/6)
    (herror:‖Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))-
      Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ))‖≤
        (Hm*Hn)*error) :
    ‖Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))‖≤
      (Hm*Hn)*(error+(J.card:ℝ)*ε) := by
  let A:=Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))
  let R:=Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ))
  have hR:‖R‖≤(J.card:ℝ)*((Hm*Hn)*ε) := by
    dsimp only [R]
    rw [←sum_dyadicSum_eq_replaced J b q x Y η s t α β F hselector hdisjoint hpartition]
    calc
      _ ≤ ∑j∈J,‖dyadicSum b q x (Y j) s t (η j) α β F‖:=norm_sum_le _ _
      _ ≤ ∑_j∈J,(Hm*Hn)*ε:=Finset.sum_le_sum (fun j hj=>
        dyadic_bound_of_energy b q x (Y j) Hm Hn ε s t (η j) α β F hq hq1 hF
          (hY j hj).1 (hY j hj).2 hHm hHn hε hs ht (hη j hj) hdisjoint (henergy j hj))
      _ = _:=by simp
  have htri:‖A‖≤‖A-R‖+‖R‖:=by
    simpa only [sub_add_cancel] using norm_add_le (A-R) R
  calc
    _ ≤ (Hm*Hn)*error+(J.card:ℝ)*((Hm*Hn)*ε):=htri.trans (add_le_add herror hR)
    _ = _:=by ring

end Elliptic.Operator.SignedEnergyAssembly
