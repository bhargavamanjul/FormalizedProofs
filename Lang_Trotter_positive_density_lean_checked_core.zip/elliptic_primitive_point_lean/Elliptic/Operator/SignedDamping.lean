module

public import Elliptic.Operator.SignedCauchyExpansion
public import Mathlib.Algebra.BigOperators.Associated

/-! The exact damping replacement after selecting one divisor in each
band. The only exceptional records are selected prime-square divisibilities;
the argument concerns mn+1 literally when instantiated at the successor. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDamping
open scoped BigOperators
open Artin Artin.MarkedSource SignedCauchyExpansion
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

theorem band_prime_dvd_labelProduct (b : Bands K) (x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (i : Fin K) (r : ℕ) (hr : r∈b.group x i) :
    r∣labelProduct b x p ↔ r=(p i).val := by
  constructor
  · intro hd
    obtain ⟨j,_,hj⟩ := (b.group_prime x hr).prime.exists_mem_finset_dvd hd
    have he : r=(p j).val := (Nat.prime_dvd_prime_iff_eq (b.group_prime x hr)
      (b.group_prime x (p j).property)).mp hj
    have hij : i=j := by
      by_contra hne
      exact Finset.disjoint_left.mp (hdisjoint hne) hr (he ▸ (p j).property)
    subst j
    exact he
  · intro he
    rw [he]
    exact Finset.dvd_prod_of_mem _ (Finset.mem_univ i)

theorem unselected_prime_dvd_cofactor (b : Bands K) (x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (n : ℕ) (hp : Divides b x p n) (i : Fin K) (r : ℕ) (hr : r∈b.group x i)
    (hne : r≠(p i).val) :
    r∣n/labelProduct b x p ↔ r∣n := by
  have hd := labelProduct_dvd b x p hdisjoint n hp
  have hn : labelProduct b x p*(n/labelProduct b x p)=n := Nat.mul_div_cancel' hd
  have hnot : ¬r∣labelProduct b x p := fun h=>hne ((band_prime_dvd_labelProduct b x p hdisjoint i r hr).mp h)
  have he : (r∣labelProduct b x p*(n/labelProduct b x p)) ↔ r∣n/labelProduct b x p := by
    rw [(b.group_prime x hr).dvd_mul]
    simp only [hnot,false_or]
  simpa only [hn] using he.symm

theorem count_cofactor_lower (b : Bands K) (x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (n : ℕ) (hn : 0<n) (hp : Divides b x p n) (i : Fin K) :
    ConcreteSelector.primeCount (b.group x i) n-1 ≤
      ConcreteSelector.primeCount (b.group x i) (n/labelProduct b x p) := by
  have hd := labelProduct_dvd b x p hdisjoint n hp
  have hc : 0<n/labelProduct b x p := Nat.div_pos (Nat.le_of_dvd hn hd) (labelProduct_pos b x p)
  rw [primeCount_eq_filter b x i n hn.ne',primeCount_eq_filter b x i _ hc.ne']
  have hmem : (p i).val∈(b.group x i).filter (fun r=>r∣n) :=
    Finset.mem_filter.mpr ⟨(p i).property,hp i⟩
  rw [←Finset.card_erase_of_mem hmem]
  apply Finset.card_le_card
  intro r hr
  obtain ⟨hne,hr⟩ := Finset.mem_erase.mp hr
  obtain ⟨hr,hdiv⟩ := Finset.mem_filter.mp hr
  exact Finset.mem_filter.mpr ⟨hr,(unselected_prime_dvd_cofactor b x p hdisjoint n hp i r hr hne).mpr hdiv⟩

theorem count_cofactor_eq (b : Bands K) (x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (n : ℕ) (hn : 0<n) (hp : Divides b x p n) (i : Fin K)
    (hsq : ¬(p i).val^2∣n) :
    ConcreteSelector.primeCount (b.group x i) (n/labelProduct b x p) =
      ConcreteSelector.primeCount (b.group x i) n-1 := by
  have hd := labelProduct_dvd b x p hdisjoint n hp
  have hc : 0<n/labelProduct b x p := Nat.div_pos (Nat.le_of_dvd hn hd) (labelProduct_pos b x p)
  rw [primeCount_eq_filter b x i n hn.ne',primeCount_eq_filter b x i _ hc.ne']
  have hmem : (p i).val∈(b.group x i).filter (fun r=>r∣n) :=
    Finset.mem_filter.mpr ⟨(p i).property,hp i⟩
  rw [←Finset.card_erase_of_mem hmem]
  congr 1
  ext r
  simp only [Finset.mem_filter,Finset.mem_erase]
  constructor
  · rintro ⟨hr,hdiv⟩
    have hne : r≠(p i).val := by
      intro he
      have hpB : (p i).val∣labelProduct b x p := Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
      have hsq' := Nat.mul_dvd_mul hpB (he ▸ hdiv)
      rw [Nat.mul_div_cancel' hd,←pow_two] at hsq'
      exact hsq hsq'
    exact ⟨hne,hr,(unselected_prime_dvd_cofactor b x p hdisjoint n hp i r hr hne).mp hdiv⟩
  · rintro ⟨hne,hr,hdiv⟩
    exact ⟨hr,(unselected_prime_dvd_cofactor b x p hdisjoint n hp i r hr hne).mpr hdiv⟩

def cofactorDamping (b : Bands K) (q x : ℝ) (h : ℕ) : ℝ :=
  ∏ i : Fin K, q^(ConcreteSelector.primeCount (b.group x i) h)/b.mass x i

theorem damping_eq_cofactorDamping (b : Bands K) (q x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (n : ℕ) (hn : 0<n) (hp : Divides b x p n) (hsq : ∀i,¬(p i).val^2∣n) :
    damping b q x n=cofactorDamping b q x (n/labelProduct b x p) := by
  unfold damping cofactorDamping
  apply Finset.prod_congr rfl
  intro i _
  rw [count_cofactor_eq b x p hdisjoint n hn hp i (hsq i)]

theorem cofactorDamping_le_damping (b : Bands K) (q x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (n : ℕ) (hn : 0<n) (hp : Divides b x p n) (hq : 0≤q) (hq1 : q≤1)
    (hV : ∀i,0≤b.mass x i) :
    cofactorDamping b q x (n/labelProduct b x p) ≤ damping b q x n := by
  unfold damping cofactorDamping
  apply Finset.prod_le_prod₀
  · intro i _
    exact div_nonneg (pow_nonneg hq _) (hV i)
  · intro i _
    exact div_le_div_of_nonneg_right
      (pow_le_pow_of_le_one hq hq1 (count_cofactor_lower b x p hdisjoint n hn hp i)) (hV i)

end Elliptic.Operator.SignedDamping
