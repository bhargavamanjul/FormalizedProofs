module

public import Elliptic.Operator.PrimeExceptionalCells
public import Elliptic.Operator.MajorArcFrequencySplit
public import Elliptic.Operator.MajorArcSparseAsymptotics
public import Elliptic.Operator.MajorArcScaleCancellation

/-!
# Coefficient-uniform small-prime/long-factor energy assembly

The exceptional cells are defined by the actual small-prime polynomial.
Their maximizing beta samples are chosen by compactness and controlled
by the proved logarithmic Gram estimates. The only long-factor premise
is its pointwise cancellation, supplied by ScaleCancellation in the
preceding module; the remaining product mean square is displayed
explicitly for application of ProductDirichletMeanSquare.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcPolynomialEnergy
open scoped BigOperators
open MeasureTheory Set ClassicalDerivativeTest LogPhaseProgression LogPhaseHighFrequency
open PrimeExceptionalCells MajorArcFrequencySplit
set_option backward.isDefEq.respectTransparency false

def betaPolynomial (N : ℕ) (c : ℕ→ℂ) (t : ℝ) : ℂ :=
  (N:ℂ)⁻¹*∑n∈Finset.range N,c n*phase t ((N:ℝ)+n)

theorem betaPolynomial_continuous (N : ℕ) (c : ℕ→ℂ) : Continuous (betaPolynomial N c) := by
  unfold betaPolynomial phase
  fun_prop

/-- Finite uniform form of the source energy split, with the actual
exceptional cardinality and every coefficient loss visible. -/
theorem small_prime_product_energy (hvdC : FixedOrderDerivativeTest)
    (d : ℕ) (hd : 2≤d) : ∃C:ℝ,0<C∧∀(K N:ℕ),1≤K→1≤N→
      (K:ℝ)+1≤(N:ℝ)^(d-1)→∀a ε B μ:ℝ,0<ε→0≤B→0≤μ→
      ∀(S:Finset ℕ)(Pscale:ℝ),0<Pscale→∀{q:ℕ}(χ:DirichletCharacter ℂ q)(ξ:ℝ),
      ∀(c:ℕ→ℂ),(∀n∈Finset.range N,‖c n‖≤B)→∀M:ℝ→ℂ,Continuous M→
      (∀t∈Icc (a+1) (a+(K:ℝ)+1),‖M t‖≤μ)→∀T:ℝ,0<T→
      (∫t in (a+1)..(a+(K:ℝ)+1),
        ‖primePolynomial S Pscale χ ξ t*M t*betaPolynomial N c t‖^2)≤
      ε^2*(∫t in (a+1)..(a+(K:ℝ)+1),‖M t*betaPolynomial N c t‖^2)+
      ((S.card:ℝ)/Pscale)^2*μ^2*(3*B^2*
        (1+12*(1+Real.log (K:ℝ))+
          ((exceptionalCells K a ε (primePolynomial S Pscale χ ξ)).card:ℝ)*T/N+
          ((exceptionalCells K a ε (primePolynomial S Pscale χ ξ)).card:ℝ)^2*C*
            ((N:ℝ)^(-exponent d)+T^(-1/2:ℝ)))) := by
  obtain ⟨C,hC,hbound⟩ := normalized_sparse_energy hvdC d hd
  refine ⟨C,hC,?_⟩
  intro K N hK hN hdiam a ε B μ hε hB hμ S Pscale hP q χ ξ c hc M hM hMμ T hT
  let P := primePolynomial S Pscale χ ξ
  let s := exceptionalCells K a ε P
  have hPc := primePolynomial_continuous S Pscale χ ξ
  have hNc := betaPolynomial_continuous N c
  have hab : a+1≤a+(K:ℝ)+1 := by have := Nat.cast_nonneg (α:=ℝ) K; linarith
  have hsplit := product_energy_split P M (betaPolynomial N c) hPc hM hNc
    (a+1) (a+(K:ℝ)+1) hab ε ((S.card:ℝ)/Pscale) μ hε.le (by positivity) hμ
    (fun t ht=>primePolynomial_norm_le S Pscale hP χ ξ t) hMμ
  obtain ⟨τ,hτ⟩ := exists_unit_cell_maxima (betaPolynomial N c) hNc a
  have hcover := exceptionalCells_cover K a ε P
  have henergy := exceptional_energy_le_samples (betaPolynomial N c) hNc s a _ hcover τ
    (fun i hi=> (hτ i).2)
  have hsample := hbound s τ K hK (exceptionalCells_subset K a ε P) a
    (fun i hi=>(hτ i).1) N hN T B hT hB ?_ c hc
  · have hcombined := henergy.trans hsample
    have hm := mul_le_mul_of_nonneg_left hcombined (show 0≤((S.card:ℝ)/Pscale)^2*μ^2 by positivity)
    exact hsplit.trans (by linarith)
  · intro i hi j hj
    have hiK := Finset.mem_Icc.mp (exceptionalCells_subset K a ε P hi)
    have hjK := Finset.mem_Icc.mp (exceptionalCells_subset K a ε P hj)
    have hi0 : (0:ℝ)≤ i := Nat.cast_nonneg _
    have hj0 : (0:ℝ)≤ j := Nat.cast_nonneg _
    have hiR : (i:ℝ)≤K := by exact_mod_cast hiK.2
    have hjR : (j:ℝ)≤K := by exact_mod_cast hjK.2
    have hit := (hτ i).1
    have hjt := (hτ j).1
    apply abs_le.mpr
    constructor <;> linarith

/-- Once the actual exceptional count has its source envelope, the full
beta exceptional energy is O(B²L), with one uniform constant and onset. -/
theorem eventually_exceptional_beta_energy (hvdC : FixedOrderDerivativeTest)
    (δ H J : ℝ) (hδ : 0<δ) (hH : 0≤H) (hJ : 0≤J) :
    ∃C:ℝ,0<C∧∀ᶠL:ℝ in Filter.atTop,∀K N:ℕ,1≤K→1≤N→
      Real.log (K:ℝ)≤J*L→(K:ℝ)+1≤Real.exp (4*L)→Real.exp (δ*L)≤N→
      ∀a ε:ℝ,∀P:ℝ→ℂ,
      ((exceptionalCells K a ε P).card:ℝ)≤Real.exp (H*L^(91/100:ℝ))→
      ∀B:ℝ,0≤B→∀c:ℕ→ℂ,(∀n∈Finset.range N,‖c n‖≤B)→
      (∫t in Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | ε<‖P t‖},‖betaPolynomial N c t‖^2)≤C*B^2*L := by
  obtain ⟨C,hC,hbound⟩ := MajorArcSparseAsymptotics.eventually_normalized_sparse_energy hvdC δ H J hδ hH hJ
  refine ⟨C,hC,?_⟩
  filter_upwards [hbound] with L hL
  intro K N hK hN hlog hdiam hNmin a ε P hcard B hB c hc
  let s := exceptionalCells K a ε P
  have hNc := betaPolynomial_continuous N c
  obtain ⟨τ,hτ⟩ := exists_unit_cell_maxima (betaPolynomial N c) hNc a
  have hcover := exceptionalCells_cover K a ε P
  have henergy := exceptional_energy_le_samples (betaPolynomial N c) hNc s a _ hcover τ
    (fun i hi=>(hτ i).2)
  have hsample := hL s τ K hK (exceptionalCells_subset K a ε P) hlog a
    (fun i hi=>(hτ i).1) hcard N hN hNmin ?_ B hB c hc
  · exact henergy.trans hsample
  · intro i hi j hj
    have hiK := Finset.mem_Icc.mp (exceptionalCells_subset K a ε P hi)
    have hjK := Finset.mem_Icc.mp (exceptionalCells_subset K a ε P hj)
    have hi0 : (0:ℝ)≤ i := Nat.cast_nonneg _
    have hj0 : (0:ℝ)≤ j := Nat.cast_nonneg _
    have hiR : (i:ℝ)≤K := by exact_mod_cast hiK.2
    have hjR : (j:ℝ)≤K := by exact_mod_cast hjK.2
    have hit := (hτ i).1
    have hjt := (hτ j).1
    apply abs_le.mpr
    constructor <;> linarith

end Elliptic.Operator.MajorArcPolynomialEnergy
