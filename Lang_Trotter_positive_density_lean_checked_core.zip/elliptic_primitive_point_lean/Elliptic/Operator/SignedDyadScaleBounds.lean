module
public import Elliptic.Operator.SignedPadDyads

/-! Uniform physical-box bounds for every actual fresh and pad dyad.
The number of pads grows with x, but the onset is chosen first. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDyadScaleBounds
open Filter Artin Artin.MarkedSource SignedSourceDyads SignedSmoothDyads SignedPadDyads
set_option backward.isDefEq.respectTransparency false

theorem pad_dyad_upper (T : ℝ) (hT : 0≤T) (j : ℕ) (hj : j∈padDyads T) :
    (2:ℝ)^j≤Real.exp (T+2*Real.log 2) := by
  have hj' : (j:ℝ)≤dyadCount T := by
    exact_mod_cast (show j≤dyadCount T from Nat.lt_succ_iff.mp (Finset.mem_range.mp hj))
  have h := hj'.trans (dyadCount_le T hT)
  rw [show (2:ℝ)^j=Real.exp ((j:ℝ)*Real.log 2) by
    rw [Real.exp_nat_mul,Real.exp_log (by norm_num : (0:ℝ)<2)]]
  apply Real.exp_le_exp.mpr
  have hh := mul_le_mul_of_nonneg_right h (Real.log_nonneg (by norm_num : (1:ℝ)≤2))
  have hlog : Real.log (2:ℝ)≠0 := (Real.log_pos (by norm_num : (1:ℝ)<2)).ne'
  field_simp at hh
  nlinarith

theorem dyad_height {K : ℕ} (b : Bands K) (x : ℝ) (hL : 1≤Real.log x)
    (j k : ℕ) (hj : j∈sourceDyads b x)
    (hk : k∈padDyads (4*K*(Real.log x)^(21/100:ℝ))) :
    (2:ℝ)^k*(2:ℝ)^j≤Real.exp ((6*K+2*Real.log 2)*(Real.log x)^(21/100:ℝ)) := by
  obtain ⟨_,_,hY⟩ := activeDyads_scale_bounds
    (fun p : SignedCauchyExpansion.LabelTuple b x=>(SignedCauchyExpansion.labelProduct b x p:ℝ))
    (sourceCount K x) 0 (Real.exp (2*K*(Real.log x)^(1/5:ℝ)))
    (fun p=>⟨Nat.cast_nonneg _,labelProduct_upper b x hL p⟩) j hj
  have hd := pad_dyad_upper (4*K*(Real.log x)^(21/100:ℝ)) (by positivity) k hk
  calc
    _ ≤ Real.exp (4*K*(Real.log x)^(21/100:ℝ)+2*Real.log 2)*
        Real.exp (2*K*(Real.log x)^(1/5:ℝ)) :=
      mul_le_mul hd hY.le (by positivity) (Real.exp_pos _).le
    _ = Real.exp (4*K*(Real.log x)^(21/100:ℝ)+2*Real.log 2+2*K*(Real.log x)^(1/5:ℝ)) :=
      (Real.exp_add _ _).symm
    _ ≤ _ := by
      apply Real.exp_le_exp.mpr
      have hs := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/5:ℝ)≤21/100)
      have h1 := Real.one_le_rpow hL (by norm_num : (0:ℝ)≤21/100)
      have hl : 0≤Real.log (2:ℝ) := Real.log_nonneg (by norm_num)
      nlinarith [mul_le_mul_of_nonneg_left hs (show 0≤(2*K:ℝ) by positivity),
        mul_le_mul_of_nonneg_left h1 (show 0≤2*Real.log (2:ℝ) by positivity)]

theorem eventually_physical_boxes (D c₂ δ : ℝ) (hD : 0≤D) (hc₂ : 0<c₂) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop,∀Hm Hn d₀ Y : ℝ,
      1≤Hm→1≤Hn→x^δ≤Hm→x^δ≤Hn→Hm*Hn≤c₂*x→1≤d₀→1≤Y→
      d₀*Y≤Real.exp (D*(Real.log x)^(21/100:ℝ))→
      x^δ≤d₀*Y*Hm ∧ d₀*Y*Hm≤x^2 ∧ x^δ≤Hn ∧ Hn≤x^2 ∧1≤(d₀*Y*Hm)*Hn := by
  have hs := RootErrorBudget.eventually_subpower_exponent_le D (1/2) (by norm_num)
  have hc := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/2)).eventually_ge_atTop c₂
  filter_upwards [Real.tendsto_log_atTop.eventually hs,hc,eventually_ge_atTop (1:ℝ),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ))] with x hs hc hx hL
  intro Hm Hn d₀ Y hHm hHn hxHm hxHn hsize hd hY hheight
  have hxm : 0<x := by linarith
  have hdY : 1≤d₀*Y := one_le_mul_of_one_le_of_one_le hd hY
  have hHmupper : Hm≤c₂*x := (le_mul_of_one_le_right (by linarith : 0≤Hm) hHn).trans hsize
  have hHnupper : Hn≤c₂*x := (le_mul_of_one_le_left (by linarith : 0≤Hn) hHm).trans hsize
  have hheight' : d₀*Y≤x^(1/2:ℝ) := by
    apply hheight.trans
    rw [Real.rpow_def_of_pos hxm]
    apply Real.exp_le_exp.mpr
    have hpow := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (21/100:ℝ)≤98/100)
    have hh := mul_le_mul_of_nonneg_left hpow hD
    nlinarith
  have hU : d₀*Y*Hm≤x^2 := by
    calc
      _ ≤ x^(1/2:ℝ)*(c₂*x) := mul_le_mul hheight' hHmupper (by linarith) (by positivity)
      _ ≤ x^(1/2:ℝ)*(x^(1/2:ℝ)*x) := by gcongr
      _ = x^2 := by
        rw [←mul_assoc,←Real.rpow_add hxm,show (1/2:ℝ)+1/2=1 by norm_num,Real.rpow_one]
        ring
  have hHnU : Hn≤d₀*Y*Hm*Hn := by
    apply le_mul_of_one_le_left (by linarith)
    exact one_le_mul_of_one_le_of_one_le hdY hHm
  refine ⟨hxHm.trans (le_mul_of_one_le_left (by linarith) hdY),hU,hxHn,?_,?_⟩
  · calc
      _ ≤ c₂*x := hHnupper
      _ ≤ x^(1/2:ℝ)*x := mul_le_mul_of_nonneg_right hc (by linarith)
      _ ≤ x*x := mul_le_mul_of_nonneg_right
        (by simpa using Real.rpow_le_rpow_of_exponent_le hx (by norm_num : (1/2:ℝ)≤1)) (by linarith)
      _ = _ := by ring
  · exact one_le_mul_of_one_le_of_one_le (one_le_mul_of_one_le_of_one_le hdY hHm) hHn

end Elliptic.Operator.SignedDyadScaleBounds
