module
public import Elliptic.Operator.ProductDirichletMeanSquare
public import Elliptic.Operator.SignedCollisionAsymptotics

/-! Scaling the unchanged global divisor moment to the source variable. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDivisorMomentScale
open scoped BigOperators
open Filter

/-- A fixed dilation changes only the constant in the global divisor moment. -/
theorem eventually_divisor_sum_scaled
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (c : ℝ) (hc : 1≤c) :
    ∃T : ℝ,0<T ∧ ∀ᶠx : ℝ in atTop,∀N : ℕ,(N:ℝ)≤c*x→
      (∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2)≤T*x*(Real.log x)^3 := by
  obtain ⟨D,hD,N₀,hN₀⟩ := ProductDirichletMeanSquare.uniform_integer_divisor_moment hD
  refine ⟨D*c*(1+Real.log c)^3,by have := Real.log_nonneg hc; positivity,?_⟩
  filter_upwards [eventually_ge_atTop (max (N₀+1:ℝ) (Real.exp 1))] with x hx
  have hx1 : 1≤x := (Real.one_le_exp (by norm_num : (0:ℝ)≤1)).trans ((le_max_right _ _).trans hx)
  have hx0 : 0<x := lt_of_lt_of_le zero_lt_one hx1
  have hc0 : 0<c := lt_of_lt_of_le zero_lt_one hc
  have hcx : x≤c*x := by nlinarith
  have hL : 1≤Real.log x := (Real.le_log_iff_exp_le hx0).mpr ((le_max_right _ _).trans hx)
  have hcL : 0≤Real.log c := Real.log_nonneg hc
  have hM₀ : N₀≤⌊c*x⌋₊ := (Nat.le_floor_iff (by positivity)).mpr (by have := (le_max_left (N₀+1:ℝ) (Real.exp 1)).trans hx; linarith)
  have hM1 : 1≤⌊c*x⌋₊ := (Nat.le_floor_iff (by positivity)).mpr (by simpa using hx1.trans hcx)
  have hMpos : 0<(⌊c*x⌋₊:ℝ) := by exact_mod_cast hM1
  have hMf : (⌊c*x⌋₊:ℝ)≤c*x := Nat.floor_le (by positivity)
  have hMl : Real.log (⌊c*x⌋₊:ℝ)≤(1+Real.log c)*Real.log x := by
    calc
      _ ≤ Real.log (c*x) := Real.log_le_log hMpos hMf
      _ = Real.log c+Real.log x := Real.log_mul hc0.ne' hx0.ne'
      _ ≤ _ := by nlinarith
  intro N hN
  have hNM : N≤⌊c*x⌋₊ := (Nat.le_floor_iff (by positivity)).mpr hN
  calc
    _ ≤ ∑u∈Finset.Icc 1 ⌊c*x⌋₊,(u.divisors.card:ℝ)^2 :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.Icc_subset_Icc_right hNM) (by intros; positivity)
    _ ≤ D*⌊c*x⌋₊*(Real.log (⌊c*x⌋₊:ℝ))^3 := hN₀ _ hM₀
    _ ≤ D*(c*x)*((1+Real.log c)*Real.log x)^3 :=
      mul_le_mul (mul_le_mul_of_nonneg_left hMf hD.le)
        (pow_le_pow_left₀ (Real.log_nonneg (by exact_mod_cast hM1)) hMl 3)
        (by positivity) (by positivity)
    _ = _ := by ring

/-- The shifted logarithm at a fixed dilation is polynomially controlled. -/
theorem scaled_log_cube (c x : ℝ) (hc : 1≤c) (hx0 : 0<x) (hx : 1≤Real.log x) :
    (1+Real.log (8*(c*x)))^3≤(2+Real.log (8*c))^3*(Real.log x)^3 := by
  have hc0 : 0<8*c := by linarith
  have hcL : 0≤Real.log (8*c) := Real.log_nonneg (by linarith)
  have he : Real.log (8*(c*x))=Real.log (8*c)+Real.log x := by
    rw [←mul_assoc,Real.log_mul hc0.ne' hx0.ne']
  rw [he,←mul_pow]
  apply pow_le_pow_left₀ (by linarith)
  nlinarith

end Elliptic.Operator.SignedDivisorMomentScale
