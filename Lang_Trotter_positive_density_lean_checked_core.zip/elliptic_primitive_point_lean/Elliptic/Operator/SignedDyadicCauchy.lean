module

public import Elliptic.Operator.SignedDampingAsymptotics

/-! Actual dyadic cofactor Cauchy reduction for mn+1. Both the arbitrary
invariant selector and the cofactor damping are removed before analytic
estimates, leaving the literal nonnegative expanded square. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDyadicCauchy
open scoped BigOperators ComplexConjugate
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDamping SignedDampingBounds
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

def dyadicRecords (b : Bands K) (x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ) :
    Finset (Record b x s t) :=
  (records b x s t).filter (fun r=>η ((labelProduct b x r.2.2:ℝ)/Y)≠0)

def dyadicCofactors (b : Bands K) (x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ) : Finset ℕ :=
  (dyadicRecords b x Y s t η).image (cofactor b x s t)

def massNormalization (b : Bands K) (x : ℝ) : ℝ := ∏ i : Fin K,(b.mass x i)⁻¹

def dampingFactor (b : Bands K) (q x : ℝ) (h : ℕ) : ℝ :=
  ∏ i : Fin K,q^(ConcreteSelector.primeCount (b.group x i) h)

def undampedCoefficient (b : Bands K) (x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ)
    (α β : ℕ→ℂ) (r : Record b x s t) : ℂ :=
  (massNormalization b x:ℂ)*η ((labelProduct b x r.2.2:ℝ)/Y)*α r.1.val*β r.2.1.val

def undampedFiber (b : Bands K) (x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ)
    (α β : ℕ→ℂ) (h : ℕ) : ℂ :=
  ∑ r∈(dyadicRecords b x Y s t η).filter (fun r=>cofactor b x s t r=h),
    undampedCoefficient b x Y s t η α β r

/-- The actual dyadic marked sum after the proved damping replacement. -/
def dyadicSum (b : Bands K) (q x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ)
    (α β F : ℕ→ℂ) : ℂ :=
  ∑ r∈records b x s t,α r.1.val*β r.2.1.val*η ((labelProduct b x r.2.2:ℝ)/Y)*
    (cofactorDamping b q x (cofactor b x s t r):ℂ)*F (cofactor b x s t r)

theorem cofactorDamping_factor (b : Bands K) (q x : ℝ) (h : ℕ) :
    cofactorDamping b q x h=massNormalization b x*dampingFactor b q x h := by
  unfold cofactorDamping massNormalization dampingFactor
  rw [←Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  simp only [div_eq_mul_inv,mul_comm]

theorem dampingFactor_bounds (b : Bands K) (q x : ℝ) (h : ℕ) (hq : 0≤q) (hq1 : q≤1) :
    0≤dampingFactor b q x h ∧ dampingFactor b q x h≤1 := by
  constructor
  · exact Finset.prod_nonneg (fun _ _=>pow_nonneg hq _)
  · exact Finset.prod_le_one₀ (fun _ _=>pow_nonneg hq _) (fun _ _=>pow_le_one₀ hq hq1)

theorem dyadicSum_eq_fibers (b : Bands K) (q x Y : ℝ) (s t : Finset ℕ) (η : ℝ→ℂ)
    (α β F : ℕ→ℂ) :
    dyadicSum b q x Y s t η α β F =
      ∑ h∈dyadicCofactors b x Y s t η,
        (F h*(dampingFactor b q x h:ℂ))*undampedFiber b x Y s t η α β h := by
  have he : dyadicSum b q x Y s t η α β F =
      ∑ r∈dyadicRecords b x Y s t η,
        (F (cofactor b x s t r)*(dampingFactor b q x (cofactor b x s t r):ℂ))*
          undampedCoefficient b x Y s t η α β r := by
    unfold dyadicSum dyadicRecords
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro r _
    by_cases hr : η ((labelProduct b x r.2.2:ℝ)/Y)=0
    · simp [hr]
    · rw [if_pos hr,cofactorDamping_factor]
      unfold undampedCoefficient
      push_cast
      ring
  rw [he]
  have hf := Finset.sum_fiberwise_of_maps_to
    (s:=dyadicRecords b x Y s t η) (t:=dyadicCofactors b x Y s t η)
    (g:=cofactor b x s t) (fun r hr=>Finset.mem_image.mpr ⟨r,hr,rfl⟩)
    (fun r=>(F (cofactor b x s t r)*(dampingFactor b q x (cofactor b x s t r):ℂ))*
      undampedCoefficient b x Y s t η α β r)
  rw [←hf]
  apply Finset.sum_congr rfl
  intro h _
  rw [undampedFiber,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  rw [(Finset.mem_filter.mp hr).2]

theorem dyadicCofactors_card (b : Bands K) (x Y Hm Hn : ℝ) (s t : Finset ℕ)
    (η : ℝ→ℂ) (hY : 0<Y) (hYX : Y≤Hm*Hn) (hHm : 1≤Hm) (hHn : 1≤Hn)
    (hs : InDyad Hm s) (ht : InDyad Hn t) (hη : ∀u,η u≠0→1≤u)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ((dyadicCofactors b x Y s t η).card:ℝ)≤6*(Hm*Hn)/Y := by
  have hX : 1≤Hm*Hn := by nlinarith [mul_nonneg (sub_nonneg.mpr hHm) (sub_nonneg.mpr hHn)]
  have hsub : dyadicCofactors b x Y s t η ⊆ Finset.range (⌊(4*(Hm*Hn)+1)/Y⌋₊+1) := by
    intro h hh
    obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hh
    obtain ⟨hr,hηr⟩ := Finset.mem_filter.mp hr
    have hdiv := (Finset.mem_filter.mp hr).2
    have hd := labelProduct_dvd b x r.2.2 hdisjoint _ hdiv
    have heN := Nat.mul_div_cancel' hd
    have he : (labelProduct b x r.2.2:ℝ)*(cofactor b x s t r:ℝ)=
        (r.1.val:ℝ)*r.2.1.val+1 := by exact_mod_cast heN
    have hlabel : Y≤(labelProduct b x r.2.2:ℝ) := by
      have hh := (le_div_iff₀ hY).mp (hη _ hηr)
      simpa using hh
    have hmn : (r.1.val:ℝ)*r.2.1.val≤4*(Hm*Hn) := by
      have hh := mul_le_mul (hs r.1.val r.1.property).2 (ht r.2.1.val r.2.1.property).2
        (Nat.cast_nonneg _) (by linarith : 0≤2*Hm)
      nlinarith
    have hh : (cofactor b x s t r:ℝ)≤(4*(Hm*Hn)+1)/Y := by
      apply (le_div_iff₀ hY).mpr
      have hmul := mul_le_mul_of_nonneg_right hlabel (Nat.cast_nonneg (cofactor b x s t r))
      nlinarith
    apply Finset.mem_range.mpr
    exact Nat.lt_succ_of_le (Nat.le_floor hh)
  have hc : ((dyadicCofactors b x Y s t η).card:ℝ)≤(⌊(4*(Hm*Hn)+1)/Y⌋₊:ℝ)+1 := by
    exact_mod_cast (by simpa using Finset.card_le_card hsub : (dyadicCofactors b x Y s t η).card≤⌊(4*(Hm*Hn)+1)/Y⌋₊+1)
  have hf := Nat.floor_le (show 0≤(4*(Hm*Hn)+1)/Y by positivity)
  apply hc.trans
  apply (le_div_iff₀ hY).mpr
  have hm := (le_div_iff₀ hY).mp hf
  nlinarith

/-- Literal Cauchy reduction with the correct X/Y cofactor count and
all inverse band masses retained in the square. -/
theorem dyadic_cauchy (b : Bands K) (q x Y Hm Hn : ℝ) (s t : Finset ℕ)
    (η : ℝ→ℂ) (α β F : ℕ→ℂ) (hq : 0≤q) (hq1 : q≤1)
    (hF : ∀h,‖F h‖≤1) (hY : 0<Y) (hYX : Y≤Hm*Hn) (hHm : 1≤Hm) (hHn : 1≤Hn)
    (hs : InDyad Hm s) (ht : InDyad Hn t) (hη : ∀u,η u≠0→1≤u)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ‖dyadicSum b q x Y s t η α β F‖^2 ≤
      (6*(Hm*Hn)/Y)*∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2 := by
  rw [dyadicSum_eq_fibers]
  apply (selector_cauchy _ (fun h=>F h*(dampingFactor b q x h:ℂ)) _ _).trans
  · exact mul_le_mul_of_nonneg_right
      (dyadicCofactors_card b x Y Hm Hn s t η hY hYX hHm hHn hs ht hη hdisjoint)
      (Finset.sum_nonneg (fun _ _=>sq_nonneg _))
  · intro h _
    rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (dampingFactor_bounds b q x h hq hq1).1]
    exact (mul_le_mul (hF h) (dampingFactor_bounds b q x h hq hq1).2
      (dampingFactor_bounds b q x h hq hq1).1 zero_le_one).trans_eq (one_mul 1)

end Elliptic.Operator.SignedDyadicCauchy
