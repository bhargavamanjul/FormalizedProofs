module

public import Elliptic.Operator.PhysicalPivotLookup

/-! # Actual local restrictions implied by prescribed earlier pivots -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalPivotRestrictionsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B : ℕ}

/-- Current batch targets depend only on the earlier actual batch prefix. -/
def ghostTarget (value : ∀i,P i → ℕ) (pivot : Address I J B → Address I J B)
    (r : Registry I J B) (j:ℕ) (i:I) (k:ℕ) (earlier:Fin k → P i) : ℕ :=
  if hk:k<B then lookupGhost r j i (fun l=>value i (earlier l))
    (pivot (.inr (.inl (j,i,⟨k,hk⟩)))) else 0

/-- Edge targets use the registry after the immediately preceding ghost visit. -/
def edgeTarget (pivot : Address I J B → Address I J B)
    (r : Registry I J B) (j:ℕ) (i:I) : ℕ :=
  (r (pivot (.inr (.inr (j,i))))).getD 0

/-- Prescribed equalities in the complete log imply the actual local ghost
restriction, using only the past registry and earlier same-batch coordinates. -/
theorem ghost_allowed (value : ∀i,P i → ℕ) (pivot : Address I J B → Address I J B)
    (r f : Registry I J B) (j:ℕ) (S:I → Finset ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalGhostChoice s)
    (hS : ∀i,(S i)⊆Finset.range B)
    (hpast : ∀a,BeforeGhost j a → r a=f a)
    (hcurrent : ∀i a,f (.inr (.inl (j,i,a)))=
      (ActualHistoryBirths.ghostSlot c i a).map (value i))
    (hbefore : ∀i k (hk:k∈S i),GhostPrecedes j i k
      (pivot (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (hS i hk)⟩)))))
    (hequal : ∀i k (hk:k∈S i),∃v,
      f (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (hS i hk)⟩)))=some v ∧
      f (pivot (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (hS i hk)⟩))))=some v) :
    PrescribedPhysicalGhost.Allowed value S (ghostTarget value pivot r j) c := by
  intro i
  constructor
  · intro k hk
    obtain ⟨v,hv,_⟩:=hequal i k hk
    rw [hcurrent] at hv
    unfold ActualHistoryBirths.ghostSlot at hv
    split_ifs at hv with hb
    · exact Finset.mem_range.mpr hb
    · simp at hv
  · intro k hk
    have hkB : k.val<B := Finset.mem_range.mp (hS i hk)
    obtain ⟨v,hv,hpv⟩:=hequal i k.val hk
    have hval : value i ((c i).2.values k)=v := by
      rw [hcurrent] at hv
      simpa only [ActualHistoryBirths.ghostSlot,dif_pos k.isLt,Option.map_some,Option.some.injEq] using hv
    rw [hval]
    unfold ghostTarget
    rw [dif_pos hkB]
    have hlookup := lookupGhost_eq r f j i
      (fun l=>value i (PrescribedPrimeTuple.earlier (c i).2.values k l)) hpast ?_
      (pivot (.inr (.inl (j,i,⟨k.val,hkB⟩)))) (hbefore i k.val hk)
    · rw [hlookup,hpv]
      rfl
    · intro l hl
      rw [hcurrent]
      have hls : l.val<(c i).2.size := lt_trans hl k.isLt
      simp only [ActualHistoryBirths.ghostSlot,dif_pos hls,Option.map_some]
      rfl

/-- Prescribed equalities force a literal fresh branch at a named edge. -/
theorem edge_allowed (value : ∀i,P i → ℕ) (pivot : Address I J B → Address I J B)
    (r f : Registry I J B) (j:ℕ) (S:Finset I)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (hpast : ∀a,BeforeEdge j a → r a=f a)
    (hcurrent : ∀i,f (.inr (.inr (j,i)))=(ActualHistoryBirths.freshSlot c i).map (value i))
    (hbefore : ∀i∈S,BeforeEdge j (pivot (.inr (.inr (j,i)))))
    (hequal : ∀i∈S,∃v,f (.inr (.inr (j,i)))=some v ∧
      f (pivot (.inr (.inr (j,i))))=some v) :
    ∀i∈S,PrescribedEdgeRow.Prescribed (value i) (edgeTarget pivot r j i) (c.group i) := by
  intro i hi
  obtain ⟨v,hv,hpv⟩:=hequal i hi
  have ht : edgeTarget pivot r j i=v := by
    unfold edgeTarget
    rw [hpast _ (hbefore i hi),hpv]
    rfl
  rw [hcurrent] at hv
  cases hc : (c.group i).2 with
  | inl k => simp [ActualHistoryBirths.freshSlot,hc] at hv
  | inr p =>
      refine ⟨p,hc,?_⟩
      rw [ht]
      simpa [ActualHistoryBirths.freshSlot,hc] using hv

end Elliptic.Operator.PhysicalBirthRegistry
