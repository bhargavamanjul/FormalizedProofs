module

public import Elliptic.Operator.LifespanHistories

/-!
# Active runs and their exact normalization

Run starts are counted from actual active visits. The count equals the
single possible fresh-active birth plus the actual promotions. Consequently
one birth measure and the promotion factors give one line-mass factor and
one inverse group normalization per active run, including ghost-only lives.
This does not identify all remaining factors in a physical history.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
namespace PrimeLifespan
variable {N : ℕ} (L : PrimeLifespan N)

/-- An actual start of a maximal consecutive block of active visits. -/
def runStart : ℕ → Prop
  | 0 => 0 ∈ L.active
  | j+1 => j+1 ∈ L.active ∧ j ∉ L.active

def activeRunCount : ℕ := ∑ j ∈ Finset.range (N+1), if L.runStart j then 1 else 0

def promotionCount : ℕ := ∑ j ∈ Finset.range N, if L.promoted j then 1 else 0

@[simp] theorem runStart_zero_iff : L.runStart 0 ↔ L.freshActive 0 := by
  unfold runStart freshActive
  constructor
  · intro h
    exact ⟨by have := (L.active_bounds 0 h).1; omega, h⟩
  · exact And.right

theorem runStart_succ_iff (j : ℕ) :
    L.runStart (j+1) ↔ L.freshActive (j+1) ∨ L.promoted j := by
  constructor
  · intro h
    exact L.active_run_start_succ j h.1 h.2
  · rintro (⟨hb,ha⟩ | ⟨ha,hb,hprev⟩)
    · refine ⟨ha, fun hprev => ?_⟩
      have := (L.active_bounds j hprev).1
      omega
    · exact ⟨ha,hprev⟩

theorem freshActive_not_promoted (j : ℕ) :
    ¬ (L.freshActive (j+1) ∧ L.promoted j) := by
  unfold freshActive promoted
  omega

/-- The only fresh-active birth is the actual birth visit, if active there. -/
theorem freshActive_count :
    (∑ j ∈ Finset.range (N+1), if L.freshActive j then 1 else 0) =
      if L.birth ∈ L.active then 1 else 0 := by
  have hb : L.birth ∈ Finset.range (N+1) :=
    Finset.mem_range.mpr (by have := L.birth_le_death; have := L.death_le; omega)
  by_cases ha : L.birth ∈ L.active
  · have he : ∀ j, L.freshActive j ↔ j = L.birth := by
      intro j
      exact ⟨And.left, fun h => ⟨h, h ▸ ha⟩⟩
    simp_rw [he]
    simp [hb,ha]
  · have he : ∀ j, ¬ L.freshActive j := by
      rintro j ⟨h,hj⟩
      exact ha (h ▸ hj)
    simp [he,ha]

/-- Each active run starts either at the one fresh-active birth or at an
actual promotion. This is a count identity, not a normalization premise. -/
theorem activeRunCount_eq :
    L.activeRunCount = (if L.birth ∈ L.active then 1 else 0) + L.promotionCount := by
  have hsplit : ∀ j,
      (if L.runStart (j+1) then 1 else 0) =
      (if L.freshActive (j+1) then 1 else 0) + (if L.promoted j then 1 else 0) := by
    intro j
    rw [L.runStart_succ_iff]
    have hnot := L.freshActive_not_promoted j
    split_ifs <;> tauto
  have hfresh := L.freshActive_count
  rw [Finset.sum_range_succ'] at hfresh
  unfold activeRunCount promotionCount
  rw [Finset.sum_range_succ']
  simp_rw [hsplit]
  rw [Finset.sum_add_distrib]
  simp only [runStart_zero_iff]
  omega

/-- The precise source normalization: a ghost birth contributes V*nu,
an active birth nu, and every later active run contributes V^-1. -/
theorem birth_promotion_normalization {R : Type*} [Field R]
    (V ν μ : R) (hV : V ≠ 0) (hν : V * ν = μ) :
    (if L.birth ∈ L.active then ν else V * ν) * (V⁻¹)^L.promotionCount =
      μ * (V⁻¹)^L.activeRunCount := by
  rw [L.activeRunCount_eq]
  by_cases ha : L.birth ∈ L.active
  · simp only [ha,ite_true, pow_add,pow_one]
    rw [← hν]
    field_simp
  · simp [ha,hν]

end PrimeLifespan
end Elliptic.Operator
