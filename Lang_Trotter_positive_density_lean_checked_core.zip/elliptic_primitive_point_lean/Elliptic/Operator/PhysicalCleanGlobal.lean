module

public import Elliptic.Operator.CleanFiberAssembly
public import Elliptic.Operator.PhysicalCleanPads
public import Elliptic.Operator.CleanRestriction

/-!
# Actual finite pad and slope-offset assembly

The finite offset count depends only on the fixed support constant.
Pad classes, slope cells, physical positions and fresh-prime tuples are
assembled as direct sums, with no cardinality loss for those fibers.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanGlobal
open scoped BigOperators
open PhysicalCleanPads
attribute [local instance] Classical.propDecidable
local instance cleanGlobalDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Literal finite nearby cell offsets. -/
def offsets (H : ℕ) : Finset ℤ := Finset.Icc (-(H:ℤ)) H

theorem offsets_card (H : ℕ) : (offsets H).card=2*H+1 := by
  simp [offsets,Int.card_Icc]
  omega

theorem mem_offsets (H : ℕ) (d : ℤ) : d∈offsets H ↔ |(d:ℝ)|≤H := by
  rw [offsets,Finset.mem_Icc,abs_le]
  constructor
  · rintro ⟨ha,hb⟩
    constructor
    · exact_mod_cast ha
    · exact_mod_cast hb
  · rintro ⟨ha,hb⟩
    constructor
    · exact_mod_cast ha
    · exact_mod_cast hb

/-- The converse cell estimate supplies the actual local radius needed
by the determinant cancellation theorem. -/
theorem slope_near_of_cells (r d₀ Y H : ℝ) (hd : 0<d₀) (hY : 0<Y)
    (z w : ℤ×ℤ) (hc : |((slopeCell r d₀ Y z-slopeCell r d₀ Y w:ℤ):ℝ)|≤H) :
    |latticeSlope r z-latticeSlope r w|≤(H+1)*d₀*Y := by
  have hz₀ := Int.floor_le (latticeSlope r z/(d₀*Y))
  have hz₁ := Int.lt_floor_add_one (latticeSlope r z/(d₀*Y))
  have hw₀ := Int.floor_le (latticeSlope r w/(d₀*Y))
  have hw₁ := Int.lt_floor_add_one (latticeSlope r w/(d₀*Y))
  have hden : 0<d₀*Y := mul_pos hd hY
  have hez : latticeSlope r z/(d₀*Y)*(d₀*Y)=latticeSlope r z := div_mul_cancel₀ _ hden.ne'
  have hew : latticeSlope r w/(d₀*Y)*(d₀*Y)=latticeSlope r w := div_mul_cancel₀ _ hden.ne'
  rw [abs_le] at hc ⊢
  dsimp only [slopeCell] at hc
  push_cast at hc
  constructor
  · have hnorm : -(H+1)≤latticeSlope r z/(d₀*Y)-latticeSlope r w/(d₀*Y) := by linarith
    have hh := mul_le_mul_of_nonneg_right hnorm hden.le
    nlinarith
  · have hnorm : latticeSlope r z/(d₀*Y)-latticeSlope r w/(d₀*Y)≤H+1 := by linarith
    have hh := mul_le_mul_of_nonneg_right hnorm hden.le
    nlinarith

abbrev Block (Z : Type*) := (Z→Bool)×ℤ

local instance (priority := 2000) blockDecidableEq {Z : Type*} : DecidableEq (Block Z) :=
  Classical.typeDecidableEq _

def sourceBlock {X Z : Type*} (position : Z→ℤ×ℤ) (point : X→Z)
    (D : ℤ) (r d₀ Y : ℝ) (x : X) : Block Z :=
  (padProfile position D (point x),slopeCell r d₀ Y (position (point x)))

def targetBlock {Yt Z : Type*} (position : Z→ℤ×ℤ) (point : Yt→Z)
    (D : ℤ) (r d₀ Y : ℝ) (d : ℤ) (y : Yt) : Block Z :=
  (padProfile position D (point y),slopeCell r d₀ Y (position (point y))-d)

def offsetKernel {X Yt Z : Type*} (position : Z→ℤ×ℤ) (px : X→Z) (py : Yt→Z)
    (r d₀ Y : ℝ) (d : ℤ) (K : X→Yt→ℂ) (x : X) (y : Yt) : ℂ :=
  if slopeCell r d₀ Y (position (py y))-slopeCell r d₀ Y (position (px x))=d then K x y else 0

/-- The exact kernel is the sum of its finitely many literal offsets. -/
theorem sum_offsetKernel {X Yt Z : Type*} (position : Z→ℤ×ℤ) (px : X→Z) (py : Yt→Z)
    (r d₀ Y C : ℝ) (hd : 0<d₀) (hY : 0<Y) (K : X→Yt→ℂ) (x : X) (y : Yt)
    (hnear : K x y≠0 → |latticeSlope r (position (px x))-latticeSlope r (position (py y))|≤C*d₀*Y) :
    (∑d∈offsets ⌈C+1⌉₊,offsetKernel position px py r d₀ Y d K x y)=K x y := by
  by_cases hk : K x y=0
  · simp [offsetKernel,hk]
  · have hc := slopeCell_near r d₀ Y C hd hY (position (px x)) (position (py y)) (hnear hk)
    have hm : slopeCell r d₀ Y (position (py y))-slopeCell r d₀ Y (position (px x))∈offsets ⌈C+1⌉₊ := by
      rw [mem_offsets]
      have he : |((slopeCell r d₀ Y (position (py y))-slopeCell r d₀ Y (position (px x)):ℤ):ℝ)|=
          |((slopeCell r d₀ Y (position (px x))-slopeCell r d₀ Y (position (py y)):ℤ):ℝ)| := by
        push_cast
        exact abs_sub_comm _ _
      rw [he]
      exact hc.trans (Nat.le_ceil _)
    simp only [offsetKernel]
    rw [Finset.sum_eq_single_of_mem _ hm]
    · simp
    · intro d hd hne
      rw [if_neg (Ne.symm hne)]

/-- Only the two compared positions must be primitive; other members
of the ambient position type may be ineligible. -/
theorem padProfile_eq_iff_local {Z : Type*} (position : Z→ℤ×ℤ) (D : ℤ) (z w : Z)
    (hz : IsCoprime (position z).1 (position z).2)
    (hw : IsCoprime (position w).1 (position w).2) :
    padProfile position D z=padProfile position D w ↔ D∣latticeDet (position z) (position w) := by
  constructor
  · intro h
    have hh := congrFun h w
    have hself : D∣latticeDet (position w) (position w) := by simp [latticeDet,mul_comm]
    simpa only [padProfile,decide_eq_true hself,decide_eq_true_eq] using hh
  · intro h
    funext v
    have he : (D∣latticeDet (position z) (position v)) =
        (D∣latticeDet (position w) (position v)) := by
      apply propext
      constructor
      · intro hv
        exact pad_dvd_pair D (position z) (position w) (position v) hz h hv
      · intro hv
        exact pad_dvd_pair D (position w) (position z) (position v) hw
          ((pad_dvd_symm D _ _).mp h) hv
    simp only [padProfile,he]

theorem offsetKernel_zero_of_blocks {X Yt Z : Type*}
    (position : Z→ℤ×ℤ)
    (px : X→Z) (py : Yt→Z) (D : ℤ) (r d₀ Y : ℝ) (d : ℤ)
    (K : X→Yt→ℂ) (x : X) (y : Yt)
    (hxprim : IsCoprime (position (px x)).1 (position (px x)).2)
    (hyprim : IsCoprime (position (py y)).1 (position (py y)).2)
    (hpad : K x y≠0 → D∣latticeDet (position (px x)) (position (py y)))
    (hb : sourceBlock position px D r d₀ Y x≠targetBlock position py D r d₀ Y d y) :
    offsetKernel position px py r d₀ Y d K x y=0 := by
  unfold offsetKernel
  split_ifs with hc
  · by_contra hk
    apply hb
    apply Prod.ext
    · exact (padProfile_eq_iff_local position D _ _ hxprim hyprim).mpr (hpad hk)
    · dsimp only [sourceBlock,targetBlock]
      omega
  · rfl

theorem offsetKernel_eq_of_blocks {X Yt Z : Type*}
    (position : Z→ℤ×ℤ) (px : X→Z) (py : Yt→Z) (D : ℤ) (r d₀ Y : ℝ) (d : ℤ)
    (K : X→Yt→ℂ) (x : X) (y : Yt)
    (hb : sourceBlock position px D r d₀ Y x=targetBlock position py D r d₀ Y d y) :
    offsetKernel position px py r d₀ Y d K x y=K x y := by
  have hc := congrArg Prod.snd hb
  dsimp only [sourceBlock,targetBlock] at hc
  exact if_pos (by omega)


/-- Pairings depend only on entries on the actual endpoint supports. -/
theorem pairing_congr {X Yt : Type*} (s : Finset X) (t : Finset Yt)
    (μ : X→ℝ) (ν : Yt→ℝ) (K L : X→Yt→ℂ)
    (h : ∀x∈s,∀y∈t,K x y=L x y) (a : X→ℂ) (b : Yt→ℂ) :
    finiteMeasuredPairing s t μ ν K a b=finiteMeasuredPairing s t μ ν L a b := by
  unfold finiteMeasuredPairing finiteKernelApply
  apply Finset.sum_congr rfl
  intro x hx
  congr 1
  apply Finset.sum_congr rfl
  intro y hy
  rw [h x hx y hy]

/-- A finite sum costs the sum of its operator bounds, only once. -/
theorem bilinear_sum {X Yt I : Type*} (s : Finset X) (t : Finset Yt) (q : Finset I)
    (μ : X→ℝ) (ν : Yt→ℝ) (K : I→X→Yt→ℂ) (M : I→ℝ)
    (hK : ∀i∈q,FiniteMeasuredBilinearBound s t μ ν (K i) (M i)) :
    FiniteMeasuredBilinearBound s t μ ν (fun x y=>∑i∈q,K i x y) (∑i∈q,M i) := by
  intro a b
  have he : finiteMeasuredPairing s t μ ν (fun x y=>∑i∈q,K i x y) a b=
      ∑i∈q,finiteMeasuredPairing s t μ ν (K i) a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    simp only [Finset.mul_sum,Finset.sum_mul]
    conv_lhs =>
      enter [2,x]
      rw [Finset.sum_comm]
    rw [Finset.sum_comm]
  rw [he]
  calc
    _ ≤ ∑i∈q,‖finiteMeasuredPairing s t μ ν (K i) a b‖ := norm_sum_le _ _
    _ ≤ ∑i∈q,M i*finiteL2 s μ a*finiteL2 t ν b := Finset.sum_le_sum (fun i hi=>hK i hi a b)
    _ = _ := by rw [←Finset.sum_mul,←Finset.sum_mul]

/-- Every nearby block has the required physical pad and slope radius
about any one of its actual source positions. -/
theorem fiber_geometry {X Yt Z : Type*}
    (position : Z→ℤ×ℤ)
    (px : X→Z) (py : Yt→Z) (D : ℤ) (r d₀ Y : ℝ) (hd : 0<d₀) (hY : 0<Y)
    (H : ℕ) (d : ℤ) (hdmem : d∈offsets H) (i : Block Z)
    (x₀ x : X) (y : Yt)
    (h₀ : IsCoprime (position (px x₀)).1 (position (px x₀)).2)
    (hxprim : IsCoprime (position (px x)).1 (position (px x)).2)
    (hyprim : IsCoprime (position (py y)).1 (position (py y)).2)
    (hb₀ : sourceBlock position px D r d₀ Y x₀=i)
    (hbx : sourceBlock position px D r d₀ Y x=i)
    (hby : targetBlock position py D r d₀ Y d y=i) :
    D∣latticeDet (position (px x₀)) (position (px x)) ∧
    D∣latticeDet (position (px x₀)) (position (py y)) ∧
    |latticeSlope r (position (px x₀))-latticeSlope r (position (px x))|≤((H:ℝ)+1)*d₀*Y ∧
    |latticeSlope r (position (px x₀))-latticeSlope r (position (py y))|≤((H:ℝ)+1)*d₀*Y := by
  have hxx := hb₀.trans hbx.symm
  have hxy := hb₀.trans hby.symm
  have hpadx := congrArg Prod.fst hxx
  have hpady := congrArg Prod.fst hxy
  have hcellx := congrArg Prod.snd hxx
  have hcelly := congrArg Prod.snd hxy
  dsimp only [sourceBlock,targetBlock] at hpadx hpady hcellx hcelly
  refine ⟨(padProfile_eq_iff_local position D _ _ h₀ hxprim).mp hpadx,
    (padProfile_eq_iff_local position D _ _ h₀ hyprim).mp hpady,?_,?_⟩
  · apply slope_near_of_cells r d₀ Y H hd hY
    simp only [hcellx,sub_self,Int.cast_zero,abs_zero]
    positivity
  · apply slope_near_of_cells r d₀ Y H hd hY
    have hc : slopeCell r d₀ Y (position (px x₀))-slopeCell r d₀ Y (position (py y))= -d := by omega
    rw [hc,Int.cast_neg,abs_neg]
    exact (mem_offsets H d).mp hdmem

/-- One fixed offset is a genuine direct sum over physical pad/cell
fibers. The local source and target supports are allowed to differ. -/
theorem offset_bound {X Yt Z : Type*}
    (s : Finset X) (t : Finset Yt) (position : Z→ℤ×ℤ)
    (px : X→Z) (py : Yt→Z)
    (hprimx : ∀x∈s,IsCoprime (position (px x)).1 (position (px x)).2)
    (hprimy : ∀y∈t,IsCoprime (position (py y)).1 (position (py y)).2) (D : ℤ) (r d₀ Y : ℝ) (d : ℤ)
    (μ : X→ℝ) (ν : Yt→ℝ) (K : X→Yt→ℂ) (M : ℝ)
    (hμ : ∀x∈s,0≤μ x) (hν : ∀y∈t,0≤ν y) (hM : 0≤M)
    (hpad : ∀x∈s,∀y∈t,K x y≠0→D∣latticeDet (position (px x)) (position (py y)))
    (hlocal : ∀i : Block Z,FiniteMeasuredBilinearBound
      (s.filter (fun x=>sourceBlock position px D r d₀ Y x=i))
      (t.filter (fun y=>targetBlock position py D r d₀ Y d y=i)) μ ν K M) :
    FiniteKernelBound s t μ ν (offsetKernel position px py r d₀ Y d K) M := by
  let f := sourceBlock position px D r d₀ Y
  let g := targetBlock position py D r d₀ Y d
  let blocks := s.image f∪t.image g
  apply finiteKernelBound_of_fibers s t blocks f g
    (fun x hx=>Finset.mem_union_left _ (Finset.mem_image.mpr ⟨x,hx,rfl⟩))
    (fun y hy=>Finset.mem_union_right _ (Finset.mem_image.mpr ⟨y,hy,rfl⟩))
    μ ν _ M hμ hν hM
  · intro x hx y hy hne
    exact offsetKernel_zero_of_blocks position px py D r d₀ Y d K x y (hprimx x hx) (hprimy y hy) (hpad x hx y hy) hne
  · intro i hi
    apply finiteKernelBound_of_measured_bilinear _ _ μ ν
      (fun x hx=>hμ x (Finset.mem_filter.mp hx).1) _ M hM
    intro a b
    rw [pairing_congr _ _ μ ν _ K (fun x hx y hy=>
      offsetKernel_eq_of_blocks position px py D r d₀ Y d K x y
        ((Finset.mem_filter.mp hx).2.trans (Finset.mem_filter.mp hy).2.symm))]
    simpa only [f,g] using hlocal i a b

/-- Global physical cancellation from the actual nearby pad/cell blocks.
The only assembly loss is the fixed number `2*ceil(C+1)+1` of offsets. -/
theorem global_bound {X Yt Z : Type*}
    (s : Finset X) (t : Finset Yt) (position : Z→ℤ×ℤ)
    (px : X→Z) (py : Yt→Z)
    (hprimx : ∀x∈s,IsCoprime (position (px x)).1 (position (px x)).2)
    (hprimy : ∀y∈t,IsCoprime (position (py y)).1 (position (py y)).2) (D : ℤ) (r d₀ Y C : ℝ) (hd : 0<d₀) (hY : 0<Y)
    (μ : X→ℝ) (ν : Yt→ℝ) (K : X→Yt→ℂ) (M : ℝ)
    (hμ : ∀x∈s,0≤μ x) (hν : ∀y∈t,0≤ν y) (hM : 0≤M)
    (hpad : ∀x∈s,∀y∈t,K x y≠0→D∣latticeDet (position (px x)) (position (py y)))
    (hnear : ∀x∈s,∀y∈t,K x y≠0→
      |latticeSlope r (position (px x))-latticeSlope r (position (py y))|≤C*d₀*Y)
    (hlocal : ∀d∈offsets ⌈C+1⌉₊,∀i : Block Z,FiniteMeasuredBilinearBound
      (s.filter (fun x=>sourceBlock position px D r d₀ Y x=i))
      (t.filter (fun y=>targetBlock position py D r d₀ Y d y=i)) μ ν K M) :
    FiniteKernelBound s t μ ν K ((2*⌈C+1⌉₊+1:ℕ)*M) := by
  apply finiteKernelBound_of_measured_bilinear s t μ ν hμ K _ (mul_nonneg (Nat.cast_nonneg _) hM)
  have hb (d) (hdm : d∈offsets ⌈C+1⌉₊) := finiteMeasuredBilinearBound_of_kernel_bound s t μ ν hμ _ M
    (offset_bound s t position px py hprimx hprimy D r d₀ Y d μ ν K M hμ hν hM hpad (hlocal d hdm))
  have hs := bilinear_sum s t (offsets ⌈C+1⌉₊) μ ν
    (fun d=>offsetKernel position px py r d₀ Y d K) (fun _=>M) hb
  simp only [Finset.sum_const,nsmul_eq_mul,offsets_card] at hs
  intro a b
  rw [←pairing_congr s t μ ν
    (fun x y=>∑d∈offsets ⌈C+1⌉₊,offsetKernel position px py r d₀ Y d K x y) K
    (fun x hx y hy=>sum_offsetKernel position px py r d₀ Y C hd hY K x y (hnear x hx y hy))]
  exact hs a b


/-- The local pad estimate need only be supplied about an actual source
point. Empty fibers are zero; every other fiber has a source witness,
and its required physical radius is proved from its literal cell index. -/
theorem global_bound_from_source_base {X Yt Z : Type*}
    (s : Finset X) (t : Finset Yt) (position : Z→ℤ×ℤ)
    (px : X→Z) (py : Yt→Z)
    (hprimx : ∀x∈s,IsCoprime (position (px x)).1 (position (px x)).2)
    (hprimy : ∀y∈t,IsCoprime (position (py y)).1 (position (py y)).2) (D : ℤ) (r d₀ Y C : ℝ) (hd : 0<d₀) (hY : 0<Y)
    (μ : X→ℝ) (ν : Yt→ℝ) (K : X→Yt→ℂ) (M : ℝ)
    (hμ : ∀x∈s,0≤μ x) (hν : ∀y∈t,0≤ν y) (hM : 0≤M)
    (hpad : ∀x∈s,∀y∈t,K x y≠0→D∣latticeDet (position (px x)) (position (py y)))
    (hnear : ∀x∈s,∀y∈t,K x y≠0→
      |latticeSlope r (position (px x))-latticeSlope r (position (py y))|≤C*d₀*Y)
    (hlocal : ∀x₀∈s,∀s' : Finset X,s'⊆s → ∀t' : Finset Yt,t'⊆t →
      (∀x∈s',D∣latticeDet (position (px x₀)) (position (px x)) ∧
        |latticeSlope r (position (px x₀))-latticeSlope r (position (px x))|≤
          ((⌈C+1⌉₊:ℝ)+1)*d₀*Y) →
      (∀y∈t',D∣latticeDet (position (px x₀)) (position (py y)) ∧
        |latticeSlope r (position (px x₀))-latticeSlope r (position (py y))|≤
          ((⌈C+1⌉₊:ℝ)+1)*d₀*Y) →
      FiniteMeasuredBilinearBound s' t' μ ν K M) :
    FiniteKernelBound s t μ ν K ((2*⌈C+1⌉₊+1:ℕ)*M) := by
  apply global_bound s t position px py hprimx hprimy D r d₀ Y C hd hY μ ν K M hμ hν hM hpad hnear
  intro d hdm i
  let s' := s.filter (fun x=>sourceBlock position px D r d₀ Y x=i)
  let t' := t.filter (fun y=>targetBlock position py D r d₀ Y d y=i)
  change FiniteMeasuredBilinearBound s' t' μ ν K M
  by_cases hs : s'=∅
  · intro a b
    simp [finiteMeasuredPairing,finiteKernelApply,finiteL2,finiteL2Sq,hs]
  by_cases ht : t'=∅
  · intro a b
    simp [finiteMeasuredPairing,finiteKernelApply,finiteL2,finiteL2Sq,ht]
  obtain ⟨x₀,hx₀⟩ := Finset.nonempty_iff_ne_empty.mpr hs
  obtain ⟨y₀,hy₀⟩ := Finset.nonempty_iff_ne_empty.mpr ht
  have hx₀' := Finset.mem_filter.mp hx₀
  have hy₀' := Finset.mem_filter.mp hy₀
  apply hlocal x₀ hx₀'.1 s' (Finset.filter_subset _ _) t' (Finset.filter_subset _ _)
  · intro x hx
    have hx' := Finset.mem_filter.mp hx
    have h := fiber_geometry position px py D r d₀ Y hd hY ⌈C+1⌉₊ d hdm i
      x₀ x y₀ (hprimx x₀ hx₀'.1) (hprimx x hx'.1) (hprimy y₀ hy₀'.1) hx₀'.2 hx'.2 hy₀'.2
    exact ⟨h.1,h.2.2.1⟩
  · intro y hy
    have hy' := Finset.mem_filter.mp hy
    have h := fiber_geometry position px py D r d₀ Y hd hY ⌈C+1⌉₊ d hdm i
      x₀ x₀ y (hprimx x₀ hx₀'.1) (hprimx x₀ hx₀'.1) (hprimy y hy'.1) hx₀'.2 hx₀'.2 hy'.2
    exact ⟨h.2.1,h.2.2.2⟩

end Elliptic.Operator.PhysicalCleanGlobal
