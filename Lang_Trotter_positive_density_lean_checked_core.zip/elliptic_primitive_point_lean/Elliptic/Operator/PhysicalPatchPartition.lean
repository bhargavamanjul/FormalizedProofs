module
public import Elliptic.Operator.PhysicalSlopePatches
public import Elliptic.Operator.PhysicalAdmissibleMoment

/-! Exact patch restriction of the actual physical pairing, with the
original constant mass and admissibility projection. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPatchPartition
open scoped BigOperators ComplexConjugate
open PhysicalRootedMoment PhysicalSlopePatches
attribute [local instance] Classical.propDecidable
set_option maxHeartbeats 500000
set_option backward.isDefEq.respectTransparency true

 def restrict {X : Type*} (κ : X→ℤ) (i : ℤ) (F : X→ℂ) : X→ℂ :=
   fun x=>if κ x=i then F x else 0
 def nearRestrict {X : Type*} (κ : X→ℤ) (D : ℕ) (i : ℤ) (F : X→ℂ) : X→ℂ :=
   fun x=>if κ x∈neighbors D i then F x else 0

 theorem sum_fibers {X M : Type*} [Fintype X] [AddCommMonoid M]
    (κ : X→ℤ) (s : Finset ℤ) (hs : ∀x,κ x∈s) (f : X→M) :
    (∑i∈s,∑x,if κ x=i then f x else 0)=∑x,f x := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  simp [hs x]

 theorem sum_restrict_norm_sq {X : Type*} [Fintype X]
    (κ : X→ℤ) (s : Finset ℤ) (hs : ∀x,κ x∈s) (F : X→ℂ) :
    (∑i∈s,∑x,‖restrict κ i F x‖^2)=∑x,‖F x‖^2 := by
  simp only [restrict,apply_ite,norm_zero,ite_pow,zero_pow (by omega : 2≠0)]
  exact sum_fibers κ s hs (fun x=>‖F x‖^2)

 theorem sum_nearRestrict_norm_sq_le {X : Type*} [Fintype X]
    (κ : X→ℤ) (s : Finset ℤ) (D : ℕ) (F : X→ℂ) :
    (∑i∈s,∑x,‖nearRestrict κ D i F x‖^2)≤(2*D+1:ℕ)*(∑x,‖F x‖^2) := by
  simp only [nearRestrict,apply_ite,norm_zero,ite_pow,zero_pow (by omega : 2≠0)]
  rw [Finset.sum_comm,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro x _
  rw [←Finset.sum_filter]
  simp only [Finset.sum_const,nsmul_eq_mul]
  exact mul_le_mul_of_nonneg_right
    (by exact_mod_cast neighbor_overlap_le s D (κ x)) (sq_nonneg _)

 theorem kernel_partition {X : Type*} [Fintype X] (κ : X→ℤ) (s : Finset ℤ)
    (hs : ∀x,κ x∈s) (D : ℕ) (K : X→X→ℂ)
    (hK : ∀x y,K x y≠0→κ y∈neighbors D (κ x)) (F G : X→ℂ) :
    (∑x,conj (F x)*(∑y,K x y*G y))=
      ∑i∈s,∑x,conj (restrict κ i F x)*(∑y,K x y*nearRestrict κ D i G y) := by
  have hrow (x : X) : (∑y,K x y*nearRestrict κ D (κ x) G y)=∑y,K x y*G y := by
    apply Finset.sum_congr rfl
    intro y _
    by_cases hn : κ y∈neighbors D (κ x)
    · simp [nearRestrict,hn]
    · have he : K x y=0 := by by_contra h;exact hn (hK x y h)
      simp [he]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  rw [Finset.sum_eq_single (κ x)]
  · simp [restrict,hrow]
  · intro i hi hne
    simp [restrict,Ne.symm hne]
  · exact fun h=>False.elim (h (hs x))

section Physical
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

 theorem row_near (κ : Z→ℤ) (D : ℕ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : ∀z a w b,g z a w b≠0→κ w∈neighbors D (κ z))
    (x y : State (Z:=Z) (P:=P) (J:=J)) (hr : row V g x y≠0) :
    κ y.1∈neighbors D (κ x.1) := by
  by_contra hn
  have hz (π τ : Perms (I:=I) (J:=J)) :
      g x.1 (fun i k=>x.2 i (π i k)) y.1 (fun i k=>y.2 i ((τ i).symm k))=0 := by
    by_contra h
    exact hn (hg _ _ _ _ h)
  exact hr (by simp only [row,hz,Finset.sum_const_zero,mul_zero])

 theorem pairing_partition (κ : Z→ℤ) (s : Finset ℤ) (hs : ∀z,κ z∈s)
    (D : ℕ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : ∀z a w b,g z a w b≠0→κ w∈neighbors D (κ z))
    (F G : State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    pairing V F (rowApply V g G)=
      ∑i∈s,pairing V (restrict (fun x=>κ x.1) i F)
        (rowApply V g (nearRestrict (fun x=>κ x.1) D i G)) := by
  simp only [pairing,rowApply,←Finset.mul_sum]
  congr 1
  exact kernel_partition (X:=State (Z:=Z) (P:=P) (J:=J))
    (fun x=>κ x.1) s (fun x=>hs x.1) D (row (J:=J) V g)
    (fun x y h=>row_near (I:=I) (Z:=Z) (P:=P) (J:=J) κ D V g hg x y h) F G

 theorem project_restrict (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (κ : Z→ℤ)
    (i : ℤ) (F : State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    PhysicalAdmissibleMoment.project value position (restrict (fun x=>κ x.1) i F)=
      restrict (fun x=>κ x.1) i (PhysicalAdmissibleMoment.project value position F) := by
  funext x
  simp only [PhysicalAdmissibleMoment.project,restrict]
  split_ifs <;> rfl

 theorem project_nearRestrict (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (κ : Z→ℤ)
    (D : ℕ) (i : ℤ) (F : State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    PhysicalAdmissibleMoment.project value position (nearRestrict (fun x=>κ x.1) D i F)=
      nearRestrict (fun x=>κ x.1) D i (PhysicalAdmissibleMoment.project value position F) := by
  funext x
  simp only [PhysicalAdmissibleMoment.project,nearRestrict]
  split_ifs <;> rfl

 theorem sum_pairing_restrict_self (κ : Z→ℤ) (s : Finset ℤ) (hs : ∀z,κ z∈s)
    (V : I→ℝ) (F : State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    (∑i∈s,(pairing V (restrict (fun x=>κ x.1) i F) (restrict (fun x=>κ x.1) i F)).re)=
      (pairing V F F).re := by
  simp_rw [pairing_self_re,PhysicalMomentEndpoint.self_quadratic_eq_sum_norm_sq]
  rw [←Finset.mul_sum]
  congr 1
  exact sum_restrict_norm_sq (fun x : State (Z:=Z) (P:=P) (J:=J)=>κ x.1) s (fun x=>hs x.1) F

 theorem sum_pairing_nearRestrict_self_le (κ : Z→ℤ) (s : Finset ℤ) (D : ℕ)
    (V : I→ℝ) (hm : 0 ≤ initialMass (J:=J) V)
    (F : State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    (∑i∈s,(pairing V (nearRestrict (fun x=>κ x.1) D i F) (nearRestrict (fun x=>κ x.1) D i F)).re)≤
      (2*D+1:ℕ)*(pairing V F F).re := by
  simp_rw [pairing_self_re,PhysicalMomentEndpoint.self_quadratic_eq_sum_norm_sq]
  rw [←Finset.mul_sum]
  have h := mul_le_mul_of_nonneg_left
    (sum_nearRestrict_norm_sq_le (fun x : State (Z:=Z) (P:=P) (J:=J)=>κ x.1) s D F) hm
  simpa only [mul_assoc,mul_left_comm,mul_comm] using h

end Physical
end Elliptic.Operator.PhysicalPatchPartition
