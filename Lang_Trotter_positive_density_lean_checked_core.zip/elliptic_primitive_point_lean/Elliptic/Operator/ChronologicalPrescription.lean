module

public import Elliptic.Operator.MemoryWord
public import Mathlib.Analysis.Complex.Basic

/-! # Adaptive prescribed-choice histories

The registry contains only values already observed. Updates are arbitrary
functions of the current actual choice; the bound therefore permits earlier
pivots to prescribe later births without conditioning on later endpoints.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ChronologicalPrescription
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

universe u v

/-- A literal operation with an adaptive performed-birth restriction.
Its local bound is certified from the actual operation, not from its
collected matrix. -/
structure Step (X : Type u) (R : Type v) (w : X → ℝ) (Δ : ℝ) where
  operation : ChoiceOperation.{u,u} X
  allowed : ∀x,R → operation.ValidChoice x → Prop
  update : ∀x,R → operation.ValidChoice x → R
  count : ℕ
  factor : ℝ
  factor_nonneg : 0≤factor
  row_bound : ∀x r,(∑c : operation.ValidChoice x,if allowed x r c then
    ‖operation.coefficient x c.val‖ *w (operation.output x c.val c.property) else 0) ≤
      factor*Δ^count*w x

variable {X R : Type*} {w : X → ℝ} {Δ : ℝ}

/-- Underlying histories are the original dependent actual choices. -/
def operations (steps : List (Step X R w Δ)) := steps.map Step.operation

/-- Each restriction is tested before updating the earlier-value registry. -/
def Allowed : (steps : List (Step X R w Δ)) → (x:X) → R → 
    ChoiceOperation.History (operations steps) x → Prop
  | [],_,_,_ => True
  | step::steps,x,r,h => step.allowed x r h.1 ∧
      Allowed steps (step.operation.output x h.1.val h.1.property) (step.update x r h.1) h.2

/-- Sum of the nonpivot coordinates actually prescribed by the steps. -/
def count (steps : List (Step X R w Δ)) := (steps.map Step.count).sum

/-- Product of explicit local constants, excluding the prime atoms. -/
def factor (steps : List (Step X R w Δ)) := (steps.map Step.factor).prod

/-- Exact positive-history estimate for adaptive chronological restrictions.
The terminal endpoint may be dropped to any majorant bounded by w. -/
theorem history_sum_le (steps : List (Step X R w Δ)) (hΔ : 0≤Δ)
    (F : X → ℝ) (hF : ∀x,F x≤w x) (x:X) (r:R) :
    (∑h : ChoiceOperation.History (operations steps) x,
      if Allowed steps x r h then ‖h.weight‖*F h.final else 0) ≤
      factor steps *Δ^(count steps)*w x := by
  induction steps generalizing x r with
  | nil =>
      simpa [operations,Allowed,ChoiceOperation.History.weight,ChoiceOperation.History.final,
        factor,count] using hF x
  | cons step steps ih =>
      simp only [Allowed,operations,List.map_cons,ChoiceOperation.History.weight,ChoiceOperation.History.final]
      change (∑h : (Σc : step.operation.ValidChoice x,
        ChoiceOperation.History (operations steps) (step.operation.output x c.val c.property)),
        if step.allowed x r h.1 ∧ Allowed steps _ (step.update x r h.1) h.2 then
          ‖step.operation.coefficient x h.1.val*h.2.weight‖*F h.2.final else 0) ≤ _
      rw [Fintype.sum_sigma]
      have hfac : 0≤factor steps := List.prod_nonneg (by
        intro a ha
        obtain ⟨s,hs,rfl⟩:=List.mem_map.mp ha
        exact s.factor_nonneg)
      calc
        _ ≤ ∑c : step.operation.ValidChoice x,if step.allowed x r c then
            ‖step.operation.coefficient x c.val‖ *
              (factor steps*Δ^(count steps)*w (step.operation.output x c.val c.property)) else 0 := by
          apply Finset.sum_le_sum
          intro c _
          by_cases hc : step.allowed x r c
          · simp only [hc,true_and,ite_true,norm_mul]
            have he : (∑h : ChoiceOperation.History (operations steps) (step.operation.output x c.val c.property),
                if Allowed steps _ (step.update x r c) h then
                  ‖step.operation.coefficient x c.val‖*‖h.weight‖*F h.final else 0) =
                ‖step.operation.coefficient x c.val‖ *
                (∑h : ChoiceOperation.History (operations steps) (step.operation.output x c.val c.property),
                  if Allowed steps _ (step.update x r c) h then ‖h.weight‖*F h.final else 0) := by
              rw [Finset.mul_sum]
              apply Finset.sum_congr rfl
              intro h _
              split_ifs <;> ring
            rw [he]
            exact mul_le_mul_of_nonneg_left (ih _ _) (norm_nonneg _)
          · simp [hc]
        _ = (factor steps*Δ^(count steps))*
            (∑c : step.operation.ValidChoice x,if step.allowed x r c then
              ‖step.operation.coefficient x c.val‖*w (step.operation.output x c.val c.property) else 0) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro c _
          split_ifs <;> ring
        _ ≤ (factor steps*Δ^(count steps))*(step.factor*Δ^step.count*w x) :=
          mul_le_mul_of_nonneg_left (step.row_bound x r) (mul_nonneg hfac (pow_nonneg hΔ _))
        _ = _ := by simp only [factor,count,List.map_cons,List.prod_cons,List.sum_cons,pow_add]; ring

end Elliptic.Operator.ChronologicalPrescription
