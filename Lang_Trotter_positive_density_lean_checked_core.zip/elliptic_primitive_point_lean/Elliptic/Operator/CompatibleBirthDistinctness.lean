module

public import Elliptic.Operator.ActualHistoryObservation
public import Elliptic.Operator.ActualHistoryBirths

/-!
# Numerical birth distinctness is constant on a compatible-history fiber

Compatibility fixes the actual ghost birth multisets and each edge's
fresh/promotion flag and target label. Ghost ordering can therefore change
birth addresses but not the multiplicity of any performed numerical value.
No injectivity hypothesis on the numerical label map is needed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath ActualHistoryObservation
attribute [local instance] Classical.propDecidable
local instance compatibleBirthDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace CompatibleBirthDistinctness

/-- Multiplicity of one numerical label in a padded performed-birth logger. -/
def birthCount {A Q : Type*} [Fintype A] (b : A → Option Q) (p : Q) : ℕ :=
  ∑ a, if b a = some p then 1 else 0

theorem birthsDistinct_iff_counts {A Q : Type*} [Fintype A] (b : A → Option Q) :
    BirthsDistinct b ↔ ∀ p, birthCount b p ≤ 1 := by
  have hc (p : Q) : birthCount b p = (Finset.univ.filter (fun a => b a = some p)).card := by
    simp [birthCount]
  simp_rw [hc,Finset.card_le_one]
  constructor
  · intro h p a ha a' ha'
    exact h a a' p (Finset.mem_filter.mp ha).2 (Finset.mem_filter.mp ha').2
  · intro h a a' p ha ha'
    exact h p a (Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha⟩)
      a' (Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha'⟩)

/-- Padding a finite tuple by zeros leaves every sum unchanged. -/
theorem sum_padded (B m : ℕ) (hm : m ≤ B) (f : Fin m → ℕ) :
    (∑ a : Fin B, if h : a.val < m then f ⟨a.val,h⟩ else 0) = ∑ a, f a := by
  induction B generalizing m with
  | zero =>
      have he : m = 0 := by omega
      subst m
      simp
  | succ B ih =>
      cases m with
      | zero => simp
      | succ m =>
          rw [Fin.sum_univ_succ,Fin.sum_univ_succ]
          simp only [Fin.val_zero,Nat.zero_lt_succ,dite_true]
          congr 1
          simp only [Fin.val_succ,Nat.succ_lt_succ_iff]
          convert ih m (by omega) (fun a => f a.succ) using 1
          apply Finset.sum_congr rfl
          intro a _
          split_ifs <;> rfl

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem ghostSlot_count (value : ∀ i, P i → ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (i : I) (p : ℕ) :
    (∑ a : Fin B, if (ActualHistoryBirths.ghostSlot c i a).map (value i) = some p then 1 else 0 : ℕ) =
      ((tupleBag (c i).2.values).map (value i)).count p := by
  have he (a : Fin B) :
      (if (ActualHistoryBirths.ghostSlot c i a).map (value i) = some p then 1 else 0 : ℕ) =
        if h : a.val < (c i).2.size then
          (if value i ((c i).2.values ⟨a.val,h⟩) = p then 1 else 0) else 0 := by
    by_cases h : a.val < (c i).2.size
    · simp [ActualHistoryBirths.ghostSlot,h]
    · simp [ActualHistoryBirths.ghostSlot,h]
  simp_rw [he]
  rw [sum_padded B (c i).2.size (c i).2.size_le
    (fun a => if value i ((c i).2.values a) = p then 1 else 0)]
  rw [tupleBag_eq_map,Multiset.map_map,Multiset.count_map]
  rw [← Finset.filter_val]
  simp only [Finset.sum_boole,Nat.cast_id,Function.comp_apply,eq_comm]
  rfl

variable (value : ∀ i, P i → ℕ)
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- The logger's padded ghost contribution has exactly the count of the
actual recorded fresh multiset, even when numerical labels collide. -/
theorem ghostAt_count (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : ℕ) :
    (∑ a : Fin B, if (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry n j s h k i a).map
      (value i) = some p then 1 else 0 : ℕ) =
      (((ghostAt ν V η q ρ anchor geometry n j s h k).fresh i).map (value i)).count p := by
  induction n generalizing j s with
  | zero => exact ghostSlot_count value s h.1.val i p
  | succ n ih =>
      exact Fin.cases (ghostSlot_count value s h.1.val i p)
        (fun t => ih (j+1) _ h.2.2 t) k

/-- The actual fresh logger is read off from the observed edge record. -/
theorem freshAt_eq_record (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin n) (i : I) :
    ActualHistoryBirths.freshAt ν V η q ρ anchor geometry n j s h k i =
      if (edgeAt ν V η q ρ anchor geometry n j s h k).promote i then none
      else some ((edgeAt ν V η q ρ anchor geometry n j s h k).targetPrime i) := by
  induction n generalizing j s with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun t => ih (j+1) _ h.2.2 t) k
      · simp only [ActualHistoryBirths.freshAt,edgeAt,Fin.cases_zero,
          ActualHistoryBirths.freshSlot,record]
        cases he : (h.2.1.val.group i).2 <;> simp [edgeTargetPrime,he]

/-- Equality of the actual recorded bags and edge data fixes every numerical
multiplicity in the future logger, including all cross-group collisions. -/
theorem count_eq_of_records (n j : ℕ)
    (s t : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (g : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) t)
    (hg : ∀ k i, (ghostAt ν V η q ρ anchor geometry n j s h k).fresh i =
      (ghostAt ν V η q ρ anchor geometry n j t g k).fresh i)
    (he : ∀ k, (edgeAt ν V η q ρ anchor geometry n j s h k).promote =
        (edgeAt ν V η q ρ anchor geometry n j t g k).promote ∧
      (edgeAt ν V η q ρ anchor geometry n j s h k).targetPrime =
        (edgeAt ν V η q ρ anchor geometry n j t g k).targetPrime)
    (p : ℕ) :
    (∑ k : Fin (n+1), ∑ i, ∑ a : Fin B,
      if (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry n j s h k i a).map (value i) = some p
        then 1 else 0 : ℕ) +
      (∑ k : Fin n, ∑ i,
        if (ActualHistoryBirths.freshAt ν V η q ρ anchor geometry n j s h k i).map (value i) = some p
          then 1 else 0) =
    (∑ k : Fin (n+1), ∑ i, ∑ a : Fin B,
      if (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry n j t g k i a).map (value i) = some p
        then 1 else 0 : ℕ) +
      (∑ k : Fin n, ∑ i,
        if (ActualHistoryBirths.freshAt ν V η q ρ anchor geometry n j t g k i).map (value i) = some p
          then 1 else 0) := by
  congr 1
  · apply Finset.sum_congr rfl
    intro k _
    apply Finset.sum_congr rfl
    intro i _
    rw [ghostAt_count,ghostAt_count,hg k i]
  · apply Finset.sum_congr rfl
    intro k _
    apply Finset.sum_congr rfl
    intro i _
    rw [freshAt_eq_record,freshAt_eq_record,(he k).1,(he k).2]


/-- Split the exact logger count into initial slots, padded ghost slots, and
fresh edge targets. Promotions and unused padding contribute zero. -/
theorem labels_count (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (p : ℕ) :
    birthCount (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h) p =
      (∑ i, ∑ a : Fin (J+1), if value i (s.active P Line J B i a) = p then 1 else 0 : ℕ) +
      ((∑ k : Fin (N+1), ∑ i, ∑ a : Fin B,
        if (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry N 0 s h k i a).map (value i) = some p
          then 1 else 0 : ℕ) +
       (∑ k : Fin N, ∑ i,
        if (ActualHistoryBirths.freshAt ν V η q ρ anchor geometry N 0 s h k i).map (value i) = some p
          then 1 else 0)) := by
  simp only [birthCount,Fintype.sum_sum_type,Fintype.sum_prod_type,
    ActualHistoryBirths.labels,Option.some.injEq]
  congr! 7

/-- Histories compatible with one schedule have identical actual recorded
birth bags and fresh-edge data, hence identical numerical birth counts. -/
theorem counts_eq_of_compatible (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h g : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hh : d.Compatible ν V η q ρ geometry N 0 s h)
    (hg : d.Compatible ν V η q ρ geometry N 0 s g) (p : ℕ) :
    birthCount (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h) p =
      birthCount (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s g) p := by
  rw [labels_count,labels_count]
  congr 1
  apply count_eq_of_records value ν V η q ρ anchor geometry N 0 s s h g
  · intro k i
    exact ((ghostMatches_of_compatible ν V η q ρ anchor geometry d N 0 s h hh k).2 i).trans
      ((ghostMatches_of_compatible ν V η q ρ anchor geometry d N 0 s g hg k).2 i).symm
  · intro k
    have heh := compatible_edgeAt ν V η q ρ anchor geometry d N 0 s h hh k
    have heg := compatible_edgeAt ν V η q ρ anchor geometry d N 0 s g hg k
    exact ⟨heh.2.2.2.2.1.trans heg.2.2.2.2.1.symm,
      heh.2.2.2.2.2.trans heg.2.2.2.2.2.symm⟩

/-- The original numerical distinct-birth restriction is constant throughout
a compatible-history fiber. It need only be checked for one member.
No injectivity of the numerical prime-value map is assumed. -/
theorem birthsDistinct_iff_of_compatible (d : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h g : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hh : d.Compatible ν V η q ρ geometry N 0 s h)
    (hg : d.Compatible ν V η q ρ geometry N 0 s g) :
    BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h) ↔
      BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s g) := by
  rw [birthsDistinct_iff_counts,birthsDistinct_iff_counts]
  exact forall_congr' (fun p => by rw [counts_eq_of_compatible value ν V η q ρ anchor geometry d s h g hh hg p])

end CompatibleBirthDistinctness
end Elliptic.Operator
