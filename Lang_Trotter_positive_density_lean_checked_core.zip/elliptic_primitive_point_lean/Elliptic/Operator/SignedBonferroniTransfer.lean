module

public import Elliptic.Operator.SourceBonferroni
public import Elliptic.Operator.SourceRootTransfer

/-!
# Signed Bonferroni comparison and sparse literal-root tests

A complex multiplier cannot be inserted in a real upper/lower sandwich.
The first part proves the needed norm comparison using its absolute bound.
The second part transfers sparse polynomials one modulus at a time.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedBonferroniTransfer
open scoped BigOperators
open SourceBonferroni SourceRootCount SourceRootTransfer
attribute [local instance] Classical.propDecidable

variable {P R Y : Type*} [DecidableEq P]

theorem even_remainder_bounds (s : Finset P) (w : P → ℝ)
    (hw : ∀ p ∈ s, 0 ≤ w p ∧ w p ≤ 1) (m : ℕ) :
    0 ≤ truncation s w (2*m) - ∏ p ∈ s, (1-w p) ∧
      truncation s w (2*m) - (∏ p ∈ s, (1-w p)) ≤ elementary s w (2*m+1) := by
  simpa [pow_mul] using signed_remainder_bounds s w hw (2*m)

/-- No positivity of the complex multiplier is assumed. -/
theorem multiplier_error_le (s : Finset P) (w : P → ℝ)
    (hw : ∀ p ∈ s, 0 ≤ w p ∧ w p ≤ 1) (m : ℕ)
    (a : ℂ) (ha : ‖a‖ ≤ 1) :
    ‖a * (∏ p ∈ s, (1-w p) : ℝ) - a * (truncation s w (2*m) : ℝ)‖ ≤
      elementary s w (2*m+1) := by
  have h := even_remainder_bounds s w hw m
  have he : a * (∏ p ∈ s, (1-w p) : ℝ) - a * (truncation s w (2*m) : ℝ) =
      -a * ((truncation s w (2*m) - ∏ p ∈ s, (1-w p) : ℝ) : ℂ) := by
    push_cast
    ring
  rw [he, norm_mul, norm_neg, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg h.1]
  exact (mul_le_mul_of_nonneg_right ha h.1).trans (by simpa using h.2)

/-- Integration against an arbitrary nonnegative finite weight. Repeated
root configurations are allowed. -/
theorem weighted_multiplier_error_le (r : Finset R) (μ : R → ℝ)
    (hμ : ∀ x ∈ r, 0 ≤ μ x) (s : Finset P) (w : R → P → ℝ)
    (hw : ∀ x ∈ r, ∀ p ∈ s, 0 ≤ w x p ∧ w x p ≤ 1)
    (m : ℕ) (a : R → ℂ) (ha : ∀ x ∈ r, ‖a x‖ ≤ 1) :
    ‖(∑ x ∈ r, (μ x : ℂ) * a x * (∏ p ∈ s, (1-w x p) : ℝ)) -
        ∑ x ∈ r, (μ x : ℂ) * a x * (truncation s (w x) (2*m) : ℝ)‖ ≤
      ∑ x ∈ r, μ x * elementary s (w x) (2*m+1) := by
  rw [← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ x ∈ r, ‖(μ x : ℂ) * a x * (∏ p ∈ s, (1-w x p) : ℝ) -
        (μ x : ℂ) * a x * (truncation s (w x) (2*m) : ℝ)‖ := norm_sum_le _ _
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro x hx
      rw [mul_assoc, mul_assoc, ← mul_sub, norm_mul, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg (hμ x hx)]
      exact mul_le_mul_of_nonneg_left (multiplier_error_le s (w x) (hw x hx) m
        (a x) (ha x hx)) (hμ x hx)

/-- The two transfer errors here are finite comparison inputs, not new
analytic contracts. Sparse literal-root transfer below supplies their
analytic estimates once the residue representations are identified. -/
theorem signed_comparison (r : Finset R) (t : Finset Y)
    (μ : R → ℝ) (ν : Y → ℝ)
    (hμ : ∀ x ∈ r, 0 ≤ μ x) (hν : ∀ y ∈ t, 0 ≤ ν y)
    (s : Finset P) (w : R → P → ℝ) (v : Y → P → ℝ)
    (hw : ∀ x ∈ r, ∀ p ∈ s, 0 ≤ w x p ∧ w x p ≤ 1)
    (hv : ∀ y ∈ t, ∀ p ∈ s, 0 ≤ v y p ∧ v y p ≤ 1)
    (m : ℕ) (a : R → ℂ) (b : Y → ℂ)
    (ha : ∀ x ∈ r, ‖a x‖ ≤ 1) (hb : ∀ y ∈ t, ‖b y‖ ≤ 1)
    (Epoly Egap : ℝ)
    (hpoly : ‖(∑ x ∈ r, (μ x : ℂ)*a x*(truncation s (w x) (2*m) : ℝ)) -
      ∑ y ∈ t, (ν y : ℂ)*b y*(truncation s (v y) (2*m) : ℝ)‖ ≤ Epoly)
    (hgap : (∑ x ∈ r, μ x*elementary s (w x) (2*m+1)) -
      (∑ y ∈ t, ν y*elementary s (v y) (2*m+1)) ≤ Egap) :
    ‖(∑ x ∈ r, (μ x : ℂ)*a x*(∏ p ∈ s, (1-w x p) : ℝ)) -
      ∑ y ∈ t, (ν y : ℂ)*b y*(∏ p ∈ s, (1-v y p) : ℝ)‖ ≤
      Epoly + Egap + 2*(∑ y ∈ t, ν y*elementary s (v y) (2*m+1)) := by
  have hR := weighted_multiplier_error_le r μ hμ s w hw m a ha
  have hY := weighted_multiplier_error_le t ν hν s v hv m b hb
  have htri := norm_sub_le_norm_sub_add_norm_sub (∑ x ∈ r, (μ x : ℂ)*a x*(∏ p ∈ s, (1-w x p) : ℝ))
    (∑ x ∈ r, (μ x : ℂ)*a x*(truncation s (w x) (2*m) : ℝ))
    (∑ y ∈ t, (ν y : ℂ)*b y*(∏ p ∈ s, (1-v y p) : ℝ))
  have htri' := norm_sub_le_norm_sub_add_norm_sub (∑ x ∈ r, (μ x : ℂ)*a x*(truncation s (w x) (2*m) : ℝ))
    (∑ y ∈ t, (ν y : ℂ)*b y*(truncation s (v y) (2*m) : ℝ))
    (∑ y ∈ t, (ν y : ℂ)*b y*(∏ p ∈ s, (1-v y p) : ℝ))
  rw [norm_sub_rev (∑ y ∈ t, (ν y : ℂ)*b y*(truncation s (v y) (2*m) : ℝ))] at htri'
  linarith

/-- A test on literal canonical integral matrices. -/
def integerRootSum (U V : ℝ) (I₁ I₂ I₃ : RootInterval)
    (f : Matrix.SpecialLinearGroup (Fin 2) ℤ → ℂ) : ℂ :=
  ∑ t ∈ rootCandidates U V, if ht : Canonical t then
    if I₁.Contains ((t.1 : ℝ)/U) ∧ I₂.Contains ((t.2.1 : ℝ)/V) ∧
      I₃.Contains ((t.2.2 : ℝ)/t.1) then f (canonicalSL2 t ht) else 0
    else 0

theorem integerRootSum_residue (U V : ℝ) (I₁ I₂ I₃ : RootInterval)
    (S : ℕ) (f : Matrix.SpecialLinearGroup (Fin 2) (ZMod S) → ℂ) :
    integerRootSum U V I₁ I₂ I₃
      (fun g => f (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod S)) g)) =
      weightedRootSum U V S I₁ I₂ I₃ f := rfl

theorem integerRootSum_sum {J : Type*} (j : Finset J) (U V : ℝ)
    (I₁ I₂ I₃ : RootInterval)
    (f : J → Matrix.SpecialLinearGroup (Fin 2) ℤ → ℂ) :
    integerRootSum U V I₁ I₂ I₃ (fun g => ∑ q ∈ j, f q g) =
      ∑ q ∈ j, integerRootSum U V I₁ I₂ I₃ (f q) := by
  unfold integerRootSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs <;> simp
  · simp [hcan]

theorem integerRootSum_mul (U V : ℝ) (I₁ I₂ I₃ : RootInterval)
    (c : ℂ) (f : Matrix.SpecialLinearGroup (Fin 2) ℤ → ℂ) :
    integerRootSum U V I₁ I₂ I₃ (fun g => c*f g) =
      c*integerRootSum U V I₁ I₂ I₃ f := by
  unfold integerRootSum
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs <;> simp
  · simp [hcan]

/-- Every term has its own small modulus; there is no bound on their
common product. Coefficients vary after the single source threshold. -/
theorem uniform_sparse_polynomial_transfer (hPD : RootCountContract)
    (δ : ℝ) (hδ : 0 < δ) (C_S : ℝ) (hCS : 0 ≤ C_S) :
    ∃ C_error : ℝ, 0 < C_error ∧ ∃ x₀ : ℝ, 2 ≤ x₀ ∧
      ∀ x : ℝ, x₀ ≤ x → ∀ U V : ℝ,
        x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
        ∀ (J : Type*) (j : Finset J) (S : J → ℕ), ∀ [∀ q, Fintype (ZMod (S q))],
        ∀ I₁ I₂ I₃ : RootInterval,
          I₁.InRange 1 16 → I₂.InRange 1 2 → I₃.InRange 0 1 →
          (∀ q ∈ j, 1 ≤ S q ∧ Squarefree (S q) ∧
            (S q : ℝ) ≤ Real.exp (C_S*(Real.log x)^(98/100 : ℝ))) →
          ∀ (c : J → ℂ)
            (f : (q : J) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S q)) → ℂ),
          ‖integerRootSum U V I₁ I₂ I₃ (fun g => ∑ q ∈ j,
              c q*f q (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod (S q))) g)) -
              ∑ q ∈ j, (rootVolume U V I₁ I₂ I₃ : ℂ)*c q*
                ((∑ g, f q g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2)
                  (ZMod (S q))) : ℂ))‖ ≤
            C_error*U*V*x^(-(δ/1000)) *
              ∑ q ∈ j, ‖c q‖*(∑ g, ‖f q g‖) := by
  obtain ⟨C, hC, x₀, hx₀, htransfer⟩ := uniform_weighted_transfer hPD δ hδ C_S hCS
  refine ⟨C, hC, x₀, hx₀, ?_⟩
  intro x hx U V hU hU' hV hV' J j S inst I₁ I₂ I₃ hI₁ hI₂ hI₃ hS c f
  rw [integerRootSum_sum, ← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ q ∈ j, ‖integerRootSum U V I₁ I₂ I₃
        (fun g => c q*f q (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod (S q))) g)) -
      (rootVolume U V I₁ I₂ I₃ : ℂ)*c q*
        ((∑ g, f q g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S q))) : ℂ))‖ :=
      norm_sum_le _ _
    _ ≤ ∑ q ∈ j, (C*U*V*x^(-(δ/1000)))*(‖c q‖*(∑ g, ‖f q g‖)) := by
      apply Finset.sum_le_sum
      intro q hq
      rcases hS q hq with ⟨hpos, hsq, hmod⟩
      have h := htransfer x hx U V hU hU' hV hV' (S q) hpos hsq hmod
        I₁ I₂ I₃ hI₁ hI₂ hI₃ (f q)
      rw [integerRootSum_mul, integerRootSum_residue]
      have he : c q*weightedRootSum U V (S q) I₁ I₂ I₃ (f q) -
          (rootVolume U V I₁ I₂ I₃ : ℂ)*c q*
            ((∑ g, f q g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S q))) : ℂ)) =
        c q*(weightedRootSum U V (S q) I₁ I₂ I₃ (f q) -
          (rootVolume U V I₁ I₂ I₃ : ℂ)*
            ((∑ g, f q g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S q))) : ℂ))) := by ring
      rw [he, norm_mul]
      calc
        _ ≤ ‖c q‖*((C*U*V*x^(-(δ/1000)))*(∑ g, ‖f q g‖)) :=
          mul_le_mul_of_nonneg_left h (norm_nonneg _)
        _ = _ := by ring
    _ = _ := by rw [Finset.mul_sum]



/-- Passing through any subset CRT modulus gives the same prime residue
as reducing the original integral matrix directly. -/
theorem crt_map_int {ι : Type*} [Fintype ι] (p : ι → ℕ)
    (hp : Pairwise (fun i j => (p i).Coprime (p j)))
    (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (i : ι) :
    RootResidues.sl2CRT p hp
      (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod (∏ i, p i))) g) i =
      Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod (p i))) g := by
  ext a b
  rw [RootResidues.sl2CRT_entry]
  change ZMod.castHom _ _ ((g a b : ℤ) : ZMod (∏ i, p i)) = (g a b : ZMod (p i))
  simp

open scoped LinearAlgebra.Projectivization

/-- Sparse tests on arbitrary separate prime subfamilies.  In particular,
one may take one family for each active-set/Bonferroni-subset union. The
root configurations in every term are literally the same integer roots;
CRT coherence is proved above, not assumed. The error retains each small
modulus's residue L1 mass, and never uses the full inactive-prime product. -/
theorem uniform_sparse_line_transfer (hPD : RootCountContract)
    (δ : ℝ) (hδ : 0 < δ) (C_S : ℝ) (hCS : 0 ≤ C_S) :
    ∃ C_error : ℝ, 0 < C_error ∧ ∃ x₀ : ℝ, 2 ≤ x₀ ∧
      ∀ x : ℝ, x₀ ≤ x → ∀ U V : ℝ,
        x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
        ∀ (J : Type*) (j : Finset J) (P : J → Type*),
        ∀ [∀ q, Fintype (P q)] [∀ q, DecidableEq (P q)],
        ∀ p : (q : J) → P q → ℕ, ∀ [∀ q i, Fact (p q i).Prime],
        ∀ hp : ∀ q, Pairwise (fun i i' => (p q i).Coprime (p q i')),
        ∀ [∀ q, Fintype (ZMod (∏ i, p q i))],
        ∀ [∀ q i, Fintype (ℙ (ZMod (p q i)) (Fin 2 → ZMod (p q i)))],
        ∀ I₁ I₂ I₃ : RootInterval,
          I₁.InRange 1 16 → I₂.InRange 1 2 → I₃.InRange 0 1 →
          (∀ q ∈ j, ((∏ i, p q i : ℕ) : ℝ) ≤
            Real.exp (C_S*(Real.log x)^(98/100 : ℝ))) →
          ∀ (c : J → ℂ)
            (f : (q : J) → (∀ i, ℙ (ZMod (p q i)) (Fin 2 → ZMod (p q i))) → ℂ),
          ‖integerRootSum U V I₁ I₂ I₃ (fun g => ∑ q ∈ j,
              c q*f q (fun i => RootResidues.kernelLine (ZMod (p q i))
                (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod (p q i))) g))) -
              ∑ q ∈ j, (rootVolume U V I₁ I₂ I₃ : ℂ)*c q*
                ((∑ l, f q l)/((∏ i, (p q i+1) : ℕ) : ℂ))‖ ≤
            C_error*U*V*x^(-(δ/1000)) * ∑ q ∈ j, ‖c q‖*
              (∑ g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p q i)),
                ‖f q (fun i => RootResidues.kernelLine (ZMod (p q i))
                  (RootResidues.sl2CRT (p q) (hp q) g i))‖) := by
  obtain ⟨C, hC, x₀, hx₀, htransfer⟩ := uniform_sparse_polynomial_transfer hPD δ hδ C_S hCS
  refine ⟨C, hC, x₀, hx₀, ?_⟩
  intro x hx U V hU hU' hV hV' J j P instP decP p instprime hp instZ instL
    I₁ I₂ I₃ hI₁ hI₂ hI₃ hmod c f
  have hadm : ∀ q ∈ j, 1 ≤ ∏ i, p q i ∧ Squarefree (∏ i, p q i) ∧
      ((∏ i, p q i : ℕ) : ℝ) ≤ Real.exp (C_S*(Real.log x)^(98/100 : ℝ)) := by
    intro q hq
    exact ⟨(prime_modulus_admissible (p q) (hp q)).1,
      (prime_modulus_admissible (p q) (hp q)).2, hmod q hq⟩
  have h := htransfer x hx U V hU hU' hV hV' J j (fun q => ∏ i, p q i)
    I₁ I₂ I₃ hI₁ hI₂ hI₃ hadm c
    (fun q g => f q (fun i => RootResidues.kernelLine (ZMod (p q i))
      (RootResidues.sl2CRT (p q) (hp q) g i)))
  simp_rw [crt_map_int, RootResidues.crt_kernel_average] at h
  exact h



/-- Arbitrary coupled tests have the correct subset marginal in the full
independent-line model. No factorization of the coupled test is assumed. -/
theorem complex_average_restrict [Fintype P]
    (Lines : P → Type*) [∀ p, Fintype (Lines p)] [∀ p, Nonempty (Lines p)]
    (s : Finset P) (f : (∀ p : s, Lines p) → ℂ) :
    (∑ l : (∀ p, Lines p), f (fun p => l p)) /
        (Fintype.card (∀ p, Lines p) : ℂ) =
      (∑ l : (∀ p : s, Lines p), f l) /
        (Fintype.card (∀ p : s, Lines p) : ℂ) := by
  let e := Equiv.piEquivPiSubtypeProd (fun p => p ∈ s) Lines
  have hsum := Equiv.sum_comp e (fun l => f l.1)
  change (∑ l : (∀ p, Lines p), f (fun p => l p)) = _ at hsum
  rw [hsum, Fintype.card_congr e, Fintype.card_prod, Fintype.sum_prod_type]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, Nat.cast_mul]
  rw [← Finset.mul_sum]
  have hC : (Fintype.card (∀ p : { p // p ∉ s }, Lines p) : ℂ) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  field_simp

/-- The actual list of small monomials in a Bonferroni truncation. -/
def truncationTerms (s : Finset P) (d : ℕ) : Finset (Σ _ : ℕ, Finset P) :=
  (Finset.range (d+1)).sigma (fun k => s.powersetCard k)

omit [DecidableEq P] in
theorem mem_truncationTerms (s : Finset P) (d : ℕ) (q : Σ _ : ℕ, Finset P) :
    q ∈ truncationTerms s d ↔ q.1 ≤ d ∧ q.2 ⊆ s ∧ q.2.card = q.1 := by
  simp [truncationTerms, Finset.mem_sigma, Finset.mem_powersetCard]

/-- Explicit sparse expansion, including the signed coefficient and an
arbitrary complex multiplier. -/
theorem truncation_eq_sparse (s : Finset P) (w : P → ℝ) (d : ℕ) (a : ℂ) :
    a*(truncation s w d : ℝ) = ∑ q ∈ truncationTerms s d,
      (-1 : ℂ)^q.1 * (a * ∏ p ∈ q.2, (w p : ℂ)) := by
  rw [truncation_eq_sum]
  simp only [Complex.ofReal_sum, Complex.ofReal_mul, Complex.ofReal_pow,
    Complex.ofReal_neg, Complex.ofReal_one, elementary, Complex.ofReal_prod,
    truncationTerms, Finset.sum_sigma, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  apply Finset.sum_congr rfl
  intro t ht
  ring

/-- A monomial multiplied by an active-prime test is a function only of
the union of the active set and the monomial's subset. -/
def coupledSubsetTest (Lines : P → Type*) (A T : Finset P)
    (a : (∀ p : A, Lines p) → ℂ) (w : ∀ p, Lines p → ℝ)
    (l : ∀ p : ↥(A ∪ T), Lines p) : ℂ :=
  a (fun p => l ⟨p, Finset.mem_union_left T p.property⟩) *
    ∏ p : T, (w p (l ⟨p, Finset.mem_union_right A p.property⟩) : ℂ)

theorem coupledSubsetTest_restrict (Lines : P → Type*) (A T : Finset P)
    (a : (∀ p : A, Lines p) → ℂ) (w : ∀ p, Lines p → ℝ)
    (l : ∀ p, Lines p) :
    coupledSubsetTest Lines A T a w (fun p => l p) =
      a (fun p => l p) * ∏ p ∈ T, (w p (l p) : ℂ) := by
  unfold coupledSubsetTest
  congr 1
  exact Finset.prod_coe_sort T (fun p => (w p (l p) : ℂ))

/-- The full independent-line expectation of each signed monomial is
exactly the subset expectation appearing in sparse root transfer. -/
theorem coupledSubsetTest_average [Fintype P]
    (Lines : P → Type*) [∀ p, Fintype (Lines p)] [∀ p, Nonempty (Lines p)]
    (A T : Finset P) (a : (∀ p : A, Lines p) → ℂ) (w : ∀ p, Lines p → ℝ) :
    (∑ l : (∀ p, Lines p), a (fun p => l p)*∏ p ∈ T, (w p (l p) : ℂ)) /
        (Fintype.card (∀ p, Lines p) : ℂ) =
      (∑ l : (∀ p : ↥(A ∪ T), Lines p), coupledSubsetTest Lines A T a w l) /
        (Fintype.card (∀ p : ↥(A ∪ T), Lines p) : ℂ) := by
  have h := complex_average_restrict Lines (A ∪ T) (coupledSubsetTest Lines A T a w)
  simpa only [coupledSubsetTest_restrict] using h



/-- The full independent expectation of the actual truncation equals the
signed sum of its small active-union-subset expectations. -/
theorem truncation_average_sparse [Fintype P]
    (Lines : P → Type*) [∀ p, Fintype (Lines p)] [∀ p, Nonempty (Lines p)]
    (A s : Finset P) (a : (∀ p : A, Lines p) → ℂ)
    (w : ∀ p, Lines p → ℝ) (d : ℕ) :
    (∑ l : (∀ p, Lines p), a (fun p => l p)*
      (truncation s (fun p => w p (l p)) d : ℝ)) /
        (Fintype.card (∀ p, Lines p) : ℂ) =
      ∑ q ∈ truncationTerms s d, (-1 : ℂ)^q.1 *
        ((∑ l : (∀ p : ↥(A ∪ q.2), Lines p), coupledSubsetTest Lines A q.2 a w l) /
          (Fintype.card (∀ p : ↥(A ∪ q.2), Lines p) : ℂ)) := by
  simp_rw [truncation_eq_sparse]
  rw [Finset.sum_comm, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro q hq
  rw [← Finset.mul_sum, mul_div_assoc, coupledSubsetTest_average]

/-- The local residue test has norm at most one when the active multiplier
and each actual loss factor have their required pointwise bounds. -/
theorem coupledSubsetTest_norm_le (Lines : P → Type*) (A T : Finset P)
    (a : (∀ p : A, Lines p) → ℂ) (w : ∀ p, Lines p → ℝ)
    (ha : ∀ l, ‖a l‖ ≤ 1) (hw : ∀ p ∈ T, ∀ l, 0 ≤ w p l ∧ w p l ≤ 1)
    (l : ∀ p : ↥(A ∪ T), Lines p) :
    ‖coupledSubsetTest Lines A T a w l‖ ≤ 1 := by
  rw [coupledSubsetTest, norm_mul, norm_prod]
  have hp : (∏ p : T, ‖(w p (l ⟨p, Finset.mem_union_right A p.property⟩) : ℂ)‖) ≤ 1 := by
    apply Finset.prod_le_one₀
    · intro p hp
      exact norm_nonneg _
    · intro p hp
      rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hw p p.property _).1]
      exact (hw p p.property _).2
  exact (mul_le_mul (ha _) hp (Finset.prod_nonneg (fun _ _ => norm_nonneg _)) (by norm_num)).trans (by norm_num)

/-- Every bounded local residue test costs at most its actual residue
matrix group cardinality in the source discrepancy estimate. -/
theorem residue_mass_le_card (X : Type*) [Fintype X] (f : X → ℂ)
    (hf : ∀ x, ‖f x‖ ≤ 1) :
    (∑ x, ‖f x‖) ≤ (Fintype.card X : ℝ) := by
  calc
    _ ≤ ∑ _x : X, (1 : ℝ) := Finset.sum_le_sum (fun x _ => hf x)
    _ = _ := by simp



/-- The actual integer-root sum of a complex-weighted truncation is the
same sparse sum whose local expectations were calculated above. -/
theorem integerRootSum_truncation_sparse (Lines : P → Type*)
    (A s : Finset P) (a : (∀ p : A, Lines p) → ℂ) (w : ∀ p, Lines p → ℝ)
    (l : Matrix.SpecialLinearGroup (Fin 2) ℤ → ∀ p, Lines p)
    (U V : ℝ) (I₁ I₂ I₃ : RootInterval) (d : ℕ) :
    integerRootSum U V I₁ I₂ I₃ (fun g =>
      a (fun p => l g p)*(truncation s (fun p => w p (l g p)) d : ℝ)) =
      ∑ q ∈ truncationTerms s d, (-1 : ℂ)^q.1 *
        integerRootSum U V I₁ I₂ I₃ (fun g =>
          coupledSubsetTest Lines A q.2 a w (fun p => l g p)) := by
  simp_rw [coupledSubsetTest_restrict, truncation_eq_sparse]
  rw [integerRootSum_sum]
  simp_rw [integerRootSum_mul]

end Elliptic.Operator.SignedBonferroniTransfer
