module

public import Elliptic.Operator.PhysicalFourierWordNorm
public import Elliptic.Operator.CanonicalBoundaryAssembly
public import Elliptic.Operator.PhysicalVacuumNorm
public import Elliptic.Operator.PhysicalLowRankWord

/-! The per-permutation low-rank term is the literal empty-memory
boundary pairing. Its scalar estimate follows from exact reindexing and
factorial Cauchy--Schwarz, with the two actual vacuum norms retained. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalLowRankBoundary
open scoped BigOperators ComplexConjugate
open PhysicalPhasedWord PhysicalFourierWord PhysicalLowRankWord ActualHistoryBirths PhysicalBirthFactors PhysicalFourierWordNorm PhysicalBagNorm CanonicalBoundaryAssembly
attribute [local instance] Classical.propDecidable
local instance lowRankBoundaryDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B N Q : ℕ} [NeZero Q]

 theorem memory_eq_empty_of_zero {X : Type*} (m : MemoryState X B) (h : m.size=0) :
    m=MemoryState.empty X B := by
  rcases m with ⟨⟨n,hn⟩,v⟩
  change n=0 at h
  subst n
  congr 1
  funext k
  exact Fin.elim0 k

 theorem state_eq_empty_of_zero (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hs : ∀i,(s.memory P Line J B i).size=0) : s=emptyState (boundaryIndex s) := by
  exact (emptyState_boundaryIndex_of_empty s hs).symm

 theorem emptyState_injective : Function.Injective (emptyState (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) := by
  intro u v h
  simpa only [emptyState_boundaryIndex] using congrArg boundaryIndex h

 theorem sum_empty_eq_sum_vacuum {R : Type*} [AddCommMonoid R]
    (F : PhysicalMemoryState (Z:=Z) P Line J B→R) :
    (∑u : BoundaryIndex I Z P J,F (emptyState u))=
      ∑s : PhysicalMemoryState (Z:=Z) P Line J B,
        if ∀i,(s.memory P Line J B i).size=0 then F s else 0 := by
  rw [←Finset.sum_filter]
  apply Finset.sum_bij (fun u _=>emptyState u)
  · intro u _
    simp
  · intro u hu v hv h
    exact emptyState_injective h
  · intro s hs
    exact ⟨boundaryIndex s,Finset.mem_univ _,(state_eq_empty_of_zero s (Finset.mem_filter.mp hs).2).symm⟩
  · intro u hu
    rfl

 variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
 variable (anchor : Z→∀i p,Line i p)
 variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
 variable (value : ∀i,P i→ℕ)

 theorem pairing_eq_full_states (a : BoundaryIndex I Z P J→ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) :
    (∑u : BoundaryIndex I Z P J,(PhysicalMemoryState.mass P Line J B ν (emptyState u):ℂ)*
      conj (a u)*F (emptyState u))=
    ∑s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s:ℂ)*conj (vacuumLift a s)*F s := by
  have h := sum_empty_eq_sum_vacuum (fun s : PhysicalMemoryState (Z:=Z) P Line J B=>
    (PhysicalMemoryState.mass P Line J B ν s:ℂ)*conj (a (boundaryIndex s))*F s)
  simp only [emptyState_boundaryIndex] at h
  rw [h]
  apply Finset.sum_congr rfl
  intro s _
  by_cases hs : ∀i,(s.memory P Line J B i).size=0 <;> simp [vacuumLift,hs]

 def term (σ : Equiv.Perm (Address I J B N)) (a b : BoundaryIndex I Z P J→ℂ) : ℂ :=
  ∑u : BoundaryIndex I Z P J,(PhysicalMemoryState.mass P Line J B ν (emptyState u):ℂ)*conj (a u)*
    ∑h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) (emptyState u),
      if BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
        then h.weight*vacuumLift b h.final else 0

 theorem term_norm_le_history_l2 (hν : ∀i p,0≤ν i p)
    (σ : Equiv.Perm (Address I J B N)) (a b : BoundaryIndex I Z P J→ℂ) :
    ‖term ν V η q ρ anchor geometry value σ a b‖≤
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (vacuumLift a)*
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (fun s=>∑h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
        if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
          then h.weight*vacuumLift b h.final else 0) := by
  unfold term
  rw [pairing_eq_full_states ν a
    (fun s=>∑h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
      if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
        then h.weight*vacuumLift b h.final else 0)]
  have hμ (s : PhysicalMemoryState (Z:=Z) P Line J B) : 0≤PhysicalMemoryState.mass P Line J B ν s := by
    unfold PhysicalMemoryState.mass
    apply Finset.prod_nonneg
    intro i _
    apply mul_nonneg (Finset.prod_nonneg (fun k _=>hν i _))
    unfold MemoryState.mass anchoredParticleMass
    exact div_nonneg (Finset.prod_nonneg (fun k _=>hν i _)) (by positivity)
  have h := finite_measured_pairing_le Finset.univ (PhysicalMemoryState.mass P Line J B ν)
    (fun s _=>hμ s) (fun s=>conj (vacuumLift a s))
    (fun s=>∑h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
      if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
        then h.weight*vacuumLift b h.final else 0)
  simpa only [finiteL2,finiteL2Sq,Complex.norm_conj] using h

 theorem vacuum_isBagFunction (b : BoundaryIndex I Z P J→ℂ) :
    IsBagFunction (vacuumLift (Line:=Line) (B:=B) b) := by
  apply (isBagFunction_iff _).mpr
  refine ⟨fun z a bags=>if ∀i,(bags i).card=0 then b (z,a) else 0,?_⟩
  funext t
  simp only [physicalBagFunction,tupleBag_card,Fintype.card_fin,vacuumLift,boundaryIndex]

 theorem term_norm_le_of_word_bound (hν : ∀i p,0≤ν i p) (hvalue : ∀i p,value i p<Q)
    (σ : Equiv.Perm (Address I J B N)) (a b : BoundaryIndex I Z P J→ℂ)
    (C : ℝ) (hC : 0≤C)
    (hword : ∀θ : Address I J B N→ZMod Q,
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (PhysicalPhasedWord.word ν V η q ρ anchor geometry value
          (PhysicalFourierWord.ghostPhase σ θ) (PhysicalFourierWord.edgePhase σ θ) N 0 (vacuumLift b))≤
      C*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (vacuumLift b)) :
    ‖term ν V η q ρ anchor geometry value σ a b‖≤
      C*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (vacuumLift a)*
        finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (vacuumLift b) := by
  apply (term_norm_le_history_l2 ν V η q ρ anchor geometry value hν σ a b).trans
  have hh := birthPreserving_l2_le_of_word_bound ν V η q ρ anchor geometry value hν hvalue σ
    (vacuumLift b) _ (mul_nonneg hC (Real.sqrt_nonneg _)) hword
  exact (mul_le_mul_of_nonneg_left hh (Real.sqrt_nonneg _)).trans_eq (by unfold finiteL2; ring)

 theorem term_position_norm_le_of_word_bound (hν : ∀i p,0≤ν i p) (hvalue : ∀i p,value i p<Q)
    (hmass : (∏i,(∑p,ν i p)^(J+1))≤2)
    (σ : Equiv.Perm (Address I J B N)) (z₀ z₁ : Z) (a b : PhysicalActiveLists P J→ℂ)
    (ha : ∀t,‖a t‖≤1) (hb : ∀t,‖b t‖≤1) (C : ℝ) (hC : 0≤C)
    (hword : ∀θ : Address I J B N→ZMod Q,
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (PhysicalPhasedWord.word ν V η q ρ anchor geometry value
          (PhysicalFourierWord.ghostPhase σ θ) (PhysicalFourierWord.edgePhase σ θ) N 0
          (vacuumLift (fun u=>if u.1=z₁ then b u.2 else 0)))≤
      C*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (vacuumLift (fun u=>if u.1=z₁ then b u.2 else 0))) :
    ‖term ν V η q ρ anchor geometry value σ
      (fun u=>if u.1=z₀ then a u.2 else 0) (fun u=>if u.1=z₁ then b u.2 else 0)‖≤2*C := by
  apply (term_norm_le_of_word_bound ν V η q ρ anchor geometry value hν hvalue σ _ _ C hC hword).trans
  have hA := vacuumLift_position_l2_le_sqrt_two (Line:=Line) (B:=B) ν hν hmass z₀ a ha
  have hB := vacuumLift_position_l2_le_sqrt_two (Line:=Line) (B:=B) ν hν hmass z₁ b hb
  calc
    _ ≤ C*Real.sqrt 2*Real.sqrt 2 := mul_le_mul
      (mul_le_mul_of_nonneg_left hA hC) hB (Real.sqrt_nonneg _) (by positivity)
    _ = 2*C := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2)]

 theorem actual_term_position_norm_le
    (σ : Equiv.Perm (Address I J B N))
    (Qghost Vmax M good bad : ℝ)
    (hν : ∀i p,0<ν i p) (hmass : ∀i,(∑p,ν i p)≤M) (hM : 0≤M)
    (hρ : 0<ρ) (hQ : Qghost<ρ^2) (hq0 : ∀j,0≤q j) (hqQ : ∀j,q j≤Qghost)
    (hη0 : ∀j,0≤η j) (hη1 : ∀j,η j≤1) (hV0 : ∀i,0≤V i) (hVmax : ∀i,V i≤Vmax)
    (hgood : 0≤good) (hgood1 : good≤1) (hbad : 1≤bad)
    (hplain : ∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        ((physicalEdgeOperation ν V ρ anchor (geometry j)).apply F)≤
      good*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (hmodified : ∀(θ : Address I J B N→ZMod Q),∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
          (fun _ c=>edgeFactor value (edgePhase σ θ) j c) F)≤
      bad*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (hvalue : ∀i p,value i p<Q) (hmassTwo : (∏i,(∑p,ν i p)^(J+1))≤2)
    (z₀ z₁ : Z) (a b : PhysicalActiveLists P J→ℂ)
    (ha : ∀t,‖a t‖≤1) (hb : ∀t,‖b t‖≤1) :
    ‖term ν V η q ρ anchor geometry value σ
      (fun u=>if u.1=z₀ then a u.2 else 0) (fun u=>if u.1=z₁ then b u.2 else 0)‖≤
    2*(((Real.exp (ghostSchurWeight ρ Qghost Vmax*max 1 Vmax*M/ρ))^(Fintype.card I))^(N+1)*
      bad^(2*birthCycleRank σ)*good^(N-2*birthCycleRank σ)) := by
  apply term_position_norm_le_of_word_bound ν V η q ρ anchor geometry value
    (fun i p=>(hν i p).le) hvalue hmassTwo σ z₀ z₁ a b ha hb _
    (mul_nonneg (mul_nonneg (by positivity) (pow_nonneg (by linarith) _)) (pow_nonneg hgood _))
  intro θ
  exact actual_fourier_word_l2_le ν V η q ρ anchor geometry value σ θ Qghost Vmax M good bad
    hν hmass hM hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax hgood hgood1 hbad hplain (hmodified θ)
    _ (vacuum_isBagFunction _)

end Elliptic.Operator.PhysicalLowRankBoundary
