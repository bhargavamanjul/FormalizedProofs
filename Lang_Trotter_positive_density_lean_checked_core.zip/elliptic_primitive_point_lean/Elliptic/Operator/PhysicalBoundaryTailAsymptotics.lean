module

public import Elliptic.Operator.OriginalBoundaryTail
public import Elliptic.Operator.UniformMemoryTruncation
public import Elliptic.Operator.PhysicalVacuumNorm
public import Elliptic.Operator.MomentBounds

/-! Uniform logarithmic savings for the actual capped boundary pairing.
The initial boundary mass is retained explicitly and bounded by two; for
the source position vacuum this is the proved transformed-band estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open Filter
open scoped BigOperators
open CanonicalBoundaryAssembly OriginalLeaf IndependentLineNormalization
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

theorem eventually_boundary_cap_tail
    (I : Type) [Fintype I] (ρ Q Vmin Vmax s G C A : ℝ)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hVmin : 0<Vmin) (hs0 : 0≤s) (hG : 0≤G) (hA : 0≤A) :
    ∀ᶠ L : ℝ in atTop,
      ∀(Z : Type) [Fintype Z] (P : I→Type) [∀i,Fintype (P i)]
        (Line : ∀i,P i→Type) (J B : ℕ) (H : ℝ) (position : Z↪ℤ×ℤ)
        (value : ∀i,P i→ℕ) (ν μ : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ)
        (anchor : Z→∀i p,Line i p)
        (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ),
      0≤H→H≤Real.exp (C*L^(21/100:ℝ))→
      (∀z,position z∈integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊)→
      Function.Injective (fun z:Sigma P=>value z.1 z.2)→
      (∀j z a w b,geometry j z a w b≠0→∀i (k:Fin J),
        anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))→
      (∀j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)→
      (∀i p,0≤ν i p)→(∀i,(∑p,ν i p)≤s)→
      (∀i,Vmin≤V i)→(∀i,V i≤Vmax)→
      (∀j,0≤q j)→(∀j,q j≤Q)→(∀j,0≤η j)→(∀j,η j≤1)→
      (∀i p,V i*ν i p=μ i p)→
      (∀j z a w b,‖geometry j z a w b‖≤G)→memoryCutoff L≤B→
      ∀a b : BoundaryIndex I Z P J→ℂ,
      initialBoundaryNorm (Line:=Line) (B:=B) ν a≤2→(∀x,‖b x‖≤1)→
      ‖boundaryPairing (B:=B) ν V η q ρ anchor geometry value (momentLength L) a b-
        boundaryPairing (B:=memoryCutoff L) ν V η q ρ anchor geometry value (momentLength L) a b‖≤
        L^(-A*(momentLength L:ℝ)) := by
  let v0 := ghostSchurWeight ρ Q (2*Vmax)
  let R := (1+v0)*(s+Vmin⁻¹/(v0*(1-ρ)))
  let gmax := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
  let Cbase := G*R^(Fintype.card I)
  have hv0 : 0<v0 := ghostSchurWeight_pos ρ Q (2*Vmax) hρ hQ
  have hR : 0≤R := by dsimp [R]; positivity
  have hbase : 0≤Cbase := mul_nonneg hG (pow_nonneg hR _)
  filter_upwards [eventually_truncation_with_position_box (Fintype.card I)
    gmax Cbase C (A+1) hbase (by linarith),eventually_ge_atTop (2:ℝ)] with L hL hL2
  intro Z instZ P instP Line J B H position value ν μ V η q anchor geometry
    hH hHC hposition hvalue hshared hban hν hs hVmin' hVmax hq0 hqQ hη0 hη1 hνμ hgeometry hTB a b ha hb
  letI : Fintype Z := instZ
  letI : ∀i,Fintype (P i) := instP
  have hVp : ∀i,0<V i := fun i=>hVmin.trans_le (hVmin' i)
  have hV0 : ∀i,0≤V i := fun i=>(hVp i).le
  have htail := boundary_cap_tail_explicit value ν μ V η q ρ Q Vmax s G geometry
    hvalue hshared hban hν hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0
    (fun i=>(hVp i).ne') hVmax hνμ hG hgeometry (memoryCutoff L) hTB hL.1 a b hb
  let edge := (Fintype.card Z:ℝ)*G*∏i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
  have hedge0 : 0≤edge := mul_nonneg (mul_nonneg (Nat.cast_nonneg _) hG)
    (Finset.prod_nonneg fun i _=>physicalEdgeLocalRowConstant_nonneg
      (ν i) (V i) ρ v0 (hν i) (hV0 i) hρ1 hv0)
  have hprod : (∏i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0)≤R^(Fintype.card I) := by
    calc
      _ ≤ ∏_i:I,R := Finset.prod_le_prod₀
        (fun i _=>physicalEdgeLocalRowConstant_nonneg (ν i) (V i) ρ v0 (hν i) (hV0 i) hρ1 hv0)
        (fun i _=>physicalEdgeLocalRowConstant_le_uniform (ν i) (V i) Vmin ρ v0 s
          hVmin (hVmin' i) hρ1 hv0 (hs i))
      _ = _ := by simp
  have hcard : Fintype.card Z≤(integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊).card := by
    let f : Z→↥(integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊) := fun z=>⟨position z,hposition z⟩
    have hf : Function.Injective f := fun z w h=>position.injective (congrArg Subtype.val h)
    simpa using Fintype.card_le_of_injective f hf
  have hedge : edge≤Cbase*((integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊).card:ℝ) := by
    have hc : (Fintype.card Z:ℝ)≤(integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊).card := by
      exact_mod_cast hcard
    dsimp [edge,Cbase]
    calc
      _ ≤ ((integerPositionBox ⌈16+4096*(momentLength L:ℝ)*H⌉₊).card:ℝ)*G*R^(Fintype.card I) := by
        gcongr
        exact Finset.prod_nonneg fun i _=>physicalEdgeLocalRowConstant_nonneg
          (ν i) (V i) ρ v0 (hν i) (hV0 i) hρ1 hv0
      _ = _ := by ring
  have hnum := hL.2 H gmax edge hH hHC (by dsimp [gmax]; positivity) hedge0 le_rfl hedge
  have hnonneg : 0≤((2:ℝ)^(memoryCutoff L-Fintype.card I*momentLength L))⁻¹ *
      (gmax^(momentLength L+1)*edge^momentLength L) := by positivity
  exact htail.trans ((mul_le_mul_of_nonneg_right ha hnonneg).trans
    ((mul_le_mul_of_nonneg_left hnum (by norm_num)).trans
      (two_mul_rpow_moment_le hL2 (momentLength_pos (by linarith)))))

/-- The exact independent-line identity transfers an actual cap-tail
estimate without loss when the baseline product is at most one. -/
theorem independent_path_sum_small_cap_error_of_tail
    {I Z : Type} [Fintype I] [Fintype Z] {P : I→Type} [∀i,Fintype (P i)]
    {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B N : ℕ}
    (value : ∀i,P i→ℕ) (ν : ∀i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hvalue : Function.Injective (fun z:Sigma P=>value z.1 z.2))
    (hshared : ∀j z a w b,geometry j z a w b≠0→∀i (k:Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (hρ : ρ≠0) (hV : ∀i,V i≠0) (hN : 0<N)
    (hn : ∀i p,(Fintype.card (Line i p):ℝ)≠0)
    (hbase : ∀i p,(Fintype.card (Line i p):ℝ)-∑j∈Finset.range (N+1),η j≠0)
    (hν : ∀i p,V i*ν i p=normalizedLineMass (Finset.range (N+1)) η (Fintype.card (Line i p)))
    (hB : (∑i,Fintype.card (P i))≤B) (T : ℕ) (a b : BoundaryIndex I Z P J→ℂ)
    (ε : ℝ) (hε : 0≤ε)
    (hbaseline : |∏i,∏p,baseline (Finset.range (N+1)) η (Fintype.card (Line i p))|≤1)
    (htail : ‖boundaryPairing (B:=B) ν V η (fun j=>1-η j) ρ anchor geometry value N a b-
      boundaryPairing (B:=T) ν V η (fun j=>1-η j) ρ anchor geometry value N a b‖≤ε) :
    ‖(∑r:OriginalPath I Z P J N,r.boundaryFactor geometry V a b*(r.independentAverage anchor η:ℂ))-
      ((∏i,∏p,baseline (Finset.range (N+1)) η (Fintype.card (Line i p)):ℝ):ℂ)*
        boundaryPairing (B:=T) ν V η (fun j=>1-η j) ρ anchor geometry value N a b‖≤ε := by
  rw [all_independent_paths_eq_baseline_boundary value ν V η ρ geometry hvalue hshared hban
    hρ hV hN hn hbase hν hB,←mul_sub,norm_mul,Complex.norm_real,Real.norm_eq_abs]
  exact (mul_le_mul_of_nonneg_left htail (abs_nonneg _)).trans
    ((mul_le_mul_of_nonneg_right hbaseline hε).trans_eq (one_mul ε))

/-- The concrete source position boundary satisfies the initial mass
condition in the cap-tail theorem, uniformly over all finite bands. -/
theorem eventually_transformed_initialBoundaryNorm_le_two (K : ℕ) :
    ∀ᶠ L : ℝ in atTop,∀(I Z : Type) [Fintype I] [Fintype Z],
      Fintype.card I=K→∀(pmin : ℝ) (η : Fin (momentLength L+1)→ℝ)
      (groups : I→Finset ℕ) (V : I→ℝ)
      (Line : ∀i,{p // p∈groups i}→Type) [∀i p,Fintype (Line i p)] (B : ℕ),
      (∀i,0<V i)→(∀i,V i=∑p∈groups i,1/(p:ℝ))→
      Real.exp (L^(1/10:ℝ))≤pmin→(∀i p,p∈groups i→pmin≤(p:ℝ))→(∀j,η j≤1)→
      ∀(z₀ : Z) (a : PhysicalActiveLists (fun i=>{p // p∈groups i}) (momentPadding L)→ℂ),
      (∀t,‖a t‖≤1)→
      initialBoundaryNorm (Line:=Line) (B:=B)
        (fun i p=>transformedPrimeMass Finset.univ η (V i) p.val)
        (fun u=>if u.1=z₀ then a u.2 else 0)≤2 := by
  filter_upwards [eventually_transformed_boundary_mass_le_two K,
    eventually_memory_visits_le_prime_cutoff] with L hmass hsize
  intro I Z _ _ hI pmin η groups V Line _ B hV hVsum hmin hp hη z₀ a ha
  have hpmin : 0<pmin := (Real.exp_pos _).trans_le hmin
  have hν : ∀i (p:{p // p∈groups i}),0≤transformedPrimeMass Finset.univ η (V i) p.val := by
    intro i p
    exact (transformedPrimeMass_sharp_bound Finset.univ η (V i) pmin p.val
      (hV i) hpmin (hp i p.val p.property) (fun j _=>hη j)
      (by simpa using hsize.trans hmin)).1
  apply (initialBoundaryNorm_position_le _ hν z₀ a ha).trans
  have hm := hmass I hI pmin η groups V hV hVsum hmin hp hη
  have he i : (∑p:{p // p∈groups i},transformedPrimeMass Finset.univ η (V i) p.val)=
      ∑p∈groups i,transformedPrimeMass Finset.univ η (V i) p :=
    (Finset.sum_subtype (groups i) (fun _=>Iff.rfl) _).symm
  simp only [he]
  exact hm

end Elliptic.Operator.OriginalLifespanSchedule
