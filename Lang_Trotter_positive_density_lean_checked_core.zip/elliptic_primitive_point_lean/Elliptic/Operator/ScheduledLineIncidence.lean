module

public import Elliptic.Operator.ScheduledActiveBirths
public import Elliptic.Operator.ScheduledHistoryConverse
public import Elliptic.Operator.SharedLineRetention

/-!
# Retained lines at every active visit

The raw scheduled history fixes lines at ghost births, ghost deaths,
stores and promotions.  It does not fix a line at a fresh active birth.
The actual shared pad support propagates birth lines to every active
visit.  A canonical normalization, changing only wholly active primes
which never enter memory, supplies the missing birth anchors and preserves
all chronological coefficients and compatible actual histories.

This file does not assert that an arbitrary unanchored raw schedule is
canonically extracted from the original operator expansion.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance scheduledLineIncidenceDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Reversing the edge swaps its two unshared slots and keeps the shared
slots, so the literal numerical cross-edge ban is symmetric. -/
theorem sourceCrossEdgeBan_symm {I : Type*} {P : I → Type*} {J : ℕ}
    (value : ∀ i, P i → ℕ) {a b : PhysicalActiveLists P J}
    (h : sourceCrossEdgeBan value a b) : sourceCrossEdgeBan value b a := by
  let flip : I × (Fin J ⊕ Bool) → I × (Fin J ⊕ Bool) :=
    fun x => (x.1, x.2.map id Bool.not)
  have hflip : ∀ x, flip (flip x) = x := by
    rintro ⟨i, k | t⟩
    · rfl
    · cases t <;> rfl
  have hvalue : ∀ x, sourceCrossEdgeLabels value b a x =
      sourceCrossEdgeLabels value a b (flip x) := by
    rintro ⟨i, k | t⟩
    · exact congrArg (value i) (h.1 i k)
    · cases t <;> rfl
  refine ⟨fun i k => (h.1 i k).symm, ?_⟩
  intro x y hxy
  have he := h.2 ((hvalue x).symm.trans (hxy.trans (hvalue y)))
  simpa only [hflip] using congrArg flip he

/-- Nonzero actual geometric support supplies the cross-edge ban in
either orientation, including on adjoint edges. -/
theorem orientedSourceEdgeGeometry_nonzero_crossEdgeBan
    {I : Type*} [Fintype I] {P : I → Type*} {J : ℕ}
    (adjoint : Bool) (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (h : orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ major σ
      z a w b ≠ 0) : sourceCrossEdgeBan value a b := by
  have hallowed : ∀ z w a b,
      sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b ≠ 0 →
      sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
    intro z w a b hn
    by_contra hnot
    simp [sourcePhysicalEdgeGeometry, hnot] at hn
  cases adjoint with
  | false =>
    apply (hallowed z w a b ?_).2.2.2.2.1
    simpa only [orientedSourceEdgeGeometry, Bool.false_eq_true, ite_false] using h
  | true =>
    apply sourceCrossEdgeBan_symm value
    apply (hallowed w z b a ?_).2.2.2.2.1
    simpa only [orientedSourceEdgeGeometry, ite_true, ne_eq, star_eq_zero] using h

namespace ScheduledPhysicalPath
variable {I Z : Type} [Fintype I] {P : I → Type}
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}
variable (d : ScheduledPhysicalPath anchor N J B)

/-- The missing local normalization: a fresh active label retains its
actual residue line at the unique birth visit. -/
def ActiveBirthAnchored : Prop :=
  ∀ j, j ≤ N → ∀ i p, p ∈ activeBirths (d.primes i) (d.lifespan i) j →
    d.retained i p = anchor (d.position j) i p

/-- A prime present on both sides of an edge must occupy a genuine shared
slot, once the new target is excluded from the previous active list. -/
theorem shared_slot_of_active_consecutive (j : ℕ) (hj : j < N) (i : I) (p : P i)
    (hp : p ∈ d.primes i) (hprev : j ∈ (d.lifespan i p).active)
    (hnext : j+1 ∈ (d.lifespan i p).active)
    (hnew : ∀ k, d.targetPrime j i ≠ d.active j i k) :
    ∃ t : Fin J, d.sourceLists j i t.castSucc = p := by
  obtain ⟨k,hk⟩ := (d.active_lifespan (j+1) hj i p).mp ⟨hp,hnext⟩
  rw [d.active_next j hj i k] at hk
  by_cases hlast : d.targetPerm j i k = Fin.last J
  · have ht : d.targetPrime j i = p := by
      simpa only [hlast,Fin.lastCases_last] using hk
    obtain ⟨k',hk'⟩ := (d.active_lifespan j hj.le i p).mp ⟨hp,hprev⟩
    exact (hnew k' (ht.trans hk'.symm)).elim
  · obtain ⟨t,ht⟩ := Fin.eq_castSucc_of_ne_last hlast
    rw [← ht,Fin.lastCases_castSucc] at hk
    exact ⟨t,hk⟩

/-- Birth anchors, existing promotion anchors, and actual shared-slot
transport imply the retained-line equality at every active visit. -/
theorem retained_eq_anchor_of_active (hbirth : d.ActiveBirthAnchored)
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (hshared : ∀ j, j < N → ∀ i (t : Fin J),
      anchor (d.position j) i (d.sourceLists j i t.castSucc) =
        anchor (d.position (j+1)) i (d.sourceLists j i t.castSucc))
    (j : ℕ) (hj : j ≤ N) (i : I) (p : P i)
    (hp : p ∈ d.primes i) (ha : j ∈ (d.lifespan i p).active) :
    d.retained i p = anchor (d.position j) i p := by
  induction j with
  | zero =>
    apply hbirth 0 hj i p
    refine Finset.mem_filter.mpr ⟨hp,?_,ha⟩
    have hb := ((d.lifespan i p).active_bounds 0 ha).1
    omega
  | succ j ih =>
    have hj' : j < N := by omega
    by_cases hprev : j ∈ (d.lifespan i p).active
    · have hline := ih (by omega) hprev
      obtain ⟨t,ht⟩ := d.shared_slot_of_active_consecutive j hj' i p hp hprev ha
        (hnew j hj' i)
      have htransport := hshared j hj' i t
      rw [ht] at htransport
      exact hline.trans htransport
    · rcases (d.lifespan i p).active_run_start_succ j ha hprev with hf | hprom
      · exact hbirth (j+1) hj i p (Finset.mem_filter.mpr ⟨hp,hf⟩)
      · exact d.promote_line j hj' i p (Finset.mem_filter.mpr ⟨hp,hprom⟩)

/-- The existing ghost-birth condition and fresh-active anchoring together
fix the retained line of every used prime at its unique birth. -/
theorem retained_eq_birth_anchor (hbirth : d.ActiveBirthAnchored) (i : I) (p : P i)
    (hp : p ∈ d.primes i) :
    d.retained i p = anchor (d.position (d.lifespan i p).birth) i p := by
  have hb : (d.lifespan i p).birth ≤ N :=
    (d.lifespan i p).birth_le_death.trans (d.lifespan i p).death_le
  by_cases ha : (d.lifespan i p).birth ∈ (d.lifespan i p).active
  · exact hbirth _ hb i p (Finset.mem_filter.mpr ⟨hp,rfl,ha⟩)
  · exact d.birth_line _ hb i p (Finset.mem_filter.mpr ⟨hp,rfl,ha⟩)

/-- Fresh-active anchoring is precisely canonical birth-line selection
for used primes; ghost births were already anchored in the raw schedule. -/
theorem activeBirthAnchored_iff_birth_anchor : d.ActiveBirthAnchored ↔
    ∀ i p, p ∈ d.primes i →
      d.retained i p = anchor (d.position (d.lifespan i p).birth) i p := by
  constructor
  · exact d.retained_eq_birth_anchor
  · intro h j hj i p hp
    obtain ⟨hp,hj',_⟩ := Finset.mem_filter.mp hp
    simpa only [hj'] using h i p hp

/-- Under actual transport and target exclusion, anchoring only at births
is equivalent to the full all-active incidence condition. -/
theorem activeBirthAnchored_iff_all_active
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (hshared : ∀ j, j < N → ∀ i (t : Fin J),
      anchor (d.position j) i (d.sourceLists j i t.castSucc) =
        anchor (d.position (j+1)) i (d.sourceLists j i t.castSucc)) :
    d.ActiveBirthAnchored ↔
      ∀ j, j ≤ N → ∀ i p, p ∈ d.primes i → j ∈ (d.lifespan i p).active →
        d.retained i p = anchor (d.position j) i p := by
  constructor
  · intro hb
    exact d.retained_eq_anchor_of_active hb hnew hshared
  · intro h j hj i p hp
    obtain ⟨hp,_,ha⟩ := Finset.mem_filter.mp hp
    exact h j hj i p hp ha

/-- An active run which eventually enters memory is already pinned by
its first store.  Shared-slot transport carries that line backwards.
This requires no fresh-birth anchoring assumption. -/
theorem retained_eq_anchor_of_future_gap
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (hshared : ∀ j, j < N → ∀ i (t : Fin J),
      anchor (d.position j) i (d.sourceLists j i t.castSucc) =
        anchor (d.position (j+1)) i (d.sourceLists j i t.castSucc))
    (i : I) (p : P i) (hp : p ∈ d.primes i)
    (j : ℕ) (hj : j ≤ N) (ha : j ∈ (d.lifespan i p).active)
    (hgap : ∃ k, j < k ∧ k ≤ (d.lifespan i p).death ∧ k ∉ (d.lifespan i p).active) :
    d.retained i p = anchor (d.position j) i p := by
  have main : ∀ j, j ≤ N → j ∈ (d.lifespan i p).active →
      (∃ k, j < k ∧ k ≤ (d.lifespan i p).death ∧ k ∉ (d.lifespan i p).active) →
      d.retained i p = anchor (d.position j) i p := by
    intro j hj
    induction hj using Nat.decreasingInduction with
    | self =>
      intro ha ⟨k,hk,hd,_⟩
      have := (d.lifespan i p).death_le
      omega
    | of_succ j hj ih =>
      intro ha ⟨k,hk,hd,hgap⟩
      by_cases hnext : j+1 ∈ (d.lifespan i p).active
      · have hk' : j+1 < k := by
          have hne : k ≠ j+1 := fun he => hgap (he ▸ hnext)
          omega
        have hline := ih hnext ⟨k,hk',hd,hgap⟩
        obtain ⟨t,ht⟩ := d.shared_slot_of_active_consecutive j hj i p hp ha hnext
          (hnew j hj i)
        have htransport := hshared j hj i t
        rw [ht] at htransport
        exact hline.trans htransport.symm
      · apply d.store_line j hj i p
        exact Finset.mem_filter.mpr ⟨hp,ha,by omega,hnext⟩
  exact main j hj ha hgap

/-- A prime is wholly active when it never enters pending memory during
its lifespan.  Its arbitrary raw retained coordinate is then unobserved. -/
def FullyActive (i : I) (p : P i) : Prop :=
  ∀ j, (d.lifespan i p).birth ≤ j → j ≤ (d.lifespan i p).death →
    j ∈ (d.lifespan i p).active

/-- Select the birth anchor only for wholly active primes.  Retained
coordinates of every prime which ever enters memory are untouched. -/
def canonicalRetained (i : I) (p : P i) : Line i p :=
  if d.FullyActive i p then anchor (d.position (d.lifespan i p).birth) i p
  else d.retained i p

theorem canonicalRetained_eq_of_inactive (i : I) (p : P i) (j : ℕ)
    (hb : (d.lifespan i p).birth ≤ j) (hd : j ≤ (d.lifespan i p).death)
    (ha : j ∉ (d.lifespan i p).active) : d.canonicalRetained i p = d.retained i p := by
  have hn : ¬d.FullyActive i p := fun h => ha (h j hb hd)
  simp only [canonicalRetained,hn,ite_false]

/-- Birth-line normalization is an actual new raw schedule with all old
positions, labels, lifespans, permutations and flags.  Its existing line
constraints are proved from the old ones. -/
def canonicalizeRetained : ScheduledPhysicalPath anchor N J B :=
  { d with
    retained := d.canonicalRetained
    death_line := by
      intro j hj i p hp
      obtain ⟨_,hdeath,ha⟩ := Finset.mem_filter.mp hp
      rw [d.canonicalRetained_eq_of_inactive i p j
        (by simpa only [hdeath] using (d.lifespan i p).birth_le_death)
        (by omega) ha]
      exact d.death_line j hj i p hp
    birth_line := by
      intro j hj i p hp
      obtain ⟨_,hbirth,ha⟩ := Finset.mem_filter.mp hp
      rw [d.canonicalRetained_eq_of_inactive i p j (by omega)
        (by simpa only [hbirth] using (d.lifespan i p).birth_le_death) ha]
      exact d.birth_line j hj i p hp
    store_line := by
      intro j hj i p hp
      obtain ⟨_,ha,hd,hn⟩ := Finset.mem_filter.mp hp
      rw [d.canonicalRetained_eq_of_inactive i p (j+1)
        (by have := ((d.lifespan i p).active_bounds j ha).1; omega) hd hn]
      exact d.store_line j hj i p hp
    promote_line := by
      intro j hj i p hp
      obtain ⟨_,ha,hb,hn⟩ := Finset.mem_filter.mp hp
      rw [d.canonicalRetained_eq_of_inactive i p j (by omega)
        (by have := ((d.lifespan i p).active_bounds (j+1) ha).2; omega) hn]
      exact d.promote_line j hj i p hp }

/-- Canonical normalization supplies fresh-active anchoring without an
additional assumption: a later gap pins the old line by a store, while a
wholly active prime receives its actual birth line by definition. -/
theorem canonicalizeRetained_activeBirthAnchored
    (hnew : ∀ j, j < N → ∀ i k, d.targetPrime j i ≠ d.active j i k)
    (hshared : ∀ j, j < N → ∀ i (t : Fin J),
      anchor (d.position j) i (d.sourceLists j i t.castSucc) =
        anchor (d.position (j+1)) i (d.sourceLists j i t.castSucc)) :
    d.canonicalizeRetained.ActiveBirthAnchored := by
  intro j hj i p hp
  change p ∈ activeBirths (d.primes i) (d.lifespan i) j at hp
  obtain ⟨hp,hj',ha⟩ := Finset.mem_filter.mp hp
  change d.canonicalRetained i p = anchor (d.position j) i p
  by_cases hfull : d.FullyActive i p
  · simp only [canonicalRetained,hfull,ite_true,hj']
  · simp only [canonicalRetained,hfull,ite_false]
    apply d.retained_eq_anchor_of_future_gap hnew hshared i p hp j hj ha
    simp only [FullyActive] at hfull
    push Not at hfull
    obtain ⟨k,hb,hd,hna⟩ := hfull
    refine ⟨k,?_,hd,hna⟩
    have hne : k ≠ j := fun he => hna (he ▸ ha)
    omega

theorem canonicalRetained_eq_of_before (j : ℕ) (i : I) (p : P i)
    (hp : p ∈ before (d.primes i) (d.lifespan i) j) :
    d.canonicalRetained i p = d.retained i p := by
  obtain ⟨_,hb,hd,ha⟩ := Finset.mem_filter.mp hp
  exact d.canonicalRetained_eq_of_inactive i p j hb.le hd ha

theorem canonicalRetained_eq_of_after (j : ℕ) (i : I) (p : P i)
    (hp : p ∈ after (d.primes i) (d.lifespan i) j) :
    d.canonicalRetained i p = d.retained i p := by
  obtain ⟨_,hb,hd,ha⟩ := Finset.mem_filter.mp hp
  exact d.canonicalRetained_eq_of_inactive i p j hb hd.le ha

theorem canonicalRetained_before_filter (j : ℕ) (i : I) (z : Z) :
    (before (d.primes i) (d.lifespan i) j).filter
      (fun p => d.canonicalRetained i p = anchor z i p) =
    (before (d.primes i) (d.lifespan i) j).filter
      (fun p => d.retained i p = anchor z i p) := by
  apply Finset.filter_congr
  intro p hp
  rw [d.canonicalRetained_eq_of_before j i p hp]

theorem canonicalRetained_after_filter (j : ℕ) (i : I) (z : Z) :
    (after (d.primes i) (d.lifespan i) j).filter
      (fun p => d.canonicalRetained i p = anchor z i p) =
    (after (d.primes i) (d.lifespan i) j).filter
      (fun p => d.retained i p = anchor z i p) := by
  apply Finset.filter_congr
  intro p hp
  rw [d.canonicalRetained_eq_of_after j i p hp]

theorem canonicalRetained_surviving_filter (j : ℕ) (i : I) (z : Z) :
    (before (d.primes i) (d.lifespan i) j \ deaths (d.primes i) (d.lifespan i) j).filter
      (fun p => d.canonicalRetained i p = anchor z i p) =
    (before (d.primes i) (d.lifespan i) j \ deaths (d.primes i) (d.lifespan i) j).filter
      (fun p => d.retained i p = anchor z i p) := by
  apply Finset.filter_congr
  intro p hp
  rw [d.canonicalRetained_eq_of_before j i p (Finset.mem_sdiff.mp hp).1]

/-- Normalizing unobserved retained coordinates preserves every signed
ghost coefficient, including all old-particle hit powers. -/
theorem canonicalizeRetained_ghostFactor [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ) (j : ℕ) :
    d.canonicalizeRetained.ghostFactor ν V η q ρ j = d.ghostFactor ν V η q ρ j := by
  simp only [ghostFactor,canonicalizeRetained,d.canonicalRetained_surviving_filter]

/-- Normalization also preserves every edge coefficient, for arbitrary
geometric factors, prime masses and damping parameters. -/
theorem canonicalizeRetained_edgeFactor [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (j : ℕ) :
    d.canonicalizeRetained.edgeFactor ν V ρ geometry j = d.edgeFactor ν V ρ geometry j := by
  have hs : d.canonicalizeRetained.sourceLists j = d.sourceLists j := rfl
  have ht : d.canonicalizeRetained.targetLists j = d.targetLists j := rfl
  unfold edgeFactor
  rw [hs,ht]
  simp only [canonicalizeRetained,
    d.canonicalRetained_before_filter,d.canonicalRetained_after_filter]

/-- Consequently the complete chronological coefficient is unchanged,
not only its separate local factors. -/
theorem canonicalizeRetained_coefficientProduct [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (n j : ℕ) :
    d.canonicalizeRetained.coefficientProduct ν V η q ρ geometry n j =
      d.coefficientProduct ν V η q ρ geometry n j := by
  induction n generalizing j with
  | zero => exact d.canonicalizeRetained_ghostFactor ν V η q ρ j
  | succ n ih =>
    simp only [coefficientProduct,d.canonicalizeRetained_ghostFactor,
      d.canonicalizeRetained_edgeFactor,ih]

/-- The normalization does not create or remove any compatible actual
history.  Compatibility tests literal choices and is independent of the
unused retained coordinates which were normalized. -/
theorem canonicalizeRetained_compatible [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s) :
    d.canonicalizeRetained.Compatible ν V η q ρ geometry n j s h ↔
      d.Compatible ν V η q ρ geometry n j s h := by
  induction n generalizing j s with
  | zero => rfl
  | succ n ih =>
    exact and_congr Iff.rfl (and_congr Iff.rfl (ih (j+1) _ h.2.2))

end ScheduledPhysicalPath

namespace ScheduledPhysicalPath
variable {I Z : Type} [Fintype I] {P : I → Type} {J B N : ℕ}

/-- On nonzero support of the literal source geometry, no abstract
shared-line or target-exclusion hypotheses are needed.  They follow from
the prime pad, primitive positions and numerical cross-edge ban.  The
sole additional retained-line condition is fresh-active birth anchoring.
The statement allows arbitrary integer shift, hence both signs. -/
theorem retained_eq_primeResidueAnchor_of_nonzero_geometry
    (value : ∀ i, P i → ℕ) (latticePosition : Z → ℤ × ℤ)
    (d : ScheduledPhysicalPath
      (fun z i p => primeResidueAnchor (value i p) (latticePosition z)) N J B)
    (hprime : ∀ i p, p ∈ d.primes i → (value i p).Prime)
    (hbirth : d.ActiveBirthAnchored)
    (adjoint : ℕ → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hsupport : ∀ j, j < N →
      orientedSourceEdgeGeometry (adjoint j) value good u v r U W d₀ Y η ψ major σ
        (latticePosition (d.position j)) (d.sourceLists j)
        (latticePosition (d.position (j+1))) (d.targetLists j) ≠ 0)
    (j : ℕ) (hj : j ≤ N) (i : I) (p : P i)
    (hp : p ∈ d.primes i) (ha : j ∈ (d.lifespan i p).active) :
    d.retained i p = primeResidueAnchor (value i p) (latticePosition (d.position j)) := by
  apply d.retained_eq_anchor_of_active hbirth ?_ ?_ j hj i p hp ha
  · intro t ht
    apply d.target_not_active_of_crossEdgeBan value t
    exact orientedSourceEdgeGeometry_nonzero_crossEdgeBan (adjoint t) value good
      u v r U W d₀ Y η ψ major σ _ _ _ _ (hsupport t ht)
  · intro t ht k s
    have hp' : d.sourceLists t k s.castSucc ∈ d.primes k :=
      ((d.active_lifespan t ht.le k _).mpr
        ⟨d.sourcePerm t k s.castSucc,rfl⟩).1
    let : Fact (value k (d.sourceLists t k s.castSucc)).Prime := ⟨hprime _ _ hp'⟩
    exact orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint t) value good
      u v r U W d₀ Y η ψ major σ _ _ _ _ (hsupport t ht) k s

/-- Every raw schedule on nonzero actual source support admits the
coefficient-preserving retained-line normalization above.  The resulting
schedule satisfies active incidence with no extra birth-anchor premise. -/
theorem canonicalizeRetained_eq_primeResidueAnchor_of_nonzero_geometry
    (value : ∀ i, P i → ℕ) (latticePosition : Z → ℤ × ℤ)
    (d : ScheduledPhysicalPath
      (fun z i p => primeResidueAnchor (value i p) (latticePosition z)) N J B)
    (hprime : ∀ i p, p ∈ d.primes i → (value i p).Prime)
    (adjoint : ℕ → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hsupport : ∀ j, j < N →
      orientedSourceEdgeGeometry (adjoint j) value good u v r U W d₀ Y η ψ major σ
        (latticePosition (d.position j)) (d.sourceLists j)
        (latticePosition (d.position (j+1))) (d.targetLists j) ≠ 0)
    (j : ℕ) (hj : j ≤ N) (i : I) (p : P i)
    (hp : p ∈ d.primes i) (ha : j ∈ (d.lifespan i p).active) :
    d.canonicalizeRetained.retained i p =
      primeResidueAnchor (value i p) (latticePosition (d.position j)) := by
  have hnew : ∀ t, t < N → ∀ k s, d.targetPrime t k ≠ d.active t k s := by
    intro t ht
    apply d.target_not_active_of_crossEdgeBan value t
    exact orientedSourceEdgeGeometry_nonzero_crossEdgeBan (adjoint t) value good
      u v r U W d₀ Y η ψ major σ _ _ _ _ (hsupport t ht)
  have hshared : ∀ t, t < N → ∀ k (s : Fin J),
      primeResidueAnchor (value k (d.sourceLists t k s.castSucc))
        (latticePosition (d.position t)) =
      primeResidueAnchor (value k (d.sourceLists t k s.castSucc))
        (latticePosition (d.position (t+1))) := by
    intro t ht k s
    have hp' : d.sourceLists t k s.castSucc ∈ d.primes k :=
      ((d.active_lifespan t ht.le k _).mpr
        ⟨d.sourcePerm t k s.castSucc,rfl⟩).1
    let : Fact (value k (d.sourceLists t k s.castSucc)).Prime := ⟨hprime _ _ hp'⟩
    exact orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint t) value good
      u v r U W d₀ Y η ψ major σ _ _ _ _ (hsupport t ht) k s
  exact d.canonicalizeRetained.retained_eq_anchor_of_active
    (d.canonicalizeRetained_activeBirthAnchored hnew hshared) hnew hshared j hj i p hp ha

end ScheduledPhysicalPath
end Elliptic.Operator
