module

public import Elliptic.Operator.PrescribedGhostRow
public import Elliptic.Operator.GroupedGhostChoiceRow
public import Elliptic.Operator.PhysicalEdgeReindexing

/-! # Actual grouped ghost rows with adaptive prescribed births

All named coordinates are required to be performed. The total cutoff is
only dropped for the positive upper bound; each local factorial is retained.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrescribedPhysicalGhost
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance prescribedPhysicalGhostDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i → Type*} {J B : ℕ}

/-- Literal performed-coordinate restrictions in every actual group. -/
def Allowed (value : ∀i,P i→ℕ) (S : I→Finset ℕ)
    (target : ∀i k,(Fin k→P i)→ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalGhostChoice s) : Prop :=
  ∀i,PrescribedGhostRow.BatchAllowed (value i) (S i) (target i) (c i).2

/-- Absolute choice row, before choices with equal outputs are collected. -/
def row (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q ρ v0 : ℝ)
    (anchor : Z→∀i p,Line i p) (value : ∀i,P i→ℕ) (S : I→Finset ℕ)
    (target : ∀i k,(Fin k→P i)→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  ∑c : PhysicalGhostChoice s,if hc : c.Valid anchor s then
    if Allowed value S target c then
      ‖physicalGhostChoiceWeight ν V η q ρ anchor s c‖ *
        physicalMemorySchurWeight v0 (c.output anchor s hc) else 0 else 0

/-- Uniform literal grouped source estimate, including adaptive targets
within each ordered batch and arbitrary values fixed by previous history. -/
theorem row_le (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q ρ v0 Δ : ℝ)
    (anchor : Z→∀i p,Line i p) (value : ∀i,P i→ℕ)
    (hinj : ∀i,Function.Injective (value i)) (S : I→Finset ℕ)
    (target : ∀i k,(Fin k→P i)→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hη : 0≤η) (hq : 0≤q)
    (hρ : 0<ρ) (hv0 : 0<v0) (hp : q/ρ^2+η/(ρ*v0)≤1)
    (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ) :
    row ν V η q ρ v0 anchor value S target s ≤
      (∏i,((η*V i/ρ)*v0*Δ)^(S i).card *
        Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) * physicalMemorySchurWeight v0 s := by
  let T := fun i (c : GhostChoice (s.memory P Line J B i)) =>
    if hc : GhostChoice.Valid (anchor (s.position P Line J B) i) (s.memory P Line J B i) c then
      if PrescribedGhostRow.BatchAllowed (value i) (S i) (target i) c.2 then
        |ghostChoiceWeight (ν i) (V i) η q ρ (anchor (s.position P Line J B) i)
          (s.memory P Line J B i) c| * v0^(ghostOutput _ _ _ hc).size else 0 else 0
  have hT i c : 0≤T i c := by dsimp [T]; split_ifs <;> positivity
  have hpoint (c : PhysicalGhostChoice s) :
      (if hc : c.Valid anchor s then
        if Allowed value S target c then ‖physicalGhostChoiceWeight ν V η q ρ anchor s c‖ *
          physicalMemorySchurWeight v0 (c.output anchor s hc) else 0 else 0) ≤ ∏i,T i (c i) := by
    by_cases hc : c.Valid anchor s
    · rw [dite_eq_left hc]
      by_cases ha : Allowed value S target c
      · rw [ite_eq_left ha]
        have ht : (∏i,T i (c i)) = ∏i,
            |ghostChoiceWeight (ν i) (V i) η q ρ (anchor (s.position P Line J B) i)
              (s.memory P Line J B i) (c i)| *v0^(ghostOutput _ _ _ (hc.1 i)).size := by
          apply Finset.prod_congr rfl
          intro i _
          simp only [T,dite_eq_left (hc.1 i),ite_eq_left (ha i)]
        rw [ht,Finset.prod_mul_distrib,Finset.prod_pow_eq_pow_sum]
        unfold physicalGhostChoiceWeight physicalMemorySchurWeight
        simp only [norm_prod,Complex.norm_real,Real.norm_eq_abs]
        exact le_rfl
      · rw [ite_eq_right ha]
        exact Finset.prod_nonneg (fun i _=>hT i (c i))
    · rw [dite_eq_right hc]
      exact Finset.prod_nonneg (fun i _=>hT i (c i))
  have hlocal i : (∑c,T i c) ≤
      (((η*V i/ρ)*v0*Δ)^(S i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) *
        v0^(s.memory P Line J B i).size := by
    apply (div_le_iff₀ (pow_pos hv0 _)).mp
    have hh := PrescribedGhostRow.choiceRow_le (ν i) (V i) η q ρ v0
      (anchor (s.position P Line J B) i) (value i) (hinj i) (S i) (target i) Δ
      (s.memory P Line J B i) (hν i) (hV i) hη hq hρ hv0 hp hΔ (hatom i)
    convert hh using 1
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro c _
    dsimp [T,PrescribedGhostRow.choiceRow]
    split_ifs <;> simp only [mul_div_assoc,zero_div]
  unfold row
  calc
    _ ≤ ∑c : PhysicalGhostChoice s,∏i,T i (c i) := Finset.sum_le_sum (fun c _=>hpoint c)
    _ = ∏i,∑c,T i c := (Fintype.prod_sum T).symm
    _ ≤ ∏i, (((η*V i/ρ)*v0*Δ)^(S i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) *
        v0^(s.memory P Line J B i).size :=
      Finset.prod_le_prod₀ (fun i _=>Finset.sum_nonneg (fun c _=>hT i c)) (fun i _=>hlocal i)
    _ = _ := by rw [Finset.prod_mul_distrib,Finset.prod_pow_eq_pow_sum]; rfl

/-- Isolate one prime atom per prescribed performed coordinate. -/
theorem row_le_atoms (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q ρ v0 Δ : ℝ)
    (anchor : Z→∀i p,Line i p) (value : ∀i,P i→ℕ)
    (hinj : ∀i,Function.Injective (value i)) (S : I→Finset ℕ)
    (target : ∀i k,(Fin k→P i)→ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hη : 0≤η) (hq : 0≤q)
    (hρ : 0<ρ) (hv0 : 0<v0) (hp : q/ρ^2+η/(ρ*v0)≤1)
    (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ) :
    row ν V η q ρ v0 anchor value S target s ≤
      (∏i,((η*V i/ρ)*v0)^(S i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) *
        Δ^(∑i,(S i).card) * physicalMemorySchurWeight v0 s := by
  apply (row_le ν V η q ρ v0 Δ anchor value hinj S target s
    hν hV hη hq hρ hv0 hp hΔ hatom).trans_eq
  simp only [mul_pow]
  have he : (∏i, (((η*V i/ρ)*v0)^(S i).card * Δ^(S i).card) *
      Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) =
      (∏i, ((η*V i/ρ)*v0)^(S i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)) *
      Δ^(∑i,(S i).card) := by
    rw [← Finset.prod_pow_eq_pow_sum,← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i _
    ring
  simpa only [mul_pow] using congrArg (fun z : ℝ => z*physicalMemorySchurWeight v0 s) he

end Elliptic.Operator.PrescribedPhysicalGhost
