module

public import Elliptic.Operator.PhysicalMaskScaling
public import Elliptic.Operator.CountingKernelSchur

/-!
# The two-sided Schur estimate for literal physical masks

Every matrix row is derived from indexed choices; the opposite column
uses the proved exact measured reversal and its fixed coefficient factor.
The standard Schur step is isolated here for use with the explicit source
row estimates, rather than being packaged as a new analytic assumption.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskedNorm
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalMaskScaling
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {G Z : Type*} [Fintype G] [Fintype Z]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- Actual ordered choice rows control every bag row, because every
admissible bag state has an ordered representative and all other rows vanish. -/
theorem all_bag_rows_le_of_choices
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (V : G → ℝ) (S I : G → Bool) (ρ v0 R : ℝ) (hv0 : 0 < v0) (hR : 0 ≤ R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hrow : ∀ s : PhysicalMemoryState (Z:=Z) P Line J B,
      choiceRow ν V S I ρ v0 anchor geometry s ≤ R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    (∑ t, ‖originalKernel ν V S I ρ anchor geometry s t‖ * (weight v0 t/weight v0 s)) ≤ R := by
  by_cases hs : Total s
  · obtain ⟨u,hu⟩ := PhysicalBagRepresentatives.ofOrdered_exists s hs
    rw [← hu]
    exact (row_le_choices ν (fun i p => (hν i p).ne') V S I ρ v0 hv0.le anchor geometry u).trans (hrow u)
  · simpa only [originalKernel,kernel,hs,false_and,ite_false,norm_zero,zero_mul,Finset.sum_const_zero] using hR

/-- Precise Schur norm bound for a literal original mask, from its two
proved indexed rows. Reversal exchanges masks and pays only the explicit
fixed product of V factors; there is no memory-cutoff loss. -/
theorem originalKernel_schur_of_choice_rows
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (V : G → ℝ) (hV : ∀ i, 0 < V i) (S I : G → Bool) (ρ v0 R C : ℝ)
    (hv0 : 0 < v0) (hR : 0 ≤ R) (hC : 0 ≤ C)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hrow : ∀ s : PhysicalMemoryState (Z:=Z) P Line J B,
      choiceRow ν V S I ρ v0 anchor geometry s ≤ R)
    (hreverse : ∀ s : PhysicalMemoryState (Z:=Z) P Line J B,
      choiceRow ν V I S ρ v0 anchor (fun z a w b => geometry w b z a) s ≤ C)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s => ∑ t, originalKernel ν V S I ρ anchor geometry s t * F t) ≤
    Real.sqrt (R*(reverseFactor V I S*C)) * finiteL2 Finset.univ (mass ν) F := by
  let K : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) →
      State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℂ :=
    originalKernel ν V S I ρ anchor geometry
  let L : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) →
      State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℂ :=
    kernel (fun i p => (ν i p:ℂ)) (fun i => (V i:ℂ)⁻¹) (fun _ => 1)
      I S (ρ:ℂ) anchor (fun z a w b => geometry w b z a)
  have hf := reverseFactor_pos V hV I S
  apply countingKernel_schur (mass ν) (weight v0) K L R (reverseFactor V I S*C)
    (mass_pos ν hν) (weight_pos hv0) hR (mul_nonneg hf.le hC)
  · intro s t
    have hn : ∀ i p, (ν i p:ℂ) ≠ 0 := by intro i p; exact_mod_cast (hν i p).ne'
    have he := congrArg norm (kernel_balance (fun i p => (ν i p:ℂ)) hn
      (fun _ => 1) (fun i => (V i:ℂ)⁻¹) S I (ρ:ℂ) anchor geometry s t)
    simpa only [mass_complex,norm_mul,Complex.norm_real,Real.norm_eq_abs,
      abs_of_pos (mass_pos ν hν s),abs_of_pos (mass_pos ν hν t),K,L,originalKernel] using he
  · exact all_bag_rows_le_of_choices ν hν V S I ρ v0 R hv0 hR anchor geometry hrow
  · intro t
    have he := all_bag_rows_le_of_choices ν hν V I S ρ v0 C hv0 hC anchor
      (fun z a w b => geometry w b z a) hreverse t
    dsimp only [L]
    simp_rw [reversed_original_kernel ν V (fun i => (hV i).ne') S I]
    simp only [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hf,mul_assoc,← Finset.mul_sum]
    exact mul_le_mul_of_nonneg_left he hf.le

end Elliptic.Operator.PhysicalMaskedNorm
