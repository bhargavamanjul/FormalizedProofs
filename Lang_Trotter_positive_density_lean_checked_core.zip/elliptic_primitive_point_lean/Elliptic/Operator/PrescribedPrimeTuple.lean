module

public import Elliptic.Operator.GhostSchurRow

/-!
# Chronological prescribed-value savings for actual prime tuples

A prescribed coordinate may depend on the entire earlier tuple. Summing
coordinates in chronological order still saves one actual prime atom per
prescription. Numerical prescriptions outside the group's alphabet have
zero mass. This supplies the adaptive within-batch part of source (4.49).
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrescribedPrimeTuple
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance prescribedTupleDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {P : Type*}

/-- The literal earlier coordinates, before coordinate j is drawn. -/
def earlier {n : ℕ} (x : Fin n → P) (j : Fin n) : Fin j.val → P :=
  fun k => x ⟨k.val,lt_trans k.isLt j.isLt⟩

/-- Prescriptions can depend arbitrarily on the already drawn coordinates. -/
def Allowed (value : P → ℕ) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) {n : ℕ} (x : Fin n → P) : Prop :=
  ∀ j : Fin n, j.val ∈ S → value (x j) = target j.val (earlier x j)

/-- Append one new draw after the fixed earlier tuple. -/
def append {n : ℕ} (x : Fin n → P) (p : P) : Fin (n+1) → P := Fin.lastCases p x

/-- A concrete last-coordinate splitting used for the chronological sum. -/
def splitLast (P : Type*) (n : ℕ) : (Fin (n+1) → P) ≃ (Fin n → P) × P where
  toFun x := (fun j => x j.castSucc,x (Fin.last n))
  invFun x := append x.1 x.2
  left_inv x := by
    funext j
    refine Fin.lastCases ?_ (fun k => ?_) j <;> simp [append]
  right_inv x := by
    rcases x with ⟨x,p⟩
    apply Prod.ext
    · funext j; simp [append]
    · simp [append]

@[simp] theorem earlier_append_cast {n : ℕ} (x : Fin n → P) (p : P) (j : Fin n) :
    earlier (append x p) j.castSucc = earlier x j := by
  funext k
  change append x p (⟨k.val,lt_trans k.isLt j.isLt⟩ : Fin n).castSucc = _
  simp only [append,Fin.lastCases_castSucc]
  rfl

@[simp] theorem earlier_append_last {n : ℕ} (x : Fin n → P) (p : P) :
    earlier (append x p) (Fin.last n) = x := by
  funext k
  change append x p k.castSucc = _
  simp only [append,Fin.lastCases_castSucc]

/-- The final prescription uses only earlier coordinates, so it can be
integrated after the entire earlier tuple has been fixed. -/
theorem allowed_append (value : P → ℕ) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) {n : ℕ} (x : Fin n → P) (p : P) :
    Allowed value S target (append x p) ↔
      Allowed value S target x ∧ (n ∈ S → value p = target n x) := by
  constructor
  · intro h
    constructor
    · intro j hj
      simpa only [Fin.val_castSucc,earlier_append_cast,append,Fin.lastCases_castSucc] using h j.castSucc hj
    · intro hn
      simpa only [Fin.val_last,earlier_append_last,append,Fin.lastCases_last] using h (Fin.last n) hn
  · rintro ⟨h,hlast⟩ j
    refine Fin.lastCases ?_ (fun k => ?_) j
    · simpa only [Fin.val_last,earlier_append_last,append,Fin.lastCases_last] using hlast
    · simpa only [Fin.val_castSucc,earlier_append_cast,append,Fin.lastCases_castSucc] using h k

variable [Fintype P]

/-- A numerical prescription picks at most one label in its actual group.
If the prescribed value is in another group, the sum is zero. -/
theorem atom_sum_le (ν : P → ℝ) (value : P → ℕ)
    (hinj : Function.Injective value) (Δ : ℝ) (hΔ : 0 ≤ Δ)
    (hatom : ∀ p, ν p ≤ Δ) (b : ℕ) :
    (∑ p : P, if value p = b then ν p else 0) ≤ Δ := by
  by_cases hb : ∃ p, value p = b
  · obtain ⟨p,hp⟩ := hb
    rw [Finset.sum_eq_single p]
    · simpa only [hp,ite_true] using hatom p
    · intro q _ hq
      have hqb : value q ≠ b := fun he => hq (hinj (he.trans hp.symm))
      simp [hqb]
    · simp
  · have hn : ∀ p, value p ≠ b := by simpa only [not_exists] using hb
    simpa only [hn,ite_false,Finset.sum_const_zero] using hΔ

/-- Exact last-coordinate expansion of the actual restricted tuple sum. -/
theorem sum_append (ν : P → ℝ) (value : P → ℕ) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (n : ℕ) :
    (∑ x : Fin (n+1) → P, if Allowed value S target x then tupleWeight ν x else 0) =
    ∑ x : Fin n → P, if Allowed value S target x then
      tupleWeight ν x * (∑ p : P, if (n ∈ S → value p = target n x) then ν p else 0) else 0 := by
  rw [Fintype.sum_equiv (splitLast P n)
    (fun x => if Allowed value S target x then tupleWeight ν x else 0)
    (fun x => if Allowed value S target (append x.1 x.2) then
      tupleWeight ν (append x.1 x.2) else 0)
    (fun x => by
      have hx : append ((splitLast P n) x).1 ((splitLast P n) x).2 = x := (splitLast P n).left_inv x
      rw [hx])]
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro x _
  have hw (p : P) : tupleWeight ν (append x p) = tupleWeight ν x * ν p := by
    unfold tupleWeight
    rw [Fin.prod_univ_castSucc]
    simp only [append,Fin.lastCases_castSucc,Fin.lastCases_last]
  simp_rw [allowed_append,hw]
  by_cases hx : Allowed value S target x
  · simp only [hx,true_and,ite_true,Finset.mul_sum,mul_ite,mul_zero]
  · simp only [hx,false_and,ite_false,Finset.sum_const_zero]

/-- Every adaptive prescribed draw costs at most one actual prime atom;
all remaining coordinates have their literal total mass. -/
theorem sum_le_product (ν : P → ℝ) (value : P → ℕ)
    (hinj : Function.Injective value) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (Δ : ℝ)
    (hν : ∀ p, 0 ≤ ν p) (hΔ : 0 ≤ Δ) (hatom : ∀ p, ν p ≤ Δ) (n : ℕ) :
    (∑ x : Fin n → P, if Allowed value S target x then tupleWeight ν x else 0) ≤
      ∏ j ∈ Finset.range n, if j ∈ S then Δ else ∑ p, ν p := by
  induction n with
  | zero => simp [Allowed,tupleWeight]
  | succ n ih =>
      rw [sum_append,Finset.prod_range_succ]
      let C : ℝ := if n ∈ S then Δ else ∑ p, ν p
      have hC : 0 ≤ C := by
        dsimp [C]
        split_ifs
        · exact hΔ
        · exact Finset.sum_nonneg (fun p _ => hν p)
      have hlast (x : Fin n → P) :
          (∑ p : P, if (n ∈ S → value p = target n x) then ν p else 0) ≤ C := by
        by_cases hn : n ∈ S
        · simpa only [C,hn,ite_true,true_implies] using atom_sum_le ν value hinj Δ hΔ hatom (target n x)
        · simp [C,hn]
      calc
        _ ≤ ∑ x : Fin n → P, (if Allowed value S target x then tupleWeight ν x else 0) * C := by
          apply Finset.sum_le_sum
          intro x _
          by_cases hx : Allowed value S target x
          · simp only [hx,ite_true]
            exact mul_le_mul_of_nonneg_left (hlast x) (Finset.prod_nonneg (fun _ _ => hν _))
          · simp only [hx,ite_false,zero_mul]; exact le_rfl
        _ = (∑ x : Fin n → P, if Allowed value S target x then tupleWeight ν x else 0) * C :=
          (Finset.sum_mul _ _ _).symm
        _ ≤ _ := mul_le_mul_of_nonneg_right ih hC

/-- When the batch reaches every named index, the saving is exactly one
atom per prescribed coordinate, irrespective of the named index positions. -/
theorem sum_le_atoms (ν : P → ℝ) (value : P → ℕ)
    (hinj : Function.Injective value) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (Δ : ℝ)
    (hν : ∀ p, 0 ≤ ν p) (hΔ : 0 ≤ Δ) (hatom : ∀ p, ν p ≤ Δ)
    (n : ℕ) (hS : S ⊆ Finset.range n) :
    (∑ x : Fin n → P, if Allowed value S target x then tupleWeight ν x else 0) ≤
      Δ^S.card * (∑ p, ν p)^(n-S.card) := by
  apply (sum_le_product ν value hinj S target Δ hν hΔ hatom n).trans_eq
  rw [Finset.prod_ite]
  have hyes : (Finset.range n).filter (fun j => j ∈ S) = S := by
    ext j
    simp only [Finset.mem_filter]
    exact ⟨fun h => h.2,fun h => ⟨hS h,h⟩⟩
  have hno : ((Finset.range n).filter (fun j => j ∉ S)).card = n-S.card := by
    have h := Finset.card_filter_add_card_filter_not (s:=Finset.range n) (p:=fun j => j∈S)
    rw [hyes,Finset.card_range] at h
    omega
  simp only [Finset.prod_const,hyes,hno]

end Elliptic.Operator.PrescribedPrimeTuple
