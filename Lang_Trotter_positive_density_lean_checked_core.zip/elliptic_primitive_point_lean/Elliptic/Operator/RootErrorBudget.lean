module

public import Elliptic.Operator.SourceRootCount
public import Elliptic.Operator.BonferroniBudget
public import Mathlib.NumberTheory.Primorial

/-!
# Uniform accumulation of the root-count error

The actual residue group has at most S^4 elements. Its cost and any other
fixed subpower coefficient budget can be absorbed into the power saving
of the accepted root count. The grid-cardinality hypothesis in the last
lemma is explicit: this file does not construct a geometric partition or
bound the boundary of the source good-state regions.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootErrorBudget
open Filter
open scoped BigOperators

/-- Distinct numerical primes give a positive squarefree CRT modulus,
including the empty product. These are the literal algebraic hypotheses
of the external root-count theorem. -/
theorem prime_modulus_admissible (s : Finset ℕ)
    (hs : ∀ p ∈ s, p.Prime) :
    1 ≤ ∏ p ∈ s, p ∧ Squarefree (∏ p ∈ s, p) := by
  constructor
  · exact Finset.one_le_prod (fun p hp => (hs p hp).one_le)
  · refine Finset.squarefree_prod_of_pairwise_isCoprime (fun p hp q hq hpq => ?_)
      (fun p hp => (hs p hp).squarefree)
    simp only [← Nat.coprime_iff_isRelPrime]
    exact (Nat.coprime_primes (hs p hp) (hs q hq)).mpr hpq

/-- Entrywise inclusion into the four matrix entries bounds the actual
residue group. No prime factorization formula for its order is needed. -/
theorem residue_card_le (S : ℕ) (hS : 1 ≤ S) :
    Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) ≤ S^4 := by
  let : NeZero S := ⟨by omega⟩
  have h := Nat.card_le_card_of_injective
    (fun g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S) => g.val)
    Subtype.val_injective
  simpa [Nat.card_eq_fintype_card, Matrix, Fintype.card_fun, ZMod.card, ← pow_mul] using h

/-- Charging every residue class in the external root-count theorem
costs only four times the logarithmic modulus budget. -/
theorem residue_card_le_exp (S : ℕ) (hS : 1 ≤ S) (D : ℝ)
    (hmod : (S:ℝ) ≤ Real.exp D) :
    (Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℝ) ≤ Real.exp (4*D) := by
  calc
    _ ≤ (S:ℝ)^4 := by exact_mod_cast residue_card_le S hS
    _ ≤ (Real.exp D)^4 := pow_le_pow_left₀ (Nat.cast_nonneg _) hmod 4
    _ = _ := by rw [← Real.exp_nat_mul]; norm_num

/-- The actual active-prime union with a retained Bonferroni monomial
meets all modulus conditions in the accepted root count. -/
theorem truncated_modulus_admissible (K : ℕ) (L : ℝ) (hL : 1 ≤ L)
    (labels : Fin (momentLength L+1) → Fin K → Fin (momentMultiplicity L) → ℕ)
    (extra : Finset ℕ)
    (ha : ∀ j i a, (labels j i a).Prime)
    (hp : ∀ p ∈ extra, p.Prime)
    (hv : ∀ j i a, (labels j i a:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (he : ∀ p ∈ extra, (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hcard : extra.card ≤ ⌈L^(76/100:ℝ)⌉₊) :
    let S := ∏ p ∈ IntegerRootReplacement.activePrimeSet labels ∪ extra, p
    1 ≤ S ∧ Squarefree S ∧
      (S:ℝ) ≤ Real.exp ((16*K+4)*L^(98/100:ℝ)) := by
  have hs := prime_modulus_admissible (IntegerRootReplacement.activePrimeSet labels ∪ extra) (by
    intro p hp'
    rcases Finset.mem_union.mp hp' with h | h
    · obtain ⟨t, _, rfl⟩ := Finset.mem_image.mp h
      exact ha t.1 t.2.1 t.2.2
    · exact hp p h)
  refine ⟨hs.1, hs.2, ?_⟩
  push_cast
  apply (IntegerRootReplacement.truncated_root_modulus_le K L hL labels extra hv he hcard).trans
  apply Real.exp_le_exp.mpr
  exact mul_le_mul_of_nonneg_left
    (Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (96/100:ℝ) ≤ 98/100))
    (by positivity)

/-- A fixed sublinear logarithmic exponent is eventually at most any
prescribed positive multiple of L. Constants are chosen before L. -/
theorem eventually_subpower_exponent_le (B ε : ℝ) (hε : 0 < ε) :
    ∀ᶠ L : ℝ in atTop, B*L^(98/100:ℝ) ≤ ε*L := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<2/100)).eventually
      (eventually_ge_atTop (B/ε))] with L hL hB
  have hb : B ≤ ε*L^(2/100:ℝ) := by simpa [mul_comm] using (div_le_iff₀ hε).mp hB
  calc
    _ ≤ (ε*L^(2/100:ℝ))*L^(98/100:ℝ) :=
      mul_le_mul_of_nonneg_right hb (by positivity)
    _ = ε*L := by rw [mul_assoc, ← Real.rpow_add hL]; norm_num

/-- The threshold is uniform in every later modulus. -/
theorem eventually_residue_cost (C ε : ℝ) (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, ∀ S : ℕ, 1 ≤ S →
      (S:ℝ) ≤ Real.exp (C*(Real.log x)^(98/100:ℝ)) →
      (Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℝ) ≤ x^ε := by
  have he := Real.tendsto_log_atTop.eventually
    (eventually_subpower_exponent_le (4*C) ε hε)
  filter_upwards [eventually_gt_atTop (0:ℝ),he] with x hx he
  intro S hS hm
  calc
    _ ≤ Real.exp (4*(C*(Real.log x)^(98/100:ℝ))) := residue_card_le_exp S hS _ hm
    _ ≤ Real.exp (ε*Real.log x) := Real.exp_le_exp.mpr (by nlinarith)
    _ = x^ε := by rw [Real.rpow_def_of_pos hx]; congr 1; ring

/-- A subpower coefficient/residue cost and a grid of at most x^(δ/2000)
cells leave a power saving. The error constant and all budgets precede x;
the cell count and accumulated coefficient mass can vary with x. -/
theorem eventually_grid_error (C B δ : ℝ) (_hC : 0 ≤ C) (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop, ∀ G W : ℝ,
      0 ≤ G → G ≤ x^(δ/2000) →
      0 ≤ W → W ≤ Real.exp (B*(Real.log x)^(98/100:ℝ)) →
      C*G*W*x^(-(δ/1000)) ≤ x^(-(δ/4000)) := by
  have hb := Real.tendsto_log_atTop.eventually
    (eventually_subpower_exponent_le B (δ/8000) (by positivity))
  have hc := (tendsto_rpow_atTop (show 0 < δ/8000 by positivity)).eventually
    (eventually_ge_atTop C)
  filter_upwards [eventually_gt_atTop (0:ℝ),hb,hc] with x hx hb hc
  intro G W hG hG' hW hW'
  have hw : W ≤ x^(δ/8000) := by
    apply hW'.trans
    rw [Real.rpow_def_of_pos hx]
    apply Real.exp_le_exp.mpr
    nlinarith
  calc
    _ ≤ x^(δ/8000)*x^(δ/2000)*x^(δ/8000)*x^(-(δ/1000)) := by gcongr
    _ = x^(-(δ/4000)) := by
      rw [← Real.rpow_add hx, ← Real.rpow_add hx, ← Real.rpow_add hx]
      congr 1
      ring

/-- The remaining power saving absorbs the growing moment target as
well. This step depends on the actual moment length, not a supplied
little-oh estimate for that length. -/
theorem eventually_power_saving_le_moment (A δ : ℝ) (hA : 0 ≤ A) (hδ : 0 < δ) :
    ∀ᶠ L : ℝ in atTop,
      Real.exp (-(δ/4000)*L) ≤ L^(-A*(momentLength L:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<4/10)).eventually
      (eventually_ge_atTop (160000*A/δ))] with L hL hc
  have hL0 : 0 < L := by linarith
  have hlog : 0 ≤ Real.log L := Real.log_nonneg hL
  have hn : (momentLength L:ℝ) ≤ 4*L^(1/2:ℝ) := by
    linarith [IntegerRootReplacement.momentLength_add_one_le L hL]
  have hl := Real.log_le_rpow_div hL0.le (by norm_num : (0:ℝ)<1/10)
  have hcost : A*(momentLength L:ℝ)*Real.log L ≤ 40*A*L^(6/10:ℝ) := by
    calc
      _ ≤ A*(4*L^(1/2:ℝ))*(L^(1/10:ℝ)/(1/10)) := by gcongr
      _ = _ := by rw [show (6/10:ℝ)=1/2+1/10 by norm_num, Real.rpow_add hL0]; ring
  have hc' : 160000*A ≤ δ*L^(4/10:ℝ) := by
    simpa [mul_comm] using (div_le_iff₀ hδ).mp hc
  have hm := mul_le_mul_of_nonneg_right hc' (show 0 ≤ L^(6/10:ℝ) by positivity)
  have he : L^(4/10:ℝ)*L^(6/10:ℝ) = L := by
    rw [← Real.rpow_add hL0]; norm_num
  rw [Real.rpow_def_of_pos hL0]
  apply Real.exp_le_exp.mpr
  nlinarith [he]

end Elliptic.Operator.RootErrorBudget
