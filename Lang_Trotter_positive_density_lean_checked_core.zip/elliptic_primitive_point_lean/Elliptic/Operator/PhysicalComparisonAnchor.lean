module

public import Elliptic.Operator.PhysicalPadLattice
public import Elliptic.Operator.DirtyComparisonBox

/-! The actual first-good physical pad cell supplies the retained-anchor
saving needed by the comparison dirty row. Neither the lattice basis nor
a target-cardinality estimate is assumed. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalComparisonAnchor
open scoped BigOperators
open PhysicalPadLattice
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Physical reconstruction from integral pad coordinates. -/
def padVector (z w : ℤ × ℤ) (D : ℤ) (v : ℤ × ℤ) : ℤ × ℤ :=
  targetVector z w (D*v.2) v.1

theorem padVector_basis (z w b₁ b₂ c : ℤ × ℤ) (D : ℤ) :
    integerBasisVector (padVector z w D b₁) (padVector z w D b₂) c=
      padVector z w D (integerBasisVector b₁ b₂ c) := by
  ext <;> simp only [padVector,integerBasisVector,targetVector] <;> ring

theorem padVector_det (z w b₁ b₂ : ℤ × ℤ) (D : ℤ)
    (hz : latticeDet z w=1) (hb : latticeDet b₁ b₂=1) :
    latticeDet (padVector z w D b₁) (padVector z w D b₂)=D := by
  have he : latticeDet (padVector z w D b₁) (padVector z w D b₂)=
      D*latticeDet z w*latticeDet b₁ b₂ := by
    simp only [padVector,targetVector,latticeDet]
    ring
  rw [he,hz,hb,mul_one,mul_one]

theorem balanced_reconstruct (z w b₁ b₂ : ℤ × ℤ) (D : ℤ)
    (hz : latticeDet z w=1) (hb : latticeDet b₁ b₂=1)
    (t : ℤ × ℤ) (ht : D∣latticeDet z t) :
    integerBasisVector (padVector z w D b₁) (padVector z w D b₂)
      (SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t))=t := by
  rw [padVector_basis,SourceGoodState.basisCoordinates_inverse b₁ b₂ hb]
  exact padCoordinates_reconstruct z w hz D t ht

/-- The target set is arbitrary; only its literal physical and retained
line conditions are used. There is no loss in the number of ambient
positions, auxiliary labels, or representatives. -/
theorem actual_anchor_count (p : ℕ) [Fact p.Prime]
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1) (D : ℤ)
    (hpD : (D : ZMod p)≠0) (u v r U W d₀ Y C : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hD : d₀≤(D:ℝ)) (hY : 1≤Y) (hC : 1≤C)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest ((D:ℝ)*latticeTau r w/latticeTau r z) Y)
    (anchor : Option (ZMod p)) (targets : Finset (ℤ × ℤ))
    (htpos : ∀t∈targets,sourcePhysicalPositionAllowed u v r U W t)
    (htdiv : ∀t∈targets,D∣latticeDet z t)
    (htcell : ∀t∈targets,|latticeSlope r t-latticeSlope r z|≤C*d₀*Y)
    (htanchor : ∀t∈targets,primeResidueAnchor p t=anchor) :
    (targets.card:ℝ)≤72*(256*C)^2*Y*((p:ℝ)⁻¹+Y^(-(1/5:ℝ))) := by
  obtain ⟨b₁,b₂,a,b,c,d,hb,hab,hcd,hwidth,hwidth',harea,hcontain⟩ :=
    physical_pad_cell_balanced_box z w hzw D u v r U W d₀ Y C hU hu hu' hd hD hY hC hz hg
  let e (t : ℤ × ℤ) := SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t)
  have hinj : Set.InjOn e (targets:Set (ℤ × ℤ)) := by
    intro t ht s hs he
    have h := congrArg (integerBasisVector (padVector z w D b₁) (padVector z w D b₂)) he
    simpa only [e,balanced_reconstruct z w b₁ b₂ D hzw hb t (htdiv t ht),
      balanced_reconstruct z w b₁ b₂ D hzw hb s (htdiv s hs)] using h
  have hsub : targets.image e ⊆ anchoredIntegerBox p a b c d
      (padVector z w D b₁) (padVector z w D b₂) anchor := by
    intro c hc
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hc
    apply Finset.mem_filter.mpr
    refine ⟨hcontain t (htpos t ht) (htdiv t ht) (htcell t ht),?_⟩
    dsimp only [e]
    rw [balanced_reconstruct z w b₁ b₂ D hzw hb t (htdiv t ht)]
    exact htanchor t ht
  have hc := Finset.card_le_card hsub
  rw [Finset.card_image_iff.mpr hinj] at hc
  have hc' : (targets.card:ℝ)≤((anchoredIntegerBox p a b c d
      (padVector z w D b₁) (padVector z w D b₂) anchor).card:ℝ) := by exact_mod_cast hc
  apply hc'.trans
  have hh := anchoredIntegerBox_scaled_card_le p a b c d hab hcd
    (padVector z w D b₁) (padVector z w D b₂)
    (by rw [padVector_det z w b₁ b₂ D hzw hb];exact hpD)
    anchor (72*(256*C)^2) Y (Y^(1/5:ℝ)) (by positivity) hwidth hwidth' harea
  simpa only [Real.rpow_neg (by linarith : 0≤Y)] using hh

/-- A literal filtered physical target set, ready for fixed-label row
summation. The finite ambient position space is completely unrestricted. -/
def anchorTargets (positions : Finset (ℤ × ℤ)) (p : ℕ) (anchor : Option (ZMod p))
    (z : ℤ × ℤ) (D : ℤ) (u v r U W d₀ Y C : ℝ) : Finset (ℤ × ℤ) :=
  positions.filter (fun t=>sourcePhysicalPositionAllowed u v r U W t ∧
    D∣latticeDet z t ∧ |latticeSlope r t-latticeSlope r z|≤C*d₀*Y ∧
    primeResidueAnchor p t=anchor)

theorem anchorTargets_card (p : ℕ) [Fact p.Prime]
    (z w : ℤ × ℤ) (hzw : latticeDet z w=1) (D : ℤ)
    (hpD : (D : ZMod p)≠0) (u v r U W d₀ Y C : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hD : d₀≤(D:ℝ)) (hY : 1≤Y) (hC : 1≤C)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest ((D:ℝ)*latticeTau r w/latticeTau r z) Y)
    (anchor : Option (ZMod p)) (positions : Finset (ℤ × ℤ)) :
    ((anchorTargets positions p anchor z D u v r U W d₀ Y C).card:ℝ)≤
      72*(256*C)^2*Y*((p:ℝ)⁻¹+Y^(-(1/5:ℝ))) := by
  apply actual_anchor_count p z w hzw D hpD u v r U W d₀ Y C hU hu hu' hd hD hY hC hz hg anchor
  · intro t ht
    exact (Finset.mem_filter.mp ht).2.1
  · intro t ht
    exact (Finset.mem_filter.mp ht).2.2.1
  · intro t ht
    exact (Finset.mem_filter.mp ht).2.2.2.1
  · intro t ht
    exact (Finset.mem_filter.mp ht).2.2.2.2

end Elliptic.Operator.PhysicalComparisonAnchor
