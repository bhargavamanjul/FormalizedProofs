module

public import Elliptic.Operator.PhysicalPivotHistory
public import Elliptic.Operator.RestrictedHistoryStep

/-! # Actual chronological pivot row with one atom per named birth

All local bounds below are derived from actual ghost and edge coefficients.
The result sums the original dependent histories with a causal restriction;
it assumes no desired high-rank or prescribed-history mass bound.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
open ChronologicalPrescription
attribute [local instance 100000] Classical.propDecidable
local instance physicalPivotRowDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1500000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B : ℕ}

def ghostFactor (ν : ∀i,P i → ℝ) (V:I → ℝ) (η ρ v0:ℝ) (plan:PivotPlan I J B) (j:ℕ) : ℝ :=
  ∏i,((η*V i/ρ)*v0)^(plan.ghostSlots j i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)

def edgeFactor (ν : ∀i,P i → ℝ) (V:I → ℝ) (v0 G:ℝ) (B:ℕ) : ℝ :=
  G*∏i,(1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)

/-- Number of named actual future births in the remaining word. -/
def PivotPlan.futureCount (plan:PivotPlan I J B) : ℕ → ℕ → ℕ
  | j,0 => ∑i,(plan.ghostSlots j i).card
  | j,n+1 => (∑i,(plan.ghostSlots j i).card)+(plan.edgeGroups j).card+plan.futureCount (j+1) n

/-- Explicit product of group and target-count constants, excluding atoms. -/
def PivotPlan.wordFactor (ν : ∀i,P i → ℝ) (V:I → ℝ) (η:ℕ → ℝ) (ρ v0:ℝ)
    (G:ℕ → ℝ) (plan:PivotPlan I J B) : ℕ → ℕ → ℝ
  | j,0 => ghostFactor ν V (η j) ρ v0 plan j
  | j,n+1 => ghostFactor ν V (η j) ρ v0 plan j *
      (edgeFactor ν V v0 (G j) B *plan.wordFactor ν V η ρ v0 G (j+1) n)

theorem wordFactor_nonneg (ν : ∀i,P i → ℝ) (V:I → ℝ) (η:ℕ → ℝ) (ρ v0:ℝ)
    (G:ℕ → ℝ) (plan:PivotPlan I J B) (hV:∀i,0≤V i) (hη:∀j,0≤η j)
    (hρ:0≤ρ) (hv:0≤v0) (hG:∀j,0≤G j) (j n:ℕ) :
    0≤plan.wordFactor ν V η ρ v0 G j n := by
  have hg j : 0≤ghostFactor ν V (η j) ρ v0 plan j := by
    apply Finset.prod_nonneg
    intro i _
    have hVi:=hV i
    have hηj:=hη j
    positivity
  have he j : 0≤edgeFactor ν V v0 (G j) B := by
    unfold edgeFactor
    exact mul_nonneg (hG j) (Finset.prod_nonneg (fun i _=>by positivity))
  induction n generalizing j with
  | zero => exact hg j
  | succ n ih => exact mul_nonneg (hg j) (mul_nonneg (he j) (ih (j+1)))

/-- Concrete chronological estimate on actual physical histories. -/
theorem actual_history_sum_le
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ v0 Δ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (hinj:∀i,Function.Injective (value i))
    (plan:PivotPlan I J B) (G:ℕ → ℝ)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:∀j,0≤η j) (hq:∀j,0≤q j)
    (hρ:0<ρ) (hρ1:ρ≤1) (hv0:0<v0) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ)
    (hp:∀j,q j/ρ^2+η j/(ρ*v0)≤1) (hG:∀j,0≤G j)
    (hgeometry:∀j z a b,(∑w:Z,‖geometry j z a w b‖)≤G j)
    (F:PhysicalMemoryState (Z:=Z) P Line J B → ℝ)
    (hF:∀s,F s≤physicalMemorySchurWeight v0 s)
    (n j:ℕ) (s:PhysicalMemoryState (Z:=Z) P Line J B)
    (r:Registry I J B) :
    (∑h:ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s,
      if plan.Allowed ν V η q ρ anchor geometry value n j s h r then ‖h.weight‖*F h.final else 0) ≤
      plan.wordFactor ν V η ρ v0 G j n * Δ^(plan.futureCount j n) *physicalMemorySchurWeight v0 s := by
  let GS j := PhysicalPrescriptionSteps.ghost ν V (η j) (q j) ρ v0 Δ anchor value hinj
    (plan.ghostSlots j) (fun r=>ghostTarget value plan.pivot r j)
    (fun _ r c=>afterGhost value j c r) hν hV (hη j) (hq j) hρ hv0 (hp j) hΔ hatom
  let ES j := PhysicalPrescriptionSteps.edge ν V ρ v0 (G j) Δ anchor (geometry j) value hinj
    (plan.edgeGroups j) (fun r=>edgeTarget plan.pivot r j)
    (fun _ r c=>afterEdge value j c r) hν hV hρ.le hρ1 hv0 (hG j) hΔ hatom (hgeometry j)
  induction n generalizing j s r with
  | zero =>
      have hh := restricted_cons_le (GS j).operation [] (physicalMemorySchurWeight v0) F s
        ((GS j).allowed s r) (fun _ _=>True) ((GS j).factor*Δ^(GS j).count) 1 (by norm_num)
        ((GS j).row_bound s r) (fun c=>by simpa [ChoiceOperation.History.weight,ChoiceOperation.History.final] using hF ((GS j).operation.output s c.val c.property))
      simpa only [PivotPlan.Allowed,GS,PhysicalPrescriptionSteps.ghost,ActualHistoryBirths.operations,
        memoryOperationsFrom,ChoiceOperation.History.weight,ChoiceOperation.History.final,and_true,
        PivotPlan.wordFactor,PivotPlan.futureCount,ghostFactor,mul_one] using hh
  | succ n ih =>
      let D:=plan.wordFactor ν V η ρ v0 G (j+1) n*Δ^(plan.futureCount (j+1) n)
      have hD:0≤D := mul_nonneg (wordFactor_nonneg ν V η ρ v0 G plan hV hη hρ.le hv0.le hG _ _) (pow_nonneg hΔ _)
      have he:0≤(ES j).factor*Δ^(ES j).count:=mul_nonneg (ES j).factor_nonneg (pow_nonneg hΔ _)
      have hh := restricted_cons_le (GS j).operation
        ((ES j).operation::ActualHistoryBirths.operations ν V η q ρ anchor geometry (j+1) n)
        (physicalMemorySchurWeight v0) F s ((GS j).allowed s r)
        (fun c h=> (ES j).allowed _ ((GS j).update s r c) h.1 ∧
          plan.Allowed ν V η q ρ anchor geometry value n (j+1) _ h.2
            ((ES j).update _ ((GS j).update s r c) h.1))
        ((GS j).factor*Δ^(GS j).count) (((ES j).factor*Δ^(ES j).count)*D)
        (mul_nonneg he hD) ((GS j).row_bound s r) ?_
      · convert hh using 1
        · apply Finset.sum_congr rfl
          intro h _
          dsimp only [GS,ES,PhysicalPrescriptionSteps.ghost,PhysicalPrescriptionSteps.edge]
          by_cases ha:plan.Allowed ν V η q ρ anchor geometry value (n+1) j s h r
          · simp only [ite_eq_left ha]
            apply (ite_eq_left _).symm
            exact ha
          · simp only [ite_eq_right ha]
            apply (ite_eq_right _).symm
            exact ha
        · simp only [GS,ES,PhysicalPrescriptionSteps.ghost,PhysicalPrescriptionSteps.edge,
            PivotPlan.wordFactor,PivotPlan.futureCount,ghostFactor,edgeFactor,pow_add,D]
          ring
      · intro c
        let sg := (GS j).operation.output s c.val c.property
        let rg := (GS j).update s r c
        have ht := restricted_cons_le (ES j).operation
          (ActualHistoryBirths.operations ν V η q ρ anchor geometry (j+1) n)
          (physicalMemorySchurWeight v0) F sg ((ES j).allowed sg rg)
          (fun d h=>plan.Allowed ν V η q ρ anchor geometry value n (j+1)
            ((ES j).operation.output sg d.val d.property) h ((ES j).update sg rg d))
          ((ES j).factor*Δ^(ES j).count) D hD ((ES j).row_bound sg rg)
          (fun d=>ih (j+1) ((ES j).operation.output sg d.val d.property) ((ES j).update sg rg d))
        exact ht

end Elliptic.Operator.PhysicalBirthRegistry
