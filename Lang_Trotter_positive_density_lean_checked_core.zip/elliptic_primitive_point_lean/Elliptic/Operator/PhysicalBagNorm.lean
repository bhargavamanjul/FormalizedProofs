module

public import Elliptic.Operator.PhysicalBagMeasure
public import Elliptic.Operator.PhysicalGhostNorm
public import Elliptic.Operator.PhysicalMaskedSchur

/-! Exact transfer between the original factorial L2 norm and the finite
bag quotient, including its total-memory zero extension. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBagNorm
open scoped BigOperators
open PhysicalMaskedKernel PhysicalEdgeAdjoint
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B : ℕ}

 def cutoff (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  if Total s then F s else 0

 theorem cutoff_ofOrdered (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : cutoff F (ofOrdered s)=F (ofOrdered s) := by
  simp [cutoff,total_ofOrdered]

 theorem pullback_norm (ν : ∀i,P i→ℝ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (fun s=>F (ofOrdered s)) =
      finiteL2 Finset.univ (mass ν) (cutoff F) := by
  unfold finiteL2 finiteL2Sq
  congr 1
  rw [PhysicalBagMeasure.physical_integral_eq_bag ν (fun s=>‖F s‖^2)]
  apply Finset.sum_congr rfl
  intro s _
  by_cases hs : Total s <;> simp [cutoff,hs]

 theorem pullback_norm_eq (ν : ∀i,P i→ℝ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (hF : ∀s,¬Total s→F s=0) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (fun s=>F (ofOrdered s)) =
      finiteL2 Finset.univ (mass ν) F := by
  rw [pullback_norm]
  congr 1
  funext s
  by_cases hs : Total s <;> simp [cutoff,hs,hF]

 def representative
    (H : Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  cutoff (fun t=>H (position t) (active t) (fun i=>(bags t i).val)) s

 theorem representative_pullback
    (H : Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ) :
    (fun s=>representative H (ofOrdered s))=physicalBagFunction (B:=B) H := by
  funext s
  rw [representative,cutoff_ofOrdered]
  rfl

 def extension (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (z : Z) (a : PhysicalActiveLists P J)
    (b : ∀i,Multiset (AnchoredParticle (P i) (Line i))) : ℂ :=
  if hb : ∀i,b i∈memoryBagRange (AnchoredParticle (P i) (Line i)) B then
    F (z,a,fun i=>⟨b i,hb i⟩) else 0

 theorem extension_pullback (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ) :
    physicalBagFunction (extension F)=(fun s=>F (ofOrdered s)) := by
  funext s
  have hb : ∀i,tupleBag (s.memory P Line J B i).values∈memoryBagRange (AnchoredParticle (P i) (Line i)) B :=
    fun i=>(memoryBagOf (s.memory P Line J B i)).property
  simp only [physicalBagFunction,extension,dif_pos hb]
  rfl

 def IsBagFunction (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) : Prop :=
  ∃f : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,F=fun s=>f (ofOrdered s)

 theorem isBagFunction_iff (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) :
    IsBagFunction F ↔ ∃H,F=physicalBagFunction H := by
  constructor
  · rintro ⟨f,rfl⟩
    exact ⟨extension f,(extension_pullback f).symm⟩
  · rintro ⟨H,rfl⟩
    exact ⟨representative H,(representative_pullback H).symm⟩

end Elliptic.Operator.PhysicalBagNorm
