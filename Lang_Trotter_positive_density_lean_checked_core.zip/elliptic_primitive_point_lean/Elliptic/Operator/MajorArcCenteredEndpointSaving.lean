module
public import Elliptic.Operator.MajorArcCenteredWindow

/-! Literal centered major-arc endpoint energy with source scale cancellation. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcCenteredEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest MellinPrimeSeparation
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem uniform_centered_endpoint_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (δ c Cprime Ccoef J E Alam Crem A₀ c₁ c₂ : ℝ)
    (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime) (hcoef : 0≤Ccoef) (hJ : 0≤J)
    (hE : 0≤E) (hAlam : 0≤Alam) (hCrem : 0≤Crem) (hA₀ : 0<A₀)
    {I : Type} (Hm Hn : ℝ→I→ℝ) (active : ℝ→I→Prop) (α : ℝ→I→ℕ→ℂ)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel : ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα : ∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^Ccoef) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→
      ∀P:ℝ,0<P→c*(Real.log x)^(1/10:ℝ)≤Real.log P→Real.log P≤Cprime*(Real.log x)^(1/5:ℝ)→
      ∀S:Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q:ℕ)(χ:DirichletCharacter ℂ q),∀s t:Finset ℕ,IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^Ccoef)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀l:ℕ,
      ∀(χm:DirichletCharacter ℂ k)(χn:DirichletCharacter ℂ l),
      ∀(R:Finset ℕ)(d:ℕ→ℂ),(∀r∈R,0<r)→∀lam Y:ℝ,0<Y→|lam|≤(Real.log x)^Alam→
      (P/Y)*(∑r∈R,‖d r‖)≤(Real.log x)^Crem→∀u:ℝ,|u|≤(Hm x j*Hn x j)*(Real.log x)^J→
      (∫v in Icc (u-(Hm x j*Hn x j)*(Real.log x)^J) (u+(Hm x j*Hn x j)*(Real.log x)^J),
        ‖(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y v*
          longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2)≤(Real.log x)^(-E) := by
  have hcell := MajorArcScaleEndpointSaving.uniform_actual_endpoint_energy hvdC hD η hη lo hi hlo hsupp
    δ c Cprime Ccoef (J+1) E Alam Crem A₀ (J+1) c₁ c₂ hδ hc hC hcoef (by linarith)
    hE hAlam hCrem hA₀ (by linarith) Hm Hn active α hscale hcancel hα
  filter_upwards [hcell,hscale,Real.tendsto_log_atTop.eventually (MajorArcCenteredWindow.eventually_rpow_le_exp (J+1)),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (3:ℝ)),eventually_ge_atTop c₂,
    eventually_gt_atTop (0:ℝ)] with x hcell hscale hpow hL hxC hx
  intro j hj P hP hplo hphi S hprime hShi q χ s t hs ht β hβ k hk hkmax l χm χn R d hR lam Y hY hlam hrem u hu
  let F : ℝ→ℂ := fun v=>(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y v*
    longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v
  have hFc : Continuous F := by
    have he : Continuous (endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y) := by
      unfold endpoint Artin.MarkedReplacement.archimedeanPhase
      fun_prop
    exact ((continuous_const.mul he).mul (longPolynomial_continuous s (α x j) (Hm x j) χm)).mul
      (longPolynomial_continuous t β (Hn x j) χn)
  have hsc := hscale j hj
  have hX : 1≤Hm x j*Hn x j := by nlinarith [hsc.1,hsc.2.1]
  have hXmax : Hm x j*Hn x j≤Real.exp (2*Real.log x) := by
    calc
      _ ≤ c₂*x := hsc.2.2.2.2.2
      _ ≤ x*x := mul_le_mul_of_nonneg_right hxC hx.le
      _ = _ := by rw [two_mul,Real.exp_add,Real.exp_log hx]
  apply MajorArcCenteredWindow.centered_energy_of_cell_bound (Real.log x) (Hm x j*Hn x j) J
    ((Real.log x)^(-E)) hL hX hJ hXmax hpow F hFc _ u hu
  intro K hK hKmax hKprod a hfreq
  exact hcell j hj K hK hKmax hKprod a P hP hplo hphi S hprime hShi q χ s t hs ht β hβ
    k hk hkmax l χm χn hfreq R d hR lam Y hY hlam hrem

end Elliptic.Operator.MajorArcCenteredEndpointSaving
