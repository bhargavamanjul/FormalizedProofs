module
public import Elliptic.Operator.SignedPairExpansion
public import Elliptic.Operator.SingleEdgeEndpointRestoration

/-! The literal coordinate bridge between the successor pair square
and a physical single edge. The source fresh product is the second
record's label product; the target fresh product is the first record's.
Consequently the actual successor sign is minus one. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators ComplexConjugate
open Artin Artin.MarkedCriterion
open SingleEdgeRootIncidence SingleEdgePhysicalRestoration
attribute [local instance] Classical.propDecidable
local instance pairBridgeDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

/-- A physical endpoint in source coordinates (3.17). -/
def position (D b m s : ℕ) : ℤ × ℤ := ((D*b*m:ℕ),s)

def scalarDet (a b m n r s : ℕ) : ℤ := (b:ℤ)*m*n-(a:ℤ)*r*s

theorem position_det (D a b m n r s : ℕ) :
    latticeDet (position D b m s) (position D a r n)=(D:ℤ)*scalarDet a b m n r s := by
  simp only [position,latticeDet,scalarDet,Nat.cast_mul]
  ring

theorem position_pad_dvd (D a b m n r s : ℕ) :
    (D:ℤ)∣latticeDet (position D b m s) (position D a r n) := by
  rw [position_det]
  exact dvd_mul_right _ _

theorem position_det_quotient (D a b m n r s : ℕ) (hD : D≠0) :
    latticeDet (position D b m s) (position D a r n)/(D:ℤ)=scalarDet a b m n r s := by
  rw [position_det,Int.mul_ediv_cancel_left _ (by exact_mod_cast hD)]

/-- A small-prime product is coprime to every rough coefficient index. -/
theorem small_product_coprime_rough (W : ℝ) (c n : ℕ)
    (hc : ∀ p, p.Prime → p∣c → (p:ℝ)≤W) (hn : IsRough W n) : c.Coprime n := by
  by_contra h
  obtain ⟨p,hp,hpc,hpn⟩ := Nat.Prime.not_coprime_iff_dvd.mp h
  exact (not_lt_of_ge (hc p hp hpc)) (hn p hp hpn)

/-- The determinant cannot vanish when a nontrivial fresh product is
coprime to every factor on the opposite side. -/
theorem scalarDet_ne_zero (a b m n r s : ℕ) (hb : 1<b)
    (hcop : b.Coprime (a*r*s)) : scalarDet a b m n r s≠0 := by
  intro hz
  have he : b*m*n=a*r*s := by
    exact_mod_cast (sub_eq_zero.mp hz : (b:ℤ)*m*n=(a:ℤ)*r*s)
  have hd : b∣a*r*s := he ▸ dvd_mul_of_dvd_left (dvd_mul_right b m) n
  have hone := Nat.eq_one_of_dvd_coprimes hcop (dvd_refl b) hd
  omega

/-- Roughness and the determinant cutoff force source primitivity;
this is the argument after source (3.18), with no primitive hypothesis. -/
theorem position_primitive_of_small_det (D a b m n r s : ℕ) (W : ℝ)
    (hsmall : (D*b).Coprime s) (hs : IsRough W s)
    (hb : 1<b) (hcop : b.Coprime (a*r*s))
    (hdet : |(scalarDet a b m n r s:ℝ)|≤W) :
    IsCoprime (position D b m s).1 (position D b m s).2 := by
  apply Nat.Coprime.isCoprime
  by_contra h
  obtain ⟨p,hp,hpD,hps⟩ := Nat.Prime.not_coprime_iff_dvd.mp h
  have hpm : p∣m := by
    rcases hp.dvd_mul.mp hpD with h | h
    · have hone := Nat.eq_one_of_dvd_coprimes hsmall h hps
      exact False.elim (hp.ne_one hone)
    · exact h
  have hpZ : (p:ℤ)∣(m:ℤ) := by exact_mod_cast hpm
  have hsZ : (p:ℤ)∣(s:ℤ) := by exact_mod_cast hps
  have hpt : (p:ℤ)∣scalarDet a b m n r s :=
    dvd_sub (dvd_mul_of_dvd_left (dvd_mul_of_dvd_right hpZ _) _)
      (dvd_mul_of_dvd_right hsZ _)
  have hne := scalarDet_ne_zero a b m n r s hb hcop
  have hle := Int.natAbs_le_of_dvd_ne_zero hpt hne
  have hpZ' : (p:ℤ)≤|scalarDet a b m n r s| := by
    rw [←Int.natCast_natAbs]
    exact_mod_cast hle
  have hpR : (p:ℝ)≤|(scalarDet a b m n r s:ℝ)| := by exact_mod_cast hpZ'
  exact (not_lt_of_ge (hpR.trans hdet)) (hs p hp hps)

/-- The actual successor relation is exactly the physical raw indicator
for sigma = -1, including the source/target label swap. -/
theorem successor_raw_iff (D a b m n r s : ℕ) (hD : D≠0)
    (ha : 0<a) (hb : 0<b) (hab : a.Coprime b) :
    (∃ h : ℕ,0<h ∧ m*n+1=a*h ∧ r*s+1=b*h) ↔
      latticeDet (position D b m s) (position D a r n)/(D:ℤ)=
        (-1:ℤ)*((b:ℤ)-a) := by
  rw [position_det_quotient D a b m n r s hD]
  have he : (-1:ℤ)*((b:ℤ)-a)=(a:ℤ)-b := by ring
  rw [he]
  exact SignedDeterminantReduction.successor_determinant_iff a b m n r s ha hb hab

variable {I : Type} [Fintype I] {P : I → Type} {J : ℕ}

def activeProduct (value : ∀ i,P i→ℕ) (a : PhysicalActiveLists P J) : ℕ :=
  ∏ i,∏ j,value i (a i j)

theorem activeProduct_eq (value : ∀ i,P i→ℕ) (a : PhysicalActiveLists P J) :
    activeProduct value a=sourcePadProduct value a*sourceUnsharedProduct value a := by
  unfold activeProduct sourcePadProduct sourceUnsharedProduct
  simp_rw [Fin.prod_univ_castSucc]
  rw [Finset.prod_mul_distrib]

theorem label_dvd_activeProduct (value : ∀ i,P i→ℕ) (a : PhysicalActiveLists P J)
    (i : I) (j : Fin (J+1)) : value i (a i j)∣activeProduct value a := by
  exact (Finset.dvd_prod_of_mem (fun j=>value i (a i j)) (Finset.mem_univ j)).trans
    (Finset.dvd_prod_of_mem (fun i=>∏j,value i (a i j)) (Finset.mem_univ i))

theorem activeProduct_pos (value : ∀ i,P i→ℕ) (hp : ∀ i p,0<value i p)
    (a : PhysicalActiveLists P J) : 0<activeProduct value a :=
  Finset.prod_pos (fun i _=>Finset.prod_pos (fun j _=>hp i (a i j)))

theorem activeProduct_coprime_rough (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (W : ℝ) (hsmall : ∀ i p,(value i p:ℝ)≤W)
    (a : PhysicalActiveLists P J) (n : ℕ) (hn : IsRough W n) :
    (activeProduct value a).Coprime n := by
  apply Nat.Coprime.prod_left
  intro i hi
  apply Nat.Coprime.prod_left
  intro j hj
  apply (hprime i (a i j)).coprime_iff_not_dvd.mpr
  intro hd
  exact (not_lt_of_ge (hsmall i (a i j))) (hn _ (hprime i _) hd)

theorem unsharedProduct_coprime_rough (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (W : ℝ) (hsmall : ∀ i p,(value i p:ℝ)≤W)
    (a : PhysicalActiveLists P J) (n : ℕ) (hn : IsRough W n) :
    (sourceUnsharedProduct value a).Coprime n := by
  apply Nat.Coprime.prod_left
  intro i hi
  apply (hprime i (a i (Fin.last J))).coprime_iff_not_dvd.mpr
  intro hd
  exact (not_lt_of_ge (hsmall i (a i (Fin.last J)))) (hn _ (hprime i _) hd)

theorem unsharedProducts_coprime (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (a b : PhysicalActiveLists P J)
    (hban : sourceCrossEdgeBan value a b) :
    (sourceUnsharedProduct value a).Coprime (sourceUnsharedProduct value b) := by
  apply Nat.Coprime.prod_left
  intro i hi
  apply Nat.Coprime.prod_right
  intro k hk
  apply (Nat.coprime_primes (hprime i _) (hprime k _)).mpr
  intro he
  have hx := hban.2 (show sourceCrossEdgeLabels value a b (i,Sum.inr false)=
    sourceCrossEdgeLabels value a b (k,Sum.inr true) from he)
  have hh := congrArg Prod.snd hx
  cases hh

theorem one_lt_unsharedProduct [Nonempty I] (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (a : PhysicalActiveLists P J) :
    1<sourceUnsharedProduct value a := by
  obtain ⟨i⟩ := ‹Nonempty I›
  have hp : 0<sourceUnsharedProduct value a := Finset.prod_pos (fun k _=>(hprime k _).pos)
  have hd : value i (a i (Fin.last J))∣sourceUnsharedProduct value a :=
    Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
  exact lt_of_lt_of_le (hprime i _).one_lt (Nat.le_of_dvd hp hd)

/-- Both primitive endpoint conditions follow from the actual label ban,
rough coefficient support and the small determinant cutoff. -/
theorem padded_endpoints_primitive [Nonempty I] (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (W : ℝ) (hsmall : ∀ i p,(value i p:ℝ)≤W)
    (a b : PhysicalActiveLists P J) (hban : sourceCrossEdgeBan value a b)
    (m n r s : ℕ) (hm : IsRough W m) (hn : IsRough W n)
    (hr : IsRough W r) (hs : IsRough W s)
    (hdet : |(scalarDet (sourceUnsharedProduct value b) (sourceUnsharedProduct value a) m n r s:ℝ)|≤W) :
    IsCoprime (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s).1
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s).2 ∧
    IsCoprime (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n).1
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n).2 := by
  have hcop := unsharedProducts_coprime value hprime a b hban
  constructor
  · apply position_primitive_of_small_det (sourcePadProduct value a)
      (sourceUnsharedProduct value b) (sourceUnsharedProduct value a) m n r s W
    · rw [←activeProduct_eq]
      exact activeProduct_coprime_rough value hprime W hsmall a s hs
    · exact hs
    · exact one_lt_unsharedProduct value hprime a
    · exact (hcop.mul_right (unsharedProduct_coprime_rough value hprime W hsmall a r hr)).mul_right
        (unsharedProduct_coprime_rough value hprime W hsmall a s hs)
    · exact hdet
  · apply position_primitive_of_small_det (sourcePadProduct value a)
      (sourceUnsharedProduct value a) (sourceUnsharedProduct value b) r s m n W
    · rw [←sourcePadProduct_eq_of_copied value a b hban.1,←activeProduct_eq]
      exact activeProduct_coprime_rough value hprime W hsmall b n hn
    · exact hn
    · exact one_lt_unsharedProduct value hprime b
    · exact (hcop.symm.mul_right (unsharedProduct_coprime_rough value hprime W hsmall b m hm)).mul_right
        (unsharedProduct_coprime_rough value hprime W hsmall b n hn)
    · have he : scalarDet (sourceUnsharedProduct value a) (sourceUnsharedProduct value b) r s m n=
          -scalarDet (sourceUnsharedProduct value b) (sourceUnsharedProduct value a) m n r s := by
        unfold scalarDet
        ring
      simpa only [he,Int.cast_neg,abs_neg] using hdet

/-- The complete first-coordinate part supported on designated primes.
On the rough endpoint support it is squarefree, so this radical product
is exactly the full active-list product. -/
def supportedPart (primes : Finset ℕ) (n : ℕ) : ℕ :=
  ∏ p∈primes.filter (fun p=>p∣n),p

theorem supportedPart_active_mul (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (primes : Finset ℕ)
    (hpool : ∀p∈primes,p.Prime)
    (a : PhysicalActiveLists P J)
    (hinj : Function.Injective (fun ij : I×Fin (J+1)=>value ij.1 (a ij.1 ij.2)))
    (hmem : ∀ i j,value i (a i j)∈primes) (n : ℕ)
    (hn : ∀ p∈primes,¬p∣n) :
    supportedPart primes (activeProduct value a*n)=activeProduct value a := by
  let labels := fun ij : I×Fin (J+1)=>value ij.1 (a ij.1 ij.2)
  have hp : activeProduct value a=∏ij,labels ij := by
    rw [Fintype.prod_prod_type]
    rfl
  have hs : primes.filter (fun p=>p∣activeProduct value a*n)=Finset.univ.image labels := by
    ext p
    simp only [Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨hpr,hd⟩
      have hd' : p∣activeProduct value a := ((hpool p hpr).dvd_mul.mp hd).resolve_right (hn p hpr)
      rw [hp] at hd'
      obtain ⟨ij,_,hij⟩ := ((hpool p hpr).prime.dvd_finsetProd_iff labels).mp hd'
      exact ⟨ij,((Nat.prime_dvd_prime_iff_eq (hpool p hpr) (hprime ij.1 _)).mp hij).symm⟩
    · rintro ⟨ij,rfl⟩
      exact ⟨hmem ij.1 ij.2,dvd_mul_of_dvd_left (label_dvd_activeProduct value a ij.1 ij.2) n⟩
  unfold supportedPart
  rw [hs,Finset.prod_image (fun _ _ _ _ h=>hinj h)]
  exact hp.symm

/-- The literal endpoint observables depend only on the integer position,
not on its ordered lists. The conjugations recover the complex Cauchy
square without any real-coefficient assumption. -/
def leftEndpoint (primes : Finset ℕ) (α β : ℕ→ℂ) (z : ℤ×ℤ) : ℂ :=
  α (z.1.toNat/supportedPart primes z.1.toNat)*conj (β z.2.toNat)

def rightEndpoint (primes : Finset ℕ) (α β : ℕ→ℂ) (z : ℤ×ℤ) : ℂ :=
  conj (α (z.1.toNat/supportedPart primes z.1.toNat))*β z.2.toNat

theorem leftEndpoint_position (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (primes : Finset ℕ)
    (hpool : ∀p∈primes,p.Prime) (a : PhysicalActiveLists P J)
    (hinj : Function.Injective (fun ij : I×Fin (J+1)=>value ij.1 (a ij.1 ij.2)))
    (hmem : ∀ i j,value i (a i j)∈primes) (m s : ℕ)
    (hm : ∀ p∈primes,¬p∣m) (α β : ℕ→ℂ) :
    leftEndpoint primes α β
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s)=
        α m*conj (β s) := by
  have hh := supportedPart_active_mul value hprime primes hpool a hinj hmem m hm
  have hp := activeProduct_pos value (fun i p=>(hprime i p).pos) a
  simp only [leftEndpoint,position,Int.toNat_natCast]
  rw [←activeProduct_eq,hh,Nat.mul_div_cancel_left _ hp]

theorem rightEndpoint_position (value : ∀ i,P i→ℕ)
    (hprime : ∀ i p,(value i p).Prime) (primes : Finset ℕ)
    (hpool : ∀p∈primes,p.Prime) (a : PhysicalActiveLists P J)
    (hinj : Function.Injective (fun ij : I×Fin (J+1)=>value ij.1 (a ij.1 ij.2)))
    (hmem : ∀ i j,value i (a i j)∈primes) (m s : ℕ)
    (hm : ∀ p∈primes,¬p∣m) (α β : ℕ→ℂ) :
    rightEndpoint primes α β
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s)=
        conj (α m)*β s := by
  have hh := congrArg conj (leftEndpoint_position value hprime primes hpool a hinj hmem m s hm α β)
  simpa only [leftEndpoint,rightEndpoint,map_mul,Complex.conj_conj] using hh

theorem rough_excludes_pool (primes : Finset ℕ) (W : ℝ)
    (hpool : ∀p∈primes,p.Prime) (hsmall : ∀p∈primes,(p:ℝ)≤W)
    (n : ℕ) (hn : IsRough W n) : ∀ p∈primes,¬p∣n := by
  intro p hp hd
  exact (not_lt_of_ge (hsmall p hp)) (hn p (hpool p hp) hd)

/-- Every actual active label divides the padded first coordinate. -/
theorem position_incidence (value : ∀ i,P i→ℕ) (a b : PhysicalActiveLists P J)
    (hcopy : ∀ i (j : Fin J),b i j.castSucc=a i j.castSucc) (m n r s : ℕ) :
    physicalIncidence value a b
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s)
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n) := by
  have ha (i) (j : Fin (J+1)) := label_dvd_activeProduct value a i j
  have hb (i) (j : Fin (J+1)) := label_dvd_activeProduct value b i j
  simp only [activeProduct_eq] at ha hb
  rw [sourcePadProduct_eq_of_copied value a b hcopy] at hb
  constructor
  · intro i j
    change (value i (a i j):ℤ)∣(sourcePadProduct value a*sourceUnsharedProduct value a*m:ℕ)
    exact_mod_cast dvd_mul_of_dvd_left (ha i j) m
  · intro i j
    change (value i (b i j):ℤ)∣(sourcePadProduct value a*sourceUnsharedProduct value b*r:ℕ)
    exact_mod_cast dvd_mul_of_dvd_left (hb i j) r

/-- The padded position is in the exact physical box, with the source's
factor 16 coming from D<2d0, b<=4Y and m<=2Hm. -/
theorem position_allowed (D b m s : ℕ) (d₀ Y Hm Hn : ℝ)
    (hd : 0≤d₀) (hY : 0≤Y) (hHm : 0≤Hm)
    (hD : d₀≤(D:ℝ)) (hD' : (D:ℝ)≤2*d₀)
    (hb : Y≤(b:ℝ)) (hb' : (b:ℝ)≤4*Y)
    (hm : Hm≤(m:ℝ)) (hm' : (m:ℝ)≤2*Hm)
    (hs : Hn≤(s:ℝ)) (hs' : (s:ℝ)≤2*Hn)
    (hprim : IsCoprime (position D b m s).1 (position D b m s).2) :
    sourcePhysicalPositionAllowed 1 0 0 (d₀*Y*Hm) Hn (position D b m s) := by
  refine ⟨hprim,?_,?_,?_,?_⟩
  all_goals simp only [rootPhysicalPosition,latticeTau,position,zero_mul,add_zero,
    zero_add,one_mul,div_one,Nat.cast_mul,Int.cast_mul,Int.cast_natCast]
  · exact mul_le_mul (mul_le_mul hD hb hY (Nat.cast_nonneg _)) hm hHm
      (mul_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))
  · calc
      _ ≤ (2*d₀)*(4*Y)*(2*Hm) := by gcongr
      _ = _ := by ring
  · exact hs
  · exact hs'

/-- Formula-level physical single-edge kernel, with the actual padding,
incidence, dyadic and primitive-box restrictions discharged. -/
theorem physicalKernel_position {K : ℕ} {P : Fin K→Type} [∀ i,Fintype (P i)] {J : ℕ}
    (value : ∀ i,P i→ℕ) (a b : PhysicalActiveLists P J)
    (hban : sourceCrossEdgeBan value a b) (m n r s : ℕ)
    (U V d₀ Y H : ℝ) (η ψ : ℝ→ℂ)
    (hD0 : sourcePadProduct value a≠0)
    (hD : d₀≤(sourcePadProduct value a:ℝ))
    (hD' : (sourcePadProduct value a:ℝ)<2*d₀)
    (hz : sourcePhysicalPositionAllowed 1 0 0 U V
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s))
    (hw : sourcePhysicalPositionAllowed 1 0 0 U V
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n)) :
    let D := sourcePadProduct value a
    let B := sourceUnsharedProduct value a
    let A := sourceUnsharedProduct value b
    physicalKernel value (fun _ _=>True) U V d₀ Y H η ψ (-1)
      (position D B m s,a) (position D A r n,b) =
      ((d₀/(D:ℝ):ℝ):ℂ)*η ((B:ℝ)/Y)*η ((A:ℝ)/Y)*
        ψ ((scalarDet A B m n r s:ℝ)/Y)*
          ((if scalarDet A B m n r s=(A:ℤ)-B then 1 else 0)-
            minorFourierTransform (sourceMajorArcs H Y) (scalarDet A B m n r s+B-A)) := by
  dsimp only
  have hi := position_incidence value a b hban.1 m n r s
  have hall : sourcePhysicalEdgeAllowed value (fun _ _=>True) 1 0 0 U V d₀
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m s) a
      (position (sourcePadProduct value a) (sourceUnsharedProduct value b) r n) b :=
    ⟨hz,hw,trivial,trivial,hban,hD,hD',position_pad_dvd _ _ _ _ _ _ _⟩
  simp only [physicalKernel,ite_eq_left hi,sourcePhysicalEdgeGeometry,ite_eq_left hall]
  rw [position_det_quotient _ _ _ _ _ _ _ hD0]
  congr 2
  · congr 1
    ring
  · congr 1
    ring

end Elliptic.Operator.SignedPhysicalPairBridge
