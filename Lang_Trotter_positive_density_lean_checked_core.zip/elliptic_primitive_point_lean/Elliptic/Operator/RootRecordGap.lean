module

public import Elliptic.Operator.RootRecordBonferroni
public import Elliptic.Operator.RootRecordAccumulation

/-!
# The actual independent-line gap for original records

This evaluates the numerical-prime loss polynomial on its literal finite
product of line spaces and absorbs the original normalization and record
count. The only mass input is the displayed prime reciprocal sum.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordGap
open scoped BigOperators
open Filter SourceBonferroni RootRecordBonferroni OriginalPathWeights
open IntegerRootReplacement RootDiscreteBudget BonferroniBudget
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

theorem elementary_map {α β : Type*} [DecidableEq α] [DecidableEq β]
    (e : α↪β) (s : Finset α) (w : β→ℝ) (k : ℕ) :
    elementary (s.map e) w k = elementary s (fun p=>w (e p)) k := by
  unfold elementary
  rw [Finset.powersetCard_map,Finset.sum_map]
  apply Finset.sum_congr rfl
  intro t ht
  exact Finset.prod_map t e w

theorem elementary_subtype (primes : Finset ℕ) (w : ℕ→ℝ) (k : ℕ) :
    elementary primes w k = elementary Finset.univ (fun p : primes=>w p) k := by
  have he : Finset.univ.map (Function.Embedding.subtype (fun p=>p∈primes))=primes := by
    ext p
    simp
  simpa only [he,Function.Embedding.subtype_apply] using elementary_map (Function.Embedding.subtype (fun p=>p∈primes)) Finset.univ w k

/-- Outside the selected prime pool no line coordinate is needed. -/
def extendLines (primes : Finset ℕ) (ℓ : ∀p : primes,Option (ZMod p))
    (p : ℕ) : Option (ZMod p) :=
  if hp : p∈primes then ℓ ⟨p,hp⟩ else none

@[simp] theorem extendLines_mem (primes : Finset ℕ)
    (ℓ : ∀p : primes,Option (ZMod p)) (p : primes) : extendLines primes ℓ p=ℓ p := by
  simp [extendLines,p.property]

def gap (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ) (k : ℕ) : ℝ :=
  uniformAverage (fun ℓ : ∀p : primes,Option (ZMod p)=>
    elementary primes (fun p=>loss rec η p (extendLines primes ℓ p)) k)

theorem gap_eq_elementary (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ) (k : ℕ) :
    gap rec primes η k = elementary Finset.univ
      (fun p : primes=>uniformAverage (loss rec η p)) k := by
  unfold gap
  simp_rw [elementary_subtype,extendLines_mem]
  exact uniformAverage_elementary (fun p : primes=>Option (ZMod p)) Finset.univ
    (fun p=>loss rec η p) k

theorem loss_average_le (rec : Record K J N R Q) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (p : ℕ) [Fact p.Prime] :
    uniformAverage (loss rec η p) ≤ ((N:ℝ)+1)/((p:ℝ)+1) := by
  by_cases hp : p∈activePrimes rec
  · have he : loss rec η p=(fun _=>0) := by funext l; simp [loss,hp]
    rw [he,uniformAverage_const]
    positivity
  · have h := inactiveLoss_average_le (Finset.range (N+1))
      (fun t=>primeResidueAnchor p (positionAt rec t)) η
      (fun j hj=>hη j (Finset.mem_range.mp hj))
    have hs : (∑j∈Finset.range (N+1),η j)≤(N:ℝ)+1 := by
      calc
        _ ≤ ∑j∈Finset.range (N+1),(1:ℝ) :=
          Finset.sum_le_sum (fun j hj=>(hη j (Finset.mem_range.mp hj)).2)
        _ = _ := by simp
    have he : loss rec η p=inactiveLoss (Finset.range (N+1))
        (fun t=>primeResidueAnchor p (positionAt rec t)) η := by
      funext l
      simp [loss,hp]
    rw [he]
    exact h.trans (by
      simp only [Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one]
      gcongr)

theorem gap_nonneg (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (k : ℕ) : 0≤gap rec primes η k := by
  unfold gap uniformAverage
  apply mul_nonneg (by positivity)
  apply Finset.sum_nonneg
  intro ℓ hℓ
  exact elementary_nonneg _ _ (fun p hp=>(loss_bounds rec η hη p _).1) _

theorem gap_moment_bound (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact (p.val).Prime] (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (k : ℕ) (t : ℝ) (ht : 0≤t)
    (C : ℝ) (hC : ∑p∈primes,1/((p:ℝ)+1)≤C) :
    gap rec primes η k*t^k ≤ Real.exp (t*(C*((N:ℝ)+1))) := by
  rw [gap_eq_elementary]
  have h := elementary_mul_pow_le_exp Finset.univ
    (fun p : primes=>uniformAverage (loss rec η p))
    (fun p hp=>by
      unfold uniformAverage
      exact mul_nonneg (by positivity)
        (Finset.sum_nonneg (fun ℓ _=>(loss_bounds rec η hη p ℓ).1))) k t ht
  apply h.trans
  apply Real.exp_le_exp.mpr
  apply mul_le_mul_of_nonneg_left _ ht
  calc
    _ ≤ ∑p : primes, ((N:ℝ)+1)/((p:ℝ)+1) :=
      Finset.sum_le_sum (fun p _=>loss_average_le rec η hη p)
    _ = ((N:ℝ)+1)*(∑p∈primes,1/((p:ℝ)+1)) := by
      simp only [div_eq_mul_inv,one_mul]
      rw [←Finset.mul_sum]
      congr 1
      exact Finset.sum_coe_sort primes (fun p : ℕ=>((p:ℝ)+1)⁻¹)
    _ ≤ _ := by nlinarith

/-- Actual record gaps, uniformly after one growing-parameter threshold. -/
theorem eventually_record_gap (C A : ℝ) (hC : 0≤C) (hA : 0≤A) :
    ∀ᶠ L : ℝ in atTop, ∀ K J R Q : ℕ, ∀ rec : Record K J (momentLength L) R Q,
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact (p.val).Prime], ∀ η : ℕ→ℝ,
      (∀j<momentLength L+1,0≤η j ∧ η j≤1) →
      (∑p∈primes,1/((p:ℝ)+1)≤C) →
      Real.exp (2*L^(73/100:ℝ))*gap rec primes η (2*truncationIndex L+1) ≤
        L^(-A*(momentLength L:ℝ)) := by
  filter_upwards [eventually_absorb_gap C 2 A hC (by norm_num) hA,
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<76/100)).eventually
      (eventually_ge_atTop (2:ℝ)),eventually_ge_atTop (0:ℝ)] with L hb hd hL
  intro K J R Q rec primes inst η hη hmass
  apply hb _ (C*((momentLength L:ℝ)+1)) _ le_rfl (depth_bounds L hd).1
  exact gap_moment_bound rec primes η hη _ _ (Real.rpow_nonneg hL _) C hmass

/-- The actual inverse-mass normalization and all original records cost
at most exp(2 L^.73); no abstract coefficient budget is assumed. -/
theorem eventually_normalized_card (K : ℕ) (C vmin : ℝ) (hC : 0≤C) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ records : Finset (SourceRecord K C L),
      ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      |normalization VM (momentPadding L) (momentLength L)| *(records.card:ℝ) ≤
        Real.exp (2*L^(73/100:ℝ)) := by
  filter_upwards [eventually_originalPathRecord_card_le_source_budget K C hC,
    eventually_inverse_mass_cost K vmin hmin] with L hrec hinv
  intro records VM hVM
  have hn := normalization_le VM vmin hmin hVM (momentPadding L) (momentLength L)
  have hcard : (records.card:ℝ)≤(Fintype.card (SourceRecord K C L):ℝ) := by
    exact_mod_cast Finset.card_le_univ records
  have hc : (records.card:ℝ)≤Real.exp (L^(73/100:ℝ)) := hcard.trans hrec
  rw [abs_of_nonneg hn.1]
  calc
    _ ≤ Real.exp (L^(73/100:ℝ))*Real.exp (L^(73/100:ℝ)) :=
      mul_le_mul (hn.2.trans hinv) hc (Nat.cast_nonneg _) (Real.exp_pos _).le
    _ = _ := by rw [←Real.exp_add]; congr 1; ring

/-- The positive line-model remainder is small after summing every
original numerical record with its literal normalization. -/
theorem eventually_accumulated_gap (K : ℕ) (C B A vmin : ℝ)
    (hC : 0≤C) (hB : 0≤B) (hA : 0≤A) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ records : Finset (SourceRecord K C L),
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact (p.val).Prime],
      ∀ η : ℕ→ℝ, (∀j<momentLength L+1,0≤η j ∧ η j≤1) →
      (∑p∈primes,1/((p:ℝ)+1)≤B) →
      ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      |normalization VM (momentPadding L) (momentLength L)| *
        (∑rec∈records,gap rec primes η (2*truncationIndex L+1)) ≤
          L^(-A*(momentLength L:ℝ)) := by
  filter_upwards [eventually_record_gap B A hB hA,
    eventually_normalized_card K C vmin hC hmin,eventually_gt_atTop (0:ℝ)] with L hg hc hL
  intro records primes inst η hη hmass VM hVM
  have hb (rec : SourceRecord K C L) : gap rec primes η (2*truncationIndex L+1) ≤
      L^(-A*(momentLength L:ℝ))/Real.exp (2*L^(73/100:ℝ)) := by
    apply (le_div_iff₀ (Real.exp_pos _)).mpr
    simpa only [mul_comm] using hg K (momentPadding L) (rootPositionRadius C L)
      (rootPrimeCeiling L) rec primes η hη hmass
  calc
    _ ≤ |normalization VM (momentPadding L) (momentLength L)| *
        ((records.card:ℝ)*(L^(-A*(momentLength L:ℝ))/Real.exp (2*L^(73/100:ℝ)))) := by
      apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
      simpa using Finset.sum_le_sum (fun rec _=>hb rec)
    _ = (|normalization VM (momentPadding L) (momentLength L)| *(records.card:ℝ))*
        (L^(-A*(momentLength L:ℝ))/Real.exp (2*L^(73/100:ℝ))) := by ring
    _ ≤ Real.exp (2*L^(73/100:ℝ))*
        (L^(-A*(momentLength L:ℝ))/Real.exp (2*L^(73/100:ℝ))) :=
      mul_le_mul_of_nonneg_right (hc records VM hVM) (by positivity)
    _ = _ := mul_div_cancel₀ _ (Real.exp_ne_zero _)

end Elliptic.Operator.RootRecordGap
