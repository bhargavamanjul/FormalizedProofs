module

public import Elliptic.Operator.PhysicalPathResidues

/-!
# The complete closed physical path moment in canonical root coordinates

The two endpoints share their position, but their active lists need not
agree. This is the unnormalized position-vector moment in PD (3.19).
All prime factors, damping, signed edges and permutations are retained.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootMomentReindex
open scoped BigOperators
open OriginalLifespanSchedule SourceRootCount SingleEdgeRootEncoding
open PhysicalPathRootEncoding PhysicalPathRootFinite PhysicalPathGeometry PhysicalPathResidues
attribute [local instance] Classical.propDecidable
local instance rootMomentDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def closedRootPaths (R : ℕ) : Finset (OriginalPath (Fin K) (ℤ×ℤ) P J N) :=
  (rootedPaths R).filter (fun r=>r.position (Fin.last N)=(1,0))

theorem physicalPath_closed_iff (t : RootTriple) (ht : Canonical t)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (hstart : r.position 0=(1,0)) :
    (physicalPath t r).position (Fin.last N)=(physicalPath t r).position 0 ↔
      r.position (Fin.last N)=(1,0) := by
  have hi : Function.Injective (decode t) := (coordinatesEquiv t ht).symm.injective
  change decode t (r.position (Fin.last N))=decode t (r.position 0) ↔ _
  rw [hi.eq_iff,hstart]

/-- The literal original closed-path sum equals a common finite sum of
rooted closed paths. No physical support or prime-incidence premise is
left: these have been proved from the actual edge multiplier. -/
theorem closed_moment_eq_roots (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V C : ℝ) (exponents : Fin K→ℝ) (hU : 0<U)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (hN : 0<N) (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (R : ℕ) (hR : ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊≤R)
    (primes : Finset ℕ) (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ) :
    (∑r∈positionPaths (J:=J) (N:=N) (primitiveSources U V),
      if r.position (Fin.last N)=r.position 0 then
        pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r*
          (physicalResidue value primes η r:ℂ) else 0)=
      ∑t∈canonicalRoots U V,if ht : Canonical t then
        ∑r∈closedRootPaths (J:=J) (N:=N) R,
          rootGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r t*
            (rootResidue value primes η r (FinitePrimeCRT.integerLines (canonicalSL2 t ht)):ℂ)
        else 0 := by
  have h := sum_eq_rooted_paths_of_radius (J:=J) value μ d₀ Y L U V C exponents hU smooth ψ major σ adjoint
    hN hd hY hC hψ R hR
    (fun r=>if r.position (Fin.last N)=r.position 0 then (physicalResidue value primes η r:ℂ) else 0)
  simp only [mul_ite,mul_zero] at h
  rw [h]
  apply Finset.sum_congr rfl
  intro t ht
  have hc := (Finset.mem_filter.mp ht).2
  rw [dite_eq_left hc]
  unfold closedRootPaths
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro r hr
  have hs := (mem_rootedPaths R r).mp hr |>.2
  simp only [physicalPath_closed_iff t hc r hs]
  split_ifs
  · have he := term_coordinates value μ d₀ Y L U V exponents smooth ψ major σ adjoint hN hU
      primes hprime η (physicalPath t r) t hc
    simpa only [root_physical t hc] using he
  · rfl

/-- All root and record sums can now be interchanged. The selected record
family is independent of the canonical root. -/
theorem closed_moment_eq_record_root_sum (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V C : ℝ) (exponents : Fin K→ℝ) (hU : 0<U)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (hN : 0<N) (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (R : ℕ) (hR : ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊≤R)
    (primes : Finset ℕ) (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ) :
    (∑r∈positionPaths (J:=J) (N:=N) (primitiveSources U V),
      if r.position (Fin.last N)=r.position 0 then
        pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r*
          (physicalResidue value primes η r:ℂ) else 0)=
      ∑r∈closedRootPaths (J:=J) (N:=N) R,∑t∈canonicalRoots U V,if ht : Canonical t then
        rootGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r t*
          (rootResidue value primes η r (FinitePrimeCRT.integerLines (canonicalSL2 t ht)):ℂ)
        else 0 := by
  rw [closed_moment_eq_roots value μ d₀ Y L U V C exponents hU smooth ψ major σ adjoint
    hN hd hY hC hψ R hR primes hprime η]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t ht
  have hc := (Finset.mem_filter.mp ht).2
  simp only [dite_eq_left hc]

end Elliptic.Operator.PhysicalRootMomentReindex
