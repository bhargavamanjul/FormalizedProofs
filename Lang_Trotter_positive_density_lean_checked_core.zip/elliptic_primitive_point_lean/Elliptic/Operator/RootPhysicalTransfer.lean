module

public import Elliptic.Operator.RootBoundaryCover

/-!
# Literal root mass in the complete geometric boundary cover

This combines the proved physical-face and scalar-endpoint cover with the
uniform external root-count deduction. The position family and endpoint
set occur after the common eventual threshold and can grow with x.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootPhysicalTransfer
open Filter SourceRootCount SourceRootTransfer RootArchimedeanGrid RootGridTransfer
open RootBoundaryCover
open scoped BigOperators

theorem eventually_cover_root_mass (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ) (s : Finset Index),
      s⊆grid n → (n:ℝ)^3≤x^(δ/2000) →
      ∀ U V B : ℝ, ∀ S : Index→ℕ, ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → coverVolume n s≤B →
      (∀ j∈s, 1≤S j ∧ Squarefree (S j) ∧
        (S j:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ))) →
      ∀ f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j∈s, ∀ g, ‖f j g‖≤1) →
      ‖∑ j∈s, weightedRootSum U V (S j)
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)‖ ≤
        (U*V/(Real.pi^2/6))*B+U*V*x^(-(δ/4000)) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    eventually_constructed_grid_transfer hPD δ C_S hδ hCS] with x hx ht
  intro n s hs hn U V B S inst hU hU' hV hV' hvol hS f hf
  have hUp : 0≤U := (Real.rpow_pos_of_pos hx δ).le.trans hU
  have hVp : 0≤V := (Real.rpow_pos_of_pos hx δ).le.trans hV
  have htransfer := ht n s hs hn U V S hU hU' hV hV' hS f hf
  have hmain := grid_mainTerm_norm_le U V hUp hVp n s S f hf
  have hmass := mul_le_mul_of_nonneg_left hvol (show 0≤U*V/(Real.pi^2/6) by positivity)
  have htri := norm_add_le
    ((∑ j∈s, weightedRootSum U V (S j)
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)) -
      ∑ j∈s, (rootVolume U V (cell 1 16 n j.1)
        (cell 1 2 n j.2.1) (cell 0 1 n j.2.2):ℂ)*
        ((∑ g, f j g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ)))
    (∑ j∈s, (rootVolume U V (cell 1 16 n j.1)
      (cell 1 2 n j.2.1) (cell 0 1 n j.2.2):ℂ)*
      ((∑ g, f j g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ)))
  rw [sub_add_cancel] at htri
  dsimp only [coverVolume] at hmass
  linarith

/-- All four physical faces and the scalar good-test endpoints are now
charged with their constructed volume, not an abstract boundary premise. -/
theorem eventually_combined_boundary_root_mass (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ), 0<n → (n:ℝ)^3≤x^(δ/2000) →
      ∀ positions : Finset (ℤ × ℤ), ∀ ends : Finset ℝ, ∀ U V R : ℝ,
      ∀ S : Index→ℕ, ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V →
      (∀ z∈positions, |(z.2:ℝ)|≤R) →
      (∀ j∈combinedFaces n positions U V ends,
        1≤S j ∧ Squarefree (S j) ∧
          (S j:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ))) →
      ∀ f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j∈combinedFaces n positions U V ends, ∀ g, ‖f j g‖≤1) →
      ‖∑ j∈combinedFaces n positions U V ends, weightedRootSum U V (S j)
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)‖ ≤
        (U*V/(Real.pi^2/6))*
          (((positions.card:ℝ)*(16864*R+120)+30*(ends.card:ℝ))/(n:ℝ)) +
            U*V*x^(-(δ/4000)) := by
  filter_upwards [eventually_cover_root_mass hPD δ C_S hδ hCS] with x ht
  intro n hn hn' positions ends U V R S inst hU hU' hV hV' hUV hR hS f hf
  exact ht n (combinedFaces n positions U V ends)
    (combinedFaces_subset_grid n positions U V ends) hn' U V _ S hU hU' hV hV'
    (combinedFaces_volume n hn positions U V R ends hUV hR) hS f hf

end Elliptic.Operator.RootPhysicalTransfer
