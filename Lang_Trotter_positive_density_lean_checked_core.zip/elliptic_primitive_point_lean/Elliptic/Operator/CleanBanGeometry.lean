module
public import Elliptic.Operator.CleanCoincidence
public import Elliptic.Operator.PhysicalCleanPads
public import Elliptic.Operator.SourceGeometryReversal

/-! Absolute geometry for restoring a cross-edge coincidence ban.
The raw determinant equation has at most 33 actual physical targets.
The comparison row pays the literal major-arc mass times the pad-cell
cardinality. No fresh-prime cardinality appears. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.CleanBanGeometry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance cleanBanGeometryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The exact raw-minus-major bracket, for any integer shift sign. -/
def bracket (H Y : ℝ) (σ a b t : ℤ) : ℂ :=
  (if t=σ*(a-b) then 1 else 0)-minorFourierTransform (sourceMajorArcs H Y) (t-σ*a+σ*b)

theorem bracket_norm_le (H Y : ℝ) (hH : 0≤H) (hY : 0<Y) (σ a b t : ℤ) :
    ‖bracket H Y σ a b t‖≤(if t=σ*(a-b) then (1:ℝ) else 0)+4*H^3/Y := by
  apply (norm_sub_le _ _).trans
  have hi : ‖(if t=σ*(a-b) then (1:ℂ) else 0)‖=(if t=σ*(a-b) then (1:ℝ) else 0) := by
    split_ifs <;> norm_num
  rw [hi]
  exact add_le_add_right (MajorArcMeasure.sourceMajorArcs_fourier_norm_le H Y hH hY _) _

/-- Actual raw determinant solutions in a physical row, even when the
position set retains arbitrary further restrictions. -/
theorem raw_row_count (D : ℤ) (z : ℤ×ℤ) (hz : IsCoprime z.1 z.2)
    (r : ℝ) (hτ : latticeTau r z≠0) (s : Finset (ℤ×ℤ))
    (hpad : ∀ w∈s, D∣latticeDet z w)
    (hbox : ∀ w∈s, |latticeTau r w/latticeTau r z|≤16) (n : ℤ) :
    (s.filter (fun w => latticeDet z w/D=n)).card≤33 := by
  obtain ⟨v,hv⟩ := exists_unimodular_complement hz
  apply physical_targets_card_le hv r hτ (D*n)
  intro w hw
  have hm := Finset.mem_filter.mp hw
  refine ⟨?_,hbox w hm.1⟩
  have he := Int.mul_ediv_cancel' (hpad w hm.1)
  rw [hm.2] at he
  exact he.symm

/-- The actual raw-plus-comparison absolute row in one pad cell. -/
theorem bracket_row_le (D : ℤ) (z : ℤ×ℤ) (hz : IsCoprime z.1 z.2)
    (r : ℝ) (hτ : latticeTau r z≠0) (s : Finset (ℤ×ℤ))
    (hpad : ∀ w∈s, D∣latticeDet z w)
    (hbox : ∀ w∈s, |latticeTau r w/latticeTau r z|≤16)
    (H Y A : ℝ) (hH : 0≤H) (hY : 0<Y) (hA : 0≤A)
    (cutoff : ℤ×ℤ → ℂ) (hc : ∀ w∈s, ‖cutoff w‖≤A) (σ a b : ℤ) :
    (∑ w∈s, ‖cutoff w*bracket H Y σ a b (latticeDet z w/D)‖) ≤
      A*(33+(s.card:ℝ)*(4*H^3/Y)) := by
  calc
    _ ≤ ∑ w∈s, A*((if latticeDet z w/D=σ*(a-b) then (1:ℝ) else 0)+4*H^3/Y) := by
      apply Finset.sum_le_sum
      intro w hw
      rw [norm_mul]
      exact mul_le_mul (hc w hw) (bracket_norm_le H Y hH hY σ a b _)
        (norm_nonneg _) hA
    _ = A*((s.filter (fun w => latticeDet z w/D=σ*(a-b))).card+(s.card:ℝ)*(4*H^3/Y)) := by
      rw [← Finset.mul_sum,Finset.sum_add_distrib]
      simp only [Finset.sum_const,nsmul_eq_mul]
      congr 2
      rw [← Finset.sum_filter (fun w => latticeDet z w/D=σ*(a-b)) (fun _ => (1:ℝ))]
      simp
    _ ≤ _ := by
      gcongr
      exact_mod_cast raw_row_count D z hz r hτ s hpad hbox (σ*(a-b))

/-- The balanced box gives the literal physical pad-cell cardinality. -/
theorem pad_cell_card_le (z w : ℤ×ℤ) (hzw : latticeDet z w=1) (D : ℤ)
    (b₁ b₂ : ℤ×ℤ) (hb : latticeDet b₁ b₂=1) (A B : ℕ) (a b : ℤ)
    (s : Finset (PadPosition z D))
    (hs : ∀ p∈s, balancedPadEmbedding z w hzw D b₁ b₂ hb p ∈
      (Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A))) :
    (s.card:ℝ)≤(A:ℝ)*B := by
  have hc : s.card≤(((Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A))).card) := by
    rw [← Finset.card_map (balancedPadEmbedding z w hzw D b₁ b₂ hb)]
    apply Finset.card_le_card
    intro p hp
    obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp
    exact hs q hq
  have he : (((Finset.Ico a (a+B))×ˢ(Finset.Ico b (b+A))).card)=B*A := by
    simp [Finset.card_product,Int.card_Ico]
  rw [he] at hc
  exact_mod_cast hc.trans_eq (Nat.mul_comm B A)

/-- Exact norm reversal of the raw/comparison bracket; no even-cutoff
or favorable sign premise is needed. -/
theorem bracket_reverse_norm (H Y : ℝ) (σ a b t : ℤ) :
    ‖bracket H Y σ b a (-t)‖=‖bracket H Y σ a b t‖ := by
  have h := congrArg norm (source_bracket_reverse (sourceMajorArcs H Y) t a b σ)
  simpa only [bracket,Complex.norm_conj] using h

/-- The actual small-atom coincidence error on any two finite physical
pad cells. The geometric rows are proved here from determinant counting
and major-arc measure, rather than left as an operator premise. -/
theorem actual_pad_coincidence_bound
    {I : Type*} [Fintype I] {P : I → Type*} [∀ i, Fintype (P i)]
    (s t : Finset (ℤ×ℤ)) (D : ℤ) (r : ℝ)
    (hprimS : ∀ z∈s, IsCoprime z.1 z.2) (hprimT : ∀ w∈t, IsCoprime w.1 w.2)
    (hτS : ∀ z∈s, latticeTau r z≠0) (hτT : ∀ w∈t, latticeTau r w≠0)
    (hpad : ∀ z∈s, ∀ w∈t, D∣latticeDet z w)
    (hbox : ∀ z∈s, ∀ w∈t, |latticeTau r w/latticeTau r z|≤16)
    (hbox' : ∀ z∈s, ∀ w∈t, |latticeTau r z/latticeTau r w|≤16)
    (H Y A Cgeo : ℝ) (hH : 0≤H) (hY : 0<Y) (hA : 0≤A) (hgeo : 0≤Cgeo)
    (hs : (s.card:ℝ)≤Cgeo*Y) (ht : (t.card:ℝ)≤Cgeo*Y)
    (ν : ∀ i,P i→ℝ) (Cmass δ : ℝ) (hν : ∀ i p, 0≤ν i p)
    (hmassC : 1≤Cmass) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ p : P i, ν i p≤Cmass) (hatom : ∀ i p, ν i p≤δ)
    (product : (∀ i,P i) → ℤ) (σ : ℤ)
    (cutoff : (ℤ×ℤ)×(∀ i,P i) → (ℤ×ℤ)×(∀ i,P i) → ℂ)
    (hcutoff : ∀ z∈s, ∀ w∈t, ∀ p q, ‖cutoff (z,p) (w,q)‖≤A) :
    FiniteMeasuredBilinearBound (s×ˢFinset.univ) (t×ˢFinset.univ)
      (fun x => CleanCoincidence.tupleMass ν x.2) (fun y => CleanCoincidence.tupleMass ν y.2)
      (fun x y => if ∃ i, y.2 i=x.2 i then cutoff x y*
        bracket H Y σ (product x.2) (product y.2) (latticeDet x.1 y.1/D) else 0)
      ((A*(33+4*Cgeo*H^3))*((Fintype.card I:ℝ)*δ*Cmass^(Fintype.card I))) := by
  have hR : 0≤A*(33+4*Cgeo*H^3) := by positivity
  apply CleanCoincidence.coincidence_kernel_bound s t ν Cmass δ (A*(33+4*Cgeo*H^3))
    hν hmassC hδ hR hmass hatom
    (fun x y => cutoff x y*bracket H Y σ (product x.2) (product y.2) (latticeDet x.1 y.1/D))
  · intro z hz p q
    have hr := bracket_row_le D z (hprimS z hz) r (hτS z hz) t (hpad z hz)
      (hbox z hz) H Y A hH hY hA (fun w => cutoff (z,p) (w,q))
      (fun w hw => hcutoff z hz w hw p q) σ (product p) (product q)
    apply hr.trans
    have hc := mul_le_mul_of_nonneg_right ht (show 0≤4*H^3/Y by positivity)
    have he : (Cgeo*Y)*(4*H^3/Y)=4*Cgeo*H^3 := by field_simp
    rw [he] at hc
    exact mul_le_mul_of_nonneg_left (add_le_add_right hc 33) hA
  · intro w hw p q
    have hpad' : ∀ z∈s, D∣latticeDet w z := fun z hz =>
      (PhysicalCleanPads.pad_dvd_symm D z w).mp (hpad z hz w hw)
    have hr := bracket_row_le D w (hprimT w hw) r (hτT w hw) s hpad'
      (fun z hz => hbox' z hz w hw) H Y A hH hY hA (fun z => cutoff (z,p) (w,q))
      (fun z hz => hcutoff z hz w hw p q) σ (product q) (product p)
    have heq : (∑ z∈s, ‖cutoff (z,p) (w,q)*
        bracket H Y σ (product p) (product q) (latticeDet z w/D)‖) =
        ∑ z∈s, ‖cutoff (z,p) (w,q)*
          bracket H Y σ (product q) (product p) (latticeDet w z/D)‖ := by
      apply Finset.sum_congr rfl
      intro z hz
      have hd : latticeDet z w/D= -(latticeDet w z/D) := by
        rw [show latticeDet z w= -latticeDet w z by dsimp [latticeDet]; ring]
        exact Int.neg_ediv_of_dvd (hpad' z hz)
      rw [norm_mul,norm_mul,hd,bracket_reverse_norm]
    rw [heq]
    apply hr.trans
    have hc := mul_le_mul_of_nonneg_right hs (show 0≤4*H^3/Y by positivity)
    have he : (Cgeo*Y)*(4*H^3/Y)=4*Cgeo*H^3 := by field_simp
    rw [he] at hc
    exact mul_le_mul_of_nonneg_left (add_le_add_right hc 33) hA

end Elliptic.Operator.CleanBanGeometry
