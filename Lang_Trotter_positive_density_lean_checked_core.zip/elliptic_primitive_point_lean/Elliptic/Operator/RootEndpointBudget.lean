module

public import Elliptic.Operator.RootGoodProductBounds
public import Elliptic.Operator.RootErrorBudget

/-! A universal, explicit root-boundary family covering every bounded
position and every source good test. Its size is derived from the actual
growing prime ceiling and moment multiplicity. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootEndpointBudget
open scoped BigOperators
open Filter IntegerRootReplacement RootGoodProductBounds
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

def chosenComplement (z : ℤ × ℤ) : ℤ × ℤ :=
  if hz : IsCoprime z.1 z.2 then RootShortComplement.complement z hz else (0,0)

theorem chosenComplement_spec (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) :
    latticeDet z (chosenComplement z)=1 ∧
      |((chosenComplement z).1:ℝ)|≤1+max |(z.1:ℝ)| |(z.2:ℝ)| ∧
      |((chosenComplement z).2:ℝ)|≤1+max |(z.1:ℝ)| |(z.2:ℝ)| := by
  simpa only [chosenComplement,dif_pos hz] using RootShortComplement.complement_spec z hz

def allEndpoints (R H : ℕ) (eps : Finset ℝ) : Finset ℝ :=
  (integerPositionBox R).biUnion fun z =>
    RootTestEndpoints.endpoints z (chosenComplement z) H (32*(1+(R:ℝ))) eps

theorem endpoint_subset (R H : ℕ) (eps : Finset ℝ) (z : ℤ × ℤ)
    (hz : z∈integerPositionBox R) :
    RootTestEndpoints.endpoints z (chosenComplement z) H (32*(1+(R:ℝ))) eps ⊆
      allEndpoints R H eps := by
  intro t ht
  exact Finset.mem_biUnion.mpr ⟨z,hz,ht⟩

theorem allEndpoints_card_le (R H K : ℕ) (eps : Finset ℝ)
    (hcard : eps.card≤K+1) (heps : ∀ ε∈eps, ε≤100) :
    ((allEndpoints R H eps).card:ℝ) ≤
      ((2*R+1:ℕ):ℝ)^2*(2*(H:ℝ)+1)*(K+1)*(128*(H:ℝ)*(1+R)+402) := by
  have hb (z : ℤ × ℤ) := RootTestEndpoints.endpoints_card_le z (chosenComplement z)
    H (32*(1+(R:ℝ))) 100 (by positivity) (by norm_num) eps heps
  have hc : ((allEndpoints R H eps).card:ℝ) ≤
      ∑ z∈integerPositionBox R,
        ((RootTestEndpoints.endpoints z (chosenComplement z) H (32*(1+(R:ℝ))) eps).card:ℝ) := by
    unfold allEndpoints
    exact_mod_cast (Finset.card_biUnion_le (s:=integerPositionBox R)
      (t:=fun z => RootTestEndpoints.endpoints z (chosenComplement z) H (32*(1+(R:ℝ))) eps))
  calc
    _ ≤ ∑ z∈integerPositionBox R,
        ((RootTestEndpoints.endpoints z (chosenComplement z) H (32*(1+(R:ℝ))) eps).card:ℝ) := hc
    _ ≤ ∑ _z∈integerPositionBox R,
        (2*(H:ℝ)+1)*(eps.card:ℝ)*(4*(H:ℝ)*(32*(1+(R:ℝ)))+4*100+2) :=
      Finset.sum_le_sum fun z _ => hb z
    _ = ((2*R+1:ℕ):ℝ)^2*(2*(H:ℝ)+1)*(eps.card:ℝ)*(128*(H:ℝ)*(1+R)+402) := by
      simp [integerPositionBox_card]
      ring
    _ ≤ _ := by gcongr; exact_mod_cast hcard

def sourceMultiplierCeiling (K : ℕ) (L : ℝ) : ℕ :=
  (rootPrimeCeiling L)^(K*momentMultiplicity L+2*K)

theorem sourceMultiplierCeiling_pos (K : ℕ) (L : ℝ) :
    1≤sourceMultiplierCeiling K L := by
  unfold sourceMultiplierCeiling
  exact one_le_pow₀ (by simp [rootPrimeCeiling])

theorem sourceMultiplierCeiling_le (K : ℕ) (L : ℝ) (hL : 1≤L)
    (hc : Real.log 2≤L^(1/5:ℝ)) :
    (sourceMultiplierCeiling K L:ℝ) ≤ Real.exp (12*K*L^(21/100:ℝ)) := by
  have hp := rootPrimeCeiling_le_exp L hc
  have hm := momentMultiplicity_le_two_rpow hL
  have hLpos : 0<L := by linarith
  have ha : 1≤L^(1/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hexp : ((K*momentMultiplicity L+2*K:ℕ):ℝ)≤4*K*L^(1/100:ℝ) := by
    push_cast
    nlinarith [mul_le_mul_of_nonneg_left hm (Nat.cast_nonneg K)]
  have he : L^(1/100:ℝ)*L^(1/5:ℝ)=L^(21/100:ℝ) := by
    rw [←Real.rpow_add hLpos]; norm_num
  unfold sourceMultiplierCeiling
  push_cast
  calc
    _ ≤ (Real.exp (3*L^(1/5:ℝ)))^(K*momentMultiplicity L+2*K) :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) hp _
    _ = Real.exp (((K*momentMultiplicity L+2*K:ℕ):ℝ)*(3*L^(1/5:ℝ))) :=
      (Real.exp_nat_mul _ _).symm
    _ ≤ _ := Real.exp_le_exp.mpr (by
      have h := mul_le_mul_of_nonneg_right hexp (show 0≤3*L^(1/5:ℝ) by positivity)
      nlinarith [he])

/-- Explicit polynomial counting estimate, before its asymptotic use. -/
theorem allEndpoints_card_le_exp (R H K : ℕ) (eps : Finset ℝ)
    (hcard : eps.card≤K+1) (heps : ∀ ε∈eps, ε≤100)
    (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hR : ((2*R+1:ℕ):ℝ)^2≤Real.exp A) (hH : (H:ℝ)≤Real.exp B) :
    ((allEndpoints R H eps).card:ℝ) ≤
      (1974*(K+1))*Real.exp (2*A+2*B) := by
  have hAe : 1≤Real.exp A := Real.one_le_exp hA
  have hBe : 1≤Real.exp B := Real.one_le_exp hB
  have hRe : (R:ℝ)≤Real.exp A := by
    have hr0 : 0≤(R:ℝ) := Nat.cast_nonneg R
    push_cast at hR
    nlinarith [sq_nonneg (R:ℝ)]
  have hmul : 1≤Real.exp A*Real.exp B := by
    nlinarith [mul_le_mul_of_nonneg_left hBe (Real.exp_pos A).le]
  have hsmall : 2*(H:ℝ)+1≤3*Real.exp B := by linarith
  have hlarge : 128*(H:ℝ)*(1+R)+402≤658*(Real.exp A*Real.exp B) := by
    have hh := mul_le_mul hH (show 1+(R:ℝ)≤2*Real.exp A by linarith)
      (by positivity : 0≤1+(R:ℝ)) (Real.exp_pos B).le
    nlinarith
  calc
    _ ≤ ((2*R+1:ℕ):ℝ)^2*(2*(H:ℝ)+1)*(K+1)*(128*(H:ℝ)*(1+R)+402) :=
      allEndpoints_card_le R H K eps hcard heps
    _ ≤ Real.exp A*(3*Real.exp B)*(K+1)*(658*(Real.exp A*Real.exp B)) := by gcongr
    _ = (1974*(K+1))*Real.exp (2*A+2*B) := by
      rw [show 2*A+2*B=A+B+A+B by ring,Real.exp_add,Real.exp_add,Real.exp_add]
      ring

/-- All root positions and all good tests share a subpower number of
endpoints, with one threshold independent of later labels, dyads and Y. -/
theorem eventually_allEndpoints_subpower (K : ℕ) (C ε : ℝ)
    (hC : 0≤C) (hε : 0<ε) :
    ∀ᶠ L : ℝ in atTop, ∀ (Y : ℝ) (a : Fin K → ℝ), 1≤Y →
      ((allEndpoints (rootPositionRadius C L) (sourceMultiplierCeiling K L)
        (radii K Y L a)).card:ℝ) ≤ Real.exp (ε*L) := by
  have hl := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<21/100)).bound
    (by norm_num : (0:ℝ)<1)
  have hc20 := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/5)).eventually
    (eventually_ge_atTop (Real.log 2))
  have hc21 := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<21/100)).eventually
    (eventually_ge_atTop (Real.log 8227))
  let D : ℝ := 4*C+12+24*K+Real.log (1974*(K+1:ℝ))
  have hD : 0≤D := by
    dsimp [D]
    have hh : 0≤Real.log (1974*(K+1:ℝ)) := Real.log_nonneg (by nlinarith [show (0:ℝ)≤K from Nat.cast_nonneg K])
    positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),hl,hc20,hc21,
    RootErrorBudget.eventually_subpower_exponent_le D ε hε] with L hL hl hc20 hc21 hd
  intro Y a hY
  have hL0 : 0<L := by linarith
  have ht : 1≤L^(21/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hlog : Real.log L≤L^(21/100:ℝ) := by
    simpa [Real.norm_eq_abs,abs_of_nonneg (Real.log_nonneg hL),
      abs_of_nonneg (Real.rpow_nonneg hL0.le _)] using hl
  have h := allEndpoints_card_le_exp (rootPositionRadius C L) (sourceMultiplierCeiling K L) K
    (radii K Y L a) (radii_card K Y L a) (radii_le K Y L a hY hL0.le)
    ((2*C+6)*L^(21/100:ℝ)) (12*K*L^(21/100:ℝ)) (by positivity) (by positivity)
    (rootPositionRadius_square_le_exp C L hC hL hlog hc21)
    (sourceMultiplierCeiling_le K L hL hc20)
  have hp : 0<(1974*(K+1:ℝ)) := by positivity
  have hg : 0≤Real.log (1974*(K+1:ℝ)) := Real.log_nonneg (by nlinarith [show (0:ℝ)≤K from Nat.cast_nonneg K])
  calc
    _ ≤ (1974*(K+1))*Real.exp (2*((2*C+6)*L^(21/100:ℝ))+2*(12*K*L^(21/100:ℝ))) := h
    _ = Real.exp (Real.log (1974*(K+1:ℝ))+2*((2*C+6)*L^(21/100:ℝ))+2*(12*K*L^(21/100:ℝ))) := by
      rw [show Real.log (1974*(K+1:ℝ))+2*((2*C+6)*L^(21/100:ℝ))+2*(12*K*L^(21/100:ℝ)) =
        Real.log (1974*(K+1:ℝ))+(2*((2*C+6)*L^(21/100:ℝ))+2*(12*K*L^(21/100:ℝ))) by ring,
        Real.exp_add (Real.log (1974*(K+1:ℝ))),Real.exp_log hp]
    _ ≤ Real.exp (D*L^(21/100:ℝ)) := Real.exp_le_exp.mpr (by dsimp [D]; nlinarith)
    _ ≤ Real.exp (D*L^(98/100:ℝ)) := Real.exp_le_exp.mpr
      (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hL (by norm_num)) hD)
    _ ≤ Real.exp (ε*L) := Real.exp_le_exp.mpr hd

theorem eventually_allEndpoints_subpower_x (K : ℕ) (C ε : ℝ)
    (hC : 0≤C) (hε : 0<ε) :
    ∀ᶠ x : ℝ in atTop, ∀ (Y : ℝ) (a : Fin K → ℝ), 1≤Y →
      ((allEndpoints (rootPositionRadius C (Real.log x)) (sourceMultiplierCeiling K (Real.log x))
        (radii K Y (Real.log x) a)).card:ℝ) ≤ x^ε := by
  filter_upwards [eventually_gt_atTop (0:ℝ),Real.tendsto_log_atTop.eventually
    (eventually_allEndpoints_subpower K C ε hC hε)] with x hx h
  intro Y a hY
  simpa [Real.rpow_def_of_pos hx,mul_comm] using h Y a hY

end Elliptic.Operator.RootEndpointBudget
