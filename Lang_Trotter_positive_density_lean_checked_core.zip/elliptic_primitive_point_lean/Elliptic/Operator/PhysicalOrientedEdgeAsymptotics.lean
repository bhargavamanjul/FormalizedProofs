module

public import Elliptic.Operator.PhysicalFullEdgeAsymptotics
public import Elliptic.Operator.SourceGeometryReversal

/-! The full logarithmic saving holds simultaneously for the original
edge and its literal conjugate-transposed geometric multiplier. No
reality or evenness assumption on either cutoff is used. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalOrientedEdgeAsymptotics
open Filter
open scoped BigOperators SchwartzMap ComplexConjugate
open PhysicalBagNorm PhysicalFullEdgeAsymptotics
attribute [local instance] Classical.propDecidable
local instance orientedSavingDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 400000

def reverseSchwartz (ψ : 𝓢(ℝ,ℂ)) : 𝓢(ℝ,ℂ) :=
  SchwartzMap.postcompCLM Complex.conjCLE.toContinuousLinearMap
    (SchwartzMap.compCLMOfContinuousLinearEquiv ℝ (LinearIsometryEquiv.neg ℝ (E:=ℝ)) ψ)

@[simp] theorem reverseSchwartz_apply (ψ : 𝓢(ℝ,ℂ)) (t : ℝ) :
    reverseSchwartz ψ t=conj (ψ (-t)) := rfl

theorem oriented_geometry_true {I : Type*} [Fintype I] {P : I→Type*} {J : ℕ}
    (value : ∀i,P i→ℕ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) :
    orientedSourceEdgeGeometry true value good u v r U W d₀ Y η ψ major σ=
      sourcePhysicalEdgeGeometry value good u v r U W d₀ Y
        (fun t=>conj (η t)) (fun t=>conj (ψ (-t))) major σ := by
  funext z a w b
  exact (sourcePhysicalEdgeGeometry_reverse value good u v r U W d₀ Y η ψ major σ w b z a).symm

def literalOrientedOperation {K J B : ℕ} (adjoint : Bool)
    (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (ν : Fin K→ℕ→ℝ) (V : Fin K→ℝ) (ρ : ℝ) (μ : ∀i,groups i→ℝ)
    (d₀ Y L : ℝ) (a : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ) :
    ChoiceOperation (SourceMemoryEdgeState positions groups J B) :=
  physicalEdgeOperation (fun i (p:groups i)=>ν i p.val) V ρ
    (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:positions=>z.val))
    (fun z b w c=>orientedSourceEdgeGeometry adjoint (fun _ p=>p.val)
      (RootLiteralGeometry.sourceGood (fun _ p=>p.val) μ d₀ Y L a q)
      (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val b w.val c)

theorem literalOrientedOperation_false {K J B : ℕ}
    (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (ν : Fin K→ℕ→ℝ) (V : Fin K→ℝ) (ρ : ℝ) (μ : ∀i,groups i→ℝ)
    (d₀ Y L : ℝ) (a : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ) :
    literalOrientedOperation (J:=J) (B:=B) false positions groups ν V ρ μ d₀ Y L a q U W η ψ H σ=
      literalFullOperation positions groups ν V ρ μ d₀ Y L a q U W η ψ H σ := rfl

theorem literalOrientedOperation_true {K J B : ℕ}
    (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (ν : Fin K→ℕ→ℝ) (V : Fin K→ℝ) (ρ : ℝ) (μ : ∀i,groups i→ℝ)
    (d₀ Y L : ℝ) (a : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ) :
    literalOrientedOperation (J:=J) (B:=B) true positions groups ν V ρ μ d₀ Y L a q U W η ψ H σ=
      literalFullOperation positions groups ν V ρ μ d₀ Y L a q U W
        (fun t=>conj (η t)) (fun t=>conj (ψ (-t))) H σ := by
  unfold literalOrientedOperation literalFullOperation
  congr 1
  funext z b w c
  dsimp only [orientedSourceEdgeGeometry,ite_true]
  exact (sourcePhysicalEdgeGeometry_reverse _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _).symm

theorem exists_group_count_for_actual_oriented_saving (G : ℝ) (hG : 0≤G) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(Cweight : Fin K→ℝ),(∀i,0≤Cweight i)→
      ∀(ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ Cmass Catom ρ vmin vmax : ℝ),
      1≤C→0≤Aψ→1≤Cmass→0≤Catom→(∀i,Cweight i≤Catom)→
      0≤ρ→ρ<1→0<vmin→
      (∀x,‖η x‖≤1)→(∀x,η x≠0→1≤x)→
      (∀x,‖ψ x‖≤Aψ)→(∀x,ψ x≠0→|x|≤C)→
      ∀ᶠ L : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i (p:groups i),Fintype (ZMod p.val)),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀(ν : Fin K→ℕ→ℝ) (μ : ∀i,groups i→ℝ) (V : Fin K→ℝ),
      (∀i,∀p∈groups i,0<ν i p)→(∀i,∀p∈groups i,ν i p≤Cweight i/p)→
      (∀i,∑p:groups i,ν i p.val≤Cmass)→(∀i (p:groups i),ν i p.val≤2*μ i p)→
      (∀i,vmin≤V i)→(∀i,V i≤vmax)→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      ∀(d₀ Y : ℝ) (q : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤q.1→q.1≤16→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀(adjoint : Bool) (σ : ℤ),(σ=1∨σ= -1)→
      ∀F : SourceMemoryEdgeState positions groups (momentPadding L) (memoryCutoff L)→ℂ,
      IsBagFunction F→
      finiteL2 Finset.univ
        (PhysicalMemoryState.mass (fun i=>groups i) (fun _i p=>Option (ZMod p.val))
          (momentPadding L) (memoryCutoff L) (fun i (p:groups i)=>ν i p.val))
        ((literalOrientedOperation adjoint positions groups ν V ρ μ d₀ Y L a q U W η ψ (L^(G+6)) σ).apply F)≤
      L^(-G)*finiteL2 Finset.univ
        (PhysicalMemoryState.mass (fun i=>groups i) (fun _i p=>Option (ZMod p.val))
          (momentPadding L) (memoryCutoff L) (fun i (p:groups i)=>ν i p.val)) F := by
  obtain ⟨K₀,hK₀,hsave⟩ := exists_group_count_for_actual_full_saving G hG
  refine ⟨K₀,hK₀,?_⟩
  intro K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax
    hC hAψ hmassC hCatom hweight hρ0 hρ1 hmin hη hηsupport hψ hψsupport
  have hηr : ∀t,‖conj (η t)‖≤1 := fun t=>by simpa using hη t
  have hηrs : ∀t,conj (η t)≠0→1≤t := by
    intro t ht
    exact hηsupport t (by intro hz; simp [hz] at ht)
  have hψr : ∀t,‖reverseSchwartz ψ t‖≤Aψ := fun t=>by simpa using hψ (-t)
  have hψrs : ∀t,reverseSchwartz ψ t≠0→|t|≤C := by
    simpa only [reverseSchwartz_apply] using reverse_cutoff_support ψ C hψsupport
  filter_upwards [hsave K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax
    hC hAψ hmassC hCatom hweight hρ0 hρ1 hmin hη hηsupport hψ hψsupport,
    hsave K hK Cweight hCweight (reverseSchwartz ψ) (fun t=>conj (η t))
      C Aψ Cmass Catom ρ vmin vmax hC hAψ hmassC hCatom hweight hρ0 hρ1 hmin
      hηr hηrs hψr hψrs] with L hplain hreverse
  intro a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband
    d₀ Y q U W hU hq hq' hd₀ hY hYlo hYhi adjoint σ hσ F hF
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  cases adjoint with
  | false =>
    rw [literalOrientedOperation_false]
    have h := hplain a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ
      hVlo hVhi hband d₀ Y q U W hU hq hq' hd₀ hY hYlo hYhi σ hσ F hF
    exact complete_support_norm_bound _ _
      (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
      _ _ _ _ h
  | true =>
    rw [literalOrientedOperation_true]
    have h := hreverse a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ
      hVlo hVhi hband d₀ Y q U W hU hq hq' hd₀ hY hYlo hYhi σ hσ F hF
    exact complete_support_norm_bound _ _
      (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
      _ _ _ _ h

end Elliptic.Operator.PhysicalOrientedEdgeAsymptotics
