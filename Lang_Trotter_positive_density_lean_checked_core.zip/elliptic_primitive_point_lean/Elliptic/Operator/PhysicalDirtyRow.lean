module

public import Elliptic.Operator.PhysicalDirtyExceptional
public import Elliptic.Operator.DirtyExceptionalOuter

/-!
# Complete raw promotion-row estimate from the actual second good-state test

The sharp separated estimate and the crude exceptional estimate are
combined on the literal physical choices. Exceptional prime draws are
integrated by their product mass, not counted. This is a forward raw-row
estimate, not yet an operator norm or a signed-edge estimate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyRow
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Explicit separated contribution, summed over the distinguished group. -/
def separatedBudget (K J B : ℕ) (ρ v0 vmin mass : ℝ) : ℝ :=
  ∑ i : Fin K, (33 * (B * ((1 + v0) * vmin⁻¹ / v0) *
    ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^
      Fintype.card {j : Fin K // j ≠ i})) / (J+1 : ℝ)^K

/-- Explicit exceptional contribution after integrating the fresh law. -/
def exceptionalBudget (K B : ℕ) (ρ v0 vmin L : ℝ) (a : Fin K → ℝ) : ℝ :=
  33 * (B+1 : ℝ)^K * ∑ i : Fin K,
    B * (2:ℝ)^K * DirtyExceptionalOuter.storeBudget ρ v0 vmin i *
      ((2:ℝ)^K * Real.exp (-(L^a i)/4))

/-- Genuine actual raw dirty-row bound: no desired row estimate, phase
separation over an oversized support, or exceptional-mass bound is an
additional input. The displayed second good-state test supplies the latter. -/
theorem raw_promotion_row_le_source
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin mass L : ℝ)
    (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (hgood : SourceSecondGoodState.SecondGoodTest value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) μ d₀
      (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) L a)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p : ℝ))
    (hν : ∀ i p, 0 ≤ ν i p) (hνμ : ∀ i p, ν i p ≤ 2*μ i p)
    (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ PhysicalDirtyPartition.rawDirtyChoices value position s good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      separatedBudget K J B ρ v0 vmin mass + exceptionalBudget K B ρ v0 vmin L a := by
  have h := PhysicalDirtyExceptional.actual_row_le value position s hposition hprime
    ν V ρ v0 vmin mass good u v r U W d₀ σ hU hσ w hzw
    (fun i _ => 100*Real.exp (-(L^a i)))
    (fun i k => SourceSecondGoodState.source_width (L^a i) _ (hband i _))
    hν hV hmin hρ0 hρ1 hv0 hmass
  apply h.trans
  dsimp only [separatedBudget,exceptionalBudget]
  apply add_le_add le_rfl
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  apply Finset.sum_le_sum
  intro i _
  convert DirtyExceptionalOuter.sum_exceptional_le_source value s ν μ V ρ v0 vmin d₀
    (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
    L a i hgood hV hmin hv0 hρ1 hν hνμ using 1
  apply Finset.sum_congr rfl
  intro k _
  by_cases ha : DirtyExceptionalOuter.Admissible value s i k
  · have ha' : ∀ j ∈ PhysicalDirtyPartition.keyPromotedGroups value s i k, j ≤ i := ha
    by_cases hs : PhysicalDirtyGoodFiber.Separated value s d₀
        (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
        (100*Real.exp (-(L^a i))) i k
    · rw [ite_eq_right (fun h => h.2 hs),ite_eq_right (fun h => h.2 hs)]
    · rw [ite_eq_left ⟨ha',hs⟩,ite_eq_left ⟨ha,hs⟩]
  · have ha' : ¬(∀ j ∈ PhysicalDirtyPartition.keyPromotedGroups value s i k, j ≤ i) := ha
    rw [ite_eq_right (fun h => ha' h.1),ite_eq_right (fun h => ha h.1)]


/-- Specialization to the actual transformed prime law, whose mass
comparison follows from the explicit visit-size condition. -/
theorem raw_promotion_row_le_transformed {τ : Type*}
    (visits : Finset τ) (η : τ → ℝ)
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (V : Fin K → ℝ) (ρ v0 vmin mass L pmin : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (hgood : SourceSecondGoodState.SecondGoodTest value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
      (fun i p => 1/(V i*(value i p:ℝ))) d₀
      (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) L a)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p : ℝ))
    (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hpmin : 0 < pmin) (hp : ∀ i p, pmin ≤ (value i p : ℝ))
    (hη : ∀ j ∈ visits, η j ≤ 1) (hsize : 2*(visits.card : ℝ) ≤ pmin)
    (hmass : ∀ i, (∑ p, transformedPrimeMass visits η (V i) (value i p)) ≤ mass) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ PhysicalDirtyPartition.rawDirtyChoices value position s good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s
          (fun i p => transformedPrimeMass visits η (V i) (value i p)) V ρ v0 c) ≤
      separatedBudget K J B ρ v0 vmin mass + exceptionalBudget K B ρ v0 vmin L a := by
  apply raw_promotion_row_le_source value position s hposition hprime
    (fun i p => transformedPrimeMass visits η (V i) (value i p))
    (fun i p => 1/(V i*(value i p:ℝ))) V ρ v0 vmin mass L a
    good u v r U W d₀ σ hU hσ w hzw hgood hband
  · intro i p
    exact (SourceSecondGoodState.transformedPrimeMass_le_twice visits η (V i) pmin (value i p)
      (hmin.trans_le (hV i)) hpmin (hp i p) hη hsize).1
  · intro i p
    exact (SourceSecondGoodState.transformedPrimeMass_le_twice visits η (V i) pmin (value i p)
      (hmin.trans_le (hV i)) hpmin (hp i p) hη hsize).2
  · exact hV
  · exact hmin
  · exact hρ0
  · exact hρ1
  · exact hv0
  · exact hmass

end Elliptic.Operator.PhysicalDirtyRow
