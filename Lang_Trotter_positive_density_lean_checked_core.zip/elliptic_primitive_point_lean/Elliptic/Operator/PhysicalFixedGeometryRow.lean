module
public import Elliptic.Operator.CleanBanGeometry
public import Elliptic.Operator.SingleEdgeTargetCount

/-! Absolute rows of the actual source geometry with both active lists
fixed. The raw equation contributes at most 33 positions. The comparison
support has O(Y) positions and its Fourier factor contributes O(H³/Y).
All physical, good-state, coincidence and dyadic masks remain present. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFixedGeometryRow
open scoped BigOperators ComplexConjugate
attribute [local instance] Classical.propDecidable
local instance fixedGeometryDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I : Type*} [Fintype I] {P : I → Type*} {J : ℕ}

/-- The exact actual row, without any geometric operator premise. -/
theorem source_row_le (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y H C Aη Aψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (η ψ : ℝ → ℂ)
    (hη : ∀ t, ‖η t‖≤Aη) (hψ : ∀ t, ‖ψ t‖≤Aψ)
    (hsupport : ∀ t, ψ t≠0 → |t|≤C)
    (σ : ℤ) (z : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (positions : Finset (ℤ × ℤ)) :
    (∑ w∈positions, ‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z a w b‖) ≤ Aη^2*Aψ*(33+132*(2*C+1)*H^3) := by
  let K := fun w => sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
    (sourceMajorArcs H Y) σ z a w b
  let S := positions.filter (fun w => K w≠0)
  have hsum : (∑ w∈positions, ‖K w‖) = ∑ w∈S, ‖K w‖ := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro w hw hn
    have he : K w=0 := by
      by_contra h
      exact hn (Finset.mem_filter.mpr ⟨hw,h⟩)
    simp [he]
  change (∑ w∈positions, ‖K w‖)≤_
  rw [hsum]
  by_cases hempty : S=∅
  · rw [hempty]
    simp only [Finset.sum_empty]
    positivity
  obtain ⟨w₀,hw₀⟩ := Finset.nonempty_iff_ne_empty.mpr hempty
  have hallowed (w) (hw : w∈S) : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
    have hn := (Finset.mem_filter.mp hw).2
    by_contra he
    simp [K,sourcePhysicalEdgeGeometry,he] at hn
  have hz := (hallowed w₀ hw₀).1
  have hτ := (sourcePhysicalPositionAllowed_ratio_le u v r U W z w₀ hU hz
    (hallowed w₀ hw₀).2.1).1
  let D := sourcePadProduct value a
  have hpad : ∀ w∈S, (D:ℤ)∣latticeDet z w := fun w hw =>
    (hallowed w hw).2.2.2.2.2.2.2
  have hbox : ∀ w∈S, |latticeTau r w/latticeTau r z|≤16 := fun w hw =>
    (sourcePhysicalPositionAllowed_ratio_le u v r U W z w hU hz (hallowed w hw).2.1).2
  have htime (w) (hw : w∈S) : |((latticeDet z w/(D:ℤ):ℤ):ℝ)|≤C*Y := by
    have hn := (Finset.mem_filter.mp hw).2
    have hp : ψ (((latticeDet z w/(D:ℤ):ℤ):ℝ)/Y)≠0 := by
      intro he
      have ha := hallowed w hw
      simp [K,sourcePhysicalEdgeGeometry,ha,D,he] at hn
    have ht := hsupport _ hp
    rw [abs_div,abs_of_pos (show 0<Y by linarith)] at ht
    exact (div_le_iff₀ (show 0<Y by linarith)).mp ht
  obtain ⟨w₁,hw₁⟩ := exists_unimodular_complement hz.1
  have hcard := SingleEdgeTargetCount.comparison_targets_card_le hw₁ r hτ (D:ℤ) C Y hC hY S
    (fun w hw => ⟨hpad w hw,htime w hw,hbox w hw⟩)
  let cutoff := fun w => ((d₀/(D:ℝ):ℝ):ℂ)*
    η ((sourceUnsharedProduct value a:ℝ)/Y)*η ((sourceUnsharedProduct value b:ℝ)/Y)*
    ψ (((latticeDet z w/(D:ℤ):ℤ):ℝ)/Y)
  have hD : d₀≤(D:ℝ) := (hallowed w₀ hw₀).2.2.2.2.2.1
  have hDp : (0:ℝ)<D := hd.trans_le hD
  have hscale : ‖((d₀/(D:ℝ):ℝ):ℂ)‖≤1 := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_pos (div_pos hd hDp)]
    exact (div_le_one hDp).mpr hD
  have hcut : ∀ w∈S, ‖cutoff w‖≤Aη^2*Aψ := by
    intro w hw
    dsimp only [cutoff]
    simp only [norm_mul]
    calc
      _ ≤ 1*Aη*Aη*Aψ := by gcongr <;> first | exact hscale | exact hη _ | exact hψ _
      _ = _ := by ring
  have heq : (∑ w∈S, ‖K w‖) = ∑ w∈S, ‖cutoff w*CleanBanGeometry.bracket H Y σ
      (sourceUnsharedProduct value a:ℤ) (sourceUnsharedProduct value b:ℤ)
      (latticeDet z w/(D:ℤ))‖ := by
    apply Finset.sum_congr rfl
    intro w hw
    simp only [K,sourcePhysicalEdgeGeometry,ite_eq_left (hallowed w hw)]
    rfl
  rw [heq]
  apply (CleanBanGeometry.bracket_row_le (D:ℤ) z hz.1 r hτ S hpad hbox H Y (Aη^2*Aψ)
    hH (by linarith) (by positivity) cutoff hcut σ _ _).trans
  have hc := mul_le_mul_of_nonneg_right hcard (show 0≤4*H^3/Y by positivity)
  have hc' : (S.card:ℝ)*(4*H^3/Y)≤132*(2*C+1)*H^3 := by
    convert hc using 1
    field_simp
    ring
  exact mul_le_mul_of_nonneg_left (add_le_add_right hc' 33) (by positivity)

/-- The same bound in the reverse direction uses exact cutoff reflection;
it does not require eta or psi to be real, even or nonnegative. -/
theorem source_column_le (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y H C Aη Aψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (η ψ : ℝ → ℂ)
    (hη : ∀ t, ‖η t‖≤Aη) (hψ : ∀ t, ‖ψ t‖≤Aψ)
    (hsupport : ∀ t, ψ t≠0 → |t|≤C)
    (σ : ℤ) (w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (positions : Finset (ℤ × ℤ)) :
    (∑ z∈positions, ‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z a w b‖) ≤ Aη^2*Aψ*(33+132*(2*C+1)*H^3) := by
  have hrev := reverse_cutoffs_norm_le η ψ Aη Aψ hη hψ
  have hh := source_row_le value good u v r U W d₀ Y H C Aη Aψ hU hd hY hH hC hAη hAψ
    (fun t => conj (η t)) (fun t => conj (ψ (-t))) hrev.1 hrev.2
    (reverse_cutoff_support ψ C hsupport) σ w b a positions
  simpa only [sourcePhysicalEdgeGeometry_reverse,Complex.norm_conj] using hh

/-- Actual alternating orientations satisfy the same fixed-list row. -/
theorem oriented_row_le (adjoint : Bool) (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y H C Aη Aψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (η ψ : ℝ → ℂ)
    (hη : ∀ t, ‖η t‖≤Aη) (hψ : ∀ t, ‖ψ t‖≤Aψ)
    (hsupport : ∀ t, ψ t≠0 → |t|≤C)
    (σ : ℤ) (z : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (positions : Finset (ℤ × ℤ)) :
    (∑ w∈positions, ‖orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z a w b‖) ≤ Aη^2*Aψ*(33+132*(2*C+1)*H^3) := by
  cases adjoint
  · exact source_row_le value good u v r U W d₀ Y H C Aη Aψ hU hd hY hH hC hAη hAψ
      η ψ hη hψ hsupport σ z a b positions
  · simpa only [orientedSourceEdgeGeometry,ite_true,norm_star] using
      source_column_le value good u v r U W d₀ Y H C Aη Aψ hU hd hY hH hC hAη hAψ
        η ψ hη hψ hsupport σ z b a positions

end Elliptic.Operator.PhysicalFixedGeometryRow
