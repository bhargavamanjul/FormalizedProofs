module

public import Elliptic.Operator.ExponentialGram
public import Mathlib.Analysis.Normed.Group.AddCircle
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

/-!
# The reciprocal circle-distance form of the exponential Gram bound

The geometric-series denominator is bounded below by four times the
actual norm in R/Z. Resonant terms are retained at their trivial bound.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators ComplexConjugate
open Elliptic.SourceContracts

theorem additivePhase_int (n : ℤ) : additivePhase (n : ℝ) = 1 := by
  have he : (((2*Real.pi*(n : ℝ) : ℝ) : ℂ)*Complex.I) =
      (n : ℂ)*(2*Real.pi*Complex.I) := by push_cast; ring
  unfold additivePhase
  rw [he]
  exact Complex.exp_int_mul_two_pi_mul_I n

theorem additivePhase_sub_int (x : ℝ) (n : ℤ) :
    additivePhase (x-n) = additivePhase x := by
  rw [sub_eq_add_neg, additivePhase_add]
  have h : additivePhase (-(n : ℝ)) = 1 := by simpa using additivePhase_int (-n)
  rw [h, mul_one]

/-- The chord of the complex unit circle dominates four times the
normalized additive-circle distance. -/
theorem phase_sub_one_norm_lower (x : ℝ) :
    4 * ‖(x : AddCircle (1 : ℝ))‖ ≤ ‖additivePhase x - 1‖ := by
  let r : ℝ := x - round x
  have hr : |r| ≤ 1/2 := abs_sub_round x
  have he : additivePhase x = Complex.exp (Complex.I * ((2*Real.pi*r : ℝ) : ℂ)) := by
    rw [← additivePhase_sub_int x (round x)]
    unfold additivePhase
    congr 1
    ring
  rw [he, Complex.norm_exp_I_mul_ofReal_sub_one]
  have harg : 2*Real.pi*r/2 = Real.pi*r := by ring
  rw [harg, Real.norm_eq_abs, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
  have hangle : |Real.pi*r| ≤ Real.pi := by
    rw [abs_mul, abs_of_pos Real.pi_pos]
    nlinarith [Real.pi_pos]
  rw [Real.abs_sin_eq_sin_abs_of_abs_le_pi hangle, abs_mul, abs_of_pos Real.pi_pos]
  have hsin := Real.mul_le_sin (x := Real.pi*|r|)
    (mul_nonneg Real.pi_pos.le (abs_nonneg r)) (by nlinarith [Real.pi_pos])
  have hsimpl : (2/Real.pi)*(Real.pi*|r|) = 2*|r| := by field_simp
  rw [hsimpl] at hsin
  have hnorm : ‖(x : AddCircle (1 : ℝ))‖ = |r| := by simp [AddCircle.norm_eq, r]
  rw [hnorm]
  linarith

/-- The source's convention at an integral phase is explicit. -/
def circleGeometricBound (B : ℕ) (x : ℝ) : ℝ :=
  if ‖(x : AddCircle (1 : ℝ))‖ = 0 then B
  else min (B : ℝ) (1/(2*‖(x : AddCircle (1 : ℝ))‖))

theorem circleGeometricBound_nonneg (B : ℕ) (x : ℝ) :
    0 ≤ circleGeometricBound B x := by
  unfold circleGeometricBound
  split_ifs <;> positivity

theorem geometricPhaseBound_le_circleGeometricBound (B : ℕ) (x : ℝ) :
    geometricPhaseBound B x ≤ circleGeometricBound B x := by
  have hlower := phase_sub_one_norm_lower x
  by_cases hz : ‖(x : AddCircle (1 : ℝ))‖ = 0
  · simp only [circleGeometricBound, hz, ite_true]
    unfold geometricPhaseBound
    split_ifs
    · exact le_rfl
    · exact min_le_left _ _
  · have hn : 0 < ‖(x : AddCircle (1 : ℝ))‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hz)
    have hp : additivePhase x ≠ 1 := by
      intro he
      rw [he, sub_self, norm_zero] at hlower
      linarith
    simp only [geometricPhaseBound, hp, ite_false, circleGeometricBound, hz]
    apply min_le_min_left
    have hphase : 0 < ‖additivePhase x - 1‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hp)
    apply (div_le_div_iff₀ hphase (by positivity : 0 < 2*‖(x : AddCircle (1 : ℝ))‖)).mpr
    nlinarith

/-- The exact scalar sum appearing in the first inequality of PD (4.32).
The factor 1/2 in the reciprocal term is harmless and slightly sharper. -/
def circleGramBudget (A B : ℕ) (θ : ℝ) : ℝ :=
  ∑ h ∈ Finset.Icc (-(A : ℤ)) (A : ℤ), circleGeometricBound B (θ*h)

theorem exponentialGramBudget_le_circleGramBudget (A B : ℕ) (θ : ℝ) :
    exponentialGramBudget A B θ ≤ circleGramBudget A B θ :=
  Finset.sum_le_sum fun _ _ => geometricPhaseBound_le_circleGeometricBound B _

theorem determinant_kernel_bound_of_circle_sum (A B : ℕ) (θ a b : ℝ) :
    FiniteKernelBound (Finset.range B ×ˢ Finset.range A)
      (Finset.range A ×ˢ Finset.range B) (fun _ => 1) (fun _ => 1)
      (fun p q => additivePhase (θ * ((a+p.1)*(b+q.1) - (b+p.2)*(a+q.2))))
      (circleGramBudget A B θ) := by
  intro v
  exact (determinant_kernel_bound_of_geometric_sum A B θ a b v).trans
    (mul_le_mul_of_nonneg_right (exponentialGramBudget_le_circleGramBudget A B θ)
      (Real.sqrt_nonneg _))

end Elliptic.Operator
