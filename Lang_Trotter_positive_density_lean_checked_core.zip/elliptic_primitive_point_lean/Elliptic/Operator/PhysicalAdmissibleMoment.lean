module

public import Elliptic.Operator.PhysicalMomentIdentification
public import Elliptic.Operator.PhysicalDirtyCoordinates

/-! Exact restriction of the physical row and positive moments to
numerically distinct active lists whose every prime divides the first
position coordinate. The endpoint vectors carry this same projection. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalAdmissibleMoment
open scoped BigOperators ComplexConjugate Matrix
open PhysicalRootedMoment PhysicalVertexDamping PhysicalMomentIdentification
attribute [local instance] Classical.propDecidable
local instance admissibleMomentDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

def Admissible (value : ∀i,P i→ℕ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : Prop :=
  Function.Injective (fun s : Sigma (fun _i:I=>Fin (J+1))=>value s.1 (a s.1 s.2)) ∧
    ∀i k,(value i (a i k):ℤ)∣z.1

def project (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ)
    (x : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)) : ℂ :=
  if Admissible value (position x.1) x.2 then F x else 0

def positionVector (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (z : Z) :
    PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ :=
  project value position (PhysicalRootedMoment.positionVector z)

theorem admissible_permute_iff (value : ∀i,P i→ℕ) (z : ℤ×ℤ)
    (a : PhysicalActiveLists P J) (π : ∀i,Equiv.Perm (Fin (J+1))) :
    Admissible value z (fun i k=>a i (π i k)) ↔ Admissible value z a := by
  let e := Equiv.sigmaCongrRight π
  constructor
  · rintro ⟨hi,hd⟩
    refine ⟨?_,fun i k=>?_⟩
    · intro x y h
      rcases x with ⟨i,k⟩
      rcases y with ⟨j,l⟩
      have he : (⟨i,(π i).symm k⟩ : Sigma (fun _i:I=>Fin (J+1)))=⟨j,(π j).symm l⟩ :=
        hi (by simpa using h)
      have hf := congrArg (fun s : Sigma (fun _i:I=>Fin (J+1))=>
        (⟨s.1,π s.1 s.2⟩ : Sigma (fun _i:I=>Fin (J+1)))) he
      simpa using hf
    · simpa using hd i ((π i).symm k)
  · rintro ⟨hi,hd⟩
    exact ⟨hi.comp e.injective,fun i k=>hd i (π i k)⟩

def Supported (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) : Prop :=
  ∀z a w b,g z a w b≠0→Admissible value (position z) a ∧ Admissible value (position w) b

theorem supported_adjoint (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) : Supported value position (adjointGeometry g) := by
  intro z a w b h
  have hn : g w b z a≠0 := by intro he; simp [adjointGeometry,he] at h
  exact (hg w b z a hn).symm

theorem row_supported (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g)
    (x y : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)) (hrow : row V g x y≠0) :
    Admissible value (position x.1) x.2 ∧ Admissible value (position y.1) y.2 := by
  have hf : ∃π : Perms (I:=I) (J:=J),∃τ : Perms (I:=I) (J:=J),
      g x.1 (fun i k=>x.2 i (π i k)) y.1 (fun i k=>y.2 i ((τ i).symm k))≠0 := by
    by_contra h
    push_neg at h
    apply hrow
    simp only [row,h,Finset.sum_const_zero,mul_zero]
  obtain ⟨π,τ,hn⟩ := hf
  have hh := hg _ _ _ _ hn
  exact ⟨(admissible_permute_iff value _ _ π).mp hh.1,
    (admissible_permute_iff value _ _ (fun i=>(τ i).symm)).mp hh.2⟩

theorem project_idem (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    project value position (project value position F)=project value position F := by
  funext x
  by_cases hx : Admissible value (position x.1) x.2 <;> simp [project,hx]

theorem pairing_project_self_re (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    (pairing V (project value position F) (project value position F)).re=
      initialMass (J:=J) V*∑x,if Admissible value (position x.1) x.2 then ‖F x‖^2 else 0 := by
  rw [pairing_self_re,PhysicalMomentEndpoint.self_quadratic_eq_sum_norm_sq]
  congr 1
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : Admissible value (position x.1) x.2 <;> simp [project,hx]

theorem rowApply_project (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    rowApply V g (project value position F)=rowApply V g F := by
  funext x
  apply Finset.sum_congr rfl
  intro y _
  by_cases hy : Admissible value (position y.1) y.2
  · simp only [project,hy,ite_true]
  · have hr : row V g x y=0 := by
      by_contra hn
      exact hy (row_supported value position V g hg x y hn).2
    simp [hr]

theorem project_rowApply (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    project value position (rowApply V g F)=rowApply V g F := by
  funext x
  by_cases hx : Admissible value (position x.1) x.2
  · simp only [project,hx,ite_true]
  · have hz : rowApply V g F x=0 := by
      apply Finset.sum_eq_zero
      intro y _
      have hr : row V g x y=0 := by
        by_contra hn
        exact hx (row_supported value position V g hg x y hn).1
      simp [hr]
    simp [project,hx,hz]

theorem pairing_project_left (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (F H : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ)
    (hH : project value position H=H) :
    pairing V (project value position F) H=pairing V F H := by
  unfold pairing
  congr 1
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : Admissible value (position x.1) x.2
  · simp [project,hx]
  · have hzero : H x=0 := by simpa [project,hx] using (congrFun hH x).symm
    simp [hzero]

theorem pairing_row_project (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g)
    (F G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    pairing V (project value position F) (rowApply V g (project value position G))=
      pairing V F (rowApply V g G) := by
  rw [rowApply_project value position V g hg G]
  exact pairing_project_left value position V F _ (project_rowApply value position V g hg G)

theorem project_aaStarPower_succ (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) (R : ℕ)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    project value position (aaStarPower V g (R+1) F)=aaStarPower V g (R+1) F :=
  project_rowApply value position V g hg _

theorem aaStarPower_project (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) (R : ℕ)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    aaStarPower V g R (project value position F)=project value position (aaStarPower V g R F) := by
  induction R with
  | zero => rfl
  | succ R ih =>
    rw [project_aaStarPower_succ value position V g hg,aaStarPower,aaStarPower,ih,
      rowApply_project value position V (adjointGeometry g) (supported_adjoint value position g hg)]

theorem pairing_power_project (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) (R : ℕ) (hR : 0<R)
    (F G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    pairing V (project value position F) (aaStarPower V g R (project value position G))=
      pairing V F (aaStarPower V g R G) := by
  obtain ⟨R,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hR)
  rw [aaStarPower_project value position V g hg,
    project_aaStarPower_succ value position V g hg]
  exact pairing_project_left value position V F _ (project_aaStarPower_succ value position V g hg R G)

theorem positionVector_sum (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (s : Finset Z) (f : Z→ℂ) :
    (∑z∈s,f z • positionVector (J:=J) value position z)=
      project value position (fun x=>if x.1∈s then f x.1 else 0) := by
  funext x
  by_cases hx : Admissible value (position x.1) x.2 <;>
    simp [positionVector,project,hx,PhysicalRootedMoment.positionVector,
      Finset.sum_apply,Pi.smul_apply,smul_eq_mul,mul_ite]

theorem projected_rootedPowerMoment_eq (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ) (V : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) (R : ℕ) (hR : 0<R) :
    (∑z:Z,pairing V (positionVector (J:=J) value position z)
      (aaStarPower V g R (positionVector (J:=J) value position z)))=rootedPowerMoment V g R := by
  apply Finset.sum_congr rfl
  intro z _
  exact pairing_power_project value position V g hg R hR _ _

/-- The endpoint estimate uses only admissible vectors in its two norm
factors, while retaining the original positive physical moment exactly. -/
theorem projected_endpoint_power_bound (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (V : I→ℝ) (hV : ∀i,0≤V i)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g) (R : ℕ) (hR : 0<R)
    (f : Z→ℂ) (G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    let F := fun x : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)=>f x.1
    ‖pairing V F (rowApply V g G)‖^(2*R)≤
      (pairing V (project value position G) (project value position G)).re^R*
      (pairing V (project value position F) (project value position F)).re^(R-1)*
      ((rootedPowerMoment V g R).re*∑z:Z,‖f z‖^2) := by
  dsimp only
  have h :
      ‖pairing V (∑z:Z,f z • positionVector (J:=J) value position z)
        (rowApply V g (project value position G))‖^(2*((R-1)+1))≤
      (pairing V (project value position G) (project value position G)).re^((R-1)+1)*
      (pairing V (∑z:Z,f z • positionVector (J:=J) value position z)
        (∑z:Z,f z • positionVector (J:=J) value position z)).re^(R-1)*
      ((∑z:Z,(pairing V (positionVector (J:=J) value position z)
        (aaStarPower V g ((R-1)+1) (positionVector (J:=J) value position z))).re)*∑z:Z,‖f z‖^2) := by
    simp only [pairing_self_re,pairing_power_re,rowApply_eq_mulVec]
    exact PhysicalMomentEndpoint.aaStar_endpoint_trace_bound Finset.univ (matrix V g) (R-1)
      (positionVector (J:=J) value position) f (project value position G)
      (initialMass (J:=J) V) (initialMass_nonneg V hV)
  rw [Nat.sub_add_cancel hR] at h
  simp only [positionVector_sum,Finset.mem_univ,ite_true] at h
  rw [pairing_row_project value position V g hg] at h
  have hm := congrArg Complex.re (projected_rootedPowerMoment_eq value position V g hg R hR)
  simp only [Complex.re_sum] at hm
  rw [hm] at h
  exact h

section Source
variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem vertexWeight_nonzero_incidence (value : ∀i,P i→ℕ) (primes : Finset ℕ)
    (hprimes : ∀i p,value i p∈primes) (q : ℝ) (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (h : vertexWeight value primes q z a≠0) : ∀i k,(value i (a i k):ℤ)∣z.1 := by
  intro i k
  have hf := (Finset.prod_ne_zero_iff.mp h) (value i (a i k)) (hprimes i (a i k))
  by_contra hd
  apply hf
  simp only [vertexFactor,show (∃j l,value j (a j l)=value i (a i k)) from ⟨i,k,rfl⟩,
    ite_true,hd,ite_false]

theorem numeric_injective_of_ban (value : ∀i,P i→ℕ) (a b : PhysicalActiveLists P J)
    (hban : sourceCrossEdgeBan value a b) :
    Function.Injective (fun s : Sigma (fun _i:Fin K=>Fin (J+1))=>value s.1 (a s.1 s.2)) :=
  (physicalSourceLabels_injective_of_ban value a b hban).comp
    (Equiv.sigmaEquivProd (Fin K) (Fin (J+1))).injective

theorem physicalGeometry_supported (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (primes : Finset ℕ)
    (hprimes : ∀i p,value i p∈primes) (q : ℝ) :
    Supported value (fun z:SingleEdgeRootEncoding.primitiveSources U V=>z.val)
      (physicalGeometry (J:=J) value μ d₀ Y L U V exponents smooth ψ major σ primes q) := by
  intro z a w b h
  change (vertexWeight value primes q z.val a:ℂ)*
    baseGeometry value μ d₀ Y L U V exponents smooth ψ major σ z.val a w.val b*
      (vertexWeight value primes q w.val b:ℂ)≠0 at h
  have hparts := mul_ne_zero_iff.mp h
  have hleft := mul_ne_zero_iff.mp hparts.1
  have hz : vertexWeight value primes q z.val a≠0 := by
    intro he
    exact hleft.1 (by simp only [he,Complex.ofReal_zero])
  have hw : vertexWeight value primes q w.val b≠0 := by
    intro he
    exact hparts.2 (by simp only [he,Complex.ofReal_zero])
  have hallowed : sourcePhysicalEdgeAllowed value
      (RootLiteralGeometry.sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U V d₀ z.val a w.val b := by
    by_contra hn
    apply hleft.2
    simp only [baseGeometry,sourcePhysicalEdgeGeometry,hn,ite_false]
  have hban := hallowed.2.2.2.2.1
  exact ⟨⟨numeric_injective_of_ban value a b hban,
      vertexWeight_nonzero_incidence value primes hprimes q z.val a hz⟩,
    ⟨numeric_injective_of_ban value b a (sourceCrossEdgeBan_symm value hban),
      vertexWeight_nonzero_incidence value primes hprimes q w.val b hw⟩⟩

/-- Source (3.21) with the numerically admissible endpoint vectors and
the unchanged numerical moment that is transferred through root cells. -/
theorem physical_projected_endpoint_power_bound (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (VM : Fin K→ℝ) (hVM : ∀i,0≤VM i) (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (hprimes : ∀i p,value i p∈primes) (q : ℝ) (R : ℕ) (hR : 0<R)
    (f : SingleEdgeRootEncoding.primitiveSources U V→ℂ)
    (G : PhysicalRootedMoment.State (Z:=SingleEdgeRootEncoding.primitiveSources U V) (P:=P) (J:=J)→ℂ) :
    let pos := fun z:SingleEdgeRootEncoding.primitiveSources U V=>z.val
    let F := fun x : PhysicalRootedMoment.State (Z:=SingleEdgeRootEncoding.primitiveSources U V) (P:=P) (J:=J)=>f x.1
    ‖pairing VM F (rowApply VM
      (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q) G)‖^(2*R)≤
      (pairing VM (project value pos G) (project value pos G)).re^R*
      (pairing VM (project value pos F) (project value pos F)).re^(R-1)*
      ((PhysicalRootMomentNumeric.physicalMoment (J:=J) (N:=2*R) value μ VM d₀ Y L U V
        exponents smooth ψ major σ alternatingAdjoint primes (momentDamping q (2*R))).re*
        ∑z:SingleEdgeRootEncoding.primitiveSources U V,‖f z‖^2) := by
  dsimp only
  rw [physicalMoment_eq_rootedPowerMoment value μ VM d₀ Y L U V exponents smooth ψ major σ primes q hR]
  exact projected_endpoint_power_bound value _ VM hVM _
    (physicalGeometry_supported value μ d₀ Y L U V exponents smooth ψ major σ primes hprimes q)
    R hR f G

end Source

end Elliptic.Operator.PhysicalAdmissibleMoment
