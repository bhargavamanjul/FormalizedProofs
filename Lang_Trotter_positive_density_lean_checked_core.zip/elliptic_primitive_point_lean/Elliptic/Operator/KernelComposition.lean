module

public import Elliptic.Operator.WeightedSchur

/-!
# Composition and finite words of measured kernels

The composition kernel sums over the actual intermediate finite measure.
The bounds here are deductions from bounds for the constituent kernels;
no estimate for a determinant kernel or a source memory operator is assumed.
-/

@[expose] public section

namespace Elliptic.Operator

open scoped BigOperators

/-- The composition kernel, using the actual intermediate measure. -/
def finiteKernelCompose {ι κ τ : Type*} (t : Finset κ) (ν : κ → ℝ)
    (K : ι → κ → ℂ) (L : κ → τ → ℂ) (i : ι) (l : τ) : ℂ :=
  ∑ j ∈ t, (ν j : ℂ) * K i j * L j l

/-- Composition of the finite kernel actions is exactly action by the
composed measured kernel. -/
theorem finiteKernelApply_compose {ι κ τ : Type*}
    (t : Finset κ) (u : Finset τ) (ν : κ → ℝ) (ξ : τ → ℝ)
    (K : ι → κ → ℂ) (L : κ → τ → ℂ) (b : τ → ℂ) (i : ι) :
    finiteKernelApply u ξ (finiteKernelCompose t ν K L) b i =
      finiteKernelApply t ν K (finiteKernelApply u ξ L b) i := by
  unfold finiteKernelApply finiteKernelCompose
  simp_rw [Finset.mul_sum, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro l hl
  ring

/-- Operator norms multiply under actual measured kernel composition. -/
theorem finiteKernelBound_compose {ι κ τ : Type*}
    (s : Finset ι) (t : Finset κ) (u : Finset τ)
    (μ : ι → ℝ) (ν : κ → ℝ) (ξ : τ → ℝ)
    (K : ι → κ → ℂ) (L : κ → τ → ℂ) (M N : ℝ) (hM : 0 ≤ M)
    (hK : FiniteKernelBound s t μ ν K M)
    (hL : FiniteKernelBound t u ν ξ L N) :
    FiniteKernelBound s u μ ξ (finiteKernelCompose t ν K L) (M * N) := by
  intro b
  have heq : finiteKernelApply u ξ (finiteKernelCompose t ν K L) b =
      finiteKernelApply t ν K (finiteKernelApply u ξ L b) := by
    funext i
    exact finiteKernelApply_compose t u ν ξ K L b i
  rw [heq]
  calc
    _ ≤ M * finiteL2 t ν (finiteKernelApply u ξ L b) := hK _
    _ ≤ M * (N * finiteL2 u ξ b) := mul_le_mul_of_nonneg_left (hL b) hM
    _ = _ := (mul_assoc _ _ _).symm

/-- A finite word of actual kernel actions. The empty word is the identity
on coefficient vectors; no division by measure atoms is introduced. -/
def finiteKernelWordApply {ι : Type*} (s : Finset ι) (μ : ι → ℝ)
    (word : List ((ι → ι → ℂ) × ℝ)) (b : ι → ℂ) : ι → ℂ :=
  match word with
  | [] => b
  | head :: tail => finiteKernelApply s μ head.1 (finiteKernelWordApply s μ tail b)

/-- A finite word is bounded by the product of its constituent nonnegative
bounds. This is an induction over actual finite kernel actions. -/
theorem finiteKernelWordApply_bound {ι : Type*} (s : Finset ι) (μ : ι → ℝ)
    (word : List ((ι → ι → ℂ) × ℝ))
    (hword : ∀ entry ∈ word, 0 ≤ entry.2 ∧ FiniteKernelBound s s μ μ entry.1 entry.2)
    (b : ι → ℂ) :
    finiteL2 s μ (finiteKernelWordApply s μ word b) ≤
      (word.map Prod.snd).prod * finiteL2 s μ b := by
  induction word with
  | nil => simp [finiteKernelWordApply]
  | cons head tail ih =>
    have hhead := hword head (by simp)
    have htail : ∀ entry ∈ tail, 0 ≤ entry.2 ∧
        FiniteKernelBound s s μ μ entry.1 entry.2 := by
      intro entry he
      exact hword entry (by simp [he])
    simp only [finiteKernelWordApply, List.map_cons, List.prod_cons]
    calc
      _ ≤ head.2 * finiteL2 s μ (finiteKernelWordApply s μ tail b) := hhead.2 _
      _ ≤ head.2 * ((tail.map Prod.snd).prod * finiteL2 s μ b) :=
        mul_le_mul_of_nonneg_left (ih htail) hhead.1
      _ = _ := (mul_assoc _ _ _).symm

end Elliptic.Operator
