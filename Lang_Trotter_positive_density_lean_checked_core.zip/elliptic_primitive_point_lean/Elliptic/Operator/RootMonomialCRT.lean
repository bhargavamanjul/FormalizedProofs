module

public import Elliptic.Operator.RootMonomialAverage
public import Elliptic.Operator.FinitePrimeCRT

/-! # Exact CRT identification of the literal root monomials -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootMonomialCRT
open scoped BigOperators
open MeasureTheory RootRecordBonferroni RootRecordGap RootIntegratedBonferroni
open RootMonomialTests RootMonomialAverage RootLiteralSum RootVariableSum
open RootArchimedeanTransfer RootGridMeasure OriginalPathWeights
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

abbrev support (rec : Record K J N R Q) (s : Finset ℕ) : Finset ℕ := activePrimes rec∪s

abbrev modulus (rec : Record K J N R Q) (s : Finset ℕ) : ℕ := ∏p∈support rec s,p

theorem modulus_source {K : ℕ} {C L : ℝ} (rec : RootDiscreteBudget.SourceRecord K C L)
    (s : Finset ℕ) : modulus rec s=RootDiscreteBudget.recordModulus rec s := rfl

theorem support_prime (rec : Record K J N R Q) (s P : Finset ℕ)
    (hA : activePrimes rec⊆P) (hs : s⊆P) (hP : ∀p∈P,p.Prime) :
    ∀p∈support rec s,p.Prime := by
  intro p hp
  exact hP p ((Finset.union_subset hA hs) hp)

/-- The local residue test is obtained by actual matrix reduction. -/
def residueTest (rec : Record K J N R Q) (s : Finset ℕ)
    (hpr : ∀p∈support rec s,p.Prime)
    (f : (∀p : support rec s,Option (ZMod p))→ℂ)
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (modulus rec s))) : ℂ :=
  f (FinitePrimeCRT.residueLines (support rec s) hpr g)

theorem literal_monomial (rec : Record K J N R Q) (s : Finset ℕ)
    (hpr : ∀p∈support rec s,p.Prime)
    (f : (∀p : support rec s,Option (ZMod p))→ℂ)
    (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ) :
    literalRootSum U V (fun q g=>G q*f (fun p=>FinitePrimeCRT.integerLines g p)) =
      variableRootSum U V (modulus rec s)
        (RootGridPartition.fullInterval 1 16) (RootGridPartition.fullInterval 1 2)
        (RootGridPartition.fullInterval 0 1) (fun q g=>G q*residueTest rec s hpr f g) := by
  rw [←literalRootSum_residue]
  apply literalRootSum_congr
  intro q g
  congr 1
  apply congrArg f
  funext p
  exact (FinitePrimeCRT.residueLines_map_int_global (support rec s) hpr g p).symm

theorem residueTest_average (rec : Record K J N R Q) (s : Finset ℕ)
    (hpr : ∀p∈support rec s,p.Prime)
    [Fintype (ZMod (modulus rec s))] [∀p : support rec s,Fact p.val.Prime]
    (f : (∀p : support rec s,Option (ZMod p))→ℂ) :
    (∑g,residueTest rec s hpr f g)/
      (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (modulus rec s))):ℂ)=average f := by
  letI : Fintype (ZMod (∏p∈support rec s,p)) :=
    (inferInstance : Fintype (ZMod (modulus rec s)))
  have h := FinitePrimeCRT.residueLines_average (support rec s) hpr f
  simpa only [residueTest,RootIntegratedBonferroni.average,line_card,modulus] using h

/-- The actual signed real-root integral and exact finite joint line
average factor, with the primitive density UV/zeta(2) retained. -/
theorem integral_monomial (rec : Record K J N R Q) (s : Finset ℕ)
    (hpr : ∀p∈support rec s,p.Prime)
    [Fintype (ZMod (modulus rec s))] [∀p : support rec s,Fact p.val.Prime]
    (f : (∀p : support rec s,Option (ZMod p))→ℂ)
    (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ) :
    rootIntegral U V (modulus rec s) (fun q g=>G q*residueTest rec s hpr f g) =
      ((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫q in rootBox,G q)*average f := by
  unfold rootIntegral averageKernel
  simp only [←Finset.mul_sum,mul_div_assoc]
  rw [residueTest_average,integral_mul_const,mul_assoc]

end Elliptic.Operator.RootMonomialCRT
