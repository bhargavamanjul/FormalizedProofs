module
public import Elliptic.Operator.CleanFiberAssembly
public import Elliptic.Operator.PhysicalMaskedSchur

/-! Actual active-slot permutation averages and total-memory projection
preserve the clean masked norm, with the original factorial bag measure. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanSymmetry
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
local instance physicalCleanSymmetryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {G Z : Type*} [Fintype G] [Fintype Z]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- The literal active-slot action on the full physical bag state. -/
def permute (π : Permutations (G:=G) (J:=J)) :
    State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) ≃
    State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) where
  toFun s := (position s,(fun i j => active s i (π i j)),bags s)
  invFun s := (position s,(fun i j => active s i ((π i).symm j)),bags s)
  left_inv s := by simp [position,active,bags]
  right_inv s := by simp [position,active,bags]

theorem permute_mass (ν : ∀ i, P i → ℝ) (π : Permutations (G:=G) (J:=J))
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    mass (B:=B) ν (permute π s)=mass (B:=B) ν s := by
  unfold mass
  apply Finset.prod_congr rfl
  intro i hi
  change tupleWeight (ν i) (fun j => active s i (π i j))*_ = _
  change (∏ j, ν i (active s i (π i j)))*_ = (∏ j, ν i (active s i j))*_
  rw [Equiv.prod_comp (π i) (fun j => ν i (active s i j))]
  rfl

theorem permute_total (π : Permutations (G:=G) (J:=J))
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    Total (permute π s) ↔ Total s := Iff.rfl

/-- Density of the actual specified-permutation physical term. -/
def termDensity (ν : ∀ i, P i → ℝ) (V : G → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (π τ : Permutations (G:=G) (J:=J))
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  term (fun i p => (ν i p:ℂ)) (fun _ => 1) (fun i => (V i:ℂ)⁻¹)
    (fun _ => false) (fun _ => false) (ρ:ℂ) anchor geometry s t π τ / ((mass (B:=B) ν t:ℝ):ℂ)

theorem termDensity_permute (ν : ∀ i, P i → ℝ) (V : G → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (π τ : Permutations (G:=G) (J:=J))
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    termDensity (B:=B) ν V ρ anchor geometry π τ s t =
      termDensity (B:=B) ν V ρ anchor geometry (fun _ => Equiv.refl _) (fun _ => Equiv.refl _)
        (permute π s) (permute τ t) := by
  unfold termDensity
  rw [permute_mass]
  rfl

/-- Every literal pair of endpoint permutations has the same clean norm. -/
theorem termDensity_bound_of_identity (ν : ∀ i, P i → ℝ) (V : G → ℝ) (ρ M : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hK : FiniteMeasuredBilinearBound Finset.univ Finset.univ (mass (B:=B) ν) (mass (B:=B) ν)
      (termDensity (B:=B) ν V ρ anchor geometry (fun _ => Equiv.refl _) (fun _ => Equiv.refl _)) M)
    (π τ : Permutations (G:=G) (J:=J)) :
    FiniteMeasuredBilinearBound Finset.univ Finset.univ (mass (B:=B) ν) (mass (B:=B) ν)
      (termDensity (B:=B) ν V ρ anchor geometry π τ) M := by
  have h := finiteMeasuredBilinearBound_equiv (permute π) (permute τ) (mass (B:=B) ν) (mass (B:=B) ν)
    (mass (B:=B) ν) (mass (B:=B) ν) (fun s => (permute_mass (B:=B) ν π s).symm)
    (fun s => (permute_mass (B:=B) ν τ s).symm) _ M hK
  simpa only [← termDensity_permute ν V ρ anchor geometry π τ] using h

/-- Actual normalized clean masked kernel, after both endpoint averages
and the source's single total-memory cutoff. -/
theorem clean_kernel_bound_of_identity
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0<ν i p) (V : G → ℝ) (ρ M : ℝ)
    (hM : 0≤M) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hK : FiniteMeasuredBilinearBound Finset.univ Finset.univ (mass (B:=B) ν) (mass (B:=B) ν)
      (termDensity (B:=B) ν V ρ anchor geometry (fun _ => Equiv.refl _) (fun _ => Equiv.refl _)) M) :
    FiniteMeasuredBilinearBound Finset.univ Finset.univ (mass (B:=B) ν) (mass (B:=B) ν)
      (fun s t => originalKernel ν V (fun _ => false) (fun _ => false) ρ anchor geometry s t /
        ((mass (B:=B) ν t:ℝ):ℂ)) M := by
  let Perm := Permutations (G:=G) (J:=J)
  let N : ℝ := Fintype.card Perm
  have hN : N≠0 := by dsimp [N]; exact_mod_cast Fintype.card_ne_zero
  have hw : (∑ _q : Perm×Perm, N⁻¹^2)=1 := by
    simp only [Finset.sum_const,Finset.card_univ,Fintype.card_prod,nsmul_eq_mul,Nat.cast_mul]
    change (N*N)*N⁻¹^2=1
    field_simp
  have hav := finiteMeasuredBilinearBound_convex Finset.univ Finset.univ
    (Finset.univ : Finset (Perm×Perm)) (mass (B:=B) ν) (mass (B:=B) ν)
    (fun q => termDensity (B:=B) ν V ρ anchor geometry q.1 q.2) (fun _ => N⁻¹^2) M
    (fun _ _ => sq_nonneg _) hw (fun q _ => termDensity_bound_of_identity ν V ρ M anchor geometry hK q.1 q.2)
  have hdiag := PhysicalCleanMemory.measured_clean_endpoint_bound Finset.univ Finset.univ
    (mass (B:=B) ν) (mass (B:=B) ν) (fun s _ => (mass_pos ν hν s).le) (fun s _ => (mass_pos ν hν s).le)
    _ M hM (fun s => if Total s then (1:ℂ) else 0) (fun s => if Total s then (1:ℂ) else 0)
    (fun s _ => by split_ifs <;> norm_num) (fun s _ => by split_ifs <;> norm_num) hav
  convert hdiag using 1
  funext s t
  by_cases hs : Total s <;> by_cases ht : Total t <;>
    simp only [originalKernel,kernel,hs,ht,true_and,and_true,false_and,and_false,
      ite_true,ite_false,one_mul,mul_one,mul_zero,zero_mul,zero_div]
  simp only [Fintype.sum_prod_type,termDensity,Finset.mul_sum,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro π hπ
  apply Finset.sum_congr rfl
  intro τ hτ
  dsimp [N,Perm]
  push_cast
  ring

end Elliptic.Operator.PhysicalCleanSymmetry
