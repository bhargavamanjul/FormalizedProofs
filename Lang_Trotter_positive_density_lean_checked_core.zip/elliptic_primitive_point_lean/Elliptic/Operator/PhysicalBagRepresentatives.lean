module

public import Elliptic.Operator.PhysicalBagMeasure

/-!
# Every admissible physical bag state has an ordered representative

The quotient contains exactly the actual ordered memories. Choosing one
representative in each group preserves the single total-memory cutoff, so
an estimate proved for every ordered state applies on every admissible bag
state without adding a surjectivity assumption.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBagRepresentatives
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- Every member of the literal bag range has an actual ordered memory. -/
theorem memory_exists {X : Type*} [Fintype X] {B : ℕ} (b : MemoryBag X B) :
    ∃ m : MemoryState X B, memoryBagOf m = b := by
  obtain ⟨m,_,hm⟩ := Finset.mem_image.mp b.property
  exact ⟨m,Subtype.ext hm⟩

variable {G Z : Type*} [Fintype G]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- Every bag state satisfying the physical total cutoff is represented by
an actual ordered physical state, with position and active lists unchanged. -/
theorem ofOrdered_exists
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) (hs : Total s) :
    ∃ t : PhysicalMemoryState (Z:=Z) P Line J B, ofOrdered t = s := by
  choose m hm using (fun i => memory_exists (bags s i))
  have htotal : (∑ i, (m i).size) ≤ B := by
    have he : (∑ i, (m i).size) = ∑ i, (bags s i).val.card := by
      apply Finset.sum_congr rfl
      intro i _
      rw [← memoryBagOf_card (m i),hm i]
    rw [he]
    exact hs
  let t : PhysicalMemoryState (Z:=Z) P Line J B := ⟨(position s,active s,m),htotal⟩
  refine ⟨t,?_⟩
  apply Prod.ext
  · rfl
  · apply Prod.ext
    · rfl
    · funext i
      exact hm i

/-- The full quotient map is surjective onto its exact total-cutoff subtype. -/
theorem ofOrdered_surjective : Function.Surjective
    (fun t : PhysicalMemoryState (Z:=Z) P Line J B =>
      (⟨ofOrdered t,total_ofOrdered t⟩ :
        {s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) // Total s})) := by
  intro s
  obtain ⟨t,ht⟩ := ofOrdered_exists s.val s.property
  exact ⟨t,Subtype.ext ht⟩

end Elliptic.Operator.PhysicalBagRepresentatives
