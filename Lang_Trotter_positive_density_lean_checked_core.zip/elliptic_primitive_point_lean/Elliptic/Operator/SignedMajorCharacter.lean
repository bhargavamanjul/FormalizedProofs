module

public import Artin.MarkedReplacement
public import Elliptic.SourceContracts

/-!
# Exact multiplicative-character separation of the signed major-arc phase

The rational six-variable phase in the source is a bounded function on six
copies of the unit group. Finite character inversion separates it exactly,
with coefficient L1 mass at most phi(k)^6. The proof works for either shift
sign and does not assume the major-arc estimate or a transform bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorCharacter
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance majorCharacterDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable (k d : ℕ) [NeZero k]
abbrev UnitTuple := Fin d→(ZMod k)ˣ
abbrev CharacterTuple := Fin d→DirichletCharacter ℂ k

/-- Product character in the actual d independent endpoint variables. -/
def characterValue (χ : CharacterTuple k d) (u : UnitTuple k d) : ℂ := ∏i,χ i (u i)

theorem characterValue_norm (χ : CharacterTuple k d) (u : UnitTuple k d) :
    ‖characterValue k d χ u‖=1 := by simp [characterValue,norm_prod]

/-- Normalized multiplicative Fourier coefficient. -/
def coefficient (f : UnitTuple k d→ℂ) (χ : CharacterTuple k d) : ℂ :=
  ((k.totient:ℂ)^d)⁻¹ * ∑u : UnitTuple k d,f u * characterValue k d χ (fun i=>(u i)⁻¹)

/-- Orthogonality over all d characters is the literal tuple diagonal. -/
theorem tuple_orthogonality (u v : UnitTuple k d) :
    (∑χ : CharacterTuple k d,characterValue k d χ (fun i=>(u i)⁻¹)*characterValue k d χ v) =
      if u=v then (k.totient:ℂ)^d else 0 := by
  simp only [characterValue,←Finset.prod_mul_distrib]
  rw [←Fintype.prod_sum (fun (i : Fin d) (χ : DirichletCharacter ℂ k)=>χ (((u i)⁻¹ : (ZMod k)ˣ):ZMod k)*χ (v i))]
  have hlocal (i : Fin d) :
      (∑χ : DirichletCharacter ℂ k,χ (((u i)⁻¹ : (ZMod k)ˣ):ZMod k)*χ (v i))=
        if u i=v i then (k.totient:ℂ) else 0 := by
    simpa only [ZMod.inv_coe_unit,Units.val_inj] using
      DirichletCharacter.sum_char_inv_mul_char_eq ℂ (u i).isUnit (v i)
  simp_rw [hlocal]
  by_cases huv : u=v
  · subst v
    simp
  · obtain ⟨i,hi⟩ : ∃i,u i≠v i := by simpa only [funext_iff,not_forall] using huv
    rw [if_neg huv]
    exact Finset.prod_eq_zero (Finset.mem_univ i) (if_neg hi)

/-- Exact character inversion, uniform over every bounded or unbounded
function on the unit tuples. -/
theorem inversion (f : UnitTuple k d→ℂ) (v : UnitTuple k d) :
    (∑χ : CharacterTuple k d,coefficient k d f χ*characterValue k d χ v)=f v := by
  unfold coefficient
  simp_rw [mul_assoc,Finset.sum_mul]
  rw [←Finset.mul_sum,Finset.sum_comm]
  simp_rw [mul_assoc,←Finset.mul_sum,tuple_orthogonality]
  simp only [mul_ite,mul_zero,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  have hk : (k.totient:ℂ)≠0 := by
    exact_mod_cast (Nat.totient_pos.mpr (NeZero.pos k)).ne'
  field_simp

/-- Each Fourier coefficient of a unit-bounded phase has norm at most one. -/
theorem coefficient_norm_le (f : UnitTuple k d→ℂ) (hf : ∀u,‖f u‖≤1)
    (χ : CharacterTuple k d) : ‖coefficient k d f χ‖≤1 := by
  have hcard : Fintype.card (UnitTuple k d)=k.totient^d := by
    simp only [UnitTuple,Fintype.card_fun,Fintype.card_fin,ZMod.card_units_eq_totient]
  have hsum : ‖∑u : UnitTuple k d,f u*characterValue k d χ (fun i=>(u i)⁻¹)‖≤(k.totient:ℝ)^d := by
    calc
      _ ≤ ∑u : UnitTuple k d,‖f u*characterValue k d χ (fun i=>(u i)⁻¹)‖ := norm_sum_le _ _
      _ ≤ ∑_u : UnitTuple k d,(1:ℝ) := by
        apply Finset.sum_le_sum
        intro u _
        simpa only [norm_mul,characterValue_norm,mul_one] using hf u
      _ = _ := by simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,hcard,Nat.cast_pow]
  have hk : (0:ℝ)<(k.totient:ℝ)^d := by
    exact pow_pos (by exact_mod_cast Nat.totient_pos.mpr (NeZero.pos k)) _
  rw [coefficient,norm_mul,norm_inv,norm_pow,Complex.norm_natCast]
  exact (mul_le_mul_of_nonneg_left hsum (inv_nonneg.mpr hk.le)).trans_eq (inv_mul_cancel₀ hk.ne')

/-- The total arithmetic separation cost is exactly bounded by phi(k)^d. -/
theorem coefficient_l1_le (f : UnitTuple k d→ℂ) (hf : ∀u,‖f u‖≤1) :
    (∑χ : CharacterTuple k d,‖coefficient k d f χ‖)≤(k.totient:ℝ)^d := by
  have hcard : Fintype.card (DirichletCharacter ℂ k)=k.totient := by
    rw [←Nat.card_eq_fintype_card]
    exact DirichletCharacter.card_eq_totient_of_hasEnoughRootsOfUnity ℂ k
  calc
    _ ≤ ∑_χ : CharacterTuple k d,(1:ℝ) :=
      Finset.sum_le_sum (fun χ _=>coefficient_norm_le k d f hf χ)
    _ = _ := by simp [CharacterTuple,Fintype.card_fun,hcard]

/-- Applying inversion to an actual independent finite variable sum
separates it into the product of its d one-variable character polynomials. -/
theorem weighted_separation (X : Fin d→Type) [∀i,Fintype (X i)]
    (units : ∀i,X i→(ZMod k)ˣ) (a : ∀i,X i→ℂ) (f : UnitTuple k d→ℂ) :
    (∑x : ∀i,X i,(∏i,a i (x i))*f (fun i=>units i (x i))) =
      ∑χ : CharacterTuple k d,coefficient k d f χ*
        ∏i,∑y : X i,a i y*χ i (units i y) := by
  simp_rw [←inversion k d f,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro χ _
  rw [Fintype.prod_sum,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  unfold characterValue
  rw [Finset.prod_mul_distrib]
  ring

def unitReal (u : (ZMod k)ˣ) : ℝ := (u.val.val:ℝ)

/-- The source six-variable phase with an arbitrary shift sign. -/
def signedRationalPhase (h : ℤ) (σ : ℤ) (u : UnitTuple k 6) : ℂ :=
  SourceContracts.additivePhase ((h:ℝ)/(k:ℝ)*
    (unitReal k (u 1)*unitReal k (u 2)*unitReal k (u 3)-
      unitReal k (u 0)*unitReal k (u 4)*unitReal k (u 5)-
      (σ:ℝ)*unitReal k (u 1)+(σ:ℝ)*unitReal k (u 0)))

theorem signedRationalPhase_norm (h σ : ℤ) (u : UnitTuple k 6) :
    ‖signedRationalPhase k h σ u‖=1 := SourceContracts.additivePhase_norm _

/-- Exact six-character separation for both predecessor and successor
phases, with the same quantitative coefficient budget. -/
theorem signedRationalPhase_separation (h σ : ℤ) :
    (∀u : UnitTuple k 6, signedRationalPhase k h σ u=
      ∑χ : CharacterTuple k 6,coefficient k 6 (signedRationalPhase k h σ) χ*characterValue k 6 χ u) ∧
    (∑χ : CharacterTuple k 6,‖coefficient k 6 (signedRationalPhase k h σ) χ‖)≤(k.totient:ℝ)^6 := by
  exact ⟨fun u=>(inversion k 6 _ u).symm,
    coefficient_l1_le k 6 _ (fun u=>(signedRationalPhase_norm k h σ u).le)⟩

/-- Integral periodicity of the actual additive phase. -/
theorem additivePhase_integer (n : ℤ) : SourceContracts.additivePhase (n:ℝ)=1 := by
  unfold SourceContracts.additivePhase
  convert Complex.exp_int_mul_two_pi_mul_I n using 1
  congr 1
  push_cast
  ring

/-- A rational phase depends only on the residue of its integer argument. -/
theorem rationalPhase_congr (h n m : ℤ) (hnm : (n:ZMod k)=(m:ZMod k)) :
    SourceContracts.additivePhase ((h:ℝ)/(k:ℝ)*(n:ℝ))=
      SourceContracts.additivePhase ((h:ℝ)/(k:ℝ)*(m:ℝ)) := by
  have hz : ((n-m:ℤ):ZMod k)=0 := by push_cast; exact sub_eq_zero.mpr hnm
  obtain ⟨t,ht⟩ := (ZMod.intCast_zmod_eq_zero_iff_dvd (n-m) k).mp hz
  have hk : (k:ℝ)≠0 := by exact_mod_cast NeZero.ne k
  have ht' : (n:ℝ)-(m:ℝ)=(k:ℝ)*(t:ℝ) := by exact_mod_cast ht
  have he : (h:ℝ)/(k:ℝ)*(n:ℝ)=(h:ℝ)/(k:ℝ)*(m:ℝ)+(h*t:ℤ) := by
    push_cast
    rw [show (n:ℝ)=(m:ℝ)+(k:ℝ)*(t:ℝ) by linarith]
    field_simp
  rw [he,SourceContracts.additivePhase_add,additivePhase_integer,mul_one]

/-- The integer polynomial in the six source variables (a,b,m,n,r,s). -/
def signedIntegerPolynomial (σ : ℤ) (z : Fin 6→ℤ) : ℤ :=
  z 1*z 2*z 3-z 0*z 4*z 5-σ*z 1+σ*z 0

/-- The source rational phase on actual integer variables is exactly the
phase separated above on their unit residues, for either sign. -/
theorem signed_integer_phase_eq (h σ : ℤ) (z : Fin 6→ℤ) (u : UnitTuple k 6)
    (hz : ∀i,(z i:ZMod k)=(u i:ZMod k)) :
    SourceContracts.additivePhase ((h:ℝ)/(k:ℝ)*(signedIntegerPolynomial σ z:ℝ))=
      signedRationalPhase k h σ u := by
  let w : Fin 6→ℤ := fun i=>(u i).val.val
  have hw (i : Fin 6) : (w i:ZMod k)=(u i:ZMod k) := by simp [w]
  have he : (signedIntegerPolynomial σ z:ZMod k)=(signedIntegerPolynomial σ w:ZMod k) := by
    unfold signedIntegerPolynomial
    push_cast
    simp only [hz,hw]
  rw [rationalPhase_congr k h _ _ he]
  unfold signedRationalPhase signedIntegerPolynomial unitReal w
  congr 1
  push_cast
  rfl

end Elliptic.Operator.SignedMajorCharacter
