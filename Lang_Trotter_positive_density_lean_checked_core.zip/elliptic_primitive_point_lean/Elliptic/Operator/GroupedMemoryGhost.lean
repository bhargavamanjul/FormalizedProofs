module

public import Elliptic.Operator.MemoryWord
public import Elliptic.Operator.PhysicalMemoryEdges

/-!
# Actual grouped ghost operation and alternating memory word

The ghost operation keeps the physical position and active lists fixed,
and performs one literal indexed ghost choice in each group. The output
obeys the total pending-memory cutoff. Together with the actual physical
edge this gives a finite word whose dependent choice histories are expanded
exactly by `ChoiceOperation.wordApply_eq_history_sum`.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable Classical.typeDecidableEq

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

abbrev PhysicalGhostChoice (s : PhysicalMemoryState (Z:=Z) P Line J B) :=
  ∀ i, GhostChoice (s.memory P Line J B i)

namespace PhysicalGhostChoice

def outputSize {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalGhostChoice s) (i : I) : ℕ :=
  (s.memory P Line J B i).size - (c i).1.card + (c i).2.size

def Valid (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s) : Prop :=
  (∀ i, GhostChoice.Valid (anchor (s.position P Line J B) i)
    (s.memory P Line J B i) (c i)) ∧ (∑ i, c.outputSize i) ≤ B

def output (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) : PhysicalMemoryState (Z:=Z) P Line J B :=
  ⟨(s.position P Line J B, s.active P Line J B,
    fun i => ghostOutput (anchor (s.position P Line J B) i)
      (s.memory P Line J B i) (c i) (hc.1 i)), by
        simpa only [ghostOutput_size, outputSize] using hc.2⟩

@[simp] theorem output_position (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) :
    (c.output anchor s hc).position P Line J B = s.position P Line J B := rfl

@[simp] theorem output_active (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) :
    (c.output anchor s hc).active P Line J B = s.active P Line J B := rfl

@[simp] theorem output_memory (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) :
    (c.output anchor s hc).memory P Line J B i =
      ghostOutput (anchor (s.position P Line J B) i)
        (s.memory P Line J B i) (c i) (hc.1 i) := rfl

end PhysicalGhostChoice

def physicalGhostChoiceWeight [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s) : ℂ :=
  ∏ i, (ghostChoiceWeight (ν i) (V i) η q ρ (anchor (s.position P Line J B) i)
    (s.memory P Line J B i) (c i) : ℂ)

/-- A full ghost step as the actual finite choice operation. -/
def physicalGhostOperation [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p) :
    ChoiceOperation (PhysicalMemoryState (Z:=Z) P Line J B) where
  Choice := PhysicalGhostChoice
  finiteChoice _ := inferInstance
  valid := PhysicalGhostChoice.Valid anchor
  output := PhysicalGhostChoice.output anchor
  coefficient := physicalGhostChoiceWeight ν V η q ρ anchor
  ghostBirths _ c := ∑ i, (c i).2.size

/-- A full edge step, including both endpoint slot permutations, as a
literal choice operation. Invalid choices contribute zero. -/
def physicalEdgeOperation [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ) :
    ChoiceOperation (PhysicalMemoryState (Z:=Z) P Line J B) where
  Choice := PhysicalEdgeChoice
  finiteChoice _ := inferInstance
  valid := PhysicalEdgeChoice.Valid anchor
  output := PhysicalEdgeChoice.output anchor
  coefficient s c := if hc : c.Valid anchor s then
    physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc else 0
  stores _ c := ∑ i, (c.group i).1.toNat

def physicalMemorySize (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℕ :=
  ∑ i, (s.memory P Line J B i).size

theorem physicalGhostOperation_size [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (c : (physicalGhostOperation ν V η q ρ anchor).ValidChoice s) :
    physicalMemorySize ((physicalGhostOperation ν V η q ρ anchor).output s c.val c.property) ≤
      physicalMemorySize s + (physicalGhostOperation ν V η q ρ anchor).ghostBirths s c.val +
        (physicalGhostOperation ν V η q ρ anchor).stores s c.val := by
  change (∑ i, (ghostOutput _ _ _ (c.property.1 i)).size) ≤
    (∑ i, (s.memory P Line J B i).size) + (∑ i, (c.val i).2.size) + 0
  simp only [ghostOutput_size, add_zero, ← Finset.sum_add_distrib]
  exact Finset.sum_le_sum fun i _ => Nat.add_le_add_right (Nat.sub_le _ _) _

theorem physicalEdgeOperation_size [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (c : (physicalEdgeOperation ν V ρ anchor geometry).ValidChoice s) :
    physicalMemorySize ((physicalEdgeOperation ν V ρ anchor geometry).output s c.val c.property) ≤
      physicalMemorySize s + (physicalEdgeOperation ν V ρ anchor geometry).ghostBirths s c.val +
        (physicalEdgeOperation ν V ρ anchor geometry).stores s c.val := by
  change (∑ i, (edgeGroupOutput _ _ _ _ (c.property.1 i).2).size) ≤
    (∑ i, (s.memory P Line J B i).size) + 0 + (∑ i, (c.val.group i).1.toNat)
  simp only [edgeGroupOutput_size, edgeGroupOutputSize_eq, add_zero, ← Finset.sum_add_distrib]
  exact Finset.sum_le_sum fun i _ => Nat.add_le_add_right (Nat.sub_le _ _) _

theorem physicalEdgeOperation_stores_le [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (c : (physicalEdgeOperation ν V ρ anchor geometry).Choice s) :
    (physicalEdgeOperation ν V ρ anchor geometry).stores s c ≤ Fintype.card I := by
  change (∑ i, (c.group i).1.toNat) ≤ _
  calc
    _ ≤ ∑ _i : I, 1 := Finset.sum_le_sum fun i _ => by cases (c.group i).1 <;> simp
    _ = _ := by simp

theorem physicalEdgeOperation_apply [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    (physicalEdgeOperation ν V ρ anchor geometry).apply F s =
      physicalEdgeApply ν V ρ anchor geometry F s := by
  rw [ChoiceOperation.apply_eq_all_choices]
  unfold physicalEdgeApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : c.Valid anchor s
  · simp [physicalEdgeOperation,hc]
  · simp [physicalEdgeOperation,hc]

/-- The chronological operation list G0,E0,G1,...,E(N-1),GN. -/
def alternatingMemoryOperations {X : Type*}
    (G E : ℕ → ChoiceOperation X) : ℕ → List (ChoiceOperation X)
  | 0 => [G 0]
  | N+1 => alternatingMemoryOperations G E N ++ [E N,G (N+1)]

/-- The same chronological order written from its first operation, so
actual dependent histories can be inspected one step at a time. -/
def memoryOperationsFrom {X : Type*} (G E : ℕ → ChoiceOperation X) :
    ℕ → ℕ → List (ChoiceOperation X)
  | first, 0 => [G first]
  | first, N+1 => G first :: E first :: memoryOperationsFrom G E (first+1) N

theorem history_stores_le_edges {X : Type*}
    (G E : ℕ → ChoiceOperation X) (K : ℕ)
    (hG : ∀ j x c, (G j).stores x c=0)
    (hE : ∀ j x c, (E j).stores x c≤K)
    (first N : ℕ) (x : X)
    (h : ChoiceOperation.History (memoryOperationsFrom G E first N) x) :
    h.stores ≤ K*N := by
  induction N generalizing first x with
  | zero => simp [memoryOperationsFrom, ChoiceOperation.History.stores, hG]
  | succ N ih =>
      have he := hE first _ h.2.1.val
      have ht := ih (first+1) _ h.2.2
      change (G first).stores x h.1.val +
        ((E first).stores _ h.2.1.val + h.2.2.stores) ≤ K*(N+1)
      rw [hG]
      simp only [Nat.mul_add, Nat.mul_one]
      omega

theorem memoryOperationsFrom_step_size {X : Type*}
    (size : X → ℕ) (G E : ℕ → ChoiceOperation X)
    (hG : ∀ j x (c : (G j).ValidChoice x),
      size ((G j).output x c.val c.property) ≤
        size x + (G j).ghostBirths x c.val + (G j).stores x c.val)
    (hE : ∀ j x (c : (E j).ValidChoice x),
      size ((E j).output x c.val c.property) ≤
        size x + (E j).ghostBirths x c.val + (E j).stores x c.val)
    (first N : ℕ) : ∀ O ∈ memoryOperationsFrom G E first N,
      ∀ x (c : O.ValidChoice x), size (O.output x c.val c.property) ≤
        size x + O.ghostBirths x c.val + O.stores x c.val := by
  induction N generalizing first with
  | zero => simpa [memoryOperationsFrom] using hG first
  | succ N ih =>
      intro O hO
      simp only [memoryOperationsFrom, List.mem_cons] at hO
      rcases hO with rfl | rfl | hO
      · exact hG first
      · exact hE first
      · exact ih (first+1) O hO

/-- The exact boundary history expansion for the actual alternating list.
This retains each actual output and its indexed-choice multiplicity. -/
theorem alternating_memory_boundary_histories {X : Type*} [Fintype X]
    (G E : ℕ → ChoiceOperation X) (N : ℕ) (μ : X → ℝ) (a b : X → ℂ) :
    (∑ x : X, (μ x : ℂ)*a x*
      ChoiceOperation.wordApply (alternatingMemoryOperations G E N) b x) =
      ∑ x : X, ∑ h : ChoiceOperation.History (alternatingMemoryOperations G E N) x,
        (μ x : ℂ)*a x*h.weight*b h.final :=
  ChoiceOperation.boundary_eq_history_sum _ μ a b

end Elliptic.Operator
