module

public import Elliptic.Operator.SourceBonferroni
public import Elliptic.Operator.IntegerRootReplacement

/-!
# Uniform Bonferroni depth and absorption of the original path budget

The expectation gap is exponentially small enough to absorb the original
exp(O(L^.73)) record budget, uniformly in the actual finite line model.
The mean bound is stated explicitly; no expected gap estimate is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BonferroniBudget
open Filter
open SourceBonferroni
open scoped BigOperators

def truncationIndex (L : ℝ) : ℕ := (⌈L^(76/100 : ℝ)⌉₊-1)/2

theorem depth_bounds (L : ℝ) (hL : 2 ≤ L^(76/100 : ℝ)) :
    L^(76/100 : ℝ)/2 ≤ (2*truncationIndex L+1 : ℕ) ∧
      2*truncationIndex L+1 ≤ ⌈L^(76/100 : ℝ)⌉₊ := by
  have hc := Nat.le_ceil (L^(76/100 : ℝ))
  have hc2 : 2 ≤ ⌈L^(76/100 : ℝ)⌉₊ := by exact_mod_cast hL.trans hc
  have hn : ⌈L^(76/100 : ℝ)⌉₊-1 ≤ 2*truncationIndex L+1 ∧
      2*truncationIndex L+1 ≤ ⌈L^(76/100 : ℝ)⌉₊ := by
    unfold truncationIndex
    omega
  refine ⟨?_,hn.2⟩
  have hh : (⌈L^(76/100 : ℝ)⌉₊ : ℝ)-1 ≤ (2*truncationIndex L+1 : ℕ) := by
    have hz : ⌈L^(76/100 : ℝ)⌉₊ ≤ 2*truncationIndex L+1+1 := by omega
    have hzR : (⌈L^(76/100 : ℝ)⌉₊ : ℝ) ≤ (2*truncationIndex L+1 : ℕ)+1 := by exact_mod_cast hz
    linarith
  linarith

theorem gap_le_exp (G M t : ℝ) (T : ℕ) (ht : 0 < t)
    (h : G*t^T ≤ Real.exp (t*M)) :
    G ≤ Real.exp (t*M-(T:ℝ)*Real.log t) := by
  rw [Real.exp_sub, Real.exp_nat_mul, Real.exp_log ht]
  exact (le_div_iff₀ (pow_pos ht T)).mpr h

/-- A single threshold precedes the gap, its mean and the depth. -/
theorem eventually_absorb_gap (C B A : ℝ) (hC : 0 ≤ C) (_hB : 0 ≤ B) (hA : 0 ≤ A) :
    ∀ᶠ L : ℝ in atTop, ∀ G M : ℝ, ∀ T : ℕ,
      M ≤ C*((momentLength L:ℝ)+1) →
      L^(76/100 : ℝ)/2 ≤ (T:ℝ) →
      G*(L^(1/10 : ℝ))^T ≤ Real.exp (L^(1/10 : ℝ)*M) →
      Real.exp (B*L^(73/100 : ℝ))*G ≤ L^(-A*(momentLength L:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<3/100)).eventually
      (eventually_ge_atTop (40*B)),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<16/100)).eventually
      (eventually_ge_atTop (160*C+1600*A))] with L hL hlog hB' hCA
  intro G M T hM hT hG
  have hL0 : 0 < L := by linarith
  have ht : 0 < L^(1/10 : ℝ) := Real.rpow_pos_of_pos hL0 _
  have hN := IntegerRootReplacement.momentLength_add_one_le L hL
  have hm : L^(1/10 : ℝ)*M ≤ 4*C*L^(6/10 : ℝ) := by
    calc
      _ ≤ L^(1/10 : ℝ)*(C*(4*L^(1/2 : ℝ))) := by gcongr; exact hM.trans (by gcongr)
      _ = _ := by rw [show (6/10 : ℝ)=1/10+1/2 by norm_num, Real.rpow_add hL0]; ring
  have hl := Real.log_le_rpow_div hL0.le (by norm_num : (0:ℝ)<1/10)
  have han : A*(momentLength L:ℝ)*Real.log L ≤ 40*A*L^(6/10 : ℝ) := by
    have hn : (momentLength L:ℝ) ≤ 4*L^(1/2 : ℝ) := by linarith
    calc
      _ ≤ A*(4*L^(1/2 : ℝ))*(L^(1/10 : ℝ)/(1/10)) := by gcongr
      _ = _ := by rw [show (6/10 : ℝ)=1/2+1/10 by norm_num, Real.rpow_add hL0]; ring
  have hcost : B*L^(73/100 : ℝ) + (4*C+40*A)*L^(6/10 : ℝ) ≤ L^(76/100 : ℝ)/20 := by
    have hb := mul_le_mul_of_nonneg_right hB' (show 0 ≤ L^(73/100 : ℝ) by positivity)
    have hc := mul_le_mul_of_nonneg_right hCA (show 0 ≤ L^(6/10 : ℝ) by positivity)
    rw [← Real.rpow_add hL0] at hb hc
    norm_num at hb hc
    nlinarith
  have hsaving : L^(76/100 : ℝ)/20 ≤ (T:ℝ)*Real.log (L^(1/10 : ℝ)) := by
    rw [Real.log_rpow hL0]
    nlinarith [mul_le_mul_of_nonneg_right hT (show 0 ≤ Real.log L by linarith)]
  have hg := gap_le_exp G M (L^(1/10 : ℝ)) T ht hG
  calc
    _ ≤ Real.exp (B*L^(73/100 : ℝ))*Real.exp (L^(1/10 : ℝ)*M-(T:ℝ)*Real.log (L^(1/10 : ℝ))) :=
      mul_le_mul_of_nonneg_left hg (Real.exp_pos _).le
    _ = Real.exp (B*L^(73/100 : ℝ)+L^(1/10 : ℝ)*M-(T:ℝ)*Real.log (L^(1/10 : ℝ))) := by
      rw [← Real.exp_add]; congr 1; ring
    _ ≤ Real.exp ((-A*(momentLength L:ℝ))*Real.log L) := by
      apply Real.exp_le_exp.mpr
      nlinarith
    _ = _ := by rw [Real.rpow_def_of_pos hL0]; congr 1; ring

end Elliptic.Operator.BonferroniBudget
