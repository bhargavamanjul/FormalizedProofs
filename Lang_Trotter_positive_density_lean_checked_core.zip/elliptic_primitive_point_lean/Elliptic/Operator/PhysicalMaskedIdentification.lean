module

public import Elliptic.Operator.PhysicalMaskedChoices
public import Elliptic.Operator.PhysicalActiveReindex
public import Elliptic.Operator.PhysicalBagMeasure

/-!
# Full literal masked physical adjunction

The ordered target lists are reindexed with the inverse target permutation.
The resulting matrix is exactly the literal indexed action; its measured
reversal therefore applies to the physical operator itself.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskedIdentification
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
local instance maskedIdentificationDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1500000

variable {G Z : Type*} [Fintype G] [Fintype Z]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- Splitting every grouped output into its prime and bag coordinates is
an exact finite bijection, retaining arbitrary coupled output tests. -/
theorem sum_grouped_split {R : Type*} [AddCommMonoid R]
    (F : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → R) :
    (∑ q : ∀ i, P i, ∑ b : Bags (P:=P) (Line:=Line) (B:=B), F (fun i => (q i,b i))) =
      ∑ t, F t := by
  have h := (Equiv.arrowProdEquivProdArrow G P
    (fun i => MemoryBag (AnchoredParticle (P i) (Line i)) B)).symm.sum_comp F
  change (∑ x : (∀ i, P i) × Bags (P:=P) (Line:=Line) (B:=B),
    F (fun i => (x.1 i,x.2 i))) = ∑ t, F t at h
  simpa only [Fintype.sum_prod_type] using h

/-- Shared-slot elimination, exact target permutation inversion, and bag
reindexing for one fixed source permutation and target position. -/
theorem target_sum {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (z : Z) (π : Permutations (G:=G) (J:=J)) :
    (∑ τ : Permutations (G:=G) (J:=J), ∑ a : PhysicalActiveLists P J,
      ∑ b : Bags (P:=P) (Line:=Line) (B:=B),
        term ν store promote S I ρ anchor geometry s (z,a,b) π τ *
          (if Total (z,a,b) then F (z,a,b) else 0)) =
    ∑ τ : Permutations (G:=G) (J:=J), ∑ t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B),
      groupedMaskedBagKernel ν store promote S I (anchor (position s)) (anchor z)
        (fun i => bagSurvival (anchor (position s) i) ρ)
        (fun i => bagSurvival (anchor z i) ρ) (unshared s π) t *
      PhysicalMaskedChoices.compressedTest geometry F (position s) z (active s) π τ t := by
  unfold term
  simp only [Shared,active,position]
  have hif (τ : Permutations (G:=G) (J:=J)) (a : PhysicalActiveLists P J) :
      (∑ b : Bags (P:=P) (Line:=Line) (B:=B),
        (if ∀ i (j : Fin J), s.2.1 i (π i j.castSucc) = a i (τ i j.castSucc) then
          geometry s.1 (fun i j => s.2.1 i (π i j)) z (fun i j => a i (τ i j)) *
          groupedMaskedBagKernel ν store promote S I (anchor s.1) (anchor z)
            (fun i => bagSurvival (anchor s.1 i) ρ) (fun i => bagSurvival (anchor z i) ρ)
            (unshared s π) (unshared (z,a,b) τ) else 0) *
          (if Total (z,a,b) then F (z,a,b) else 0)) =
      if ∀ i (j : Fin J), s.2.1 i (π i j.castSucc) = a i (τ i j.castSucc) then
        ∑ b : Bags (P:=P) (Line:=Line) (B:=B),
          geometry s.1 (fun i j => s.2.1 i (π i j)) z (fun i j => a i (τ i j)) *
          groupedMaskedBagKernel ν store promote S I (anchor s.1) (anchor z)
            (fun i => bagSurvival (anchor s.1 i) ρ) (fun i => bagSurvival (anchor z i) ρ)
            (unshared s π) (unshared (z,a,b) τ) *
          (if Total (z,a,b) then F (z,a,b) else 0)
      else 0 := by
    split_ifs <;> simp_all
  simp_rw [hif]
  rw [PhysicalActiveReindex.sum_permutations_shared]
  apply Finset.sum_congr rfl
  intro τ _
  rw [← sum_grouped_split]
  apply Finset.sum_congr rfl
  intro q _
  apply Finset.sum_congr rfl
  intro b _
  unfold PhysicalMaskedKernel.unshared
  simp only [PhysicalMaskedChoices.compressedTest,active,bags,Total,
    Equiv.apply_symm_apply,PhysicalEdgeAdjoint.targetLists,Fin.lastCases_last]
  ac_rfl

/-- The complete bag kernel is the literal ordered physical masked action. -/
theorem physicalApply_eq_kernel {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    PhysicalMaskedChoices.physicalApply ν store promote S I ρ anchor geometry F s =
      ∑ t, kernel ν store promote S I ρ anchor geometry (ofOrdered s) t * F t := by
  rw [PhysicalMaskedChoices.physicalApply_eq_grouped ν hν]
  have hc := total_ofOrdered s
  have he (t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
      kernel ν store promote S I ρ anchor geometry (ofOrdered s) t * F t =
      (Fintype.card (Permutations (G:=G) (J:=J)) : R)⁻¹ ^ 2 *
        ∑ π : Permutations (G:=G) (J:=J), ∑ τ : Permutations (G:=G) (J:=J),
          term ν store promote S I ρ anchor geometry (ofOrdered s) t π τ *
            (if Total t then F t else 0) := by
    by_cases ht : Total t
    · simp only [kernel,ite_eq_left (And.intro hc ht),ite_eq_left ht,
        Finset.sum_mul,mul_assoc]
    · simp [kernel,hc,ht]
  simp_rw [he]
  rw [← Finset.mul_sum]
  apply congrArg (_ * ·)
  simp only [Fintype.sum_prod_type]
  symm
  calc
    _ = ∑ z : Z, ∑ π : Permutations (G:=G) (J:=J),
        ∑ τ : Permutations (G:=G) (J:=J), ∑ a : PhysicalActiveLists P J,
        ∑ b : Bags (P:=P) (Line:=Line) (B:=B),
          term ν store promote S I ρ anchor geometry (ofOrdered s) (z,a,b) π τ *
            (if Total (z,a,b) then F (z,a,b) else 0) := by
      apply Finset.sum_congr rfl
      intro z _
      conv_lhs =>
        arg 2
        ext a
        rw [Finset.sum_comm]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro π _
      conv_lhs =>
        arg 2
        ext a
        rw [Finset.sum_comm]
      rw [Finset.sum_comm]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro z _
      apply Finset.sum_congr rfl
      intro π _
      exact target_sum ν store promote S I ρ anchor geometry F (ofOrdered s) z π

/-- The kernel has zero rows outside the actual total-memory cutoff. -/
theorem kernel_row_zero {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) (hs : ¬ Total s) :
    (∑ t, kernel ν store promote S I ρ anchor geometry s t * F t) = 0 := by
  simp [kernel,hs]

/-- Exact pushforward of the literal physical pairing to its bag matrix. -/
theorem physical_pairing_eq_kernel {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F H : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      PhysicalBagMeasure.orderedMass ν s * H (ofOrdered s) *
        PhysicalMaskedChoices.physicalApply ν store promote S I ρ anchor geometry F s) =
    ∑ s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
      mass ν s * H s * ∑ t, kernel ν store promote S I ρ anchor geometry s t * F t := by
  simp_rw [physicalApply_eq_kernel ν hν]
  simp only [mul_assoc]
  rw [PhysicalBagMeasure.integral_eq_bag ν
    (fun s => H s * ∑ t, kernel ν store promote S I ρ anchor geometry s t * F t)]
  apply Finset.sum_congr rfl
  intro s _
  by_cases hs : Total s
  · rw [ite_eq_left hs]
  · rw [ite_eq_right hs,kernel_row_zero ν store promote S I ρ anchor geometry F s hs]
    simp

/-- Full measured reversal of the literal physical masked action. This
uses the original factorial memory measure, every endpoint permutation,
arbitrary coupled tests and geometry, and the exact total cutoff.
Both masks and the independent store/promotion coefficients are exchanged. -/
theorem physicalApply_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F H : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      PhysicalBagMeasure.orderedMass ν s * H (ofOrdered s) *
        PhysicalMaskedChoices.physicalApply ν store promote S I ρ anchor geometry F s) =
    ∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      PhysicalBagMeasure.orderedMass ν s * F (ofOrdered s) *
        PhysicalMaskedChoices.physicalApply ν promote store I S ρ anchor
          (fun z a w b => geometry w b z a) H s := by
  rw [physical_pairing_eq_kernel ν hν,physical_pairing_eq_kernel ν hν]
  exact kernel_adjoint ν hν store promote S I ρ anchor geometry F H

/-- The original masked physical suboperator has this measured reverse:
store 1/V, promotion 1, with the masks exchanged. These coefficients are
derived rather than silently identified with the original normalization. -/
theorem originalMaskedApply_adjoint
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0) (V : G → ℝ)
    (S I : G → Bool) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F H : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℂ) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) * H (ofOrdered s) *
        PhysicalMaskedChoices.originalMaskedApply ν V S I ρ anchor geometry F s) =
    ∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) * F (ofOrdered s) *
        PhysicalMaskedChoices.physicalApply (fun i p => (ν i p:ℂ))
          (fun i => (V i:ℂ)⁻¹) (fun _ => 1) I S (ρ:ℂ) anchor
          (fun z a w b => geometry w b z a) H s := by
  have hn : ∀ i p, (ν i p:ℂ) ≠ 0 := by
    intro i p
    exact_mod_cast hν i p
  have h := physicalApply_adjoint (fun i p => (ν i p:ℂ)) hn
    (fun _ => 1) (fun i => (V i:ℂ)⁻¹) S I (ρ:ℂ) anchor geometry F H
  simpa only [PhysicalBagMeasure.orderedMass_complex,
    PhysicalMaskedChoices.physicalApply_original] using h

end Elliptic.Operator.PhysicalMaskedIdentification
