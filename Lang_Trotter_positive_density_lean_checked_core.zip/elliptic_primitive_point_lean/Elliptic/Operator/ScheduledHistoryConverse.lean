module

public import Elliptic.Operator.ScheduledHistoryCoefficient

/-!
# The exact history fiber of a prescribed raw schedule

Compatibility is tested on the literal choices: deleted prime-label images,
fresh bags, both endpoint permutations, target position, store flags, target
prime labels, and promotion/fresh status.  These tests do not mention the
constructed history map.  They characterize its finite birth-order fiber.

This is a converse for a fixed `ScheduledPhysicalPath`. Constructing such
a path from the original restricted operator expansion remains separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance scheduledConverseDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace ScheduledPhysicalPath
variable (d : ScheduledPhysicalPath anchor N J B)

/-- Observable ghost conditions, with no choice of fresh tuple ordering. -/
def GhostObserved (j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (c : PhysicalGhostChoice s) : Prop :=
  (∀ i, (c i).1.image (fun a => ((s.memory P Line J B i).values a).1) =
    deaths (d.primes i) (d.lifespan i) j) ∧
  (∀ i, tupleBag (c i).2.values = (births (d.primes i) (d.lifespan i) j).val)

/-- Observable edge conditions include the literal endpoint permutations.
Promotion status is read from the actual old-index/fresh-prime choice. -/
def EdgeObserved (j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (c : PhysicalEdgeChoice s) : Prop :=
  c.target = d.position (j+1) ∧ c.sourcePerm = d.sourcePerm j ∧
  c.targetPerm = d.targetPerm j ∧
  ∀ i, (c.group i).1 = d.store j i ∧
    edgeTargetPrime (s.memory P Line J B i) (c.group i) = d.targetPrime j i ∧
    (match (c.group i).2 with | .inl _ => true | .inr _ => false) = d.promote j i

omit [Fintype Z] in
theorem ghost_observed (j : ℕ) (hj : j ≤ N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (x : d.BirthOrders j) : d.GhostObserved j s (d.ghost j hj s x) := by
  constructor
  · intro i
    exact ghostDeletionIndices_image (before (d.primes i) (d.lifespan i) j)
      (deaths (d.primes i) (d.lifespan i) j) (d.retained i)
      (s.memory P Line J B i) (hs.2.2 i)
      (deaths_subset_before (d.primes i) (d.lifespan i) j)
  · intro i
    change tupleBag (x i).val = _
    simpa using distinctBirthTuple_bag _ id (x i)

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem ghost_existsUnique_of_observed (j : ℕ) (hj : j ≤ N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (c : PhysicalGhostChoice s) (hc : d.GhostObserved j s c) :
    ∃! x : d.BirthOrders j, d.ghost j hj s x = c :=
  groupedGhostChoice_existsUnique_of_fibers d.primes d.lifespan j d.retained s
    hs.2.2 (d.after_cutoff j hj) c hc.1 hc.2

theorem edgeData_observed (j : ℕ) (hj : j < N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.After j s) :
    d.EdgeObserved j s (d.edgeData j hj s hs).choice := by
  refine ⟨rfl,rfl,rfl,?_⟩
  intro i
  refine ⟨rfl,?_,?_⟩
  · exact scheduledEdgeChoice_target _ _ _ _ _ _ _ _
  · change (match (scheduledEdgeChoice (after (d.primes i) (d.lifespan i) j)
      (d.retained i) (s.memory P Line J B i) (hs.2.2 i) (d.store j i)
      (d.promote j i) (d.targetPrime j i) (d.promoted_mem j hj i)).2 with
      | .inl _ => true | .inr _ => false) = _
    unfold scheduledEdgeChoice
    split_ifs with h <;> simp_all

theorem edge_eq_of_observed (j : ℕ) (hj : j < N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.After j s)
    (c : PhysicalEdgeChoice s) (hc : d.EdgeObserved j s c) :
    c = (d.edgeData j hj s hs).choice := by
  apply Prod.ext hc.1
  apply Prod.ext hc.2.1
  apply Prod.ext _ hc.2.2.1
  funext i
  exact scheduledEdgeChoice_unique _ _ _ (hs.2.2 i) _ _ _
    (d.promoted_mem j hj i) (c.group i) (hc.2.2.2 i).1
    (hc.2.2.2 i).2.1 (by
      cases h : (c.group i).2 with
      | inl a => simpa only [h] using (hc.2.2.2 i).2.2
      | inr p => simpa only [h] using (hc.2.2.2 i).2.2)

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Recursive tests on the actual choices of an arbitrary dependent
history. Intermediate memories are the literal preceding outputs. -/
def Compatible : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s → Prop
  | 0,j,s,h => d.GhostObserved j s h.1.val
  | n+1,j,s,h => d.GhostObserved j s h.1.val ∧
      d.EdgeObserved j _ h.2.1.val ∧ Compatible n (j+1) _ h.2.2

/-- Birth-order changes outside the realized interval do not change its
literal history, including its ordered intermediate memories. -/
theorem realization_congr_orders (x y : ∀ j, d.BirthOrders j)
    (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (hxy : ∀ k, j ≤ k → k ≤ j+n → x k = y k) :
    (d.realization ν V η q ρ geometry x n j hend s hs).val =
      (d.realization ν V η q ρ geometry y n j hend s hs).val := by
  induction n generalizing j s with
  | zero =>
      have hx := hxy j le_rfl (by omega)
      simp only [realization]
      apply Sigma.ext (Subtype.ext (congrArg (d.ghost j (by omega) s) hx))
      exact HEq.rfl
  | succ n ih =>
      have hj : j < N := by omega
      let step (z : d.BirthOrders j) (w : ∀ j, d.BirthOrders j) :
          ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j (n+1)) s :=
        let t := d.ghostOutput j hj.le s hs z
        let ht := d.ghostOutput_after j hj.le s hs z
        let u := d.edgeOutput j hj t ht
        let hu := d.edgeOutput_before j hj t ht
        ⟨⟨d.ghost j hj.le s z,d.ghost_valid j hj.le s hs z⟩,
          ⟨(d.edgeData j hj t ht).choice,d.edgeData_valid j hj t ht⟩,
          (d.realization ν V η q ρ geometry w n (j+1) (by omega) u hu).val⟩
      change step (x j) x = step (y j) y
      calc
        _ = step (y j) x := congrArg (fun z => step z x) (hxy j le_rfl (by omega))
        _ = _ := by
          dsimp only [step]
          refine Sigma.ext (by rfl) ?_
          apply heq_of_eq
          refine Sigma.ext (by rfl) ?_
          apply heq_of_eq
          exact ih (j+1) (by omega) _ _ (fun k hk hkn => hxy k (by omega) (by omega))

/-- Every constructed chronological history passes the raw observable tests. -/
theorem realization_compatible (x : ∀ j, d.BirthOrders j)
    (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s) :
    d.Compatible ν V η q ρ geometry n j s
      (d.realization ν V η q ρ geometry x n j hend s hs).val := by
  induction n generalizing j s with
  | zero => exact d.ghost_observed j (by omega) s hs (x j)
  | succ n ih =>
      refine ⟨d.ghost_observed j (by omega) s hs (x j),?_,?_⟩
      · exact d.edgeData_observed j (by omega) _ _
      · exact ih (j+1) (by omega) _ _

/-- Every actual history passing the observable tests is realized by some
family of ordered ghost births. No equality with a constructed history is
among the compatibility hypotheses. -/
theorem exists_realization_of_compatible (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) :
    ∃ x : ∀ j, d.BirthOrders j,
      (d.realization ν V η q ρ geometry x n j hend s hs).val = h := by
  induction n generalizing j s with
  | zero =>
      rcases h with ⟨c,t⟩
      obtain ⟨z,hz,_⟩ := d.ghost_existsUnique_of_observed j (by omega) s hs c.val hc
      let w : ∀ j, d.BirthOrders j := fun k i =>
        (distinctBirthTupleEquiv (births (d.primes i) (d.lifespan i) k)).symm
          (births (d.primes i) (d.lifespan i) k).equivFin.symm
      let x := Function.update w j z
      have hx : x j = z := Function.update_self j z w
      refine ⟨x,?_⟩
      simp only [realization]
      refine Sigma.ext (Subtype.ext ?_) ?_
      · exact (congrArg (d.ghost j (by omega) s) hx).trans hz
      · cases t
        rfl
  | succ n ih =>
      have hj : j < N := by omega
      rcases h with ⟨c,e,t⟩
      obtain ⟨z,hz,_⟩ := d.ghost_existsUnique_of_observed j hj.le s hs c.val hc.1
      have hg : c = ⟨d.ghost j hj.le s z,d.ghost_valid j hj.le s hs z⟩ :=
        Subtype.ext hz.symm
      subst c
      let a := d.ghostOutput j hj.le s hs z
      have ha : d.After j a := d.ghostOutput_after j hj.le s hs z
      have he : e = ⟨(d.edgeData j hj a ha).choice,d.edgeData_valid j hj a ha⟩ :=
        Subtype.ext (d.edge_eq_of_observed j hj a ha e.val hc.2.1)
      subst e
      let b := d.edgeOutput j hj a ha
      have hb : d.Before (j+1) b := d.edgeOutput_before j hj a ha
      obtain ⟨w,hw⟩ := ih (j+1) (by omega) b hb t hc.2.2
      let x := Function.update w j z
      have hx : x j = z := Function.update_self j z w
      have htail : (d.realization ν V η q ρ geometry x n (j+1) (by omega) b hb).val = t := by
        rw [d.realization_congr_orders ν V η q ρ geometry x w n (j+1) (by omega) b hb]
        · exact hw
        · intro k hk hkn
          exact Function.update_of_ne (by omega) z w
      refine ⟨x,?_⟩
      let step (z' : d.BirthOrders j) :
          ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j (n+1)) s :=
        let a' := d.ghostOutput j hj.le s hs z'
        let ha' := d.ghostOutput_after j hj.le s hs z'
        let b' := d.edgeOutput j hj a' ha'
        let hb' := d.edgeOutput_before j hj a' ha'
        ⟨⟨d.ghost j hj.le s z',d.ghost_valid j hj.le s hs z'⟩,
          ⟨(d.edgeData j hj a' ha').choice,d.edgeData_valid j hj a' ha'⟩,
          (d.realization ν V η q ρ geometry x n (j+1) (by omega) b' hb').val⟩
      change step (x j) = _
      rw [hx]
      dsimp only [step]
      refine Sigma.ext (by rfl) ?_
      apply heq_of_eq
      refine Sigma.ext (by rfl) ?_
      exact heq_of_eq htail

/-- The full finite realization satisfies all local observable tests. -/
theorem finiteHistory_compatible (x : d.BirthFamily) :
    d.Compatible ν V η q ρ geometry N 0 d.initialState
      (d.finiteHistory ν V η q ρ geometry x) :=
  d.realization_compatible ν V η q ρ geometry (d.extendBirthFamily x) N 0
    (by omega) d.initialState d.initialState_before

/-- The finite birth-order family is exactly, and uniquely, the fiber of
all actual histories satisfying the raw local tests for this schedule. -/
theorem finiteHistory_existsUnique_of_compatible
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState)
    (hc : d.Compatible ν V η q ρ geometry N 0 d.initialState h) :
    ∃! x : d.BirthFamily, d.finiteHistory ν V η q ρ geometry x = h := by
  obtain ⟨w,hw⟩ := d.exists_realization_of_compatible ν V η q ρ geometry N 0
    (by omega) d.initialState d.initialState_before h hc
  let x : d.BirthFamily := fun j => w j.val
  have hx : d.finiteHistory ν V η q ρ geometry x = h := by
    change (d.realization ν V η q ρ geometry (d.extendBirthFamily x) N 0
      (by omega) d.initialState d.initialState_before).val = h
    rw [d.realization_congr_orders ν V η q ρ geometry (d.extendBirthFamily x) w N 0
      (by omega) d.initialState d.initialState_before]
    · exact hw
    · intro k hk hkN
      have hk' : k ≤ N := by omega
      simp [extendBirthFamily,hk',x]
  exact ⟨x,hx,fun y hy => d.finiteHistory_injective ν V η q ρ geometry (hy.trans hx.symm)⟩

/-- Actual histories selected by raw local data, rather than by membership
in the image of the constructed map. -/
abbrev CompatibleHistory :=
  {h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      d.initialState // d.Compatible ν V η q ρ geometry N 0 d.initialState h}

/-- Genuine equivalence with the independently specified observable fiber. -/
def historyFiberEquiv : d.BirthFamily ≃ d.CompatibleHistory ν V η q ρ geometry :=
  Equiv.ofBijective (fun x => ⟨d.finiteHistory ν V η q ρ geometry x,
    d.finiteHistory_compatible ν V η q ρ geometry x⟩) ⟨by
      intro x y h
      exact d.finiteHistory_injective ν V η q ρ geometry
        (congrArg (fun z : d.CompatibleHistory ν V η q ρ geometry => z.val) h), by
      intro h
      obtain ⟨x,hx,_⟩ := d.finiteHistory_existsUnique_of_compatible ν V η q ρ geometry
        h.val h.property
      exact ⟨x,Subtype.ext hx⟩⟩

/-- Exact fiber size, including every visit and prime group. -/
theorem compatibleHistory_card :
    Fintype.card (d.CompatibleHistory ν V η q ρ geometry) =
      ∏ j : Fin (N+1), ∏ i, (births (d.primes i) (d.lifespan i) j.val).card.factorial := by
  rw [← Fintype.card_congr (d.historyFiberEquiv ν V η q ρ geometry)]
  exact d.birthFamily_card

/-- Every compatible history has the previously derived exact signed
coefficient, independently of the orders of all fresh batches. -/
theorem compatibleHistory_weight (h : d.CompatibleHistory ν V η q ρ geometry) :
    h.val.weight = d.coefficientProduct ν V η q ρ geometry N 0 := by
  obtain ⟨x,hx,_⟩ := d.finiteHistory_existsUnique_of_compatible ν V η q ρ geometry
    h.val h.property
  rw [← hx]
  exact d.finiteHistory_weight ν V η q ρ geometry x

/-- The terminal memory vanishes for every observable-compatible actual
history. No terminal emptiness assumption occurs in the fiber definition. -/
theorem compatibleHistory_memory_empty (h : d.CompatibleHistory ν V η q ρ geometry) :
    physicalMemorySize h.val.final = 0 := by
  obtain ⟨x,hx,_⟩ := d.finiteHistory_existsUnique_of_compatible ν V η q ρ geometry
    h.val h.property
  rw [← hx]
  exact d.finiteHistory_memory_empty ν V η q ρ geometry x

/-- Reindexing permits an arbitrary history-dependent summand, including
coupled coefficients or continuations; no independence hypothesis occurs. -/
theorem sum_compatibleHistory_eq_birthFamily {R : Type*} [AddCommMonoid R]
    (W : d.CompatibleHistory ν V η q ρ geometry → R) :
    (∑ h, W h) = ∑ x : d.BirthFamily, W (d.historyFiberEquiv ν V η q ρ geometry x) :=
  (Equiv.sum_comp (d.historyFiberEquiv ν V η q ρ geometry) W).symm

/-- Exact signed coefficient sum over all histories in the observable
fiber, with every ghost birth factorial canceled. -/
theorem compatibleHistory_weight_sum :
    (∑ h : d.CompatibleHistory ν V η q ρ geometry, h.val.weight) =
      d.summedCoefficientProduct ν V η q ρ geometry N 0 := by
  rw [d.sum_compatibleHistory_eq_birthFamily ν V η q ρ geometry]
  exact d.finiteHistory_weight_sum_eq_summedCoefficient ν V η q ρ geometry

/-- The actual initial measure times the sum over the complete observable
history fiber is exactly the primewise coefficient. Endpoint permutation
normalizations and geometric factors are retained. The numerical source
cross-edge ban supplies the required nonrecurrence of fresh active targets. -/
theorem compatibleHistory_complete_coefficient_of_crossEdgeBan
    (value : ∀ i, P i → ℕ) (μ : ∀ i, P i → ℝ) (hρ : ρ ≠ 0)
    (hV : ∀ i, V i ≠ 0) (hν : ∀ i p, p ∈ d.primes i → V i*ν i p=μ i p)
    (hban : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j)) :
    (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ) *
      (∑ h : d.CompatibleHistory ν V η q ρ geometry, h.val.weight) =
    (∏ j ∈ Finset.range N, d.geometricFactor geometry j) *
      ∏ i, ((∏ p ∈ d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
        (∏ j ∈ Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t => d.retained i p = anchor (d.position t) i p) j) : ℝ) : ℂ) := by
  rw [d.sum_compatibleHistory_eq_birthFamily ν V η q ρ geometry]
  exact d.finiteHistory_complete_coefficient_of_crossEdgeBan ν V η q ρ geometry
    value μ hρ hV hν hban

end ScheduledPhysicalPath
end Elliptic.Operator
