module

public import Elliptic.Operator.ExponentialSeparation
public import Mathlib.NumberTheory.Harmonic.Bounds

/-!
# The harmonic bound for a separated block of circle phases

A literal injection into signed distance bins proves the elementary
reciprocal-distance estimate used in PD (4.32). All finite sums retain
their actual phases; no counting or operator bound is assumed.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open Elliptic.SourceContracts
attribute [local instance] Classical.propDecidable

/-- The centered real lift, whose absolute value is the circle norm. -/
def centeredPhase (x : ℝ) : ℝ := x - round x

theorem centeredPhase_abs (x : ℝ) : |centeredPhase x| = ‖(x : AddCircle (1 : ℝ))‖ := by
  simp [centeredPhase, AddCircle.norm_eq]

theorem centeredPhase_abs_le (x : ℝ) : |centeredPhase x| ≤ 1/2 := abs_sub_round x

theorem centeredPhase_coe (x : ℝ) :
    ((centeredPhase x : ℝ) : AddCircle (1 : ℝ)) = (x : AddCircle (1 : ℝ)) := by
  unfold centeredPhase
  rw [AddCircle.coe_sub]
  have hi : (((round x : ℤ) : ℝ) : AddCircle (1 : ℝ)) = 0 := by
    rw [show ((round x : ℤ) : ℝ) = (round x) • (1 : ℝ) by simp,
      AddCircle.coe_zsmul, AddCircle.coe_period, smul_zero]
  rw [hi, sub_zero]

/-- The sign is needed: distances alone can identify two opposite arcs. -/
def signedDistanceBin (d : ℕ) (x : ℝ) : Bool × ℕ :=
  (decide (0 ≤ centeredPhase x), ⌊2*(d : ℝ)*|centeredPhase x|⌋₊)

theorem signedDistanceBin_mem (d : ℕ) (x : ℝ) :
    signedDistanceBin d x ∈ (Finset.univ : Finset Bool) ×ˢ Finset.range (d+1) := by
  apply Finset.mem_product.mpr
  refine ⟨Finset.mem_univ _, ?_⟩
  apply Finset.mem_range.mpr
  have h := centeredPhase_abs_le x
  have hnon : 0 ≤ 2*(d : ℝ)*|centeredPhase x| := by positivity
  apply (Nat.floor_lt hnon).mpr
  push_cast
  nlinarith

/-- Equal signed bins have distance strictly smaller than one bin width. -/
theorem signedDistanceBin_eq_distance_lt (d : ℕ) (hd : 0 < d) (x y : ℝ)
    (hbin : signedDistanceBin d x = signedDistanceBin d y) :
    |centeredPhase x - centeredPhase y| < 1/(2*(d : ℝ)) := by
  have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
  have hfloor : ⌊2*(d : ℝ)*|centeredPhase x|⌋₊ =
      ⌊2*(d : ℝ)*|centeredPhase y|⌋₊ := congrArg Prod.snd hbin
  have hsign : (0 ≤ centeredPhase x) ↔ 0 ≤ centeredPhase y := by
    have h := congrArg Prod.fst hbin
    simpa only [signedDistanceBin, decide_eq_decide] using h
  have hxl := Nat.floor_le (by positivity : 0 ≤ 2*(d : ℝ)*|centeredPhase x|)
  have hxu := Nat.lt_floor_add_one (2*(d : ℝ)*|centeredPhase x|)
  have hyl := Nat.floor_le (by positivity : 0 ≤ 2*(d : ℝ)*|centeredPhase y|)
  have hyu := Nat.lt_floor_add_one (2*(d : ℝ)*|centeredPhase y|)
  rw [hfloor] at hxl hxu
  have hcancel : (2*(d : ℝ))*(1/(2*(d : ℝ))) = 1 := by field_simp
  apply abs_lt.mpr
  by_cases hx : 0 ≤ centeredPhase x
  · have hy := hsign.mp hx
    simp only [abs_of_nonneg hx, abs_of_nonneg hy] at hxl hxu hyl hyu
    constructor <;> nlinarith
  · have hy : centeredPhase y < 0 := lt_of_not_ge fun hy => hx (hsign.mpr hy)
    simp only [abs_of_neg (lt_of_not_ge hx), abs_of_neg hy] at hxl hxu hyl hyu
    constructor <;> nlinarith

/-- Separation on the quotient circle makes the literal bin map injective. -/
theorem signedDistanceBin_injOn {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (d : ℕ) (hd : 0 < d)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j →
      1/(2*(d : ℝ)) ≤ ‖((x i - x j : ℝ) : AddCircle (1 : ℝ))‖) :
    Set.InjOn (fun i => signedDistanceBin d (x i)) s := by
  intro i hi j hj heq
  by_contra hij
  have hsmall := signedDistanceBin_eq_distance_lt d hd (x i) (x j) heq
  have hnorm : ‖((x i-x j : ℝ) : AddCircle (1 : ℝ))‖ ≤
      |centeredPhase (x i)-centeredPhase (x j)| := by
    rw [show ((x i-x j : ℝ) : AddCircle (1 : ℝ)) =
        ((centeredPhase (x i)-centeredPhase (x j) : ℝ) : AddCircle (1 : ℝ)) by
      rw [AddCircle.coe_sub, AddCircle.coe_sub, centeredPhase_coe, centeredPhase_coe]]
    exact QuotientAddGroup.norm_mk_le_norm
  exact (not_lt_of_ge (hsep i hi j hj hij)) (hnorm.trans_lt hsmall)

/-- The zero bin retains the full geometric-sum length. -/
def distanceBinWeight (B d n : ℕ) : ℝ := if n = 0 then B else (d : ℝ)/n

theorem distanceBinWeight_nonneg (B d n : ℕ) : 0 ≤ distanceBinWeight B d n := by
  unfold distanceBinWeight
  split_ifs <;> positivity

theorem circleGeometricBound_le_binWeight (B d : ℕ) (hd : 0 < d) (x : ℝ) :
    circleGeometricBound B x ≤ distanceBinWeight B d (signedDistanceBin d x).2 := by
  let n := (signedDistanceBin d x).2
  have hn : (n : ℝ) ≤ 2*(d : ℝ)*‖(x : AddCircle (1 : ℝ))‖ := by
    rw [← centeredPhase_abs]
    exact Nat.floor_le (by positivity)
  by_cases hn0 : n = 0
  · simp only [distanceBinWeight, show (signedDistanceBin d x).2 = 0 from hn0, ite_true]
    unfold circleGeometricBound
    split_ifs
    · exact le_rfl
    · exact min_le_left _ _
  · have hnR : 0 < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn0
    have hnorm : 0 < ‖(x : AddCircle (1 : ℝ))‖ := by
      have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
      nlinarith
    simp only [distanceBinWeight, show (signedDistanceBin d x).2 ≠ 0 from hn0, ite_false,
      circleGeometricBound, ne_of_gt hnorm]
    apply (min_le_right _ _).trans
    apply (div_le_div_iff₀ (by positivity : 0 < 2*‖(x : AddCircle (1 : ℝ))‖) hnR).mpr
    nlinarith

theorem distanceBinWeight_sum (B d : ℕ) :
    (∑ n ∈ Finset.range (d+1), distanceBinWeight B d n) =
      (B : ℝ) + (d : ℝ)*(harmonic d : ℝ) := by
  rw [Finset.sum_range_succ']
  simp only [distanceBinWeight, Nat.add_eq_zero_iff, Nat.one_ne_zero, and_false, ite_false,
    ite_true]
  rw [harmonic, Rat.cast_sum, Finset.mul_sum]
  simp only [Rat.cast_inv, Rat.cast_natCast, div_eq_mul_inv]
  ring

/-- A block of circle phases separated by 1/(2d) costs at most
2B + 2d H_d. This is an actual finite-sum estimate. -/
theorem separated_circle_geometric_sum_le {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (B d : ℕ) (hd : 0 < d)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j →
      1/(2*(d : ℝ)) ≤ ‖((x i - x j : ℝ) : AddCircle (1 : ℝ))‖) :
    (∑ i ∈ s, circleGeometricBound B (x i)) ≤
      2*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ)) := by
  have hsum : (∑ i ∈ s, circleGeometricBound B (x i)) ≤
      ∑ b ∈ (Finset.univ : Finset Bool) ×ˢ Finset.range (d+1), distanceBinWeight B d b.2 := by
    apply Finset.sum_le_sum_of_injOn (fun i => signedDistanceBin d (x i))
      (signedDistanceBin_injOn s x d hd hsep)
    · intro b hb
      obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
      exact signedDistanceBin_mem d (x i)
    · intro i hi
      exact circleGeometricBound_le_binWeight B d hd (x i)
    · intro b hb hnot
      exact distanceBinWeight_nonneg B d b.2
  calc
    _ ≤ _ := hsum
    _ = _ := by
      simp only [Finset.sum_product, distanceBinWeight_sum, Finset.sum_const,
        Finset.card_univ, Fintype.card_bool, nsmul_eq_mul, Nat.cast_ofNat]

/-- The conventional logarithmic form of the separated block estimate. -/
theorem separated_circle_geometric_sum_le_log {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (B d : ℕ) (hd : 0 < d)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j →
      1/(2*(d : ℝ)) ≤ ‖((x i - x j : ℝ) : AddCircle (1 : ℝ))‖) :
    (∑ i ∈ s, circleGeometricBound B (x i)) ≤
      2*((B : ℝ)+(d : ℝ)*(1+Real.log d)) := by
  apply (separated_circle_geometric_sum_le s x B d hd hsep).trans
  gcongr
  exact harmonic_le_one_add_log d

end Elliptic.Operator
