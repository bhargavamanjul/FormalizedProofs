module
public import Elliptic.Operator.MomentParameters

/-! Numerical absorption for the actual patched spectral endpoint. All
constants are fixed before the logarithmic parameter and the moment. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalEndpointParameters
open Filter
set_option backward.isDefEq.respectTransparency false

theorem eventually_height_exponent_le_moment (D : ℝ) :
    ∀ᶠ L : ℝ in atTop,D*L^(21/100:ℝ)≤(momentLength L:ℝ) := by
  filter_upwards [(tendsto_rpow_atTop (by norm_num : (0:ℝ)<29/100)).eventually
    (eventually_ge_atTop D),eventually_gt_atTop (0:ℝ)] with L hD hL
  calc
    _ ≤ L^(29/100:ℝ)*L^(21/100:ℝ) :=
      mul_le_mul_of_nonneg_right hD (Real.rpow_nonneg hL.le _)
    _ = L^(1/2:ℝ) := by rw [←Real.rpow_add hL]; norm_num
    _ ≤ _ := momentLength_lower L

theorem eventually_const_exp_le_pow_moment (C₀ A₀ D : ℝ)
    (hC : 0≤C₀) (hA : 0≤A₀) :
    ∀ᶠ L : ℝ in atTop,
      C₀^(momentLength L)*A₀*Real.exp (D*L^(21/100:ℝ))≤L^(momentLength L) := by
  filter_upwards [eventually_height_exponent_le_moment D,eventually_gt_atTop (0:ℝ),
    eventually_ge_atTop (max 1 C₀*max 1 A₀*Real.exp 1)] with L hheight hL hscale
  have hN : 1≤momentLength L := momentLength_pos hL
  have hAm : A₀≤(max 1 A₀)^(momentLength L) :=
    (le_max_right _ _).trans (le_self_pow₀ (le_max_left _ _) (by omega))
  have hCm := pow_le_pow_left₀ hC (le_max_right 1 C₀) (momentLength L)
  have he : Real.exp (D*L^(21/100:ℝ))≤(Real.exp 1)^(momentLength L) := by
    rw [←Real.exp_nat_mul,mul_one]
    exact Real.exp_le_exp.mpr hheight
  calc
    _ ≤ (max 1 C₀)^(momentLength L)*(max 1 A₀)^(momentLength L)*
        (Real.exp 1)^(momentLength L) :=
      mul_le_mul (mul_le_mul hCm hAm hA (by positivity)) he (Real.exp_pos _).le (by positivity)
    _ = (max 1 C₀*max 1 A₀*Real.exp 1)^(momentLength L) := by simp only [mul_pow]
    _ ≤ _ := pow_le_pow_left₀ (by positivity) hscale _

theorem eventually_half_moment_ge_two :
    ∀ᶠ L : ℝ in atTop,2≤⌈L^(1/2:ℝ)/2⌉₊ := by
  filter_upwards [(tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/2)).eventually
    (eventually_ge_atTop (4:ℝ))] with L hL
  have h := Nat.le_ceil (L^(1/2:ℝ)/2)
  have hh : (2:ℝ)≤(⌈L^(1/2:ℝ)/2⌉₊:ℝ) := by linarith
  exact_mod_cast hh

end Elliptic.Operator.PhysicalEndpointParameters
