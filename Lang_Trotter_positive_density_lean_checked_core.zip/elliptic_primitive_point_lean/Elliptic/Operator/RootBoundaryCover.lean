module

public import Elliptic.Operator.RootPhysicalCell
public import Elliptic.Operator.RootGridTransfer

/-!
# The complete geometric boundary cover for a finite position family

Both physical coordinates and an explicitly supplied finite set of scalar
circle endpoints are covered. The actual union cardinalities and covering
volumes are bounded, and the source physical predicates are constant on
every remaining cell. The endpoint set can be over-enumerated: its exact
connection with all source good tests is handled by their own finite
arithmetic enumeration.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootBoundaryCover
open RootArchimedeanGrid RootPhysicalCell SourceRootCount
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def coverVolume (n : ℕ) (s : Finset Index) : ℝ := ∑ j∈s, cellVolume n j

theorem coverVolume_eq (n : ℕ) (s : Finset Index) :
    coverVolume n s=(s.card:ℝ)*(15/(n:ℝ)^3) := by
  simp only [coverVolume,cellVolume_eq,Finset.sum_const,nsmul_eq_mul]

theorem coverVolume_nonneg (n : ℕ) (s : Finset Index) : 0≤coverVolume n s := by
  rw [coverVolume_eq]
  positivity

theorem coverVolume_union (n : ℕ) (s t : Finset Index) :
    coverVolume n (s∪t) ≤ coverVolume n s+coverVolume n t := by
  simp only [coverVolume_eq]
  have hc : ((s∪t).card:ℝ)≤(s.card:ℝ)+(t.card:ℝ) := by exact_mod_cast Finset.card_union_le s t
  calc
    _ ≤ ((s.card:ℝ)+(t.card:ℝ))*(15/(n:ℝ)^3) :=
      mul_le_mul_of_nonneg_right hc (by positivity)
    _ = _ := by ring

theorem coverVolume_biUnion {I : Type*} [DecidableEq I] (n : ℕ)
    (s : Finset I) (f : I→Finset Index) :
    coverVolume n (s.biUnion f) ≤ ∑ i∈s, coverVolume n (f i) := by
  simp only [coverVolume_eq,←Finset.sum_mul]
  have hc : ((s.biUnion f).card:ℝ)≤∑ i∈s, ((f i).card:ℝ) := by
    exact_mod_cast (Finset.card_biUnion_le (s:=s) (t:=f))
  exact mul_le_mul_of_nonneg_right hc (by positivity)

def physicalFaces (n : ℕ) (z : ℤ × ℤ) (d : ℝ) : Finset Index :=
  (RootFirstFace.faceCubes n z 1 ∪ RootFirstFace.faceCubes n z 16) ∪
    (RootSecondFace.faceCubes n z d 1 ∪ RootSecondFace.faceCubes n z d 2)

theorem not_mem_physicalFaces (n : ℕ) (z : ℤ × ℤ) (d : ℝ) (j : Index) :
    j∉physicalFaces n z d ↔
      j∉RootFirstFace.faceCubes n z 1 ∧ j∉RootFirstFace.faceCubes n z 16 ∧
        j∉RootSecondFace.faceCubes n z d 1 ∧ j∉RootSecondFace.faceCubes n z d 2 := by
  simp [physicalFaces,and_assoc]

theorem physicalFaces_subset_grid (n : ℕ) (z : ℤ × ℤ) (d : ℝ) :
    physicalFaces n z d ⊆ grid n := by
  apply Finset.union_subset
  · exact Finset.union_subset (RootFirstFace.faceCubes_subset_grid n z 1)
      (RootFirstFace.faceCubes_subset_grid n z 16)
  · exact Finset.union_subset (RootSecondFace.faceCubes_subset_grid n z d 1)
      (RootSecondFace.faceCubes_subset_grid n z d 2)

theorem physicalFaces_volume (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (d : ℝ) :
    coverVolume n (physicalFaces n z d) ≤
      (2464*|(z.2:ℝ)|+14400*|d|+120)/(n:ℝ) := by
  have h := coverVolume_union n
    (RootFirstFace.faceCubes n z 1 ∪ RootFirstFace.faceCubes n z 16)
    (RootSecondFace.faceCubes n z d 1 ∪ RootSecondFace.faceCubes n z d 2)
  have h1 := coverVolume_union n (RootFirstFace.faceCubes n z 1) (RootFirstFace.faceCubes n z 16)
  have h2 := coverVolume_union n (RootSecondFace.faceCubes n z d 1) (RootSecondFace.faceCubes n z d 2)
  have h11 := RootFirstFace.faceCubes_volume n hn z 1 (by norm_num)
  have h16 := RootFirstFace.faceCubes_volume n hn z 16 (by norm_num)
  have h21 := RootSecondFace.faceCubes_volume n hn z d 1
  have h22 := RootSecondFace.faceCubes_volume n hn z d 2
  change coverVolume n _ ≤ _ at h11 h16 h21 h22
  change coverVolume n (physicalFaces n z d) ≤ _ at h
  have he :
      (512*|(z.2:ℝ)|/1+30)/(n:ℝ) + (512*|(z.2:ℝ)|/16+30)/(n:ℝ) +
        ((960*|(z.2:ℝ)|+7200*|d|+30)/(n:ℝ) +
          (960*|(z.2:ℝ)|+7200*|d|+30)/(n:ℝ)) =
        (2464*|(z.2:ℝ)|+14400*|d|+120)/(n:ℝ) := by ring
  linarith

theorem physicalFaces_volume_scales (n : ℕ) (hn : 0<n) (z : ℤ × ℤ)
    (U V : ℝ) (hUV : 1≤U*V) :
    coverVolume n (physicalFaces n z ((z.2:ℝ)/(U*V))) ≤
      (16864*|(z.2:ℝ)|+120)/(n:ℝ) := by
  have hd : |(z.2:ℝ)/(U*V)|≤|(z.2:ℝ)| := by
    rw [abs_div,abs_of_nonneg (by linarith : 0≤U*V)]
    exact div_le_self (abs_nonneg _) hUV
  exact (physicalFaces_volume n hn z _).trans (by gcongr; nlinarith)

def positionFaces (n : ℕ) (positions : Finset (ℤ × ℤ)) (U V : ℝ) : Finset Index :=
  positions.biUnion fun z => physicalFaces n z ((z.2:ℝ)/(U*V))

theorem positionFaces_subset_grid (n : ℕ) (positions : Finset (ℤ × ℤ)) (U V : ℝ) :
    positionFaces n positions U V ⊆ grid n := by
  intro j hj
  obtain ⟨z,hz,hjz⟩ := Finset.mem_biUnion.mp hj
  exact physicalFaces_subset_grid n z _ hjz

theorem positionFaces_volume (n : ℕ) (hn : 0<n) (positions : Finset (ℤ × ℤ))
    (U V R : ℝ) (hUV : 1≤U*V) (hR : ∀ z∈positions, |(z.2:ℝ)|≤R) :
    coverVolume n (positionFaces n positions U V) ≤
      (positions.card:ℝ)*(16864*R+120)/(n:ℝ) := by
  calc
    _ ≤ ∑ z∈positions, coverVolume n (physicalFaces n z ((z.2:ℝ)/(U*V))) :=
      coverVolume_biUnion n positions _
    _ ≤ ∑ _z∈positions, (16864*R+120)/(n:ℝ) := by
      apply Finset.sum_le_sum
      intro z hz
      exact (physicalFaces_volume_scales n hn z U V hUV).trans (by gcongr; exact hR z hz)
    _ = _ := by simp; ring

def combinedFaces (n : ℕ) (positions : Finset (ℤ × ℤ)) (U V : ℝ)
    (endpoints : Finset ℝ) : Finset Index :=
  positionFaces n positions U V ∪ boundaryFamily n endpoints

theorem combinedFaces_subset_grid (n : ℕ) (positions : Finset (ℤ × ℤ)) (U V : ℝ)
    (endpoints : Finset ℝ) : combinedFaces n positions U V endpoints ⊆ grid n :=
  Finset.union_subset (positionFaces_subset_grid n positions U V) (boundaryFamily_subset_grid n endpoints)

theorem combinedFaces_volume (n : ℕ) (hn : 0<n) (positions : Finset (ℤ × ℤ))
    (U V R : ℝ) (endpoints : Finset ℝ) (hUV : 1≤U*V)
    (hR : ∀ z∈positions, |(z.2:ℝ)|≤R) :
    coverVolume n (combinedFaces n positions U V endpoints) ≤
      ((positions.card:ℝ)*(16864*R+120)+30*(endpoints.card:ℝ))/(n:ℝ) := by
  have h := coverVolume_union n (positionFaces n positions U V) (boundaryFamily n endpoints)
  have hp := positionFaces_volume n hn positions U V R hUV hR
  have he := boundaryFamily_volume n hn endpoints
  change coverVolume n _ ≤ _ at he
  change coverVolume n (combinedFaces n positions U V endpoints) ≤ _ at h
  calc
    _ ≤ (positions.card:ℝ)*(16864*R+120)/(n:ℝ)+30*(endpoints.card:ℝ)/(n:ℝ) := by linarith
    _ = _ := by ring

theorem source_allowed_constant_of_outside (n : ℕ) (j : Index) (hj : j∈grid n)
    (positions : Finset (ℤ × ℤ)) (endpoints : Finset ℝ) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n positions U V endpoints)
    (z : ℤ × ℤ) (hz : z∈positions) (p q : RootPoint)
    (hp : Contains n j p) (hq : Contains n j q) :
    sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z ↔
      sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z := by
  have hnot : j∉physicalFaces n z ((z.2:ℝ)/(U*V)) := by
    intro h
    exact hout (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨z,hz,h⟩))
  obtain ⟨h1,h16,h21,h22⟩ := (not_mem_physicalFaces n z _ j).mp hnot
  exact source_allowed_constant n j hj z U V hU hV h1 h16 h21 h22 p q hp hq

end Elliptic.Operator.RootBoundaryCover
