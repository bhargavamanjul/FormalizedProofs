module
public import Elliptic.Operator.MellinEndpointEnergy

/-! Arbitrary logarithmic saving for the literal normalized endpoint cutoff. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest
open MellinPrimeSeparation
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem eventually_mellin_cost_bound (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (Alam Crem E : ℝ) (hAlam : 0≤Alam) :
    ∀ᶠL : ℝ in atTop,∀lam Y B : ℝ,0≤B→B≤L^Crem→|lam|≤L^Alam→
      (∫ξ:ℝ,‖scaledKernel (twistedCutoff η lam) Y ξ‖)^2*B^2*
        L^(-(E+4*Alam+2*Crem+1))≤L^(-E) := by
  obtain ⟨C,hC,hkernel⟩ := MellinGeneralCutoff.twisted_scaledKernel_L1 η hη lo hi hlo hsupp
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop (16*C^2)] with L hL hLC
  intro lam Y B hB hBL hlam
  have hLp : 0<L := by linarith
  have hAlamOne : 1≤L^Alam := Real.one_le_rpow hL hAlam
  have hk : (∫ξ:ℝ,‖scaledKernel (twistedCutoff η lam) Y ξ‖)≤C*(2*L^Alam)^2 := by
    apply (hkernel lam Y).2.trans
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) (by linarith : 1+|lam|≤2*L^Alam) 2) hC.le
  have he : (C*(2*L^Alam)^2)^2*(L^Crem)^2*L^(-(E+4*Alam+2*Crem+1))=
      16*C^2*L^(-E-1) := by
    calc
      _ = 16*C^2*((L^Alam)^4*(L^Crem)^2*L^(-(E+4*Alam+2*Crem+1))) := by ring
      _ = _ := by
        rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_mul_natCast hLp.le,
          ←Real.rpow_add hLp,←Real.rpow_add hLp]
        congr 2
        norm_num
        ring
  calc
    _ ≤ (C*(2*L^Alam)^2)^2*(L^Crem)^2*L^(-(E+4*Alam+2*Crem+1)) := by
      apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hLp.le _)
      exact mul_le_mul (pow_le_pow_left₀ (integral_nonneg (fun ξ=>norm_nonneg _)) hk 2)
        (pow_le_pow_left₀ hB hBL 2) (sq_nonneg _) (sq_nonneg _)
    _ = 16*C^2*L^(-E-1) := he
    _ ≤ L*L^(-E-1) := mul_le_mul_of_nonneg_right hLC (Real.rpow_nonneg hLp.le _)
    _ = _ := by
      conv_lhs => lhs;rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 1
      ring

/-- The source endpoint sum, its two actual long factors, and its remaining
label mass are combined. Only source cancellation remains as an input. -/
 theorem eventually_actual_endpoint_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (δ c Cprime Ccoef J E Alam Crem : ℝ) (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime)
    (hcoef : 0≤Ccoef) (hJ : 0≤J) (hE : 0≤E) (hAlam : 0≤Alam) (hCrem : 0≤Crem) :
    ∃A : ℝ,0<A ∧ ∀ᶠL : ℝ in atTop,∀K : ℕ,1≤K→(K:ℝ)≤Real.exp (3*L)→
      ∀Hm Hn : ℝ,1≤Hm→Real.exp (δ*L)≤Hn→Hm*Hn≤Real.exp (2*L)→
      (K:ℝ)≤Hm*Hn*L^J→
      ∀a P : ℝ,0<P→c*L^(1/10:ℝ)≤Real.log P→Real.log P≤Cprime*L^(1/5:ℝ)→
      ∀S : Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q : ℕ) (χ : DirichletCharacter ℂ q),
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^Ccoef)→(∀n∈t,‖β n‖≤L^Ccoef)→
      ∀(k l : ℕ) (χm : DirichletCharacter ℂ k) (χn : DirichletCharacter ℂ l),
      (∀v∈Icc (a+1) (a+(K:ℝ)+1),‖longPolynomial s α Hm χm v‖≤L^(-A))→
      ∀(R : Finset ℕ) (d : ℕ→ℂ),(∀r∈R,0<r)→∀lam Y : ℝ,0<Y→|lam|≤L^Alam→
      (P/Y)*(∑r∈R,‖d r‖)≤L^Crem→
      (∫v in Icc (a+1) (a+(K:ℝ)+1),
        ‖(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y v*
          longPolynomial s α Hm χm v*longPolynomial t β Hn χn v‖^2)≤L^(-E) := by
  let G := E+4*Alam+2*Crem+1
  have hG : 0≤G := by dsimp [G];linarith
  obtain ⟨A,hA,henergy⟩ := MajorArcActualProductEnergy.eventually_actual_product_energy hvdC hD
    δ c Cprime Ccoef J G hδ hc hC hcoef hJ hG
  refine ⟨A,hA,?_⟩
  filter_upwards [henergy,eventually_mellin_cost_bound η hη lo hi hlo hsupp Alam Crem E hAlam,
    eventually_ge_atTop (1:ℝ)] with L henergy hcost hL
  intro K hK hKmax Hm Hn hm hn hmax hKprod a P hP hplo hphi S hprime hShi q χ s t hs ht α β hα hβ k l χm χn hcancel R d hR lam Y hY hlam hrem
  have hnp : 0<Hn := (Real.exp_pos _).trans_le hn
  have hab : a+1≤a+(K:ℝ)+1 := by have := Nat.cast_nonneg (α:=ℝ) K;linarith
  have hpenergy (ξ:ℝ) : (∫v in Icc (a+1) (a+(K:ℝ)+1),
      ‖PrimeExceptionalCells.primePolynomial S P χ ξ v*longPolynomial s α Hm χm v*
        longPolynomial t β Hn χn v‖^2)≤L^(-G) := by
    rw [integral_Icc_eq_integral_Ioc,←intervalIntegral.integral_of_le hab]
    exact henergy K hK hKmax Hm Hn hm hn hmax hKprod a P hP hplo hphi S hprime hShi q χ ξ
      s t hs ht α β hα hβ k l χm χn hcancel
  have hh := MellinEndpointEnergy.normalized_long_endpoint_energy S R (fun p hp=>(hprime p hp).pos) hR
    χ χm χn d η hη lo hi hlo hsupp s t α β Hm Hn (by linarith) hnp
    lam P Y (a+1) (a+(K:ℝ)+1) (L^(-G)) hP hY hpenergy
  exact hh.trans (hcost lam Y _ (by positivity) hrem hlam)

end Elliptic.Operator.MajorArcEndpointSaving
