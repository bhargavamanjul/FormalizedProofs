module
public import Elliptic.Operator.MajorArcIsolatedEndpointSaving

/-! Complete normalized prime-label endpoint energy. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcFullEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest
open MajorArcLabelMass MajorArcIsolatedEndpointSaving
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
local instance fullDecEq {α:Type*} : DecidableEq α := Classical.typeDecidableEq α
attribute [local instance] Classical.propDecidable

 theorem fullEndpoint_eq_isolated {ι : Type*} [Fintype ι] (G : ι→Finset ℕ) (i₀ : ι)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    fullEndpoint G χ η lam Y t=(((∑p∈G i₀,(p:ℝ)⁻¹)⁻¹:ℝ):ℂ)*
      isolatedEndpoint (G i₀) (fun i:{i:ι // i≠i₀}=>G i) χ η lam Y t := by
  rw [fullEndpoint_split,isolatedEndpoint,←mul_assoc]
  congr 1
  apply Finset.sum_congr rfl
  intro p hp
  apply Finset.sum_congr (by ext; simp)
  intro l hl
  rfl

 theorem uniform_full_endpoint_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η) (hsupp : ∀y,η y≠0→1≤y ∧ y≤4)
    (δ c Cprime Ccoef J E Alam A₀ c₁ c₂ : ℝ)
    (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime) (hcoef : 0≤Ccoef) (hJ : 0≤J)
    (hE : 0≤E) (hAlam : 0≤Alam) (hA₀ : 0<A₀)
    {I : Type} (Hm Hn : ℝ→I→ℝ) (active : ℝ→I→Prop) (α : ℝ→I→ℕ→ℂ)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel : ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα : ∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^Ccoef) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→
      ∀(ι:Type)[fi:Fintype ι](G:ι→Finset ℕ)(i₀:ι),
      (∀i,∀p∈G i,0<p)→(∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)→
      (∀p∈G i₀,p.Prime)→(∑p∈G i₀,(p:ℝ)⁻¹)⁻¹≤Real.log x→
      (∀p∈G i₀,c*(Real.log x)^(1/10:ℝ)≤Real.log p ∧ Real.log p≤Cprime*(Real.log x)^(1/5:ℝ))→
      ∀(q:ℕ)(χ:DirichletCharacter ℂ q),∀s t:Finset ℕ,IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^Ccoef)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀l:ℕ,
      ∀(χm:DirichletCharacter ℂ k)(χn:DirichletCharacter ℂ l),
      ∀lam Y:ℝ,0<Y→|lam|≤(Real.log x)^Alam→∀u:ℝ,|u|≤(Hm x j*Hn x j)*(Real.log x)^J→
      (∫v in Icc (u-(Hm x j*Hn x j)*(Real.log x)^J) (u+(Hm x j*Hn x j)*(Real.log x)^J),
        ‖fullEndpoint G χ η lam Y v*
          longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2)≤(Real.log x)^(-E) := by
  have henergy := uniform_isolated_endpoint_energy hvdC hD η hη hsupp δ c Cprime Ccoef J (E+2)
    Alam A₀ c₁ c₂ hδ hc hC hcoef hJ (by linarith) hAlam hA₀ Hm Hn active α hscale hcancel hα
  filter_upwards [henergy,Real.tendsto_log_atTop.eventually (eventually_gt_atTop (0:ℝ))] with x henergy hL
  intro j hj ι fi G i₀ hG hm hprime hinv hlog q χ s t hs ht β hβ k hk hkmax l χm χn lam Y hY hlam u hu
  have he := henergy j hj (G i₀) hprime hlog {i:ι // i≠i₀} (fun i=>G i)
    (fun i=>hG i) (fun i=>hm i) q χ s t hs ht β hβ k hk hkmax l χm χn lam Y hY hlam u hu
  let Z := (∑p∈G i₀,(p:ℝ)⁻¹)⁻¹
  have hZ : 0≤Z := by dsimp [Z];positivity
  have hn : ‖(Z:ℂ)‖=Z := by rw [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hZ]
  have heq (v:ℝ) : ‖fullEndpoint G χ η lam Y v*longPolynomial s (α x j) (Hm x j) χm v*
      longPolynomial t β (Hn x j) χn v‖^2=
      Z^2*‖isolatedEndpoint (G i₀) (fun i:{i:ι // i≠i₀}=>G i) χ η lam Y v*
        longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2 := by
    rw [fullEndpoint_eq_isolated G i₀ χ η lam Y v]
    simp only [norm_mul,mul_pow,norm_inv,Complex.norm_real,Real.norm_eq_abs]
    have hm0 : 0≤∑p∈G i₀,(p:ℝ)⁻¹ := by positivity
    rw [abs_of_nonneg hm0]
    dsimp [Z]
    ring
  simp_rw [heq]
  rw [integral_const_mul]
  calc
    _ ≤ Z^2*(Real.log x)^(-(E+2)) := mul_le_mul_of_nonneg_left he (sq_nonneg _)
    _ ≤ (Real.log x)^2*(Real.log x)^(-(E+2)) := mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ hZ hinv 2) (Real.rpow_nonneg hL.le _)
    _ = _ := by
      rw [←Real.rpow_natCast (Real.log x) 2,←Real.rpow_add hL]
      congr 1
      norm_num

end Elliptic.Operator.MajorArcFullEndpointSaving
