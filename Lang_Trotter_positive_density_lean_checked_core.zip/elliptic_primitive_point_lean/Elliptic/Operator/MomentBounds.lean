module

public import Elliptic.Operator.MomentParameters

/-!
# Numerical high- and low-rank bounds at the source's growing moment length

The estimates in this file concern the explicit right-hand side of
`MomentSummation`, with the source parameter definitions.  No signed word
estimate is postulated here.  Constants are fixed before the asymptotic
variable; the rank cutoff constant is chosen after the crude exponent.
-/

@[expose] public section
namespace Elliptic.Operator
open Filter
open scoped Topology

theorem rankPenalty_rpow_le {L Q C G : ℝ} {N r : ℕ}
    (hL : 1 ≤ L) (hQ0 : 0 ≤ Q) (hQ : Q ≤ L^4) (hr : 2*r ≤ N) :
    rankPenalty N r (L^(-G)) (L^C) Q ≤
      L^(-G*(N:ℝ)+2*(G+C+4)*(r:ℝ)) := by
  have hL0 : 0 ≤ L := by linarith
  have hLp : 0 < L := by linarith
  have hq : Q * L^C ≤ L^(C+4) := by
    calc
      _ ≤ L^4 * L^C := mul_le_mul_of_nonneg_right hQ (Real.rpow_nonneg hL0 _)
      _ = _ := by rw [Real.rpow_add hLp, Real.rpow_ofNat]; ring
  unfold rankPenalty
  calc
    _ ≤ (L^(-G))^(N-2*r) * (L^(C+4))^(2*r) :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) hq _) (by positivity)
    _ = _ := by
      rw [← Real.rpow_mul_natCast hL0, ← Real.rpow_mul_natCast hL0,
        ← Real.rpow_add hLp]
      congr 1
      push_cast [Nat.cast_sub hr]
      ring

theorem two_mul_rpow_moment_le {L a : ℝ} {N : ℕ} (hL : 2 ≤ L) (hN : 1 ≤ N) :
    2 * L^(-(a+1)*(N:ℝ)) ≤ L^(-a*(N:ℝ)) := by
  have hLp : 0 < L := by linarith
  have hLN : (2:ℝ) ≤ L^(N:ℝ) := by
    rw [Real.rpow_natCast]
    exact hL.trans (by simpa using pow_le_pow_right₀ (by linarith : 1 ≤ L) hN)
  calc
    _ ≤ L^(N:ℝ)*L^(-(a+1)*(N:ℝ)) :=
      mul_le_mul_of_nonneg_right hLN (by positivity)
    _ = _ := by rw [← Real.rpow_add hLp]; congr 1; ring

/-- The chosen cutoff is allowed to depend on the crude exponent `C`,
which is determined only after the accuracy parameters and `K`. -/
noncomputable def sourceRankConstant (C E : ℝ) : ℝ := 4*(C+E+4)

noncomputable def sourceHighRankMajorant (K : ℕ) (C D E L : ℝ) : ℝ :=
  L^(C*((momentLength L : ℝ)+1)) *
    (((birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ)))) ^
        rankCutoff (sourceRankConstant C E) L /
      (1-(birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ)))))

theorem eventually_sourceHighRankMajorant_le (K : ℕ) {C D E : ℝ}
    (hC : 0 ≤ C) (hD : 0 ≤ D) (hE : 0 ≤ E) :
    ∀ᶠ L : ℝ in atTop, sourceHighRankMajorant K C D E L ≤
      L^(-(E+1)*(momentLength L : ℝ)) := by
  filter_upwards [eventually_birth_atom_ratio K hD, eventually_ge_atTop (2:ℝ)] with L hatom hL
  have hL1 : 1 ≤ L := by linarith
  have hLp : 0 < L := by linarith
  have hlog : 0 ≤ Real.log L := Real.log_nonneg hL1
  have hN : 1 ≤ momentLength L := momentLength_pos hLp
  have hNr : (1:ℝ) ≤ momentLength L := by exact_mod_cast hN
  have hpow : 0 < L^(1/10:ℝ) := Real.rpow_pos_of_pos hLp _
  let z := (birthAddressBudget K L : ℝ)^2 * (D*Real.exp (-L^(1/10:ℝ)))
  let r := rankCutoff (sourceRankConstant C E) L
  have hz0 : 0 ≤ z := by dsimp [z]; positivity
  have hzhalf : z ≤ 1/2 := hatom.2
  have hzden : 0 < 1-z := by linarith
  have hzpow : z^r ≤ Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))^r :=
    pow_le_pow_left₀ hz0 hatom.1 _
  have hcut : sourceRankConstant C E * (momentLength L : ℝ) * Real.log L ≤
      (r:ℝ)*L^(1/10:ℝ) := by
    have h := rankCutoff_lower (sourceRankConstant C E) L
    exact (div_le_iff₀ hpow).mp h
  have hexponent : Real.log L * (C*((momentLength L : ℝ)+1)) +
      (r:ℝ)*(-(1/2:ℝ)*L^(1/10:ℝ)) ≤
      Real.log L * (-(E+2)*(momentLength L : ℝ)) := by
    have hNN : (momentLength L : ℝ)+1 ≤ 2*(momentLength L : ℝ) := by linarith
    have hcn := mul_le_mul_of_nonneg_left hNN (mul_nonneg hlog hC)
    have hen : 0 ≤ (E+6)*(momentLength L : ℝ)*Real.log L := by positivity
    dsimp [sourceRankConstant] at hcut
    nlinarith
  have hmain : L^(C*((momentLength L : ℝ)+1)) *
      Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))^r ≤ L^(-(E+2)*(momentLength L : ℝ)) := by
    rw [Real.rpow_def_of_pos hLp (C*((momentLength L : ℝ)+1)),
      ← Real.exp_nat_mul, ← Real.exp_add,
      Real.rpow_def_of_pos hLp (-(E+2)*(momentLength L : ℝ)), Real.exp_le_exp]
    exact hexponent
  have hfrac : z^r/(1-z) ≤ 2*Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))^r := by
    apply (div_le_iff₀ hzden).2
    have hp : 0 ≤ Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))^r := by positivity
    nlinarith
  unfold sourceHighRankMajorant
  change L^(C*((momentLength L : ℝ)+1))*(z^r/(1-z)) ≤ _
  calc
    _ ≤ L^(C*((momentLength L : ℝ)+1)) *
        (2*Real.exp (-(1/2:ℝ)*L^(1/10:ℝ))^r) :=
      mul_le_mul_of_nonneg_left hfrac (by positivity)
    _ ≤ 2*L^(-(E+2)*(momentLength L : ℝ)) := by nlinarith
    _ ≤ _ := by simpa only [add_assoc, one_add_one_eq_two] using
      two_mul_rpow_moment_le (a:=E+1) hL hN

/-- A convenient fixed contraction exponent, chosen before the crude
constant `C` and before the cutoff constant. -/
noncomputable def sourceContractionExponent (E : ℝ) : ℝ := E+5

noncomputable def sourceLowRankMajorant (K : ℕ) (C Cg E L : ℝ) : ℝ :=
  (rankCutoff (sourceRankConstant C E) L : ℝ) *
    (Cg^(momentLength L+1)*2) *
    rankPenalty (momentLength L) (rankCutoff (sourceRankConstant C E) L)
      (L^(-sourceContractionExponent E)) (L^C) (birthAddressBudget K L)

theorem eventually_sourceLowRankMajorant_le (K : ℕ) {C Cg E : ℝ}
    (hC : 0 ≤ C) (hCg : 1 ≤ Cg) (hE : 0 ≤ E) :
    ∀ᶠ L : ℝ in atTop, sourceLowRankMajorant K C Cg E L ≤
      L^(-(E+1)*(momentLength L : ℝ)) := by
  let G := sourceContractionExponent E
  let F : ℝ := 2*(G+C+4)
  have hG : 5 ≤ G := by dsimp [G, sourceContractionExponent]; linarith
  have hF : 2 ≤ F := by dsimp [F]; linarith
  have hFp : 0 < F := by linarith
  have hC' : 0 ≤ sourceRankConstant C E := by unfold sourceRankConstant; positivity
  have hδ : 0 < 1/F := by positivity
  filter_upwards [eventually_rankCutoff_le hC' hδ, eventually_birthAddressBudget_le K,
    eventually_ge_atTop (6:ℝ), eventually_ge_atTop (Cg^2),
    tendsto_momentLength.eventually_ge_atTop 2] with L hr hQ hL hCgL hN2
  have hL1 : 1 ≤ L := by linarith
  have hLp : 0 < L := by linarith
  let N := momentLength L
  let r := rankCutoff (sourceRankConstant C E) L
  have hNr : (2:ℝ) ≤ N := hN2
  have hNnat : 2 ≤ N := by exact_mod_cast hNr
  have hFrr : F*(r:ℝ) ≤ (N:ℝ) := by
    have hm := mul_le_mul_of_nonneg_left hr hFp.le
    dsimp only [N, r]
    field_simp at hm
    nlinarith
  have hr2real : 2*(r:ℝ) ≤ (N:ℝ) := by nlinarith [show (0:ℝ) ≤ r by positivity]
  have hr2 : 2*r ≤ N := by exact_mod_cast hr2real
  have hrN : r ≤ N := by omega
  have hpen : rankPenalty N r (L^(-G)) (L^C) (birthAddressBudget K L) ≤
      L^(-(G-1)*(N:ℝ)) := by
    refine (rankPenalty_rpow_le hL1 (Nat.cast_nonneg _) hQ hr2).trans ?_
    apply Real.rpow_le_rpow_of_exponent_le hL1
    dsimp [F] at hFrr
    linarith
  have hghost : Cg^(N+1) ≤ L^N := by
    calc
      _ ≤ Cg^(2*N) := pow_le_pow_right₀ hCg (by omega)
      _ = (Cg^2)^N := by rw [pow_mul]
      _ ≤ L^N := pow_le_pow_left₀ (sq_nonneg _) hCgL _
  have htwoR : 2*(r:ℝ) ≤ L^N := by
    have hrN' : (r:ℝ) ≤ N := by exact_mod_cast hrN
    have hNl := momentLength_le_three_mul hL1
    calc
      _ ≤ 6*L := by dsimp only [N] at hrN'; linarith
      _ ≤ L^2 := by nlinarith
      _ ≤ L^N := pow_le_pow_right₀ hL1 hNnat
  have hover : (r:ℝ)*(Cg^(N+1)*2) ≤ L^(2*(N:ℝ)) := by
    have hmul := mul_le_mul htwoR hghost (pow_nonneg (by linarith : 0 ≤ Cg) _)
      (pow_nonneg (by linarith : 0 ≤ L) N)
    have heq : L^N*L^N = L^(2*(N:ℝ)) := by
      rw [← pow_add, ← Real.rpow_natCast]
      congr 1
      push_cast
      ring
    rw [heq] at hmul
    nlinarith
  unfold sourceLowRankMajorant
  change (r:ℝ)*(Cg^(N+1)*2)*rankPenalty N r (L^(-G)) (L^C)
    (birthAddressBudget K L) ≤ _
  calc
    _ ≤ L^(2*(N:ℝ))*L^(-(G-1)*(N:ℝ)) :=
      mul_le_mul hover hpen (by unfold rankPenalty; positivity) (by positivity)
    _ = L^(-(E+2)*(N:ℝ)) := by
      rw [← Real.rpow_add hLp]
      congr 1
      dsimp [G, sourceContractionExponent]
      ring
    _ ≤ _ := by
      apply Real.rpow_le_rpow_of_exponent_le hL1
      change -(E+2)*(N:ℝ) ≤ -(E+1)*(N:ℝ)
      nlinarith [show (0:ℝ) ≤ N by positivity]

/-- The explicit high/low numerical expression has every prescribed
moment saving.  The threshold depends on the displayed fixed constants
only, and therefore is uniform in bands, selectors, and histories. -/
theorem eventually_sourceMomentMajorant_le (K : ℕ) {C Cg D E : ℝ}
    (hC : 0 ≤ C) (hCg : 1 ≤ Cg) (hD : 0 ≤ D) (hE : 0 ≤ E) :
    ∀ᶠ L : ℝ in atTop,
      sourceLowRankMajorant K C Cg E L + sourceHighRankMajorant K C D E L ≤
        L^(-E*(momentLength L : ℝ)) := by
  filter_upwards [eventually_sourceLowRankMajorant_le K hC hCg hE,
    eventually_sourceHighRankMajorant_le K hC hD hE,
    eventually_ge_atTop (2:ℝ)] with L hlo hhi hL
  have hN : 1 ≤ momentLength L := momentLength_pos (by linarith : 0 < L)
  exact (by linarith : sourceLowRankMajorant K C Cg E L +
    sourceHighRankMajorant K C D E L ≤ 2*L^(-(E+1)*(momentLength L : ℝ))).trans
      (two_mul_rpow_moment_le hL hN)

end Elliptic.Operator
