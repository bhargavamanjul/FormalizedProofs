module
public import Elliptic.Operator.PhysicalEndpointSaving
public import Elliptic.Operator.SingleEdgeEndpointRestoration

/-! Exact conversion from the physical matrix pairing to the original
normalized position/list sum. Both endpoint averages cancel literally. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalEndpointPairing
open scoped BigOperators ComplexConjugate
open PhysicalRootedMoment SingleEdgeSymmetrization SingleEdgePhysicalRestoration
open SingleEdgeEndpointRestoration SingleEdgeRootEncoding
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {I Z : Type} [Fintype I] [Fintype Z] {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

theorem row_sum_lists (VM : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (z w : Z) :
    (∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,row VM g (z,a) (w,b)) =
    ((∏i,(VM i)⁻¹:ℝ):ℂ)*∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,g z a w b := by
  simp only [row,←Finset.mul_sum]
  simp_rw [Finset.sum_comm (s:=(Finset.univ : Finset (PhysicalActiveLists P J)))
    (t:=(Finset.univ : Finset (Perms (I:=I) (J:=J))))]
  have hfix (π τ : Perms (I:=I) (J:=J)) :
      (∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,
        g z (fun i k=>a i (π i k)) w (fun i k=>b i ((τ i).symm k)))=
        ∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,g z a w b := by
    have hh := pairing_fixed_permutations (P:=P) π (fun i=>(τ i).symm) (fun _=>1) (fun _=>1)
      (fun a b=>g z a w b) (fun _ _=>rfl) (fun _ _=>rfl)
    simp only [one_mul,mul_one] at hh
    convert hh using 1
    apply Finset.sum_congr (by ext; simp)
    intro a ha
    apply Finset.sum_congr (by ext; simp)
    intro b hb
    rfl
  simp_rw [hfix]
  have hn : (Fintype.card (Perms (I:=I) (J:=J)):ℂ)≠0 := by
    exact_mod_cast Fintype.card_ne_zero
  simp only [edgeMass,Complex.ofReal_mul,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,
    endpointPermutationWeight,Complex.ofReal_pow,Complex.ofReal_inv,Complex.ofReal_natCast]
  field_simp

theorem pairing_position_functions (VM : I→ℝ)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (f h : Z→ℂ) :
    pairing VM (fun x=>conj (f x.1)) (rowApply VM g (fun x=>h x.1)) =
      ((∏i,(VM i)⁻¹^(J+2):ℝ):ℂ)*
        ∑z : Z,∑w : Z,∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,
          f z*g z a w b*h w := by
  unfold pairing rowApply
  simp only [Complex.conj_conj,Fintype.sum_prod_type]
  conv_lhs => arg 2; simp only [Finset.mul_sum]
  simp_rw [Finset.sum_comm (s:=(Finset.univ : Finset (PhysicalActiveLists P J)))
    (t:=(Finset.univ : Finset Z))]
  have hs (z w : Z) :
      (∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,
        f z*(row VM g (z,a) (w,b)*h w)) =
      ((∏i,(VM i)⁻¹:ℝ):ℂ)*(∑a : PhysicalActiveLists P J,∑b : PhysicalActiveLists P J,
        f z*g z a w b*h w) := by
    simp only [←Finset.mul_sum,←Finset.sum_mul]
    rw [row_sum_lists]
    ring
  simp_rw [hs]
  simp only [←Finset.mul_sum,←mul_assoc,←Complex.ofReal_mul]
  congr 1
  unfold initialMass
  rw [←Finset.prod_mul_distrib]
  congr 1

section Source
variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem sum_subtype_complete {X : Type} (s : Finset X) (t : Finset s)
    (ht : ∀x,x∈t) (F : X→ℂ) : (∑x∈t,F x.val)=∑x∈s,F x := by
  classical
  have he : t=Finset.univ := Finset.eq_univ_iff_forall.mpr ht
  rw [he]
  exact (Finset.sum_subtype s (fun _=>Iff.rfl) F).symm

theorem pairing_physicalKernel_eq_original (value : ∀i,P i→ℕ) (VM : Fin K→ℝ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop) (U V d₀ Y H : ℝ)
    (η ψ : ℝ→ℂ) (σ : ℤ) (f h : (ℤ×ℤ)→ℂ) :
    pairing VM (fun x : State (Z:=primitiveSources U V) (P:=P) (J:=J)=>conj (f x.1.val))
      (rowApply VM (fun z a w b=>physicalKernel value good U V d₀ Y H η ψ σ (z.val,a) (w.val,b))
        (fun x=>h x.1.val)) =
    originalPairing value VM good U V d₀ Y H η ψ σ (fun x=>f x.1) (fun x=>h x.1) := by
  rw [pairing_position_functions VM _ (fun z : primitiveSources U V=>f z.val)
    (fun z : primitiveSources U V=>h z.val)]
  unfold originalPairing Elliptic.SourceContracts.finitePairing endpoints
  simp only [Finset.sum_product]
  congr 1
  apply Finset.sum_bij (fun z _=>z.val)
  · intro z hz; exact z.property
  · intro z hz w hw he; exact Subtype.val_injective he
  · intro z hz; exact ⟨⟨z,hz⟩,Finset.mem_univ _,rfl⟩
  intro z hz
  rw [Finset.sum_comm]
  apply Finset.sum_congr (by ext; simp)
  intro a ha
  apply Finset.sum_bij (fun w _=>w.val)
  · intro w hw; exact w.property
  · intro w hw t ht he; exact Subtype.val_injective he
  · intro w hw; exact ⟨⟨w,hw⟩,Finset.mem_univ _,rfl⟩
  intro w hw
  apply Finset.sum_congr (by ext; simp)
  intro b hb
  rfl

end Source

end Elliptic.Operator.PhysicalEndpointPairing
