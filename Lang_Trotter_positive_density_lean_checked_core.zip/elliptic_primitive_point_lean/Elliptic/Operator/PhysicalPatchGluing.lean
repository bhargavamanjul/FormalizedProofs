module

public import Elliptic.Operator.PhysicalAdmissibleMoment
public import Mathlib.Analysis.MeanInequalities

/-! Hölder gluing of localized endpoint estimates. The number of slope
patches never enters the bound; only the overlap of their neighbor sets
and the local number of primitive positions enter. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPatchGluing
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

theorem triple_holder {ι : Type*} (s : Finset ι) (F G M : ι→ℝ)
    (hF : ∀i∈s,0≤F i) (hG : ∀i∈s,0≤G i) (hM : ∀i∈s,0≤M i)
    (p q r : ℝ) (hp : 0<p) (hq : 0<q) (hr : 0<r) (hpqr : p+q+r=1) :
    (∑i∈s,(F i)^p*(G i)^q*(M i)^r)≤
      (∑i∈s,F i)^p*(∑i∈s,G i)^q*(∑i∈s,M i)^r := by
  have hFs : 0≤∑i∈s,F i := Finset.sum_nonneg hF
  have hGs : 0≤∑i∈s,G i := Finset.sum_nonneg hG
  have hMs : 0≤∑i∈s,M i := Finset.sum_nonneg hM
  by_cases hf0 : (∑i∈s,F i)=0
  · have hf : ∀i∈s,F i=0 := (Finset.sum_eq_zero_iff_of_nonneg hF).mp hf0
    simp only [hf0,Real.zero_rpow hp.ne',zero_mul]
    exact le_of_eq (Finset.sum_eq_zero (fun i hi=>by simp [hf i hi,Real.zero_rpow hp.ne']))
  by_cases hg0 : (∑i∈s,G i)=0
  · have hg : ∀i∈s,G i=0 := (Finset.sum_eq_zero_iff_of_nonneg hG).mp hg0
    simp only [hg0,Real.zero_rpow hq.ne',mul_zero,zero_mul]
    exact le_of_eq (Finset.sum_eq_zero (fun i hi=>by simp [hg i hi,Real.zero_rpow hq.ne']))
  by_cases hm0 : (∑i∈s,M i)=0
  · have hm : ∀i∈s,M i=0 := (Finset.sum_eq_zero_iff_of_nonneg hM).mp hm0
    simp only [hm0,Real.zero_rpow hr.ne',mul_zero]
    exact le_of_eq (Finset.sum_eq_zero (fun i hi=>by simp [hm i hi,Real.zero_rpow hr.ne']))
  have hFp : 0<∑i∈s,F i := lt_of_le_of_ne hFs (Ne.symm hf0)
  have hGp : 0<∑i∈s,G i := lt_of_le_of_ne hGs (Ne.symm hg0)
  have hMp : 0<∑i∈s,M i := lt_of_le_of_ne hMs (Ne.symm hm0)
  have hn : (∑i∈s,(F i/(∑j∈s,F j))^p*(G i/(∑j∈s,G j))^q*(M i/(∑j∈s,M j))^r)≤1 := by
    calc
      _ ≤ ∑i∈s,(p*(F i/(∑j∈s,F j))+q*(G i/(∑j∈s,G j))+r*(M i/(∑j∈s,M j))) :=
        Finset.sum_le_sum (fun i hi=>Real.geom_mean_le_arith_mean3_weighted hp.le hq.le hr.le
          (div_nonneg (hF i hi) hFs) (div_nonneg (hG i hi) hGs) (div_nonneg (hM i hi) hMs) hpqr)
      _ = 1 := by
        simp only [Finset.sum_add_distrib,←Finset.mul_sum,←Finset.sum_div,div_self hf0,
          div_self hg0,div_self hm0,mul_one,hpqr]
  have he : (∑i∈s,(F i/(∑j∈s,F j))^p*(G i/(∑j∈s,G j))^q*(M i/(∑j∈s,M j))^r)=
      (∑i∈s,(F i)^p*(G i)^q*(M i)^r)/
        ((∑i∈s,F i)^p*(∑i∈s,G i)^q*(∑i∈s,M i)^r) := by
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i hi
    rw [Real.div_rpow (hF i hi) hFs,Real.div_rpow (hG i hi) hGs,Real.div_rpow (hM i hi) hMs]
    ring
  rw [he] at hn
  exact (div_le_one (by positivity)).mp hn

/-- Positive integer power conversion for one localized estimate. -/
theorem local_power_to_root (R : ℕ) (hR : 0<R) (a F G M : ℝ)
    (ha : 0≤a) (hF : 0≤F) (hG : 0≤G) (hM : 0≤M)
    (h : a^(2*R)≤G^R*F^(R-1)*M) :
    a≤G^(1/2:ℝ)*F^((R-1:ℕ)/(2*(R:ℝ)))*M^(1/(2*(R:ℝ))) := by
  have hn : (0:ℝ)<2*(R:ℝ) := by positivity
  have hh := Real.rpow_le_rpow (pow_nonneg ha _) h (show 0≤1/(2*(R:ℝ)) by positivity)
  have hleft : (a^(2*R))^(1/(2*(R:ℝ)))=a := by
    rw [←Real.rpow_natCast,←Real.rpow_mul ha]
    push_cast
    rw [mul_one_div_cancel (by positivity : (2*(R:ℝ))≠0),Real.rpow_one]
  have hright : (G^R*F^(R-1)*M)^(1/(2*(R:ℝ)))=
      G^(1/2:ℝ)*F^((R-1:ℕ)/(2*(R:ℝ)))*M^(1/(2*(R:ℝ))) := by
    rw [Real.mul_rpow (mul_nonneg (pow_nonneg hG _) (pow_nonneg hF _)) hM,
      Real.mul_rpow (pow_nonneg hG _) (pow_nonneg hF _),
      ←Real.rpow_natCast,←Real.rpow_mul hG,←Real.rpow_natCast,←Real.rpow_mul hF]
    have he : (R:ℝ)*(1/(2*(R:ℝ)))=1/2 := by field_simp
    rw [he,mul_one_div]
  simpa only [hleft,hright] using hh

/-- Cardinality-free assembly of arbitrary localized complex terms. -/
theorem local_power_sum_bound {ι : Type*} (s : Finset ι) (term : ι→ℂ)
    (F G M : ι→ℝ) (R : ℕ) (hR : 2≤R)
    (hF : ∀i∈s,0≤F i) (hG : ∀i∈s,0≤G i) (hM : ∀i∈s,0≤M i)
    (hlocal : ∀i∈s,‖term i‖^(2*R)≤G i^R*F i^(R-1)*M i) :
    ‖∑i∈s,term i‖^(2*R)≤(∑i∈s,G i)^R*(∑i∈s,F i)^(R-1)*(∑i∈s,M i) := by
  have hRp : 0<R := by omega
  have hRm : (0:ℝ)<(R-1:ℕ) := by exact_mod_cast (show 0<R-1 by omega)
  have hh := triple_holder s G F M hG hF hM (1/2) ((R-1:ℕ)/(2*(R:ℝ)))
    (1/(2*(R:ℝ))) (by norm_num) (by positivity) (by positivity) (by
      rw [Nat.cast_sub (by omega : 1≤R),Nat.cast_one]
      field_simp
      ring)
  have hsum : ‖∑i∈s,term i‖≤(∑i∈s,G i)^(1/2:ℝ)*
      (∑i∈s,F i)^((R-1:ℕ)/(2*(R:ℝ)))*(∑i∈s,M i)^(1/(2*(R:ℝ))) :=
    (norm_sum_le _ _).trans ((Finset.sum_le_sum (fun i hi=>
      local_power_to_root R hRp _ _ _ _ (norm_nonneg _) (hF i hi) (hG i hi) (hM i hi)
        (hlocal i hi))).trans hh)
  have hp := pow_le_pow_left₀ (norm_nonneg _) hsum (2*R)
  apply hp.trans_eq
  rw [mul_pow,mul_pow]
  have hGs := Finset.sum_nonneg hG
  have hFs := Finset.sum_nonneg hF
  have hMs := Finset.sum_nonneg hM
  rw [←Real.rpow_mul_natCast hGs,←Real.rpow_mul_natCast hFs,←Real.rpow_mul_natCast hMs]
  have h1 : (1/2:ℝ)*(2*R:ℕ)=R := by push_cast; ring
  have h2 : ((R-1:ℕ)/(2*(R:ℝ)))*(2*R:ℕ)=(R-1:ℕ) := by push_cast; field_simp
  have h3 : (1/(2*(R:ℝ)))*(2*R:ℕ)=1 := by push_cast; field_simp
  rw [h1,h2,h3,Real.rpow_natCast,Real.rpow_natCast,Real.rpow_one]

/-- Local trace savings glue with the neighbor overlap, rather than the
total number of positions or patches. F and G are squared endpoint norms. -/
theorem glue_with_overlap {ι : Type*} (s : Finset ι) (term : ι→ℂ)
    (F G M : ι→ℝ) (R : ℕ) (hR : 2≤R) (A D Ftotal Gtotal Mtotal : ℝ)
    (hA : 0≤A) (hD : 0≤D) (hFt : 0≤Ftotal) (hGt : 0≤Gtotal) (hMt : 0≤Mtotal)
    (hF : ∀i∈s,0≤F i) (hG : ∀i∈s,0≤G i) (hM : ∀i∈s,0≤M i)
    (hlocal : ∀i∈s,‖term i‖^(2*R)≤G i^R*F i^(R-1)*(A*M i))
    (hFsum : (∑i∈s,F i)≤Ftotal) (hGsum : (∑i∈s,G i)≤D*Gtotal)
    (hMsum : (∑i∈s,M i)≤Mtotal) :
    ‖∑i∈s,term i‖^(2*R)≤D^R*Gtotal^R*Ftotal^(R-1)*A*Mtotal := by
  have h := local_power_sum_bound s term F G (fun i=>A*M i) R hR hF hG
    (fun i hi=>mul_nonneg hA (hM i hi)) hlocal
  calc
    _ ≤ (∑i∈s,G i)^R*(∑i∈s,F i)^(R-1)*(A*∑i∈s,M i) := by
      simpa only [Finset.mul_sum] using h
    _ ≤ (D*Gtotal)^R*Ftotal^(R-1)*(A*Mtotal) := by
      have hFs := Finset.sum_nonneg hF
      have hGs := Finset.sum_nonneg hG
      have hMs := Finset.sum_nonneg hM
      gcongr
    _ = _ := by rw [mul_pow]; ring

section LocalizedEndpoint
open PhysicalRootedMoment PhysicalAdmissibleMoment
attribute [local instance] Classical.propDecidable
local instance patchGluingDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
variable {I Z : Type} [Fintype I] [Fintype Z] {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

/-- Projected spectral Hölder on one finite patch, retaining only that
patch's positive diagonal moment. This is the input to the gluing lemma. -/
theorem localized_endpoint_power_bound (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (V : I→ℝ) (hV : ∀i,0≤V i)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : PhysicalAdmissibleMoment.Supported value position g) (R : ℕ) (hR : 0<R)
    (s : Finset Z) (f : Z→ℂ) (G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    let F := fun x : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)=>if x.1∈s then f x.1 else 0
    ‖pairing V F (rowApply V g G)‖^(2*R)≤
      (pairing V (project value position G) (project value position G)).re^R*
      (pairing V (project value position F) (project value position F)).re^(R-1)*
      ((∑z∈s,(pairing V (PhysicalRootedMoment.positionVector z)
        (aaStarPower V g R (PhysicalRootedMoment.positionVector z))).re)*∑z∈s,‖f z‖^2) := by
  dsimp only
  have h :
      ‖pairing V (∑z∈s,f z • PhysicalAdmissibleMoment.positionVector (J:=J) value position z)
        (rowApply V g (project value position G))‖^(2*((R-1)+1))≤
      (pairing V (project value position G) (project value position G)).re^((R-1)+1)*
      (pairing V (∑z∈s,f z • PhysicalAdmissibleMoment.positionVector (J:=J) value position z)
        (∑z∈s,f z • PhysicalAdmissibleMoment.positionVector (J:=J) value position z)).re^(R-1)*
      ((∑z∈s,(pairing V (PhysicalAdmissibleMoment.positionVector (J:=J) value position z)
        (aaStarPower V g ((R-1)+1) (PhysicalAdmissibleMoment.positionVector (J:=J) value position z))).re)*
          ∑z∈s,‖f z‖^2) := by
    simp only [pairing_self_re,pairing_power_re,rowApply_eq_mulVec]
    exact PhysicalMomentEndpoint.aaStar_endpoint_trace_bound s (matrix V g) (R-1)
      (PhysicalAdmissibleMoment.positionVector (J:=J) value position) f (project value position G)
      (initialMass (J:=J) V) (initialMass_nonneg V hV)
  rw [Nat.sub_add_cancel hR,PhysicalAdmissibleMoment.positionVector_sum,
    pairing_row_project value position V g hg] at h
  have hm : (∑z∈s,(pairing V (PhysicalAdmissibleMoment.positionVector (J:=J) value position z)
      (aaStarPower V g R (PhysicalAdmissibleMoment.positionVector (J:=J) value position z))).re)=
      ∑z∈s,(pairing V (PhysicalRootedMoment.positionVector z)
        (aaStarPower V g R (PhysicalRootedMoment.positionVector z))).re := by
    apply Finset.sum_congr rfl
    intro z _
    exact congrArg Complex.re (pairing_power_project value position V g hg R hR _ _)
  rw [hm] at h
  exact h

theorem pairing_self_re_nonneg (V : I→ℝ) (hV : ∀i,0≤V i)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) : 0≤(pairing V F F).re := by
  rw [pairing_self_re,PhysicalMomentEndpoint.self_quadratic_eq_sum_norm_sq]
  exact mul_nonneg (initialMass_nonneg V hV) (Finset.sum_nonneg (fun _ _=>sq_nonneg _))

/-- A patch with at most Pcap primitive positions has the exact local
spectral estimate with coefficient cost Pcap times the squared supremum. -/
theorem localized_endpoint_bound_of_card (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (V : I→ℝ) (hV : ∀i,0≤V i)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : PhysicalAdmissibleMoment.Supported value position g) (R : ℕ) (hR : 0<R)
    (s : Finset Z) (f : Z→ℂ) (G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ)
    (B Pcap : ℝ) (hB : 0≤B) (hcard : (s.card:ℝ)≤Pcap) (hf : ∀z∈s,‖f z‖≤B) :
    let F := fun x : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)=>if x.1∈s then f x.1 else 0
    ‖pairing V F (rowApply V g G)‖^(2*R)≤
      (pairing V (project value position G) (project value position G)).re^R*
      (pairing V (project value position F) (project value position F)).re^(R-1)*
      ((Pcap*B^2)*(∑z∈s,(pairing V (PhysicalRootedMoment.positionVector z)
        (aaStarPower V g R (PhysicalRootedMoment.positionVector z))).re)) := by
  dsimp only
  have h := localized_endpoint_power_bound value position V hV g hg R hR s f G
  dsimp only at h
  have hc : (∑z∈s,‖f z‖^2)≤Pcap*B^2 := by
    calc
      _ ≤ ∑_z∈s,B^2 := Finset.sum_le_sum (fun z hz=>by nlinarith [hf z hz,norm_nonneg (f z)])
      _ = (s.card:ℝ)*B^2 := by simp
      _ ≤ _ := mul_le_mul_of_nonneg_right hcard (sq_nonneg _)
  have hm : 0≤∑z∈s,(pairing V (PhysicalRootedMoment.positionVector z)
      (aaStarPower V g R (PhysicalRootedMoment.positionVector z))).re := by
    apply Finset.sum_nonneg
    intro z _
    rw [pairing_power_re]
    exact mul_nonneg (initialMass_nonneg V hV)
      ((aaStarMatrix_posSemidef V g R).re_dotProduct_nonneg _)
  apply h.trans
  apply mul_le_mul_of_nonneg_left
    ((mul_le_mul_of_nonneg_left hc hm).trans_eq (mul_comm _ _))
  exact mul_nonneg (pow_nonneg (pairing_self_re_nonneg V hV _) _)
    (pow_nonneg (pairing_self_re_nonneg V hV _) _)

end LocalizedEndpoint

end Elliptic.Operator.PhysicalPatchGluing
