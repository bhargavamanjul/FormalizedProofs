module
public import Elliptic.Operator.SignedPhysicalCofactorCount

/-! Common-cofactor counting with an arbitrary fixed enlargement of the source scale. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteRaw
open scoped BigOperators
open Filter
attribute [local instance 10000] Classical.propDecidable
local instance cofactorScaleDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

def cofactorScaleConstant (c : ℝ) : ℝ :=
  32 * max c 1 * (1 + Real.log (max c 1))^3

theorem cofactorScaleConstant_nonneg (c : ℝ) : 0≤cofactorScaleConstant c := by
  have hh : 0≤Real.log (max c 1) := Real.log_nonneg (le_max_right _ _)
  unfold cofactorScaleConstant
  positivity

theorem eventually_common_cofactor_count_scaled (c D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀(s t : Finset ℕ) (a b : ℕ) (Y : ℝ),
      (∀m∈s,0<m) → (∀m∈s,∀n∈t,0<m*n) →
      0<Y → Y≤a → (a:ℝ)≤4*Y → Y≤b → (b:ℝ)≤4*Y →
      (a:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (b:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (∑m∈s,∑n∈t,∑r∈s,∑q∈t,
        if ∃h∈Finset.Icc 1 ⌊(c*x)/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)≤
        cofactorScaleConstant c*(x/Y)*(1+Real.log (8*x))^3 := by
  let d := max c 1
  have hd : 1≤d := le_max_right _ _
  have hdp : 0<d := lt_of_lt_of_le zero_lt_one hd
  have ht : Tendsto (fun x : ℝ=>d*x) atTop atTop :=
    Tendsto.const_mul_atTop hdp tendsto_id
  filter_upwards [ht.eventually (eventually_common_cofactor_count D hD),
    eventually_ge_atTop (1:ℝ)] with x hx hx1
  intro s t a b Y hs hpos hY ha ha' hb hb' hau hbu
  have hxp : 0<x := lt_of_lt_of_le zero_lt_one hx1
  have hxd : x≤d*x := by nlinarith
  have hlogx : 0≤Real.log x := Real.log_nonneg hx1
  have hlogd : 0≤Real.log d := Real.log_nonneg hd
  have hlog8 : 0≤Real.log (8*x) := Real.log_nonneg (by linarith)
  have hexp : Real.exp (D*(Real.log x)^(1/5:ℝ))≤
      Real.exp (D*(Real.log (d*x))^(1/5:ℝ)) := by
    apply Real.exp_le_exp.mpr
    apply mul_le_mul_of_nonneg_left _ hD
    exact Real.rpow_le_rpow hlogx (Real.log_le_log hxp hxd) (by positivity)
  have hc := hx s t a b Y hs hpos hY ha ha' hb hb' (hau.trans hexp) (hbu.trans hexp)
  have hcap : ⌊(c*x)/Y⌋₊≤⌊(d*x)/Y⌋₊ := by
    apply Nat.floor_mono
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (le_max_left c 1) hxp.le) hY.le
  have hsum : (∑m∈s,∑n∈t,∑r∈s,∑q∈t,
        if ∃h∈Finset.Icc 1 ⌊(c*x)/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)≤
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,
        if ∃h∈Finset.Icc 1 ⌊(d*x)/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0 := by
    apply Finset.sum_le_sum
    intro m hm
    apply Finset.sum_le_sum
    intro n hn
    apply Finset.sum_le_sum
    intro r hr
    apply Finset.sum_le_sum
    intro q hq
    split_ifs with h₁ h₂
    · rfl
    · exfalso
      apply h₂
      obtain ⟨h,hh,he⟩ := h₁
      exact ⟨h,Finset.Icc_subset_Icc le_rfl hcap hh,he⟩
    · exact zero_le_one
    · rfl
  have hlog : 1+Real.log (8*(d*x))≤(1+Real.log d)*(1+Real.log (8*x)) := by
    rw [show 8*(d*x)=d*(8*x) by ring,Real.log_mul hdp.ne' (by positivity : 8*x≠0)]
    nlinarith [mul_nonneg hlogd hlog8]
  have hpow := pow_le_pow_left₀
    (by have := Real.log_nonneg (show 1≤8*(d*x) by nlinarith); linarith) hlog 3
  calc
    _ ≤ _ := hsum.trans hc
    _ ≤ 32*((d*x)/Y)*((1+Real.log d)*(1+Real.log (8*x)))^3 :=
      mul_le_mul_of_nonneg_left hpow (by positivity)
    _ = _ := by unfold cofactorScaleConstant; dsimp [d]; ring

end Elliptic.Operator.SignedPhysicalAbsoluteRaw
