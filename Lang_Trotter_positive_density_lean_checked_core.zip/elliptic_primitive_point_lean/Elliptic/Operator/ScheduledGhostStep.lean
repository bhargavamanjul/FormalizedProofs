module

public import Elliptic.Operator.GhostSetRealization
public import Elliptic.Operator.LifespanSchedule

/-!
# Literal ghost steps of a prescribed prime-lifespan schedule

The old memory may be any ordered representative of the scheduled bag.
Endpoint incidence and the next scheduled cardinality suffice to construct
an actually valid indexed ghost choice.  Its output enumerates the next
scheduled set.  Summing the actual distinct-birth ordering fiber retains
all signs, survival powers, and prime weights exactly.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- A tuple bag is the image multiset of all its actual indices. -/
theorem tupleBag_eq_univ_map {ι X : Type*} [Fintype ι] (x : ι → X) :
    tupleBag x = Finset.univ.val.map x := by
  simp only [tupleBag, Finset.sum_eq_multiset_sum]
  rw [← Multiset.sum_map_singleton (Finset.univ.val.map x), Multiset.map_map]
  rfl

/-- Equality with a scheduled prime-set bag forces distinct prime labels
and their retained lines in every ordered representative. -/
theorem memoryEnumeratesSet_of_bag {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hm : tupleBag m.values = A.val.map (anchorPrime ℓ)) :
    MemoryEnumeratesSet A ℓ m := by
  classical
  have hmap : Finset.univ.val.map (fun i => (m.values i).1) = A.val := by
    have hh := congrArg (Multiset.map Sigma.fst) hm
    simpa only [tupleBag_eq_univ_map, Multiset.map_map, Function.comp_def,
      anchorPrime, Multiset.map_id'] using hh
  refine ⟨?_, ?_, ?_⟩
  · intro i k hik
    have hn : (Finset.univ.val.map (fun i => (m.values i).1)).Nodup :=
      hmap ▸ A.nodup
    exact (Multiset.nodup_map_iff_inj_on Finset.univ.nodup).mp hn
      i (by simp) k (by simp) hik
  · intro p
    have hh := congrArg (fun t : Multiset P => p ∈ t) hmap
    simpa only [Multiset.mem_map, Finset.mem_val, Finset.mem_univ, true_and] using
      (Iff.of_eq hh).symm
  · intro i
    have hi : m.values i ∈ tupleBag m.values := by
      rw [tupleBag_eq_univ_map]
      exact Multiset.mem_map.mpr ⟨i, by simp, rfl⟩
    rw [hm] at hi
    obtain ⟨p,hp,he⟩ := Multiset.mem_map.mp hi
    have heprime : p = (m.values i).1 := congrArg Sigma.fst he
    simpa only [heprime] using he.symm

/-- Conversely, the explicit distinct enumeration gives exactly the
scheduled multiset, without choosing a preferred ordering. -/
theorem memoryEnumeratesSet_bag {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    tupleBag m.values = A.val.map (anchorPrime ℓ) := by
  rw [← selectedBag_eq_map A (anchorPrime ℓ)]
  calc
    _ = ∑ i : Fin m.size,
        ({anchorPrime ℓ (m.values i).1} : Multiset (AnchoredParticle P Line)) := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [hm.2.2 i]
      rfl
    _ = _ := Equiv.sum_comp (memoryPrimeSetEquiv A ℓ m hm)
      (fun p : A => ({anchorPrime ℓ p.val} : Multiset (AnchoredParticle P Line)))

/-- A tuple with exactly the finite-set bag lists each element once. -/
theorem enumeratesDistinct_of_tupleBag {P : Type*}
    (T : Finset P) (x : Fin T.card → P) (hx : tupleBag x = T.val) :
    EnumeratesDistinct T x := by
  classical
  rw [tupleBag_eq_univ_map] at hx
  refine ⟨?_, ?_⟩
  · have hn : (Finset.univ.val.map x).Nodup := hx ▸ T.nodup
    intro i k hik
    exact (Multiset.nodup_map_iff_inj_on Finset.univ.nodup).mp hn
      i (by simp) k (by simp) hik
  · intro p
    have hh := congrArg (fun t : Multiset P => p ∈ t) hx
    simpa only [Multiset.mem_map, Finset.mem_val, Finset.mem_univ, true_and] using
      (Iff.of_eq hh).symm

/-- Scheduled deletion indices have exactly their declared prime labels. -/
theorem ghostDeletionIndices_image {P : Type*} [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) :
    (ghostDeletionIndices m D).image (fun i => (m.values i).1) = D := by
  ext p
  constructor
  · rintro hp
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hp
    exact (mem_ghostDeletionIndices m D i).mp hi
  · intro hp
    obtain ⟨i,hi⟩ := (hm.2.1 p).mp (hD hp)
    exact Finset.mem_image.mpr ⟨i, (mem_ghostDeletionIndices m D i).mpr (hi ▸ hp), hi⟩

/-- In a distinct old memory, the deleted prime-label image determines
all actual deleted indices; this is the local inverse for deletion. -/
theorem ghostDeletionIndices_eq_of_image {P : Type*} [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (U : Finset (Fin m.size))
    (hU : U.image (fun i => (m.values i).1) = D) :
    U = ghostDeletionIndices m D := by
  ext i
  rw [mem_ghostDeletionIndices, ← hU, Finset.mem_image]
  constructor
  · intro hi
    exact ⟨i,hi,rfl⟩
  · rintro ⟨k,hk,hki⟩
    exact hm.1 hki ▸ hk

namespace LifespanSchedule
variable {P : Type*} {N : ℕ}

/-- A cutoff for the scheduled output derives the exact indexed survivor
plus birth size; the old order never enters this bound. -/
theorem ghost_survivors_births_card (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    (before S L j \ deaths S L j).card + (births S L j).card =
      (after S L j).card := by
  classical
  rw [ghost_recurrence, Finset.card_union_of_disjoint]
  exact (births_disjoint_before S L j).symm.mono_left Finset.sdiff_subset

/-- Births are included in the actual next pending set. -/
theorem births_subset_after (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    births S L j ⊆ after S L j := by
  classical
  rw [ghost_recurrence]
  exact Finset.subset_union_right

/-- The cardinality bound needed by the literal fresh-batch constructor
follows from the single next-state cutoff. -/
theorem births_card_le_cutoff (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (B : ℕ) (hcut : (after S L j).card ≤ B) :
    (births S L j).card ≤ B :=
  (Finset.card_le_card (births_subset_after S L j)).trans hcut

/-- The actual indexed ghost choice at this visit: delete exactly the
scheduled dying primes, then append a chosen ordering of the births. -/
def ghostChoice {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hcut : (after S L j).card ≤ B) (x : DistinctBirthTuple (births S L j)) :
    GhostChoice m :=
  distinctFreshGhostChoice m (ghostDeletionIndices m (deaths S L j))
    (births S L j) (births_card_le_cutoff S L j B hcut) x.val

/-- Different fresh orderings give different literal ghost choices; no
extra identification or multiplicity is hidden in the construction. -/
theorem ghostChoice_injective {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hcut : (after S L j).card ≤ B) :
    Function.Injective (ghostChoice S L j m hcut) := by
  intro x y h
  have hbatch := congrArg Prod.snd h
  apply Subtype.ext
  exact eq_of_heq (Sigma.mk.inj_iff.mp hbatch).2

/-- Every arbitrary actual choice with the scheduled deleted-label image
and the scheduled fresh-prime bag is uniquely the constructed choice for
one fresh ordering.  The fresh length and distinctness are derived from
bag equality rather than supplied or assumed in constructor form. -/
theorem ghostChoice_existsUnique_of_fibers [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hcut : (after S L j).card ≤ B) (c : GhostChoice m)
    (hdeleted : c.1.image (fun i => (m.values i).1) = deaths S L j)
    (hfresh : tupleBag c.2.values = (births S L j).val) :
    ∃! x : DistinctBirthTuple (births S L j), ghostChoice S L j m hcut x = c := by
  rcases c with ⟨U, ⟨⟨k,hk⟩,v⟩⟩
  have hlen : k = (births S L j).card := by
    have hh := congrArg Multiset.card hfresh
    simpa [tupleBag, Multiset.card_sum, MemoryState.values, MemoryState.size] using hh
  subst k
  have hx : EnumeratesDistinct (births S L j) v :=
    enumeratesDistinct_of_tupleBag (births S L j) v hfresh
  have hU := ghostDeletionIndices_eq_of_image (before S L j) (deaths S L j)
    ℓ m hm U hdeleted
  let x : DistinctBirthTuple (births S L j) := ⟨v,hx⟩
  have he : ghostChoice S L j m hcut x = (U, ⟨⟨(births S L j).card,hk⟩,v⟩) := by
    apply Prod.ext
    · exact hU.symm
    · rfl
  refine ⟨x,he,?_⟩
  intro y hy
  exact ghostChoice_injective S L j m hcut (hy.trans he.symm)

/-- The observable deletion-image and fresh-bag conditions characterize
exactly the scheduled ghost-choice fiber, with no preferred old order. -/
theorem ghostChoice_fiber_iff [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hcut : (after S L j).card ≤ B) (c : GhostChoice m) :
    (c.1.image (fun i => (m.values i).1) = deaths S L j ∧
      tupleBag c.2.values = (births S L j).val) ↔
      ∃! x : DistinctBirthTuple (births S L j), ghostChoice S L j m hcut x = c := by
  constructor
  · rintro ⟨hd,hb⟩
    exact ghostChoice_existsUnique_of_fibers S L j ℓ m hm hcut c hd hb
  · rintro ⟨x,rfl,hx⟩
    constructor
    · exact ghostDeletionIndices_image (before S L j) (deaths S L j) ℓ m hm
        (deaths_subset_before S L j)
    · simpa [ghostChoice, distinctFreshGhostChoice, MemoryState.values] using
        distinctBirthTuple_bag (births S L j) id x

/-- The independently defined actual-choice fiber uses only observable
old deletion labels and the entire fresh tuple bag. -/
abbrev GhostChoiceFiber [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (m : MemoryState (AnchoredParticle P Line) B) :=
  {c : GhostChoice m // c.1.image (fun i => (m.values i).1) = deaths S L j ∧
    tupleBag c.2.values = (births S L j).val}

/-- The exact local fiber equivalence between fresh orderings and all
actual choices having the prescribed deletion-label and fresh-bag data. -/
def ghostChoiceFiberEquiv [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hcut : (after S L j).card ≤ B) :
    DistinctBirthTuple (births S L j) ≃ GhostChoiceFiber S L j m := by
  let f : DistinctBirthTuple (births S L j) → GhostChoiceFiber S L j m :=
    fun x => ⟨ghostChoice S L j m hcut x,
      (ghostChoice_fiber_iff S L j ℓ m hm hcut _).mpr
        ⟨x,rfl,fun y hy => ghostChoice_injective S L j m hcut hy⟩⟩
  refine Equiv.ofBijective f ⟨?_,?_⟩
  · intro x y h
    exact ghostChoice_injective S L j m hcut (congrArg Subtype.val h)
  · intro c
    obtain ⟨x,hx,_⟩ := ghostChoice_existsUnique_of_fibers S L j ℓ m hm hcut
      c.val c.property.1 c.property.2
    exact ⟨x,Subtype.ext hx⟩

/-- The actual scheduled choice fiber has exactly the factorial size;
this count is a consequence of its constructed bijection. -/
theorem ghostChoiceFiber_card [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hcut : (after S L j).card ≤ B) :
    Fintype.card (GhostChoiceFiber S L j m) = (births S L j).card.factorial := by
  rw [← Fintype.card_congr (ghostChoiceFiberEquiv S L j ℓ m hm hcut)]
  exact distinctBirthTuple_card (births S L j)

/-- The actual choice is valid from endpoint line incidence and the next
scheduled size, with no ghost-validity assumption. -/
theorem ghostChoice_valid {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hdeath : ∀ p ∈ deaths S L j, ℓ p = anchor p)
    (hcut : (after S L j).card ≤ B) (x : DistinctBirthTuple (births S L j)) :
    GhostChoice.Valid anchor m (ghostChoice S L j m hcut x) := by
  apply ghostSetChoice_valid (before S L j) (deaths S L j) (births S L j)
    ℓ anchor m hm (deaths_subset_before S L j) hdeath
  rw [ghost_survivors_births_card]
  exact hcut

/-- Its literal survivor/append output has exactly the next scheduled bag,
for every ordering of the distinct fresh birth set. -/
theorem ghostChoice_output_bag [Fintype P] {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hdeath : ∀ p ∈ deaths S L j, ℓ p = anchor p)
    (hbirth : ∀ p ∈ births S L j, ℓ p = anchor p)
    (hcut : (after S L j).card ≤ B) (x : DistinctBirthTuple (births S L j)) :
    tupleBag (ghostOutput anchor m (ghostChoice S L j m hcut x)
      (ghostChoice_valid S L j ℓ anchor m hm hdeath hcut x)).values =
      bag ℓ (after S L j) := by
  have hc : (before S L j \ deaths S L j).card + (births S L j).card ≤ B := by
    rw [ghost_survivors_births_card]
    exact hcut
  have h := ghostSet_actual_output_bag (before S L j) (deaths S L j) (births S L j)
    ℓ anchor m hm (deaths_subset_before S L j) (births_disjoint_before S L j).symm
    hdeath hbirth (births_card_le_cutoff S L j B hcut) hc x
  simpa only [← ghost_recurrence, ghostChoice, bag] using h

/-- In particular the actual output is again a distinct ordered
representative, which is the invariant required by the following edge. -/
theorem ghostChoice_output_enumerates [Fintype P] {Line : P → Type*} {B : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hdeath : ∀ p ∈ deaths S L j, ℓ p = anchor p)
    (hbirth : ∀ p ∈ births S L j, ℓ p = anchor p)
    (hcut : (after S L j).card ≤ B) (x : DistinctBirthTuple (births S L j)) :
    MemoryEnumeratesSet (after S L j) ℓ
      (ghostOutput anchor m (ghostChoice S L j m hcut x)
        (ghostChoice_valid S L j ℓ anchor m hm hdeath hcut x)) :=
  memoryEnumeratesSet_of_bag (after S L j) ℓ _
    (ghostChoice_output_bag S L j ℓ anchor m hm hdeath hbirth hcut x)

/-- The complete actual fresh-ordering fiber gives the exact signed
scheduled coefficient and the next scheduled bag. -/
theorem ghostChoice_coefficient_fiber [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ)
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (before S L j) ℓ m)
    (hdeath : ∀ p ∈ deaths S L j, ℓ p = anchor p)
    (hbirth : ∀ p ∈ births S L j, ℓ p = anchor p)
    (hcut : (after S L j).card ≤ B)
    (F : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ x : DistinctBirthTuple (births S L j),
      (ghostChoiceWeight ν V η q ρ anchor m (ghostChoice S L j m hcut x) : ℂ) *
      F (tupleBag (ghostOutput anchor m (ghostChoice S L j m hcut x)
        (ghostChoice_valid S L j ℓ anchor m hm hdeath hcut x)).values)) =
      (((-η/ρ)^(deaths S L j).card *
        (q/ρ^2)^((before S L j \ deaths S L j).filter (fun p => ℓ p = anchor p)).card *
        (-η*V/ρ)^(births S L j).card : ℝ) : ℂ) *
      (∏ p ∈ births S L j, (ν p : ℂ)) * F (bag ℓ (after S L j)) := by
  have hc : (before S L j \ deaths S L j).card + (births S L j).card ≤ B := by
    rw [ghost_survivors_births_card]
    exact hcut
  have h := ghostSet_actual_coefficient_fiber ν V η q ρ
    (before S L j) (deaths S L j) (births S L j) ℓ anchor m hm
    (deaths_subset_before S L j) (births_disjoint_before S L j).symm hdeath hbirth
    (births_card_le_cutoff S L j B hcut) hc F
  simpa only [← ghost_recurrence, ghostChoice, bag] using h

end LifespanSchedule
end Elliptic.Operator
