module

public import Mathlib.Analysis.Complex.Basic
public import Mathlib.Data.Finset.Powerset
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Data.Fintype.Perm
public import Mathlib.Data.Nat.Choose.Basic
public import Mathlib.Logic.Equiv.Set
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.BigOperators.Field
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.NormNum
public import Lean.Elab.Tactic.Omega
public import Mathlib.Tactic.Ring

/-!
# Factorial memory measure and indexed particle deletion

Memory functions are evaluated on multisets of particle values, while their
measure is the actual product measure on ordered tuples, divided by the
factorial of the tuple length. Deletions select subsets of the index set;
repeated particle values therefore remain distinct indexed choices.

The finite sum identities below are the measure-theoretic algebra behind
source (4.17)--(4.18). They do not assert estimates for ghost or edge kernels.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators


/-- The multiset of an actual ordered tuple's particle values. -/
def tupleBag {ι X : Type*} [Fintype ι] (x : ι → X) : Multiset X :=
  ∑ i, {x i}

/-- Unnormalized tensor product measure at an actual ordered tuple. -/
def tupleWeight {ι X R : Type*} [Fintype ι] [CommMonoid R]
    (μ : X → R) (x : ι → X) : R := ∏ i, μ (x i)

/-- Splitting a tuple by any specified bijection of its coordinates. -/
def tupleSplitEquiv {ι κ τ X : Type*} (e : κ ⊕ τ ≃ ι) :
    (ι → X) ≃ (κ → X) × (τ → X) where
  toFun x := (fun j => x (e (Sum.inl j)), fun j => x (e (Sum.inr j)))
  invFun uv := fun i => Sum.elim uv.1 uv.2 (e.symm i)
  left_inv x := by
    funext i
    change Sum.elim (fun j => x (e (Sum.inl j)))
      (fun j => x (e (Sum.inr j))) (e.symm i) = x i
    have h : ∀ z : κ ⊕ τ, Sum.elim (fun j => x (e (Sum.inl j)))
        (fun j => x (e (Sum.inr j))) z = x (e z) := by intro z; cases z <;> rfl
    rw [h, e.apply_symm_apply]
  right_inv uv := by
    apply Prod.ext <;> funext j <;> simp

/-- Product measure factors exactly under coordinate splitting. -/
theorem tupleWeight_split {ι κ τ X R : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ] [CommMonoid R]
    (e : κ ⊕ τ ≃ ι) (μ : X → R) (x : ι → X) :
    tupleWeight μ x = tupleWeight μ ((tupleSplitEquiv e x).1) *
      tupleWeight μ ((tupleSplitEquiv e x).2) := by
  unfold tupleWeight
  rw [← Equiv.prod_comp e]
  rw [Fintype.prod_sum_type]
  rfl

/-- The actual particle multiset splits into survivor and selected bags. -/
theorem tupleBag_split {ι κ τ X : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ]
    (e : κ ⊕ τ ≃ ι) (x : ι → X) :
    tupleBag x = tupleBag ((tupleSplitEquiv e x).1) +
      tupleBag ((tupleSplitEquiv e x).2) := by
  unfold tupleBag
  rw [← Equiv.sum_comp e]
  rw [Fintype.sum_sum_type]
  rfl

/-- A genuine finite product-measure integral reindexed into the survivor
and deleted coordinates. Arbitrary multiset functions give symmetric old,
survivor and deleted-particle test functions. -/
theorem tuple_split_integral {ι κ τ X R : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ] [DecidableEq ι] [DecidableEq κ]
    [DecidableEq τ] [Fintype X] [CommSemiring R]
    (e : κ ⊕ τ ≃ ι) (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : ι → X, tupleWeight μ x * F (tupleBag x) *
      G (tupleBag ((tupleSplitEquiv e x).1)) *
      D (tupleBag ((tupleSplitEquiv e x).2))) =
    ∑ u : κ → X, ∑ v : τ → X,
      tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
        G (tupleBag u) * D (tupleBag v) := by
  calc
    _ = ∑ uv : (κ → X) × (τ → X),
        tupleWeight μ uv.1 * tupleWeight μ uv.2 * F (tupleBag uv.1 + tupleBag uv.2) *
          G (tupleBag uv.1) * D (tupleBag uv.2) := by
      apply Fintype.sum_equiv (tupleSplitEquiv e)
      intro x
      rw [tupleWeight_split e μ x, tupleBag_split e x]
    _ = _ := Fintype.sum_prod_type _

/-- The selected coordinates may also be tested in their prescribed
order, as needed for retrieval into ordered active slots. -/
theorem tuple_split_integral_ordered {ι κ τ X R : Type*}
    [Fintype ι] [Fintype κ] [Fintype τ] [DecidableEq ι] [DecidableEq κ]
    [DecidableEq τ] [Fintype X] [CommSemiring R]
    (e : κ ⊕ τ ≃ ι) (μ : X → R) (F G : Multiset X → R) (D : (τ → X) → R) :
    (∑ x : ι → X, tupleWeight μ x * F (tupleBag x) *
      G (tupleBag ((tupleSplitEquiv e x).1)) * D ((tupleSplitEquiv e x).2)) =
    ∑ u : κ → X, ∑ v : τ → X,
      tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
        G (tupleBag u) * D v := by
  calc
    _ = ∑ uv : (κ → X) × (τ → X),
        tupleWeight μ uv.1 * tupleWeight μ uv.2 * F (tupleBag uv.1 + tupleBag uv.2) *
          G (tupleBag uv.1) * D uv.2 := by
      apply Fintype.sum_equiv (tupleSplitEquiv e)
      intro x
      rw [tupleWeight_split e μ x, tupleBag_split e x]
    _ = _ := Fintype.sum_prod_type _

/-- Tuple measure is invariant under any permutation of coordinates. -/
theorem tupleWeight_permute {ι X R : Type*} [Fintype ι] [CommMonoid R]
    (σ : Equiv.Perm ι) (μ : X → R) (x : ι → X) :
    tupleWeight μ (x ∘ σ) = tupleWeight μ x :=
  Equiv.prod_comp σ (fun i => μ (x i))

/-- Multiset test functions are symmetric under arbitrary tuple permutations. -/
theorem tupleBag_permute {ι X : Type*} [Fintype ι]
    (σ : Equiv.Perm ι) (x : ι → X) : tupleBag (x ∘ σ) = tupleBag x :=
  Equiv.sum_comp σ (fun i => ({x i} : Multiset X))

/-- Selected and surviving particle multisets use actual index subsets. -/
def selectedBag {ι X : Type*} [Fintype ι] (S : Finset ι) (x : ι → X) : Multiset X :=
  ∑ i : S, {x i}

def survivorBag {ι X : Type*} [Fintype ι] [DecidableEq ι] (S : Finset ι) (x : ι → X) : Multiset X :=
  ∑ i : {i : ι // i ∉ S}, {x i}

/-- Canonical coordinate enumerations are irrelevant to symmetric tests,
but give a precise equivalence for the finite sum reindexing. -/
def selectedIndexEquiv (k a : ℕ) (S : Finset (Fin (k + a))) (hS : S.card = a) :
    Fin a ≃ S := Fintype.equivOfCardEq (by simp [hS])

def survivorIndexEquiv (k a : ℕ) (S : Finset (Fin (k + a))) (hS : S.card = a) :
    Fin k ≃ {i : Fin (k + a) // i ∉ S} :=
  Fintype.equivOfCardEq (by rw [Fintype.card_subtype_compl]; simp [hS])

def deletionSplitEquiv (k a : ℕ) (S : Finset (Fin (k + a))) (hS : S.card = a) :
    Fin k ⊕ Fin a ≃ Fin (k + a) :=
  (Equiv.sumCongr (survivorIndexEquiv k a S hS) (selectedIndexEquiv k a S hS)).trans
    ((Equiv.sumComm _ _).trans (Equiv.sumCompl (fun i => i ∈ S)))

theorem deletionSplit_left_bag {X : Type*} (k a : ℕ)
    (S : Finset (Fin (k + a))) (hS : S.card = a) (x : Fin (k + a) → X) :
    tupleBag ((tupleSplitEquiv (deletionSplitEquiv k a S hS) x).1) = survivorBag S x := by
  change (∑ i : Fin k, {x (survivorIndexEquiv k a S hS i)}) = _
  exact Equiv.sum_comp (survivorIndexEquiv k a S hS) (fun i => ({x i} : Multiset X))

theorem deletionSplit_right_bag {X : Type*} (k a : ℕ)
    (S : Finset (Fin (k + a))) (hS : S.card = a) (x : Fin (k + a) → X) :
    tupleBag ((tupleSplitEquiv (deletionSplitEquiv k a S hS) x).2) = selectedBag S x := by
  change (∑ i : Fin a, {x (selectedIndexEquiv k a S hS i)}) = _
  exact Equiv.sum_comp (selectedIndexEquiv k a S hS) (fun i => ({x i} : Multiset X))

/-- Every actual indexed subset of a fixed size gives the same split
product-measure integral. No distinctness of particle values is required. -/
theorem indexed_subset_integral {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (S : Finset (Fin (k + a))) (hS : S.card = a)
    (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : Fin (k + a) → X, tupleWeight μ x * F (tupleBag x) *
      G (survivorBag S x) * D (selectedBag S x)) =
    ∑ u : Fin k → X, ∑ v : Fin a → X,
      tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
        G (tupleBag u) * D (tupleBag v) := by
  simpa only [deletionSplit_left_bag, deletionSplit_right_bag] using
    tuple_split_integral (deletionSplitEquiv k a S hS) μ F G D

/-- Deletion really sums over subsets of the old coordinate index set,
with repeated values still counted as different indexed choices. -/
def indexedDeletion {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (G D : Multiset X → R) (x : Fin (k + a) → X) : R :=
  ∑ S ∈ (Finset.univ : Finset (Fin (k + a))).powersetCard a,
    G (survivorBag S x) * D (selectedBag S x)

/-- The unnormalized birth/deletion adjoint identity for actual finite
particle sums. The binomial coefficient is proved from the number of
indexed subset choices, rather than supplied as an operator premise. -/
theorem indexed_deletion_integral {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : Fin (k + a) → X,
      tupleWeight μ x * F (tupleBag x) * indexedDeletion k a G D x) =
    ((k + a).choose a : R) *
      ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D (tupleBag v) := by
  unfold indexedDeletion
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  have hsum : ∀ S ∈ (Finset.univ : Finset (Fin (k + a))).powersetCard a,
      (∑ x : Fin (k + a) → X,
        tupleWeight μ x * F (tupleBag x) * (G (survivorBag S x) * D (selectedBag S x))) =
      ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D (tupleBag v) := by
    intro S hS
    simpa only [mul_assoc] using indexed_subset_integral k a S
      (Finset.mem_powersetCard.mp hS).2 μ F G D
  simp_rw [Finset.sum_congr rfl hsum]
  simp only [Finset.sum_const, Finset.card_powersetCard, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul]
  simp only [Finset.mul_sum]

/-- Select coordinates and order them into the prescribed target slots. -/
def orderedDeletionSplitEquiv (k a : ℕ) (S : Finset (Fin (k + a)))
    (hS : S.card = a) (σ : Equiv.Perm (Fin a)) : Fin k ⊕ Fin a ≃ Fin (k + a) :=
  (Equiv.sumCongr (Equiv.refl (Fin k)) σ).trans (deletionSplitEquiv k a S hS)

/-- Each ordered retrieval choice has the same integral after relabelling
its deleted coordinates into the prescribed ordered active slots. -/
theorem ordered_subset_integral {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (S : Finset (Fin (k + a))) (hS : S.card = a)
    (σ : Equiv.Perm (Fin a)) (μ : X → R) (F G : Multiset X → R)
    (D : (Fin a → X) → R) :
    (∑ x : Fin (k + a) → X, tupleWeight μ x * F (tupleBag x) *
      G (survivorBag S x) * D (fun j => x (selectedIndexEquiv k a S hS (σ j)))) =
    ∑ u : Fin k → X, ∑ v : Fin a → X,
      tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
        G (tupleBag u) * D v := by
  have h := tuple_split_integral_ordered (orderedDeletionSplitEquiv k a S hS σ) μ F G D
  have hleft (x : Fin (k + a) → X) :
      tupleBag ((tupleSplitEquiv (orderedDeletionSplitEquiv k a S hS σ) x).1) =
        survivorBag S x := deletionSplit_left_bag k a S hS x
  have hright (x : Fin (k + a) → X) :
      ((tupleSplitEquiv (orderedDeletionSplitEquiv k a S hS σ) x).2) =
        (fun j => x (selectedIndexEquiv k a S hS (σ j))) := by
    funext j
    rfl
  simpa only [hleft, hright] using h

/-- The actual finite set of indexed deletion subsets of size a. -/
abbrev DeletionSubsets (k a : ℕ) :=
  {S : Finset (Fin (k + a)) // S ∈ Finset.univ.powersetCard a}

/-- Retrieval into prescribed ordered slots enumerates every selected
index subset and every ordering of that subset. The output test need not
be symmetric in those active slots. -/
def indexedOrderedRetrieval {X R : Type*} [Fintype X] [CommSemiring R]
    (k a : ℕ) (G : Multiset X → R) (D : (Fin a → X) → R)
    (x : Fin (k + a) → X) : R :=
  ∑ S : DeletionSubsets k a, ∑ σ : Equiv.Perm (Fin a),
    G (survivorBag S.val x) * D (fun j => x
      (selectedIndexEquiv k a S.val (Finset.mem_powersetCard.mp S.property).2 (σ j)))

/-- Actual ordered retrieval has choose(k+a,a)*a! indexed choices, with
its complete product-measure integral explicitly retained. -/
theorem indexed_ordered_retrieval_integral {X R : Type*}
    [Fintype X] [CommSemiring R]
    (k a : ℕ) (μ : X → R) (F G : Multiset X → R) (D : (Fin a → X) → R) :
    (∑ x : Fin (k + a) → X,
      tupleWeight μ x * F (tupleBag x) * indexedOrderedRetrieval k a G D x) =
    (((k + a).choose a : R) * (a.factorial : R)) *
      ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D v := by
  unfold indexedOrderedRetrieval
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  have hsum (S : DeletionSubsets k a) :
      (∑ x : Fin (k + a) → X, ∑ σ : Equiv.Perm (Fin a),
        tupleWeight μ x * F (tupleBag x) * (G (survivorBag S.val x) *
          D (fun j => x (selectedIndexEquiv k a S.val
            (Finset.mem_powersetCard.mp S.property).2 (σ j))))) =
      (a.factorial : R) * ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D v := by
    rw [Finset.sum_comm]
    have hi (σ : Equiv.Perm (Fin a)) := ordered_subset_integral k a S.val
      (Finset.mem_powersetCard.mp S.property).2 σ μ F G D
    simp_rw [← mul_assoc, hi]
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_perm,
      Fintype.card_fin, nsmul_eq_mul]
  simp_rw [hsum]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have hc : Fintype.card (DeletionSubsets k a) = (k + a).choose a := by
    simp [DeletionSubsets]
  rw [hc]
  simp only [Finset.mul_sum, mul_assoc]

/-- The actual bijection of tuple coordinates used in batch symmetrization. -/
def tuplePermuteEquiv {ι X : Type*} (σ : Equiv.Perm ι) : (ι → X) ≃ (ι → X) where
  toFun x := x ∘ σ
  invFun x := x ∘ σ.symm
  left_inv x := by funext i; simp
  right_inv x := by funext i; simp

/-- A local multiplier can be relabelled on the fresh tuple coordinates
inside a symmetric continuation integral, without changing that integral. -/
theorem tuple_permutation_integral {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [Fintype X] [CommSemiring R]
    (σ : Equiv.Perm ι) (μ : X → R) (F : Multiset X → R) (A : (ι → X) → R) :
    (∑ x : ι → X, tupleWeight μ x * F (tupleBag x) * A (x ∘ σ)) =
      ∑ x : ι → X, tupleWeight μ x * F (tupleBag x) * A x := by
  apply Fintype.sum_equiv (tuplePermuteEquiv σ)
  intro x
  change _ = tupleWeight μ (x ∘ σ) * F (tupleBag (x ∘ σ)) * A (x ∘ σ)
  rw [tupleWeight_permute, tupleBag_permute]

/-- Arithmetic mean over all permutations of fresh-batch coordinates. -/
def tupleSymmetrize {ι X R : Type*} [Fintype ι] [DecidableEq ι] [Field R]
    (A : (ι → X) → R) (x : ι → X) : R :=
  (∑ σ : Equiv.Perm ι, A (x ∘ σ)) / (Fintype.card (Equiv.Perm ι) : R)

/-- Averaging a local fresh-batch multiplier over its coordinates leaves
its actual product-measure integral against a symmetric continuation
unchanged. No exchangeability or adjoint statement is assumed. -/
theorem tuple_symmetrize_integral {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [Fintype X] [Field R] [CharZero R]
    (μ : X → R) (F : Multiset X → R) (A : (ι → X) → R) :
    (∑ x : ι → X, tupleWeight μ x * F (tupleBag x) * tupleSymmetrize A x) =
      ∑ x : ι → X, tupleWeight μ x * F (tupleBag x) * A x := by
  have hc : (Fintype.card (Equiv.Perm ι) : R) ≠ 0 :=
    Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  unfold tupleSymmetrize
  simp only [Finset.sum_div, Finset.mul_sum]
  rw [Finset.sum_comm]
  simp_rw [← mul_div_assoc, ← Finset.sum_div, tuple_permutation_integral]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp

/-- Symmetry on the actual ordered tensor space. -/
def SymmetricTupleFunction {ι X R : Type*} (F : (ι → X) → R) : Prop :=
  ∀ (σ : Equiv.Perm ι) (x : ι → X), F (x ∘ σ) = F x

/-- Relabelling a fresh tuple preserves integration against any symmetric
continuation, without requiring a representation by a multiset function. -/
theorem tuple_permutation_integral_of_symmetric {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [Fintype X] [CommSemiring R]
    (σ : Equiv.Perm ι) (μ : X → R) (F A : (ι → X) → R)
    (hF : SymmetricTupleFunction F) :
    (∑ x : ι → X, tupleWeight μ x * F x * A (x ∘ σ)) =
      ∑ x : ι → X, tupleWeight μ x * F x * A x := by
  apply Fintype.sum_equiv (tuplePermuteEquiv σ)
  intro x
  change _ = tupleWeight μ (x ∘ σ) * F (x ∘ σ) * A (x ∘ σ)
  rw [tupleWeight_permute, hF]

/-- Exact averaging invariance for arbitrary symmetric continuations. -/
theorem tuple_symmetrize_integral_of_symmetric {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [Fintype X] [Field R] [CharZero R]
    (μ : X → R) (F A : (ι → X) → R) (hF : SymmetricTupleFunction F) :
    (∑ x : ι → X, tupleWeight μ x * F x * tupleSymmetrize A x) =
      ∑ x : ι → X, tupleWeight μ x * F x * A x := by
  have hc : (Fintype.card (Equiv.Perm ι) : R) ≠ 0 :=
    Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  unfold tupleSymmetrize
  simp only [Finset.sum_div, Finset.mul_sum]
  rw [Finset.sum_comm]
  simp_rw [← mul_div_assoc, ← Finset.sum_div,
    tuple_permutation_integral_of_symmetric _ μ F A hF]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp

/-- The averaged multiplier itself preserves symmetry of the tuple. -/
theorem tupleSymmetrize_symmetric {ι X R : Type*}
    [Fintype ι] [DecidableEq ι] [Field R] (A : (ι → X) → R) :
    SymmetricTupleFunction (tupleSymmetrize A) := by
  intro τ x
  unfold tupleSymmetrize
  congr 1
  exact Equiv.sum_comp (Equiv.mulLeft τ) (fun σ : Equiv.Perm ι => A (x ∘ σ))

/-- Averaging a complex fresh-batch multiplier cannot increase its bound
one. This is the precise local multiplier restriction used by the source. -/
theorem norm_tupleSymmetrize_le_one {ι X : Type*}
    [Fintype ι] [DecidableEq ι] (A : (ι → X) → ℂ) (x : ι → X)
    (hA : ∀ σ : Equiv.Perm ι, ‖A (x ∘ σ)‖ ≤ 1) :
    ‖tupleSymmetrize A x‖ ≤ 1 := by
  have hc : (0 : ℝ) < Fintype.card (Equiv.Perm ι) := by
    exact_mod_cast Fintype.card_pos
  unfold tupleSymmetrize
  rw [norm_div, Complex.norm_natCast]
  apply (div_le_one hc).mpr
  calc
    _ ≤ ∑ σ : Equiv.Perm ι, ‖A (x ∘ σ)‖ := norm_sum_le _ _
    _ ≤ ∑ _σ : Equiv.Perm ι, (1 : ℝ) := Finset.sum_le_sum (fun σ _ => hA σ)
    _ = _ := by simp

/-- Source (4.17): unordered indexed deletion choices exactly match the
factorial measure of a fresh ordered batch. -/
theorem factorial_unordered_deletion {R : Type*} [Field R] [CharZero R] (k a : ℕ) :
    ((k + a).choose a : R) / ((k + a).factorial : R) =
      1 / ((k.factorial : R) * (a.factorial : R)) := by
  have h := Nat.add_choose_mul_factorial_mul_factorial k a
  have hcast : ((k + a).choose a : R) * (k.factorial : R) * (a.factorial : R) =
      ((k + a).factorial : R) := by exact_mod_cast h
  have hk : (k.factorial : R) ≠ 0 := Nat.cast_ne_zero.mpr k.factorial_ne_zero
  have ha : (a.factorial : R) ≠ 0 := Nat.cast_ne_zero.mpr a.factorial_ne_zero
  apply (div_eq_iff (Nat.cast_ne_zero.mpr (k + a).factorial_ne_zero)).mpr
  rw [← hcast]
  field_simp

/-- Source (4.18): ordering the retrieved batch cancels its factorial. -/
theorem factorial_ordered_retrieval {R : Type*} [Field R] [CharZero R] (k a : ℕ) :
    (((k + a).choose a : R) * (a.factorial : R)) / ((k + a).factorial : R) =
      1 / (k.factorial : R) := by
  have ha : (a.factorial : R) ≠ 0 := Nat.cast_ne_zero.mpr a.factorial_ne_zero
  have hk : (k.factorial : R) ≠ 0 := Nat.cast_ne_zero.mpr k.factorial_ne_zero
  calc
    _ = (a.factorial : R) * (((k + a).choose a : R) / ((k + a).factorial : R)) := by ring
    _ = (a.factorial : R) * (1 / ((k.factorial : R) * (a.factorial : R))) := by
      rw [factorial_unordered_deletion]
    _ = _ := by field_simp

/-- The complete finite-sum identity with the source's factorial memory
measure. This is the unordered birth/deletion adjoint pairing, including the
actual tuple coordinates, actual subset choices, and both factorials. -/
theorem factorial_indexed_deletion_integral {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (k a : ℕ) (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : Fin (k + a) → X,
      tupleWeight μ x * F (tupleBag x) * indexedDeletion k a G D x) /
        ((k + a).factorial : R) =
    (1 / (k.factorial : R)) * (1 / (a.factorial : R)) *
      ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D (tupleBag v) := by
  rw [indexed_deletion_integral]
  rw [show ∀ T : R, ((k + a).choose a : R) * T / ((k + a).factorial : R) =
      (((k + a).choose a : R) / ((k + a).factorial : R)) * T by intro T; ring]
  rw [factorial_unordered_deletion]
  ring

/-- The actual ordered fresh-batch integral, with its factorial measure. -/
def memoryBirthIntegral {X R : Type*} [Fintype X] [Field R]
    (a : ℕ) (μ : X → R) (D F : Multiset X → R) (survivors : Multiset X) : R :=
  (∑ v : Fin a → X,
    tupleWeight μ v * D (tupleBag v) * F (survivors + tupleBag v)) / (a.factorial : R)

/-- Rearranged adjoint form: deleting an indexed batch from the old memory
is adjoint, for factorial tensor measure, to appending an integrated batch.
No distinctness condition on particle values occurs anywhere. -/
theorem memory_birth_deletion_adjoint {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (k a : ℕ) (μ : X → R) (F G D : Multiset X → R) :
    (∑ x : Fin (k + a) → X,
      tupleWeight μ x * F (tupleBag x) * indexedDeletion k a G D x) /
        ((k + a).factorial : R) =
    (∑ u : Fin k → X, tupleWeight μ u * G (tupleBag u) *
      memoryBirthIntegral a μ D F (tupleBag u)) / (k.factorial : R) := by
  rw [factorial_indexed_deletion_integral]
  unfold memoryBirthIntegral
  simp only [Finset.mul_sum, Finset.sum_div, mul_div_assoc]
  apply Finset.sum_congr rfl
  intro u _
  apply Finset.sum_congr rfl
  intro v _
  ring

/-- Source (4.18) with the actual ordered-slot tensor sums. Retrieval
cancels the factorial of the selected batch exactly. -/
theorem memory_ordered_retrieval_adjoint {X R : Type*}
    [Fintype X] [Field R] [CharZero R]
    (k a : ℕ) (μ : X → R) (F G : Multiset X → R) (D : (Fin a → X) → R) :
    (∑ x : Fin (k + a) → X,
      tupleWeight μ x * F (tupleBag x) * indexedOrderedRetrieval k a G D x) /
        ((k + a).factorial : R) =
    (1 / (k.factorial : R)) *
      ∑ u : Fin k → X, ∑ v : Fin a → X,
        tupleWeight μ u * tupleWeight μ v * F (tupleBag u + tupleBag v) *
          G (tupleBag u) * D v := by
  rw [indexed_ordered_retrieval_integral]
  rw [show ∀ T : R, (((k + a).choose a : R) * (a.factorial : R)) * T /
      ((k + a).factorial : R) =
      ((((k + a).choose a : R) * (a.factorial : R)) / ((k + a).factorial : R)) * T
      by intro T; ring]
  rw [factorial_ordered_retrieval]

end Elliptic.Operator
