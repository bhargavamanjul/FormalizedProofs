module
public import Elliptic.Operator.MomentParameters

/-! Absorption of the actual common-label exponential saving, including
the divisor progression logarithm and arbitrary fixed logarithmic losses. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedCollisionAsymptotics
open Filter

theorem eventually_rpow_exp_loss (T B A : ℝ) :
    ∀ᶠ L : ℝ in atTop,T*L^B*Real.exp (-L^(1/10:ℝ))≤L^(-A) := by
  have hlim : Tendsto (fun L : ℝ=>T*(L^(B+A)*Real.exp (-L^(1/10:ℝ)))) atTop (nhds 0) := by
    simpa only [neg_mul,one_mul,mul_zero] using
      (tendsto_power_mul_exp_neg_rpow (B+A) (by norm_num : (0:ℝ)<1)
        (by norm_num : (0:ℝ)<1/10)).const_mul T
  filter_upwards [eventually_gt_atTop (0:ℝ),hlim.eventually_lt_const (by norm_num : (0:ℝ)<1)] with L hL hh
  apply (mul_le_mul_iff_left₀ (Real.rpow_pos_of_pos hL A)).mp
  calc
    _ = T*(L^(B+A)*Real.exp (-L^(1/10:ℝ))) := by rw [Real.rpow_add hL]; ring
    _ ≤ 1 := hh.le
    _ = L^(-A)*L^A := by rw [←Real.rpow_add hL]; simp

theorem eventually_collision_log_loss (T B A : ℝ) (hT : 0≤T) :
    ∀ᶠ x : ℝ in atTop,
      T*(Real.log x)^B*(1+Real.log (8*x))^3*Real.exp (-(Real.log x)^(1/10:ℝ))≤
        (Real.log x)^(-A) := by
  let C := 2+Real.log 8
  have hC : 0≤C := by dsimp [C]; have := Real.log_nonneg (by norm_num : (1:ℝ)≤8); linarith
  filter_upwards [Real.tendsto_log_atTop.eventually (eventually_rpow_exp_loss (T*C^3) (B+3) A),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),eventually_gt_atTop (0:ℝ)] with x hh hL hx
  have hLp : 0<Real.log x := by linarith
  have hlog : 0≤1+Real.log (8*x) ∧ 1+Real.log (8*x)≤C*Real.log x := by
    rw [Real.log_mul (by norm_num : (8:ℝ)≠0) hx.ne']
    have h8 : 0≤Real.log 8 := Real.log_nonneg (by norm_num)
    dsimp [C]
    constructor
    · linarith
    · nlinarith [mul_le_mul_of_nonneg_left hL h8]
  calc
    _ ≤ T*(Real.log x)^B*(C*Real.log x)^3*Real.exp (-(Real.log x)^(1/10:ℝ)) := by
      apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlog.1 hlog.2 3) (by positivity)
    _ = (T*C^3)*(Real.log x)^(B+3)*Real.exp (-(Real.log x)^(1/10:ℝ)) := by
      rw [Real.rpow_add hLp,Real.rpow_ofNat]
      ring
    _ ≤ _ := hh

end Elliptic.Operator.SignedCollisionAsymptotics
