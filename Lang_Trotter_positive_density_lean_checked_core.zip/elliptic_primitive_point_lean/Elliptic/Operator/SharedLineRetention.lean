module

public import Elliptic.Operator.SourceMemoryEdges

/-!
# Shared active primes retain their actual residue lines

Primitivity excludes the zero residue vector. Consequently determinant
divisibility is equivalent to equality of the actual projective anchors.
The shared pad condition therefore transports a shared prime's line across
an actual physical edge. No global history identity is assumed here.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

/-- At a primitive integer position, the first residue coordinate cannot
also vanish when the second coordinate does. -/
theorem primitive_first_residue_ne_zero (p : ℕ) [Fact p.Prime]
    (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) (hz₂ : (z.2 : ZMod p) = 0) :
    (z.1 : ZMod p) ≠ 0 := by
  intro hz₁
  obtain ⟨a, b, hab⟩ := hz
  have h : (a : ZMod p) * (z.1 : ZMod p) +
      (b : ZMod p) * (z.2 : ZMod p) = 1 := by
    simpa only [Int.cast_add, Int.cast_mul, Int.cast_one] using
      congrArg (fun t : ℤ => (t : ZMod p)) hab
  simp [hz₁, hz₂] at h

/-- For primitive endpoints, vanishing determinant forces equality of the
literal anchors, including the line at infinity. -/
theorem primeResidueAnchor_eq_of_det_zero (p : ℕ) [Fact p.Prime]
    (z w : ℤ × ℤ) (hz : IsCoprime z.1 z.2) (hw : IsCoprime w.1 w.2)
    (hdet : (latticeDet z w : ZMod p) = 0) :
    primeResidueAnchor p z = primeResidueAnchor p w := by
  have hd : (z.1 : ZMod p) * (w.2 : ZMod p) -
      (z.2 : ZMod p) * (w.1 : ZMod p) = 0 := by
    simpa only [latticeDet, Int.cast_sub, Int.cast_mul] using hdet
  by_cases hz₂ : (z.2 : ZMod p) = 0
  · have hz₁ := primitive_first_residue_ne_zero p z hz hz₂
    have hw₂ : (w.2 : ZMod p) = 0 := by
      simpa only [hz₂, zero_mul, sub_zero, mul_eq_zero, hz₁, false_or] using hd
    simp [primeResidueAnchor, hz₂, hw₂]
  · by_cases hw₂ : (w.2 : ZMod p) = 0
    · have hw₁ := primitive_first_residue_ne_zero p w hw hw₂
      simp [hw₂, hz₂, hw₁] at hd
    · simp only [primeResidueAnchor, hz₂, hw₂, ite_false, Option.some.injEq]
      field_simp
      linear_combination hd

/-- The shared-line condition is exactly determinant divisibility when
both integer endpoints are primitive. -/
theorem primeResidueAnchor_eq_iff_dvd_det (p : ℕ) [Fact p.Prime]
    (z w : ℤ × ℤ) (hz : IsCoprime z.1 z.2) (hw : IsCoprime w.1 w.2) :
    primeResidueAnchor p z = primeResidueAnchor p w ↔ (p : ℤ) ∣ latticeDet z w := by
  rw [← ZMod.intCast_zmod_eq_zero_iff_dvd]
  exact ⟨primeResidueAnchor_eq_det_zero p z w,
    primeResidueAnchor_eq_of_det_zero p z w hz hw⟩

section SharedPad
variable {I : Type*} [Fintype I] {P : I → Type*} {J : ℕ}

/-- Each prescribed shared slot is a genuine factor of the whole pad. -/
theorem shared_label_dvd_sourcePadProduct (value : ∀ i, P i → ℕ)
    (a : PhysicalActiveLists P J) (i : I) (j : Fin J) :
    value i (a i j.castSucc) ∣ sourcePadProduct value a := by
  exact (Finset.dvd_prod_of_mem (fun k : Fin J => value i (a i k.castSucc))
    (Finset.mem_univ j)).trans
      (Finset.dvd_prod_of_mem (fun k : I => ∏ l : Fin J, value k (a k l.castSucc))
        (Finset.mem_univ i))

/-- A literal allowed source edge preserves the line of every shared prime.
This uses the actual pad divisibility and primitive endpoint conditions. -/
theorem sourcePhysicalEdgeAllowed_sharedLine (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (h : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b)
    (i : I) (j : Fin J) [Fact (value i (a i j.castSucc)).Prime] :
    primeResidueAnchor (value i (a i j.castSucc)) z =
      primeResidueAnchor (value i (a i j.castSucc)) w := by
  rcases h with ⟨hz, hw, _, _, _, _, _, hdet⟩
  apply (primeResidueAnchor_eq_iff_dvd_det _ z w hz.1 hw.1).mpr
  have hpad : (value i (a i j.castSucc) : ℤ) ∣ (sourcePadProduct value a : ℤ) := by
    exact_mod_cast shared_label_dvd_sourcePadProduct value a i j
  exact hpad.trans hdet

/-- The shared-line bridge applies on the actual support of the signed
geometric multiplier, for either integer shift sign. -/
theorem sourcePhysicalEdgeGeometry_nonzero_sharedLine (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (h : sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b ≠ 0)
    (i : I) (j : Fin J) [Fact (value i (a i j.castSucc)).Prime] :
    primeResidueAnchor (value i (a i j.castSucc)) z =
      primeResidueAnchor (value i (a i j.castSucc)) w := by
  have hallowed : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
    by_contra hn
    simp [sourcePhysicalEdgeGeometry, hn] at h
  exact sourcePhysicalEdgeAllowed_sharedLine value good u v r U W d₀ z w a b hallowed i j

/-- The actual alternating geometric multiplier preserves shared lines in
both orientations. This is a support statement, not a memory adjoint claim. -/
theorem orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint : Bool)
    (value : ∀ i, P i → ℕ) (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (h : orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ major σ
      z a w b ≠ 0)
    (i : I) (j : Fin J) [Fact (value i (a i j.castSucc)).Prime] :
    primeResidueAnchor (value i (a i j.castSucc)) z =
      primeResidueAnchor (value i (a i j.castSucc)) w := by
  cases adjoint with
  | false =>
    apply sourcePhysicalEdgeGeometry_nonzero_sharedLine value good
      u v r U W d₀ Y η ψ major σ z w a b _ i j
    simpa only [orientedSourceEdgeGeometry, Bool.false_eq_true, ite_false] using h
  | true =>
    have hg : sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ
        w b z a ≠ 0 := by
      simpa only [orientedSourceEdgeGeometry, ite_true, ne_eq, star_eq_zero] using h
    have hallowed : sourcePhysicalEdgeAllowed value good u v r U W d₀ w b z a := by
      by_contra hn
      simp [sourcePhysicalEdgeGeometry, hn] at hg
    have he : a i j.castSucc = b i j.castSucc := hallowed.2.2.2.2.1.1 i j
    have hp : (value i (a i j.castSucc)).Prime := Fact.out
    let : Fact (value i (b i j.castSucc)).Prime := ⟨by simpa only [he] using hp⟩
    have hs := (sourcePhysicalEdgeAllowed_sharedLine value good
      u v r U W d₀ w z b a hallowed i j).symm
    exact Eq.mpr (congrArg (fun p : ℕ => primeResidueAnchor p z = primeResidueAnchor p w)
      (congrArg (value i) he)) hs

end SharedPad

end Elliptic.Operator
