module

public import Elliptic.Operator.PhysicalPivotHistory

/-! # Initial active draws with earlier prescribed pivots -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalPivotInitialDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I : Type} [Fintype I] {J B : ℕ}

def InitialPrecedes (i:I) (k:ℕ) (a:Address I J B) : Prop :=
  ∃l:Fin (J+1),l.val<k ∧ a=.inl (i,l)

/-- The initial named coordinates and pivots are fixed before drawing labels. -/
structure InitialPlan (I : Type) (J B : ℕ) where
  pivot : Address I J B → Address I J B
  slots : I → Finset ℕ
  bounded : ∀i,slots i⊆Finset.range (J+1)
  earlier : ∀i k (hk:k∈slots i),InitialPrecedes i k
    (pivot (.inl (i,⟨k,Finset.mem_range.mp (bounded i hk)⟩)))

/-- Read an earlier coordinate from the initial ordered tuple. -/
def lookupInitial (i:I) {k:ℕ} (earlier:Fin k → ℕ) : Address I J B → ℕ
  | .inl a => if a.1=i then if h:a.2.val<k then earlier ⟨a.2.val,h⟩ else 0 else 0
  | .inr _ => 0

theorem lookupInitial_current (i:I) {k:ℕ} (earlier:Fin k → ℕ) (l:Fin (J+1)) (hl:l.val<k) :
    lookupInitial (B:=B) i earlier (.inl (i,l))=earlier ⟨l.val,hl⟩ := by simp [lookupInitial,hl]

variable {P : I → Type} [∀i,Fintype (P i)]

def InitialPlan.target (value:∀i,P i → ℕ) (plan:InitialPlan I J B)
    (i:I) (k:ℕ) (earlier:Fin k → P i) : ℕ :=
  if hk:k<J+1 then lookupInitial i (fun l=>value i (earlier l))
    (plan.pivot (.inl (i,⟨k,hk⟩))) else 0

def InitialPlan.Allowed (value:∀i,P i → ℕ) (plan:InitialPlan I J B)
    (a:PhysicalActiveLists P J) : Prop :=
  ∀i,PrescribedPrimeTuple.Allowed (value i) (plan.slots i) (plan.target value i) (a i)

/-- Completed initial-label equalities imply the causal tuple restriction. -/
theorem initial_allowed (value:∀i,P i → ℕ) (plan:InitialPlan I J B)
    (a:PhysicalActiveLists P J) (f:Registry I J B)
    (hf:∀i k,f (.inl (i,k))=some (value i (a i k)))
    (hequal:∀i k (hk:k∈plan.slots i),∃v,
      f (.inl (i,⟨k,Finset.mem_range.mp (plan.bounded i hk)⟩))=some v ∧
      f (plan.pivot (.inl (i,⟨k,Finset.mem_range.mp (plan.bounded i hk)⟩)))=some v) :
    plan.Allowed value a := by
  intro i k hk
  have hkJ:k.val<J+1:=k.isLt
  obtain ⟨v,hv,hpv⟩:=hequal i k.val hk
  have hvalue:value i (a i k)=v:=by simpa only [hf,Option.some.injEq] using hv
  obtain ⟨l,hl,hpivot⟩:=plan.earlier i k.val hk
  have hpvalue:value i (a i l)=v:=by simpa only [hpivot,hf,Option.some.injEq] using hpv
  rw [hvalue]
  unfold InitialPlan.target
  rw [dite_eq_left hkJ,hpivot,lookupInitial_current i _ l hl]
  exact hpvalue.symm

/-- Initial product prime mass with the exact named-coordinate atom saving. -/
theorem initial_mass_le (ν:∀i,P i → ℝ) (value:∀i,P i → ℕ)
    (hinj:∀i,Function.Injective (value i)) (plan:InitialPlan I J B) (Δ:ℝ)
    (hν:∀i p,0≤ν i p) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ) :
    (∑a:PhysicalActiveLists P J,if plan.Allowed value a then ∏i,tupleWeight (ν i) (a i) else 0) ≤
      Δ^(∑i,(plan.slots i).card) * ∏i,(∑p,ν i p)^((J+1)-(plan.slots i).card) := by
  let F:=fun i (a:Fin (J+1) → P i)=>
    if PrescribedPrimeTuple.Allowed (value i) (plan.slots i) (plan.target value i) a
    then tupleWeight (ν i) a else 0
  have he:(∑a:PhysicalActiveLists P J,if plan.Allowed value a then ∏i,tupleWeight (ν i) (a i) else 0)=
      ∏i,∑a:Fin (J+1) → P i,F i a := by
    rw [Fintype.prod_sum]
    apply Finset.sum_congr rfl
    intro a _
    by_cases ha:plan.Allowed value a
    · simp only [ite_eq_left ha]
      apply Finset.prod_congr rfl
      intro i _
      exact (ite_eq_left (ha i)).symm
    · rw [ite_eq_right ha]
      symm
      have hn:∃i,¬PrescribedPrimeTuple.Allowed (value i) (plan.slots i) (plan.target value i) (a i):=by
        simpa only [InitialPlan.Allowed,not_forall] using ha
      obtain ⟨i,hi⟩:=hn
      exact Finset.prod_eq_zero (Finset.mem_univ i) (ite_eq_right hi)
  rw [he]
  calc
    _ ≤ ∏i,Δ^(plan.slots i).card*(∑p,ν i p)^((J+1)-(plan.slots i).card) := by
      apply Finset.prod_le_prod₀
      · intro i _
        apply Finset.sum_nonneg
        intro a _
        dsimp [F]
        split_ifs
        · exact Finset.prod_nonneg (fun k _=>hν i (a k))
        · exact le_rfl
      · intro i _
        exact PrescribedPrimeTuple.sum_le_atoms (ν i) (value i) (hinj i) (plan.slots i)
          (plan.target value i) Δ (hν i) hΔ (hatom i) (J+1) (plan.bounded i)
    _ = _ := by rw [Finset.prod_mul_distrib,Finset.prod_pow_eq_pow_sum]

end Elliptic.Operator.PhysicalBirthRegistry
