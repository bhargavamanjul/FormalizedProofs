module
public import Elliptic.Operator.CleanNormAsymptotics

/-! Every fixed polynomial row loss is absorbed by the literal fresh
prime atom saving. The major-arc exponent is already chosen at this step. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open Filter

/-- A single threshold for the coincidence-ban budget after fixing the
major-arc exponent and the group/band constants. -/
theorem eventually_clean_ban_atom_saving (D B G : ℝ) :
    ∀ᶠ L : ℝ in atTop, D*(1+L^B)*Real.exp (-L^(1/10:ℝ))≤L^(-G) := by
  have h₁ := tendsto_power_mul_exp_neg_rpow G (show (0:ℝ)<1 by norm_num)
    (show (0:ℝ)<1/10 by norm_num)
  have h₂ := tendsto_power_mul_exp_neg_rpow (B+G) (show (0:ℝ)<1 by norm_num)
    (show (0:ℝ)<1/10 by norm_num)
  have hlim : Tendsto (fun L : ℝ => D*(L^G*Real.exp (-L^(1/10:ℝ))+
      L^(B+G)*Real.exp (-L^(1/10:ℝ)))) atTop (nhds 0) := by
    simpa only [neg_mul,one_mul,zero_add,mul_zero] using (h₁.add h₂).const_mul D
  filter_upwards [eventually_gt_atTop (0:ℝ),hlim.eventually_lt_const (show (0:ℝ)<1 by norm_num)] with L hL h
  apply (mul_le_mul_iff_left₀ (Real.rpow_pos_of_pos hL G)).mp
  calc
    (D*(1+L^B)*Real.exp (-L^(1/10:ℝ)))*L^G =
        D*(L^G*Real.exp (-L^(1/10:ℝ))+L^(B+G)*Real.exp (-L^(1/10:ℝ))) := by
      rw [Real.rpow_add hL]
      ring
    _ ≤ 1 := h.le
    _ = L^(-G)*L^G := by rw [← Real.rpow_add hL]; simp

end Elliptic.Operator
