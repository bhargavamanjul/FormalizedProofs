module
public import Mathlib.NumberTheory.Divisors
public import Mathlib.Data.Fintype.Pi
public import Mathlib.Tactic

/-! The elementary pointwise divisor-square inequality, by an explicit
injection of two divisors into ordered four-factor decompositions. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.DivisorFourFactors
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance factorDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

def fourFactors (n : ℕ) : Finset (Fin 4→ℕ) :=
  (Fintype.piFinset (fun _ : Fin 4=>Finset.Icc 1 n)).filter (fun f=>(∏i,f i)=n)

theorem mem_fourFactors (n : ℕ) (f : Fin 4→ℕ) :
    f∈fourFactors n ↔ (∀i,1≤f i ∧ f i≤n) ∧ (∏i,f i)=n := by
  simp only [fourFactors,Finset.mem_filter,Fintype.mem_piFinset,Finset.mem_Icc]

theorem mem_fourFactors_of_product {n : ℕ} (hn : 0<n) (f : Fin 4→ℕ)
    (hf : (∏i,f i)=n) : f∈fourFactors n := by
  apply (mem_fourFactors n f).mpr
  refine ⟨fun i=>?_,hf⟩
  have hd : f i∣n := hf ▸ Finset.dvd_prod_of_mem f (Finset.mem_univ i)
  have hp : f i≠0 := by intro h; have := hd; rw [h,zero_dvd_iff] at this; omega
  exact ⟨Nat.one_le_iff_ne_zero.mpr hp,Nat.le_of_dvd hn hd⟩

def divisorPairFactors (n : ℕ) (u v : ℕ) : Fin 4→ℕ :=
  ![u.gcd v,u/(u.gcd v),v/(u.gcd v),n/(u.lcm v)]

theorem divisorPairFactors_product {n u v : ℕ} (hn : 0<n) (hu : u∣n) (hv : v∣n) :
    (∏i,divisorPairFactors n u v i)=n := by
  have hu0 : u≠0 := by intro h; subst u; simp only [zero_dvd_iff] at hu; omega
  have hg : 0<u.gcd v := Nat.gcd_pos_of_pos_left v (Nat.pos_of_ne_zero hu0)
  have hgu : u.gcd v*(u/u.gcd v)=u := Nat.mul_div_cancel' (Nat.gcd_dvd_left u v)
  have hgv : u.gcd v*(v/u.gcd v)=v := Nat.mul_div_cancel' (Nat.gcd_dvd_right u v)
  have hl : u.gcd v*(u/u.gcd v)*(v/u.gcd v)=u.lcm v := by
    apply Nat.eq_of_mul_eq_mul_left hg
    calc
      _ = (u.gcd v*(u/u.gcd v))*(u.gcd v*(v/u.gcd v)) := by ring
      _ = u*v := by rw [hgu,hgv]
      _ = _ := (Nat.gcd_mul_lcm u v).symm
  have hln : u.lcm v∣n := Nat.lcm_dvd hu hv
  simp only [divisorPairFactors,Fin.prod_univ_succ,Matrix.cons_val_zero,Matrix.cons_val_succ,
    Fin.prod_univ_zero,mul_one]
  calc
    _ = (u.gcd v*(u/u.gcd v)*(v/u.gcd v))*(n/(u.lcm v)) := by ring
    _ = n := by rw [hl,Nat.mul_div_cancel' hln]

theorem divisorPairFactors_recover_left (n u v : ℕ) :
    divisorPairFactors n u v 0*divisorPairFactors n u v 1=u := by
  exact Nat.mul_div_cancel' (Nat.gcd_dvd_left u v)

theorem divisorPairFactors_recover_right (n u v : ℕ) :
    divisorPairFactors n u v 0*divisorPairFactors n u v 2=v := by
  exact Nat.mul_div_cancel' (Nat.gcd_dvd_right u v)

theorem divisorPairFactors_injective (n : ℕ) :
    Function.Injective (fun uv : ℕ×ℕ=>divisorPairFactors n uv.1 uv.2) := by
  intro uv wz h
  apply Prod.ext
  · have hh := congrArg (fun f : Fin 4→ℕ=>f 0*f 1) h
    simpa only [divisorPairFactors_recover_left] using hh
  · have hh := congrArg (fun f : Fin 4→ℕ=>f 0*f 2) h
    simpa only [divisorPairFactors_recover_right] using hh

/-- No average divisor estimate is used here. -/
theorem divisor_square_le_fourFactors (n : ℕ) :
    n.divisors.card^2≤(fourFactors n).card := by
  by_cases hn : n=0
  · subst n; simp
  have hpos := Nat.pos_of_ne_zero hn
  have hc := Finset.card_le_card_of_injOn (s:=n.divisors×ˢn.divisors) (t:=fourFactors n)
    (fun uv : ℕ×ℕ=>divisorPairFactors n uv.1 uv.2)
    (fun uv huv=>mem_fourFactors_of_product hpos _ (divisorPairFactors_product hpos
      (Nat.mem_divisors.mp (Finset.mem_product.mp huv).1).1
      (Nat.mem_divisors.mp (Finset.mem_product.mp huv).2).1))
    (divisorPairFactors_injective n).injOn
  simpa only [Finset.card_product,pow_two] using hc

end Elliptic.Operator.DivisorFourFactors
