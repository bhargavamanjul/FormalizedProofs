module

public import Elliptic.Operator.PhysicalPhasedGhostNorm
public import Elliptic.Operator.PhysicalBagMeasure

/-! Fresh-slot ghost phases preserve the physical memory bag subspace. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedGhostBags
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel PhysicalBirthFactors PhysicalPhasedWord
attribute [local instance] Classical.propDecidable
local instance phasedGhostBagsDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {P : Type*} [Fintype P] {Line : P→Type*} {B:ℕ}

def bagApply (ν:P→ℂ) (d r b:ℂ) (anchor:∀p,Line p)
    (A:MemoryState P B→ℂ) (F:Multiset (AnchoredParticle P Line)→ℂ)
    (u:Multiset (AnchoredParticle P Line)):ℂ :=
  bagDeletion (anchorBatch anchor d) (fun v=>bagSurvival anchor r v *
    ∑fresh:MemoryState P B,if v.card+fresh.size≤B then
      (b^fresh.size*tupleWeight ν fresh.values/(fresh.size.factorial:ℂ))*A fresh*
        F (v+tupleBag (fun k=>anchorPrime anchor (fresh.values k))) else 0) u

theorem bagApply_eq_choices (ν:P→ℝ) (V η q ρ:ℝ) (anchor:∀p,Line p)
    (A:MemoryState P B→ℂ) (F:Multiset (AnchoredParticle P Line)→ℂ)
    (m:MemoryState (AnchoredParticle P Line) B) :
    bagApply (fun p=>(ν p:ℂ)) ((-η/ρ:ℝ):ℂ) ((q/ρ^2:ℝ):ℂ) ((-η*V/ρ:ℝ):ℂ)
      anchor A F (tupleBag m.values)=
    ∑c:GhostChoice m,if hc:GhostChoice.Valid anchor m c then
      A c.2*(ghostChoiceWeight ν V η q ρ anchor m c:ℂ)*
        F (tupleBag (ghostOutput anchor m c hc).values) else 0 := by
  unfold bagApply
  rw [bagDeletion_eq_indexed,Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro S _
  simp only [anchorBatch,bagHits_selectedBag,selectedBag_card]
  by_cases hhit:S⊆memoryHits anchor m
  · rw [ite_eq_left hhit]
    simp only [ghostOutput_tupleBag,GhostChoice.Valid,hhit,true_and,
      Finset.card_compl,Fintype.card_fin,dite_eq_ite,
      bagSurvival,survivorBag_hits_card,survivorBag_card]
    rw [Finset.mul_sum,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro fresh _
    split_ifs
    · simp only [ghostChoiceWeight,Complex.ofReal_div,Complex.ofReal_mul,
        Complex.ofReal_pow,Complex.ofReal_natCast,tupleWeight,Complex.ofReal_prod]
      ring
    · simp
  · rw [ite_eq_right hhit,mul_zero]
    symm
    apply Finset.sum_eq_zero
    intro fresh _
    have hn:¬GhostChoice.Valid anchor m (S,fresh):=fun h=>hhit h.1
    exact dite_eq_right hn

variable [∀p,Fintype (Line p)]

def localKernel (ν:P→ℝ) (V η q ρ:ℝ) (anchor:∀p,Line p)
    (A:MemoryState P B→ℂ) (u v:MemoryBag (AnchoredParticle P Line) B):ℂ :=
  bagApply (fun p=>(ν p:ℂ)) ((-η/ρ:ℝ):ℂ) ((q/ρ^2:ℝ):ℂ) ((-η*V/ρ:ℝ):ℂ)
    anchor A (fun b=>if b=v.val then 1 else 0) u.val

theorem localKernel_eq_choices (ν:P→ℝ) (V η q ρ:ℝ) (anchor:∀p,Line p)
    (A:MemoryState P B→ℂ) (m:MemoryState (AnchoredParticle P Line) B)
    (v:MemoryBag (AnchoredParticle P Line) B):
    localKernel ν V η q ρ anchor A (memoryBagOf m) v=
      ∑c:GhostChoice m,(A c.2*ghostSignedCoefficient ν V η q ρ anchor m c)*
        (if memoryBagOf (ghostChoiceTarget anchor m c)=v then 1 else 0) := by
  rw [localKernel,show (memoryBagOf m).val=tupleBag m.values from rfl,bagApply_eq_choices]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc:GhostChoice.Valid anchor m c
  · simp only [dite_eq_left hc,ghostSignedCoefficient,ite_eq_left hc,
      ghostChoiceTarget,dite_eq_left hc]
    have he:memoryBagOf (ghostOutput anchor m c hc)=v ↔
        tupleBag (ghostOutput anchor m c hc).values=v.val:=Subtype.ext_iff
    simp only [he]
  · simp only [dite_eq_right hc,ghostSignedCoefficient,ite_eq_right hc,mul_zero,zero_mul]

section Grouped
variable {I Z : Type*} [Fintype I]
variable {P:I→Type*} [∀i,Fintype (P i)]
variable {Line:∀i,P i→Type*} [∀i p,Fintype (Line i p)] {J B:ℕ}

def tensorApply (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ)
    (anchor:∀i p,Line i p) (A:∀i,MemoryState (P i) B→ℂ)
    (F:Bags (P:=P) (Line:=Line) (B:=B)→ℂ) (m:PhysicalMemories P Line B):ℂ :=
  ∑c:∀i,GhostChoice (m i),
    (∏i,A i (c i).2*ghostSignedCoefficient (ν i) (V i) η q ρ (anchor i) (m i) (c i))*
      F (fun i=>memoryBagOf (ghostChoiceTarget (anchor i) (m i) (c i)))

theorem tensorApply_eq_kernel (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ)
    (anchor:∀i p,Line i p) (A:∀i,MemoryState (P i) B→ℂ)
    (F:Bags (P:=P) (Line:=Line) (B:=B)→ℂ) (m:PhysicalMemories P Line B):
    tensorApply ν V η q ρ anchor A F m=
      ∑b:Bags (P:=P) (Line:=Line) (B:=B),
        (∏i,localKernel (ν i) (V i) η q ρ (anchor i) (A i) (memoryBagOf (m i)) (b i))*F b:=by
  simp_rw [localKernel_eq_choices,Fintype.prod_sum,Finset.sum_mul]
  rw [Finset.sum_comm]
  unfold tensorApply
  apply Finset.sum_congr rfl
  intro c _
  simp_rw [Finset.prod_mul_distrib]
  have hd (b:Bags (P:=P) (Line:=Line) (B:=B)):
      (∏i,if memoryBagOf (ghostChoiceTarget (anchor i) (m i) (c i))=b i then (1:ℂ) else 0)=
      if (fun i=>memoryBagOf (ghostChoiceTarget (anchor i) (m i) (c i)))=b then 1 else 0:=
    product_coordinate_indicator _ b
  simp_rw [hd]
  simp [mul_ite]

def apply (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ) (anchor:Z→∀i p,Line i p)
    (A:∀i,MemoryState (P i) B→ℂ)
    (F:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)):ℂ :=
  ∑b:Bags (P:=P) (Line:=Line) (B:=B),
    (∏i,localKernel (ν i) (V i) η q ρ (anchor (position s) i) (A i) (bags s i) (b i))*
      (if (∑i,(b i).val.card)≤B then F (position s,active s,b) else 0)

theorem phasedApply_eq_tensor (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ)
    (anchor:Z→∀i p,Line i p) (A:∀i,MemoryState (P i) B→ℂ)
    (F:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s:PhysicalMemoryState (Z:=Z) P Line J B):
    phasedApply (physicalGhostOperation ν V η q ρ anchor)
      (fun _ c=>∏i,A i (c i).2) (fun t=>F (ofOrdered t)) s =
      tensorApply ν V η q ρ (anchor (s.position P Line J B)) A
        (fun b=>if (∑i,(b i).val.card)≤B then F (s.position P Line J B,s.active P Line J B,b) else 0)
        (s.memory P Line J B):=by
  unfold phasedApply
  rw [PhysicalBagMeasure.sum_subtype_zero]
  change (∑c:PhysicalGhostChoice s,if hc:c.Valid anchor s then
    (∏i,A i (c i).2)*physicalGhostChoiceWeight ν V η q ρ anchor s c*
      F (ofOrdered (c.output anchor s hc)) else 0)=_
  unfold tensorApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hl:∀i,GhostChoice.Valid (anchor (s.position P Line J B) i)
      (s.memory P Line J B i) (c i)
  · have hc:(∏i,A i (c i).2*ghostSignedCoefficient (ν i) (V i) η q ρ
        (anchor (s.position P Line J B) i) (s.memory P Line J B i) (c i))=
        (∏i,A i (c i).2)*physicalGhostChoiceWeight ν V η q ρ anchor s c:=by
      unfold physicalGhostChoiceWeight
      rw [←Finset.prod_mul_distrib]
      apply Finset.prod_congr rfl
      intro i _
      simp only [ghostSignedCoefficient,ite_eq_left (hl i)]
    rw [hc]
    have hout:(fun i=>memoryBagOf (ghostChoiceTarget (anchor (s.position P Line J B) i)
        (s.memory P Line J B i) (c i)))=
        fun i=>memoryBagOf (ghostOutput (anchor (s.position P Line J B) i)
          (s.memory P Line J B i) (c i) (hl i)):=by
      funext i
      simp only [ghostChoiceTarget,dite_eq_left (hl i)]
    rw [hout]
    by_cases ht:(∑i,c.outputSize i)≤B
    · have hv:c.Valid anchor s:=⟨hl,ht⟩
      rw [dite_eq_left hv]
      simp only [memoryBagOf_card,ghostOutput_size]
      change (∏i,A i (c i).2)*physicalGhostChoiceWeight ν V η q ρ anchor s c*
        F (ofOrdered (c.output anchor s hv))=
        (∏i,A i (c i).2)*physicalGhostChoiceWeight ν V η q ρ anchor s c*
        (if (∑i,c.outputSize i)≤B then _ else 0)
      rw [ite_eq_left ht]
      rfl
    · have hv:¬c.Valid anchor s:=fun h=>ht h.2
      rw [dite_eq_right hv]
      simp only [memoryBagOf_card,ghostOutput_size]
      change 0=(∏i,A i (c i).2)*physicalGhostChoiceWeight ν V η q ρ anchor s c*
        (if (∑i,c.outputSize i)≤B then _ else 0)
      rw [ite_eq_right ht,mul_zero]
  · obtain ⟨i,hi⟩:=not_forall.mp hl
    have hz:(∏i,A i (c i).2*ghostSignedCoefficient (ν i) (V i) η q ρ
        (anchor (s.position P Line J B) i) (s.memory P Line J B i) (c i))=0:=
      Finset.prod_eq_zero (Finset.mem_univ i) (by simp [ghostSignedCoefficient,hi])
    have hv:¬c.Valid anchor s:=fun h=>hi (h.1 i)
    rw [dite_eq_right hv,hz,zero_mul]

theorem phasedApply_eq_apply (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ)
    (anchor:Z→∀i p,Line i p) (A:∀i,MemoryState (P i) B→ℂ)
    (F:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s:PhysicalMemoryState (Z:=Z) P Line J B):
    phasedApply (physicalGhostOperation ν V η q ρ anchor)
      (fun _ c=>∏i,A i (c i).2) (fun t=>F (ofOrdered t)) s =
      apply ν V η q ρ anchor A F (ofOrdered s):=by
  rw [phasedApply_eq_tensor,tensorApply_eq_kernel]
  rfl

theorem exists_bagFunction_pullback
    (F:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ):
    ∃H:Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ,
      (fun t:PhysicalMemoryState (Z:=Z) P Line J B=>F (ofOrdered t))=physicalBagFunction H:=by
  let H:=fun z a (b:∀i,Multiset (AnchoredParticle (P i) (Line i)))=>
    if hb:∀i,b i∈memoryBagRange (AnchoredParticle (P i) (Line i)) B then
      F (z,a,fun i=>⟨b i,hb i⟩) else 0
  refine ⟨H,?_⟩
  funext t
  have ht:∀i,tupleBag (t.memory P Line J B i).values∈
      memoryBagRange (AnchoredParticle (P i) (Line i)) B:=fun i=>(memoryBagOf (t.memory P Line J B i)).property
  simp only [physicalBagFunction,H,dite_eq_left ht]
  rfl

theorem exists_phased_bagFunction (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ)
    (anchor:Z→∀i p,Line i p) (A:∀i,MemoryState (P i) B→ℂ)
    (H:Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ):
    ∃H':Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ,
      phasedApply (physicalGhostOperation ν V η q ρ anchor) (fun _ c=>∏i,A i (c i).2)
        (physicalBagFunction H)=physicalBagFunction H':=by
  let F:State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ:=
    fun t=>H (position t) (active t) (fun i=>(bags t i).val)
  obtain ⟨H',hH'⟩:=exists_bagFunction_pullback (apply ν V η q ρ anchor A F)
  refine ⟨H',?_⟩
  have hF:physicalBagFunction H=(fun t:PhysicalMemoryState (Z:=Z) P Line J B=>F (ofOrdered t)):=rfl
  rw [hF]
  funext t
  rw [phasedApply_eq_apply]
  exact congrFun hH' t

end Grouped

section ActualFactors
variable {I Z:Type} [Fintype I] [Fintype Z]
variable {P:I→Type} [∀i,Fintype (P i)]
variable {Line:∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B:ℕ}

def batchFactor (value:∀i,P i→ℕ) (G:I→Fin B→Option ℕ→ℂ)
    (i:I) (fresh:MemoryState (P i) B):ℂ:=
  ∏k:Fin B,G i k ((if hk:k.val<fresh.size then some (fresh.values ⟨k.val,hk⟩) else none).map (value i))

theorem ghostFactor_eq_batchFactor (value:∀i,P i→ℕ) (G:ℕ→I→Fin B→Option ℕ→ℂ)
    (j:ℕ) (s:PhysicalMemoryState (Z:=Z) P Line J B) (c:PhysicalGhostChoice s):
    ghostFactor value G j c=∏i,batchFactor value (G j) i (c i).2:=rfl

/-- Address-dependent fresh-slot factors preserve symmetry of the old
memory, although their dependence on fresh-slot order is retained exactly. -/
theorem birthPhased_exists_bagFunction
    (ν:∀i,P i→ℝ) (V:I→ℝ) (η q ρ:ℝ) (anchor:Z→∀i p,Line i p)
    (value:∀i,P i→ℕ) (G:ℕ→I→Fin B→Option ℕ→ℂ) (j:ℕ)
    (H:Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ):
    ∃H':Z→PhysicalActiveLists P J→(∀i,Multiset (AnchoredParticle (P i) (Line i)))→ℂ,
      phasedApply (physicalGhostOperation ν V η q ρ anchor) (fun _ c=>ghostFactor value G j c)
        (physicalBagFunction H)=physicalBagFunction H':=by
  exact exists_phased_bagFunction ν V η q ρ anchor (batchFactor value (G j)) H

end ActualFactors
end Elliptic.Operator.PhysicalPhasedGhostBags
