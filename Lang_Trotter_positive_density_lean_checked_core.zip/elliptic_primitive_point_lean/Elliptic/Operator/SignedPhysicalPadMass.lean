module

public import Elliptic.Operator.SingleEdgeSymmetrization
public import Elliptic.Operator.CleanCoincidence
public import Elliptic.Operator.MomentParameters

/-! Probability mass of actual ordered harmonic pads avoiding both endpoint
labels and repeated pad labels. No alphabet-cardinality factor is used. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPadMass
open scoped BigOperators
open Filter
attribute [local instance] Classical.propDecidable
local instance padMassDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {P : Type*} [Fintype P]

def GoodPad {J : ℕ} (a b : P) (c : Fin J→P) : Prop :=
  Function.Injective c ∧ ∀j,c j≠a ∧ c j≠b

def padWeight {J : ℕ} (μ : P→ℝ) (c : Fin J→P) : ℝ := ∏j,μ (c j)

def goodPadMass (J : ℕ) (μ : P→ℝ) (a b : P) : ℝ :=
  ∑c : Fin J→P,if GoodPad a b c then padWeight μ c else 0

def consEquiv (J : ℕ) (P : Type*) : P×(Fin J→P) ≃ (Fin (J+1)→P) where
  toFun pc := Fin.cons pc.1 pc.2
  invFun c := (c 0,Fin.tail c)
  left_inv pc := by ext j <;> simp [Fin.tail]
  right_inv c := by funext j; refine Fin.cases ?_ (fun k=>?_) j <;> simp [Fin.tail]

theorem goodPad_cons {J : ℕ} (a b p : P) (c : Fin J→P) :
    GoodPad a b (Fin.cons p c) ↔ GoodPad a b c ∧ p≠a ∧ p≠b ∧ ∀j,p≠c j := by
  constructor
  · rintro ⟨hi,he⟩
    refine ⟨⟨fun j k h=>Fin.succ_injective _ (hi (a₁:=j.succ) (a₂:=k.succ) (by simpa using h)),fun j=>by simpa using he j.succ⟩,
      (he 0).1,(he 0).2,?_⟩
    intro j hj
    have hh := hi (a₁:=0) (a₂:=j.succ) (by simpa using hj)
    exact Fin.succ_ne_zero j hh.symm
  · rintro ⟨⟨hi,he⟩,hpa,hpb,hpc⟩
    constructor
    · intro j k
      refine Fin.cases ?_ (fun j=>?_) j <;> refine Fin.cases ?_ (fun k=>?_) k
      · intro _; rfl
      · intro hjk; exact False.elim (hpc k (by simpa using hjk))
      · intro hjk; exact False.elim (hpc j (by simpa using hjk.symm))
      · intro hjk; exact congrArg Fin.succ (hi (by simpa using hjk))
    · intro j; refine Fin.cases ?_ (fun k=>?_) j
      · exact ⟨hpa,hpb⟩
      · simpa using he k

theorem padWeight_sum (J : ℕ) (μ : P→ℝ) (hμ : ∑p,μ p=1) :
    (∑c : Fin J→P,padWeight μ c)=1 := by
  unfold padWeight
  rw [←Fintype.prod_sum]
  simp [hμ]

theorem goodPadMass_bounds (J : ℕ) (μ : P→ℝ) (hμ0 : ∀p,0≤μ p) (hμ : ∑p,μ p=1) (a b : P) :
    0≤goodPadMass J μ a b ∧ goodPadMass J μ a b≤1 := by
  constructor
  · exact Finset.sum_nonneg (fun c _=>by split_ifs; exact Finset.prod_nonneg (fun j _=>hμ0 _); rfl)
  · rw [←padWeight_sum J μ hμ]
    apply Finset.sum_le_sum
    intro c _
    split_ifs
    · rfl
    · exact Finset.prod_nonneg (fun j _=>hμ0 _)

theorem fresh_mass_le_loss {J : ℕ} (μ : P→ℝ) (hμ0 : ∀p,0≤μ p) (hμ : ∑p,μ p=1)
    (δ : ℝ) (hδ : 0≤δ) (hatom : ∀p,μ p≤δ) (a b : P) (c : Fin J→P) :
    1-((J:ℝ)+2)*δ≤∑p,if p≠a ∧ p≠b ∧ ∀j,p≠c j then μ p else 0 := by
  let S : Finset P := insert a (insert b (Finset.univ.image c))
  have hc : (S.card:ℝ)≤(J:ℝ)+2 := by
    have hh : S.card≤J+2 := (Finset.card_insert_le _ _).trans
      (Nat.add_le_add_right ((Finset.card_insert_le _ _).trans
        (Nat.add_le_add_right (Finset.card_image_le.trans (by simp)) 1)) 1)
    exact_mod_cast hh
  have hb : (∑p∈S,μ p)≤((J:ℝ)+2)*δ := by
    calc
      _ ≤ ∑_p∈S,δ := Finset.sum_le_sum (fun p _=>hatom p)
      _ = S.card*δ := by simp
      _ ≤ _ := mul_le_mul_of_nonneg_right hc hδ
  have he p : p∉S ↔ p≠a ∧ p≠b ∧ ∀j,p≠c j := by simp [S,eq_comm]
  have hsplit : (∑p∈S,μ p)+(∑p,if p∉S then μ p else 0)=1 := by
    rw [←hμ,←Finset.sum_filter]
    have hh := Finset.sum_filter_add_sum_filter_not (s:=Finset.univ) (p:=fun p=>p∈S) (f:=μ)
    simpa only [Finset.filter_mem_eq_inter,Finset.univ_inter] using hh
  simp_rw [he] at hsplit
  linarith

theorem goodPadMass_succ (J : ℕ) (μ : P→ℝ) (a b : P) :
    goodPadMass (J+1) μ a b =
      ∑c : Fin J→P,(if GoodPad a b c then padWeight μ c else 0)*
        (∑p,if p≠a ∧ p≠b ∧ ∀j,p≠c j then μ p else 0) := by
  unfold goodPadMass
  rw [←(consEquiv J P).sum_comp,Fintype.sum_prod_type,Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro p _
  change (if GoodPad a b (Fin.cons p c) then _ else _)=_
  rw [goodPad_cons]
  have hw : padWeight μ (Fin.cons p c)=μ p*padWeight μ c := by
    simp only [padWeight,Fin.prod_univ_succ,Fin.cons_zero,Fin.cons_succ]
  have heq : (consEquiv J P) (p,c)=Fin.cons p c := rfl
  rw [heq,hw]
  by_cases hg : GoodPad a b c <;> by_cases hp : p≠a ∧ p≠b ∧ ∀j,p≠c j <;>
    simp [hg,hp,mul_comm]

/-- Exact quadratic small-atom loss for one group's ordered pad. -/
theorem goodPadMass_lower (J : ℕ) (μ : P→ℝ) (hμ0 : ∀p,0≤μ p) (hμ : ∑p,μ p=1)
    (δ : ℝ) (hδ : 0≤δ) (hatom : ∀p,μ p≤δ) (a b : P) :
    1-((J:ℝ)*(J+3)/2)*δ≤goodPadMass J μ a b := by
  induction J with
  | zero =>
    have hg (c : Fin 0→P) : GoodPad a b c := ⟨fun j=>Fin.elim0 j,fun j=>Fin.elim0 j⟩
    simp [goodPadMass,hg,padWeight]
  | succ J ih =>
    have hb := goodPadMass_bounds J μ hμ0 hμ a b
    have he : goodPadMass J μ a b*(1-((J:ℝ)+2)*δ)≤goodPadMass (J+1) μ a b := by
      rw [goodPadMass_succ,goodPadMass,Finset.sum_mul]
      apply Finset.sum_le_sum
      intro c _
      apply mul_le_mul_of_nonneg_left (fresh_mass_le_loss μ hμ0 hμ δ hδ hatom a b c)
      split_ifs
      · exact Finset.prod_nonneg (fun j _=>hμ0 _)
      · rfl
    have hcost : goodPadMass J μ a b*((J:ℝ)+2)*δ≤((J:ℝ)+2)*δ := by
      nlinarith [mul_le_mul_of_nonneg_right hb.2 (show 0≤((J:ℝ)+2)*δ by positivity)]
    push_cast
    nlinarith

section Groups
variable {I : Type*} [Fintype I] {P : I→Type*} [∀i,Fintype (P i)] {J : ℕ}

def GoodPads (a b : ∀i,P i) (pads : ∀i,Fin J→P i) : Prop := ∀i,GoodPad (a i) (b i) (pads i)

def orderedWeight (μ : ∀i,P i→ℝ) (pads : ∀i,Fin J→P i) : ℝ :=
  ∏i,padWeight (μ i) (pads i)

def allowedMass (μ : ∀i,P i→ℝ) (a b : ∀i,P i) : ℝ :=
  ∑pads : ∀i,Fin J→P i,if GoodPads a b pads then orderedWeight μ pads else 0

theorem allowedMass_eq_product (μ : ∀i,P i→ℝ) (a b : ∀i,P i) :
    allowedMass (J:=J) μ a b=∏i,goodPadMass J (μ i) (a i) (b i) := by
  have he (pads : ∀i,Fin J→P i) : (if GoodPads a b pads then orderedWeight μ pads else 0)=
      ∏i,if GoodPad (a i) (b i) (pads i) then padWeight (μ i) (pads i) else 0 := by
    by_cases hg : GoodPads a b pads
    · simp only [ite_eq_left hg,orderedWeight]
      apply Finset.prod_congr rfl
      intro i _
      rw [ite_eq_left (hg i)]
    · rw [ite_eq_right hg]
      unfold GoodPads at hg
      push_neg at hg
      obtain ⟨i,hi⟩ := hg
      exact (Finset.prod_eq_zero (Finset.mem_univ i) (by rw [ite_eq_right hi])).symm
  unfold allowedMass
  simp_rw [he]
  exact (Fintype.prod_sum (fun i (c : Fin J→P i)=>
    if GoodPad (a i) (b i) c then padWeight (μ i) c else 0)).symm

theorem one_sub_prod_le_sum {α : Type*} [DecidableEq α] (s : Finset α) (f : α→ℝ)
    (hf0 : ∀i∈s,0≤f i) (hf1 : ∀i∈s,f i≤1) :
    1-∏i∈s,f i≤∑i∈s,(1-f i) := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [Finset.prod_insert hi,Finset.sum_insert hi]
    have h0 := hf0 i (Finset.mem_insert_self _ _)
    have h1 := hf1 i (Finset.mem_insert_self _ _)
    have hp0 : 0≤∏j∈s,f j := Finset.prod_nonneg (fun j hj=>hf0 j (Finset.mem_insert_of_mem hj))
    have hp1 : (∏j∈s,f j)≤1 := Finset.prod_le_one₀
      (fun j hj=>hf0 j (Finset.mem_insert_of_mem hj)) (fun j hj=>hf1 j (Finset.mem_insert_of_mem hj))
    have hh := ih (fun j hj=>hf0 j (Finset.mem_insert_of_mem hj)) (fun j hj=>hf1 j (Finset.mem_insert_of_mem hj))
    nlinarith [mul_nonneg (sub_nonneg.mpr h1) (sub_nonneg.mpr hp1)]

/-- Actual ordered pad law: the total loss is quadratic in padding and
linear in the number of groups and the largest one-prime atom. -/
theorem allowedMass_lower (μ : ∀i,P i→ℝ) (hμ0 : ∀i p,0≤μ i p)
    (hμ : ∀i,∑p,μ i p=1) (δ : ℝ) (hδ : 0≤δ) (hatom : ∀i p,μ i p≤δ)
    (a b : ∀i,P i) :
    1-(Fintype.card I:ℝ)*((J:ℝ)*(J+3)/2)*δ≤allowedMass (J:=J) μ a b := by
  rw [allowedMass_eq_product]
  have hb i := goodPadMass_bounds J (μ i) (hμ0 i) (hμ i) (a i) (b i)
  have hp := one_sub_prod_le_sum Finset.univ (fun i=>goodPadMass J (μ i) (a i) (b i))
    (fun i _=>(hb i).1) (fun i _=>(hb i).2)
  have hs : (∑i,(1-goodPadMass J (μ i) (a i) (b i)))≤
      (Fintype.card I:ℝ)*((J:ℝ)*(J+3)/2)*δ := by
    calc
      _ ≤ ∑_i : I,((J:ℝ)*(J+3)/2)*δ := Finset.sum_le_sum (fun i _=>by
        linarith [goodPadMass_lower J (μ i) (hμ0 i) (hμ i) δ hδ (hatom i) (a i) (b i)])
      _ = _ := by simp; ring
  linarith

/-- Assemble the original active lists from ordered common pads and one
fresh endpoint label in the last slot. -/
def assembledLists (pads : ∀i,Fin J→P i) (a : ∀i,P i) : PhysicalActiveLists P J :=
  fun i=>Fin.snoc (pads i) (a i)

def slotLabel (a b : ∀i,P i) (pads : ∀i,Fin J→P i) (i : I) : Fin J⊕Bool→P i
  | .inl j=>pads i j
  | .inr false=>a i
  | .inr true=>b i

theorem slotLabel_injective (a b : ∀i,P i) (pads : ∀i,Fin J→P i)
    (hg : GoodPads a b pads) (hab : ∀i,a i≠b i) (i : I) :
    Function.Injective (slotLabel a b pads i) := by
  rintro (j|t) (k|u) h
  · exact congrArg Sum.inl ((hg i).1 h)
  · cases u
    · exact False.elim ((hg i).2 j |>.1 <| h)
    · exact False.elim ((hg i).2 j |>.2 <| h)
  · cases t
    · exact False.elim ((hg i).2 k |>.1 <| h.symm)
    · exact False.elim ((hg i).2 k |>.2 <| h.symm)
  · cases t <;> cases u
    · rfl
    · exact False.elim (hab i h)
    · exact False.elim (hab i h.symm)
    · rfl

/-- Global numerical label injectivity and the allowed pad condition
supply the original copied-slot/cross-edge ban exactly. -/
theorem goodPads_crossEdgeBan (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (a b : ∀i,P i) (hab : ∀i,a i≠b i) (pads : ∀i,Fin J→P i) (hg : GoodPads a b pads) :
    sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) := by
  constructor
  · intro i j; simp [assembledLists]
  · have hs : Function.Injective (fun x : I×(Fin J⊕Bool)=>(⟨x.1,slotLabel a b pads x.1 x.2⟩ : Sigma P)) := by
      rintro ⟨i,s⟩ ⟨j,t⟩ he
      obtain ⟨hij,hst⟩ := Sigma.mk.inj_iff.mp he
      dsimp only at hij hst
      subst j
      have hh := slotLabel_injective a b pads hg hab i (eq_of_heq hst)
      exact Prod.ext rfl hh
    have he : sourceCrossEdgeLabels value (assembledLists pads a) (assembledLists pads b)=
        fun x : I×(Fin J⊕Bool)=>value x.1 (slotLabel a b pads x.1 x.2) := by
      funext x
      rcases x with ⟨i,j|t⟩
      · simp [sourceCrossEdgeLabels,assembledLists,slotLabel]
      · cases t <;> simp [sourceCrossEdgeLabels,assembledLists,slotLabel]
    rw [he]
    exact hinj.comp hs

/-- The original harmonic one-prime pad law. -/
def harmonicMass (value : ∀i,P i→ℕ) (V : I→ℝ) (i : I) (p : P i) : ℝ :=
  1/(V i*(value i p:ℝ))

theorem harmonicMass_sum (value : ∀i,P i→ℕ) (V : I→ℝ)
    (hV : ∀i,V i≠0) (hVsum : ∀i,V i=∑p,1/(value i p:ℝ)) (i : I) :
    (∑p,harmonicMass value V i p)=1 := by
  unfold harmonicMass
  simp_rw [←one_div_mul_one_div]
  rw [←Finset.mul_sum,←hVsum i]
  exact one_div_mul_cancel (hV i)

theorem harmonicMass_nonneg (value : ∀i,P i→ℕ) (V : I→ℝ)
    (hV : ∀i,0≤V i) (i : I) (p : P i) : 0≤harmonicMass value V i p := by
  unfold harmonicMass
  exact one_div_nonneg.mpr (mul_nonneg (hV i) (Nat.cast_nonneg _))

theorem harmonicMass_atom_le (value : ∀i,P i→ℕ) (V : I→ℝ) (vmin pmin : ℝ)
    (hmin : 0<vmin) (hpmin : 0<pmin) (hV : ∀i,vmin≤V i)
    (hp : ∀i p,pmin≤(value i p:ℝ)) (i : I) (p : P i) :
    harmonicMass value V i p≤1/(vmin*pmin) := by
  apply one_div_le_one_div_of_le (mul_pos hmin hpmin)
  exact mul_le_mul (hV i) (hp i p) hpmin.le (hmin.trans_le (hV i)).le

/-- The harmonic pad mass surviving the literal source cross-edge ban.
This is the concrete pad-recovery estimate used in the scalar pair bridge. -/
theorem harmonic_crossEdgeBan_mass_lower (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (V : I→ℝ) (vmin pmin : ℝ) (hmin : 0<vmin) (hpmin : 0<pmin)
    (hV : ∀i,vmin≤V i) (hp : ∀i p,pmin≤(value i p:ℝ))
    (hVsum : ∀i,V i=∑p,1/(value i p:ℝ))
    (a b : ∀i,P i) (hab : ∀i,a i≠b i) :
    1-(Fintype.card I:ℝ)*((J:ℝ)*(J+3)/2)/(vmin*pmin) ≤
      ∑pads : ∀i,Fin J→P i,
        if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
          ∏i,∏j,1/(V i*(value i (pads i j):ℝ)) else 0 := by
  have hVpos i : 0<V i := hmin.trans_le (hV i)
  have hlo := allowedMass_lower (J:=J) (harmonicMass value V)
    (harmonicMass_nonneg value V (fun i=>(hVpos i).le))
    (harmonicMass_sum value V (fun i=>(hVpos i).ne') hVsum)
    (1/(vmin*pmin)) (by positivity) (harmonicMass_atom_le value V vmin pmin hmin hpmin hV hp) a b
  have he : (Fintype.card I:ℝ)*((J:ℝ)*(J+3)/2)*(1/(vmin*pmin))=
      (Fintype.card I:ℝ)*((J:ℝ)*(J+3)/2)/(vmin*pmin) := by ring
  rw [he] at hlo
  apply hlo.trans
  unfold allowedMass
  apply Finset.sum_le_sum
  intro pads _
  by_cases hg : GoodPads a b pads
  · simp only [ite_eq_left hg,ite_eq_left (goodPads_crossEdgeBan value hinj a b hab pads hg)]
    rfl
  · rw [ite_eq_right hg]
    split_ifs
    · exact Finset.prod_nonneg (fun i _=>Finset.prod_nonneg (fun j _=>
        harmonicMass_nonneg value V (fun i=>(hVpos i).le) i (pads i j)))
    · rfl

/-- Pairwise disjoint numerical groups give the global numerical-label
injectivity used by the literal source cross-edge ban. -/
theorem groupValue_injective (groups : I→Finset ℕ)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j)) :
    Function.Injective (fun s : Sigma (fun i=>↥(groups i))=>s.2.val) := by
  rintro ⟨i,p⟩ ⟨j,q⟩ h
  change p.val=q.val at h
  by_cases hij : i=j
  · subst j
    exact Sigma.ext rfl (heq_of_eq (Subtype.ext h))
  · exact False.elim (Finset.disjoint_left.mp (hdis i j hij) p.property (h.symm ▸ q.property))

end Groups

/-- Literal growing-padding cost is smaller than any prescribed log power
at the source lower prime cutoff. -/
theorem eventually_pad_loss_le (K : ℕ) (vmin A : ℝ) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ pmin : ℝ, Real.exp (L^(1/10:ℝ))≤pmin →
      (K:ℝ)*((momentPadding L:ℝ)*(momentPadding L+3)/2)/(vmin*pmin)≤L^(-A) := by
  let D := 2*(K:ℝ)/vmin
  have hlim : Tendsto (fun L : ℝ=>D*(L^(2+A)*Real.exp (-L^(1/10:ℝ)))) atTop (nhds 0) := by
    simpa only [neg_mul,one_mul,mul_zero] using
      (tendsto_power_mul_exp_neg_rpow (2+A) (by norm_num : (0:ℝ)<1)
        (by norm_num : (0:ℝ)<1/10)).const_mul D
  filter_upwards [eventually_ge_atTop (1:ℝ),hlim.eventually_lt_const (by norm_num : (0:ℝ)<1)] with L hL hh
  intro pmin hpmin
  have hLp : 0<L := by linarith
  have hp : 0<pmin := (Real.exp_pos _).trans_le hpmin
  have hJ : (momentPadding L:ℝ)≤L := by
    apply (Nat.floor_le (Real.rpow_nonneg hLp.le _)).trans
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/100:ℝ)≤1)
  have hnum : (K:ℝ)*((momentPadding L:ℝ)*(momentPadding L+3)/2)≤2*K*L^2 := by
    have hJ0 : (0:ℝ)≤momentPadding L := Nat.cast_nonneg _
    have hb : (momentPadding L:ℝ)*(momentPadding L+3)≤4*L^2 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_left hb (Nat.cast_nonneg K : (0:ℝ)≤K)]
  have he : (K:ℝ)*((momentPadding L:ℝ)*(momentPadding L+3)/2)/(vmin*pmin)≤
      D*(L^2*Real.exp (-L^(1/10:ℝ))) := by
    calc
      _ ≤ (2*K*L^2)/(vmin*Real.exp (L^(1/10:ℝ))) :=
        div_le_div₀ (by positivity) hnum (mul_pos hmin (Real.exp_pos _))
          (mul_le_mul_of_nonneg_left hpmin hmin.le)
      _ = _ := by dsimp [D]; rw [Real.exp_neg]; field_simp <;> ring
  apply (mul_le_mul_iff_left₀ (Real.rpow_pos_of_pos hLp A)).mp
  calc
    _ ≤ D*(L^2*Real.exp (-L^(1/10:ℝ)))*L^A := mul_le_mul_of_nonneg_right he (by positivity)
    _ = D*(L^(2+A)*Real.exp (-L^(1/10:ℝ))) := by rw [Real.rpow_add hLp,Real.rpow_two]; ring
    _ ≤ 1 := hh.le
    _ = L^(-A)*L^A := by rw [←Real.rpow_add hLp]; simp

/-- Source-scale harmonic padding recovers mass one up to every fixed
logarithmic power, with actual copied slots and cross-edge bans. -/
theorem eventually_harmonic_pad_recovery (K : ℕ) (vmin A : ℝ) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ value : (i : Fin K)→P i→ℕ,
      Function.Injective (fun s : Sigma P=>value s.1 s.2) →
      (∀i p,Real.exp (L^(1/10:ℝ))≤(value i p:ℝ)) →
      ∀ V : Fin K→ℝ, (∀i,vmin≤V i) → (∀i,V i=∑p,1/(value i p:ℝ)) →
      ∀ a b : ∀i,P i, (∀i,a i≠b i) →
      1-L^(-A)≤∑pads : ∀i,Fin (momentPadding L)→P i,
        if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
          ∏i,∏j,1/(V i*(value i (pads i j):ℝ)) else 0 := by
  filter_upwards [eventually_pad_loss_le K vmin A hmin] with L hL
  intro P _ value hinj hp V hV hVsum a b hab
  have hm := harmonic_crossEdgeBan_mass_lower (J:=momentPadding L) value hinj V vmin
    (Real.exp (L^(1/10:ℝ))) hmin (Real.exp_pos _) hV hp hVsum a b hab
  simp only [Fintype.card_fin] at hm
  have hh := (sub_le_sub_left (hL _ le_rfl) 1).trans hm
  convert hh using 1
  apply Finset.sum_congr
  · ext; simp
  · intro pads _; rfl

end Elliptic.Operator.SignedPhysicalPadMass
