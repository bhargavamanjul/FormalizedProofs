module
public import Elliptic.Operator.PhysicalCleanMemory

/-!
# Lossless assembly of actual finite fibers and endpoint averages

Fibers may have varying supports. Shared lists, unchanged bags, pad classes
and individual slope-cell shifts therefore incur no counting factor.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance cleanFiberAssemblyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

/-- The whole kernel action at a source in block i is exactly its target
fiber action, when all cross-block entries vanish. -/
theorem finiteKernelApply_eq_fiber {X Y I : Type*}
    (s : Finset X) (t : Finset Y) (f : X → I) (g : Y → I)
    (ν : Y → ℝ) (K : X → Y → ℂ)
    (hzero : ∀ x∈s, ∀ y∈t, f x≠g y → K x y=0)
    (b : Y → ℂ) (x : X) (hx : x∈s) (i : I) (hi : f x=i) :
    finiteKernelApply t ν K b x = finiteKernelApply (t.filter (fun y => g y=i)) ν K b x := by
  unfold finiteKernelApply
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro y hy hnot
  have hn : f x≠g y := by
    intro he
    apply hnot
    exact Finset.mem_filter.mpr ⟨hy,he.symm.trans hi⟩
  simp only [hzero x hx y hy hn,mul_zero,zero_mul]

/-- True direct sum over arbitrary finite fibers. No number-of-fibers
factor occurs, even when all physical labels and cutoffs vary. -/
theorem finiteKernelBound_of_fibers {X Y I : Type*}
    (s : Finset X) (t : Finset Y) (blocks : Finset I) (f : X → I) (g : Y → I)
    (hf : ∀ x∈s, f x∈blocks) (hg : ∀ y∈t, g y∈blocks)
    (μ : X → ℝ) (ν : Y → ℝ) (K : X → Y → ℂ) (M : ℝ)
    (hμ : ∀ x∈s, 0≤μ x) (hν : ∀ y∈t, 0≤ν y) (hM : 0≤M)
    (hzero : ∀ x∈s, ∀ y∈t, f x≠g y → K x y=0)
    (hblock : ∀ i∈blocks,
      FiniteKernelBound (s.filter (fun x => f x=i)) (t.filter (fun y => g y=i)) μ ν K M) :
    FiniteKernelBound s t μ ν K M := by
  intro b
  have hs : finiteL2Sq s μ (finiteKernelApply t ν K b) ≤ M^2*finiteL2Sq t ν b := by
    calc
      _ = ∑ i∈blocks, finiteL2Sq (s.filter (fun x => f x=i)) μ
          (finiteKernelApply (t.filter (fun y => g y=i)) ν K b) := by
        unfold finiteL2Sq
        rw [← Finset.sum_fiberwise_of_maps_to hf (fun x => μ x*‖finiteKernelApply t ν K b x‖^2)]
        apply Finset.sum_congr rfl
        intro i hi
        apply Finset.sum_congr rfl
        intro x hx
        rw [finiteKernelApply_eq_fiber s t f g ν K hzero b x (Finset.mem_filter.mp hx).1 i
          (Finset.mem_filter.mp hx).2]
      _ ≤ ∑ i∈blocks, M^2*finiteL2Sq (t.filter (fun y => g y=i)) ν b := by
        apply Finset.sum_le_sum
        intro i hi
        exact finiteKernelBound_sq _ _ μ ν K M
          (fun x hx => hμ x (Finset.mem_filter.mp hx).1)
          (fun y hy => hν y (Finset.mem_filter.mp hy).1) (hblock i hi) b
      _ = _ := by
        rw [← Finset.mul_sum]
        congr 1
        exact Finset.sum_fiberwise_of_maps_to hg (fun y => ν y*‖b y‖^2)
  exact (Real.sqrt_le_sqrt hs).trans_eq (by
    rw [Real.sqrt_mul (sq_nonneg M),Real.sqrt_sq hM]
    rfl)

/-- Exact finite measured L2 invariance under a mass-preserving relabeling. -/
theorem finiteL2_equiv {X Y : Type*} [Fintype X] [Fintype Y]
    (e : X ≃ Y) (μ : X → ℝ) (ν : Y → ℝ) (hm : ∀ x, μ x=ν (e x)) (F : Y → ℂ) :
    finiteL2 Finset.univ μ (fun x => F (e x)) = finiteL2 Finset.univ ν F := by
  unfold finiteL2 finiteL2Sq
  congr 1
  exact Fintype.sum_equiv e _ _ (fun x => by rw [hm x])

/-- Independent endpoint relabelings preserve the measured bilinear norm. -/
theorem finiteMeasuredBilinearBound_equiv {X Y U V : Type*}
    [Fintype X] [Fintype Y] [Fintype U] [Fintype V]
    (e : X ≃ U) (d : Y ≃ V) (μ : X → ℝ) (ν : Y → ℝ)
    (μ' : U → ℝ) (ν' : V → ℝ)
    (he : ∀ x, μ x=μ' (e x)) (hd : ∀ y, ν y=ν' (d y))
    (K : U → V → ℂ) (M : ℝ)
    (hK : FiniteMeasuredBilinearBound Finset.univ Finset.univ μ' ν' K M) :
    FiniteMeasuredBilinearBound Finset.univ Finset.univ μ ν (fun x y => K (e x) (d y)) M := by
  intro a b
  have hp : finiteMeasuredPairing Finset.univ Finset.univ μ ν (fun x y => K (e x) (d y)) a b =
      finiteMeasuredPairing Finset.univ Finset.univ μ' ν' K
        (fun u => a (e.symm u)) (fun v => b (d.symm v)) := by
    unfold finiteMeasuredPairing finiteKernelApply
    apply Fintype.sum_equiv e
    intro x
    simp only [Equiv.symm_apply_apply,he]
    congr 1
    apply Fintype.sum_equiv d
    intro y
    simp only [Equiv.symm_apply_apply,hd]
  rw [hp]
  have h := hK (fun u => a (e.symm u)) (fun v => b (d.symm v))
  have ha := finiteL2_equiv e μ μ' he (fun u => a (e.symm u))
  have hb := finiteL2_equiv d ν ν' hd (fun v => b (d.symm v))
  simp only [Equiv.symm_apply_apply] at ha hb
  rw [← ha,← hb] at h
  exact h

/-- A genuine convex finite average retains the same norm bound; in
particular the two endpoint permutation averages cost exactly one. -/
theorem finiteMeasuredBilinearBound_convex {X Y I : Type*}
    (s : Finset X) (t : Finset Y) (q : Finset I)
    (μ : X → ℝ) (ν : Y → ℝ) (K : I → X → Y → ℂ)
    (w : I → ℝ) (M : ℝ)
    (hw : ∀ i∈q, 0≤w i) (hsum : ∑ i∈q, w i=1)
    (hK : ∀ i∈q, FiniteMeasuredBilinearBound s t μ ν (K i) M) :
    FiniteMeasuredBilinearBound s t μ ν (fun x y => ∑ i∈q, (w i:ℂ)*K i x y) M := by
  intro a b
  have he : finiteMeasuredPairing s t μ ν (fun x y => ∑ i∈q, (w i:ℂ)*K i x y) a b =
      ∑ i∈q, (w i:ℂ)*finiteMeasuredPairing s t μ ν (K i) a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    simp only [Finset.mul_sum,Finset.sum_mul]
    conv_lhs =>
      enter [2,x]
      rw [Finset.sum_comm]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i hi
    apply Finset.sum_congr rfl
    intro x hx
    apply Finset.sum_congr rfl
    intro y hy
    ring
  rw [he]
  calc
    _ ≤ ∑ i∈q, ‖(w i:ℂ)*finiteMeasuredPairing s t μ ν (K i) a b‖ := norm_sum_le _ _
    _ ≤ ∑ i∈q, w i*(M*finiteL2 s μ a*finiteL2 t ν b) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (hw i hi)]
      exact mul_le_mul_of_nonneg_left (hK i hi a b) (hw i hi)
    _ = _ := by rw [← Finset.sum_mul,hsum,one_mul]

end Elliptic.Operator
