module
public import Elliptic.Operator.SignedDivisorProgression
public import Elliptic.Operator.RootErrorBudget

/-! The proved progression divisor-square estimate at the actual
subpower label-product scale, uniformly for both unit shifts. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDivisorProgression
open scoped BigOperators
open Filter
attribute [local instance] Classical.propDecidable
local instance progressionScaleDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

theorem real_scale_progression (n : ℕ→ℕ) (l : ℕ) (x : ℝ) (σ : ℤ)
    (hl : 1≤l) (hx : 1≤x) (hscale : 8*(l:ℝ)^4≤x) (hσ : σ=1 ∨ σ= -1)
    (hshift : ∀h∈Finset.Icc 1 ⌊x/l⌋₊,(n h:ℤ)=(l:ℤ)*h+σ) :
    (∑h∈Finset.Icc 1 ⌊x/l⌋₊,((n h).divisors.card:ℝ)^2)≤
      8*(x/l)*(1+Real.log (2*x))^3 := by
  let H := ⌊x/l⌋₊
  let X := 2*l*H
  have hlp : (0:ℝ)<l := by exact_mod_cast (show 0<l by omega)
  have hHlarge : 8*l^3≤H := by
    apply (Nat.le_floor_iff (by positivity : (0:ℝ)≤x/l)).mpr
    apply (le_div_iff₀ hlp).mpr
    push_cast
    nlinarith [hscale]
  have hH : 1≤H := by have : 1≤l^3 := Nat.one_le_pow 3 l hl; omega
  have hX : 1≤X := Nat.mul_pos (Nat.mul_pos (by norm_num) hl) hH
  have hpower : X^3≤H^4 := by
    have hh := Nat.mul_le_mul_right (H^3) hHlarge
    dsimp [X]
    nlinarith only [hh]
  have hnX : ∀h∈Finset.Icc 1 H,n h≤X := by
    intro h hh
    have he := hshift h hh
    have hle : (n h:ℤ)≤(l:ℤ)*H+1 := by
      have hb : (h:ℤ)≤H := by exact_mod_cast (Finset.mem_Icc.mp hh).2
      have hlz : (0:ℤ)≤l := by positivity
      rcases hσ with rfl|rfl <;> nlinarith [mul_le_mul_of_nonneg_left hb hlz]
    have hLH : 1≤l*H := Nat.mul_pos hl hH
    have hnat : n h≤l*H+1 := by exact_mod_cast hle
    dsimp [X]
    nlinarith only [hLH,hnat]
  have hb := divisor_square_progression_long n l H X σ hσ hX hpower hnX hshift
  have hHle : (H:ℝ)≤x/l := Nat.floor_le (by positivity)
  have hXle : (X:ℝ)≤2*x := by
    have hh := (le_div_iff₀ hlp).mp hHle
    dsimp [X]
    push_cast
    nlinarith
  have hlog : 1+Real.log (X:ℝ)≤1+Real.log (2*x) := by
    have hp : (0:ℝ)<X := by exact_mod_cast (show 0<X by omega)
    linarith [Real.log_le_log hp hXle]
  apply hb.trans
  apply mul_le_mul
  · exact mul_le_mul_of_nonneg_left hHle (by norm_num)
  · exact pow_le_pow_left₀ (by have := Real.log_natCast_nonneg X; linarith) hlog 3
  · positivity
  · positivity

theorem eventually_label_fourth_power (D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀l : ℕ,(l:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      8*(l:ℝ)^4≤x := by
  filter_upwards [Real.tendsto_log_atTop.eventually
      (RootErrorBudget.eventually_subpower_exponent_le (Real.log 8+4*D) 1 (by norm_num)),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),eventually_gt_atTop (0:ℝ)]
      with x he hL hx
  intro l hl
  have hp : 1≤(Real.log x)^(98/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hpow : (Real.log x)^(1/5:ℝ)≤(Real.log x)^(98/100:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hL (by norm_num)
  have hex : Real.log 8+4*D*(Real.log x)^(1/5:ℝ)≤Real.log x := by
    have hlog8 : 0≤Real.log 8 := Real.log_nonneg (by norm_num)
    have h₁ := mul_le_mul_of_nonneg_left hp hlog8
    have h₂ := mul_le_mul_of_nonneg_left hpow (by positivity : 0≤4*D)
    nlinarith
  calc
    _ ≤ 8*(Real.exp (D*(Real.log x)^(1/5:ℝ)))^4 :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (Nat.cast_nonneg l) hl 4) (by norm_num)
    _ = Real.exp (Real.log 8+4*D*(Real.log x)^(1/5:ℝ)) := by
      rw [Real.exp_add,Real.exp_log (by norm_num : (0:ℝ)<8)]
      congr 1
      rw [show 4*D*(Real.log x)^(1/5:ℝ)=4*(D*(Real.log x)^(1/5:ℝ)) by ring]
      simpa using (Real.exp_nat_mul (D*(Real.log x)^(1/5:ℝ)) 4).symm
    _ ≤ Real.exp (Real.log x) := Real.exp_le_exp.mpr hex
    _ = x := Real.exp_log hx

/-- The dyadic label interval `[Y,4Y]` gives the source cofactor length
x/Y uniformly for every fixed label product in that interval. -/
theorem real_band_progression (n : ℕ→ℕ) (l : ℕ) (x Y : ℝ) (σ : ℤ)
    (hl : 1≤l) (hx : 1≤x) (hY : 0<Y) (hlo : Y≤l) (hhi : (l:ℝ)≤4*Y)
    (hscale : 8*(l:ℝ)^4≤x) (hσ : σ=1 ∨ σ= -1)
    (hshift : ∀h : ℕ,1≤h→(n h:ℤ)=(l:ℤ)*h+σ) :
    (∑h∈Finset.Icc 1 ⌊x/Y⌋₊,((n h).divisors.card:ℝ)^2)≤
      32*(x/Y)*(1+Real.log (8*x))^3 := by
  have hlp : (0:ℝ)<l := hY.trans_le hlo
  have hrange : ⌊x/Y⌋₊≤⌊(4*x)/l⌋₊ := by
    apply Nat.floor_mono
    apply (div_le_div_iff₀ hY hlp).mpr
    nlinarith [mul_le_mul_of_nonneg_left hhi (by linarith : 0≤x)]
  have hb := real_scale_progression n l (4*x) σ hl (by linarith)
    (by nlinarith) hσ (fun h hh=>hshift h (Finset.mem_Icc.mp hh).1)
  have hs : Finset.Icc 1 ⌊x/Y⌋₊⊆Finset.Icc 1 ⌊(4*x)/l⌋₊ :=
    Finset.Icc_subset_Icc le_rfl hrange
  apply (Finset.sum_le_sum_of_subset_of_nonneg hs (fun _ _ _=>sq_nonneg _)).trans
  apply hb.trans
  have hdiv : (4*x)/l≤4*(x/Y) := by
    calc
      (4*x)/l ≤ (4*x)/Y := div_le_div_of_nonneg_left (by linarith) hY hlo
      _ = _ := by ring
  have hp : 0≤(1+Real.log (8*x))^3 := by
    have hh := Real.log_nonneg (by linarith : 1≤8*x)
    positivity
  have heq : 2*(4*x)=8*x := by ring
  rw [heq]
  nlinarith [mul_le_mul_of_nonneg_right hdiv hp]

theorem eventually_band_progression (D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀(n : ℕ→ℕ) (l : ℕ) (Y : ℝ) (σ : ℤ),
      1≤l → 0<Y → Y≤l → (l:ℝ)≤4*Y →
      (l:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) → (σ=1 ∨ σ= -1) →
      (∀h : ℕ,1≤h→(n h:ℤ)=(l:ℤ)*h+σ) →
      (∑h∈Finset.Icc 1 ⌊x/Y⌋₊,((n h).divisors.card:ℝ)^2)≤
        32*(x/Y)*(1+Real.log (8*x))^3 := by
  filter_upwards [eventually_label_fourth_power D hD,eventually_ge_atTop (1:ℝ)] with x hs hx
  intro n l Y σ hl hY hlo hhi hupper hσ hshift
  exact real_band_progression n l x Y σ hl hx hY hlo hhi (hs l hupper) hσ hshift

/-- Literal source successor cofactor, with no assumed progression estimate. -/
theorem eventually_predecessor_band (D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀(l : ℕ) (Y : ℝ),
      1≤l → 0<Y → Y≤l → (l:ℝ)≤4*Y →
      (l:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (∑h∈Finset.Icc 1 ⌊x/Y⌋₊,((l*h-1).divisors.card:ℝ)^2)≤
        32*(x/Y)*(1+Real.log (8*x))^3 := by
  filter_upwards [eventually_band_progression D hD] with x hx
  intro l Y hl hY hlo hhi hupper
  apply hx (fun h=>l*h-1) l Y (-1) hl hY hlo hhi hupper (Or.inr rfl)
  intro h hh
  have hp : 1≤l*h := Nat.mul_pos hl hh
  simp only [Nat.cast_sub hp,Nat.cast_mul,Nat.cast_one]
  ring

end Elliptic.Operator.SignedDivisorProgression
