module

public import Elliptic.Operator.ScheduledHistoryConverse
public import Elliptic.Operator.LifespanReconstruction

/-!
# Recovering lifespan data from an actual compatible history

The before/after states at each visit are read from the literal dependent
history. Their prime-label occurrences recover its live-prime intervals,
active visits, and hence every used prime's lifespan. This proves
uniqueness for compatible schedules; it does not construct a compatible
schedule from an arbitrary term of the original restricted expansion.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance scheduledRecoveryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace PrimeLifespan
variable {N : ℕ}

/-- Every point of the lifespan interval is either active or pending on
at least one side of its visit. The no-singleton-ghost condition is used. -/
theorem live_iff (L : PrimeLifespan N) (j : ℕ) :
    (j ∈ L.active ∨ L.beforeGhost j ∨ L.afterGhost j) ↔ L.birth ≤ j ∧ j ≤ L.death := by
  constructor
  · rintro (ha | hb | ha)
    · exact L.active_bounds j ha
    · exact ⟨hb.1.le,hb.2.1⟩
    · exact ⟨ha.1,ha.2.1.le⟩
  · rintro ⟨hb,hd⟩
    by_cases ha : j ∈ L.active
    · exact Or.inl ha
    by_cases hbj : L.birth < j
    · exact Or.inr (Or.inl ⟨hbj,hd,ha⟩)
    · have he : L.birth = j := by omega
      have hjd : j < L.death := by
        by_contra h
        have hed : L.birth = L.death := by omega
        exact ha (he ▸ L.singleton_active hed)
      exact Or.inr (Or.inr ⟨hb,hjd,ha⟩)

/-- Live traces on the finite horizon recover both endpoints. -/
theorem endpoints_eq_of_live_trace (L M : PrimeLifespan N)
    (h : ∀ j, j ≤ N →
      ((j ∈ L.active ∨ L.beforeGhost j ∨ L.afterGhost j) ↔
      (j ∈ M.active ∨ M.beforeGhost j ∨ M.afterGhost j))) :
    L.birth = M.birth ∧ L.death = M.death := by
  have hbL := (M.live_iff L.birth).mp ((h L.birth (L.birth_le_death.trans L.death_le)).mp
    ((L.live_iff L.birth).mpr ⟨le_rfl,L.birth_le_death⟩))
  have hbM := (L.live_iff M.birth).mp ((h M.birth (M.birth_le_death.trans M.death_le)).mpr
    ((M.live_iff M.birth).mpr ⟨le_rfl,M.birth_le_death⟩))
  have hdL := (M.live_iff L.death).mp ((h L.death L.death_le).mp
    ((L.live_iff L.death).mpr ⟨L.birth_le_death,le_rfl⟩))
  have hdM := (L.live_iff M.death).mp ((h M.death M.death_le).mpr
    ((M.live_iff M.death).mpr ⟨M.birth_le_death,le_rfl⟩))
  omega

/-- Active and live traces together determine the entire used lifespan. -/
theorem eq_of_observable_traces (L M : PrimeLifespan N)
    (ha : ∀ j, j ≤ N → (j ∈ L.active ↔ j ∈ M.active))
    (hl : ∀ j, j ≤ N →
      ((j ∈ L.active ∨ L.beforeGhost j ∨ L.afterGhost j) ↔
      (j ∈ M.active ∨ M.beforeGhost j ∨ M.afterGhost j))) : L = M := by
  obtain ⟨hb,hd⟩ := L.endpoints_eq_of_live_trace M hl
  apply PrimeLifespan.ext_data hb hd
  ext j
  by_cases hj : j ≤ N
  · exact ha j hj
  · have hL : j ∉ L.active := fun h => hj ((L.active_bounds j h).2.trans L.death_le)
    have hM : j ∉ M.active := fun h => hj ((M.active_bounds j h).2.trans M.death_le)
    simp [hL,hM]
/-- Construct lifespan endpoints from finite observed data. The hypotheses
are properties of those finite sets, not a relation to a pre-existing
lifespan or history realization. Convexity is needed only for exact live
trace recovery below. -/
def ofTrace (live active : Finset ℕ) (hne : live.Nonempty)
    (hbound : ∀ j ∈ live, j ≤ N) (ha : active ⊆ live)
    (hsingle : ∀ j ∈ live, (∀ k ∈ live, k = j) → j ∈ active) : PrimeLifespan N where
  birth := live.min' hne
  death := live.max' hne
  birth_le_death := Finset.min'_le _ _ (Finset.max'_mem _ _)
  death_le := hbound _ (Finset.max'_mem _ _)
  active := active
  active_bounds j hj := ⟨Finset.min'_le _ _ (ha hj),Finset.le_max' _ _ (ha hj)⟩
  singleton_active h := hsingle _ (Finset.min'_mem _ _) (by
    intro k hk
    exact le_antisymm ((Finset.le_max' _ _ hk).trans h.symm.le) (Finset.min'_le _ _ hk))

/-- For convex observed live data, the construction recovers exactly that
live trace and the supplied active set. Proving these finite hypotheses
for raw selected histories is a separate provenance task. -/
theorem ofTrace_live (live active : Finset ℕ) (hne : live.Nonempty)
    (hbound : ∀ j ∈ live, j ≤ N) (ha : active ⊆ live)
    (hsingle : ∀ j ∈ live, (∀ k ∈ live, k = j) → j ∈ active)
    (hconvex : ∀ a ∈ live, ∀ b ∈ live, ∀ j, a ≤ j → j ≤ b → j ∈ live) (j : ℕ) :
    (j ∈ (ofTrace live active hne hbound ha hsingle).active ∨
      (ofTrace live active hne hbound ha hsingle).beforeGhost j ∨
      (ofTrace live active hne hbound ha hsingle).afterGhost j) ↔ j ∈ live := by
  rw [live_iff]
  constructor
  · intro hj
    exact hconvex (live.min' hne) (Finset.min'_mem live hne)
      (live.max' hne) (Finset.max'_mem live hne) j hj.1 hj.2
  · intro hj
    exact ⟨Finset.min'_le _ _ hj,Finset.le_max' _ _ hj⟩

end PrimeLifespan

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace ScheduledPhysicalPath
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Actual state immediately before a chosen ghost visit. -/
def beforeStateAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin (n+1) → PhysicalMemoryState (Z:=Z) P Line J B
  | 0,_,s,_,_ => s
  | n+1,j,s,h,k => Fin.cases s (fun t => beforeStateAt n (j+1) _ h.2.2 t) k

/-- Actual state immediately after a chosen ghost visit. -/
def afterStateAt : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s →
    Fin (n+1) → PhysicalMemoryState (Z:=Z) P Line J B
  | 0,j,s,h,_ => (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
  | n+1,j,s,h,k => Fin.cases
      ((physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property)
      (fun t => afterStateAt n (j+1) _ h.2.2 t) k

variable (d : ScheduledPhysicalPath anchor N J B)

/-- Constructed histories expose the scheduled before states without
changing their actual ordered memory representatives. -/
theorem realization_beforeStateAt (x : ∀ j, d.BirthOrders j)
    (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s) (k : Fin (n+1)) :
    d.Before (j+k.val) (beforeStateAt ν V η q ρ geometry n j s
      (d.realization ν V η q ρ geometry x n j hend s hs).val k) := by
  induction n generalizing j s with
  | zero =>
      have hk : k.val = 0 := by omega
      simpa only [beforeStateAt,hk,Nat.add_zero] using hs
  | succ n ih =>
      refine Fin.cases ?_ (fun k => ?_) k
      · exact hs
      · have hj : j < N := by omega
        let a := d.ghostOutput j hj.le s hs (x j)
        have ha : d.After j a := d.ghostOutput_after j hj.le s hs (x j)
        let b := d.edgeOutput j hj a ha
        have hb : d.Before (j+1) b := d.edgeOutput_before j hj a ha
        have hh := ih (j+1) (by omega) b hb k
        have he : j+k.succ.val = (j+1)+k.val := by simp only [Fin.val_succ]; omega
        change d.Before (j+k.succ.val) (beforeStateAt ν V η q ρ geometry n (j+1) b
          (d.realization ν V η q ρ geometry x n (j+1) (by omega) b hb).val k)
        rw [he]
        exact hh

/-- The same extraction after the literal ghost operation. -/
theorem realization_afterStateAt (x : ∀ j, d.BirthOrders j)
    (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s) (k : Fin (n+1)) :
    d.After (j+k.val) (afterStateAt ν V η q ρ geometry n j s
      (d.realization ν V η q ρ geometry x n j hend s hs).val k) := by
  induction n generalizing j s with
  | zero =>
      have hk : k.val = 0 := by omega
      have h := d.ghostOutput_after j (by omega) s hs (x j)
      change d.After (j+k.val) (d.ghostOutput j (by omega) s hs (x j))
      simpa only [hk,Nat.add_zero] using h
  | succ n ih =>
      refine Fin.cases ?_ (fun k => ?_) k
      · exact d.ghostOutput_after j (by omega) s hs (x j)
      · have hj : j < N := by omega
        let a := d.ghostOutput j hj.le s hs (x j)
        have ha : d.After j a := d.ghostOutput_after j hj.le s hs (x j)
        let b := d.edgeOutput j hj a ha
        have hb : d.Before (j+1) b := d.edgeOutput_before j hj a ha
        have hh := ih (j+1) (by omega) b hb k
        have he : j+k.succ.val = (j+1)+k.val := by simp only [Fin.val_succ]; omega
        change d.After (j+k.succ.val) (afterStateAt ν V η q ρ geometry n (j+1) b
          (d.realization ν V η q ρ geometry x n (j+1) (by omega) b hb).val k)
        rw [he]
        exact hh

/-- For every arbitrary compatible history, the observed states recover
the schedule invariants at every visit. -/
theorem compatible_observed_states (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) :
    d.Before (j+k.val) (beforeStateAt ν V η q ρ geometry n j s h k) ∧
    d.After (j+k.val) (afterStateAt ν V η q ρ geometry n j s h k) := by
  obtain ⟨x,hx⟩ := d.exists_realization_of_compatible ν V η q ρ geometry n j hend s hs h hc
  rw [← hx]
  exact ⟨d.realization_beforeStateAt ν V η q ρ geometry x n j hend s hs k,
    d.realization_afterStateAt ν V η q ρ geometry x n j hend s hs k⟩

/-- Occurrence in an actual active slot at the visit. -/
def observedActive (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i) : Prop :=
  ∃ a, (beforeStateAt ν V η q ρ geometry n j s h k).active P Line J B i a = p

/-- Occurrence in actual pending memory before the visit. -/
def observedPendingBefore (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i) : Prop :=
  ∃ a, (((beforeStateAt ν V η q ρ geometry n j s h k).memory P Line J B i).values a).1 = p

/-- Occurrence in actual pending memory after the visit. -/
def observedPendingAfter (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i) : Prop :=
  ∃ a, (((afterStateAt ν V η q ρ geometry n j s h k).memory P Line J B i).values a).1 = p

/-- A prime is live if active or pending on either side of the visit. -/
def observedLive (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (k : Fin (n+1)) (i : I) (p : P i) : Prop :=
  observedActive ν V η q ρ geometry n j s h k i p ∨
    observedPendingBefore ν V η q ρ geometry n j s h k i p ∨
    observedPendingAfter ν V η q ρ geometry n j s h k i p

/-- Actual active-slot observations recover the scheduled active visits. -/
theorem compatible_active_trace (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) (i : I) (p : P i) :
    observedActive ν V η q ρ geometry n j s h k i p ↔
      p ∈ d.primes i ∧ j+k.val ∈ (d.lifespan i p).active := by
  have hb := (d.compatible_observed_states ν V η q ρ geometry n j hend s hs h hc k).1
  unfold observedActive
  rw [hb.2.1]
  exact (d.active_lifespan (j+k.val) (by omega) i p).symm

/-- Actual old-memory labels recover the before-pending trace. -/
theorem compatible_before_trace (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) (i : I) (p : P i) :
    observedPendingBefore ν V η q ρ geometry n j s h k i p ↔
      p ∈ before (d.primes i) (d.lifespan i) (j+k.val) :=
  ((d.compatible_observed_states ν V η q ρ geometry n j hend s hs h hc k).1.2.2 i).2.1 p |>.symm

/-- Actual post-ghost labels recover the after-pending trace. -/
theorem compatible_after_trace (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) (i : I) (p : P i) :
    observedPendingAfter ν V η q ρ geometry n j s h k i p ↔
      p ∈ after (d.primes i) (d.lifespan i) (j+k.val) :=
  ((d.compatible_observed_states ν V η q ρ geometry n j hend s hs h hc k).2.2.2 i).2.1 p |>.symm

/-- The live trace is exactly the closed lifespan interval; there are no
holes even when the active visits themselves have gaps. -/
theorem compatible_live_trace (n j : ℕ) (hend : j+n=N)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before j s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hc : d.Compatible ν V η q ρ geometry n j s h) (k : Fin (n+1)) (i : I) (p : P i) :
    observedLive ν V η q ρ geometry n j s h k i p ↔
      p ∈ d.primes i ∧ (d.lifespan i p).birth ≤ j+k.val ∧ j+k.val ≤ (d.lifespan i p).death := by
  unfold observedLive
  rw [d.compatible_active_trace ν V η q ρ geometry n j hend s hs h hc,
    d.compatible_before_trace ν V η q ρ geometry n j hend s hs h hc,
    d.compatible_after_trace ν V η q ρ geometry n j hend s hs h hc]
  simp only [before,after,Finset.mem_filter]
  have hl := (d.lifespan i p).live_iff (j+k.val)
  tauto

/-- The scheduled prime set is recovered from all actual live occurrences.
Every scheduled prime appears, including a prime that is always active. -/
theorem compatible_prime_occurs
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (i : I) (p : P i) :
    p ∈ d.primes i ↔ ∃ k : Fin (N+1), observedLive ν V η q ρ geometry N 0 s h k i p := by
  constructor
  · intro hp
    let k : Fin (N+1) := ⟨(d.lifespan i p).birth,by
      have := (d.lifespan i p).birth_le_death
      have := (d.lifespan i p).death_le
      omega⟩
    refine ⟨k,?_⟩
    rw [d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hs h hc]
    exact ⟨hp,by simp [k],by simpa [k] using (d.lifespan i p).birth_le_death⟩
  · rintro ⟨k,hk⟩
    exact ((d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hs h hc k i p).mp hk).1

/-- Two schedules compatible with the same actual history use exactly the
same prime labels. No relation between their supplied prime sets is assumed. -/
theorem compatible_primes_unique (e : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hsd : d.Before 0 s) (hse : e.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hcd : d.Compatible ν V η q ρ geometry N 0 s h)
    (hce : e.Compatible ν V η q ρ geometry N 0 s h) : d.primes = e.primes := by
  funext i
  ext p
  exact (d.compatible_prime_occurs ν V η q ρ geometry s hsd h hcd i p).trans
    (e.compatible_prime_occurs ν V η q ρ geometry s hse h hce i p).symm

/-- The same actual history determines each used prime's entire lifespan.
Unused prime labels and other unobserved fields are deliberately excluded. -/
theorem compatible_lifespan_unique (e : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hsd : d.Before 0 s) (hse : e.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hcd : d.Compatible ν V η q ρ geometry N 0 s h)
    (hce : e.Compatible ν V η q ρ geometry N 0 s h)
    (i : I) (p : P i) (hp : p ∈ d.primes i) : d.lifespan i p = e.lifespan i p := by
  have he : p ∈ e.primes i := by rw [← d.compatible_primes_unique ν V η q ρ geometry e s hsd hse h hcd hce]; exact hp
  apply PrimeLifespan.eq_of_observable_traces
  · intro j hj
    let k : Fin (N+1) := ⟨j,by omega⟩
    have hd := d.compatible_active_trace ν V η q ρ geometry N 0 (by omega) s hsd h hcd k i p
    have hh := e.compatible_active_trace ν V η q ρ geometry N 0 (by omega) s hse h hce k i p
    simpa only [hp,he,true_and,Nat.zero_add,k] using hd.symm.trans hh
  · intro j hj
    let k : Fin (N+1) := ⟨j,by omega⟩
    rw [(d.lifespan i p).live_iff j,(e.lifespan i p).live_iff j]
    have hd := d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hsd h hcd k i p
    have hh := e.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hse h hce k i p
    simpa only [hp,he,true_and,Nat.zero_add,k] using hd.symm.trans hh

/-- The prime-label set extracted solely from the actual history. -/
def observedPrimes
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (i : I) : Finset (P i) :=
  Finset.univ.filter (fun p => ∃ k : Fin (N+1), observedLive ν V η q ρ geometry N 0 s h k i p)

/-- Explicit recovery of the supplied prime set from actual state data. -/
theorem compatible_primes_recovered
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (i : I) :
    observedPrimes ν V η q ρ geometry s h i = d.primes i := by
  ext p
  simp only [observedPrimes,Finset.mem_filter,Finset.mem_univ,true_and]
  exact (d.compatible_prime_occurs ν V η q ρ geometry s hs h hc i p).symm

/-- Positions and literal active orders are also determined at every
observed visit; no assertion is made about values beyond the horizon. -/
theorem compatible_visit_data_unique (e : ScheduledPhysicalPath anchor N J B)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hsd : d.Before 0 s) (hse : e.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hcd : d.Compatible ν V η q ρ geometry N 0 s h)
    (hce : e.Compatible ν V η q ρ geometry N 0 s h) (j : ℕ) (hj : j ≤ N) :
    d.position j = e.position j ∧ d.active j = e.active j := by
  let k : Fin (N+1) := ⟨j,by omega⟩
  have hd := (d.compatible_observed_states ν V η q ρ geometry N 0 (by omega) s hsd h hcd k).1
  have he := (e.compatible_observed_states ν V η q ρ geometry N 0 (by omega) s hse h hce k).1
  simpa only [k,Nat.zero_add] using
    And.intro (hd.1.symm.trans he.1) (hd.2.1.symm.trans he.2.1)

/-- Finite live-visit data extracted without any supplied schedule. -/
def observedLiveVisits
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (i : I) (p : P i) : Finset ℕ :=
  (Finset.univ.filter (fun k : Fin (N+1) =>
    observedLive ν V η q ρ geometry N 0 s h k i p)).image Fin.val

/-- Finite active-visit data extracted without any supplied schedule. -/
def observedActiveVisits
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (i : I) (p : P i) : Finset ℕ :=
  (Finset.univ.filter (fun k : Fin (N+1) =>
    observedActive ν V η q ρ geometry N 0 s h k i p)).image Fin.val

/-- The literal finite live-visit set is the closed lifespan interval. -/
theorem compatible_liveVisits_recovered
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (i : I) (p : P i)
    (hp : p ∈ d.primes i) :
    observedLiveVisits ν V η q ρ geometry s h i p =
      Finset.Icc (d.lifespan i p).birth (d.lifespan i p).death := by
  ext t
  simp only [observedLiveVisits,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,
    true_and,Finset.mem_Icc]
  constructor
  · rintro ⟨k,hk,rfl⟩
    have hh := (d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hs h hc k i p).mp hk
    simpa only [Nat.zero_add] using hh.2
  · rintro ⟨hb,hd⟩
    have htN : t ≤ N := hd.trans (d.lifespan i p).death_le
    let k : Fin (N+1) := ⟨t,by omega⟩
    refine ⟨k,?_,rfl⟩
    rw [d.compatible_live_trace ν V η q ρ geometry N 0 (by omega) s hs h hc]
    exact ⟨hp,by simpa only [Nat.zero_add,k] using hb,by simpa only [Nat.zero_add,k] using hd⟩

/-- The literal finite active-visit set is exactly the active lifespan set. -/
theorem compatible_activeVisits_recovered
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) (i : I) (p : P i)
    (hp : p ∈ d.primes i) :
    observedActiveVisits ν V η q ρ geometry s h i p = (d.lifespan i p).active := by
  ext t
  simp only [observedActiveVisits,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨k,hk,rfl⟩
    have hh := (d.compatible_active_trace ν V η q ρ geometry N 0 (by omega) s hs h hc k i p).mp hk
    simpa only [Nat.zero_add] using hh.2
  · intro ht
    have htN : t ≤ N := ((d.lifespan i p).active_bounds t ht).2.trans (d.lifespan i p).death_le
    let k : Fin (N+1) := ⟨t,by omega⟩
    refine ⟨k,?_,rfl⟩
    rw [d.compatible_active_trace ν V η q ρ geometry N 0 (by omega) s hs h hc]
    exact ⟨hp,by simpa only [Nat.zero_add,k] using ht⟩

end ScheduledPhysicalPath
end Elliptic.Operator
