module

public import Elliptic.Operator.RootBoundaryCover
public import Mathlib.MeasureTheory.Constructions.BorelSpace.Order

/-!
# Constancy of the actual source multiplier on a good root cell

Both physical-box projections are the literal source predicates. Their
constancy follows from the constructed boundary cover. The two good-state
projections are supplied through their exact pointwise equivalences; all
remaining determinant, pad, cutoff, and Fourier factors are independent
of the root once the integral positions and prime labels are fixed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootSourceGeometry
open RootArchimedeanGrid RootPhysicalCell RootBoundaryCover
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {I : Type*} [Fintype I] {P : I→Type*} {J : ℕ}

theorem source_edge_allowed_constant (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (n : ℕ) (j : Index) (hj : j∈grid n) (positions : Finset (ℤ × ℤ))
    (endpoints : Finset ℝ) (U V d₀ : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n positions U V endpoints)
    (z w : ℤ × ℤ) (hz : z∈positions) (hw : w∈positions)
    (a b : PhysicalActiveLists P J) (p q : RootPoint)
    (hp : Contains n j p) (hq : Contains n j q)
    (hgz : good p z a ↔ good q z a) (hgw : good p w b ↔ good q w b) :
    sourcePhysicalEdgeAllowed value (good p) (U*p.1) (V*p.2.1) p.2.2 U V d₀ z a w b ↔
      sourcePhysicalEdgeAllowed value (good q) (U*q.1) (V*q.2.1) q.2.2 U V d₀ z a w b := by
  have hpz := source_allowed_constant_of_outside n j hj positions endpoints U V hU hV hout z hz p q hp hq
  have hpw := source_allowed_constant_of_outside n j hj positions endpoints U V hU hV hout w hw p q hp hq
  simp only [sourcePhysicalEdgeAllowed,hpz,hpw,hgz,hgw]

theorem source_geometry_constant (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (n : ℕ) (j : Index) (hj : j∈grid n) (positions : Finset (ℤ × ℤ))
    (endpoints : Finset ℝ) (U V d₀ Y : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n positions U V endpoints)
    (z w : ℤ × ℤ) (hz : z∈positions) (hw : w∈positions)
    (a b : PhysicalActiveLists P J) (p q : RootPoint)
    (hp : Contains n j p) (hq : Contains n j q)
    (hgz : good p z a ↔ good q z a) (hgw : good p w b ↔ good q w b) :
    sourcePhysicalEdgeGeometry value (good p) (U*p.1) (V*p.2.1) p.2.2
      U V d₀ Y η ψ major σ z a w b =
    sourcePhysicalEdgeGeometry value (good q) (U*q.1) (V*q.2.1) q.2.2
      U V d₀ Y η ψ major σ z a w b := by
  have h := source_edge_allowed_constant value good n j hj positions endpoints U V d₀ hU hV
    hout z w hz hw a b p q hp hq hgz hgw
  unfold sourcePhysicalEdgeGeometry
  rw [propext h]

theorem oriented_geometry_constant (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (adjoint : Bool) (n : ℕ) (j : Index) (hj : j∈grid n) (positions : Finset (ℤ × ℤ))
    (endpoints : Finset ℝ) (U V d₀ Y : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n positions U V endpoints)
    (z w : ℤ × ℤ) (hz : z∈positions) (hw : w∈positions)
    (a b : PhysicalActiveLists P J) (p q : RootPoint)
    (hp : Contains n j p) (hq : Contains n j q)
    (hgz : good p z a ↔ good q z a) (hgw : good p w b ↔ good q w b) :
    orientedSourceEdgeGeometry adjoint value (good p) (U*p.1) (V*p.2.1) p.2.2
      U V d₀ Y η ψ major σ z a w b =
    orientedSourceEdgeGeometry adjoint value (good q) (U*q.1) (V*q.2.1) q.2.2
      U V d₀ Y η ψ major σ z a w b := by
  cases adjoint
  · exact source_geometry_constant value good n j hj positions endpoints U V d₀ Y hU hV η ψ major σ
      hout z w hz hw a b p q hp hq hgz hgw
  · apply congrArg star
    exact source_geometry_constant value good n j hj positions endpoints U V d₀ Y hU hV η ψ major σ
      hout w z hw hz b a p q hp hq hgw hgz

theorem source_position_measurableSet (U V : ℝ) (z : ℤ × ℤ) :
    MeasurableSet {q : RootPoint |
      sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z} := by
  have h1 : Measurable (fun q : RootPoint => (rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).1) := by
    unfold rootPhysicalPosition latticeTau
    fun_prop
  have h2 : Measurable (fun q : RootPoint => (rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).2) := by
    unfold rootPhysicalPosition latticeTau
    fun_prop
  have hcop : MeasurableSet {q : RootPoint | IsCoprime z.1 z.2} := by
    by_cases h : IsCoprime z.1 z.2 <;> simp [h]
  exact hcop.inter ((measurableSet_le measurable_const h1).inter
    ((measurableSet_le h1 measurable_const).inter
      ((measurableSet_le measurable_const h2).inter (measurableSet_le h2 measurable_const))))

theorem source_edge_measurableSet (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (hgood : ∀ z a, MeasurableSet {q | good q z a})
    (U V d₀ : ℝ) (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J) :
    MeasurableSet {q : RootPoint |
      sourcePhysicalEdgeAllowed value (good q) (U*q.1) (V*q.2.1) q.2.2 U V d₀ z a w b} := by
  have hd : MeasurableSet {q : RootPoint | sourceCrossEdgeBan value a b ∧
      d₀≤(sourcePadProduct value a:ℝ) ∧ (sourcePadProduct value a:ℝ)<2*d₀ ∧
        (sourcePadProduct value a:ℤ)∣latticeDet z w} := by
    by_cases h : sourceCrossEdgeBan value a b ∧
      d₀≤(sourcePadProduct value a:ℝ) ∧ (sourcePadProduct value a:ℝ)<2*d₀ ∧
        (sourcePadProduct value a:ℤ)∣latticeDet z w
    · simp [h]
    · simp [h]
  exact (source_position_measurableSet U V z).inter ((source_position_measurableSet U V w).inter
    ((hgood z a).inter ((hgood w b).inter hd)))

/-- The root dependence is a measurable indicator times an exactly
constant multiplier. No regularity of eta or psi is needed after all
integral positions and prime labels have been fixed. -/
theorem source_geometry_measurable (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (hgood : ∀ z a, MeasurableSet {q | good q z a})
    (U V d₀ Y : ℝ) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J) :
    Measurable (fun q : RootPoint => sourcePhysicalEdgeGeometry value (good q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b) := by
  unfold sourcePhysicalEdgeGeometry
  exact Measurable.ite (source_edge_measurableSet value good hgood U V d₀ z w a b)
    measurable_const measurable_const

theorem oriented_geometry_measurable (value : ∀ i, P i→ℕ)
    (good : RootPoint→(ℤ × ℤ)→PhysicalActiveLists P J→Prop)
    (hgood : ∀ z a, MeasurableSet {q | good q z a})
    (adjoint : Bool) (U V d₀ Y : ℝ) (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J) :
    Measurable (fun q : RootPoint => orientedSourceEdgeGeometry adjoint value (good q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b) := by
  cases adjoint
  · exact source_geometry_measurable value good hgood U V d₀ Y η ψ major σ z w a b
  · exact continuous_star.measurable.comp
      (source_geometry_measurable value good hgood U V d₀ Y η ψ major σ w z b a)

end Elliptic.Operator.RootSourceGeometry
