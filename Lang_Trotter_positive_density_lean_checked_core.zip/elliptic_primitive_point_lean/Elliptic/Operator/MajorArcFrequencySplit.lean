module

public import Elliptic.Operator.SparseFrequencyEnergy

/-!
# The small/large prime-frequency split as an actual integral estimate

The small-prime, long-coefficient, and arbitrary-coefficient factors are
literal continuous functions. The exceptional set is defined by the
actual small-prime polynomial. Its beta energy is left as an actual set
integral for the sparse Gram estimate to control.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcFrequencySplit
open scoped BigOperators
open MeasureTheory Set
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- Exact small/large-frequency splitting, with every loss visible. -/
theorem product_energy_split (P M N : ℝ→ℂ) (hP : Continuous P)
    (hM : Continuous M) (hN : Continuous N) (a b : ℝ) (hab : a≤b)
    (δ A ε : ℝ) (hδ : 0≤δ) (hA : 0≤A) (hε : 0≤ε)
    (hPA : ∀t∈Icc a b,‖P t‖≤A) (hMε : ∀t∈Icc a b,‖M t‖≤ε) :
    (∫t in a..b,‖P t*M t*N t‖^2)≤
      δ^2*(∫t in a..b,‖M t*N t‖^2)+
      A^2*ε^2*(∫t in Ioc a b∩{t:ℝ | δ < ‖P t‖},‖N t‖^2) := by
  let E : Set ℝ := {t | δ < ‖P t‖}
  have hE : MeasurableSet E := isOpen_lt continuous_const hP.norm |>.measurableSet
  have hPN : IntegrableOn (fun t=>‖P t*M t*N t‖^2) (Ioc a b) :=
    (((hP.mul hM).mul hN).norm.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hMN : IntegrableOn (fun t=>‖M t*N t‖^2) (Ioc a b) :=
    ((hM.mul hN).norm.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hNN : IntegrableOn (fun t=>‖N t‖^2) (Ioc a b) :=
    (hN.norm.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hpoint (t : ℝ) (ht : t∈Icc a b) :
      ‖P t*M t*N t‖^2≤δ^2*‖M t*N t‖^2+A^2*ε^2*E.indicator (fun t=>‖N t‖^2) t := by
    by_cases he : t∈E
    · rw [Set.indicator_of_mem he]
      have hp := pow_le_pow_left₀ (norm_nonneg _) (hPA t ht) 2
      have hm := pow_le_pow_left₀ (norm_nonneg _) (hMε t ht) 2
      have hh := mul_le_mul hp hm (sq_nonneg _) (sq_nonneg A)
      have hh' := mul_le_mul_of_nonneg_right hh (sq_nonneg ‖N t‖)
      simp only [norm_mul,mul_pow] at hh' ⊢
      nlinarith [sq_nonneg δ,mul_nonneg (sq_nonneg ‖M t‖) (sq_nonneg ‖N t‖)]
    · rw [Set.indicator_of_notMem he,mul_zero,add_zero]
      have hp : ‖P t‖≤δ := not_lt.mp he
      have hp2 := pow_le_pow_left₀ (norm_nonneg _) hp 2
      have hh := mul_le_mul_of_nonneg_right hp2 (sq_nonneg ‖M t*N t‖)
      simpa only [norm_mul,mul_pow,mul_assoc] using hh
  have hh := setIntegral_mono_on hPN
    ((hMN.const_mul (δ^2)).add ((hNN.indicator hE).const_mul (A^2*ε^2)))
    measurableSet_Ioc (fun t ht=>hpoint t (Ioc_subset_Icc_self ht))
  simp only [Pi.add_apply] at hh
  rw [integral_add (hMN.const_mul (δ^2)) ((hNN.indicator hE).const_mul (A^2*ε^2)),
    integral_const_mul,integral_const_mul,integral_indicator hE] at hh
  rw [Measure.restrict_restrict hE] at hh
  simpa only [intervalIntegral.integral_of_le hab,E,Set.inter_comm] using hh

/-- A beta polynomial is continuous, so its squared magnitude attains a
maximum on each closed unit interval. -/
theorem exists_unit_cell_maxima (N : ℝ→ℂ) (hN : Continuous N) (a : ℝ) :
    ∃τ:ℕ→ℝ,∀i:ℕ,(a+(i:ℝ)≤τ i∧τ i≤a+(i:ℝ)+1)∧
      ∀t∈Icc (a+(i:ℝ)) (a+(i:ℝ)+1),‖N t‖^2≤‖N (τ i)‖^2 := by
  have he (i : ℕ) : ∃t∈Icc (a+(i:ℝ)) (a+(i:ℝ)+1),IsMaxOn (fun t=>‖N t‖^2) (Icc (a+(i:ℝ)) (a+(i:ℝ)+1)) t :=
    isCompact_Icc.exists_isMaxOn ⟨a+(i:ℝ),by constructor <;> linarith⟩ (hN.norm.pow 2).continuousOn
  choose τ hτ hmax using he
  exact ⟨τ,fun i=>⟨hτ i,fun t ht=>hmax i ht⟩⟩

/-- Covering an exceptional set by actual unit cells bounds its beta energy
by the sum at their maximizing points. -/
theorem exceptional_energy_le_samples (N : ℝ→ℂ) (hN : Continuous N)
    (s : Finset ℕ) (a : ℝ) (E : Set ℝ)
    (hcover : E⊆⋃i:ℕ,⋃ (_:i∈s),Ioc (a+(i:ℝ)) (a+(i:ℝ)+1)) (τ : ℕ→ℝ)
    (hmax : ∀i∈s,∀t∈Icc (a+(i:ℝ)) (a+(i:ℝ)+1),‖N t‖^2≤‖N (τ i)‖^2) :
    (∫t in E,‖N t‖^2)≤∑i∈s,‖N (τ i)‖^2 := by
  have hc (i : ℕ) : IntegrableOn (fun t=>‖N t‖^2) (Ioc (a+(i:ℝ)) (a+(i:ℝ)+1)) :=
    (hN.norm.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hdis : Set.Pairwise (↑s : Set ℕ) (fun i j=>Disjoint (Ioc (a+(i:ℝ)) (a+(i:ℝ)+1)) (Ioc (a+(j:ℝ)) (a+(j:ℝ)+1))) := by
    intro i hi j hj hij
    rcases lt_or_gt_of_ne hij with hij|hji
    · apply Set.Ioc_disjoint_Ioc_of_le
      have hh : (i:ℝ)+1≤j := by exact_mod_cast hij
      linarith
    · apply Disjoint.symm
      apply Set.Ioc_disjoint_Ioc_of_le
      have hh : (j:ℝ)+1 ≤ i := by exact_mod_cast hji
      linarith
  calc
    _ ≤ ∫t in ⋃i:ℕ,⋃ (_:i∈s),Ioc (a+(i:ℝ)) (a+(i:ℝ)+1),‖N t‖^2 :=
      setIntegral_mono_set (integrableOn_finset_iUnion.mpr fun i hi=>hc i)
        (Filter.Eventually.of_forall fun t=>sq_nonneg _) (Filter.Eventually.of_forall hcover)
    _ = ∑i∈s,∫t in Ioc (a+(i:ℝ)) (a+(i:ℝ)+1),‖N t‖^2 :=
      integral_biUnion_finset s (fun _ _=>measurableSet_Ioc) hdis (fun i hi=>hc i)
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro i hi
      have hh := intervalIntegral.integral_mono_on (μ:=volume) (show a+(i:ℝ)≤a+(i:ℝ)+1 by linarith)
        ((hN.norm.pow 2).intervalIntegrable _ _) intervalIntegrable_const (hmax i hi)
      rw [intervalIntegral.integral_const] at hh
      simpa only [Pi.pow_apply,intervalIntegral.integral_of_le (show a+(i:ℝ)≤a+(i:ℝ)+1 by linarith),
        add_sub_cancel_left,one_smul] using hh

end Elliptic.Operator.MajorArcFrequencySplit
