module

public import Elliptic.Operator.RootRecordKernel

/-!
# Actual original-record and Bonferroni-subset accumulation

Both endpoint permutations, the original inverse-mass normalization,
the actual finite position/prime records, and every retained prime
subset are charged explicitly. Each term uses its own actual squarefree
CRT modulus. No abstract coefficient-mass premise is introduced.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordAccumulation
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootGridPartition RootArchimedeanTransfer RootVariableSum RootRecordKernel
open IntegerRootReplacement OriginalPathWeights RootDiscreteBudget BonferroniMonomialCount
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

abbrev Term {K : ℕ} {C L : ℝ} (records : Finset (SourceRecord K C L))
    (primes : Finset ℕ) (T : ℕ) := ↥records × ↥(truncatedSubsets primes T)

theorem term_card {K : ℕ} {C L : ℝ} (records : Finset (SourceRecord K C L))
    (primes : Finset ℕ) (T : ℕ) :
    Fintype.card (Term records primes T)=records.card*(truncatedSubsets primes T).card := by
  simp [Term]

theorem eventually_term_mass_le (K : ℕ) (C vmin : ℝ) (hC : 0≤C) (hmin : 0<vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ records : Finset (SourceRecord K C L),
      ∀ primes : Finset ℕ, ∀ T : ℕ,
      (∀p∈primes,(p:ℝ)≤Real.exp (2*L^(1/5:ℝ))) → T≤⌈L^(76/100:ℝ)⌉₊ →
      ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      |normalization VM (momentPadding L) (momentLength L)| *
        (Fintype.card (Term records primes T):ℝ) ≤ Real.exp (12*L^(98/100:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_originalPathRecord_card_le_source_budget K C hC,
    eventually_truncatedSubsets_card_le_exp,eventually_inverse_mass_cost K vmin hmin]
    with L hL hrec hsub hinv
  intro records primes T hpr hT VM hVM
  have hn := normalization_le VM vmin hmin hVM (momentPadding L) (momentLength L)
  have hnormal : |normalization VM (momentPadding L) (momentLength L)|≤Real.exp (L^(73/100:ℝ)) := by
    rw [abs_of_nonneg hn.1]
    exact hn.2.trans hinv
  have hrecords : (records.card:ℝ)≤Real.exp (L^(73/100:ℝ)) := by
    have hh : (records.card:ℝ)≤(Fintype.card (SourceRecord K C L):ℝ) :=
      by exact_mod_cast Finset.card_le_univ records
    exact hh.trans hrec
  have hsubsets := hsub primes T hpr hT
  rw [term_card,Nat.cast_mul]
  calc
    _ ≤ Real.exp (L^(73/100:ℝ))*(Real.exp (L^(73/100:ℝ))*Real.exp (10*L^(96/100:ℝ))) := by
      gcongr
    _ = Real.exp (2*L^(73/100:ℝ)+10*L^(96/100:ℝ)) := by
      rw [←Real.exp_add,←Real.exp_add]; congr 1; ring
    _ ≤ _ := Real.exp_le_exp.mpr (by
      have h73 := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (73/100:ℝ)≤98/100)
      have h96 := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (96/100:ℝ)≤98/100)
      linarith)

theorem eventually_accumulation_cost (δ : ℝ) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop, ∀ U V : ℝ, 0≤U*V →
      Real.exp (12*(Real.log x)^(98/100:ℝ))*(U*V*x^(-(δ/32000))) ≤
        U*V*x^(-(δ/64000)) := by
  have h := Real.tendsto_log_atTop.eventually
    (RootErrorBudget.eventually_subpower_exponent_le 12 (δ/64000) (by positivity))
  filter_upwards [eventually_gt_atTop (0:ℝ),h] with x hx h
  intro U V hUV
  have he : Real.exp (12*(Real.log x)^(98/100:ℝ))≤x^(δ/64000) := by
    rw [Real.rpow_def_of_pos hx]
    exact Real.exp_le_exp.mpr (by nlinarith)
  calc
    _ ≤ x^(δ/64000)*(U*V*x^(-(δ/32000))) := by gcongr
    _ = U*V*(x^(δ/64000)*x^(-(δ/32000))) := by ring
    _ = _ := by rw [←Real.rpow_add hx]; congr 2; ring

/-- The literal normalized original-record expansion, over all retained
Bonferroni prime subsets, has a single power-saving root/integral error.
Signs and coupled residue incidences can be retained inside the bounded
tests; no positivity of the complex geometric multiplier is used. -/
theorem eventually_original_records_transfer (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ vmin : ℝ) (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ records : Finset (SourceRecord K C (Real.log x)), ∀ primes : Finset ℕ, ∀ T : ℕ,
      (∀rec∈records,∀j i a,(recordLabels rec j i a).Prime) →
      (∀p∈primes,p.Prime ∧ (p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      T≤⌈(Real.log x)^(76/100:ℝ)⌉₊ →
      ∀ [∀t : Term records primes T,Fintype (ZMod (recordModulus t.1.val t.2.val))],
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤U*V → 0<d₀ → 1≤Y → ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) →
      ∀ exponents : Fin K→ℝ, ∀ η ψ : ℝ→ℂ,
      (∀t,‖η t‖≤1) → (∀t,‖ψ t‖≤1) → (∀t,η t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin (momentLength (Real.log x))→Bool,
      ∀ ρ : (t : Term records primes T)→Matrix.SpecialLinearGroup (Fin 2)
        (ZMod (recordModulus t.1.val t.2.val))→ℂ,
      (∀t g,‖ρ t g‖≤1) →
      ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
        ((∑t : Term records primes T,
          variableRootSum U V (recordModulus t.1.val t.2.val)
            (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1)
            (recordKernel _ t.1.val adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ (ρ t))) -
         (∑t : Term records primes T,
          rootIntegral U V (recordModulus t.1.val t.2.val)
            (recordKernel _ t.1.val adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ (ρ t))))‖ ≤
        U*V*x^(-(δ/64000)) := by
  have hlog := Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ))
  have hmass := Real.tendsto_log_atTop.eventually (eventually_term_mass_le K C vmin hC hmin)
  filter_upwards [eventually_gt_atTop (0:ℝ),hlog,hmass,eventually_accumulation_cost δ hδ,
    eventually_record_power hPD K hK C δ (16*K+4) hC hδ (by positivity)] with x hx hL hm hc ht
  intro P instP records primes T hrecords hpr hT inst U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM
    value μ hv exponents η ψ hη hψ hsupport major hmajor σ adjoint ρ hρ
  let A (t : Term records primes T) := variableRootSum U V (recordModulus t.1.val t.2.val)
    (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1)
    (recordKernel _ t.1.val adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ (ρ t))
  let B (t : Term records primes T) := rootIntegral U V (recordModulus t.1.val t.2.val)
    (recordKernel _ t.1.val adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ (ρ t))
  have hterm (t : Term records primes T) : ‖A t-B t‖≤U*V*x^(-(δ/32000)) := by
    have hadm := recordModulus_admissible hL t.1.val primes t.2.val T
      (hrecords t.1.val t.1.property) hpr t.2.property hT
    exact ht P U V d₀ Y _ hU hU' hV hV' hUV hd hY hadm.1 hadm.2.1 hadm.2.2
      t.1.val value μ hv exponents η ψ hη hψ hsupport major hmajor σ adjoint (ρ t) (hρ t)
  have hsum : ‖(∑t,A t)-(∑t,B t)‖≤
      (Fintype.card (Term records primes T):ℝ)*(U*V*x^(-(δ/32000))) := by
    rw [←Finset.sum_sub_distrib]
    exact (norm_sum_le _ _).trans (by
      simpa using Finset.sum_le_sum (s:=Finset.univ) (fun t _=>hterm t))
  have hweight := hm records primes T (fun p hp=>(hpr p hp).2) hT VM hVM
  change ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
    ((∑t,A t)-(∑t,B t))‖≤_
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs]
  calc
    _ ≤ |normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
        ((Fintype.card (Term records primes T):ℝ)*(U*V*x^(-(δ/32000)))) :=
      mul_le_mul_of_nonneg_left hsum (abs_nonneg _)
    _ = (|normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
        (Fintype.card (Term records primes T):ℝ))*(U*V*x^(-(δ/32000))) := by ring
    _ ≤ Real.exp (12*(Real.log x)^(98/100:ℝ))*(U*V*x^(-(δ/32000))) :=
      mul_le_mul_of_nonneg_right hweight (mul_nonneg (by linarith) (by positivity))
    _ ≤ _ := hc U V (by linarith)

end Elliptic.Operator.RootRecordAccumulation
