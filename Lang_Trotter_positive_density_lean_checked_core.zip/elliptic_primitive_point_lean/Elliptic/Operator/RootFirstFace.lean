module

public import Elliptic.Operator.RootArchimedeanGrid
public import Elliptic.Operator.SourceMemoryEdges

/-!
# First-coordinate physical faces on the concrete root grid

For `a=u/U`, a first-coordinate physical face is `a*tau(r)=c`, with
`c=1` or `c=16`. The graph bound below is derived from that equation.
No Lipschitz or abstract regular-boundary premise is imported.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootFirstFace
open RootArchimedeanGrid SourceRootCount
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- This is the literal normalized first coordinate of the source root
matrix, so c=1 and c=16 are exactly its two physical box faces. -/
theorem physical_first_face_iff (U V a b r c : ℝ) (hU : U≠0) (z : ℤ × ℤ) :
    (rootPhysicalPosition (U*a) (V*b) r z).1=c*U ↔ a*latticeTau r z=c := by
  dsimp [rootPhysicalPosition]
  constructor
  · intro h
    apply mul_left_cancel₀ hU
    linear_combination h
  · intro h
    linear_combination U*h

theorem cell_point_bounds (a b : ℝ) (n i : ℕ) (hi : i<n)
    (hab : a≤b) (t : ℝ) (ht : (cell a b n i).Contains t) : a≤t ∧ t≤b := by
  have hI := cell_inRange a b hab n i hi
  exact ⟨hI.1.trans ht.1,ht.2.trans hI.2.2⟩

theorem cell_diameter (a b : ℝ) (n i : ℕ) (r s : ℝ)
    (hr : (cell a b n i).Contains r) (hs : (cell a b n i).Contains s) :
    |s-r|≤(b-a)/n := by
  have hlen := cell_length a b n i
  dsimp [RootInterval.length] at hlen
  have hr' : (cell a b n i).lower≤r ∧ r≤(cell a b n i).upper := hr
  have hs' : (cell a b n i).lower≤s ∧ s≤(cell a b n i).upper := hs
  rw [abs_le]
  constructor <;> linarith

/-- Any two points on the same actual face in one r-layer have this
first-coordinate spread, including layers containing an edge endpoint. -/
theorem first_face_spread (z : ℤ × ℤ) (c : ℝ) (hc : 0<c)
    (n k : ℕ) (a b r s : ℝ)
    (ha : 1≤a) (ha' : a≤16) (hb : 1≤b) (hb' : b≤16)
    (hr : (cell 0 1 n k).Contains r) (hs : (cell 0 1 n k).Contains s)
    (har : a*latticeTau r z=c) (hbs : b*latticeTau s z=c) :
    |a-b|≤(256*|(z.2:ℝ)|/c)/(n:ℝ) := by
  have he : c*(a-b)=a*b*(s-r)*(z.2:ℝ) := by
    dsimp [latticeTau] at har hbs
    linear_combination b*har-a*hbs
  have hab : |a*b|≤256 := by
    rw [abs_mul,abs_of_nonneg (by linarith : 0≤a),abs_of_nonneg (by linarith : 0≤b)]
    nlinarith
  have hrs : |s-r|≤(1:ℝ)/n := by simpa using cell_diameter 0 1 n k r s hr hs
  have h := congrArg abs he
  rw [abs_mul,abs_of_pos hc] at h
  have hbound : c*|a-b| ≤ (256*|(z.2:ℝ)|)/(n:ℝ) := by
    calc
      _ = |a*b*(s-r)*(z.2:ℝ)| := h
      _ = |a*b| *|s-r| *|(z.2:ℝ)| := by rw [abs_mul,abs_mul]
      _ ≤ 256*((1:ℝ)/n)*|(z.2:ℝ)| := by gcongr
      _ = _ := by ring
  calc
    |a-b| ≤ (256*|(z.2:ℝ)|/(n:ℝ))/c := (le_div_iff₀ hc).mpr (by nlinarith)
    _ = _ := by ring

theorem nat_finite_window (s : Finset ℕ) (lo hi : ℝ)
    (h : ∀ i∈s, lo≤(i:ℝ) ∧ (i:ℝ)≤hi) :
    (s.card:ℝ) ≤ max 0 (hi-lo+1) := by
  have hc : s.card≤(Finset.Icc ⌈lo⌉ ⌊hi⌋).card := by
    apply Finset.card_le_card_of_injOn (fun i : ℕ => (i:ℤ))
    · intro i hi'
      exact Finset.mem_Icc.mpr ⟨Int.ceil_le.mpr (h i hi').1,Int.le_floor.mpr (h i hi').2⟩
    · intro i _ j _ hij
      exact Int.ofNat_inj.mp hij
  have hcast (q:ℤ) : (q.toNat:ℝ)=max (q:ℝ) 0 := by exact_mod_cast Int.toNat_eq_max q
  have hcR : (s.card:ℝ)≤((Finset.Icc ⌈lo⌉ ⌊hi⌋).card:ℝ) := by exact_mod_cast hc
  apply hcR.trans
  rw [Int.card_Icc,hcast,max_comm]
  apply max_le_max (by rfl)
  have hl := Int.le_ceil lo
  have hu := Int.floor_le hi
  push_cast
  linarith

def columns (n k : ℕ) (z : ℤ × ℤ) (c : ℝ) : Finset ℕ :=
  (Finset.range n).filter fun i => ∃ a r : ℝ,
    (cell 1 16 n i).Contains a ∧ (cell 0 1 n k).Contains r ∧ a*latticeTau r z=c

theorem columns_card (n k : ℕ) (hn : 0<n) (z : ℤ × ℤ) (c : ℝ) (hc : 0<c) :
    ((columns n k z c).card:ℝ) ≤ 2*(256*|(z.2:ℝ)|/c)/15+2 := by
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  have hM : 0≤256*|(z.2:ℝ)|/c := by positivity
  by_cases hempty : (columns n k z c).Nonempty
  · obtain ⟨i₀,hi₀⟩ := hempty
    obtain ⟨a₀,r₀,ha₀,hr₀,hface₀⟩ := (Finset.mem_filter.mp hi₀).2
    have ha₀range := cell_point_bounds 1 16 n i₀
      (Finset.mem_range.mp (Finset.mem_filter.mp hi₀).1) (by norm_num) a₀ ha₀
    let M : ℝ := 256*|(z.2:ℝ)|/c
    let center : ℝ := (n:ℝ)*(a₀-1)/15
    have hwindow : ∀ i∈columns n k z c,
        center-M/15-1≤(i:ℝ) ∧ (i:ℝ)≤center+M/15 := by
      intro i hi
      obtain ⟨a,r,ha,hr,hface⟩ := (Finset.mem_filter.mp hi).2
      have harange := cell_point_bounds 1 16 n i
        (Finset.mem_range.mp (Finset.mem_filter.mp hi).1) (by norm_num) a ha
      have hspread := first_face_spread z c hc n k a a₀ r r₀
        harange.1 harange.2 ha₀range.1 ha₀range.2 hr hr₀ hface hface₀
      change |a-a₀|≤M/(n:ℝ) at hspread
      have hd1 : (a-a₀)*(n:ℝ)≤M :=
        (le_div_iff₀ hnR).mp ((le_abs_self _).trans hspread)
      have hd2 : (a₀-a)*(n:ℝ)≤M :=
        (le_div_iff₀ hnR).mp (by linarith [(abs_le.mp hspread).1])
      have hi1 : 15*(i:ℝ)≤(a-1)*(n:ℝ) := by
        apply (div_le_iff₀ hnR).mp
        have h := ha.1
        dsimp [cell] at h
        norm_num at h
        linarith
      have hi2 : (a-1)*(n:ℝ)≤15*((i:ℝ)+1) := by
        apply (le_div_iff₀ hnR).mp
        have h := ha.2
        dsimp [cell] at h
        norm_num at h
        linarith
      dsimp [center]
      constructor <;> nlinarith
    have h := nat_finite_window (columns n k z c) (center-M/15-1) (center+M/15) hwindow
    have he : center+M/15-(center-M/15-1)+1=2*M/15+2 := by ring
    rw [he,max_eq_right (by dsimp [M]; positivity)] at h
    exact h
  · rw [Finset.not_nonempty_iff_eq_empty.mp hempty]
    simp only [Finset.card_empty,Nat.cast_zero]
    positivity

def faceCubes (n : ℕ) (z : ℤ × ℤ) (c : ℝ) : Finset Index :=
  (Finset.range n).biUnion fun k =>
    ((columns n k z c) ×ˢ Finset.range n).image fun ij => (ij.1,ij.2,k)

theorem face_cube_mem (n : ℕ) (z : ℤ × ℤ) (c : ℝ)
    (j : Index) (hj : j∈grid n) (q : ℝ × ℝ × ℝ)
    (hq : Contains n j q) (hface : q.1*latticeTau q.2.2 z=c) :
    j∈faceCubes n z c := by
  simp only [grid,Finset.mem_product] at hj
  apply Finset.mem_biUnion.mpr
  refine ⟨j.2.2,hj.2.2,?_⟩
  apply Finset.mem_image.mpr
  refine ⟨(j.1,j.2.1),Finset.mem_product.mpr ⟨?_,hj.2.1⟩,rfl⟩
  exact Finset.mem_filter.mpr ⟨hj.1,q.1,q.2.2,hq.1,hq.2.2,hface⟩

theorem faceCubes_subset_grid (n : ℕ) (z : ℤ × ℤ) (c : ℝ) :
    faceCubes n z c ⊆ grid n := by
  intro j hj
  obtain ⟨k,hk,hj'⟩ := Finset.mem_biUnion.mp hj
  obtain ⟨⟨i,l⟩,hil,rfl⟩ := Finset.mem_image.mp hj'
  have hi := (Finset.mem_filter.mp (Finset.mem_product.mp hil).1).1
  have hl := (Finset.mem_product.mp hil).2
  exact Finset.mem_product.mpr ⟨hi,Finset.mem_product.mpr ⟨hl,hk⟩⟩

theorem faceCubes_card (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (c : ℝ) (hc : 0<c) :
    ((faceCubes n z c).card:ℝ)≤(2*(256*|(z.2:ℝ)|/c)/15+2)*(n:ℝ)^2 := by
  have hcard : (faceCubes n z c).card ≤
      ∑ k∈Finset.range n, (columns n k z c).card*n := by
    apply Finset.card_biUnion_le.trans
    apply Finset.sum_le_sum
    intro k hk
    exact Finset.card_image_le.trans_eq (by simp)
  calc
    _ ≤ ∑ k∈Finset.range n, ((columns n k z c).card:ℝ)*(n:ℝ) := by exact_mod_cast hcard
    _ ≤ ∑ _k∈Finset.range n, (2*(256*|(z.2:ℝ)|/c)/15+2)*(n:ℝ) := by
      apply Finset.sum_le_sum
      intro k hk
      exact mul_le_mul_of_nonneg_right (columns_card n k hn z c hc) (Nat.cast_nonneg _)
    _ = _ := by simp; ring

/-- The actual first-coordinate face has a proved O((1+|z₂|)/n)
covering volume. Both source faces are obtained by c=1 and c=16. -/
theorem faceCubes_volume (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (c : ℝ) (hc : 0<c) :
    ∑ j∈faceCubes n z c, cellVolume n j ≤ (512*|(z.2:ℝ)|/c+30)/(n:ℝ) := by
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  simp only [cellVolume_eq,Finset.sum_const,nsmul_eq_mul]
  calc
    _ ≤ ((2*(256*|(z.2:ℝ)|/c)/15+2)*(n:ℝ)^2)*(15/(n:ℝ)^3) :=
      mul_le_mul_of_nonneg_right (faceCubes_card n hn z c hc) (by positivity)
    _ = _ := by field_simp; ring

end Elliptic.Operator.RootFirstFace
