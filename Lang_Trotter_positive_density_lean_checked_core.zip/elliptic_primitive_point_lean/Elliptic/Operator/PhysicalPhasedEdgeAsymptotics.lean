module

public import Elliptic.Operator.PhysicalPhasedEdgeBudget
public import Elliptic.Operator.PhysicalComparisonBudgetAsymptotics
public import Elliptic.Operator.DirtyRowAsymptotics

/-! The actual modified-edge budget has a fixed power of L, uniformly in
finite physical spaces and in all bounded birth phases. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdgeAsymptotics
open Filter
open scoped BigOperators
open PhysicalPhasedEdgeNorm PhysicalPhasedEdgeBudget PhysicalMaskBudgetBounds
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 theorem sqrt_two_sq_le (x y : ℝ) (hx : 0≤x) (hy : 0≤y) :
    Real.sqrt (2*(x^2+y^2))≤2*(x+y) := by
  apply (Real.sqrt_le_sqrt (show 2*(x^2+y^2)≤(2*(x+y))^2 by nlinarith [mul_nonneg hx hy])).trans_eq
  exact Real.sqrt_sq (by positivity)

 def degree (K : ℕ) (E : ℝ) : ℝ := max (3*E) 0+2*(K:ℝ)
 def comparisonConstant (K : ℕ) (v0 vmin vmax M A C : ℝ) : ℝ :=
  4*A*Real.sqrt (reverseBound K vmin vmax)*(comparisonCoarse C+2*comparisonGeo C)*
    ((1+v0)*(2*vmin⁻¹/v0+M))^K
 def constant (K : ℕ) (v0 vmin vmax M A C : ℝ) : ℝ :=
  2*(4:ℝ)^K*(crudeRaw K v0 vmin vmax M A+comparisonConstant K v0 vmin vmax M A C)

 theorem crudeComparison_le (K : ℕ) (L v0 vmin vmax M A H E C : ℝ)
    (hL : 1≤L) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A)
    (hH : 0≤H) (hHl : H≤L^E) (hC : 0≤C) :
    crudeComparison K (memoryCutoff L) v0 vmin vmax M A H C≤
      comparisonConstant K v0 vmin vmax M A C*L^(degree K E) := by
  have hL0 : 0<L := by linarith
  have hQ : 0≤comparisonCoarse C+2*comparisonGeo C := by unfold comparisonCoarse comparisonGeo;positivity
  have hH3 : H^3≤L^(max (3*E) 0) := by
    apply (pow_le_pow_left₀ hH hHl 3).trans
    have he : (L^E)^3=L^(3*E) := by
      rw [←Real.rpow_mul_natCast hL0.le]
      congr 1
      norm_num
      ring
    rw [he]
    exact Real.rpow_le_rpow_of_exponent_le hL (le_max_left _ _)
  have hm := PhysicalComparisonBudgetAsymptotics.memory_polynomial_le K L v0 vmin M hL hv0 hmin hM
  unfold crudeComparison comparisonConstant degree
  calc
    _ ≤ (4*A*L^(max (3*E) 0))*Real.sqrt (reverseBound K vmin vmax)*
        ((comparisonCoarse C+2*comparisonGeo C)*
          (((1+v0)*(2*vmin⁻¹/v0+M))^K*L^(2*(K:ℝ)))) := by gcongr
    _ = _ := by rw [Real.rpow_add hL0];ring

 theorem allMaskBudget_polynomial {K J : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (ρ v0 vmin vmax M L A H E Y C R : ℝ) (a : Fin K→ℝ)
    (hν : ∀i p,0≤ν i p) (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin)
    (hM : 0≤M) (hA : 0≤A) (hH : 0≤H) (hL : 1≤L) (hHl : H≤L^E)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax) (hmass : ∀i,(∑p,ν i p)≤M)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R)
    (hraw : rawSaving K J (memoryCutoff L) ρ v0 vmin M L a≤1) (hcomp : comparisonSaving Y R≤2) :
    allMaskBudget (J:=J) (B:=memoryCutoff L) ν V ρ v0 vmin M L A H Y C R a≤
      constant K v0 vmin vmax M A C*L^(degree K E) := by
  have hr : 0≤crudeRaw K v0 vmin vmax M A := by unfold crudeRaw;positivity
  have hc : 0≤crudeComparison K (memoryCutoff L) v0 vmin vmax M A H C := by
    unfold crudeComparison comparisonCoarse comparisonGeo;positivity
  have hD : 0≤degree K E := by unfold degree;positivity
  have hp : 1≤L^(degree K E) := Real.one_le_rpow hL hD
  apply (allMaskBudget_le ν V ρ v0 vmin vmax M L A H Y C R a hν hρ hv0 hmin hM hA hH
    hlo hhi hmass hY hC hR hraw hcomp).trans
  have hs : Real.sqrt (2*((crudeRaw K v0 vmin vmax M A)^2+
      (crudeComparison K (memoryCutoff L) v0 vmin vmax M A H C)^2))≤
      2*(crudeRaw K v0 vmin vmax M A+crudeComparison K (memoryCutoff L) v0 vmin vmax M A H C) := by
    exact sqrt_two_sq_le _ _ hr hc
  apply (mul_le_mul_of_nonneg_left hs (by positivity)).trans
  have hraw' := le_mul_of_one_le_right hr hp
  have hcomp' := crudeComparison_le K L v0 vmin vmax M A H E C hL hv0 hmin hM hA hH hHl hC
  calc
    _ ≤ (4:ℝ)^K*(2*(crudeRaw K v0 vmin vmax M A*L^(degree K E)+
      comparisonConstant K v0 vmin vmax M A C*L^(degree K E))) := by gcongr
    _ = _ := by unfold constant;ring

 theorem eventually_budget_le_power (K : ℕ) (ρ v0 vmin vmax M A E C : ℝ)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀(J : ℕ) (a : Fin K→ℝ)
      (P : Fin K→Type) (_ : ∀i,Fintype (P i)) (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (H Y R : ℝ),
      (∀i p,0≤ν i p)→(∀i,(∑p,ν i p)≤M)→(∀i,vmin≤V i)→(∀i,V i≤vmax)→
      0≤H→H≤L^E→Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
      rawSaving K J (memoryCutoff L) ρ v0 vmin M L a≤1→
      allMaskBudget (J:=J) (B:=memoryCutoff L) ν V ρ v0 vmin M L A H Y C R a≤L^(degree K E+1) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop (constant K v0 vmin vmax M A C)] with L hL hconst
  intro J a P instP ν V H Y R hν hmass hlo hhi hH hHl hY hR hraw
  letI : ∀i,Fintype (P i) := instP
  have hY0 : 0≤Y := (Real.exp_pos _).le.trans hY
  have hR0 : 0≤R := (Real.exp_pos _).le.trans hR
  have hc := PhysicalComparisonBudgetAsymptotics.comparisonSaving_le_two L Y R (by linarith) hY hR
  apply (allMaskBudget_polynomial ν V ρ v0 vmin vmax M L A H E Y C R a hν hρ hv0 hmin hM hA hH hL hHl
    hlo hhi hmass hY0 hC hR0 hraw hc).trans
  calc
    _ ≤ L*L^(degree K E) := mul_le_mul_of_nonneg_right hconst (by positivity)
    _ = _ := by rw [Real.rpow_add (by linarith : 0<L),Real.rpow_one];ring

 theorem exists_group_count_for_modified_budget :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀ρ v0 vmin vmax M A E C : ℝ,ρ<1→0<v0→0<vmin→0≤M→0≤A→0≤C→
      ∀ᶠL : ℝ in atTop,∀a : Fin K→ℝ,(∀i,(1/10:ℝ)≤a i)→
        ∀(P : Fin K→Type) (_ : ∀i,Fintype (P i)) (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (H Y R : ℝ),
        (∀i p,0≤ν i p)→(∀i,(∑p,ν i p)≤M)→(∀i,vmin≤V i)→(∀i,V i≤vmax)→
        0≤H→H≤L^E→Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
        allMaskBudget (J:=momentPadding L) (B:=memoryCutoff L) ν V ρ v0 vmin M L A H Y C R a≤
          L^(degree K E+1) := by
  obtain ⟨K₀,hK₀,hrow⟩ := DirtyRowAsymptotics.exists_group_count_for_row_saving 0
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ρ v0 vmin vmax M A E C hρ hv0 hmin hM hA hC
  filter_upwards [hrow K hK ρ v0 vmin M hρ hv0 hmin hM,
    eventually_budget_le_power K ρ v0 vmin vmax M A E C hρ hv0 hmin hM hA hC] with L hr hb
  intro a ha P instP ν V H Y R hν hmass hlo hhi hH hHl hY hR
  apply hb (momentPadding L) a P instP ν V H Y R hν hmass hlo hhi hH hHl hY hR
  simpa only [rawSaving,neg_zero,Real.rpow_zero] using hr a ha

end Elliptic.Operator.PhysicalPhasedEdgeAsymptotics
