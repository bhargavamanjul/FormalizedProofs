module
public import Elliptic.Operator.MellinModulationBounds

/-! One-prime Mellin inversion for every fixed smooth cutoff on a positive compact interval.
This includes the actual source interval [1,4] and uses proved Fourier inversion. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinGeneralCutoff
open MeasureTheory FourierTransform
open scoped BigOperators SchwartzMap
open Artin.MarkedSource Artin.MarkedReplacement
open MellinPrimeSeparation MellinModulationBounds FourierL1Control
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

/-- Logarithmic coordinates preserve compact support bounded away from zero. -/
theorem logProfile_compact (η:ℝ→ℂ) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) : HasCompactSupport (fun x:ℝ=>η (Real.exp x)) := by
  apply HasCompactSupport.of_support_subset_isCompact
    (isCompact_Icc : IsCompact (Set.Icc (Real.log a) (Real.log b)))
  intro x hx
  obtain ⟨hl,hu⟩ := hsupp (Real.exp x) hx
  constructor
  · simpa only [Real.log_exp] using Real.log_le_log ha hl
  · simpa only [Real.log_exp] using Real.log_le_log (Real.exp_pos x) hu

theorem twisted_smooth (η:ℝ→ℂ) (hη:Smooth η) (lam:ℝ) : Smooth (twistedCutoff η lam) := by
  unfold twistedCutoff Elliptic.SourceContracts.additivePhase
  apply hη.mul
  have hr : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun x:ℝ=>2*Real.pi*(-lam*x)) := by fun_prop
  exact ((Complex.ofRealCLM.contDiff.comp hr).mul (contDiff_const (c:=Complex.I))).cexp

theorem twisted_support (η:ℝ→ℂ) (a b lam:ℝ)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) :
    ∀y,twistedCutoff η lam y≠0→a≤y ∧ y≤b := by
  intro y hy
  apply hsupp y
  intro h
  simp [twistedCutoff,h] at hy

/-- The source-normalized kernel is integrable for every such cutoff. -/
theorem fourierKernel_integrable (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) : Integrable (fourierKernel η) := by
  let F := (logProfile_compact η a b ha hsupp).toSchwartzMap (hη.comp Real.contDiff_exp)
  have hf : Integrable (𝓕 (fun x:ℝ=>η (Real.exp x))) := (𝓕 F).integrable
  have hh := (hf.comp_div (by positivity : (2*Real.pi:ℝ)≠0)).const_mul (((2*Real.pi:ℝ)⁻¹):ℂ)
  have he : fourierKernel η=(fun v:ℝ=>(((2*Real.pi:ℝ)⁻¹):ℂ)*𝓕 (fun x:ℝ=>η (Real.exp x)) (v/(2*Real.pi))) := funext (fourierKernel_eq η)
  rw [he]
  exact hh

theorem scaledKernel_integrable (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (Y:ℝ) : Integrable (scaledKernel η Y) := by
  apply (fourierKernel_integrable η hη a b ha hsupp).mul_bdd (c:=1)
  · apply Continuous.aestronglyMeasurable
    fun_prop
  · filter_upwards [] with v
    have he : Complex.exp (-Complex.I*(v:ℂ)*(Real.log Y:ℂ))=
        Complex.exp (Complex.I*((-v*Real.log Y:ℝ):ℂ)) := by congr 1; push_cast; ring
    rw [he,Complex.norm_exp_I_mul_ofReal]

/-- Fourier inversion with the literal manuscript normalization, proved without a source contract. -/
theorem fourierKernel_inversion (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (z:ℝ) :
    η (Real.exp z)=∫v:ℝ,fourierKernel η v*Complex.exp (Complex.I*((v*z:ℝ):ℂ)) := by
  let F := (logProfile_compact η a b ha hsupp).toSchwartzMap (hη.comp Real.contDiff_exp)
  have hi := congrArg (fun G:𝓢(ℝ,ℂ)=>G z) (fourierInv_fourier_eq (F:=𝓢(ℝ,ℂ)) F)
  rw [SchwartzMap.fourierInv_coe,Real.fourierInv_eq'] at hi
  simp only [smul_eq_mul] at hi
  let r := 2*Real.pi
  have hr : 0<r := by dsimp [r]; positivity
  let g : ℝ→ℂ := fun v=>(𝓕 F) v*Complex.exp (Complex.I*((r*v*z:ℝ):ℂ))
  have hmain : η (Real.exp z)=∫v:ℝ,g v := by
    apply hi.symm.trans
    apply integral_congr_ae
    filter_upwards [] with v
    dsimp [g]
    rw [mul_comm]
    congr 2
    simp only [RCLike.inner_apply',conj_trivial]
    dsimp [r]
    push_cast
    ring
  have he (v:ℝ) : fourierKernel η v*Complex.exp (Complex.I*((v*z:ℝ):ℂ))=
      ((r:ℂ)⁻¹)*g (v/r) := by
    rw [fourierKernel_eq]
    dsimp only [g]
    have hv : r*(v/r)*z=v*z := by field_simp
    rw [hv]
    change (((2*Real.pi:ℝ)⁻¹):ℂ)*𝓕 (fun x:ℝ=>η (Real.exp x)) (v/(2*Real.pi))*_=((r:ℂ)⁻¹)*(𝓕 (fun x:ℝ=>η (Real.exp x)) (v/r)*_)
    simp only [r,Complex.ofReal_inv,mul_assoc]
  simp_rw [he]
  rw [integral_const_mul]
  have hs := Measure.integral_comp_mul_right g r⁻¹
  have hs' : (∫v:ℝ,g (v/r))=(r:ℂ)*(∫v:ℝ,g v) := by
    simpa only [div_eq_mul_inv,inv_inv,abs_of_pos hr,Complex.real_smul] using hs
  rw [hs',←hmain]
  have hrC : (r:ℂ)≠0 := by exact_mod_cast hr.ne'
  field_simp

/-- Exact scaled two-label inversion for an arbitrary positive-support cutoff. -/
theorem scaledKernel_pair_inversion (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (Y:ℝ) (hY:0<Y) (m n:ℕ) (hm:0<m) (hn:0<n) :
    η ((m*n:ℕ)/Y)=∫v:ℝ,scaledKernel η Y v*archimedeanPhase v m*archimedeanPhase v n := by
  have hmR : (0:ℝ)<m := by exact_mod_cast hm
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  have hmn : (0:ℝ)<(m*n:ℕ)/Y := by positivity
  rw [←Real.exp_log hmn,fourierKernel_inversion η hη a b ha hsupp]
  apply integral_congr_ae
  filter_upwards [] with v
  unfold scaledKernel archimedeanPhase
  rw [mul_assoc,mul_assoc,←Complex.exp_add,←Complex.exp_add]
  congr 2
  rw [Nat.cast_mul,Real.log_div (mul_pos hmR hnR).ne' hY.ne',Real.log_mul hmR.ne' hnR.ne']
  push_cast
  ring

/-- Multiplying by the two unit-modulus label phases preserves integrability. -/
theorem scaledKernel_pair_integrable (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (Y:ℝ) (m n:ℕ) :
    Integrable (fun v:ℝ=>scaledKernel η Y v*archimedeanPhase v m*archimedeanPhase v n) := by
  apply ((scaledKernel_integrable η hη a b ha hsupp Y).mul_bdd (c:=1) ?_ ?_).mul_bdd (c:=1)
  · apply Continuous.aestronglyMeasurable
    unfold archimedeanPhase
    fun_prop
  · filter_upwards [] with v
    rw [archimedeanPhase_norm]
  · apply Continuous.aestronglyMeasurable
    unfold archimedeanPhase
    fun_prop
  · filter_upwards [] with v
    rw [archimedeanPhase_norm]

/-- Uniform polynomial modulation cost for cutoffs on any fixed positive compact interval. -/
theorem twisted_scaledKernel_L1 (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) :
    ∃C:ℝ,0<C ∧ ∀lam Y:ℝ,
      Integrable (scaledKernel (twistedCutoff η lam) Y) ∧
      (∫v:ℝ,‖scaledKernel (twistedCutoff η lam) Y v‖)≤C*(1+|lam|)^2 := by
  obtain ⟨C,hC,hbound⟩ := modulated_fourier_L1 (fun x:ℝ=>η (Real.exp x))
    (logProfile_compact η a b ha hsupp) (hη.comp Real.contDiff_exp)
  refine ⟨C*(1+2*Real.pi)^2,by positivity,?_⟩
  intro lam Y
  refine ⟨scaledKernel_integrable _ (twisted_smooth η hη lam) a b ha (twisted_support η a b lam hsupp) Y,?_⟩
  simp_rw [scaledKernel_norm]
  rw [fourierKernel_L1_eq,twistedCutoff_logProfile]
  have hb := hbound (-2*Real.pi*lam)
  have he : |-2*Real.pi*lam|=2*Real.pi*|lam| := by
    rw [abs_mul,abs_mul,abs_of_pos Real.pi_pos]
    norm_num
  rw [he] at hb
  have hlin : 1+2*Real.pi*|lam|≤(1+2*Real.pi)*(1+|lam|) := by nlinarith [abs_nonneg lam,Real.pi_pos]
  have hm := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) hlin 2) hC.le
  exact hb.trans (by nlinarith [hm])

/-- Exact finite one-prime separation for the actual general-support endpoint cutoff. -/
theorem endpoint_separation (S R:Finset ℕ) (hS:∀p∈S,0<p) (hR:∀r∈R,0<r)
    (c d:ℕ→ℂ) (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (lam Y t:ℝ) (hY:0<Y) :
    endpoint S R c d η lam Y t=
      ∫ξ:ℝ,scaledKernel (twistedCutoff η lam) Y ξ*
        (∑p∈S,c p*archimedeanPhase (t+ξ) p)*
        (∑r∈R,d r*archimedeanPhase (t+ξ) r) := by
  have ht := twisted_smooth η hη lam
  have hs := twisted_support η a b lam hsupp
  have hh := smooth_separation S R
    (fun p=>c p*archimedeanPhase t p) (fun r=>d r*archimedeanPhase t r)
    (fun _=>1) (fun n=>twistedCutoff η lam ((n:ℝ)/Y))
    (scaledKernel (twistedCutoff η lam) Y) archimedeanPhase
    (fun p hp r hr=>scaledKernel_pair_inversion _ ht a b ha hs Y hY p r (hS p hp) (hR r hr))
    (fun p hp r hr=>scaledKernel_pair_integrable _ ht a b ha hs Y p r)
  calc
    _ = ∑p∈S,∑r∈R,(c p*archimedeanPhase t p)*(d r*archimedeanPhase t r)*
        1*twistedCutoff η lam ((p*r:ℕ)/Y) := by
      unfold endpoint
      apply Finset.sum_congr rfl
      intro p hp
      apply Finset.sum_congr rfl
      intro r hr
      rw [archimedeanPhase_mul t (hS p hp).ne' (hR r hr).ne']
      ring
    _ = _ := by
      rw [hh]
      apply integral_congr_ae
      filter_upwards [] with ξ
      simp only [bilinear,archimedeanPhase_add,Finset.mul_sum,Finset.sum_mul]
      conv_rhs => rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro p hp
      apply Finset.sum_congr rfl
      intro r hr
      ring

/-- Literal source normalization, now valid in particular for support [1,4]. -/
theorem normalized_endpoint_separation (S R:Finset ℕ) (hS:∀p∈S,0<p) (hR:∀r∈R,0<r)
    (c d:ℕ→ℂ) (η:ℝ→ℂ) (hη:Smooth η) (a b:ℝ) (ha:0<a)
    (hsupp:∀y,η y≠0→a≤y ∧ y≤b) (lam P Y t:ℝ) (hP:0<P) (hY:0<Y) :
    (Y:ℂ)⁻¹*endpoint S R c d η lam Y t=
      ∫ξ:ℝ,scaledKernel (twistedCutoff η lam) Y ξ*
        MellinPrimeSeparation.primePolynomial S c P (t+ξ)*
        remainingPolynomial R d P Y (t+ξ) := by
  rw [endpoint_separation S R hS hR c d η hη a b ha hsupp lam Y t hY,←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with ξ
  unfold MellinPrimeSeparation.primePolynomial remainingPolynomial
  have hPC : (P:ℂ)≠0 := by exact_mod_cast hP.ne'
  push_cast
  field_simp

end Elliptic.Operator.MellinGeneralCutoff
