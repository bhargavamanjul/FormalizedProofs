module

public import Elliptic.Operator.PhysicalPathSupport
public import Elliptic.Operator.PhysicalDirtyCoordinates
public import Elliptic.Operator.SourceGoodState

/-!
# Physical slope cells embed into the actual normalized pad lattice

Pad divisibility and a primitive pivot supply integral coordinates. The
physical box and slope-cell width give the bounded shear region needed by
the independently constructed good-state basis. No coordinate-box or
shortest-vector bound is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPadLattice

def padCoordinates (z w : ℤ × ℤ) (D : ℤ) (v : ℤ × ℤ) : ℤ × ℤ :=
  (latticeDet v w, latticeDet z v / D)

theorem padCoordinates_reconstruct (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (v : ℤ × ℤ) (hdiv : D ∣ latticeDet z v) :
    targetVector z w (D*(padCoordinates z w D v).2) (padCoordinates z w D v).1 = v := by
  dsimp only [padCoordinates]
  rw [mul_comm D, Int.ediv_mul_cancel hdiv]
  exact targetVector_decomposition hzw v

theorem padCoordinates_injective (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) : Function.Injective
      (fun v : {v : ℤ × ℤ // D ∣ latticeDet z v} => padCoordinates z w D v.val) := by
  intro v u h
  dsimp only at h
  apply Subtype.ext
  rw [← padCoordinates_reconstruct z w hzw D v.val v.property,
    ← padCoordinates_reconstruct z w hzw D u.val u.property,h]

/-- The determinant on the pad lattice has the required scale factor `D`. -/
theorem padCoordinates_det (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (v t : ℤ × ℤ) (hv : D ∣ latticeDet z v)
    (ht : D ∣ latticeDet z t) :
    D * latticeDet (padCoordinates z w D v) (padCoordinates z w D t) =
      latticeDet v t := by
  have hv' := padCoordinates_reconstruct z w hzw D v hv
  have ht' := padCoordinates_reconstruct z w hzw D t ht
  conv_rhs => rw [← hv', ← ht']
  dsimp only [targetVector, latticeDet] at *
  linear_combination
    -(D * (padCoordinates z w D v).1 * (padCoordinates z w D t).2 -
      D * (padCoordinates z w D v).2 * (padCoordinates z w D t).1) * hzw

/-- The physical tau ratio is exactly the first sheared coordinate. -/
theorem padCoordinates_tau (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (r : ℝ) (hz : latticeTau r z ≠ 0)
    (v : ℤ × ℤ) (hdiv : D ∣ latticeDet z v) :
    ((padCoordinates z w D v).1 : ℝ) +
      ((padCoordinates z w D v).2 : ℝ) * ((D : ℝ)*latticeTau r w/latticeTau r z) =
        latticeTau r v / latticeTau r z := by
  have he : ((padCoordinates z w D v).2 : ℝ)*(D : ℝ) = (latticeDet z v : ℝ) := by
    exact_mod_cast Int.ediv_mul_cancel hdiv
  rw [latticeTau_ratio_coordinates hzw r hz v]
  change (latticeDet v w : ℝ) + _ = (latticeDet v w : ℝ) + _
  congr 1
  calc
    _ = (((padCoordinates z w D v).2 : ℝ)*(D : ℝ)) *
        (latticeTau r w/latticeTau r z) := by ring
    _ = _ := by rw [he]

/-- A slope cell of width C*d0*Y and the literal physical tau range imply
the bounded normalized shear region of source (4.26). -/
theorem padCoordinates_height_le
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (r d₀ Y C : ℝ) (hd : 0 < d₀) (hD : d₀ ≤ (D : ℝ))
    (hY : 0 < Y) (hC : 1 ≤ C)
    (v : ℤ × ℤ) (hdiv : D ∣ latticeDet z v)
    (hz : 1/16 ≤ latticeTau r z ∧ latticeTau r z ≤ 16)
    (hv : 1/16 ≤ latticeTau r v ∧ latticeTau r v ≤ 16)
    (hratio : |latticeTau r v/latticeTau r z| ≤ 16)
    (hcell : |latticeSlope r v-latticeSlope r z| ≤ C*d₀*Y) :
    SourceGoodState.height ((D : ℝ)*latticeTau r w/latticeTau r z) Y
      (padCoordinates z w D v) ≤ 256*C := by
  have hz0 : 0 < latticeTau r z := by linarith [hz.1]
  have hv0 : 0 < latticeTau r v := by linarith [hv.1]
  have hD0 : (0 : ℝ) < D := hd.trans_le hD
  have hC0 : 0 ≤ C := by linarith
  have htau : latticeTau r z*latticeTau r v ≤ 256 := by nlinarith [mul_le_mul hz.2 hv.2 hv0.le (by norm_num : (0:ℝ)≤16)]
  rw [latticeSlope_sub r z v hz0.ne' hv0.ne',abs_div,abs_of_pos (mul_pos hz0 hv0)] at hcell
  have hdet : |(latticeDet z v : ℝ)| ≤ 256*C*(D : ℝ)*Y := by
    calc
      _ ≤ (C*d₀*Y)*(latticeTau r z*latticeTau r v) :=
        (div_le_iff₀ (mul_pos hz0 hv0)).mp hcell
      _ ≤ (C*d₀*Y)*256 := mul_le_mul_of_nonneg_left htau (by positivity)
      _ ≤ 256*C*(D : ℝ)*Y := by nlinarith [mul_le_mul_of_nonneg_left hD (show 0 ≤ C*Y by positivity)]
  have he : |((padCoordinates z w D v).2 : ℝ)| * (D : ℝ) = |(latticeDet z v : ℝ)| := by
    have hm : ((padCoordinates z w D v).2 : ℝ)*(D : ℝ) = (latticeDet z v : ℝ) := by
      exact_mod_cast Int.ediv_mul_cancel hdiv
    simpa only [abs_mul,abs_of_pos hD0] using congrArg abs hm
  have hl : |((padCoordinates z w D v).2 : ℝ)|/Y ≤ 256*C := by
    apply (div_le_iff₀ hY).mpr
    nlinarith [he,hdet]
  unfold SourceGoodState.height
  apply max_le
  · rw [padCoordinates_tau z w hzw D r hz0.ne' v hdiv]
    exact hratio.trans (by linarith)
  · exact hl

/-- The previous bound with both tau intervals and the ratio derived from
the actual source boxes; only the chosen cell-width condition remains. -/
theorem physical_padCoordinates_height_le
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (u v r U W d₀ Y C : ℝ)
    (hU : 0 < U) (hu : U ≤ u) (hu' : u ≤ 16*U)
    (hd : 0 < d₀) (hD : d₀ ≤ (D : ℝ)) (hY : 0 < Y) (hC : 1 ≤ C)
    (t : ℤ × ℤ) (hdiv : D ∣ latticeDet z t)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (ht : sourcePhysicalPositionAllowed u v r U W t)
    (hcell : |latticeSlope r t-latticeSlope r z| ≤ C*d₀*Y) :
    SourceGoodState.height ((D : ℝ)*latticeTau r w/latticeTau r z) Y
      (padCoordinates z w D t) ≤ 256*C :=
  padCoordinates_height_le z w hzw D r d₀ Y C hd hD hY hC t hdiv
    (sourcePhysicalPosition_tau_bounds u v r U W z hU hu hu' hz)
    (sourcePhysicalPosition_tau_bounds u v r U W t hU hu hu' ht)
    (sourcePhysicalPositionAllowed_ratio_le u v r U W z t hU hz ht).2 hcell

/-- The two coordinate changes are injective on the actual pad lattice. -/
theorem balancedPadCoordinates_injective (z w : ℤ × ℤ)
    (hzw : latticeDet z w = 1) (D : ℤ) (b₁ b₂ : ℤ × ℤ)
    (hb : latticeDet b₁ b₂ = 1) :
    Function.Injective (fun t : {t : ℤ × ℤ // D ∣ latticeDet z t} =>
      SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t.val)) :=
  (SourceGoodState.basisCoordinates_injective b₁ b₂ hb).comp
    (padCoordinates_injective z w hzw D)

/-- Passing to the balanced basis preserves the physical determinant
formula, so the phase scale is exactly `D`. -/
theorem balancedPadCoordinates_det (z w : ℤ × ℤ)
    (hzw : latticeDet z w = 1) (D : ℤ) (b₁ b₂ : ℤ × ℤ)
    (hb : latticeDet b₁ b₂ = 1) (v t : ℤ × ℤ)
    (hv : D ∣ latticeDet z v) (ht : D ∣ latticeDet z t) :
    D * latticeDet
      (SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D v))
      (SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t)) =
        latticeDet v t := by
  rw [SourceGoodState.basisCoordinates_determinant b₁ b₂ hb]
  exact padCoordinates_det z w hzw D v t hv ht

/-- Actual physical positions in the chosen slope cell and pad lattice
embed in an integral balanced rectangle. The good-state test is imposed
on the actual shear parameter `D*tau(w)/tau(z)`; no lattice box is assumed.
The physical cell, divisibility and good-state premises remain explicit.
-/
theorem physical_pad_cell_balanced_box
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (u v r U W d₀ Y C : ℝ)
    (hU : 0 < U) (hu : U ≤ u) (hu' : u ≤ 16*U)
    (hd : 0 < d₀) (hD : d₀ ≤ (D : ℝ)) (hY : 1 ≤ Y) (hC : 1 ≤ C)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest
      ((D : ℝ)*latticeTau r w/latticeTau r z) Y) :
    ∃ b₁ b₂ : ℤ × ℤ, ∃ a b c d : ℤ,
      latticeDet b₁ b₂ = 1 ∧ a ≤ b ∧ c ≤ d ∧
      Y^(1/5 : ℝ) ≤ (b : ℝ)-a ∧ Y^(1/5 : ℝ) ≤ (d : ℝ)-c ∧
      ((b : ℝ)-a)*((d : ℝ)-c) ≤ 72*(256*C)^2*Y ∧
      ∀ t : ℤ × ℤ, sourcePhysicalPositionAllowed u v r U W t →
        D ∣ latticeDet z t → |latticeSlope r t-latticeSlope r z| ≤ C*d₀*Y →
        SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t) ∈
          (Finset.Ico a b) ×ˢ (Finset.Ico c d) := by
  obtain ⟨b₁,b₂,a,b,c,d,hb,hab,hcd,hwidth,hwidth',harea,hcontain⟩ :=
    SourceGoodState.exists_balanced_integer_box
      ((D : ℝ)*latticeTau r w/latticeTau r z) Y (256*C) hY (by linarith) hg
  refine ⟨b₁,b₂,a,b,c,d,hb,hab,hcd,hwidth,hwidth',harea,?_⟩
  intro t ht hdiv hcell
  apply hcontain
  exact physical_padCoordinates_height_le z w hzw D u v r U W d₀ Y C
    hU hu hu' hd hD (by linarith) hC t hdiv hz ht hcell

end Elliptic.Operator.PhysicalPadLattice
