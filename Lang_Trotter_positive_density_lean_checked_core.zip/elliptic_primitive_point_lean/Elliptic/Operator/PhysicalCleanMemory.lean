module
public import Elliptic.Operator.PhysicalBagRepresentatives
public import Elliptic.Operator.PhysicalCleanNorm
public import Elliptic.Operator.BlockAssembly

/-!
# Literal clean memory block and endpoint multipliers

The zero-store, zero-promotion mask preserves the actual finite memory bag.
The resulting hit factors are endpoint diagonals, uniformly bounded by one
for every memory cutoff. These are identities in the source physical kernel.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanMemory
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
local instance physicalCleanMemoryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {P : Type*} [Fintype P] {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}

theorem maskedDampedBagKernel_clean {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p≠0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (ds dt : Multiset (AnchoredParticle P Line) → R)
    (s t : MemoryBag (AnchoredParticle P Line) B) :
    maskedDampedBagKernel ν store promote false false sourceAnchor targetAnchor
      source target ds dt s t =
      if s=t then ds s.val * ν target * dt s.val else 0 := by
  simp only [maskedDampedBagKernel,edgeMaskComponent,Bool.false_eq_true,ite_false,
    Bool.toNat_false,pow_zero,one_mul,dampedBagKernel,bagEdgeTransfer,
    bagDeletion_edgePromotionBatch,zero_mul,add_zero]
  have hb := bagBirth_edgeStoreBatch B (fun x : AnchoredParticle P Line => ν x.1)
    (anchorPrime sourceAnchor source) 0 (hν source)
    (fun t_1 => dt t_1 * if t_1=t.val then 1 else 0) s.val
  change bagBirth B (fun x : AnchoredParticle P Line => ν x.1)
    (edgeStoreBatch (anchorPrime sourceAnchor source) (ν source) 0) _ _ = _ at hb
  rw [hb]
  have hs : s.val.card≤B := by
    obtain ⟨m,hm⟩ := PhysicalBagRepresentatives.memory_exists s
    rw [← hm,memoryBagOf_card]
    exact Nat.le_of_lt_succ m.1.isLt
  by_cases he : s=t
  · subst t
    simp [hs,mul_assoc]
  · have hn : s.val≠t.val := fun h => he (Subtype.ext h)
    simp [hs,hn,he]

theorem bagSurvival_norm_le_one (anchor : ∀ p, Line p) (ρ : ℝ)
    (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (s : Multiset (AnchoredParticle P Line)) :
    ‖bagSurvival anchor (ρ:ℂ) s‖≤1 := by
  simp only [bagSurvival,norm_pow,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hρ0]
  exact pow_le_one₀ hρ0 hρ1

variable {G Z : Type*} [Fintype G]
variable {Q : G → Type*} [∀ i, Fintype (Q i)]
variable {Lines : ∀ i, Q i → Type*} [∀ i p, Fintype (Lines i p)] {J : ℕ}

/-- Actual damping for a fixed tuple of memory bags. -/
def damping (anchor : Z → ∀ i p, Lines i p) (ρ : ℂ)
    (b : Bags (P:=Q) (Line:=Lines) (B:=B)) (z : Z) : ℂ :=
  ∏ i, bagSurvival (anchor z i) ρ (b i).val

theorem damping_norm_le_one (anchor : Z → ∀ i p, Lines i p) (ρ : ℝ)
    (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (b : Bags (P:=Q) (Line:=Lines) (B:=B)) (z : Z) :
    ‖damping anchor (ρ:ℂ) b z‖≤1 := by
  rw [damping,norm_prod]
  calc
    _ ≤ ∏ _i : G, (1:ℝ) := Finset.prod_le_prod₀ (fun i _ => norm_nonneg _)
      (fun i _ => bagSurvival_norm_le_one _ ρ hρ0 hρ1 _)
    _ = 1 := by simp

/-- No memory multiplicity is lost in the clean mask: the bag equality is
literal, while every fresh target prime keeps its original mass. -/
theorem groupedMaskedBagKernel_clean {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (hν : ∀ i p, ν i p≠0) (store promote : G → R)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p)
    (ds dt : ∀ i, Multiset (AnchoredParticle (Q i) (Lines i)) → R)
    (s t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B)) :
    groupedMaskedBagKernel ν store promote (fun _ => false) (fun _ => false)
      sourceAnchor targetAnchor ds dt s t =
      if (fun i => (s i).2)=(fun i => (t i).2) then
        (∏ i, ds i (s i).2.val) * (∏ i, ν i (t i).1) * (∏ i, dt i (s i).2.val)
      else 0 := by
  unfold groupedMaskedBagKernel
  simp_rw [maskedDampedBagKernel_clean _ (hν _)]
  by_cases he : (fun i => (s i).2)=(fun i => (t i).2)
  · have hh (i) : (s i).2=(t i).2 := congrFun he i
    simp only [hh,ite_true,Finset.prod_mul_distrib]
  · rw [ite_eq_right he]
    have hn : ∃ i, (s i).2≠(t i).2 := by
      by_contra h
      push Not at h
      exact he (funext h)
    obtain ⟨i,hi⟩ := hn
    exact Finset.prod_eq_zero (Finset.mem_univ i) (by simp [hi])

/-- The actual physical term for the clean mask is diagonal in shared
slots and bags, with the two literal hit diagonals and fresh product mass. -/
theorem term_clean
    (ν : ∀ i, Q i → ℂ) (hν : ∀ i p, ν i p≠0) (store promote : G → ℂ) (ρ : ℂ)
    (anchor : Z → ∀ i p, Lines i p)
    (geometry : Z → PhysicalActiveLists Q J → Z → PhysicalActiveLists Q J → ℂ)
    (s t : State (Z:=Z) (P:=Q) (Line:=Lines) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) :
    term ν store promote (fun _ => false) (fun _ => false) ρ anchor geometry s t π τ =
      if Shared s t π τ ∧ bags s=bags t then
        damping anchor ρ (bags s) (position s) *
        geometry (position s) (fun i j => active s i (π i j))
          (position t) (fun i j => active t i (τ i j)) *
        (∏ i, ν i (active t i (τ i (Fin.last J)))) *
        damping anchor ρ (bags s) (position t)
      else 0 := by
  unfold term
  rw [groupedMaskedBagKernel_clean ν hν]
  by_cases hs : Shared s t π τ <;> by_cases hb : bags s=bags t <;>
    simp only [unshared,hs,hb,ite_true,ite_false,true_and,false_and,mul_zero,damping]
  ring

/-- Arbitrary endpoint cutoffs and the actual memory-hit damping preserve
the measured clean bound. The conclusion is uniform in the bag and B. -/
theorem measured_clean_endpoint_bound {X Y : Type*}
    (s : Finset X) (t : Finset Y) (μ : X → ℝ) (ν : Y → ℝ)
    (hμ : ∀ x∈s, 0≤μ x) (hν : ∀ y∈t, 0≤ν y)
    (K : X → Y → ℂ) (M : ℝ) (hM : 0≤M)
    (left : X → ℂ) (right : Y → ℂ)
    (hl : ∀ x∈s, ‖left x‖≤1) (hr : ∀ y∈t, ‖right y‖≤1)
    (hK : FiniteMeasuredBilinearBound s t μ ν K M) :
    FiniteMeasuredBilinearBound s t μ ν (fun x y => left x*K x y*right y) M := by
  apply finiteMeasuredBilinearBound_of_kernel_bound s t μ ν hμ _ M
  exact finiteKernelBound_diagonal_contractions s t μ ν K M hμ hν hM
    (finiteKernelBound_of_measured_bilinear s t μ ν hμ K M hM hK) left right hl hr

end Elliptic.Operator.PhysicalCleanMemory
