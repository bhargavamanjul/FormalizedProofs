module

public import Elliptic.Operator.PhysicalFourierWord
public import Elliptic.Operator.PhysicalDirtyMasks
public import Elliptic.Operator.PhysicalKernelLinearity

/-! Exact mask decomposition of birth-phased physical edges. The phase is
attached to the actual fresh target prime; promotions read the absent birth.
Consequently it becomes a bounded endpoint multiplier at each fixed mask.
No assertion that phases preserve clean cancellation is made. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdge
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthFactors PhysicalPhasedWord
open PhysicalMaskedKernel PhysicalMaskedChoices PhysicalMaskedIdentification PhysicalMaskedSchur PhysicalDirtyMasks
attribute [local instance] Classical.propDecidable
local instance phasedEdgeDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B : ℕ}
variable (value : ∀i,P i→ℕ)

 def targetFactor (M : I→Bool) (E : I→Option ℕ→ℂ) (b : PhysicalActiveLists P J) : ℂ :=
  ∏i,E i (if M i then none else some (value i (b i (Fin.last J))))

 theorem targetFactor_norm_le (M : I→Bool) (E : I→Option ℕ→ℂ)
    (hE : ∀i b,‖E i b‖≤1) (b : PhysicalActiveLists P J) :
    ‖targetFactor value M E b‖≤1 := by
  simp only [targetFactor,norm_prod]
  exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _) (fun i _=>hE i _)

 theorem factor_eq_targetFactor (M : I→Bool) (E : I→Option ℕ→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hM : ∀i,edgeChoicePromotes (c.group i)=M i) :
    edgeFactor value (fun _=>E) 0 c=targetFactor value M E c.targetLists := by
  apply Finset.prod_congr rfl
  intro i _
  have hi := hM i
  simp only [PhysicalEdgeChoice.targetLists_last]
  unfold freshSlot
  cases he : (c.group i).2 with
  | inl k =>
      have hm : M i=true := by simpa [edgeChoicePromotes,he] using hi.symm
      simp [hm,he]
  | inr p =>
      have hm : M i=false := by simpa [edgeChoicePromotes,he] using hi.symm
      simp [hm,he,edgeTargetPrime]

 def phaseGeometry (M : I→Bool) (E : I→Option ℕ→ℂ)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (z : Z) (a : PhysicalActiveLists P J) (w : Z) (b : PhysicalActiveLists P J) : ℂ :=
  targetFactor value M E b*geometry z a w b

 theorem phaseGeometry_norm_le (M : I→Bool) (E : I→Option ℕ→ℂ)
    (hE : ∀i b,‖E i b‖≤1)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (z : Z) (a : PhysicalActiveLists P J) (w : Z) (b : PhysicalActiveLists P J) :
    ‖phaseGeometry value M E geometry z a w b‖≤‖geometry z a w b‖ := by
  unfold phaseGeometry
  rw [norm_mul]
  exact (mul_le_mul_of_nonneg_right (targetFactor_norm_le value M E hE b) (norm_nonneg _)).trans_eq (one_mul _)

 variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (ρ : ℝ)
 variable (anchor : Z→∀i p,Line i p)
 variable (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

 theorem phasedApply_eq_choices (E : I→Option ℕ→ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
      (fun _ c=>edgeFactor value (fun _=>E) 0 c) F s =
    ∑c : PhysicalEdgeChoice s,if hc : c.Valid anchor s then
      edgeFactor value (fun _=>E) 0 c*physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc*
        F (c.output anchor s hc) else 0 := by
  unfold phasedApply
  rw [PhysicalBagMeasure.sum_subtype_zero]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : c.Valid anchor s
  · simp [physicalEdgeOperation,hc]
  · simp [physicalEdgeOperation,hc]

 theorem phasedApply_eq_mask_sum (E : I→Option ℕ→ℂ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
      (fun _ c=>edgeFactor value (fun _=>E) 0 c) (fun t=>F (ofOrdered t)) s =
    ∑m : Mask (G:=I),originalMaskedApply ν V m.1 m.2 ρ anchor
      (phaseGeometry value m.2 E geometry) F s := by
  rw [phasedApply_eq_choices]
  unfold originalMaskedApply
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : c.Valid anchor s
  · simp only [dite_eq_left hc]
    simp_rw [match_iff]
    rw [Finset.sum_ite_eq]
    simp only [Finset.mem_univ,ite_true]
    have hf := factor_eq_targetFactor value (fun i=>edgeChoicePromotes (c.group i)) E s c (fun _=>rfl)
    rw [hf]
    unfold physicalEdgeChoiceWeight phaseGeometry
    ring
  · simp [hc]

 def kernel (E : I→Option ℕ→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  ∑m : Mask (G:=I),originalKernel ν V m.1 m.2 ρ anchor
    (phaseGeometry value m.2 E geometry) s t

 theorem phasedApply_eq_kernel (hν : ∀i p,ν i p≠0) (E : I→Option ℕ→ℂ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
      (fun _ c=>edgeFactor value (fun _=>E) 0 c) (fun t=>F (ofOrdered t)) s =
    ∑t,kernel value ν V ρ anchor geometry E (ofOrdered s) t*F t := by
  have hn : ∀i p,(ν i p:ℂ)≠0 := by intro i p;exact_mod_cast hν i p
  rw [phasedApply_eq_mask_sum]
  simp_rw [←physicalApply_original,PhysicalMaskedIdentification.physicalApply_eq_kernel _ hn]
  unfold kernel originalKernel
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]

end Elliptic.Operator.PhysicalPhasedEdge
