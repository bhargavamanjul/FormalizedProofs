module

public import Elliptic.Operator.PhysicalMomentIdentification
public import Elliptic.Operator.SingleEdgeNormalization
public import Elliptic.Operator.PhysicalAdmissibleMoment
public import Elliptic.Operator.RootErrorBudget

/-!
# Sharp physical endpoint mass

Divisibility by the complete active-list product gives the reciprocal
factor needed to cancel the original list normalization. The bound has
no power of log depending on the number of lists or their lengths.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalEndpointNorm
open scoped BigOperators
open SingleEdgeRootEncoding
attribute [local instance] Classical.propDecidable
local instance endpointNormDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

def divisiblePositions (U V : ℝ) (G : ℕ) : Finset (ℤ×ℤ) :=
  (primitiveSources U V).filter (fun z=>(G:ℤ)∣z.1)

theorem divisiblePositions_card (U V : ℝ) (G : ℕ)
    (hG : 0<G) (hGU : (G:ℝ)≤U) (hV : 1≤V) :
    ((divisiblePositions U V G).card:ℝ)≤51*U*V/G := by
  have hGR : (0:ℝ)<G := by exact_mod_cast hG
  have hU : 0<U := hGR.trans_le hGU
  let S := Finset.range (⌊16*U/(G:ℝ)⌋₊+1) ×ˢ Finset.range (⌊2*V⌋₊+1)
  let f : ℕ×ℕ→ℤ×ℤ := fun k=>((G:ℤ)*k.1,k.2)
  have hsub : divisiblePositions U V G⊆S.image f := by
    intro z hz
    obtain ⟨hz,hd⟩ := Finset.mem_filter.mp hz
    have hb := (mem_primitiveSources U V z).mp hz
    obtain ⟨k,hk⟩ := hd
    have hkR : (z.1:ℝ)=(G:ℝ)*(k:ℝ) := by exact_mod_cast hk
    have hk0R : (0:ℝ)≤k := by nlinarith [hb.2.1]
    have hk0 : 0≤k := by exact_mod_cast hk0R
    have hz20 : 0≤z.2 := by exact_mod_cast (show (0:ℝ)≤z.2 by linarith [hb.2.2.2.1])
    have hkR' : (k.toNat:ℝ)=(k:ℝ) := by exact_mod_cast (Int.toNat_of_nonneg hk0)
    have hzR : (z.2.toNat:ℝ)=(z.2:ℝ) := by exact_mod_cast (Int.toNat_of_nonneg hz20)
    refine Finset.mem_image.mpr ⟨(k.toNat,z.2.toNat),?_,?_⟩
    · apply Finset.mem_product.mpr
      constructor
      · apply Finset.mem_range.mpr
        apply Nat.lt_succ_of_le
        apply Nat.le_floor
        rw [hkR']
        apply (le_div_iff₀ hGR).mpr
        nlinarith [hb.2.2.1]
      · apply Finset.mem_range.mpr
        apply Nat.lt_succ_of_le
        apply Nat.le_floor
        rw [hzR]
        exact hb.2.2.2.2
    · dsimp [f]
      simp only [Int.toNat_of_nonneg hk0,Int.toNat_of_nonneg hz20]
      exact Prod.ext hk.symm rfl
  have hc : ((divisiblePositions U V G).card:ℝ)≤
      (⌊16*U/(G:ℝ)⌋₊+1:ℕ)*(⌊2*V⌋₊+1:ℕ) := by
    exact_mod_cast (Finset.card_le_card hsub).trans ((Finset.card_image_le).trans_eq
      (by simp [S,Finset.card_product]))
  have hfloor1 := Nat.floor_le (show 0≤16*U/(G:ℝ) by positivity)
  have hfloor2 := Nat.floor_le (show 0≤2*V by linarith)
  have huG : 1≤U/(G:ℝ) := (one_le_div hGR).mpr hGU
  have h1 : (⌊16*U/(G:ℝ)⌋₊:ℝ)+1≤17*U/(G:ℝ) := by
    simp only [mul_div_assoc] at hfloor1 ⊢
    linarith
  have h2 : (⌊2*V⌋₊:ℝ)+1≤3*V := by linarith
  push_cast at hc
  apply hc.trans
  calc
    _ ≤ (17*U/(G:ℝ))*(3*V) := mul_le_mul h1 h2 (by positivity) (by positivity)
    _ = _ := by ring

variable {I : Type} [Fintype I] {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

def listProduct (value : ∀i,P i→ℕ) (a : PhysicalActiveLists P J) : ℕ :=
  ∏i,∏k,value i (a i k)

theorem reciprocal_list_sum (value : ∀i,P i→ℕ) :
    (∑a : PhysicalActiveLists P J,1/(listProduct value a:ℝ))=
      ∏i,(∑p : P i,1/(value i p:ℝ))^(J+1) := by
  simp only [listProduct,Nat.cast_prod,one_div,←Finset.prod_inv_distrib]
  rw [←Fintype.prod_sum (fun i (a : Fin (J+1)→P i)=>∏k,(value i (a k):ℝ)⁻¹)]
  apply Finset.prod_congr rfl
  intro i hi
  rw [←Fintype.prod_sum (fun (_k : Fin (J+1)) (p : P i)=>(value i p:ℝ)⁻¹)]
  simp

theorem normalized_reciprocal_list_sum (value : ∀i,P i→ℕ) (VM : I→ℝ)
    (hVM : ∀i,VM i=∑p : P i,1/(value i p:ℝ)) (hV : ∀i,VM i≠0) :
    (PhysicalRootedMoment.initialMass (J:=J) VM)*
      (∑a : PhysicalActiveLists P J,1/(listProduct value a:ℝ))=1 := by
  rw [reciprocal_list_sum]
  simp_rw [←hVM]
  unfold PhysicalRootedMoment.initialMass
  rw [←Finset.prod_mul_distrib]
  apply Finset.prod_eq_one
  intro i hi
  rw [←mul_pow,inv_mul_cancel₀ (hV i),one_pow]

theorem admissible_product_dvd (value : ∀i,P i→ℕ)
    (hp : ∀i p,(value i p).Prime) (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (ha : PhysicalAdmissibleMoment.Admissible value z a) :
    (listProduct value a:ℤ)∣z.1 := by
  have hcop : Pairwise (fun s t : Sigma (fun _i:I=>Fin (J+1))=>
      IsCoprime (value s.1 (a s.1 s.2):ℤ) (value t.1 (a t.1 t.2):ℤ)) := by
    intro s t hst
    exact ((Nat.coprime_primes (hp _ _) (hp _ _)).mpr
      (fun h=>hst (ha.1 h))).isCoprime
  have hd := Fintype.prod_dvd_of_coprime hcop (fun s=>ha.2 s.1 s.2)
  simpa only [listProduct,Nat.cast_prod,Fintype.prod_sigma] using hd

theorem listProduct_pos (value : ∀i,P i→ℕ) (hp : ∀i p,0<value i p)
    (a : PhysicalActiveLists P J) : 0<listProduct value a := by
  exact Finset.prod_pos (fun i _=>Finset.prod_pos (fun k _=>hp i (a i k)))

theorem admissible_position_count {Z : Type} [Fintype Z]
    (position : Z→ℤ×ℤ) (hinj : Function.Injective position)
    (U V : ℝ) (hbox : ∀z,position z∈primitiveSources U V)
    (value : ∀i,P i→ℕ) (hp : ∀i p,(value i p).Prime)
    (a : PhysicalActiveLists P J) (hGU : (listProduct value a:ℝ)≤U) (hV : 1≤V) :
    ((Finset.univ.filter (fun z=>PhysicalAdmissibleMoment.Admissible value (position z) a)).card:ℝ)
      ≤51*U*V/(listProduct value a) := by
  have hc := Finset.card_le_card_of_injOn (s:=Finset.univ.filter
      (fun z=>PhysicalAdmissibleMoment.Admissible value (position z) a))
      (t:=divisiblePositions U V (listProduct value a)) position
      (fun z hz=>Finset.mem_filter.mpr ⟨hbox z,
        admissible_product_dvd value hp _ a (Finset.mem_filter.mp hz).2⟩)
      hinj.injOn
  exact (show (_:ℝ)≤_ by exact_mod_cast hc).trans
    (divisiblePositions_card U V _ (listProduct_pos value (fun i p=>(hp i p).pos) a) hGU hV)

/-- The normalization cancels the full ordered-list harmonic mass.
There is no logarithmic loss depending on either the number of groups
or the length of a list. -/
theorem projected_self_norm_le {Z : Type} [Fintype Z]
    (position : Z→ℤ×ℤ) (hinj : Function.Injective position)
    (U V : ℝ) (hbox : ∀z,position z∈primitiveSources U V)
    (value : ∀i,P i→ℕ) (hp : ∀i p,(value i p).Prime)
    (hGU : ∀a : PhysicalActiveLists P J,(listProduct value a:ℝ)≤U) (hV : 1≤V)
    (VM : I→ℝ) (hVM : ∀i,VM i=∑p : P i,1/(value i p:ℝ)) (hVMpos : ∀i,0<VM i)
    (F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) (B : ℝ)
    (hB : 0≤B) (hF : ∀x,‖F x‖≤B) :
    (PhysicalRootedMoment.pairing VM (PhysicalAdmissibleMoment.project value position F)
      (PhysicalAdmissibleMoment.project value position F)).re≤51*U*V*B^2 := by
  rw [PhysicalAdmissibleMoment.pairing_project_self_re]
  have hm : 0≤PhysicalRootedMoment.initialMass (J:=J) VM :=
    PhysicalRootedMoment.initialMass_nonneg VM (fun i=>(hVMpos i).le)
  have hc (a : PhysicalActiveLists P J) :
      (∑z:Z,if PhysicalAdmissibleMoment.Admissible value (position z) a
        then ‖F (z,a)‖^2 else 0)≤(51*U*V/(listProduct value a))*B^2 := by
    rw [←Finset.sum_filter]
    calc
      _ ≤ ((Finset.univ.filter (fun z=>PhysicalAdmissibleMoment.Admissible value (position z) a)).card:ℝ)*B^2 := by
        simpa only [nsmul_eq_mul] using Finset.sum_le_card_nsmul
          (Finset.univ.filter (fun z=>PhysicalAdmissibleMoment.Admissible value (position z) a))
          (fun z=>‖F (z,a)‖^2) (B^2) (fun z _=>pow_le_pow_left₀ (norm_nonneg _) (hF (z,a)) 2)
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (admissible_position_count position hinj U V hbox value hp a (hGU a) hV) (sq_nonneg B)
  have hs : (∑x:PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J),
      if PhysicalAdmissibleMoment.Admissible value (position x.1) x.2 then ‖F x‖^2 else 0)
      ≤51*U*V*B^2*(∑a : PhysicalActiveLists P J,1/(listProduct value a:ℝ)) := by
    rw [Fintype.sum_prod_type,Finset.sum_comm,Finset.mul_sum]
    exact Finset.sum_le_sum (fun a _=>(hc a).trans_eq (by ring))
  apply (mul_le_mul_of_nonneg_left hs hm).trans_eq
  rw [←mul_assoc, mul_right_comm (PhysicalRootedMoment.initialMass (J:=J) VM),
    normalized_reciprocal_list_sum value VM hVM (fun i=>(hVMpos i).ne')]
  ring

section SourceHeight
open Filter
variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem listProduct_le_exp (L : ℝ) (value : ∀i,P i→ℕ)
    (hvalue : ∀i p,(value i p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))
    (a : PhysicalActiveLists P J) :
    (listProduct value a:ℝ)≤Real.exp (2*K*(J+1)*L^(1/5:ℝ)) := by
  simp only [listProduct,Nat.cast_prod]
  calc
    _ ≤ ∏i : Fin K,∏_k : Fin (J+1),Real.exp (2*L^(1/5:ℝ)) := by
      apply Finset.prod_le_prod₀ (fun i _=>by positivity)
      intro i _
      exact Finset.prod_le_prod₀ (fun k _=>by positivity) (fun k _=>hvalue i (a i k))
    _ = _ := by
      simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin,←pow_mul,←Real.exp_nat_mul]
      congr 1
      push_cast
      ring

/-- A single threshold covers every actual active list. -/
theorem eventually_listProduct_le_scale (K : ℕ) (δ : ℝ) (hδ : 0<δ) :
    ∀ᶠ L : ℝ in atTop,∀ P : Fin K→Type,∀[∀i,Fintype (P i)],
      ∀ value : ∀i,P i→ℕ,
      (∀i p,(value i p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))→
      ∀ U : ℝ,Real.exp (δ*L)≤U→
      ∀a : PhysicalActiveLists P (momentPadding L),(listProduct value a:ℝ)≤U := by
  filter_upwards [RootErrorBudget.eventually_subpower_exponent_le (4*K) δ hδ,
    eventually_ge_atTop (1:ℝ)] with L he hL
  intro P instP value hvalue U hU a
  have hLp : 0<L := by linarith
  have hJ := momentMultiplicity_le_two_rpow hL
  change (momentPadding L+1:ℕ)≤2*L^(1/100:ℝ) at hJ
  have hcost : 2*K*((momentPadding L:ℝ)+1)*L^(1/5:ℝ)≤δ*L := by
    calc
      _ ≤ (4*K)*(L^(1/100:ℝ)*L^(1/5:ℝ)) := by
        have hJ' : (momentPadding L:ℝ)+1≤2*L^(1/100:ℝ) := by exact_mod_cast hJ
        nlinarith [mul_le_mul_of_nonneg_left hJ'
          (show 0≤(2*K:ℝ)*L^(1/5:ℝ) by positivity)]
      _ = (4*K)*L^(21/100:ℝ) := by rw [←Real.rpow_add hLp]; norm_num
      _ ≤ (4*K)*L^(98/100:ℝ) := mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow_of_exponent_le hL (by norm_num)) (by positivity)
      _ ≤ _ := he
  exact ((listProduct_le_exp L value hvalue a).trans (Real.exp_le_exp.mpr hcost)).trans hU

end SourceHeight
end Elliptic.Operator.PhysicalEndpointNorm
