module

public import Elliptic.Operator.PhysicalPhasedWord

/-! Birth-preserving original physical histories are exactly a normalized
Fourier average of chronological words with local choice factors. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFourierWord
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthFactors PhysicalPhasedWord BirthFourierLocalization
attribute [local instance] Classical.propDecidable
local instance fourierWordDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} {J B N Q : ℕ} [NeZero Q]

def atAddress (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (a : Address I J B N) (b : Option ℕ) : ℂ :=
  localPhase (fun _=>b) (fun v=>(v:ZMod Q)) σ θ a

def initialPhase (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (i:I) (k:Fin (J+1)) : Option ℕ→ℂ := atAddress σ θ (.inl (i,k))

def ghostPhase (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (j:ℕ) (i:I) (k:Fin B) (b:Option ℕ) : ℂ :=
  if hj:j<N+1 then atAddress σ θ (.inr (.inl (⟨j,hj⟩,i,k))) b else 1

def edgePhase (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (j:ℕ) (i:I) (b:Option ℕ) : ℂ :=
  if hj:j<N then atAddress σ θ (.inr (.inr (⟨j,hj⟩,i))) b else 1

theorem phases_match (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (birth : Address I J B N→Option ℕ) (a : Address I J B N) :
    addressFactor (initialPhase σ θ) (ghostPhase σ θ) (edgePhase σ θ) a (birth a) =
      localPhase birth (fun v=>(v:ZMod Q)) σ θ a := by
  rcases a with a|(a|a)
  · rfl
  · simp [addressFactor,ghostPhase,a.1.isLt,atAddress,localPhase]
  · simp [addressFactor,edgePhase,a.1.isLt,atAddress,localPhase]

theorem phase_bounds (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q) :
    (∀i k b,‖initialPhase σ θ i k b‖≤1) ∧
    (∀j i k b,‖ghostPhase σ θ j i k b‖≤1) ∧
    (∀j i b,‖edgePhase σ θ j i b‖≤1) := by
  constructor
  · intro i k b
    exact localPhase_norm_le (fun _ : Address I J B N=>b) (fun v : ℕ=>(v:ZMod Q)) σ θ (.inl (i,k))
  constructor
  · intro j i k b
    unfold ghostPhase
    split_ifs
    · exact localPhase_norm_le (Q:=Q) _ _ σ θ _
    · simp
  · intro j i b
    unfold edgePhase
    split_ifs
    · exact localPhase_norm_le (Q:=Q) _ _ σ θ _
    · simp

/-- Operation labels distinguish initial draws, ghost visits and edges. -/
def operation : Address I J B N→ℕ
  | .inl _ => 0
  | .inr (.inl a) => 2*a.1.val+1
  | .inr (.inr a) => 2*a.1.val+2

theorem modified_operations_count (σ : Equiv.Perm (Address I J B N)) :
    (σ.support.image operation).card≤2*birthCycleRank σ :=
  modified_operations_card_le_twice_birthCycleRank operation σ

theorem ghostPhase_unmodified (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ)
    (hj:2*j+1∉σ.support.image operation) (i:I) (k:Fin B) (b:Option ℕ) :
    ghostPhase σ θ j i k b=1 := by
  unfold ghostPhase
  split_ifs with ht
  · apply localPhase_unmoved
    intro ha
    exact hj (Finset.mem_image.mpr ⟨.inr (.inl (⟨j,ht⟩,i,k)),ha,rfl⟩)
  · rfl

theorem edgePhase_unmodified (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ)
    (hj:2*j+2∉σ.support.image operation) (i:I) (b:Option ℕ) :
    edgePhase σ θ j i b=1 := by
  unfold edgePhase
  split_ifs with ht
  · apply localPhase_unmoved
    intro ha
    exact hj (Finset.mem_image.mpr ⟨.inr (.inr (⟨j,ht⟩,i)),ha,rfl⟩)
  · rfl

variable (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ:ℝ)
variable (anchor:Z→∀i p,Line i p)
variable (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
variable (value:∀i,P i→ℕ)

theorem initialFactor_norm_le (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (s:PhysicalMemoryState (Z:=Z) P Line J B) :
    ‖initialFactor value (initialPhase σ θ) s‖≤1 := by
  simp only [initialFactor,norm_prod]
  apply Finset.prod_le_one₀ (fun _ _=>Finset.prod_nonneg (fun _ _=>norm_nonneg _))
  intro i _
  exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _) (fun k _=>(phase_bounds σ θ).1 i k _)

theorem ghostFactor_norm_le (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ) (s:PhysicalMemoryState (Z:=Z) P Line J B)
    (c:PhysicalGhostChoice s) : ‖ghostFactor value (ghostPhase σ θ) j c‖≤1 := by
  simp only [ghostFactor,norm_prod]
  apply Finset.prod_le_one₀ (fun _ _=>Finset.prod_nonneg (fun _ _=>norm_nonneg _))
  intro i _
  exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _) (fun k _=>(phase_bounds σ θ).2.1 j i k _)

theorem edgeFactor_norm_le (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ) (s:PhysicalMemoryState (Z:=Z) P Line J B)
    (c:PhysicalEdgeChoice s) : ‖edgeFactor value (edgePhase σ θ) j c‖≤1 := by
  simp only [edgeFactor,norm_prod]
  exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _) (fun i _=>(phase_bounds σ θ).2.2 j i _)

theorem ghostFactor_unmodified (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ) (hj:2*j+1∉σ.support.image operation)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) (c:PhysicalGhostChoice s) :
    ghostFactor value (ghostPhase σ θ) j c=1 := by
  simp [ghostFactor,ghostPhase_unmodified σ θ j hj]

theorem edgeFactor_unmodified (σ : Equiv.Perm (Address I J B N))
    (θ:Address I J B N→ZMod Q) (j:ℕ) (hj:2*j+2∉σ.support.image operation)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) (c:PhysicalEdgeChoice s) :
    edgeFactor value (edgePhase σ θ) j c=1 := by
  simp [edgeFactor,edgePhase_unmodified σ θ j hj]

theorem history_phase_product (σ : Equiv.Perm (Address I J B N))
    (θ : Address I J B N→ZMod Q) (s:PhysicalMemoryState (Z:=Z) P Line J B)
    (h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    (∏a,localPhase (labels ν V η q ρ anchor geometry value N s h)
      (fun v=>(v:ZMod Q)) σ θ a) =
      initialFactor value (initialPhase σ θ) s *
        historyFactor ν V η q ρ anchor geometry value (ghostPhase σ θ) (edgePhase σ θ) N 0 s h := by
  rw [← logger_factorization ν V η q ρ anchor geometry value]
  apply Finset.prod_congr rfl
  intro a _
  exact (phases_match σ θ _ a).symm

/-- The local Fourier word is the literal physical operation word, with
the original signed coefficients and dependent outputs unchanged. -/
theorem birthPreserving_eq_average_word (hvalue:∀i p,value i p<Q)
    (σ:Equiv.Perm (Address I J B N))
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) :
    (∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
      if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
        then h.weight*F h.final else 0) =
      average (fun θ:Address I J B N→ZMod Q=>
        initialFactor value (initialPhase σ θ) s *
          word ν V η q ρ anchor geometry value (ghostPhase σ θ) (edgePhase σ θ) N 0 F s) := by
  rw [actual_birthFourier_average ν V η q ρ anchor geometry value hvalue s σ]
  congr 1
  funext θ
  rw [word_eq_historySum,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro h _
  rw [history_phase_product]
  ring

end Elliptic.Operator.PhysicalFourierWord
