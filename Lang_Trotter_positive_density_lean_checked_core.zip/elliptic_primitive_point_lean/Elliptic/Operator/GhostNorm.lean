module

public import Elliptic.Operator.GhostSymmetricAdjoint
public import Elliptic.Operator.GhostSchurRow

/-!
# The ghost norm on symmetric memory functions

The coefficient adjoint exchanges actual births and indexed deletions.
We apply weighted Cauchy--Schwarz to the literal choices and use that
proved factorial-measure adjoint; a column bound for the raw ordered
kernel is neither assumed nor claimed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def ghostChoiceBag {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) : Multiset (AnchoredParticle P Line) :=
  if hc : GhostChoice.Valid anchor m c then tupleBag (ghostOutput anchor m c hc).values else 0

def ghostPositiveCoefficient {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (d r b : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) : ℝ :=
  if GhostChoice.Valid anchor m c then
    d^c.1.card * r^(memoryHits anchor m \ c.1).card * b^c.2.size *
      tupleWeight ν c.2.values / (c.2.size.factorial : ℝ) else 0

theorem ghostPositiveCoefficient_nonneg {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (d r b : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m)
    (hν : ∀ p, 0 ≤ ν p) (hd : 0 ≤ d) (hr : 0 ≤ r) (hb : 0 ≤ b) :
    0 ≤ ghostPositiveCoefficient ν d r b anchor m c := by
  unfold ghostPositiveCoefficient
  split_ifs
  · have ht : 0 ≤ tupleWeight ν c.2.values := Finset.prod_nonneg (fun i _ => hν _)
    positivity
  · exact le_rfl

theorem ghostCoefficientApply_eq_positive_sum {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (d r b : ℝ)
    (anchor : ∀ p, Line p) (F : Multiset (AnchoredParticle P Line) → ℝ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostCoefficientApply ν d r b anchor F m =
      ∑ c : GhostChoice m, ghostPositiveCoefficient ν d r b anchor m c *
        F (ghostChoiceBag anchor m c) := by
  unfold ghostCoefficientApply ghostPositiveCoefficient ghostChoiceBag
  apply Finset.sum_congr rfl
  intro c _
  split_ifs <;> simp

/-- Pointwise Cauchy--Schwarz with the actual finite signed ghost
choices and the positive birth/deletion majorant. -/
theorem ghostCoefficientApply_sq_le {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (d r b : ℂ)
    (anchor : ∀ p, Line p) (F : Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) (v0 : ℝ)
    (hν : ∀ p, 0 ≤ ν p) (hv : 0 < v0) :
    ‖ghostCoefficientApply (fun p => (ν p : ℂ)) d r b anchor F m‖^2 ≤
      ghostCoefficientApply ν ‖d‖ ‖r‖ ‖b‖ anchor (fun s => v0^s.card) m *
      ghostCoefficientApply ν ‖d‖ ‖r‖ ‖b‖ anchor
        (fun s => ‖F s‖^2/v0^s.card) m := by
  let w := ghostPositiveCoefficient ν ‖d‖ ‖r‖ ‖b‖ anchor m
  let out := ghostChoiceBag anchor m
  have hw (c : GhostChoice m) : 0 ≤ w c :=
    ghostPositiveCoefficient_nonneg ν _ _ _ anchor m c hν (norm_nonneg _) (norm_nonneg _) (norm_nonneg _)
  have hnorm : ‖ghostCoefficientApply (fun p => (ν p : ℂ)) d r b anchor F m‖ ≤
      ∑ c : GhostChoice m, w c * ‖F (out c)‖ := by
    unfold ghostCoefficientApply
    apply (norm_sum_le _ _).trans_eq
    apply Finset.sum_congr rfl
    intro c _
    dsimp only [w, out, ghostPositiveCoefficient, ghostChoiceBag]
    split_ifs with hc
    · have ht : ‖tupleWeight (fun p => (ν p : ℂ)) c.2.values‖ = tupleWeight ν c.2.values := by
        simp only [tupleWeight, norm_prod, Complex.norm_real, Real.norm_eq_abs,
          abs_of_nonneg (hν _)]
      simp only [norm_mul, norm_div, norm_pow, ht, norm_natCast]
    · simp
  calc
    _ ≤ (∑ c : GhostChoice m, w c * ‖F (out c)‖)^2 :=
      pow_le_pow_left₀ (norm_nonneg _) hnorm _
    _ ≤ (∑ c : GhostChoice m, w c * v0^(out c).card) *
        ∑ c : GhostChoice m, w c * ‖F (out c)‖^2 / v0^(out c).card :=
      weighted_sum_sq_le Finset.univ w (fun c => v0^(out c).card)
        (fun c => ‖F (out c)‖) (fun c _ => hw c) (fun c _ => pow_pos hv _)
    _ = _ := by
      simp_rw [ghostCoefficientApply_eq_positive_sum]
      simp only [w, out, mul_div_assoc]

theorem ghostCoefficientApply_nonneg {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (d r b : ℝ)
    (anchor : ∀ p, Line p) (F : Multiset (AnchoredParticle P Line) → ℝ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hd : 0 ≤ d) (hr : 0 ≤ r) (hb : 0 ≤ b)
    (hF : ∀ s, 0 ≤ F s) : 0 ≤ ghostCoefficientApply ν d r b anchor F m := by
  rw [ghostCoefficientApply_eq_positive_sum]
  exact Finset.sum_nonneg fun c _ => mul_nonneg
    (ghostPositiveCoefficient_nonneg ν d r b anchor m c hν hd hr hb) (hF _)

/-- Only the output truncation is dropped in this comparison. Hit sets,
indexed deletion multiplicities and fresh-prime integration are retained. -/
theorem ghostCoefficient_weighted_row_le_indexed {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (d r b v0 : ℝ)
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hd : 0 ≤ d) (hr : 0 ≤ r) (hb : 0 ≤ b) (hv : 0 ≤ v0) :
    ghostCoefficientApply ν d r b anchor (fun s => v0^s.card) m / v0^m.size ≤
      ghostIndexedWeightedRow m.size (memoryHits anchor m) ν r d b v0 B := by
  let T := fun (S : Finset (Fin m.size)) (l : ℕ) (fresh : Fin l → P) =>
    (d^S.card * r^((memoryHits anchor m).card-S.card) * b^l *
      tupleWeight ν fresh / (l.factorial : ℝ)) *
        (v0^(m.size-S.card+l)/v0^m.size)
  have hpoint (c : GhostChoice m) :
      (if hc : GhostChoice.Valid anchor m c then
        (d^c.1.card * r^(memoryHits anchor m \ c.1).card * b^c.2.size *
          tupleWeight ν c.2.values / (c.2.size.factorial : ℝ)) *
            v0^(tupleBag (ghostOutput anchor m c hc).values).card else 0) / v0^m.size ≤
      if c.1 ⊆ memoryHits anchor m then T c.1 c.2.size c.2.values else 0 := by
    by_cases hc : GhostChoice.Valid anchor m c
    · rw [dite_eq_left hc, ite_eq_left hc.1, tupleBag_card, Fintype.card_fin,
        ghostOutput_size, Finset.card_sdiff_of_subset hc.1]
      dsimp [T]
      rw [mul_div_assoc]
    · rw [dite_eq_right hc, zero_div]
      split_ifs
      · exact ghost_choice_weight_nonneg m.size (memoryHits anchor m) c.1 ν
          r d b v0 c.2.size c.2.values hν hr hd hb hv
      · exact le_rfl
  unfold ghostCoefficientApply
  rw [Finset.sum_div]
  apply (Finset.sum_le_sum fun c _ => hpoint c).trans_eq
  exact sum_ghost_choices_hits m.size B (memoryHits anchor m) T

theorem ghostCoefficient_weighted_row_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (d r b ρ Q Vmax s : ℝ)
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hd : 0 ≤ d) (hr : 0 ≤ r) (hb : 0 ≤ b)
    (hdC : d ≤ max 1 Vmax/ρ) (hrQ : r ≤ Q/ρ^2) (hbC : b ≤ max 1 Vmax/ρ) :
    ghostCoefficientApply ν d r b anchor (fun t => (ghostSchurWeight ρ Q Vmax)^t.card) m ≤
      Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ) *
        (ghostSchurWeight ρ Q Vmax)^m.size := by
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  apply (div_le_iff₀ (pow_pos hv m.size)).mp
  exact (ghostCoefficient_weighted_row_le_indexed ν d r b _ anchor m hν hd hr hb hv.le).trans
    (ghostIndexedWeightedRow_uniform m.size (memoryHits anchor m) ν r d b ρ Q Vmax s B
      hν hs hs0 hρ hQ hr hd hb hrQ hdC hbC)

/-- Both Schur sides follow from the explicit coefficients, with the
second side supplied by the proved symmetric factorial adjoint. -/
theorem ghostCoefficient_symmetric_l2_sq_bound {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (d r b : ℂ) (ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2)
    (hdC : ‖d‖ ≤ max 1 Vmax/ρ) (hrQ : ‖r‖ ≤ Q/ρ^2) (hbC : ‖b‖ ≤ max 1 Vmax/ρ) :
    finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
      (MemoryState.mass (anchoredParticleMass ν))
      (ghostCoefficientApply (fun p => (ν p : ℂ)) d r b anchor F) ≤
        (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^2 *
          finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
            (MemoryState.mass (anchoredParticleMass ν))
            (fun m => F (tupleBag m.values)) := by
  let v := ghostSchurWeight ρ Q Vmax
  let C := Real.exp (v * max 1 Vmax*s/ρ)
  let μ : MemoryState (AnchoredParticle P Line) B → ℝ := MemoryState.mass (anchoredParticleMass ν)
  let w : Multiset (AnchoredParticle P Line) → ℝ := fun t => v^t.card
  let F2 : Multiset (AnchoredParticle P Line) → ℝ := fun t => ‖F t‖^2/w t
  have hv : 0 < v := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hC : 0 ≤ C := (Real.exp_pos _).le
  have hμ (m : MemoryState (AnchoredParticle P Line) B) : 0 ≤ μ m := by
    dsimp [μ, MemoryState.mass, anchoredParticleMass]
    apply div_nonneg (Finset.prod_nonneg (fun i _ => hν _))
    positivity
  have hF2 (t) : 0 ≤ F2 t := div_nonneg (sq_nonneg _) (pow_pos hv _).le
  have hw (m : MemoryState (AnchoredParticle P Line) B) : w (tupleBag m.values) = v^m.size := by
    simp only [w, tupleBag_card, Fintype.card_fin]
  have hrow (m : MemoryState (AnchoredParticle P Line) B) :
      ghostCoefficientApply ν ‖d‖ ‖r‖ ‖b‖ anchor w m ≤ C*w (tupleBag m.values) := by
    rw [hw]
    exact ghostCoefficient_weighted_row_uniform ν _ _ _ ρ Q Vmax s anchor m
      hν hs hs0 hρ hQ (norm_nonneg _) (norm_nonneg _) (norm_nonneg _) hdC hrQ hbC
  have hcol (m : MemoryState (AnchoredParticle P Line) B) :
      ghostCoefficientApply ν ‖b‖ ‖r‖ ‖d‖ anchor w m ≤ C*w (tupleBag m.values) := by
    rw [hw]
    exact ghostCoefficient_weighted_row_uniform ν _ _ _ ρ Q Vmax s anchor m
      hν hs hs0 hρ hQ (norm_nonneg _) (norm_nonneg _) (norm_nonneg _) hbC hrQ hdC
  change (∑ m, μ m * ‖ghostCoefficientApply (fun p => (ν p : ℂ)) d r b anchor F m‖^2) ≤
    C^2 * ∑ m, μ m * ‖F (tupleBag m.values)‖^2
  calc
    _ ≤ ∑ m, μ m * ((C*w (tupleBag m.values)) *
        ghostCoefficientApply ν ‖d‖ ‖r‖ ‖b‖ anchor F2 m) := by
      apply Finset.sum_le_sum
      intro m _
      apply mul_le_mul_of_nonneg_left _ (hμ m)
      exact (ghostCoefficientApply_sq_le ν d r b anchor F m v hν hv).trans
        (mul_le_mul_of_nonneg_right (hrow m)
          (ghostCoefficientApply_nonneg ν _ _ _ anchor F2 m hν
            (norm_nonneg _) (norm_nonneg _) (norm_nonneg _) hF2))
    _ = C * ∑ m, μ m * w (tupleBag m.values) *
        ghostCoefficientApply ν ‖d‖ ‖r‖ ‖b‖ anchor F2 m := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m _
      ring
    _ = C * ∑ m, μ m * F2 (tupleBag m.values) *
        ghostCoefficientApply ν ‖b‖ ‖r‖ ‖d‖ anchor w m := by
      congr 1
      exact ghostCoefficientApply_adjoint B ν ‖d‖ ‖r‖ ‖b‖ anchor F2 w
    _ ≤ C * ∑ m, μ m * F2 (tupleBag m.values) * (C*w (tupleBag m.values)) := by
      apply mul_le_mul_of_nonneg_left _ hC
      exact Finset.sum_le_sum fun m _ => mul_le_mul_of_nonneg_left
        (hcol m) (mul_nonneg (hμ m) (hF2 _))
    _ = _ := by
      simp_rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m _
      have hw0 : w (tupleBag m.values) ≠ 0 := (pow_pos hv _).ne'
      dsimp only [F2]
      field_simp

/-- The actual source ghost has a uniform symmetric-memory squared
norm bound. No row, column, or adjoint estimate is a hypothesis. -/
theorem ghostApply_symmetric_l2_sq_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
      (MemoryState.mass (anchoredParticleMass ν))
      (ghostApply ν V η q ρ anchor (fun m => F (tupleBag m.values))) ≤
        (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^2 *
          finiteL2Sq (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
            (MemoryState.mass (anchoredParticleMass ν)) (fun m => F (tupleBag m.values)) := by
  have hd : ‖((-η/ρ : ℝ) : ℂ)‖ ≤ max 1 Vmax/ρ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_div, abs_neg,
      abs_of_nonneg hη0, abs_of_pos hρ]
    exact div_le_div_of_nonneg_right (hη1.trans (le_max_left _ _)) hρ.le
  have hr : ‖((q/ρ^2 : ℝ) : ℂ)‖ ≤ Q/ρ^2 := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (div_nonneg hq0 (sq_nonneg _))]
    exact div_le_div_of_nonneg_right hqQ (sq_nonneg _)
  have hb : ‖((-η*V/ρ : ℝ) : ℂ)‖ ≤ max 1 Vmax/ρ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_div, abs_mul, abs_neg,
      abs_of_nonneg hη0, abs_of_nonneg hV0, abs_of_pos hρ]
    apply div_le_div_of_nonneg_right _ hρ.le
    exact ((mul_le_mul_of_nonneg_right hη1 hV0).trans_eq (one_mul V)).trans
      (hVmax.trans (le_max_right _ _))
  have heq : ghostApply (B := B) ν V η q ρ anchor (fun m => F (tupleBag m.values)) =
      ghostCoefficientApply (fun p => (ν p : ℂ))
        ((-η/ρ : ℝ) : ℂ) ((q/ρ^2 : ℝ) : ℂ) ((-η*V/ρ : ℝ) : ℂ) anchor F :=
    funext (ghostApply_eq_coefficientApply ν V η q ρ anchor F)
  rw [heq]
  exact ghostCoefficient_symmetric_l2_sq_bound ν _ _ _ ρ Q Vmax s anchor F
    hν hs hs0 hρ hQ hd hr hb

/-- The ghost norm is bounded by the same explicit exponential for every
memory cutoff and every symmetric test function. -/
theorem ghostApply_symmetric_l2_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (F : Multiset (AnchoredParticle P Line) → ℂ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    finiteL2 (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
      (MemoryState.mass (anchoredParticleMass ν))
      (ghostApply ν V η q ρ anchor (fun m => F (tupleBag m.values))) ≤
        Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ) *
          finiteL2 (Finset.univ : Finset (MemoryState (AnchoredParticle P Line) B))
            (MemoryState.mass (anchoredParticleMass ν)) (fun m => F (tupleBag m.values)) := by
  unfold finiteL2
  apply (Real.sqrt_le_sqrt (ghostApply_symmetric_l2_sq_uniform ν V η q ρ Q Vmax s
    anchor F hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax)).trans_eq
  rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (Real.exp_pos _).le]

end Elliptic.Operator
