module

public import Elliptic.Operator.OriginalIndependentBoundary

/-!
# Source support of the full original path sum

For a nonempty path the literal cross-edge ban makes every active list
injective. All other paths have zero complete geometric multiplier. Thus the
global independent-line identity sums over every original finite path.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open CanonicalBoundaryAssembly IndependentLineNormalization
attribute [local instance] Classical.propDecidable
local instance originalSupportDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

private def edgeSlot (J : ℕ) (b : Bool) : Fin (J+1) → Fin J ⊕ Bool :=
  Fin.lastCases (.inr b) (fun k=>.inl k)

private theorem edgeSlot_injective (J : ℕ) (b : Bool) : Function.Injective (edgeSlot J b) := by
  intro k l
  refine Fin.lastCases ?_ (fun k=>?_) k <;>
    refine Fin.lastCases ?_ (fun l=>?_) l <;> simp [edgeSlot]

/-- Both literal pre-symmetrized endpoint lists are individually injective. -/
theorem crossEdgeBan_lists_injective {I : Type*} {P : I→Type*} {J : ℕ}
    (value : ∀ i,P i→ℕ) (a b : PhysicalActiveLists P J)
    (h : sourceCrossEdgeBan value a b) :
    (∀ i,Function.Injective (a i)) ∧ (∀ i,Function.Injective (b i)) := by
  have ha (i : I) (k : Fin (J+1)) :
      sourceCrossEdgeLabels value a b (i,edgeSlot J false k)=value i (a i k) := by
    refine Fin.lastCases ?_ (fun k=>?_) k <;> simp [sourceCrossEdgeLabels,edgeSlot]
  have hb (i : I) (k : Fin (J+1)) :
      sourceCrossEdgeLabels value a b (i,edgeSlot J true k)=value i (b i k) := by
    refine Fin.lastCases ?_ (fun k=>?_) k
    · simp [sourceCrossEdgeLabels,edgeSlot]
    · simp [sourceCrossEdgeLabels,edgeSlot,h.1 i k]
  constructor
  · intro i k l he
    apply edgeSlot_injective J false
    exact congrArg Prod.snd (h.2 (a₁:=(i,edgeSlot J false k)) (a₂:=(i,edgeSlot J false l)) (by rw [ha,ha,he]))
  · intro i k l he
    apply edgeSlot_injective J true
    exact congrArg Prod.snd (h.2 (a₁:=(i,edgeSlot J true k)) (a₂:=(i,edgeSlot J true l)) (by rw [hb,hb,he]))

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i→Type} {J B N : ℕ}
variable {anchor : Z→∀ i p,Line i p}

namespace OriginalPath

/-- On a nonempty path the literal edge bans imply all active-list
requirements, including the final list after the last target permutation. -/
theorem sourceValid_of_crossEdgeBan (r : OriginalPath I Z P J N)
    (value : ∀ i,P i→ℕ) (hN : 0<N)
    (hban : ∀ j,j<N→sourceCrossEdgeBan value (r.sourceLists j) (r.targetLists j)) :
    r.SourceValid value := by
  refine ⟨?_,hban⟩
  intro j hj i k l he
  by_cases hlt : j<N
  · have hh := (crossEdgeBan_lists_injective value _ _ (hban j hlt)).1 i
    have hkl : (r.sourcePermAt j i).symm k=(r.sourcePermAt j i).symm l := by
      apply hh
      simpa only [sourceLists,Equiv.apply_symm_apply] using he
    exact (r.sourcePermAt j i).symm.injective hkl
  · have hjN : j=N := by omega
    subst j
    have ht : N-1<N := by omega
    have hs : N-1+1=N := by omega
    have hh := (crossEdgeBan_lists_injective value _ _ (hban (N-1) ht)).2 i
    have hkl : r.targetPermAt (N-1) i k=r.targetPermAt (N-1) i l := by
      apply hh
      simpa only [targetLists,Equiv.symm_apply_apply,hs] using he
    exact (r.targetPermAt (N-1) i).injective hkl

/-- A nonzero complete source path coefficient carries the source support
conditions used by the independent-lifespan reconstruction. -/
theorem sourceValid_of_boundaryFactor_ne_zero
    (r : OriginalPath I Z P J N) (value : ∀ i,P i→ℕ)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hban : ∀ j z c w d,geometry j z c w d≠0→sourceCrossEdgeBan value c d)
    (V : I→ℝ) (a b : BoundaryIndex I Z P J→ℂ) (hN : 0<N)
    (hw : r.boundaryFactor geometry V a b≠0) : r.SourceValid value := by
  apply r.sourceValid_of_crossEdgeBan value hN
  intro j hj
  apply hban
  intro hz
  have hp : (∏ t∈Finset.range N,geometry t (r.positionAt t) (r.sourceLists t)
      (r.positionAt (t+1)) (r.targetLists t))=0 :=
    Finset.prod_eq_zero (Finset.mem_range.mpr hj) hz
  exact hw (by simp only [boundaryFactor,hp,mul_zero,zero_mul])

/-- Restricting to source-supported paths discards only zero summands,
regardless of how the independent-line factor depends on the entire path. -/
theorem sum_all_eq_sourcePaths
    (value : ∀ i,P i→ℕ)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hban : ∀ j z c w d,geometry j z c w d≠0→sourceCrossEdgeBan value c d)
    (V : I→ℝ) (a b : BoundaryIndex I Z P J→ℂ) (hN : 0<N)
    (W : OriginalPath I Z P J N→ℂ) :
    (∑ r : OriginalPath I Z P J N,r.boundaryFactor geometry V a b*W r) =
      ∑ r : SourcePaths (Z:=Z) value J N,r.val.boundaryFactor geometry V a b*W r.val := by
  calc
    _ = ∑ r : OriginalPath I Z P J N,
        if r.SourceValid value then r.boundaryFactor geometry V a b*W r else 0 := by
      apply Finset.sum_congr rfl
      intro r _
      by_cases hr : r.SourceValid value
      · simp [hr]
      · have hz : r.boundaryFactor geometry V a b=0 := by
          by_contra hw
          exact hr (r.sourceValid_of_boundaryFactor_ne_zero value geometry hban V a b hN hw)
        simp [hr,hz]
    _ = _ := by
      rw [Finset.sum_ite]
      simp only [Finset.sum_const_zero,add_zero]
      exact Finset.sum_subtype _ (fun _=>by simp) _

end OriginalPath

/-- Full original path sum, with no support restriction on its index type. -/
theorem all_independent_paths_eq_baseline_boundary [∀ i p,Fintype (Line i p)]
    (value : ∀ i,P i→ℕ) (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ) (ρ : ℝ)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z c w d,geometry j z c w d≠0→∀ i (k : Fin J),
      anchor z i (c i k.castSucc)=anchor w i (c i k.castSucc))
    (hban : ∀ j z c w d,geometry j z c w d≠0→sourceCrossEdgeBan value c d)
    (hρ : ρ≠0) (hV : ∀ i,V i≠0) (hN : 0<N)
    (hn : ∀ i p,(Fintype.card (Line i p) : ℝ)≠0)
    (hbase : ∀ i p,(Fintype.card (Line i p) : ℝ)-∑j∈Finset.range (N+1),η j≠0)
    (hν : ∀ i p,V i*ν i p=normalizedLineMass (Finset.range (N+1)) η (Fintype.card (Line i p)))
    (hB : (∑ i,Fintype.card (P i))≤B)
    (a b : BoundaryIndex I Z P J→ℂ) :
    (∑ r : OriginalPath I Z P J N,
      r.boundaryFactor geometry V a b*(r.independentAverage anchor η : ℂ)) =
      ((∏ i, ∏ p,baseline (Finset.range (N+1)) η (Fintype.card (Line i p)) : ℝ) : ℂ)*
        boundaryPairing (B:=B) ν V η (fun j=>1-η j) ρ anchor geometry value N a b := by
  rw [OriginalPath.sum_all_eq_sourcePaths value geometry hban V a b hN]
  exact independent_path_sum_eq_baseline_boundary value ν V η ρ geometry
    hvalue hshared hban hρ hV hn hbase hν hB a b

end Elliptic.Operator.OriginalLifespanSchedule
