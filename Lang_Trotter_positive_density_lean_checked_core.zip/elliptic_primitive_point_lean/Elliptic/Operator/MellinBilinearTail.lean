module

public import Elliptic.Operator.MellinWeightedTail
public import Elliptic.Operator.MellinCentralEnergy

/-! Actual translated bilinear Mellin integrals and their frequency tails. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinBilinearTail
open MeasureTheory Set MellinWeightedTail
set_option backward.isDefEq.respectTransparency false

def productMass (Q Q':ℝ→ℂ) (s t:ℝ) : ℝ := ‖Q t‖*‖Q' (s-t)‖

theorem productMass_continuous (Q Q':ℝ→ℂ) (hQ:Continuous Q) (hQ':Continuous Q') (s:ℝ) :
    Continuous (productMass Q Q' s) := hQ.norm.mul ((hQ'.comp (continuous_const.sub continuous_id)).norm)

theorem productMass_nonneg (Q Q':ℝ→ℂ) (s t:ℝ) : 0≤productMass Q Q' s t :=
  mul_nonneg (norm_nonneg _) (norm_nonneg _)

/-- Reflection plus translation preserves the literal interval length. -/
theorem interval_substitution (f:ℝ→ℝ) (s a b:ℝ) (hab:a≤b) :
    (∫t in Icc a b,f (s-t))=∫t in Icc (s-b) (s-a),f t := by
  rw [integral_Icc_eq_integral_Ioc,←intervalIntegral.integral_of_le hab,
    intervalIntegral.integral_comp_sub_left,intervalIntegral.integral_of_le (by linarith),
    integral_Icc_eq_integral_Ioc]

/-- Cauchy's inequality in the precise translated form required by the Mellin tail. -/
theorem translated_product_mean (Q Q':ℝ→ℂ) (hQ:Continuous Q) (hQ':Continuous Q')
    (A X:ℝ)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))
    (hmean':∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))
    (s a b:ℝ) (hab:a≤b) :
    (∫t in Icc a b,productMass Q Q' s t)≤A*(1+(b-a)/X) := by
  have hi : IntegrableOn (productMass Q Q' s) (Icc a b) :=
    (productMass_continuous Q Q' hQ hQ' s).continuousOn.integrableOn_compact isCompact_Icc
  have hiQ : IntegrableOn (fun t=>‖Q t‖^2) (Icc a b) :=
    (hQ.norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  have hiQ' : IntegrableOn (fun t=>‖Q' (s-t)‖^2) (Icc a b) :=
    ((hQ'.comp (continuous_const.sub continuous_id)).norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  have hbound := setIntegral_mono_on hi ((hiQ.add hiQ').div_const 2) measurableSet_Icc
    (fun t ht=>show productMass Q Q' s t≤(‖Q t‖^2+‖Q' (s-t)‖^2)/2 by
      dsimp [productMass]
      nlinarith [sq_nonneg (‖Q t‖-‖Q' (s-t)‖)])
  simp only [Pi.add_apply] at hbound
  rw [integral_div,integral_add hiQ hiQ'] at hbound
  rw [interval_substitution (fun t=>‖Q' t‖^2) s a b hab] at hbound
  have hm := hmean a b hab
  have hm' := hmean' (s-b) (s-a) (by linarith)
  have he : s-a-(s-b)=b-a := by ring
  rw [he] at hm'
  linarith

/-- The fixed polynomial weight is integrable, with a deliberately coarse universal constant. -/
theorem weight_integrable (j:ℕ) (hj:2≤j) : Integrable (weight 1 j) ∧ (∫s:ℝ,weight 1 j s)≤12 := by
  obtain ⟨hi,hb⟩ := polynomial_weight_full (fun _=>1) continuous_const (by intro; norm_num)
    1 1 1 (by norm_num) (by norm_num) (by norm_num) j hj (by
      intro a b hab
      rw [setIntegral_const,Real.volume_real_Icc_of_le hab]
      simp only [smul_eq_mul,mul_one,one_mul,div_one]
      linarith)
  norm_num at hi hb ⊢
  exact ⟨hi,hb⟩

/-- A continuous kernel with product decay is integrable against the literal
two endpoint polynomials; the interval hypotheses are coefficient uniform. -/
theorem bilinear_integrable (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (A X D:ℝ) (hA:0≤A) (hX:0<X) (hD:0≤D) (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))
    (hmean':∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))
    (hdecay:∀t s,‖K t s‖≤D*weight X j t*weight 1 j s) :
    Integrable (fun p:ℝ×ℝ=>K p.2 p.1*Q p.2*Q' (p.1-p.2)) (volume.prod volume) := by
  let F : ℝ×ℝ→ℂ := fun p=>K p.2 p.1*Q p.2*Q' (p.1-p.2)
  have hFc : Continuous F := ((hK.comp continuous_swap).mul (hQ.comp continuous_snd)).mul
    (hQ'.comp (continuous_fst.sub continuous_snd))
  have hmajor (s:ℝ) := polynomial_weight_full (productMass Q Q' s)
    (productMass_continuous Q Q' hQ hQ' s) (productMass_nonneg Q Q' s)
    X X A hX hX hA j hj (translated_product_mean Q Q' hQ hQ' A X hmean hmean' s)
  have hbound (s:ℝ) : (∫t:ℝ,weight X j t*productMass Q Q' s t)≤12*A := by
    have hh := (hmajor s).2
    simp only [div_self hX.ne'] at hh
    convert hh using 1 <;> ring
  have hslice (s:ℝ) : Integrable (fun t=>F (s,t)) := by
    apply ((hmajor s).1.const_mul (D*weight 1 j s)).mono'
      ((hFc.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable)
    filter_upwards [] with t
    have hh := mul_le_mul_of_nonneg_right (hdecay t s) (productMass_nonneg Q Q' s t)
    simpa [F,productMass,norm_mul,mul_assoc,mul_left_comm,mul_comm] using hh
  apply (integrable_prod_iff hFc.aestronglyMeasurable).mpr
  refine ⟨ae_of_all _ hslice,?_⟩
  apply ((weight_integrable j hj).1.const_mul (12*A*D)).mono'
    (hFc.norm.stronglyMeasurable.integral_prod_right').aestronglyMeasurable
  filter_upwards [] with s
  rw [Real.norm_of_nonneg (integral_nonneg (fun t=>norm_nonneg _))]
  calc
    (∫t:ℝ,‖F (s,t)‖)≤(D*weight 1 j s)*(∫t:ℝ,weight X j t*productMass Q Q' s t) := by
      rw [←integral_const_mul]
      apply integral_mono (hslice s).norm ((hmajor s).1.const_mul _)
      intro t
      have hh := mul_le_mul_of_nonneg_right (hdecay t s) (productMass_nonneg Q Q' s t)
      simpa [F,productMass,norm_mul,mul_assoc,mul_left_comm,mul_comm] using hh
    _ ≤(D*weight 1 j s)*(12*A) :=
      mul_le_mul_of_nonneg_left (hbound s) (mul_nonneg hD (weight_nonneg 1 (by norm_num) j s))
    _ = _ := by ring

/-- The t-strip outside the Mellin rectangle, integrated over every s. -/
theorem t_strip_bound (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (A X D T:ℝ) (hA:0≤A) (hX:0<X) (hD:0≤D) (hT:0<T) (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))
    (hmean':∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))
    (hdecay:∀t s,‖K t s‖≤D*weight X j t*weight 1 j s) :
    (∫p in (univ×ˢ{t:ℝ | T≤|t|}),‖K p.2 p.1*Q p.2*Q' (p.1-p.2)‖ ∂volume.prod volume)≤
      48*A*D*(X/T)^j*(1+T/X) := by
  have hF := bilinear_integrable K Q Q' hK hQ hQ' A X D hA hX hD j hj hmean hmean' hdecay
  rw [setIntegral_prod _ hF.norm.integrableOn,setIntegral_univ]
  let B : ℝ := 4*A*(X/T)^j*(1+T/X)
  have hB : 0≤B := by dsimp [B]; positivity
  have hslice (s:ℝ) : (∫t in {t:ℝ | T≤|t|},‖K t s*Q t*Q' (s-t)‖)≤D*weight 1 j s*B := by
    obtain ⟨hi,hb⟩ := polynomial_weight_two_sided_tail (productMass Q Q' s)
      (productMass_continuous Q Q' hQ hQ' s) (productMass_nonneg Q Q' s)
      X T X A hX hT hX hA j hj (translated_product_mean Q Q' hQ hQ' A X hmean hmean' s)
    calc
      _ ≤(D*weight 1 j s)*(∫t in {t:ℝ | T≤|t|},weight X j t*productMass Q Q' s t) := by
        rw [←integral_const_mul]
        apply integral_mono_of_nonneg (ae_of_all _ (fun t=>norm_nonneg _)) (hi.const_mul _)
        filter_upwards [] with t
        have hh := mul_le_mul_of_nonneg_right (hdecay t s) (productMass_nonneg Q Q' s t)
        simpa [productMass,norm_mul,mul_assoc,mul_left_comm,mul_comm] using hh
      _ ≤_ := mul_le_mul_of_nonneg_left hb (mul_nonneg hD (weight_nonneg 1 (by norm_num) j s))
  calc
    _ ≤∫s:ℝ,D*weight 1 j s*B := by
      apply integral_mono_of_nonneg (ae_of_all _ (fun s=>integral_nonneg (fun t=>norm_nonneg _)))
        (((weight_integrable j hj).1.const_mul D).mul_const B) (ae_of_all _ hslice)
    _ = D*(∫s:ℝ,weight 1 j s)*B := by rw [integral_mul_const,integral_const_mul]
    _ ≤D*12*B := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (weight_integrable j hj).2 hD) hB
    _ = _ := by dsimp [B]; ring

/-- The s-strip uses the full weighted t integral, so translated frequencies
never require a pointwise estimate on Q or Q′. -/
theorem s_strip_bound (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (A X D S:ℝ) (hA:0≤A) (hX:0<X) (hD:0≤D) (hS:0<S) (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))
    (hmean':∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))
    (hdecay:∀t s,‖K t s‖≤D*weight X j t*weight 1 j s) :
    (∫p in ({s:ℝ | S≤|s|}×ˢuniv),‖K p.2 p.1*Q p.2*Q' (p.1-p.2)‖ ∂volume.prod volume)≤
      48*A*D*(1/S)^j*(1+S) := by
  have hF := bilinear_integrable K Q Q' hK hQ hQ' A X D hA hX hD j hj hmean hmean' hdecay
  rw [setIntegral_prod _ hF.norm.integrableOn]
  simp only [setIntegral_univ]
  have hslice (s:ℝ) : (∫t:ℝ,‖K t s*Q t*Q' (s-t)‖)≤D*weight 1 j s*(12*A) := by
    obtain ⟨hi,hb⟩ := polynomial_weight_full (productMass Q Q' s)
      (productMass_continuous Q Q' hQ hQ' s) (productMass_nonneg Q Q' s)
      X X A hX hX hA j hj (translated_product_mean Q Q' hQ hQ' A X hmean hmean' s)
    have hb' : (∫t:ℝ,weight X j t*productMass Q Q' s t)≤12*A := by
      simpa only [div_self hX.ne',show (6:ℝ)*A*(1+1)=12*A by ring] using hb
    calc
      _ ≤(D*weight 1 j s)*(∫t:ℝ,weight X j t*productMass Q Q' s t) := by
        rw [←integral_const_mul]
        apply integral_mono_of_nonneg (ae_of_all _ (fun t=>norm_nonneg _)) (hi.const_mul _)
        filter_upwards [] with t
        have hh := mul_le_mul_of_nonneg_right (hdecay t s) (productMass_nonneg Q Q' s t)
        simpa [productMass,norm_mul,mul_assoc,mul_left_comm,mul_comm] using hh
      _ ≤_ := mul_le_mul_of_nonneg_left hb' (mul_nonneg hD (weight_nonneg 1 (by norm_num) j s))
  obtain ⟨hiw,hw⟩ := polynomial_weight_two_sided_tail (fun _=>1) continuous_const (by intro; norm_num)
    1 S 1 1 (by norm_num) hS (by norm_num) (by norm_num) j hj (by
      intro a b hab
      rw [setIntegral_const,Real.volume_real_Icc_of_le hab]
      simp only [smul_eq_mul,mul_one,one_mul,div_one]
      linarith)
  simp only [mul_one,one_mul,div_one] at hiw hw
  calc
    _ ≤∫s in {s:ℝ | S≤|s|},D*weight 1 j s*(12*A) := by
      apply integral_mono_of_nonneg (ae_of_all _ (fun s=>integral_nonneg (fun t=>norm_nonneg _)))
        ((hiw.const_mul D).mul_const (12*A)) (ae_of_all _ hslice)
    _ = D*(∫s in {s:ℝ | S≤|s|},weight 1 j s)*(12*A) := by rw [integral_mul_const,integral_const_mul]
    _ ≤D*(4*(1/S)^j*(1+S))*(12*A) :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hw hD) (by positivity)
    _ = _ := by ring

/-- The rectangular truncation error is bounded by the two actual tail strips. -/
theorem rectangle_error_le_strips (F:ℝ×ℝ→ℂ) (hF:Integrable F (volume.prod volume)) (T S:ℝ) :
    ‖(∫p:ℝ×ℝ,F p ∂volume.prod volume)-
      (∫p in Icc (-S) S×ˢIcc (-T) T,F p ∂volume.prod volume)‖≤
      (∫p in univ×ˢ{t:ℝ | T≤|t|},‖F p‖ ∂volume.prod volume)+
      (∫p in {s:ℝ | S≤|s|}×ˢuniv,‖F p‖ ∂volume.prod volume) := by
  let R : Set (ℝ×ℝ) := Icc (-S) S×ˢIcc (-T) T
  let U : Set (ℝ×ℝ) := univ×ˢ{t:ℝ | T≤|t|}
  let V : Set (ℝ×ℝ) := {s:ℝ | S≤|s|}×ˢuniv
  have hR : MeasurableSet R := measurableSet_Icc.prod measurableSet_Icc
  have hU : MeasurableSet U := MeasurableSet.univ.prod (isClosed_le continuous_const continuous_abs).measurableSet
  have hV : MeasurableSet V := (isClosed_le continuous_const continuous_abs).measurableSet.prod MeasurableSet.univ
  rw [←setIntegral_compl hR hF]
  apply (norm_integral_le_integral_norm _).trans
  rw [←integral_indicator hR.compl,←integral_indicator hU,←integral_indicator hV,
    ←integral_add (hF.norm.indicator hU) (hF.norm.indicator hV)]
  apply integral_mono (hF.norm.indicator hR.compl) ((hF.norm.indicator hU).add (hF.norm.indicator hV))
  intro p
  simp only [Pi.add_apply]
  have hcover : p∈Rᶜ→p∈U∨p∈V := by
    intro hp
    by_cases ht:T≤|p.2|
    · exact Or.inl ⟨mem_univ _,ht⟩
    · apply Or.inr
      refine ⟨?_,mem_univ _⟩
      by_contra hs
      apply hp
      exact ⟨abs_le.mp (le_of_not_ge hs),abs_le.mp (le_of_not_ge ht)⟩
  by_cases hp:p∈Rᶜ
  · rw [indicator_of_mem hp]
    rcases hcover hp with hu|hv
    · rw [indicator_of_mem hu]
      exact le_add_of_nonneg_right (indicator_nonneg (fun p hp=>norm_nonneg _) _)
    · rw [indicator_of_mem hv]
      exact le_add_of_nonneg_left (indicator_nonneg (fun p hp=>norm_nonneg _) _)
  · rw [indicator_of_notMem hp]
    exact add_nonneg (indicator_nonneg (fun p hp=>norm_nonneg _) _) (indicator_nonneg (fun p hp=>norm_nonneg _) _)

/-- Fully explicit source (5.20): a rectangular truncation using only the
two proved uniform interval mean-square estimates and kernel decay. -/
theorem bilinear_rectangle_error (K:ℝ→ℝ→ℂ) (Q Q':ℝ→ℂ)
    (hK:Continuous (Function.uncurry K)) (hQ:Continuous Q) (hQ':Continuous Q')
    (A X D T S:ℝ) (hA:0≤A) (hX:0<X) (hD:0≤D) (hT:0<T) (hS:0<S) (j:ℕ) (hj:2≤j)
    (hmean:∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))
    (hmean':∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))
    (hdecay:∀t s,‖K t s‖≤D*weight X j t*weight 1 j s) :
    ‖(∫t:ℝ,∫s:ℝ,K t s*Q t*Q' (s-t))-
      (∫t in Icc (-T) T,∫s in Icc (-S) S,K t s*Q t*Q' (s-t))‖≤
      48*A*D*((X/T)^j*(1+T/X)+(1/S)^j*(1+S)) := by
  have hF := bilinear_integrable K Q Q' hK hQ hQ' A X D hA hX hD j hj hmean hmean' hdecay
  have h := rectangle_error_le_strips _ hF T S
  have hrect := MellinCentralEnergy.rectangle_integrable K Q Q' hK hQ hQ' T S
  have hall := (integral_prod _ hF).trans (integral_integral_swap hF)
  have hr := (setIntegral_prod _ hF.integrableOn (s:=Icc (-S) S) (t:=Icc (-T) T)).trans
    (integral_integral_swap hrect)
  rw [hall,hr] at h
  have ht := t_strip_bound K Q Q' hK hQ hQ' A X D T hA hX hD hT j hj hmean hmean' hdecay
  have hs := s_strip_bound K Q Q' hK hQ hQ' A X D S hA hX hD hS j hj hmean hmean' hdecay
  exact h.trans (by nlinarith)

end Elliptic.Operator.MellinBilinearTail
