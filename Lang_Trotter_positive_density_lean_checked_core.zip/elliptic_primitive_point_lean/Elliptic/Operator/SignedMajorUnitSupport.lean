module
public import Elliptic.Operator.SignedMajorFiniteEstimate

/-! Uniform unit support for the actual polylogarithmic major-arc moduli. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorMellinIdentity
open Filter Artin.MarkedSource Artin.MarkedCriterion
set_option backward.isDefEq.respectTransparency false

/-- The threshold precedes every modulus, coefficient index, band count and
prime family. Long variables use actual rough support W(x); prime labels use
only the source lower bound exp((log x)^.1). -/
theorem eventually_source_unit_support (A : ℝ) :
    ∀ᶠx:ℝ in atTop,
      (∀k:ℕ,0<k → (k:ℝ)≤(Real.log x)^A → ∀n:ℕ,IsRough (W x) n → n.Coprime k) ∧
      (∀K:ℕ,∀b:Bands K,
        (∀i,∀p∈b.group x i,Real.exp ((Real.log x)^(1/10:ℝ))≤(p:ℝ)) →
        ∀k:ℕ,0<k → (k:ℝ)≤(Real.log x)^A → ∀a:SignedCauchyExpansion.LabelTuple b x,
          (SignedCauchyExpansion.labelProduct b x a).Coprime k) := by
  filter_upwards [logarithmic_power_le_rough_cutoff A (6/25) (by norm_num),
    logarithmic_power_le_rough_cutoff (A+1) (1/10) (by norm_num),
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop (1:ℝ))] with x hW hp hL
  constructor
  · intro k hk hkL n hn
    exact rough_coprime hk (hkL.trans hW) hn
  · intro K b hb k hk hkL a
    apply labelProduct_coprime b x k hk
    intro i p hpi
    have hh : (k:ℝ)<p := (hkL.trans_lt
      (Real.rpow_lt_rpow_of_exponent_lt hL (by linarith : A<A+1))).trans_le (hp.trans (hb i p hpi))
    exact_mod_cast hh

end Elliptic.Operator.SignedMajorMellinIdentity
