module

public import Elliptic.Operator.PhysicalRawBudgetAsymptotics
public import Elliptic.Operator.PhysicalComparisonBudgetAsymptotics

/-! Arbitrary logarithmic saving for the actual full signed dirty budget.
The number of groups is chosen from the requested saving before all later
fixed constants. The eventual statement is uniform over prime spaces,
masses, coefficient arrays, band exponents, and admissible dyads. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyBudgetAsymptotics
open Filter
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 theorem combine_savings (L G R C : ℝ) (hL : 2≤L) (hR : 0≤R) (hC : 0≤C)
    (hr : R≤L^(-(G+1))) (hc : C≤L^(-(G+1))) :
    Real.sqrt (2*(R^2+C^2))≤L^(-G) := by
  have hL0 : 0<L := by linarith
  have hp : 0≤L^(-(G+1)) := by positivity
  calc
    _ ≤ Real.sqrt ((2*L^(-(G+1)))^2) := Real.sqrt_le_sqrt (by nlinarith)
    _ = 2*L^(-(G+1)) := Real.sqrt_sq (by positivity)
    _ ≤ L*L^(-(G+1)) := mul_le_mul_of_nonneg_right hL hp
    _ = _ := by rw [show -G=1+(-(G+1)) by ring,Real.rpow_add hL0,Real.rpow_one]

 theorem exists_group_count_for_signed_saving (G : ℝ) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀ρ v0 vmin vmax M A E C : ℝ,ρ<1→0<v0→0<vmin→0≤M→0≤A→0≤C→
      ∀ᶠL : ℝ in atTop,∀a : Fin K→ℝ,(∀i,(1/10:ℝ)≤a i)→
        ∀(P : Fin K→Type) (_ : ∀i,Fintype (P i)),∀(ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (H Y R : ℝ),
        (∀i p,0≤ν i p)→(∀i,(∑p,ν i p)≤M)→(∀i,vmin≤V i)→(∀i,V i≤vmax)→
        0≤H→H≤L^E→Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
        Real.sqrt (2*((PhysicalDirtyRawSchur.allMaskBudget K (momentPadding L) (memoryCutoff L)
          V ρ v0 vmin M L A a)^2+
          (PhysicalDirtyComparisonSchur.allMaskBudget (memoryCutoff L) ν V v0 (4*A*H^3) Y C R)^2))≤L^(-G) := by
  obtain ⟨K₀,hK₀,hraw⟩ := PhysicalRawBudgetAsymptotics.exists_group_count_for_actual_raw_saving (G+1)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ρ v0 vmin vmax M A E C hρ hv0 hmin hM hA hC
  have h4A : 0≤4*A := by positivity
  filter_upwards [eventually_ge_atTop (2:ℝ),hraw K hK ρ v0 vmin vmax M A hρ hv0 hmin hM hA,
    PhysicalComparisonBudgetAsymptotics.eventually_actual_comparison_saving K v0 vmin vmax M (4*A) (3*E) C (G+1)
      hv0 hmin hM h4A hC] with L hL hr hc
  intro a ha P inst ν V H Y R hν hmass hlo hhi hH hHl hY hR
  letI : ∀i,Fintype (P i) := inst
  have hL0 : 0<L := by linarith
  have hH3 : H^3≤L^(3*E) := by
    apply (pow_le_pow_left₀ hH hHl 3).trans_eq
    rw [←Real.rpow_mul_natCast hL0.le]
    congr 1
    norm_num
    ring
  apply combine_savings L G _ _ hL (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) (hr a ha V hlo hhi)
  exact hc P inst ν V (4*A*H^3) Y R hν hmass hlo hhi (by positivity)
    (mul_le_mul_of_nonneg_left hH3 h4A) hY hR

end Elliptic.Operator.PhysicalDirtyBudgetAsymptotics
