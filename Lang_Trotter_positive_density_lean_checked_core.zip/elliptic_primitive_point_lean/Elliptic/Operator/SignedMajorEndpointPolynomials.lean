module
public import Elliptic.Operator.SignedMajorMellinIdentity
public import Elliptic.Operator.MajorArcScaleCancellation

/-! Exact normalized endpoint polynomials, including the conjugated side. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorMellinIdentity
open scoped BigOperators ComplexConjugate
open Artin.MarkedReplacement MajorArcScaleCancellation
open SignedMajorCharacter Elliptic.SourceContracts
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

/-- The normalized label factor, with the literal modulation convention. -/
def labelPolynomial {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (χ : DirichletCharacter ℂ k) (η : ℝ→ℂ) (Y lam t : ℝ) : ℂ :=
  (Y:ℂ)⁻¹*∑a∈A,η ((value a:ℝ)/Y)*additivePhase (-lam*((value a:ℝ)/Y))*
    χ (value a:ZMod k)*archimedeanPhase t (value a)

theorem leftPolynomial_normalized {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,0<value a) (hm : ∀m∈S,0<m) (hn : ∀n∈T,0<n) :
    (∑i∈triples A S T,leftCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
      LogPhaseProgression.phase t (endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2))=
      ((Y*(Hm*Hn):ℝ):ℂ)*LogPhaseProgression.phase (-t) (Y*(Hm*Hn))*
        labelPolynomial A value (χ 1) η Y (-lam) t*
          longPolynomial S α Hm (χ 2) t*longPolynomial T β Hn (χ 3) t := by
  unfold leftCoefficient
  rw [triplePolynomial_factor A value S T
    (fun a=>η ((value a:ℝ)/Y)*additivePhase (lam*((value a:ℝ)/Y))*χ 1 (value a:ZMod k))
    (fun m=>α m*χ 2 (m:ZMod k)) (fun n=>β n*χ 3 (n:ZMod k))
    Y (Hm*Hn) t hY (mul_pos hHm hHn) ha hm hn]
  have hy : (Y:ℂ)≠0 := by exact_mod_cast hY.ne'
  have hm' : (Hm:ℂ)≠0 := by exact_mod_cast hHm.ne'
  have hn' : (Hn:ℂ)≠0 := by exact_mod_cast hHn.ne'
  simp only [labelPolynomial,longPolynomial,neg_neg,Complex.ofReal_mul]
  field_simp
  simp only [mul_comm,mul_left_comm,mul_assoc]

theorem rightPolynomial_normalized {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,0<value a) (hm : ∀m∈S,0<m) (hn : ∀n∈T,0<n) :
    (∑i∈triples A S T,rightCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
      LogPhaseProgression.phase t (endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2))=
      ((Y*(Hm*Hn):ℝ):ℂ)*LogPhaseProgression.phase (-t) (Y*(Hm*Hn))*
        labelPolynomial A value (χ 0) η Y lam t*
          longPolynomial S (fun n=>conj (α n)) Hm (χ 4) t*
            longPolynomial T (fun n=>conj (β n)) Hn (χ 5) t := by
  unfold rightCoefficient
  rw [triplePolynomial_factor A value S T
    (fun a=>η ((value a:ℝ)/Y)*additivePhase (-lam*((value a:ℝ)/Y))*χ 0 (value a:ZMod k))
    (fun m=>conj (α m)*χ 4 (m:ZMod k)) (fun n=>conj (β n)*χ 5 (n:ZMod k))
    Y (Hm*Hn) t hY (mul_pos hHm hHn) ha hm hn]
  have hy : (Y:ℂ)≠0 := by exact_mod_cast hY.ne'
  have hm' : (Hm:ℂ)≠0 := by exact_mod_cast hHm.ne'
  have hn' : (Hn:ℂ)≠0 := by exact_mod_cast hHn.ne'
  simp only [labelPolynomial,longPolynomial,Complex.ofReal_mul]
  field_simp
  simp only [mul_comm,mul_left_comm,mul_assoc]

theorem archimedeanPhase_conj (t : ℝ) (n : ℕ) :
    conj (archimedeanPhase t n)=archimedeanPhase (-t) n := by
  unfold archimedeanPhase
  rw [←Complex.exp_conj]
  congr 1
  simp only [map_mul,Complex.conj_I,Complex.conj_ofReal,neg_mul,Complex.ofReal_neg]
  ring

/-- The right endpoint uses the original long coefficient at reflected
frequency and conjugated character. Its cancellation needs no new premise. -/
theorem longPolynomial_conjugate (S : Finset ℕ) (α : ℕ→ℂ) (H : ℝ)
    {k : ℕ} (χ : DirichletCharacter ℂ k) (t : ℝ) :
    longPolynomial S (fun n=>conj (α n)) H χ t=
      conj (longPolynomial S α H (star χ) (-t)) := by
  simp only [longPolynomial,map_mul,map_inv₀,Complex.conj_ofReal,map_sum,MulChar.star_apply,
    archimedeanPhase_conj,neg_neg]
  simp only [←starRingEnd_apply, Complex.conj_conj]

theorem longPolynomial_conjugate_norm (S : Finset ℕ) (α : ℕ→ℂ) (H : ℝ)
    {k : ℕ} (χ : DirichletCharacter ℂ k) (t : ℝ) :
    ‖longPolynomial S (fun n=>conj (α n)) H χ t‖=
      ‖longPolynomial S α H (star χ) (-t)‖ := by
  rw [longPolynomial_conjugate,Complex.norm_conj]


/-- Restricting to the cutoff support leaves the label polynomial unchanged. -/
theorem labelPolynomial_filter {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (χ : DirichletCharacter ℂ k) (η : ℝ→ℂ) (Y lam t : ℝ) :
    labelPolynomial (A.filter (fun a=>η ((value a:ℝ)/Y)≠0)) value χ η Y lam t=
      labelPolynomial A value χ η Y lam t := by
  unfold labelPolynomial
  congr 1
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro a ha
  by_cases hη : η ((value a:ℝ)/Y)=0
  · simp [hη]
  · rw [if_pos hη]

def normalizedLeft {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) : ℂ :=
  LogPhaseProgression.phase (-t) (Y*(Hm*Hn))*labelPolynomial A value (χ 1) η Y (-lam) t*
    longPolynomial S α Hm (χ 2) t*longPolynomial T β Hn (χ 3) t

def normalizedRight {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) : ℂ :=
  LogPhaseProgression.phase (-t) (Y*(Hm*Hn))*labelPolynomial A value (χ 0) η Y lam t*
    longPolynomial S (fun n=>conj (α n)) Hm (χ 4) t*
      longPolynomial T (fun n=>conj (β n)) Hn (χ 5) t

def sourceMellinKernel (X lam t s : ℝ) : ℂ :=
  MellinPlane.mellinKernel (MellinPlane.determinantSchwartz SignedSmoothDyads.determinantCutoff
    MellinPlateau.rho MellinPlateau.sigma SignedSmoothDyads.determinantCutoff_contDiff
    (MellinPlateau.plateau_smooth (-5) 5) (MellinPlateau.plateau_smooth 0 (Real.log 16))
    (MellinPlateau.plateau_compact (-5) 5) (MellinPlateau.plateau_compact 0 (Real.log 16)) X lam) (t/X) s

/-- Full normalization of the actual finite character pair. The two raw
endpoint factors YX and determinant Jacobian X⁻¹ leave exactly Y²X. -/
theorem characterPair_normalized_mellin {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (Y Hm Hn lam : ℝ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,1≤(value a:ℝ)/Y ∧ (value a:ℝ)/Y≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T) :
    characterPair A value S T χ Y lam η SignedSmoothDyads.determinantCutoff α β=
      ((Y^2*(Hm*Hn):ℝ):ℂ)*(∫t:ℝ,∫s:ℝ,sourceMellinKernel (Hm*Hn) lam t s*
        normalizedLeft A value S T χ η α β Y Hm Hn lam t*
        normalizedRight A value S T χ η α β Y Hm Hn lam (s-t)) := by
  have ha' (a) (haA : a∈A) : 0<value a := by
    have hh := (le_div_iff₀ hY).mp (ha a haA).1
    have hp : (0:ℝ)<value a := by linarith
    exact_mod_cast hp
  have hm' (m) (hmS : m∈S) : 0<m := by exact_mod_cast hHm.trans_le (hm m hmS).1
  have hn' (n) (hnT : n∈T) : 0<n := by exact_mod_cast hHn.trans_le (hn n hnT).1
  have hleft (t:ℝ) :
      (∑i∈triples A S T,leftCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
        LogPhaseProgression.phase t (endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2))=
      ((Y*(Hm*Hn):ℝ):ℂ)*normalizedLeft A value S T χ η α β Y Hm Hn lam t := by
    rw [leftPolynomial_normalized A value S T χ η α β Y Hm Hn lam t hY hHm hHn ha' hm' hn']
    unfold normalizedLeft
    ring
  have hright (t:ℝ) :
      (∑i∈triples A S T,rightCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
        LogPhaseProgression.phase t (endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2))=
      ((Y*(Hm*Hn):ℝ):ℂ)*normalizedRight A value S T χ η α β Y Hm Hn lam t := by
    rw [rightPolynomial_normalized A value S T χ η α β Y Hm Hn lam t hY hHm hHn ha' hm' hn']
    unfold normalizedRight
    ring
  rw [characterPair_mellin A value S T χ Y Hm Hn lam η α β hY hHm hHn ha hm hn]
  simp_rw [hleft,hright]
  have hmul (a b c z:ℂ) : a*(z*b)*(z*c)=z^2*(a*b*c) := by ring
  simp_rw [hmul,MeasureTheory.integral_const_mul]
  change ((Hm*Hn:ℝ):ℂ)⁻¹*(((Y*(Hm*Hn):ℝ):ℂ)^2*_) = _
  have hx : ((Hm*Hn:ℝ):ℂ)≠0 := by exact_mod_cast (mul_pos hHm hHn).ne'
  simp only [sourceMellinKernel,Complex.ofReal_mul,Complex.ofReal_pow] at ⊢
  have hmC : (Hm:ℂ)≠0 := by exact_mod_cast hHm.ne'
  have hnC : (Hn:ℂ)≠0 := by exact_mod_cast hHn.ne'
  field_simp

end Elliptic.Operator.SignedMajorMellinIdentity
