module

public import Elliptic.Operator.SourceFirstGoodMeasure
public import Elliptic.Operator.MomentParameters
public import Mathlib.Data.Fintype.Powerset
public import Mathlib.NumberTheory.Bertrand

/-!
# Literal counting parameters in the source good-state estimate

This identifies the promoted configurations with nonempty subsets and bounds
the actual numeric prime bands, dyadic omissions and positive test lengths.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.GoodStateCounting
open scoped BigOperators
open SourceFirstGoodMeasure
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- Each nonempty set has exactly one maximal distinguished group. -/
def configurationEquiv (K : ℕ) : Configuration K ≃ {I : Finset (Fin K) // I.Nonempty} where
  toFun (c : Configuration K) := ⟨c.1.1, ⟨c.1.2,c.2.1⟩⟩
  invFun (I : {I : Finset (Fin K) // I.Nonempty}) :=
    ⟨(I.1,I.1.max' I.2), Finset.max'_mem I.1 I.2, fun i hi => Finset.le_max' I.1 i hi⟩
  left_inv c := Subtype.ext (Prod.ext rfl
    (le_antisymm (c.2.2 _ (Finset.max'_mem c.1.1 ⟨c.1.2,c.2.1⟩))
      (Finset.le_max' c.1.1 c.1.2 c.2.1)))
  right_inv _I := rfl

theorem configuration_card (K : ℕ) : Fintype.card (Configuration K) = 2^K-1 := by
  rw [Fintype.card_congr (configurationEquiv K)]
  simp only [Finset.nonempty_iff_ne_empty, ne_eq, Fintype.card_subtype_compl]
  simp

theorem omissionProducts_card_le {K M : ℕ} (label : Fin K × Fin M → ℕ) (d₀ : ℝ) :
    (SourceSecondGoodState.omissionProducts label d₀).card ≤ M^K := by
  exact (Finset.card_filter_le _ _).trans (Finset.card_image_le.trans (by simp))

theorem omissionProducts_ne_zero {K M : ℕ} (label : Fin K × Fin M → ℕ)
    (hprime : ∀ ij, (label ij).Prime) (d₀ : ℝ)
    (D : ℕ) (hD : D ∈ SourceSecondGoodState.omissionProducts label d₀) : D ≠ 0 := by
  obtain ⟨o,_,rfl⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hD).1
  exact copiedProduct_ne_zero label hprime o

theorem testLengths_card_le (L : ℝ) (hL : 0 ≤ L) :
    ((testLengths L).card : ℝ) ≤ L := by
  have hf : 0 ≤ ⌊L⌋ := Int.floor_nonneg.mpr hL
  rw [testLengths, Int.card_Icc]
  have he : ⌊L⌋ + 1 - 1 = ⌊L⌋ := by omega
  rw [he]
  have hc : ((⌊L⌋.toNat : ℕ) : ℝ) = (⌊L⌋ : ℝ) := by exact_mod_cast Int.toNat_of_nonneg hf
  rw [hc]
  exact Int.floor_le L

theorem momentMultiplicity_le {L : ℝ} (hL : 1 ≤ L) :
    (momentMultiplicity L : ℝ) ≤ 2*L := by
  have hL0 : 0 ≤ L := by linarith
  have hp : L^(1/100 : ℝ) ≤ L := by
    simpa using Real.rpow_le_rpow_of_exponent_le hL (show (1/100 : ℝ) ≤ 1 by norm_num)
  have hf := Nat.floor_le (Real.rpow_nonneg hL0 (1/100 : ℝ))
  simp only [momentMultiplicity, momentPadding, Nat.cast_add, Nat.cast_one]
  linarith

/-- The literal band of all rational primes between the source endpoints. -/
def numericPrimeBand (L a : ℝ) : Finset ℕ :=
  (Finset.range (⌊Real.exp (2*L^a)⌋₊+1)).filter
    (fun p => p.Prime ∧ Real.exp (L^a) ≤ (p : ℝ))

theorem mem_numericPrimeBand (L a : ℝ) (p : ℕ) :
    p ∈ numericPrimeBand L a ↔ p.Prime ∧ Real.exp (L^a) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2*L^a) := by
  simp only [numericPrimeBand, Finset.mem_filter, Finset.mem_range]
  rw [Nat.lt_add_one_iff, Nat.le_floor_iff (Real.exp_pos _).le]
  tauto

theorem numericPrimeBand_card_le (L a : ℝ) :
    ((numericPrimeBand L a).card : ℝ) ≤ Real.exp (2*L^a) := by
  have hs : numericPrimeBand L a ⊆ Finset.Icc 1 ⌊Real.exp (2*L^a)⌋₊ := by
    intro p hp
    have hp' := (mem_numericPrimeBand L a p).mp hp
    simp only [Finset.mem_Icc]
    exact ⟨hp'.1.one_lt.le, (Nat.le_floor_iff (Real.exp_pos _).le).mpr hp'.2.2⟩
  have hc := Finset.card_le_card hs
  have hc' : (numericPrimeBand L a).card ≤ ⌊Real.exp (2*L^a)⌋₊ := by simpa using hc
  have hcR : ((numericPrimeBand L a).card : ℝ) ≤ (⌊Real.exp (2*L^a)⌋₊ : ℝ) := by exact_mod_cast hc'
  exact hcR.trans (Nat.floor_le (Real.exp_pos _).le)

/-- The prime band is nonempty once its lower endpoint is at least four;
Bertrand suffices, so no prime number theorem is assumed here. -/
theorem numericPrimeBand_nonempty (L a : ℝ) (hfour : 4 ≤ Real.exp (L^a)) :
    (numericPrimeBand L a).Nonempty := by
  let n : ℕ := ⌈Real.exp (L^a)⌉₊
  have hnR : Real.exp (L^a) ≤ (n : ℝ) := Nat.le_ceil _
  have hn : n ≠ 0 := by intro hn; simp [hn] at hnR; linarith
  obtain ⟨p,hp,hnp,hpn⟩ := Nat.exists_prime_lt_and_le_two_mul n hn
  refine ⟨p,(mem_numericPrimeBand L a p).mpr ⟨hp,?_,?_⟩⟩
  · exact hnR.trans (by exact_mod_cast hnp.le)
  · have hnup : (n : ℝ) < Real.exp (L^a)+1 := Nat.ceil_lt_add_one (Real.exp_pos _).le
    have hpup : (p : ℝ) ≤ 2*(n : ℝ) := by exact_mod_cast hpn
    have he : Real.exp (2*L^a) = (Real.exp (L^a))^2 := by
      rw [two_mul, Real.exp_add, pow_two]
    rw [he]
    nlinarith

end Elliptic.Operator.GoodStateCounting
