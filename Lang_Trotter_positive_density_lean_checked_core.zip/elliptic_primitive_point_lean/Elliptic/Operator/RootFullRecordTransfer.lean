module

public import Elliptic.Operator.RootPolynomialIdentity

/-!
# Full original-record root replacement, including Bonferroni tails

The two finite discrepancies in the signed comparison are discharged by
the proved root-count transfers. Every geometric predicate, finite line
factor, normalization and growing subset family is the literal source
object. The only analytic inputs are the accepted root-count contract
and the displayed reciprocal-prime mass bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootFullRecordTransfer
open scoped BigOperators
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootRecordBonferroni RootRecordGap RootIntegratedBonferroni RootRecordComparison
open RootMonomialTests RootMonomialCRT RootPolynomialIdentity RootRecordKernel
open RootRecordAccumulation RootConstantAccumulation RootDiscreteBudget
open OriginalPathWeights IntegerRootReplacement BonferroniBudget BonferroniMonomialCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

theorem record_labels_prime {K J N R Q : ℕ} (rec : Record K J N R Q) (P : Finset ℕ)
    (hA : activePrimes rec⊆P) (hP : ∀p∈P,p.Prime) :
    ∀j i a,((rec.2.1 j i a).val).Prime := by
  intro j i a
  exact hP _ (hA ((mem_activePrimes rec _).mpr ⟨j,i,a,rfl⟩))

/-- The positive gap discrepancy, with actual scalar normalization and
all actual record/subset moduli, follows from the accepted count. -/
theorem eventually_gap_transfer (hPD : RootCountContract)
    (K : ℕ) (C δ vmin : ℝ) (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) :
    ∀ᶠ x : ℝ in atTop, ∀ records : Finset (SourceRecord K C (Real.log x)),
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact p.val.Prime],
      (∀r∈records,activePrimes r⊆primes) →
      (∀p∈primes,(p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      ∀ k T : ℕ, k≤T → T≤⌈(Real.log x)^(76/100:ℝ)⌉₊ →
      ∀ η : ℕ→ℝ, (∀j<momentLength (Real.log x)+1,0≤η j ∧ η j≤1) →
      ∀ U V : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      |normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
        (∑r∈records,rootGap r primes η k U V FinitePrimeCRT.integerLines) -
      (15*(U*V/(Real.pi^2/6)))*
        (|normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))| *
          (∑r∈records,gap r primes η k)) ≤ U*V*x^(-(δ/64000)) := by
  filter_upwards [eventually_original_residue_transfer hPD K C δ vmin hC hδ hmin] with x ht
  intro records primes instPrime hA hbounds k T hk hT η hη U V hU hU' hV hV' VM hVM
  have hP : ∀p∈primes,p.Prime := fun p hp=>@Fact.out _ (instPrime ⟨p,hp⟩)
  have hr : ∀r∈records,∀j i a,(recordLabels r j i a).Prime := by
    intro r hr j i a
    exact record_labels_prime r primes (hA r hr) hP j i a
  letI (t : Pairs records primes T) : NeZero (modulus t.1.val t.2.val) := ⟨by
    have hp := (RootErrorBudget.prime_modulus_admissible (support t.1.val t.2.val)
      (primeProof records primes T hA hP t)).1
    change (∏p∈support t.1.val t.2.val,p)≠0
    omega⟩
  letI (t : Pairs records primes T) : Fintype (ZMod (modulus t.1.val t.2.val)) := inferInstance
  letI (t : Pairs records primes T) (p : support t.1.val t.2.val) : Fact p.val.Prime :=
    ⟨primeProof records primes T hA hP t p p.property⟩
  letI : ∀t : Term records primes T,Fintype (ZMod (recordModulus t.1.val t.2.val)) :=
    fun t=>(inferInstance : Fintype (ZMod (modulus t.1.val t.2.val)))
  let ρ (t : Pairs records primes T) := residueTest t.1.val t.2.val
    (primeProof records primes T hA hP t) (gapTest t.1.val η k t.2.val)
  have hh := ht records primes T hr (fun p hp=>⟨hP p hp,hbounds p hp⟩) hT
    U V hU hU' hV hV' VM hVM ρ
    (fun t g=>gapTest_norm_le t.1.val η hη k t.2.val _)
  change ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
    ((∑t : Pairs records primes T,weightedRootSum U V (modulus t.1.val t.2.val)
      (RootGridPartition.fullInterval 1 16) (RootGridPartition.fullInterval 1 2)
      (RootGridPartition.fullInterval 0 1) (ρ t))-
     ∑t : Pairs records primes T,(rootVolume U V (RootGridPartition.fullInterval 1 16)
      (RootGridPartition.fullInterval 1 2) (RootGridPartition.fullInterval 0 1):ℂ)*
      ((∑g,ρ t g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2)
        (ZMod (modulus t.1.val t.2.val))):ℂ)))‖≤_ at hh
  dsimp only [ρ] at hh
  rw [rootGap_eq records primes k T hk hA hP η U V,
    integralGap_eq records primes k T hk hA hP η U V] at hh
  rw [←Complex.ofReal_sub,←Complex.ofReal_mul,Complex.norm_real,Real.norm_eq_abs] at hh
  have hn := (normalization_le VM vmin hmin hVM (momentPadding (Real.log x)) (momentLength (Real.log x))).1
  rw [abs_of_nonneg hn]
  calc
    _ = normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x))*
      ((∑r∈records,rootGap r primes η k U V FinitePrimeCRT.integerLines)-
        (15*(U*V/(Real.pi^2/6)))*(∑r∈records,gap r primes η k)) := by ring
    _ ≤ abs _ := le_abs_self _
    _ ≤ _ := hh

/-- The signed polynomial discrepancy uses the actual source geometry,
not a supplied bounded or stable surrogate. -/
theorem eventually_polynomial_transfer (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ vmin : ℝ) (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ records : Finset (SourceRecord K C (Real.log x)),
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact p.val.Prime],
      (∀r∈records,activePrimes r⊆primes) →
      (∀p∈primes,(p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      ∀ T : ℕ, T≤⌈(Real.log x)^(76/100:ℝ)⌉₊ →
      ∀ damping : ℕ→ℝ, (∀j<momentLength (Real.log x)+1,0≤damping j ∧ damping j≤1) →
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤U*V → 0<d₀ → 1≤Y → ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀t,‖smooth t‖≤1) → (∀t,‖ψ t‖≤1) → (∀t,smooth t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin (momentLength (Real.log x))→Bool,
      let G := fun rec=>recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ
      ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
        ((∑r∈records,rootPolynomial r primes damping T U V (G r) FinitePrimeCRT.integerLines)-
          ∑r∈records,integralPolynomial r primes damping T U V (G r))‖ ≤ U*V*x^(-(δ/64000)) := by
  filter_upwards [eventually_original_records_transfer hPD K hK C δ vmin hC hδ hmin] with x ht
  intro P instP records primes instPrime hA hbounds T hT damping hdamping U V d₀ Y hU hU' hV hV'
    hUV hd hY VM hVM value μ hv exponents smooth ψ hsmooth hψ hsupport major hmajor σ adjoint
  dsimp only
  have hP : ∀p∈primes,p.Prime := fun p hp=>@Fact.out _ (instPrime ⟨p,hp⟩)
  have hr : ∀r∈records,∀j i a,(recordLabels r j i a).Prime := by
    intro r hr j i a
    exact record_labels_prime r primes (hA r hr) hP j i a
  letI (t : Pairs records primes T) : NeZero (modulus t.1.val t.2.val) := ⟨by
    have hp := (RootErrorBudget.prime_modulus_admissible (support t.1.val t.2.val)
      (primeProof records primes T hA hP t)).1
    change (∏p∈support t.1.val t.2.val,p)≠0
    omega⟩
  letI (t : Pairs records primes T) : Fintype (ZMod (modulus t.1.val t.2.val)) := inferInstance
  letI (t : Pairs records primes T) (p : support t.1.val t.2.val) : Fact p.val.Prime :=
    ⟨primeProof records primes T hA hP t p p.property⟩
  letI : ∀t : Term records primes T,Fintype (ZMod (recordModulus t.1.val t.2.val)) :=
    fun t=>(inferInstance : Fintype (ZMod (modulus t.1.val t.2.val)))
  let ρ (t : Pairs records primes T) := residueTest t.1.val t.2.val
    (primeProof records primes T hA hP t) (subsetTest t.1.val damping t.2.val)
  have hh := ht P records primes T hr (fun p hp=>⟨hP p hp,hbounds p hp⟩) hT
    U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM value μ hv exponents smooth ψ
    hsmooth hψ hsupport major hmajor σ adjoint ρ
    (fun t g=>subsetTest_norm_le t.1.val damping hdamping t.2.val _)
  change ‖(normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
    ((∑t : Pairs records primes T,RootVariableSum.variableRootSum U V (modulus t.1.val t.2.val)
      (RootGridPartition.fullInterval 1 16) (RootGridPartition.fullInterval 1 2)
      (RootGridPartition.fullInterval 0 1) (fun q g=>recordGeometry t.1.val adjoint value μ U V d₀ Y
        (Real.log x) exponents smooth ψ major σ q*ρ t g))-
     ∑t : Pairs records primes T,RootArchimedeanTransfer.rootIntegral U V (modulus t.1.val t.2.val)
      (fun q g=>recordGeometry t.1.val adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ q*ρ t g))‖≤_ at hh
  dsimp only [ρ] at hh
  rw [rootPolynomial_eq records primes T hA hP damping U V
      (fun rec=>recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ),
    integralPolynomial_eq records primes T hA hP damping U V
      (fun rec=>recordGeometry rec adjoint value μ U V d₀ Y (Real.log x) exponents smooth ψ major σ)] at hh
  exact hh

end Elliptic.Operator.RootFullRecordTransfer
