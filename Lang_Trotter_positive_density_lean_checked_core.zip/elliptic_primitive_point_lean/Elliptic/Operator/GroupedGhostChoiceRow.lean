module

public import Elliptic.Operator.GroupedGhostNorm

/-!
# Absolute literal ghost choices, including doubled births

These bounds are on the uncollected indexed choices used in the positive
truncation word.  They therefore remain valid before any cancellation
between choices having the same output.  Doubling each ghost birth is
exactly the replacement `V i` by `2*V i` in the literal coefficients.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance groupedGhostChoiceRowDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

def ghostAbsoluteChoiceTerm {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) : ℝ :=
  if hc : GhostChoice.Valid anchor m c then
    ‖(ghostChoiceWeight ν V η q ρ anchor m c : ℂ)‖ * v^(ghostOutput anchor m c hc).size else 0

theorem ghostAbsoluteChoiceTerm_nonneg {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (V η q ρ v : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) (hv : 0 ≤ v) :
    0 ≤ ghostAbsoluteChoiceTerm ν V η q ρ v anchor m c := by
  unfold ghostAbsoluteChoiceTerm
  split_ifs
  · exact mul_nonneg (norm_nonneg _) (pow_nonneg hv _)
  · exact le_rfl

theorem ghost_literal_choice_row_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    (∑ c : GhostChoice m,
      ghostAbsoluteChoiceTerm ν V η q ρ (ghostSchurWeight ρ Q Vmax) anchor m c) ≤
      Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ) *
        (ghostSchurWeight ρ Q Vmax)^m.size := by
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hrow := (ghostAbsoluteChoiceRow_le_indexed ν V η q ρ
    (ghostSchurWeight ρ Q Vmax) anchor m hν hV0 hη0 hq0 hρ.le hv.le).trans
      (ghost_forward_adjoint_uniform m.size (memoryHits anchor m) ν q η ρ V Q Vmax s B
        hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax).1
  apply (div_le_iff₀ (pow_pos hv m.size)).mp
  convert hrow using 1
  unfold ghostAbsoluteChoiceRow ghostAbsoluteChoiceTerm
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro c _
  split_ifs <;> simp only [Complex.norm_real, Real.norm_eq_abs, mul_div_assoc, zero_div]

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- The literal grouped choice sum, with the actual total cutoff. -/
theorem physicalGhost_literal_choice_row_uniform [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    (∑ c : PhysicalGhostChoice m, if hc : c.Valid anchor m then
      ‖physicalGhostChoiceWeight ν V η q ρ anchor m c‖ *
        (ghostSchurWeight ρ Q Vmax)^physicalMemorySize (c.output anchor m hc) else 0) ≤
      (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I) *
        (ghostSchurWeight ρ Q Vmax)^physicalMemorySize m := by
  let v := ghostSchurWeight ρ Q Vmax
  let C := Real.exp (v * max 1 Vmax*s/ρ)
  have hv : 0 ≤ v := (ghostSchurWeight_pos ρ Q Vmax hρ hQ).le
  let T := fun i => ghostAbsoluteChoiceTerm (ν i) (V i) η q ρ v
    (anchor (m.position P Line J B) i) (m.memory P Line J B i)
  have hT i c : 0 ≤ T i c := ghostAbsoluteChoiceTerm_nonneg _ _ _ _ _ _ _ _ _ hv
  have hpoint (c : PhysicalGhostChoice m) :
      (if hc : c.Valid anchor m then ‖physicalGhostChoiceWeight ν V η q ρ anchor m c‖ *
        v^physicalMemorySize (c.output anchor m hc) else 0) ≤ ∏ i, T i (c i) := by
    by_cases hc : c.Valid anchor m
    · rw [dite_eq_left hc]
      have ht : (∏ i, T i (c i)) =
          ∏ i, ‖(ghostChoiceWeight (ν i) (V i) η q ρ (anchor (m.position P Line J B) i)
            (m.memory P Line J B i) (c i) : ℂ)‖ *
            v^(ghostOutput _ _ _ (hc.1 i)).size := by
        apply Finset.prod_congr rfl
        intro i _
        exact dite_eq_left (hc.1 i)
      rw [ht, Finset.prod_mul_distrib, Finset.prod_pow_eq_pow_sum]
      unfold physicalGhostChoiceWeight physicalMemorySize
      rw [norm_prod]
      rfl
    · rw [dite_eq_right hc]
      exact Finset.prod_nonneg fun i _ => hT i (c i)
  change (∑ c : PhysicalGhostChoice m, if hc : c.Valid anchor m then
    ‖physicalGhostChoiceWeight ν V η q ρ anchor m c‖ *
      v^physicalMemorySize (c.output anchor m hc) else 0) ≤ C^(Fintype.card I)*v^physicalMemorySize m
  calc
    _ ≤ ∑ c : PhysicalGhostChoice m, ∏ i, T i (c i) := Finset.sum_le_sum fun c _ => hpoint c
    _ = ∏ i, ∑ c : GhostChoice (m.memory P Line J B i), T i c := (Fintype.prod_sum T).symm
    _ ≤ ∏ i, C*v^(m.memory P Line J B i).size := Finset.prod_le_prod₀
      (fun i _ => Finset.sum_nonneg fun c _ => hT i c)
      (fun i _ => ghost_literal_choice_row_uniform (ν i) (V i) η q ρ Q Vmax s
        (anchor (m.position P Line J B) i) (m.memory P Line J B i)
        (hν i) (hs i) hs0 hρ hQ hq0 hqQ hη0 hη1 (hV0 i) (hVmax i))
    _ = _ := by
      rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ,
        Finset.prod_pow_eq_pow_sum]
      rfl

theorem ghostChoiceWeight_double_births {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) :
    ghostChoiceWeight ν (2*V) η q ρ anchor m c =
      2^c.2.size * ghostChoiceWeight ν V η q ρ anchor m c := by
  unfold ghostChoiceWeight
  have he : -η*(2*V)/ρ = 2*(-η*V/ρ) := by ring
  rw [he, mul_pow]
  ring

theorem physicalGhostChoiceWeight_double_births [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (m : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice m) :
    ‖physicalGhostChoiceWeight ν (fun i => 2*V i) η q ρ anchor m c‖ =
      (2:ℝ)^(∑ i, (c i).2.size)*‖physicalGhostChoiceWeight ν V η q ρ anchor m c‖ := by
  unfold physicalGhostChoiceWeight
  simp_rw [ghostChoiceWeight_double_births, Complex.ofReal_mul, norm_prod, norm_mul,
    Complex.norm_real, Real.norm_eq_abs, abs_pow, abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)]
  rw [Finset.prod_mul_distrib, Finset.prod_pow_eq_pow_sum]

/-- Doubling every actual ghost birth changes only the fixed row
constant, never the cutoff dependence. This is the uncollected positive
choice bound needed by the truncation majorant. -/
theorem physicalGhost_doubled_birth_choice_row_uniform [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (m : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    (∑ c : PhysicalGhostChoice m, if hc : c.Valid anchor m then
      (2:ℝ)^(∑ i, (c i).2.size)*‖physicalGhostChoiceWeight ν V η q ρ anchor m c‖ *
        (ghostSchurWeight ρ Q (2*Vmax))^physicalMemorySize (c.output anchor m hc) else 0) ≤
      (Real.exp (ghostSchurWeight ρ Q (2*Vmax) * max 1 (2*Vmax)*s/ρ))^(Fintype.card I) *
        (ghostSchurWeight ρ Q (2*Vmax))^physicalMemorySize m := by
  have h := physicalGhost_literal_choice_row_uniform ν (fun i => 2*V i) η q ρ Q (2*Vmax) s
    anchor m hν hs hs0 hρ hQ hq0 hqQ hη0 hη1
    (fun i => by linarith [hV0 i]) (fun i => by linarith [hVmax i])
  simpa only [physicalGhostChoiceWeight_double_births] using h

end Elliptic.Operator
