module

public import Elliptic.Operator.RootSecondFace
public import Elliptic.Operator.RootGoodBoundary
public import Mathlib.Topology.Order.IntermediateValue

/-!
# Physical and circle predicates throughout one root cell

Avoiding the counted first and second physical faces makes the physical
box indicator constant on the entire connected closed root cell. One
admissible point then gives the pole exclusion and phase bound throughout
its r-interval, discharging the whole-cell premises in RootGoodBoundary.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootPhysicalCell
open RootArchimedeanGrid RootFirstFace RootSecondFace SourceRootCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

abbrev RootPoint := ℝ × ℝ × ℝ

def cellSet (n : ℕ) (j : Index) : Set RootPoint :=
  Set.Icc (cell 1 16 n j.1).lower (cell 1 16 n j.1).upper ×ˢ
    (Set.Icc (cell 1 2 n j.2.1).lower (cell 1 2 n j.2.1).upper ×ˢ
      Set.Icc (cell 0 1 n j.2.2).lower (cell 0 1 n j.2.2).upper)

theorem mem_cellSet (n : ℕ) (j : Index) (q : RootPoint) :
    q∈cellSet n j ↔ Contains n j q := by rfl

theorem cellSet_preconnected (n : ℕ) (j : Index) : IsPreconnected (cellSet n j) :=
  isPreconnected_Icc.prod (isPreconnected_Icc.prod isPreconnected_Icc)

theorem lower_cut_constant {X : Type*} [TopologicalSpace X] (s : Set X)
    (hs : IsPreconnected s) (f : X→ℝ) (hf : ContinuousOn f s) (c : ℝ)
    (hno : ∀ t∈s, f t≠c) (p q : X) (hp : p∈s) (hq : q∈s) :
    c≤f p ↔ c≤f q := by
  have hmove (p q : X) (hp : p∈s) (hq : q∈s) (h : c≤f p) : c≤f q := by
    by_contra hn
    obtain ⟨t,ht,he⟩ := hs.intermediate_value hq hp hf ⟨(lt_of_not_ge hn).le,h⟩
    exact hno t ht he
  exact ⟨hmove p q hp hq,hmove q p hq hp⟩

theorem upper_cut_constant {X : Type*} [TopologicalSpace X] (s : Set X)
    (hs : IsPreconnected s) (f : X→ℝ) (hf : ContinuousOn f s) (c : ℝ)
    (hno : ∀ t∈s, f t≠c) (p q : X) (hp : p∈s) (hq : q∈s) :
    f p≤c ↔ f q≤c := by
  simpa only [neg_le_neg_iff] using lower_cut_constant s hs (fun t => -f t) hf.neg (-c)
    (fun t ht h => hno t ht (neg_injective h)) p q hp hq

theorem first_box_constant (n : ℕ) (j : Index) (hj : j∈grid n) (z : ℤ × ℤ)
    (hface1 : j∉RootFirstFace.faceCubes n z 1)
    (hface16 : j∉RootFirstFace.faceCubes n z 16)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    FirstBox z p.1 p.2.2 ↔ FirstBox z q.1 q.2.2 := by
  let f : RootPoint→ℝ := fun t => t.1*latticeTau t.2.2 z
  have hf : Continuous f := by dsimp [f,latticeTau]; fun_prop
  have hno (c : ℝ) (hc : j∉RootFirstFace.faceCubes n z c) :
      ∀ t∈cellSet n j, f t≠c := by
    intro t ht he
    exact hc (RootFirstFace.face_cube_mem n z c j hj t ht he)
  exact and_congr
    (lower_cut_constant (cellSet n j) (cellSet_preconnected n j) f hf.continuousOn 1
      (hno 1 hface1) p q hp hq)
    (upper_cut_constant (cellSet n j) (cellSet_preconnected n j) f hf.continuousOn 16
      (hno 16 hface16) p q hp hq)

theorem whole_cell_tau (n : ℕ) (j : Index) (hj : j∈grid n) (z : ℤ × ℤ)
    (hface1 : j∉RootFirstFace.faceCubes n z 1)
    (hface16 : j∉RootFirstFace.faceCubes n z 16)
    (q : RootPoint) (hq : Contains n j q) (hbox : FirstBox z q.1 q.2.2) :
    ∀ r, (cell 0 1 n j.2.2).Contains r → 1/16≤latticeTau r z := by
  intro r hr
  have ha := cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) q.1 hq.1
  have hbox' := (first_box_constant n j hj z hface1 hface16 q (q.1,q.2.1,r)
    hq ⟨hq.1,hq.2.1,hr⟩).mp hbox
  exact tau_lower z q.1 r ha.1 ha.2 hbox'

/-- The former whole-cell pole/phase assumptions now follow from one
physical point and the explicit first-face exclusion. -/
theorem whole_cell_phase (n : ℕ) (j : Index) (hj : j∈grid n) (z w : ℤ × ℤ)
    (hface1 : j∉RootFirstFace.faceCubes n z 1)
    (hface16 : j∉RootFirstFace.faceCubes n z 16)
    (q : RootPoint) (hq : Contains n j q) (hbox : FirstBox z q.1 q.2.2) :
    ∀ r, (cell 0 1 n j.2.2).Contains r →
      latticeTau r z≠0 ∧ |RootGoodBoundary.phase z w r|≤16*(|(w.1:ℝ)|+|(w.2:ℝ)|) := by
  intro r hr
  have ht := whole_cell_tau n j hj z hface1 hface16 q hq hbox r hr
  have hrange := cell_point_bounds 0 1 n j.2.2
    (Finset.mem_range.mp (Finset.mem_product.mp (Finset.mem_product.mp hj).2).2)
    (by norm_num) r hr
  exact ⟨by linarith,RootGoodBoundary.phase_bound z w r hrange.1 hrange.2 ht⟩

def NormalizedBox (d : ℝ) (z : ℤ × ℤ) (q : RootPoint) : Prop :=
  FirstBox z q.1 q.2.2 ∧ 1≤coordinate d z q.1 q.2.1 q.2.2 ∧
    coordinate d z q.1 q.2.1 q.2.2≤2

theorem second_coordinate_continuousOn (n : ℕ) (j : Index) (hj : j∈grid n)
    (z : ℤ × ℤ) (d : ℝ) :
    ContinuousOn (fun q : RootPoint => coordinate d z q.1 q.2.1 q.2.2) (cellSet n j) := by
  have hpoly : Continuous (fun q : RootPoint => q.2.1*latticeTau q.2.2 z) := by
    unfold latticeTau
    fun_prop
  apply hpoly.continuousOn.add
    (continuousOn_const.div continuous_fst.continuousOn ?_)
  intro q hq
  have ha := cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) q.1 hq.1
  linarith

theorem normalized_box_constant (n : ℕ) (j : Index) (hj : j∈grid n)
    (z : ℤ × ℤ) (d : ℝ)
    (hface1 : j∉RootFirstFace.faceCubes n z 1)
    (hface16 : j∉RootFirstFace.faceCubes n z 16)
    (hsecond1 : j∉RootSecondFace.faceCubes n z d 1)
    (hsecond2 : j∉RootSecondFace.faceCubes n z d 2)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    NormalizedBox d z p ↔ NormalizedBox d z q := by
  have hfirst := first_box_constant n j hj z hface1 hface16 p q hp hq
  by_cases hbox : FirstBox z p.1 p.2.2
  · have hall : ∀ t∈cellSet n j, FirstBox z t.1 t.2.2 := by
      intro t ht
      exact (first_box_constant n j hj z hface1 hface16 p t hp ht).mp hbox
    let f : RootPoint→ℝ := fun t => coordinate d z t.1 t.2.1 t.2.2
    have hcont := second_coordinate_continuousOn n j hj z d
    have hno (c : ℝ) (hc : j∉RootSecondFace.faceCubes n z d c) :
        ∀ t∈cellSet n j, f t≠c := by
      intro t ht he
      exact hc (RootSecondFace.face_cube_mem n z d c j hj t ht (hall t ht) he)
    exact and_congr hfirst (and_congr
      (lower_cut_constant (cellSet n j) (cellSet_preconnected n j) f hcont 1
        (hno 1 hsecond1) p q hp hq)
      (upper_cut_constant (cellSet n j) (cellSet_preconnected n j) f hcont 2
        (hno 2 hsecond2) p q hp hq))
  · have hbox' : ¬FirstBox z q.1 q.2.2 := fun h => hbox (hfirst.mpr h)
    simp [NormalizedBox,hbox,hbox']

theorem source_allowed_iff_normalized (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (q : RootPoint) (ha : q.1≠0) (z : ℤ × ℤ) :
    sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z ↔
      IsCoprime z.1 z.2 ∧ NormalizedBox ((z.2:ℝ)/(U*V)) z q := by
  have hfirst : (rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).1/U =
      q.1*latticeTau q.2.2 z := by dsimp [rootPhysicalPosition]; field_simp
  have hsecond := physical_second_coordinate U V q.1 q.2.1 q.2.2 hU.ne' hV.ne' ha z
  have hf1 : U≤(rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).1 ↔
      1≤q.1*latticeTau q.2.2 z := by rw [←hfirst,le_div_iff₀ hU,one_mul]
  have hf16 : (rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).1≤16*U ↔
      q.1*latticeTau q.2.2 z≤16 := by rw [←hfirst,div_le_iff₀ hU]
  have hs1 : V≤(rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).2 ↔
      1≤coordinate ((z.2:ℝ)/(U*V)) z q.1 q.2.1 q.2.2 := by
    rw [←hsecond,le_div_iff₀ hV,one_mul]
  have hs2 : (rootPhysicalPosition (U*q.1) (V*q.2.1) q.2.2 z).2≤2*V ↔
      coordinate ((z.2:ℝ)/(U*V)) z q.1 q.2.1 q.2.2≤2 := by
    rw [←hsecond,div_le_iff₀ hV]
  simp only [sourcePhysicalPositionAllowed,NormalizedBox,FirstBox,hf1,hf16,hs1,hs2,and_assoc]

/-- Constancy of the literal source physical-box predicate, including
primitivity, after excluding precisely the four counted faces. -/
theorem source_allowed_constant (n : ℕ) (j : Index) (hj : j∈grid n)
    (z : ℤ × ℤ) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hface1 : j∉RootFirstFace.faceCubes n z 1)
    (hface16 : j∉RootFirstFace.faceCubes n z 16)
    (hsecond1 : j∉RootSecondFace.faceCubes n z ((z.2:ℝ)/(U*V)) 1)
    (hsecond2 : j∉RootSecondFace.faceCubes n z ((z.2:ℝ)/(U*V)) 2)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z ↔
      sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z := by
  have hpi := cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) p.1 hp.1
  have hqi := cell_point_bounds 1 16 n j.1
    (Finset.mem_range.mp (Finset.mem_product.mp hj).1) (by norm_num) q.1 hq.1
  rw [source_allowed_iff_normalized U V hU hV p (by linarith) z,
    source_allowed_iff_normalized U V hU hV q (by linarith) z]
  exact and_congr Iff.rfl
    (normalized_box_constant n j hj z _ hface1 hface16 hsecond1 hsecond2 p q hp hq)

end Elliptic.Operator.RootPhysicalCell
