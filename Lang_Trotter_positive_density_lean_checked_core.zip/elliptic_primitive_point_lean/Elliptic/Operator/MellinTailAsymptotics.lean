module
public import Elliptic.Operator.MellinPlaneUniform
public import Elliptic.Operator.MellinBilinearTail
public import Elliptic.Operator.MajorArcSparseAsymptotics

/-! Explicit logarithmic absorption for the uniform two-dimensional Mellin tail. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinTailAsymptotics
open Filter
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

/-- A one-power margin absorbs every fixed Fourier constant after the cutoffs are fixed. -/
theorem eventually_tail_numerical (A₀ C₄ E B₁ Cj:ℝ) (j:ℕ)
    (hA₀:0≤A₀) (hB₁:0≤B₁) (hCj:0≤Cj)
    (hgap:C₄+2*A₀*(j:ℝ)-B₁*(j:ℝ)+B₁≤ -E-1) :
    ∀ᶠL:ℝ in atTop,
      96*L^C₄*Cj*(1+2*L^A₀)^(2*j)*L^(-B₁*(j:ℝ))*(1+L^B₁)≤L^(-E) := by
  let D := 192*Cj*(3:ℝ)^(2*j)
  have hD : 0≤D := by dsimp [D]; positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop D] with L hL hDL
  have hLp : 0<L := by linarith
  have hA : 1≤L^A₀ := Real.one_le_rpow hL hA₀
  have hB : 1≤L^B₁ := Real.one_le_rpow hL hB₁
  have hlam : 1+2*L^A₀≤3*L^A₀ := by linarith
  have hs : 1+L^B₁≤2*L^B₁ := by linarith
  have he : 96*L^C₄*Cj*(3*L^A₀)^(2*j)*L^(-B₁*(j:ℝ))*(2*L^B₁)=
      D*L^(C₄+2*A₀*(j:ℝ)-B₁*(j:ℝ)+B₁) := by
    rw [mul_pow,←Real.rpow_mul_natCast hLp.le]
    calc
      _ = D*(L^C₄*L^(A₀*(2*j:ℕ))*L^(-B₁*(j:ℝ))*L^B₁) := by dsimp [D]; ring
      _ = _ := by
        rw [←Real.rpow_add hLp,←Real.rpow_add hLp,←Real.rpow_add hLp]
        congr 2
        push_cast
        ring
  calc
    _ ≤ 96*L^C₄*Cj*(3*L^A₀)^(2*j)*L^(-B₁*(j:ℝ))*(2*L^B₁) := by gcongr
    _ = D*L^(C₄+2*A₀*(j:ℝ)-B₁*(j:ℝ)+B₁) := he
    _ ≤ D*L^(-E-1) := mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hL hgap) hD
    _ ≤ L*L^(-E-1) := mul_le_mul_of_nonneg_right hDL (Real.rpow_nonneg hLp.le _)
    _ = L^(-E) := by
      conv_lhs => lhs; rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 1
      ring

/-- The frequency exponent and integration-by-parts order precede all fixed constants. -/
theorem exists_tail_parameters (A₀ C₄ E Bmin:ℝ)
    (hA₀:0≤A₀) (hC₄:0≤C₄) (hE:0≤E) :
    ∃B₁:ℝ,Bmin≤B₁ ∧ 2*A₀+1<B₁ ∧ ∃j:ℕ,2≤j ∧
      ∀Cj:ℝ,0≤Cj→∀ᶠL:ℝ in atTop,
        96*L^C₄*Cj*(1+2*L^A₀)^(2*j)*L^(-B₁*(j:ℝ))*(1+L^B₁)≤L^(-E) := by
  let B₁ := max Bmin (2*A₀+2)
  have hB : 2*A₀+2≤B₁ := le_max_right _ _
  have hB0 : 0≤B₁ := by linarith
  let j := ⌈C₄+B₁+E+2⌉₊+2
  have hj : 2≤j := by dsimp [j]; omega
  have hjR : C₄+B₁+E+2≤(j:ℝ) := by
    have hh := Nat.le_ceil (C₄+B₁+E+2)
    dsimp [j]
    push_cast
    linarith
  have hgap : C₄+2*A₀*(j:ℝ)-B₁*(j:ℝ)+B₁≤ -E-1 := by
    have hm := mul_le_mul_of_nonneg_right hB (Nat.cast_nonneg (α:=ℝ) j)
    nlinarith
  refine ⟨B₁,le_max_left _ _,by linarith,j,hj,?_⟩
  intro Cj hCj
  exact eventually_tail_numerical A₀ C₄ E B₁ Cj j hA₀ hB0 hCj hgap

end Elliptic.Operator.MellinTailAsymptotics
