module

public import Elliptic.Operator.DirtyGeometry
public import Elliptic.Operator.WeightedSchur

/-!
# Concrete dirty raw target rows

The finite row below sums actual omission tuples, numeric promoted
products, and integral target coordinates. Its determinant and congruence
conditions are imposed before counting. Good-state phase separation then
forces one omission/product pair, and the actual tube gives at most 33
target positions. Thus source averaging yields `33 B/M^K` before the
remaining bounded store/promotion coefficients and pending damping.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

variable {K M : ℕ}

def rawChoiceDeterminant (label : Fin K × Fin M → ℕ) (p T : ℕ) (σ : ℤ)
    (oz : (Fin K → Fin M) × ℕ) : ℤ :=
  σ*((fullSourceProduct label : ℤ)-(copiedProduct label oz.1 : ℤ)*p*oz.2*T)

def rawChoiceCoordinates (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β : ℝ) : Finset (((Fin K → Fin M) × ℕ) × ℤ) :=
  (Finset.univ.product newProducts).biUnion fun oz =>
    ((targetIntegers β (rawChoiceDeterminant label p T σ oz)).filter
      (fun h => (p : ℤ) ∣ h-h₀)).image (fun h => (oz,h))

theorem mem_rawChoiceCoordinates (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β : ℝ) (c : ((Fin K → Fin M) × ℕ) × ℤ) :
    c ∈ rawChoiceCoordinates label newProducts p T σ h₀ β ↔
      c.1.2 ∈ newProducts ∧
      |(c.2 : ℝ)+(rawChoiceDeterminant label p T σ c.1 : ℝ)*β| ≤ 16 ∧
      (p : ℤ) ∣ c.2-h₀ := by
  rcases c with ⟨⟨o,Z⟩,h⟩
  simp [rawChoiceCoordinates, mem_targetIntegers]

theorem rawChoiceCoordinates_phase_window
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β : ℝ) (hp : 0 < p) (hσ : σ=1 ∨ σ= -1)
    {c : ((Fin K → Fin M) × ℕ) × ℤ}
    (hc : c ∈ rawChoiceCoordinates label newProducts p T σ h₀ β) :
    dist ((((copiedProduct label c.1.1 * c.1.2 : ℕ) : ℝ)*((T : ℝ)*β) : ℝ) : AddCircle (1 : ℝ))
      ((((fullSourceProduct label : ℝ)*β+(σ*h₀ : ℤ))/(p : ℝ) : ℝ) : AddCircle (1 : ℝ)) ≤
        16/(p : ℝ) := by
  have hm := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β c).mp hc
  have hw := raw_target_phase_window (p : ℤ) (fullSourceProduct label)
    (copiedProduct label c.1.1) c.1.2 T σ
    (rawChoiceDeterminant label p T σ c.1) c.2 h₀ β
    (by exact_mod_cast hp) hσ rfl hm.2.2 hm.2.1
  simpa only [Int.cast_mul, Int.cast_natCast, Nat.cast_mul, mul_assoc] using hw

theorem rawChoiceCoordinates_pair_unique
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β δ : ℝ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : 0 < p) (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : 2*(16/(p : ℝ)) < δ)
    {a b : ((Fin K → Fin M) × ℕ) × ℤ}
    (ha : a ∈ rawChoiceCoordinates label newProducts p T σ h₀ β)
    (hb : b ∈ rawChoiceCoordinates label newProducts p T σ h₀ β) : a.1=b.1 := by
  have ha' := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β a).mp ha
  have hb' := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β b).mp hb
  have he := phase_separated_circle_unique hsep hwidth
    (Finset.mem_image.mpr ⟨a.1, by simpa using ha'.1, rfl⟩)
    (Finset.mem_image.mpr ⟨b.1, by simpa using hb'.1, rfl⟩) _
    (rawChoiceCoordinates_phase_window label newProducts p T σ h₀ β hp hσ ha)
    (rawChoiceCoordinates_phase_window label newProducts p T σ h₀ β hp hσ hb)
  have hf := old_new_factorization_unique
    (copiedProduct_dvd_fullSourceProduct label a.1.1)
    (copiedProduct_dvd_fullSourceProduct label b.1.1)
    (copiedProduct_ne_zero label hprime a.1.1)
    (hban a.1.2 ha'.1) (hban b.1.2 hb'.1) he
  exact Prod.ext (copiedProduct_injective label hprime hinj hf.1) hf.2

theorem rawChoiceCoordinates_card_le
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β δ : ℝ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : 0 < p) (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : 2*(16/(p : ℝ)) < δ) :
    (rawChoiceCoordinates label newProducts p T σ h₀ β).card ≤ 33 := by
  let s := rawChoiceCoordinates label newProducts p T σ h₀ β
  by_cases hempty : s=∅
  · simp only [← show s = rawChoiceCoordinates label newProducts p T σ h₀ β from rfl, hempty,
      Finset.card_empty, Nat.zero_le]
  obtain ⟨a,ha⟩ := Finset.nonempty_iff_ne_empty.mpr hempty
  have hsub : s ⊆ ({a.1} : Finset ((Fin K → Fin M) × ℕ)).product
      (targetIntegers β (rawChoiceDeterminant label p T σ a.1)) := by
    intro b hb
    have he := rawChoiceCoordinates_pair_unique label newProducts p T σ h₀ β δ
      hprime hinj hban hp hσ hsep hwidth hb ha
    have hm := (mem_rawChoiceCoordinates label newProducts p T σ h₀ β b).mp hb
    apply Finset.mem_product.mpr
    refine ⟨Finset.mem_singleton.mpr he, ?_⟩
    rw [mem_targetIntegers]
    simpa only [he] using hm.2.1
  have hc := Finset.card_le_card hsub
  have hcard := Finset.card_product ({a.1} : Finset ((Fin K → Fin M) × ℕ))
    (targetIntegers β (rawChoiceDeterminant label p T σ a.1))
  change (({a.1} : Finset ((Fin K → Fin M) × ℕ)).product
    (targetIntegers β (rawChoiceDeterminant label p T σ a.1))).card = _ at hcard
  rw [hcard, Finset.card_singleton, one_mul] at hc
  exact hc.trans (targetIntegers_card_le _ _)

theorem rawChoiceCoordinates_averaged_mass_le
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ h₀ : ℤ) (β δ : ℝ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : 0 < p) (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : 2*(16/(p : ℝ)) < δ) :
    (∑ _c ∈ rawChoiceCoordinates label newProducts p T σ h₀ β, 1/(M : ℝ)^K) ≤
      33/(M : ℝ)^K := by
  rw [Finset.sum_const, nsmul_eq_mul, div_eq_mul_inv, one_mul]
  apply mul_le_mul_of_nonneg_right _ (by positivity)
  exact_mod_cast rawChoiceCoordinates_card_le label newProducts p T σ h₀ β δ
    hprime hinj hban hp hσ hsep hwidth

/-- Sum over the actual indexed choices of the distinguished promoted
particle. The other promoted primes remain numeric products at this stage. -/
theorem rawChoiceCoordinates_sum_averaged_mass_le {B : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p : Fin B → ℕ) (T : ℕ) (σ : ℤ) (h₀ : Fin B → ℤ) (β δ : ℝ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hp : ∀ b, 0 < p b) (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : ∀ b, 2*(16/(p b : ℝ)) < δ) :
    (∑ b : Fin B, ∑ _c ∈ rawChoiceCoordinates label newProducts (p b) T σ (h₀ b) β,
      1/(M : ℝ)^K) ≤ 33*(B : ℝ)/(M : ℝ)^K := by
  calc
    _ ≤ ∑ _b : Fin B, 33/(M : ℝ)^K := Finset.sum_le_sum (fun b _ =>
      rawChoiceCoordinates_averaged_mass_le label newProducts (p b) T σ (h₀ b) β δ
        hprime hinj hban (hp b) hσ hsep (hwidth b))
    _ = 33*(B : ℝ)/(M : ℝ)^K := by simp [div_eq_mul_inv]; ring

end Elliptic.Operator
