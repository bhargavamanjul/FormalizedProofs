module

public import Elliptic.Operator.PhysicalMaskedIdentification
public import Elliptic.Operator.PhysicalBagRepresentatives
public import Elliptic.Operator.CrudePhysicalRow
public import Elliptic.Operator.WeightedSchur

/-!
# Actual masked physical rows and measured columns

The matrix rows are bounded by literal physical indexed choice rows.
The opposite measured column is derived from the proved mask-swapping
physical reversal, retaining the actual bag measure and Schur weights.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskedSchur
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
local instance maskedSchurDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1500000

variable {G Z : Type*} [Fintype G] [Fintype Z]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- The source Schur weight on the exact total bag cardinality. -/
def weight (v0 : ℝ) (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℝ :=
  v0 ^ (∑ i, (bags s i).val.card)

theorem weight_pos {v0 : ℝ} (hv0 : 0 < v0)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : 0 < weight v0 s := pow_pos hv0 _

theorem weight_ofOrdered (v0 : ℝ) (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    weight v0 (ofOrdered s) = physicalMemorySchurWeight v0 s := by
  simp only [weight,ofOrdered,bags,memoryBagOf_card,physicalMemorySchurWeight]

/-- Every bag has positive actual factorial mass for positive prime masses. -/
theorem memoryBagMass_pos {X : Type*} [Fintype X] (μ : X → ℝ)
    (hμ : ∀ x, 0 < μ x) (b : MemoryBag X B) : 0 < memoryBagMass μ b := by
  obtain ⟨m,hm⟩ := PhysicalBagRepresentatives.memory_exists b
  have he : tupleBag m.values = b.val := congrArg Subtype.val hm
  unfold memoryBagMass
  apply Finset.sum_pos'
  · intro n _
    split_ifs
    · exact (MemoryState.mass_pos μ hμ n).le
    · exact le_rfl
  · exact ⟨m,Finset.mem_univ _,by rw [ite_eq_left he]; exact MemoryState.mass_pos μ hμ m⟩

theorem mass_pos (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : 0 < mass ν s := by
  unfold mass
  apply Finset.prod_pos
  intro i _
  apply mul_pos
  · exact Finset.prod_pos (fun j _ => hν i (active s i j))
  · exact memoryBagMass_pos _ (fun (x : AnchoredParticle (P i) (Line i)) => hν i x.1) _

theorem mass_complex (ν : ∀ i, P i → ℝ)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    mass (fun i p => (ν i p:ℂ)) s = ((mass (R:=ℝ) ν s : ℝ):ℂ) := by
  simp [mass,memoryBagMass,tupleWeight,MemoryState.mass,Complex.ofReal_prod,
    Complex.ofReal_sum,apply_ite]

/-- The full bag matrix at the original physical normalization. -/
def originalKernel (ν : ∀ i, P i → ℝ) (V : G → ℝ) (S I : G → Bool) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  kernel (fun i p => (ν i p:ℂ)) (fun _ => 1) (fun i => (V i:ℂ)⁻¹)
    S I (ρ:ℂ) anchor geometry s t

/-- The exact normalized row of the original bag matrix. -/
def row (ν : ∀ i, P i → ℝ) (V : G → ℝ) (S I : G → Bool) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℝ :=
  ∑ t, ‖originalKernel ν V S I ρ anchor geometry s t‖ * (weight v0 t / weight v0 s)

/-- Literal masked absolute choice row in the original physical operator. -/
def choiceRow (ν : ∀ i, P i → ℝ) (V : G → ℝ) (S I : G → Bool) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    if ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i then
      ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
        (physicalMemorySchurWeight v0 (c.output anchor s hc) / physicalMemorySchurWeight v0 s)
    else 0
  else 0

theorem originalKernel_eq_choices
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0)
    (V : G → ℝ) (S I : G → Bool) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    originalKernel ν V S I ρ anchor geometry (ofOrdered s) t =
      PhysicalMaskedChoices.originalMaskedApply ν V S I ρ anchor geometry
        (fun u => if u=t then 1 else 0) s := by
  have hn : ∀ i p, (ν i p:ℂ) ≠ 0 := by intro i p; exact_mod_cast hν i p
  have h := PhysicalMaskedIdentification.physicalApply_eq_kernel
    (fun i p => (ν i p:ℂ)) hn (fun _ => 1) (fun i => (V i:ℂ)⁻¹)
    S I (ρ:ℂ) anchor geometry (fun u => if u=t then 1 else 0) s
  rw [PhysicalMaskedChoices.physicalApply_original] at h
  rw [Finset.sum_eq_single t] at h
  · simpa only [ite_true,mul_one,originalKernel] using h.symm
  · intro u _ hu
    simp only [ite_eq_right hu,mul_zero]
  · simp

/-- The exact collected bag row is dominated by the literal indexed row.
No column or opposite-row estimate is used here. -/
theorem row_le_choices
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0)
    (V : G → ℝ) (S I : G → Bool) (ρ v0 : ℝ) (hv0 : 0 ≤ v0)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    (∑ t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
      ‖originalKernel ν V S I ρ anchor geometry (ofOrdered s) t‖ *
        (weight v0 t / weight v0 (ofOrdered s))) ≤ choiceRow ν V S I ρ v0 anchor geometry s := by
  simp_rw [originalKernel_eq_choices ν hν]
  unfold PhysicalMaskedChoices.originalMaskedApply choiceRow
  calc
    _ ≤ ∑ t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
        (∑ c : PhysicalEdgeChoice s,
          ‖if hc : c.Valid anchor s then
            if ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i then
              physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc *
                (if ofOrdered (c.output anchor s hc)=t then 1 else 0) else 0 else 0‖) *
          (weight v0 t / weight v0 (ofOrdered s)) := by
      apply Finset.sum_le_sum
      intro t _
      exact mul_le_mul_of_nonneg_right (norm_sum_le _ _)
        (by unfold weight; positivity)
    _ = _ := by
      simp_rw [Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro c _
      by_cases hc : c.Valid anchor s
      · simp only [dite_eq_left hc]
        by_cases hm : ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i
        · simp only [ite_eq_left hm]
          rw [Finset.sum_eq_single (ofOrdered (c.output anchor s hc))]
          · simp [weight_ofOrdered]
          · intro t _ ht
            simp [Ne.symm ht]
          · simp
        · simp only [ite_eq_right hm,norm_zero,zero_mul,Finset.sum_const_zero]
      · simp only [dite_eq_right hc,norm_zero,zero_mul,Finset.sum_const_zero]

/-- Named normalized row version, retaining the same finite enumeration. -/
theorem row_le_choices_named
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0)
    (V : G → ℝ) (S I : G → Bool) (ρ v0 : ℝ) (hv0 : 0 ≤ v0)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    row ν V S I ρ v0 anchor geometry (ofOrdered s) ≤ choiceRow ν V S I ρ v0 anchor geometry s :=
  row_le_choices ν hν V S I ρ v0 hv0 anchor geometry s

/-- Taking norms of the proved measured reversal gives the actual weighted
column identity. The opposite masks and coefficients remain explicit. -/
theorem measured_column_eq_reverse_row
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (store promote : G → ℂ) (S I : G → Bool) (ρ : ℂ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (h : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℝ)
    (t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    (∑ s, mass ν s * ‖kernel (fun i p => (ν i p:ℂ)) store promote S I ρ anchor geometry s t‖ * h s) =
    mass ν t * ∑ s,
      ‖kernel (fun i p => (ν i p:ℂ)) promote store I S ρ anchor
        (fun z a w b => geometry w b z a) t s‖ * h s := by
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro s _
  have hn : ∀ i p, (ν i p:ℂ) ≠ 0 := by intro i p; exact_mod_cast (hν i p).ne'
  have he := congrArg norm (kernel_balance (fun i p => (ν i p:ℂ)) hn
    store promote S I ρ anchor geometry s t)
  simp only [mass_complex,norm_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_of_pos (mass_pos ν hν s),abs_of_pos (mass_pos ν hν t)] at he
  rw [he,mul_assoc]

end Elliptic.Operator.PhysicalMaskedSchur
