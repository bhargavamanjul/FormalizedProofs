module
public import Elliptic.Operator.MajorArcBandEndpointSaving
public import Elliptic.Operator.MajorArcFullEndpointMeanSquare
public import Elliptic.Operator.SignedMajorEndpointPolynomials

/-! Actual source endpoint energy inserted into the proved determinant Mellin estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcSourceMellinSaving
open Filter MeasureTheory Set
open scoped BigOperators ComplexConjugate
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest
open MajorArcLabelMass MajorArcBandEndpointSaving MajorArcFullEndpointMeanSquare
open SignedMajorMellinIdentity SignedSmoothDyads MellinPlateau
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

/-- The norm identities in the conclusion merely allow the unit Mellin
normalization phases and the reflected conjugate endpoint. All analytic
energy estimates are proved for the literal source coefficients. -/
theorem uniform_source_mellin_integral
    (hbands:ClassicalBandMass) (hvdC:FixedOrderDerivativeTest)
    (hD:Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ C G E c₁ c₂:ℝ) (hδ:0<δ) (hC:0≤C) (hG:0≤G) (hE:0≤E)
    {I:Type} (Hm Hn:ℝ→I→ℝ) (active:ℝ→I→Prop) (α:ℝ→I→ℕ→ℂ)
    (hscale:ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel:ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα:∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^C)
    (K:ℕ) (hK:1≤K) (bands:Bands K) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→∀s t:Finset ℕ,
      IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^C)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^(G+1)→
      ∀χa χm χn χa' χm' χn':DirichletCharacter ℂ k,
      ∀lam Y:ℝ,0<Y→|lam|≤2*(Real.log x)^G→
      ∀Q Q':ℝ→ℂ,Continuous Q→Continuous Q'→
      (∀v,‖Q v‖=‖fullEndpoint (bands.group x) χa weight (-lam) Y v*
        longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖)→
      (∀v,‖Q' v‖=‖fullEndpoint (bands.group x) χa' weight (-lam) Y (-v)*
        longPolynomial s (α x j) (Hm x j) χm' (-v)*longPolynomial t β (Hn x j) χn' (-v)‖)→
      ‖∫v:ℝ,∫w:ℝ,sourceMellinKernel (Hm x j*Hn x j) lam v w*Q v*Q' (w-v)‖≤(Real.log x)^(-E) := by
  obtain ⟨B,Ac,hBmin,hB,hAc,hdet⟩ := MellinDeterminantBound.eventually_determinant_bilinear
    determinantCutoff rho sigma determinantCutoff_contDiff (plateau_smooth (-5) 5)
    (plateau_smooth 0 (Real.log 16)) (plateau_compact (-5) 5) (plateau_compact 0 (Real.log 16))
    G (4*C+6) E 1 hG (by linarith) hE
  have henergy := uniform_band_endpoint_energy hbands hvdC hD weight weight_contDiff
    (fun y hy=>⟨(weight_support y hy).1.le,(weight_support y hy).2.le⟩)
    δ C (B+1) Ac (G+1) (G+1) c₁ c₂ hδ hC (by linarith) hAc.le (by linarith) (by linarith)
    Hm Hn active α hscale hcancel hα K hK bands
  filter_upwards [henergy,Real.tendsto_log_atTop.eventually hdet,
    Real.tendsto_log_atTop.eventually (eventually_full_endpoint_mean_square hD δ C hδ hC),
    hscale,hα,hbands K bands,Real.tendsto_log_atTop.eventually (eventually_ge_atTop (2:ℝ)),
    eventually_ge_atTop c₂,eventually_gt_atTop (0:ℝ)] with x henergy hdet hmean hscale hα hmass hL hxC hx
  intro j hj s t hs ht β hβ k hk hkmax χa χm χn χa' χm' χn' lam Y hY hlam Q Q' hQ hQ' hnorm hnorm'
  let L := Real.log x
  let X := Hm x j*Hn x j
  have hL':2≤L := hL
  have hLp:0<L := by dsimp [L];linarith
  have hsc := hscale j hj
  have hX:1≤X := by dsimp [X];nlinarith [hsc.1,hsc.2.1]
  have hXp:0<X := by linarith
  have hmin:Real.exp (δ*L)≤X := by
    have hxδ:Real.exp (δ*L)=x^δ := by rw [Real.rpow_def_of_pos hx];congr 1;ring
    rw [hxδ]
    exact hsc.2.2.1.trans (by dsimp [X];nlinarith [hsc.1,hsc.2.1])
  have hmax:X≤Real.exp (2*L) := by
    calc
      _ ≤ c₂*x := hsc.2.2.2.2.2
      _ ≤ x*x := mul_le_mul_of_nonneg_right hxC hx.le
      _ = _ := by dsimp [L];rw [two_mul,Real.exp_add,Real.exp_log hx]
  have hs' : InDyad (Hm x j) s := hs.inDyad
  have hcoef : ∀n∈s,‖α x j n‖≤L^C := fun n hn=>hα j hj n (hs' n hn).1 (hs' n hn).2
  have hmasses : ∀i,(∑p∈bands.group x i,(p:ℝ)⁻¹)≠0 := by
    intro i
    exact ne_of_gt ((show (0:ℝ)<Real.log 2/2 by positivity).trans_le (hmass i))
  let F (a m n:DirichletCharacter ℂ k) (v:ℝ) :=
    fullEndpoint (bands.group x) a weight (-lam) Y v*
      longPolynomial s (α x j) (Hm x j) m v*longPolynomial t β (Hn x j) n v
  have hFc (a m n:DirichletCharacter ℂ k):Continuous (F a m n) :=
    ((fullEndpoint_continuous _ _ _ _ _).mul (longPolynomial_continuous _ _ _ _)).mul
      (longPolynomial_continuous _ _ _ _)
  have hmeanF (a m n:DirichletCharacter ℂ k) (u v:ℝ) (huv:u≤v) :
      (∫w in Icc u v,‖F a m n w‖^2)≤L^(4*C+6)*(1+(v-u)/X) := by
    rw [integral_Icc_eq_integral_Ioc,←intervalIntegral.integral_of_le huv]
    exact hmean (Hm x j) (Hn x j) hsc.1 hsc.2.1 hmin hmax s t hs' ht (α x j) β hcoef hβ
      k k m n (Fin K) (bands.group x) (fun i p hp=>(bands.group_prime x hp).pos) hmasses k a weight
      weight_norm_le_one (fun y hy=>(weight_support y hy).2.le) (-lam) Y hY u v huv
  have hlam' : |-lam|≤L^(G+1) := by
    rw [abs_neg]
    apply hlam.trans
    rw [Real.rpow_add hLp,Real.rpow_one]
    calc
      _ ≤ L*L^G := mul_le_mul_of_nonneg_right hL' (Real.rpow_nonneg hLp.le G)
      _ = _ := mul_comm _ _
  have hwindow : 2*X*L^B≤X*L^(B+1) := by
    rw [Real.rpow_add hLp,Real.rpow_one]
    have hh := mul_le_mul_of_nonneg_right hL' (show 0≤X*L^B by positivity)
    nlinarith
  have hcentral (a m n:DirichletCharacter ℂ k) :
      (∫v in Icc (-2*X*L^B) (2*X*L^B),‖F a m n v‖^2)≤L^(-Ac) := by
    have he := henergy j hj k a s t hs ht β hβ k hk hkmax k m n (-lam) Y hY hlam' 0 (by simp;positivity)
    simp only [zero_sub,zero_add] at he
    apply le_trans _ he
    apply setIntegral_mono_set ((hFc a m n).norm.pow 2).integrableOn_Icc
      (ae_of_all _ (fun v=>sq_nonneg _)) (ae_of_all _ ?_)
    intro v hv
    constructor <;> nlinarith [hv.1,hv.2]
  apply hdet X hX lam hlam Q Q' hQ hQ'
  · intro a b hab
    simp_rw [hnorm]
    exact hmeanF χa χm χn a b hab
  · intro a b hab
    simp_rw [hnorm']
    have hh := MellinBilinearTail.interval_substitution (fun v=>‖F χa' χm' χn' v‖^2) 0 a b hab
    simp only [zero_sub] at hh
    rw [hh]
    convert hmeanF χa' χm' χn' (-b) (-a) (by linarith) using 1 <;> congr 2 <;> ring
  · simp_rw [hnorm]
    exact hcentral χa χm χn
  · simp_rw [hnorm']
    have hh := MellinBilinearTail.interval_substitution (fun v=>‖F χa' χm' χn' v‖^2) 0
      (-2*X*L^B) (2*X*L^B) (by nlinarith [show 0≤X*L^B by positivity]) 
    simp only [zero_sub] at hh
    rw [hh]
    convert hcentral χa' χm' χn' using 1 <;> congr 2 <;> ring

end Elliptic.Operator.MajorArcSourceMellinSaving
