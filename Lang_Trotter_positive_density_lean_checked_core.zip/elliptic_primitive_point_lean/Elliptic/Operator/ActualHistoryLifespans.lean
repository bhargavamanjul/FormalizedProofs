module

public import Elliptic.Operator.ScheduledHistoryRecovery
public import Elliptic.Operator.ActualBirthSupport
public import Elliptic.Operator.ActualHistorySupport

/-!
# Lifespan constraints read directly from actual histories

The assertions here concern literal state and choice data, without a
supplied schedule or compatibility predicate. In particular, an isolated
live visit must be active when both pending-memory boundaries are empty.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath
attribute [local instance] Classical.propDecidable
local instance actualHistoryLifespansDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace ActualHistoryLifespans
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- Pending memory after an edge comes only from previous pending memory
or a stored previous active prime. Fresh targets are active, not pending. -/
theorem edge_pending_from_source (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i)
    (hp : ∃ a, (((c.output anchor s hc).memory P Line J B i).values a).1 = p) :
    (∃ a, s.active P Line J B i a = p) ∨
      (∃ a, ((s.memory P Line J B i).values a).1 = p) := by
  have hh := (edgeGroupOutput_prime_exists_iff (anchor (s.position P Line J B) i)
    (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2 p).mp hp
  rcases hh with ⟨a,ha,hp⟩ | ⟨hstore,hp⟩
  · exact Or.inr ⟨a,hp⟩
  · exact Or.inl ⟨c.sourcePerm i (Fin.last J),hp⟩

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- An old pending particle survives an edge either in pending memory or
in the promoted active slot. The edge cannot simply discard it. -/
theorem edge_pending_persists (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i)
    (hp : ∃ a, ((s.memory P Line J B i).values a).1 = p) :
    (∃ a, (c.output anchor s hc).active P Line J B i a = p) ∨
      (∃ a, (((c.output anchor s hc).memory P Line J B i).values a).1 = p) := by
  obtain ⟨a,ha⟩ := hp
  by_cases hprom : a ∈ edgePromotedIndices (c.group i)
  · have ht : edgeTargetPrime (s.memory P Line J B i) (c.group i) = p := by
      cases he : (c.group i).2 with
      | inl k =>
          have hak : a = k := by simpa only [edgePromotedIndices,he,Finset.mem_singleton] using hprom
          simpa only [edgeTargetPrime,he,← hak] using ha
      | inr q => simp [edgePromotedIndices,he] at hprom
    refine Or.inl ⟨(c.targetPerm i).symm (Fin.last J),?_⟩
    rw [PhysicalEdgeChoice.output_active]
    simpa only [Equiv.apply_symm_apply,PhysicalEdgeChoice.targetLists_last] using ht
  · apply Or.inr
    exact (edgeGroupOutput_prime_exists_iff (anchor (s.position P Line J B) i)
      (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2 p).mpr
      (Or.inl ⟨a,hprom,ha⟩)

/-- Literal presence in active or pending slots of one actual group. -/
def StateHas (s : PhysicalMemoryState (Z:=Z) P Line J B) (i : I) (p : P i) : Prop :=
  (∃ a, s.active P Line J B i a = p) ∨
    (∃ a, ((s.memory P Line J B i).values a).1 = p)

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- Every post-ghost occurrence has an old source or an actual fresh draw. -/
theorem ghost_has_source_or_birth (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i)
    (hp : StateHas (c.output anchor s hc) i p) :
    StateHas s i p ∨ ∃ a, (c i).2.values a = p := by
  rcases hp with ha | hm
  · exact Or.inl (Or.inl ha)
  · rcases (ghostOutput_prime_exists_iff _ _ _ (hc.1 i) p).mp hm with ⟨a,_,ha⟩ | hb
    · exact Or.inl (Or.inr ⟨a,ha⟩)
    · exact Or.inr hb

omit [Fintype Z] [∀ i, Fintype (P i)] in
/-- Every post-edge occurrence has an old source or a literal fresh target. -/
theorem edge_has_source_or_birth (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i)
    (hp : StateHas (c.output anchor s hc) i p) :
    StateHas s i p ∨ (c.group i).2 = Sum.inr p := by
  rcases hp with ⟨a,ha⟩ | hm
  · change c.targetLists i (c.targetPerm i a) = p at ha
    generalize c.targetPerm i a = k at ha
    revert ha
    refine Fin.lastCases ?_ (fun k => ?_) k
    · intro ht
      have ht' : edgeTargetPrime (s.memory P Line J B i) (c.group i) = p := by simpa using ht
      cases he : (c.group i).2 with
      | inl a => exact Or.inl (Or.inr ⟨a,by simpa only [edgeTargetPrime,he] using ht'⟩)
      | inr q =>
          have hqp : q = p := by simpa only [edgeTargetPrime,he] using ht'
          exact Or.inr (congrArg Sum.inr hqp)
    · intro hk
      exact Or.inl (Or.inl ⟨c.sourcePerm i k.castSucc,by simpa [PhysicalEdgeChoice.sourceLists] using hk⟩)
  · exact Or.inl (edge_pending_from_source anchor s c hc i p hm)

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

theorem beforeStateAt_zero (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s) :
    beforeStateAt ν V η q ρ geometry n j s h 0 = s := by
  cases n <;> rfl

/-- With no pending occurrence at either boundary, a prime whose only
live visit is k must be active there. No schedule or distinct-birth
hypothesis is needed. -/
theorem singleton_live_active (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i)
    (hinitial : ¬ ∃ a, ((s.memory P Line J B i).values a).1 = p)
    (hfinal : ¬ ∃ a, ((h.final.memory P Line J B i).values a).1 = p)
    (k : Fin (n+1))
    (hlive : observedLive ν V η q ρ geometry n j s h k i p)
    (honly : ∀ t : Fin (n+1), observedLive ν V η q ρ geometry n j s h t i p → t = k) :
    observedActive ν V η q ρ geometry n j s h k i p := by
  induction n generalizing j s with
  | zero =>
      rcases hlive with ha | hb | ha
      · exact ha
      · exact False.elim (hinitial hb)
      · exact False.elim (hfinal ha)
  | succ n ih =>
      let a : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
      let b : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalEdgeOperation ν V ρ anchor (geometry j)).output a h.2.1.val h.2.1.property
      have hbefore : (∃ t, ((b.memory P Line J B i).values t).1 = p) →
          observedLive ν V η q ρ geometry (n+1) j s h 0 i p := by
        intro hp
        rcases edge_pending_from_source anchor a h.2.1.val h.2.1.property i p hp with ha | hm
        · exact Or.inl ha
        · exact Or.inr (Or.inr hm)
      have hafter : (∃ t, ((a.memory P Line J B i).values t).1 = p) →
          observedLive ν V η q ρ geometry (n+1) j s h (Fin.succ 0) i p := by
        intro hp
        rcases edge_pending_persists anchor a h.2.1.val h.2.1.property i p hp with ha | hm
        · apply Or.inl
          change ∃ t, (beforeStateAt ν V η q ρ geometry n (j+1) b h.2.2 0).active P Line J B i t = p
          rw [beforeStateAt_zero]
          exact ha
        · apply Or.inr ∘ Or.inl
          change ∃ t, (((beforeStateAt ν V η q ρ geometry n (j+1) b h.2.2 0).memory P Line J B i).values t).1 = p
          rw [beforeStateAt_zero]
          exact hm
      revert hlive honly
      refine Fin.cases ?_ (fun k => ?_) k
      · intro hlive honly
        rcases hlive with ha | hb | ha
        · exact ha
        · exact False.elim (hinitial hb)
        · have he := honly (Fin.succ 0) (hafter ha)
          have hv := congrArg Fin.val he
          simp at hv
      · intro hlive honly
        have hbinitial : ¬ ∃ t, ((b.memory P Line J B i).values t).1 = p := by
          intro hb
          have he := honly 0 (hbefore hb)
          have hv := congrArg Fin.val he
          simp at hv
        apply ih (j+1) b h.2.2 hbinitial hfinal k hlive
        intro t ht
        exact Fin.succ_injective _ (honly t.succ ht)

/-- If a numerical label has no performed birth in the remaining word,
every later occurrence of that prime must already be live initially. -/
theorem live_origin_of_no_future_birth (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i)
    (hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h)
    (k : Fin (n+1)) (hlive : observedLive ν V η q ρ geometry n j s h k i p) :
    StateHas s i p := by
  induction n generalizing j s with
  | zero =>
      rcases hlive with ha | hb | ha
      · exact Or.inl ha
      · exact Or.inr hb
      · rcases ghost_has_source_or_birth anchor s h.1.val h.1.property i p (Or.inr ha) with hs | ⟨a,ha⟩
        · exact hs
        · exfalso
          apply hn
          refine ⟨.inl (0,i,⟨a.val,lt_of_lt_of_le a.isLt (h.1.val i).2.size_le⟩),?_⟩
          simpa only [ActualHistorySupport.firstGhost,ha] using
            ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry 0 j s h i a
  | succ n ih =>
      let a : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
      let b : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalEdgeOperation ν V ρ anchor (geometry j)).output a h.2.1.val h.2.1.property
      have hghost (hp : StateHas a i p) : StateHas s i p := by
        rcases ghost_has_source_or_birth anchor s h.1.val h.1.property i p hp with hs | ⟨a,ha⟩
        · exact hs
        · exfalso
          apply hn
          refine ⟨.inl (0,i,⟨a.val,lt_of_lt_of_le a.isLt (h.1.val i).2.size_le⟩),?_⟩
          simpa only [ActualHistorySupport.firstGhost,ha] using
            ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i a
      revert hlive
      refine Fin.cases ?_ (fun k => ?_) k
      · intro hlive
        rcases hlive with ha | hb | ha
        · exact Or.inl ha
        · exact Or.inr hb
        · exact hghost (Or.inr ha)
      · intro hlive
        have hnTail : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) b h.2.2 := by
          rintro ⟨addr,haddr⟩
          apply hn
          refine ⟨ActualHistorySupport.tailAddress addr,?_⟩
          rw [ActualHistorySupport.futureLabels_tail]
          exact haddr
        have hb := ih (j+1) b h.2.2 hnTail k hlive
        rcases edge_has_source_or_birth anchor a h.2.1.val h.2.1.property i p hb with ha | hf
        · exact hghost ha
        · exfalso
          apply hn
          exact ⟨.inr (0,i), ActualHistorySupport.futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hf⟩

/-- Global distinct performed births rule out gaps in a prime's observed
live visits. The proof uses actual support and future-birth avoidance;
interval convexity is the conclusion, not an input. -/
theorem live_convex_of_future_distinct (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (i : I) (p : P i) (a c b : Fin (n+1))
    (ha : observedLive ν V η q ρ geometry n j s h a i p)
    (hc : observedLive ν V η q ρ geometry n j s h c i p)
    (hab : a.val ≤ b.val) (hbc : b.val ≤ c.val) :
    observedLive ν V η q ρ geometry n j s h b i p := by
  induction n generalizing j s with
  | zero =>
      have he : a = b := Fin.ext (by omega)
      exact he ▸ ha
  | succ n ih =>
      let sg : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
      let se : PhysicalMemoryState (Z:=Z) P Line J B :=
        (physicalEdgeOperation ν V ρ anchor (geometry j)).output sg h.2.1.val h.2.1.property
      have hi := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
      have hhead : observedLive ν V η q ρ geometry (n+1) j s h 0 i p →
          value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2 := by
        rintro (⟨k,hk⟩ | ⟨k,hk⟩ | ⟨k,hk⟩)
        · change s.active P Line J B i k = p at hk
          have hh := hi.2.1.1 i k
          rw [hk] at hh
          exact hh
        · change ((s.memory P Line J B i).values k).1 = p at hk
          have hh := hi.2.1.2 i k
          rw [hk] at hh
          exact hh
        · change ((sg.memory P Line J B i).values k).1 = p at hk
          have hh := hi.2.2.1.2 i k
          change value i ((sg.memory P Line J B i).values k).1 ∉ _ at hh
          rw [hk] at hh
          exact hh
      revert ha hc hab hbc
      refine Fin.cases ?_ (fun a => ?_) a
      · refine Fin.cases ?_ (fun b => ?_) b
        · intro ha _ _ _
          exact ha
        · refine Fin.cases ?_ (fun c => ?_) c
          · intro _ _ _ hbc
            simp only [Fin.val_succ,Fin.val_zero] at hbc
            omega
          · intro ha hc _ hbc
            have hsource := live_origin_of_no_future_birth ν V η q ρ anchor geometry value n (j+1) se h.2.2 i p (hhead ha) c hc
            have hzero : observedLive ν V η q ρ geometry n (j+1) se h.2.2 0 i p := by
              rcases hsource with hs | hs
              · apply Or.inl
                unfold observedActive
                rw [beforeStateAt_zero]
                exact hs
              · apply Or.inr ∘ Or.inl
                unfold observedPendingBefore
                rw [beforeStateAt_zero]
                exact hs
            exact ih (j+1) se h.2.2 hi.1 hi.2.2.2 0 c b hzero hc
              (Nat.zero_le _) (by simpa only [Fin.val_succ,Nat.add_le_add_iff_right] using hbc)
      · refine Fin.cases ?_ (fun b => ?_) b
        · intro _ _ hab _
          simp only [Fin.val_succ,Fin.val_zero] at hab
          omega
        · refine Fin.cases ?_ (fun c => ?_) c
          · intro _ _ _ hbc
            simp only [Fin.val_succ,Fin.val_zero] at hbc
            omega
          · intro ha hc hab hbc
            exact ih (j+1) se h.2.2 hi.1 hi.2.2.2 a c b ha hc
              (by simpa only [Fin.val_succ,Nat.add_le_add_iff_right] using hab)
              (by simpa only [Fin.val_succ,Nat.add_le_add_iff_right] using hbc)

/-- The full actual birth logger supplies both initial future conditions. -/
theorem initial_future_conditions (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0) :
    BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry N 0 s h) ∧
      ActualHistorySupport.Avoids value
        (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry N 0 s h) s := by
  constructor
  · intro a b p hap hbp
    apply Sum.inr.inj (hd (.inr a) (.inr b) p ?_ ?_)
    · cases a <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using hap
    · cases b <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using hbp
  · constructor
    · intro i k hp
      obtain ⟨a,ha⟩ := hp
      have he := hd (.inl (i,k)) (.inr a) _ rfl (by
        cases a <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using ha)
      cases he
    · intro i k
      have hk := k.isLt
      have he := hempty i
      omega

/-- Live visits form an interval for a raw history with globally distinct
performed numerical births and initially empty pending memories. -/
theorem live_convex_of_birthsDistinct (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0)
    (i : I) (p : P i) (a c b : Fin (N+1))
    (ha : observedLive ν V η q ρ geometry N 0 s h a i p)
    (hc : observedLive ν V η q ρ geometry N 0 s h c i p)
    (hab : a.val ≤ b.val) (hbc : b.val ≤ c.val) :
    observedLive ν V η q ρ geometry N 0 s h b i p := by
  have hh := initial_future_conditions ν V η q ρ anchor geometry value N s h hd hempty
  exact live_convex_of_future_distinct ν V η q ρ anchor geometry value N 0 s h hh.1 hh.2 i p a c b ha hc hab hbc

/-- The extracted finite live set has interval convexity under the actual
birth restriction. It is not supplied as a reconstruction hypothesis. -/
theorem observedLiveVisits_convex (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0) (i : I) (p : P i) :
    ∀ a ∈ observedLiveVisits ν V η q ρ geometry s h i p,
      ∀ c ∈ observedLiveVisits ν V η q ρ geometry s h i p,
      ∀ b, a ≤ b → b ≤ c → b ∈ observedLiveVisits ν V η q ρ geometry s h i p := by
  intro a ha c hc b hab hbc
  obtain ⟨ka,hka,rfl⟩ := Finset.mem_image.mp ha
  obtain ⟨kc,hkc,rfl⟩ := Finset.mem_image.mp hc
  have hkb : b < N+1 := lt_of_le_of_lt hbc kc.isLt
  let kb : Fin (N+1) := ⟨b,hkb⟩
  apply Finset.mem_image.mpr
  refine ⟨kb,Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩,rfl⟩
  exact live_convex_of_birthsDistinct ν V η q ρ anchor geometry value N s h hd hempty
    i p ka kc kb (Finset.mem_filter.mp hka).2 (Finset.mem_filter.mp hkc).2 hab hbc

/-- The finite trace has the singleton-active property needed to construct
a lifespan whenever both actual pending-memory boundaries are empty. -/
theorem observedLiveVisits_singleton_active (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0) (i : I) (p : P i) :
    ∀ j ∈ observedLiveVisits ν V η q ρ geometry s h i p,
      (∀ k ∈ observedLiveVisits ν V η q ρ geometry s h i p, k = j) →
      j ∈ observedActiveVisits ν V η q ρ geometry s h i p := by
  intro j hj honly
  obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hj
  have ha : observedActive ν V η q ρ geometry N 0 s h k i p := by
    apply singleton_live_active ν V η q ρ anchor geometry N 0 s h i p
    · rintro ⟨a,_⟩
      have hb := a.isLt
      have hz := hinitial i
      omega
    · rintro ⟨a,_⟩
      have hb := a.isLt
      have hz := hfinal i
      omega
    · exact (Finset.mem_filter.mp hk).2
    · intro t ht
      apply Fin.ext
      exact honly t.val (Finset.mem_image.mpr ⟨t,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ht⟩,rfl⟩)
  exact Finset.mem_image.mpr ⟨k,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha⟩,rfl⟩

/-- The extracted live visits always lie within the physical horizon. -/
theorem observedLiveVisits_bound (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (i : I) (p : P i) :
    ∀ j ∈ observedLiveVisits ν V η q ρ geometry s h i p, j ≤ N := by
  intro j hj
  obtain ⟨k,_,rfl⟩ := Finset.mem_image.mp hj
  omega

/-- Active visits are live by the actual definition of occurrence. -/
theorem observedActiveVisits_subset_live (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (i : I) (p : P i) :
    observedActiveVisits ν V η q ρ geometry s h i p ⊆ observedLiveVisits ν V η q ρ geometry s h i p := by
  intro j hj
  obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hj
  exact Finset.mem_image.mpr ⟨k,Finset.mem_filter.mpr ⟨Finset.mem_univ _,Or.inl (Finset.mem_filter.mp hk).2⟩,rfl⟩

/-- Every extracted used prime has a nonempty actual live trace. -/
theorem observedLiveVisits_nonempty (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) :
    (observedLiveVisits ν V η q ρ geometry s h i p).Nonempty := by
  obtain ⟨k,hk⟩ := (Finset.mem_filter.mp hp).2
  exact ⟨k.val,Finset.mem_image.mpr ⟨k,Finset.mem_filter.mpr ⟨Finset.mem_univ _,hk⟩,rfl⟩⟩

/-- A canonical lifespan extracted directly from a used prime's actual
live and active traces. The interval property is proved separately below. -/
def observedLifespan (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) : PrimeLifespan N :=
  PrimeLifespan.ofTrace (observedLiveVisits ν V η q ρ geometry s h i p)
    (observedActiveVisits ν V η q ρ geometry s h i p)
    (observedLiveVisits_nonempty ν V η q ρ anchor geometry N s h i p hp)
    (observedLiveVisits_bound ν V η q ρ anchor geometry N s h i p)
    (observedActiveVisits_subset_live ν V η q ρ anchor geometry N s h i p)
    (observedLiveVisits_singleton_active ν V η q ρ anchor geometry N s h hinitial hfinal i p)

/-- Under the actual distinct-birth restriction, the canonical extracted
lifespan has exactly the actual live trace: no gaps are filled artificially. -/
theorem observedLifespan_live (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (i : I) (p : P i) (hp : p ∈ observedPrimes ν V η q ρ geometry s h i) (j : ℕ) :
    let L := observedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p hp
    (j ∈ L.active ∨ L.beforeGhost j ∨ L.afterGhost j) ↔
      j ∈ observedLiveVisits ν V η q ρ geometry s h i p := by
  apply PrimeLifespan.ofTrace_live
  exact observedLiveVisits_convex ν V η q ρ anchor geometry value N s h hd hinitial i p

end ActualHistoryLifespans
end Elliptic.Operator
