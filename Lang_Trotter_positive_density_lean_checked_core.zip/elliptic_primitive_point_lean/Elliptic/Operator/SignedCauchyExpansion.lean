module

public import Artin.MarkedSource
public import Elliptic.Sieve.SignedReplacement
public import Elliptic.Operator.WeightedSchur

/-! Exact expansion of the original successor marked weight and removal
of its invariant selector. No bound on a desired bilinear sum is assumed.
The finite identities precede all choices of K and all asymptotic estimates. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedCauchyExpansion
open scoped BigOperators
open Artin Artin.MarkedSource
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}
abbrev LabelTuple (b : Bands K) (x : ℝ) := ∀ i, (b.group x i : Type)

def labelProduct (b : Bands K) (x : ℝ) (p : LabelTuple b x) : ℕ := ∏ i, (p i).val

def Divides (b : Bands K) (x : ℝ) (p : LabelTuple b x) (h : ℕ) : Prop :=
  ∀ i, (p i).val ∣ h

def damping (b : Bands K) (q x : ℝ) (h : ℕ) : ℝ :=
  ∏ i : Fin K, q^(ConcreteSelector.primeCount (b.group x i) h-1)/b.mass x i

theorem primeCount_eq_filter (b : Bands K) (x : ℝ) (i : Fin K) (h : ℕ) (hh : h≠0) :
    ConcreteSelector.primeCount (b.group x i) h = ((b.group x i).filter (fun p=>p∣h)).card := by
  unfold ConcreteSelector.primeCount
  congr 1
  ext p
  simp only [Finset.mem_inter,Finset.mem_filter,Nat.mem_primeFactors]
  constructor
  · intro hp
    exact ⟨hp.2,hp.1.2.1⟩
  · intro hp
    exact ⟨⟨b.group_prime x hp.1,hp.2,hh⟩,hp.1⟩

/-- The original marked weight is an exact sum over one literal divisor
prime in each band, including all multiplicity factors. -/
theorem markedWeight_eq_labels (b : Bands K) (q x : ℝ) (h : ℕ) (hh : h≠0) :
    markedWeight b q x h =
      ∑ p : LabelTuple b x, if Divides b x p h then damping b q x h else 0 := by
  have hi (i : Fin K) :
      ((ConcreteSelector.primeCount (b.group x i) h:ℝ)*q^(ConcreteSelector.primeCount (b.group x i) h-1))/b.mass x i =
        ∑ p : (b.group x i : Type), if p.val∣h then
          q^(ConcreteSelector.primeCount (b.group x i) h-1)/b.mass x i else 0 := by
    rw [Finset.sum_coe_sort (b.group x i) (fun p : ℕ => if p∣h then
      q^(ConcreteSelector.primeCount (b.group x i) h-1)/b.mass x i else 0)]
    rw [←Finset.sum_filter,Finset.sum_const,nsmul_eq_mul,←primeCount_eq_filter b x i h hh]
    ring
  unfold markedWeight
  simp_rw [hi]
  rw [Fintype.prod_sum]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hp : Divides b x p h
  · simp only [ite_eq_left hp]
    exact Finset.prod_congr rfl (fun i _=>if_pos (hp i))
  · have hi : ∃ i, ¬(p i).val∣h := by simpa only [Divides,not_forall] using hp
    obtain ⟨i,hi⟩ := hi
    rw [ite_eq_right hp]
    exact Finset.prod_eq_zero (Finset.mem_univ i) (by simp [hi])

theorem labelProduct_pos (b : Bands K) (x : ℝ) (p : LabelTuple b x) :
    0<labelProduct b x p := Finset.prod_pos (fun i _=>(b.group_prime x (p i).property).pos)

theorem labelProduct_dvd (b : Bands K) (x : ℝ) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (h : ℕ) (hp : Divides b x p h) : labelProduct b x p∣h := by
  apply Finset.prod_dvd_of_isRelPrime _ (fun i _=>hp i)
  intro i _ j _ hij
  change IsRelPrime (p i).val (p j).val
  rw [←Nat.coprime_iff_isRelPrime]
  apply (Nat.coprime_primes (b.group_prime x (p i).property) (b.group_prime x (p j).property)).mpr
  intro he
  exact Finset.disjoint_left.mp (hdisjoint hij) (p i).property (he ▸ (p j).property)

/-- Invariance removes any finite product of selected primes; there is
no dependence here on the particular selector or a later choice of K. -/
theorem invariant_product (b : Bands K) (x : ℝ) (F : ℕ→ℂ)
    (hF : InvariantSelector b x F) (p : LabelTuple b x) (s : Finset (Fin K))
    (h : ℕ) (hh : 0<h) : F ((∏ i∈s,(p i).val)*h)=F h := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [Finset.prod_insert hi,mul_assoc,hF.2 i (p i).val (p i).property]
    · exact ih
    · exact Nat.mul_pos (Finset.prod_pos (fun j _=>(b.group_prime x (p j).property).pos)) hh

theorem selector_eq_cofactor (b : Bands K) (x : ℝ) (F : ℕ→ℂ)
    (hF : InvariantSelector b x F) (p : LabelTuple b x)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (h : ℕ) (hh : 0<h) (hp : Divides b x p h) :
    F h=F (h/labelProduct b x p) := by
  have hd := labelProduct_dvd b x p hdisjoint h hp
  have hq : 0<h/labelProduct b x p := Nat.div_pos (Nat.le_of_dvd hh hd) (labelProduct_pos b x p)
  have he := invariant_product b x F hF p Finset.univ (h/labelProduct b x p) hq
  change F (labelProduct b x p*(h/labelProduct b x p))=F (h/labelProduct b x p) at he
  simpa only [Nat.mul_div_cancel' hd] using he

/-- Actual successor form after marking expansion, before any damping
replacement or asymptotic error estimate. -/
theorem successor_bilinear_eq_labels (b : Bands K) (q x : ℝ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (hF : InvariantSelector b x F)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    Sieve.SignedReplacement.bilinear s t α β (fun h=>F h*(markedWeight b q x h:ℂ)) =
      ∑ m∈s, ∑ n∈t, ∑ p : LabelTuple b x,
        if Divides b x p (m*n+1) then
          α m*β n*(damping b q x (m*n+1):ℂ)*F ((m*n+1)/labelProduct b x p) else 0 := by
  unfold Sieve.SignedReplacement.bilinear
  apply Finset.sum_congr rfl
  intro m _
  apply Finset.sum_congr rfl
  intro n _
  dsimp only
  rw [markedWeight_eq_labels b q x (m*n+1) (by omega)]
  push_cast
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hp : Divides b x p (m*n+1)
  · simp only [ite_eq_left hp]
    rw [selector_eq_cofactor b x F hF p hdisjoint (m*n+1) (by omega) hp]
    ring
  · simp [hp]

abbrev Record (b : Bands K) (x : ℝ) (s t : Finset ℕ) := s×t×LabelTuple b x

def records (b : Bands K) (x : ℝ) (s t : Finset ℕ) : Finset (Record b x s t) :=
  Finset.univ.filter (fun r=>Divides b x r.2.2 (r.1.val*r.2.1.val+1))

def cofactor (b : Bands K) (x : ℝ) (s t : Finset ℕ) (r : Record b x s t) : ℕ :=
  (r.1.val*r.2.1.val+1)/labelProduct b x r.2.2

def coefficient (b : Bands K) (q x : ℝ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (r : Record b x s t) : ℂ :=
  α r.1.val*β r.2.1.val*(damping b q x (r.1.val*r.2.1.val+1):ℂ)

def cofactors (b : Bands K) (x : ℝ) (s t : Finset ℕ) : Finset ℕ :=
  (records b x s t).image (cofactor b x s t)

def fiberCoefficient (b : Bands K) (q x : ℝ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (h : ℕ) : ℂ :=
  ∑ r∈(records b x s t).filter (fun r=>cofactor b x s t r=h), coefficient b q x s t α β r

/-- Literal reindexing of the successor sum by its positive cofactor. The
remaining coefficient is independent of the invariant selector. -/
theorem successor_bilinear_eq_cofactors (b : Bands K) (q x : ℝ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (hF : InvariantSelector b x F)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    Sieve.SignedReplacement.bilinear s t α β (fun h=>F h*(markedWeight b q x h:ℂ)) =
      ∑ h∈cofactors b x s t, F h*fiberCoefficient b q x s t α β h := by
  rw [successor_bilinear_eq_labels b q x s t α β F hF hdisjoint]
  have he : (∑ r∈records b x s t, coefficient b q x s t α β r*F (cofactor b x s t r)) =
      ∑ m∈s, ∑ n∈t, ∑ p : LabelTuple b x,
        if Divides b x p (m*n+1) then
          α m*β n*(damping b q x (m*n+1):ℂ)*F ((m*n+1)/labelProduct b x p) else 0 := by
    unfold records coefficient cofactor
    rw [Finset.sum_filter,Fintype.sum_prod_type]
    simp_rw [Fintype.sum_prod_type]
    rw [Finset.sum_coe_sort s (fun m : ℕ => ∑ n : t, ∑ p : LabelTuple b x,
      if Divides b x p (m*n.val+1) then
        α m*β n.val*(damping b q x (m*n.val+1):ℂ)*F ((m*n.val+1)/labelProduct b x p) else 0)]
    apply Finset.sum_congr rfl
    intro m _
    exact Finset.sum_coe_sort t (fun n : ℕ => ∑ p : LabelTuple b x,
      if Divides b x p (m*n+1) then
        α m*β n*(damping b q x (m*n+1):ℂ)*F ((m*n+1)/labelProduct b x p) else 0)
  rw [←he]
  have hf := Finset.sum_fiberwise_of_maps_to
    (s:=records b x s t) (t:=cofactors b x s t) (g:=cofactor b x s t)
    (fun r hr=>Finset.mem_image.mpr ⟨r,hr,rfl⟩)
    (fun r=>coefficient b q x s t α β r*F (cofactor b x s t r))
  rw [←hf]
  apply Finset.sum_congr rfl
  intro h _
  rw [fiberCoefficient,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  rw [(Finset.mem_filter.mp hr).2]
  ring

/-- Finite Cauchy removes a bounded selector with no loss depending on
its values, regularity, complexity, or dependence on x. -/
theorem selector_cauchy (H : Finset ℕ) (F c : ℕ→ℂ)
    (hF : ∀ h∈H, ‖F h‖≤1) :
    ‖∑ h∈H,F h*c h‖^2 ≤ (H.card:ℝ)*∑ h∈H,‖c h‖^2 := by
  have hnorm : ‖∑ h∈H,F h*c h‖ ≤ ∑ h∈H,‖c h‖ := by
    apply (norm_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro h hh
    rw [norm_mul]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right (hF h hh) (norm_nonneg (c h))
  have hsq := Finset.sum_mul_sq_le_sq_mul_sq H (fun _=>(1:ℝ)) (fun h=>‖c h‖)
  simp only [one_mul,one_pow,Finset.sum_const,nsmul_eq_mul,mul_one] at hsq
  exact (sq_le_sq₀ (norm_nonneg _) (Finset.sum_nonneg (fun _ _=>norm_nonneg _))).mpr hnorm |>.trans hsq

/-- Cauchy applied to the original marked successor bilinear form. All
selector dependence has disappeared before any analytic parameter choice. -/
theorem successor_bilinear_cauchy (b : Bands K) (q x : ℝ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (hF : InvariantSelector b x F)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ‖Sieve.SignedReplacement.bilinear s t α β (fun h=>F h*(markedWeight b q x h:ℂ))‖^2 ≤
      ((cofactors b x s t).card:ℝ)*∑ h∈cofactors b x s t,‖fiberCoefficient b q x s t α β h‖^2 := by
  rw [successor_bilinear_eq_cofactors b q x s t α β F hF hdisjoint]
  exact selector_cauchy _ F _ (fun h _=>hF.1 h)

end Elliptic.Operator.SignedCauchyExpansion
