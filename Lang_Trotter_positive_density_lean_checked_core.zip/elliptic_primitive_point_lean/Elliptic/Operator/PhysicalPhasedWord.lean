module

public import Elliptic.Operator.PhysicalBirthFactors

/-! Fourier factors multiply actual operation choices. The exact word
below retains all dependent outputs, valid-choice restrictions, and
factorial coefficients of the physical ghost and edge operations. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedWord
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthFactors
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000

def phasedApply {X : Type*} (O : ChoiceOperation X)
    (phase : (s:X)→O.Choice s→ℂ) (F:X→ℂ) (s:X) : ℂ :=
  ∑c : O.ValidChoice s,phase s c.val*O.coefficient s c.val*F (O.output s c.val c.property)

theorem phasedApply_one {X : Type*} (O : ChoiceOperation X) (F:X→ℂ) (s:X) :
    phasedApply O (fun _ _=>1) F s=O.apply F s := by simp [phasedApply,ChoiceOperation.apply]

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} {J B : ℕ}
variable (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ:ℝ)
variable (anchor:Z→∀i p,Line i p)
variable (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
variable (value:∀i,P i→ℕ)

def word (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ) :
    ℕ→ℕ→(PhysicalMemoryState (Z:=Z) P Line J B→ℂ)→PhysicalMemoryState (Z:=Z) P Line J B→ℂ
  | 0,j,F => phasedApply (physicalGhostOperation ν V (η j) (q j) ρ anchor)
      (fun _ c=>ghostFactor value G j c) F
  | n+1,j,F => phasedApply (physicalGhostOperation ν V (η j) (q j) ρ anchor)
      (fun _ c=>ghostFactor value G j c)
      (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
        (fun _ c=>edgeFactor value E j c) (word G E n (j+1) F))

theorem word_eq_historySum (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ)
    (n j : ℕ) (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (s:PhysicalMemoryState (Z:=Z) P Line J B) :
    word ν V η q ρ anchor geometry value G E n j F s =
      ∑h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s,
        historyFactor ν V η q ρ anchor geometry value G E n j s h*h.weight*F h.final := by
  induction n generalizing j s with
  | zero =>
      simp only [word,phasedApply,operations,memoryOperationsFrom,ChoiceOperation.History,
        Fintype.sum_sigma,historyFactor,ChoiceOperation.History.weight,
        ChoiceOperation.History.final,mul_one]
      simp
  | succ n ih =>
      simp only [word,phasedApply,operations,memoryOperationsFrom,ChoiceOperation.History,
        Fintype.sum_sigma,historyFactor,ChoiceOperation.History.weight,
        ChoiceOperation.History.final]
      apply Finset.sum_congr rfl
      intro c _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro e _
      rw [ih]
      simp_rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro h _
      ring

end Elliptic.Operator.PhysicalPhasedWord
