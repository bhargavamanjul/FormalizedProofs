module

public import Elliptic.Operator.PhysicalPivotRestrictions
public import Elliptic.Operator.PrescribedAlternatingWord

/-! # Pivot equalities imply causal restrictions along actual histories -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalPivotHistoryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Fixed addresses and pivots, chosen before any prime values are sampled. -/
structure PivotPlan (I : Type) (J B : ℕ) where
  pivot : Address I J B → Address I J B
  ghostSlots : ℕ → I → Finset ℕ
  edgeGroups : ℕ → Finset I
  ghost_bounded : ∀j i,ghostSlots j i⊆Finset.range B
  ghost_earlier : ∀j i k (hk:k∈ghostSlots j i),GhostPrecedes j i k
    (pivot (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (ghost_bounded j i hk)⟩))))
  edge_earlier : ∀j i,i∈edgeGroups j → BeforeEdge j (pivot (.inr (.inr (j,i))))

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B : ℕ}

/-- Performed-value equalities in the completed actual birth log. -/
def PivotPlan.Equalities (plan : PivotPlan I J B) (f : Registry I J B) : Prop :=
  (∀j i k (hk:k∈plan.ghostSlots j i),∃v,
    f (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (plan.ghost_bounded j i hk)⟩)))=some v ∧
    f (plan.pivot (.inr (.inl (j,i,⟨k,Finset.mem_range.mp (plan.ghost_bounded j i hk)⟩))))=some v) ∧
  (∀j i,i∈plan.edgeGroups j → ∃v,f (.inr (.inr (j,i)))=some v ∧
    f (plan.pivot (.inr (.inr (j,i))))=some v)

variable (ν : ∀i,P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀i p,Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
variable (value : ∀i,P i → ℕ) (plan : PivotPlan I J B)

/-- Tests on original actual histories; every update is causal. -/
def PivotPlan.Allowed : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s →
    Registry I J B → Prop
  | 0,j,_,h,r => PrescribedPhysicalGhost.Allowed value (plan.ghostSlots j)
      (ghostTarget value plan.pivot r j) h.1.val
  | n+1,j,_,h,r => PrescribedPhysicalGhost.Allowed value (plan.ghostSlots j)
      (ghostTarget value plan.pivot r j) h.1.val ∧
      (∀i∈plan.edgeGroups j,PrescribedEdgeRow.Prescribed (value i)
        (edgeTarget plan.pivot (afterGhost value j h.1.val r) j i) (h.2.1.val.group i)) ∧
      PivotPlan.Allowed n (j+1) _ h.2.2
        (afterEdge value j h.2.1.val (afterGhost value j h.1.val r))

/-- The completed record agrees with the starting registry at all earlier visits. -/
theorem record_agrees_before (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) :
    ∀a,BeforeGhost j a → r a=record ν V η q ρ anchor geometry value n j s h r a := by
  rintro (a|(a|a)) ha
  · exact (record_initial ν V η q ρ anchor geometry value n j s h r a).symm
  · exact (record_pastGhost ν V η q ρ anchor geometry value n j s h r a.1 ha a.2.1 a.2.2).symm
  · exact (record_pastEdge ν V η q ρ anchor geometry value n j s h r a.1 ha a.2).symm

/-- All prescribed completed-log equalities are implemented by the causal
checks, including same-batch earlier pivots and actual performed flags. -/
theorem allowed_of_equalities (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (f : Registry I J B)
    (hrecord : record ν V η q ρ anchor geometry value n j s h r=f)
    (hequal : plan.Equalities f) :
    plan.Allowed ν V η q ρ anchor geometry value n j s h r := by
  induction n generalizing j s r with
  | zero =>
    have hpast : ∀a,BeforeGhost j a → r a=f a := by
      rw [← hrecord]
      exact record_agrees_before ν V η q ρ anchor geometry value 0 j s h r
    have hghost : ∀i a,f (.inr (.inl (j,i,a)))=
        (ActualHistoryBirths.ghostSlot h.1.val i a).map (value i) := by
      intro i a
      rw [← hrecord]
      have hh := record_ghostAt ν V η q ρ anchor geometry value 0 j s h r (0:Fin (0+1)) i a
      simpa only [Fin.val_zero,Nat.add_zero,ActualHistoryBirths.ghostAt,Fin.cases_zero] using hh
    have hg := ghost_allowed value plan.pivot r f j (plan.ghostSlots j) h.1.val
      (plan.ghost_bounded j) hpast hghost (plan.ghost_earlier j) (hequal.1 j)
    exact hg
  | succ n ih =>
    have hpast : ∀a,BeforeGhost j a → r a=f a := by
      rw [← hrecord]
      exact record_agrees_before ν V η q ρ anchor geometry value (n+1) j s h r
    have hghost : ∀i a,f (.inr (.inl (j,i,a)))=
        (ActualHistoryBirths.ghostSlot h.1.val i a).map (value i) := by
      intro i a
      rw [← hrecord]
      have hh := record_ghostAt ν V η q ρ anchor geometry value (n+1) j s h r (0:Fin ((n+1)+1)) i a
      simpa only [Fin.val_zero,Nat.add_zero,ActualHistoryBirths.ghostAt,Fin.cases_zero] using hh
    have hg := ghost_allowed value plan.pivot r f j (plan.ghostSlots j) h.1.val
      (plan.ghost_bounded j) hpast hghost (plan.ghost_earlier j) (hequal.1 j)
    refine ⟨hg,?_,?_⟩
    · have hedge : ∀i,f (.inr (.inr (j,i)))=
          (ActualHistoryBirths.freshSlot h.2.1.val i).map (value i) := by
        intro i
        rw [← hrecord]
        have hh := record_freshAt ν V η q ρ anchor geometry value (n+1) j s h r (0:Fin (n+1)) i
        simpa only [Fin.val_zero,Nat.add_zero,ActualHistoryBirths.freshAt,Fin.cases_zero] using hh
      exact edge_allowed value plan.pivot (afterGhost value j h.1.val r) f j (plan.edgeGroups j)
        h.2.1.val (afterGhost_agrees value j h.1.val r f hpast hghost) hedge
        (plan.edge_earlier j) (hequal.2 j)
    · exact ih (j+1) _ h.2.2 _ hrecord

/-- In particular, the initial registry is the literal initial active list,
not an oracle containing the future history. -/
theorem allowed_from_initial (N : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hequal : plan.Equalities (record ν V η q ρ anchor geometry value N 0 s h (initial value s))) :
    plan.Allowed ν V η q ρ anchor geometry value N 0 s h (initial value s) :=
  allowed_of_equalities ν V η q ρ anchor geometry value plan N 0 s h (initial value s) _ rfl hequal

end Elliptic.Operator.PhysicalBirthRegistry
