module

public import Elliptic.Operator.RootLiteralTransfer
public import Elliptic.Operator.RootBoundaryBudget

/-!
# A uniform power saving for the actual growing source root geometry

The grid, position radius, moment padding, prime ceiling, complementary
phases, all source test endpoints, and their curved physical boundary
cover are now the literal constructions. Only the stated external root
count and elementary source cutoff/residue hypotheses remain.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootLiteralPowerTransfer
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootArchimedeanGrid RootGridPartition RootGridMeasure RootGridTransfer
open RootArchimedeanTransfer RootVariableSum RootLiteralGeometry RootLiteralTransfer
open RootBoundaryCover RootBoundaryBudget RootEndpointBudget IntegerRootReplacement
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

theorem primeCeiling_ge_two (L : ℝ) (hL : 0≤L) : 2≤rootPrimeCeiling L := by
  have he : (1:ℝ)≤Real.exp (2*L^(1/5:ℝ)) := Real.one_le_exp (by positivity)
  have hf : 1≤⌊Real.exp (2*L^(1/5:ℝ))⌋₊ :=
    (Nat.le_floor_iff (Real.exp_pos _).le).mpr (by simpa using he)
  unfold rootPrimeCeiling
  omega

theorem eventually_transfer_cost (δ : ℝ) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop, ∀ U V : ℝ, 0≤U*V →
      2*(U*V/(Real.pi^2/6))*x^(-(δ/16000)) + 2*(U*V*x^(-(δ/4000))) ≤
        U*V*x^(-(δ/32000)) := by
  have hc := (tendsto_rpow_atTop (show 0<δ/32000 by positivity)).eventually
    (eventually_ge_atTop (2/(Real.pi^2/6)+2))
  filter_upwards [eventually_ge_atTop (1:ℝ),hc] with x hx hc
  intro U V hUV
  have hx0 : 0<x := by linarith
  have hp : x^(-(δ/4000))≤x^(-(δ/16000)) :=
    Real.rpow_le_rpow_of_exponent_le hx (by linarith)
  calc
    _ ≤ 2*(U*V/(Real.pi^2/6))*x^(-(δ/16000)) +
        2*(U*V*x^(-(δ/16000))) := by gcongr
    _ = U*V*((2/(Real.pi^2/6)+2)*x^(-(δ/16000))) := by ring
    _ ≤ U*V*(x^(δ/32000)*x^(-(δ/16000))) := by gcongr
    _ = _ := by rw [←Real.rpow_add hx0]; congr 2; ring

/-- One threshold controls all later prime alphabets, path lengths,
active labels, dyads, physical scales, residue tests, and endpoint radii.
The actual source cutoff discharges the former first-test scale premise.
The archimedean term is a genuine three-dimensional Lebesgue integral. -/
theorem eventually_source_path_power (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ C_S : ℝ) (hC : 0≤C) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ N : ℕ, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ U V d₀ Y : ℝ, ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V → 0<d₀ → 1≤Y →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) → ∀ exponents : Fin K→ℝ,
      ∀ η ψ : ℝ→ℂ, (∀t, ‖η t‖≤1) → (∀t, ‖ψ t‖≤1) →
      (∀t,η t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin N→Bool, ∀ z : Fin (N+1)→ℤ×ℤ,
      (∀i,z i∈integerPositionBox (rootPositionRadius C (Real.log x))) →
      ∀ a : Fin (N+1)→PhysicalActiveLists P (momentPadding (Real.log x)),
      ∀ ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ, (∀g, ‖ρ g‖≤1) →
      ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1)
          (pathKernel S value μ U V d₀ Y (Real.log x) exponents η ψ major σ adjoint z a ρ) -
        rootIntegral U V S
          (pathKernel S value μ U V d₀ Y (Real.log x) exponents η ψ major σ adjoint z a ρ)‖ ≤
        U*V*x^(-(δ/32000)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_subdivisions δ hδ,
    eventually_variable_root_transfer hPD δ C_S hδ hCS,
    eventually_combinedFaces_small K C δ hC hδ,eventually_transfer_cost δ hδ] with x hx hn ht hb hcost
  intro N P instP U V d₀ Y S inst hU hU' hV hV' hUV hd hY hS hSq hSize
    value μ hv exponents η ψ hη hψ hsupport major hmajor σ adjoint z hz a ρ hρ
  let n := subdivisions δ x
  let R := rootPositionRadius C (Real.log x)
  let Q := rootPrimeCeiling (Real.log x)
  let bad := combinedFaces n (integerPositionBox R) U V
    (sourceEndpoints (J:=momentPadding (Real.log x)) R Q Y (Real.log x) exponents)
  let F := pathKernel S value μ U V d₀ Y (Real.log x) exponents η ψ major σ adjoint z a ρ
  have hx0 : 0<x := by linarith
  have hUp : 0<U := (Real.rpow_pos_of_pos hx0 δ).trans_le hU
  have hVp : 0<V := (Real.rpow_pos_of_pos hx0 δ).trans_le hV
  have hQ : 2≤Q := primeCeiling_ge_two (Real.log x) (Real.log_nonneg hx)
  have hbad : bad⊆grid n := combinedFaces_subset_grid _ _ _ _ _
  have hvolume : coverVolume n bad≤x^(-(δ/16000)) := by
    simpa only [bad,n,R,Q,sourceEndpoints,sourceMultiplierCeiling,momentMultiplicity] using
      hb U V Y exponents hUV hY
  have hF : ∀q g, ‖F q g‖≤1 :=
    pathKernel_norm_le_one S value μ U V d₀ Y (Real.log x) hd exponents η ψ hη hψ
      major hmajor σ adjoint z a ρ hρ
  have hmeas (g) : Measurable (fun q=>F q g) :=
    (pathGeometry_measurable value μ U V d₀ Y (Real.log x) exponents η ψ major σ adjoint z a).mul_const (ρ g)
  have hstable : ∀j∈grid n,j∉bad→∀q,PartContains n j q→∀g,F q g=F (representative n j) g := by
    intro j hj hjbad q hq g
    exact pathKernel_constant_with_cutoff S value μ R Q hK hQ hv d₀ Y (Real.log x)
      exponents hY n j hj U V hUp hVp η ψ hsupport major σ hjbad adjoint z hz a ρ
      q (representative n j) (part_subset_closed n j q hq)
      (part_subset_closed n j _ (representative_mem n hn.1 j)) g
  exact (ht n bad hn.1 hbad hn.2.1 U V (x^(-(δ/16000))) S
    hU hU' hV hV' hvolume hS hSq hSize F (fun j=>F (representative n j)) hF
      (fun j _ g=>hF _ g)
      (averageKernel_integrable S F (fun g=>bounded_measurable_integrable _ (hmeas g) (fun q=>hF q g)))
      hstable).trans (hcost U V (by linarith))

end Elliptic.Operator.RootLiteralPowerTransfer
