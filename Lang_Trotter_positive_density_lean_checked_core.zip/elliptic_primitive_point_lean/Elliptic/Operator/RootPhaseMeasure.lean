module

public import Elliptic.Operator.RootGoodBoundary
public import Elliptic.Operator.NumericGoodState
public import Mathlib.MeasureTheory.Measure.Hausdorff

/-!
# Physical phase distortion of the good-state root measure

The fractional-linear phase has derivative bounded above and below on the
literal physical tau-range. An exact difference identity gives the required
Lipschitz estimates without assuming a change-of-variables formula. The
inverse image estimate follows from Hausdorff measure, which equals
Lebesgue measure on the real line, and a finite cover by unit circle lifts.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootPhaseMeasure
open scoped BigOperators ENNReal
open MeasureTheory Set
open RootGoodBoundary
abbrev Circle := AddCircle (1 : ℝ)
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The exact tau-range supplied by a physical first-coordinate box. -/
def domain (z : ℤ × ℤ) : Set ℝ :=
  {r | 0≤r ∧ r≤1 ∧ 1/16≤latticeTau r z ∧ latticeTau r z≤16}

theorem domain_tau_pos (z : ℤ × ℤ) {r : ℝ} (hr : r∈domain z) : 0<latticeTau r z := by
  have h := hr.2.2.1
  linarith

/-- Uniform expansion and contraction bounds on the whole physical domain. -/
theorem phase_distortion (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    {r s : ℝ} (hr : r∈domain z) (hs : s∈domain z) :
    |phase z w r-phase z w s| ≤ 256*|r-s| ∧
      |r-s| ≤ 256*|phase z w r-phase z w s| := by
  have hrp := domain_tau_pos z hr
  have hsp := domain_tau_pos z hs
  have hprod : 0<latticeTau r z*latticeTau s z := mul_pos hrp hsp
  have hlo : 1/256≤latticeTau r z*latticeTau s z := by
    nlinarith [hr.2.2.1,hs.2.2.1]
  have hhi : latticeTau r z*latticeTau s z≤256 := by
    nlinarith [hr.2.2.2,hs.2.2.2]
  have he := phase_sub z w hzw s r hsp.ne' hrp.ne'
  rw [he,abs_div,abs_of_pos hprod]
  constructor
  · apply (div_le_iff₀ hprod).mpr
    nlinarith [mul_le_mul_of_nonneg_right hlo (abs_nonneg (r-s))]
  · have hh := mul_le_mul_of_nonneg_right hhi (abs_nonneg (r-s))
    rw [← mul_div_assoc]
    apply (le_div_iff₀ hprod).mpr
    nlinarith

/-- Every physical phase image lies within a fixed length-512 interval,
independently of the sizes of the position and its chosen complement. -/
theorem phase_image_interval (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (S : Set ℝ) (hS : S⊆domain z) {r₀ : ℝ} (hr₀ : r₀∈S) :
    phase z w '' S ⊆ Icc (phase z w r₀-256) (phase z w r₀+256) := by
  rintro _ ⟨r,hr,rfl⟩
  have h := (phase_distortion z w hzw (hS hr) (hS hr₀)).1
  have hd : |r-r₀|≤1 := by
    apply abs_le.mpr
    constructor <;> linarith [(hS hr).1,(hS hr).2.1,(hS hr₀).1,(hS hr₀).2.1]
  have ha : |phase z w r-phase z w r₀|≤256 := by linarith
  have hh := abs_le.mp ha
  exact ⟨by linarith,by linarith⟩

/-- The explicit inverse fractional-linear function recovers every point
in the physical domain. -/
theorem endpoint_phase (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    {r : ℝ} (hr : r∈domain z) : endpoint z w (phase z w r)=r :=
  (threshold_eq_endpoint z w hzw r (phase z w r) (domain_tau_pos z hr).ne' rfl).symm

theorem inverse_lipschitz (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (S : Set ℝ) (hS : S⊆domain z) :
    LipschitzOnWith 256 (endpoint z w) (phase z w '' S) := by
  apply LipschitzOnWith.of_dist_le_mul
  rintro _ ⟨r,hr,rfl⟩ _ ⟨s,hs,rfl⟩
  rw [endpoint_phase z w hzw (hS hr),endpoint_phase z w hzw (hS hs)]
  simpa only [Real.dist_eq,NNReal.coe_ofNat] using (phase_distortion z w hzw (hS hr) (hS hs)).2

theorem inverse_image_phase (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (S : Set ℝ) (hS : S⊆domain z) : endpoint z w '' (phase z w '' S)=S := by
  ext x
  constructor
  · rintro ⟨_,⟨r,hr,rfl⟩,rfl⟩
    simpa only [endpoint_phase z w hzw (hS hr)] using hr
  · intro hx
    exact ⟨phase z w x,⟨x,hx,rfl⟩,endpoint_phase z w hzw (hS hx)⟩

/-- An arbitrary subset of the physical domain has measure at most 256
times the measure of its phase image. No measurability assumption is needed. -/
theorem measure_le_phase_image (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (S : Set ℝ) (hS : S⊆domain z) :
    volume S ≤ 256*volume (phase z w '' S) := by
  have h := (inverse_lipschitz z w hzw S hS).hausdorffMeasure_image_le (show (0 : ℝ)≤1 by norm_num)
  rw [hausdorffMeasure_real,ENNReal.rpow_one,inverse_image_phase z w hzw S hS] at h
  exact h

/-- A closed interval of integer length N is covered by N+1 half-open
unit intervals, including its left endpoint without a boundary assumption. -/
theorem unit_interval_cover (a : ℝ) (N : ℕ) :
    Icc a (a+(N : ℝ)) ⊆ ⋃ i : Fin (N+1), Ioc (a+(i : ℝ)-1) (a+(i : ℝ)) := by
  intro r hr
  have hr0 : 0≤r-a := by linarith [hr.1]
  have hn : ⌈r-a⌉₊≤N := Nat.ceil_le.mpr (by linarith [hr.2])
  let i : Fin (N+1) := ⟨⌈r-a⌉₊,Nat.lt_succ_of_le hn⟩
  apply Set.mem_iUnion.mpr
  refine ⟨i,?_,?_⟩
  · have hl := Nat.ceil_lt_add_one hr0
    change a+(⌈r-a⌉₊ : ℝ)-1<r
    linarith
  · have hu := Nat.le_ceil (r-a)
    change r≤a+(⌈r-a⌉₊ : ℝ)
    linarith

/-- One half-open unit lift carries exactly the normalized circle measure. -/
theorem unit_lift_measure (B : Set Circle) (hB : MeasurableSet B) (a : ℝ) :
    volume ((fun r : ℝ => (r : Circle)) ⁻¹' B ∩ Ioc a (a+1)) = volume B :=
  (AddCircle.add_projection_respects_measure 1 a hB).symm

/-- A finite-length lift of a circle set has at most one copy of its mass
per unit interval; the constant is independent of the interval's location. -/
theorem interval_lift_measure_le (B : Set Circle) (hB : MeasurableSet B)
    (a : ℝ) (N : ℕ) :
    volume ((fun r : ℝ => (r : Circle)) ⁻¹' B ∩ Icc a (a+(N : ℝ))) ≤
      (N+1 : ℕ)*volume B := by
  have hs : (fun r : ℝ => (r : Circle)) ⁻¹' B ∩ Icc a (a+(N : ℝ)) ⊆
      ⋃ i : Fin (N+1), ((fun r : ℝ => (r : Circle)) ⁻¹' B ∩ Ioc (a+(i : ℝ)-1) (a+(i : ℝ))) := by
    intro r hr
    obtain ⟨i,hi⟩ := Set.mem_iUnion.mp (unit_interval_cover a N hr.2)
    exact Set.mem_iUnion.mpr ⟨i,hr.1,hi⟩
  refine (measure_mono hs).trans ((measure_iUnion_fintype_le _ _).trans_eq ?_)
  have hu (i : Fin (N+1)) :
      volume ((fun r : ℝ => (r : Circle)) ⁻¹' B ∩ Ioc (a+(i : ℝ)-1) (a+(i : ℝ))) = volume B := by
    have he : a+(i : ℝ)-1+1=a+(i : ℝ) := by ring
    simpa only [he] using unit_lift_measure B hB (a+(i : ℝ)-1)
  simp only [hu,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]

/-- The actual physical-root pullback of an arbitrary measurable circle
exceptional set. This is the bounded-density step used when removing G. -/
theorem physical_bad_measure_le (z w : ℤ × ℤ) (hzw : latticeDet z w=1)
    (B : Set Circle) (hB : MeasurableSet B) :
    volume {r : ℝ | r∈domain z ∧ ((phase z w r : ℝ) : Circle)∈B} ≤
      131328*volume B := by
  let S : Set ℝ := {r | r∈domain z ∧ ((phase z w r : ℝ) : Circle)∈B}
  have hS : S⊆domain z := fun _ h => h.1
  by_cases he : S=∅
  · change volume S≤_
    simp [he]
  obtain ⟨r₀,hr₀⟩ := Set.nonempty_iff_ne_empty.mpr he
  have hrange := phase_image_interval z w hzw S hS hr₀
  have hs : phase z w '' S ⊆ (fun r : ℝ => (r : Circle)) ⁻¹' B ∩
      Icc (phase z w r₀-256) ((phase z w r₀-256)+(512 : ℝ)) := by
    intro t ht
    obtain ⟨r,hr,rfl⟩ := ht
    have hi := hrange ⟨r,hr,rfl⟩
    refine ⟨hr.2,hi.1,?_⟩
    linarith [hi.2]
  calc
    volume S ≤ 256*volume (phase z w '' S) := measure_le_phase_image z w hzw S hS
    _ ≤ 256*volume ((fun r : ℝ => (r : Circle)) ⁻¹' B ∩
        Icc (phase z w r₀-256) ((phase z w r₀-256)+(512 : ℝ))) := by gcongr
    _ ≤ 256*((512+1 : ℕ)*volume B) := by
      gcongr
      exact interval_lift_measure_le B hB _ 512
    _ = _ := by norm_num [← mul_assoc]

/-- All finite source tests define measurable circle exceptional sets. -/
theorem allBadRoots_measurable {K M : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ) (μ : ∀ i, P i → ℝ)
    (d₀ Y L : ℝ) (a : Fin K → ℝ) :
    MeasurableSet (SourceFirstGoodMeasure.allBadRoots value label μ d₀ Y L a) := by
  apply MeasurableSet.union
  · unfold SourceFirstGoodMeasure.badRoots
    exact MeasurableSet.iUnion fun D => MeasurableSet.iUnion fun l =>
      measurableSet_le ((continuous_id.zsmul _).norm.measurable) measurable_const
  · apply MeasurableSet.iUnion
    intro c
    apply measurableSet_le measurable_const
    unfold SourceSecondGoodMeasure.primeExceptionalMass
      SourceSecondGoodMeasure.circleExceptionalMass
    exact Finset.measurable_sum _ fun f _ => measurable_const.indicator
      (SourceSecondGoodMeasure.not_separated_measurable _ _ _)

/-- A physically allowed source position has exactly the tau-domain used
in the distortion estimate. -/
theorem physical_allowed_mem_domain (u v r U W : ℝ) (hU : 0<U)
    (hu : U≤u) (hu' : u≤16*U) (hr : 0≤r) (hr' : r≤1) (z : ℤ × ℤ)
    (hz : sourcePhysicalPositionAllowed u v r U W z) : r∈domain z :=
  ⟨hr,hr',physical_tau_bounds u v r U W hU hu hu' z hz⟩

/-- Literal conjunction of both source tests, with no auxiliary good-state
predicate supplied by a caller. -/
def sourceTests {K M : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ) (μ : ∀ i, P i → ℝ)
    (d₀ Y L : ℝ) (a : Fin K → ℝ) (β : ℝ) : Prop :=
  (∀ D∈SourceSecondGoodState.omissionProducts label d₀,
    SourceGoodState.NoSmallMultiple ((D : ℝ)*β) (Y^(1/5 : ℝ)) (Y^(-(7/10) : ℝ))) ∧
    SourceSecondGoodState.SecondGoodTest value label μ d₀ β L a

/-- Removing either actual source-good-test failure costs no more than
the already measured finite envelope. -/
theorem failed_sourceTests_subset {K M : ℕ} {P : Fin K → Type} [∀ i, Fintype (P i)]
    (value : ∀ i, P i → ℕ) (label : Fin K × Fin M → ℕ) (μ : ∀ i, P i → ℝ)
    (hμ : ∀i p, 0≤μ i p) (d₀ Y L : ℝ) (a : Fin K → ℝ) (z w : ℤ × ℤ) :
    {r : ℝ | r∈domain z ∧ ¬sourceTests value label μ d₀ Y L a (phase z w r)} ⊆
    {r : ℝ | r∈domain z ∧ ((phase z w r : ℝ) : Circle)∈
      SourceFirstGoodMeasure.allBadRoots value label μ d₀ Y L a} := by
  intro r hr
  exact ⟨hr.1,SourceFirstGoodMeasure.allBadRoots_contains value label μ hμ d₀ Y L
    (phase z w r) a hr.2⟩

open Filter GoodStateCounting NumericGoodState in
/-- The physical-root exceptional mass is exponentially small for the
literal numeric prime bands. The threshold is uniform in the active
lists, pad dyad, Y, and determinant-one position and complement. -/
theorem eventually_numeric_physical_bad_small {K : ℕ} (a : Fin K → ℝ)
    (hmono : StrictMono a) (ha : ∀ i, (1/10 : ℝ) ≤ a i) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (active : ∀ i : Fin K, Fin (momentMultiplicity L) → numericPrimeBand L (a i))
        (d₀ Y : ℝ), Real.exp (L^(1/10 : ℝ)) ≤ Y →
      ∀ z w : ℤ × ℤ, latticeDet z w=1 →
      volume {r : ℝ | r∈domain z ∧ ((phase z w r : ℝ) : Circle)∈
        SourceFirstGoodMeasure.allBadRoots
        (fun i => fun p : numericPrimeBand L (a i) => (p : ℕ))
        (fun ij => (active ij.1 ij.2 : ℕ))
        (fun i => bandMass L (a i)) d₀ Y L a} ≤
        ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/8))) := by
  have hgrowth := (Real.tendsto_exp_atTop.comp
    ((tendsto_rpow_atTop (by norm_num : (0 : ℝ)<1/10)).atTop_div_const
      (by norm_num : (0 : ℝ)<8))).eventually_ge_atTop (131328 : ℝ)
  filter_upwards [eventually_numeric_allBadRoots_small a hmono ha, hgrowth] with L h hC
  intro active d₀ Y hY z w hzw
  apply (physical_bad_measure_le z w hzw _ (allBadRoots_measurable _ _ _ _ _ _ _)).trans
  calc
    _ ≤ 131328 * ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/4))) := by
      gcongr
      exact h active d₀ Y hY
    _ = ENNReal.ofReal (131328 * Real.exp (-(L^(1/10 : ℝ)/4))) := by
      rw [ENNReal.ofReal_mul (by norm_num)]
      norm_num
    _ ≤ _ := ENNReal.ofReal_le_ofReal (calc
      _ ≤ Real.exp (L^(1/10 : ℝ)/8)*Real.exp (-(L^(1/10 : ℝ)/4)) := by
        exact mul_le_mul_of_nonneg_right hC (Real.exp_pos _).le
      _ = _ := by rw [← Real.exp_add]; congr 1; ring)

open Filter GoodStateCounting NumericGoodState in
/-- Source-good-state removal in the physical root coordinate for actual
numeric prime bands, stated with the actual tests rather than an envelope. -/
theorem eventually_numeric_failed_sourceTests_small {K : ℕ} (a : Fin K → ℝ)
    (hmono : StrictMono a) (ha : ∀ i, (1/10 : ℝ) ≤ a i) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (active : ∀ i : Fin K, Fin (momentMultiplicity L) → numericPrimeBand L (a i))
        (d₀ Y : ℝ), Real.exp (L^(1/10 : ℝ)) ≤ Y →
      ∀ z w : ℤ × ℤ, latticeDet z w=1 →
      volume {r : ℝ | r∈domain z ∧ ¬sourceTests
        (fun i => fun p : numericPrimeBand L (a i) => (p : ℕ))
        (fun ij => (active ij.1 ij.2 : ℕ))
        (fun i => bandMass L (a i)) d₀ Y L a (phase z w r)} ≤
        ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/8))) := by
  filter_upwards [eventually_numeric_physical_bad_small a hmono ha,
    eventually_bands_nonempty a ha] with L h hfour
  intro active d₀ Y hY z w hzw
  apply (measure_mono (failed_sourceTests_subset _ _ _
    (fun i p => bandMass_nonneg L (a i) (hfour i) p) d₀ Y L a z w)).trans
  exact h active d₀ Y hY z w hzw

end Elliptic.Operator.RootPhaseMeasure
