module
public import Elliptic.Operator.MajorArcProductMeanSquare
public import Elliptic.Operator.MajorArcRealDyadExceptionalEnergy

/-! Arbitrary logarithmic energy saving for the literal three source factors.
Both exceptional energy and product mean square are discharged. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcActualProductEnergy
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation PrimeExceptionalCells ClassicalDerivativeTest
set_option maxHeartbeats 500000

 theorem eventually_actual_product_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ c Cprime Ccoef J E : ℝ) (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime)
    (hcoef : 0≤Ccoef) (hJ : 0≤J) (hE : 0≤E) :
    ∃A : ℝ,0<A ∧ ∀ᶠL : ℝ in atTop,∀K : ℕ,1≤K→(K:ℝ)≤Real.exp (3*L)→
      ∀Hm Hn : ℝ,1≤Hm→Real.exp (δ*L)≤Hn→Hm*Hn≤Real.exp (2*L)→
      (K:ℝ)≤Hm*Hn*L^J→
      ∀a P : ℝ,0<P→c*L^(1/10:ℝ)≤Real.log P→Real.log P≤Cprime*L^(1/5:ℝ)→
      ∀S : Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q : ℕ) (χ : DirichletCharacter ℂ q) (ξ : ℝ),
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^Ccoef)→(∀n∈t,‖β n‖≤L^Ccoef)→
      ∀(k l : ℕ) (χm : DirichletCharacter ℂ k) (χn : DirichletCharacter ℂ l),
      (∀v∈Icc (a+1) (a+(K:ℝ)+1),‖longPolynomial s α Hm χm v‖≤L^(-A))→
      (∫v in (a+1)..(a+(K:ℝ)+1),
        ‖primePolynomial S P χ ξ v*longPolynomial s α Hm χm v*longPolynomial t β Hn χn v‖^2)≤L^(-E) := by
  let Cprod := 4*Ccoef+J+6
  let As := (Cprod+E+1)/2
  let A := Ccoef+(E+2)/2
  have hAs : 0<As := by dsimp [As,Cprod];linarith
  have hA : 0<A := by dsimp [A];linarith
  obtain ⟨Cβ,hCβ,henergy⟩ := MajorArcRealDyadExceptionalEnergy.eventually_actual_exceptional_long_energy
    hvdC δ c Cprime As hδ hc hC hAs.le
  have hms := MajorArcProductMeanSquare.eventually_long_product_mean_square hD δ Ccoef hδ hcoef
  refine ⟨A,hA,?_⟩
  filter_upwards [henergy,hms,eventually_ge_atTop (2:ℝ),eventually_ge_atTop (1+9*Cβ)] with L henergy hms hL hLC
  intro K hK hKmax Hm Hn hm hn hmax hKprod a P hP hlo hhi S hprime hShi q χ ξ s t hs ht α β hα hβ k l χm χn hcancel
  have hLp : 0<L := by linarith
  have hn1 : 1≤Hn := (Real.one_le_exp_iff.mpr (mul_nonneg hδ.le hLp.le)).trans hn
  have hmp : 0<Hm := by linarith
  have hnp : 0<Hn := by linarith
  have hmin : Real.exp (δ*L)≤Hm*Hn := hn.trans (by nlinarith only [hm,hnp])
  have hab : a+1≤a+(K:ℝ)+1 := by have := Nat.cast_nonneg (α:=ℝ) K;linarith
  have hprod := hms Hm Hn hm hn1 hmin hmax s t hs ht α β hα hβ k l χm χn (a+1) (a+(K:ℝ)+1) hab
  have hprod' : (∫v in (a+1)..(a+(K:ℝ)+1),‖longPolynomial s α Hm χm v*longPolynomial t β Hn χn v‖^2)≤L^Cprod := by
    apply hprod.trans
    have hfrac : (a+(K:ℝ)+1-(a+1))/(Hm*Hn)≤L^J := by
      apply (div_le_iff₀ (mul_pos hmp hnp)).mpr
      nlinarith only [hKprod]
    have hJone : 1≤L^J := Real.one_le_rpow (by linarith) hJ
    calc
      _ ≤ L^(4*Ccoef+5)*(L*L^J) := by
        apply mul_le_mul_of_nonneg_left _ (Real.rpow_nonneg hLp.le _)
        nlinarith [mul_nonneg (show 0≤L-2 by linarith) (Real.rpow_nonneg hLp.le J)]
      _ = _ := by
        conv_lhs => rhs;lhs;rw [←Real.rpow_one L]
        rw [←Real.rpow_add hLp,←Real.rpow_add hLp]
        congr 1
        dsimp [Cprod]
        ring
  have hPone : 1≤P := ((Real.log_pos_iff hP.le).mp
    ((mul_pos hc (Real.rpow_pos_of_pos hLp _)).trans_le hlo)).le
  have hcard := PrimeExceptionalEnvelope.prime_card_le S P hPone hprime hShi
  have hprimeNorm : ∀v∈Icc (a+1) (a+(K:ℝ)+1),‖primePolynomial S P χ ξ v‖≤3 := by
    intro v hv
    apply (primePolynomial_norm_le S P hP χ ξ v).trans
    exact (div_le_iff₀ hP).mpr (by nlinarith only [hcard])
  have hlarge := henergy K hK hKmax Hn hn a P hP hlo hhi S hprime hShi q χ ξ
    (L^Ccoef) (Real.rpow_nonneg hLp.le _) t ht β hβ l χn
  have hsplit := MajorArcFrequencySplit.product_energy_split (primePolynomial S P χ ξ)
    (longPolynomial s α Hm χm) (longPolynomial t β Hn χn)
    (primePolynomial_continuous S P χ ξ) (longPolynomial_continuous s α Hm χm)
    (longPolynomial_continuous t β Hn χn) (a+1) (a+(K:ℝ)+1) hab (L^(-As)) 3 (L^(-A))
    (Real.rpow_nonneg hLp.le _) (by norm_num) (Real.rpow_nonneg hLp.le _) hprimeNorm hcancel
  have hs : (L^(-As))^2*L^Cprod=L^(-E-1) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_add hLp]
    congr 1
    dsimp [As]
    norm_num
    ring
  have hl : (3:ℝ)^2*(L^(-A))^2*(Cβ*(L^Ccoef)^2*L)=9*Cβ*L^(-E-1) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_mul_natCast hLp.le]
    calc
      _ = 9*Cβ*((L^((-A)*(2:ℕ)))*L^(Ccoef*(2:ℕ))*L^(1:ℝ)) := by rw [Real.rpow_one];ring
      _ = _ := by
        rw [←Real.rpow_add hLp,←Real.rpow_add hLp]
        congr 2
        dsimp [A]
        norm_num
        ring
  calc
    _ ≤ (L^(-As))^2*L^Cprod+(3:ℝ)^2*(L^(-A))^2*(Cβ*(L^Ccoef)^2*L) :=
      hsplit.trans (add_le_add (mul_le_mul_of_nonneg_left hprod' (sq_nonneg _))
        (mul_le_mul_of_nonneg_left hlarge (by positivity)))
    _ = (1+9*Cβ)*L^(-E-1) := by rw [hs,hl];ring
    _ ≤ L*L^(-E-1) := mul_le_mul_of_nonneg_right hLC (Real.rpow_nonneg hLp.le _)
    _ = L^(-E) := by
      conv_lhs => lhs;rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 1
      ring

end Elliptic.Operator.MajorArcActualProductEnergy
