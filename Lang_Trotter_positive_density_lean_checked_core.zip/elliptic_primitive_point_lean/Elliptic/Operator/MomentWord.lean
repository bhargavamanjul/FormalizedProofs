module

public import Elliptic.Operator.KernelComposition

/-!
# Norm of the actual alternating ghost/edge word

This is the finite operator deduction in source (4.54).  It acts on actual
coefficient vectors using measured kernels.  The estimates for its concrete
ghost and edge kernels must be proved separately; no source memory or
moment conclusion is assumed here.
-/

@[expose] public section
namespace Elliptic.Operator
open scoped BigOperators

/-- The actual word `G₀ E₀ G₁ ... E_(N-1) G_N`, with each kernel paired
with its proved bound. -/
def ghostEdgeWord {ι : Type*} (G E : ℕ → ι → ι → ℂ)
    (Cghost : ℝ) (Cedge : ℕ → ℝ) : ℕ → List ((ι → ι → ℂ) × ℝ)
  | 0 => [(G 0, Cghost)]
  | N + 1 => ghostEdgeWord G E Cghost Cedge N ++ [(E N, Cedge N), (G (N+1), Cghost)]

theorem ghostEdgeWord_constants {ι : Type*} (G E : ℕ → ι → ι → ℂ)
    (Cghost : ℝ) (Cedge : ℕ → ℝ) (N : ℕ) :
    ((ghostEdgeWord G E Cghost Cedge N).map Prod.snd).prod =
      Cghost ^ (N+1) * ∏ j ∈ Finset.range N, Cedge j := by
  induction N with
  | zero => simp [ghostEdgeWord]
  | succ N ih =>
    simp only [ghostEdgeWord, List.map_append, List.prod_append, List.map_cons,
      List.prod_cons, List.map_nil, List.prod_nil, mul_one, ih,
      Finset.prod_range_succ, pow_succ]
    ring

theorem ghostEdgeWord_entries {ι : Type*} (s : Finset ι) (μ : ι → ℝ)
    (G E : ℕ → ι → ι → ℂ) (Cghost : ℝ) (Cedge : ℕ → ℝ) (N : ℕ)
    (hghost : 0 ≤ Cghost)
    (hG : ∀ j ≤ N, FiniteKernelBound s s μ μ (G j) Cghost)
    (hE : ∀ j < N, 0 ≤ Cedge j ∧ FiniteKernelBound s s μ μ (E j) (Cedge j)) :
    ∀ entry ∈ ghostEdgeWord G E Cghost Cedge N,
      0 ≤ entry.2 ∧ FiniteKernelBound s s μ μ entry.1 entry.2 := by
  induction N with
  | zero =>
    intro entry hentry
    simp only [ghostEdgeWord, List.mem_singleton] at hentry
    subst entry
    exact ⟨hghost, hG 0 le_rfl⟩
  | succ N ih =>
    intro entry hentry
    simp only [ghostEdgeWord, List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hentry
    rcases hentry with hentry | rfl | rfl
    · exact ih (fun j hj => hG j (hj.trans (Nat.le_succ N)))
        (fun j hj => hE j (hj.trans_le (Nat.le_succ N))) entry hentry
    · exact hE N (Nat.lt_succ_self N)
    · exact ⟨hghost, hG (N+1) le_rfl⟩

/-- Actual word norm with the exact product of edge constants. -/
theorem ghostEdgeWord_bound {ι : Type*} (s : Finset ι) (μ : ι → ℝ)
    (G E : ℕ → ι → ι → ℂ) (Cghost : ℝ) (Cedge : ℕ → ℝ) (N : ℕ)
    (hghost : 0 ≤ Cghost)
    (hG : ∀ j ≤ N, FiniteKernelBound s s μ μ (G j) Cghost)
    (hE : ∀ j < N, 0 ≤ Cedge j ∧ FiniteKernelBound s s μ μ (E j) (Cedge j))
    (b : ι → ℂ) :
    finiteL2 s μ (finiteKernelWordApply s μ (ghostEdgeWord G E Cghost Cedge N) b) ≤
      (Cghost ^ (N+1) * ∏ j ∈ Finset.range N, Cedge j) * finiteL2 s μ b := by
  have h := finiteKernelWordApply_bound s μ (ghostEdgeWord G E Cghost Cedge N)
    (ghostEdgeWord_entries s μ G E Cghost Cedge N hghost hG hE) b
  rwa [ghostEdgeWord_constants] at h

theorem edge_constant_product {N : ℕ} (modified : Finset ℕ) (good bad : ℝ) :
    (∏ j ∈ Finset.range N, if j ∈ modified then bad else good) =
      bad ^ ((Finset.range N).filter (fun j => j ∈ modified)).card *
        good ^ (N - ((Finset.range N).filter (fun j => j ∈ modified)).card) := by
  classical
  rw [Finset.prod_ite]
  simp only [Finset.prod_const]
  have hcard := Finset.card_filter_add_card_filter_not (s := Finset.range N)
    (p := fun j => j ∈ modified)
  have heq : ((Finset.range N).filter (fun j => j ∉ modified)).card =
      N - ((Finset.range N).filter (fun j => j ∈ modified)).card := by
    simp only [Finset.card_range] at hcard
    omega
  rw [heq]

/-- At most `2r` modified edges pay the crude bound; all other edges retain
their contraction. This is valid even when `2r>N`, with natural subtraction.
-/
theorem edge_constant_product_le {N r : ℕ} (modified : Finset ℕ) (good bad : ℝ)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hbad : 1 ≤ bad)
    (hmodified : ((Finset.range N).filter (fun j => j ∈ modified)).card ≤ 2*r) :
    (∏ j ∈ Finset.range N, if j ∈ modified then bad else good) ≤
      good ^ (N-2*r) * bad ^ (2*r) := by
  rw [edge_constant_product]
  have hfirst := pow_le_pow_right₀ hbad hmodified
  have hsecond := pow_le_pow_of_le_one hgood hgood1 (Nat.sub_le_sub_left hmodified N)
  calc
    _ ≤ bad ^ (2*r) * good ^ (N-2*r) :=
      mul_le_mul hfirst hsecond (pow_nonneg hgood _) (pow_nonneg (by linarith) _)
    _ = _ := mul_comm _ _

/-- The actual boundary matrix element has the source (4.54) bound once
the concrete ghost, unmodified edge, and modified edge norms are supplied.
The rank restriction is counted on the actual modified edge indices. -/
theorem ghostEdgeWord_boundary_bound {ι : Type*} (s : Finset ι) (μ : ι → ℝ)
    (hμ : ∀ i ∈ s, 0 ≤ μ i) (G E : ℕ → ι → ι → ℂ)
    (Cghost good bad : ℝ) (N r : ℕ) (modified : Finset ℕ)
    (hghost : 0 ≤ Cghost) (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hbad : 1 ≤ bad)
    (hG : ∀ j ≤ N, FiniteKernelBound s s μ μ (G j) Cghost)
    (hE : ∀ j < N, FiniteKernelBound s s μ μ (E j)
      (if j ∈ modified then bad else good))
    (hmodified : ((Finset.range N).filter (fun j => j ∈ modified)).card ≤ 2*r)
    (a b : ι → ℂ) :
    ‖∑ i ∈ s, (μ i : ℂ) * a i *
        finiteKernelWordApply s μ
          (ghostEdgeWord G E Cghost (fun j => if j ∈ modified then bad else good) N) b i‖ ≤
      (Cghost ^ (N+1) * good ^ (N-2*r) * bad ^ (2*r)) *
        finiteL2 s μ a * finiteL2 s μ b := by
  have hconst : ∀ j < N, 0 ≤ (if j ∈ modified then bad else good) := by
    intro j hj
    split_ifs <;> linarith
  have hword := ghostEdgeWord_bound s μ G E Cghost
    (fun j => if j ∈ modified then bad else good) N hghost hG
    (fun j hj => ⟨hconst j hj, hE j hj⟩) b
  have hprod := edge_constant_product_le modified good bad hgood hgood1 hbad hmodified
  calc
    _ ≤ finiteL2 s μ a * finiteL2 s μ
        (finiteKernelWordApply s μ
          (ghostEdgeWord G E Cghost (fun j => if j ∈ modified then bad else good) N) b) :=
      finite_measured_pairing_le s μ hμ a _
    _ ≤ finiteL2 s μ a *
        ((Cghost ^ (N+1) * ∏ j ∈ Finset.range N,
          if j ∈ modified then bad else good) * finiteL2 s μ b) :=
      mul_le_mul_of_nonneg_left hword (Real.sqrt_nonneg _)
    _ ≤ finiteL2 s μ a *
        ((Cghost ^ (N+1) * (good ^ (N-2*r) * bad ^ (2*r))) * finiteL2 s μ b) := by
      apply mul_le_mul_of_nonneg_left _ (Real.sqrt_nonneg _)
      apply mul_le_mul_of_nonneg_right _ (Real.sqrt_nonneg _)
      exact mul_le_mul_of_nonneg_left hprod (pow_nonneg hghost _)
    _ = _ := by ring

end Elliptic.Operator
