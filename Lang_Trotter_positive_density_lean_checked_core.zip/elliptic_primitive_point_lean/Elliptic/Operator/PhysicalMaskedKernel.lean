module

public import Elliptic.Operator.EdgeMaskedAdjoint

/-!
# Full physical bag kernel with exact store/promotion masks

This kernel retains positions, ordered active lists, both endpoint
permutations, the actual factorial bag measure, and the total cutoff.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskedKernel
open scoped BigOperators
open PhysicalEdgeAdjoint
attribute [local instance] Classical.propDecidable
local instance maskedKernelDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {G Z : Type*} [Fintype G]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

abbrev Bags := ∀ i, MemoryBag (AnchoredParticle (P i) (Line i)) B
abbrev State := Z × (PhysicalActiveLists P J × Bags (P:=P) (Line:=Line) (B:=B))
abbrev Permutations := G → Equiv.Perm (Fin (J+1))

def position (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : Z := s.1
def active (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : PhysicalActiveLists P J := s.2.1
def bags (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : Bags (P:=P) (Line:=Line) (B:=B) := s.2.2

def ofOrdered (s : PhysicalMemoryState (Z:=Z) P Line J B) : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) :=
  (s.position P Line J B, s.active P Line J B, fun i => memoryBagOf (s.memory P Line J B i))

def Total (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : Prop :=
  (∑ i, (bags s i).val.card) ≤ B

theorem total_ofOrdered (s : PhysicalMemoryState (Z:=Z) P Line J B) : Total (ofOrdered s) := by
  simpa only [Total,ofOrdered,bags,memoryBagOf_card,PhysicalMemoryState.memory] using s.property

/-- Literal active-prime times factorial-bag measure. -/
def mass {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : R :=
  ∏ i, tupleWeight (ν i) (active s i) * memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (bags s i)

/-- The unshared active prime and actual memory bag in each group. -/
def unshared (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π : Permutations (G:=G) (J:=J)) : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) :=
  fun i => (active s i (π i (Fin.last J)),bags s i)

def sharedMass {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π : Permutations (G:=G) (J:=J)) : R :=
  ∏ i, ∏ j : Fin J, ν i (active s i (π i j.castSucc))

/-- Reordering all active slots preserves their actual product weight. -/
theorem active_mass_split {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π : Permutations (G:=G) (J:=J)) :
    mass ν s = sharedMass ν s π * groupedBagMass ν (unshared s π) := by
  unfold mass sharedMass groupedBagMass unshared
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  have hs : tupleWeight (ν i) (active s i) =
      (∏ j : Fin J, ν i (active s i (π i j.castSucc))) * ν i (active s i (π i (Fin.last J))) := by
    rw [← Fin.prod_univ_castSucc (fun j => ν i (active s i (π i j)))]
    exact (Equiv.prod_comp (π i) (fun j => ν i (active s i j))).symm
  rw [hs]
  ring

/-- Both permuted active lists have exactly the same retained slots. -/
def Shared
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) : Prop :=
  ∀ i (j : Fin J), active s i (π i j.castSucc) = active t i (τ i j.castSucc)

theorem shared_symm
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) : Shared s t π τ ↔ Shared t s τ π := by
  constructor <;> intro h i j <;> exact (h i j).symm

theorem sharedMass_eq {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) (h : Shared s t π τ) :
    sharedMass ν s π = sharedMass ν t τ := by
  unfold sharedMass
  apply Finset.prod_congr rfl
  intro i _
  apply Finset.prod_congr rfl
  intro j _
  rw [h i j]

/-- One fully specified pair of endpoint permutations. -/
def term {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) : R :=
  if Shared s t π τ then
    geometry (position s) (fun i j => active s i (π i j))
      (position t) (fun i j => active t i (τ i j)) *
    groupedMaskedBagKernel ν store promote S I (anchor (position s)) (anchor (position t))
      (fun i => bagSurvival (anchor (position s) i) ρ)
      (fun i => bagSurvival (anchor (position t) i) ρ) (unshared s π) (unshared t τ)
  else 0

/-- Pointwise balance for actual positions and both ordered active lists. -/
theorem term_balance {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) :
    mass ν s * term ν store promote S I ρ anchor geometry s t π τ =
    mass ν t * term ν promote store I S ρ anchor (fun z a w b => geometry w b z a) t s τ π := by
  by_cases hs : Shared s t π τ
  · have ht := (shared_symm s t π τ).mp hs
    simp only [term,ite_eq_left hs,ite_eq_left ht]
    rw [active_mass_split ν s π,active_mass_split ν t τ,sharedMass_eq ν s t π τ hs]
    have h := groupedMaskedBagKernel_balance ν hν store promote S I
      (anchor (position s)) (anchor (position t))
      (fun i => bagSurvival (anchor (position s) i) ρ)
      (fun i => bagSurvival (anchor (position t) i) ρ) (unshared s π) (unshared t τ)
    linear_combination (sharedMass ν t τ * geometry (position s) (fun i j => active s i (π i j))
      (position t) (fun i j => active t i (τ i j))) * h
  · have ht : ¬Shared t s τ π := fun h => hs ((shared_symm s t π τ).mpr h)
    simp only [term,ite_eq_right hs,ite_eq_right ht,mul_zero]

/-- Full physical matrix with the exact endpoint average and total cutoff. -/
def kernel {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : R :=
  if Total s ∧ Total t then
    (Fintype.card (Permutations (G:=G) (J:=J)) : R)⁻¹ ^ 2 *
      ∑ π : Permutations (G:=G) (J:=J), ∑ τ : Permutations (G:=G) (J:=J),
        term ν store promote S I ρ anchor geometry s t π τ
  else 0

/-- Full measured reversal, including both endpoint averages, all positions,
ordered active slots, exact masks, and the single total memory cutoff. -/
theorem kernel_balance {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    mass ν s * kernel ν store promote S I ρ anchor geometry s t =
    mass ν t * kernel ν promote store I S ρ anchor (fun z a w b => geometry w b z a) t s := by
  by_cases hc : Total s ∧ Total t
  · have hc' : Total t ∧ Total s := ⟨hc.2,hc.1⟩
    simp only [kernel,ite_eq_left hc,ite_eq_left hc']
    rw [mul_left_comm (mass ν s),mul_left_comm (mass ν t)]
    apply congrArg (_ * ·)
    simp only [Finset.mul_sum]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro τ _
    apply Finset.sum_congr rfl
    intro π _
    exact term_balance ν hν store promote S I ρ anchor geometry s t π τ
  · have hc' : ¬(Total t ∧ Total s) := fun h => hc ⟨h.2,h.1⟩
    simp [kernel,hc,hc']

/-- Bilinear adjunction for arbitrary coupled tests on the full finite
physical bag space. The identification with the indexed physical action is
proved separately, rather than imposed as a hypothesis. -/
theorem kernel_adjoint [Fintype Z] {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (F H : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R) :
    (∑ s, mass ν s * H s * ∑ t, kernel ν store promote S I ρ anchor geometry s t * F t) =
    ∑ t, mass ν t * F t * ∑ s,
      kernel ν promote store I S ρ anchor (fun z a w b => geometry w b z a) t s * H s := by
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t _
  apply Finset.sum_congr rfl
  intro s _
  have h := kernel_balance ν hν store promote S I ρ anchor geometry s t
  linear_combination (F t * H s) * h

end Elliptic.Operator.PhysicalMaskedKernel
