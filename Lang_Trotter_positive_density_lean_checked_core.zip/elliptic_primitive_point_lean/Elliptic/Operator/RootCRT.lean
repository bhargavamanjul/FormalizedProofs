module

public import Elliptic.Operator.RootResidues
public import Mathlib.Data.ZMod.QuotientRing

/-!
# Actual Chinese remaindering of root matrices

The uniform independent-line identity here starts with matrices modulo
the product of distinct primes, rather than assuming independent matrices
as an input. It is an exact finite identity for an arbitrary coupled test
function and an arbitrary finite prime family.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator.RootResidues
open scoped BigOperators LinearAlgebra.Projectivization

def sl2RingEquiv {R S : Type*} [CommRing R] [CommRing S] (e : R ≃+* S) :
    Matrix.SpecialLinearGroup (Fin 2) R ≃ Matrix.SpecialLinearGroup (Fin 2) S where
  toFun := Matrix.SpecialLinearGroup.map e.toRingHom
  invFun := Matrix.SpecialLinearGroup.map e.symm.toRingHom
  left_inv g := by
    ext i j
    change e.symm (e (g i j)) = g i j
    exact e.symm_apply_apply _
  right_inv g := by
    ext i j
    change e (e.symm (g i j)) = g i j
    exact e.apply_symm_apply _

def sl2PiEquiv {ι : Type*} (R : ι → Type*) [∀ i, CommRing (R i)] :
    Matrix.SpecialLinearGroup (Fin 2) (∀ i, R i) ≃
      (∀ i, Matrix.SpecialLinearGroup (Fin 2) (R i)) where
  toFun g i := Matrix.SpecialLinearGroup.map (Pi.evalRingHom R i) g
  invFun g := ⟨Matrix.of fun a b i => (g i).val a b, by
    rw [Matrix.det_fin_two]
    funext i
    have h := (g i).property
    rw [Matrix.det_fin_two] at h
    exact h⟩
  left_inv g := by ext i j; rfl
  right_inv g := by funext i; ext a b; rfl

/-- The actual CRT equivalence, evaluated entrywise on determinant-one
matrices. Pairwise coprimality is enough for this algebraic step. -/
def sl2CRT {ι : Type*} [Fintype ι] (p : ι → ℕ)
    (hp : Pairwise (fun i j => (p i).Coprime (p j))) :
    Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i)) ≃
      (∀ i, Matrix.SpecialLinearGroup (Fin 2) (ZMod (p i))) :=
  (sl2RingEquiv (ZMod.prodEquivPi p hp)).trans (sl2PiEquiv (fun i => ZMod (p i)))

/-- The CRT image is the ordinary reduction of each matrix entry. -/
theorem sl2CRT_entry {ι : Type*} [Fintype ι] (p : ι → ℕ)
    (hp : Pairwise (fun i j => (p i).Coprime (p j)))
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i))) (i : ι)
    (a b : Fin 2) :
    sl2CRT p hp g i a b =
      ZMod.castHom (Finset.dvd_prod_of_mem p (Finset.mem_univ i)) (ZMod (p i)) (g a b) := by
  change (ZMod.prodEquivPi p hp) (g.val a b) i = _
  exact ZMod.prodEquivPi_apply p hp (g a b) i

/-- For an actual integral root matrix and integral position vector,
the kernel-line test is exactly divisibility of its first physical
coordinate by the marked prime. -/
theorem reduced_kernel_membership (p : ℕ) [Fact p.Prime]
    (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (z : Fin 2 → ℤ) :
    (fun i => (z i : ZMod p)) ∈
      (kernelLine (ZMod p)
        (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod p)) g)).submodule ↔
      (p : ℤ) ∣ g 0 0 * z 0 + g 0 1 * z 1 := by
  rw [mem_kernelLine_iff]
  change (g 0 0 : ZMod p) * (z 0 : ZMod p) +
    (g 0 1 : ZMod p) * (z 1 : ZMod p) = 0 ↔ _
  rw [← Int.cast_mul, ← Int.cast_mul, ← Int.cast_add]
  exact ZMod.intCast_zmod_eq_zero_iff_dvd _ _

/-- An exact normalized root-residue average over a squarefree modulus
equals independent uniform averaging over the `p+1` projective lines at
each prime. No bound depends on the test function or size of the family. -/
theorem crt_kernel_average {ι : Type*} [Fintype ι] [DecidableEq ι]
    (p : ι → ℕ) [∀ i, Fact (p i).Prime]
    (hp : Pairwise (fun i j => (p i).Coprime (p j)))
    [Fintype (ZMod (∏ i, p i))]
    [∀ i, Fintype (ℙ (ZMod (p i)) (Fin 2 → ZMod (p i)))]
    (f : (∀ i, ℙ (ZMod (p i)) (Fin 2 → ZMod (p i))) → ℂ) :
    (∑ g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i)),
        f (fun i => kernelLine (ZMod (p i)) (sl2CRT p hp g i))) /
        (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏ i, p i))) : ℂ) =
      (∑ ℓ : (∀ i, ℙ (ZMod (p i)) (Fin 2 → ZMod (p i))), f ℓ) /
        ((∏ i, (p i + 1)) : ℕ) := by
  have he := Equiv.sum_comp (sl2CRT p hp)
    (fun g => f (fun i => kernelLine (ZMod (p i)) (g i)))
  rw [he, Fintype.card_congr (sl2CRT p hp)]
  simpa only [ZMod.card] using kernel_family_average (fun i => ZMod (p i)) f

end Elliptic.Operator.RootResidues
