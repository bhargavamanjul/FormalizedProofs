module

public import Elliptic.Operator.GoodStateAsymptotics

/-!
# The good-state estimate for the actual numeric prime bands

The band-card and normalization hypotheses of the abstract finite-family
estimate are discharged from the literal source bands. Nonemptiness uses
Bertrand's theorem; the final measure bound is uniform in source lists,
Y and the pad dyad after fixing the ordered exponents.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.NumericGoodState
open scoped BigOperators Topology ENNReal
open Filter MeasureTheory
open GoodStateCounting GoodStateAsymptotics SourceFirstGoodMeasure
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The source reciprocal-prime normalizer, literally over the full band. -/
def bandV (L a : ℝ) : ℝ := ∑ p ∈ numericPrimeBand L a, 1/(p : ℝ)

def bandMass (L a : ℝ) (p : numericPrimeBand L a) : ℝ := 1/(bandV L a * (p : ℝ))

theorem bandV_pos (L a : ℝ) (hfour : 4≤Real.exp (L^a)) : 0<bandV L a := by
  apply Finset.sum_pos'
  · intro p hp
    positivity
  · obtain ⟨p,hp⟩ := numericPrimeBand_nonempty L a hfour
    refine ⟨p,hp,?_⟩
    have hpp : (0 : ℝ)<p := by exact_mod_cast ((mem_numericPrimeBand L a p).mp hp).1.pos
    positivity

theorem bandMass_nonneg (L a : ℝ) (hfour : 4≤Real.exp (L^a))
    (p : numericPrimeBand L a) : 0≤bandMass L a p := by
  have hv := bandV_pos L a hfour
  unfold bandMass
  positivity

theorem bandMass_sum (L a : ℝ) (hfour : 4≤Real.exp (L^a)) :
    (∑ p : numericPrimeBand L a, bandMass L a p) = 1 := by
  have hv := bandV_pos L a hfour
  unfold bandMass
  simp_rw [← one_div_mul_one_div]
  rw [← Finset.mul_sum]
  have hs : (∑ p : numericPrimeBand L a, 1/(p : ℝ)) = bandV L a :=
    Finset.sum_coe_sort (numericPrimeBand L a) (fun p : ℕ => 1/(p : ℝ))
  rw [hs]
  field_simp

theorem eventually_bands_nonempty {K : ℕ} (a : Fin K → ℝ)
    (ha : ∀ i, (1/10 : ℝ) ≤ a i) :
    ∀ᶠ L : ℝ in atTop, ∀ i, 4≤Real.exp (L^a i) := by
  have h := (Real.tendsto_exp_atTop.comp
    (tendsto_rpow_atTop (by norm_num : (0 : ℝ)<1/10))).eventually_ge_atTop 4
  filter_upwards [h,eventually_ge_atTop (1 : ℝ)] with L h hL
  intro i
  exact h.trans (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (ha i)))

/-- The literal source bands and original probability law satisfy the
full exponentially small bad-root bound. There is no band-card estimate,
normalization, bad-root estimate or good-state premise left to supply. -/
theorem eventually_numeric_allBadRoots_small {K : ℕ} (a : Fin K → ℝ)
    (hmono : StrictMono a) (ha : ∀ i, (1/10 : ℝ) ≤ a i) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (active : ∀ i : Fin K, Fin (momentMultiplicity L) → numericPrimeBand L (a i))
        (d₀ Y : ℝ), Real.exp (L^(1/10 : ℝ)) ≤ Y →
      volume (allBadRoots
        (fun i => fun p : numericPrimeBand L (a i) => (p : ℕ))
        (fun ij => (active ij.1 ij.2 : ℕ))
        (fun i => bandMass L (a i)) d₀ Y L a) ≤
        ENNReal.ofReal (Real.exp (-(L^(1/10 : ℝ)/4))) := by
  filter_upwards [eventually_allBadRoots_small a hmono ha, eventually_bands_nonempty a ha] with L h hfour
  intro active d₀ Y hY
  apply h (fun i => numericPrimeBand L (a i))
    (fun i => fun p : numericPrimeBand L (a i) => (p : ℕ))
    (fun ij => (active ij.1 ij.2 : ℕ)) (fun i => bandMass L (a i)) d₀ Y hY
  · intro ij
    exact ((mem_numericPrimeBand L (a ij.1) (active ij.1 ij.2)).mp (active ij.1 ij.2).property).1
  · intro i p
    exact ((mem_numericPrimeBand L (a i) p).mp p.property).1.ne_zero
  · exact fun i p => bandMass_nonneg L (a i) (hfour i) p
  · exact fun i => bandMass_sum L (a i) (hfour i)
  · intro i
    simpa using numericPrimeBand_card_le L (a i)

end Elliptic.Operator.NumericGoodState
