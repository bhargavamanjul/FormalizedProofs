module

public import Elliptic.Operator.PhysicalRawGlobalRow
public import Elliptic.Operator.PhysicalMaskScaling
public import Elliptic.Operator.CountingKernelSchur

/-!
# Two-sided Schur estimate for each literal raw physical mask

Both counting rows are derived from the source second-good test. The
opposite measured column is supplied by the proved literal adjunction,
with its fixed V-factor and exchanged store/promotion masks. The resulting
bound gives the four raw mask cases in the source proof.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRawSchur
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalRawMaskedRow PhysicalRawGlobalRow PhysicalMaskScaling
attribute [local instance] Classical.propDecidable
local instance rawSchurDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable [Fintype Z] [∀ i, Fintype (P i)]
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable [∀ i p, Fintype (ZMod (value i p))]

/-- The exact actual raw physical matrix at a fixed store/promotion mask. -/
def rawKernel
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (S I : Fin K → Bool) (ρ : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=fun i p => Option (ZMod (value i p))) (J:=J) (B:=B)) : ℂ :=
  originalKernel ν V S I ρ (anchor value position)
    (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c) s t

/-- Actual raw operator bound for every store/promotion mask. No forward
row, opposite row, or adjoint identity is an additional hypothesis. -/
theorem masked_raw_schur
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool)
    (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ=1 ∨ σ= -1)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hgood : GoodProjection value μ d₀ r L a good)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p:ℝ))
    (hνμ : ∀ i p, ν i p ≤ 2*μ i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hM : 0 ≤ M) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z b w c, sourceRawAllowed value good u v r U W d₀ σ z b w c → ‖amplitude z b w c‖ ≤ A)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p => Option (ZMod (value i p))) (J:=J) (B:=B) → ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s => ∑ t, rawKernel value position ν V S I ρ good u v r U W d₀ σ amplitude s t * F t) ≤
    Real.sqrt ((A * budget K J B ρ v0 vmin M L a I) *
      (reverseFactor V I S * A * budget K J B ρ v0 vmin M L a S)) *
      finiteL2 Finset.univ (mass ν) F := by
  let geometry := fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c
  let C := reverseFactor V I S
  have hVp : ∀ i, 0 < V i := fun i => hmin.trans_le (hV i)
  have hC : 0 < C := reverseFactor_pos V hVp I S
  let reverse := fun s t => (C:ℂ) * originalKernel (B:=B) ν V I S ρ (anchor value position)
    (fun z b w c => geometry w c z b) s t
  have hamp' : ∀ z b w c, sourceRawAllowed value good u v r U W d₀ σ z b w c →
      ‖amplitude w c z b‖ ≤ A := by
    intro z b w c hc
    exact hamp w c z b ((sourceRawAllowed_swap value good u v r U W d₀ σ z b w c).mp hc)
  have hg : (fun z b w c => geometry w c z b) =
      (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ
        (fun z b w c => amplitude w c z b) (position z) b (position w) c) := by
    funext z b w c
    exact sourceRawGeometry_swap value good u v r U W d₀ σ amplitude _ _ _ _
  apply countingKernel_schur (mass ν) (weight v0)
    (rawKernel value position ν V S I ρ good u v r U W d₀ σ amplitude) reverse
    (A * budget K J B ρ v0 vmin M L a I)
    (C * A * budget K J B ρ v0 vmin M L a S)
    (mass_pos ν hνpos) (weight_pos hv0)
    (mul_nonneg hA (budget_nonneg K J B ρ v0 vmin M L a I hρ1 hv0 hmin hM))
    (mul_nonneg (mul_nonneg hC.le hA) (budget_nonneg K J B ρ v0 vmin M L a S hρ1 hv0 hmin hM))
  · intro s t
    have h := original_norm_balance ν hνpos V hVp S I ρ (anchor value position) geometry s t
    simpa only [rawKernel,reverse,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hC] using h
  · intro s
    have h := PhysicalRawGlobalRow.row_le value position hposition hprime ν μ hνpos V S I
      ρ v0 vmin M L A a good u v r U W d₀ σ hU hσ amplitude hgood hband hνμ
      hV hmin hρ0 hρ1 hv0 hM hA hmass hamp s
    apply (le_of_eq ?_).trans h
    unfold row rawKernel
    apply Finset.sum_congr
    · ext t
      simp only [Finset.mem_univ]
    · intro t _
      rfl
  · intro s
    have h := PhysicalRawGlobalRow.row_le value position hposition hprime ν μ hνpos V I S
      ρ v0 vmin M L A a good u v r U W d₀ σ hU hσ (fun z b w c => amplitude w c z b)
      hgood hband hνμ hV hmin hρ0 hρ1 hv0 hM hA hmass hamp' s
    simp only [reverse,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hC]
    simp_rw [mul_assoc]
    rw [← Finset.mul_sum,hg]
    have hh := mul_le_mul_of_nonneg_left h hC.le
    apply (le_of_eq ?_).trans (hh.trans_eq (by ring))
    apply congrArg (fun x : ℝ => C * x)
    unfold row
    apply Finset.sum_congr
    · ext t
      simp only [Finset.mem_univ]
    · intro t _
      rfl

end Elliptic.Operator.PhysicalRawSchur
