module

public import Elliptic.Operator.OriginalIndependentBoundary

/-! The unnormalized physical position moment is an exact closed-position
path sum. Active lists at the two ends remain independently summed. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootedMoment
open scoped BigOperators ComplexConjugate
open OriginalLifespanSchedule
attribute [local instance] Classical.propDecidable
local instance rootedMomentDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I Z:Type} [Fintype I] [Fintype Z]
variable {P:I→Type} [∀i,Fintype (P i)] {J N:ℕ}

abbrev State := Z×PhysicalActiveLists P J
abbrev Perms := ∀i:I,Equiv.Perm (Fin (J+1))

def initialMass (V:I→ℝ):ℝ := ∏i,(V i)⁻¹^(J+1)
def edgeMass (V:I→ℝ):ℝ := endpointPermutationWeight I J * ∏i,(V i)⁻¹

def row (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (x y:State (Z:=Z) (P:=P) (J:=J)):ℂ :=
  (edgeMass (J:=J) V:ℂ)*∑π:Perms (I:=I) (J:=J),∑τ:Perms (I:=I) (J:=J),
    g x.1 (fun i k=>x.2 i (π i k)) y.1 (fun i k=>y.2 i ((τ i).symm k))

def rowApply (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F:State (Z:=Z) (P:=P) (J:=J)→ℂ) (x:State (Z:=Z) (P:=P) (J:=J)):ℂ :=
  ∑y,row V g x y*F y

def word (V:I→ℝ)
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ):
    ℕ→ℕ→(State (Z:=Z) (P:=P) (J:=J)→ℂ)→State (Z:=Z) (P:=P) (J:=J)→ℂ
  | 0,_,F=>F
  | n+1,j,F=>rowApply V (g j) (word V g n (j+1) F)

def pairing (V:I→ℝ) (F G:State (Z:=Z) (P:=P) (J:=J)→ℂ):ℂ :=
  (initialMass (J:=J) V:ℂ)*∑x,conj (F x)*G x

/-- One at every ordered list over z, with no list-count normalization. -/
def positionVector (z:Z) (x:State (Z:=Z) (P:=P) (J:=J)):ℂ:=
  if x.1=z then 1 else 0

def moment (V:I→ℝ)
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (N:ℕ):ℂ:=
  ∑z:Z,pairing V (positionVector z) (word V g N 0 (positionVector z))

def pathState (r:OriginalPath I Z P J N) (j:Fin (N+1)):State (Z:=Z) (P:=P) (J:=J):=
  (r.position j,r.active j)

def pathProduct
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (j:ℕ) (r:OriginalPath I Z P J N):ℂ:=
  ∏k:Fin N,g (j+k.val) (r.position k.castSucc)
    (fun i a=>r.active k.castSucc i (r.sourcePerm k i a)) (r.position k.succ)
    (fun i a=>r.active k.succ i ((r.targetPerm k i).symm a))

def emptyPathEquiv : OriginalPath I Z P J 0 ≃ State (Z:=Z) (P:=P) (J:=J) where
  toFun r:=pathState r 0
  invFun x:=⟨fun _=>x.1,fun _=>x.2,Fin.elim0,Fin.elim0⟩
  left_inv r:=by
    apply OriginalPath.ext <;> funext j
    · exact congrArg r.position (Fin.ext (by omega))
    · exact congrArg r.active (Fin.ext (by omega))
    · exact Fin.elim0 j
    · exact Fin.elim0 j
  right_inv x:=rfl

def consPathEquiv (N:ℕ):
    OriginalPath I Z P J (N+1) ≃
      (State (Z:=Z) (P:=P) (J:=J)×Perms (I:=I) (J:=J)×Perms (I:=I) (J:=J))×OriginalPath I Z P J N where
  toFun r:=((pathState r 0,r.sourcePerm 0,r.targetPerm 0),
    ⟨fun k=>r.position k.succ,fun k=>r.active k.succ,
      fun k=>r.sourcePerm k.succ,fun k=>r.targetPerm k.succ⟩)
  invFun d:=⟨Fin.cons d.1.1.1 d.2.position,Fin.cons d.1.1.2 d.2.active,
    Fin.cons d.1.2.1 d.2.sourcePerm,Fin.cons d.1.2.2 d.2.targetPerm⟩
  left_inv r:=by
    apply OriginalPath.ext <;> funext k <;> exact Fin.cases rfl (fun _=>rfl) k
  right_inv d:=by rcases d with ⟨⟨x,π,τ⟩,r⟩;rfl

theorem normalization_eq (V:I→ℝ) (N:ℕ):
    pathNormalization V J N=initialMass (J:=J) V*edgeMass (J:=J) V^N:=by
  unfold pathNormalization initialMass edgeMass
  simp only [pow_add,Finset.prod_mul_distrib,mul_pow,Finset.prod_pow]
  ring

theorem pathProduct_cons
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (j:ℕ)
    (x:State (Z:=Z) (P:=P) (J:=J)) (π τ:Perms (I:=I) (J:=J))
    (r:OriginalPath I Z P J N):
    pathProduct g j ((consPathEquiv N).symm ((x,π,τ),r))=
      g j x.1 (fun i k=>x.2 i (π i k)) (r.position 0)
        (fun i k=>r.active 0 i ((τ i).symm k))*pathProduct g (j+1) r:=by
  rw [pathProduct,Fin.prod_univ_succ]
  simp only [consPathEquiv,Equiv.coe_fn_symm_mk,Fin.val_zero,Nat.add_zero,
    Fin.castSucc_zero,Fin.cons_zero,Fin.succ_zero_eq_one,Fin.cons_succ,
    Fin.val_succ,Fin.succ_castSucc]
  congr 1
  apply Finset.prod_congr rfl
  intro k _
  congr 1
  omega


theorem sum_paths_cons
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (j:ℕ)
    (A B:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    (∑r:OriginalPath I Z P J (N+1),A (pathState r 0)*pathProduct g j r*B (pathState r (Fin.last (N+1))))=
      ∑r:OriginalPath I Z P J N,
        (∑x:State (Z:=Z) (P:=P) (J:=J),∑π:Perms (I:=I) (J:=J),∑τ:Perms (I:=I) (J:=J),
          A x*g j x.1 (fun i k=>x.2 i (π i k)) (r.position 0)
            (fun i k=>r.active 0 i ((τ i).symm k)))*pathProduct g (j+1) r*B (pathState r (Fin.last N)):=by
  rw [←(consPathEquiv (I:=I) (Z:=Z) (P:=P) (J:=J) N).symm.sum_comp]
  rw [Fintype.sum_prod_type,Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro r _
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_prod_type,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro x _
  apply Finset.sum_congr rfl
  intro π _
  apply Finset.sum_congr rfl
  intro τ _
  apply Finset.sum_congr rfl
  intro υ _
  rw [pathProduct_cons]
  simp only [pathState,consPathEquiv,Equiv.coe_fn_symm_mk,Fin.cons_zero,
    Fin.cons_last]
  ring

theorem word_eq_path_sum (V:I→ℝ)
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (N j:ℕ) (A B:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    (∑x,A x*word V g N j B x)=
      ((edgeMass (J:=J) V:ℂ)^N)*
        ∑r:OriginalPath I Z P J N,A (pathState r 0)*pathProduct g j r*B (pathState r (Fin.last N)):=by
  induction N generalizing j A with
  | zero=>
    rw [←(emptyPathEquiv (I:=I) (Z:=Z) (P:=P) (J:=J)).symm.sum_comp]
    simp [word,pathProduct,pathState,emptyPathEquiv]
  | succ N ih=>
    have hrearr:
        (∑x,A x*word V g (N+1) j B x)=
        ∑y,(∑x,A x*row V (g j) x y)*word V g N (j+1) B y:=by
      simp only [word,rowApply,Finset.mul_sum,Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro y _
      apply Finset.sum_congr rfl
      intro x _
      ring
    rw [hrearr,ih,sum_paths_cons,pow_succ]
    simp only [row,Finset.mul_sum,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro π _
    apply Finset.sum_congr rfl
    intro τ _
    simp only [pathState]
    ring


theorem pairing_eq_path_sum (V:I→ℝ)
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (N j:ℕ) (A B:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    pairing V A (word V g N j B)=
      ∑r:OriginalPath I Z P J N,(pathNormalization V J N:ℂ)*
        conj (A (pathState r 0))*pathProduct g j r*B (pathState r (Fin.last N)):=by
  rw [pairing,word_eq_path_sum,normalization_eq]
  simp only [Complex.ofReal_mul,Complex.ofReal_pow,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  ring

/-- Exact physical moment with position closure only: the terminal ordered
lists are independent of the initial lists and both remain summed. -/
theorem moment_eq_closed_paths (V:I→ℝ)
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (N:ℕ):
    moment V g N=
      ∑r:OriginalPath I Z P J N,if r.position 0=r.position (Fin.last N) then
        (pathNormalization V J N:ℂ)*pathProduct g 0 r else 0:=by
  unfold moment
  simp_rw [pairing_eq_path_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro r _
  simp only [positionVector,pathState,apply_ite,map_one,map_zero]
  by_cases he:r.position 0=r.position (Fin.last N)
  · simp [he,mul_ite,ite_mul]
  · simp [he,mul_ite,ite_mul]

theorem pathProduct_eq_range
    (g:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (r:OriginalPath I Z P J N):
    pathProduct g 0 r=
      ∏j∈Finset.range N,g j (r.positionAt j) (r.sourceLists j)
        (r.positionAt (j+1)) (r.targetLists j):=by
  rw [Finset.prod_range]
  apply Finset.prod_congr rfl
  intro j _
  have hj:j.val<N:=j.isLt
  have hv:OriginalPath.visit (N:=N) j.val=j.castSucc:=Fin.ext (Nat.min_eq_left (by omega))
  have hw:OriginalPath.visit (N:=N) (j.val+1)=j.succ:=Fin.ext (Nat.min_eq_left (by omega))
  simp only [pathProduct,Nat.zero_add,OriginalPath.positionAt,OriginalPath.sourceLists,
    OriginalPath.targetLists,OriginalPath.activeAt,OriginalPath.sourcePermAt,
    OriginalPath.targetPermAt,dite_eq_left hj,hv,hw]
  congr 1
  · funext i a
    simp [OriginalPath.sourceLists,OriginalPath.activeAt,OriginalPath.sourcePermAt,hj,hv]
  · funext i a
    simp [OriginalPath.targetLists,OriginalPath.activeAt,OriginalPath.targetPermAt,hj,hw]


def adjointGeometry (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (z:Z) (a:PhysicalActiveLists P J) (w:Z) (b:PhysicalActiveLists P J):ℂ:=
  conj (g w b z a)

theorem row_adjoint (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (x y:State (Z:=Z) (P:=P) (J:=J)):
    row V (adjointGeometry g) x y=conj (row V g y x):=by
  simp only [row,adjointGeometry,map_mul,map_sum,Complex.conj_ofReal]
  congr 1
  rw [Finset.sum_comm]
  rw [←Equiv.sum_comp (Equiv.inv (Perms (I:=I) (J:=J)))]
  apply Finset.sum_congr rfl
  intro π _
  rw [←Equiv.sum_comp (Equiv.inv (Perms (I:=I) (J:=J)))]
  apply Finset.sum_congr rfl
  intro τ _
  simp only [Equiv.inv_apply,Pi.inv_apply,Equiv.Perm.inv_def,Equiv.symm_symm]

/-- Conjugate reversal is the adjoint for the actual constant physical
list measure; no normalization by the number of lists occurs. -/
theorem pairing_adjoint (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F G:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    pairing V F (rowApply V g G)=pairing V (rowApply V (adjointGeometry g) F) G:=by
  unfold pairing rowApply
  simp only [map_sum,map_mul,row_adjoint,starRingEnd_self_apply]
  congr 1
  simp only [Finset.mul_sum,Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  apply Finset.sum_congr rfl
  intro y _
  ring


def alternatingGeometry
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (j:ℕ):
    Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ:=
  if j%2=0 then g else adjointGeometry g

/-- The literal power (AA*)^R of the finite physical row operation. -/
def aaStarPower (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ):
    ℕ→(State (Z:=Z) (P:=P) (J:=J)→ℂ)→State (Z:=Z) (P:=P) (J:=J)→ℂ
  | 0,F=>F
  | R+1,F=>rowApply V g (rowApply V (adjointGeometry g) (aaStarPower V g R F))

theorem alternating_word_eq_power (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (R j:ℕ) (F:State (Z:=Z) (P:=P) (J:=J)→ℂ):
    word V (alternatingGeometry g) (2*R) (2*j) F=aaStarPower V g R F:=by
  induction R generalizing j with
  | zero=>rfl
  | succ R ih=>
    rw [show 2*(R+1)=2*R+1+1 by omega]
    simp only [word]
    have he:alternatingGeometry g (2*j)=g:=by simp [alternatingGeometry,Nat.mul_mod]
    have ho:alternatingGeometry g (2*j+1)=adjointGeometry g:=by simp [alternatingGeometry,Nat.add_mod,Nat.mul_mod]
    rw [he,ho,show 2*j+1+1=2*(j+1) by omega,ih]
    rfl

def rootedPowerMoment (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (R:ℕ):ℂ:=
  ∑z:Z,pairing V (positionVector z) (aaStarPower V g R (positionVector z))

theorem rootedPowerMoment_eq_moment (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (R:ℕ):
    rootedPowerMoment V g R=moment V (alternatingGeometry g) (2*R):=by
  unfold rootedPowerMoment moment
  apply Finset.sum_congr rfl
  intro z _
  rw [show (0:ℕ)=2*0 by omega,alternating_word_eq_power]

/-- The source unnormalized AA* moment is the exact alternating physical
path expansion, with only the endpoint positions required to coincide. -/
theorem rootedPowerMoment_eq_closed_paths (V:I→ℝ)
    (g:Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (R:ℕ):
    rootedPowerMoment V g R=
      ∑r:OriginalPath I Z P J (2*R),if r.position 0=r.position (Fin.last (2*R)) then
        (pathNormalization V J (2*R):ℂ)*pathProduct (alternatingGeometry g) 0 r else 0:=by
  rw [rootedPowerMoment_eq_moment,moment_eq_closed_paths]

end Elliptic.Operator.PhysicalRootedMoment
