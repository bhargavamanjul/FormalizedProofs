module

public import Elliptic.Operator.PhysicalPhasedEdgeOrderedNorm

/-! Exact clean-plus-dirty decomposition and norm assembly for the literal
unmodified physical edge. The complete original choice operation is the
one passed to the chronological word. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFullEdgeNorm
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalDirtyMasks PhysicalPhasedWord PhysicalBirthFactors PhysicalBagNorm
attribute [local instance] Classical.propDecidable
local instance fullEdgeDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B : ℕ}

 def emptyMask : Mask (G:=I) := (fun _=>false,fun _=>false)

 theorem not_dirty_iff (m : Mask (G:=I)) : ¬Dirty m ↔ m=emptyMask := by
  constructor
  · intro hm
    apply Prod.ext <;> funext i
    · cases h : m.1 i
      · rfl
      · exact (hm ⟨i,Or.inl h⟩).elim
    · cases h : m.2 i
      · rfl
      · exact (hm ⟨i,Or.inr h⟩).elim
  · rintro rfl
    simp [Dirty,emptyMask]

 theorem dirtyMasks_eq_erase : dirtyMasks (G:=I)=Finset.univ.erase emptyMask := by
  ext m
  simp only [dirtyMasks,Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_erase,and_true]
  simpa only [not_not] using not_congr (not_dirty_iff m)

 variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (ρ : ℝ) (anchor : Z→∀i p,Line i p)
 variable (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
 variable (value : ∀i,P i→ℕ)

 theorem phase_one_kernel (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    PhysicalPhasedEdge.kernel value ν V ρ anchor geometry (fun _ _=>1) s t=
      originalKernel ν V (fun _=>false) (fun _=>false) ρ anchor geometry s t+
        dirtyKernel ν V ρ anchor geometry s t := by
  unfold PhysicalPhasedEdge.kernel dirtyKernel
  have hg (M : I→Bool) : PhysicalPhasedEdge.phaseGeometry value M (fun _ _=>1) geometry=geometry := by
    funext z a w b
    simp [PhysicalPhasedEdge.phaseGeometry,PhysicalPhasedEdge.targetFactor]
  simp_rw [hg]
  rw [dirtyMasks_eq_erase]
  exact (Finset.add_sum_erase _ _ (Finset.mem_univ emptyMask)).symm

 theorem full_bag_l2_le (hν : ∀i p,0<ν i p) (clean dirty : ℝ) (hc : 0≤clean) (hd : 0≤dirty)
    (hclean : ∀F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass ν)
        (fun s=>∑t,originalKernel ν V (fun _=>false) (fun _=>false) ρ anchor geometry s t*F t)≤
      clean*finiteL2 Finset.univ (mass ν) F)
    (hdirty : ∀F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass ν) (fun s=>∑t,dirtyKernel ν V ρ anchor geometry s t*F t)≤
      dirty*finiteL2 Finset.univ (mass ν) F)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ anchor geometry (fun _ _=>1) s t*F t)≤
      Real.sqrt (2*(clean^2+dirty^2))*finiteL2 Finset.univ (mass ν) F := by
  have hneg := hdirty F
  rw [←finiteL2_neg] at hneg
  have hs := finiteL2_sub_le_of_le Finset.univ (mass ν) (fun s _=>(mass_pos ν hν s).le)
    (fun s=>∑t,originalKernel ν V (fun _=>false) (fun _=>false) ρ anchor geometry s t*F t)
    (fun s=>-(∑t,dirtyKernel ν V ρ anchor geometry s t*F t)) clean dirty
    (finiteL2 Finset.univ (mass ν) F) hc hd (Real.sqrt_nonneg _) (hclean F) hneg
  apply (le_of_eq ?_).trans hs
  apply congrArg (finiteL2 Finset.univ (mass ν))
  funext s
  simp_rw [phase_one_kernel ν V ρ anchor geometry value,add_mul,Finset.sum_add_distrib,sub_neg_eq_add]

 include value in
 theorem actual_full_edge_l2_le (hν : ∀i p,0<ν i p) (clean dirty : ℝ) (hc : 0≤clean) (hd : 0≤dirty)
    (hclean : ∀F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass ν)
        (fun s=>∑t,originalKernel ν V (fun _=>false) (fun _=>false) ρ anchor geometry s t*F t)≤
      clean*finiteL2 Finset.univ (mass ν) F)
    (hdirty : ∀F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass ν) (fun s=>∑t,dirtyKernel ν V ρ anchor geometry s t*F t)≤
      dirty*finiteL2 Finset.univ (mass ν) F)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      ((physicalEdgeOperation ν V ρ anchor geometry).apply F)≤
    Real.sqrt (2*(clean^2+dirty^2))*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
  have h := PhysicalPhasedEdgeOrderedNorm.phasedApply_l2_of_kernel_bound ν V ρ anchor geometry value
    (fun i p=>(hν i p).ne') (fun _ _=>1) _
    (full_bag_l2_le ν V ρ anchor geometry value hν clean dirty hc hd hclean hdirty) F hF
  have he : phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
      (fun _ c=>edgeFactor value (fun _ _ _=>1) 0 c) F=
      (physicalEdgeOperation ν V ρ anchor geometry).apply F := by
    funext s
    simpa only [edgeFactor,Finset.prod_const_one] using phasedApply_one (physicalEdgeOperation ν V ρ anchor geometry) F s
  rw [he] at h
  exact h

end Elliptic.Operator.PhysicalFullEdgeNorm
