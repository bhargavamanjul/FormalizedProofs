module
public import Elliptic.Operator.MajorArcSourceMellinSaving
public import Elliptic.Operator.SignedMajorFiniteEstimate
public import Elliptic.Operator.SignedMajorSourceParameters
public import Elliptic.Operator.SignedEnergyReconstruction

/-! The actual normalized scalar major-arc saving, with all analytic and finite
character budgets discharged from the original source hypotheses. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorArcSaving
open scoped BigOperators ComplexConjugate
open Filter MeasureTheory Artin Artin.MarkedSource
open SignedCauchyExpansion SignedDyadicCauchy SignedSourceDyads SignedSmoothDyads
open SignedEnergyReconstruction MajorArcSourceMellinSaving MajorArcFullEndpointMeanSquare
open SignedMajorMellinIdentity SignedMajorSourceParameters
attribute [local instance] Classical.propDecidable
local instance majorSavingDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1400000

/-- The band count threshold is one. All larger choices are available for the
independent high-rank/minor-arc argument. -/
theorem actual_normalized_scalar_major_saving
    (hbands : ClassicalBandMass)
    (hvdC : ClassicalDerivativeTest.FixedOrderDerivativeTest)
    (hDsq : Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment) :
  ∀δ C A G c₁ c₂ : ℝ,0<δ→0<C→0<A→0≤G→0<c₁→0<c₂→
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→∀b : Bands K,
    ∀(J : Type) (Hm Hn : ℝ→J→ℝ) (active : ℝ→J→Prop),
    ScaleFamily δ c₁ c₂ Hm Hn active→∀α : ℝ→J→ℕ→ℂ,
    ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j)→
    (∀ᶠx : ℝ in atTop,∀j,active x j→∀n : ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→
      ‖α x j n‖≤(Real.log x)^C ∧ (α x j n≠0→Artin.MarkedCriterion.IsRough (W x) n))→
    ∀ᶠx : ℝ in atTop,∀j,active x j→∀s t : Finset ℕ,
    IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→∀β : ℕ→ℂ,CoefficientOn x C t β→
    ∀d∈sourceDyads b x,
      ‖(massNormalization b x:ℂ)^2*scalarMajorSum b x ((2:ℝ)^d)
        ((Real.log x)^G) s t weight determinantCutoff (α x j) β‖≤
          (Hm x j*Hn x j)*(2:ℝ)^d*(Real.log x)^(-A) := by
  intro δ C A G c₁ c₂ hδ hC hA hG hc₁ hc₂
  refine ⟨1,le_rfl,?_⟩
  intro K hK b J Hm Hn active hscale α hcancel hcoeff
  have hα : ∀ᶠx : ℝ in atTop,∀j,active x j→∀n : ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→
      ‖α x j n‖≤(Real.log x)^C := by
    filter_upwards [hcoeff] with x hx
    intro j hj n hn hn'
    exact (hx j hj n hn hn').1
  have hmellin := uniform_source_mellin_integral hbands hvdC hDsq δ C G (A+9*G+2)
    c₁ c₂ hδ hC.le hG (by linarith) Hm Hn active α hscale hcancel hα K hK b
  filter_upwards [hmellin,eventually_source_major_parameters G,hscale,hcoeff]
    with x hmellin hparams hscale hcoeff
  intro j hj s t hs ht β hβ d hd
  let L := Real.log x
  let Y : ℝ := 2^d
  let X := Hm x j*Hn x j
  have hL : 2≤L := hparams.1
  have hLp : 0<L := by linarith
  have hY : 0<Y := by dsimp [Y];positivity
  have hsc := hscale j hj
  have hHm : 0<Hm x j := by linarith [hsc.1]
  have hHn : 0<Hn x j := by linarith [hsc.2.1]
  have hs' := hs.inDyad
  have hfinite := record_scalarMajor_norm_le_of_integrals b x Y (Hm x j) (Hn x j)
    (L^G) (massNormalization b x) (L^(-(A+9*G+2))) s t weight (α x j) β
    hY hHm hHn (by positivity) (by positivity)
    ((hparams.2.2 K b).2 hK d hd)
    (fun v hv=>⟨(weight_support v hv).1.le,(weight_support v hv).2.le⟩) hs' ht
    (hparams.2.2 K b).1
    (fun k hk hkL m hm hαm=>hparams.2.1 k hk hkL m
      ((hcoeff j hj m (hs' m hm).1 (hs' m hm).2).2 hαm))
    (fun k hk hkL n hn hβn=>hparams.2.1 k hk hkL n ((hβ n hn).2 hβn))
    (by
      intro k hk hkL χ lam hlam
      have hkL' : (k:ℝ)≤L^(G+1) := hkL.trans
        (Real.rpow_le_rpow_of_exponent_le (by linarith) (by linarith))
      dsimp only
      apply hmellin j hj s t hs ht β (fun n hn=>(hβ n hn).1) k hk hkL'
        (χ 1) (χ 2) (χ 3) (star (χ 0)) (star (χ 4)) (star (χ 5)) lam Y hY hlam
        (fun v=>(massNormalization b x:ℂ)*normalizedLeft
          (Finset.univ.filter (fun a:LabelTuple b x=>weight ((labelProduct b x a:ℝ)/Y)≠0))
          (labelProduct b x) s t χ weight (α x j) β Y (Hm x j) (Hn x j) lam v)
        (fun v=>(massNormalization b x:ℂ)*normalizedRight
          (Finset.univ.filter (fun a:LabelTuple b x=>weight ((labelProduct b x a:ℝ)/Y)≠0))
          (labelProduct b x) s t χ weight (α x j) β Y (Hm x j) (Hn x j) lam v)
      · exact continuous_const.mul (normalizedLeft_continuous _ _ _ _ _ _ _ _ _ _ _ _)
      · exact continuous_const.mul (normalizedRight_continuous _ _ _ _ _ _ _ _ _ _ _ _)
      · intro v
        exact source_normalizedLeft_fullEndpoint_norm b x s t χ weight (α x j) β Y (Hm x j) (Hn x j) lam v
      · intro v
        exact source_normalizedRight_reflected_fullEndpoint_norm b x s t χ weight
          (fun y=>by simp [weight]) (α x j) β Y (Hm x j) (Hn x j) lam v)
  have hre := SignedEnergyReconstruction.record_pair_reindex b x s t
    (fun a c m n r q=>SignedPhysicalPairBridge.scalarMajor (labelProduct b x a)
      (labelProduct b x c) m n r q Y (L^G) weight determinantCutoff (α x j) β)
  rw [hre] at hfinite
  change ‖(massNormalization b x:ℂ)^2*scalarMajorSum b x Y (L^G) s t weight
    determinantCutoff (α x j) β‖≤_ at hfinite
  have habs := finite_major_cost_absorption L G A Y X hL hY.le (by dsimp [X];positivity)
  exact hfinite.trans (by simpa only [X,mul_comm Y] using habs)

end Elliptic.Operator.SignedMajorArcSaving
