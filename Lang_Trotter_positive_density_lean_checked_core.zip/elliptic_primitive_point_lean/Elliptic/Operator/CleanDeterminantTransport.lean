module

public import Elliptic.Operator.SmoothedDeterminant
public import Elliptic.Operator.SignedPhysicalClean
public import Elliptic.Operator.PhysicalPadLattice

/-!
# From the proved smooth determinant norm to actual clean prime labels

Integer interval reindexing and exact pad-lattice coordinates connect the
proved Fourier estimate to the existing measured signed clean kernel.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators FourierTransform SchwartzMap
open MeasureTheory Elliptic.SourceContracts

/-- The reverse direction of counting-measure embedding transport. -/
theorem finiteBilinearBound_map {ι κ ι' κ' : Type*}
    (s : Finset ι) (t : Finset κ) (e : ι ↪ ι') (f : κ ↪ κ')
    (K : ι' → κ' → ℂ) (M : ℝ)
    (hK : FiniteBilinearBound s t (fun i j => K (e i) (f j)) M) :
    FiniteBilinearBound (s.map e) (t.map f) K M := by
  intro a b
  simpa only [finitePairing, Finset.sum_map] using hK (fun i => a (e i)) (fun j => b (f j))

def integerTranslateEmbedding (a : ℤ) : ℕ ↪ ℤ :=
  Nat.castEmbedding.trans (addLeftEmbedding a)

theorem integerTranslateEmbedding_range (a : ℤ) (B : ℕ) :
    (Finset.range B).map (integerTranslateEmbedding a) = Finset.Ico a (a+B) := by
  rw [Int.Ico_eq_finset_map]
  have he : (a+(B : ℤ)-a).toNat = B := by omega
  rw [he]
  rfl

/-- The same normalized matrix on a literal integer rectangle, with both
endpoints in ordinary coordinate order. -/
theorem smoothed_minor_integer_box_bound
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (a b : ℤ) (H Y θ : ℝ) (k : ℕ)
    (hH : 1 ≤ H) (hY : 0 < Y)
    (hminor : (θ : ProductCircle) ∉ sourceMajorArcs H Y) :
    FiniteBilinearBound ((Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
      ((Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
      (fun p q => (Y : ℂ)⁻¹ * (ψ ((latticeDet p q : ℝ)/Y) *
        additivePhase (θ*(latticeDet p q : ℝ))))
      (smoothedDeterminantBudget ψ A B H Y k) := by
  let e := (integerTranslateEmbedding a).prodMap (integerTranslateEmbedding b)
  let swap : (ℕ × ℕ) ↪ (ℕ × ℕ) := ⟨Prod.swap, Prod.swap_injective⟩
  have he : (Finset.range B ×ˢ Finset.range A).map e =
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)) := by
    rw [Finset.prodMap_map_product, integerTranslateEmbedding_range, integerTranslateEmbedding_range]
  have hf : (Finset.range A ×ˢ Finset.range B).map (swap.trans e) =
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)) := by
    rw [← Finset.map_map]
    change ((Finset.range A ×ˢ Finset.range B).map ⟨Prod.swap, Prod.swap_injective⟩).map e = _
    rw [Finset.map_swap_product, he]
  have h := finiteBilinearBound_map (Finset.range B ×ˢ Finset.range A)
    (Finset.range A ×ˢ Finset.range B) e (swap.trans e)
    (fun p q => (Y : ℂ)⁻¹ * (ψ ((latticeDet p q : ℝ)/Y) *
      additivePhase (θ*(latticeDet p q : ℝ))))
    (smoothedDeterminantBudget ψ A B H Y k) ?_
  · rwa [he, hf] at h
  · exact smoothed_minor_determinant_bound ψ A B a b H Y θ k hH hY hminor

/-- Restriction to arbitrary actual geometric supports within the integer
rectangle costs no cardinality factor. -/
theorem smoothed_minor_integer_box_bound_restrict
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1 ≤ H) (hY : 0 < Y)
    (s t : Finset (ℤ × ℤ))
    (hs : s ⊆ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (ht : t ⊆ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (θ : ProductCircle) (hminor : θ ∉ sourceMajorArcs H Y) :
    FiniteBilinearBound s t
      (fun p q => ((Y : ℂ)⁻¹ * ψ ((latticeDet p q : ℝ)/Y)) * fourier (latticeDet p q) θ)
      (smoothedDeterminantBudget ψ A B H Y k) := by
  induction θ using QuotientAddGroup.induction_on
  rename_i θ
  have h := finiteBilinearBound_restrict _ s _ t hs ht _ _
    (smoothed_minor_integer_box_bound ψ A B a b H Y θ k hH hY hminor)
  simpa only [fourier_eq_additivePhase, mul_assoc] using h

/-- Actual positive prime labels with their original product masses now
receive the proved smooth clean bound for BOTH shift signs. No determinant
fiber estimate is assumed in this theorem. -/
theorem actual_measured_signed_clean_integer_box_bound
    {ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (ν : ι → ℕ → ℝ) (C : ι → ℝ) (hC : ∀ i ∈ I, 0 ≤ C i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hνbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ C i / p)
    (s t : Finset ((ℤ × ℤ) × PrimeChoice I groups))
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1 ≤ H) (hY : 0 < Y)
    (hsbox : ∀ z ∈ s, z.1 ∈ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (htbox : ∀ z ∈ t, z.1 ∈ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (hs : ∀ z ∈ s, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (ht : ∀ z ∈ t, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    FiniteMeasuredBilinearBound s t
      (fun z => primeChoiceMass I groups ν z.2)
      (fun z => primeChoiceMass I groups ν z.2)
      (actualSignedCleanKernel I groups (sourceMajorArcs H Y)ᶜ
        (fun p q => ψ ((latticeDet p q : ℝ)/Y)) latticeDet σ)
      ((∏ i : I, C i) * smoothedDeterminantBudget ψ A B H Y k) := by
  apply actual_measured_signed_clean_bound I groups hprime hdisjoint ν C hC hν hνbound
    s t (sourceMajorArcs H Y)ᶜ (sourceMajorArcs_measurable H Y).compl
    (fun p q => ψ ((latticeDet p q : ℝ)/Y)) latticeDet Y
    (smoothedDeterminantBudget ψ A B H Y k) hY
    (smoothedDeterminantBudget_nonneg ψ A B H Y k (by linarith) hY) hs ht ?_ σ hσ
  intro θ hθ
  apply smoothed_minor_integer_box_bound_restrict ψ A B a b H Y k hH hY
    (s.image Prod.fst) (t.image Prod.fst) ?_ ?_ θ hθ
  · intro z hz
    obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hz
    exact hsbox p hp
  · intro z hz
    obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hz
    exact htbox p hp

end Elliptic.Operator
