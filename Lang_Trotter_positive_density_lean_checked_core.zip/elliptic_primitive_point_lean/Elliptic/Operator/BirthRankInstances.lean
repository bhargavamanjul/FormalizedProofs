module
public import Elliptic.Operator.BirthDistinctness

/-! Cycle ranks and signs do not depend on the implementation of equality. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator

 theorem birthCycleRank_decidableEq {α : Type*} [Fintype α]
    (d : DecidableEq α) (σ : Equiv.Perm α) :
    @birthCycleRank α _ d σ = @birthCycleRank α _ (Classical.typeDecidableEq α) σ := by
  have h : d = Classical.typeDecidableEq α := Subsingleton.elim _ _
  rw [h]

 theorem permutationSign_decidableEq {α : Type*} [Fintype α]
    (d : DecidableEq α) (σ : Equiv.Perm α) :
    @permutationSign α _ d σ = @permutationSign α _ (Classical.typeDecidableEq α) σ := by
  have h : d = Classical.typeDecidableEq α := Subsingleton.elim _ _
  rw [h]

end Elliptic.Operator
