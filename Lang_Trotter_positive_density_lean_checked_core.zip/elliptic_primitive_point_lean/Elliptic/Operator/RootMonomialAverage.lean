module

public import Elliptic.Operator.RootMonomialTests
public import Elliptic.Operator.FinitePrimeMarginal

/-! # Exact full-line marginals of the actual signed and gap monomials -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootMonomialAverage
open scoped BigOperators
open RootRecordBonferroni RootRecordGap RootIntegratedBonferroni
open RootMonomialTests OriginalPathWeights BonferroniMonomialCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

theorem line_card (P : Finset ℕ) [∀p : P,Fact p.val.Prime] :
    Fintype.card (∀p : P,Option (ZMod p.val))=∏p∈P,(p+1) := by
  simp only [Fintype.card_pi,Fintype.card_option,ZMod.card]
  exact Finset.prod_coe_sort P (fun p : ℕ=>p+1)

theorem average_subset (S P : Finset ℕ) (hSP : S⊆P)
    [∀p : P,Fact p.val.Prime] [∀p : S,Fact p.val.Prime]
    (f : (∀p : S,Option (ZMod p.val))→ℂ) :
    average (fun ℓ : ∀p : P,Option (ZMod p.val)=>f (fun p=>extendLines P ℓ p))=average f := by
  have he (ℓ : ∀p : P,Option (ZMod p.val)) :
      (fun p : S=>extendLines P ℓ p)=(fun p : S=>ℓ ⟨p.val,hSP p.property⟩) := by
    funext p
    simp only [extendLines,dif_pos (hSP p.property)]
  simp_rw [he]
  simp only [average,line_card]
  exact FinitePrimeMarginal.average_restrict S P hSP f

/-- A single signed monomial has exactly its small-union line average. -/
theorem subsetTest_average (rec : Record K J N R Q) (P s : Finset ℕ)
    (hA : activePrimes rec⊆P) (hs : s⊆P)
    [∀p : P,Fact p.val.Prime] [∀p : ↥(activePrimes rec∪s),Fact p.val.Prime]
    (η : ℕ→ℝ) :
    average (fun ℓ : ∀p : P,Option (ZMod p)=>subsetTest rec η s (fun p=>extendLines P ℓ p))=
      average (subsetTest rec η s) :=
  average_subset _ _ (Finset.union_subset hA hs) _

/-- The complete finite-prime polynomial equals the sum of the exact
small-modulus averages used by root replacement. -/
theorem truncatedAverage_subsets (rec : Record K J N R Q) (P : Finset ℕ)
    (hA : activePrimes rec⊆P) (η : ℕ→ℝ) (T : ℕ)
    [∀p : P,Fact p.val.Prime]
    [∀s : truncatedSubsets P T,∀p : ↥(activePrimes rec∪s.val),Fact p.val.Prime] :
    truncatedAverage rec P η T =
      ∑s : truncatedSubsets P T,average (subsetTest rec η s.val) := by
  unfold truncatedAverage average
  rw [Finset.sum_comm,Finset.sum_div]
  rw [←Finset.sum_coe_sort (truncatedSubsets P T)]
  apply Finset.sum_congr rfl
  intro s hs
  exact subsetTest_average rec P s.val hA (mem_truncatedSubsets P T s.val |>.mp s.property).1 η

/-- Casting the real positive expected gap gives the same complex
uniform average; the line count is never replaced by an asymptotic. -/
theorem gap_cast_average (rec : Record K J N R Q) (P : Finset ℕ)
    [∀p : P,Fact p.val.Prime] (η : ℕ→ℝ) (k : ℕ) :
    (gap rec P η k:ℂ)=average (fun ℓ : ∀p : P,Option (ZMod p)=>
      (SourceBonferroni.elementary P (fun p=>loss rec η p (extendLines P ℓ p)) k:ℂ)) := by
  unfold gap SourceBonferroni.uniformAverage average
  push_cast
  ring

theorem gap_average_subsets (rec : Record K J N R Q) (P : Finset ℕ)
    (hA : activePrimes rec⊆P) (η : ℕ→ℝ) (k T : ℕ) (hk : k≤T)
    [∀p : P,Fact p.val.Prime]
    [∀s : truncatedSubsets P T,∀p : ↥(activePrimes rec∪s.val),Fact p.val.Prime] :
    (gap rec P η k:ℂ)=∑s : truncatedSubsets P T,average (gapTest rec η k s.val) := by
  rw [gap_cast_average]
  simp_rw [gap_sparse rec P η k T hk]
  unfold average
  rw [Finset.sum_comm,Finset.sum_div]
  rw [←Finset.sum_coe_sort (truncatedSubsets P T)]
  apply Finset.sum_congr rfl
  intro s hs
  exact average_subset _ _ (Finset.union_subset hA (mem_truncatedSubsets P T s.val |>.mp s.property).1) _

end Elliptic.Operator.RootMonomialAverage
