module

public import Elliptic.Operator.PhysicalBagNorm
public import Elliptic.Operator.PhysicalPhasedEdge
public import Elliptic.Operator.PhysicalPhasedGhostBags
public import Elliptic.Operator.PhysicalPhasedGhostNorm

/-! Chronological composition for literal birth-phased physical words.
Every intermediate output remains a function of the actual memory bags.
The finite norm argument therefore applies the original factorial ghost
and edge estimates to the actual word, without a symmetry hypothesis on
intermediate states. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedWordNorm
open scoped BigOperators
open PhysicalPhasedWord PhysicalBirthFactors PhysicalBagNorm PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B : ℕ}
variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (anchor : Z→∀i p,Line i p)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
variable (value : ∀i,P i→ℕ)

 theorem edge_isBagFunction (hν : ∀i p,ν i p≠0)
    (E : ℕ→I→Option ℕ→ℂ) (j : ℕ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    IsBagFunction (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
      (fun _ c=>edgeFactor value E j c) F) := by
  obtain ⟨f,rfl⟩ := hF
  refine ⟨fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ anchor (geometry j) (E j) s t*f t,?_⟩
  funext s
  exact PhysicalPhasedEdge.phasedApply_eq_kernel value ν V ρ anchor (geometry j) hν (E j) f s

 theorem ghost_isBagFunction (G : ℕ→I→Fin B→Option ℕ→ℂ) (j : ℕ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    IsBagFunction (phasedApply (physicalGhostOperation ν V (η j) (q j) ρ anchor)
      (fun _ c=>ghostFactor value G j c) F) := by
  obtain ⟨H,rfl⟩ := (isBagFunction_iff F).mp hF
  apply (isBagFunction_iff _).mpr
  exact PhysicalPhasedGhostBags.birthPhased_exists_bagFunction ν V (η j) (q j) ρ anchor value G j H

 theorem word_isBagFunction (hν : ∀i p,ν i p≠0)
    (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ)
    (n j : ℕ) (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    IsBagFunction (word ν V η q ρ anchor geometry value G E n j F) := by
  induction n generalizing j with
  | zero => exact ghost_isBagFunction ν V η q ρ anchor value G j F hF
  | succ n ih =>
      exact ghost_isBagFunction ν V η q ρ anchor value G j _
        (edge_isBagFunction ν V ρ anchor geometry value hν E j _ (ih (j+1)))

 def wordCost (Cg Ce : ℕ→ℝ) : ℕ→ℕ→ℝ
  | 0,j => Cg j
  | n+1,j => Cg j*Ce j*wordCost Cg Ce n (j+1)

 theorem wordCost_nonneg (Cg Ce : ℕ→ℝ) (hCg : ∀j,0≤Cg j) (hCe : ∀j,0≤Ce j)
    (n j : ℕ) : 0≤wordCost Cg Ce n j := by
  induction n generalizing j with
  | zero => exact hCg j
  | succ n ih => exact mul_nonneg (mul_nonneg (hCg j) (hCe j)) (ih _)

 theorem word_l2_le (hν : ∀i p,ν i p≠0)
    (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ)
    (Cg Ce : ℕ→ℝ) (hCg : ∀j,0≤Cg j) (hCe : ∀j,0≤Ce j)
    (hg : ∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalGhostOperation ν V (η j) (q j) ρ anchor)
          (fun _ c=>ghostFactor value G j c) F)≤
      Cg j*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (he : ∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
          (fun _ c=>edgeFactor value E j c) F)≤
      Ce j*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (n j : ℕ) (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (word ν V η q ρ anchor geometry value G E n j F)≤
    wordCost Cg Ce n j*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
  induction n generalizing j with
  | zero => exact hg j F hF
  | succ n ih =>
      have hw := word_isBagFunction ν V η q ρ anchor geometry value hν G E n (j+1) F hF
      have hed := edge_isBagFunction ν V ρ anchor geometry value hν E j _ hw
      apply (hg j _ hed).trans
      apply (mul_le_mul_of_nonneg_left (he j _ hw) (hCg j)).trans
      apply (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left (ih (j+1)) (hCe j)) (hCg j)).trans_eq
      simp only [wordCost]
      ring

 theorem wordCost_eq_products (Cg Ce : ℕ→ℝ) (n j : ℕ) :
    wordCost Cg Ce n j=(∏k : Fin (n+1),Cg (j+k.val))*(∏k : Fin n,Ce (j+k.val)) := by
  induction n generalizing j with
  | zero => simp [wordCost]
  | succ n ih =>
      rw [wordCost,ih,Fin.prod_univ_succ (f:=fun k : Fin (n+1+1)=>Cg (j+k.val)),
        Fin.prod_univ_succ (f:=fun k : Fin (n+1)=>Ce (j+k.val))]
      simp only [Fin.val_zero,Nat.add_zero,Fin.val_succ]
      have hh (k : ℕ) : j+1+k=j+(k+1) := by omega
      simp only [hh]
      ring

end Elliptic.Operator.PhysicalPhasedWordNorm
