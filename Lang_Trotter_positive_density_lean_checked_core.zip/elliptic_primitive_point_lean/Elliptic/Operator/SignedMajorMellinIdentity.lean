module
public import Elliptic.Operator.SignedPhysicalPairSquare
public import Elliptic.Operator.SignedMajorCharacter
public import Elliptic.Operator.MellinPlateau
public import Artin.MarkedCriterion

/-! Literal signed major-arc character separation and its two determinant endpoints. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorMellinIdentity
open scoped BigOperators ComplexConjugate
open MeasureTheory Set SignedPhysicalPairBridge SignedMajorCharacter
open Elliptic.SourceContracts
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- The actual circle integrand of the scalar major term. -/
def scalarIntegrand (a b m n r s : ℕ) (Y : ℝ) (η ψ : ℝ→ℂ)
    (α β : ℕ→ℂ) (θ : ProductCircle) : ℂ :=
  η ((a:ℝ)/Y)*η ((b:ℝ)/Y)*α m*β n*conj (α r)*conj (β s)*
    ψ ((scalarDet a b m n r s:ℝ)/Y)*fourier (scalarDet a b m n r s+b-a) θ

theorem scalarMajor_eq_integral (a b m n r s : ℕ) (Y H : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    scalarMajor a b m n r s Y H η ψ α β =
      ∫θ in sourceMajorArcs H Y,scalarIntegrand a b m n r s Y η ψ α β θ ∂productCircleMeasure := by
  simp only [scalarMajor,scalarIntegrand,minorFourierTransform,integral_const_mul]

theorem scalarIntegrand_continuous (a b m n r s : ℕ) (Y : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : Continuous (scalarIntegrand a b m n r s Y η ψ α β) := by
  exact continuous_const.mul (fourier _).continuous

/-- The label endpoint, with its sign retained in the additive modulation. -/
def leftCoefficient {k : ℕ} (χ : CharacterTuple k 6) (η : ℝ→ℂ)
    (α β : ℕ→ℂ) (Y lam : ℝ) (b m n : ℕ) : ℂ :=
  η ((b:ℝ)/Y)*additivePhase (lam*((b:ℝ)/Y))*χ 1 (b:ZMod k)*
    (α m*χ 2 (m:ZMod k))*(β n*χ 3 (n:ZMod k))

def rightCoefficient {k : ℕ} (χ : CharacterTuple k 6) (η : ℝ→ℂ)
    (α β : ℕ→ℂ) (Y lam : ℝ) (a r s : ℕ) : ℂ :=
  η ((a:ℝ)/Y)*additivePhase (-lam*((a:ℝ)/Y))*χ 0 (a:ZMod k)*
    (conj (α r)*χ 4 (r:ZMod k))*(conj (β s)*χ 5 (s:ZMod k))

/-- Roughness supplies units; there is no unit-residue assumption in addition
 to the ordinary rough support of the coefficients. -/
theorem rough_unit {k n : ℕ} (hk : 0<k) (W : ℝ) (hkW : (k:ℝ)≤W)
    (hn : ∀p:ℕ,p.Prime→p∣n→W<(p:ℝ)) : IsUnit (n:ZMod k) :=
  (ZMod.isUnit_iff_coprime n k).mpr (Artin.MarkedCriterion.rough_coprime hk hkW hn)

/-- Pointwise exact six-character expansion. The successor equation has
shift sign -1; the determinant modulation is +lam and the endpoint phases
are +lam*b/Y and -lam*a/Y. -/
theorem scalarIntegrand_characters (k : ℕ) [NeZero k] (h : ℤ)
    (a b m n r s : ℕ) (Y lam : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (ha : a.Coprime k) (hb : b.Coprime k)
    (hm : α m≠0 → m.Coprime k) (hn : β n≠0 → n.Coprime k)
    (hr : α r≠0 → r.Coprime k) (hs : β s≠0 → s.Coprime k) :
    scalarIntegrand a b m n r s Y η ψ α β (((h:ℝ)/k+lam/Y:ℝ):ProductCircle)=
      ∑χ : CharacterTuple k 6,coefficient k 6 (signedRationalPhase k h (-1)) χ*
        (leftCoefficient χ η α β Y lam b m n*rightCoefficient χ η α β Y lam a r s*
          (ψ ((scalarDet a b m n r s:ℝ)/Y)*
            additivePhase (lam*((scalarDet a b m n r s:ℝ)/Y)))) := by
  by_cases ham : α m=0
  · simp [scalarIntegrand,leftCoefficient,ham]
  by_cases hbn : β n=0
  · simp [scalarIntegrand,leftCoefficient,hbn]
  by_cases har : α r=0
  · simp [scalarIntegrand,rightCoefficient,har]
  by_cases hbs : β s=0
  · simp [scalarIntegrand,rightCoefficient,hbs]
  let z : Fin 6→ℤ := ![(a:ℤ),(b:ℤ),(m:ℤ),(n:ℤ),(r:ℤ),(s:ℤ)]
  let u : UnitTuple k 6 := ![ZMod.unitOfCoprime a ha,ZMod.unitOfCoprime b hb,
    ZMod.unitOfCoprime m (hm ham),ZMod.unitOfCoprime n (hn hbn),
    ZMod.unitOfCoprime r (hr har),ZMod.unitOfCoprime s (hs hbs)]
  have hz (i : Fin 6) : (z i:ZMod k)=(u i:ZMod k) := by
    fin_cases i <;> simp [z,u]
  have he := signed_integer_phase_eq k h (-1) z u hz
  have hzpoly : signedIntegerPolynomial (-1) z=scalarDet a b m n r s+b-a := by
    simp [signedIntegerPolynomial,z,scalarDet]
    ring
  rw [hzpoly] at he
  have hephase : ((h:ℝ)/k+lam/Y)*((scalarDet a b m n r s+b-a:ℤ):ℝ)=
      (h:ℝ)/k*((scalarDet a b m n r s+b-a:ℤ):ℝ)+
        (lam*((b:ℝ)/Y)+(-lam*((a:ℝ)/Y)+lam*((scalarDet a b m n r s:ℝ)/Y))) := by
    push_cast
    ring
  rw [scalarIntegrand,fourier_eq_additivePhase,hephase,additivePhase_add,he,
    (signedRationalPhase_separation k h (-1)).1 u]
  simp only [Finset.sum_mul,Finset.mul_sum,additivePhase_add]
  apply Finset.sum_congr rfl
  intro χ _
  simp only [leftCoefficient,rightCoefficient,characterValue,Fin.prod_univ_succ,u,
    Matrix.cons_val_zero,Matrix.cons_val_succ,Finset.univ_eq_empty,Finset.prod_empty,mul_one,
    ZMod.coe_unitOfCoprime]
  norm_num only [Fin.reduceSucc]
  ring

/-- The geometric variables entering the fixed logarithmic plateaus. -/
def endpointPosition (Y X : ℝ) (b m n : ℕ) : ℝ := (b:ℝ)*m*n/(Y*X)

theorem determinant_position (a b m n r s : ℕ) (Y X : ℝ) (hX : X≠0) :
    X*(endpointPosition Y X b m n-endpointPosition Y X a r s)=
      (scalarDet a b m n r s:ℝ)/Y := by
  unfold endpointPosition scalarDet
  push_cast
  field_simp
  <;> ring

theorem endpointPosition_mem (Y Hm Hn : ℝ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (b m n : ℕ) (hb : 1≤(b:ℝ)/Y ∧ (b:ℝ)/Y≤4)
    (hm : Hm≤(m:ℝ) ∧ (m:ℝ)≤2*Hm) (hn : Hn≤(n:ℝ) ∧ (n:ℝ)≤2*Hn) :
    endpointPosition Y (Hm*Hn) b m n∈Icc 1 16 := by
  have hb' : Y≤(b:ℝ) ∧ (b:ℝ)≤4*Y := by
    exact ⟨by simpa using (le_div_iff₀ hY).mp hb.1,(div_le_iff₀ hY).mp hb.2⟩
  have hlo := mul_le_mul (mul_le_mul hb'.1 hm.1 hHm.le (Nat.cast_nonneg b)) hn.1 hHn.le
    (mul_nonneg (Nat.cast_nonneg b) (Nat.cast_nonneg m))
  have hhi := mul_le_mul (mul_le_mul hb'.2 hm.2 (Nat.cast_nonneg m) (by positivity)) hn.2
    (Nat.cast_nonneg n) (by positivity : 0≤4*Y*(2*Hm))
  constructor
  · apply (le_div_iff₀ (by positivity : 0<Y*(Hm*Hn))).mpr
    nlinarith
  · apply (div_le_iff₀ (by positivity : 0<Y*(Hm*Hn))).mpr
    nlinarith


/-- Three independent factors on each side of the determinant. Label indices
are retained, so this construction does not discard product multiplicities. -/
def triples {ι : Type*} (A : Finset ι) (S T : Finset ℕ) : Finset (ι×ℕ×ℕ) :=
  A×ˢ(S×ˢT)

def pairIntegrand {ι : Type*} (A : Finset ι) (value : ι→ℕ) (S T : Finset ℕ)
    (Y : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (θ : ProductCircle) : ℂ :=
  ∑i∈triples A S T,∑j∈triples A S T,
    scalarIntegrand (value j.1) (value i.1) i.2.1 i.2.2 j.2.1 j.2.2 Y η ψ α β θ

def characterPair {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ) (S T : Finset ℕ)
    (χ : CharacterTuple k 6) (Y lam : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  ∑i∈triples A S T,∑j∈triples A S T,
    leftCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
    rightCoefficient χ η α β Y lam (value j.1) j.2.1 j.2.2*
    (ψ ((scalarDet (value j.1) (value i.1) i.2.1 i.2.2 j.2.1 j.2.2:ℝ)/Y)*
      additivePhase (lam*((scalarDet (value j.1) (value i.1) i.2.1 i.2.2 j.2.1 j.2.2:ℝ)/Y)))

theorem pairIntegrand_characters {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (k : ℕ) [NeZero k] (h : ℤ) (Y lam : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (ha : ∀a∈A,(value a).Coprime k)
    (hm : ∀m∈S,α m≠0 → m.Coprime k) (hn : ∀n∈T,β n≠0 → n.Coprime k) :
    pairIntegrand A value S T Y η ψ α β (((h:ℝ)/k+lam/Y:ℝ):ProductCircle)=
      ∑χ : CharacterTuple k 6,coefficient k 6 (signedRationalPhase k h (-1)) χ*
        characterPair A value S T χ Y lam η ψ α β := by
  unfold pairIntegrand characterPair
  have hp (i) (hi : i∈triples A S T) (j) (hj : j∈triples A S T) :=
    scalarIntegrand_characters k h (value j.1) (value i.1) i.2.1 i.2.2 j.2.1 j.2.2 Y lam η ψ α β
      (ha j.1 (Finset.mem_product.mp hj).1) (ha i.1 (Finset.mem_product.mp hi).1)
      (hm i.2.1 (Finset.mem_product.mp (Finset.mem_product.mp hi).2).1)
      (hn i.2.2 (Finset.mem_product.mp (Finset.mem_product.mp hi).2).2)
      (hm j.2.1 (Finset.mem_product.mp (Finset.mem_product.mp hj).2).1)
      (hn j.2.2 (Finset.mem_product.mp (Finset.mem_product.mp hj).2).2)
  simp_rw [Finset.mul_sum]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  conv_rhs => rw [Finset.sum_comm]
  exact Finset.sum_congr rfl (fun j hj=>hp i hi j hj)

/-- The literal determinant pair is the fixed two-dimensional Mellin
integral. Its Jacobian is X⁻¹ with X=Hm*Hn. -/
theorem characterPair_mellin {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (Y Hm Hn lam : ℝ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,1≤(value a:ℝ)/Y ∧ (value a:ℝ)/Y≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T) :
    characterPair A value S T χ Y lam η SignedSmoothDyads.determinantCutoff α β=
      ((Hm*Hn:ℝ):ℂ)⁻¹*(∫t:ℝ,∫s:ℝ,
        MellinPlane.mellinKernel (MellinPlane.determinantSchwartz SignedSmoothDyads.determinantCutoff
          MellinPlateau.rho MellinPlateau.sigma SignedSmoothDyads.determinantCutoff_contDiff
          (MellinPlateau.plateau_smooth (-5) 5) (MellinPlateau.plateau_smooth 0 (Real.log 16))
          (MellinPlateau.plateau_compact (-5) 5) (MellinPlateau.plateau_compact 0 (Real.log 16))
          (Hm*Hn) lam) (t/(Hm*Hn)) s*
        (∑i∈triples A S T,leftCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2*
          LogPhaseProgression.phase t (endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2))*
        (∑j∈triples A S T,rightCoefficient χ η α β Y lam (value j.1) j.2.1 j.2.2*
          LogPhaseProgression.phase (s-t) (endpointPosition Y (Hm*Hn) (value j.1) j.2.1 j.2.2))) := by
  have hX : 0<Hm*Hn := mul_pos hHm hHn
  have hw (i) (hi : i∈triples A S T) :
      endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2∈Icc 1 16 := by
    exact endpointPosition_mem Y Hm Hn hY hHm hHn _ _ _
      (ha _ (Finset.mem_product.mp hi).1)
      (hm _ (Finset.mem_product.mp (Finset.mem_product.mp hi).2).1)
      (hn _ (Finset.mem_product.mp (Finset.mem_product.mp hi).2).2)
  have hh := MellinPlateau.source_determinant_pair_separation (triples A S T) (triples A S T)
    (fun i=>leftCoefficient χ η α β Y lam (value i.1) i.2.1 i.2.2)
    (fun j=>rightCoefficient χ η α β Y lam (value j.1) j.2.1 j.2.2)
    (fun i=>endpointPosition Y (Hm*Hn) (value i.1) i.2.1 i.2.2)
    (fun j=>endpointPosition Y (Hm*Hn) (value j.1) j.2.1 j.2.2)
    (Hm*Hn) lam hX hw hw
  simpa only [determinant_position _ _ _ _ _ _ Y (Hm*Hn) hX.ne',characterPair] using hh


/-- The archimedean phase of the scaled determinant variable separates into
its three positive integer factors and a common phase of norm one. -/
theorem endpointPosition_phase (Y X t : ℝ) (hY : 0<Y) (hX : 0<X)
    (b m n : ℕ) (hb : 0<b) (hm : 0<m) (hn : 0<n) :
    LogPhaseProgression.phase t (endpointPosition Y X b m n)=
      LogPhaseProgression.phase (-t) (Y*X)*Artin.MarkedReplacement.archimedeanPhase t b*
        Artin.MarkedReplacement.archimedeanPhase t m*Artin.MarkedReplacement.archimedeanPhase t n := by
  have hb' : (b:ℝ)≠0 := by exact_mod_cast hb.ne'
  have hm' : (m:ℝ)≠0 := by exact_mod_cast hm.ne'
  have hn' : (n:ℝ)≠0 := by exact_mod_cast hn.ne'
  simp only [LogPhaseProgression.phase,Artin.MarkedReplacement.archimedeanPhase,
    endpointPosition,Real.log_div (mul_ne_zero (mul_ne_zero hb' hm') hn') (mul_ne_zero hY.ne' hX.ne'),
    Real.log_mul (mul_ne_zero hb' hm') hn',Real.log_mul hb' hm',←Complex.exp_add]
  congr 1
  push_cast
  ring

/-- Exact factorization of each Mellin endpoint into its label polynomial
and the two original coefficient polynomials. -/
theorem triplePolynomial_factor {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (c : ι→ℂ) (d e : ℕ→ℂ) (Y X t : ℝ)
    (hY : 0<Y) (hX : 0<X) (ha : ∀a∈A,0<value a)
    (hm : ∀m∈S,0<m) (hn : ∀n∈T,0<n) :
    (∑i∈triples A S T,c i.1*d i.2.1*e i.2.2*
      LogPhaseProgression.phase t (endpointPosition Y X (value i.1) i.2.1 i.2.2))=
      LogPhaseProgression.phase (-t) (Y*X)*
        (∑a∈A,c a*Artin.MarkedReplacement.archimedeanPhase t (value a))*
        (∑m∈S,d m*Artin.MarkedReplacement.archimedeanPhase t m)*
        (∑n∈T,e n*Artin.MarkedReplacement.archimedeanPhase t n) := by
  simp only [triples,Finset.sum_product,Finset.sum_mul,Finset.mul_sum]
  conv_rhs =>
    rw [Finset.sum_comm]
    arg 2
    ext m
    rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a haA
  apply Finset.sum_congr rfl
  intro m hmS
  apply Finset.sum_congr rfl
  intro n hnT
  rw [endpointPosition_phase Y X t hY hX _ _ _ (ha a haA) (hm m hmS) (hn n hnT)]
  ring

/-- The literal label product is a unit for every modulus below all its
prime labels, without any assumption about numerical product injectivity. -/
theorem labelProduct_coprime {K : ℕ} (b : Artin.MarkedSource.Bands K) (x : ℝ)
    (k : ℕ) (hk : 0<k)
    (hsmall : ∀i,∀p∈b.group x i,k<p) (a : SignedCauchyExpansion.LabelTuple b x) :
    (SignedCauchyExpansion.labelProduct b x a).Coprime k := by
  apply Nat.Coprime.prod_left
  intro i _
  apply (b.group_prime x (a i).property).coprime_iff_not_dvd.mpr
  exact Nat.not_dvd_of_pos_of_lt hk (hsmall i _ (a i).property)

/-- Removing zero cutoff labels is exact, before invoking any unit or dyadic
support assertion. -/
theorem pairIntegrand_filter {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (Y : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (θ : ProductCircle) :
    pairIntegrand (A.filter (fun a=>η ((value a:ℝ)/Y)≠0)) value S T Y η ψ α β θ=
      pairIntegrand A value S T Y η ψ α β θ := by
  simp only [pairIntegrand,triples,Finset.sum_product,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro b hb
  by_cases hηb : η ((value b:ℝ)/Y)=0
  · simp [hηb,scalarIntegrand]
  · rw [if_pos hηb]
    apply Finset.sum_congr rfl
    intro m hm
    apply Finset.sum_congr rfl
    intro n hn
    apply Finset.sum_congr rfl
    intro a ha
    by_cases hηa : η ((value a:ℝ)/Y)=0
    · simp [hηa,scalarIntegrand]
    · rw [if_pos hηa]


/-- Exchanging the two label coordinates turns the original pair of Cauchy
records into the two independent determinant triples. -/
theorem record_pair_reindex {ι : Type*} [Fintype ι] (S T : Finset ℕ)
    (F : ι→ι→ℕ→ℕ→ℕ→ℕ→ℂ) :
    (∑r : S×T×ι,∑u : S×T×ι,F r.2.2 u.2.2 r.1.val r.2.1.val u.1.val u.2.1.val)=
      ∑i∈triples (Finset.univ : Finset ι) S T,∑j∈triples Finset.univ S T,
        F j.1 i.1 i.2.1 i.2.2 j.2.1 j.2.2 := by
  let e : ((S×T×ι)×(S×T×ι)) ≃ ((ι×S×T)×(ι×S×T)) :=
    { toFun := fun p=>((p.2.2.2,p.1.1,p.1.2.1),(p.1.2.2,p.2.1,p.2.2.1))
      invFun := fun p=>((p.1.2.1,p.1.2.2,p.2.1),(p.2.2.1,p.2.2.2,p.1.1))
      left_inv := fun p=>rfl
      right_inv := fun p=>rfl }
  have he := Fintype.sum_equiv e
    (fun p=>F p.1.2.2 p.2.2.2 p.1.1.val p.1.2.1.val p.2.1.val p.2.2.1.val)
    (fun p=>F p.2.1 p.1.1 p.1.2.1.val p.1.2.2.val p.2.2.1.val p.2.2.2.val)
    (fun p=>rfl)
  simp_rw [Fintype.sum_prod_type] at he
  simpa only [Fintype.sum_prod_type,triples,Finset.sum_product,←Finset.sum_coe_sort S,←Finset.sum_coe_sort T] using he

theorem pairIntegrand_continuous {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (Y : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    Continuous (pairIntegrand A value S T Y η ψ α β) := by
  exact continuous_finset_sum _ (fun i _=>continuous_finset_sum _ (fun j _=>
    scalarIntegrand_continuous _ _ _ _ _ _ _ _ _ _ _))

/-- The unrestricted major sum appearing in the signed Cauchy square is
exactly the integral of the separated finite pair integrand. -/
theorem record_scalarMajor_sum_integral {K : ℕ} (b : Artin.MarkedSource.Bands K)
    (x Y H : ℝ) (S T : Finset ℕ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    (∑r : SignedCauchyExpansion.Record b x S T,∑u : SignedCauchyExpansion.Record b x S T,
      scalarMajor (SignedCauchyExpansion.labelProduct b x r.2.2)
        (SignedCauchyExpansion.labelProduct b x u.2.2)
        r.1.val r.2.1.val u.1.val u.2.1.val Y H η ψ α β)=
      ∫θ in sourceMajorArcs H Y,
        pairIntegrand Finset.univ (SignedCauchyExpansion.labelProduct b x) S T Y η ψ α β θ
          ∂productCircleMeasure := by
  rw [record_pair_reindex S T (fun a c m n r s=>scalarMajor
    (SignedCauchyExpansion.labelProduct b x a) (SignedCauchyExpansion.labelProduct b x c)
    m n r s Y H η ψ α β)]
  simp_rw [scalarMajor_eq_integral]
  have hi (a c m n r s : ℕ) : IntegrableOn
      (scalarIntegrand a c m n r s Y η ψ α β) (sourceMajorArcs H Y) productCircleMeasure := by
    exact ((scalarIntegrand_continuous _ _ _ _ _ _ _ _ _ _ _).integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)).integrableOn
  unfold pairIntegrand
  rw [integral_finsetSum _ (fun i _=>integrable_finsetSum _ (fun j _=>hi _ _ _ _ _ _))]
  apply Finset.sum_congr rfl
  intro i hi'
  rw [integral_finsetSum _ (fun j _=>hi _ _ _ _ _ _)]

/-- Ordinary rough coefficient support discharges every long-variable unit
condition in the exact arithmetic character separation. -/
theorem pairIntegrand_characters_of_rough {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (k : ℕ) [NeZero k] (h : ℤ) (W Y lam : ℝ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ)
    (hkW : (k:ℝ)≤W) (ha : ∀a∈A,(value a).Coprime k)
    (hm : ∀m∈S,α m≠0 → Artin.MarkedCriterion.IsRough W m)
    (hn : ∀n∈T,β n≠0 → Artin.MarkedCriterion.IsRough W n) :
    pairIntegrand A value S T Y η ψ α β (((h:ℝ)/k+lam/Y:ℝ):ProductCircle)=
      ∑χ : CharacterTuple k 6,coefficient k 6 (signedRationalPhase k h (-1)) χ*
        characterPair A value S T χ Y lam η ψ α β := by
  apply pairIntegrand_characters A value S T k h Y lam η ψ α β ha
  · intro m hmS hα
    exact Artin.MarkedCriterion.rough_coprime (NeZero.pos k) hkW (hm m hmS hα)
  · intro n hnT hβ
    exact Artin.MarkedCriterion.rough_coprime (NeZero.pos k) hkW (hn n hnT hβ)

end Elliptic.Operator.SignedMajorMellinIdentity
