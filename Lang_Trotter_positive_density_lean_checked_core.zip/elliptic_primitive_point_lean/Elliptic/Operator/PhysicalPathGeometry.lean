module

public import Elliptic.Operator.PhysicalPathRootFinite

/-!
# The original physical signed path sum in one finite root universe

Support hypotheses in the finite reindexing are derived here from the
literal projected source geometry.  The multiplier may encode closure,
all prime incidences and inactive damping.  It is not assumed smooth.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPathGeometry
open scoped BigOperators
open OriginalLifespanSchedule SingleEdgeRootEncoding PhysicalPathRootEncoding
open PhysicalPathRootFinite RootLiteralGeometry SourceRootCount
attribute [local instance] Classical.propDecidable
local instance physicalGeometryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def edge (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (j : ℕ) : ℂ :=
  orientedSourceEdgeGeometry (adjoint j) value
    (sourceGood value μ d₀ Y L exponents (1,1,0))
    1 0 0 U V d₀ Y η ψ major σ (r.positionAt j) (r.sourceLists j)
      (r.positionAt (j+1)) (r.targetLists j)

def pathGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) : ℂ :=
  ∏j∈Finset.range N,edge value μ d₀ Y L U V exponents η ψ major σ adjoint r j

theorem edge_nonzero (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N)
    (h : pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r≠0)
    (j : ℕ) (hj : j<N) : edge value μ d₀ Y L U V exponents η ψ major σ adjoint r j≠0 := by
  intro hz
  apply h
  exact Finset.prod_eq_zero (Finset.mem_range.mpr hj) hz

theorem oriented_nonzero_positions (adjoint : Bool) (value : ∀i,P i→ℕ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop) (u v r U V d₀ Y : ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J)
    (h : orientedSourceEdgeGeometry adjoint value good u v r U V d₀ Y η ψ major σ z a w b≠0) :
    sourcePhysicalPositionAllowed u v r U V z ∧ sourcePhysicalPositionAllowed u v r U V w := by
  have hs (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J)
      (hh : sourcePhysicalEdgeGeometry value good u v r U V d₀ Y η ψ major σ z a w b≠0) :
      sourcePhysicalPositionAllowed u v r U V z ∧ sourcePhysicalPositionAllowed u v r U V w := by
    have ha : sourcePhysicalEdgeAllowed value good u v r U V d₀ z a w b := by
      by_contra hn
      exact hh (by simp [sourcePhysicalEdgeGeometry,hn])
    exact ⟨ha.1,ha.2.1⟩
  cases adjoint
  · exact hs z w a b h
  · have hn : sourcePhysicalEdgeGeometry value good u v r U V d₀ Y η ψ major σ w b z a≠0 := by
      intro hz
      simp [orientedSourceEdgeGeometry,hz] at h
    exact (hs w z b a hn).symm

theorem positionAt_fin (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (j : Fin (N+1)) :
    r.positionAt j.val=r.position j := by
  have h : OriginalPath.visit (N:=N) j.val=j := Fin.ext (Nat.min_eq_left (by omega))
  simp only [OriginalPath.positionAt,h]

theorem physical_support (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (hN : 0<N)
    (h : pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r≠0)
    (j : ℕ) (hj : j≤N) : sourcePhysicalPositionAllowed 1 0 0 U V (r.positionAt j) := by
  by_cases hlt : j<N
  · exact (oriented_nonzero_positions (adjoint j) value _ 1 0 0 U V d₀ Y η ψ major σ
      _ _ _ _ (edge_nonzero value μ d₀ Y L U V exponents η ψ major σ adjoint r h j hlt)).1
  · have hn : N-1<N := by omega
    have hh := (oriented_nonzero_positions (adjoint (N-1)) value _ 1 0 0 U V d₀ Y η ψ major σ
      _ _ _ _ (edge_nonzero value μ d₀ Y L U V exponents η ψ major σ adjoint r h (N-1) hn)).2
    have he : N-1+1=j := by omega
    rwa [he] at hh

theorem physical_support_mem (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (hN : 0<N)
    (h : pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r≠0)
    (j : Fin (N+1)) : r.position j∈primitiveSources U V := by
  have hh := physical_support value μ d₀ Y L U V exponents η ψ major σ adjoint r hN h j.val (by omega)
  rw [positionAt_fin] at hh
  rw [mem_primitiveSources]
  simpa [sourcePhysicalPositionAllowed,rootPhysicalPosition,latticeTau] using hh

/-- Exact complete physical path sum, with all geometric support proved.
The arbitrary multiplier W may contain closure and all primewise factors. -/
theorem sum_eq_rooted_paths (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V C : ℝ) (exponents : Fin K→ℝ) (hU : 0<U)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (hN : 0<N) (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (W : OriginalPath (Fin K) (ℤ×ℤ) P J N→ℂ) :
    (∑r∈positionPaths (primitiveSources U V),
      pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r*W r)=
      ∑t∈canonicalRoots U V,∑r∈rootedPaths ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊,
        pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint (physicalPath t r)*
          W (physicalPath t r) := by
  apply sum_eq_common_root_universe U V hU
  · intro r hr j
    exact physical_support_mem value μ d₀ Y L U V exponents η ψ major σ adjoint r hN
      (left_ne_zero_of_mul hr) j
  · intro t ht r hs hr j
    have hn := left_ne_zero_of_mul hr
    have hh := rootPath_mem_positionBox r adjoint value μ d₀ Y L C exponents U V hU t ht
      η ψ major σ hd hY hC hψ hs
      (physical_support value μ d₀ Y L U V exponents η ψ major σ adjoint r hN hn)
      (edge_nonzero value μ d₀ Y L U V exponents η ψ major σ adjoint r hn)
      j.val (by omega)
    rwa [positionAt_fin] at hh

/-- The same exact identity in any prescribed larger root box. This is
the form used with the common source moment radius. -/
theorem sum_eq_rooted_paths_of_radius (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V C : ℝ) (exponents : Fin K→ℝ) (hU : 0<U)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (hN : 0<N) (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀s,ψ s≠0→|s|≤C)
    (R : ℕ) (hR : ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊≤R)
    (W : OriginalPath (Fin K) (ℤ×ℤ) P J N→ℂ) :
    (∑r∈positionPaths (primitiveSources U V),
      pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r*W r)=
      ∑t∈canonicalRoots U V,∑r∈rootedPaths R,
        pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint (physicalPath t r)*
          W (physicalPath t r) := by
  apply sum_eq_common_root_universe U V hU
  · intro r hr j
    exact physical_support_mem value μ d₀ Y L U V exponents η ψ major σ adjoint r hN
      (left_ne_zero_of_mul hr) j
  · intro t ht r hs hr j
    have hn := left_ne_zero_of_mul hr
    apply integerPositionBox_mono hR
    have hh := rootPath_mem_positionBox r adjoint value μ d₀ Y L C exponents U V hU t ht
      η ψ major σ hd hY hC hψ hs
      (physical_support value μ d₀ Y L U V exponents η ψ major σ adjoint r hN hn)
      (edge_nonzero value μ d₀ Y L U V exponents η ψ major σ adjoint r hn)
      j.val (by omega)
    rwa [positionAt_fin] at hh

end Elliptic.Operator.PhysicalPathGeometry
