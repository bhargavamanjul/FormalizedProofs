module

public import Elliptic.Operator.PhysicalCleanActualSaving
public import Elliptic.Operator.PhysicalDirtySignedAsymptotics
public import Elliptic.Operator.PhysicalDirtySourceProjection
public import Elliptic.Operator.PhysicalFullEdgeNorm

/-! Arbitrary logarithmic saving for the literal full physical edge, in
the original ordered factorial norm.  The major-arc exponent G+6 is fixed
before the number of prime groups.  Both source-good projections, the
clean cancellation and the complete signed dirty remainder are proved. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFullEdgeAsymptotics
open Filter
open scoped BigOperators SchwartzMap
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalDirtyMasks RootLiteralGeometry
open PhysicalCleanActualSaving PhysicalDirtySourceProjection PhysicalBagNorm
attribute [local instance] Classical.propDecidable
local instance fullSavingDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 400000

/-- The original, unmodified physical edge with the literal source geometry. -/
def literalFullOperation {K J B : ℕ}
    (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (ν : Fin K→ℕ→ℝ) (V : Fin K→ℝ) (ρ : ℝ) (μ : ∀i,groups i→ℝ)
    (d₀ Y L : ℝ) (a : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ) :
    ChoiceOperation (SourceMemoryEdgeState positions groups J B) :=
  physicalEdgeOperation (fun i (p:groups i)=>ν i p.val) V ρ
    (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:positions=>z.val))
    (fun z b w c=>sourcePhysicalEdgeGeometry (fun _ p=>p.val)
      (sourceGood (fun _ p=>p.val) μ d₀ Y L a q)
      (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) σ z.val b w.val c)

/-- Changing the enumeration of a complete finite support preserves an
action norm estimate. This avoids comparing the computational enumerators
of large physical bag spaces. -/
theorem full_support_action_bound {X : Type} [Fintype X]
    (s t : Finset X) (hs : ∀x,x∈s) (ht : ∀x,x∈t)
    (m : X→ℝ) (A : X→X→ℂ) (M : ℝ)
    (h : ∀F : X→ℂ,finiteL2 s m (fun x=>∑y∈t,A x y*F y)≤M*finiteL2 t m F) :
    ∀F : X→ℂ,finiteL2 Finset.univ m (fun x=>∑y,A x y*F y)≤
      M*finiteL2 Finset.univ m F := by
  have hs' : s=Finset.univ := Finset.eq_univ_of_forall hs
  have ht' : t=Finset.univ := Finset.eq_univ_of_forall ht
  simpa only [hs',ht'] using h

theorem complete_support_action_bound {X : Type}
    (s t s' t' : Finset X) (hs : ∀x,x∈s) (ht : ∀x,x∈t)
    (hs' : ∀x,x∈s') (ht' : ∀x,x∈t')
    (m : X→ℝ) (A : X→X→ℂ) (M : ℝ)
    (h : ∀F : X→ℂ,finiteL2 s m (fun x=>∑y∈t,A x y*F y)≤M*finiteL2 t m F) :
    ∀F : X→ℂ,finiteL2 s' m (fun x=>∑y∈t',A x y*F y)≤M*finiteL2 t' m F := by
  have he : s=s' := Finset.ext (fun x=>⟨fun _=>hs' x,fun _=>hs x⟩)
  have he' : t=t' := Finset.ext (fun x=>⟨fun _=>ht' x,fun _=>ht x⟩)
  simpa only [he,he'] using h

theorem complete_support_norm_bound {X : Type}
    (s t : Finset X) (hs : ∀x,x∈s) (ht : ∀x,x∈t)
    (m : X→ℝ) (F H : X→ℂ) (M : ℝ)
    (h : finiteL2 s m H≤M*finiteL2 s m F) :
    finiteL2 t m H≤M*finiteL2 t m F := by
  have he : s=t := Finset.ext (fun x=>⟨fun _=>ht x,fun _=>hs x⟩)
  simpa only [he] using h

/-- Choose the major-arc exponent first, then the number of groups. The
large-L threshold is uniform over prime bands, positions, masses, root
coordinates, admissible dyads, signs and all bag-invariant test vectors. -/
theorem exists_group_count_for_actual_full_saving (G : ℝ) (hG : 0≤G) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(Cweight : Fin K→ℝ),(∀i,0≤Cweight i)→
      ∀(ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ Cmass Catom ρ vmin vmax : ℝ),
      1≤C→0≤Aψ→1≤Cmass→0≤Catom→(∀i,Cweight i≤Catom)→
      0≤ρ→ρ<1→0<vmin→
      (∀x,‖η x‖≤1)→(∀x,η x≠0→1≤x)→
      (∀x,‖ψ x‖≤Aψ)→(∀x,ψ x≠0→|x|≤C)→
      ∀ᶠ L : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i (p:groups i),Fintype (ZMod p.val)),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀(ν : Fin K→ℕ→ℝ) (μ : ∀i,groups i→ℝ) (V : Fin K→ℝ),
      (∀i,∀p∈groups i,0<ν i p)→(∀i,∀p∈groups i,ν i p≤Cweight i/p)→
      (∀i,∑p:groups i,ν i p.val≤Cmass)→(∀i (p:groups i),ν i p.val≤2*μ i p)→
      (∀i,vmin≤V i)→(∀i,V i≤vmax)→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      ∀(d₀ Y : ℝ) (q : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤q.1→q.1≤16→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀σ : ℤ,(σ=1∨σ= -1)→
      ∀F : SourceMemoryEdgeState positions groups (momentPadding L) (memoryCutoff L)→ℂ,
      IsBagFunction F→
      finiteL2 Finset.univ
        (PhysicalMemoryState.mass (fun i=>groups i) (fun _i p=>Option (ZMod p.val))
          (momentPadding L) (memoryCutoff L) (fun i (p:groups i)=>ν i p.val))
        ((literalFullOperation positions groups ν V ρ μ d₀ Y L a q U W η ψ (L^(G+6)) σ).apply F)≤
      L^(-G)*finiteL2 Finset.univ
        (PhysicalMemoryState.mass (fun i=>groups i) (fun _i p=>Option (ZMod p.val))
          (momentPadding L) (memoryCutoff L) (fun i (p:groups i)=>ν i p.val)) F := by
  obtain ⟨K₀,hK₀,hdirty⟩ :=
    PhysicalDirtySignedAsymptotics.exists_group_count_for_actual_signed_saving (G+1)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax
    hC hAψ hmassC hCatom hweight hρ0 hρ1 hmin hη hηsupport hψ hψsupport
  have hC0 : 0≤C := (by norm_num : (0:ℝ)≤1).trans hC
  have hm0 : 0≤Cmass := (by norm_num : (0:ℝ)≤1).trans hmassC
  filter_upwards [eventually_actual_clean_saving (G+1) (by linarith) K Cweight hCweight
    ψ η C Aψ Cmass Catom hC0 hAψ hmassC hCatom hweight hη hηsupport hψ hψsupport,
    hdirty K hK ρ 1 vmin vmax Cmass 1 Aψ (G+6) C hρ0 hρ1 (by norm_num) hmin hm0 hAψ hC,
    eventually_ge_atTop (2:ℝ)] with L hc hd hL
  intro a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband
    d₀ Y q U W hU hq hq' hd₀ hY hYlo hYhi σ hσ F hF
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  let value : ∀i,groups i→ℕ := fun _ p=>p.val
  let ν' : ∀i,groups i→ℝ := fun i p=>ν i p.val
  let anchor := PhysicalRawMaskedRow.anchor value (fun z:positions=>z.val)
  let good := sourceGood (J:=momentPadding L) value μ d₀ Y L a q
  let geom := fun (z:positions) b (w:positions) c=>
    sourcePhysicalEdgeGeometry value good (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ
      (sourceMajorArcs (L^(G+6)) Y) σ z.val b w.val c
  have hL0 : 0<L := by linarith
  have hL1 : 1≤L := by linarith
  have hband0 : ∀i,∀p∈groups i,Real.exp (L^(1/10:ℝ))≤(p:ℝ) := by
    intro i p hp
    exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL1 (ha i))).trans (hband i p hp)
  have hu : U≤U*q.1 := by simpa only [mul_one] using mul_le_mul_of_nonneg_left hq hU.le
  have hu' : U*q.1≤16*U := by simpa only [mul_comm] using mul_le_mul_of_nonneg_left hq' hU.le
  have hν' : ∀i p,0<ν' i p := fun i p=>hν i p.val p.property
  have hexp : (G+1)+5=G+6 := by ring
  have hc0 := hc positions groups hprime hdis ν hν hνbound hmass hband0
    (momentPadding L) (memoryCutoff L) (fun _i p=>Option (ZMod p.val)) inferInstance V ρ hρ0 hρ1.le
    anchor μ d₀ Y a q U W hU hq hq' hd₀ hY hYlo hYhi σ hσ
  simp only [hexp,literalCleanKernel] at hc0
  have hd0 := hd a ha positions inferInstance (fun i=>groups i) inferInstance value instLine
    (fun z:positions=>z.val) Subtype.val_injective (fun i p=>hprime i p.val p.property)
    ν' μ V hν' hνμ hmass hVlo hVhi (admissibleGood value good d₀)
    (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y (L^(G+6)) (Real.exp (L^(1/10:ℝ))) η ψ σ
    hU hu hu' hd₀ hY (Real.rpow_nonneg hL0.le _) le_rfl (Real.exp_pos _) hσ hη hψ hψsupport
    (first_projection value μ d₀ Y L a q) (second_projection value μ d₀ Y L a q)
    (fun i p=>hband i p.val p.property) (fun i p=>hband0 i p.val p.property) hYlo le_rfl
  have hgeom : (fun (z:positions) b (w:positions) c=>
      sourcePhysicalEdgeGeometry value (admissibleGood value good d₀)
        (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ (sourceMajorArcs (L^(G+6)) Y) σ z.val b w.val c)=geom := by
    funext z b w c
    exact geometry_admissible_eq value good _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
  simp only [PhysicalDirtySignedSchur.signedKernel,hgeom] at hd0
  have hs := PhysicalFullEdgeNorm.actual_full_edge_l2_le
    (I:=Fin K) (Z:=positions) (P:=fun i=>groups i)
    (Line:=fun _i p=>Option (ZMod p.val)) (J:=momentPadding L) (B:=memoryCutoff L) ν' V ρ anchor geom value hν'
    (L^(-(G+1))) (L^(-(G+1))) (Real.rpow_nonneg hL0.le _) (Real.rpow_nonneg hL0.le _)
    (by
      exact complete_support_action_bound _ _ _ _
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        _ _ _ hc0)
    (by
      exact complete_support_action_bound _ _ _ _
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
        _ _ _ hd0)
    F hF
  have hfinal := hs.trans (mul_le_mul_of_nonneg_right
    (PhysicalDirtyBudgetAsymptotics.combine_savings L G _ _ hL
      (Real.rpow_nonneg hL0.le _) (Real.rpow_nonneg hL0.le _) le_rfl le_rfl) (Real.sqrt_nonneg _))
  exact complete_support_norm_bound _ _
    (by intro x; simp only [Finset.mem_univ]) (by intro x; simp only [Finset.mem_univ])
    _ _ _ _ hfinal

end Elliptic.Operator.PhysicalFullEdgeAsymptotics
