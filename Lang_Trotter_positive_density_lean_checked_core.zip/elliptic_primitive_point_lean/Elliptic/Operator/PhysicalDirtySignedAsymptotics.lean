module

public import Elliptic.Operator.PhysicalDirtySignedSchur
public import Elliptic.Operator.PhysicalDirtyBudgetAsymptotics

/-! Arbitrary logarithmic saving for the literal signed dirty matrix.
The group threshold precedes every later fixed constant, and the large-L
threshold is uniform in all finite prime and position spaces, coefficients,
band exponents, amplitudes and admissible dyads. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtySignedAsymptotics
open Filter
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

 theorem exists_group_count_for_actual_signed_saving (G : ℝ) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀ρ v0 vmin vmax M Aη Aψ E C : ℝ,
      0≤ρ→ρ<1→0<v0→0<vmin→0≤M→0≤Aψ→1≤C→
      ∀ᶠL : ℝ in atTop,∀a : Fin K→ℝ,(∀i,(1/10:ℝ)≤a i)→
        ∀(Z : Type) (_ : Fintype Z) (P : Fin K→Type) (_ : ∀i,Fintype (P i))
        (value : ∀i,P i→ℕ) (_ : ∀i p,Fintype (ZMod (value i p)))
        (position : Z→ℤ×ℤ),Function.Injective position→(∀i p,(value i p).Prime)→
        ∀(ν μ : ∀i,P i→ℝ) (V : Fin K→ℝ),
        (∀i p,0<ν i p)→(∀i p,ν i p≤2*μ i p)→(∀i,(∑p,ν i p)≤M)→
        (∀i,vmin≤V i)→(∀i,V i≤vmax)→
        ∀(good : (ℤ×ℤ)→PhysicalActiveLists P (momentPadding L)→Prop)
        (u v r U W d₀ Y H R : ℝ) (η ψ : ℝ→ℂ) (σ : ℤ),
        0<U→U≤u→u≤16*U→0<d₀→1≤Y→0≤H→H≤L^E→0<R→
        (σ=1 ∨ σ= -1)→(∀t,‖η t‖≤Aη)→(∀t,‖ψ t‖≤Aψ)→
        (∀t,ψ t≠0→|t|≤C)→
        PhysicalComparisonChoices.GoodProjection value r Y good→
        PhysicalRawGlobalRow.GoodProjection value μ d₀ r L a good→
        (∀i p,Real.exp (L^a i)≤(value i p:ℝ))→(∀i p,R≤(value i p:ℝ))→
        Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
        ∀F : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p)))
          (J:=momentPadding L) (B:=memoryCutoff L)→ℂ,
        finiteL2 Finset.univ (mass ν)
          (fun s=>∑t,PhysicalDirtySignedSchur.signedKernel value position ν V ρ good
            u v r U W d₀ Y H η ψ σ s t*F t)≤
        L^(-G)*finiteL2 Finset.univ (mass ν) F := by
  obtain ⟨K₀,hK₀,hbudget⟩ := PhysicalDirtyBudgetAsymptotics.exists_group_count_for_signed_saving G
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ρ v0 vmin vmax M Aη Aψ E C hρ0 hρ1 hv0 hmin hM hψ0 hC
  filter_upwards [hbudget K hK ρ v0 vmin vmax M (Aη^2*Aψ) E C hρ1 hv0 hmin hM
    (mul_nonneg (sq_nonneg _) hψ0) (by linarith)] with L hb
  intro a ha Z instZ P instP value instLine position hposition hprime ν μ V
    hν hνμ hmass hlo hhi good u v r U W d₀ Y H R η ψ σ hU hu hu' hd hY hH hHl hR hσ
    hη hψ hsupport hfirst hsecond hband hband' hYexp hRexp F
  letI : Fintype Z := instZ
  letI : ∀i,Fintype (P i) := instP
  letI : ∀i p,Fintype (ZMod (value i p)) := instLine
  apply (PhysicalDirtySignedSchur.actual_dirty_signed_schur value position hposition hprime
    ν μ hν V ρ v0 vmin M L a good u v r U W d₀ Y H C R Aη Aψ η ψ σ
    hU hu hu' hd hY hH hC hR hσ hη hψ hsupport hfirst hsecond hband hband'
    hνμ hlo hmin hρ0 hρ1 hv0 hM hmass F).trans
  exact mul_le_mul_of_nonneg_right
    (hb a ha P instP ν V H Y R (fun i p=>(hν i p).le) hmass hlo hhi hH hHl hYexp hRexp)
    (Real.sqrt_nonneg _)

end Elliptic.Operator.PhysicalDirtySignedAsymptotics
