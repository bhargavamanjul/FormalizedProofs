module

public import Elliptic.Operator.WeightedSchur
public import Mathlib.Analysis.Fourier.AddCircle

/-!
# Fourier fibers for the enlarged integer-product kernel

The integer product coordinate is treated by exact finite Parseval, rather
than by an estimate losing its support cardinality. The Fourier measure is
normalized Haar measure on the circle of period one.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators ComplexConjugate
open MeasureTheory

abbrev ProductCircle := AddCircle (1 : ℝ)
abbrev productCircleMeasure : Measure ProductCircle := AddCircle.haarAddCircle

/-- A finite Fourier polynomial, with an injective indexing of its integer
frequencies. The negative-frequency embedding handles the row endpoint. -/
def finiteFourierPolynomial (z : Finset ℤ) (freq : ℤ ↪ ℤ) (a : ℤ → ℂ) :
    C(ProductCircle, ℂ) := ∑ n ∈ z, a n • fourier (freq n)

/-- Exact finite Parseval on normalized Haar measure. -/
theorem finiteFourierPolynomial_parseval (z : Finset ℤ) (freq : ℤ ↪ ℤ) (a : ℤ → ℂ) :
    (∫ θ, ‖finiteFourierPolynomial z freq a θ‖ ^ 2 ∂productCircleMeasure) =
      ∑ n ∈ z, ‖a n‖ ^ 2 := by
  have hp : ContinuousMap.toLp 2 productCircleMeasure ℂ (finiteFourierPolynomial z freq a) =
      ∑ n ∈ z, a n • fourierLp (T := (1 : ℝ)) 2 (freq n) := by
    simp [finiteFourierPolynomial, fourierLp]
  have hi := (orthonormal_fourier (T := (1 : ℝ))).comp freq freq.injective
  have hs := hi.inner_sum a a z
  apply Complex.ofReal_injective
  rw [← integral_complex_ofReal]
  calc
    _ = inner ℂ
        (ContinuousMap.toLp 2 productCircleMeasure ℂ (finiteFourierPolynomial z freq a))
        (ContinuousMap.toLp 2 productCircleMeasure ℂ (finiteFourierPolynomial z freq a)) := by
      rw [ContinuousMap.inner_toLp]
      apply integral_congr_ae
      exact Filter.Eventually.of_forall fun θ => by simp [Complex.mul_conj', Complex.ofReal_pow]
    _ = _ := by
      rw [hp]
      simpa [Complex.conj_mul', Complex.ofReal_sum, Complex.ofReal_pow] using hs

/-- The squared L2 norm of a real continuous function is its integral of
squares. The norm is on the actual normalized Haar L2 space. -/
theorem continuous_real_toLp_norm_sq (f : C(ProductCircle, ℝ)) :
    ‖ContinuousMap.toLp 2 productCircleMeasure ℝ f‖ ^ 2 =
      ∫ θ, f θ ^ 2 ∂productCircleMeasure := by
  have h := ContinuousMap.inner_toLp productCircleMeasure f f
  simpa [real_inner_self_eq_norm_sq, sq] using h

/-- Integral Cauchy--Schwarz for continuous real functions, with exact
square-root integral norms. -/
theorem continuous_integral_mul_le (f g : C(ProductCircle, ℝ)) :
    (∫ θ, f θ * g θ ∂productCircleMeasure) ≤
      Real.sqrt (∫ θ, f θ ^ 2 ∂productCircleMeasure) *
        Real.sqrt (∫ θ, g θ ^ 2 ∂productCircleMeasure) := by
  have h := re_inner_le_norm (𝕜 := ℝ)
    (ContinuousMap.toLp 2 productCircleMeasure ℝ f)
    (ContinuousMap.toLp 2 productCircleMeasure ℝ g)
  rw [ContinuousMap.inner_toLp] at h
  have hf : Real.sqrt (∫ θ, f θ ^ 2 ∂productCircleMeasure) =
      ‖ContinuousMap.toLp 2 productCircleMeasure ℝ f‖ := by
    rw [← continuous_real_toLp_norm_sq, Real.sqrt_sq (norm_nonneg _)]
  have hg : Real.sqrt (∫ θ, g θ ^ 2 ∂productCircleMeasure) =
      ‖ContinuousMap.toLp 2 productCircleMeasure ℝ g‖ := by
    rw [← continuous_real_toLp_norm_sq, Real.sqrt_sq (norm_nonneg _)]
  rw [hf, hg]
  simpa [mul_comm] using h

/-- Integrability of continuous functions on the compact product circle
for any finite measure, including a restricted Haar measure. -/
theorem productCircle_integrable {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] (f : ProductCircle → E) (hf : Continuous f)
    (m : Measure ProductCircle) [IsFiniteMeasure m] : Integrable f m := by
  exact memLp_one_iff_integrable.mp
    (ContinuousMap.memLp (μ := m) (p := 1) ℝ (⟨f, hf⟩ : C(ProductCircle, E)))

/-- The rowwise L2 norm of a vector of finite Fourier polynomials. -/
def fourierEnergyRoot {ι : Type*} (s : Finset ι) (z : Finset ℤ)
    (freq : ℤ ↪ ℤ) (a : ι × ℤ → ℂ) : C(ProductCircle, ℝ) where
  toFun θ := Real.sqrt (∑ i ∈ s, ‖finiteFourierPolynomial z freq (fun n => a (i, n)) θ‖ ^ 2)
  continuous_toFun := Real.continuous_sqrt.comp (continuous_finsetSum s
    (fun i _ => (finiteFourierPolynomial z freq (fun n => a (i, n))).continuous.norm.pow 2))

theorem fourierEnergyRoot_nonneg {ι : Type*} (s : Finset ι) (z : Finset ℤ)
    (freq : ℤ ↪ ℤ) (a : ι × ℤ → ℂ) (θ : ProductCircle) :
    0 ≤ fourierEnergyRoot s z freq a θ := Real.sqrt_nonneg _

/-- Parseval summed over the finite geometric state set; the integer
product-coordinate support contributes no cardinality factor. -/
theorem fourierEnergyRoot_integral_sq {ι : Type*} (s : Finset ι) (z : Finset ℤ)
    (freq : ℤ ↪ ℤ) (a : ι × ℤ → ℂ) :
    (∫ θ, fourierEnergyRoot s z freq a θ ^ 2 ∂productCircleMeasure) =
      ∑ p ∈ (s ×ˢ z), ‖a p‖ ^ 2 := by
  have hs (θ : ProductCircle) : fourierEnergyRoot s z freq a θ ^ 2 =
      ∑ i ∈ s, ‖finiteFourierPolynomial z freq (fun n => a (i, n)) θ‖ ^ 2 :=
    Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)
  simp_rw [hs]
  rw [integral_finsetSum s]
  · simp_rw [finiteFourierPolynomial_parseval]
    exact (Finset.sum_product s z (fun p => ‖a p‖ ^ 2)).symm
  · intro i hi
    exact productCircle_integrable _
      ((finiteFourierPolynomial z freq (fun n => a (i, n))).continuous.norm.pow 2) _

/-- Fourier extension in the unrestricted integer product coordinates,
integrated over an arbitrary minor-arc set. -/
def integratedProductKernel {ι κ : Type*} (minor : Set ProductCircle)
    (G : ι → κ → C(ProductCircle, ℂ)) (rowFreq colFreq : ℤ ↪ ℤ)
    (p : ι × ℤ) (q : κ × ℤ) : ℂ :=
  ∫ θ in minor, G p.1 q.1 θ * fourier (rowFreq p.2) θ * fourier (colFreq q.2) θ
    ∂productCircleMeasure

/-- Exact finite Fourier factorization before integration. -/
theorem finitePairing_fourier_factorization {ι κ : Type*}
    (s : Finset ι) (t : Finset κ) (z w : Finset ℤ)
    (G : ι → κ → C(ProductCircle, ℂ)) (rowFreq colFreq : ℤ ↪ ℤ)
    (a : ι × ℤ → ℂ) (b : κ × ℤ → ℂ) (θ : ProductCircle) :
    Elliptic.SourceContracts.finitePairing ((s ×ˢ z)) ((t ×ˢ w))
      (fun p q => G p.1 q.1 θ * fourier (rowFreq p.2) θ * fourier (colFreq q.2) θ) a b =
      Elliptic.SourceContracts.finitePairing s t (fun i j => G i j θ)
        (fun i => finiteFourierPolynomial z rowFreq (fun n => a (i, n)) θ)
        (fun j => finiteFourierPolynomial w colFreq (fun n => b (j, n)) θ) := by
  unfold Elliptic.SourceContracts.finitePairing
  simp_rw [Finset.sum_product]
  apply Finset.sum_congr rfl
  intro i hi
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  simp only [finiteFourierPolynomial, ContinuousMap.sum_apply,
    ContinuousMap.smul_apply, smul_eq_mul]
  simp_rw [Finset.sum_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m hm
  apply Finset.sum_congr rfl
  intro n hn
  ring

/-- Passing a finite bilinear pairing through an actual integral. -/
theorem finitePairing_integral {ι κ : Type*} (s : Finset ι) (t : Finset κ)
    (m : Measure ProductCircle) (F : ι → κ → ProductCircle → ℂ)
    (hF : ∀ i ∈ s, ∀ j ∈ t, Integrable (F i j) m)
    (a : ι → ℂ) (b : κ → ℂ) :
    Elliptic.SourceContracts.finitePairing s t (fun i j => ∫ θ, F i j θ ∂m) a b =
      ∫ θ, Elliptic.SourceContracts.finitePairing s t (fun i j => F i j θ) a b ∂m := by
  unfold Elliptic.SourceContracts.finitePairing
  rw [integral_finsetSum s (fun i hi => integrable_finsetSum t
    (fun j hj => ((hF i hi j hj).const_mul _).mul_const _))]
  apply Finset.sum_congr rfl
  intro i hi
  rw [integral_finsetSum t (fun j hj => ((hF i hi j hj).const_mul _).mul_const _)]
  apply Finset.sum_congr rfl
  intro j hj
  rw [integral_mul_const, integral_const_mul]

/-- The integrated product kernel pairs exactly as the integral of its
finite-dimensional geometric Fourier fibers. -/
theorem finitePairing_integratedProductKernel {ι κ : Type*}
    (s : Finset ι) (t : Finset κ) (z w : Finset ℤ) (minor : Set ProductCircle)
    (G : ι → κ → C(ProductCircle, ℂ)) (rowFreq colFreq : ℤ ↪ ℤ)
    (a : ι × ℤ → ℂ) (b : κ × ℤ → ℂ) :
    Elliptic.SourceContracts.finitePairing ((s ×ˢ z)) ((t ×ˢ w))
      (integratedProductKernel minor G rowFreq colFreq) a b =
      ∫ θ in minor, Elliptic.SourceContracts.finitePairing s t (fun i j => G i j θ)
        (fun i => finiteFourierPolynomial z rowFreq (fun n => a (i, n)) θ)
        (fun j => finiteFourierPolynomial w colFreq (fun n => b (j, n)) θ)
        ∂productCircleMeasure := by
  unfold integratedProductKernel
  rw [finitePairing_integral]
  · apply integral_congr_ae
    exact Filter.Eventually.of_forall
      (finitePairing_fourier_factorization s t z w G rowFreq colFreq a b)
  · intro p hp q hq
    exact productCircle_integrable _ (((G p.1 q.1).continuous.mul
      (fourier (rowFreq p.2)).continuous).mul (fourier (colFreq q.2)).continuous) _

/-- A uniform bound for the determinant Fourier fibers on the minor arcs gives the same
bound for the entire integrated product kernel. Exact Parseval removes
all dependence on the cardinalities of the integer-product supports. -/
theorem integratedProductKernel_bound {ι κ : Type*}
    (s : Finset ι) (t : Finset κ) (z w : Finset ℤ) (minor : Set ProductCircle)
    (G : ι → κ → C(ProductCircle, ℂ)) (rowFreq colFreq : ℤ ↪ ℤ)
    (M : ℝ) (hM : 0 ≤ M) (hminor : MeasurableSet minor)
    (hG : ∀ θ ∈ minor, Elliptic.SourceContracts.FiniteBilinearBound s t (fun i j => G i j θ) M) :
    Elliptic.SourceContracts.FiniteBilinearBound ((s ×ˢ z)) ((t ×ˢ w))
      (integratedProductKernel minor G rowFreq colFreq) M := by
  intro a b
  let F := fourierEnergyRoot s z rowFreq a
  let H := fourierEnergyRoot t w colFreq b
  let pair := fun θ => Elliptic.SourceContracts.finitePairing s t (fun i j => G i j θ)
    (fun i => finiteFourierPolynomial z rowFreq (fun n => a (i, n)) θ)
    (fun j => finiteFourierPolynomial w colFreq (fun n => b (j, n)) θ)
  have hpair : Continuous pair := by
    apply continuous_finsetSum s
    intro i hi
    apply continuous_finsetSum t
    intro j hj
    exact (((finiteFourierPolynomial z rowFreq (fun n => a (i, n))).continuous.mul
      (G i j).continuous).mul
        (finiteFourierPolynomial w colFreq (fun n => b (j, n))).continuous)
  have hFH : Continuous (fun θ => F θ * H θ) := F.continuous.mul H.continuous
  have hmajor : Continuous (fun θ => M * F θ * H θ) :=
    (continuous_const.mul F.continuous).mul H.continuous
  have hpoint : ∀ᵐ θ ∂productCircleMeasure.restrict minor, ‖pair θ‖ ≤ M * F θ * H θ :=
    (ae_restrict_mem hminor).mono fun θ hθ => hG θ hθ _ _
  rw [finitePairing_integratedProductKernel]
  change ‖∫ θ in minor, pair θ ∂productCircleMeasure‖ ≤ _
  calc
    _ ≤ ∫ θ in minor, ‖pair θ‖ ∂productCircleMeasure := norm_integral_le_integral_norm _
    _ ≤ ∫ θ in minor, M * F θ * H θ ∂productCircleMeasure :=
      integral_mono_ae (productCircle_integrable _ hpair.norm _)
        (productCircle_integrable _ hmajor _) hpoint
    _ = M * ∫ θ in minor, F θ * H θ ∂productCircleMeasure := by
      simp_rw [mul_assoc]
      exact integral_const_mul M _
    _ ≤ M * ∫ θ, F θ * H θ ∂productCircleMeasure := by
      apply mul_le_mul_of_nonneg_left _ hM
      exact integral_mono_measure Measure.restrict_le_self
        (Filter.Eventually.of_forall fun θ => mul_nonneg
          (fourierEnergyRoot_nonneg s z rowFreq a θ)
          (fourierEnergyRoot_nonneg t w colFreq b θ))
        (productCircle_integrable _ hFH _)
    _ ≤ M * (Real.sqrt (∫ θ, F θ ^ 2 ∂productCircleMeasure) *
        Real.sqrt (∫ θ, H θ ^ 2 ∂productCircleMeasure)) :=
      mul_le_mul_of_nonneg_left (continuous_integral_mul_le F H) hM
    _ = _ := by
      dsimp [F, H]
      rw [fourierEnergyRoot_integral_sq, fourierEnergyRoot_integral_sq]
      ring

/-- The exact minor-arc Fourier transform at an integer argument. -/
def minorFourierTransform (minor : Set ProductCircle) (n : ℤ) : ℂ :=
  ∫ θ in minor, fourier n θ ∂productCircleMeasure

/-- The determinant fiber on the geometric state space. -/
def integerDeterminantFiber {ι κ : Type*}
    (cutoff : ι → κ → ℂ) (det : ι → κ → ℤ) (i : ι) (j : κ) :
    C(ProductCircle, ℂ) := cutoff i j • fourier (det i j)

/-- An exact identification of the product Fourier extension with its
minor-arc transform. -/
theorem integratedProductKernel_integerDeterminant_eq {ι κ : Type*}
    (minor : Set ProductCircle) (cutoff : ι → κ → ℂ) (det : ι → κ → ℤ)
    (rowFreq colFreq : ℤ ↪ ℤ) (p : ι × ℤ) (q : κ × ℤ) :
    integratedProductKernel minor (integerDeterminantFiber cutoff det) rowFreq colFreq p q =
      cutoff p.1 q.1 * minorFourierTransform minor
        (det p.1 q.1 + rowFreq p.2 + colFreq q.2) := by
  unfold integratedProductKernel minorFourierTransform integerDeterminantFiber
  rw [← integral_const_mul]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall fun θ => by
    simp only [ContinuousMap.smul_apply, smul_eq_mul, fourier_add]
    ring

/-- Reflection of an integer Fourier frequency. -/
def negativeFrequency : ℤ ↪ ℤ where
  toFun n := -n
  inj' := neg_injective

/-- The actual integrated clean kernel with either shift sign. -/
def signedIntegerCleanKernel {ι κ : Type*}
    (minor : Set ProductCircle) (cutoff : ι → κ → ℂ) (det : ι → κ → ℤ)
    (σ : ℤ) (p : ι × ℤ) (q : κ × ℤ) : ℂ :=
  cutoff p.1 q.1 * minorFourierTransform minor (det p.1 q.1 - σ * p.2 + σ * q.2)

/-- The complete integrated clean-kernel bound for either sign follows
from the same determinant Fourier-fiber bound on the minor arcs. This derives the extension
through the integer product coordinate by Parseval; it does not assume an
integrated enlarged-kernel estimate or a signed source moment estimate. -/
theorem signedIntegerCleanKernel_bound {ι κ : Type*}
    (s : Finset ι) (t : Finset κ) (z w : Finset ℤ)
    (minor : Set ProductCircle) (cutoff : ι → κ → ℂ) (det : ι → κ → ℤ)
    (M : ℝ) (hM : 0 ≤ M) (hminor : MeasurableSet minor)
    (hG : ∀ θ ∈ minor, Elliptic.SourceContracts.FiniteBilinearBound s t
      (fun i j => cutoff i j * fourier (det i j) θ) M)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    Elliptic.SourceContracts.FiniteBilinearBound (s ×ˢ z) (t ×ˢ w)
      (signedIntegerCleanKernel minor cutoff det σ) M := by
  have hGc : ∀ θ ∈ minor, Elliptic.SourceContracts.FiniteBilinearBound s t
      (fun i j => integerDeterminantFiber cutoff det i j θ) M := hG
  rcases hσ with rfl | rfl
  · have h := integratedProductKernel_bound s t z w minor
      (integerDeterminantFiber cutoff det) negativeFrequency (Function.Embedding.refl ℤ) M hM hminor hGc
    have heq : integratedProductKernel minor (integerDeterminantFiber cutoff det)
        negativeFrequency (Function.Embedding.refl ℤ) = signedIntegerCleanKernel minor cutoff det 1 := by
      funext p q
      rw [integratedProductKernel_integerDeterminant_eq]
      simp [signedIntegerCleanKernel, negativeFrequency, sub_eq_add_neg]
    rw [heq] at h
    exact h
  · have h := integratedProductKernel_bound s t z w minor
      (integerDeterminantFiber cutoff det) (Function.Embedding.refl ℤ) negativeFrequency M hM hminor hGc
    have heq : integratedProductKernel minor (integerDeterminantFiber cutoff det)
        (Function.Embedding.refl ℤ) negativeFrequency = signedIntegerCleanKernel minor cutoff det (-1) := by
      funext p q
      rw [integratedProductKernel_integerDeterminant_eq]
      simp [signedIntegerCleanKernel, negativeFrequency, sub_eq_add_neg]
    rw [heq] at h
    exact h

/-- The circle Fourier monomial is the usual additive exponential on any
real representative of the circle coordinate. -/
theorem fourier_eq_additivePhase (n : ℤ) (θ : ℝ) :
    fourier n (θ : ProductCircle) = Elliptic.SourceContracts.additivePhase (θ * n) := by
  rw [fourier_coe_apply]
  unfold Elliptic.SourceContracts.additivePhase
  congr 1
  push_cast
  ring

/-- The signed integrated clean bound on arbitrary finite supports inside
a geometric-state/product-coordinate rectangle. Restriction contributes
no factor and does not require the actual supports to be rectangles. -/
theorem signedIntegerCleanKernel_bound_restrict {ι κ : Type*}
    (s : Finset ι) (t : Finset κ) (z w : Finset ℤ)
    (S : Finset (ι × ℤ)) (T : Finset (κ × ℤ))
    (hS : S ⊆ s ×ˢ z) (hT : T ⊆ t ×ˢ w)
    (minor : Set ProductCircle) (cutoff : ι → κ → ℂ) (det : ι → κ → ℤ)
    (M : ℝ) (hM : 0 ≤ M) (hminor : MeasurableSet minor)
    (hG : ∀ θ ∈ minor, Elliptic.SourceContracts.FiniteBilinearBound s t
      (fun i j => cutoff i j * fourier (det i j) θ) M)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    Elliptic.SourceContracts.FiniteBilinearBound S T
      (signedIntegerCleanKernel minor cutoff det σ) M :=
  finiteBilinearBound_restrict (s ×ˢ z) S (t ×ˢ w) T hS hT _ M
    (signedIntegerCleanKernel_bound s t z w minor cutoff det M hM hminor hG σ hσ)

end Elliptic.Operator
