module
public import Elliptic.Operator.CleanFiberAssembly
public import Elliptic.Operator.MajorArcMeasure

/-! Small-atom cost of the actual fresh-label coincidence event.
The finite product law is summed exactly; fresh tuple cardinalities never
replace their prime masses. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.CleanCoincidence
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance cleanCoincidenceDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type*} [Fintype I] {P : I → Type*} [∀ i, Fintype (P i)]

def tupleMass (ν : ∀ i, P i → ℝ) (p : ∀ i, P i) : ℝ := ∏ i, ν i (p i)

def oneCoordinateWeight (ν : ∀ i, P i → ℝ) (p : ∀ i, P i) (i j : I) (q : P j) : ℝ :=
  if j=i then if q=p j then ν j q else 0 else ν j q

theorem coordinate_indicator_product (ν : ∀ i, P i → ℝ) (p q : ∀ i, P i) (i : I) :
    (if q i=p i then tupleMass ν q else 0) = ∏ j, oneCoordinateWeight ν p i j (q j) := by
  by_cases hi : q i=p i
  · rw [ite_eq_left hi]
    apply Finset.prod_congr rfl
    intro j hj
    by_cases hji : j=i
    · subst j
      simp [oneCoordinateWeight,hi]
    · simp [oneCoordinateWeight,hji]
  · rw [ite_eq_right hi]
    symm
    exact Finset.prod_eq_zero (Finset.mem_univ i) (by simp [oneCoordinateWeight,hi])

/-- The exact finite marginal of a single specified fresh coordinate. -/
theorem coordinate_mass (ν : ∀ i, P i → ℝ) (p : ∀ i, P i) (i : I) :
    (∑ q : ∀ i, P i, if q i=p i then tupleMass ν q else 0) =
      ν i (p i) * ∏ j∈Finset.univ.erase i, ∑ q : P j, ν j q := by
  simp_rw [coordinate_indicator_product]
  rw [← Fintype.prod_sum]
  rw [← Finset.mul_prod_erase Finset.univ _ (Finset.mem_univ i)]
  congr 1
  · simp [oneCoordinateWeight]
  · apply Finset.prod_congr rfl
    intro j hj
    simp [oneCoordinateWeight,(Finset.mem_erase.mp hj).1]

/-- Uniform mass of one coincidence, with no cardinality of any prime
band or fresh-tuple space. -/
theorem coordinate_mass_le (ν : ∀ i, P i → ℝ) (p : ∀ i, P i)
    (C δ : ℝ) (hν : ∀ i q, 0≤ν i q) (hC : 1≤C) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ q : P i, ν i q≤C) (hatom : ∀ i q, ν i q≤δ) (i : I) :
    (∑ q : ∀ i, P i, if q i=p i then tupleMass ν q else 0) ≤ δ*C^(Fintype.card I) := by
  rw [coordinate_mass]
  have hprod : (∏ j∈Finset.univ.erase i, ∑ q : P j, ν j q) ≤ C^(Fintype.card I) := by
    calc
      _ ≤ ∏ _j∈Finset.univ.erase i, C := Finset.prod_le_prod₀
        (fun j _ => Finset.sum_nonneg (fun q _ => hν j q)) (fun j _ => hmass j)
      _ = C^((Finset.univ.erase i).card) := by simp
      _ ≤ _ := pow_le_pow_right₀ hC (Finset.card_erase_le.trans (by simp))
  exact mul_le_mul (hatom i (p i)) hprod
    (Finset.prod_nonneg (fun j _ => Finset.sum_nonneg (fun q _ => hν j q))) hδ

/-- Literal union bound for the source/target fresh-label coincidence event. -/
theorem coincidence_mass_le (ν : ∀ i, P i → ℝ) (p : ∀ i, P i)
    (C δ : ℝ) (hν : ∀ i q, 0≤ν i q) (hC : 1≤C) (hδ : 0≤δ)
    (hmass : ∀ i, ∑ q : P i, ν i q≤C) (hatom : ∀ i q, ν i q≤δ) :
    (∑ q : ∀ i, P i, if ∃ i, q i=p i then tupleMass ν q else 0) ≤
      (Fintype.card I:ℝ)*δ*C^(Fintype.card I) := by
  calc
    _ ≤ ∑ q : ∀ i, P i, ∑ i : I, if q i=p i then tupleMass ν q else 0 := by
      apply Finset.sum_le_sum
      intro q hq
      by_cases h : ∃ i, q i=p i
      · rw [ite_eq_left h]
        obtain ⟨i,hi⟩ := h
        have hh := Finset.single_le_sum (s:=Finset.univ)
          (f:=fun j : I => if q j=p j then tupleMass ν q else 0)
          (fun j _ => show 0≤(if q j=p j then tupleMass ν q else 0) from by
            split_ifs
            · exact Finset.prod_nonneg (fun j _ => hν j (q j))
            · rfl) (Finset.mem_univ i)
        simpa only [ite_eq_left hi] using hh
      · rw [ite_eq_right h]
        apply Finset.sum_nonneg
        intro i hi
        split_ifs <;> try positivity
        exact Finset.prod_nonneg (fun j _ => hν j (q j))
    _ = ∑ i : I, ∑ q : ∀ i, P i, if q i=p i then tupleMass ν q else 0 := Finset.sum_comm
    _ ≤ ∑ _i : I, δ*C^(Fintype.card I) :=
      Finset.sum_le_sum (fun i _ => coordinate_mass_le ν p C δ hν hC hδ hmass hatom i)
    _ = _ := by simp; ring

/-- Fixed-target geometric rows are integrated against the actual fresh
law on the literal coincidence event. -/
theorem coincidence_row_le {Z W : Type*}
    (t : Finset W) (ν : ∀ i, P i → ℝ) (C δ R : ℝ)
    (hν : ∀ i q, 0≤ν i q) (hC : 1≤C) (hδ : 0≤δ) (hR : 0≤R)
    (hmass : ∀ i, ∑ q : P i, ν i q≤C) (hatom : ∀ i q, ν i q≤δ)
    (K : Z×(∀ i,P i) → W×(∀ i,P i) → ℂ) (z : Z) (p : ∀ i,P i)
    (hrow : ∀ q : ∀ i,P i, ∑ w∈t, ‖K (z,p) (w,q)‖≤R) :
    (∑ y∈t×ˢ(Finset.univ : Finset (∀ i,P i)), tupleMass ν y.2*
      ‖if ∃ i, y.2 i=p i then K (z,p) y else 0‖) ≤
      R*((Fintype.card I:ℝ)*δ*C^(Fintype.card I)) := by
  rw [Finset.sum_product,Finset.sum_comm]
  calc
    _ ≤ ∑ q : ∀ i,P i, R*(if ∃ i, q i=p i then tupleMass ν q else 0) := by
      apply Finset.sum_le_sum
      intro q hq
      by_cases h : ∃ i, q i=p i
      · simp only [ite_eq_left h,← Finset.mul_sum]
        have hh := mul_le_mul_of_nonneg_left (hrow q) (show 0≤tupleMass ν q from Finset.prod_nonneg (fun i _ => hν i (q i)))
        simpa only [mul_comm] using hh
      · simp only [ite_eq_right h,norm_zero,mul_zero,Finset.sum_const_zero]
        rfl
    _ = R*(∑ q : ∀ i,P i, if ∃ i, q i=p i then tupleMass ν q else 0) := by rw [Finset.mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (coincidence_mass_le ν p C δ hν hC hδ hmass hatom) hR

/-- The coincidence error has its actual small-atom norm. Both geometric
rows are positional rows with fixed prime labels; no tuple-counting bound
or arbitrary Schur-product contraction is being assumed. -/
theorem coincidence_kernel_bound {Z W : Type*}
    (s : Finset Z) (t : Finset W) (ν : ∀ i, P i → ℝ) (C δ R : ℝ)
    (hν : ∀ i q, 0≤ν i q) (hC : 1≤C) (hδ : 0≤δ) (hR : 0≤R)
    (hmass : ∀ i, ∑ q : P i, ν i q≤C) (hatom : ∀ i q, ν i q≤δ)
    (K : Z×(∀ i,P i) → W×(∀ i,P i) → ℂ)
    (hrow : ∀ z∈s, ∀ p q : ∀ i,P i, ∑ w∈t, ‖K (z,p) (w,q)‖≤R)
    (hcol : ∀ w∈t, ∀ p q : ∀ i,P i, ∑ z∈s, ‖K (z,p) (w,q)‖≤R) :
    FiniteMeasuredBilinearBound (s×ˢFinset.univ) (t×ˢFinset.univ)
      (fun x => tupleMass ν x.2) (fun y => tupleMass ν y.2)
      (fun x y => if ∃ i, y.2 i=x.2 i then K x y else 0)
      (R*((Fintype.card I:ℝ)*δ*C^(Fintype.card I))) := by
  let E := R*((Fintype.card I:ℝ)*δ*C^(Fintype.card I))
  have hE : 0≤E := by
    dsimp [E]
    have hC0 : 0≤C := by linarith
    positivity
  have hm (p : ∀ i,P i) : 0≤tupleMass ν p := Finset.prod_nonneg (fun i _ => hν i (p i))
  apply finiteMeasuredBilinearBound_of_kernel_bound _ _ _ _ (fun x _ => hm x.2) _ E
  intro b
  have h := finite_weighted_schur (s×ˢFinset.univ) (t×ˢFinset.univ)
    (fun x => tupleMass ν x.2) (fun _ => 1) (fun y => tupleMass ν y.2) (fun _ => 1)
    (fun x y => if ∃ i, y.2 i=x.2 i then K x y else 0) E E
    (fun x _ => hm x.2) (fun y _ => hm y.2) (fun _ _ => zero_lt_one) (fun _ _ => zero_lt_one)
    hE hE ?_ ?_ b
  · simpa only [Real.sqrt_mul_self hE] using h
  · intro x hx
    simp only [mul_one]
    exact coincidence_row_le t ν C δ R hν hC hδ hR hmass hatom K x.1 x.2
      (fun q => hrow x.1 (Finset.mem_product.mp hx).1 x.2 q)
  · intro y hy
    simp only [mul_one]
    have hh := coincidence_row_le s ν C δ R hν hC hδ hR hmass hatom
      (fun y x => K x y) y.1 y.2
      (fun p => hcol y.1 (Finset.mem_product.mp hy).1 p y.2)
    have he (x : Z×(∀ i,P i)) : (∃ i, x.2 i=y.2 i) ↔ (∃ i, y.2 i=x.2 i) := by
      constructor <;> rintro ⟨i,hi⟩ <;> exact ⟨i,hi.symm⟩
    simpa only [he] using hh

end Elliptic.Operator.CleanCoincidence
