module

public import Elliptic.Operator.PhysicalMaskedSchur
public import Elliptic.Operator.PhysicalComparisonChoices
public import Elliptic.Operator.PhysicalChoiceFiberWeight
public import Elliptic.Operator.SourceComparisonGeometry
public import Elliptic.Operator.PhysicalBagRepresentatives

/-! Actual comparison rows, with retained old-particle line savings and
literal fresh-prime masses. Both endpoint permutation averages cancel. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalComparisonMaskedRow
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
local instance compMaskedDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable [Fintype Z] [∀ i,Fintype (P i)]
variable (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
variable [∀i p,Fintype (ZMod (value i p))]
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p=>Option (ZMod (value i p))) J B)

/-- The literal source anchor used throughout the physical row. -/
def anchor (z : Z) (i : Fin K) (p : P i) := primeResidueAnchor (value i p) (position z)

/-- The actual comparison subrow selected by both Boolean masks. -/
def choices (S I : Fin K → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ) : Finset (PhysicalEdgeChoice s) :=
  Finset.univ.filter (fun c => PhysicalComparisonChoices.Support value position s good u v r U W d₀ Y C c ∧
    ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i)

/-- The comparison amplitude estimate retains exactly the actual indexed mask
support. It does not replace that support by a Cartesian product. -/
theorem choiceRow_le_comparison
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (S I : Fin K → Bool) (ρ v0 A : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0)
    (hamp : ∀ z a w b, sourceComparisonAllowed value good u v r U W d₀ Y C z a w b → ‖amplitude z a w b‖ ≤ A) :
    choiceRow ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b) s ≤
    A * (endpointPermutationWeight (Fin K) J *
      ∑ c ∈ choices value position s S I good u v r U W d₀ Y C,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) := by
  unfold choiceRow choices
  simp only [Finset.sum_filter,Finset.mul_sum]
  conv_lhs =>
    arg 1
    equals (Finset.univ : Finset (PhysicalEdgeChoice s)) =>
      ext c
      simp only [Finset.mem_univ]
  apply Finset.sum_le_sum
  intro c _
  by_cases hc : c.Valid (anchor value position) s
  · rw [dite_eq_left hc]
    by_cases hm : ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i
    · rw [ite_eq_left hm]
      by_cases hg : sourceComparisonAllowed value good u v r U W d₀ Y C
          (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) c.sourceLists
          (position c.target) c.targetLists
      · have hr : PhysicalComparisonChoices.Support value position s good u v r U W d₀ Y C c := ⟨hc,hg.1,hg.2⟩
        rw [ite_eq_left ⟨hr,hm⟩]
        rw [physicalEdgeChoiceWeight_norm_mul_ratio ν V ρ v0 _ _ s c hc hν hV hρ]
        simp only [sourceComparisonGeometry,ite_eq_left hg]
        have hw := PhysicalDirtyWeighted.choiceWeight_nonneg value position s ν V ρ v0 c hν hV hρ hv0
        change endpointPermutationWeight (Fin K) J * ‖amplitude _ _ _ _‖ *
          PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c ≤ _
        calc
          _ ≤ endpointPermutationWeight (Fin K) J * A *
              PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c := by
            exact mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left (hamp _ _ _ _ hg)
                (by unfold endpointPermutationWeight; positivity)) hw
          _ = _ := by ring
      · have hr : ¬PhysicalComparisonChoices.Support value position s good u v r U W d₀ Y C c :=
          fun h => hg ⟨h.2.1,h.2.2⟩
        rw [ite_eq_right (fun h => hr h.1)]
        simp only [physicalEdgeChoiceWeight,sourceComparisonGeometry,ite_eq_right hg,mul_zero,zero_mul,norm_zero]
        exact le_rfl
    · rw [ite_eq_right hm,ite_eq_right (fun h => hm h.2)]
      simp
  · have hr : ¬PhysicalComparisonChoices.Support value position s good u v r U W d₀ Y C c := fun h => hc h.1
    rw [dite_eq_right hc,ite_eq_right (fun h => hr h.1)]
    simp

/-- The actual bag row has the same literal comparison masked bound. -/
theorem bag_row_le_comparison
    (ν : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool) (ρ v0 A : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0)
    (hamp : ∀ z a w b, sourceComparisonAllowed value good u v r U W d₀ Y C z a w b → ‖amplitude z a w b‖ ≤ A) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b)
      (ofOrdered s) ≤
    A * (endpointPermutationWeight (Fin K) J *
      ∑ c ∈ choices value position s S I good u v r U W d₀ Y C,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) :=
  (row_le_choices_named ν (fun i p => (hνpos i p).ne') V S I ρ v0 hv0 _ _ s).trans
    (choiceRow_le_comparison value position s ν V S I ρ v0 A good u v r U W d₀ Y C amplitude
      (fun i p => (hνpos i p).le) hV hρ hv0 hamp)


/-- The target count before multiplying by the O(H³/Y) comparison scalar. -/
def targetBudget (Y C R : ℝ) (I : Fin K→Bool) : ℝ :=
  if ∃i,I i=true then 72*(256*(512*C))^2*Y*(R⁻¹+Y^(-(1/5:ℝ)))
  else 33*(2*C+1)*Y

 theorem targetBudget_nonneg (Y C R : ℝ) (I : Fin K→Bool)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R) : 0≤targetBudget Y C R I := by
  unfold targetBudget
  split_ifs <;> positivity

/-- Actual ordered masked comparison row. A promotion gives the retained
line saving; the empty promotion mask has the ordinary O(Y) count. -/
theorem ordered_row_le
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ) (S I : Fin K→Bool)
    (ρ v0 A : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ))
    (hg : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) (hA : 0≤A)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (hamp : ∀z a w b,sourceComparisonAllowed value good u v r U W d₀ Y C z a w b→‖amplitude z a w b‖≤A) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b)
      (ofOrdered s)≤A*(targetBudget Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0) := by
  apply (bag_row_le_comparison value position s ν hνpos V S I ρ v0 A good
    u v r U W d₀ Y C amplitude hV hρ0 hv0.le hamp).trans
  apply mul_le_mul_of_nonneg_left _ hA
  apply PhysicalChoiceFiberWeight.endpoint_sum_le value position s ν V ρ v0
    (targetBudget Y C R I) (fun i p=>(hνpos i p).le) hV hρ0 hρ1 hv0
    (targetBudget_nonneg Y C R I (by linarith) (by linarith) hR.le)
  intro k
  by_cases hI : ∃i,I i=true
  · rw [targetBudget,ite_eq_left hI]
    apply PhysicalComparisonChoices.fixed_key_card_le value position s hposition hprime good
      u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband hg
    · intro c hc
      exact (Finset.mem_filter.mp (Finset.mem_filter.mp hc).1).2.1
    · intro c hc d hd
      exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm
    · intro c hc
      obtain ⟨i,hi⟩ := hI
      exact ⟨i,((Finset.mem_filter.mp (Finset.mem_filter.mp hc).1).2.2 i).2.trans hi⟩
  · rw [targetBudget,ite_eq_right hI]
    apply PhysicalComparisonChoices.fixed_key_card_le_coarse value position s hposition good
      u v r U W d₀ Y C hU hY (by linarith)
    · intro c hc
      exact (Finset.mem_filter.mp (Finset.mem_filter.mp hc).1).2.1
    · intro c hc d hd
      exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm

/-- Uniform actual comparison row on every physical bag state. -/
theorem row_le
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ) (S I : Fin K→Bool)
    (ρ v0 A : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ))
    (hg : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) (hA : 0≤A)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (hamp : ∀z a w b,sourceComparisonAllowed value good u v r U W d₀ Y C z a w b→‖amplitude z a w b‖≤A)
    (t : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b)
      t≤A*(targetBudget Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0) := by
  by_cases ht : Total t
  · obtain ⟨q,hq⟩ := PhysicalBagRepresentatives.ofOrdered_exists t ht
    rw [←hq]
    exact ordered_row_le value position q hposition hprime ν hνpos V S I ρ v0 A good
      u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband hg hV hρ0 hρ1 hv0 hA amplitude hamp
  · have hz : row ν V S I ρ v0 (anchor value position)
        (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b) t=0 := by
      simp [row,originalKernel,kernel,ht]
    rw [hz]
    apply mul_nonneg hA
    apply mul_nonneg (targetBudget_nonneg Y C R I (by linarith) (by linarith) hR.le)
    unfold PhysicalChoiceFiberWeight.budget
    apply Finset.prod_nonneg
    intro i _
    have hv := hV i
    have hn : 0≤∑p,ν i p := Finset.sum_nonneg fun p _=>(hνpos i p).le
    positivity


/-- The count after the comparison 1/Y factor has canceled. -/
def countFactor (Y C R : ℝ) (I : Fin K→Bool) : ℝ :=
  if ∃i,I i=true then 72*(256*(512*C))^2*(R⁻¹+Y^(-(1/5:ℝ)))
  else 33*(2*C+1)

 theorem countFactor_nonneg (Y C R : ℝ) (I : Fin K→Bool)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R) : 0≤countFactor Y C R I := by
  unfold countFactor
  split_ifs <;> positivity

 theorem targetBudget_eq (Y C R : ℝ) (I : Fin K→Bool) :
    targetBudget Y C R I=Y*countFactor Y C R I := by
  unfold targetBudget countFactor
  split_ifs <;> ring

theorem normalized_row_le
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ) (S I : Fin K→Bool)
    (ρ v0 A : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ))
    (hg : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) (hA : 0≤A)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (hamp : ∀z a w b,sourceComparisonAllowed value good u v r U W d₀ Y C z a w b→‖amplitude z a w b‖≤A/Y)
    (t : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b)
      t≤A*(countFactor Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0) := by
  have hh := row_le value position hposition hprime ν hνpos V S I ρ v0 (A/Y) good
    u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband hg hV hρ0 hρ1 hv0
    (div_nonneg hA (by linarith)) amplitude hamp t
  apply hh.trans_eq
  rw [targetBudget_eq]
  have hy : Y≠0 := by linarith
  field_simp

end Elliptic.Operator.PhysicalComparisonMaskedRow
