module

public import Elliptic.Operator.BonferroniBudget

/-!
# The inactive-prime Bonferroni comparison in the actual line model

Only the reciprocal line-count mass bound remains an explicit analytic
input. The damping bounds, pointwise sandwich, independent mean estimate
and absorption of the original path budget are proved here. No geometric
grid comparison or signed operator estimate is asserted.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.InactivePrimeBonferroni
open SourceBonferroni BonferroniBudget Filter
open scoped BigOperators
universe u v

theorem total_mean_le {P : Type u} [Fintype P] [DecidableEq P]
    (Lines : P → Type v) [∀ p, Fintype (Lines p)] [∀ p, DecidableEq (Lines p)]
    (s : Finset P) (visits : P → Finset ℕ) (line : ∀ p, ℕ → Lines p)
    (η : P → ℕ → ℝ) (N : ℕ) (C : ℝ)
    (hη : ∀ p ∈ s, ∀ j ∈ visits p, 0 ≤ η p j ∧ η p j ≤ 1)
    (hv : ∀ p ∈ s, (visits p).card ≤ N+1)
    (hC : ∑ p ∈ s, (Fintype.card (Lines p) : ℝ)⁻¹ ≤ C) :
    (∑ p ∈ s, uniformAverage (inactiveLoss (visits p) (line p) (η p))) ≤ C*((N:ℝ)+1) := by
  have hsum p (hp : p ∈ s) : (∑ j ∈ visits p, η p j) ≤ (N:ℝ)+1 := by
    calc
      _ ≤ ∑ _j ∈ visits p, (1:ℝ) := Finset.sum_le_sum (fun j hj => (hη p hp j hj).2)
      _ = ((visits p).card : ℝ) := by simp
      _ ≤ _ := by exact_mod_cast hv p hp
  calc
    _ ≤ ∑ p ∈ s, ((N:ℝ)+1)*(Fintype.card (Lines p) : ℝ)⁻¹ := by
      apply Finset.sum_le_sum
      intro p hp
      exact (inactiveLoss_average_le (visits p) (line p) (η p) (hη p hp)).trans
        (by rw [div_eq_mul_inv]; gcongr; exact hsum p hp)
    _ = ((N:ℝ)+1)*∑ p ∈ s, (Fintype.card (Lines p) : ℝ)⁻¹ := by rw [Finset.mul_sum]
    _ ≤ _ := by nlinarith

/-- Literal source cardinality: each projective line space has p+1 lines. -/
theorem projective_line_mass {P : Type u} [Fintype P]
    (value : P → ℕ) [∀ p, Fact (value p).Prime] (s : Finset P) :
    (∑ p ∈ s, (Fintype.card (Option (ZMod (value p))) : ℝ)⁻¹) =
      ∑ p ∈ s, 1/((value p:ℝ)+1) := by
  simp [Fintype.card_option, ZMod.card, one_div]

/-- Uniform source endpoint. Its threshold precedes every finite prime
family, line space, path, damping vector and allowed inactive-prime subset.
The mean input is just the reciprocal line-count mass, not a gap bound. -/
theorem eventually_inactive_gap (C B A : ℝ) (hC : 0 ≤ C) (hB : 0 ≤ B) (hA : 0 ≤ A) :
    ∀ᶠ L : ℝ in atTop,
      ∀ (P : Type u) (_ : Fintype P) (_ : DecidableEq P),
      ∀ (Lines : P → Type v) (_ : ∀ p, Fintype (Lines p))
        (_ : ∀ p, Nonempty (Lines p)) (_ : ∀ p, DecidableEq (Lines p)),
      ∀ (s : Finset P) (visits : P → Finset ℕ) (line : ∀ p, ℕ → Lines p)
        (η : P → ℕ → ℝ),
      (∀ p ∈ s, ∀ j ∈ visits p, 0 ≤ η p j ∧ η p j ≤ 1) →
      (∀ p ∈ s, (visits p).card ≤ momentLength L+1) →
      (∑ p ∈ s, (Fintype.card (Lines p) : ℝ)⁻¹ ≤ C) →
      let m := truncationIndex L
      let X := fun (l : ∀ p, Lines p) p => inactiveLoss (visits p) (line p) (η p) (l p)
      (∀ l : ∀ p, Lines p,
        truncation s (X l) (2*m+1) ≤ ∏ p ∈ s, (1-X l p) ∧
          (∏ p ∈ s, (1-X l p)) ≤ truncation s (X l) (2*m)) ∧
      2*m+1 ≤ ⌈L^(76/100 : ℝ)⌉₊ ∧
      Real.exp (B*L^(73/100 : ℝ)) *
        uniformAverage (fun l : ∀ p, Lines p =>
          truncation s (X l) (2*m)-truncation s (X l) (2*m+1)) ≤
        L^(-A*(momentLength L:ℝ)) := by
  filter_upwards [eventually_absorb_gap C B A hC hB hA,
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<76/100)).eventually
      (eventually_ge_atTop (2:ℝ)), eventually_gt_atTop (0:ℝ)] with L hbudget hdepth hL
  intro P _ _ Lines _ _ _ s visits line η hη hv hmass
  dsimp only
  have hd := depth_bounds L hdepth
  have hx p (hp : p ∈ s) l := inactiveLoss_bounds (visits p) (line p) (η p) (hη p hp) l
  refine ⟨?_,hd.2,?_⟩
  · intro l
    exact sandwich s _ (fun p hp => ⟨(hx p hp (l p)).1,(hx p hp (l p)).2.1⟩) _
  · apply hbudget _ (∑ p ∈ s, uniformAverage (inactiveLoss (visits p) (line p) (η p))) _
    · exact total_mean_le Lines s visits line η _ C hη hv hmass
    · exact hd.1
    · exact expected_gap_mul_pow_le_exp Lines s
        (fun p => inactiveLoss (visits p) (line p) (η p))
        (fun p hp l => (hx p hp l).1) _ _ (Real.rpow_nonneg hL.le _)

end Elliptic.Operator.InactivePrimeBonferroni
