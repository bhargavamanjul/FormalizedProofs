module

public import Elliptic.Operator.LifespanSchedule

/-!
# Inverting active endpoint choices and uniqueness of pending schedules

This is a set-level reconstruction, not yet the weighted indexed-history
bijection. In particular, no factorial fiber or operator identity is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

namespace PrimeLifespan
/-- A lifespan is determined by its two endpoints and active visits. -/
theorem ext_data {N : ℕ} {L M : PrimeLifespan N}
    (hb : L.birth = M.birth) (hd : L.death = M.death)
    (ha : L.active = M.active) : L = M := by
  cases L
  cases M
  simp_all
end PrimeLifespan

/-- Optional left endpoints are recovered from their numerical value. -/
theorem left_endpoint_injective (s : Finset ℕ) (a : ℕ) :
    Function.Injective (fun b : LeftGhostChoice s a => b.elim a Subtype.val) := by
  intro b d h
  cases b with
  | none =>
    cases d with
    | none => rfl
    | some d => have := d.property.2; simp only [Option.elim] at h; omega
  | some b =>
    cases d with
    | none => have := b.property.2; simp only [Option.elim] at h; omega
    | some d => exact congrArg some (Subtype.ext h)

/-- The same recovery at the right endpoint. -/
theorem right_endpoint_injective (s : Finset ℕ) (c : ℕ) :
    Function.Injective (fun d : RightGhostChoice s c => d.elim c Subtype.val) := by
  intro b d h
  cases b with
  | none =>
    cases d with
    | none => rfl
    | some d => have := d.property.2; simp only [Option.elim] at h; omega
  | some b =>
    cases d with
    | none => have := b.property.2; simp only [Option.elim] at h; omega
    | some d => exact congrArg some (Subtype.ext h)

section Active
variable (N : ℕ) (visits active : Finset ℕ)
    (hvisits : ∀ j ∈ visits, j ≤ N) (hactive : active ⊆ visits)
    (a c : ℕ) (ha : a ∈ active) (hc : c ∈ active)
    (hull : ∀ j ∈ active, a ≤ j ∧ j ≤ c)

/-- There is no overcounting in the optional endpoint parametrization. -/
theorem activeChoiceLifespan_injective :
    Function.Injective (fun bd : LeftGhostChoice (visits \ active) a ×
        RightGhostChoice (visits \ active) c =>
      activeChoiceLifespan N visits active hvisits hactive a c ha hc hull bd.1 bd.2) := by
  intro bd ef h
  apply Prod.ext
  · apply left_endpoint_injective
    exact congrArg PrimeLifespan.birth h
  · apply right_endpoint_injective
    exact congrArg PrimeLifespan.death h

/-- Every legal active lifespan with endpoints among the actual visits is
produced by a UNIQUE pair of optional exterior endpoints. -/
theorem activeChoiceLifespan_existsUnique (L : PrimeLifespan N)
    (hL : L.active = active) (hb : L.birth ∈ visits) (hd : L.death ∈ visits) :
    ∃! bd : LeftGhostChoice (visits \ active) a × RightGhostChoice (visits \ active) c,
      activeChoiceLifespan N visits active hvisits hactive a c ha hc hull bd.1 bd.2 = L := by
  have hba : L.birth ≤ a := (L.active_bounds a (hL ▸ ha)).1
  have hcd : c ≤ L.death := (L.active_bounds c (hL ▸ hc)).2
  let b : LeftGhostChoice (visits \ active) a :=
    if h : L.birth = a then none else some ⟨L.birth, by
      refine ⟨Finset.mem_sdiff.mpr ⟨hb, ?_⟩, by omega⟩
      intro hx
      have := (hull _ hx).1
      omega⟩
  let d : RightGhostChoice (visits \ active) c :=
    if h : L.death = c then none else some ⟨L.death, by
      refine ⟨Finset.mem_sdiff.mpr ⟨hd, ?_⟩, by omega⟩
      intro hx
      have := (hull _ hx).2
      omega⟩
  have hbval : b.elim a Subtype.val = L.birth := by
    dsimp [b]; split_ifs with h <;> simp_all
  have hdval : d.elim c Subtype.val = L.death := by
    dsimp [d]; split_ifs with h <;> simp_all
  have he : activeChoiceLifespan N visits active hvisits hactive a c ha hc hull b d = L :=
    PrimeLifespan.ext_data hbval hdval hL.symm
  refine ⟨(b,d), he, ?_⟩
  intro bd hbd
  exact activeChoiceLifespan_injective N visits active hvisits hactive a c ha hc hull
    (hbd.trans he.symm)

/-- The exact endpoint-parametrized class: active visits are fixed, and both
endpoints are actual visits. This imposes no operator or counting hypothesis. -/
abbrev ActiveLifespanClass :=
  {L : PrimeLifespan N // L.active = active ∧ L.birth ∈ visits ∧ L.death ∈ visits}

/-- Optional endpoints and legal active lifespans are genuinely equivalent. -/
def activeEndpointEquiv :
    (LeftGhostChoice (visits \ active) a × RightGhostChoice (visits \ active) c) ≃
      ActiveLifespanClass N visits active :=
  Equiv.ofBijective (fun bd => ⟨
    activeChoiceLifespan N visits active hvisits hactive a c ha hc hull bd.1 bd.2,
    rfl, by
      change bd.1.elim a Subtype.val ∈ visits
      cases bd.1 with
      | none => exact hactive ha
      | some b => exact (Finset.mem_sdiff.mp b.property.1).1,
    by
      change bd.2.elim c Subtype.val ∈ visits
      cases bd.2 with
      | none => exact hactive hc
      | some d => exact (Finset.mem_sdiff.mp d.property.1).1⟩) ⟨by
      intro x y h
      exact activeChoiceLifespan_injective N visits active hvisits hactive a c ha hc hull
        (congrArg Subtype.val h), by
      intro L
      obtain ⟨bd, he, _⟩ := activeChoiceLifespan_existsUnique N visits active
        hvisits hactive a c ha hc hull L.val L.property.1 L.property.2.1 L.property.2.2
      exact ⟨bd, Subtype.ext he⟩⟩

/-- Reindexing is valid for EVERY lifespan weight, including weights coupled
to other data. No probabilistic independence or factorization is used. -/
theorem sum_active_endpoints {R : Type*} [AddCommMonoid R]
    (W : ActiveLifespanClass N visits active → R) :
    let e := activeEndpointEquiv N visits active hvisits hactive a c ha hc hull
    letI := Fintype.ofEquiv _ e
    (∑ bd, W (e bd)) = ∑ L, W L := by
  let e := activeEndpointEquiv N visits active hvisits hactive a c ha hc hull
  letI := Fintype.ofEquiv _ e
  exact Equiv.sum_comp e W

end Active

namespace LifespanSchedule
variable {P : Type*} {N : ℕ}

/-- With the literal births/deaths/stores/promotions fixed, the two local
recurrences and empty initial memory force the entire pending schedule.
This theorem is finite-horizon: nothing is required beyond the last visit. -/
theorem schedule_unique (S : Finset P) (L : P → PrimeLifespan N)
    (B A : ℕ → Finset P) (hzero : B 0 = ∅)
    (hghost : ∀ j ≤ N, A j = (B j \ deaths S L j) ∪ births S L j)
    (hedge : ∀ j < N, B (j+1) = (A j \ promotions S L j) ∪ stores S L j) :
    ∀ j ≤ N, B j = before S L j ∧ A j = after S L j := by
  intro j hj
  induction j with
  | zero =>
    have hb : B 0 = before S L 0 := by simpa using hzero
    exact ⟨hb, by rw [hghost 0 (Nat.zero_le _), hb, ← ghost_recurrence]⟩
  | succ j ih =>
    have hprev := ih (by omega)
    have hb : B (j+1) = before S L (j+1) := by
      rw [hedge j (by omega), hprev.2, ← edge_recurrence]
    exact ⟨hb, by rw [hghost (j+1) hj, hb, ← ghost_recurrence]⟩

/-- Empty final pending memory is a consequence of the schedule, rather
than an additional endpoint assumption. -/
theorem schedule_final_empty (S : Finset P) (L : P → PrimeLifespan N)
    (B A : ℕ → Finset P) (hzero : B 0 = ∅)
    (hghost : ∀ j ≤ N, A j = (B j \ deaths S L j) ∪ births S L j)
    (hedge : ∀ j < N, B (j+1) = (A j \ promotions S L j) ∪ stores S L j) :
    A N = ∅ := by
  rw [(schedule_unique S L B A hzero hghost hedge N le_rfl).2, after_final]

end LifespanSchedule
end Elliptic.Operator
