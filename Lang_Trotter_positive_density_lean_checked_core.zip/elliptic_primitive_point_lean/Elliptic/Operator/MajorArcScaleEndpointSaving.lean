module
public import Elliptic.Operator.MajorArcEndpointSaving

/-! Uniform source cancellation supplies the actual major-arc endpoint energy. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcScaleEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource MajorArcScaleCancellation ClassicalDerivativeTest MellinPrimeSeparation
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

/-- The fixed transform constant is absorbed by one additional logarithmic power. -/
 theorem uniform_longPolynomial_unit_constant {I : Type} (α : ℝ→I→ℕ→ℂ)
    (active : ℝ→I→Prop) (Hm X : ℝ→I→ℝ)
    (hcancel : ScaleCancellation α active Hm X)
    (hHm : ∀ᶠx:ℝ in atTop,∀j,active x j→0<Hm x j)
    (A₀ B A : ℝ) (hA₀ : 0<A₀) (hB : 0<B) (hA : 0<A) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→∀s:Finset ℕ,IntervalInDyad (Hm x j) s→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀χ:DirichletCharacter ℂ k,∀t:ℝ,
      |t|≤2*X x j*(Real.log x)^B→‖longPolynomial s (α x j) (Hm x j) χ t‖≤(Real.log x)^(-A) := by
  obtain ⟨C,hC,hcan⟩ := uniform_longPolynomial α active Hm X hcancel hHm A₀ B (A+1) hA₀ hB (by linarith)
  filter_upwards [hcan,Real.tendsto_log_atTop.eventually (eventually_ge_atTop C),
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop (0:ℝ))] with x hcan hLC hL
  intro j hj s hs k hk hkmax χ t ht
  apply (hcan j hj s hs k hk hkmax χ t ht).trans
  calc
    _ ≤ Real.log x*(Real.log x)^(-(A+1)) :=
      mul_le_mul_of_nonneg_right hLC (Real.rpow_nonneg hL.le _)
    _ = _ := by
      conv_lhs => lhs;rw [←Real.rpow_one (Real.log x)]
      rw [←Real.rpow_add hL]
      congr 1
      ring

/-- Literal endpoint energy under the general criterion's original uniform
scale and cancellation hypotheses. No transform constant, exceptional energy,
or mean-square estimate is requested from the caller. -/
 theorem uniform_actual_endpoint_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (δ c Cprime Ccoef Jwin E Alam Crem A₀ B c₁ c₂ : ℝ)
    (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime) (hcoef : 0≤Ccoef) (hJ : 0≤Jwin)
    (hE : 0≤E) (hAlam : 0≤Alam) (hCrem : 0≤Crem) (hA₀ : 0<A₀) (hB : 0<B)
    {I : Type} (Hm Hn : ℝ→I→ℝ) (active : ℝ→I→Prop) (α : ℝ→I→ℕ→ℂ)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel : ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα : ∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^Ccoef) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→∀K:ℕ,1≤K→(K:ℝ)≤Real.exp (3*Real.log x)→
      (K:ℝ)≤Hm x j*Hn x j*(Real.log x)^Jwin→
      ∀a P:ℝ,0<P→c*(Real.log x)^(1/10:ℝ)≤Real.log P→Real.log P≤Cprime*(Real.log x)^(1/5:ℝ)→
      ∀S:Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q:ℕ)(χ:DirichletCharacter ℂ q),∀s t:Finset ℕ,IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^Ccoef)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀l:ℕ,
      ∀(χm:DirichletCharacter ℂ k)(χn:DirichletCharacter ℂ l),
      (∀v∈Icc (a+1) (a+(K:ℝ)+1),|v|≤2*(Hm x j*Hn x j)*(Real.log x)^B)→
      ∀(R:Finset ℕ)(d:ℕ→ℂ),(∀r∈R,0<r)→∀lam Y:ℝ,0<Y→|lam|≤(Real.log x)^Alam→
      (P/Y)*(∑r∈R,‖d r‖)≤(Real.log x)^Crem→
      (∫v in Icc (a+1) (a+(K:ℝ)+1),
        ‖(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y v*
          longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2)≤(Real.log x)^(-E) := by
  obtain ⟨A,hA,henergy⟩ := MajorArcEndpointSaving.eventually_actual_endpoint_energy hvdC hD η hη
    lo hi hlo hsupp δ c Cprime Ccoef Jwin E Alam Crem hδ hc hC hcoef hJ hE hAlam hCrem
  have hHm : ∀ᶠx:ℝ in atTop,∀j,active x j→0<Hm x j := by
    filter_upwards [hscale] with x hx
    intro j hj
    linarith [(hx j hj).1]
  have hcan := uniform_longPolynomial_unit_constant α active Hm (fun x j=>Hm x j*Hn x j)
    hcancel hHm A₀ B A hA₀ hB hA
  filter_upwards [Real.tendsto_log_atTop.eventually henergy,hcan,hscale,hα,
    eventually_ge_atTop c₂,eventually_gt_atTop (0:ℝ)] with x henergy hcan hscale hα hxC hx
  intro j hj K hK hKmax hKprod a P hP hplo hphi S hprime hShi q χ s t hs ht β hβ k hk hkmax l χm χn hfreq R d hR lam Y hY hlam hrem
  have hsc := hscale j hj
  have hn : Real.exp (δ*Real.log x)≤Hn x j := by
    simpa only [Real.rpow_def_of_pos hx,mul_comm] using hsc.2.2.2.1
  have hmax : Hm x j*Hn x j≤Real.exp (2*Real.log x) := by
    calc
      _ ≤ c₂*x := hsc.2.2.2.2.2
      _ ≤ x*x := mul_le_mul_of_nonneg_right hxC hx.le
      _ = _ := by rw [two_mul,Real.exp_add,Real.exp_log hx]
  exact henergy K hK hKmax (Hm x j) (Hn x j) hsc.1 hn hmax hKprod a P hP hplo hphi S hprime hShi
    q χ s t hs.inDyad ht (α x j) β (fun n hn=>hα j hj n (hs.inDyad n hn).1 (hs.inDyad n hn).2) hβ
    k l χm χn (fun v hv=>hcan j hj s hs k hk hkmax χm v (hfreq v hv)) R d hR lam Y hY hlam hrem

end Elliptic.Operator.MajorArcScaleEndpointSaving
