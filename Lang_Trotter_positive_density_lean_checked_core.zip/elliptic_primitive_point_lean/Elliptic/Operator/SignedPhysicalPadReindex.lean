module
public import Elliptic.Operator.SignedPhysicalPairSupport
public import Elliptic.Operator.SignedPhysicalPadMass

/-! Exact reindexing of the actual ordered active-list pair by its common
pads and its two fresh endpoint tuples. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open SignedPhysicalPadMass SingleEdgePhysicalRestoration
open Artin Artin.MarkedCriterion Artin.MarkedSource
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {K J : ℕ} {P : Fin K→Type*} [∀i,Fintype (P i)]

def splitListsEquiv : PhysicalActiveLists P J ≃ (∀i,Fin J→P i)×(∀i,P i) where
  toFun a := (fun i j=>a i j.castSucc,fun i=>a i (Fin.last J))
  invFun pa := assembledLists pa.1 pa.2
  left_inv a := by
    funext i j
    refine Fin.lastCases ?_ (fun k=>?_) j <;> simp [assembledLists]
  right_inv pa := by
    rcases pa with ⟨pads,a⟩
    apply Prod.ext <;> funext i
    · funext j
      simp [assembledLists]
    · simp [assembledLists]

/-- All ordered active lists split exactly into common slots and one fresh slot. -/
theorem sum_lists_eq_pads_fresh {R : Type*} [AddCommMonoid R]
    (F : PhysicalActiveLists P J→R) :
    (∑a,F a)=∑pads : ∀i,Fin J→P i,∑p : ∀i,P i,F (assembledLists pads p) := by
  rw [Fintype.sum_equiv splitListsEquiv F
    (fun pa=>F (assembledLists pa.1 pa.2))
    (fun a=>congrArg F (splitListsEquiv.left_inv a).symm)]
  rw [Fintype.sum_prod_type]

/-- Any full pair summand supported on the literal copied slots has the
exact common-pad/fresh-label parametrization. -/
theorem sum_pairs_eq_sharedPads {R : Type*} [AddCommMonoid R]
    (F : PhysicalActiveLists P J→PhysicalActiveLists P J→R)
    (hzero : ∀a b,¬(∀i (j : Fin J),b i j.castSucc=a i j.castSucc)→F a b=0) :
    (∑a,∑b,F a b)=∑pads : ∀i,Fin J→P i,∑a : ∀i,P i,∑b : ∀i,P i,
      F (assembledLists pads a) (assembledLists pads b) := by
  have hi (a : PhysicalActiveLists P J) : (∑b,F a b)=
      ∑p : ∀i,P i,F a (assembledLists (fun i j=>a i j.castSucc) p) := by
    calc
      _ = ∑b,if (∀i (j : Fin J),a i j.castSucc=b i j.castSucc) then F a b else 0 := by
        apply Finset.sum_congr rfl
        intro b hb
        by_cases h : ∀i (j : Fin J),a i j.castSucc=b i j.castSucc
        · rw [ite_eq_left h]
        · rw [ite_eq_right h,hzero a b (fun hh=>h (fun i j=>(hh i j).symm))]
      _ = _ := by
        rw [sum_lists_eq_pads_fresh]
        simp only [assembledLists,Fin.snoc_castSucc]
        rw [Finset.sum_eq_single (fun i j=>a i j.castSucc)]
        · simp
        · intro pads hpads hne
          have hn : ¬(∀i (j : Fin J),a i j.castSucc=pads i j) := by
            intro he
            exact hne (funext (fun i=>funext (fun j=>(he i j).symm)))
          simp only [ite_eq_right hn,Finset.sum_const_zero]
        · simp
  simp_rw [hi]
  rw [sum_lists_eq_pads_fresh]
  simp only [assembledLists,Fin.snoc_castSucc]

/-- The actual cross-edge ban already supplies the copied-slot support. -/
theorem sum_banned_pairs_eq_sharedPads {R : Type*} [AddCommMonoid R]
    (value : ∀i,P i→ℕ) (F : PhysicalActiveLists P J→PhysicalActiveLists P J→R) :
    (∑a,∑b,if sourceCrossEdgeBan value a b then F a b else 0)=
      ∑pads : ∀i,Fin J→P i,∑a : ∀i,P i,∑b : ∀i,P i,
        if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
          F (assembledLists pads a) (assembledLists pads b) else 0 := by
  apply sum_pairs_eq_sharedPads
  intro a b hn
  exact ite_eq_right (fun h=>hn h.1)

@[simp] theorem padProduct_assembled (value : ∀i,P i→ℕ) (pads : ∀i,Fin J→P i) (a : ∀i,P i) :
    sourcePadProduct value (assembledLists pads a)=∏i,∏j,value i (pads i j) := by
  simp [sourcePadProduct,assembledLists]

@[simp] theorem freshProduct_assembled (value : ∀i,P i→ℕ) (pads : ∀i,Fin J→P i) (a : ∀i,P i) :
    sourceUnsharedProduct value (assembledLists pads a)=∏i,value i (a i) := by
  simp [sourceUnsharedProduct,assembledLists]

/-- The cross-edge ban on assembled lists is exactly the good-pad event
and distinct fresh labels, under the actual global numeric injection. -/
theorem crossEdgeBan_assembled_iff (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (pads : ∀i,Fin J→P i) (a b : ∀i,P i) :
    sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) ↔
      GoodPads a b pads ∧ ∀i,a i≠b i := by
  constructor
  · intro h
    have hs (i : Fin K) : Function.Injective (slotLabel a b pads i) := by
      intro j k he
      have hh := congrArg Prod.snd (h.2 (a₁:=(i,j)) (a₂:=(i,k)) (by
        rcases j with j|j <;> rcases k with k|k
        · simpa [sourceCrossEdgeLabels,assembledLists,slotLabel] using congrArg (value i) he
        · cases k <;> simpa [sourceCrossEdgeLabels,assembledLists,slotLabel] using congrArg (value i) he
        · cases j <;> simpa [sourceCrossEdgeLabels,assembledLists,slotLabel] using congrArg (value i) he
        · cases j <;> cases k <;> simpa [sourceCrossEdgeLabels,assembledLists,slotLabel] using congrArg (value i) he))
      exact hh
    constructor
    · intro i
      refine ⟨?_,?_⟩
      · intro j k he
        exact Sum.inl.inj (hs i (a₁:=.inl j) (a₂:=.inl k) he)
      · intro j
        constructor
        · intro he
          have hh := hs i (a₁:=.inl j) (a₂:=.inr false) he
          cases hh
        · intro he
          have hh := hs i (a₁:=.inl j) (a₂:=.inr true) he
          cases hh
    · intro i he
      have hh := hs i (a₁:=.inr false) (a₂:=.inr true) he
      cases Sum.inr.inj hh
  · rintro ⟨hg,hab⟩
    exact goodPads_crossEdgeBan value hinj a b hab pads hg

theorem originalPairing_eq_pad_sum {K J : ℕ} (hK : 0<K)
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (W : ℝ) (hsmall : ∀i,∀p∈groups i,(p:ℝ)≤W)
    (S T : Finset ℕ) (Hm Hn : ℝ) (hHm : 0≤Hm) (hHn : 0≤Hn)
    (hS : InDyad Hm S) (hT : InDyad Hn T)
    (α β : ℕ→ℂ)
    (hroughS : ∀m∈S,α m≠0→IsRough W m) (hroughT : ∀n∈T,β n≠0→IsRough W n)
    (Vmass : Fin K→ℝ) (d₀ Y H C : ℝ) (hd : 0<d₀) (hY : 0<Y) (hCY : C*Y≤W)
    (η ψ : ℝ→ℂ) (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hψ : ∀t,ψ t≠0→|t|≤C) :
    originalPairing (J:=J) (fun i=>fun p : groups i=>p.val) Vmass (fun _ _=>True) (d₀*Y*Hm) Hn d₀ Y H η ψ (-1)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1) =
    ∑pads : ∀i,Fin J→groups i,∑a : ∀i,groups i,∑b : ∀i,groups i,
      ∑m∈S,∑q∈T,∑r∈S,∑n∈T,
      if sourceCrossEdgeBan (fun _ p=>p.val) (assembledLists pads a) (assembledLists pads b) ∧
          d₀≤(∏i,∏j,(pads i j).val:ℝ) ∧ (∏i,∏j,(pads i j).val:ℝ)<2*d₀ then
        (d₀:ℂ)*((∏i,∏j,1/(Vmass i*((pads i j).val:ℝ)):ℝ):ℂ)*
          ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*
          scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β else 0 := by
  rw [originalPairing_eq_scalarError_of_supported_rough hK groups hp hdis W hsmall S T Hm Hn hHm hHn
    hS hT α β hroughS hroughT Vmass d₀ Y H C hd hY hCY η ψ hη hψ]
  let F := fun a b : PhysicalActiveLists (fun i=>groups i) J=>
    ∑m∈S,∑q∈T,∑r∈S,∑n∈T,
      if sourceCrossEdgeBan (fun _ p=>p.val) a b ∧
          d₀≤(sourcePadProduct (fun _ p=>p.val) a:ℝ) ∧
          (sourcePadProduct (fun _ p=>p.val) a:ℝ)<2*d₀ then
        (d₀:ℂ)*((∏i,∏j : Fin J,1/(Vmass i*((a i j.castSucc).val:ℝ)):ℝ):ℂ)*
          ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*
          scalarError (sourceUnsharedProduct (fun _ p=>p.val) b)
            (sourceUnsharedProduct (fun _ p=>p.val) a) m n r q Y H η ψ α β else 0
  have hz : ∀a b,¬(∀i (j : Fin J),b i j.castSucc=a i j.castSucc)→F a b=0 := by
    intro a b hn
    have hb : ¬sourceCrossEdgeBan (fun i=>fun p : groups i=>p.val) a b := fun h=>hn h.1
    simp [F,hb]
  change (∑a,∑b,F a b)=_
  rw [sum_pairs_eq_sharedPads F hz]
  simp only [F,padProduct_assembled,freshProduct_assembled,assembledLists,Fin.snoc_castSucc,Nat.cast_prod]

end Elliptic.Operator.SignedPhysicalPairBridge
