module

public import Elliptic.Operator.IndependentLifespanCoefficient
public import Elliptic.Operator.LifespanReconstruction

/-!
# The complete optional-interval expansion of one independent prime line

The index is the actual finite set of possible lifespan intervals, with
active visits fixed. It includes the unused-prime choice. Endpoint line
incidence is kept explicitly, and all signed ghost weights are retained.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalIntervalAverage
open scoped BigOperators
open IndependentLineNormalization IndependentLifespanCoefficient
attribute [local instance] Classical.propDecidable
local instance intervalAverageDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {N : ℕ}

abbrev Span (N : ℕ) (active : Finset ℕ) := ActiveLifespanClass N (Finset.range (N+1)) active

def endpoints {active : Finset ℕ} (L : Span N active) : Fin (N+1) × Fin (N+1) :=
  (⟨L.val.birth,Finset.mem_range.mp L.property.2.1⟩,
    ⟨L.val.death,Finset.mem_range.mp L.property.2.2⟩)

theorem endpoints_injective (active : Finset ℕ) :
    Function.Injective (endpoints (N:=N) (active:=active)) := by
  intro L M h
  apply Subtype.ext
  apply PrimeLifespan.ext_data
  · exact congrArg (fun bd : Fin (N+1) × Fin (N+1) => bd.1.val) h
  · exact congrArg (fun bd : Fin (N+1) × Fin (N+1) => bd.2.val) h
  · exact L.property.1.trans M.property.1.symm

instance spanFintype (active : Finset ℕ) : Fintype (Span N active) :=
  Fintype.ofInjective endpoints (endpoints_injective active)

variable {Line : Type*} [DecidableEq Line]

def Incidence (line : ℕ → Line) (L : PrimeLifespan N) : Prop :=
  line L.birth=line L.death ∧ ∀ j∈L.active, line j=line L.birth

def spanWeight (line : ℕ → Line) (η : ℕ → ℝ) (μ : ℝ) {active : Finset ℕ}
    (L : Span N active) : ℝ :=
  μ * if Incidence line L.val then
    ∏ j∈Finset.range (N+1), L.val.lifespanVisitFactor 1 η (fun j=>1-η j)
      (fun j=>line j=line L.val.birth) j else 0

def choiceWeight (active : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ) (μ : ℝ) :
    Option (Span N active) → ℝ
  | none => if active=∅ then 1 else 0
  | some L => spanWeight line η μ L

/-- All inactive nonempty intervals have two strictly ordered endpoints. -/
def ghostSpanEquiv :
    (Σ d : (Finset.range (N+1)), (Finset.range (N+1)).filter (·<d.val)) ≃ Span N ∅ :=
  Equiv.ofBijective (fun bd => ⟨ghostOnlyLifespan N bd.2.val bd.1.val (Finset.mem_filter.mp bd.2.property).2
    (Nat.le_of_lt_succ (Finset.mem_range.mp bd.1.property)),rfl,(Finset.mem_filter.mp bd.2.property).1,bd.1.property⟩) ⟨by
      intro bd ce h
      have hd := congrArg (fun L : Span N ∅ => L.val.death) h
      have hb := congrArg (fun L : Span N ∅ => L.val.birth) h
      cases bd with | mk d b =>
        cases ce with | mk e c =>
          have hd' : d=e := Subtype.ext hd
          subst e
          exact congrArg (Sigma.mk d) (Subtype.ext hb),by
      intro L
      have hbd : L.val.birth<L.val.death := by
        have hle := L.val.birth_le_death
        have hs := L.val.singleton_active
        rw [L.property.1] at hs
        by_contra hn
        exact Finset.notMem_empty _ (hs (by omega))
      refine ⟨⟨⟨L.val.death,L.property.2.2⟩,⟨L.val.birth,Finset.mem_filter.mpr ⟨L.property.2.1,hbd⟩⟩⟩,?_⟩
      exact Subtype.ext (PrimeLifespan.ext_data rfl rfl L.property.1.symm)⟩

/-- The inactive local formula is reindexed by every legal interval,
including its unused-prime choice, without choosing representatives. -/
theorem inactive_average [Fintype Line] (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ)≠0)
    (hbase : (Fintype.card Line : ℝ)-∑ j∈Finset.range (N+1),η j≠0) :
    lineAverage (Finset.range (N+1)) ∅ line η =
      baseline (Finset.range (N+1)) η (Fintype.card Line) *
        ∑ L : Option (Span N ∅), choiceWeight ∅ line η
          (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line)) L := by
  rw [inactive_lineAverage_lifespans (Finset.range (N+1))
    (fun j hj=>Nat.le_of_lt_succ (Finset.mem_range.mp hj)) line η hn hbase]
  rw [Fintype.sum_option]
  simp only [choiceWeight,ite_true]
  congr 1
  congr 1
  rw [← (ghostSpanEquiv (N:=N)).sum_comp (spanWeight line η
    (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line))),Fintype.sum_sigma]
  simp only [spanWeight,ghostSpanEquiv,Equiv.ofBijective_apply,ghostOnlyLifespan,
    Incidence,Finset.notMem_empty,forall_const,and_true]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro d _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b _
  by_cases he : line b.val=line d.val
  · simp [he]
  · simp [he]

section Active
variable (active : Finset ℕ) (hactive : active⊆Finset.range (N+1))
variable (a c : ℕ) (ha : a∈active) (hc : c∈active)
variable (hull : ∀ j∈active,a≤j∧j≤c)

/-- The active interval's incidence condition is exactly the active-line
condition together with both optional ghost endpoint conditions. -/
theorem active_incidence (line : ℕ → Line)
    (b : LeftGhostChoice (Finset.range (N+1) \ active) a)
    (d : RightGhostChoice (Finset.range (N+1) \ active) c) :
    let L := activeChoiceLifespan N (Finset.range (N+1)) active
      (fun j hj=>Nat.le_of_lt_succ (Finset.mem_range.mp hj)) hactive a c ha hc hull b d
    Incidence line L ↔
      (∀ j∈active,line j=line a) ∧
      b.elim True (fun t=>line t.val=line a) ∧ d.elim True (fun t=>line t.val=line a) := by
  dsimp only
  have hca : (∀ j∈active,line j=line a) → line c=line a := fun h=>h c hc
  cases b with
  | none =>
    cases d with
    | none => simp only [Incidence,activeChoiceLifespan,Option.elim_none,true_and,and_true]
              exact ⟨fun h=>h.2,fun h=>⟨(hca h).symm,h⟩⟩
    | some d =>
      simp only [Incidence,activeChoiceLifespan,Option.elim_none,Option.elim_some,true_and]
      exact ⟨fun h=>⟨h.2,h.1.symm⟩,fun h=>⟨h.2.symm,h.1⟩⟩
  | some b =>
    cases d with
    | none =>
      simp only [Incidence,activeChoiceLifespan,Option.elim_none,Option.elim_some,and_true]
      constructor
      · intro h
        have hab := h.2 a ha
        exact ⟨fun j hj=>(h.2 j hj).trans hab.symm,hab.symm⟩
      · rintro ⟨h,hb⟩
        exact ⟨hb.trans (hca h).symm,fun j hj=>(h j hj).trans hb.symm⟩
    | some d =>
      simp only [Incidence,activeChoiceLifespan,Option.elim_some]
      constructor
      · intro h
        have hab := h.2 a ha
        exact ⟨fun j hj=>(h.2 j hj).trans hab.symm,hab.symm,h.1.symm.trans hab.symm⟩
      · rintro ⟨h,hb,hd⟩
        exact ⟨hb.trans hd.symm,fun j hj=>(h j hj).trans hb.symm⟩

include hactive a c ha hc hull in
/-- Exact active-prime optional-interval average. -/
theorem active_average [Fintype Line] (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ)≠0)
    (hbase : (Fintype.card Line : ℝ)-∑ j∈Finset.range (N+1),η j≠0) :
    lineAverage (Finset.range (N+1)) active line η =
      baseline (Finset.range (N+1)) η (Fintype.card Line) *
        ∑ L : Option (Span N active), choiceWeight active line η
          (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line)) L := by
  rw [active_lineAverage_lifespans (Finset.range (N+1)) active
    (fun j hj=>Nat.le_of_lt_succ (Finset.mem_range.mp hj)) hactive a c ha hc hull line η hn hbase]
  have hne : active≠∅ := Finset.ne_empty_of_mem ha
  rw [Fintype.sum_option (choiceWeight active line η
    (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line)))]
  simp only [choiceWeight,hne,ite_false,zero_add]
  let e := activeEndpointEquiv N (Finset.range (N+1)) active
    (fun j hj=>Nat.le_of_lt_succ (Finset.mem_range.mp hj)) hactive a c ha hc hull
  rw [← e.sum_comp (spanWeight line η
    (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line))),Fintype.sum_prod_type]
  rw [mul_assoc]
  congr 1
  by_cases hall : ∀ j∈active,line j=line a
  · rw [if_pos hall]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro b _
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro d _
    simp only [spanWeight,e,activeEndpointEquiv,Equiv.ofBijective_apply]
    rw [show _ ↔ _ from active_incidence active hactive a c ha hc hull line b d]
    by_cases hend : b.elim True (fun t=>line t.val=line a) ∧ d.elim True (fun t=>line t.val=line a)
    · rw [if_pos hend,if_pos ⟨hall,hend⟩]
      congr 1
      have hb : line (b.elim a Subtype.val)=line a := by
        cases b with
        | none => rfl
        | some b => exact hend.1
      apply Finset.prod_congr rfl
      intro j _
      simp only [activeChoiceLifespan,hb]
    · rw [if_neg hend,if_neg (fun h=>hend h.2)]
  · rw [if_neg hall,mul_zero]
    symm
    apply Finset.sum_eq_zero
    intro b _
    apply Finset.sum_eq_zero
    intro d _
    simp only [spanWeight,e,activeEndpointEquiv,Equiv.ofBijective_apply]
    rw [show _ ↔ _ from active_incidence active hactive a c ha hc hull line b d]
    simp [hall]

end Active

/-- Uniform statement including both active and inactive primes. -/
theorem average_eq_optional_intervals [Fintype Line]
    (active : Finset ℕ) (hactive : active⊆Finset.range (N+1))
    (line : ℕ → Line) (η : ℕ → ℝ)
    (hn : (Fintype.card Line : ℝ)≠0)
    (hbase : (Fintype.card Line : ℝ)-∑ j∈Finset.range (N+1),η j≠0) :
    lineAverage (Finset.range (N+1)) active line η =
      baseline (Finset.range (N+1)) η (Fintype.card Line) *
        ∑ L : Option (Span N active), choiceWeight active line η
          (normalizedLineMass (Finset.range (N+1)) η (Fintype.card Line)) L := by
  by_cases h : active.Nonempty
  · exact active_average active hactive (active.min' h) (active.max' h)
      (active.min'_mem h) (active.max'_mem h)
      (fun j hj=>⟨active.min'_le j hj,active.le_max' j hj⟩) line η hn hbase
  · have he : active=∅ := Finset.not_nonempty_iff_eq_empty.mp h
    subst active
    exact inactive_average line η hn hbase

end Elliptic.Operator.OriginalIntervalAverage
