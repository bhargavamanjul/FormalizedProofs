module

public import Elliptic.Operator.BirthRankCounting
public import Mathlib.Analysis.Fourier.ZMod

/-! Exact finite Fourier localization of the performed-birth restrictions.
The Fourier average is normalized, so its size contributes no factor.
After regrouping, each phase is attached to one birth address; only moved
addresses are changed. The modulus is arbitrary subject to faithful
encoding of the finite label alphabet. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthFourierLocalization
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {α β H : Type*} [Fintype α] [DecidableEq α]
variable {Q : ℕ} [NeZero Q]

def average (f : (α → ZMod Q) → ℂ) : ℂ :=
  ((Q : ℂ) ^ Fintype.card α)⁻¹ * ∑ θ, f θ

theorem character_average (t : ZMod Q) :
    (Q : ℂ)⁻¹ * ∑ θ : ZMod Q, ZMod.stdAddChar (t*θ) = if t=0 then 1 else 0 := by
  by_cases ht : t=0
  · simp [ht,NeZero.ne Q]
  · have hs : (∑ θ : ZMod Q, ZMod.stdAddChar (t*θ))=0 :=
      AddChar.sum_eq_zero_of_ne_one (ZMod.isPrimitive_stdAddChar Q ht)
    rw [hs]
    simp [ht]

theorem product_average (f : α → ZMod Q → ℂ) :
    average (fun θ => ∏ a, f a (θ a)) =
      ∏ a, ((Q : ℂ)⁻¹ * ∑ θ : ZMod Q, f a θ) := by
  rw [average,← Fintype.prod_sum,Finset.prod_mul_distrib]
  simp [← inv_pow]

theorem equality_average (v w : α → ZMod Q) :
    average (fun θ => ∏ a, ZMod.stdAddChar ((v a-w a)*θ a)) =
      if v=w then 1 else 0 := by
  rw [product_average (fun a θ => ZMod.stdAddChar ((v a-w a)*θ))]
  simp_rw [character_average,sub_eq_zero]
  by_cases h : v=w
  · subst w
    simp
  · obtain ⟨a,ha⟩ := Function.ne_iff.mp h
    rw [if_neg h]
    apply Finset.prod_eq_zero (Finset.mem_univ a)
    simp [ha]

def localPhase (birth : α → Option β) (code : β → ZMod Q)
    (σ : Equiv.Perm α) (θ : α → ZMod Q) (a : α) : ℂ :=
  if a∈σ.support then
    match birth a with
    | none => 0
    | some v => ZMod.stdAddChar (code v * (θ (σ.symm a)-θ a))
  else 1

theorem localPhase_unmoved (birth : α → Option β) (code : β → ZMod Q)
    (σ : Equiv.Perm α) (θ : α → ZMod Q) (a : α) (ha : a∉σ.support) :
    localPhase birth code σ θ a=1 := by simp [localPhase,ha]

theorem localPhase_norm_le (birth : α → Option β) (code : β → ZMod Q)
    (σ : Equiv.Perm α) (θ : α → ZMod Q) (a : α) :
    ‖localPhase birth code σ θ a‖≤1 := by
  unfold localPhase
  split_ifs
  · cases birth a <;> simp [ZMod.stdAddChar_apply]
  · simp

theorem permutation_phase_regroup (v : α → ZMod Q) (σ : Equiv.Perm α)
    (θ : α → ZMod Q) :
    (∏ a, ZMod.stdAddChar ((v (σ a)-v a)*θ a)) =
      ∏ a, ZMod.stdAddChar (v a*(θ (σ.symm a)-θ a)) := by
  simp_rw [sub_mul,mul_sub,AddChar.map_sub_eq_div,Finset.prod_div_distrib]
  congr 1
  exact Fintype.prod_equiv σ _ _ (fun a => by simp)

theorem localPhase_eq_character (birth : α → Option β) (code : β → ZMod Q)
    (σ : Equiv.Perm α) (θ : α → ZMod Q)
    (hp : ∀ a∈σ.support,(birth a).isSome) (a : α) :
    localPhase birth code σ θ a =
      ZMod.stdAddChar (((birth a).map code |>.getD 0)*(θ (σ.symm a)-θ a)) := by
  by_cases ha : a∈σ.support
  · cases hb : birth a with
    | none => simpa [hb] using hp a ha
    | some v => simp [localPhase,ha,hb]
  · have he : σ.symm a=a := by
      apply σ.injective
      simpa using (Equiv.Perm.notMem_support.mp ha).symm
    simp [localPhase,ha,he]

/-- The literal birth-preservation indicator is a normalized average of
products of local, bounded address factors. Unperformed moved addresses
vanish locally; they are not assigned a fictitious prime value. -/
theorem birthPreserving_average (birth : α → Option β) (code : β → ZMod Q)
    (hcode : ∀a b v w,birth a=some v → birth b=some w → code v=code w → v=w)
    (σ : Equiv.Perm α) :
    (if BirthPreserving birth σ then (1:ℂ) else 0) =
      average (fun θ => ∏ a, localPhase birth code σ θ a) := by
  by_cases hp : ∀a∈σ.support,(birth a).isSome
  · let v : α → ZMod Q := fun a => ((birth a).map code).getD 0
    have hi : BirthPreserving birth σ ↔ (fun a=>v (σ a))=v := by
      constructor
      · intro h
        funext a
        simp [v,h.1 a]
      · intro h
        apply (birthPreserving_iff_moved_equalities birth σ).mpr
        intro a ha
        have hpa := hp a ha
        have hpb := hp (σ a) (by simpa using ha)
        cases he : birth a with
        | none => simp [he] at hpa
        | some b =>
          cases hf : birth (σ a) with
          | none => simp [hf] at hpb
          | some c =>
            have hc : code c=code b := by simpa [v,he,hf] using congrFun h a
            exact ⟨b,rfl,by rw [hcode (σ a) a c b hf he hc]⟩
    have he : average (fun θ => ∏ a, localPhase birth code σ θ a) =
        average (fun θ => ∏ a, ZMod.stdAddChar ((v (σ a)-v a)*θ a)) := by
      congr 1
      funext θ
      rw [permutation_phase_regroup]
      apply Finset.prod_congr rfl
      intro a _
      exact localPhase_eq_character birth code σ θ hp a
    rw [he,equality_average,hi]
    split_ifs <;> rfl
  · push_neg at hp
    obtain ⟨a,ha,hpa⟩ := hp
    have hn : birth a=none := by cases hh : birth a <;> simp_all
    have hb : ¬ BirthPreserving birth σ := by
      intro h
      exact (Equiv.Perm.mem_support.mp ha) (h.2 a hn)
    rw [if_neg hb]
    have hz (θ : α → ZMod Q) : (∏ a,localPhase birth code σ θ a)=0 := by
      apply Finset.prod_eq_zero (Finset.mem_univ a)
      simp [localPhase,ha,hn]
    simp [average,hz]

/-- Fourier localization commutes with the actual finite history sum. -/
theorem weighted_birthPreserving_average (histories : Finset H)
    (birth : H → α → Option β) (code : β → ZMod Q)
    (hcode : ∀h∈histories,∀a b v w,birth h a=some v → birth h b=some w →
      code v=code w → v=w) (σ : Equiv.Perm α) (weight : H → ℂ) :
    (∑ h∈histories, if BirthPreserving (birth h) σ then weight h else 0) =
      average (fun θ => ∑ h∈histories,
        (∏ a,localPhase (birth h) code σ θ a)*weight h) := by
  have hi (h : H) (hh : h∈histories) : (if BirthPreserving (birth h) σ then weight h else 0) =
      average (fun θ=>∏a,localPhase (birth h) code σ θ a)*weight h := by
    rw [← birthPreserving_average (birth h) code (hcode h hh) σ]
    split_ifs <;> simp
  calc
    _ = ∑h∈histories,average (fun θ=>∏a,localPhase (birth h) code σ θ a)*weight h :=
      Finset.sum_congr rfl hi
    _ = _ := by
      simp_rw [average,mul_assoc,Finset.sum_mul]
      rw [← Finset.mul_sum,Finset.sum_comm]

/-- Actual numerical prime labels admit the needed faithful encoding as
soon as the freely chosen Fourier modulus exceeds every possible value. -/
theorem natural_code_faithful (birth : α → Option ℕ)
    (hbound : ∀a v,birth a=some v → v<Q) :
    ∀a b v w,birth a=some v → birth b=some w →
      (v:ZMod Q)=(w:ZMod Q) → v=w := by
  intro a b v w ha hb he
  have hv := hbound a v ha
  have hw := hbound b w hb
  have hh := congrArg ZMod.val he
  simpa [ZMod.val_natCast,Nat.mod_eq_of_lt hv,Nat.mod_eq_of_lt hw] using hh

theorem natural_birthPreserving_average (birth : α → Option ℕ)
    (hbound : ∀a v,birth a=some v → v<Q) (σ : Equiv.Perm α) :
    (if BirthPreserving birth σ then (1:ℂ) else 0) =
      average (fun θ => ∏a,localPhase birth (fun v=>(v:ZMod Q)) σ θ a) :=
  birthPreserving_average birth _ (natural_code_faithful birth hbound) σ

/-- The normalized Fourier average never loses a phase-space factor. -/
theorem norm_average_le (f : (α → ZMod Q) → ℂ) (C : ℝ)
    (hf : ∀θ,‖f θ‖≤C) : ‖average f‖≤C := by
  have hn : (Q:ℝ)^Fintype.card α≠0 := pow_ne_zero _ (by exact_mod_cast NeZero.ne Q)
  calc
    ‖average f‖ = ((Q:ℝ)^Fintype.card α)⁻¹ * ‖∑θ,f θ‖ := by
      simp [average,norm_mul,norm_inv,norm_pow]
    _ ≤ ((Q:ℝ)^Fintype.card α)⁻¹ * ∑θ,‖f θ‖ :=
      mul_le_mul_of_nonneg_left (norm_sum_le _ _) (inv_nonneg.mpr (by positivity))
    _ ≤ ((Q:ℝ)^Fintype.card α)⁻¹ * ∑ _θ : α → ZMod Q,C :=
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum (fun θ _=>hf θ))
        (inv_nonneg.mpr (by positivity))
    _ = C := by simp [Fintype.card_fun,← mul_assoc,hn]

/-- Grouping local factors by their actual operation creates at most
2r modified operations. Every other operation factor is exactly one. -/
theorem unmodified_operation_factor {O : Type*} [DecidableEq O]
    (operation : α → O) (birth : α → Option β) (code : β → ZMod Q)
    (σ : Equiv.Perm α) (θ : α → ZMod Q) (o : O)
    (ho : o∉σ.support.image operation) :
    (∏a∈Finset.univ.filter (fun a=>operation a=o),localPhase birth code σ θ a)=1 := by
  apply Finset.prod_eq_one
  intro a ha
  apply localPhase_unmoved
  intro hs
  exact ho (Finset.mem_image.mpr ⟨a,hs,(Finset.mem_filter.mp ha).2⟩)

end Elliptic.Operator.BirthFourierLocalization
