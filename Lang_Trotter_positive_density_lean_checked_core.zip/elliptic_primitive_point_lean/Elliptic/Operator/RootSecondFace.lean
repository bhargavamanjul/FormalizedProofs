module

public import Elliptic.Operator.RootFirstFace

/-!
# The second physical coordinate faces on the actual root grid

Writing `a=u/U`, `b=v/V`, and `d=z₂/(UV)`, the second coordinate is
`b*tau(r,z)+d/a`. We count its face cells inside the closed first-coordinate
box. Their graph spread is derived from the literal equations; no abstract
regularity or surface-area estimate is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootSecondFace
open RootArchimedeanGrid RootFirstFace SourceRootCount
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def coordinate (d : ℝ) (z : ℤ × ℤ) (a b r : ℝ) : ℝ :=
  b*latticeTau r z+d/a

def FirstBox (z : ℤ × ℤ) (a r : ℝ) : Prop :=
  1≤a*latticeTau r z ∧ a*latticeTau r z≤16

theorem physical_second_coordinate (U V a b r : ℝ) (hU : U≠0) (hV : V≠0)
    (ha : a≠0) (z : ℤ × ℤ) :
    (rootPhysicalPosition (U*a) (V*b) r z).2/V =
      coordinate ((z.2:ℝ)/(U*V)) z a b r := by
  dsimp [rootPhysicalPosition,coordinate]
  field_simp

theorem physical_second_face_iff (U V a b r c : ℝ) (hU : U≠0) (hV : V≠0)
    (ha : a≠0) (z : ℤ × ℤ) :
    (rootPhysicalPosition (U*a) (V*b) r z).2=c*V ↔
      coordinate ((z.2:ℝ)/(U*V)) z a b r=c := by
  rw [←physical_second_coordinate U V a b r hU hV ha z,div_eq_iff hV]

theorem tau_lower (z : ℤ × ℤ) (a r : ℝ) (ha : 1≤a) (ha' : a≤16)
    (hbox : FirstBox z a r) : 1/16≤latticeTau r z := by
  have hap : 0<a := by linarith
  have htp : 0<latticeTau r z := (mul_pos_iff.mp (show 0<a*latticeTau r z by
    have := hbox.1; linarith)).resolve_right (by rintro ⟨h,_⟩; linarith) |>.2
  have hlo := hbox.1
  nlinarith [mul_le_mul_of_nonneg_right ha' htp.le]

theorem reciprocal_difference (d a a' : ℝ) (ha : a≠0) (ha' : a'≠0) :
    d/a'-d/a=d*(a-a')/(a*a') := by field_simp

/-- The bound is uniform in the face level c. The source uses c=1,2. -/
theorem second_face_spread (z : ℤ × ℤ) (d c : ℝ) (n i k : ℕ)
    (a a' b b' r s : ℝ) (ha : 1≤a) (ha' : 1≤a') (ha16 : a≤16)
    (hb' : 1≤b') (hb2' : b'≤2)
    (hai : (cell 1 16 n i).Contains a) (hai' : (cell 1 16 n i).Contains a')
    (hr : (cell 0 1 n k).Contains r) (hs : (cell 0 1 n k).Contains s)
    (hbox : FirstBox z a r)
    (hf : coordinate d z a b r=c) (hf' : coordinate d z a' b' s=c) :
    |b-b'|≤(32*|(z.2:ℝ)|+240*|d|)/(n:ℝ) := by
  have hap : 0<a := by linarith
  have hap' : 0<a' := by linarith
  have ht := tau_lower z a r ha ha16 hbox
  have hdiff : (b-b')*latticeTau r z =
      b'*(s-r)*(z.2:ℝ)+(d/a'-d/a) := by
    dsimp [coordinate,latticeTau] at hf hf' ⊢
    linear_combination hf-hf'
  rw [reciprocal_difference d a a' hap.ne' hap'.ne'] at hdiff
  have har : |a-a'|≤15/(n:ℝ) := by
    simpa only [abs_sub_comm,show (16:ℝ)-1=15 by norm_num] using
      cell_diameter 1 16 n i a a' hai hai'
  have hrr : |s-r|≤1/(n:ℝ) := by simpa using cell_diameter 0 1 n k r s hr hs
  have haap : 0<a*a' := mul_pos hap hap'
  have haa : 1≤a*a' := by nlinarith
  have hbabs : |b'|≤2 := by rw [abs_of_nonneg (by linarith : 0≤b')]; exact hb2'
  have hbound : |b-b'| * latticeTau r z ≤ (2*|(z.2:ℝ)|+15*|d|)/(n:ℝ) := by
    calc
      _ = |(b-b')*latticeTau r z| := by
        rw [abs_mul,abs_of_nonneg (show 0≤latticeTau r z by linarith)]
      _ = |b'*(s-r)*(z.2:ℝ)+d*(a-a')/(a*a')| := congrArg abs hdiff
      _ ≤ |b'*(s-r)*(z.2:ℝ)|+|d*(a-a')/(a*a')| := abs_add_le _ _
      _ = |b'| * |s-r| * |(z.2:ℝ)| + |d| * |a-a'|/(a*a') := by
        rw [abs_mul,abs_mul,abs_div,abs_mul,abs_of_pos haap]
      _ ≤ 2*(1/(n:ℝ))*|(z.2:ℝ)| + |d| * |a-a'| := by
        apply add_le_add
        · gcongr
        · exact div_le_self (by positivity) haa
      _ ≤ 2*(1/(n:ℝ))*|(z.2:ℝ)| + |d| * (15/(n:ℝ)) := by gcongr
      _ = _ := by ring
  have hh : |b-b'|/16 ≤ |b-b'| * latticeTau r z := by
    nlinarith [mul_le_mul_of_nonneg_left ht (abs_nonneg (b-b'))]
  have he : (32*|(z.2:ℝ)|+240*|d|)/(n:ℝ) =
      16*((2*|(z.2:ℝ)|+15*|d|)/(n:ℝ)) := by ring
  rw [he]
  linarith

def columns (n i k : ℕ) (z : ℤ × ℤ) (d c : ℝ) : Finset ℕ :=
  (Finset.range n).filter fun j => ∃ a b r : ℝ,
    (cell 1 16 n i).Contains a ∧ (cell 1 2 n j).Contains b ∧
      (cell 0 1 n k).Contains r ∧ FirstBox z a r ∧ coordinate d z a b r=c

theorem columns_card (n i k : ℕ) (hn : 0<n) (hi : i<n)
    (z : ℤ × ℤ) (d c : ℝ) :
    ((columns n i k z d c).card:ℝ) ≤ 2*(32*|(z.2:ℝ)|+240*|d|)+2 := by
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  let M : ℝ := 32*|(z.2:ℝ)|+240*|d|
  have hM : 0≤M := by dsimp [M]; positivity
  by_cases hempty : (columns n i k z d c).Nonempty
  · obtain ⟨j₀,hj₀⟩ := hempty
    obtain ⟨a₀,b₀,r₀,ha₀,hb₀,hr₀,hbox₀,hface₀⟩ := (Finset.mem_filter.mp hj₀).2
    have ha₀range := cell_point_bounds 1 16 n i hi (by norm_num) a₀ ha₀
    have hb₀range := cell_point_bounds 1 2 n j₀
      (Finset.mem_range.mp (Finset.mem_filter.mp hj₀).1) (by norm_num) b₀ hb₀
    let center : ℝ := (n:ℝ)*(b₀-1)
    have hwindow : ∀ j∈columns n i k z d c,
        center-M-1≤(j:ℝ) ∧ (j:ℝ)≤center+M := by
      intro j hj
      obtain ⟨a,b,r,ha,hb,hr,hbox,hface⟩ := (Finset.mem_filter.mp hj).2
      have harange := cell_point_bounds 1 16 n i hi (by norm_num) a ha
      have hspread := second_face_spread z d c n i k a a₀ b b₀ r r₀
        harange.1 ha₀range.1 harange.2 hb₀range.1 hb₀range.2 ha ha₀ hr hr₀ hbox hface hface₀
      change |b-b₀|≤M/(n:ℝ) at hspread
      have hd1 : (b-b₀)*(n:ℝ)≤M :=
        (le_div_iff₀ hnR).mp ((le_abs_self _).trans hspread)
      have hd2 : (b₀-b)*(n:ℝ)≤M :=
        (le_div_iff₀ hnR).mp (by linarith [(abs_le.mp hspread).1])
      have hj1 : (j:ℝ)≤(b-1)*(n:ℝ) := by
        apply (div_le_iff₀ hnR).mp
        have h := hb.1
        dsimp [cell] at h
        norm_num at h
        linarith
      have hj2 : (b-1)*(n:ℝ)≤(j:ℝ)+1 := by
        apply (le_div_iff₀ hnR).mp
        have h := hb.2
        dsimp [cell] at h
        norm_num at h
        linarith
      dsimp [center]
      constructor <;> nlinarith
    have h := nat_finite_window (columns n i k z d c) (center-M-1) (center+M) hwindow
    have he : center+M-(center-M-1)+1=2*M+2 := by ring
    rw [he,max_eq_right (by positivity)] at h
    exact h
  · rw [Finset.not_nonempty_iff_eq_empty.mp hempty]
    simp only [Finset.card_empty,Nat.cast_zero]
    positivity

def faceCubes (n : ℕ) (z : ℤ × ℤ) (d c : ℝ) : Finset Index :=
  (Finset.range n ×ˢ Finset.range n).biUnion fun ik =>
    (columns n ik.1 ik.2 z d c).image fun j => (ik.1,j,ik.2)

theorem face_cube_mem (n : ℕ) (z : ℤ × ℤ) (d c : ℝ)
    (j : Index) (hj : j∈grid n) (q : ℝ × ℝ × ℝ)
    (hq : Contains n j q) (hbox : FirstBox z q.1 q.2.2)
    (hface : coordinate d z q.1 q.2.1 q.2.2=c) : j∈faceCubes n z d c := by
  simp only [grid,Finset.mem_product] at hj
  apply Finset.mem_biUnion.mpr
  refine ⟨(j.1,j.2.2),Finset.mem_product.mpr ⟨hj.1,hj.2.2⟩,?_⟩
  apply Finset.mem_image.mpr
  refine ⟨j.2.1,?_,rfl⟩
  exact Finset.mem_filter.mpr ⟨hj.2.1,q.1,q.2.1,q.2.2,hq.1,hq.2.1,hq.2.2,hbox,hface⟩

theorem faceCubes_subset_grid (n : ℕ) (z : ℤ × ℤ) (d c : ℝ) :
    faceCubes n z d c ⊆ grid n := by
  intro j hj
  obtain ⟨⟨i,k⟩,hik,hj'⟩ := Finset.mem_biUnion.mp hj
  obtain ⟨l,hl,rfl⟩ := Finset.mem_image.mp hj'
  have hl' := (Finset.mem_filter.mp hl).1
  exact Finset.mem_product.mpr ⟨(Finset.mem_product.mp hik).1,
    Finset.mem_product.mpr ⟨hl',(Finset.mem_product.mp hik).2⟩⟩

theorem faceCubes_card (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (d c : ℝ) :
    ((faceCubes n z d c).card:ℝ)≤(2*(32*|(z.2:ℝ)|+240*|d|)+2)*(n:ℝ)^2 := by
  have hcard : (faceCubes n z d c).card ≤
      ∑ ik∈Finset.range n ×ˢ Finset.range n, (columns n ik.1 ik.2 z d c).card := by
    apply Finset.card_biUnion_le.trans
    exact Finset.sum_le_sum (fun _ _ => Finset.card_image_le)
  calc
    _ ≤ ∑ ik∈Finset.range n ×ˢ Finset.range n,
        ((columns n ik.1 ik.2 z d c).card:ℝ) := by exact_mod_cast hcard
    _ ≤ ∑ _ik∈Finset.range n ×ˢ Finset.range n, (2*(32*|(z.2:ℝ)|+240*|d|)+2) := by
      apply Finset.sum_le_sum
      intro ik hik
      exact columns_card n ik.1 ik.2 hn (Finset.mem_range.mp (Finset.mem_product.mp hik).1) z d c
    _ = _ := by simp; ring

/-- The actual second-coordinate boundary cover, inside the first box,
has this proved volume. No differentiability or regularity premise is used. -/
theorem faceCubes_volume (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (d c : ℝ) :
    ∑ j∈faceCubes n z d c, cellVolume n j ≤
      (960*|(z.2:ℝ)|+7200*|d|+30)/(n:ℝ) := by
  have hnR : (0:ℝ)<n := by exact_mod_cast hn
  simp only [cellVolume_eq,Finset.sum_const,nsmul_eq_mul]
  calc
    _ ≤ ((2*(32*|(z.2:ℝ)|+240*|d|)+2)*(n:ℝ)^2)*(15/(n:ℝ)^3) :=
      mul_le_mul_of_nonneg_right (faceCubes_card n hn z d c) (by positivity)
    _ = _ := by field_simp; ring

theorem physical_faceCubes_volume (n : ℕ) (hn : 0<n) (z : ℤ × ℤ) (U V c : ℝ)
    (hUV : 1≤U*V) :
    ∑ j∈faceCubes n z ((z.2:ℝ)/(U*V)) c, cellVolume n j ≤
      (8160*|(z.2:ℝ)|+30)/(n:ℝ) := by
  have hd : |(z.2:ℝ)/(U*V)|≤|(z.2:ℝ)| := by
    rw [abs_div,abs_of_nonneg (by linarith : 0≤U*V)]
    exact div_le_self (abs_nonneg _) hUV
  exact (faceCubes_volume n hn z _ c).trans (by gcongr; nlinarith)

end Elliptic.Operator.RootSecondFace
