module

public import Elliptic.Operator.PhysicalRootedMomentMatrix
public import Mathlib.Analysis.Matrix.PosDef
public import Mathlib.Analysis.MeanInequalities
public import Mathlib.Analysis.MeanInequalitiesPow

/-! Unnormalized finite position-vector trace bounds. The testing vectors
may have arbitrary norms and need not be orthogonal. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMomentEndpoint
open scoped BigOperators ComplexConjugate ComplexOrder
open Matrix Unitary
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

/-- Finite vector Cauchy--Schwarz, with no normalization of the vectors. -/
theorem norm_sum_smul_sq_le {Z E : Type*} [SeminormedAddCommGroup E]
    [NormedSpace ℂ E] (s : Finset Z) (f : Z → ℂ) (u : Z → E) :
    ‖∑ z∈s, f z • u z‖^2 ≤ (∑ z∈s, ‖f z‖^2)*(∑ z∈s, ‖u z‖^2) := by
  have ht : ‖∑ z∈s, f z • u z‖ ≤ ∑ z∈s, ‖f z‖*‖u z‖ := by
    simpa only [norm_smul] using norm_sum_le s (fun z => f z • u z)
  have hs := Finset.sum_mul_sq_le_sq_mul_sq s (fun z => ‖f z‖) (fun z => ‖u z‖)
  have hn : 0≤‖∑ z∈s, f z • u z‖ := norm_nonneg _
  nlinarith

/-- The actual quadratic coefficient bound for a positive semidefinite
matrix tested on any finite family of unnormalized vectors. -/
theorem posSemidef_coefficient_bound {Z X : Type*} [Fintype X] [DecidableEq X]
    (s : Finset Z) (B : Matrix X X ℂ) (hB : B.PosSemidef)
    (u : Z → X → ℂ) (f : Z → ℂ) :
    (star (∑ z∈s, f z • u z) ⬝ᵥ (B *ᵥ (∑ z∈s, f z • u z))).re ≤
      (∑ z∈s, (star (u z) ⬝ᵥ (B *ᵥ u z)).re)*(∑ z∈s, ‖f z‖^2) := by
  letI sn := B.toSeminormedAddCommGroup hB
  letI ip := B.toInnerProductSpace hB
  have hn (x : X → ℂ) : (@norm (X → ℂ) sn.toNorm x)^2=(star x ⬝ᵥ (B *ᵥ x)).re := by
    rw [← @inner_self_eq_norm_sq ℂ (X → ℂ) _ sn ip x]
    change ((B *ᵥ x) ⬝ᵥ star x).re=(star x ⬝ᵥ (B *ᵥ x)).re
    rw [dotProduct_comm]
  have h := @norm_sum_smul_sq_le Z (X → ℂ) sn ip.toNormedSpace s f u
  simp only [hn] at h
  simpa only [mul_comm] using h

/-- Source (3.21), including the scalar physical measure. The finite
trace sums diagonal tests on the original unnormalized position vectors. -/
theorem weighted_posSemidef_coefficient_bound {Z X : Type*} [Fintype X] [DecidableEq X]
    (s : Finset Z) (B : Matrix X X ℂ) (hB : B.PosSemidef)
    (u : Z → X → ℂ) (f : Z → ℂ) (m : ℝ) (hm : 0≤m) :
    m*(star (∑ z∈s, f z • u z) ⬝ᵥ (B *ᵥ (∑ z∈s, f z • u z))).re ≤
      (∑ z∈s, m*(star (u z) ⬝ᵥ (B *ᵥ u z)).re)*(∑ z∈s, ‖f z‖^2) := by
  have h := mul_le_mul_of_nonneg_left (posSemidef_coefficient_bound s B hB u f) hm
  convert h using 1
  rw [← Finset.mul_sum]
  ring

/-- Uniform coefficients turn the diagonal position trace into the
literal number of positions times the squared coefficient bound. -/
theorem weighted_posSemidef_coefficient_bound_of_norm_le
    {Z X : Type*} [Fintype X] [DecidableEq X]
    (s : Finset Z) (B : Matrix X X ℂ) (hB : B.PosSemidef)
    (u : Z → X → ℂ) (f : Z → ℂ) (m F : ℝ) (hm : 0≤m) (hF : 0≤F)
    (hf : ∀ z∈s, ‖f z‖≤F) :
    m*(star (∑ z∈s, f z • u z) ⬝ᵥ (B *ᵥ (∑ z∈s, f z • u z))).re ≤
      (s.card:ℝ)*F^2*(∑ z∈s, m*(star (u z) ⬝ᵥ (B *ᵥ u z)).re) := by
  have hd : 0≤∑ z∈s, m*(star (u z) ⬝ᵥ (B *ᵥ u z)).re :=
    Finset.sum_nonneg (fun z _ => mul_nonneg hm (hB.re_dotProduct_nonneg _))
  have hf' : (∑ z∈s, ‖f z‖^2)≤(s.card:ℝ)*F^2 := by
    calc
      _ ≤ ∑ _z∈s, F^2 := Finset.sum_le_sum (fun z hz => by
        nlinarith [hf z hz,norm_nonneg (f z)])
      _ = _ := by simp
  exact (weighted_posSemidef_coefficient_bound s B hB u f m hm).trans
    ((mul_le_mul_of_nonneg_left hf' hd).trans_eq (by ring))

/-- Every positive power of the concrete matrix `AA*` obeys the source
coefficient trace bound. No spectral norm premise is assumed. -/
theorem aaStar_power_coefficient_bound {Z X : Type*} [Fintype X] [DecidableEq X]
    (s : Finset Z) (A : Matrix X X ℂ) (R : ℕ)
    (u : Z → X → ℂ) (f : Z → ℂ) (m : ℝ) (hm : 0≤m) :
    m*(star (∑ z∈s, f z • u z) ⬝ᵥ ((A*Aᴴ)^R *ᵥ (∑ z∈s, f z • u z))).re ≤
      (∑ z∈s, m*(star (u z) ⬝ᵥ ((A*Aᴴ)^R *ᵥ u z)).re)*(∑ z∈s, ‖f z‖^2) :=
  weighted_posSemidef_coefficient_bound s _ ((posSemidef_self_mul_conjTranspose A).pow R) u f m hm

/-- Weighted finite power-mean inequality without normalized weights. -/
theorem weighted_power_mean {X : Type*} (s : Finset X) (w lam : X → ℝ)
    (hw : ∀ i∈s, 0≤w i) (hlam : ∀ i∈s, 0≤lam i) (R : ℕ) :
    (∑ i∈s, w i*lam i)^(R+1) ≤ (∑ i∈s, w i)^R*(∑ i∈s, w i*(lam i)^(R+1)) := by
  let M : ℝ := ∑ i∈s, w i
  have hM : 0≤M := Finset.sum_nonneg hw
  by_cases hz : M=0
  · have hw0 : ∀ i∈s, w i=0 := (Finset.sum_eq_zero_iff_of_nonneg hw).mp hz
    have hs0 : (∑ i∈s, w i*lam i)=0 := Finset.sum_eq_zero (fun i hi => by rw [hw0 i hi,zero_mul])
    have ht0 : (∑ i∈s, w i*(lam i)^(R+1))=0 := Finset.sum_eq_zero (fun i hi => by rw [hw0 i hi,zero_mul])
    simp [hs0,ht0]
  have hM0 : 0<M := lt_of_le_of_ne hM (Ne.symm hz)
  have hj := Real.pow_arith_mean_le_arith_mean_pow s (fun i => w i/M) lam
    (fun i hi => div_nonneg (hw i hi) hM)
    (by rw [← Finset.sum_div]; exact div_self hz) hlam (R+1)
  simp only [div_mul_eq_mul_div,← Finset.sum_div,div_pow] at hj
  have hc := (div_le_div_iff₀ (pow_pos hM0 _) hM0).mp hj
  apply le_of_mul_le_mul_right (a:=M) ?_ hM0
  convert hc using 1 <;> rw [pow_succ] <;> dsimp [M] <;> ring

private theorem quadratic_conjugate {X : Type*} [Fintype X] [DecidableEq X]
    (U B : Matrix X X ℂ) (x : X → ℂ) :
    star x ⬝ᵥ ((U*B*Uᴴ) *ᵥ x) =
      star (Uᴴ *ᵥ x) ⬝ᵥ (B *ᵥ (Uᴴ *ᵥ x)) := by
  simp only [star_mulVec,dotProduct_mulVec,vecMul_vecMul,conjTranspose_conjTranspose]

private theorem diagonal_quadratic {X : Type*} [Fintype X] [DecidableEq X]
    (lam : X → ℝ) (x : X → ℂ) (R : ℕ) :
    (star x ⬝ᵥ (diagonal (fun i => (lam i:ℂ)^R) *ᵥ x)).re =
      ∑ i, ‖x i‖^2*(lam i)^R := by
  simp only [dotProduct,Pi.star_apply,Complex.re_sum,mulVec_diagonal]
  apply Finset.sum_congr rfl
  intro i hi
  have he : star (x i)*((lam i:ℂ)^R*x i)=(‖x i‖:ℂ)^2*(lam i:ℂ)^R := by
    rw [← Complex.conj_mul']
    change conj (x i)*((lam i:ℂ)^R*x i)=_
    ring
  rw [he]
  simp only [← Complex.ofReal_pow,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
    zero_mul,sub_zero]

/-- Exact spectral expansion of the quadratic moments. -/
theorem quadratic_power_eigenvalues {X : Type*} [Fintype X] [DecidableEq X]
    (B : Matrix X X ℂ) (hB : B.IsHermitian) (x : X → ℂ) (R : ℕ) :
    (star x ⬝ᵥ (B^R *ᵥ x)).re =
      ∑ i, ‖((hB.eigenvectorUnitary:Matrix X X ℂ)ᴴ *ᵥ x) i‖^2*(hB.eigenvalues i)^R := by
  have hp : B^R = (hB.eigenvectorUnitary:Matrix X X ℂ) *
      diagonal (fun i => (hB.eigenvalues i:ℂ)^R) * (hB.eigenvectorUnitary:Matrix X X ℂ)ᴴ := by
    calc
      _ = (conjStarAlgAut ℂ _ hB.eigenvectorUnitary
          (diagonal (RCLike.ofReal ∘ hB.eigenvalues)))^R := congrArg (fun A => A^R) hB.spectral_theorem
      _ = conjStarAlgAut ℂ _ hB.eigenvectorUnitary
          ((diagonal (RCLike.ofReal ∘ hB.eigenvalues))^R) := (map_pow _ _ _).symm
      _ = _ := by rw [diagonal_pow]; rfl
  rw [hp,quadratic_conjugate,diagonal_quadratic]

/-- Spectral Hölder for every finite positive matrix, in the equivalent
integer-power form that has no fractional-power side conditions. -/
theorem posSemidef_spectral_holder {X : Type*} [Fintype X] [DecidableEq X]
    (B : Matrix X X ℂ) (hB : B.PosSemidef) (x : X → ℂ) (R : ℕ) :
    (star x ⬝ᵥ (B *ᵥ x)).re^(R+1) ≤
      (star x ⬝ᵥ x).re^R*(star x ⬝ᵥ (B^(R+1) *ᵥ x)).re := by
  let w := fun i => ‖((hB.isHermitian.eigenvectorUnitary:Matrix X X ℂ)ᴴ *ᵥ x) i‖^2
  have h := weighted_power_mean Finset.univ w hB.isHermitian.eigenvalues
    (fun i _ => sq_nonneg _) (fun i _ => hB.eigenvalues_nonneg i) R
  have h0 := quadratic_power_eigenvalues B hB.isHermitian x 0
  have h1 := quadratic_power_eigenvalues B hB.isHermitian x 1
  have hR := quadratic_power_eigenvalues B hB.isHermitian x (R+1)
  simp only [pow_zero,one_mulVec,mul_one] at h0
  simp only [pow_one] at h1
  change _ = ∑ i, w i at h0
  rw [h1,h0,hR]
  exact h

theorem self_quadratic_eq_sum_norm_sq {X : Type*} [Fintype X] [DecidableEq X] (x : X → ℂ) :
    (star x ⬝ᵥ x).re=∑ i, ‖x i‖^2 := by
  simpa only [pow_zero,diagonal_one,one_mulVec,mul_one] using
    diagonal_quadratic (fun _ : X => (1:ℝ)) x 0

/-- Finite Cauchy--Schwarz for the literal coefficient pairing. -/
theorem pairing_sq_le {X : Type*} [Fintype X] [DecidableEq X] (x y : X → ℂ) :
    ‖star x ⬝ᵥ y‖^2 ≤ (star x ⬝ᵥ x).re*(star y ⬝ᵥ y).re := by
  rw [self_quadratic_eq_sum_norm_sq,self_quadratic_eq_sum_norm_sq]
  change ‖∑ i, conj (x i)*y i‖^2≤_
  have h := norm_sum_smul_sq_le Finset.univ (fun i => conj (x i)) y
  simpa only [smul_eq_mul,Complex.norm_conj] using h

/-- Spectral Hölder followed by Cauchy--Schwarz gives the actual endpoint
moment estimate for every complex matrix. This is its integer-power form. -/
theorem aaStar_pairing_power_bound {X : Type*} [Fintype X] [DecidableEq X]
    (A : Matrix X X ℂ) (f g : X → ℂ) (R : ℕ) :
    ‖star f ⬝ᵥ (A *ᵥ g)‖^(2*(R+1)) ≤
      (star g ⬝ᵥ g).re^(R+1)*(star f ⬝ᵥ f).re^R*
        (star f ⬝ᵥ ((A*Aᴴ)^(R+1) *ᵥ f)).re := by
  have he : star f ⬝ᵥ (A *ᵥ g)=star (Aᴴ *ᵥ f) ⬝ᵥ g := by
    simp only [star_mulVec,conjTranspose_conjTranspose,dotProduct_mulVec]
  have hq : star f ⬝ᵥ ((A*Aᴴ) *ᵥ f)=star (Aᴴ *ᵥ f) ⬝ᵥ (Aᴴ *ᵥ f) := by
    simpa only [mul_one,one_mulVec] using quadratic_conjugate A 1 f
  have hc := pairing_sq_le (Aᴴ *ᵥ f) g
  rw [← he,← hq] at hc
  have hp := pow_le_pow_left₀ (sq_nonneg ‖star f ⬝ᵥ (A *ᵥ g)‖) hc (R+1)
  rw [← pow_mul,mul_pow] at hp
  have hs := posSemidef_spectral_holder (A*Aᴴ) (posSemidef_self_mul_conjTranspose A) f R
  have hg : 0≤(star g ⬝ᵥ g).re := by
    rw [self_quadratic_eq_sum_norm_sq]
    exact Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  exact hp.trans ((mul_le_mul_of_nonneg_right hs (pow_nonneg hg _)).trans_eq (by ring))

/-- The same endpoint estimate in the exact constant physical measure. -/
theorem weighted_aaStar_pairing_power_bound {X : Type*} [Fintype X] [DecidableEq X]
    (A : Matrix X X ℂ) (f g : X → ℂ) (R : ℕ) (m : ℝ) (hm : 0≤m) :
    ‖(m:ℂ)*(star f ⬝ᵥ (A *ᵥ g))‖^(2*(R+1)) ≤
      (m*(star g ⬝ᵥ g).re)^(R+1)*(m*(star f ⬝ᵥ f).re)^R*
        (m*(star f ⬝ᵥ ((A*Aᴴ)^(R+1) *ᵥ f)).re) := by
  have h := mul_le_mul_of_nonneg_left (aaStar_pairing_power_bound A f g R)
    (pow_nonneg hm (2*(R+1)))
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hm,mul_pow]
  convert h using 1
  simp only [mul_pow,show 2*(R+1)=(R+1)+R+1 by omega,pow_add,pow_one]
  ring

/-- The source moment-to-endpoint estimate on an arbitrary finite set
of unnormalized position vectors. Both spectral Hölder and the trace
coefficient estimate are proved, rather than supplied as assumptions. -/
theorem aaStar_endpoint_trace_bound {Z X : Type*} [Fintype X] [DecidableEq X]
    (s : Finset Z) (A : Matrix X X ℂ) (R : ℕ)
    (u : Z → X → ℂ) (f : Z → ℂ) (g : X → ℂ) (m : ℝ) (hm : 0≤m) :
    let F := ∑ z∈s, f z • u z
    ‖(m:ℂ)*(star F ⬝ᵥ (A *ᵥ g))‖^(2*(R+1)) ≤
      (m*(star g ⬝ᵥ g).re)^(R+1)*(m*(star F ⬝ᵥ F).re)^R*
        ((∑ z∈s, m*(star (u z) ⬝ᵥ ((A*Aᴴ)^(R+1) *ᵥ u z)).re)*(∑ z∈s, ‖f z‖^2)) := by
  dsimp only
  have h := weighted_aaStar_pairing_power_bound A (∑ z∈s, f z • u z) g R m hm
  have ht := aaStar_power_coefficient_bound s A (R+1) u f m hm
  apply h.trans
  apply mul_le_mul_of_nonneg_left ht
  have hn (x : X → ℂ) : 0≤m*(star x ⬝ᵥ x).re := by
    rw [self_quadratic_eq_sum_norm_sq]
    exact mul_nonneg hm (Finset.sum_nonneg (fun _ _ => sq_nonneg _))
  exact mul_nonneg (pow_nonneg (hn g) _) (pow_nonneg (hn _) _)

end Elliptic.Operator.PhysicalMomentEndpoint

namespace Elliptic.Operator.PhysicalRootedMoment
open scoped BigOperators ComplexConjugate Matrix ComplexOrder
open PhysicalMomentEndpoint
attribute [local instance] Classical.propDecidable
local instance endpointDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)] {J : ℕ}

theorem initialMass_nonneg (V : I → ℝ) (hV : ∀ i, 0≤V i) :
    0≤Elliptic.Operator.PhysicalRootedMoment.initialMass (J:=J) V :=
  Finset.prod_nonneg (fun i _ => pow_nonneg (inv_nonneg.mpr (hV i)) _)

/-- The coefficient vector is exactly the physical observable restricted
to its finite position set; the ordered lists are never normalized. -/
theorem positionVector_sum (s : Finset Z) (f : Z → ℂ) :
    (∑ z∈s, f z • (positionVector (P:=P) (J:=J) z)) =
      fun x => if x.1∈s then f x.1 else 0 := by
  funext x
  simp [positionVector,Finset.sum_apply,Pi.smul_apply,smul_eq_mul,mul_ite]

theorem pairing_self_re (V : I → ℝ)
    (F : State (Z:=Z) (P:=P) (J:=J) → ℂ) :
    (pairing V F F).re=initialMass (J:=J) V*(star F ⬝ᵥ F).re := by
  change (((initialMass (J:=J) V:ℝ):ℂ)*(star F ⬝ᵥ F)).re=_
  simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]

theorem pairing_power_re (V : I → ℝ)
    (g : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (R : ℕ) (F : State (Z:=Z) (P:=P) (J:=J) → ℂ) :
    (pairing V F (aaStarPower V g R F)).re =
      initialMass (J:=J) V*(star F ⬝ᵥ (((matrix V g)*(matrix V g)ᴴ)^R *ᵥ F)).re := by
  rw [aaStarPower_eq_matrix]
  change (((initialMass (J:=J) V:ℝ):ℂ)*
    (star F ⬝ᵥ (((matrix V g)*(matrix V g)ᴴ)^R *ᵥ F))).re=_
  simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]

/-- Source (3.21) for the actual physical AA* power and its original
constant list measure, on unnormalized position testing vectors. -/
theorem position_trace_coefficient_bound
    (V : I → ℝ) (hV : ∀ i, 0≤V i)
    (g : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (R : ℕ) (s : Finset Z) (f : Z → ℂ) :
    let F := ∑ z∈s, f z • (positionVector (P:=P) (J:=J) z)
    (pairing V F (aaStarPower V g R F)).re ≤
      (∑ z∈s, (pairing V (positionVector z) (aaStarPower V g R (positionVector z))).re)*
        (∑ z∈s, ‖f z‖^2) := by
  dsimp only
  simp only [pairing_power_re]
  exact aaStar_power_coefficient_bound s (matrix V g) R positionVector f
    (initialMass (J:=J) V) (initialMass_nonneg V hV)

/-- Literal physical endpoint pairing from its positive rooted moment.
This directly combines the actual matrix identification, spectral
Hölder and the unnormalized position-trace coefficient bound. -/
theorem position_endpoint_trace_bound
    (V : I → ℝ) (hV : ∀ i, 0≤V i)
    (g : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (R : ℕ) (s : Finset Z) (f : Z → ℂ)
    (G : State (Z:=Z) (P:=P) (J:=J) → ℂ) :
    let F := ∑ z∈s, f z • (positionVector (P:=P) (J:=J) z)
    ‖pairing V F (rowApply V g G)‖^(2*(R+1)) ≤
      (pairing V G G).re^(R+1)*(pairing V F F).re^R*
        ((∑ z∈s, (pairing V (positionVector z)
          (aaStarPower V g (R+1) (positionVector z))).re)*(∑ z∈s, ‖f z‖^2)) := by
  dsimp only
  simp only [pairing_self_re,pairing_power_re,rowApply_eq_mulVec]
  exact aaStar_endpoint_trace_bound s (matrix V g) R positionVector f G
    (initialMass (J:=J) V) (initialMass_nonneg V hV)

/-- The same endpoint estimate indexed by the positive moment order R,
as in the source, rather than by its predecessor. -/
theorem position_endpoint_trace_bound_pos
    (V : I → ℝ) (hV : ∀ i, 0≤V i)
    (g : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (R : ℕ) (hR : 0<R) (s : Finset Z) (f : Z → ℂ)
    (G : State (Z:=Z) (P:=P) (J:=J) → ℂ) :
    let F := ∑ z∈s, f z • (positionVector (P:=P) (J:=J) z)
    ‖pairing V F (rowApply V g G)‖^(2*R) ≤
      (pairing V G G).re^R*(pairing V F F).re^(R-1)*
        ((∑ z∈s, (pairing V (positionVector z)
          (aaStarPower V g R (positionVector z))).re)*(∑ z∈s, ‖f z‖^2)) := by
  simpa only [Nat.sub_add_cancel hR] using
    position_endpoint_trace_bound V hV g (R-1) s f G

/-- Taking the explicit 2R-th root gives a direct norm bound from the
actual positive position moment. -/
theorem position_endpoint_trace_root_bound
    (V : I → ℝ) (hV : ∀ i, 0≤V i)
    (g : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (R : ℕ) (hR : 0<R) (s : Finset Z) (f : Z → ℂ)
    (G : State (Z:=Z) (P:=P) (J:=J) → ℂ) :
    let F := ∑ z∈s, f z • (positionVector (P:=P) (J:=J) z)
    ‖pairing V F (rowApply V g G)‖ ≤
      ((pairing V G G).re^R*(pairing V F F).re^(R-1)*
        ((∑ z∈s, (pairing V (positionVector z)
          (aaStarPower V g R (positionVector z))).re)*(∑ z∈s, ‖f z‖^2)))^
            (1/(2*(R:ℝ))) := by
  dsimp only
  have hh := position_endpoint_trace_bound_pos V hV g R hR s f G
  dsimp only at hh
  have hn := (pow_nonneg (norm_nonneg (pairing V
    (∑ z∈s, f z • positionVector z) (rowApply V g G))) (2*R)).trans hh
  have hx := (Real.le_rpow_inv_iff_of_pos (norm_nonneg (pairing V
    (∑ z∈s, f z • positionVector z) (rowApply V g G))) hn
    (show (0:ℝ)<(2*R:ℕ) by exact_mod_cast Nat.mul_pos (by omega) hR)).mpr
      (by simpa only [Real.rpow_natCast] using hh)
  simpa only [Nat.cast_mul,Nat.cast_ofNat,one_div] using hx

end Elliptic.Operator.PhysicalRootedMoment
