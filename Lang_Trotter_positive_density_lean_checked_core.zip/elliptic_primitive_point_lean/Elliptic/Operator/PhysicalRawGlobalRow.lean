module

public import Elliptic.Operator.PhysicalRawMaskedRow
public import Elliptic.Operator.PhysicalBagRepresentatives

/-!
# Uniform raw rows from the literal good-state projection

A nonzero raw row itself supplies the source primitive position and its
good-state test. Slot invariance transfers that exact test to the original
source lists; no uniform row estimate is imposed as an assumption.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRawGlobalRow
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalRawMaskedRow
attribute [local instance] Classical.propDecidable
local instance rawGlobalRowDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable [Fintype Z] [∀ i, Fintype (P i)]
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable [∀ i p, Fintype (ZMod (value i p))]

/-- The source projection includes exactly the stated second good-state
test, at some integral complement of every primitive allowed source.
Changing that complement only adds an integer to its phase parameter. -/
def GoodProjection (μ : ∀ i, P i → ℝ) (d₀ r L : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop) : Prop :=
  ∀ z b, IsCoprime z.1 z.2 → good z b → ∃ w, latticeDet z w=1 ∧
    SourceSecondGoodState.SecondGoodTest value (physicalSourceLabels value b) μ d₀
      (latticeTau r w/latticeTau r z) L a

/-- The actual numerical row budget for an arbitrary promotion mask. -/
def budget (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K → ℝ) (I : Fin K → Bool) : ℝ :=
  if ∃ i, I i=true then
    PhysicalDirtyRow.separatedBudget K J B ρ v0 vmin M + PhysicalDirtyRow.exceptionalBudget K B ρ v0 vmin L a
  else 33*((1+v0)*M)^K

theorem budget_nonneg (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K → ℝ) (I : Fin K → Bool)
    (hρ : ρ < 1) (hv0 : 0 < v0) (hmin : 0 < vmin) (hM : 0 ≤ M) :
    0 ≤ budget K J B ρ v0 vmin M L a I := by
  have hr : 0 < 1-ρ := sub_pos.mpr hρ
  unfold budget
  split_ifs
  · unfold PhysicalDirtyRow.separatedBudget PhysicalDirtyRow.exceptionalBudget
    apply add_nonneg
    · apply Finset.sum_nonneg
      intro i _
      positivity
    · apply mul_nonneg (by positivity)
      apply Finset.sum_nonneg
      intro i _
      unfold DirtyExceptionalOuter.storeBudget
      positivity
  · positivity

/-- Any actual selected edge supplies an original-list second-good test.
Its source permutation is removed by the proved source-test invariance. -/
theorem second_good_of_choice
    (μ : ∀ i, P i → ℝ) (d₀ r L : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (hgood : GoodProjection value μ d₀ r L a good)
    (u v U W : ℝ) (σ : ℤ)
    (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
    (c : PhysicalEdgeChoice s)
    (hc : PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c) :
    ∃ w, latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w=1 ∧
      SourceSecondGoodState.SecondGoodTest value
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) μ d₀
        (latticeTau r w/latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) L a := by
  obtain ⟨w,hw,ht⟩ := hgood _ c.sourceLists hc.2.1.1.1 hc.2.1.2.2.1
  refine ⟨w,hw,?_⟩
  apply (SourceSecondGoodState.secondGoodTest_permute value
    (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
    c.sourcePerm μ d₀ _ L a).mp
  exact ht

/-- Every ordered physical raw row has its explicit mask-dependent bound.
The only goodness premise is the literal pointwise second-good test. -/
theorem ordered_row_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool)
    (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ=1 ∨ σ= -1)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hgood : GoodProjection value μ d₀ r L a good)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p:ℝ))
    (hνμ : ∀ i p, ν i p ≤ 2*μ i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hM : 0 ≤ M) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z b w c, sourceRawAllowed value good u v r U W d₀ σ z b w c → ‖amplitude z b w c‖ ≤ A)
    (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B) :
    row ν V S I ρ v0 (anchor value position)
      (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c)
      (ofOrdered s) ≤ A * budget K J B ρ v0 vmin M L a I := by
  by_cases he : (choices value position s S I good u v r U W d₀ σ).Nonempty
  · obtain ⟨c,hc⟩ := he
    obtain ⟨w,hw,ht⟩ := second_good_of_choice value position μ d₀ r L a good hgood u v U W σ s c
      (Finset.mem_filter.mp hc).2.1
    by_cases hI : ∃ i, I i=true
    · rw [budget,ite_eq_left hI]
      exact promotion_row_le value position s hposition hprime ν μ hνpos V S I hI
        ρ v0 vmin M L A a good u v r U W d₀ σ hU hσ amplitude w hw ht hband hνμ
        hV hmin hρ0 hρ1 hv0 hA hmass hamp
    · rw [budget,ite_eq_right hI]
      have hIf : ∀ i, I i=false := by
        intro i
        cases he : I i
        · rfl
        · exact (hI ⟨i,he⟩).elim
      exact fresh_row_le value position s hposition ν hνpos V S I hIf ρ v0 M A good
        u v r U W d₀ σ hU amplitude w hw (fun i => (hmin.trans_le (hV i)).le)
        hρ0 hρ1 hv0 hA hmass hamp
  · have hempty : choices value position s S I good u v r U W d₀ σ = ∅ := Finset.not_nonempty_iff_eq_empty.mp he
    have h := bag_row_le_raw value position s ν hνpos V S I ρ v0 A good u v r U W d₀ σ amplitude
      (fun i => (hmin.trans_le (hV i)).le) hρ0 hv0.le hamp
    rw [hempty,Finset.sum_empty,mul_zero,mul_zero] at h
    exact h.trans (mul_nonneg hA (budget_nonneg K J B ρ v0 vmin M L a I hρ1 hv0 hmin hM))

/-- Uniform row estimate on every bag state: admissible states have an
actual ordered representative; the other rows are zero by definition. -/
theorem row_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool)
    (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ=1 ∨ σ= -1)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hgood : GoodProjection value μ d₀ r L a good)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p:ℝ))
    (hνμ : ∀ i p, ν i p ≤ 2*μ i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hM : 0 ≤ M) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z b w c, sourceRawAllowed value good u v r U W d₀ σ z b w c → ‖amplitude z b w c‖ ≤ A)
    (s : State (Z:=Z) (P:=P) (Line:=fun i p => Option (ZMod (value i p))) (J:=J) (B:=B)) :
    row ν V S I ρ v0 (anchor value position)
      (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c)
      s ≤ A * budget K J B ρ v0 vmin M L a I := by
  by_cases hs : Total s
  · obtain ⟨t,ht⟩ := PhysicalBagRepresentatives.ofOrdered_exists s hs
    rw [← ht]
    exact ordered_row_le value position hposition hprime ν μ hνpos V S I ρ v0 vmin M L A a
      good u v r U W d₀ σ hU hσ amplitude hgood hband hνμ hV hmin hρ0 hρ1 hv0 hM hA hmass hamp t
  · have hz : row ν V S I ρ v0 (anchor value position)
        (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c) s = 0 := by
      simp [row,originalKernel,kernel,hs]
    rw [hz]
    exact mul_nonneg hA (budget_nonneg K J B ρ v0 vmin M L a I hρ1 hv0 hmin hM)

end Elliptic.Operator.PhysicalRawGlobalRow
