module

public import Elliptic.Operator.PhysicalMaskedKernel

/-!
# Exact active-list reindexing at a physical edge

A fixed endpoint permutation splits every ordered active list into its
shared slots and unshared prime. Summing the literal shared-slot equality
indicator removes the shared slots without any numerical distinctness or
independence assumption. The output permutation is reversed explicitly.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalActiveReindex
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalActiveReindexDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type*} {P : I → Type*} {J : ℕ}

abbrev SharedLists (P : I → Type*) (J : ℕ) := ∀ i, Fin J → P i
abbrev Permutations := I → Equiv.Perm (Fin (J+1))

/-- Reconstruct the original ordered list from its permuted shared slots
and its single permuted unshared slot. -/
def assemble (τ : Permutations (I:=I) (J:=J))
    (shared : SharedLists P J) (prime : ∀ i, P i) : PhysicalActiveLists P J :=
  fun i j => Fin.lastCases (prime i) (shared i) ((τ i).symm j)

@[simp] theorem assemble_shared (τ : Permutations (I:=I) (J:=J))
    (shared : SharedLists P J) (prime : ∀ i, P i) (i : I) (j : Fin J) :
    assemble τ shared prime i (τ i j.castSucc) = shared i j := by
  simp [assemble]

@[simp] theorem assemble_last (τ : Permutations (I:=I) (J:=J))
    (shared : SharedLists P J) (prime : ∀ i, P i) (i : I) :
    assemble τ shared prime i (τ i (Fin.last J)) = prime i := by
  simp [assemble]

/-- The literal shared/unshared decomposition, including empty prime types. -/
def equiv (τ : Permutations (I:=I) (J:=J)) :
    PhysicalActiveLists P J ≃ SharedLists P J × (∀ i, P i) where
  toFun a := (fun i j => a i (τ i j.castSucc), fun i => a i (τ i (Fin.last J)))
  invFun b := assemble τ b.1 b.2
  left_inv a := by
    funext i j
    have h := (τ i).apply_symm_apply j
    generalize he : (τ i).symm j = k at *
    rw [← h]
    refine Fin.lastCases ?_ (fun k => ?_) k
    · simp [assemble]
    · simp [assemble]
  right_inv b := by
    rcases b with ⟨shared,prime⟩
    apply Prod.ext
    · funext i j
      exact assemble_shared τ shared prime i j
    · funext i
      exact assemble_last τ shared prime i

@[simp] theorem equiv_symm_apply (τ : Permutations (I:=I) (J:=J))
    (shared : SharedLists P J) (prime : ∀ i, P i) :
    (equiv (P:=P) τ).symm (shared,prime) = assemble τ shared prime := rfl

/-- Recovering all slots after decomposition is exact, without a
prime-distinctness assumption on the active list. -/
theorem assemble_of_list (τ : Permutations (I:=I) (J:=J)) (a : PhysicalActiveLists P J) :
    assemble τ (fun i j => a i (τ i j.castSucc))
      (fun i => a i (τ i (Fin.last J))) = a :=
  (equiv τ).left_inv a

variable [Fintype I] [∀ i, Fintype (P i)]

/-- Summing the actual shared-slot equality indicator leaves only the
unshared target prime in each group. Arbitrary coupled F is retained. -/
theorem sum_shared {R : Type*} [AddCommMonoid R]
    (source : PhysicalActiveLists P J) (π τ : Permutations (I:=I) (J:=J))
    (F : PhysicalActiveLists P J → R) :
    (∑ a : PhysicalActiveLists P J,
      if (∀ i (j : Fin J), source i (π i j.castSucc) = a i (τ i j.castSucc)) then F a else 0) =
    ∑ prime : ∀ i, P i, F (assemble τ (fun i j => source i (π i j.castSucc)) prime) := by
  rw [Fintype.sum_equiv (equiv (P:=P) τ)
    (fun a => if (∀ i (j : Fin J), source i (π i j.castSucc) = a i (τ i j.castSucc)) then F a else 0)
    (fun b => if (∀ i (j : Fin J), source i (π i j.castSucc) = b.1 i j)
      then F (assemble τ b.1 b.2) else 0)
    (fun a => by
      have ha : assemble τ ((equiv (P:=P) τ) a).1 ((equiv (P:=P) τ) a).2 = a :=
        (equiv (P:=P) τ).left_inv a
      by_cases hh : ∀ i (j : Fin J), source i (π i j.castSucc) = a i (τ i j.castSucc)
      · have hh' : ∀ i (j : Fin J), source i (π i j.castSucc) = ((equiv (P:=P) τ) a).1 i j := hh
        simp only [ite_eq_left hh,ite_eq_left hh',ha]
      · have hh' : ¬ (∀ i (j : Fin J), source i (π i j.castSucc) = ((equiv (P:=P) τ) a).1 i j) := hh
        simp only [ite_eq_right hh,ite_eq_right hh'])]
  rw [Fintype.sum_prod_type]
  rw [Finset.sum_eq_single (fun i j => source i (π i j.castSucc))]
  · simp
  · intro shared _ hshared
    have hn : ¬ (∀ i (j : Fin J), source i (π i j.castSucc) = shared i j) := by
      intro he
      exact hshared (funext (fun i => funext (fun j => (he i j).symm)))
    simp [hn]
  · simp

/-- The bag-kernel reconstruction is the physical target-list assembly
followed by the inverse target endpoint permutation. -/
theorem assemble_eq_targetLists (source : PhysicalActiveLists P J)
    (π τ : Permutations (I:=I) (J:=J)) (prime : ∀ i, P i) :
    assemble τ (fun i j => source i (π i j.castSucc)) prime =
      fun i j => PhysicalEdgeAdjoint.targetLists source π prime i ((τ i).symm j) := rfl

/-- Inverting every target endpoint permutation is an exact bijection. -/
def inversePermutations : Permutations (I:=I) (J:=J) ≃ Permutations (I:=I) (J:=J) where
  toFun τ i := (τ i).symm
  invFun τ i := (τ i).symm
  left_inv τ := by funext i; exact Equiv.symm_symm (τ i)
  right_inv τ := by funext i; exact Equiv.symm_symm (τ i)

/-- The complete uniform target-permutation sum is unchanged by inversion. -/
theorem sum_inverse_permutations {R : Type*} [AddCommMonoid R]
    (F : Permutations (I:=I) (J:=J) → R) :
    (∑ τ : Permutations (I:=I) (J:=J), F (fun i => (τ i).symm)) = ∑ τ, F τ :=
  (inversePermutations (I:=I) (J:=J)).sum_comp F

/-- Shared-slot elimination followed by target-permutation inversion gives
exactly the target lists in the original physical edge definition. -/
theorem sum_permutations_shared {R : Type*} [AddCommMonoid R]
    (source : PhysicalActiveLists P J) (π : Permutations (I:=I) (J:=J))
    (F : Permutations (I:=I) (J:=J) → PhysicalActiveLists P J → R) :
    (∑ τ : Permutations (I:=I) (J:=J), ∑ a : PhysicalActiveLists P J,
      if (∀ i (j : Fin J), source i (π i j.castSucc) = a i (τ i j.castSucc)) then F τ a else 0) =
    ∑ τ : Permutations (I:=I) (J:=J), ∑ prime : ∀ i, P i,
      F (fun i => (τ i).symm)
        (fun i j => PhysicalEdgeAdjoint.targetLists source π prime i (τ i j)) := by
  simp_rw [sum_shared source π]
  symm
  have h := sum_inverse_permutations (I:=I) (J:=J)
    (fun τ => ∑ prime : ∀ i, P i,
      F τ (assemble τ (fun i j => source i (π i j.castSucc)) prime))
  simpa only [assemble_eq_targetLists,Equiv.symm_symm] using h

end Elliptic.Operator.PhysicalActiveReindex
