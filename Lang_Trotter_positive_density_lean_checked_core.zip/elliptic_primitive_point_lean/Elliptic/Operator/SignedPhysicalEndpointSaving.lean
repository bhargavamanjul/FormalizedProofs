module
public import Elliptic.Operator.SignedPhysicalEndpointIdentity

/-! The actual complete source endpoints enjoy arbitrary logarithmic
saving in the original physical good pairing. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalEndpointSaving
open Filter
open scoped BigOperators SchwartzMap ComplexConjugate
open SignedPhysicalPairBridge PhysicalRootedMoment PhysicalMomentIdentification
open SingleEdgePhysicalRestoration RootLiteralGeometry SourceRootCount
open PhysicalRootIndependentMoment PhysicalRootBoundarySaving SingleEdgeRootEncoding
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

theorem exists_group_count_for_complete_pairing (hPD : RootCountContract)
    (A C : ℝ) (hA : 0≤A) (hC : 0≤C) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(ψ : 𝓢(ℝ,ℂ)) (smooth : ℝ→ℂ) (D δ Cψ vmin vmax : ℝ),
      0≤D→0<δ→1≤Cψ→0<vmin→
      (∀t,‖smooth t‖≤1)→(∀t,smooth t≠0→1≤t)→
      (∀t,‖ψ t‖≤1)→(∀t,ψ t≠0→|t|≤Cψ)→
      ∀ᶠx : ℝ in atTop,let L := Real.log x
      ∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀groups : Fin K→Finset ℕ,∀[∀i (p:groups i),Fact p.val.Prime],
      (∀i j,i≠j→Disjoint (groups i) (groups j))→∀VM : Fin K→ℝ,
      (∀i,vmin≤VM i)→(∀i,VM i≤vmax)→(∀i,VM i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      (∀i,∀p∈groups i,(p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))→
      ∀(U V d₀ Y : ℝ),x^δ≤U→U≤x^2→x^δ≤V→V≤x^2→1≤U*V→0<d₀→
      1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→d₀*Y≤Real.exp (D*L^(21/100:ℝ))→
      ∀(σ : ℤ),(σ=1∨σ= -1)→∀(S T : Finset ℕ) (α β : ℕ→ℂ),
      (∀m∈S,‖α m‖≤L^C)→(∀n∈T,‖β n‖≤L^C)→
      (∀m∈S,α m≠0→∀p∈groupPool groups,¬p∣m)→
      ‖originalPairing (J:=momentPadding L) (fun i (p:groups i)=>p.val) VM
        (sourceGood (fun i (p:groups i)=>p.val) (fun i (p:groups i)=>1/(VM i*p.val))
          d₀ Y L a (1,1,0)) U V d₀ Y
        (L^(sourceContractionExponent (A+4*C+4)+6)) smooth ψ σ
        (fun x=>completeLeft groups (momentPadding L) S T α β x.1)
        (fun x=>completeRight groups (momentPadding L) S T α β x.1)‖≤U*V*L^(-A) := by
  obtain ⟨K₀,hK₀,h⟩ := PhysicalEndpointSaving.exists_group_count_for_physical_endpoint hPD A (2*C) hA (by positivity)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ψ smooth D δ Cψ vmin vmax hD hδ hCψ hmin hsmooth hsupport hψ hsuppψ
  filter_upwards [h K hK ψ smooth D δ Cψ (1/4) vmin vmax hD hδ hCψ (by norm_num) (by norm_num)
      hmin hsmooth hsupport hψ hsuppψ,
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop (0:ℝ)),eventually_gt_atTop (0:ℝ)] with x hx hL hx0
  dsimp only
  let L := Real.log x
  intro a ha groups instPr hdis VM hVlo hVhi hVsum hband hupper U V d₀ Y
    hU hUhi hV hVhi' hUV hd hY hYlo hYhi hprod σ hσ S T α β hα hβ hrough
  letI : ∀i (p:groups i),Fact p.val.Prime := instPr
  have hp : ∀i,∀p∈groups i,p.Prime := fun i p hpg=>(instPr i ⟨p,hpg⟩).out
  have hUp : 0<U := (Real.rpow_pos_of_pos hx0 δ).trans_le hU
  have hVp : 0<V := (Real.rpow_pos_of_pos hx0 δ).trans_le hV
  have he : L^C*L^C=L^(2*C) := by rw [←Real.rpow_add hL]; congr 1; ring
  have hf (z : primitiveSources U V) :
      ‖conj (completeLeft groups (momentPadding L) S T α β z.val)‖≤L^(2*C) := by
    rw [Complex.norm_conj,←he]
    exact completeLeft_norm_le groups _ S T α β _ _ (by positivity) (by positivity) hα hβ z.val
  have hg (z : State (Z:=primitiveSources U V) (P:=fun i=>groups i) (J:=momentPadding L)) :
      ‖completeRight groups (momentPadding L) S T α β z.1.val‖≤L^(2*C) := by
    rw [←he]
    exact completeRight_norm_le groups _ S T α β _ _ (by positivity) (by positivity) hα hβ z.1.val
  have hb := @hx a ha groups instPr hdis VM hVlo hVhi hVsum hband hupper U V d₀ Y
    hU hUhi hV hVhi' hUV hd hY hYlo hYhi hprod σ hσ
    (fun z=>conj (completeLeft groups (momentPadding L) S T α β z.val)) hf
    (fun z=>completeRight groups (momentPadding L) S T α β z.1.val) hg
  have hi := pairing_complete_eq_original (J:=momentPadding L) groups hp VM
    (fun i (p:groups i)=>1/(VM i*p.val)) U V d₀ Y L
    (L^(sourceContractionExponent (A+2*(2*C)+4)+6)) (1-Real.sqrt (1/4))
    hUp.le hVp.le a smooth ψ σ S T α β hrough
  rw [hi] at hb
  convert hb using 1 <;> congr 7 <;> ring

end Elliptic.Operator.SignedPhysicalEndpointSaving
