module

public import Elliptic.Operator.TensorDeterminant

/-!
# Direct sums of measured finite clean blocks

Conditioning on unchanged shared labels and pending particles gives diagonal
blocks. This file proves their uniform norm bound passes to the whole
finite kernel, with no factor depending on the number of conditioning
states or cells. It is the finite direct-sum operation used in source
equations (4.29)--(4.34), independently of any source analytic estimate.
-/

@[expose] public section

namespace Elliptic.Operator

open scoped BigOperators

def blockDiagonalKernel {ι ζ ξ : Type*} [DecidableEq ι]
    (K : ι → ζ → ξ → ℂ) (p : ι × ζ) (q : ι × ξ) : ℂ :=
  if p.1 = q.1 then K p.1 p.2 q.2 else 0

theorem blockDiagonalKernel_apply {ι ζ ξ : Type*} [DecidableEq ι]
    (I : Finset ι) (t : Finset ξ) (ν : ι → ξ → ℝ)
    (K : ι → ζ → ξ → ℂ) (b : ι × ξ → ℂ) (i : ι) (hi : i ∈ I) (z : ζ) :
    finiteKernelApply (I ×ˢ t) (fun q => ν q.1 q.2) (blockDiagonalKernel K) b (i,z) =
      finiteKernelApply t (ν i) (K i) (fun w => b (i,w)) z := by
  simp only [finiteKernelApply, Finset.sum_product, blockDiagonalKernel]
  rw [Finset.sum_eq_single i]
  · simp
  · intro j hj hji
    simp [Ne.symm hji]
  · exact fun h => (h hi).elim

/-- Uniform block norm bounds yield the same global bound. The block
measures may vary and may have zero atoms. There is no cardinality loss
from conditioning on a large number of shared or pending states. -/
theorem blockDiagonalKernel_bound {ι ζ ξ : Type*} [DecidableEq ι]
    (I : Finset ι) (s : Finset ζ) (t : Finset ξ)
    (μ : ι → ζ → ℝ) (ν : ι → ξ → ℝ) (K : ι → ζ → ξ → ℂ)
    (M : ℝ) (hM : 0 ≤ M)
    (hμ : ∀ i ∈ I, ∀ z ∈ s, 0 ≤ μ i z)
    (hν : ∀ i ∈ I, ∀ w ∈ t, 0 ≤ ν i w)
    (hK : ∀ i ∈ I, FiniteKernelBound s t (μ i) (ν i) (K i) M) :
    FiniteKernelBound (I ×ˢ s) (I ×ˢ t)
      (fun p => μ p.1 p.2) (fun q => ν q.1 q.2) (blockDiagonalKernel K) M := by
  intro b
  have hsq : finiteL2Sq (I ×ˢ s) (fun p => μ p.1 p.2)
      (finiteKernelApply (I ×ˢ t) (fun q => ν q.1 q.2) (blockDiagonalKernel K) b) ≤
      M ^ 2 * finiteL2Sq (I ×ˢ t) (fun q => ν q.1 q.2) b := by
    calc
      _ = ∑ i ∈ I, finiteL2Sq s (μ i)
          (finiteKernelApply t (ν i) (K i) (fun w => b (i,w))) := by
        simp only [finiteL2Sq, Finset.sum_product]
        apply Finset.sum_congr rfl
        intro i hi
        apply Finset.sum_congr rfl
        intro z hz
        rw [blockDiagonalKernel_apply I t ν K b i hi z]
      _ ≤ ∑ i ∈ I, M ^ 2 * finiteL2Sq t (ν i) (fun w => b (i,w)) := by
        apply Finset.sum_le_sum
        intro i hi
        exact finiteKernelBound_sq s t (μ i) (ν i) (K i) M
          (hμ i hi) (hν i hi) (hK i hi) _
      _ = _ := by simp [finiteL2Sq, Finset.sum_product, Finset.mul_sum]
  unfold finiteL2
  calc
    _ ≤ Real.sqrt (M ^ 2 * finiteL2Sq (I ×ˢ t) (fun q => ν q.1 q.2) b) :=
      Real.sqrt_le_sqrt hsq
    _ = _ := by rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq hM]

end Elliptic.Operator
