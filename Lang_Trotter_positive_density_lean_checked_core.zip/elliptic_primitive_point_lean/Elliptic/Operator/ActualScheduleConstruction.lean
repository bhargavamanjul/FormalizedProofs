module

public import Elliptic.Operator.ActualHistoryPending
public import Elliptic.Operator.ActualHistoryEvents
public import Elliptic.Operator.ActualHistoryRetained
public import Elliptic.Operator.CanonicalHistoryKey

/-!
# Constructing the full schedule from a literal history

Every field is read from actual visits, actual choices, and the extracted
lifespans. The off-horizon values are harmless fixed extensions. Coherent
retained lines are proved from the source geometry in the final wrapper.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath ActualHistoryPending ActualHistoryObservation
open ActualHistoryRetained LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance actualScheduleConstructionDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace ActualScheduleConstruction
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Extend literal visit data by its last observed state. -/
def visitState (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (j : ℕ) : PhysicalMemoryState (Z:=Z) P Line J B :=
  beforeStateAt ν V η q ρ geometry N 0 s h ⟨min j N,by omega⟩

theorem visitState_eq (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (k : Fin (N+1)) :
    visitState ν V η q ρ anchor geometry N s h k.val =
      beforeStateAt ν V η q ρ geometry N 0 s h k := by
  unfold visitState
  congr 1
  apply Fin.ext
  exact Nat.min_eq_left (by omega)

/-- Extend actual edge data by a fixed harmless record after the horizon. -/
def edgeRecord (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (j : ℕ) : EdgeRecord I Z P J :=
  if hj : j < N then edgeAt ν V η q ρ anchor geometry N 0 s h ⟨j,hj⟩
  else {
    target := s.position P Line J B
    sourcePerm := fun _ => Equiv.refl _
    targetPerm := fun _ => Equiv.refl _
    store := fun _ => false
    promote := fun _ => false
    targetPrime := fun i => s.active P Line J B i 0 }

theorem edgeRecord_eq (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (k : Fin N) :
    edgeRecord ν V η q ρ anchor geometry N s h k.val =
      edgeAt ν V η q ρ anchor geometry N 0 s h k := by
  simp only [edgeRecord,dite_eq_left k.isLt]

/-- Literal active observations agree with the used lifespan data at
every in-horizon natural-number visit. -/
theorem active_lifespan (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (j : ℕ) (hj : j ≤ N) (i : I) (p : P i) :
    (p ∈ observedPrimes ν V η q ρ geometry s h i ∧
      j ∈ (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i p).active) ↔
      ∃ a, (visitState ν V η q ρ anchor geometry N s h j).active P Line J B i a = p := by
  let k : Fin (N+1) := ⟨j,by omega⟩
  change _ ↔ ∃ a, (visitState ν V η q ρ anchor geometry N s h k.val).active P Line J B i a = p
  rw [visitState_eq]
  exact extracted_active_iff ν V η q ρ anchor geometry N s h hinitial hfinal k i p

/-- The actual edge recurrence survives the harmless natural-number
extension used by `ScheduledPhysicalPath`. -/
theorem active_next (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (j : ℕ) (hj : j < N) (i : I) (a : Fin (J+1)) :
    (visitState ν V η q ρ anchor geometry N s h (j+1)).active P Line J B i a =
      Fin.lastCases ((edgeRecord ν V η q ρ anchor geometry N s h j).targetPrime i)
        (fun t : Fin J => (visitState ν V η q ρ anchor geometry N s h j).active P Line J B i
          ((edgeRecord ν V η q ρ anchor geometry N s h j).sourcePerm i t.castSucc))
        ((edgeRecord ν V η q ρ anchor geometry N s h j).targetPerm i a) := by
  let k : Fin N := ⟨j,hj⟩
  have hleft := visitState_eq ν V η q ρ anchor geometry N s h k.succ
  have hright := visitState_eq ν V η q ρ anchor geometry N s h k.castSucc
  have hedge := edgeRecord_eq ν V η q ρ anchor geometry N s h k
  simp only [Fin.val_succ,Fin.val_castSucc,k] at hleft hright hedge
  rw [hleft,hright,hedge]
  exact next_active ν V η q ρ anchor geometry N 0 s h k i a

/-- Coherent retained lines and exact pending support recover the full
ordered-memory enumeration, including the retained particle data. -/
theorem before_enumerates (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) (i : I) :
    MemoryEnumeratesSet
      (before (observedPrimes ν V η q ρ geometry s h i)
        (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val)
      (retained i) ((beforeStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) := by
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  refine ⟨((allLive_at ν V η q ρ anchor geometry N 0 s h hall k).1 i).2.1,?_,?_⟩
  · intro p
    rw [extracted_before_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
    simp
  · intro a
    exact (allLines_observed anchor ν V η q ρ geometry N 0 s h i _ _ (hl i _) k).1.2 a rfl

/-- The post-ghost memory has the same exact retained-line enumeration. -/
theorem after_enumerates (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) (i : I) :
    MemoryEnumeratesSet
      (after (observedPrimes ν V η q ρ geometry s h i)
        (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val)
      (retained i) ((afterStateAt ν V η q ρ geometry N 0 s h k).memory P Line J B i) := by
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
  refine ⟨((allLive_at ν V η q ρ anchor geometry N 0 s h hall k).2 i).2.1,?_,?_⟩
  · intro p
    rw [extracted_after_eq_pending ν V η q ρ anchor geometry value N s h hd hinitial hfinal k i]
    simp
  · intro a
    exact (allLines_observed anchor ν V η q ρ geometry N 0 s h i _ _ (hl i _) k).2.2 a rfl

/-- The literal ghost deletion and its validity supply the extracted
death-line condition. -/
theorem death_line (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) (i : I) (p : P i)
    (hp : p ∈ deaths (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val) :
    retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.val).position i p := by
  rw [visitState_eq]
  apply ghostAt_death_line anchor ν V η q ρ geometry N 0 s h i p (retained i p) (hl i p) k
  rw [ActualHistoryEvents.ghostAt_deleted_eq_extracted_deaths value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i]
  exact hp

/-- A literal fresh ghost particle is anchored at its actual birth visit. -/
theorem birth_line (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) (i : I) (p : P i)
    (hp : p ∈ births (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val) :
    retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.val).position i p := by
  rw [visitState_eq]
  apply ghostAt_birth_line anchor ν V η q ρ geometry N 0 s h i p (retained i p) (hl i p) k
  rw [ActualHistoryEvents.ghostAt_fresh_eq_extracted_births value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i]
  exact hp

/-- A store comes from the actual active tuple at its source visit. -/
theorem store_line (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin N) (i : I) (p : P i)
    (hp : p ∈ stores (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val) :
    retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.val).position i p := by
  obtain ⟨hp,hs⟩ := Finset.mem_filter.mp hp
  obtain ⟨a,ha⟩ := (extracted_active_iff ν V η q ρ anchor geometry N s h hinitial hfinal k.castSucc i p).mp ⟨hp,hs.1⟩
  have hh := (allLines_observed anchor ν V η q ρ geometry N 0 s h i p (retained i p) (hl i p) k.castSucc).1.1 a ha
  change retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.castSucc.val).position i p
  rw [visitState_eq]
  exact hh.symm

/-- A promotion is active at the literal target visit, with its same line. -/
theorem promote_line (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin N) (i : I) (p : P i)
    (hp : p ∈ promotions (observedPrimes ν V η q ρ geometry s h i)
      (extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal i) k.val) :
    retained i p = anchor (visitState ν V η q ρ anchor geometry N s h (k.val+1)).position i p := by
  obtain ⟨hp,hs⟩ := Finset.mem_filter.mp hp
  obtain ⟨a,ha⟩ := (extracted_active_iff ν V η q ρ anchor geometry N s h hinitial hfinal k.succ i p).mp ⟨hp,hs.1⟩
  have hh := (allLines_observed anchor ν V η q ρ geometry N 0 s h i p (retained i p) (hl i p) k.succ).1.1 a ha
  change retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.succ.val).position i p
  rw [visitState_eq]
  exact hh.symm

/-- The full raw schedule extracted from actual history data. All set,
recurrence, incidence and cutoff fields are proved from that data. -/
def constructed (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    ScheduledPhysicalPath anchor N J B where
  primes := observedPrimes ν V η q ρ geometry s h
  lifespan := extractedLifespan ν V η q ρ anchor geometry N s h hinitial hfinal
  retained := retained
  position j := (visitState ν V η q ρ anchor geometry N s h j).position P Line J B
  active j := (visitState ν V η q ρ anchor geometry N s h j).active P Line J B
  active_distinct j hj i := by
    let k : Fin (N+1) := ⟨j,by omega⟩
    change Function.Injective ((visitState ν V η q ρ anchor geometry N s h k.val).active P Line J B i)
    rw [visitState_eq]
    have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hinitial
    exact ((allLive_at ν V η q ρ anchor geometry N 0 s h hall k).1 i).1
  active_lifespan := active_lifespan ν V η q ρ anchor geometry N s h hinitial hfinal
  sourcePerm j := (edgeRecord ν V η q ρ anchor geometry N s h j).sourcePerm
  targetPerm j := (edgeRecord ν V η q ρ anchor geometry N s h j).targetPerm
  store j := (edgeRecord ν V η q ρ anchor geometry N s h j).store
  promote j := (edgeRecord ν V η q ρ anchor geometry N s h j).promote
  targetPrime j := (edgeRecord ν V η q ρ anchor geometry N s h j).targetPrime
  active_next := active_next ν V η q ρ anchor geometry N s h
  store_set j hj i := by
    let k : Fin N := ⟨j,hj⟩
    have hv := visitState_eq ν V η q ρ anchor geometry N s h k.castSucc
    have he := edgeRecord_eq ν V η q ρ anchor geometry N s h k
    change _ = optionalPrimeSet ((edgeRecord ν V η q ρ anchor geometry N s h k.val).store i)
      ((visitState ν V η q ρ anchor geometry N s h k.castSucc.val).active P Line J B i
        ((edgeRecord ν V η q ρ anchor geometry N s h k.val).sourcePerm i (Fin.last J)))
    rw [hv,he]
    exact ActualHistoryEvents.extracted_stores_eq_actual value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i
  promote_set j hj i := by
    let k : Fin N := ⟨j,hj⟩
    change _ = optionalPrimeSet ((edgeRecord ν V η q ρ anchor geometry N s h k.val).promote i)
      ((edgeRecord ν V η q ρ anchor geometry N s h k.val).targetPrime i)
    rw [edgeRecord_eq]
    exact ActualHistoryEvents.extracted_promotions_eq_actual value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i
  death_line j hj i p hp := death_line ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl ⟨j,by omega⟩ i p hp
  birth_line j hj i p hp := birth_line ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl ⟨j,by omega⟩ i p hp
  store_line j hj i p hp := store_line ν V η q ρ anchor geometry N s h hinitial hfinal retained hl ⟨j,hj⟩ i p hp
  promote_line j hj i p hp := promote_line ν V η q ρ anchor geometry N s h hinitial hfinal retained hl ⟨j,hj⟩ i p hp
  before_cutoff j hj := extracted_before_cutoff ν V η q ρ anchor geometry value N s h hd hinitial hfinal ⟨j,by omega⟩
  after_cutoff j hj := extracted_after_cutoff ν V η q ρ anchor geometry value N s h hd hinitial hfinal ⟨j,by omega⟩

/-- Every literal before state realizes the extracted schedule. -/
theorem constructed_before_at (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).Before k.val
      (beforeStateAt ν V η q ρ geometry N 0 s h k) := by
  have hv := visitState_eq ν V η q ρ anchor geometry N s h k
  refine ⟨?_,?_,fun i => before_enumerates ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl k i⟩
  · exact (congrArg (PhysicalMemoryState.position P Line J B) hv).symm
  · exact (congrArg (PhysicalMemoryState.active P Line J B) hv).symm

/-- Every literal post-ghost state realizes the extracted schedule. -/
theorem constructed_after_at (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h)
    (k : Fin (N+1)) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).After k.val
      (afterStateAt ν V η q ρ geometry N 0 s h k) := by
  have hv := visitState_eq ν V η q ρ anchor geometry N s h k
  refine ⟨?_,?_,fun i => after_enumerates ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl k i⟩
  · exact (before_after_position ν V η q ρ anchor geometry N 0 s h k).trans
      (congrArg (PhysicalMemoryState.position P Line J B) hv).symm
  · exact (before_after_active ν V η q ρ anchor geometry N 0 s h k).trans
      (congrArg (PhysicalMemoryState.active P Line J B) hv).symm

theorem constructed_before_initial (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).Before 0 s := by
  simpa only [Fin.val_zero,ActualHistoryLifespans.beforeStateAt_zero] using
    constructed_before_at ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl 0

/-- The full recursively defined compatibility relation follows from
the extracted actual ghost and edge records. -/
theorem constructed_compatible (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).Compatible
      ν V η q ρ geometry N 0 s h := by
  apply compatible_of_records ν V η q ρ anchor geometry _ N 0 s h
  · intro k
    simp only [Nat.zero_add]
    exact ⟨fun i => ActualHistoryEvents.ghostAt_deleted_eq_extracted_deaths value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i,
      fun i => ActualHistoryEvents.ghostAt_fresh_eq_extracted_births value ν V η q ρ anchor geometry N s h hd hinitial hfinal k i⟩
  · intro k
    simp only [Nat.zero_add]
    change (edgeAt ν V η q ρ anchor geometry N 0 s h k).target =
        (visitState ν V η q ρ anchor geometry N s h (k.val+1)).position P Line J B ∧
      (edgeAt ν V η q ρ anchor geometry N 0 s h k).sourcePerm =
        (edgeRecord ν V η q ρ anchor geometry N s h k.val).sourcePerm ∧
      (edgeAt ν V η q ρ anchor geometry N 0 s h k).targetPerm =
        (edgeRecord ν V η q ρ anchor geometry N s h k.val).targetPerm ∧
      (edgeAt ν V η q ρ anchor geometry N 0 s h k).store =
        (edgeRecord ν V η q ρ anchor geometry N s h k.val).store ∧
      (edgeAt ν V η q ρ anchor geometry N 0 s h k).promote =
        (edgeRecord ν V η q ρ anchor geometry N s h k.val).promote ∧
      (edgeAt ν V η q ρ anchor geometry N 0 s h k).targetPrime =
        (edgeRecord ν V η q ρ anchor geometry N s h k.val).targetPrime
    rw [edgeRecord_eq]
    refine ⟨?_,rfl,rfl,rfl,rfl,rfl⟩
    change _ = (visitState ν V η q ρ anchor geometry N s h k.succ.val).position P Line J B
    rw [visitState_eq]
    exact (next_position ν V η q ρ anchor geometry N 0 s h k).symm

omit [Fintype I] [Fintype Z] [∀ i, Fintype (P i)] in
/-- An ordered memory of size zero has its unique empty representative. -/
theorem empty_eq_of_size_zero {X : Type*} (m : MemoryState X B) (hm : m.size = 0) :
    MemoryState.empty X B = m := by
  rcases m with ⟨⟨n,hn⟩,v⟩
  change n = 0 at hm
  subst n
  have hv : v = Fin.elim0 := by funext a; exact Fin.elim0 a
  subst v
  rfl

/-- The constructed canonical empty initial state is the original state;
there is no additional initial-state multiplicity. -/
theorem constructed_initialState_eq (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).initialState = s := by
  have hs := constructed_before_initial ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl
  apply Subtype.ext
  refine Prod.ext ?_ ?_
  · exact hs.1.symm
  · refine Prod.ext ?_ ?_
    · exact hs.2.1.symm
    · funext i
      exact empty_eq_of_size_zero (s.memory P Line J B i) (hinitial i)

/-- The independent finite observable key is exactly the constructed
schedule's key; unused and off-horizon choices have been removed. -/
theorem constructed_canonicalKey_eq (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h =
      (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).canonicalKey := by
  exact canonicalKey_of_compatible ν V η q ρ anchor geometry _ s
    (constructed_before_initial ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl) h
    (constructed_compatible ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl)

/-- Coherent actual active occurrences also give the active-birth
normalization, including primes which never enter pending memory. -/
theorem constructed_activeBirthAnchored (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (retained : ∀ i p, Line i p)
    (hl : ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h) :
    (constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl).ActiveBirthAnchored := by
  intro j hj i p hp
  obtain ⟨hp,hb,ha⟩ := Finset.mem_filter.mp hp
  let k : Fin (N+1) := ⟨j,by omega⟩
  obtain ⟨a,hap⟩ := (extracted_active_iff ν V η q ρ anchor geometry N s h hinitial hfinal k i p).mp ⟨hp,ha⟩
  have hh := (allLines_observed anchor ν V η q ρ geometry N 0 s h i p (retained i p) (hl i p) k).1.1 a hap
  change retained i p = anchor (visitState ν V η q ρ anchor geometry N s h k.val).position i p
  rw [visitState_eq]
  exact hh.symm

/-- Global schedule existence follows from the actual shared-line
transport, distinct numerical births, and empty pending boundaries. -/
theorem exists_schedule_of_sharedTransport (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0)
    (ht : SharedTransport anchor ν V η q ρ geometry N 0 s h) :
    ∃ d : ScheduledPhysicalPath anchor N J B,
      d.Before 0 s ∧ d.Compatible ν V η q ρ geometry N 0 s h ∧
      d.initialState = s ∧ ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ∧
      d.ActiveBirthAnchored := by
  obtain ⟨retained,hl⟩ := exists_retained_of_birthsDistinct anchor ν V η q ρ geometry value N s h hd hinitial ht
  exact ⟨constructed ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl,
    constructed_before_initial ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl,
    constructed_compatible ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl,
    constructed_initialState_eq ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl,
    constructed_canonicalKey_eq ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl,
    constructed_activeBirthAnchored ν V η q ρ anchor geometry value N s h hd hinitial hfinal retained hl⟩

/-- A nonzero literal weight supplies shared transport whenever it is a
proved support property of the chosen geometry. -/
theorem exists_schedule_of_weight_ne_zero (value : ∀ i, P i → ℕ) (N : ℕ)
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hinitial : ∀ i, (s.memory P Line J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P Line J B i).size = 0) (hw : h.weight ≠ 0) :
    ∃ d : ScheduledPhysicalPath anchor N J B,
      d.Before 0 s ∧ d.Compatible ν V η q ρ geometry N 0 s h ∧
      d.initialState = s ∧ ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ∧
      d.ActiveBirthAnchored := by
  exact exists_schedule_of_sharedTransport ν V η q ρ anchor geometry value N s h hd hinitial hfinal
    (sharedTransport_of_weight_ne_zero anchor ν V η q ρ geometry hgeometry N 0 s h hw)

end ActualScheduleConstruction

namespace ActualScheduleConstruction
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)] {J B : ℕ}

/-- Full schedule extraction for the actual signed source geometry. The
support property required for coherent retained lines is proved from its
pad condition and primality, for either orientation and any integer shift.
No schedule, pending trace, retained-line incidence, or compatibility is
assumed. -/
theorem exists_schedule_of_source_geometry
    (value : ∀ i, P i → ℕ) (hprime : ∀ i p, (value i p).Prime)
    (position : Z → ℤ × ℤ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ) (major : Set ProductCircle)
    (σ : ℤ) (adjoint : ℕ → Bool)
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ
      (fun z i p => primeResidueAnchor (value i p) (position z))
      (fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
        u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b) N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ
      (fun z i p => primeResidueAnchor (value i p) (position z))
      (fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
        u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b) value N s h))
    (hinitial : ∀ i, (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size = 0)
    (hfinal : ∀ i, (h.final.memory P (fun i p => Option (ZMod (value i p))) J B i).size = 0)
    (hw : h.weight ≠ 0) :
    let anchor := fun z i p => primeResidueAnchor (value i p) (position z)
    let geometry := fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
      u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b
    ∃ d : ScheduledPhysicalPath anchor N J B,
      d.Before 0 s ∧ d.Compatible ν V η q ρ geometry N 0 s h ∧
      d.initialState = s ∧ ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry s h = d.canonicalKey ∧
      d.ActiveBirthAnchored := by
  apply exists_schedule_of_weight_ne_zero ν V η q ρ _ _ value N ?_ s h hd hinitial hfinal hw
  intro j z a w b hn i k
  let : Fact (value i (a i k.castSucc)).Prime := ⟨hprime i _⟩
  exact orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint j) value good
    u v r U W d₀ Y smooth ψ major σ (position z) (position w) a b hn i k

end ActualScheduleConstruction
end Elliptic.Operator
