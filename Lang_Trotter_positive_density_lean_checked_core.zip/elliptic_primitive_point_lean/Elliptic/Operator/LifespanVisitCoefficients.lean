module

public import Elliptic.Operator.ActiveRunNormalization

/-!
# Exact cancellation of the pending-hit damping along a lifespan

These are literal per-prime ghost and endpoint-edge factors. Their product
is computed without assuming a global word/lifespan correspondence.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

theorem product_edge_visit_regroup {R : Type*} [CommMonoid R]
    (N : ℕ) (before after ghost : ℕ → R)
    (hfirst : before 0 = 1) (hlast : after N = 1) :
    (∏ j ∈ Finset.range N, after j * before (j+1)) *
      (∏ j ∈ Finset.range (N+1), ghost j) =
    ∏ j ∈ Finset.range (N+1), before j * ghost j * after j := by
  simp only [Finset.prod_mul_distrib]
  have hb : (∏ j ∈ Finset.range (N+1), before j) =
      ∏ j ∈ Finset.range N, before (j+1) := by
    rw [Finset.prod_range_succ', hfirst, mul_one]
  have ha : (∏ j ∈ Finset.range (N+1), after j) =
      ∏ j ∈ Finset.range N, after j := by
    rw [Finset.prod_range_succ, hlast, mul_one]
  rw [hb,ha]
  ac_rfl

namespace PrimeLifespan
variable {N : ℕ} (L : PrimeLifespan N)

def incomingFactor {R : Type*} [One R] (ρ : R) (hit : ℕ → Prop) (j : ℕ) : R :=
  if L.beforeGhost j ∧ hit j then ρ else 1

def outgoingFactor {R : Type*} [One R] (ρ : R) (hit : ℕ → Prop) (j : ℕ) : R :=
  if L.afterGhost j ∧ hit j then ρ else 1

/-- Deletion, survival and birth factors of this one prime. Fresh-batch
factorials and the prime measure are accounted for in separate modules. -/
def ghostVisitFactor {R : Type*} [Field R] (ρ V : R)
    (η q : ℕ → R) (hit : ℕ → Prop) (j : ℕ) : R :=
  (if L.ghostDies j then -η j / ρ else 1) *
  (if L.beforeGhost j ∧ ¬ L.ghostDies j ∧ hit j then q j / ρ^2 else 1) *
  (if L.ghostBorn j then -η j * V / ρ else 1)

/-- The surviving factor after the two neighboring edge dampings cancel. -/
def lifespanVisitFactor {R : Type*} [Field R] (V : R)
    (η q : ℕ → R) (hit : ℕ → Prop) (j : ℕ) : R :=
  (if L.ghostDies j then -η j else 1) *
  (if L.birth < j ∧ j < L.death ∧ j ∉ L.active ∧ hit j then q j else 1) *
  (if L.ghostBorn j then -η j * V else 1)

/-- Pending states determine the neighboring rho factors. Endpoint hits
are the literal retained-line compatibility condition. -/
theorem visit_factors_cancel {R : Type*} [Field R] (ρ V : R) (hρ : ρ ≠ 0)
    (η q : ℕ → R) (hit : ℕ → Prop) (j : ℕ)
    (hend : L.ghostBorn j ∨ L.ghostDies j → hit j) :
    L.incomingFactor ρ hit j * L.ghostVisitFactor ρ V η q hit j *
      L.outgoingFactor ρ hit j = L.lifespanVisitFactor V η q hit j := by
  have hle := L.birth_le_death
  have hs := L.singleton_active
  unfold incomingFactor outgoingFactor ghostVisitFactor lifespanVisitFactor
    beforeGhost afterGhost ghostDies ghostBorn at *
  by_cases ha : j ∈ L.active
  · simp [ha]
  · by_cases hb : j = L.birth
    · subst j
      have hbd : L.birth < L.death := by
        by_contra h
        exact ha (hs (by omega))
      have ht : hit L.birth := hend (Or.inl ⟨rfl,ha⟩)
      simp [ha,ht,hbd,hbd.ne,hbd.le]
      field_simp
    · by_cases hd : j = L.death
      · subst j
        have hbd : L.birth < L.death := by omega
        have ht : hit L.death := hend (Or.inr ⟨rfl,ha⟩)
        simp [ha,hb,ht,hbd,hbd.le]
        field_simp
      · by_cases hm : L.birth < j ∧ j < L.death
        · have hbj : L.birth ≤ j := hm.1.le
          have hjd : j ≤ L.death := hm.2.le
          simp only [ha,hb,hd,hm.1,hm.2,hbj,hjd,not_false_eq_true,
            false_and,true_and,ite_false,one_mul,mul_one]
          by_cases ht : hit j
          · simp only [ht,ite_true]
            field_simp
          · simp [ht]
        · have he : ¬ (L.birth < j ∧ j ≤ L.death) := by omega
          have hf : ¬ (L.birth ≤ j ∧ j < L.death) := by omega
          simp [ha,hb,hd,he,hf,← and_assoc,hm]

/-- The boundary equalities are derived from the lifespan axioms. -/
theorem lifespan_factors_cancel {R : Type*} [Field R] (ρ V : R) (hρ : ρ ≠ 0)
    (η q : ℕ → R) (hit : ℕ → Prop)
    (hend : ∀ j ≤ N, L.ghostBorn j ∨ L.ghostDies j → hit j) :
    (∏ j ∈ Finset.range N,
      L.outgoingFactor ρ hit j * L.incomingFactor ρ hit (j+1)) *
    (∏ j ∈ Finset.range (N+1), L.ghostVisitFactor ρ V η q hit j) =
    ∏ j ∈ Finset.range (N+1), L.lifespanVisitFactor V η q hit j := by
  rw [product_edge_visit_regroup N]
  · apply Finset.prod_congr rfl
    intro j hj
    exact L.visit_factors_cancel ρ V hρ η q hit j
      (hend j (Nat.le_of_lt_succ (Finset.mem_range.mp hj)))
  · simp [incomingFactor, L.beforeGhost_zero]
  · simp [outgoingFactor, L.afterGhost_final]

/-- The ghost-birth factor V occurs once precisely when the birth is inactive. -/
theorem ghostBirth_normalization_product {R : Type*} [CommMonoid R] (V : R) :
    (∏ j ∈ Finset.range (N+1), if L.ghostBorn j then V else 1) =
      if L.birth ∈ L.active then 1 else V := by
  have hb : L.birth ∈ Finset.range (N+1) :=
    Finset.mem_range.mpr (by have := L.birth_le_death; have := L.death_le; omega)
  by_cases ha : L.birth ∈ L.active
  · have he : ∀ j, ¬ L.ghostBorn j := by
      rintro j ⟨h,hj⟩
      exact hj (h ▸ ha)
    simp [he,ha]
  · have he : ∀ j, L.ghostBorn j ↔ j = L.birth := by
      intro j
      exact ⟨And.left, fun h => ⟨h, h ▸ ha⟩⟩
    simp_rw [he]
    simp [hb,ha]

theorem lifespanVisitFactor_split {R : Type*} [Field R] (V : R)
    (η q : ℕ → R) (hit : ℕ → Prop) (j : ℕ) :
    L.lifespanVisitFactor V η q hit j =
      L.lifespanVisitFactor 1 η q hit j * (if L.ghostBorn j then V else 1) := by
  unfold lifespanVisitFactor
  by_cases hb : L.ghostBorn j
  · simp only [hb,ite_true,mul_one]
    ring
  · simp only [hb,ite_false,mul_one]

/-- Exact per-prime weight over the entire lifespan: one line-mass factor,
one inverse V per active run, the endpoint signs, and the internal hit
factors. The remaining global task is to identify these factors with all
actual grouped/permuted histories and their multiplicities. -/
theorem full_lifespan_coefficient {R : Type*} [Field R]
    (ρ V ν μ : R) (hρ : ρ ≠ 0) (hV : V ≠ 0) (hν : V * ν = μ)
    (η q : ℕ → R) (hit : ℕ → Prop)
    (hend : ∀ j ≤ N, L.ghostBorn j ∨ L.ghostDies j → hit j) :
    ν * (V⁻¹)^L.promotionCount *
      ((∏ j ∈ Finset.range N,
        L.outgoingFactor ρ hit j * L.incomingFactor ρ hit (j+1)) *
       (∏ j ∈ Finset.range (N+1), L.ghostVisitFactor ρ V η q hit j)) =
    μ * (V⁻¹)^L.activeRunCount *
      (∏ j ∈ Finset.range (N+1), L.lifespanVisitFactor 1 η q hit j) := by
  rw [L.lifespan_factors_cancel ρ V hρ η q hit hend]
  simp_rw [L.lifespanVisitFactor_split V η q hit]
  rw [Finset.prod_mul_distrib,L.ghostBirth_normalization_product]
  have hn := L.birth_promotion_normalization V ν μ hV hν
  by_cases ha : L.birth ∈ L.active
  · simp only [ha,ite_true,mul_one] at *
    rw [hn]
  · simp only [ha,ite_false] at *
    rw [← hn]
    ring

end PrimeLifespan
end Elliptic.Operator
