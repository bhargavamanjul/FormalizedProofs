module
public import Elliptic.Operator.SignedPhysicalPairDamping

/-! Position-only complete-support endpoint vectors from source (3.16).
Their coefficient support and norm bounds are literal and independent
of the number of groups and auxiliary slots. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators ComplexConjugate
attribute [local instance] Classical.propDecidable
local instance endpointsDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

variable {K J : ℕ}

def groupPool (groups : Fin K→Finset ℕ) : Finset ℕ := Finset.univ.biUnion groups

/-- Each group supplies exactly the required number of distinct prime
divisors of the physical first coordinate. Roughness of the remaining
coefficient index then excludes repeated powers. -/
def completeCounts (groups : Fin K→Finset ℕ) (J n : ℕ) : Prop :=
  ∀i,((groups i).filter (fun p=>p∣n)).card=J+1

def completeLeft (groups : Fin K→Finset ℕ) (J : ℕ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (z : ℤ×ℤ) : ℂ :=
  if completeCounts groups J z.1.toNat ∧
      z.1.toNat/supportedPart (groupPool groups) z.1.toNat∈s ∧ z.2.toNat∈t then
    leftEndpoint (groupPool groups) α β z else 0

def completeRight (groups : Fin K→Finset ℕ) (J : ℕ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (z : ℤ×ℤ) : ℂ :=
  if completeCounts groups J z.1.toNat ∧
      z.1.toNat/supportedPart (groupPool groups) z.1.toNat∈s ∧ z.2.toNat∈t then
    rightEndpoint (groupPool groups) α β z else 0

theorem groupPool_prime (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime) :
    ∀p∈groupPool groups,p.Prime := by
  intro p h
  obtain ⟨i,_,hi⟩ := Finset.mem_biUnion.mp h
  exact hp i p hi

theorem groupPool_mem (groups : Fin K→Finset ℕ) (i : Fin K) (p : groups i) :
    p.val∈groupPool groups := Finset.mem_biUnion.mpr ⟨i,Finset.mem_univ i,p.property⟩

theorem group_filter_eq_active (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (a : PhysicalActiveLists (fun i=>groups i) J) (m : ℕ)
    (hm : ∀p∈groupPool groups,¬p∣m) (i : Fin K) :
    (groups i).filter (fun p=>p∣activeProduct (fun _ p=>p.val) a*m)=
      Finset.univ.image (fun j : Fin (J+1)=>(a i j).val) := by
  ext p
  simp only [Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨hpi,hd⟩
    have hmem : p∈groupPool groups := Finset.mem_biUnion.mpr ⟨i,Finset.mem_univ i,hpi⟩
    obtain ⟨k,j,hkj⟩ := (active_mul_prime_dvd_iff (fun _ p=>p.val)
      (fun i p=>hp i p.val p.property) a m p (hp i p hpi) (hm p hmem)).mp hd
    have he : k=i := by
      by_contra hki
      apply Finset.disjoint_left.mp (hdis k i hki) (a k j).property
      simpa only [hkj] using hpi
    subst k
    exact ⟨j,hkj⟩
  · rintro ⟨j,rfl⟩
    exact ⟨(a i j).property,dvd_mul_of_dvd_left (label_dvd_activeProduct (fun _ p=>p.val) a i j) m⟩

theorem completeCounts_active_mul (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (m : ℕ) (hm : ∀p∈groupPool groups,¬p∣m) :
    completeCounts groups J (activeProduct (fun _ p=>p.val) a*m) := by
  intro i
  rw [group_filter_eq_active groups hp hdis a m hm i]
  rw [Finset.card_image_of_injective _ (fun j k h=>by
    have he : (i,j)=(i,k) := hinj h
    exact congrArg Prod.snd he)]
  simp

theorem complete_endpoint_position (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (m n : ℕ) (hm : ∀p∈groupPool groups,¬p∣m)
    (s t : Finset ℕ) (hms : m∈s) (hnt : n∈t) (α β : ℕ→ℂ) :
    let z := position (sourcePadProduct (fun _ p=>p.val) a) (sourceUnsharedProduct (fun _ p=>p.val) a) m n
    completeLeft groups J s t α β z=α m*conj (β n) ∧
      completeRight groups J s t α β z=conj (α m)*β n := by
  let value := fun i=>fun p : groups i=>p.val
  have hp' : ∀i p,(value i p).Prime := fun i p=>hp i p.val p.property
  have hh := supportedPart_active_mul value hp' (groupPool groups) (groupPool_prime groups hp)
    a hinj (fun i j=>groupPool_mem groups i (a i j)) m hm
  have hc : (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m n).1.toNat/
      supportedPart (groupPool groups)
        (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m n).1.toNat=m := by
    simp only [position,Int.toNat_natCast]
    rw [←activeProduct_eq,hh,Nat.mul_div_cancel_left _ (activeProduct_pos value (fun i p=>(hp' i p).pos) a)]
  have hcounts : completeCounts groups J
      (position (sourcePadProduct value a) (sourceUnsharedProduct value a) m n).1.toNat := by
    simp only [position,Int.toNat_natCast,←activeProduct_eq]
    exact completeCounts_active_mul groups hp hdis a hinj m hm
  dsimp only
  constructor
  · unfold completeLeft
    rw [if_pos ⟨hcounts,by rw [hc];exact hms,by simpa [position] using hnt⟩]
    exact leftEndpoint_position value hp' (groupPool groups) (groupPool_prime groups hp) a hinj
      (fun i j=>groupPool_mem groups i (a i j)) m n hm α β
  · unfold completeRight
    rw [if_pos ⟨hcounts,by rw [hc];exact hms,by simpa [position] using hnt⟩]
    exact rightEndpoint_position value hp' (groupPool groups) (groupPool_prime groups hp) a hinj
      (fun i j=>groupPool_mem groups i (a i j)) m n hm α β

theorem completeLeft_norm_le (groups : Fin K→Finset ℕ) (J : ℕ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hα : ∀n∈s,‖α n‖≤A) (hβ : ∀n∈t,‖β n‖≤B) (z : ℤ×ℤ) :
    ‖completeLeft groups J s t α β z‖≤A*B := by
  unfold completeLeft
  split_ifs with h
  · simp only [leftEndpoint,norm_mul,Complex.norm_conj]
    exact mul_le_mul (hα _ h.2.1) (hβ _ h.2.2) (norm_nonneg _) hA
  · simpa only [norm_zero] using mul_nonneg hA hB

theorem completeRight_norm_le (groups : Fin K→Finset ℕ) (J : ℕ) (s t : Finset ℕ)
    (α β : ℕ→ℂ) (A B : ℝ) (hA : 0≤A) (hB : 0≤B)
    (hα : ∀n∈s,‖α n‖≤A) (hβ : ∀n∈t,‖β n‖≤B) (z : ℤ×ℤ) :
    ‖completeRight groups J s t α β z‖≤A*B := by
  unfold completeRight
  split_ifs with h
  · simp only [rightEndpoint,norm_mul,Complex.norm_conj]
    exact mul_le_mul (hα _ h.2.1) (hβ _ h.2.2) (norm_nonneg _) hA
  · simpa only [norm_zero] using mul_nonneg hA hB

/-- On a complete position, any numerically distinct incident active
list exhausts every designated prime divisor of the first coordinate. -/
theorem supportedPart_eq_active_of_complete (groups : Fin K→Finset ℕ)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (n : ℕ) (hc : completeCounts groups J n) (hinc : ∀i j,(a i j).val∣n) :
    supportedPart (groupPool groups) n=activeProduct (fun _ p=>p.val) a := by
  have hfilter (i) : Finset.univ.image (fun j : Fin (J+1)=>(a i j).val)=
      (groups i).filter (fun p=>p∣n) := by
    apply Finset.eq_of_subset_of_card_le
    · intro p hp
      obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp hp
      exact Finset.mem_filter.mpr ⟨(a i j).property,hinc i j⟩
    · rw [hc i,Finset.card_image_of_injective _ (fun j k h=>by
        have he : (i,j)=(i,k) := hinj h
        exact congrArg Prod.snd he)]
      simp
  let labels := fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val
  have hs : (groupPool groups).filter (fun p=>p∣n)=Finset.univ.image labels := by
    ext p
    simp only [Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨hp,hd⟩
      obtain ⟨i,_,hi⟩ := Finset.mem_biUnion.mp hp
      have hm : p∈Finset.univ.image (fun j : Fin (J+1)=>(a i j).val) :=
        (hfilter i).symm ▸ Finset.mem_filter.mpr ⟨hi,hd⟩
      obtain ⟨j,_,hj⟩ := Finset.mem_image.mp hm
      exact ⟨(i,j),hj⟩
    · rintro ⟨ij,rfl⟩
      exact ⟨groupPool_mem groups ij.1 (a ij.1 ij.2),hinc ij.1 ij.2⟩
  unfold supportedPart
  rw [hs,Finset.prod_image (fun _ _ _ _ h=>hinj h),Fintype.prod_prod_type]
  rfl

theorem activeProduct_dvd_of_incidence (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (n : ℕ) (hinc : ∀i j,(a i j).val∣n) : activeProduct (fun _ p=>p.val) a∣n := by
  change (∏i,∏j,(a i j).val)∣n
  rw [←Fintype.prod_prod_type (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val)]
  apply Finset.prod_dvd_of_isRelPrime _ (fun ij _=>hinc ij.1 ij.2)
  intro ij _ kl _ hne
  apply Nat.coprime_iff_isRelPrime.mp
  apply (Nat.coprime_primes (hp ij.1 _ (a ij.1 ij.2).property) (hp kl.1 _ (a kl.1 kl.2).property)).mpr
  exact fun he=>hne (hinj he)

/-- Unique physical coordinate reconstruction from the actual complete
support, with no change to the coefficient index sets. -/
theorem endpoint_reconstruct (groups : Fin K→Finset ℕ)
    (hp : ∀i,∀p∈groups i,p.Prime)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (z : ℤ×ℤ) (hz₁ : 0≤z.1) (hz₂ : 0≤z.2)
    (hinc : ∀i j,((a i j).val:ℤ)∣z.1) (S T : Finset ℕ)
    (hc : completeCounts groups J z.1.toNat ∧
      z.1.toNat/supportedPart (groupPool groups) z.1.toNat∈S ∧ z.2.toNat∈T) :
    ∃m∈S,∃s∈T,z=position (sourcePadProduct (fun _ p=>p.val) a)
      (sourceUnsharedProduct (fun _ p=>p.val) a) m s := by
  have hn : ∀i j,(a i j).val∣z.1.toNat := by
    intro i j
    rw [←Int.natCast_dvd_natCast,Int.toNat_of_nonneg hz₁]
    exact hinc i j
  have he := supportedPart_eq_active_of_complete groups a hinj z.1.toNat hc.1 hn
  have hd := activeProduct_dvd_of_incidence groups hp a hinj z.1.toNat hn
  refine ⟨_,hc.2.1,_,hc.2.2,?_⟩
  apply Prod.ext
  · change z.1=((sourcePadProduct (fun _ p=>p.val) a*
      sourceUnsharedProduct (fun _ p=>p.val) a*(z.1.toNat/supportedPart (groupPool groups) z.1.toNat):ℕ):ℤ)
    rw [←activeProduct_eq,he,Nat.mul_div_cancel' hd,Int.toNat_of_nonneg hz₁]
  · simpa only [position,Int.toNat_of_nonneg hz₂]

end Elliptic.Operator.SignedPhysicalPairBridge
