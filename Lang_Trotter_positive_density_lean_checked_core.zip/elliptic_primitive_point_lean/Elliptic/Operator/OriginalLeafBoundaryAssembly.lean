module

public import Elliptic.Operator.OriginalLifespanKeyEquiv
public import Elliptic.Operator.ScheduledBirthDistinctness

/-!
# Global original-lifespan reindexing of the finite boundary pairing

Original leaves retain every path position, active list, endpoint
permutation and optional prime interval. The pending-memory bound is a
literal condition on these leaves. The maps to finite history keys are
injective, and every actual nonzero selected history yields such a leaf.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open LifespanSchedule ScheduledPhysicalPath CanonicalHistoryFiber
open CanonicalHistoryCoefficient CanonicalBoundaryAssembly SourceHistoryCoefficient
attribute [local instance] Classical.propDecidable
local instance leafAssemblyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace OriginalLeaf

/-- Source leaves include the literal numerical cross-edge ban. This is
already forced by nonzero source geometry, and retains the distinctness
needed to identify the entire birth-order fiber, including zero weights. -/
structure SourceValid
    (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))
    (anchor : Z → ∀ i p, Line i p) (value : ∀ i, P i → ℕ) (B : ℕ) : Prop where
  valid : e.Valid anchor B
  crossEdgeBan : ∀ j, j<N →
    sourceCrossEdgeBan value (e.sourceLists j) (e.targetLists j)

abbrev SourceLeaves (anchor : Z → ∀ i p, Line i p)
    (value : ∀ i, P i → ℕ) (J B N : ℕ) :=
  {e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) // e.SourceValid anchor value B}

variable (value : ∀ i, P i → ℕ)

def sourceKey (e : SourceLeaves anchor value J B N) : CanonicalHistoryKey I Z P J N :=
  e.val.key anchor e.property.valid

/-- Finite original coordinates do not acquire multiplicity from arbitrary
outside-horizon schedule data or from ghost birth orderings. -/
theorem sourceKey_injective : Function.Injective (sourceKey (anchor:=anchor) (B:=B) (N:=N) (J:=J) value) := by
  intro e f h
  apply Subtype.ext
  have hh := key_injective anchor (B:=B)
    (a₁:=⟨e.val,e.property.valid⟩) (a₂:=⟨f.val,f.property.valid⟩) h
  exact congrArg (fun x : {d : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) // d.Valid anchor B} => x.val) hh

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Every contributing actual key is represented by the original positions,
permutations and prime intervals read directly from its history. -/
theorem nonzeroKey_covered
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (u : BoundaryIndex I Z P J) (k : CanonicalHistoryKey I Z P J N)
    (hk : NonzeroKey ν V η q ρ anchor geometry value
      (emptyState (Line:=Line) (B:=B) u) k) :
    ∃ e : SourceLeaves anchor value J B N, sourceKey value e=k := by
  obtain ⟨h,hr,hkey,hw⟩ := hk
  obtain ⟨d,hs,hc,hi,hkd,hbirth⟩ := ActualScheduleConstruction.exists_schedule_of_weight_ne_zero
    ν V η q ρ anchor geometry value N hshared (emptyState (B:=B) u) h hr.1
      (fun i => emptyState_memory u i) hr.2 hw
  have hedge : ∀ j, j<N → geometry j (d.position j) (d.sourceLists j)
      (d.position (j+1)) (d.targetLists j) ≠ 0 := fun j hj =>
    compatible_nonzero_geometry ν V η q ρ anchor geometry d _ hs h hc hw ⟨j,hj⟩
  have hcross : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j) :=
    fun j hj => hban j _ _ _ _ (hedge j hj)
  have hnew := fun j hj => d.target_not_active_of_crossEdgeBan value j (hcross j hj)
  have hline := fun j hj => hshared j _ _ _ _ (hedge j hj)
  have hv := ofSchedule_valid d hbirth (d.retained_eq_anchor_of_active hbirth hnew hline)
  have hv' : (ofSchedule d).SourceValid anchor value B := ⟨hv,by
    intro j hj
    rw [ofSchedule_sourceLists d j hj,ofSchedule_targetLists d j hj]
    exact hcross j hj⟩
  refine ⟨⟨ofSchedule d,hv'⟩,?_⟩
  exact (ofSchedule_key d hv).trans (hkd.symm.trans hkey)

/-- Exact global finite reindexing, allowing arbitrary complex data on the
entire path key. The only support used is proved actual nonzero-key support. -/
theorem sum_keys_eq_sourceLeaves
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (u : BoundaryIndex I Z P J) (F : CanonicalHistoryKey I Z P J N → ℂ) :
    (∑ k : CanonicalHistoryKey I Z P J N,
      keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) k * F k) =
    ∑ e : SourceLeaves anchor value J B N,
      keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) (sourceKey value e) *
        F (sourceKey value e) := by
  symm
  apply Finset.sum_bij_ne_zero (fun e _ _ => sourceKey value e)
  · intros; exact Finset.mem_univ _
  · intro e _ _ f _ _ he
    exact sourceKey_injective value he
  · intro k _ hk
    have hn : NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) k := by
      by_contra hh
      simp [keyWeightSum_zero ν V η q ρ anchor geometry value (emptyState (B:=B) u) k hh] at hk
    obtain ⟨e,he⟩ := nonzeroKey_covered value ν V η q ρ geometry hshared hban u k hn
    exact ⟨e,Finset.mem_univ _,by simpa only [he] using hk,he⟩
  · intros; rfl

/-- A leaf determines its unique literal initial vacuum state. -/
theorem initialState_eq_empty (e : SourceLeaves anchor value J B N) :
    (e.val.toSchedule anchor e.property.valid).initialState =
      emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e)) := rfl

/-- The complete boundary pairing has now been reindexed by original finite
leaves. The sum is over every admissible leaf, not chosen schedule witnesses.
Both original endpoint vectors and the literal initial measure are retained. -/
theorem boundaryPairing_eq_originalLeaves
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (a b : BoundaryIndex I Z P J → ℂ) :
    boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b =
      ∑ e : SourceLeaves anchor value J B N,
        (PhysicalMemoryState.mass P Line J B ν
          (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) : ℂ) *
        conj (a (keyInitial (sourceKey value e))) *
        keyWeightSum ν V η q ρ anchor geometry value
          (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) (sourceKey value e) *
        b (keyFinal (sourceKey value e)) := by
  rw [boundaryPairing_eq_finite_key_sum ν V η q ρ anchor geometry value]
  calc
    _ = ∑ u : BoundaryIndex I Z P J, ∑ e : SourceLeaves anchor value J B N,
        (PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ) *
          conj (a u) * keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u)
            (sourceKey value e) * b (keyFinal (sourceKey value e)) := by
      apply Finset.sum_congr rfl
      intro u _
      calc
        _ = ∑ k : CanonicalHistoryKey I Z P J N,
            keyWeightSum ν V η q ρ anchor geometry value (emptyState (B:=B) u) k *
              ((PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ) *
                conj (a u) * b (keyFinal k)) := by
          apply Finset.sum_congr rfl
          intros; ring
        _ = _ := by
          rw [sum_keys_eq_sourceLeaves value ν V η q ρ geometry hshared hban]
          apply Finset.sum_congr rfl
          intros; ring
    _ = _ := ?_
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.sum_eq_single (keyInitial (sourceKey value e))]
  · intro u _ hu
    have hk : ¬NonzeroKey ν V η q ρ anchor geometry value (emptyState (B:=B) u) (sourceKey value e) := by
      intro hh
      exact hu (nonzeroKey_initial ν V η q ρ anchor geometry value u _ hh).symm
    rw [keyWeightSum_zero ν V η q ρ anchor geometry value (emptyState (B:=B) u) _ hk]
    simp
  · simp

/-- Every actual history in a source leaf's full observable fiber has
numerically distinct births. Thus its exact coefficient is valid even when
all weights vanish and no nonzero witness can be selected. -/
theorem sourceLeaf_complete_coefficient
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (μ : ∀ i, P i → ℝ) (hρ : ρ≠0) (hV : ∀ i, V i≠0)
    (hν : ∀ i p, V i*ν i p=μ i p)
    (e : SourceLeaves anchor value J B N) :
    (PhysicalMemoryState.mass P Line J B ν
      (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) : ℂ) *
      keyWeightSum ν V η q ρ anchor geometry value
        (emptyState (Line:=Line) (B:=B) (keyInitial (sourceKey value e))) (sourceKey value e) =
      primewiseCoefficient anchor geometry μ V η q (e.val.toSchedule anchor e.property.valid) := by
  let d := e.val.toSchedule anchor e.property.valid
  have hban : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j) := by
    intro j hj
    have hs := ofSchedule_sourceLists d j hj
    have ht := ofSchedule_targetLists d j hj
    rw [ofSchedule_toSchedule] at hs ht
    rw [← hs,← ht]
    exact e.property.crossEdgeBan j hj
  have hnew := fun j hj => d.target_not_active_of_crossEdgeBan value j (hban j hj)
  have he : ∀ h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) d.initialState,
      (Restricted ν V η q ρ anchor geometry value d.initialState h ∧
        ActualHistoryObservation.canonicalKey ν V η q ρ anchor geometry d.initialState h=d.canonicalKey) ↔
      d.Compatible ν V η q ρ geometry N 0 d.initialState h := by
    intro h
    constructor
    · rintro ⟨hr,hk⟩
      exact compatible_of_key_eq ν V η q ρ anchor geometry value d d.initialState h
        hr.1 (initial_empty anchor d) hr.2 hk
    · intro hc
      refine ⟨⟨ScheduledBirthDistinctness.birthsDistinct_of_compatible anchor d ν V η q ρ geometry
        value hvalue h hc hnew,compatible_final_empty ν V η q ρ anchor geometry d h hc⟩,?_⟩
      exact ActualHistoryObservation.canonicalKey_of_compatible ν V η q ρ anchor geometry
        d d.initialState d.initialState_before h hc
  rw [← initialState_eq_empty value e]
  change (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ) *
      keyWeightSum ν V η q ρ anchor geometry value d.initialState d.canonicalKey = _
  unfold keyWeightSum
  simp_rw [he]
  exact (congrArg (fun z : ℂ => (PhysicalMemoryState.mass P Line J B ν d.initialState : ℂ)*z)
    (sum_compatible_indicator ν V η q ρ anchor geometry d (fun h=>h.weight))).trans
      (d.compatibleHistory_complete_coefficient_of_crossEdgeBan ν V η q ρ geometry
        value μ hρ hV (fun i p _ => hν i p) hban)

/-- Global source boundary identity with explicit original-leaf primewise
weights, every normalization, and arbitrary complex endpoint vectors. -/
theorem boundaryPairing_eq_originalLeaf_coefficients
    (hvalue : Function.Injective (fun z : Sigma P => value z.1 z.2))
    (hshared : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b, geometry j z a w b ≠ 0 → sourceCrossEdgeBan value a b)
    (μ : ∀ i, P i → ℝ) (hρ : ρ≠0) (hV : ∀ i, V i≠0)
    (hν : ∀ i p, V i*ν i p=μ i p)
    (a b : BoundaryIndex I Z P J → ℂ) :
    boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b =
      ∑ e : SourceLeaves anchor value J B N,
        conj (a (keyInitial (sourceKey value e))) *
        primewiseCoefficient anchor geometry μ V η q (e.val.toSchedule anchor e.property.valid) *
        b (keyFinal (sourceKey value e)) := by
  rw [boundaryPairing_eq_originalLeaves value ν V η q ρ geometry hshared hban]
  apply Finset.sum_congr rfl
  intro e _
  have he := sourceLeaf_complete_coefficient value ν V η q ρ geometry hvalue μ hρ hV hν e
  rw [← he]
  ring

end OriginalLeaf
end Elliptic.Operator.OriginalLifespanSchedule
