module

public import Elliptic.Operator.DirtyRawRow
public import Elliptic.Operator.MemoryEdges
public import Mathlib.Algebra.BigOperators.Fin

/-!
# Indexed dirty-edge weights

The estimates here use the literal store/promotion choices of MemoryEdges.
In particular, removing one promoted OLD index leaves all other indexed
hits in the output. Their outgoing damping absorbs repeated particles;
no distinctness assumption is imposed on the memory tuple.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- Surviving old hits inject into the actual output hit set, whether or
not the appended store is also a hit. -/
theorem edgeGroupOutput_hits_ge {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor targetAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) :
    (memoryHits targetAnchor m \ edgePromotedIndices c).card ≤
      (memoryHits targetAnchor (edgeGroupOutput sourceAnchor sourcePrime m c hc)).card := by
  classical
  let S := edgePromotedIndices c
  let e := (Sᶜ.orderIsoOfFin rfl).symm
  let f : {i // i ∈ memoryHits targetAnchor m \ S} →
      {j // j ∈ memoryHits targetAnchor (edgeGroupOutput sourceAnchor sourcePrime m c hc)} :=
    fun i => ⟨(e ⟨i.val, Finset.mem_compl.mpr (Finset.mem_sdiff.mp i.property).2⟩).castAdd c.1.toNat,
      by
        have hi : particleHits targetAnchor (m.values i.val) := by
          simpa [memoryHits] using (Finset.mem_sdiff.mp i.property).1
        simp only [memoryHits, Finset.mem_filter, Finset.mem_univ, true_and]
        rw [edgeGroupOutput_old]
        have he : Sᶜ.orderEmbOfFin rfl
            (e ⟨i.val, Finset.mem_compl.mpr (Finset.mem_sdiff.mp i.property).2⟩) = i.val := by
          exact congrArg Subtype.val ((Sᶜ.orderIsoOfFin rfl).apply_symm_apply _)
        change particleHits targetAnchor (m.values (Sᶜ.orderEmbOfFin rfl _))
        rw [he]
        exact hi⟩
  have hf : Function.Injective f := by
    intro i j h
    apply Subtype.ext
    have h' := congrArg (fun x => x.val.val) h
    have he : e ⟨i.val, Finset.mem_compl.mpr (Finset.mem_sdiff.mp i.property).2⟩ =
        e ⟨j.val, Finset.mem_compl.mpr (Finset.mem_sdiff.mp j.property).2⟩ := by
      exact Fin.ext h'
    exact congrArg (fun x : {j // j ∈ Sᶜ} => x.val) (e.injective he)
  simpa only [Fintype.card_coe, S] using Fintype.card_le_of_injective f hf

/-- Promoting a hit removes exactly one OLD hit before any new store. -/
theorem edgeGroupOutput_promotion_hits_ge {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor targetAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (store : Bool) (i : Fin m.size)
    (hi : particleHits targetAnchor (m.values i))
    (hc : edgeGroupOutputSize (store, Sum.inl i) ≤ B) :
    (memoryHits targetAnchor m).card - 1 ≤
      (memoryHits targetAnchor
        (edgeGroupOutput sourceAnchor sourcePrime m (store, Sum.inl i) hc)).card := by
  have h := edgeGroupOutput_hits_ge sourceAnchor targetAnchor sourcePrime m
    (store, Sum.inl i) hc
  have hmem : i ∈ memoryHits targetAnchor m := by simpa [memoryHits] using hi
  simpa [edgePromotedIndices, Finset.card_sdiff_of_subset (Finset.singleton_subset_iff.mpr hmem)] using h

/-- The exact Schur ratio for one promotion and an optional store. -/
theorem edgeGroupOutput_promotion_schurRatio {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (store : Bool) (i : Fin m.size)
    (hc : edgeGroupOutputSize (store, Sum.inl i) ≤ B)
    {v0 : ℝ} (hv0 : 0 < v0) :
    v0 ^ (edgeGroupOutput sourceAnchor sourcePrime m (store, Sum.inl i) hc).size /
      v0 ^ m.size = v0 ^ store.toNat / v0 := by
  rw [edgeGroupOutput_size, edgeGroupOutputSize_eq]
  simp only [edgePromotedIndices, Finset.card_singleton]
  have hn : m.size - 1 + 1 = m.size := by have := i.isLt; omega
  have he : v0 ^ m.size = v0 ^ (m.size - 1) * v0 := by
    conv_lhs => rw [← hn]
    rw [pow_add, pow_one]
  rw [pow_add, he]
  field_simp

/-- A literal valid edge choice, with the actual normalized Schur weight.
Invalid choices have zero weight rather than a hypothetical output. -/
def edgeWeightedChoice {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) : ℝ :=
  if hc : EdgeGroupChoice.Valid targetAnchor m c then
    edgeGroupWeight ν V ρ sourceAnchor targetAnchor sourcePrime m c hc.2 *
      (v0 ^ (edgeGroupOutput sourceAnchor sourcePrime m c hc.2).size / v0 ^ m.size)
  else 0

theorem edgeWeightedChoice_nonneg {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) (hν : ∀ p, 0 ≤ ν p)
    (hV : 0 ≤ V) (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0) :
    0 ≤ edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m c := by
  unfold edgeWeightedChoice
  split_ifs with hc
  · have ht : 0 ≤ edgeTargetWeight ν V c := by
      cases c with | mk s c => cases c <;> simp [edgeTargetWeight, hν, inv_nonneg.mpr hV]
    unfold edgeGroupWeight
    positivity
  · exact le_rfl

/-- Actual endpoint damping and store/Schur coefficients for a promoted
OLD index. This is a bound on the transition coefficient itself. -/
theorem edgeWeightedChoice_promotion_le {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (i : Fin m.size)
    (hV : 0 ≤ V) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inl i) ≤
      if i ∈ memoryHits targetAnchor m then
        (V⁻¹ * (v0 ^ store.toNat / v0)) * ρ ^ ((memoryHits targetAnchor m).card - 1)
      else 0 := by
  unfold edgeWeightedChoice
  split_ifs with hc hi hi
  · have hit : particleHits targetAnchor (m.values i) := hc.1
    have hs := edgeGroupOutput_promotion_hits_ge sourceAnchor targetAnchor sourcePrime m store i hit hc.2
    have hout := pow_le_pow_of_le_one hρ0 hρ1 hs
    have hsrc : ρ ^ (memoryHits sourceAnchor m).card ≤ 1 := pow_le_one₀ hρ0 hρ1
    rw [edgeGroupOutput_promotion_schurRatio sourceAnchor sourcePrime m store i hc.2 hv0]
    unfold edgeGroupWeight edgeTargetWeight
    calc
      _ ≤ (1 * V⁻¹ * ρ ^ ((memoryHits targetAnchor m).card - 1)) *
          (v0 ^ store.toNat / v0) := by
        gcongr
      _ = _ := by ring
  · have hit : particleHits targetAnchor (m.values i) := hc.1
    exact (hi (by simpa [memoryHits] using hit)).elim
  · positivity
  · exact le_rfl

/-- The sum over actual indexed promotions is uniformly bounded, even
with repeated particles. The cutoff and new-store hits can only lower it. -/
theorem edgeWeightedChoice_promotion_sum_le {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (hV : 0 ≤ V) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ i : Fin m.size,
      edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inl i)) ≤
      (V⁻¹ * (v0 ^ store.toNat / v0)) / (1 - ρ) := by
  calc
    _ ≤ ∑ i : Fin m.size, if i ∈ memoryHits targetAnchor m then
        (V⁻¹ * (v0 ^ store.toNat / v0)) * ρ ^ ((memoryHits targetAnchor m).card - 1)
        else 0 := Finset.sum_le_sum fun i _ =>
      edgeWeightedChoice_promotion_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store i
        hV hρ0 hρ1.le hv0
    _ = (V⁻¹ * (v0 ^ store.toNat / v0)) *
        ((memoryHits targetAnchor m).card * ρ ^ ((memoryHits targetAnchor m).card - 1)) := by
      simp [Finset.sum_ite_mem, mul_assoc, mul_left_comm]
    _ ≤ (V⁻¹ * (v0 ^ store.toNat / v0)) * (1 / (1 - ρ)) :=
      mul_le_mul_of_nonneg_left (pending_multiplicity_bound _ hρ0 hρ1) (by positivity)
    _ = _ := by ring

/-- Distinguished promotions may instead be summed crudely over at most
B indices; this bound leaves their individual geometric line tests intact. -/
theorem edgeWeightedChoice_promotion_le_coefficient {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (i : Fin m.size)
    (hV : 0 ≤ V) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inl i) ≤
      V⁻¹ * (v0 ^ store.toNat / v0) := by
  apply (edgeWeightedChoice_promotion_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store i
    hV hρ0 hρ1 hv0).trans
  split_ifs
  · exact mul_le_of_le_one_right (by positivity) (pow_le_one₀ hρ0 hρ1)
  · positivity

/-- Fresh target draws carry exactly their prime mass. Removing their two
nonnegative damping factors bounds the actual normalized Schur coefficient. -/
theorem edgeWeightedChoice_fresh_le {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (p : P)
    (hν : ∀ p, 0 ≤ ν p) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inr p) ≤
      ν p * v0 ^ store.toNat := by
  have hnp := hν p
  unfold edgeWeightedChoice
  split_ifs with hc
  · have he : (edgeGroupOutput sourceAnchor sourcePrime m (store, Sum.inr p) hc.2).size =
        m.size + store.toNat := by
      rw [edgeGroupOutput_size, edgeGroupOutputSize_eq]
      simp [edgePromotedIndices]
    have hr : v0 ^ (edgeGroupOutput sourceAnchor sourcePrime m (store, Sum.inr p) hc.2).size /
        v0 ^ m.size = v0 ^ store.toNat := by
      rw [he, pow_add]
      field_simp
    rw [hr]
    unfold edgeGroupWeight edgeTargetWeight
    dsimp only
    have hs : ρ ^ (memoryHits sourceAnchor m).card ≤ 1 := pow_le_one₀ hρ0 hρ1
    have ht : ρ ^ (memoryHits targetAnchor
        (edgeGroupOutput sourceAnchor sourcePrime m (store, Sum.inr p) hc.2)).card ≤ 1 :=
      pow_le_one₀ hρ0 hρ1
    calc
      _ ≤ (1 * ν p * 1) * v0 ^ store.toNat := by gcongr
      _ = _ := by ring
  · positivity

/-- Integration of actual fresh choices over any exceptional set costs
its prime mass, with no factor for the number of primes in the set. -/
theorem edgeWeightedChoice_fresh_sum_le {P : Type*} [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (s : Finset P)
    (hν : ∀ p, 0 ≤ ν p) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    (∑ p ∈ s, edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inr p)) ≤
      (∑ p ∈ s, ν p) * v0 ^ store.toNat := by
  calc
    _ ≤ ∑ p ∈ s, ν p * v0 ^ store.toNat := Finset.sum_le_sum fun p _ =>
      edgeWeightedChoice_fresh_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store p
        hν hρ0 hρ1 hv0
    _ = _ := by rw [Finset.sum_mul]

/-- Restricting promotions to a specified numeric prime can only decrease
the actual indexed weighted sum. This is the fiber used after phase uniqueness. -/
theorem edgeWeightedChoice_promotion_fiber_le {P : Type*} [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (store : Bool) (p : P) (hν : ∀ p, 0 ≤ ν p)
    (hV : 0 ≤ V) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ i : Fin m.size with (m.values i).1 = p,
      edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m (store, Sum.inl i)) ≤
      (V⁻¹ * (v0 ^ store.toNat / v0)) / (1 - ρ) := by
  apply (Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
    (fun i _ _ => edgeWeightedChoice_nonneg ν V ρ v0 sourceAnchor targetAnchor sourcePrime m
      (store, Sum.inl i) hν hV hρ0 hv0.le)).trans
  exact edgeWeightedChoice_promotion_sum_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store
    hV hρ0 hρ1 hv0

/-- The literal product promotion sum over independent indexed memories.
Numeric prime-product restrictions may be applied afterwards. -/
theorem edgeWeightedChoice_promotion_product_sum_le {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (hν : ∀ i p, 0 ≤ ν i p)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ a : ∀ i, Fin (m i).size,
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
        (sourcePrime i) (m i) (store i, Sum.inl (a i))) ≤
      ∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1 - ρ) := by
  classical
  rw [← Fintype.prod_sum (fun i (a : Fin (m i).size) =>
    edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i, Sum.inl a))]
  apply Finset.prod_le_prod₀
  · intro i _
    exact Finset.sum_nonneg fun a _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
      (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) (store i, Sum.inl a)
      (hν i) (hV i) hρ0 hv0.le
  · intro i _
    exact edgeWeightedChoice_promotion_sum_le (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i) (hV i) hρ0 hρ1 hv0

/-- Restricting indexed promotions by their actual numeric prime product
retains the uniform bound. Repeated numeric values are still summed. -/
def edgePromotionProductFiber {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (Z : ℕ) : ℝ :=
  ∑ a : ∀ i, Fin (m i).size,
    if (∏ i, value i ((m i).values (a i)).1) = Z then
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
        (sourcePrime i) (m i) (store i, Sum.inl (a i))
    else 0

theorem edgePromotionProductFiber_nonneg {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (Z : ℕ) (hν : ∀ i p, 0 ≤ ν i p)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hv0 : 0 ≤ v0) :
    0 ≤ edgePromotionProductFiber value ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store Z := by
  unfold edgePromotionProductFiber
  apply Finset.sum_nonneg
  intro a _
  split_ifs
  · exact Finset.prod_nonneg fun i _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
      (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) (store i, Sum.inl (a i))
      (hν i) (hV i) hρ0 hv0
  · exact le_rfl

theorem edgePromotionProductFiber_le {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (Z : ℕ) (hν : ∀ i p, 0 ≤ ν i p)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    edgePromotionProductFiber value ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store Z ≤
      ∏ i, ((V i)⁻¹ * (v0 ^ (store i).toNat / v0)) / (1 - ρ) := by
  apply le_trans _ (edgeWeightedChoice_promotion_product_sum_le ν V ρ v0 sourceAnchor targetAnchor
    sourcePrime m store hν hV hρ0 hρ1 hv0)
  unfold edgePromotionProductFiber
  apply Finset.sum_le_sum
  intro a _
  split_ifs
  · exact le_rfl
  · exact Finset.prod_nonneg fun i _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
      (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) (store i, Sum.inl (a i))
      (hν i) (hV i) hρ0 hv0.le

/-- The actual number of indexed OLD promotion tuples with a given
numeric product, written as a real count for weighted integration. -/
def promotionProductMultiplicity {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) (Z : ℕ) : ℝ :=
  ∑ a : ∀ i, Fin (m i).size,
    if (∏ i, value i ((m i).values (a i)).1) = Z then 1 else 0

theorem promotionProductMultiplicity_nonneg {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) (Z : ℕ) :
    0 ≤ promotionProductMultiplicity value m Z := by
  unfold promotionProductMultiplicity
  exact Finset.sum_nonneg fun _ _ => by split_ifs <;> norm_num

/-- All numeric-product fibers together have at most the number of
actual indexed tuples, hence at most B to the number of promoted groups. -/
theorem promotionProductMultiplicity_sum_le {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B) (s : Finset ℕ) :
    (∑ Z ∈ s, promotionProductMultiplicity value m Z) ≤ (B : ℝ) ^ Fintype.card I := by
  classical
  unfold promotionProductMultiplicity
  rw [Finset.sum_comm]
  calc
    _ ≤ ∑ _a : ∀ i, Fin (m i).size, (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro a _
      simp only [Finset.sum_ite_eq]
      split_ifs <;> norm_num
    _ = ∏ i, ((m i).size : ℝ) := by simp [Fintype.card_pi]
    _ ≤ ∏ _i : I, (B : ℝ) := by
      apply Finset.prod_le_prod₀
      · intro i _; positivity
      · intro i _; exact_mod_cast (m i).size_le
    _ = _ := by simp

/-- On exceptional fresh draws the damping can be discarded. What
remains is the actual indexed multiplicity, rather than a count of prime values. -/
theorem edgePromotionProductFiber_le_crude {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (value : ∀ i, P i → ℕ) (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (Z : ℕ) (hν : ∀ i p, 0 ≤ ν i p)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    edgePromotionProductFiber value ν V ρ v0 sourceAnchor targetAnchor sourcePrime m store Z ≤
      promotionProductMultiplicity value m Z *
        ∏ i, (V i)⁻¹ * (v0 ^ (store i).toNat / v0) := by
  unfold edgePromotionProductFiber promotionProductMultiplicity
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro a _
  split_ifs
  · simp only [one_mul]
    apply Finset.prod_le_prod₀
    · intro i _
      exact edgeWeightedChoice_nonneg (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
        (sourcePrime i) (m i) (store i, Sum.inl (a i)) (hν i) (hV i) hρ0 hv0.le
    · intro i _
      exact edgeWeightedChoice_promotion_le_coefficient (ν i) (V i) ρ v0
        (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) (store i) (a i)
        (hV i) hρ0 hρ1 hv0
  · simp

/-- All actual fresh-group coefficients are bounded by their product
prime law and the explicit optional-store Schur factors. -/
theorem edgeWeightedChoice_fresh_product_le {I : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {B : ℕ}
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (store : I → Bool) (fresh : ∀ i, P i) (hν : ∀ i p, 0 ≤ ν i p)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1) (hv0 : 0 < v0) :
    (∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i, Sum.inr (fresh i))) ≤
      (∏ i, ν i (fresh i)) * ∏ i, v0 ^ (store i).toNat := by
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_le_prod₀
  · intro i _
    exact edgeWeightedChoice_nonneg (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i, Sum.inr (fresh i)) (hν i) (hV i) hρ0 hv0.le
  · intro i _
    exact edgeWeightedChoice_fresh_le (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (store i) (fresh i) (hν i) hρ0 hρ1 hv0

end Elliptic.Operator
