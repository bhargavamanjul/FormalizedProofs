module

public import Mathlib.LinearAlgebra.Projectivization.Action
public import Mathlib.LinearAlgebra.Projectivization.Cardinality
public import Mathlib.Tactic

/-!
# The projective-line part of root-residue replacement

This is the finite algebraic step in [pd, Lemma 3.4]: a uniform special
linear residue matrix gives a uniform kernel line. The proof works with
the actual matrix action. It does not assume equidistribution of integer
roots, nor the replacement of the growing path sum.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootResidues
open scoped BigOperators LinearAlgebra.Projectivization Matrix

section TransitiveAverage
variable {G A : Type*} [Group G] [Fintype G] [Fintype A]
  [MulAction G A] [MulAction.IsPretransitive G A]

omit [Fintype A] in
/-- Reindexing group elements proves that the orbit sum has the same
value at every point; transitivity is used explicitly. -/
theorem orbit_sum_eq (f : A → ℂ) (a b : A) :
    (∑ g : G, f (g • a)) = ∑ g : G, f (g • b) := by
  obtain ⟨h, rfl⟩ := MulAction.exists_smul_eq G a b
  symm
  simpa [mul_smul] using Equiv.sum_comp (Equiv.mulRight h) (fun g : G => f (g • a))

/-- A finite transitive group action pushes uniform counting measure
forward to uniform counting measure, with no fiber-count premise. -/
theorem uniform_orbit_average (f : A → ℂ) (a : A) :
    (∑ g : G, f (g • a)) / (Fintype.card G : ℂ) =
      (∑ b : A, f b) / (Fintype.card A : ℂ) := by
  let : Nonempty A := ⟨a⟩
  have hG : (Fintype.card G : ℂ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  have hA : (Fintype.card A : ℂ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  have hsum (g : G) : (∑ b : A, f (g • b)) = ∑ b : A, f b :=
    Equiv.sum_comp (MulAction.toPerm g) f
  have hdouble : (Fintype.card A : ℂ) * (∑ g : G, f (g • a)) =
      (Fintype.card G : ℂ) * ∑ b : A, f b := by
    calc
      _ = ∑ b : A, ∑ g : G, f (g • b) := by
        simp_rw [← orbit_sum_eq f a]
        simp
      _ = ∑ g : G, ∑ b : A, f (g • b) := Finset.sum_comm
      _ = _ := by simp_rw [hsum]; simp
  apply (div_eq_div_iff hG hA).mpr
  simpa only [mul_comm] using hdouble

end TransitiveAverage

variable (k : Type*) [Field k]

/-- The vertical line, the kernel of the first coordinate. -/
def verticalLine : ℙ k (Fin 2 → k) :=
  Projectivization.mk k ![0, 1] (by intro h; have := congrFun h 1; simp at this)

/-- The kernel of the first row of `g`, represented invariantly as the
inverse image of the vertical line. -/
def kernelLine (g : Matrix.SpecialLinearGroup (Fin 2) k) : ℙ k (Fin 2 → k) :=
  g⁻¹ • verticalLine k

variable {k}

/-- Membership in the transported line agrees with inverse transport
of vectors. -/
theorem mem_smul_line_iff (g : Matrix.SpecialLinearGroup (Fin 2) k)
    (ℓ : ℙ k (Fin 2 → k)) (v : Fin 2 → k) :
    v ∈ (g • ℓ).submodule ↔ g⁻¹ • v ∈ ℓ.submodule := by
  induction ℓ using Projectivization.ind with
  | h w hw =>
    simp only [Projectivization.smul_mk, Projectivization.submodule_mk,
      Submodule.mem_span_singleton]
    constructor
    · rintro ⟨c, hc⟩
      refine ⟨c, ?_⟩
      rw [← hc, smul_comm, inv_smul_smul]
    · rintro ⟨c, hc⟩
      refine ⟨c, ?_⟩
      rw [← smul_comm, hc, smul_inv_smul]

theorem mem_verticalLine_iff (v : Fin 2 → k) :
    v ∈ (verticalLine k).submodule ↔ v 0 = 0 := by
  simp only [verticalLine, Projectivization.submodule_mk, Submodule.mem_span_singleton]
  constructor
  · rintro ⟨c, rfl⟩
    simp
  · intro hv
    refine ⟨v 1, ?_⟩
    ext i
    fin_cases i <;> simp [hv]

/-- The named kernel line is the actual kernel of the first matrix row,
not just an abstract uniformly distributed projective point. -/
theorem mem_kernelLine_iff (g : Matrix.SpecialLinearGroup (Fin 2) k)
    (v : Fin 2 → k) :
    v ∈ (kernelLine k g).submodule ↔ g 0 0 * v 0 + g 0 1 * v 1 = 0 := by
  rw [kernelLine, mem_smul_line_iff, inv_inv, mem_verticalLine_iff]
  change ((g : Matrix (Fin 2) (Fin 2) k) *ᵥ v) 0 = 0 ↔ _
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_two]

/-- There are exactly `#k + 1` possible kernel lines. -/
theorem card_lines [Fintype k] [Fintype (ℙ k (Fin 2 → k))] :
    Fintype.card (ℙ k (Fin 2 → k)) = Fintype.card k + 1 := by
  have h := Projectivization.card_of_finrank_two k (Fin 2 → k) (by simp)
  simpa only [Nat.card_eq_fintype_card] using h

/-- Uniform special linear matrices give uniform projective kernel
lines. This is valid in every finite field, including characteristic 2. -/
theorem kernel_line_average [Fintype k] [DecidableEq k]
    [Fintype (ℙ k (Fin 2 → k))] (f : ℙ k (Fin 2 → k) → ℂ) :
    (∑ g : Matrix.SpecialLinearGroup (Fin 2) k, f (kernelLine k g)) /
        (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) k) : ℂ) =
      (∑ ℓ : ℙ k (Fin 2 → k), f ℓ) / (Fintype.card (ℙ k (Fin 2 → k)) : ℂ) := by
  have hinv := Equiv.sum_comp (Equiv.inv (Matrix.SpecialLinearGroup (Fin 2) k))
    (fun g => f (g • verticalLine k))
  simp only [Equiv.inv_apply] at hinv
  change (∑ g : Matrix.SpecialLinearGroup (Fin 2) k, f (g⁻¹ • verticalLine k)) / _ = _
  rw [hinv]
  exact uniform_orbit_average f (verticalLine k)

/-- The finite product version needed after Chinese remaindering. The
test function may couple all the primes: independence is a conclusion
about the full joint distribution, not an assumption on the test. -/
theorem kernel_family_average {ι : Type*} [Fintype ι] [DecidableEq ι]
    (F : ι → Type*) [∀ i, Field (F i)] [∀ i, Fintype (F i)]
    [∀ i, DecidableEq (F i)] [∀ i, Fintype (ℙ (F i) (Fin 2 → F i))]
    (f : (∀ i, ℙ (F i) (Fin 2 → F i)) → ℂ) :
    (∑ g : (∀ i, Matrix.SpecialLinearGroup (Fin 2) (F i)),
        f (fun i => kernelLine (F i) (g i))) /
        (Fintype.card (∀ i, Matrix.SpecialLinearGroup (Fin 2) (F i)) : ℂ) =
      (∑ ℓ : (∀ i, ℙ (F i) (Fin 2 → F i)), f ℓ) /
        ((∏ i, (Fintype.card (F i) + 1)) : ℕ) := by
  let : MulAction.IsPretransitive
      (∀ i, Matrix.SpecialLinearGroup (Fin 2) (F i))
      (∀ i, ℙ (F i) (Fin 2 → F i)) := {
    exists_smul_eq := by
      intro a b
      choose g hg using fun i => MulAction.exists_smul_eq
        (Matrix.SpecialLinearGroup (Fin 2) (F i)) (a i) (b i)
      exact ⟨g, funext hg⟩ }
  have hcard : Fintype.card (∀ i, ℙ (F i) (Fin 2 → F i)) =
      ∏ i, (Fintype.card (F i) + 1) := by
    rw [Fintype.card_pi]
    simp_rw [card_lines]
  have hinv := Equiv.sum_comp
    (Equiv.inv (∀ i, Matrix.SpecialLinearGroup (Fin 2) (F i)))
    (fun g => f (g • fun i => verticalLine (F i)))
  simp only [Equiv.inv_apply] at hinv
  change (∑ g : (∀ i, Matrix.SpecialLinearGroup (Fin 2) (F i)),
      f (g⁻¹ • fun i => verticalLine (F i))) / _ = _
  rw [hinv, ← hcard]
  exact uniform_orbit_average f (fun i => verticalLine (F i))

end Elliptic.Operator.RootResidues
