module

public import Elliptic.Operator.PrimeExceptionalSet
public import Mathlib.Order.Interval.Set.Union

/-! Actual exceptional cells of the small-prime polynomial, indexed to
match the sampled Gram theorem. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrimeExceptionalCells
open scoped BigOperators
open SmallPrimePower Set
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

def primePolynomial (S : Finset ℕ) (P : ℝ) {q : ℕ}
    (χ : DirichletCharacter ℂ q) (ξ t : ℝ) : ℂ :=
  ∑p:S,normalizedPrimeCoefficient S P χ ξ p*Artin.MarkedReplacement.archimedeanPhase t p.val

theorem primePolynomial_continuous (S : Finset ℕ) (P : ℝ) {q : ℕ}
    (χ : DirichletCharacter ℂ q) (ξ : ℝ) : Continuous (primePolynomial S P χ ξ) := by
  unfold primePolynomial Artin.MarkedReplacement.archimedeanPhase
  fun_prop

theorem primePolynomial_norm_le (S : Finset ℕ) (P : ℝ) (hP : 0<P) {q : ℕ}
    (χ : DirichletCharacter ℂ q) (ξ t : ℝ) : ‖primePolynomial S P χ ξ t‖≤(S.card:ℝ)/P := by
  calc
    _ ≤ ∑p:S,‖normalizedPrimeCoefficient S P χ ξ p*Artin.MarkedReplacement.archimedeanPhase t p.val‖ :=
      norm_sum_le _ _
    _ ≤ ∑_p:S,P⁻¹ := by
      apply Finset.sum_le_sum
      intro p hp
      rw [norm_mul,Artin.MarkedReplacement.archimedeanPhase_norm,mul_one,
        normalizedPrimeCoefficient,norm_mul,norm_mul,Artin.MarkedReplacement.archimedeanPhase_norm,
        mul_one,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hP]
      simpa only [mul_one] using mul_le_mul_of_nonneg_left (χ.norm_le_one (p.val:ZMod q)) (inv_nonneg.mpr hP.le)
    _ = _ := by simp [div_eq_mul_inv]

/-- Cells are included exactly when the actual prime polynomial exceeds ε
somewhere in their closure. -/
def exceptionalCells (K : ℕ) (a ε : ℝ) (P : ℝ→ℂ) : Finset ℕ :=
  (Finset.Icc 1 K).filter (fun i=>∃t∈Icc (a+(i:ℝ)) (a+(i:ℝ)+1),ε<‖P t‖)

theorem exceptionalCells_subset (K : ℕ) (a ε : ℝ) (P : ℝ→ℂ) :
    exceptionalCells K a ε P⊆Finset.Icc 1 K := Finset.filter_subset _ _

theorem exceptionalCells_witnesses (K : ℕ) (a ε : ℝ) (P : ℝ→ℂ) :
    ∃τ:ℕ→ℝ,∀i∈exceptionalCells K a ε P,
      (a+(i:ℝ)≤τ i∧τ i≤a+(i:ℝ)+1)∧ε≤‖P (τ i)‖ := by
  have hex (i:ℕ) : ∃t:ℝ,i∈exceptionalCells K a ε P→
      (a+(i:ℝ)≤t∧t≤a+(i:ℝ)+1)∧ε≤‖P t‖ := by
    by_cases hi : i∈exceptionalCells K a ε P
    · obtain ⟨t,ht,hP⟩ := (Finset.mem_filter.mp hi).2
      exact ⟨t,fun _=>⟨ht,hP.le⟩⟩
    · exact ⟨0,fun h=>False.elim (hi h)⟩
  choose τ hτ using hex
  exact ⟨τ,hτ⟩

theorem exceptionalCells_cover (K : ℕ) (a ε : ℝ) (P : ℝ→ℂ) :
    Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | ε<‖P t‖}⊆
      ⋃i:ℕ,⋃ (_:i∈exceptionalCells K a ε P),Ioc (a+(i:ℝ)) (a+(i:ℝ)+1) := by
  intro t ht
  have hcover := Ioc_subset_biUnion_Ioc K (fun i:ℕ=>a+(i:ℝ)+1)
  have htin : t∈Ioc (a+(0:ℕ)+1) (a+(K:ℝ)+1) := by simpa using ht.1
  obtain ⟨i,hi,hcell⟩ := Set.mem_iUnion₂.mp (hcover htin)
  have hiK := Finset.mem_range.mp hi
  have hi' : i+1∈exceptionalCells K a ε P := by
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_Icc.mpr ⟨by omega,by omega⟩,t,?_,ht.2⟩
    simp only [Nat.cast_add,Nat.cast_one] at hcell ⊢
    constructor <;> linarith [hcell.1,hcell.2]
  apply Set.mem_iUnion₂.mpr ⟨i+1,hi',?_⟩
  simp only [Nat.cast_add,Nat.cast_one] at hcell ⊢
  constructor <;> linarith [hcell.1,hcell.2]

/-- The exact growing-moment cardinality bound for the actual exceptional
cell set. Its constant is independent of the character and real shift. -/
theorem exceptionalCells_card (K : ℕ) (a ε : ℝ) (hε : 0<ε)
    (S : Finset ℕ) (j : ℕ) (hprime : ∀p∈S,p.Prime) (B : ℕ)
    (hBpos : 1≤B) (hB : ∀p∈S,p≤B) (Pscale : ℝ) (hP : 0<Pscale)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (ξ : ℝ) :
    ((exceptionalCells K a ε (primePolynomial S Pscale χ ξ)).card:ℝ)≤
      3*sampleBudget (B^j) (a+1) (a+(K:ℝ)+1)*
        ((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j)/ε^(2*j) := by
  let s := exceptionalCells K a ε (primePolynomial S Pscale χ ξ)
  obtain ⟨τ,hτ⟩ := exceptionalCells_witnesses K a ε (primePolynomial S Pscale χ ξ)
  have hτrange : ∀i∈s,a+1≤τ i∧τ i≤a+(K:ℝ)+1 := by
    intro i hi
    have his := Finset.mem_Icc.mp (exceptionalCells_subset K a ε _ hi)
    have hir : (1:ℝ)≤ i := by exact_mod_cast his.1
    have hiK : (i:ℝ)≤K := by exact_mod_cast his.2
    have ht := (hτ i hi).1
    constructor <;> linarith
  let f : ℕ→ℝ := fun i=>‖primePolynomial S Pscale χ ξ (τ i)‖^(2*j)
  let E := sampleBudget (B^j) (a+1) (a+(K:ℝ)+1)*((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j)
  have hc (r:ℕ) : (∑i∈s.filter (fun i=>i%3=r),f i)≤E := by
    apply separated_normalized_prime_moment _ τ (a+1) (a+(K:ℝ)+1) (by have := Nat.cast_nonneg (α:=ℝ) K; linarith)
      (fun i hi=>hτrange i (Finset.mem_filter.mp hi).1) _ S j hprime B hBpos hB Pscale hP χ ξ
    intro i hi k hk hik
    have hi' := Finset.mem_filter.mp hi
    have hk' := Finset.mem_filter.mp hk
    have hiτ := (hτ i hi'.1).1
    have hkτ := (hτ k hk'.1).1
    rcases lt_or_gt_of_ne hik with hik|hki
    · have hgap : i+3≤ k := by omega
      have hgapR : (i:ℝ)+3≤ k := by exact_mod_cast hgap
      rw [abs_of_nonpos (by linarith : τ i-τ k≤0)]
      linarith
    · have hgap : k+3≤ i := by omega
      have hgapR : (k:ℝ)+3≤ i := by exact_mod_cast hgap
      rw [abs_of_nonneg (by linarith : 0≤τ i-τ k)]
      linarith
  have hm : ∀i∈s,i%3∈Finset.range 3 := fun i hi=>Finset.mem_range.mpr (Nat.mod_lt i (by omega))
  have hsum : (∑i∈s,f i)≤3*E := by
    rw [←Finset.sum_fiberwise_of_maps_to hm]
    calc
      _ ≤ ∑r∈Finset.range 3,E := Finset.sum_le_sum fun r hr=>hc r
      _ = _ := by simp
  have hlo : (s.card:ℝ)*ε^(2*j)≤∑i∈s,f i := by
    calc
      _ = ∑_i∈s,ε^(2*j) := by simp
      _ ≤ _ := Finset.sum_le_sum fun i hi=>pow_le_pow_left₀ hε.le (hτ i hi).2 (2*j)
  apply (le_div_iff₀ (pow_pos hε _)).mpr
  simpa only [E,mul_assoc] using hlo.trans hsum

end Elliptic.Operator.PrimeExceptionalCells
