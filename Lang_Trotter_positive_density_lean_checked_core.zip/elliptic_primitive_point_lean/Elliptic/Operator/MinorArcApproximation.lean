module

public import Elliptic.Operator.RationalExponentialBound
public import Elliptic.Operator.FourierFiber
public import Mathlib.NumberTheory.DiophantineApproximation.Basic
public import Mathlib.RingTheory.Int.Basic

/-!
# Actual major arcs and Dirichlet approximation after a Fourier shift

The major arcs have the source radius 2H/Y and all reduced denominators
at most H. A shift u/Y with |u|<=H/2 stays far enough from those rationals
that a Dirichlet approximant has denominator greater than H.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open MeasureTheory Elliptic.SourceContracts

/-- The literal union of rational major arcs, with the source radius. -/
def sourceMajorArcs (H Y : ℝ) : Set ProductCircle :=
  {θ | ∃ (c : ℤ) (d : ℕ), 0 < d ∧ (d : ℝ) ≤ H ∧ IsCoprime c (d : ℤ) ∧
    dist θ (((c : ℝ)/d : ℝ) : ProductCircle) ≤ 2*H/Y}

theorem sourceMajorArcs_measurable (H Y : ℝ) : MeasurableSet (sourceMajorArcs H Y) := by
  change MeasurableSet {θ : ProductCircle | ∃ (c : ℤ) (d : ℕ), _}
  simp only [Set.ofPred_exists]
  apply MeasurableSet.iUnion
  intro c
  apply MeasurableSet.iUnion
  intro d
  by_cases hd : 0 < d ∧ (d : ℝ) ≤ H ∧ IsCoprime c (d : ℤ)
  · have he : {θ : ProductCircle | 0 < d ∧ (d : ℝ) ≤ H ∧ IsCoprime c (d : ℤ) ∧
        dist θ (((c : ℝ)/d : ℝ) : ProductCircle) ≤ 2*H/Y} =
        {θ : ProductCircle | dist θ (((c : ℝ)/d : ℝ) : ProductCircle) ≤ 2*H/Y} := by
      ext θ; simp [hd.1, hd.2.1, hd.2.2]
    rw [he]
    exact isClosed_le (continuous_id.dist continuous_const) continuous_const |>.measurableSet
  · have he : {θ : ProductCircle | 0 < d ∧ (d : ℝ) ≤ H ∧ IsCoprime c (d : ℤ) ∧
        dist θ (((c : ℝ)/d : ℝ) : ProductCircle) ≤ 2*H/Y} = ∅ := by
      ext θ; simp only [Set.mem_ofPred_eq, Set.mem_empty_iff_false, iff_false]
      exact fun h => hd ⟨h.1, h.2.1, h.2.2.1⟩
    rw [he]
    exact MeasurableSet.empty

/-- Dirichlet gives the precise source denominator range after every
allowed small Fourier shift. Numerators are signed integers. -/
theorem minor_arc_shift_rational_approximation (H Y θ u : ℝ)
    (hH : 1 ≤ H) (hY : 0 < Y) (hu : |u| ≤ H/2)
    (hminor : (θ : ProductCircle) ∉ sourceMajorArcs H Y) :
    ∃ (c : ℤ) (d : ℕ), 2 ≤ d ∧ H < (d : ℝ) ∧ d ≤ ⌈Y/H⌉₊ ∧
      IsCoprime c (d : ℤ) ∧ |(θ+u/Y)-(c : ℝ)/d| ≤ 1/(d : ℝ)^2 := by
  have hHpos : 0 < H := lt_of_lt_of_le zero_lt_one hH
  let Q : ℕ := ⌈Y/H⌉₊
  have hQ : 0 < Q := Nat.ceil_pos.mpr (div_pos hY hHpos)
  have hYQ : Y/H ≤ (Q : ℝ) := Nat.le_ceil _
  obtain ⟨q, hq, hqQ⟩ := Real.exists_rat_abs_sub_le_and_den_le (θ+u/Y) hQ
  have hd : 0 < q.den := q.pos
  have hdR : 0 < (q.den : ℝ) := by exact_mod_cast hd
  have hQpos : 0 < (Q : ℝ) := by exact_mod_cast hQ
  have hcop : IsCoprime q.num (q.den : ℤ) := by
    exact Int.isCoprime_iff_nat_coprime.mpr (by simpa using q.reduced)
  have hqcast : (q : ℝ) = (q.num : ℝ)/q.den := by
    exact_mod_cast q.num_div_den.symm
  have hfirst : |(θ+u/Y)-(q.num : ℝ)/q.den| ≤ 1/((Q : ℝ)*(q.den : ℝ)) := by
    rw [← hqcast]
    apply hq.trans
    apply one_div_le_one_div_of_le (mul_pos hQpos hdR)
    gcongr
    simp
  have hsmall : |(θ+u/Y)-(q.num : ℝ)/q.den| ≤ H/Y := by
    apply hfirst.trans
    have hd1 : (1 : ℝ) ≤ q.den := by exact_mod_cast hd
    calc
      1/((Q : ℝ)*(q.den : ℝ)) ≤ 1/(Q : ℝ) := by
        apply one_div_le_one_div_of_le hQpos
        nlinarith
      _ ≤ H/Y := by
        apply (div_le_div_iff₀ hQpos hY).mpr
        have h := (div_le_iff₀ hHpos).mp hYQ
        nlinarith
  have hlarge : H < (q.den : ℝ) := by
    by_contra hnot
    have hdH : (q.den : ℝ) ≤ H := le_of_not_gt hnot
    apply hminor
    refine ⟨q.num, q.den, hd, hdH, hcop, ?_⟩
    rw [dist_eq_norm, ← AddCircle.coe_sub]
    calc
      _ ≤ |θ-(q.num : ℝ)/q.den| := QuotientAddGroup.norm_mk_le_norm
      _ ≤ |(θ+u/Y)-(q.num : ℝ)/q.den| + |u/Y| := by
        have h := abs_sub ((θ+u/Y)-(q.num : ℝ)/q.den) (u/Y)
        have he : (θ+u/Y)-(q.num : ℝ)/q.den-u/Y = θ-(q.num : ℝ)/q.den := by ring
        rwa [he] at h
      _ ≤ H/Y + (H/2)/Y := by
        apply add_le_add hsmall
        rw [abs_div, abs_of_pos hY]
        exact div_le_div_of_nonneg_right hu hY.le
      _ ≤ 2*H/Y := by
        have hnon : 0 ≤ H/Y := div_nonneg hHpos.le hY.le
        rw [show (H/2)/Y = (H/Y)/2 by ring, show 2*H/Y = 2*(H/Y) by ring]
        linarith
  refine ⟨q.num, q.den, ?_, hlarge, hqQ, hcop, ?_⟩
  · have hd1 : (1 : ℝ) < q.den := hH.trans_lt hlarge
    exact_mod_cast hd1
  · apply hfirst.trans
    apply one_div_le_one_div_of_le (sq_pos_of_pos hdR)
    have hdQ : (q.den : ℝ) ≤ Q := by exact_mod_cast hqQ
    nlinarith

/-- Expanded before replacing the denominator bounds; this avoids the
false cross-term that would result from bounding both factors separately. -/
def minorDeterminantBudget (A B : ℕ) (H Y : ℝ) : ℝ :=
  let Q : ℝ := ⌈Y/H⌉₊
  12*((A : ℝ)*B/H + ((A : ℝ)+Q)*(1+Real.log Q) + B)

theorem minorDeterminantBudget_nonneg (A B : ℕ) (H Y : ℝ)
    (hH : 0 < H) (hY : 0 < Y) : 0 ≤ minorDeterminantBudget A B H Y := by
  have hQ : 0 < ⌈Y/H⌉₊ := Nat.ceil_pos.mpr (div_pos hY hH)
  have hQ1 : (1 : ℝ) ≤ ⌈Y/H⌉₊ := by exact_mod_cast hQ
  have hlog := Real.log_nonneg hQ1
  unfold minorDeterminantBudget
  positivity

/-- Uniformly in every small Fourier shift, the literal determinant
matrix has the expanded source bound. -/
theorem minor_arc_shift_determinant_bound (A B : ℕ) (a b H Y θ u : ℝ)
    (hH : 1 ≤ H) (hY : 0 < Y) (hu : |u| ≤ H/2)
    (hminor : (θ : ProductCircle) ∉ sourceMajorArcs H Y) :
    FiniteKernelBound (Finset.range B ×ˢ Finset.range A)
      (Finset.range A ×ˢ Finset.range B) (fun _ => 1) (fun _ => 1)
      (fun p q => additivePhase ((θ+u/Y) *
        ((a+p.1)*(b+q.1) - (b+p.2)*(a+q.2))))
      (minorDeterminantBudget A B H Y) := by
  obtain ⟨c,d,hd,hdH,hdQ,hcop,happrox⟩ :=
    minor_arc_shift_rational_approximation H Y θ u hH hY hu hminor
  have hdR : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hHpos : 0 < H := lt_of_lt_of_le zero_lt_one hH
  let Q : ℝ := ⌈Y/H⌉₊
  have hdQR : (d : ℝ) ≤ Q := by dsimp [Q]; exact_mod_cast hdQ
  have hlog : Real.log (d : ℝ) ≤ Real.log Q := Real.log_le_log hdR hdQR
  have hd1 : (1 : ℝ) ≤ d := by exact_mod_cast (show 1 ≤ d by omega)
  have hlog0 : 0 ≤ 1+Real.log Q := by have := Real.log_nonneg (hd1.trans hdQR); linarith
  have hAB : (A : ℝ)*B/d ≤ (A : ℝ)*B/H :=
    div_le_div_of_nonneg_left (by positivity) hHpos hdH.le
  have hA : (A : ℝ)*(1+Real.log d) ≤ (A : ℝ)*(1+Real.log Q) := by gcongr
  have hdlog : (d : ℝ)*(1+Real.log d) ≤ Q*(1+Real.log Q) := by
    exact mul_le_mul hdQR (by linarith) (by positivity) (by positivity)
  have hnum : 12*((A : ℝ)/d+1)*((B : ℝ)+(d : ℝ)*(1+Real.log d)) ≤
      minorDeterminantBudget A B H Y := by
    have he : ((A : ℝ)/d+1)*((B : ℝ)+(d : ℝ)*(1+Real.log d)) =
        (A : ℝ)*B/d+(A : ℝ)*(1+Real.log d)+B+(d : ℝ)*(1+Real.log d) := by
      field_simp
      ring
    rw [mul_assoc, he]
    unfold minorDeterminantBudget
    dsimp only
    change 12*((A : ℝ)*B/d+(A : ℝ)*(1+Real.log d)+B+(d : ℝ)*(1+Real.log d)) ≤
      12*((A : ℝ)*B/H+((A : ℝ)+Q)*(1+Real.log Q)+B)
    nlinarith
  intro v
  exact (determinant_kernel_bound_of_rational_approximation A B d (θ+u/Y) a b c hd
    hcop happrox v).trans (mul_le_mul_of_nonneg_right hnum (Real.sqrt_nonneg _))

end Elliptic.Operator
