module

public import Elliptic.Operator.WeightedSchur
public import Artin.MarkedMultigroupMass

/-!
# From the enlarged clean kernel to actual prime-labelled states

The source is OpenAI, *The Poisson--Dirichlet law for prime predecessors*,
equations (4.28)--(4.34), printed pages 25--26.  The enlargement in (4.29)
has an unrestricted integer product coordinate.  Actual labels are positive
prime tuples, so reflection is performed only after embedding those labels
into that larger space.  The results here prove that embedding, its exact
finite-sum pullback, and the product-measure estimate used in (4.28).

The enlarged unsigned analytic bound remains an explicit hypothesis.  No
signed physical operator, memory identity, or marked replacement estimate
is assumed as an imported source statement.
-/

@[expose] public section

namespace Elliptic.Operator

open scoped BigOperators
open Elliptic.SourceContracts

/-- Literal transformed prime mass from source (4.3), for a finite set
of visits and their damping deficits `η`. -/
noncomputable def transformedPrimeMass {τ : Type*} (visits : Finset τ)
    (η : τ → ℝ) (V : ℝ) (p : ℕ) : ℝ :=
  1 / (V * ((p : ℝ) + 1) * (1 - (∑ j ∈ visits, η j) / ((p : ℝ) + 1)))

theorem transformedPrimeMass_eq {τ : Type*} (visits : Finset τ)
    (η : τ → ℝ) (V : ℝ) (p : ℕ) :
    transformedPrimeMass visits η V p =
      1 / (V * ((p : ℝ) + 1 - ∑ j ∈ visits, η j)) := by
  unfold transformedPrimeMass
  congr 1
  have hp : (p : ℝ) + 1 ≠ 0 := by positivity
  field_simp

/-- The actual transformed mass in the memory proof has the reciprocal
prime bound required in (4.28), uniformly over all paths of a bounded
number of visits. The inequality `2*#visits ≤ p` is eventually automatic
in the source ranges, but that asymptotic fact is not presumed here. -/
theorem transformedPrimeMass_bounds {τ : Type*} (visits : Finset τ)
    (η : τ → ℝ) (V : ℝ) (p : ℕ) (hV : 0 < V) (hp : 0 < p)
    (hη : ∀ j ∈ visits, η j ≤ 1)
    (hsize : 2 * (visits.card : ℝ) ≤ p) :
    0 ≤ transformedPrimeMass visits η V p ∧
      transformedPrimeMass visits η V p ≤ (2 / V) / p := by
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hsum : (∑ j ∈ visits, η j) ≤ (visits.card : ℝ) := by
    calc
      _ ≤ ∑ j ∈ visits, (1 : ℝ) := Finset.sum_le_sum hη
      _ = _ := by simp
  have hbase : (p : ℝ) / 2 ≤ (p : ℝ) + 1 - ∑ j ∈ visits, η j := by linarith
  have hden : 0 < V * ((p : ℝ) + 1 - ∑ j ∈ visits, η j) :=
    mul_pos hV ((half_pos hpR).trans_le hbase)
  rw [transformedPrimeMass_eq]
  refine ⟨(one_div_pos.mpr hden).le, ?_⟩
  calc
    _ ≤ 1 / (V * ((p : ℝ) / 2)) :=
      one_div_le_one_div_of_le (mul_pos hV (half_pos hpR))
        (mul_le_mul_of_nonneg_left hbase hV.le)
    _ = _ := by field_simp

/-- Restrict a counting-measure bilinear bound along injective label maps.
The proof uses actual extension by zero; it does not assume the actual
prime-label support is invariant under reflection. -/
theorem finiteBilinearBound_embedding {ι κ ι' κ' : Type*}
    (s : Finset ι) (t : Finset κ) (e : ι ↪ ι') (f : κ ↪ κ')
    (K : ι' → κ' → ℂ) (C : ℝ)
    (hK : FiniteBilinearBound (s.map e) (t.map f) K C) :
    FiniteBilinearBound s t (fun i j => K (e i) (f j)) C := by
  classical
  intro a b
  have h := hK (Function.extend e a (fun _ => 0))
    (Function.extend f b (fun _ => 0))
  simpa [finitePairing, Finset.sum_map, e.injective.extend_apply,
    f.injective.extend_apply] using h

/-- One actual prime from each of the disjoint marked groups. -/
abbrev PrimeChoice {ι : Type*} [DecidableEq ι] (I : Finset ι) (groups : ι → Finset ℕ) :=
  {f : I → ℕ // f ∈ Fintype.piFinset (fun i : I => groups i)}

/-- The positive prime-product coordinate of an actual label tuple. -/
def primeChoiceProduct {ι : Type*} [DecidableEq ι] (I : Finset ι) (groups : ι → Finset ℕ)
    (f : PrimeChoice I groups) : ℕ := ∏ i, f.val i

/-- Disjoint prime bands ensure that no two actual unshared lists have
the same integer product. This is the precise multiplicity assertion
needed before the source's change to counting measure. -/
def primeChoiceEmbedding {ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j)) :
    PrimeChoice I groups ↪ ℤ where
  toFun f := primeChoiceProduct I groups f
  inj' := by
    intro f g h
    apply Subtype.ext
    apply Artin.MarkedMultigroupMass.choice_product_injective I groups hprime hdisjoint
      f.property g.property
    change ((∏ i, f.val i : ℕ) : ℤ) = (∏ i, g.val i : ℕ) at h
    exact_mod_cast h

/-- Keep the physical lattice coordinate and embed only the label tuple. -/
def labelledStateEmbedding {ζ ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j)) :
    (ζ × PrimeChoice I groups) ↪ (ζ × ℤ) where
  toFun p := (p.1, primeChoiceEmbedding I groups hprime hdisjoint p.2)
  inj' := by
    intro p q h
    have hfirst : p.1 = q.1 := congrArg (fun z : ζ × ℤ => z.1) h
    have hsecond : p.2 = q.2 :=
      (primeChoiceEmbedding I groups hprime hdisjoint).injective
        (congrArg (fun z : ζ × ℤ => z.2) h)
    exact Prod.ext hfirst hsecond

/-- The actual tensor-product label measure. -/
noncomputable def primeChoiceMass {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (ν : ι → ℕ → ℝ) (f : PrimeChoice I groups) : ℝ :=
  ∏ i : I, ν i (f.val i)

theorem primeChoiceMass_nonneg {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (ν : ι → ℕ → ℝ)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p) (f : PrimeChoice I groups) :
    0 ≤ primeChoiceMass I groups ν f := by
  apply Finset.prod_nonneg
  intro i _
  exact hν i i.property _ (Fintype.mem_piFinset.mp f.property i)

/-- The product-measure bound in source (4.28), before using the product
cutoff: pointwise reciprocal-prime bounds multiply with no loss from the
number of tuples, because the product map is injective. -/
theorem primeChoiceMass_le_product_div {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (ν : ι → ℕ → ℝ) (A : ι → ℝ)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ A i / p)
    (f : PrimeChoice I groups) :
    primeChoiceMass I groups ν f ≤ (∏ i : I, A i) / primeChoiceProduct I groups f := by
  calc
    _ ≤ ∏ i : I, A i / (f.val i : ℝ) := by
      apply Finset.prod_le_prod₀
      · intro i _
        exact hν i i.property _ (Fintype.mem_piFinset.mp f.property i)
      · intro i _
        exact hbound i i.property _ (Fintype.mem_piFinset.mp f.property i)
    _ = _ := by simp [Finset.prod_div_distrib, primeChoiceProduct]

/-- A product cutoff `b ≥ Y > 0` yields exactly the source atom bound
`m(b) ≤ C/Y`; the constant is the product of the bandwise constants. -/
theorem primeChoiceMass_le_of_product_lower {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (ν : ι → ℕ → ℝ) (A : ι → ℝ)
    (hA : ∀ i ∈ I, 0 ≤ A i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ A i / p)
    (f : PrimeChoice I groups) (Y : ℝ) (hY : 0 < Y)
    (hproduct : Y ≤ primeChoiceProduct I groups f) :
    primeChoiceMass I groups ν f ≤ (∏ i : I, A i) / Y := by
  apply (primeChoiceMass_le_product_div I groups ν A hν hbound f).trans
  exact div_le_div_of_nonneg_left
    (Finset.prod_nonneg fun i _ => hA i i.property) hY hproduct

/-- The full integrated sign-minus clean kernel on actual positive prime
tuples is controlled by the sign-plus enlarged kernel on reflected integer
supports. Reflection of the actual prime labels is neither used nor valid. -/
theorem actualLabel_clean_minus_bound {ζ ξ ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (s : Finset (ζ × PrimeChoice I groups)) (t : Finset (ξ × PrimeChoice I groups))
    (cutoff : ζ → ξ → ℂ) (det : ζ → ξ → ℝ) (Phi : ℝ → ℂ) (C : ℝ)
    (hplus : FiniteBilinearBound
      ((s.map (labelledStateEmbedding I groups hprime hdisjoint)).map
        (productReflection ζ).toEmbedding)
      ((t.map (labelledStateEmbedding I groups hprime hdisjoint)).map
        (productReflection ξ).toEmbedding)
      (integratedCleanKernel cutoff det Phi 1) C) :
    FiniteBilinearBound s t
      (fun p q => cutoff p.1 q.1 * Phi
        (det p.1 q.1 + (primeChoiceProduct I groups p.2 : ℝ) -
          (primeChoiceProduct I groups q.2 : ℝ))) C := by
  have hminus := integratedCleanKernel_minus_bound
    (s.map (labelledStateEmbedding I groups hprime hdisjoint))
    (t.map (labelledStateEmbedding I groups hprime hdisjoint))
    cutoff det Phi C hplus
  have h := finiteBilinearBound_embedding s t
    (labelledStateEmbedding I groups hprime hdisjoint)
    (labelledStateEmbedding I groups hprime hdisjoint)
    (integratedCleanKernel cutoff det Phi (-1)) C hminus
  simpa [integratedCleanKernel, labelledStateEmbedding, primeChoiceEmbedding, sub_eq_add_neg] using h

/-- The complete measure-normalization step of source (4.28)--(4.29).
An enlarged counting kernel has prefactor `1/Y`; label atoms at most `C/Y`
turn its bound `M` into the physical measured bound `C*M`.  Zero atoms are
allowed, and the factor `Y` is cancelled exactly rather than estimated. -/
theorem measured_clean_bound_of_normalized_counting {ζ ξ : Type*}
    (s : Finset ζ) (t : Finset ξ) (μ : ζ → ℝ) (ν : ξ → ℝ)
    (K : ζ → ξ → ℂ) (Y C M : ℝ) (hY : 0 < Y) (hC : 0 ≤ C) (hM : 0 ≤ M)
    (hμ : ∀ i ∈ s, 0 ≤ μ i) (hν : ∀ j ∈ t, 0 ≤ ν j)
    (hμC : ∀ i ∈ s, μ i ≤ C / Y) (hνC : ∀ j ∈ t, ν j ≤ C / Y)
    (hK : FiniteBilinearBound s t (fun i j => (Y : ℂ)⁻¹ * K i j) M) :
    FiniteMeasuredBilinearBound s t μ ν K (C * M) := by
  have hleft : ∀ i ∈ s, ‖(Real.sqrt (μ i) : ℂ) * (Real.sqrt Y : ℂ)‖ ≤
      Real.sqrt C := by
    intro i hi
    simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Real.sqrt_nonneg _)]
    rw [← Real.sqrt_mul (hμ i hi)]
    exact Real.sqrt_le_sqrt ((le_div_iff₀ hY).mp (hμC i hi))
  have hright : ∀ j ∈ t, ‖(Real.sqrt (ν j) : ℂ) * (Real.sqrt Y : ℂ)‖ ≤
      Real.sqrt C := by
    intro j hj
    simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Real.sqrt_nonneg _)]
    rw [← Real.sqrt_mul (hν j hj)]
    exact Real.sqrt_le_sqrt ((le_div_iff₀ hY).mp (hνC j hj))
  have h := finiteBilinearBound_endpoint_bounds s t
    (fun i j => (Y : ℂ)⁻¹ * K i j) M (Real.sqrt C) (Real.sqrt C)
    hM (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
    (fun i => (Real.sqrt (μ i) : ℂ) * (Real.sqrt Y : ℂ))
    (fun j => (Real.sqrt (ν j) : ℂ) * (Real.sqrt Y : ℂ)) hleft hright hK
  have hy0 : (Y : ℂ) ≠ 0 := by exact_mod_cast hY.ne'
  have hysq : (Real.sqrt Y : ℂ) ^ 2 = (Y : ℂ) := by
    exact_mod_cast Real.sq_sqrt hY.le
  have heq : (fun i j =>
      ((Real.sqrt (μ i) : ℂ) * (Real.sqrt Y : ℂ)) * ((Y : ℂ)⁻¹ * K i j) *
      ((Real.sqrt (ν j) : ℂ) * (Real.sqrt Y : ℂ))) = sqrtMeasureKernel μ ν K := by
    funext i j
    unfold sqrtMeasureKernel
    calc
      _ = (Real.sqrt (μ i) : ℂ) * K i j * (Real.sqrt (ν j) : ℂ) *
          ((Real.sqrt Y : ℂ) ^ 2 * (Y : ℂ)⁻¹) := by ring
      _ = _ := by rw [hysq, mul_inv_cancel₀ hy0, mul_one]
  have hconstant : Real.sqrt C * M * Real.sqrt C = C * M := by
    nlinarith [Real.sq_sqrt hC]
  rw [heq, hconstant] at h
  exact finiteMeasuredBilinearBound_of_sqrt_conjugated s t μ ν hμ hν K (C * M) h

/-- Clean sign transport with the actual prime-tuple tensor measures,
including the source's normalization by `1/Y`. This closes the measure and
label restriction portion of the clean edge argument. The only analytic
premise here is the enlarged unsigned kernel bound on reflected supports.
-/
theorem actual_measured_clean_minus_bound {ζ ξ ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (ν : ι → ℕ → ℝ) (A : ι → ℝ) (hA : ∀ i ∈ I, 0 ≤ A i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hνbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ A i / p)
    (s : Finset (ζ × PrimeChoice I groups)) (t : Finset (ξ × PrimeChoice I groups))
    (cutoff : ζ → ξ → ℂ) (det : ζ → ξ → ℝ) (Phi : ℝ → ℂ)
    (Y M : ℝ) (hY : 0 < Y) (hM : 0 ≤ M)
    (hs : ∀ z ∈ s, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (ht : ∀ z ∈ t, Y ≤ (primeChoiceProduct I groups z.2 : ℝ))
    (hplus : FiniteBilinearBound
      ((s.map (labelledStateEmbedding I groups hprime hdisjoint)).map
        (productReflection ζ).toEmbedding)
      ((t.map (labelledStateEmbedding I groups hprime hdisjoint)).map
        (productReflection ξ).toEmbedding)
      (integratedCleanKernel (fun i j => (Y : ℂ)⁻¹ * cutoff i j) det Phi 1) M) :
    FiniteMeasuredBilinearBound s t
      (fun z => primeChoiceMass I groups ν z.2)
      (fun z => primeChoiceMass I groups ν z.2)
      (fun p q => cutoff p.1 q.1 * Phi
        (det p.1 q.1 + (primeChoiceProduct I groups p.2 : ℝ) -
          (primeChoiceProduct I groups q.2 : ℝ)))
      ((∏ i : I, A i) * M) := by
  have h := actualLabel_clean_minus_bound I groups hprime hdisjoint s t
    (fun i j => (Y : ℂ)⁻¹ * cutoff i j) det Phi M hplus
  apply measured_clean_bound_of_normalized_counting s t _ _ _ Y (∏ i : I, A i) M hY
    (Finset.prod_nonneg fun i _ => hA i i.property) hM
    (fun z _ => primeChoiceMass_nonneg I groups ν hν z.2)
    (fun z _ => primeChoiceMass_nonneg I groups ν hν z.2)
    (fun z hz => primeChoiceMass_le_of_product_lower I groups ν A hA hν hνbound
      z.2 Y hY (hs z hz))
    (fun z hz => primeChoiceMass_le_of_product_lower I groups ν A hA hν hνbound
      z.2 Y hY (ht z hz))
  simpa only [mul_assoc] using h

end Elliptic.Operator
