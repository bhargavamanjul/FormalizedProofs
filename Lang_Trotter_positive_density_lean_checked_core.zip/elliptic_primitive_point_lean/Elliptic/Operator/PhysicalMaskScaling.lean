module

public import Elliptic.Operator.PhysicalMaskedSchur

/-!
# Exact fixed-mask coefficient normalization

Reversing a fixed store/promotion mask changes its coefficient by an
explicit finite product of V factors. This factor is independent of the
memory cutoff, active-list length and the scale parameter.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMaskScaling
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {G Z : Type*} [Fintype G]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- Exact coefficient of a specified store/promotion mask. -/
def scalar {R : Type*} [Field R] (store promote : G → R) (S I : G → Bool) : R :=
  ∏ i, store i ^ (S i).toNat * promote i ^ (I i).toNat

theorem grouped_factor {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool)
    (sourceAnchor targetAnchor : ∀ i p, Line i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (P i) (Line i)) → R)
    (s t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) :
    groupedMaskedBagKernel ν store promote S I sourceAnchor targetAnchor sourceDamping targetDamping s t =
    scalar store promote S I *
      groupedMaskedBagKernel ν (fun _ => 1) (fun _ => 1) S I sourceAnchor targetAnchor sourceDamping targetDamping s t := by
  simp only [groupedMaskedBagKernel,maskedDampedBagKernel,one_pow,one_mul,
    Finset.prod_mul_distrib,scalar]

theorem term_factor {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B))
    (π τ : Permutations (G:=G) (J:=J)) :
    term ν store promote S I ρ anchor geometry s t π τ =
      scalar store promote S I * term ν (fun _ => 1) (fun _ => 1) S I ρ anchor geometry s t π τ := by
  by_cases hs : Shared s t π τ
  · simp only [term,ite_eq_left hs]
    rw [grouped_factor ν store promote S I]
    ring
  · simp only [term,ite_eq_right hs,mul_zero]

theorem kernel_factor {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (store promote : G → R) (S I : G → Bool) (ρ : R)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → R)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    kernel ν store promote S I ρ anchor geometry s t =
      scalar store promote S I * kernel ν (fun _ => 1) (fun _ => 1) S I ρ anchor geometry s t := by
  by_cases hs : Total s ∧ Total t
  · simp only [kernel,ite_eq_left hs]
    simp_rw [term_factor ν store promote S I ρ anchor geometry]
    simp only [← Finset.mul_sum]
    ring
  · simp only [kernel,ite_eq_right hs,mul_zero]

/-- The explicit positive adjustment for reversing the original mask. -/
def reverseFactor (V : G → ℝ) (S I : G → Bool) : ℝ :=
  ∏ i, (V i) ^ (I i).toNat / (V i) ^ (S i).toNat

theorem reverseFactor_pos (V : G → ℝ) (hV : ∀ i, 0 < V i) (S I : G → Bool) :
    0 < reverseFactor V S I := by
  unfold reverseFactor
  exact Finset.prod_pos (fun i _ => div_pos (pow_pos (hV i) _) (pow_pos (hV i) _))

/-- Exact reversal coefficient for fixed masks at the original physical
normalization. It is a fixed K-dependent factor, with no B or J loss. -/
theorem reversed_original_kernel
    (ν : ∀ i, P i → ℝ) (V : G → ℝ) (hV : ∀ i, V i ≠ 0)
    (S I : G → Bool) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    kernel (fun i p => (ν i p:ℂ)) (fun i => (V i:ℂ)⁻¹) (fun _ => 1)
      I S (ρ:ℂ) anchor geometry s t =
    (reverseFactor V I S:ℂ) * originalKernel ν V I S ρ anchor geometry s t := by
  unfold originalKernel
  conv_lhs => rw [kernel_factor]
  conv_rhs => arg 2; rw [kernel_factor]
  have hs : scalar (fun i => (V i:ℂ)⁻¹) (fun _ => 1) I S =
      (reverseFactor V I S:ℂ) * scalar (fun _ => (1:ℂ)) (fun i => (V i:ℂ)⁻¹) I S := by
    simp only [scalar,reverseFactor,Complex.ofReal_prod,Complex.ofReal_div,
      Complex.ofReal_pow,one_pow,one_mul,mul_one,← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i _
    have hv : (V i:ℂ) ≠ 0 := by exact_mod_cast hV i
    cases hI : I i <;> cases hS : S i <;> simp [Bool.toNat,hv]
  rw [hs,mul_assoc]

/-- Pointwise measured norm reversal at the original normalization,
with its explicit positive fixed-mask factor. -/
theorem original_norm_balance [Fintype Z]
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (V : G → ℝ) (hV : ∀ i, 0 < V i)
    (S I : G → Bool) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    mass ν s * ‖originalKernel ν V S I ρ anchor geometry s t‖ =
    mass ν t * (reverseFactor V I S *
      ‖originalKernel ν V I S ρ anchor (fun z a w b => geometry w b z a) t s‖) := by
  have hn : ∀ i p, (ν i p:ℂ) ≠ 0 := by intro i p; exact_mod_cast (hν i p).ne'
  have he := congrArg norm (kernel_balance (fun i p => (ν i p:ℂ)) hn
    (fun _ => 1) (fun i => (V i:ℂ)⁻¹) S I (ρ:ℂ) anchor geometry s t)
  rw [reversed_original_kernel ν V (fun i => (hV i).ne') S I] at he
  simp only [mass_complex,norm_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_of_pos (mass_pos ν hν s),abs_of_pos (mass_pos ν hν t),
    abs_of_pos (reverseFactor_pos V hV I S)] at he
  exact he

end Elliptic.Operator.PhysicalMaskScaling
