module

public import Elliptic.Operator.PhysicalDirtyCrude

/-!
# Exact exceptional-coefficient bridge for the actual dirty raw row

Only keys whose distinguished group is maximal can occur. The actual
exceptional physical sum is bounded by its literal exceptional coefficient
sum, with no prime-count factor and no assumed row estimate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyExceptional
open scoped BigOperators
open PhysicalDirtyPartition PhysicalDirtyGoodFiber
attribute [local instance] Classical.propDecidable
local instance exceptionalDirtyDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Canonical physical fibers can only contain keys with maximal
distinguished promoted group. -/
theorem maximal_of_mem_fiber
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (i : Fin K)
    (k : PhysicalDirtyOuter.Key value s i) (c : PhysicalEdgeChoice s)
    (hc : c ∈ fiber value position s good u v r U W d₀ σ i k) :
    ∀ j ∈ keyPromotedGroups value s i k, j ≤ i := by
  have hclass := (Finset.mem_filter.mp hc).2.2
  have hp := (classify_properties value s c i k hclass).2.2.2
  rw [promotedGroups_eq_key value s c i k hclass] at hp
  exact hp

/-- The exceptional physical contribution is zero for impossible keys and
retains the source-test exceptional indicator for all remaining keys. -/
theorem exceptional_fiber_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (i : Fin K) (k : PhysicalDirtyOuter.Key value s i) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ∀ i, PhysicalDirtyOuter.Key value s i → ℝ)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ exceptionalFiber value position s good u v r U W d₀
        (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
        σ δ i k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * (B+1 : ℝ)^K *
        (if (∀ j ∈ keyPromotedGroups value s i k, j ≤ i) ∧
          ¬Separated value s d₀ (latticeTau r w /
            latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) (δ i k) i k
        then PhysicalDirtyOuter.coefficient value s ν V ρ v0 i k else 0) := by
  by_cases ha : ∀ j ∈ keyPromotedGroups value s i k, j ≤ i
  · by_cases hs : Separated value s d₀ (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) (δ i k) i k
    · simp [exceptionalFiber,hs]
    · rw [if_pos ⟨ha,hs⟩]
      simp only [exceptionalFiber,if_neg hs]
      exact PhysicalDirtyCrude.fiber_endpoint_averaged_sum_le value position s hposition ν V ρ v0
        good u v r U W d₀ σ hU i k w hzw hν hV hρ0 hρ1 hv0
  · have he : fiber value position s good u v r U W d₀ σ i k = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro c hc
      exact ha (maximal_of_mem_fiber value position s good u v r U W d₀ σ i k c hc)
    simp [exceptionalFiber,he,ha]

/-- Source exceptional mass is the only remaining input to this finite
coefficient sum. No distribution estimate is assumed in this theorem. -/
theorem exceptional_outer_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (i : Fin K) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ∀ i, PhysicalDirtyOuter.Key value s i → ℝ)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ k : PhysicalDirtyOuter.Key value s i, endpointPermutationWeight (Fin K) J *
      ∑ c ∈ exceptionalFiber value position s good u v r U W d₀
        (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
        σ δ i k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * (B+1 : ℝ)^K *
        ∑ k : PhysicalDirtyOuter.Key value s i,
          if (∀ j ∈ keyPromotedGroups value s i k, j ≤ i) ∧
            ¬Separated value s d₀ (latticeTau r w /
              latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) (δ i k) i k
          then PhysicalDirtyOuter.coefficient value s ν V ρ v0 i k else 0 := by
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum fun k _ => exceptional_fiber_sum_le value position s hposition
    ν V ρ v0 good u v r U W d₀ σ hU i k w hzw δ hν hV hρ0 hρ1 hv0

/-- The complete actual raw dirty row splits into the sharp separated
contribution and the literal exceptional coefficient sum. Both terms are
proved directly from the actual physical choices. -/
theorem actual_row_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin mass : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (δ : ∀ i, PhysicalDirtyOuter.Key value s i → ℝ)
    (hwidth : ∀ i (k : PhysicalDirtyOuter.Key value s i), 2 * (16 / (value i
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i).values k.1).1 : ℝ)) < δ i k)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i)
    (hmin : 0 < vmin) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ rawDirtyChoices value position s good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      (∑ i, (33 * (B * ((1 + v0) * vmin⁻¹ / v0) *
        ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^
          Fintype.card {j : Fin K // j ≠ i})) / (J+1 : ℝ)^K) +
      33 * (B+1 : ℝ)^K * ∑ i, ∑ k : PhysicalDirtyOuter.Key value s i,
        if (∀ j ∈ keyPromotedGroups value s i k, j ≤ i) ∧
          ¬Separated value s d₀ (latticeTau r w /
            latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) (δ i k) i k
        then PhysicalDirtyOuter.coefficient value s ν V ρ v0 i k else 0 := by
  rw [← sum_separated_add_exceptional value position s good u v r U W d₀
    (latticeTau r w / latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))
    σ δ (PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0)]
  rw [mul_add]
  apply add_le_add
  · simp only [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    simpa only [Finset.mul_sum] using separated_outer_sum_le value position s hposition hprime
      ν V ρ v0 vmin mass good u v r U W d₀ σ hU hσ i w hzw δ (hwidth i)
      hν hV hmin hρ0 hρ1 hv0 hmass
  · simp only [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    simpa only [Finset.mul_sum] using exceptional_outer_sum_le value position s hposition
      ν V ρ v0 good u v r U W d₀ σ hU i w hzw δ hν
      (fun i => (hmin.trans_le (hV i)).le) hρ0 hρ1 hv0

end Elliptic.Operator.PhysicalDirtyExceptional
