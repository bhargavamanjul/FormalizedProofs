module

public import Elliptic.Operator.PhysicalPathSupport
public import Elliptic.Operator.SourceHeightBounds
public import Elliptic.Operator.ProjectiveCoordinates

/-!
# The original finite enumeration budget for integer-root replacement

These are the literal position paths, active label lists and two endpoint
permutations, before introducing any memory particles. Their actual finite
cardinality has the finer subexponential budget required in PD Lemma 3.4.
No integer-root equidistribution or replacement theorem is assumed here.
The incomplete inverse-graph count and archimedean partition remain separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.IntegerRootReplacement
open scoped BigOperators
open Filter
open scoped Topology

/-- Enlarged original path records. Every bounded integer position path,
bounded numerical active list and literal pair of endpoint permutations
is such a record; local restrictions only select a subset. -/
abbrev OriginalPathRecord (K M N R Q : ℕ) :=
  (Fin (N+1) → ↥(integerPositionBox R)) ×
    ((Fin (N+1) → Fin K → Fin M → Fin Q) ×
      ((Fin N → Fin K → Equiv.Perm (Fin M)) ×
        (Fin N → Fin K → Equiv.Perm (Fin M))))

/-- Exact cardinality, including both endpoint permutations on every edge. -/
theorem originalPathRecord_card (K M N R Q : ℕ) :
    Fintype.card (OriginalPathRecord K M N R Q) =
      ((2*R+1)^2)^(N+1) * Q^(M*K*(N+1)) * (M.factorial)^(2*K*N) := by
  simp only [OriginalPathRecord,Fintype.card_prod,Fintype.card_fun,
    Fintype.card_coe,integerPositionBox_card,Fintype.card_fin,Fintype.card_perm]
  rw [← pow_mul,← pow_mul,← pow_mul,← pow_mul]
  ring

/-- The coordinate ceiling dictated by the actual source path support. -/
def rootPositionRadius (C L : ℝ) : ℕ :=
  ⌈16 + 4096 * (momentLength L : ℝ) * Real.exp (C * L^(21/100 : ℝ))⌉₊

/-- A finite set containing every numerical prime label in the source bands. -/
def rootPrimeCeiling (L : ℝ) : ℕ := ⌊Real.exp (2 * L^(1/5 : ℝ))⌋₊ + 1

theorem label_lt_rootPrimeCeiling (L : ℝ) (p : ℕ)
    (hp : (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) : p < rootPrimeCeiling L := by
  have hh : p ≤ ⌊Real.exp (2*L^(1/5:ℝ))⌋₊ := (Nat.le_floor_iff (Real.exp_pos _).le).mpr hp
  exact Nat.lt_succ_of_le hh

/-- Nonzero supported source paths already proved to obey the determinant
height fit into this original-record position set. -/
theorem path_mem_rootPositionRadius (C L : ℝ) (z : ℕ → ℤ × ℤ) (r H : ℝ)
    (hH : 0≤H) (hr : |r|≤1) (hstart : z 0=(1,0))
    (htau : ∀ j≤momentLength L,1/16≤latticeTau r (z j) ∧ latticeTau r (z j)≤16)
    (hdet : ∀ j<momentLength L, |(latticeDet (z j) (z (j+1)):ℝ)|≤H)
    (hheight : H ≤ Real.exp (C*L^(21/100:ℝ))) (j : ℕ) (hj : j≤momentLength L) :
    z j ∈ integerPositionBox (rootPositionRadius C L) := by
  have hc := physical_path_coordinates z r H (momentLength L) hH hr hstart htau hdet j hj
  have he := Nat.le_ceil (16+4096*(momentLength L:ℝ)*Real.exp (C*L^(21/100:ℝ)))
  have hh := mul_le_mul_of_nonneg_left hheight (show 0≤4096*(momentLength L:ℝ) by positivity)
  apply mem_integerPositionBox_of_abs <;> change _ ≤ (⌈16+4096*(momentLength L:ℝ)*Real.exp (C*L^(21/100:ℝ))⌉₊:ℝ)
  · linarith [hc.2]
  · exact hc.1.trans ((by linarith : 4096*(momentLength L:ℝ)*H ≤
        16+4096*(momentLength L:ℝ)*Real.exp (C*L^(21/100:ℝ))).trans he)

/-- Elementary exponential bound for an entire original finite record
space. The position, label and slot costs are all charged explicitly. -/
theorem originalPathRecord_card_le_exp (K M N R Q : ℕ) (A L : ℝ)
    (hL : 1≤L) (hA : 0≤A)
    (hpos : ((2*R+1:ℕ):ℝ)^2 ≤ Real.exp (A*L^(21/100:ℝ)))
    (hlabel : (Q:ℝ) ≤ Real.exp (3*L^(1/5:ℝ)))
    (hM : (M:ℝ) ≤ 2*L^(1/100:ℝ))
    (hN : (N:ℝ)+1 ≤ 4*L^(1/2:ℝ))
    (hMf : (M:ℝ) ≤ Real.exp (L^(1/5:ℝ))) :
    (Fintype.card (OriginalPathRecord K M N R Q):ℝ) ≤
      Real.exp ((4*A+40*K)*L^(71/100:ℝ)) := by
  have hLpos : 0<L := by linarith
  have hfact : (M.factorial:ℝ) ≤ Real.exp ((M:ℝ)*L^(1/5:ℝ)) := by
    calc
      _ ≤ (M:ℝ)^M := by exact_mod_cast Nat.factorial_le_pow M
      _ ≤ (Real.exp (L^(1/5:ℝ)))^M := pow_le_pow_left₀ (Nat.cast_nonneg _) hMf M
      _ = _ := (Real.exp_nat_mul _ _).symm
  have hp := pow_le_pow_left₀ (show 0≤((2*R+1:ℕ):ℝ)^2 by positivity) hpos (N+1)
  have hq := pow_le_pow_left₀ (Nat.cast_nonneg Q) hlabel (M*K*(N+1))
  have hf := pow_le_pow_left₀ (Nat.cast_nonneg M.factorial) hfact (2*K*N)
  have h51 : L^(1/100:ℝ)*L^(1/2:ℝ) = L^(51/100:ℝ) := by rw [←Real.rpow_add hLpos]; norm_num
  have h71 : L^(51/100:ℝ)*L^(1/5:ℝ) = L^(71/100:ℝ) := by rw [←Real.rpow_add hLpos]; norm_num
  have hposition : ((N:ℝ)+1)*(A*L^(21/100:ℝ)) ≤ 4*A*L^(71/100:ℝ) := by
    have hh := mul_le_mul_of_nonneg_right hN (show 0≤A*L^(21/100:ℝ) by positivity)
    have he : L^(1/2:ℝ)*L^(21/100:ℝ)=L^(71/100:ℝ) := by rw [←Real.rpow_add hLpos]; norm_num
    nlinarith [he]
  have hMN : (M:ℝ)*((N:ℝ)+1) ≤ 8*L^(51/100:ℝ) := by
    have hh := mul_le_mul hM hN (by positivity : 0≤(N:ℝ)+1) (by positivity : 0≤2*L^(1/100:ℝ))
    nlinarith [h51]
  have hlabelcost : ((M:ℝ)*K*((N:ℝ)+1))*(3*L^(1/5:ℝ)) ≤ 24*K*L^(71/100:ℝ) := by
    have hh := mul_le_mul_of_nonneg_right hMN (show 0≤3*(K:ℝ)*L^(1/5:ℝ) by positivity)
    nlinarith [h71]
  have hpermcost : (2*(K:ℝ)*N)*((M:ℝ)*L^(1/5:ℝ)) ≤ 16*K*L^(71/100:ℝ) := by
    have hMN' : (M:ℝ)*N ≤ 8*L^(51/100:ℝ) := by nlinarith [show (0:ℝ)≤M by positivity]
    have hh := mul_le_mul_of_nonneg_right hMN' (show 0≤2*(K:ℝ)*L^(1/5:ℝ) by positivity)
    nlinarith [h71]
  push_cast at hp
  rw [originalPathRecord_card]
  push_cast
  calc
    _ ≤ (Real.exp (A*L^(21/100:ℝ)))^(N+1) *
        (Real.exp (3*L^(1/5:ℝ)))^(M*K*(N+1)) *
        (Real.exp ((M:ℝ)*L^(1/5:ℝ)))^(2*K*N) := by
      exact mul_le_mul (mul_le_mul hp hq (by positivity) (by positivity)) hf (by positivity) (by positivity)
    _ = Real.exp (((N:ℝ)+1)*(A*L^(21/100:ℝ)) +
        ((M:ℝ)*K*((N:ℝ)+1))*(3*L^(1/5:ℝ)) +
        (2*(K:ℝ)*N)*((M:ℝ)*L^(1/5:ℝ))) := by
      simp only [←Real.exp_nat_mul,←Real.exp_add]
      congr 1
      push_cast
      ring
    _ ≤ _ := Real.exp_le_exp.mpr (by nlinarith)

/-- The literal moment length has its square-root scale even after adding
one visit; the extra factor is absolute. -/
theorem momentLength_add_one_le (L : ℝ) (hL : 1≤L) :
    (momentLength L:ℝ)+1 ≤ 4*L^(1/2:ℝ) := by
  have h := momentLength_upper (by linarith : 0≤L)
  have hp : 1≤L^(1/2:ℝ) := Real.one_le_rpow hL (by norm_num)
  linarith

/-- The rounded numerical prime pool has the source's exponential scale. -/
theorem rootPrimeCeiling_le_exp (L : ℝ)
    (hb : Real.log 2 ≤ L^(1/5:ℝ)) :
    (rootPrimeCeiling L:ℝ) ≤ Real.exp (3*L^(1/5:ℝ)) := by
  have he : 2 ≤ Real.exp (L^(1/5:ℝ)) := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ)<2)] using Real.exp_le_exp.mpr hb
  have hpos : 0≤L^(1/5:ℝ) := (Real.log_nonneg (by norm_num : (1:ℝ)≤2)).trans hb
  have hunit : 1 ≤ Real.exp (2*L^(1/5:ℝ)) := Real.one_le_exp (by positivity)
  have hf := Nat.floor_le (Real.exp_pos (2*L^(1/5:ℝ))).le
  unfold rootPrimeCeiling
  push_cast
  calc
    _ ≤ 2*Real.exp (2*L^(1/5:ℝ)) := by linarith
    _ ≤ Real.exp (L^(1/5:ℝ))*Real.exp (2*L^(1/5:ℝ)) :=
      mul_le_mul_of_nonneg_right he (Real.exp_pos _).le
    _ = _ := by rw [←Real.exp_add]; congr 1; ring

/-- The actual coordinate radius has logarithm of order L^.21. This
charges its square-root moment factor and the integer rounding explicitly. -/
theorem rootPositionRadius_square_le_exp (C L : ℝ) (hC : 0≤C) (hL : 1≤L)
    (hlog : Real.log L ≤ L^(21/100:ℝ))
    (hconstant : Real.log 8227 ≤ L^(21/100:ℝ)) :
    ((2*rootPositionRadius C L+1:ℕ):ℝ)^2 ≤
      Real.exp ((2*C+6)*L^(21/100:ℝ)) := by
  have hLpos : 0<L := by linarith
  let a := L^(21/100:ℝ)
  have ha : 0≤a := by dsimp [a]; positivity
  have hbig : (8227:ℝ)≤Real.exp a := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ)<8227)] using Real.exp_le_exp.mpr hconstant
  have hsqrt : L^(1/2:ℝ)≤Real.exp a := by
    rw [Real.rpow_def_of_pos hLpos]
    apply Real.exp_le_exp.mpr
    have hlogpos := Real.log_nonneg hL
    dsimp [a] at *
    linarith
  have hn : (momentLength L:ℝ)≤Real.exp (2*a) := by
    have hn0 := momentLength_add_one_le L hL
    have hn1 : (momentLength L:ℝ)≤3*L^(1/2:ℝ) := by
      have hh := momentLength_upper hLpos.le
      have hp := Real.one_le_rpow hL (show (0:ℝ)≤1/2 by norm_num)
      linarith
    calc
      _ ≤ 3*L^(1/2:ℝ) := hn1
      _ ≤ Real.exp a*Real.exp a := mul_le_mul (by linarith : (3:ℝ)≤Real.exp a) hsqrt (by positivity) (Real.exp_pos _).le
      _ = _ := by rw [←Real.exp_add]; congr 1; ring
  have hr : (rootPositionRadius C L:ℝ) ≤ 17+4096*Real.exp ((C+2)*a) := by
    have hc := (Nat.ceil_lt_add_one (show 0≤16+4096*(momentLength L:ℝ)*Real.exp (C*a) by positivity)).le
    have hm := mul_le_mul_of_nonneg_right hn (show 0≤4096*Real.exp (C*a) by positivity)
    have he : Real.exp (2*a)*Real.exp (C*a)=Real.exp ((C+2)*a) := by
      rw [←Real.exp_add]; congr 1; ring
    change (⌈16+4096*(momentLength L:ℝ)*Real.exp (C*a)⌉₊:ℝ)≤_
    nlinarith [he]
  have hunit : 1≤Real.exp ((C+2)*a) := Real.one_le_exp (by positivity)
  have hside : 2*(rootPositionRadius C L:ℝ)+1 ≤ Real.exp ((C+3)*a) := by
    calc
      _ ≤ 8227*Real.exp ((C+2)*a) := by linarith
      _ ≤ Real.exp a*Real.exp ((C+2)*a) := mul_le_mul_of_nonneg_right hbig (Real.exp_pos _).le
      _ = _ := by rw [←Real.exp_add]; congr 1; ring
  push_cast
  calc
    _ ≤ (Real.exp ((C+3)*a))^2 := pow_le_pow_left₀ (by positivity) hside 2
    _ = _ := by rw [←Real.exp_nat_mul]; congr 1; dsimp [a]; ring

/-- All fixed constants are chosen before L. The resulting bound concerns
the actual enlarged original records, and remains valid for any selected
subset of physical records. No memory-birth count enters this estimate. -/
theorem eventually_originalPathRecord_card_le (K : ℕ) (C : ℝ) (hC : 0≤C) :
    ∀ᶠ L : ℝ in atTop,
      (Fintype.card (OriginalPathRecord K (momentMultiplicity L) (momentLength L)
        (rootPositionRadius C L) (rootPrimeCeiling L)):ℝ) ≤
          Real.exp ((8*C+24+40*K)*L^(71/100:ℝ)) := by
  have hlog20 := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<1/5)).bound (by norm_num : (0:ℝ)<1)
  have hlog21 := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<21/100)).bound (by norm_num : (0:ℝ)<1)
  have hc20 := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/5)).eventually (eventually_ge_atTop (2*Real.log 2))
  have hc21 := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<21/100)).eventually (eventually_ge_atTop (Real.log 8227))
  filter_upwards [eventually_ge_atTop (1:ℝ),hlog20,hlog21,hc20,hc21] with L hL hl20 hl21 hc20 hc21
  have hLpos : 0<L := by linarith
  have hlogpos := Real.log_nonneg hL
  have hp20 : 0≤L^(1/5:ℝ) := by positivity
  have hp21 : 0≤L^(21/100:ℝ) := by positivity
  simp only [Real.norm_eq_abs,abs_of_nonneg hlogpos,abs_of_nonneg hp20,one_mul] at hl20
  simp only [Real.norm_eq_abs,abs_of_nonneg hlogpos,abs_of_nonneg hp21,one_mul] at hl21
  have hm := momentMultiplicity_le_two_rpow hL
  have hmf : (momentMultiplicity L:ℝ)≤Real.exp (L^(1/5:ℝ)) := by
    calc
      _ ≤ 2*L^(1/100:ℝ) := hm
      _ = Real.exp (Real.log 2 + Real.log L*(1/100:ℝ)) := by
        rw [Real.exp_add,Real.exp_log (by norm_num : (0:ℝ)<2),Real.rpow_def_of_pos hLpos]
      _ ≤ _ := Real.exp_le_exp.mpr (by linarith)
  have he := originalPathRecord_card_le_exp K (momentMultiplicity L) (momentLength L)
    (rootPositionRadius C L) (rootPrimeCeiling L) (2*C+6) L hL (by positivity)
    (rootPositionRadius_square_le_exp C L hC hL hl21 hc21)
    (rootPrimeCeiling_le_exp L (by linarith)) hm (momentLength_add_one_le L hL) hmf
  convert he using 1
  congr 2
  ring

/-- In particular the finer source budget exp(O_K(L^.73)) is achieved
by the original records, with a threshold uniform over every record. -/
theorem eventually_originalPathRecord_card_le_source_budget (K : ℕ) (C : ℝ) (hC : 0≤C) :
    ∀ᶠ L : ℝ in atTop,
      (Fintype.card (OriginalPathRecord K (momentMultiplicity L) (momentLength L)
        (rootPositionRadius C L) (rootPrimeCeiling L)):ℝ) ≤ Real.exp (L^(73/100:ℝ)) := by
  have hc := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<2/100)).eventually
    (eventually_ge_atTop (8*C+24+40*K))
  filter_upwards [eventually_originalPathRecord_card_le K C hC,eventually_gt_atTop (0:ℝ),hc] with L h hL hc
  apply h.trans
  apply Real.exp_le_exp.mpr
  have hm := mul_le_mul_of_nonneg_right hc (show 0≤L^(71/100:ℝ) by positivity)
  have he : L^(2/100:ℝ)*L^(71/100:ℝ)=L^(73/100:ℝ) := by
    rw [←Real.rpow_add hL]; norm_num
  simpa only [he] using hm

/-- The numerical prime values active anywhere on the original path.
Repeated uses contribute only once to this set and its CRT modulus. -/
def activePrimeSet {K M N : ℕ} (labels : Fin (N+1) → Fin K → Fin M → ℕ) : Finset ℕ :=
  Finset.univ.image (fun t : Fin (N+1) × (Fin K × Fin M) => labels t.1 t.2.1 t.2.2)

theorem activePrimeSet_card_le {K M N : ℕ}
    (labels : Fin (N+1) → Fin K → Fin M → ℕ) :
    (activePrimeSet labels).card ≤ M*K*(N+1) := by
  have h := Finset.card_image_le (s:=Finset.univ)
    (f:=fun t : Fin (N+1) × (Fin K × Fin M) => labels t.1 t.2.1 t.2.2)
  simpa only [activePrimeSet,Finset.card_univ,Fintype.card_prod,Fintype.card_fin,
    Nat.mul_comm,Nat.mul_left_comm] using h

/-- A finite modulus built from bounded numerical primes is bounded by
its number of distinct factors, regardless of how often a path uses them. -/
theorem primeSet_product_le_exp (S : Finset ℕ) (β : ℝ)
    (hv : ∀ p∈S, (p:ℝ)≤Real.exp β) :
    ((∏ p∈S,p):ℝ) ≤ Real.exp ((S.card:ℝ)*β) := by
  calc
    _ ≤ ∏ _p∈S, Real.exp β := Finset.prod_le_prod₀ (fun p _ => Nat.cast_nonneg p) hv
    _ = _ := by rw [Finset.prod_const,←Real.exp_nat_mul]

/-- Actual original active labels satisfy the finer L^.71 log-product
bound, before any inactive-prime truncation is performed. -/
theorem activePrimeSet_product_le (K : ℕ) (L : ℝ) (hL : 1≤L)
    (labels : Fin (momentLength L+1) → Fin K → Fin (momentMultiplicity L) → ℕ)
    (hv : ∀ j i a, (labels j i a:ℝ)≤Real.exp (2*L^(1/5:ℝ))) :
    ((∏ p∈activePrimeSet labels,p):ℝ) ≤ Real.exp (16*K*L^(71/100:ℝ)) := by
  have hLpos : 0<L := by linarith
  have hp := primeSet_product_le_exp (activePrimeSet labels) (2*L^(1/5:ℝ)) (by
    intro p hp
    obtain ⟨t,_,rfl⟩ := Finset.mem_image.mp hp
    exact hv t.1 t.2.1 t.2.2)
  have hc : ((activePrimeSet labels).card:ℝ)≤(momentMultiplicity L:ℝ)*K*((momentLength L:ℝ)+1) := by
    exact_mod_cast activePrimeSet_card_le labels
  have hm := momentMultiplicity_le_two_rpow hL
  have hn := momentLength_add_one_le L hL
  have hmn := mul_le_mul hm hn (by positivity : 0≤(momentLength L:ℝ)+1)
    (by positivity : 0≤2*L^(1/100:ℝ))
  have he : L^(1/100:ℝ)*L^(1/2:ℝ)*L^(1/5:ℝ)=L^(71/100:ℝ) := by
    rw [←Real.rpow_add hLpos,←Real.rpow_add hLpos]; norm_num
  have hcost := mul_le_mul_of_nonneg_right hmn (show 0≤2*(K:ℝ)*L^(1/5:ℝ) by positivity)
  apply hp.trans
  apply Real.exp_le_exp.mpr
  have hc' := mul_le_mul_of_nonneg_right hc (show 0≤2*L^(1/5:ℝ) by positivity)
  nlinarith [he]

/-- Bonferroni monomials retain the source modulus range: the active
primes together with at most ceil(L^.76) further bounded primes have
logarithmic modulus at most (16K+4)L^.96. -/
theorem truncated_root_modulus_le (K : ℕ) (L : ℝ) (hL : 1≤L)
    (labels : Fin (momentLength L+1) → Fin K → Fin (momentMultiplicity L) → ℕ)
    (extra : Finset ℕ)
    (hv : ∀ j i a, (labels j i a:ℝ)≤Real.exp (2*L^(1/5:ℝ)))
    (he : ∀ p∈extra, (p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))
    (hcard : extra.card≤⌈L^(76/100:ℝ)⌉₊) :
    ((∏ p∈activePrimeSet labels ∪ extra,p):ℝ) ≤ Real.exp ((16*K+4)*L^(96/100:ℝ)) := by
  have hLpos : 0<L := by linarith
  have hpow : 1≤L^(76/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hceil := (Nat.ceil_lt_add_one (show 0≤L^(76/100:ℝ) by positivity)).le
  have hcard' : (extra.card:ℝ)≤2*L^(76/100:ℝ) := by
    have hc : (extra.card:ℝ)≤(⌈L^(76/100:ℝ)⌉₊:ℝ) := by exact_mod_cast hcard
    linarith
  have hset := primeSet_product_le_exp (activePrimeSet labels ∪ extra) (2*L^(1/5:ℝ)) (by
    intro p hp
    rcases Finset.mem_union.mp hp with hp | hp
    · obtain ⟨t,_,rfl⟩ := Finset.mem_image.mp hp
      exact hv t.1 t.2.1 t.2.2
    · exact he p hp)
  have hactivecard : ((activePrimeSet labels).card:ℝ)≤(momentMultiplicity L:ℝ)*K*((momentLength L:ℝ)+1) := by
    exact_mod_cast activePrimeSet_card_le labels
  have hmn := mul_le_mul (momentMultiplicity_le_two_rpow hL) (momentLength_add_one_le L hL)
    (by positivity : 0≤(momentLength L:ℝ)+1) (by positivity : 0≤2*L^(1/100:ℝ))
  have hcomb : ((activePrimeSet labels ∪ extra).card:ℝ)≤
      (momentMultiplicity L:ℝ)*K*((momentLength L:ℝ)+1)+2*L^(76/100:ℝ) := by
    have hc : ((activePrimeSet labels ∪ extra).card:ℝ)≤
        ((activePrimeSet labels).card:ℝ)+(extra.card:ℝ) := by
      exact_mod_cast Finset.card_union_le (activePrimeSet labels) extra
    linarith
  have hcost := mul_le_mul_of_nonneg_right hcomb (show 0≤2*L^(1/5:ℝ) by positivity)
  have hmcost := mul_le_mul_of_nonneg_right hmn (show 0≤2*(K:ℝ)*L^(1/5:ℝ) by positivity)
  have he1 : L^(1/100:ℝ)*L^(1/2:ℝ)*L^(1/5:ℝ)=L^(71/100:ℝ) := by
    rw [←Real.rpow_add hLpos,←Real.rpow_add hLpos]; norm_num
  have he2 : L^(76/100:ℝ)*L^(1/5:ℝ)=L^(96/100:ℝ) := by
    rw [←Real.rpow_add hLpos]; norm_num
  have hle := Real.rpow_le_rpow_of_exponent_le hL (show (71/100:ℝ)≤96/100 by norm_num)
  have hle' := mul_le_mul_of_nonneg_left hle (show 0≤16*(K:ℝ) by positivity)
  apply hset.trans
  apply Real.exp_le_exp.mpr
  nlinarith [he1,he2]

end Elliptic.Operator.IntegerRootReplacement
