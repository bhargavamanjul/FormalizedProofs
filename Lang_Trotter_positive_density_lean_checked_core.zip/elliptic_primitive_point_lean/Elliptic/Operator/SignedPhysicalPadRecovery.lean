module
public import Elliptic.Operator.SignedPhysicalPadReindex

/-! Quantitative recovery of the unpadded scalar pair sum from the literal
ban-filtered harmonic padding, with an absolute-sum error. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open SignedPhysicalPadMass
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {K J : ℕ} {P : Fin K→Type*} [∀i,Fintype (P i)]

def crossPadMass (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (a b : ∀i,P i) : ℝ :=
  ∑pads : ∀i,Fin J→P i,
    if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then orderedWeight μ pads else 0

theorem crossPadMass_eq (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (μ : ∀i,P i→ℝ) (a b : ∀i,P i) :
    crossPadMass (J:=J) value μ a b=if (∀i,a i≠b i) then allowedMass (J:=J) μ a b else 0 := by
  unfold crossPadMass allowedMass
  simp_rw [crossEdgeBan_assembled_iff value hinj]
  by_cases hab : ∀i,a i≠b i <;> simp [hab]
  apply Finset.sum_congr (by ext; simp)
  intro pads hpads
  rfl

theorem allowedMass_bounds (μ : ∀i,P i→ℝ) (hμ0 : ∀i p,0≤μ i p)
    (hμ : ∀i,∑p,μ i p=1) (a b : ∀i,P i) :
    0≤allowedMass (J:=J) μ a b ∧ allowedMass (J:=J) μ a b≤1 := by
  rw [allowedMass_eq_product]
  have hb i := goodPadMass_bounds J (μ i) (hμ0 i) (hμ i) (a i) (b i)
  exact ⟨Finset.prod_nonneg (fun i _=>(hb i).1),
    Finset.prod_le_one₀ (fun i _=>(hb i).1) (fun i _=>(hb i).2)⟩

theorem fresh_products_coprime_iff (value : ∀i,P i→ℕ)
    (hp : ∀i p,(value i p).Prime)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2)) (a b : ∀i,P i) :
    (∏i,value i (a i)).Coprime (∏i,value i (b i)) ↔ ∀i,a i≠b i := by
  constructor
  · intro hc i he
    have hda : value i (a i)∣∏j,value j (a j) := Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
    have hdb : value i (a i)∣∏j,value j (b j) := he ▸ Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
    have hh := Nat.dvd_gcd hda hdb
    rw [hc.gcd_eq_one] at hh
    have hle := Nat.le_of_dvd (by norm_num : 0<1) hh
    have hgt := (hp i (a i)).one_lt
    omega
  · intro hab
    apply Nat.Coprime.prod_left
    intro i hi
    apply Nat.Coprime.prod_right
    intro j hj
    apply (Nat.coprime_primes (hp i _) (hp j _)).mpr
    intro he
    have hh := hinj (a₁:=⟨i,a i⟩) (a₂:=⟨j,b j⟩) he
    obtain ⟨hij,hij'⟩ := Sigma.mk.inj_iff.mp hh
    subst j
    exact hab i (eq_of_heq hij')

/-- Exact finite pad summation before applying its mass bounds. -/
theorem sum_padded_eq_crossPadMass (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (F : (∀i,P i)→(∀i,P i)→ℂ) :
    (∑pads : ∀i,Fin J→P i,∑a : ∀i,P i,∑b : ∀i,P i,
      if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
        (orderedWeight μ pads:ℂ)*F a b else 0)=
    ∑a : ∀i,P i,∑b : ∀i,P i,(crossPadMass (J:=J) value μ a b:ℂ)*F a b := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  simp only [crossPadMass,Complex.ofReal_sum,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro pads hpad
  split_ifs <;> simp

/-- Concrete pad recovery. The error is the lost pad mass times the
absolute scalar pair sum, never an unweighted worst-case count. -/
theorem pad_recovery_norm_le (value : ∀i,P i→ℕ)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (μ : ∀i,P i→ℝ) (hμ0 : ∀i p,0≤μ i p) (hμ : ∀i,∑p,μ i p=1)
    (δ : ℝ) (hδ : 0≤δ) (hatom : ∀i p,μ i p≤δ)
    (F : (∀i,P i)→(∀i,P i)→ℂ) :
    ‖(∑a : ∀i,P i,∑b : ∀i,P i,if (∀i,a i≠b i) then F a b else 0)-
      (∑pads : ∀i,Fin J→P i,∑a : ∀i,P i,∑b : ∀i,P i,
        if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
          (orderedWeight μ pads:ℂ)*F a b else 0)‖≤
    (K:ℝ)*((J:ℝ)*(J+3)/2)*δ*
      ∑a : ∀i,P i,∑b : ∀i,P i,if (∀i,a i≠b i) then ‖F a b‖ else 0 := by
  rw [sum_padded_eq_crossPadMass,←Finset.sum_sub_distrib]
  simp_rw [←Finset.sum_sub_distrib]
  apply (norm_sum_le _ _).trans
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro a ha
  apply (norm_sum_le _ _).trans
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro b hb
  rw [crossPadMass_eq value hinj]
  by_cases hab : ∀i,a i≠b i
  · simp only [ite_eq_left hab]
    have hbnd := allowedMass_bounds (J:=J) μ hμ0 hμ a b
    have hlo := allowedMass_lower (J:=J) μ hμ0 hμ δ hδ hatom a b
    simp only [Fintype.card_fin] at hlo
    have he : F a b-(allowedMass (J:=J) μ a b:ℂ)*F a b=
        ((1-allowedMass (J:=J) μ a b:ℝ):ℂ)*F a b := by push_cast; ring
    rw [he,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (sub_nonneg.mpr hbnd.2)]
    exact mul_le_mul_of_nonneg_right (by linarith) (norm_nonneg _)
  · simp [hab]

/-- The source's coprime fresh-product restriction is exactly the
fresh-label event in the concrete pad recovery estimate. -/
theorem coprime_pad_recovery_norm_le (value : ∀i,P i→ℕ)
    (hp : ∀i p,(value i p).Prime)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    (μ : ∀i,P i→ℝ) (hμ0 : ∀i p,0≤μ i p) (hμ : ∀i,∑p,μ i p=1)
    (δ : ℝ) (hδ : 0≤δ) (hatom : ∀i p,μ i p≤δ)
    (F : (∀i,P i)→(∀i,P i)→ℂ) :
    ‖(∑a : ∀i,P i,∑b : ∀i,P i,
        if (∏i,value i (a i)).Coprime (∏i,value i (b i)) then F a b else 0)-
      (∑pads : ∀i,Fin J→P i,∑a : ∀i,P i,∑b : ∀i,P i,
        if sourceCrossEdgeBan value (assembledLists pads a) (assembledLists pads b) then
          (orderedWeight μ pads:ℂ)*F a b else 0)‖≤
    (K:ℝ)*((J:ℝ)*(J+3)/2)*δ*
      ∑a : ∀i,P i,∑b : ∀i,P i,
        if (∏i,value i (a i)).Coprime (∏i,value i (b i)) then ‖F a b‖ else 0 := by
  simpa only [fresh_products_coprime_iff value hp hinj] using
    pad_recovery_norm_le (J:=J) value hinj μ hμ0 hμ δ hδ hatom F

end Elliptic.Operator.SignedPhysicalPairBridge
