module

public import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
public import Mathlib.GroupTheory.Perm.Cycle.Type
public import Lean.Elab.Tactic.Omega
public import Mathlib.Tactic.Ring

/-!
# Exact restoration of distinct performed birth values

This file proves the signed-permutation form of the identity in equation
(4.44) of the prime-predecessor paper. An unperformed address is represented
by `none`; it must be fixed, and no prime value is assigned to it. Performed
addresses may only be permuted among equal values. The sign sum is exactly
the distinctness indicator, by the determinant of the equality matrix.

The cycle rank is the sum of `length-1` over the nontrivial cycles. Its
support bound proves that a rank-r constraint modifies at most 2r addresses
and hence at most 2r operations. The factorial regrouping by unordered cycle
supports and the analytic estimates for the memory operators are separate.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators

attribute [local instance] Classical.propDecidable

/-- A finite permutation's integer sign. -/
def permutationSign {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) : ℤ := (Equiv.Perm.sign σ : ℤ)

/-- The exact alternating sum of the permutations preserving any labels.
Repeated labels give identical rows in the equality matrix, so their
contribution vanishes. This is an identity, not a distinctness estimate. -/
theorem signed_permutations_preserving_labels
    {α β : Type*} [Fintype α] [DecidableEq α]
    (label : α → β) :
    (∑ σ : Equiv.Perm α,
      if ∀ a, label (σ a) = label a then permutationSign σ else 0) =
      if Function.Injective label then 1 else 0 := by
  classical
  let M : Matrix α α ℤ := fun a b => if label a = label b then 1 else 0
  have hexpand : M.det = ∑ σ : Equiv.Perm α,
      if ∀ a, label (σ a) = label a then permutationSign σ else 0 := by
    rw [Matrix.det_apply']
    apply Finset.sum_congr rfl
    intro σ _
    simp only [M, Fintype.prod_boole, mul_ite, mul_one, mul_zero]
    rfl
  rw [← hexpand]
  by_cases h : Function.Injective label
  · rw [ite_eq_left h]
    have hM : M = 1 := by
      ext a b
      simp only [M, Matrix.one_apply, h.eq_iff]
    rw [hM, Matrix.det_one]
  · rw [ite_eq_right h]
    obtain ⟨a, b, heq, hne⟩ : ∃ a b, label a = label b ∧ a ≠ b := by
      simpa only [Function.Injective, not_forall, exists_prop] using h
    apply Matrix.det_zero_of_row_eq hne
    funext c
    simp only [M, heq]

/-- An unperformed address is given its own address tag, not a prime value.
Performed addresses receive the value tag. -/
def effectiveBirthLabel {α β : Type*} (birth : α → Option β) (a : α) : α ⊕ β :=
  match birth a with
  | none => Sum.inl a
  | some b => Sum.inr b

/-- Pairwise distinctness is imposed only on actual performed births. -/
def BirthsDistinct {α β : Type*} (birth : α → Option β) : Prop :=
  ∀ a b v, birth a = some v → birth b = some v → a = b

/-- The exact admissible permutation condition, including local performed
flags: unperformed addresses are fixed. -/
def BirthPreserving {α β : Type*} (birth : α → Option β) (σ : Equiv.Perm α) : Prop :=
  (∀ a, birth (σ a) = birth a) ∧ (∀ a, birth a = none → σ a = a)

theorem effectiveBirthLabel_injective_iff {α β : Type*} (birth : α → Option β) :
    Function.Injective (effectiveBirthLabel birth) ↔ BirthsDistinct birth := by
  constructor
  · intro h a b v ha hb
    apply h
    simp only [effectiveBirthLabel, ha, hb]
  · intro h a b heq
    cases ha : birth a with
    | none =>
      cases hb : birth b with
      | none => simpa only [effectiveBirthLabel, ha, hb, Sum.inl.injEq] using heq
      | some v => simp only [effectiveBirthLabel, ha, hb, Sum.inl_ne_inr] at heq
    | some v =>
      cases hb : birth b with
      | none => simp only [effectiveBirthLabel, ha, hb, Sum.inr_ne_inl] at heq
      | some w =>
        have hvw : v = w := by simpa only [effectiveBirthLabel, ha, hb, Sum.inr.injEq] using heq
        exact h a b v ha (by simpa only [hvw] using hb)

theorem birthPreserving_iff_effectiveLabel {α β : Type*}
    (birth : α → Option β) (σ : Equiv.Perm α) :
    BirthPreserving birth σ ↔ ∀ a, effectiveBirthLabel birth (σ a) = effectiveBirthLabel birth a := by
  constructor
  · rintro ⟨hvalue, hflag⟩ a
    cases ha : birth a with
    | none => rw [hflag a ha]
    | some v => simp only [effectiveBirthLabel, hvalue a, ha]
  · intro h
    constructor
    · intro a
      have heq := h a
      cases ha : birth a <;> cases hb : birth (σ a) <;>
        simp_all [effectiveBirthLabel]
    · intro a ha
      have heq := h a
      cases hb : birth (σ a) <;> simp_all [effectiveBirthLabel]

/-- Source (4.44), in its exact signed-permutation form. The blocks of its
printed version are the nontrivial cycle supports of these permutations. -/
theorem birth_distinctness_identity {α β : Type*} [Fintype α] [DecidableEq α]
    (birth : α → Option β) :
    (∑ σ : Equiv.Perm α, if BirthPreserving birth σ then permutationSign σ else 0) =
      if BirthsDistinct birth then 1 else 0 := by
  classical
  simpa only [← birthPreserving_iff_effectiveLabel, effectiveBirthLabel_injective_iff] using
    signed_permutations_preserving_labels (effectiveBirthLabel birth)

/-- The integer identity transported to any coefficient ring. -/
theorem birth_distinctness_identity_cast {α β R : Type*}
    [Fintype α] [DecidableEq α] [CommRing R] (birth : α → Option β) :
    (∑ σ : Equiv.Perm α, if BirthPreserving birth σ then (permutationSign σ : R) else 0) =
      if BirthsDistinct birth then 1 else 0 := by
  have h := congrArg (fun z : ℤ => (z : R)) (birth_distinctness_identity birth)
  simpa only [Int.cast_sum, Int.cast_ite, Int.cast_zero, Int.cast_one] using h

/-- Restoring distinctness inside an arbitrary finite weighted history sum
is exact. No norm, absolute value, or operator estimate has been inserted. -/
theorem weighted_birth_distinctness_expansion {α β H R : Type*}
    [Fintype α] [DecidableEq α] [CommRing R]
    (histories : Finset H) (birth : H → α → Option β) (weight : H → R) :
    (∑ h ∈ histories, if BirthsDistinct (birth h) then weight h else 0) =
      ∑ σ : Equiv.Perm α, (permutationSign σ : R) *
        ∑ h ∈ histories, if BirthPreserving (birth h) σ then weight h else 0 := by
  calc
    _ = ∑ h ∈ histories, (if BirthsDistinct (birth h) then (1 : R) else 0) * weight h := by
      apply Finset.sum_congr rfl
      intro h _
      split_ifs <;> simp
    _ = ∑ h ∈ histories,
        (∑ σ : Equiv.Perm α,
          if BirthPreserving (birth h) σ then (permutationSign σ : R) else 0) * weight h := by
      simp_rw [birth_distinctness_identity_cast]
    _ = _ := by
      simp_rw [Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro σ _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro h _
      split_ifs <;> simp

/-- Each moved address must be performed and carry the same value as its
successor in the permutation. Fixed addresses impose no condition. -/
theorem birthPreserving_iff_moved_equalities {α β : Type*}
    [Fintype α] [DecidableEq α] (birth : α → Option β) (σ : Equiv.Perm α) :
    BirthPreserving birth σ ↔
      ∀ a ∈ σ.support, ∃ v, birth a = some v ∧ birth (σ a) = some v := by
  constructor
  · rintro ⟨hvalue, hflag⟩ a ha
    cases hb : birth a with
    | none => exact False.elim ((Equiv.Perm.mem_support.mp ha) (hflag a hb))
    | some v => exact ⟨v, rfl, (hvalue a).trans hb⟩
  · intro h
    constructor
    · intro a
      by_cases ha : a ∈ σ.support
      · obtain ⟨v, hv, hσv⟩ := h a ha
        exact hσv.trans hv.symm
      · rw [Equiv.Perm.notMem_support.mp ha]
    · intro a ha
      by_contra hne
      obtain ⟨v, hv, _⟩ := h a (Equiv.Perm.mem_support.mpr hne)
      rw [ha] at hv
      cases hv

/-- The source rank: each nontrivial cycle of length n contributes n-1. -/
def birthCycleRank {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) : ℕ := (σ.cycleType.map (fun n => n - 1)).sum

private theorem multiset_sum_le_twice_pred_sum (s : Multiset ℕ)
    (hs : ∀ n ∈ s, 2 ≤ n) :
    s.sum ≤ 2 * (s.map (fun n => n - 1)).sum := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons n s ih =>
    have hn := hs n (by simp)
    have hrest := ih (fun m hm => hs m (Multiset.mem_cons_of_mem hm))
    simp only [Multiset.sum_cons, Multiset.map_cons]
    omega

/-- Rank r involves at most 2r actual moved birth addresses. -/
theorem support_card_le_twice_birthCycleRank
    {α : Type*} [Fintype α] [DecidableEq α] (σ : Equiv.Perm α) :
    σ.support.card ≤ 2 * birthCycleRank σ := by
  rw [← Equiv.Perm.sum_cycleType]
  exact multiset_sum_le_twice_pred_sum σ.cycleType
    (fun _ hn => Equiv.Perm.two_le_of_mem_cycleType hn)

/-- Any assignment of addresses to operations inherits the same 2r bound.
This is the combinatorial operation count used in source (4.54). -/
theorem modified_operations_card_le_twice_birthCycleRank
    {α β : Type*} [Fintype α] [DecidableEq α] [DecidableEq β]
    (operation : α → β) (σ : Equiv.Perm α) :
    (σ.support.image operation).card ≤ 2 * birthCycleRank σ :=
  (Finset.card_image_le).trans (support_card_le_twice_birthCycleRank σ)

end Elliptic.Operator
