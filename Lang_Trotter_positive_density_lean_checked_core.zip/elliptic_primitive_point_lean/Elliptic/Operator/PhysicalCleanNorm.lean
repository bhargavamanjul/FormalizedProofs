module

public import Elliptic.Operator.CleanDeterminantTransport

/-!
# The proved clean core norm on an actual physical pad cell

The first good-state test constructs the balanced integer box. Exact pad
coordinates preserve det/D. The sharp smoothed minor-arc bound is then
transported to actual prime labels with their actual product masses.
This concerns the central clean block after the cross-edge ban is removed;
that ban's small error and the assembly of all blocks remain separate.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators FourierTransform SchwartzMap
open MeasureTheory Elliptic.SourceContracts PhysicalPadLattice

abbrev PadPosition (z : ℤ × ℤ) (D : ℤ) := {v : ℤ × ℤ // D ∣ latticeDet z v}

def balancedPadEmbedding (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (b₁ b₂ : ℤ × ℤ) (hb : latticeDet b₁ b₂ = 1) :
    PadPosition z D ↪ (ℤ × ℤ) where
  toFun t := SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D t.val)
  inj' := balancedPadCoordinates_injective z w hzw D b₁ b₂ hb

def padDeterminant (z : ℤ × ℤ) (D : ℤ) (v t : PadPosition z D) : ℤ :=
  latticeDet v.val t.val / D

theorem balancedPadEmbedding_det (z w : ℤ × ℤ) (hzw : latticeDet z w = 1)
    (D : ℤ) (hD : D ≠ 0) (b₁ b₂ : ℤ × ℤ) (hb : latticeDet b₁ b₂ = 1)
    (v t : PadPosition z D) :
    latticeDet (balancedPadEmbedding z w hzw D b₁ b₂ hb v)
      (balancedPadEmbedding z w hzw D b₁ b₂ hb t) = padDeterminant z D v t := by
  unfold padDeterminant
  rw [← balancedPadCoordinates_det z w hzw D b₁ b₂ hb v.val t.val v.property t.property,
    Int.mul_ediv_cancel_left _ hD]
  rfl

/-- No determinant-fiber estimate is assumed: the actual physical pad
coordinates pull back the proved integer-box bound. -/
theorem smoothed_minor_pad_box_bound
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1) (D : ℤ) (hD : D ≠ 0)
    (b₁ b₂ : ℤ × ℤ) (hb : latticeDet b₁ b₂ = 1)
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1 ≤ H) (hY : 0 < Y) (s t : Finset (PadPosition z D))
    (hs : ∀ p ∈ s, balancedPadEmbedding z w hzw D b₁ b₂ hb p ∈
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (ht : ∀ p ∈ t, balancedPadEmbedding z w hzw D b₁ b₂ hb p ∈
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (θ : ProductCircle) (hminor : θ ∉ sourceMajorArcs H Y) :
    FiniteBilinearBound s t
      (fun p q => ((Y : ℂ)⁻¹ * ψ ((padDeterminant z D p q : ℝ)/Y)) *
        fourier (padDeterminant z D p q) θ)
      (smoothedDeterminantBudget ψ A B H Y k) := by
  let e := balancedPadEmbedding z w hzw D b₁ b₂ hb
  have hs' : s.map e ⊆ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)) := by
    intro p hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_map.mp hp
    exact hs q hq
  have ht' : t.map e ⊆ (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)) := by
    intro p hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_map.mp hp
    exact ht q hq
  have h := finiteBilinearBound_embedding s t e e _ _
    (smoothed_minor_integer_box_bound_restrict ψ A B a b H Y k hH hY
      (s.map e) (t.map e) hs' ht' θ hminor)
  simpa only [e, balancedPadEmbedding_det z w hzw D hD b₁ b₂ hb] using h

/-- The full positive prime-label and exact product-measure transfer for
one physical pad block, for either sign of the shift. -/
theorem actual_measured_signed_clean_pad_box_bound
    {ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (ν : ι → ℕ → ℝ) (C : ι → ℝ) (hC : ∀ i ∈ I, 0 ≤ C i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hνbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ C i / p)
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1) (D : ℤ) (hD : D ≠ 0)
    (b₁ b₂ : ℤ × ℤ) (hb : latticeDet b₁ b₂ = 1)
    (s t : Finset (PadPosition z D × PrimeChoice I groups))
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (a b : ℤ) (H Y : ℝ) (k : ℕ)
    (hH : 1 ≤ H) (hY : 0 < Y)
    (hsbox : ∀ p ∈ s, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (htbox : ∀ p ∈ t, balancedPadEmbedding z w hzw D b₁ b₂ hb p.1 ∈
      (Finset.Ico a (a+B)) ×ˢ (Finset.Ico b (b+A)))
    (hs : ∀ p ∈ s, Y ≤ (primeChoiceProduct I groups p.2 : ℝ))
    (ht : ∀ p ∈ t, Y ≤ (primeChoiceProduct I groups p.2 : ℝ))
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    FiniteMeasuredBilinearBound s t
      (fun p => primeChoiceMass I groups ν p.2)
      (fun p => primeChoiceMass I groups ν p.2)
      (actualSignedCleanKernel I groups (sourceMajorArcs H Y)ᶜ
        (fun p q => ψ ((padDeterminant z D p q : ℝ)/Y)) (padDeterminant z D) σ)
      ((∏ i : I, C i) * smoothedDeterminantBudget ψ A B H Y k) := by
  apply actual_measured_signed_clean_bound I groups hprime hdisjoint ν C hC hν hνbound
    s t (sourceMajorArcs H Y)ᶜ (sourceMajorArcs_measurable H Y).compl
    (fun p q => ψ ((padDeterminant z D p q : ℝ)/Y)) (padDeterminant z D) Y
    (smoothedDeterminantBudget ψ A B H Y k) hY
    (smoothedDeterminantBudget_nonneg ψ A B H Y k (by linarith) hY) hs ht ?_ σ hσ
  intro θ hθ
  apply smoothed_minor_pad_box_bound z w hzw D hD b₁ b₂ hb ψ A B a b H Y k hH hY
    (s.image Prod.fst) (t.image Prod.fst) ?_ ?_ θ hθ
  · intro p hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hp
    exact hsbox q hq
  · intro p hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hp
    exact htbox q hq

/-- The actual first good-state test constructs the box needed by the
clean bound. Widths and area are returned explicitly for the final uniform
asymptotic estimate; they are not extra box hypotheses. -/
theorem actual_measured_signed_clean_good_pad_cell_bound
    {ι : Type*} [DecidableEq ι]
    (I : Finset ι) (groups : ι → Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (ν : ι → ℕ → ℝ) (Cmass : ι → ℝ) (hCmass : ∀ i ∈ I, 0 ≤ Cmass i)
    (hν : ∀ i ∈ I, ∀ p ∈ groups i, 0 ≤ ν i p)
    (hνbound : ∀ i ∈ I, ∀ p ∈ groups i, ν i p ≤ Cmass i / p)
    (z w : ℤ × ℤ) (hzw : latticeDet z w = 1) (D : ℤ)
    (u v r U W d₀ Y C : ℝ)
    (hU : 0 < U) (hu : U ≤ u) (hu' : u ≤ 16*U)
    (hd : 0 < d₀) (hD : d₀ ≤ (D : ℝ)) (hY : 1 ≤ Y) (hC : 1 ≤ C)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest ((D : ℝ)*latticeTau r w/latticeTau r z) Y)
    (s t : Finset (PadPosition z D × PrimeChoice I groups))
    (hspos : ∀ p ∈ s, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (htpos : ∀ p ∈ t, sourcePhysicalPositionAllowed u v r U W p.1.val)
    (hscell : ∀ p ∈ s, |latticeSlope r p.1.val-latticeSlope r z| ≤ C*d₀*Y)
    (htcell : ∀ p ∈ t, |latticeSlope r p.1.val-latticeSlope r z| ≤ C*d₀*Y)
    (hs : ∀ p ∈ s, Y ≤ (primeChoiceProduct I groups p.2 : ℝ))
    (ht : ∀ p ∈ t, Y ≤ (primeChoiceProduct I groups p.2 : ℝ))
    (ψ : 𝓢(ℝ, ℂ)) (H : ℝ) (hH : 1 ≤ H) (k : ℕ)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    ∃ A B : ℕ, Y^(1/5 : ℝ) ≤ A ∧ Y^(1/5 : ℝ) ≤ B ∧
      (A : ℝ)*B ≤ 72*(256*C)^2*Y ∧
      FiniteMeasuredBilinearBound s t
        (fun p => primeChoiceMass I groups ν p.2)
        (fun p => primeChoiceMass I groups ν p.2)
        (actualSignedCleanKernel I groups (sourceMajorArcs H Y)ᶜ
          (fun p q => ψ ((padDeterminant z D p q : ℝ)/Y)) (padDeterminant z D) σ)
        ((∏ i : I, Cmass i) * smoothedDeterminantBudget ψ A B H Y k) := by
  obtain ⟨b₁,b₂,a,b,c,d,hb,hab,hcd,hwidth,hwidth',harea,hcontain⟩ :=
    physical_pad_cell_balanced_box z w hzw D u v r U W d₀ Y C hU hu hu' hd hD hY hC hz hg
  let A : ℕ := (d-c).toNat
  let B : ℕ := (b-a).toNat
  have hAcast : (A : ℤ) = d-c := Int.toNat_of_nonneg (by omega)
  have hBcast : (B : ℤ) = b-a := Int.toNat_of_nonneg (by omega)
  have hAR : (A : ℝ) = (d : ℝ)-c := by exact_mod_cast hAcast
  have hBR : (B : ℝ) = (b : ℝ)-a := by exact_mod_cast hBcast
  have hD0 : D ≠ 0 := by
    have hDpos : (0 : ℝ) < D := hd.trans_le hD
    exact_mod_cast hDpos.ne'
  refine ⟨A,B,?_,?_,?_,?_⟩
  · rwa [hAR]
  · rwa [hBR]
  · rw [hAR,hBR,mul_comm]
    exact harea
  · apply actual_measured_signed_clean_pad_box_bound I groups hprime hdisjoint ν Cmass
      hCmass hν hνbound z w hzw D hD0 b₁ b₂ hb s t ψ A B a c H Y k hH
      (by linarith) ?_ ?_ hs ht σ hσ
    · intro p hp
      have h := hcontain p.1.val (hspos p hp) p.1.property (hscell p hp)
      change SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D p.1.val) ∈
        (Finset.Ico a (a+(B : ℤ))) ×ˢ (Finset.Ico c (c+(A : ℤ)))
      simpa only [hAcast, hBcast, add_sub_cancel] using h
    · intro p hp
      have h := hcontain p.1.val (htpos p hp) p.1.property (htcell p hp)
      change SourceGoodState.basisCoordinates b₁ b₂ (padCoordinates z w D p.1.val) ∈
        (Finset.Ico a (a+(B : ℤ))) ×ˢ (Finset.Ico c (c+(A : ℤ)))
      simpa only [hAcast, hBcast, add_sub_cancel] using h

end Elliptic.Operator
