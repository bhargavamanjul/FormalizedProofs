module

public import Elliptic.Operator.DirtySchur
public import Elliptic.Operator.PhysicalMemoryEdges

/-!
# A coarse row bound for the actual full physical memory operator

This bound keeps every literal choice and both endpoint permutation
averages. It drops only the total cutoff and bounds the geometric
multiplier by a supplied scalar supremum. The resulting positive row
majorant is uniform in the memory length and needs no adjoint identity.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- The literal sum of all local store/promotion/fresh choices has a
uniform weighted row bound. -/
theorem edgeWeightedChoice_sum_le {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ v0 : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c : EdgeGroupChoice m,
      edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor sourcePrime m c) ≤
      (1+v0) * ((∑ p, ν p) + V⁻¹/(v0*(1-ρ))) := by
  classical
  rw [Fintype.sum_prod_type]
  calc
    _ ≤ ∑ store : Bool, (v0 ^ store.toNat * ((∑ p, ν p) + V⁻¹/(v0*(1-ρ)))) := by
      apply Finset.sum_le_sum
      intro store _
      rw [Fintype.sum_sum_type]
      have hp := edgeWeightedChoice_promotion_sum_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m
        store hV hρ0 hρ1 hv0
      have hf := edgeWeightedChoice_fresh_sum_le ν V ρ v0 sourceAnchor targetAnchor sourcePrime m
        store Finset.univ hν hρ0 hρ1.le hv0
      apply (add_le_add hp hf).trans_eq
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring
    _ = _ := by simp [Bool.toNat]; ring

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- The source (4.19) Schur weight on the actual total pending memory. -/
def physicalMemorySchurWeight (v0 : ℝ) (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  v0 ^ (∑ i, (s.memory P Line J B i).size)

theorem physicalMemorySchurWeight_pos {v0 : ℝ} (hv0 : 0 < v0)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : 0 < physicalMemorySchurWeight v0 s :=
  pow_pos hv0 _

/-- The full weight ratio factors into the actual local output ratios. -/
theorem physicalMemorySchurWeight_output_ratio (v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) :
    physicalMemorySchurWeight v0 (c.output anchor s hc) / physicalMemorySchurWeight v0 s =
      ∏ i, v0 ^ (edgeGroupOutput (anchor (s.position P Line J B) i) (c.sourcePrime i)
        (s.memory P Line J B i) (c.group i) (hc.1 i).2).size /
          v0 ^ (s.memory P Line J B i).size := by
  unfold physicalMemorySchurWeight
  rw [Finset.prod_div_distrib, Finset.prod_pow_eq_pow_sum, Finset.prod_pow_eq_pow_sum]
  rfl

/-- All local real edge coefficients are nonnegative for nonnegative
prime weights and damping. -/
theorem edgeGroupWeight_nonneg {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourcePrime : P) (m : MemoryState (AnchoredParticle P Line) B)
    (c : EdgeGroupChoice m) (hc : edgeGroupOutputSize c ≤ B)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V) (hρ : 0 ≤ ρ) :
    0 ≤ edgeGroupWeight ν V ρ sourceAnchor targetAnchor sourcePrime m c hc := by
  have ht : 0 ≤ edgeTargetWeight ν V c := by
    rcases c with ⟨store,i|p⟩ <;> simp [edgeTargetWeight, hν, inv_nonneg.mpr hV]
  unfold edgeGroupWeight
  positivity

/-- Exact normalization of a valid full choice into the product of its
literal local weighted choices. -/
theorem physicalEdgeChoiceWeight_norm_mul_ratio
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
      (physicalMemorySchurWeight v0 (c.output anchor s hc) / physicalMemorySchurWeight v0 s) =
      endpointPermutationWeight I J *
        ‖geometry (s.position P Line J B) c.sourceLists c.target c.targetLists‖ *
          ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
            (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) := by
  have hw : 0 ≤ endpointPermutationWeight I J := by unfold endpointPermutationWeight; positivity
  have he (i : I) :
      edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
          (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) =
        edgeGroupWeight (ν i) (V i) ρ (anchor (s.position P Line J B) i)
          (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2 *
        (v0 ^ (edgeGroupOutput (anchor (s.position P Line J B) i) (c.sourcePrime i)
          (s.memory P Line J B i) (c.group i) (hc.1 i).2).size /
            v0 ^ (s.memory P Line J B i).size) := by
    simp only [edgeWeightedChoice, dite_eq_left (hc.1 i)]
  simp_rw [he]
  rw [Finset.prod_mul_distrib, physicalMemorySchurWeight_output_ratio]
  unfold physicalEdgeChoiceWeight
  simp only [norm_mul, norm_prod, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hw]
  have hn (i : I) : |edgeGroupWeight (ν i) (V i) ρ (anchor (s.position P Line J B) i)
      (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2| =
      edgeGroupWeight (ν i) (V i) ρ (anchor (s.position P Line J B) i)
        (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2 :=
    abs_of_nonneg (edgeGroupWeight_nonneg _ _ _ _ _ _ _ _ _ (hν i) (hV i) hρ)
  simp_rw [hn]
  ring

/-- The absolute weighted row over the full physical operation choices. -/
def physicalEdgeAbsoluteChoiceRow [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
      (physicalMemorySchurWeight v0 (c.output anchor s hc) / physicalMemorySchurWeight v0 s)
  else 0

/-- Explicit local constant, including both optional store choices. -/
def physicalEdgeLocalRowConstant {P : Type*} [Fintype P]
    (ν : P → ℝ) (V ρ v0 : ℝ) : ℝ :=
  (1+v0) * ((∑ p, ν p) + V⁻¹/(v0*(1-ρ)))

theorem physicalEdgeLocalRowConstant_nonneg {P : Type*} [Fintype P]
    (ν : P → ℝ) (V ρ v0 : ℝ) (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V)
    (hρ1 : ρ < 1) (hv0 : 0 < v0) : 0 ≤ physicalEdgeLocalRowConstant ν V ρ v0 := by
  have hs : 0 ≤ ∑ p, ν p := Finset.sum_nonneg fun p _ => hν p
  unfold physicalEdgeLocalRowConstant
  positivity

/-- The actual independent group-choice sums factor; each local bound is
uniform in the source prime, target anchor and memory length. -/
theorem edgeWeightedChoice_product_sum_le [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (sourcePrime : ∀ i, P i)
    (m : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c : ∀ i, EdgeGroupChoice (m i),
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
        (sourcePrime i) (m i) (c i)) ≤
      ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0 := by
  classical
  rw [← Fintype.prod_sum (fun i (c : EdgeGroupChoice (m i)) =>
    edgeWeightedChoice (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) c)]
  apply Finset.prod_le_prod₀
  · intro i _
    exact Finset.sum_nonneg fun c _ => edgeWeightedChoice_nonneg (ν i) (V i) ρ v0
      (sourceAnchor i) (targetAnchor i) (sourcePrime i) (m i) c (hν i) (hV i) hρ0 hv0.le
  · intro i _
    exact edgeWeightedChoice_sum_le (ν i) (V i) ρ v0 (sourceAnchor i) (targetAnchor i)
      (sourcePrime i) (m i) (hν i) (hV i) hρ0 hρ1 hv0

/-- Summing all physical choices after dropping the total cutoff has
exactly one factor for target positions and two for endpoint permutations.
The independent group sums are the literal finite local choice sums. -/
theorem physicalEdge_group_choice_sum_le [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    (∑ c : PhysicalEdgeChoice s,
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
        (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i)) ≤
      (Fintype.card Z : ℝ) * (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ)^2 *
        ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0 := by
  classical
  let C : ℝ := ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
  let n : ℝ := Fintype.card (I → Equiv.Perm (Fin (J+1)))
  rw [Fintype.sum_prod_type]
  calc
    _ ≤ ∑ _z : Z, n*n*C := by
      apply Finset.sum_le_sum
      intro z _
      rw [Fintype.sum_prod_type]
      calc
        _ ≤ ∑ _σ : I → Equiv.Perm (Fin (J+1)), n*C := by
          apply Finset.sum_le_sum
          intro σ _
          rw [Fintype.sum_prod_type]
          simp only [PhysicalEdgeChoice.group, PhysicalEdgeChoice.target, PhysicalEdgeChoice.sourcePrime,
            PhysicalEdgeChoice.sourceLists, PhysicalEdgeChoice.sourcePerm,
            Finset.sum_const, nsmul_eq_mul, Finset.card_univ]
          rw [← Finset.mul_sum]
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          exact edgeWeightedChoice_product_sum_le ν V ρ v0 (anchor (s.position P Line J B))
            (anchor z) (fun i => s.active P Line J B i (σ i (Fin.last J)))
            (s.memory P Line J B) hν hV hρ0 hρ1 hv0
        _ = n*n*C := by simp [n]; ring
    _ = _ := by simp [n, C, pow_two]; ring

/-- A bound on the actual full weighted absolute choice row. The only
geometric input is a scalar upper bound on the literal multiplier. -/
theorem physicalEdgeAbsoluteChoiceRow_le [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hG : 0 ≤ G)
    (hgeometry : ∀ z a w b, ‖geometry z a w b‖ ≤ G) :
    physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s ≤
      (Fintype.card Z : ℝ) * G *
        ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0 := by
  classical
  have hw : 0 ≤ endpointPermutationWeight I J := by unfold endpointPermutationWeight; positivity
  let C : ℝ := ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
  let n : ℝ := Fintype.card (I → Equiv.Perm (Fin (J+1)))
  have hn : n ≠ 0 := by
    dsimp [n]
    exact_mod_cast (Fintype.card_pos_iff.mpr
      ⟨fun _ : I => Equiv.refl (Fin (J+1))⟩).ne'
  unfold physicalEdgeAbsoluteChoiceRow
  calc
    _ ≤ ∑ c : PhysicalEdgeChoice s, endpointPermutationWeight I J * G *
        ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
          (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i) := by
      apply Finset.sum_le_sum
      intro c _
      have hp : 0 ≤ ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0
          (anchor (s.position P Line J B) i) (anchor c.target i) (c.sourcePrime i)
          (s.memory P Line J B i) (c.group i) :=
        Finset.prod_nonneg fun i _ => edgeWeightedChoice_nonneg _ _ _ _ _ _ _ _ _
          (hν i) (hV i) hρ0 hv0.le
      split_ifs with hc
      · rw [physicalEdgeChoiceWeight_norm_mul_ratio ν V ρ v0 anchor geometry s c hc hν hV hρ0]
        exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (hgeometry _ _ _ _) hw) hp
      · exact mul_nonneg (mul_nonneg hw hG) hp
    _ = endpointPermutationWeight I J * G *
        (∑ c : PhysicalEdgeChoice s,
          ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
            (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i)) := by
      rw [Finset.mul_sum]
    _ ≤ endpointPermutationWeight I J * G * ((Fintype.card Z : ℝ) * n^2 * C) :=
      mul_le_mul_of_nonneg_left
        (physicalEdge_group_choice_sum_le ν V ρ v0 anchor s hν hV hρ0 hρ1 hv0)
        (mul_nonneg hw hG)
    _ = _ := by
      unfold endpointPermutationWeight
      change n⁻¹ ^ 2 * G * ((Fintype.card Z : ℝ) * n^2 * C) = (Fintype.card Z : ℝ) * G * C
      field_simp

/-- The same actual absolute choice bound without normalization. This is
the one-step weighted positive-history estimate, requiring no column bound. -/
theorem physicalEdge_absolute_choice_weighted_sum_le [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hG : 0 ≤ G)
    (hgeometry : ∀ z a w b, ‖geometry z a w b‖ ≤ G) :
    (∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
      ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
        physicalMemorySchurWeight v0 (c.output anchor s hc) else 0) ≤
      ((Fintype.card Z : ℝ) * G *
        ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0) * physicalMemorySchurWeight v0 s := by
  have hw := physicalMemorySchurWeight_pos hv0 s
  calc
    _ = physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s * physicalMemorySchurWeight v0 s := by
      unfold physicalEdgeAbsoluteChoiceRow
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro c _
      split_ifs
      · field_simp
      · simp
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (physicalEdgeAbsoluteChoiceRow_le ν V ρ v0 G anchor geometry s hν hV hρ0 hρ1 hv0 hG hgeometry) hw.le

/-- Collecting equal outputs can only reduce the absolute weighted row;
all literal indexed multiplicities have already been accounted for. -/
theorem physicalEdgeTransition_weighted_row_le_choices [Fintype Z] [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hv0 : 0 ≤ v0) :
    (∑ t : PhysicalMemoryState (Z:=Z) P Line J B,
      ‖physicalEdgeTransition ν V ρ anchor geometry s t‖ *
        (physicalMemorySchurWeight v0 t / physicalMemorySchurWeight v0 s)) ≤
      physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s := by
  classical
  unfold physicalEdgeTransition physicalEdgeApply physicalEdgeAbsoluteChoiceRow
  calc
    _ ≤ ∑ t : PhysicalMemoryState (Z:=Z) P Line J B,
        (∑ c : PhysicalEdgeChoice s,
          ‖if hc : c.Valid anchor s then
            physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc *
              (if c.output anchor s hc = t then 1 else 0) else 0‖) *
            (physicalMemorySchurWeight v0 t / physicalMemorySchurWeight v0 s) := by
      apply Finset.sum_le_sum
      intro t _
      exact mul_le_mul_of_nonneg_right (norm_sum_le _ _)
        (by unfold physicalMemorySchurWeight; positivity)
    _ = _ := by
      simp_rw [Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro c _
      by_cases hc : c.Valid anchor s
      · simp only [dite_eq_left hc]
        rw [Finset.sum_eq_single (c.output anchor s hc)]
        · simp
        · intro t _ ht
          simp [Ne.symm ht]
        · intro hnot
          exact (hnot (Finset.mem_univ _)).elim
      · simp [hc]

/-- Consequently the actual collected transition has the same concrete
coarse weighted row bound. -/
theorem physicalEdgeTransition_weighted_row_le [Fintype Z] [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 G : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hG : 0 ≤ G)
    (hgeometry : ∀ z a w b, ‖geometry z a w b‖ ≤ G) :
    (∑ t : PhysicalMemoryState (Z:=Z) P Line J B,
      ‖physicalEdgeTransition ν V ρ anchor geometry s t‖ *
        (physicalMemorySchurWeight v0 t / physicalMemorySchurWeight v0 s)) ≤
      (Fintype.card Z : ℝ) * G *
        ∏ i, physicalEdgeLocalRowConstant (ν i) (V i) ρ v0 :=
  (physicalEdgeTransition_weighted_row_le_choices ν V ρ v0 anchor geometry s hv0.le).trans
    (physicalEdgeAbsoluteChoiceRow_le ν V ρ v0 G anchor geometry s hν hV hρ0 hρ1 hv0 hG hgeometry)

end Elliptic.Operator
