module
public import Elliptic.Operator.PhysicalLowRankBoundary
public import Elliptic.Operator.ActualBirthHighRankParameters
public import Elliptic.Operator.ActualBirthSourceMass
public import Elliptic.Operator.GrowingMoment
public import Elliptic.Operator.BirthRankInstances

/-! Exact distinct-birth boundary sums and their actual rank assembly. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBoundaryMoment
open scoped BigOperators ComplexConjugate
open CanonicalBoundaryAssembly ActualHistoryBirths PhysicalBagNorm
attribute [local instance] Classical.propDecidable
local instance boundaryMomentDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} [∀ i p, Fintype (Line i p)] {J B N : ℕ}
local instance (priority := 100000) boundaryMomentAddressDecEq : DecidableEq (Address I J B N) :=
  Classical.typeDecidableEq _

/-- The literal unnormalized position vector on the empty-memory boundary. -/
def atPosition (z : Z) : BoundaryIndex I Z P J → ℂ := fun u => if u.1=z then 1 else 0

theorem atPosition_norm_le (z : Z) (u : BoundaryIndex I Z P J) :
    ‖atPosition z u‖ ≤ 1 := by unfold atPosition;split_ifs <;> norm_num

theorem position_indicator_eq (d : DecidableEq Z) (z : Z) :
    (fun u : BoundaryIndex I Z P J => @ite ℂ (u.1=z) (d u.1 z) 1 0) = atPosition z := by
  funext u
  by_cases h : u.1=z <;> simp [atPosition,h]

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
variable (value : ∀ i, P i → ℕ)

theorem term_atPosition_eq (σ : Equiv.Perm (Address I J B N))
    (z : Z) (b : BoundaryIndex I Z P J → ℂ) :
    PhysicalLowRankBoundary.term ν V η q ρ anchor geometry value σ (atPosition z) b =
      ActualBirthHighRank.term ν V η q ρ anchor geometry value σ (vacuumLift b) z := by
  unfold PhysicalLowRankBoundary.term
  rw [Fintype.sum_prod_type]
  simp only [atPosition,apply_ite (starRingEnd ℂ),map_one,map_zero,mul_ite,mul_one,mul_zero,ite_mul,zero_mul]
  rw [Finset.sum_comm]
  simp only [Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  unfold ActualBirthHighRank.term
  with_reducible refine Finset.sum_congr ?_ ?_
  · ext a;simp only [Finset.mem_univ]
  · intro a _
    rw [emptyState_mass]
    rfl

/-- The actual selected boundary pairing is exactly the signed sum of the
same per-permutation terms estimated by the physical word bounds. -/
theorem boundaryPairing_eq_signed_terms (a b : BoundaryIndex I Z P J → ℂ) :
    boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b =
      ∑ σ : Equiv.Perm (Address I J B N), (permutationSign σ : ℂ)*
        PhysicalLowRankBoundary.term ν V η q ρ anchor geometry value σ a b := by
  unfold boundaryPairing ChoiceOperation.selectedHistorySum
  have he (u : BoundaryIndex I Z P J) :
      (∑ h : ChoiceOperation.History (physicalMemoryOperations (B:=B) ν V η q ρ anchor geometry N) (emptyState u),
        (if BirthsDistinct (labels ν V η q ρ anchor geometry value N _ h) then (1:ℂ) else 0)*
          h.weight*vacuumLift b h.final) =
      ∑ σ : Equiv.Perm (Address I J B N), (permutationSign σ : ℂ)*
        ∑ h : ChoiceOperation.History (physicalMemoryOperations (B:=B) ν V η q ρ anchor geometry N) (emptyState u),
          if BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
          then h.weight*vacuumLift b h.final else 0 := by
    have h := weighted_birth_distinctness_expansion Finset.univ
      (fun h : ChoiceOperation.History (physicalMemoryOperations (B:=B) ν V η q ρ anchor geometry N) (emptyState u) =>
        labels ν V η q ρ anchor geometry value N _ h)
      (fun h => h.weight*vacuumLift b h.final)
    calc
      _ = ∑ h : ChoiceOperation.History (physicalMemoryOperations (B:=B) ν V η q ρ anchor geometry N) (emptyState u),
          if BirthsDistinct (labels ν V η q ρ anchor geometry value N _ h) then
            h.weight*vacuumLift b h.final else 0 := by
        apply Finset.sum_congr rfl
        intro h _
        split_ifs <;> simp
      _ = _ := by
        convert h using 1
        with_reducible refine Finset.sum_congr ?_ ?_
        · ext σ;simp only [Finset.mem_univ]
        · intro σ _;rfl
  simp_rw [he,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro σ _
  unfold PhysicalLowRankBoundary.term
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro u _
  simp only [←Finset.mul_sum]
  ring

/-- The literal source birth universe has exactly the declared budget. -/
theorem address_card : Fintype.card (Address I J B N) =
    Fintype.card I*(J+1)+Fintype.card I*N+Fintype.card I*(N+1)*B := by
  simp only [Address,Fintype.card_sum,Fintype.card_prod,Fintype.card_fin]
  ring

end Elliptic.Operator.PhysicalBoundaryMoment
