module

public import Elliptic.Operator.PhysicalRawSchur
public import Elliptic.Operator.PhysicalDirtyMasks
public import Elliptic.Operator.FiniteOperatorSum

/-! The actual full dirty raw operator is the finite sum of its literal
store/promotion masks. The empty/empty mask is excluded exactly. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyRawSchur
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalRawMaskedRow PhysicalRawGlobalRow PhysicalMaskScaling
open PhysicalRawSchur PhysicalDirtyMasks
attribute [local instance] Classical.propDecidable
local instance dirtyRawSchurDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable [Fintype Z] [∀ i, Fintype (P i)]
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable [∀ i p, Fintype (ZMod (value i p))]

/-- Explicit sum of squared two-sided mask budgets. -/
def allMaskBudget (K J B : ℕ) (V : Fin K → ℝ) (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ) : ℝ :=
  Real.sqrt (((dirtyMasks (G:=Fin K)).card:ℝ)*∑m∈dirtyMasks,
    (Real.sqrt ((A*budget K J B ρ v0 vmin M L a m.2)*
      (reverseFactor V m.2 m.1*A*budget K J B ρ v0 vmin M L a m.1)))^2)

theorem dirty_raw_schur
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) 
    (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ=1 ∨ σ= -1)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hgood : GoodProjection value μ d₀ r L a good)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p:ℝ))
    (hνμ : ∀ i p, ν i p ≤ 2*μ i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hM : 0 ≤ M) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z b w c, sourceRawAllowed value good u v r U W d₀ σ z b w c → ‖amplitude z b w c‖ ≤ A)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p => Option (ZMod (value i p))) (J:=J) (B:=B) → ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s => ∑t,dirtyKernel ν V ρ (anchor value position)
        (fun z b w c => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) b (position w) c) s t*F t) ≤
    allMaskBudget K J B V ρ v0 vmin M L A a * finiteL2 Finset.univ (mass ν) F := by
  let f := fun (m : Mask (G:=Fin K)) s => ∑t,
    rawKernel value position ν V m.1 m.2 ρ good u v r U W d₀ σ amplitude s t*F t
  have hm (m : Mask (G:=Fin K)) (_ : m∈dirtyMasks) := masked_raw_schur value position
    hposition hprime ν μ hνpos V m.1 m.2 ρ v0 vmin M L A a good u v r U W d₀ σ
    hU hσ amplitude hgood hband hνμ hV hmin hρ0 hρ1 hv0 hM hA hmass hamp F
  have hs := finiteL2_sum_le Finset.univ (dirtyMasks (G:=Fin K)) (mass ν)
    (fun s _ => (mass_pos ν hνpos s).le) f
    (fun m => Real.sqrt ((A*budget K J B ρ v0 vmin M L a m.2)*
      (reverseFactor V m.2 m.1*A*budget K J B ρ v0 vmin M L a m.1)))
    (finiteL2 Finset.univ (mass ν) F) (Real.sqrt_nonneg _) (fun _ _=>Real.sqrt_nonneg _) hm
  apply (le_of_eq ?_).trans hs
  apply congrArg (finiteL2 Finset.univ (mass ν))
  funext s
  unfold dirtyKernel
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  unfold f rawKernel
  apply Finset.sum_congr
  · ext t
    simp only [Finset.mem_univ]
  · intro t ht
    rfl

end Elliptic.Operator.PhysicalDirtyRawSchur
