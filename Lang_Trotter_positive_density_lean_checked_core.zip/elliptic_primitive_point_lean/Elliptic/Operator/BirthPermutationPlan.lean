module

public import Elliptic.Operator.BirthChronologicalOrder
public import Elliptic.Operator.PhysicalPivotInitial

/-! The chronological pivot plan is constructed from a fixed permutation.
The selected coordinates are exactly its nonpivots. Group preservation is
a necessary condition for actual histories with injective numerical labels;
it is not an assumption about the values sampled later. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthPermutationPlan
open scoped BigOperators
open ActualHistoryBirths BirthCyclePivots
attribute [local instance] Classical.propDecidable
local instance {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

variable {I : Type} [Fintype I] {J B N : ℕ}
local instance chronologicalOrder : LinearOrder (Address I J B N) := BirthChronologicalOrder.order

def unembed : PhysicalBirthRegistry.Address I J B → Option (Address I J B N)
  | .inl a => some (.inl a)
  | .inr (.inl a) => if h : a.1<N+1 then some (.inr (.inl (⟨a.1,h⟩,a.2))) else none
  | .inr (.inr a) => if h : a.1<N then some (.inr (.inr (⟨a.1,h⟩,a.2))) else none

theorem unembed_embed (a : Address I J B N) : unembed (PhysicalBirthRegistry.embed a)=some a := by
  rcases a with a|(a|a)
  · rfl
  · simp [unembed,PhysicalBirthRegistry.embed,a.1.isLt,Nat.le_of_lt_succ a.1.isLt]
  · simp [unembed,PhysicalBirthRegistry.embed,a.1.isLt]

def liftedPivot (σ : Equiv.Perm (Address I J B N)) (r : PhysicalBirthRegistry.Address I J B) :
    PhysicalBirthRegistry.Address I J B :=
  ((unembed r).map (fun a=>if ha:a∈nonpivots σ then
    PhysicalBirthRegistry.embed (pivot σ a ha) else PhysicalBirthRegistry.embed a)).getD r

theorem liftedPivot_embed (σ : Equiv.Perm (Address I J B N))
    (a : Address I J B N) (ha:a∈nonpivots σ) :
    liftedPivot σ (PhysicalBirthRegistry.embed a)=PhysicalBirthRegistry.embed (pivot σ a ha) := by
  simp [liftedPivot,unembed_embed,ha]

def ghostSlots (σ : Equiv.Perm (Address I J B N)) (j : ℕ) (i:I) : Finset ℕ :=
  if hj:j<N+1 then
    (Finset.univ.filter (fun k : Fin B=>(.inr (.inl (⟨j,hj⟩,i,k)))∈nonpivots σ)).image Fin.val
  else ∅

def edgeGroups (σ : Equiv.Perm (Address I J B N)) (j : ℕ) : Finset I :=
  if hj:j<N then Finset.univ.filter (fun i=>(.inr (.inr (⟨j,hj⟩,i)))∈nonpivots σ) else ∅

def initialSlots (σ : Equiv.Perm (Address I J B N)) (i:I) : Finset ℕ :=
  (Finset.univ.filter (fun k : Fin (J+1)=>(.inl (i,k))∈nonpivots σ)).image Fin.val

theorem mem_ghostSlots (σ : Equiv.Perm (Address I J B N)) (j : ℕ) (i:I) (k:ℕ) :
    k∈ghostSlots σ j i ↔ ∃hj:j<N+1,∃a:Fin B,a.val=k ∧
      (.inr (.inl (⟨j,hj⟩,i,a)))∈nonpivots σ := by
  by_cases hj:j<N+1 <;> simp [ghostSlots,hj,Finset.mem_image,and_comm]

theorem mem_edgeGroups (σ : Equiv.Perm (Address I J B N)) (j : ℕ) (i:I) :
    i∈edgeGroups σ j ↔ ∃hj:j<N,(.inr (.inr (⟨j,hj⟩,i)))∈nonpivots σ := by
  by_cases hj:j<N <;> simp [edgeGroups,hj]

theorem mem_initialSlots (σ : Equiv.Perm (Address I J B N)) (i:I) (k:ℕ) :
    k∈initialSlots σ i ↔ ∃a:Fin (J+1),a.val=k ∧ (.inl (i,a))∈nonpivots σ := by
  simp [initialSlots,Finset.mem_image,and_comm]

theorem ghostSlots_bounded (σ : Equiv.Perm (Address I J B N)) (j : ℕ) (i:I) :
    ghostSlots σ j i ⊆ Finset.range B := by
  intro k hk
  obtain ⟨hj,a,rfl,_⟩ := (mem_ghostSlots σ j i k).mp hk
  exact Finset.mem_range.mpr a.isLt

theorem initialSlots_bounded (σ : Equiv.Perm (Address I J B N)) (i:I) :
    initialSlots σ i ⊆ Finset.range (J+1) := by
  intro k hk
  obtain ⟨a,rfl,_⟩ := (mem_initialSlots σ i k).mp hk
  exact Finset.mem_range.mpr a.isLt

theorem pivot_group (σ : Equiv.Perm (Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) (a : Address I J B N) (ha:a∈nonpivots σ) :
    addressGroup (pivot σ a ha)=addressGroup a :=
  invariant_on_cycle σ addressGroup hgroup (pivot_sameCycle σ a ha)

def plan (σ : Equiv.Perm (Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) : PhysicalBirthRegistry.PivotPlan I J B where
  pivot := liftedPivot σ
  ghostSlots := ghostSlots σ
  edgeGroups := edgeGroups σ
  ghost_bounded := ghostSlots_bounded σ
  ghost_earlier := by
    intro j i k hk
    obtain ⟨hj,a,rfl,ha⟩ := (mem_ghostSlots σ j i k).mp hk
    change PhysicalBirthRegistry.GhostPrecedes j i a.val
      (liftedPivot σ (PhysicalBirthRegistry.embed (.inr (.inl (⟨j,hj⟩,i,a)))))
    rw [liftedPivot_embed σ _ ha]
    exact BirthChronologicalOrder.lt_ghost_same_group _ _ i a (pivot_lt σ _ ha)
      (pivot_group σ hgroup _ ha)
  edge_earlier := by
    intro j i hi
    obtain ⟨hj,ha⟩ := (mem_edgeGroups σ j i).mp hi
    change PhysicalBirthRegistry.BeforeEdge j
      (liftedPivot σ (PhysicalBirthRegistry.embed (.inr (.inr (⟨j,hj⟩,i)))))
    rw [liftedPivot_embed σ _ ha]
    exact BirthChronologicalOrder.lt_edge_same_group _ _ i (pivot_lt σ _ ha)
      (pivot_group σ hgroup _ ha)

def initialPlan (σ : Equiv.Perm (Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) : PhysicalBirthRegistry.InitialPlan I J B where
  pivot := liftedPivot σ
  slots := initialSlots σ
  bounded := initialSlots_bounded σ
  earlier := by
    intro i k hk
    obtain ⟨a,rfl,ha⟩ := (mem_initialSlots σ i k).mp hk
    change PhysicalBirthRegistry.InitialPrecedes i a.val
      (liftedPivot σ (PhysicalBirthRegistry.embed (N:=N) (.inl (i,a))))
    rw [liftedPivot_embed σ _ ha]
    obtain ⟨b,hb,he⟩ := BirthChronologicalOrder.lt_initial_same_group _ i a
      (pivot_lt σ _ ha) (pivot_group σ hgroup _ ha)
    exact ⟨b,hb,congrArg PhysicalBirthRegistry.embed he⟩

theorem prescribed_equalities (σ : Equiv.Perm (Address I J B N))
    (birth : Address I J B N→Option ℕ) (f : PhysicalBirthRegistry.Registry I J B)
    (hf : ∀a,f (PhysicalBirthRegistry.embed a)=birth a) (hp : BirthPreserving birth σ)
    (a : Address I J B N) (ha:a∈nonpivots σ) :
    ∃v,f (PhysicalBirthRegistry.embed a)=some v ∧
      f (liftedPivot σ (PhysicalBirthRegistry.embed a))=some v := by
  obtain ⟨v,hv,ha'⟩ := birthPreserving_prescribes birth σ hp a ha
  exact ⟨v,(hf a).trans ha',by rw [liftedPivot_embed σ a ha,hf,hv]⟩

end Elliptic.Operator.BirthPermutationPlan
