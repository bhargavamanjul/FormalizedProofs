module
public import Elliptic.Operator.PhysicalCleanLabels

/-! Exact finite measured restriction and addition, used to restore the
literal coincidence ban after the cancellation estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance cleanRestrictionDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

theorem finiteMeasuredBilinearBound_restrict {X Y : Type*}
    (s s' : Finset X) (t t' : Finset Y) (hs : s'⊆s) (ht : t'⊆t)
    (μ : X → ℝ) (ν : Y → ℝ) (K : X → Y → ℂ) (M : ℝ)
    (hK : FiniteMeasuredBilinearBound s t μ ν K M) :
    FiniteMeasuredBilinearBound s' t' μ ν K M := by
  intro a b
  let a' : X → ℂ := fun x => if x∈s' then a x else 0
  let b' : Y → ℂ := fun y => if y∈t' then b y else 0
  have ha : finiteL2 s μ a'=finiteL2 s' μ a := by
    unfold finiteL2 finiteL2Sq
    congr 1
    calc
      _ = ∑ x∈s', μ x*‖a' x‖^2 :=
        (Finset.sum_subset hs (fun x hx hnot => by simp [a',hnot])).symm
      _ = _ := Finset.sum_congr rfl (fun x hx => by simp [a',hx])
  have hb : finiteL2 t ν b'=finiteL2 t' ν b := by
    unfold finiteL2 finiteL2Sq
    congr 1
    calc
      _ = ∑ y∈t', ν y*‖b' y‖^2 :=
        (Finset.sum_subset ht (fun y hy hnot => by simp [b',hnot])).symm
      _ = _ := Finset.sum_congr rfl (fun y hy => by simp [b',hy])
  have hp : finiteMeasuredPairing s t μ ν K a' b'=finiteMeasuredPairing s' t' μ ν K a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    calc
      _ = ∑ x∈s', (μ x:ℂ)*a' x*(∑ y∈t, (ν y:ℂ)*K x y*b' y) :=
        (Finset.sum_subset hs (fun x hx hnot => by simp [a',hnot])).symm
      _ = _ := by
        apply Finset.sum_congr rfl
        intro x hx
        rw [show a' x=a x by simp [a',hx]]
        congr 1
        calc
          _ = ∑ y∈t', (ν y:ℂ)*K x y*b' y :=
            (Finset.sum_subset ht (fun y hy hnot => by simp [b',hnot])).symm
          _ = _ := Finset.sum_congr rfl (fun y hy => by simp [b',hy])
  have h := hK a' b'
  rwa [hp,ha,hb] at h

theorem finiteMeasuredBilinearBound_sub {X Y : Type*}
    (s : Finset X) (t : Finset Y) (μ : X → ℝ) (ν : Y → ℝ)
    (K L : X → Y → ℂ) (M N : ℝ)
    (hK : FiniteMeasuredBilinearBound s t μ ν K M)
    (hL : FiniteMeasuredBilinearBound s t μ ν L N) :
    FiniteMeasuredBilinearBound s t μ ν (fun x y => K x y-L x y) (M+N) := by
  intro a b
  have he : finiteMeasuredPairing s t μ ν (fun x y => K x y-L x y) a b =
      finiteMeasuredPairing s t μ ν K a b-finiteMeasuredPairing s t μ ν L a b := by
    simp [finiteMeasuredPairing,finiteKernelApply,mul_sub,sub_mul,Finset.sum_sub_distrib]
  rw [he]
  exact (norm_sub_le _ _).trans ((add_le_add (hK a b) (hL a b)).trans_eq (by ring))

end Elliptic.Operator
