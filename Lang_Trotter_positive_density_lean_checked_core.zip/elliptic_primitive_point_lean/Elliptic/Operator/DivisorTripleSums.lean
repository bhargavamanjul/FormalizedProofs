module
public import Elliptic.Operator.DivisorFourFactors
public import Mathlib.NumberTheory.Harmonic.Bounds

/-! Elementary reciprocal sums for the triples left after deleting the
largest factor. The deliberately weaker cardinal bound with log cubed
already gives the required progression estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.DivisorTripleSums
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance tripleDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

def shortTriples (X D : ℕ) : Finset (Fin 3→ℕ) :=
  (Fintype.piFinset (fun _ : Fin 3=>Finset.Icc 1 X)).filter (fun t=>(∏j,t j)≤D)

def harmonicSum (X : ℕ) : ℝ := ∑a∈Finset.Icc 1 X,1/(a:ℝ)

theorem harmonicSum_nonneg (X : ℕ) : 0≤harmonicSum X :=
  Finset.sum_nonneg (fun _ _=>by positivity)

theorem harmonicSum_le_log (X : ℕ) : harmonicSum X≤1+Real.log X := by
  simpa only [harmonicSum,harmonic_eq_sum_Icc,Rat.cast_sum,Rat.cast_inv,Rat.cast_natCast,one_div]
    using harmonic_le_one_add_log X

theorem mem_shortTriples (X D : ℕ) (t : Fin 3→ℕ) :
    t∈shortTriples X D ↔ (∀i,1≤t i ∧ t i≤X) ∧ (∏i,t i)≤D := by
  simp only [shortTriples,Finset.mem_filter,Fintype.mem_piFinset,Finset.mem_Icc]

theorem product_pos {X D : ℕ} {t : Fin 3→ℕ} (ht : t∈shortTriples X D) :
    0<∏i,t i := Finset.prod_pos (fun i _=>lt_of_lt_of_le Nat.zero_lt_one
      (((mem_shortTriples X D t).mp ht).1 i).1)

theorem reciprocal_sum_le (X D : ℕ) :
    (∑t∈shortTriples X D,1/((∏j,t j:ℕ):ℝ))≤harmonicSum X^3 := by
  have hs : shortTriples X D⊆Fintype.piFinset (fun _ : Fin 3=>Finset.Icc 1 X) :=
    Finset.filter_subset _ _
  calc
    _ ≤ ∑t∈Fintype.piFinset (fun _ : Fin 3=>Finset.Icc 1 X),1/((∏j,t j:ℕ):ℝ) :=
      Finset.sum_le_sum_of_subset_of_nonneg hs (fun _ _ _=>by positivity)
    _ = _ := by
      simp only [Nat.cast_prod,one_div,←Finset.prod_inv_distrib]
      rw [Finset.sum_prod_piFinset (Finset.Icc 1 X) (fun (_i : Fin 3) (a : ℕ)=>(a:ℝ)⁻¹)]
      simp [harmonicSum,one_div]

theorem shortTriples_card_le (X D : ℕ) :
    ((shortTriples X D).card:ℝ)≤D*harmonicSum X^3 := by
  have hterm (t : Fin 3→ℕ) (ht : t∈shortTriples X D) :
      (1:ℝ)≤D*(1/((∏j,t j:ℕ):ℝ)) := by
    have hp : (0:ℝ)<(∏j,t j:ℕ) := by exact_mod_cast product_pos ht
    rw [mul_one_div]
    exact (one_le_div hp).mpr (by exact_mod_cast ((mem_shortTriples X D t).mp ht).2)
  calc
    _ = ∑_t∈shortTriples X D,(1:ℝ) := by simp
    _ ≤ ∑t∈shortTriples X D,(D:ℝ)*(1/((∏j,t j:ℕ):ℝ)) := Finset.sum_le_sum hterm
    _ = D*(∑t∈shortTriples X D,1/((∏j,t j:ℕ):ℝ)) := by rw [Finset.mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (reciprocal_sum_le X D) (Nat.cast_nonneg D)

/-- The exact expression arising from counting one residue class per
retained triple. Both terms have the same harmless logarithmic factor. -/
theorem progression_budget (X D : ℕ) (H : ℝ) (hH : 0≤H) :
    (∑t∈shortTriples X D,(H/((∏j,t j:ℕ):ℝ)+1))≤(H+D)*(1+Real.log X)^3 := by
  rw [Finset.sum_add_distrib]
  simp only [Finset.sum_const,nsmul_eq_mul,mul_one]
  have hsum : (∑t∈shortTriples X D,H/((∏j,t j:ℕ):ℝ))≤H*harmonicSum X^3 := by
    simpa only [Finset.mul_sum,mul_one_div] using
      mul_le_mul_of_nonneg_left (reciprocal_sum_le X D) hH
  calc
    _ ≤ H*harmonicSum X^3+D*harmonicSum X^3 := add_le_add hsum (shortTriples_card_le X D)
    _ = (H+D)*harmonicSum X^3 := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (harmonicSum_nonneg X)
      (harmonicSum_le_log X) 3) (by positivity)

end Elliptic.Operator.DivisorTripleSums
