module

public import Elliptic.Operator.RootIntegratedBonferroni

/-! # One literal integer-root sum for different monomial moduli -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootLiteralSum
open scoped BigOperators
open SourceRootCount SourceRootTransfer RootVariableSum RootGridPartition
open RootRecordBonferroni OriginalPathWeights SourceBonferroni
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

def literalRootSum (U V : ℝ) (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ) : ℂ :=
  ∑t∈rootCandidates U V,if ht : Canonical t then
    if InRootBox (normalizedRoot U V t) then
      F (normalizedRoot U V t) (canonicalSL2 t ht) else 0 else 0

theorem literalRootSum_residue (U V : ℝ) (S : ℕ)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) :
    literalRootSum U V (fun q g=>F q (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod S)) g)) =
      variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1) F := by
  simp only [literalRootSum,variableRootSum,InRootBox,InIntervals,fullInterval,
    RootInterval.Contains,ite_true,and_assoc]

theorem literalRootSum_congr (U V : ℝ)
    (F G : RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ)
    (h : ∀q g,F q g=G q g) : literalRootSum U V F=literalRootSum U V G := by
  congr 1
  funext q g
  exact h q g

theorem literalRootSum_sum {I : Type*} (s : Finset I) (U V : ℝ)
    (F : I→RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ) :
    literalRootSum U V (fun q g=>∑i∈s,F i q g)=∑i∈s,literalRootSum U V (F i) := by
  unfold literalRootSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs <;> simp
  · simp [hcan]

theorem literalRootSum_sub (U V : ℝ)
    (F G : RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ) :
    literalRootSum U V F-literalRootSum U V G=literalRootSum U V (fun q g=>F q g-G q g) := by
  unfold literalRootSum
  rw [←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs <;> simp
  · simp [hcan]

/-- A positive gap remains an actual sum over the very same integer
roots; it has not been replaced by an abstract root-average premise. -/
def literalGap (U V : ℝ) (b : Matrix.SpecialLinearGroup (Fin 2) ℤ→ℝ) : ℝ :=
  ∑t∈rootCandidates U V,if ht : Canonical t then
    if InRootBox (normalizedRoot U V t) then b (canonicalSL2 t ht) else 0 else 0

theorem norm_literalRootSum_le (U V : ℝ)
    (F : RootPoint→Matrix.SpecialLinearGroup (Fin 2) ℤ→ℂ)
    (b : Matrix.SpecialLinearGroup (Fin 2) ℤ→ℝ) (h : ∀q g,‖F q g‖≤b g) :
    ‖literalRootSum U V F‖≤literalGap U V b := by
  unfold literalRootSum literalGap
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro t ht
  by_cases hcan : Canonical t
  · simp only [dite_eq_left hcan]
    split_ifs
    · exact h _ _
    · simp
  · simp [hcan]

variable {K J N R Q : ℕ}

/-- Exact polynomial expansion, retaining the actual geometry at every
canonical integer root and the signed active-union-subset tests. -/
theorem literal_truncation_sparse (rec : Record K J N R Q) (primes : Finset ℕ)
    (η : ℕ→ℝ) (T : ℕ) (U V : ℝ) (G : RootPoint→ℂ)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) :
    literalRootSum U V (fun q g=>G q*(activeFactor rec η (fun p=>ℓ g p):ℂ)*
      (truncation primes (fun p=>loss rec η p (ℓ g p)) T:ℝ)) =
    ∑s∈BonferroniMonomialCount.truncatedSubsets primes T,
      literalRootSum U V (fun q g=>G q*subsetTest rec η s (fun p=>ℓ g p)) := by
  rw [←literalRootSum_sum]
  apply literalRootSum_congr
  intro q g
  rw [←Finset.mul_sum,←truncation_subsetTests,mul_assoc]

/-- The signed complete-to-polynomial discrepancy is bounded by its
literal positive elementary gap over canonical integer roots. -/
theorem literal_remainder (rec : Record K J N R Q) (primes : Finset ℕ)
    (hA : activePrimes rec⊆primes) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (m : ℕ) (U V : ℝ)
    (G : RootPoint→ℂ) (hG : ∀q,‖G q‖≤1)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) :
    ‖literalRootSum U V (fun q g=>G q*(residueFactor rec primes η (ℓ g):ℂ)) -
      ∑s∈BonferroniMonomialCount.truncatedSubsets primes (2*m),
        literalRootSum U V (fun q g=>G q*subsetTest rec η s (fun p=>ℓ g p))‖ ≤
      literalGap U V (fun g=>elementary primes (fun p=>loss rec η p (ℓ g p)) (2*m+1)) := by
  rw [←literalRootSum_sum,literalRootSum_sub]
  apply norm_literalRootSum_le
  intro q g
  rw [←Finset.mul_sum]
  exact residue_remainder rec primes hA η hη (ℓ g) m (G q) (hG q)

end Elliptic.Operator.RootLiteralSum
