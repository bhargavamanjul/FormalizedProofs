module

public import Elliptic.Operator.PhysicalRootMomentNumeric
public import Elliptic.Operator.RootFullRecordComparison

/-!
# Uniform replacement of the original physical closed moment

The full signed root comparison is now applied to the actual closed path
record family, after the proved physical-coordinate and prime-factor
identifications. One threshold covers all later alphabets, dyads, tests and
coefficients. The source root-count proposition remains an explicit input.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootMomentComparison
open scoped BigOperators
open Filter SourceRootCount IntegerRootReplacement OriginalPathWeights
open PhysicalRootMomentNumeric RootRecordKernel RootRecordComparison
open RootFullRecordComparison
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

theorem eventually_physical_moment_comparison (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ vmin B A : ℝ)
    (hC : 0≤C) (hδ : 0<δ) (hmin : 0<vmin) (hB : 0≤B) (hA : 0≤A) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ primes : Finset ℕ, ∀ [∀p : primes,Fact p.val.Prime],
      (∀p∈primes,(p:ℝ)≤Real.exp (2*(Real.log x)^(1/5:ℝ))) →
      (∑p∈primes,1/((p:ℝ)+1)≤B) →
      ∀ value : (i : Fin K)→P i→ℕ,
      ∀ hv : ∀i p,value i p<rootPrimeCeiling (Real.log x),
      (∀i,Function.Injective (value i)) → (∀i p,value i p∈primes) →
      ∀ μ : (i : Fin K)→P i→ℝ,
      ∀ damping : ℕ→ℝ, (∀j<momentLength (Real.log x)+1,0≤damping j ∧ damping j≤1) →
      ∀ U V d₀ Y : ℝ, x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 →
      1≤U*V → 0<d₀ → 1≤Y → ∀ VM : Fin K→ℝ, (∀i,vmin≤VM i) →
      ∀ exponents : Fin K→ℝ, ∀ smooth ψ : ℝ→ℂ,
      (∀s,‖smooth s‖≤1) → (∀s,‖ψ s‖≤1) → (∀s,smooth s≠0→1/2≤s) →
      ∀ Cψ : ℝ, 0≤Cψ → (∀s,ψ s≠0→|s|≤Cψ) →
      ⌈16+4096*(momentLength (Real.log x):ℝ)*(2*d₀*Y*Cψ)⌉₊≤rootPositionRadius C (Real.log x) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : ℕ→Bool,
      let records := closedRecords (J:=momentPadding (Real.log x)) (N:=momentLength (Real.log x))
        (R:=rootPositionRadius C (Real.log x)) value hv
      let G := fun rec=>recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y (Real.log x)
        exponents smooth ψ major σ
      ‖physicalMoment (J:=momentPadding (Real.log x)) (N:=momentLength (Real.log x))
        value μ VM d₀ Y (Real.log x) U V exponents smooth ψ major σ adjoint primes damping -
        (normalization VM (momentPadding (Real.log x)) (momentLength (Real.log x)):ℂ)*
          ∑rec∈records,integralComplete rec primes damping U V (G rec)‖ ≤
      U*V*(Real.log x)^(-A*(momentLength (Real.log x):ℝ)) := by
  filter_upwards [eventually_full_moment_comparison hPD K hK C δ vmin B A hC hδ hmin hB hA,
    eventually_gt_atTop (0:ℝ),Real.tendsto_log_atTop.eventually (eventually_gt_atTop (0:ℝ))]
    with x hcomp hx hL
  intro P instP primes instPrimes hbounds hmass value hv hinj hvalues μ damping hdamping
    U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM exponents smooth ψ hsmooth hψ hsupport
    Cψ hCψ hsuppψ hR major hmajor σ adjoint
  dsimp only
  have hp : ∀p∈primes,p.Prime := fun p hp=>@Fact.out _ (instPrimes ⟨p,hp⟩)
  have hu : 0<U := (Real.rpow_pos_of_pos hx δ).trans_le hU
  have hv' : 0<V := (Real.rpow_pos_of_pos hx δ).trans_le hV
  rw [physicalMoment,closed_physical_moment_eq_numerical_root_sum value hv hinj μ VM
    d₀ Y (Real.log x) U V Cψ exponents hu hv' smooth ψ major σ adjoint
    (momentLength_pos hL) hd (by linarith) hCψ hsuppψ hR primes hp damping,←mul_sub]
  exact hcomp P _ primes (fun rec hr=>closedRecords_active_subset value hv primes hvalues rec hr)
    hbounds hmass damping hdamping U V d₀ Y hU hU' hV hV' hUV hd hY VM hVM
    value μ (fun i p=>(hv i p).le) exponents smooth ψ hsmooth hψ hsupport major hmajor σ
    (fun j=>adjoint j.val)

end Elliptic.Operator.PhysicalRootMomentComparison
