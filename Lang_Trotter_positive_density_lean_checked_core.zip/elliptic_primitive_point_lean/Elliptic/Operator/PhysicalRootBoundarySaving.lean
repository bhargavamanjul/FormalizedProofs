module
public import Elliptic.Operator.PhysicalBoundaryTransformedSaving
public import Elliptic.Operator.PhysicalRootSmallCapComparison

/-! The proved physical boundary estimate applies to the exact root
integrand, including the unnormalized root endpoint vectors. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootBoundarySaving
open Filter MeasureTheory
open scoped BigOperators SchwartzMap
open CanonicalBoundaryAssembly PhysicalBoundaryMoment PhysicalLowRankOrientedSaving
open PhysicalRootIndependentMoment RootRecordEncoding RootGridMeasure RootGridPartition
open OriginalLifespanSchedule IntegerRootReplacement PhysicalRootMomentNumeric
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem rootPositionRadius_one_le (C L : ℝ) : 1≤rootPositionRadius C L := by
  unfold rootPositionRadius
  apply Nat.one_le_ceil_iff.mpr
  positivity

 theorem rootEndpoint_eq_atPosition {K J R : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (hmem : (1,0)∈integerPositionBox R) :
    rootEndpoint (P:=P) (J:=J) (R:=R)=atPosition (P:=P) (J:=J) (⟨(1,0),hmem⟩ : integerPositionBox R) := by
  funext u
  simp only [rootEndpoint,atPosition,Subtype.ext_iff]

 theorem independentBoundary_eq_transformed_pairing {K J N R B : ℕ}
    (groups : Fin K→Finset ℕ) [∀i (p:groups i),Fact p.val.Prime]
    (VM : Fin K→ℝ) (damping : ℕ→ℝ) (ρ : ℝ) (adjoint : ℕ→Bool)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ) (H : ℝ) (σ : ℤ)
    (q : RootGridMeasure.RootPoint) (hmem : (1,0)∈integerPositionBox R) :
    independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) (fun i (p:groups i)=>p.val)
      (fun i (p:groups i)=>1/(VM i*p.val)) VM damping ρ adjoint U V d₀ Y L exponents smooth ψ
      (sourceMajorArcs H Y) σ q=
    boundaryPairing (J:=J) (B:=B)
      (fun i (p:groups i)=>transformedPrimeMass (Finset.range (N+1)) damping (VM i) p.val)
      VM damping (fun j=>1-damping j) ρ
      (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:integerPositionBox R=>z.val))
      (literalOrientedGeometry (integerPositionBox R) groups (fun i (p:groups i)=>1/(VM i*p.val))
        d₀ Y L exponents q U V smooth ψ H adjoint (fun _=>σ))
      (fun i (p:groups i)=>p.val) N
      (atPosition (⟨(1,0),hmem⟩ : integerPositionBox R)) (atPosition (⟨(1,0),hmem⟩ : integerPositionBox R)) := by
  unfold independentBoundary
  rw [rootEndpoint_eq_atPosition hmem]
  rfl

 theorem exists_group_count_for_root_integrand (E : ℝ) (hE : 0≤E) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(ψ : 𝓢(ℝ,ℂ)) (smooth : ℝ→ℂ) (Cψ ρ vmin vmax Qg : ℝ),
      1≤Cψ→0<ρ→ρ<1→0<vmin→Qg<ρ^2→
      (∀t,‖smooth t‖≤1)→(∀t,smooth t≠0→1≤t)→
      (∀t,‖ψ t‖≤1)→(∀t,ψ t≠0→|t|≤Cψ)→
      ∀ᶠL : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀groups : Fin K→Finset ℕ,∀[∀i (p:groups i),Fact p.val.Prime],
      (∀i j,i≠j→Disjoint (groups i) (groups j))→∀VM : Fin K→ℝ,
      (∀i,vmin≤VM i)→(∀i,VM i≤vmax)→(∀i,VM i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      ∀(R : ℕ),1≤R→∀(d₀ Y : ℝ) (U V : ℝ),0<U→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀damping : ℕ→ℝ,(∀j,0≤damping j)→(∀j,damping j≤1)→(∀j,1-damping j≤Qg)→
      ∀(adjoint : ℕ→Bool) (σ : ℤ),(σ=1∨σ= -1)→∀q∈rootBox,
      ‖independentBoundary (J:=momentPadding L) (N:=momentLength L) (R:=R) (B:=memoryCutoff L)
        (fun i (p:groups i)=>p.val) (fun i (p:groups i)=>1/(VM i*p.val)) VM damping ρ adjoint
        U V d₀ Y L a smooth ψ (sourceMajorArcs (L^(sourceContractionExponent E+6)) Y) σ q‖≤
      L^(-E*(momentLength L:ℝ)) := by
  obtain ⟨K₀,hK₀,hbound⟩ := PhysicalBoundaryTransformedSaving.exists_group_count_for_transformed_boundary E hE
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ψ smooth Cψ ρ vmin vmax Qg hCψ hρ hρ1 hmin hQg hsmooth hsupport hψ hsuppψ
  filter_upwards [hbound K hK ψ smooth Cψ 1 ρ vmin vmax Qg hCψ (by norm_num) hρ hρ1 hmin hQg
    hsmooth hsupport hψ hsuppψ] with L hb
  intro a ha groups instPr hdis VM hVlo hVhi hVsum hband R hR d₀ Y U V hU hd hY hYlo hYhi
    damping hd0 hd1 hq adjoint σ hσ q hqbox
  letI : ∀i (p:groups i),Fact p.val.Prime := instPr
  have hmem : (1,0)∈integerPositionBox R := by
    apply mem_integerPositionBox_of_abs
    · norm_num; exact_mod_cast hR
    · norm_num
  rw [independentBoundary_eq_transformed_pairing groups VM damping ρ adjoint U V d₀ Y L a smooth ψ _ σ q hmem]
  exact hb a ha (integerPositionBox R) groups inferInstance
    (fun i p hp=>@Fact.out p.Prime (instPr i ⟨p,hp⟩)) hdis VM hVlo hVhi hVsum hband
    d₀ Y q U V hU hqbox.1 hqbox.2.1 hd hY hYlo hYhi damping (fun j=>1-damping j)
    (fun j=>sub_nonneg.mpr (hd1 j)) hq hd0 hd1 adjoint (fun _=>σ) (fun _=>hσ) _ _

end Elliptic.Operator.PhysicalRootBoundarySaving
