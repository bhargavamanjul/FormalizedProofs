module
public import Elliptic.Operator.SingleEdgeTargetCount

/-! A literal finite partition by the slope interval of width `H/U²`.
Primitive positions in the physical first-coordinate strip have O(H)
points per patch, and a determinant cutoff gives bounded patch overlap. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalSlopePatches
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option maxHeartbeats 500000

 def coordinate (U H : ℝ) (z : ℤ×ℤ) : ℝ := U^2/H*((z.2:ℝ)/(z.1:ℝ))
 def patchIndex (U H : ℝ) (z : ℤ×ℤ) : ℤ := ⌊coordinate U H z⌋
 def patch (positions : Finset (ℤ×ℤ)) (U H : ℝ) (i : ℤ) : Finset (ℤ×ℤ) :=
   positions.filter (fun z=>patchIndex U H z=i)
 def indices (positions : Finset (ℤ×ℤ)) (U H : ℝ) : Finset ℤ :=
   positions.image (patchIndex U H)
 def neighbors (D : ℕ) (i : ℤ) : Finset ℤ := Finset.Icc (i-D) (i+D)

 theorem mem_patch (positions : Finset (ℤ×ℤ)) (U H : ℝ) (i : ℤ) (z : ℤ×ℤ) :
    z∈patch positions U H i ↔ z∈positions ∧ patchIndex U H z=i := by
  simp only [patch,Finset.mem_filter]

 theorem sum_patches {M : Type*} [AddCommMonoid M] (positions : Finset (ℤ×ℤ))
    (U H : ℝ) (f : (ℤ×ℤ)→M) :
    (∑i∈indices positions U H,∑z∈patch positions U H i,f z)=∑z∈positions,f z := by
  exact Finset.sum_fiberwise_of_maps_to (fun z hz=>Finset.mem_image_of_mem _ hz) f

 theorem coordinate_sub (U H : ℝ) (hU : U≠0) (hH : H≠0)
    (z w : ℤ×ℤ) (hz : (z.1:ℝ)≠0) (hw : (w.1:ℝ)≠0) :
    coordinate U H w-coordinate U H z=
      U^2/(H*(z.1:ℝ)*(w.1:ℝ))*(latticeDet z w:ℝ) := by
  unfold coordinate latticeDet
  push_cast
  field_simp
  <;> ring

 theorem same_patch_coordinate_le (U H : ℝ) (z w : ℤ×ℤ)
    (he : patchIndex U H z=patchIndex U H w) :
    |coordinate U H w-coordinate U H z|≤1 := by
  have hz := Int.floor_le (coordinate U H z)
  have hz' := Int.lt_floor_add_one (coordinate U H z)
  have hw := Int.floor_le (coordinate U H w)
  have hw' := Int.lt_floor_add_one (coordinate U H w)
  have he' : (⌊coordinate U H z⌋:ℝ)=(⌊coordinate U H w⌋:ℝ) := congrArg (fun x:ℤ=>(x:ℝ)) he
  exact abs_le.mpr ⟨by linarith,by linarith⟩

 theorem same_patch_det_le (U H : ℝ) (hU : 0<U) (hH : 0<H)
    (z w : ℤ×ℤ) (hzlo : U≤(z.1:ℝ)) (hzhi : (z.1:ℝ)≤16*U)
    (hwlo : U≤(w.1:ℝ)) (hwhi : (w.1:ℝ)≤16*U)
    (he : patchIndex U H z=patchIndex U H w) : |(latticeDet z w:ℝ)|≤256*H := by
  have hz : 0<(z.1:ℝ) := hU.trans_le hzlo
  have hw : 0<(w.1:ℝ) := hU.trans_le hwlo
  have hc := same_patch_coordinate_le U H z w he
  have hid : (latticeDet z w:ℝ)=
      (H/U^2)*((z.1:ℝ)*(w.1:ℝ))*(coordinate U H w-coordinate U H z) := by
    rw [coordinate_sub U H hU.ne' hH.ne' z w hz.ne' hw.ne']
    field_simp
  rw [hid,abs_mul,abs_mul,abs_of_pos (div_pos hH (sq_pos_of_pos hU)),
    abs_of_pos (mul_pos hz hw)]
  calc
    _ ≤ H/U^2*((z.1:ℝ)*(w.1:ℝ)) := mul_le_of_le_one_right (by positivity) hc
    _ ≤ H/U^2*((16*U)*(16*U)) := mul_le_mul_of_nonneg_left
      (mul_le_mul hzhi hwhi hw.le (by positivity)) (by positivity)
    _ = 256*H := by field_simp <;> ring

 theorem coordinate_distance_le_of_det (U H C : ℝ) (hU : 0<U) (hH : 0<H) (hC : 0≤C)
    (z w : ℤ×ℤ) (hzlo : U≤(z.1:ℝ)) (hwlo : U≤(w.1:ℝ))
    (hdet : |(latticeDet z w:ℝ)|≤C*H) :
    |coordinate U H w-coordinate U H z|≤C := by
  have hz : 0<(z.1:ℝ) := hU.trans_le hzlo
  have hw : 0<(w.1:ℝ) := hU.trans_le hwlo
  have hprod : U^2≤(z.1:ℝ)*(w.1:ℝ) := by
    simpa only [pow_two] using mul_le_mul hzlo hwlo hU.le hz.le
  rw [coordinate_sub U H hU.ne' hH.ne' z w hz.ne' hw.ne',abs_mul,
    abs_of_pos (div_pos (sq_pos_of_pos hU) (mul_pos (mul_pos hH hz) hw))]
  calc
    _ ≤ U^2/(H*(z.1:ℝ)*(w.1:ℝ))*(C*H) := mul_le_mul_of_nonneg_left hdet (by positivity)
    _ = C*(U^2/((z.1:ℝ)*(w.1:ℝ))) := by field_simp <;> ring
    _ ≤ C*1 := mul_le_mul_of_nonneg_left ((div_le_one (mul_pos hz hw)).mpr hprod) hC
    _ = C := mul_one _

 theorem index_distance_le_of_det (U H C : ℝ) (hU : 0<U) (hH : 0<H) (hC : 0≤C)
    (z w : ℤ×ℤ) (hzlo : U≤(z.1:ℝ)) (hwlo : U≤(w.1:ℝ))
    (hdet : |(latticeDet z w:ℝ)|≤C*H) :
    |patchIndex U H z-patchIndex U H w|≤⌈C⌉+1 := by
  have hc := abs_le.mp (coordinate_distance_le_of_det U H C hU hH hC z w hzlo hwlo hdet)
  have hz := Int.floor_le (coordinate U H z)
  have hz' := Int.lt_floor_add_one (coordinate U H z)
  have hw := Int.floor_le (coordinate U H w)
  have hw' := Int.lt_floor_add_one (coordinate U H w)
  have hceil := Int.le_ceil C
  have hr : |(patchIndex U H z:ℝ)-(patchIndex U H w:ℝ)|≤(⌈C⌉:ℝ)+1 :=
    abs_le.mpr ⟨by dsimp [patchIndex];linarith,by dsimp [patchIndex];linarith⟩
  exact_mod_cast hr

 theorem patch_card_le (positions : Finset (ℤ×ℤ)) (U H : ℝ) (hU : 0<U) (hH : 1≤H)
    (hprimitive : ∀z∈positions,IsCoprime z.1 z.2)
    (hstrip : ∀z∈positions,U≤(z.1:ℝ) ∧ (z.1:ℝ)≤16*U) (i : ℤ) :
    ((patch positions U H i).card:ℝ)≤16929*H := by
  by_cases hempty : patch positions U H i=∅
  · rw [hempty];simp only [Finset.card_empty,Nat.cast_zero];positivity
  obtain ⟨z,hz⟩ := Finset.nonempty_iff_ne_empty.mpr hempty
  have hz' := (mem_patch positions U H i z).mp hz
  obtain ⟨w,hw⟩ := exists_unimodular_complement (hprimitive z hz'.1)
  have hzpos : 0<(z.1:ℝ) := hU.trans_le (hstrip z hz'.1).1
  have ht := SingleEdgeTargetCount.comparison_targets_card_le hw 0
    (show latticeTau 0 z≠0 by simpa [latticeTau] using hzpos.ne') 1 256 H
    (by norm_num) hH (patch positions U H i) (by
      intro v hv
      have hv' := (mem_patch positions U H i v).mp hv
      refine ⟨one_dvd _,?_,?_⟩
      · simpa only [Int.ediv_one] using same_patch_det_le U H hU (by linarith) z v
          (hstrip z hz'.1).1 (hstrip z hz'.1).2 (hstrip v hv'.1).1 (hstrip v hv'.1).2
          (hz'.2.trans hv'.2.symm)
      · simp only [latticeTau,zero_mul,add_zero]
        rw [abs_of_nonneg (div_nonneg (hU.le.trans (hstrip v hv'.1).1) hzpos.le)]
        apply (div_le_iff₀ hzpos).mpr
        exact (hstrip v hv'.1).2.trans (mul_le_mul_of_nonneg_left (hstrip z hz'.1).1 (by norm_num)))
  norm_num at ht ⊢
  exact ht

 theorem mem_neighbors (D : ℕ) (i j : ℤ) : j∈neighbors D i ↔ |j-i|≤D := by
  simp only [neighbors,Finset.mem_Icc,abs_le]
  omega

 theorem edge_mem_neighbors (U H C : ℝ) (hU : 0<U) (hH : 0<H) (hC : 0≤C)
    (z w : ℤ×ℤ) (hzlo : U≤(z.1:ℝ)) (hwlo : U≤(w.1:ℝ))
    (hdet : |(latticeDet z w:ℝ)|≤C*H) :
    patchIndex U H w∈neighbors (⌈C⌉+1).toNat (patchIndex U H z) := by
  rw [mem_neighbors,abs_sub_comm]
  exact (index_distance_le_of_det U H C hU hH hC z w hzlo hwlo hdet).trans (by omega)

 theorem neighbors_card (D : ℕ) (i : ℤ) : (neighbors D i).card=2*D+1 := by
  simp only [neighbors,Int.card_Icc]
  omega

 theorem neighbor_overlap_le (s : Finset ℤ) (D : ℕ) (j : ℤ) :
    (s.filter (fun i=>j∈neighbors D i)).card≤2*D+1 := by
  apply (Finset.card_le_card (t:=neighbors D j) ?_).trans_eq (neighbors_card D j)
  intro i hi
  rw [mem_neighbors] at *
  have h := (Finset.mem_filter.mp hi).2
  rw [mem_neighbors] at h
  simpa only [abs_sub_comm] using h

 theorem sum_neighbor_patches_le (positions : Finset (ℤ×ℤ)) (U H : ℝ)
    (s : Finset ℤ) (D : ℕ) (f : (ℤ×ℤ)→ℝ) (hf : ∀z∈positions,0≤f z) :
    (∑i∈s,∑z∈positions.filter (fun z=>patchIndex U H z∈neighbors D i),f z)≤
      (2*D+1:ℕ)*(∑z∈positions,f z) := by
  simp only [Finset.sum_filter]
  rw [Finset.sum_comm]
  calc
    _ = ∑z∈positions,((s.filter (fun i=>patchIndex U H z∈neighbors D i)).card:ℝ)*f z := by
      apply Finset.sum_congr rfl
      intro z hz
      rw [←Finset.sum_filter]
      simp
    _ ≤ ∑z∈positions,(2*D+1:ℕ)*f z := Finset.sum_le_sum fun z hz=>
      mul_le_mul_of_nonneg_right (by exact_mod_cast neighbor_overlap_le s D (patchIndex U H z)) (hf z hz)
    _ = _ := by rw [Finset.mul_sum]

end Elliptic.Operator.PhysicalSlopePatches
