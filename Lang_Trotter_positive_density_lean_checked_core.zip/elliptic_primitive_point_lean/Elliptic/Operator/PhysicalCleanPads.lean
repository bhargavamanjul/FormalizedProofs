module
public import Elliptic.Operator.PhysicalCleanNorm

/-! Literal pad classes and physical slope cells. Determinant divisibility
is an equivalence relation on primitive vectors, for every integer D;
no squarefree or probabilistic approximation is used in this partition. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanPads
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalCleanPadsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

/-- Symmetry of exact pad membership. -/
theorem pad_dvd_symm (D : ℤ) (z w : ℤ×ℤ) :
    D∣latticeDet z w ↔ D∣latticeDet w z := by
  have he : latticeDet w z= -latticeDet z w := by dsimp [latticeDet]; ring
  rw [he,dvd_neg]

/-- Two vectors in the pad through a primitive vector have mutual
 determinant divisible by the same literal D. -/
theorem pad_dvd_pair (D : ℤ) (z u v : ℤ×ℤ) (hz : IsCoprime z.1 z.2)
    (hu : D∣latticeDet z u) (hv : D∣latticeDet z v) : D∣latticeDet u v := by
  obtain ⟨w,hw⟩ := exists_unimodular_complement hz
  exact ⟨latticeDet (PhysicalPadLattice.padCoordinates z w D u)
    (PhysicalPadLattice.padCoordinates z w D v),
      (PhysicalPadLattice.padCoordinates_det z w hw D u v hu hv).symm⟩

/-- The actual physical pad equivalence. -/
def padSetoid {Z : Type*} (position : Z → ℤ×ℤ)
    (hprim : ∀ z, IsCoprime (position z).1 (position z).2) (D : ℤ) : Setoid Z where
  r z w := D∣latticeDet (position z) (position w)
  iseqv := ⟨by intro z; simp [latticeDet,mul_comm],
    by intro z w h; exact (pad_dvd_symm D _ _).mp h,
    by intro z u v hzu huv
       exact pad_dvd_pair D (position u) (position z) (position v) (hprim u)
         ((pad_dvd_symm D _ _).mp hzu) huv⟩

/-- The finite, concrete Boolean membership profile names a pad class.
This avoids any choice of a projective representative modulo D. -/
def padProfile {Z : Type*} (position : Z → ℤ×ℤ) (D : ℤ) (z : Z) : Z → Bool :=
  fun w => decide (D∣latticeDet (position z) (position w))

theorem padProfile_eq_iff {Z : Type*} (position : Z → ℤ×ℤ)
    (hprim : ∀ z, IsCoprime (position z).1 (position z).2) (D : ℤ) (z w : Z) :
    padProfile position D z=padProfile position D w ↔ D∣latticeDet (position z) (position w) := by
  let S := padSetoid position hprim D
  constructor
  · intro h
    have hh := congrFun h w
    have hw : D∣latticeDet (position w) (position w) := S.refl w
    simpa only [padProfile,decide_eq_true hw,decide_eq_true_eq] using hh
  · intro h
    funext v
    have he : (D∣latticeDet (position z) (position v)) = (D∣latticeDet (position w) (position v)) :=
      propext ⟨fun hv => S.trans (S.symm h) hv, fun hv => S.trans h hv⟩
    simp only [padProfile,he]

/-- Physical slope cells have the source's literal width d0*Y. -/
def slopeCell (r d₀ Y : ℝ) (z : ℤ×ℤ) : ℤ := ⌊latticeSlope r z/(d₀*Y)⌋

theorem slopeCell_near (r d₀ Y C : ℝ) (hd : 0<d₀) (hY : 0<Y)
    (z w : ℤ×ℤ) (h : |latticeSlope r z-latticeSlope r w|≤C*d₀*Y) :
    |((slopeCell r d₀ Y z-slopeCell r d₀ Y w:ℤ):ℝ)|≤C+1 := by
  have hh : |latticeSlope r z/(d₀*Y)-latticeSlope r w/(d₀*Y)|≤C := by
    rw [← sub_div,abs_div,abs_of_pos (mul_pos hd hY)]
    apply (div_le_iff₀ (mul_pos hd hY)).mpr
    nlinarith
  have hz₀ := Int.floor_le (latticeSlope r z/(d₀*Y))
  have hz₁ := Int.lt_floor_add_one (latticeSlope r z/(d₀*Y))
  have hw₀ := Int.floor_le (latticeSlope r w/(d₀*Y))
  have hw₁ := Int.lt_floor_add_one (latticeSlope r w/(d₀*Y))
  rw [abs_le] at hh ⊢
  dsimp [slopeCell]
  push_cast
  constructor <;> linarith

end Elliptic.Operator.PhysicalCleanPads
