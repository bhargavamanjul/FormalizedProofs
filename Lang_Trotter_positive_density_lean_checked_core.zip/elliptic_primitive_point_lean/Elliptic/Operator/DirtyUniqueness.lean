module

public import Mathlib.Analysis.Normed.Group.AddCircle
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Nat.GCD.BigOperators
public import Mathlib.Data.Fintype.Card
public import Mathlib.LinearAlgebra.Projectivization.Basic
public import Mathlib.Algebra.Ring.GeomSum
public import Elliptic.SuccessorSign
public import Mathlib.Tactic

/-!
# The exact uniqueness mechanism for dirty raw edges

This module proves the steps after equations (4.35)--(4.36) of the
prime-predecessor source. Circle-separated phases in a shorter real
interval determine the numeric product. The old-prime/new-prime ban
then separates its two factors. Distinct prime labels make the omitted
slot tuple unique, so normalized source averaging costs at most `M⁻ᴷ`.
The good-state phase-separation hypothesis is explicit; it is not a
hypothesis of product or omission uniqueness.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def PhaseSeparated (s : Finset ℕ) (α δ : ℝ) : Prop :=
  ∀ a ∈ s, ∀ b ∈ s, a ≠ b →
    δ ≤ dist (((a : ℝ) * α : ℝ) : AddCircle (1 : ℝ))
      (((b : ℝ) * α : ℝ) : AddCircle (1 : ℝ))

theorem circle_dist_le_real_dist (a b : ℝ) :
    dist (a : AddCircle (1 : ℝ)) (b : AddCircle (1 : ℝ)) ≤ |a-b| := by
  rw [dist_eq_norm, ← QuotientAddGroup.mk_sub]
  exact QuotientAddGroup.norm_mk_le_norm

/-- The full modular window version, allowing different integer lifts for
different products. This is the form needed after fixing `h` modulo `p`. -/
theorem phase_separated_circle_unique {s : Finset ℕ} {α δ r : ℝ}
    (hsep : PhaseSeparated s α δ) (hwidth : 2*r < δ)
    {a b : ℕ} (ha : a ∈ s) (hb : b ∈ s) (c : AddCircle (1 : ℝ))
    (hai : dist (((a : ℝ)*α : ℝ) : AddCircle (1 : ℝ)) c ≤ r)
    (hbi : dist (((b : ℝ)*α : ℝ) : AddCircle (1 : ℝ)) c ≤ r) : a=b := by
  by_contra hab
  have hlo := hsep a ha b hb hab
  have htri := dist_triangle (((a : ℝ)*α : ℝ) : AddCircle (1 : ℝ)) c
    (((b : ℝ)*α : ℝ) : AddCircle (1 : ℝ))
  rw [dist_comm c] at htri
  linarith

/-- The centre is arbitrary. This includes either sign of the determinant
equation and allows the interval to cross an integer boundary. -/
theorem phase_separated_interval_unique {s : Finset ℕ} {α δ c r : ℝ}
    (hsep : PhaseSeparated s α δ) (hwidth : 2*r < δ)
    {a b : ℕ} (ha : a ∈ s) (hb : b ∈ s)
    (hai : |(a : ℝ)*α-c| ≤ r) (hbi : |(b : ℝ)*α-c| ≤ r) : a=b := by
  by_contra hab
  have hlow := hsep a ha b hb hab
  have hupp : dist (((a : ℝ)*α : ℝ) : AddCircle (1 : ℝ))
      (((b : ℝ)*α : ℝ) : AddCircle (1 : ℝ)) ≤ 2*r := by
    apply (circle_dist_le_real_dist _ _).trans
    calc
      |(a : ℝ)*α-(b : ℝ)*α| = |((a : ℝ)*α-c) + (c-(b : ℝ)*α)| := by congr 1; ring
      _ ≤ |(a : ℝ)*α-c| + |c-(b : ℝ)*α| := abs_add_le _ _
      _ ≤ 2*r := by rw [abs_sub_comm c]; linarith
  linarith

theorem phase_separated_interval_card_le_one {s : Finset ℕ} {α δ c r : ℝ}
    (hsep : PhaseSeparated s α δ) (hwidth : 2*r < δ) :
    (s.filter (fun a : ℕ => |(a : ℝ)*α-c| ≤ r)).card ≤ 1 := by
  rw [Finset.card_le_one]
  intro a ha b hb
  exact phase_separated_interval_unique hsep hwidth
    (Finset.mem_filter.mp ha).1 (Finset.mem_filter.mp hb).1
    (Finset.mem_filter.mp ha).2 (Finset.mem_filter.mp hb).2

/-- The constants in the source leave a strict margin: interval diameter
`32/p` is less than phase separation `100 exp(-A)` when `p ≥ exp(A)`. -/
theorem dirty_interval_width {p A : ℝ} (hp : Real.exp A ≤ p) :
    2*(16/p) < 100 * Real.exp (-A) := by
  have hp0 : 0 < p := (Real.exp_pos A).trans_le hp
  have hprod : 1 ≤ p * Real.exp (-A) := by
    have he := mul_le_mul_of_nonneg_right hp (Real.exp_pos (-A)).le
    simpa only [← Real.exp_add, add_neg_cancel, Real.exp_zero] using he
  rw [show 2*(16/p) = 32/p by ring, div_lt_iff₀ hp0]
  nlinarith

/-- Coprimality against the full source product separates old and new
factors. This proves the factorization claim without unique-factorization
data being supplied as an extra premise. -/
theorem old_new_factorization_unique {P D D' Z Z' : ℕ}
    (hD : D ∣ P) (hD' : D' ∣ P) (hD0 : D ≠ 0)
    (hZ : P.Coprime Z) (hZ' : P.Coprime Z')
    (heq : D*Z = D'*Z') : D=D' ∧ Z=Z' := by
  have hle : D ∣ D' := (hZ'.coprime_dvd_left hD).dvd_of_dvd_mul_right
    (heq ▸ dvd_mul_right D Z)
  have hge : D' ∣ D := (hZ.coprime_dvd_left hD').dvd_of_dvd_mul_right
    (heq.symm ▸ dvd_mul_right D' Z')
  have hd := Nat.dvd_antisymm hle hge
  refine ⟨hd, ?_⟩
  rw [← hd] at heq
  exact Nat.eq_of_mul_eq_mul_left (Nat.pos_of_ne_zero hD0) heq

variable {K M : ℕ}

/-- Source labels retained when one slot in every group is omitted. -/
def retainedPrimes (label : Fin K × Fin M → ℕ) (omission : Fin K → Fin M) : Finset ℕ :=
  (Finset.univ.filter (fun ij : Fin K × Fin M => ij.2 ≠ omission ij.1)).image label

def copiedProduct (label : Fin K × Fin M → ℕ) (omission : Fin K → Fin M) : ℕ :=
  (retainedPrimes label omission).prod id

def fullSourceProduct (label : Fin K × Fin M → ℕ) : ℕ :=
  (Finset.univ.image label).prod id

theorem retainedPrimes_injective (label : Fin K × Fin M → ℕ)
    (hinj : Function.Injective label) : Function.Injective (retainedPrimes label) := by
  intro o o' heq
  funext i
  by_contra hne
  have hm : label (i, o i) ∈ retainedPrimes label o' := by
    apply Finset.mem_image.mpr
    exact ⟨(i, o i), by simp [hne], rfl⟩
  rw [← heq] at hm
  obtain ⟨ij, hij, he⟩ := Finset.mem_image.mp hm
  have he' := hinj he
  subst ij
  simp at hij

theorem copiedProduct_injective (label : Fin K × Fin M → ℕ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label) :
    Function.Injective (copiedProduct label) := by
  intro o o' heq
  apply retainedPrimes_injective label hinj
  have hp (o : Fin K → Fin M) : ∀ q ∈ retainedPrimes label o, q.Prime := by
    intro q hq
    obtain ⟨ij, _, rfl⟩ := Finset.mem_image.mp hq
    exact hprime ij
  have he := congrArg Nat.primeFactors heq
  change Nat.primeFactors (∏ q ∈ retainedPrimes label o, q) =
    Nat.primeFactors (∏ q ∈ retainedPrimes label o', q) at he
  simpa only [Nat.primeFactors_prod (hp _)] using he

theorem copiedProduct_ne_zero (label : Fin K × Fin M → ℕ)
    (hprime : ∀ ij, (label ij).Prime) (o : Fin K → Fin M) : copiedProduct label o ≠ 0 := by
  apply Finset.prod_ne_zero_iff.mpr
  intro q hq
  obtain ⟨ij, _, rfl⟩ := Finset.mem_image.mp hq
  exact (hprime ij).ne_zero

theorem copiedProduct_dvd_fullSourceProduct (label : Fin K × Fin M → ℕ)
    (o : Fin K → Fin M) : copiedProduct label o ∣ fullSourceProduct label := by
  apply Finset.prod_dvd_prod_of_subset
  exact Finset.image_subset_image (Finset.filter_subset _ _)

theorem copiedProduct_eq_slot_product (label : Fin K × Fin M → ℕ)
    (hinj : Function.Injective label) (o : Fin K → Fin M) :
    copiedProduct label o =
      ∏ ij : Fin K × Fin M with ij.2 ≠ o ij.1, label ij := by
  exact Finset.prod_image (fun _ _ _ _ he => hinj he)

theorem fullSourceProduct_eq_slot_product (label : Fin K × Fin M → ℕ)
    (hinj : Function.Injective label) :
    fullSourceProduct label = ∏ ij : Fin K × Fin M, label ij := by
  exact Finset.prod_image (fun _ _ _ _ he => hinj he)

/-- The source ban really implies the required coprimality: every new
prime differs from every source label. Repeated new values are allowed. -/
theorem fullSourceProduct_coprime_promoted {ι : Type*} [Fintype ι]
    (label : Fin K × Fin M → ℕ) (promoted : ι → ℕ)
    (hprime : ∀ ij, (label ij).Prime) (hpprime : ∀ i, (promoted i).Prime)
    (hban : ∀ ij i, label ij ≠ promoted i) :
    (fullSourceProduct label).Coprime (∏ i, promoted i) := by
  apply Nat.Coprime.prod_left
  intro q hq
  obtain ⟨ij, _, rfl⟩ := Finset.mem_image.mp hq
  apply Nat.Coprime.prod_right
  intro i _
  exact (Nat.coprime_primes (hprime ij) (hpprime i)).mpr (hban ij i)

theorem fullSourceProduct_mod_ne_zero (p : ℕ) [hp : Fact p.Prime]
    (label : Fin K × Fin M → ℕ) (hprime : ∀ ij, (label ij).Prime)
    (hban : ∀ ij, label ij ≠ p) : (fullSourceProduct label : ZMod p) ≠ 0 := by
  have hc : (fullSourceProduct label).Coprime p := by
    simpa using fullSourceProduct_coprime_promoted label (fun _ : Unit => p)
      hprime (fun _ => hp.out) (fun ij _ => hban ij)
  have hn := hp.out.coprime_iff_not_dvd.mp hc.symm
  exact fun he => hn ((ZMod.natCast_eq_zero_iff _ p).mp he)

/-- The raw determinant's second coordinate stays nonzero modulo the
distinguished old prime, independently of the omission and other products. -/
theorem dirty_determinant_nonzero_of_ban (p : ℕ) [Fact p.Prime]
    (label : Fin K × Fin M → ℕ) (hprime : ∀ ij, (label ij).Prime)
    (hban : ∀ ij, label ij ≠ p) (σ D Z T : ℤ) (hσ : σ=1 ∨ σ= -1) :
    ((σ * (fullSourceProduct label : ℤ) - σ*D*(p : ℤ)*Z*T : ℤ) : ZMod p) ≠ 0 := by
  apply Elliptic.SuccessorSign.dirty_determinant_ne_zero p σ _ D Z T hσ
  simpa using fullSourceProduct_mod_ne_zero p label hprime hban

def dirtyProductSupport (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ) : Finset ℕ :=
  (Finset.univ.product newProducts).image
    (fun oz : (Fin K → Fin M) × ℕ => copiedProduct label oz.1 * oz.2)

def dirtyCompatiblePairs (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (α c r : ℝ) : Finset ((Fin K → Fin M) × ℕ) :=
  (Finset.univ.product newProducts).filter
    (fun oz => |((copiedProduct label oz.1 * oz.2 : ℕ) : ℝ)*α-c| ≤ r)

/-- On a good fresh draw, the actual retained-prime product and new-prime
product are both unique. In particular the source omission tuple is unique. -/
theorem dirtyCompatiblePairs_card_le_one
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    {α δ c r : ℝ} (hsep : PhaseSeparated (dirtyProductSupport label newProducts) α δ)
    (hwidth : 2*r < δ) : (dirtyCompatiblePairs label newProducts α c r).card ≤ 1 := by
  rw [Finset.card_le_one]
  intro a ha b hb
  have ha' := Finset.mem_filter.mp ha
  have hb' := Finset.mem_filter.mp hb
  have he := phase_separated_interval_unique hsep hwidth
    (Finset.mem_image.mpr ⟨a, ha'.1, rfl⟩)
    (Finset.mem_image.mpr ⟨b, hb'.1, rfl⟩) ha'.2 hb'.2
  have hf := old_new_factorization_unique
    (copiedProduct_dvd_fullSourceProduct label a.1)
    (copiedProduct_dvd_fullSourceProduct label b.1)
    (copiedProduct_ne_zero label hprime a.1)
    (hban a.2 (Finset.mem_product.mp ha'.1).2)
    (hban b.2 (Finset.mem_product.mp hb'.1).2) he
  exact Prod.ext (copiedProduct_injective label hprime hinj hf.1) hf.2

/-- The source symmetrization is an average over `M^K` omission tuples,
so the unique compatible numeric choice has mass at most `M⁻ᴷ`. -/
theorem dirtyCompatiblePairs_uniform_mass_le
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    {α δ c r : ℝ} (hsep : PhaseSeparated (dirtyProductSupport label newProducts) α δ)
    (hwidth : 2*r < δ) :
    (∑ _oz ∈ dirtyCompatiblePairs label newProducts α c r, 1/(M : ℝ)^K) ≤ 1/(M : ℝ)^K := by
  have hc := dirtyCompatiblePairs_card_le_one label newProducts hprime hinj hban
    (c := c) hsep hwidth
  rw [Finset.sum_const, nsmul_eq_mul]
  exact mul_le_of_le_one_left (by positivity) (by exact_mod_cast hc)

theorem omission_tuple_count : Fintype.card (Fin K → Fin M) = M^K := by
  simp

/-- Summing over the at most `B` choices of the distinguished promoted
old index produces the `B/M^K` term in the raw row estimate. -/
theorem dirtyCompatiblePairs_sum_uniform_mass_le {B : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (α δ c r : Fin B → ℝ)
    (hsep : ∀ b, PhaseSeparated (dirtyProductSupport label newProducts) (α b) (δ b))
    (hwidth : ∀ b, 2*r b < δ b) :
    (∑ b : Fin B, ∑ _oz ∈ dirtyCompatiblePairs label newProducts (α b) (c b) (r b),
      1/(M : ℝ)^K) ≤ B/(M : ℝ)^K := by
  calc
    _ ≤ ∑ _b : Fin B, 1/(M : ℝ)^K := Finset.sum_le_sum (fun b _ =>
      dirtyCompatiblePairs_uniform_mass_le label newProducts hprime hinj hban
        (hsep b) (hwidth b))
    _ = B/(M : ℝ)^K := by simp [div_eq_mul_inv]

/-- Distinct prime bands identify each promoted numeric prime from their
product, independently of the multiplicity of old indices carrying it. -/
theorem promoted_product_injective {ι : Type*} [Fintype ι]
    (band : ι → Finset ℕ)
    (hprime : ∀ i q, q ∈ band i → q.Prime)
    (hdisjoint : ∀ i j, i ≠ j → Disjoint (band i) (band j)) :
    Function.Injective (fun a : (i : ι) → {q // q ∈ band i} => ∏ i, (a i : ℕ)) := by
  intro a b heq
  dsimp only at heq
  funext i
  have hp : (a i : ℕ).Prime := hprime i _ (a i).property
  have hd : (a i : ℕ) ∣ ∏ j, (b j : ℕ) := by
    rw [← heq]
    exact Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
  obtain ⟨j, _, hj⟩ := ((Nat.prime_iff.mp hp).dvd_finsetProd_iff
    (fun j => (b j : ℕ))).mp hd
  have hijprime : (a i : ℕ) = (b j : ℕ) :=
    (Nat.prime_dvd_prime_iff_eq hp (hprime j _ (b j).property)).mp hj
  have hij : i=j := by
    by_contra hne
    exact Finset.disjoint_left.mp (hdisjoint i j hne) (a i).property
      (hijprime.symm ▸ (b j).property)
  subst j
  exact Subtype.ext hijprime

/-- The elementary multiplicity estimate (4.37), with an explicit
constant depending only on the pending damping parameter. -/
theorem pending_multiplicity_bound (n : ℕ) {ρ : ℝ} (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) :
    (n : ℝ) * ρ^(n-1) ≤ 1/(1-ρ) := by
  have hc : (n : ℝ) * ρ^(n-1) ≤ ∑ i ∈ Finset.range n, ρ^i := by
    calc
      _ = ∑ _i ∈ Finset.range n, ρ^(n-1) := by simp
      _ ≤ _ := Finset.sum_le_sum (fun i hi =>
        pow_le_pow_of_le_one hρ0 hρ1.le (by have := Finset.mem_range.mp hi; omega))
  apply hc.trans
  apply (le_div_iff₀ (sub_pos.mpr hρ1)).mpr
  rw [geom_sum_mul_neg]
  exact sub_le_self _ (pow_nonneg hρ0 n)

/-- Summing over actual eligible old indices remains bounded when all
other hits are damped. Any additional newly stored hits only decrease
the sum; repeated numeric values and anchors require no distinctness. -/
theorem promotion_damping_sum_le {ι : Type*} [DecidableEq ι]
    (hits eligible : Finset ι) (heligible : eligible ⊆ hits)
    (newHits : ℕ) {ρ : ℝ} (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) :
    (∑ _i ∈ eligible, ρ^(hits.card-1+newHits)) ≤ 1/(1-ρ) := by
  calc
    _ ≤ ∑ _i ∈ eligible, ρ^(hits.card-1) := Finset.sum_le_sum (fun _ _ =>
      pow_le_pow_of_le_one hρ0 hρ1.le (Nat.le_add_right _ _))
    _ ≤ ∑ _i ∈ hits, ρ^(hits.card-1) :=
      Finset.sum_le_sum_of_subset_of_nonneg heligible (fun _ _ _ => pow_nonneg hρ0 _)
    _ = (hits.card : ℝ) * ρ^(hits.card-1) := by simp
    _ ≤ 1/(1-ρ) := pending_multiplicity_bound _ hρ0 hρ1

section ProjectiveLine
variable {k : Type*} [Field k]

def fixedSecondLine (j : k) (hj : j ≠ 0) (h : k) : Projectivization k (k × k) :=
  Projectivization.mk k (h,j) (fun he => hj (congrArg Prod.snd he))

/-- A projective line with a fixed nonzero second coordinate determines
the first coordinate uniquely, as used immediately after (4.35). -/
theorem fixedSecondLine_injective (j : k) (hj : j ≠ 0) :
    Function.Injective (fixedSecondLine j hj) := by
  intro h h' he
  obtain ⟨a, ha⟩ := (Projectivization.mk_eq_mk_iff' k _ _ _ _).mp he
  have hs : a*j = j := congrArg Prod.snd ha
  have ha1 : a=1 := (mul_right_cancel₀ hj (by simpa using hs : a*j=1*j))
  have hf : a*h'=h := congrArg Prod.fst ha
  simpa only [ha1, one_mul] using hf.symm

end ProjectiveLine

end Elliptic.Operator
