module
public import Elliptic.Operator.MellinPlane
public import Mathlib.Analysis.Analytic.IsolatedZeros
public import Mathlib.Analysis.Calculus.ContDiff.Bounds

/-! Uniform scale regularity for the literal two-dimensional determinant profile. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinPlaneUniform
open Filter MeasureTheory FourierTransform
open scoped Topology SchwartzMap BigOperators
open MellinPlane
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

abbrev Smooth {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (f : E→F) :=
  ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) f

/-- The removable exponential divided difference, including the scale limit. -/
def expDiv (t : ℝ) : ℝ := dslope Real.exp 0 t

theorem expDiv_zero : expDiv 0=1 := by simp [expDiv,dslope_same,Real.deriv_exp]

theorem expDiv_eq (t : ℝ) (ht : t≠0) : expDiv t=(Real.exp t-1)/t := by
  rw [expDiv,dslope_of_ne _ ht,slope_def_field]
  simp

theorem expDiv_smooth : Smooth expDiv := by
  apply contDiff_iff_contDiffAt.mpr
  intro t
  by_cases ht : t=0
  · subst t
    obtain ⟨p,hp⟩ := (analyticAt_rexp (x:=0))
    exact hp.has_fpower_series_dslope_fslope.analyticAt.contDiffAt
  · have he : expDiv =ᶠ[𝓝 t] (fun z:ℝ=>(Real.exp z-1)/z) := by
      filter_upwards [eventually_ne_nhds ht] with z hz
      exact expDiv_eq z hz
    apply ContDiffAt.congr_of_eventuallyEq _ he
    fun_prop

/-- A smooth profile phase in reciprocal scale r, including r=0. -/
def phaseCore (r : ℝ) (u : Plane) : ℝ :=
  Real.exp (u 1)*(u 0*expDiv (r*u 0))

theorem phaseCore_smooth : Smooth (fun p:ℝ×Plane=>phaseCore p.1 p.2) := by
  have hc (i:Fin 2) : Smooth (fun p:ℝ×Plane=>p.2 i) :=
    ((contDiff_apply ℝ (fun _:Fin 2=>ℝ) i).comp
      (EuclideanSpace.equiv (Fin 2) ℝ).contDiff).comp contDiff_snd
  have hd : Smooth (fun p:ℝ×Plane=>expDiv (p.1*p.2 0)) :=
    expDiv_smooth.comp (contDiff_fst.mul (hc 0))
  exact (hc 1).exp.mul ((hc 0).mul hd)

theorem phaseCore_eq (X : ℝ) (hX : X≠0) (u : Plane) :
    phaseCore X⁻¹ u=X*Real.exp (u 1)*(Real.exp (u 0/X)-1) := by
  by_cases hu : u 0=0
  · simp [phaseCore,hu]
  · rw [phaseCore,expDiv_eq _ (mul_ne_zero (inv_ne_zero hX) hu)]
    field_simp

/-- The actual profile, extended smoothly through reciprocal scale zero. -/
def profile (ψ ρ σ : ℝ→ℂ) (r lam : ℝ) (u : Plane) : ℂ :=
  ρ (u 0)*σ (u 1)*ψ (phaseCore r u)*
    Elliptic.SourceContracts.additivePhase (lam*phaseCore r u)

theorem profile_eq (ψ ρ σ : ℝ→ℂ) (X lam : ℝ) (hX : X≠0) :
    profile ψ ρ σ X⁻¹ lam=determinantProfile ψ ρ σ X lam := by
  funext u
  rw [profile,phaseCore_eq X hX,determinantProfile]

theorem profile_joint_smooth (ψ ρ σ : ℝ→ℂ) (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ) :
    Smooth (fun p:(ℝ×ℝ)×Plane=>profile ψ ρ σ p.1.1 p.1.2 p.2) := by
  have hc (i:Fin 2) : Smooth (fun p:(ℝ×ℝ)×Plane=>p.2 i) :=
    ((contDiff_apply ℝ (fun _:Fin 2=>ℝ) i).comp
      (EuclideanSpace.equiv (Fin 2) ℝ).contDiff).comp contDiff_snd
  have hp : Smooth (fun p:(ℝ×ℝ)×Plane=>phaseCore p.1.1 p.2) :=
    phaseCore_smooth.comp (contDiff_fst.fst.prodMk contDiff_snd)
  have hr : Smooth (fun p:(ℝ×ℝ)×Plane=>2*Real.pi*(p.1.2*phaseCore p.1.1 p.2)) :=
    (contDiff_const.mul (contDiff_fst.snd.mul hp))
  have he := ((Complex.ofRealCLM.contDiff.comp hr).mul (contDiff_const (c:=Complex.I))).cexp
  exact (((hρ.comp (hc 0)).mul (hσ.comp (hc 1))).mul (hψ.comp hp)).mul he

section Slice
variable {A E F : Type*} [NormedAddCommGroup A] [NormedSpace ℝ A]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [NormedAddCommGroup F] [NormedSpace ℝ F]

/-- Restricting total derivatives to the variable slice has operator norm at most one. -/
theorem norm_slice_derivative_le (f:A×E→F) (hf:Smooth f) (n:ℕ) (a:A) (x:E) :
    ‖iteratedFDeriv ℝ n (fun y=>f (a,y)) x‖≤‖iteratedFDeriv ℝ n f (a,x)‖ := by
  let L : E→L[ℝ]A×E := ContinuousLinearMap.inr ℝ A E
  have he : (fun y=>f (a,y))=(fun z:A×E=>f ((a,0)+z)) ∘ L := by
    funext y
    simp [L]
  have hs : Smooth (fun z:A×E=>f ((a,0)+z)) := hf.comp (contDiff_const.add contDiff_id)
  rw [he,L.iteratedFDeriv_comp_right hs x (by simp)]
  rw [iteratedFDeriv_comp_add_left]
  have h := ContinuousMultilinearMap.norm_compContinuousLinearMap_le
    (iteratedFDeriv ℝ n f ((a,0)+L x)) (fun _ : Fin n=>L)
  have hL : ‖L‖≤1 := ContinuousLinearMap.norm_inr_le_one ℝ A E
  apply h.trans
  simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  have hh := mul_le_mul_of_nonneg_left (pow_le_one₀ (n:=n) (norm_nonneg L) hL) (norm_nonneg (iteratedFDeriv ℝ n f ((a,0)+L x)))
  simpa [L] using hh

/-- Uniform derivatives of a smooth family on a compact parameter and variable set. -/
theorem uniform_slice_derivatives (f:A×E→F) (hf:Smooth f) (S:Set A) (T:Set E)
    (hS:IsCompact S) (hT:IsCompact T) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀a∈S,∀x∈T,‖iteratedFDeriv ℝ n (fun y=>f (a,y)) x‖≤C := by
  obtain ⟨C,hC⟩ := (hS.prod hT).exists_bound_of_continuousOn
    (hf.continuous_iteratedFDeriv (by simp)).continuousOn
  refine ⟨max 0 C,le_max_left _ _,?_⟩
  intro a ha x hx
  exact (norm_slice_derivative_le f hf n a x).trans ((hC (a,x) ⟨ha,hx⟩).trans (le_max_right _ _))
end Slice

/-- Every derivative of the determinant phase is uniform for X≥1 on a fixed compact set. -/
theorem phaseCore_uniform_derivatives (T:Set Plane) (hT:IsCompact T) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀u∈T,
      ‖iteratedFDeriv ℝ n (fun v:Plane=>X*Real.exp (v 1)*(Real.exp (v 0/X)-1)) u‖≤C := by
  obtain ⟨C,hC,hbound⟩ := uniform_slice_derivatives _ phaseCore_smooth
    (Set.Icc (0:ℝ) 1) T isCompact_Icc hT n
  refine ⟨C,hC,?_⟩
  intro X hX u hu
  have hXp : 0<X := lt_of_lt_of_le zero_lt_one hX
  have hh := hbound X⁻¹ ⟨inv_nonneg.mpr hXp.le,inv_le_one_of_one_le₀ hX⟩ u hu
  simpa only [phaseCore_eq X hXp.ne'] using hh

/-- Unit-modulus real oscillation, with its exact derivative polynomial. -/
def oscillation (lam x:ℝ) : ℂ := Complex.exp (Complex.I*((lam*x:ℝ):ℂ))

theorem oscillation_norm (lam x:ℝ) : ‖oscillation lam x‖=1 :=
  Complex.norm_exp_I_mul_ofReal _

theorem oscillation_smooth (lam:ℝ) : Smooth (oscillation lam) := by
  have hr : Smooth (fun x:ℝ=>lam*x) := contDiff_const.mul contDiff_id
  exact (contDiff_const.mul (Complex.ofRealCLM.contDiff.comp hr)).cexp

theorem oscillation_hasDerivAt (lam x:ℝ) :
    HasDerivAt (oscillation lam) ((Complex.I*(lam:ℂ))*oscillation lam x) x := by
  have h := (((hasDerivAt_id x).const_mul lam).ofReal_comp.const_mul Complex.I).cexp
  convert h using 1 <;> (try rfl) <;> (try simp only [mul_one,oscillation,id_eq]) <;> ring

theorem oscillation_iteratedDeriv (lam:ℝ) (n:ℕ) :
    iteratedDeriv n (oscillation lam)=fun x=>(Complex.I*(lam:ℂ))^n*oscillation lam x := by
  induction n with
  | zero => ext x; simp
  | succ n ih =>
    rw [iteratedDeriv_succ,ih]
    funext x
    rw [((oscillation_hasDerivAt lam x).const_mul ((Complex.I*(lam:ℂ))^n)).deriv]
    ring

theorem oscillation_iteratedFDeriv_norm (lam:ℝ) (n:ℕ) (x:ℝ) :
    ‖iteratedFDeriv ℝ n (oscillation lam) x‖=|lam|^n := by
  rw [norm_iteratedFDeriv_eq_norm_iteratedDeriv,oscillation_iteratedDeriv]
  simp [norm_mul,norm_pow,oscillation_norm]

/-- A smooth real phase on compact sets has a uniform polynomial modulation cost. -/
theorem uniform_oscillation_derivatives {A E:Type*} [NormedAddCommGroup A] [NormedSpace ℝ A]
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (φ:A×E→ℝ) (hφ:Smooth φ) (S:Set A) (T:Set E) (hS:IsCompact S) (hT:IsCompact T) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀a∈S,∀lam:ℝ,∀x∈T,
      ‖iteratedFDeriv ℝ n (fun y=>oscillation lam (φ (a,y))) x‖≤C*(1+|lam|)^n := by
  choose D hD0 hD using (fun i:ℕ=>uniform_slice_derivatives φ hφ S T hS hT i)
  let B := 1+∑i∈Finset.range (n+1),D i
  have hB : 1≤B := by dsimp [B]; exact le_add_of_nonneg_right (Finset.sum_nonneg (fun i _=>hD0 i))
  have hDi (i:ℕ) (hi:i≤n) : D i≤B := by
    have hh := Finset.single_le_sum (fun j _=>hD0 j) (Finset.mem_range.mpr (by omega : i<n+1))
    dsimp [B]
    linarith
  refine ⟨(n.factorial:ℝ)*B^n,by positivity,?_⟩
  intro a ha lam x hx
  have hs : Smooth (fun y:E=>φ (a,y)) := hφ.comp (contDiff_const.prodMk contDiff_id)
  have hb := norm_iteratedFDeriv_comp_le (oscillation_smooth lam) hs (by simp : (n:WithTop ℕ∞)≤↑(⊤:ℕ∞)) x
    (C:=(1+|lam|)^n) (D:=B) ?_ ?_
  · convert hb using 1 <;> (try simp only [Function.comp_def]) <;> ring
  · intro i hi
    rw [oscillation_iteratedFDeriv_norm]
    exact (pow_le_pow_left₀ (abs_nonneg lam) (by linarith [abs_nonneg lam] : |lam|≤1+|lam|) i).trans
      (pow_le_pow_right₀ (by linarith [abs_nonneg lam] : 1≤1+|lam|) hi)
  · intro i hi hin
    exact (hD i a ha x hx).trans ((hDi i hin).trans (le_self_pow₀ hB (by omega : i≠0)))

/-- Fixed smooth amplitudes retain the polynomial modulation bound. -/
theorem uniform_modulated_derivatives {A E:Type*} [NormedAddCommGroup A] [NormedSpace ℝ A]
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (a:A×E→ℂ) (φ:A×E→ℝ) (ha:Smooth a) (hφ:Smooth φ)
    (S:Set A) (T:Set E) (hS:IsCompact S) (hT:IsCompact T) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀r∈S,∀lam:ℝ,∀x∈T,
      ‖iteratedFDeriv ℝ n (fun y=>a (r,y)*oscillation lam (φ (r,y))) x‖≤C*(1+|lam|)^n := by
  choose CA hCA0 hCA using (fun i:ℕ=>uniform_slice_derivatives a ha S T hS hT i)
  choose CP hCP0 hCP using (fun i:ℕ=>uniform_oscillation_derivatives φ hφ S T hS hT i)
  let C := ∑i∈Finset.range (n+1),(n.choose i:ℝ)*CA i*CP (n-i)
  have hC : 0≤C := by
    dsimp [C]
    exact Finset.sum_nonneg (fun i _=>mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hCA0 i)) (hCP0 _))
  refine ⟨C,hC,?_⟩
  intro r hr lam x hx
  have has : Smooth (fun y:E=>a (r,y)) := ha.comp (contDiff_const.prodMk contDiff_id)
  have hφs : Smooth (fun y:E=>φ (r,y)) := hφ.comp (contDiff_const.prodMk contDiff_id)
  apply (norm_iteratedFDeriv_mul_le has ((oscillation_smooth lam).comp hφs) x (by simp)).trans
  dsimp only [C]
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i hi
  calc
    _ ≤ (n.choose i:ℝ)*CA i*(CP (n-i)*(1+|lam|)^(n-i)) := by
      gcongr
      · exact mul_nonneg (Nat.cast_nonneg _) (hCA0 i)
      · exact hCA i r hr x hx
      · simpa only [Function.comp_def] using hCP (n-i) r hr lam x hx
    _ = ((n.choose i:ℝ)*CA i*CP (n-i))*(1+|lam|)^(n-i) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (pow_le_pow_right₀ (by linarith [abs_nonneg lam] : 1≤1+|lam|) (Nat.sub_le n i)) (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hCA0 i)) (hCP0 _))

/-- Fixed-coordinate amplitude of the determinant profile. -/
def amplitude (ψ ρ σ:ℝ→ℂ) (r:ℝ) (u:Plane) : ℂ :=
  ρ (u 0)*σ (u 1)*ψ (phaseCore r u)

theorem amplitude_smooth (ψ ρ σ:ℝ→ℂ) (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ) :
    Smooth (fun p:ℝ×Plane=>amplitude ψ ρ σ p.1 p.2) := by
  have hc (i:Fin 2) : Smooth (fun p:ℝ×Plane=>p.2 i) :=
    ((contDiff_apply ℝ (fun _:Fin 2=>ℝ) i).comp
      (EuclideanSpace.equiv (Fin 2) ℝ).contDiff).comp contDiff_snd
  exact ((hρ.comp (hc 0)).mul (hσ.comp (hc 1))).mul (hψ.comp phaseCore_smooth)

/-- The fixed compact rectangle supporting every reciprocal-scale profile. -/
def profileSupport (ρ σ:ℝ→ℂ) : Set Plane :=
  coordinateHomeomorph ⁻¹' (tsupport ρ ×ˢ tsupport σ)

theorem profileSupport_compact (ρ σ:ℝ→ℂ) (hρ:HasCompactSupport ρ) (hσ:HasCompactSupport σ) :
    IsCompact (profileSupport ρ σ) :=
  coordinateHomeomorph.isCompact_preimage.mpr (hρ.isCompact.prod hσ.isCompact)

theorem profile_tsupport_subset (ψ ρ σ:ℝ→ℂ) (r lam:ℝ)
    (hρ:HasCompactSupport ρ) (hσ:HasCompactSupport σ) :
    tsupport (profile ψ ρ σ r lam)⊆profileSupport ρ σ := by
  apply closure_minimal _ (profileSupport_compact ρ σ hρ hσ).isClosed
  intro u hu
  change u 0∈tsupport ρ ∧ u 1∈tsupport σ
  have hn : profile ψ ρ σ r lam u≠0 := hu
  unfold profile at hn
  constructor
  · apply subset_tsupport
    intro h
    simp [h] at hn
  · apply subset_tsupport
    intro h
    simp [h] at hn

/-- Every literal determinant-profile seminorm has a scale-uniform polynomial λ bound. -/
theorem determinantProfile_uniform_derivatives (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (k n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam:ℝ,∀u:Plane,
      ‖u‖^k*‖iteratedFDeriv ℝ n (determinantProfile ψ ρ σ X lam) u‖≤C*(1+|lam|)^n := by
  let T := profileSupport ρ σ
  have hT : IsCompact T := profileSupport_compact ρ σ hcρ hcσ
  obtain ⟨A,hA,hbound⟩ := uniform_modulated_derivatives
    (fun p:ℝ×Plane=>amplitude ψ ρ σ p.1 p.2) (fun p:ℝ×Plane=>phaseCore p.1 p.2)
    (amplitude_smooth ψ ρ σ hψ hρ hσ) phaseCore_smooth
    (Set.Icc (0:ℝ) 1) T isCompact_Icc hT n
  obtain ⟨R,hR⟩ := hT.exists_bound_of_continuousOn (continuous_id.continuousOn : ContinuousOn (fun u:Plane=>u) T)
  let B := max 1 R
  have hB : 0≤B := le_trans (by norm_num : (0:ℝ)≤1) (le_max_left _ _)
  have hpi : 0≤2*Real.pi := by positivity
  refine ⟨B^k*A*(1+2*Real.pi)^n,by positivity,?_⟩
  intro X hX lam u
  have hXp : 0<X := lt_of_lt_of_le zero_lt_one hX
  rw [←profile_eq ψ ρ σ X lam hXp.ne']
  by_cases hu : u∈T
  · have hh := hbound X⁻¹ ⟨inv_nonneg.mpr hXp.le,inv_le_one_of_one_le₀ hX⟩ (2*Real.pi*lam) u hu
    have he : (fun y:Plane=>amplitude ψ ρ σ X⁻¹ y*oscillation (2*Real.pi*lam) (phaseCore X⁻¹ y))=
        profile ψ ρ σ X⁻¹ lam := by
      funext y
      unfold profile amplitude oscillation Elliptic.SourceContracts.additivePhase
      congr 2
      push_cast
      ring
    rw [he] at hh
    have hlam : 1+|2*Real.pi*lam|≤(1+2*Real.pi)*(1+|lam|) := by
      rw [abs_mul,abs_of_nonneg hpi]
      nlinarith [Real.pi_pos,abs_nonneg lam]
    calc
      _ ≤ B^k*(A*(1+|2*Real.pi*lam|)^n) :=
        mul_le_mul (pow_le_pow_left₀ (norm_nonneg u) ((hR u hu).trans (le_max_right _ _)) k) hh
          (norm_nonneg _) (by positivity)
      _ ≤ B^k*(A*(((1+2*Real.pi)*(1+|lam|))^n)) := by gcongr
      _ = _ := by rw [mul_pow]; ring
  · have hz : iteratedFDeriv ℝ n (profile ψ ρ σ X⁻¹ lam) u=0 := by
      by_contra hn
      exact hu ((profile_tsupport_subset ψ ρ σ X⁻¹ lam hcρ hcσ) (support_iteratedFDeriv_subset n hn))
    rw [hz,norm_zero,mul_zero]
    positivity

/-- Uniform seminorm estimates for the actual bundled Schwartz profile. -/
theorem determinantSchwartz_seminorm (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (k n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam:ℝ,
      SchwartzMap.seminorm ℝ k n (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)≤C*(1+|lam|)^n := by
  obtain ⟨C,hC,h⟩ := determinantProfile_uniform_derivatives ψ ρ σ hψ hρ hσ hcρ hcσ k n
  refine ⟨C,hC,?_⟩
  intro X hX lam
  exact SchwartzMap.seminorm_le_bound ℝ k n _ (by positivity) (h X hX lam)

/-- L1 norms of every derivative have the same uniform polynomial modulation cost. -/
theorem determinantSchwartz_derivative_integral (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam:ℝ,
      (∫u:Plane,‖iteratedFDeriv ℝ n (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) u‖)≤C*(1+|lam|)^n := by
  let d := (volume:Measure Plane).integrablePower
  let M := (2:ℝ)^d*(∫u:Plane,(1+‖u‖)^(-(d:ℝ)))
  have hM : 0≤M := by dsimp [M]; positivity
  obtain ⟨A,hA,ha⟩ := determinantSchwartz_seminorm ψ ρ σ hψ hρ hσ hcρ hcσ 0 n
  obtain ⟨B,hB,hb⟩ := determinantSchwartz_seminorm ψ ρ σ hψ hρ hσ hcρ hcσ d n
  refine ⟨M*(A+B),by positivity,?_⟩
  intro X hX lam
  have hh := (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam).integral_pow_mul_iteratedFDeriv_le ℝ (μ:=volume) 0 n
  simp only [pow_zero,one_mul,zero_add] at hh
  apply hh.trans
  change M*(_+_)≤M*(A+B)*(1+|lam|)^n
  calc
    _ ≤ M*(A*(1+|lam|)^n+B*(1+|lam|)^n) := mul_le_mul_of_nonneg_left (add_le_add (ha X hX lam) (hb X hX lam)) hM
    _ = _ := by ring

/-- Direct Fourier derivative transfer retains the degree n in the modulation. -/
theorem determinantSchwartz_fourier_weight (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam:ℝ,∀w:Plane,
      ‖w‖^n*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖≤C*(1+|lam|)^n := by
  choose A hA0 hA using (fun i:ℕ=>determinantSchwartz_derivative_integral ψ ρ σ hψ hρ hσ hcρ hcσ i)
  refine ⟨(2:ℝ)^n*(∑i∈Finset.range (n+1),A i),mul_nonneg (by positivity) (Finset.sum_nonneg (fun i _=>hA0 i)),?_⟩
  intro X hX lam w
  let F := determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam
  have hh := Real.pow_mul_norm_iteratedFDeriv_fourier_le (F.smooth ⊤)
    (fun k m _ _=>SchwartzMap.integrable_pow_mul_iteratedFDeriv volume F k m)
    (k:=0) (n:=n) (K:=⊤) (by simp) (by simp) w
  simp only [norm_iteratedFDeriv_zero,Nat.cast_zero,mul_zero,zero_add,pow_zero,one_mul,
    Finset.range_one,Finset.sum_product,Finset.sum_singleton] at hh
  rw [SchwartzMap.fourier_coe] at ⊢
  apply hh.trans
  rw [mul_assoc]
  apply mul_le_mul_of_nonneg_left _ (by positivity : 0≤(2:ℝ)^n)
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i hi
  apply (hA i X hX lam).trans
  exact mul_le_mul_of_nonneg_left
    (pow_le_pow_right₀ (by linarith [abs_nonneg lam] : 1≤1+|lam|) (by simpa using Finset.mem_range.mp hi)) (hA0 i)

/-- Full radial rapid decay with uniform polynomial modulation cost. -/
theorem determinantSchwartz_fourier_decay_weight (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (n:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam:ℝ,∀w:Plane,
      (1+‖w‖)^n*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖≤C*(1+|lam|)^n := by
  obtain ⟨A,hA,ha⟩ := determinantSchwartz_fourier_weight ψ ρ σ hψ hρ hσ hcρ hcσ 0
  obtain ⟨B,hB,hb⟩ := determinantSchwartz_fourier_weight ψ ρ σ hψ hρ hσ hcρ hcσ n
  refine ⟨(2:ℝ)^(n-1)*(A+B),by positivity,?_⟩
  intro X hX lam w
  have ha' := ha X hX lam w
  simp only [pow_zero,one_mul,mul_one] at ha'
  have hbase : 1≤(1+|lam|)^n := one_le_pow₀ (by linarith [abs_nonneg lam])
  have hh : ‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖≤A*(1+|lam|)^n :=
    ha'.trans (le_mul_of_one_le_right hA hbase)
  calc
    _ ≤ ((2:ℝ)^(n-1)*(1+‖w‖^n))*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖ :=
      mul_le_mul_of_nonneg_right (by simpa using add_pow_le (by norm_num : (0:ℝ)≤1) (norm_nonneg w) n) (norm_nonneg _)
    _ = (2:ℝ)^(n-1)*(‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖+
      ‖w‖^n*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖) := by ring
    _ ≤ (2:ℝ)^(n-1)*(A*(1+|lam|)^n+B*(1+|lam|)^n) :=
      mul_le_mul_of_nonneg_left (add_le_add hh (hb X hX lam w)) (by positivity)
    _ = _ := by ring

/-- The literal Mellin kernel has separate rapid decay in both frequency coordinates.
The modulation degree is exactly twice the requested decay order. -/
theorem mellinKernel_uniform_weight (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (j:ℕ) :
    ∃C:ℝ,0≤C ∧ ∀X:ℝ,1≤X→∀lam v s:ℝ,
      (1+|v|)^j*(1+|s|)^j*
        ‖mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) v s‖≤C*(1+|lam|)^(2*j) := by
  obtain ⟨A,hA,ha⟩ := determinantSchwartz_fourier_decay_weight ψ ρ σ hψ hρ hσ hcρ hcσ (2*j)
  let r := 2*Real.pi
  have hr : 0<r := by dsimp [r]; positivity
  let C := (r^2)⁻¹*(1+r)^(2*j)*A
  refine ⟨C,by dsimp [C]; positivity,?_⟩
  intro X hX lam v s
  let w := vec (v/r) (s/r)
  have hc (i:Fin 2) : |w i|≤‖w‖ := by simpa only [Real.norm_eq_abs] using PiLp.norm_apply_le w i
  have hv : |v|≤r*‖w‖ := by
    have h := hc 0
    change |v/r|≤‖w‖ at h
    rw [abs_div,abs_of_pos hr] at h
    simpa only [mul_comm] using (div_le_iff₀ hr).mp h
  have hs : |s|≤r*‖w‖ := by
    have h := hc 1
    change |s/r|≤‖w‖ at h
    rw [abs_div,abs_of_pos hr] at h
    simpa only [mul_comm] using (div_le_iff₀ hr).mp h
  have hv' : 1+|v|≤(1+r)*(1+‖w‖) := by nlinarith [norm_nonneg w]
  have hs' : 1+|s|≤(1+r)*(1+‖w‖) := by nlinarith [norm_nonneg w]
  have hweight : (1+|v|)^j*(1+|s|)^j≤(1+r)^(2*j)*(1+‖w‖)^(2*j) := by
    calc
      _ ≤ (((1+r)*(1+‖w‖))^j)*(((1+r)*(1+‖w‖))^j) := by gcongr
      _ = _ := by rw [←pow_add,←two_mul,mul_pow]
  have hk : ‖mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) v s‖=
      (r^2)⁻¹*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖ := by
    simp only [mellinKernel,norm_mul,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_pow,
      abs_of_pos (show 0<2*Real.pi by positivity),r,w]
  rw [hk]
  calc
    _ ≤ ((1+r)^(2*j)*(1+‖w‖)^(2*j))*((r^2)⁻¹*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖) :=
      mul_le_mul_of_nonneg_right hweight (by positivity)
    _ = (r^2)⁻¹*(1+r)^(2*j)*((1+‖w‖)^(2*j)*‖(𝓕 (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)) w‖) := by ring
    _ ≤ (r^2)⁻¹*(1+r)^(2*j)*(A*(1+|lam|)^(2*j)) := mul_le_mul_of_nonneg_left (ha X hX lam w) (by positivity)
    _ = _ := by dsimp [C]; ring

/-- Separate polynomial decay in the exact normalized Mellin frequencies. -/
theorem mellinKernel_uniform_decay (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (j:ℕ) :
    ∃C:ℝ,0<C ∧ ∀X:ℝ,1≤X→∀lam v s:ℝ,
      ‖mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) v s‖≤
        C*(1+|lam|)^(2*j)/((1+|v|)^j*(1+|s|)^j) := by
  obtain ⟨C,hC,h⟩ := mellinKernel_uniform_weight ψ ρ σ hψ hρ hσ hcρ hcσ j
  refine ⟨C+1,by linarith,?_⟩
  intro X hX lam v s
  apply (le_div_iff₀ (by positivity : 0<(1+|v|)^j*(1+|s|)^j)).mpr
  calc
    _ = (1+|v|)^j*(1+|s|)^j*‖mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) v s‖ := by ring
    _ ≤ C*(1+|lam|)^(2*j) := h X hX lam v s
    _ ≤ _ := mul_le_mul_of_nonneg_right (by linarith) (by positivity)

end Elliptic.Operator.MellinPlaneUniform
