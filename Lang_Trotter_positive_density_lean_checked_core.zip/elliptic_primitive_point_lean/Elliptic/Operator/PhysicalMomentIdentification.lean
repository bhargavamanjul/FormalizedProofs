module

public import Elliptic.Operator.PhysicalVertexDamping
public import Elliptic.Operator.PhysicalMomentEndpoint

/-!
# Identification of the actual damped AA* moment

The positive-semidefinite finite matrix moment is the same physical moment
that is transferred to canonical roots. This is an equality of the actual
path expansions, including divisibility, inactive damping and list weights.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMomentIdentification
open scoped BigOperators ComplexConjugate
open OriginalLifespanSchedule PhysicalPathGeometry PhysicalVertexDamping
open PhysicalPathRootEncoding PhysicalPathRootFinite PhysicalRootMomentNumeric
open SingleEdgeRootEncoding RootLiteralGeometry
attribute [local instance] Classical.propDecidable
local instance physicalMomentDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J R : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def alternatingAdjoint (j : ℕ) : Bool := if j%2=0 then false else true

def baseGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) :
    (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ :=
  sourcePhysicalEdgeGeometry value (sourceGood value μ d₀ Y L exponents (1,1,0))
    1 0 0 U V d₀ Y smooth ψ major σ

def physicalGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ)
    (z : primitiveSources U V) (a : PhysicalActiveLists P J)
    (w : primitiveSources U V) (b : PhysicalActiveLists P J) : ℂ :=
  dampedGeometry value primes q
    (baseGeometry value μ d₀ Y L U V exponents smooth ψ major σ) z.val a w.val b

theorem alternating_physicalGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ) (j : ℕ)
    (z : primitiveSources U V) (a : PhysicalActiveLists P J)
    (w : primitiveSources U V) (b : PhysicalActiveLists P J) :
    PhysicalRootedMoment.alternatingGeometry
      (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q) j z a w b=
    dampedGeometry value primes q
      (orientedSourceEdgeGeometry (alternatingAdjoint j) value
        (sourceGood value μ d₀ Y L exponents (1,1,0))
        1 0 0 U V d₀ Y smooth ψ major σ) z.val a w.val b := by
  unfold PhysicalRootedMoment.alternatingGeometry alternatingAdjoint
  split_ifs
  · rfl
  · simp [PhysicalRootedMoment.adjointGeometry,physicalGeometry,dampedGeometry,
      baseGeometry,orientedSourceEdgeGeometry,mul_assoc,mul_comm,mul_left_comm]

theorem alternating_path_product (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ) (hR : 0<R)
    (r : OriginalPath (Fin K) (primitiveSources U V) P J (2*R)) :
    PhysicalRootedMoment.pathProduct
      (PhysicalRootedMoment.alternatingGeometry
        (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q)) 0 r=
    pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ alternatingAdjoint
      (mapPositions Subtype.val r)*
      (PhysicalPathResidues.physicalResidue value primes (momentDamping q (2*R))
        (mapPositions Subtype.val r):ℂ) := by
  rw [PhysicalRootedMoment.pathProduct_eq_range]
  simp_rw [alternating_physicalGeometry]
  exact damped_path_product value primes q
    (fun j=>orientedSourceEdgeGeometry (alternatingAdjoint j) value
      (sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U V d₀ Y smooth ψ major σ) (mapPositions Subtype.val r) (by omega)

/-- The original numerical physical closed moment is a literal positive
AA* moment. Endpoints are position vectors, not normalized list vectors. -/
theorem physicalMoment_eq_rootedPowerMoment (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (VM : Fin K→ℝ) (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ) (hR : 0<R) :
    physicalMoment (J:=J) (N:=2*R) value μ VM d₀ Y L U V exponents smooth ψ major σ
      alternatingAdjoint primes (momentDamping q (2*R))=
    PhysicalRootedMoment.rootedPowerMoment (J:=J) VM
      (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q) R := by
  rw [PhysicalRootedMoment.rootedPowerMoment_eq_closed_paths,physicalMoment,positionPaths,
    Finset.sum_image (mapPositions_injective _ Subtype.val_injective).injOn,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  rw [alternating_path_product value μ d₀ Y L U V exponents smooth ψ major σ primes q hR r]
  have he : (mapPositions Subtype.val r).position (Fin.last (2*R))=(mapPositions Subtype.val r).position 0 ↔
      r.position 0=r.position (Fin.last (2*R)) := by
    change (r.position (Fin.last (2*R))).val=(r.position 0).val ↔ _
    rw [Subtype.val_inj,eq_comm]
  simp only [he]
  split_ifs
  · rfl
  · simp

open scoped ComplexOrder in
theorem physicalMoment_nonneg (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (VM : Fin K→ℝ) (hVM : ∀i,0≤VM i) (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ) (hR : 0<R) :
    0≤physicalMoment (J:=J) (N:=2*R) value μ VM d₀ Y L U V exponents smooth ψ major σ
      alternatingAdjoint primes (momentDamping q (2*R)) := by
  rw [physicalMoment_eq_rootedPowerMoment value μ VM d₀ Y L U V exponents smooth ψ major σ primes q hR]
  exact PhysicalRootedMoment.rootedPowerMoment_nonneg VM hVM _ R

/-- The literal damped physical pairing is controlled by the numerical
moment already transferred to canonical roots. No spectral premise remains. -/
theorem physical_endpoint_power_bound (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (VM : Fin K→ℝ) (hVM : ∀i,0≤VM i) (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (q : ℝ) (hR : 0<R)
    (f : primitiveSources U V→ℂ)
    (G : PhysicalRootedMoment.State (Z:=primitiveSources U V) (P:=P) (J:=J)→ℂ) :
    let F := fun x : PhysicalRootedMoment.State (Z:=primitiveSources U V) (P:=P) (J:=J)=>f x.1
    ‖PhysicalRootedMoment.pairing VM F (PhysicalRootedMoment.rowApply VM
      (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q) G)‖^(2*R)≤
    (PhysicalRootedMoment.pairing VM G G).re^R *
      (PhysicalRootedMoment.pairing VM F F).re^(R-1) *
      ((physicalMoment (J:=J) (N:=2*R) value μ VM d₀ Y L U V exponents smooth ψ major σ
        alternatingAdjoint primes (momentDamping q (2*R))).re *
        ∑z : primitiveSources U V,‖f z‖^2) := by
  dsimp only
  have h := PhysicalRootedMoment.position_endpoint_trace_bound_pos VM hVM
    (physicalGeometry value μ d₀ Y L U V exponents smooth ψ major σ primes q)
    R hR Finset.univ f G
  dsimp only at h
  rw [PhysicalRootedMoment.positionVector_sum] at h
  simp only [Finset.mem_univ,ite_true] at h
  rw [physicalMoment_eq_rootedPowerMoment value μ VM d₀ Y L U V exponents smooth ψ major σ primes q hR]
  simpa only [PhysicalRootedMoment.rootedPowerMoment,←Complex.reCLM_apply,map_sum] using h

end Elliptic.Operator.PhysicalMomentIdentification
