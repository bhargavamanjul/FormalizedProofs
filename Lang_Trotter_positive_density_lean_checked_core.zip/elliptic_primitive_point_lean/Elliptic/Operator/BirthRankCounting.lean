module

public import Elliptic.Operator.BirthDistinctness
public import Mathlib.GroupTheory.Perm.Cycle.Concrete
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Analysis.Complex.Basic

/-!
# Exact rank counting for the birth-distinctness expansion

Source (4.46) counts permutations by the sum of cycle lengths minus one.
Every such permutation is reconstructed from exactly that many ordered
pairs of addresses, interpreted as transpositions. Choosing one word for
each permutation is injective because its product recovers the permutation.
This proves the coefficient bound directly for the exact signed-permutation
identity in BirthDistinctness, without a factorial or rank-counting input.
-/

@[expose] public section
noncomputable section

namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- Adjacent transpositions representing a list's cyclic permutation. -/
def adjacentSwapPairs {α : Type*} : List α → List (α × α)
  | [] => []
  | [_] => []
  | a :: b :: l => (a,b) :: adjacentSwapPairs (b :: l)

theorem adjacentSwapPairs_length {α : Type*} (l : List α) :
    (adjacentSwapPairs l).length = l.length - 1 := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    cases l with
    | nil => rfl
    | cons b l => simp [adjacentSwapPairs, ih]

/-- Evaluation keeps the order of the transpositions. -/
def swapWordProduct {α : Type*} [DecidableEq α] (l : List (α × α)) : Equiv.Perm α :=
  (l.map (fun ab => Equiv.swap ab.1 ab.2)).prod

theorem adjacentSwapPairs_product {α : Type*} [DecidableEq α] (l : List α) :
    swapWordProduct (adjacentSwapPairs l) = l.formPerm := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    cases l with
    | nil => rfl
    | cons b l =>
      simpa [adjacentSwapPairs, swapWordProduct] using
        congrArg (fun σ => Equiv.swap a b * σ) ih

theorem birthCycleRank_one {α : Type*} [Fintype α] [DecidableEq α] :
    birthCycleRank (1 : Equiv.Perm α) = 0 := by
  simp [birthCycleRank]

theorem birthCycleRank_disjoint_mul {α : Type*} [Fintype α] [DecidableEq α]
    {σ τ : Equiv.Perm α} (h : Equiv.Perm.Disjoint σ τ) :
    birthCycleRank (σ*τ) = birthCycleRank σ + birthCycleRank τ := by
  simp [birthCycleRank, h.cycleType_mul]

/-- Each rank-r permutation has an ordered transposition word of length r.
The proof decomposes actual cycles, rather than bounding support crudely. -/
theorem exists_swapWord_of_birthCycleRank {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) :
    ∃ l : List (α × α), l.length = birthCycleRank σ ∧ swapWordProduct l = σ := by
  induction σ using Equiv.Perm.cycle_induction_on with
  | base_one => exact ⟨[], by simp [birthCycleRank_one], rfl⟩
  | base_cycles σ hσ =>
    obtain ⟨a, ha, _⟩ := hσ
    have hcycle := (show σ.IsCycle from ⟨a,ha,by assumption⟩)
    have heq := hcycle.cycleOf_eq ha
    refine ⟨adjacentSwapPairs (σ.toList a), ?_, ?_⟩
    · rw [adjacentSwapPairs_length, Equiv.Perm.length_toList, heq]
      simp [birthCycleRank, hcycle.cycleType]
    · rw [adjacentSwapPairs_product, Equiv.Perm.formPerm_toList, heq]
  | induction_disjoint σ τ hd _ hσ hτ =>
    obtain ⟨l, hl, hprod⟩ := hσ
    obtain ⟨l', hl', hprod'⟩ := hτ
    refine ⟨l ++ l', ?_, ?_⟩
    · rw [List.length_append, hl, hl', birthCycleRank_disjoint_mul hd]
    · simp only [swapWordProduct, List.map_append, List.prod_append] at *
      rw [hprod, hprod']

/-- A fixed choice of word for a permutation of a specified rank. -/
def birthRankWord {α : Type*} [Fintype α] [DecidableEq α] (r : ℕ)
    (σ : {σ : Equiv.Perm α // birthCycleRank σ = r}) : List.Vector (α × α) r :=
  ⟨Classical.choose (exists_swapWord_of_birthCycleRank σ.val),
    (Classical.choose_spec (exists_swapWord_of_birthCycleRank σ.val)).1.trans σ.property⟩

theorem birthRankWord_product {α : Type*} [Fintype α] [DecidableEq α] (r : ℕ)
    (σ : {σ : Equiv.Perm α // birthCycleRank σ = r}) :
    swapWordProduct (birthRankWord r σ).val = σ.val :=
  (Classical.choose_spec (exists_swapWord_of_birthCycleRank σ.val)).2

theorem birthRankWord_injective {α : Type*} [Fintype α] [DecidableEq α] (r : ℕ) :
    Function.Injective (birthRankWord (α:=α) r) := by
  intro σ τ h
  apply Subtype.ext
  have hh := congrArg (fun w : List.Vector (α × α) r => swapWordProduct w.val) h
  simpa only [birthRankWord_product] using hh

/-- Source (4.46), with exact constant one, including the empty-address case. -/
theorem card_permutations_birthCycleRank_le {α : Type*} [Fintype α] [DecidableEq α]
    (r : ℕ) :
    Fintype.card {σ : Equiv.Perm α // birthCycleRank σ = r} ≤ (Fintype.card α)^(2*r) := by
  classical
  have h := Fintype.card_le_of_injective (birthRankWord (α:=α) r) (birthRankWord_injective r)
  simpa only [card_vector, Fintype.card_prod, ← pow_two, ← pow_mul] using h

/-- The literal finite set of rank-r permutations in the signed expansion. -/
def birthRankPermutations (α : Type*) [Fintype α] [DecidableEq α] (r : ℕ) :
    Finset (Equiv.Perm α) :=
  Finset.univ.filter (fun σ => birthCycleRank σ = r)

theorem card_birthRankPermutations_le {α : Type*} [Fintype α] [DecidableEq α]
    (r : ℕ) : (birthRankPermutations α r).card ≤ (Fintype.card α)^(2*r) := by
  classical
  simpa only [birthRankPermutations, Fintype.card_subtype] using
    card_permutations_birthCycleRank_le (α:=α) r

theorem permutationSign_abs_real {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) : |(permutationSign σ : ℝ)| = 1 := by
  unfold permutationSign
  exact_mod_cast Equiv.Perm.sign_abs σ

theorem permutationSign_norm_complex {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) : ‖(permutationSign σ : ℂ)‖ = 1 := by
  rw [Complex.norm_intCast, permutationSign_abs_real]

/-- The total absolute coefficient mass is exactly the rank count before
being bounded. Thus no triangle-inequality multiplicity is hidden. -/
theorem birthRank_absolute_coefficient_mass {α : Type*} [Fintype α] [DecidableEq α]
    (r : ℕ) :
    (∑ σ ∈ birthRankPermutations α r, |(permutationSign σ : ℝ)|) =
      ((birthRankPermutations α r).card : ℝ) := by
  simp only [permutationSign_abs_real, Finset.sum_const, nsmul_eq_mul, mul_one]

theorem birthRank_absolute_coefficient_mass_le {α : Type*}
    [Fintype α] [DecidableEq α] (r : ℕ) :
    (∑ σ ∈ birthRankPermutations α r, |(permutationSign σ : ℝ)|) ≤
      (Fintype.card α : ℝ)^(2*r) := by
  rw [birthRank_absolute_coefficient_mass]
  exact_mod_cast card_birthRankPermutations_le (α:=α) r

/-- The actual signed contribution at one rank inherits the coefficient
bound. Its per-permutation analytic estimate is displayed explicitly. -/
theorem norm_birthRank_contribution_le {α : Type*} [Fintype α] [DecidableEq α]
    (r : ℕ) (term : Equiv.Perm α → ℂ) {B : ℝ} (hB : 0 ≤ B)
    (hterm : ∀ σ, birthCycleRank σ = r → ‖term σ‖ ≤ B) :
    ‖∑ σ ∈ birthRankPermutations α r, (permutationSign σ : ℂ) * term σ‖ ≤
      (Fintype.card α : ℝ)^(2*r) * B := by
  calc
    _ ≤ ∑ σ ∈ birthRankPermutations α r, ‖(permutationSign σ : ℂ) * term σ‖ :=
      norm_sum_le _ _
    _ ≤ ∑ _σ ∈ birthRankPermutations α r, B := by
      apply Finset.sum_le_sum
      intro σ hσ
      rw [norm_mul, permutationSign_norm_complex, one_mul]
      exact hterm σ (Finset.mem_filter.mp hσ).2
    _ = ((birthRankPermutations α r).card : ℝ) * B := by simp
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (by exact_mod_cast card_birthRankPermutations_le (α:=α) r) hB

private theorem sum_pred_le_sum (s : Multiset ℕ) :
    (s.map (fun n => n-1)).sum ≤ s.sum := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons n s ih => simp only [Multiset.map_cons, Multiset.sum_cons]; omega

theorem birthCycleRank_le_card {α : Type*} [Fintype α] [DecidableEq α]
    (σ : Equiv.Perm α) : birthCycleRank σ ≤ Fintype.card α :=
  (sum_pred_le_sum σ.cycleType).trans (Equiv.Perm.sum_cycleType_le σ)

/-- Exact finite regrouping of the original signed sum by cycle rank. -/
theorem signed_permutation_sum_by_birthRank {α R : Type*}
    [Fintype α] [DecidableEq α] [CommRing R] (term : Equiv.Perm α → R) :
    (∑ σ : Equiv.Perm α, (permutationSign σ : R) * term σ) =
      ∑ r ∈ Finset.range (Fintype.card α + 1),
        ∑ σ ∈ birthRankPermutations α r, (permutationSign σ : R) * term σ := by
  symm
  exact Finset.sum_fiberwise_of_maps_to
    (s:=Finset.univ) (t:=Finset.range (Fintype.card α + 1))
    (g:=birthCycleRank) (fun σ _ => Finset.mem_range.mpr (by
      have h := birthCycleRank_le_card σ
      omega)) _

/-- The actual performed-birth history sum, regrouped exactly by rank. -/
theorem weighted_birth_distinctness_expansion_by_rank {α β H R : Type*}
    [Fintype α] [DecidableEq α] [CommRing R]
    (histories : Finset H) (birth : H → α → Option β) (weight : H → R) :
    (∑ h ∈ histories, if BirthsDistinct (birth h) then weight h else 0) =
      ∑ r ∈ Finset.range (Fintype.card α + 1),
        ∑ σ ∈ birthRankPermutations α r, (permutationSign σ : R) *
          ∑ h ∈ histories, if BirthPreserving (birth h) σ then weight h else 0 := by
  classical
  rw [weighted_birth_distinctness_expansion]
  exact signed_permutation_sum_by_birthRank _

end Elliptic.Operator
