module

public import Elliptic.Operator.OriginalLeafBoundaryAssembly
public import Elliptic.Operator.ScheduledRunCount

/-!
# Original path normalization of complete lifespan coefficients

The per-prime active-run exponents are summed on the actual source path.
Both endpoint permutations contribute exactly once per edge. All remaining
prime factors are the normalized signed independent-line lifespan weights.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalBoundaryAssembly SourceHistoryCoefficient
attribute [local instance] Classical.propDecidable
local instance leafNormDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

def pathNormalization (V : I → ℝ) (J N : ℕ) : ℝ :=
  (∏ i,(V i)⁻¹^(J+1+N)) * endpointPermutationWeight I J ^ N

/-- Complete normalization on an actual schedule. There is no assumed
power identity: its exponent is proved by counting initial and new runs. -/
theorem primewiseCoefficient_eq_pathNormalization
    (d : ScheduledPhysicalPath anchor N J B)
    (value : ∀ i, P i → ℕ)
    (hban : ∀ j, j<N → sourceCrossEdgeBan value (d.sourceLists j) (d.targetLists j))
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (μ : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) :
    primewiseCoefficient anchor geometry μ V η q d =
      (pathNormalization V J N : ℂ) *
      (∏ j∈Finset.range N, geometry j (d.position j) (d.sourceLists j)
        (d.position (j+1)) (d.targetLists j)) *
      ((∏ i, ∏ p∈d.primes i, μ i p *
        ∏ j∈Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t=>d.retained i p=anchor (d.position t) i p) j : ℝ) : ℂ) := by
  have hloc (i : I) :
      (∏ p∈d.primes i, μ i p * ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
        ∏ j∈Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t=>d.retained i p=anchor (d.position t) i p) j) =
      (V i)⁻¹^(J+1+N) *
      ∏ p∈d.primes i, μ i p *
        ∏ j∈Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
          (fun t=>d.retained i p=anchor (d.position t) i p) j := by
    calc
      _ = ∏ p∈d.primes i, ((V i)⁻¹)^(d.lifespan i p).activeRunCount *
          (μ i p * ∏ j∈Finset.range (N+1), (d.lifespan i p).lifespanVisitFactor 1 η q
            (fun t=>d.retained i p=anchor (d.position t) i p) j) := by
        apply Finset.prod_congr rfl
        intros; ring
      _ = _ := by
        rw [Finset.prod_mul_distrib,d.prod_inverse_pow_activeRunCount i (V i)
          (fun j hj=>d.target_not_active_of_crossEdgeBan value j (hban j hj) i)]
  unfold primewiseCoefficient
  simp_rw [hloc]
  simp only [ScheduledPhysicalPath.geometricFactor,Finset.prod_mul_distrib,Finset.prod_const,
    Finset.card_range,pathNormalization,Complex.ofReal_mul,Complex.ofReal_prod,Complex.ofReal_pow]
  ring

end Elliptic.Operator.OriginalLifespanSchedule
