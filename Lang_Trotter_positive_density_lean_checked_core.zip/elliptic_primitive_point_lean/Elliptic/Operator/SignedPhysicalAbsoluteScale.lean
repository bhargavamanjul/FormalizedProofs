module
public import Elliptic.Operator.SignedPhysicalAbsoluteError
public import Elliptic.Operator.SignedDivisorMomentScale

/-! A uniform polynomial logarithmic bound for the full absolute scalar error. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteScale
open scoped BigOperators
open Filter SignedPhysicalPairBridge SignedPhysicalAbsoluteMajor SignedPhysicalAbsoluteError
open SignedDivisorMomentScale
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

lemma power_budget (L C G : ℝ) (hL : 0<L) :
    (L^C)^2*(L^C)^2*(L^G)^3*L^3=L^(4*C+3*G+3) := by
  simp_rw [←Real.rpow_mul_natCast hL.le]
  rw [←Real.rpow_ofNat L 3]
  rw [←Real.rpow_add hL,←Real.rpow_add hL,←Real.rpow_add hL]
  congr 1
  ring

/-- The constants precede the source scale, label family, cutoffs, and coefficients. -/
theorem eventually_absolute_scalarError
    (hDsq : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (D C G c₂ Cψ : ℝ) (hD : 0≤D) (hC : 0≤C) (hG : 0≤G)
    (hc₂ : 0<c₂) (hCψ : 0≤Cψ) :
    ∃B E : ℝ,0≤B ∧ 0≤E ∧ ∀ᶠx : ℝ in atTop,
      ∀(ι : Type*) [Fintype ι] (p : ι→ℕ),Function.Injective p→
      (∀a,(p a:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)))→
      ∀(s t : Finset ℕ) (Y : ℝ),(∀m∈s,0<m)→(∀n∈t,0<n)→
      (∀m∈s,∀n∈t,(m*n:ℕ)≤4*c₂*x)→0<Y→
      ∀(η ψ : ℝ→ℂ) (α β : ℕ→ℂ),
      (∀v,‖η v‖≤1)→(∀v,‖ψ v‖≤1)→
      (∀v,η v≠0→1≤v ∧ v≤4)→(∀v,ψ v≠0→|v|≤Cψ)→
      (∀m∈s,‖α m‖≤(Real.log x)^C)→(∀n∈t,‖β n‖≤(Real.log x)^C)→
      (∑a : ι,∑b : ι,if (p a).Coprime (p b) then
        ∑m∈s,∑n∈t,∑r∈s,∑q∈t,
          ‖scalarError (p a) (p b) m n r q Y ((Real.log x)^G) η ψ α β‖ else 0)≤
        B*x*Y*(Real.log x)^E := by
  let c := 4*c₂+1
  have hc : 1≤c := by dsimp [c]; linarith
  have hc0 : 0<c := by linarith
  obtain ⟨T,hT,ht⟩ := eventually_divisor_sum_scaled hDsq c hc
  let Q := (2+Real.log (8*c))^3
  have hQ : 0≤Q := by dsimp [Q]; have := Real.log_nonneg (show 1≤8*c by linarith); positivity
  refine ⟨512*c*Q+64*(2*Cψ+1)*T,4*C+3*G+3,by positivity,by positivity,?_⟩
  have hlim : Tendsto (fun x : ℝ=>c*x) atTop atTop := tendsto_id.const_mul_atTop hc0
  filter_upwards [hlim.eventually (eventually_all_labels_scalarRaw_sum_le D hD),ht,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    eventually_ge_atTop (1:ℝ)] with x hr ht hL hx
  intro ι _ p hinj hsmall s t Y hs htpos hp hY η ψ α β hη hψ hηs hψs hα hβ
  have hx0 : 0<x := by linarith
  have hLp : 0<Real.log x := by linarith
  have hcx : x≤c*x := by nlinarith
  have hpos : ∀m∈s,∀n∈t,0<m*n := fun m hm n hn=>Nat.mul_pos (hs m hm) (htpos n hn)
  have hp' : ∀m∈s,∀n∈t,(m*n+1:ℕ)≤c*x := by
    intro m hm n hn
    have := hp m hm n hn
    push_cast at this ⊢
    dsimp only [c]
    nlinarith
  have hpN : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 ⌊c*x⌋₊ := by
    intro m hm n hn
    refine Finset.mem_Icc.mpr ⟨hpos m hm n hn,?_⟩
    apply (Nat.le_floor_iff (by positivity)).mpr
    have := hp m hm n hn
    dsimp only [c]
    nlinarith
  have hsmall' : ∀a,(p a:ℝ)≤Real.exp (D*(Real.log (c*x))^(1/5:ℝ)) := by
    intro a
    apply (hsmall a).trans
    apply Real.exp_le_exp.mpr
    apply mul_le_mul_of_nonneg_left _ hD
    exact Real.rpow_le_rpow (by linarith) (Real.log_le_log hx0 hcx) (by norm_num)
  have hraw := hr ι p hinj hsmall' s t Y hs hpos hp' hY η ψ α β
    1 1 ((Real.log x)^C) ((Real.log x)^C)
    (by norm_num) (by norm_num) (by positivity) (by positivity) hη hψ hηs hα hβ
  have hmajor := all_labels_scalarMajor_sum_le p hinj s t ⌊c*x⌋₊ hs hpN Cψ Y ((Real.log x)^G)
    hCψ hY (by positivity) η ψ α β 1 1 ((Real.log x)^C) ((Real.log x)^C)
    (by norm_num) (by norm_num) (by positivity) (by positivity) hη hψ hηs hψs hα hβ
  have hpowers := power_budget (Real.log x) C G hLp
  have hone : 1≤((Real.log x)^G)^3 := one_le_pow₀ (Real.one_le_rpow hL hG)
  have hraw' : (∑a : ι,∑b : ι,if (p a).Coprime (p b) then
      ∑m∈s,∑n∈t,∑r∈s,∑q∈t,‖SignedPhysicalAbsoluteRaw.scalarRaw (p a) (p b) m n r q Y η ψ α β‖ else 0)≤
      (512*c*Q)*x*Y*(Real.log x)^(4*C+3*G+3) := by
    calc
      _ ≤ _ := hraw
      _ ≤ 512*1^2*((Real.log x)^C)^2*((Real.log x)^C)^2*1*(c*x)*Y*
          (Q*(Real.log x)^3) := by
        exact mul_le_mul_of_nonneg_left (scaled_log_cube c x hc hx0 hL) (by positivity)
      _ ≤ 512*1^2*((Real.log x)^C)^2*((Real.log x)^C)^2*1*(c*x)*Y*
          (Q*(Real.log x)^3)*((Real.log x)^G)^3 := by
        exact le_mul_of_one_le_right (by positivity) hone
      _ = _ := by rw [←hpowers]; ring
  have hmajor' : (∑a : ι,∑b : ι,∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      ‖scalarMajor (p a) (p b) m n r q Y ((Real.log x)^G) η ψ α β‖)≤
      (64*(2*Cψ+1)*T)*x*Y*(Real.log x)^(4*C+3*G+3) := by
    calc
      _ ≤ _ := hmajor
      _ ≤ 64*(2*Cψ+1)*1^2*((Real.log x)^C)^2*((Real.log x)^C)^2*1*((Real.log x)^G)^3*Y*
          (T*x*(Real.log x)^3) := by
        exact mul_le_mul_of_nonneg_left (ht _ (Nat.floor_le (by positivity))) (by positivity)
      _ = _ := by rw [←hpowers]; ring
  apply (coprime_scalarError_sum_le_raw_add_major p s t Y ((Real.log x)^G) η ψ α β).trans
  apply (add_le_add hraw' hmajor').trans
  exact le_of_eq (by ring)

end Elliptic.Operator.SignedPhysicalAbsoluteScale
