module
public import Elliptic.Operator.PhysicalCleanAsymptotics

/-! The literal source edge on a fixed shared-list pad is the proved
ban-restored clean kernel with separate endpoint cutoffs. No arbitrary
coupled phase is introduced into the cancellation argument. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators SchwartzMap
attribute [local instance] Classical.propDecidable
local instance physicalCleanLocalGeometryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Equality on the actual supports suffices to transport a measured bound. -/
theorem finiteMeasuredBilinearBound_congr {X Y : Type*}
    (s : Finset X) (t : Finset Y) (μ : X→ℝ) (ν : Y→ℝ)
    (K L : X→Y→ℂ) (M : ℝ)
    (he : ∀ x∈s, ∀ y∈t, K x y=L x y)
    (hK : FiniteMeasuredBilinearBound s t μ ν K M) :
    FiniteMeasuredBilinearBound s t μ ν L M := by
  intro a b
  have hp : finiteMeasuredPairing s t μ ν K a b=finiteMeasuredPairing s t μ ν L a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    apply Finset.sum_congr rfl
    intro x hx
    congr 1
    apply Finset.sum_congr rfl
    intro y hy
    rw [he x hx y hy]
  rw [← hp]
  exact hK a b

namespace PhysicalCleanLocalGeometry
open PhysicalCleanBlocks PhysicalCleanBanNorm
variable {I : Type*} [Fintype I] {J : ℕ}

def sharedProduct (groups : I → Finset ℕ)
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J) : ℕ :=
  ∏ i, ∏ j, (shared i j).val

@[simp] theorem assemble_shared (groups : I → Finset ℕ)
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J)
    (p : ∀ i, groups i) (i : I) (j : Fin J) :
    assemble shared p i j.castSucc=shared i j := by
  simp [PhysicalCleanBlocks.assemble,PhysicalActiveReindex.assemble]

@[simp] theorem assemble_last (groups : I → Finset ℕ)
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J)
    (p : ∀ i, groups i) (i : I) :
    assemble shared p i (Fin.last J)=p i := by
  simp [PhysicalCleanBlocks.assemble,PhysicalActiveReindex.assemble]

@[simp] theorem padProduct_assemble (groups : I → Finset ℕ)
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J)
    (p : ∀ i, groups i) :
    sourcePadProduct (fun _ p => p.val) (assemble shared p)=sharedProduct groups shared := by
  simp only [sourcePadProduct,sharedProduct,assemble_shared]

@[simp] theorem freshProduct_assemble (groups : I → Finset ℕ)
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J)
    (p : ∀ i, groups i) :
    sourceUnsharedProduct (fun _ p => p.val) (assemble shared p)=∏ i, (p i).val := by
  simp only [sourceUnsharedProduct,assemble_last]

/-- Exact local source geometry after the endpoint eligibility projections.
The cross-edge ban becomes the actual fresh-coordinate ban, and d₀/D and
both eta cutoffs remain explicit. -/
theorem source_geometry_eq
    (groups : I → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (shared : PhysicalActiveReindex.SharedLists (fun i => groups i) J)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i => groups i) J→Prop)
    (u v r U W d₀ H Y : ℝ) (η : ℝ→ℂ) (ψ : 𝓢(ℝ,ℂ)) (σ : ℤ)
    (p q : PadPosition z (sharedProduct groups shared : ℤ) × (∀ i, groups i))
    (hp : sourcePhysicalPositionAllowed u v r U W p.1.val)
    (hq : sourcePhysicalPositionAllowed u v r U W q.1.val)
    (hgp : good p.1.val (assemble shared p.2))
    (hgq : good q.1.val (assemble shared q.2))
    (hap : ∀ i, Function.Injective (assemble shared p.2 i))
    (haq : ∀ i, Function.Injective (assemble shared q.2 i))
    (hd : d₀≤(sharedProduct groups shared : ℝ))
    (hd' : (sharedProduct groups shared : ℝ)<2*d₀) :
    sourcePhysicalEdgeGeometry (fun _ p => p.val) good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ p.1.val (assemble shared p.2) q.1.val (assemble shared q.2) =
      (((d₀/(sharedProduct groups shared : ℝ):ℝ):ℂ)*η (((∏ i, (p.2 i).val):ℕ)/Y)) *
        bannedKernel groups z (sharedProduct groups shared : ℤ) ψ H Y σ p q *
          η (((∏ i, (q.2 i).val):ℕ)/Y) := by
  have hban := CleanCrossBan.sourceCrossEdgeBan_iff (fun i (p : groups i) => p.val)
    (fun _ => Subtype.val_injective) (CleanCrossBan.actual_band_separation groups hdis)
    (assemble shared p.2) (assemble shared q.2)
    (by intro i j; simp only [assemble_shared]) hap haq
  simp only [assemble_last] at hban
  have hpad : (sharedProduct groups shared : ℤ)∣latticeDet p.1.val q.1.val :=
    ⟨_,(PhysicalPadLattice.padCoordinates_det z w hzw _ _ _ p.1.property q.1.property).symm⟩
  have he : sourcePhysicalEdgeAllowed (fun i (p : groups i) => p.val) good
      u v r U W d₀ p.1.val (assemble shared p.2) q.1.val (assemble shared q.2) ↔
      ∀ i, p.2 i≠q.2 i := by
    simp only [sourcePhysicalEdgeAllowed,hp,hq,hgp,hgq,padProduct_assemble,hd,hd',hpad,
      true_and,and_true,hban]
  rw [sourcePhysicalEdgeGeometry_eq_minor _ _ _ _ _ _ _ _ _ _ _ _ (sourceMajorArcs_measurable H Y)]
  simp only [he,padProduct_assemble,freshProduct_assemble]
  simp only [bannedKernel,kernel,padDeterminant]
  split_ifs <;> ring

end PhysicalCleanLocalGeometry
end Elliptic.Operator
