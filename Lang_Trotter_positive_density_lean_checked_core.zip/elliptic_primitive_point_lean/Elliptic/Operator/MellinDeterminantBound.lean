module

public import Elliptic.Operator.MellinBilinearTail
public import Elliptic.Operator.MellinTailAsymptotics

/-! The literal determinant Mellin integral: central energy and proved frequency tails. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinDeterminantBound
open MeasureTheory Set MellinPlane MellinPlaneUniform MellinWeightedTail MellinBilinearTail
open scoped SchwartzMap
set_option backward.isDefEq.respectTransparency false

theorem mellinKernel_continuous (F:𝓢(Plane,ℂ)) (X:ℝ) :
    Continuous (Function.uncurry (fun t s=>mellinKernel F (t/X) s)) := by
  have hc : Continuous (fun p:ℝ×ℝ=>vec (p.1/X/(2*Real.pi)) (p.2/(2*Real.pi))) :=
    coordinateHomeomorph.symm.continuous.comp
      (((continuous_fst.div_const X).div_const (2*Real.pi)).prodMk
        (continuous_snd.div_const (2*Real.pi)))
  exact continuous_const.mul ((FourierTransform.fourier F).continuous.comp hc)

/-- The actual Fourier kernel has the product weight used by the proved tail lemma. -/
theorem kernel_weight_bound (ψ ρ σ:ℝ→ℂ) (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (j:ℕ) :
    ∃C:ℝ,0<C ∧ ∀X:ℝ,1≤X→∀lam t s:ℝ,
      ‖mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) s‖≤
        (C*(1+|lam|)^(2*j))*weight X j t*weight 1 j s := by
  obtain ⟨C,hC,hbound⟩ := mellinKernel_uniform_decay ψ ρ σ hψ hρ hσ hcρ hcσ j
  refine ⟨C,hC,?_⟩
  intro X hX lam t s
  have hXp : 0<X := lt_of_lt_of_le (by norm_num) hX
  have h := hbound X hX lam (t/X) s
  rw [abs_div,abs_of_pos hXp] at h
  simp only [weight,div_one]
  convert h using 1 <;> ring

/-- Quantitative determinant bilinear estimate. All constants precede X,
the modulation parameter, coefficients, and interval endpoints. -/
theorem determinant_bilinear_bound (ψ ρ σ:ℝ→ℂ) (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ) (j:ℕ) (hj:2≤j) :
    ∃C₀ Cj:ℝ,0<C₀ ∧ 0<Cj ∧ ∀X:ℝ,1≤X→∀lam A T S ε:ℝ,
      0≤A→0<T→0<S→∀Q Q':ℝ→ℂ,Continuous Q→Continuous Q'→
      (∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤A*(1+(b-a)/X))→
      (∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤A*(1+(b-a)/X))→
      (∫t in Icc (-T) T,‖Q t‖^2)≤ε→
      (∀s∈Icc (-S) S,(∫t in Icc (-T) T,‖Q' (s-t)‖^2)≤ε)→
      ‖∫t:ℝ,∫s:ℝ,
        mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) s*
          Q t*Q' (s-t)‖≤
        2*S*C₀*ε+48*A*(Cj*(1+|lam|)^(2*j))*
          ((X/T)^j*(1+T/X)+(1/S)^j*(1+S)) := by
  obtain ⟨C₀,hC₀,hzero⟩ := kernel_weight_bound ψ ρ σ hψ hρ hσ hcρ hcσ 0
  obtain ⟨Cj,hCj,hjbound⟩ := kernel_weight_bound ψ ρ σ hψ hρ hσ hcρ hcσ j
  refine ⟨C₀,Cj,hC₀,hCj,?_⟩
  intro X hX lam A T S ε hA hT hS Q Q' hQ hQ' hmean hmean' henergy henergy'
  let K : ℝ→ℝ→ℂ := fun t s=>
    mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) s
  have hK : Continuous (Function.uncurry K) := mellinKernel_continuous _ X
  have hcentral := MellinCentralEnergy.central_rectangle K Q Q' hK hQ hQ' T S C₀ ε
    hS.le hC₀.le (fun t ht s hs=>by simpa [K,weight] using hzero X hX lam t s) henergy henergy'
  have htail := bilinear_rectangle_error K Q Q' hK hQ hQ' A X (Cj*(1+|lam|)^(2*j)) T S
    hA (lt_of_lt_of_le (by norm_num) hX) (by positivity) hT hS j hj hmean hmean' (hjbound X hX lam)
  have hnorm := norm_add_le
    ((∫t in Icc (-T) T,∫s in Icc (-S) S,K t s*Q t*Q' (s-t)))
    ((∫t:ℝ,∫s:ℝ,K t s*Q t*Q' (s-t))-
      (∫t in Icc (-T) T,∫s in Icc (-S) S,K t s*Q t*Q' (s-t)))
  rw [add_sub_cancel] at hnorm
  exact hnorm.trans (add_le_add hcentral htail)

/-- Arbitrary logarithmic saving for the literal determinant Mellin integral.
The chosen frequency and energy exponents precede all coefficients and scales. -/
theorem eventually_determinant_bilinear (ψ ρ σ:ℝ→ℂ)
    (hψ:Smooth ψ) (hρ:Smooth ρ) (hσ:Smooth σ)
    (hcρ:HasCompactSupport ρ) (hcσ:HasCompactSupport σ)
    (A₀ C₄ E Bmin:ℝ) (hA₀:0≤A₀) (hC₄:0≤C₄) (hE:0≤E) :
    ∃B Ac:ℝ,Bmin≤B ∧ 0<B ∧ 0<Ac ∧ ∀ᶠL:ℝ in Filter.atTop,
      ∀X:ℝ,1≤X→∀lam:ℝ,|lam|≤2*L^A₀→∀Q Q':ℝ→ℂ,
      Continuous Q→Continuous Q'→
      (∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q t‖^2)≤L^C₄*(1+(b-a)/X))→
      (∀a b:ℝ,a≤b→(∫t in Icc a b,‖Q' t‖^2)≤L^C₄*(1+(b-a)/X))→
      (∫t in Icc (-2*X*L^B) (2*X*L^B),‖Q t‖^2)≤L^(-Ac)→
      (∫t in Icc (-2*X*L^B) (2*X*L^B),‖Q' t‖^2)≤L^(-Ac)→
      ‖∫t:ℝ,∫s:ℝ,
        mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) s*
          Q t*Q' (s-t)‖≤L^(-E) := by
  obtain ⟨B,hBmin,hB,j,hj,hnum⟩ := MellinTailAsymptotics.exists_tail_parameters
    A₀ C₄ (E+1) Bmin hA₀ hC₄ (by linarith)
  obtain ⟨C₀,Cj,hC₀,hCj,hbound⟩ := determinant_bilinear_bound ψ ρ σ hψ hρ hσ hcρ hcσ j hj
  have hBp : 0<B := by linarith
  refine ⟨B,E+B+2,hBmin,hBp,by linarith,?_⟩
  filter_upwards [hnum Cj hCj.le,Filter.eventually_ge_atTop (max 2 (2*C₀))] with L hnumL hL
  have hL2 : 2≤L := (le_max_left _ _).trans hL
  have hCL : 2*C₀≤L := (le_max_right _ _).trans hL
  have hLp : 0<L := by linarith
  intro X hX lam hlam Q Q' hQ hQ' hmean hmean' henergy henergy'
  have hXp : 0<X := by linarith
  let S := L^B
  let T := X*S
  have hS : 0<S := Real.rpow_pos_of_pos hLp _
  have hT : 0<T := mul_pos hXp hS
  have hST : S≤T := by dsimp [T]; nlinarith
  have hcentral : (∫t in Icc (-T) T,‖Q t‖^2)≤L^(-(E+B+2)) := by
    apply le_trans _ henergy
    apply setIntegral_mono_set (hQ.norm.pow 2).integrableOn_Icc
      (ae_of_all _ (fun t=>sq_nonneg _)) (ae_of_all _ ?_)
    intro t ht
    dsimp [T,S] at ht
    constructor <;> nlinarith [ht.1,ht.2]
  have hcentral' (s:ℝ) (hs:s∈Icc (-S) S) :
      (∫t in Icc (-T) T,‖Q' (s-t)‖^2)≤L^(-(E+B+2)) := by
    rw [interval_substitution (fun t=>‖Q' t‖^2) s (-T) T (by linarith)]
    apply le_trans _ henergy'
    apply setIntegral_mono_set (hQ'.norm.pow 2).integrableOn_Icc
      (ae_of_all _ (fun t=>sq_nonneg _)) (ae_of_all _ ?_)
    intro t ht
    dsimp [T,S] at ht hs hST
    constructor <;> nlinarith [ht.1,ht.2,hs.1,hs.2]
  have hb := hbound X hX lam (L^C₄) T S (L^(-(E+B+2)))
    (Real.rpow_nonneg hLp.le _) hT hS Q Q' hQ hQ' hmean hmean' hcentral hcentral'
  have hpow : (1/S)^j=L^(-B*(j:ℝ)) := by
    dsimp [S]
    rw [one_div,inv_pow,←Real.rpow_mul_natCast hLp.le,←Real.rpow_neg hLp.le]
    congr 1
    ring
  have hXT : X/T=1/S := by dsimp [T]; field_simp
  have hTX : T/X=S := by dsimp [T]; field_simp
  have htail : 48*L^C₄*(Cj*(1+|lam|)^(2*j))*
      ((X/T)^j*(1+T/X)+(1/S)^j*(1+S))≤L^(-(E+1)) := by
    rw [hXT,hTX,hpow]
    calc
      _ ≤96*L^C₄*Cj*(1+2*L^A₀)^(2*j)*L^(-B*(j:ℝ))*(1+L^B) := by
        have hp := pow_le_pow_left₀ (show 0≤1+|lam| by positivity) (by linarith : 1+|lam|≤1+2*L^A₀) (2*j)
        have hh := mul_le_mul_of_nonneg_left hp
          (show 0≤96*L^C₄*Cj*L^(-B*(j:ℝ))*(1+L^B) by positivity)
        convert hh using 1 <;> (try dsimp [S]) <;> ring
      _ ≤_ := hnumL
  have hc : 2*S*C₀*L^(-(E+B+2))≤L^(-(E+1)) := by
    have he : 2*S*C₀*L^(-(E+B+2))=(2*C₀)*L^(-E-2) := by
      dsimp [S]
      calc
        _ = (2*C₀)*(L^B*L^(-(E+B+2))) := by ring
        _ = _ := by rw [←Real.rpow_add hLp]; congr 2; ring
    rw [he]
    calc
      _ ≤ L*L^(-E-2) := mul_le_mul_of_nonneg_right hCL (Real.rpow_nonneg hLp.le _)
      _ = _ := by
        conv_lhs => lhs; rw [←Real.rpow_one L]
        rw [←Real.rpow_add hLp]
        congr 1
        ring
  apply hb.trans
  apply (add_le_add hc htail).trans
  have he : L^(-(E+1))+L^(-(E+1))=2*L^(-E-1) := by
    rw [show -(E+1)= -E-1 by ring]
    ring
  rw [he]
  calc
    _ ≤ L*L^(-E-1) := mul_le_mul_of_nonneg_right hL2 (Real.rpow_nonneg hLp.le _)
    _ = _ := by
      conv_lhs => lhs; rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 1
      ring

end Elliptic.Operator.MellinDeterminantBound
