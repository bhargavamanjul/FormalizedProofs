module

public import Elliptic.Operator.SeparatedCircleSum
public import Mathlib.RingTheory.Coprime.Lemmas

/-!
# Rational approximation and the actual exponential-matrix bound

Reduced rational approximation gives separated blocks of phases. Their
literal harmonic bounds are summed over a quotient/remainder partition.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open Elliptic.SourceContracts
attribute [local instance] Classical.propDecidable

/-- A nonintegral rational of denominator d has circle norm at least 1/d. -/
theorem rational_circle_norm_lower (c : ℤ) (d : ℕ) (hd : 0 < d)
    (hcop : IsCoprime c (d : ℤ)) (h : ℤ) (hne : h ≠ 0)
    (hsmall : |(h : ℝ)| < (d : ℝ)) :
    1/(d : ℝ) ≤ ‖(((c : ℝ)*h/d : ℝ) : AddCircle (1 : ℝ))‖ := by
  have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
  let k : ℤ := round ((c : ℝ)*h/d)
  have hnum : c*h-k*(d : ℤ) ≠ 0 := by
    intro he
    have hdiv : (d : ℤ) ∣ c*h := ⟨k, by nlinarith⟩
    have hdh : (d : ℤ) ∣ h := hcop.symm.dvd_of_dvd_mul_left hdiv
    have hsize := Int.natAbs_le_of_dvd_ne_zero hdh hne
    have hsizeZ : (d : ℤ) ≤ |h| := by
      simpa only [Int.natAbs_natCast, Int.natCast_natAbs] using (Int.ofNat_le.mpr hsize)
    have hsizeR : (d : ℝ) ≤ |(h : ℝ)| := by exact_mod_cast hsizeZ
    linarith
  have hnumsize : (1 : ℝ) ≤ |((c*h-k*(d : ℤ) : ℤ) : ℝ)| := by
    exact_mod_cast Int.one_le_abs hnum
  have he : (c : ℝ)*h/d - (k : ℝ) = ((c*h-k*(d : ℤ) : ℤ) : ℝ)/(d : ℝ) := by
    push_cast
    field_simp
  rw [AddCircle.norm_eq]
  simp only [inv_one, one_mul, mul_one]
  change 1/(d : ℝ) ≤ |(c : ℝ)*h/d - (k : ℝ)|
  rw [he, abs_div, abs_of_pos hdR]
  exact div_le_div_of_nonneg_right hnumsize hdR.le

/-- The source block separation, with the perturbation error included. -/
theorem rational_approximation_circle_separation (θ : ℝ) (c : ℤ) (d : ℕ)
    (hd : 0 < d) (hcop : IsCoprime c (d : ℤ))
    (happrox : |θ-(c : ℝ)/d| ≤ 1/(d : ℝ)^2)
    (h : ℤ) (hne : h ≠ 0) (hshort : |(h : ℝ)| ≤ (d : ℝ)/2) :
    1/(2*(d : ℝ)) ≤ ‖((θ*h : ℝ) : AddCircle (1 : ℝ))‖ := by
  have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
  have hrat := rational_circle_norm_lower c d hd hcop h hne (by linarith)
  have herror : ‖((((c : ℝ)*h/d)-(θ*h) : ℝ) : AddCircle (1 : ℝ))‖ ≤
      1/(2*(d : ℝ)) := by
    calc
      _ ≤ |(c : ℝ)*h/d - θ*h| := QuotientAddGroup.norm_mk_le_norm
      _ = |θ-(c : ℝ)/d| * |(h : ℝ)| := by
        rw [show (c : ℝ)*h/d-θ*h = -(θ-(c : ℝ)/d)*(h : ℝ) by ring,
          abs_mul, abs_neg]
      _ ≤ (1/(d : ℝ)^2)*((d : ℝ)/2) :=
        mul_le_mul happrox hshort (abs_nonneg _) (by positivity)
      _ = _ := by field_simp
  have htriangle := norm_sub_norm_le
    ((((c : ℝ)*h/d) : ℝ) : AddCircle (1 : ℝ))
    (((θ*h) : ℝ) : AddCircle (1 : ℝ))
  rw [← AddCircle.coe_sub] at htriangle
  have hid : 1/(d : ℝ) - 1/(2*(d : ℝ)) = 1/(2*(d : ℝ)) := by field_simp; ring
  linarith

/-- Every consecutive block of at most floor(d/2) indices satisfies the
literal harmonic estimate, independently of its integer starting point. -/
theorem rational_phase_block_sum_le (θ : ℝ) (c : ℤ) (d B m : ℕ) (a : ℝ)
    (hd : 0 < d) (hcop : IsCoprime c (d : ℤ))
    (happrox : |θ-(c : ℝ)/d| ≤ 1/(d : ℝ)^2) (hm : 2*m ≤ d) :
    (∑ k ∈ Finset.range m, circleGeometricBound B (θ*(a+k))) ≤
      2*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ)) := by
  apply separated_circle_geometric_sum_le (Finset.range m) (fun k : ℕ => θ*(a+k)) B d hd
  intro i hi j hj hij
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  have hne : (i : ℤ)-j ≠ 0 := by omega
  have hshort : |(((i : ℤ)-j : ℤ) : ℝ)| ≤ (d : ℝ)/2 := by
    have hmR : 2*(m : ℝ) ≤ d := by exact_mod_cast hm
    have hiR : (i : ℝ) < m := by exact_mod_cast hi'
    have hjR : (j : ℝ) < m := by exact_mod_cast hj'
    push_cast
    apply abs_le.mpr
    constructor <;> linarith [Nat.cast_nonneg (α := ℝ) i, Nat.cast_nonneg (α := ℝ) j]
  have h := rational_approximation_circle_separation θ c d hd hcop happrox
    ((i : ℤ)-j) hne hshort
  have he : θ*(a+i)-θ*(a+j) = θ*(((i : ℤ)-j : ℤ) : ℝ) := by push_cast; ring
  rwa [he]

/-- Partition an arbitrary consecutive interval into literal blocks;
quotient and remainder introduce no multiplicity or support loss. -/
theorem rational_phase_interval_sum_le (θ : ℝ) (c : ℤ) (d B m N : ℕ) (a : ℝ)
    (hd : 0 < d) (hcop : IsCoprime c (d : ℤ))
    (happrox : |θ-(c : ℝ)/d| ≤ 1/(d : ℝ)^2) (hm0 : 0 < m) (hm : 2*m ≤ d) :
    (∑ k ∈ Finset.range N, circleGeometricBound B (θ*(a+k))) ≤
      ((N/m+1 : ℕ) : ℝ) * (2*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ))) := by
  let f : ℕ → ℕ × ℕ := fun k => (k/m, k%m)
  have hinj : Function.Injective f := by
    intro k l hkl
    have hq := congrArg Prod.fst hkl
    have hr := congrArg Prod.snd hkl
    dsimp [f] at hq hr
    have hk := Nat.div_add_mod k m
    have hl := Nat.div_add_mod l m
    rw [hq, hr] at hk
    omega
  have hsum : (∑ k ∈ Finset.range N, circleGeometricBound B (θ*(a+k))) ≤
      ∑ p ∈ Finset.range (N/m+1) ×ˢ Finset.range m,
        circleGeometricBound B (θ*(a+(p.1*m+p.2 : ℕ))) := by
    apply Finset.sum_le_sum_of_injOn f hinj.injOn
    · intro p hp
      obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hp
      apply Finset.mem_product.mpr
      refine ⟨Finset.mem_range.mpr ?_, Finset.mem_range.mpr (Nat.mod_lt k hm0)⟩
      exact Nat.lt_succ_of_le (Nat.div_le_div_right (Nat.le_of_lt (Finset.mem_range.mp hk)))
    · intro k hk
      dsimp [f]
      rw [Nat.mul_comm (k/m) m, Nat.div_add_mod]
    · intro p hp hnot
      exact circleGeometricBound_nonneg B _
  calc
    _ ≤ _ := hsum
    _ = ∑ b ∈ Finset.range (N/m+1), ∑ k ∈ Finset.range m,
        circleGeometricBound B (θ*((a+(b*m : ℕ))+k)) := by
      rw [Finset.sum_product]
      simp only [Nat.cast_add, add_assoc]
    _ ≤ ∑ b ∈ Finset.range (N/m+1), 2*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ)) := by
      apply Finset.sum_le_sum
      intro b hb
      exact rational_phase_block_sum_le θ c d B m (a+(b*m : ℕ)) hd hcop happrox hm
    _ = _ := by simp

/-- The symmetric difference interval is exactly a translated natural interval. -/
theorem circleGramBudget_eq_range (A B : ℕ) (θ : ℝ) :
    circleGramBudget A B θ =
      ∑ k ∈ Finset.range (2*A+1), circleGeometricBound B (θ*(-(A : ℝ)+k)) := by
  unfold circleGramBudget
  rw [Int.Icc_eq_finset_map, Finset.sum_map]
  have hsize : ((A : ℤ)+1-(-(A : ℤ))).toNat = 2*A+1 := by omega
  rw [hsize]
  apply Finset.sum_congr rfl
  intro k hk
  simp

/-- A denominator at least two supplies enough short blocks, with a
uniform absolute constant independent of both side lengths. -/
theorem half_denominator_block_count_le (A d : ℕ) (hd : 2 ≤ d) :
    (((2*A+1)/(d/2)+1 : ℕ) : ℝ) ≤ 6*((A : ℝ)/(d : ℝ)+1) := by
  have hm : 0 < d/2 := by omega
  have hdm : d ≤ 3*(d/2) := by omega
  have hqm := Nat.div_mul_le_self (2*A+1) (d/2)
  have hdR : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hd2R : (2 : ℝ) ≤ d := by exact_mod_cast hd
  have hdmR : (d : ℝ) ≤ 3*((d/2 : ℕ) : ℝ) := by exact_mod_cast hdm
  have hqmR : (((2*A+1)/(d/2) : ℕ) : ℝ)*((d/2 : ℕ) : ℝ) ≤ 2*(A : ℝ)+1 := by
    exact_mod_cast hqm
  have hqR : 0 ≤ (((2*A+1)/(d/2) : ℕ) : ℝ) := Nat.cast_nonneg _
  have hqd : (((2*A+1)/(d/2) : ℕ) : ℝ)*(d : ℝ) ≤ 3*(2*(A : ℝ)+1) := by
    nlinarith
  rw [Nat.cast_add, Nat.cast_one]
  apply (mul_le_mul_iff_right₀ hdR).mp
  have he : (6*((A : ℝ)/(d : ℝ)+1))*(d : ℝ) = 6*(A : ℝ)+6*(d : ℝ) := by
    field_simp
  rw [mul_comm (d : ℝ) (6*((A : ℝ)/(d : ℝ)+1)), he]
  nlinarith

/-- The elementary rational-approximation estimate of PD (4.32),
now for the literal reciprocal-distance sum. -/
theorem circleGramBudget_le_rational (A B d : ℕ) (θ : ℝ) (c : ℤ)
    (hd : 2 ≤ d) (hcop : IsCoprime c (d : ℤ))
    (happrox : |θ-(c : ℝ)/d| ≤ 1/(d : ℝ)^2) :
    circleGramBudget A B θ ≤
      12*((A : ℝ)/(d : ℝ)+1)*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ)) := by
  rw [circleGramBudget_eq_range]
  have h := rational_phase_interval_sum_le θ c d B (d/2) (2*A+1) (-(A : ℝ))
    (by omega) hcop happrox (by omega) (by omega)
  have hnon : 0 ≤ (B : ℝ)+(d : ℝ)*(harmonic d : ℝ) := by
    have hh : (0 : ℝ) ≤ (harmonic d : ℝ) := by
      rw [harmonic, Rat.cast_sum]
      exact Finset.sum_nonneg fun k hk => by positivity
    positivity
  calc
    _ ≤ _ := h
    _ ≤ (6*((A : ℝ)/(d : ℝ)+1))*(2*((B : ℝ)+(d : ℝ)*(harmonic d : ℝ))) :=
      mul_le_mul_of_nonneg_right (half_denominator_block_count_le A d hd) (by positivity)
    _ = _ := by ring

/-- The genuine two-dimensional determinant estimate with an explicit
uniform constant. No matrix or exponential-sum estimate is a hypothesis. -/
theorem determinant_kernel_bound_of_rational_approximation
    (A B d : ℕ) (θ a b : ℝ) (c : ℤ) (hd : 2 ≤ d)
    (hcop : IsCoprime c (d : ℤ))
    (happrox : |θ-(c : ℝ)/d| ≤ 1/(d : ℝ)^2) :
    FiniteKernelBound (Finset.range B ×ˢ Finset.range A)
      (Finset.range A ×ˢ Finset.range B) (fun _ => 1) (fun _ => 1)
      (fun p q => additivePhase (θ * ((a+p.1)*(b+q.1) - (b+p.2)*(a+q.2))))
      (12*((A : ℝ)/(d : ℝ)+1)*((B : ℝ)+(d : ℝ)*(1+Real.log d))) := by
  intro v
  have hh := harmonic_le_one_add_log d
  have hbudget := circleGramBudget_le_rational A B d θ c hd hcop happrox
  have hlog : circleGramBudget A B θ ≤
      12*((A : ℝ)/(d : ℝ)+1)*((B : ℝ)+(d : ℝ)*(1+Real.log d)) := by
    apply hbudget.trans
    gcongr
  exact (determinant_kernel_bound_of_circle_sum A B θ a b v).trans
    (mul_le_mul_of_nonneg_right hlog (Real.sqrt_nonneg _))

end Elliptic.Operator
