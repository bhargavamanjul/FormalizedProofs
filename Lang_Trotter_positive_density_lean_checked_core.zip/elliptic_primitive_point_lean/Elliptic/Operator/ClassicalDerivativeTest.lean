module

public import Elliptic.Operator.LogPhaseProgression

/-!
# A separately identified classical derivative-test input

This is the ordinary fixed-order van der Corput derivative test, in the
form of O. Robert, *On van der Corput's k-th derivative test for exponential
sums*, Theorem 3, equation (17) (2015 author manuscript, page 8).
It is NOT an added field of the existing accepted sieve-source record.
It is an explicit external proposition, never a global axiom.

The finite jet formulation supplies the actual derivatives, their
continuity, and their differentiation identities. The slightly enlarged
interval [0,M] contains every summation point 0,...,M-1. Constants depend
only on the fixed derivative order and the derivative-ratio bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ClassicalDerivativeTest
open scoped BigOperators
open Set

def exponent (k : ℕ) : ℝ := 1 / ((2:ℝ)^k-2)

def secondaryExponent (k : ℕ) : ℝ := 1-4/(2:ℝ)^k

/-- An ordinary classical exponential-sum theorem. No primes, exceptional
sets, major arcs, elliptic curves or manuscript conclusion occur in it. -/
def FixedOrderDerivativeTest : Prop :=
  ∀ k : ℕ, 2≤k → ∀ α : ℝ, 1≤α → ∃ C : ℝ, 0<C ∧
    ∀ M : ℕ, 1≤M → ∀ F : ℕ→ℝ→ℝ, ∀ lam : ℝ, 0<lam →
    (∀ j≤k, ContinuousOn (F j) (Icc (0:ℝ) M)) →
    (∀ j<k, ∀ y∈Icc (0:ℝ) M, HasDerivAt (F j) (F (j+1) y) y) →
    (∀ y∈Icc (0:ℝ) M, lam≤|F k y| ∧ |F k y|≤α*lam) →
    ‖∑ n∈Finset.range M,
      Complex.exp (Complex.I*((2*Real.pi*F 0 n:ℝ):ℂ))‖ ≤
      C*((M:ℝ)*lam^(exponent k)+(M:ℝ)^(secondaryExponent k)*lam^(-exponent k))

theorem exponent_pos (k : ℕ) (hk : 2≤k) : 0<exponent k := by
  unfold exponent
  have h : (2:ℝ)^2≤2^k := pow_le_pow_right₀ (by norm_num) hk
  apply one_div_pos.mpr
  norm_num at h ⊢
  linarith

end Elliptic.Operator.ClassicalDerivativeTest
