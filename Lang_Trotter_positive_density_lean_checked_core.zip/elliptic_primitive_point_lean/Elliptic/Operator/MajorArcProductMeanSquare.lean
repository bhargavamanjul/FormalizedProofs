module
public import Elliptic.Operator.MajorArcScaleCancellation

/-! The source long-polynomial product mean square at real dyadic scales.
The divisor-square input is the existing classical arithmetic hypothesis. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcProductMeanSquare
open scoped BigOperators
open Filter MeasureTheory Artin.MarkedSource MajorArcScaleCancellation
open ProductDirichletMeanSquare
set_option maxHeartbeats 500000

 theorem normalized_mean_square (s t : Finset ℕ) (Hm Hn : ℝ) (hm : 0<Hm) (hn : 0<Hn)
    (U V : ℕ) (hU : 1≤U) (hV : 1≤V) (hs : s⊆Finset.Icc 1 U) (ht : t⊆Finset.Icc 1 V)
    (α β : ℕ→ℂ) (B : ℝ) (hB : 0≤B) (hα : ∀m∈s,‖α m‖≤B) (hβ : ∀n∈t,‖β n‖≤B)
    {k l : ℕ} (χ : DirichletCharacter ℂ k) (ψ : DirichletCharacter ℂ l)
    (a b : ℝ) (hab : a≤b) :
    (∫v in a..b,‖longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2)≤
      ((Hm*Hn)⁻¹)^2*((b-a+4*(U*V:ℕ)*(1+Real.log (U*V:ℕ)))*(B*B)^2*
        (∑u∈Finset.Icc 1 (U*V),(u.divisors.card:ℝ)^2)) := by
  have hα' : ∀m∈s,‖α m*χ (m:ZMod k)‖≤B := by
    intro m hm'
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg _)).trans (by simpa using hα m hm')
  have hβ' : ∀n∈t,‖β n*ψ (n:ZMod l)‖≤B := by
    intro n hn'
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left (ψ.norm_le_one _) (norm_nonneg _)).trans (by simpa using hβ n hn')
  have he : ∀v,‖longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2=
      ((Hm*Hn)⁻¹)^2*‖polynomial s (fun m=>α m*χ (m:ZMod k)) v*
        polynomial t (fun n=>β n*ψ (n:ZMod l)) v‖^2 := by
    intro v
    simp only [longPolynomial,polynomial,norm_mul,norm_inv,Complex.norm_real,
      Real.norm_eq_abs,abs_of_pos hm,abs_of_pos hn,mul_inv_rev]
    ring
  simp_rw [he]
  rw [intervalIntegral.integral_const_mul]
  exact mul_le_mul_of_nonneg_left
    (product_mean_square s t U V hU hV hs ht _ _ B B hB hB hα' hβ' a b hab) (sq_nonneg _)

 private theorem numerical_bound (L X Y Z D C : ℝ) (hL : 1≤L) (hX : 0<X)
    (hY : 0≤Y) (hYmax : Y≤9*X) (hlog : 0≤Real.log Y) (hlogmax : Real.log Y≤10*L)
    (hZ : 0≤Z) (hD : 0≤D) (hC : 0≤C) :
    (X⁻¹)^2*((Z+4*Y*(1+Real.log Y))*(L^C*L^C)^2*(D*Y*(Real.log Y)^3))≤
      (3564000*D)*L^(4*C+4)*(1+Z/X) := by
  have hLp : 0<L := by linarith
  have htime : Z+4*Y*(1+Real.log Y)≤Z+396*X*L := by
    have hh := mul_le_mul hYmax (show 1+Real.log Y≤11*L by linarith) (by linarith : 0≤1+Real.log Y) (by positivity : 0≤9*X)
    nlinarith only [hh]
  have hdiv : D*Y*(Real.log Y)^3≤9000*D*X*L^3 := by
    have hh := mul_le_mul hYmax (pow_le_pow_left₀ hlog hlogmax 3) (by positivity : 0≤(Real.log Y)^3) (by positivity : 0≤9*X)
    have hh' := mul_le_mul_of_nonneg_left hh hD
    nlinarith only [hh']
  have hnorm : (L^C*L^C)^2=L^(4*C) := by
    rw [←Real.rpow_add hLp,←Real.rpow_mul_natCast hLp.le]
    congr 1
    norm_num
    ring
  have hstage : (X⁻¹)^2*((Z+4*Y*(1+Real.log Y))*(L^C*L^C)^2*(D*Y*(Real.log Y)^3))≤
      (X⁻¹)^2*((Z+396*X*L)*L^(4*C)*(9000*D*X*L^3)) := by
    rw [hnorm]
    apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
    apply mul_le_mul
    · exact mul_le_mul_of_nonneg_right htime (Real.rpow_nonneg hLp.le _)
    · exact hdiv
    · positivity
    · positivity
  have hz : Z/X+396*L≤396*L*(1+Z/X) := by
    have hz' : 0≤Z/X := div_nonneg hZ hX.le
    nlinarith [mul_nonneg (show 0≤L-1 by linarith) hz']
  calc
    _ ≤ (X⁻¹)^2*((Z+396*X*L)*L^(4*C)*(9000*D*X*L^3)) := hstage
    _ = 9000*D*L^(4*C)*L^3*(Z/X+396*L) := by field_simp
    _ ≤ 9000*D*L^(4*C)*L^3*(396*L*(1+Z/X)) :=
      mul_le_mul_of_nonneg_left hz (by positivity)
    _ = _ := by
      rw [show 4*C+4=4*C+(4:ℕ) by norm_num,Real.rpow_add hLp,Real.rpow_natCast]
      ring

/-- Uniform normalized mean square on every translated interval. The logarithmic
exponent depends only on the coefficient exponent, and not on the prime groups. -/
 theorem eventually_long_product_mean_square
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ C : ℝ) (hδ : 0<δ) (hC : 0≤C) :
    ∀ᶠ L : ℝ in atTop,∀Hm Hn : ℝ,1≤Hm→1≤Hn→
      Real.exp (δ*L)≤Hm*Hn→Hm*Hn≤Real.exp (2*L)→
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^C)→(∀n∈t,‖β n‖≤L^C)→
      ∀(k l : ℕ) (χ : DirichletCharacter ℂ k) (ψ : DirichletCharacter ℂ l),
      ∀a b : ℝ,a≤b→
      (∫v in a..b,‖longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2)≤
        L^(4*C+5)*(1+(b-a)/(Hm*Hn)) := by
  obtain ⟨D,hD,Y₀,hdiv⟩ := uniform_integer_divisor_moment hD
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop ((Y₀:ℝ)/δ),
    eventually_ge_atTop (3564000*D)] with L hL hLY hLD
  intro Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ a b hab
  have hLp : 0<L := by linarith
  have hmp : 0<Hm := by linarith
  have hnp : 0<Hn := by linarith
  let U : ℕ := ⌈2*Hm⌉₊
  let V : ℕ := ⌈2*Hn⌉₊
  have hU : 1≤U := Nat.one_le_ceil_iff.mpr (by positivity)
  have hV : 1≤V := Nat.one_le_ceil_iff.mpr (by positivity)
  have hUlo : Hm≤(U:ℝ) := (by linarith : Hm≤2*Hm).trans (Nat.le_ceil _)
  have hVlo : Hn≤(V:ℝ) := (by linarith : Hn≤2*Hn).trans (Nat.le_ceil _)
  have hUhi : (U:ℝ)≤3*Hm := by have := Nat.ceil_lt_add_one (show 0≤2*Hm by positivity);dsimp [U];linarith
  have hVhi : (V:ℝ)≤3*Hn := by have := Nat.ceil_lt_add_one (show 0≤2*Hn by positivity);dsimp [V];linarith
  have hUVlo : Hm*Hn≤(U*V:ℕ) := by
    simpa only [Nat.cast_mul] using mul_le_mul hUlo hVlo hnp.le (Nat.cast_nonneg U)
  have hUVhi : (U*V:ℕ)≤9*(Hm*Hn) := by
    have := mul_le_mul hUhi hVhi (Nat.cast_nonneg V) (by positivity : 0≤3*Hm)
    simpa only [Nat.cast_mul] using (show (U:ℝ)*V≤9*(Hm*Hn) by nlinarith only [this])
  have hUVone : (1:ℝ)≤(U*V:ℕ) := by exact_mod_cast (Nat.mul_pos hU hV)
  have hthreshold : Y₀≤U*V := by
    have hy : (Y₀:ℝ)≤δ*L := by simpa only [mul_comm] using (div_le_iff₀ hδ).mp hLY
    exact_mod_cast hy.trans ((by linarith [Real.add_one_le_exp (δ*L)] : δ*L≤Real.exp (δ*L)).trans (hmin.trans hUVlo))
  have hlog : 0≤Real.log (U*V:ℕ) := Real.log_nonneg hUVone
  have hlogmax : Real.log (U*V:ℕ)≤10*L := by
    have hh := Real.log_le_log (show (0:ℝ)<(U*V:ℕ) by linarith) (hUVhi.trans (mul_le_mul_of_nonneg_left hmax (by norm_num)))
    rw [Real.log_mul (by norm_num : (9:ℝ)≠0) (Real.exp_ne_zero _),Real.log_exp] at hh
    have h9 := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<9)
    linarith
  have hs' : s⊆Finset.Icc 1 U := by
    intro n hn'
    have hh := hs n hn'
    exact Finset.mem_Icc.mpr ⟨by exact_mod_cast (hm.trans hh.1),by exact_mod_cast hh.2.trans (Nat.le_ceil (2*Hm))⟩
  have ht' : t⊆Finset.Icc 1 V := by
    intro n hn'
    have hh := ht n hn'
    exact Finset.mem_Icc.mpr ⟨by exact_mod_cast (hn.trans hh.1),by exact_mod_cast hh.2.trans (Nat.le_ceil (2*Hn))⟩
  have hraw := normalized_mean_square s t Hm Hn hmp hnp U V hU hV hs' ht' α β (L^C)
    (Real.rpow_nonneg hLp.le _) hα hβ χ ψ a b hab
  have htime : 0≤b-a+4*(U*V:ℕ)*(1+Real.log (U*V:ℕ)) := by positivity
  calc
    _ ≤ ((Hm*Hn)⁻¹)^2*((b-a+4*(U*V:ℕ)*(1+Real.log (U*V:ℕ)))*(L^C*L^C)^2*
        (D*(U*V:ℕ)*(Real.log (U*V:ℕ))^3)) := hraw.trans
      (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left (hdiv _ hthreshold) (mul_nonneg htime (sq_nonneg _))) (sq_nonneg _))
    _ ≤ (3564000*D)*L^(4*C+4)*(1+(b-a)/(Hm*Hn)) := numerical_bound L (Hm*Hn) (U*V:ℕ) (b-a) D C
      hL (mul_pos hmp hnp) (Nat.cast_nonneg _) hUVhi hlog hlogmax (sub_nonneg.mpr hab) hD.le hC
    _ ≤ L*L^(4*C+4)*(1+(b-a)/(Hm*Hn)) := by gcongr
    _ = _ := by
      conv_lhs => lhs;lhs;rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 2
      ring

end Elliptic.Operator.MajorArcProductMeanSquare
