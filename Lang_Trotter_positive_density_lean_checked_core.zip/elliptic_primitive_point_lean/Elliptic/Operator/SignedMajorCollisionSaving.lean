module
public import Elliptic.Operator.SignedMajorCollision
public import Elliptic.Operator.SignedDivisorMomentScale

/-! Common-label deletion for the actual major term at the source scale. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorCollisionSaving
open scoped BigOperators
open Filter Artin Artin.MarkedSource SignedCauchyExpansion SignedLabelCollisions
open SignedMajorCollision SignedDivisorMomentScale
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

/-- Arbitrary logarithmic saving for the actual noncoprime major-label sum.
The sole analytic input is the unchanged global divisor-square moment. -/
theorem eventually_collision_major_saving {K : ℕ}
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (c C G Cψ A : ℝ) (hc : 1≤c) (hCψ : 0≤Cψ) :
    ∀ᶠx : ℝ in atTop,∀(b : Bands K),
      Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))→
      ∀(s t : Finset ℕ) (N : ℕ),(N:ℝ)≤c*x→(∀m∈s,0<m)→
      (∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)→∀Y : ℝ,0<Y→
      ∀(η ψ : ℝ→ℂ) (α β : ℕ→ℂ),
      (∀v,‖η v‖≤1)→(∀v,‖ψ v‖≤1)→
      (∀v,η v≠0→1≤v ∧ v≤4)→(∀v,ψ v≠0→|v|≤Cψ)→
      (∀m∈s,‖α m‖≤(Real.log x)^C)→(∀n∈t,‖β n‖≤(Real.log x)^C)→
      (∑a : LabelTuple b x,∑d : LabelTuple b x,
        if ¬(labelProduct b x a).Coprime (labelProduct b x d) then
          pairAbsolute b x Y ((Real.log x)^G) s t η ψ α β a d else 0)≤
        x*Y*(Real.log x)^(-A) := by
  obtain ⟨T,hT,ht⟩ := eventually_divisor_sum_scaled hD c hc
  let Q : ℝ := 64*(2*Cψ+1)*T*(8*Real.log 4*K)
  filter_upwards [ht,Real.tendsto_log_atTop.eventually
    (SignedCollisionAsymptotics.eventually_rpow_exp_loss Q (4*C+3*G+3) A),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    eventually_gt_atTop (0:ℝ)] with x ht he hL hx
  intro b hdis s t N hN hs hp Y hY η ψ α β hη hψ hηs hψs hα hβ
  have hLp : 0<Real.log x := by linarith
  have hm := collision_scalarMajor_sum_le b x hdis hL s t N hs hp Cψ Y ((Real.log x)^G)
    hCψ hY (by positivity) η ψ α β 1 1 ((Real.log x)^C) ((Real.log x)^C)
    (by norm_num) (by norm_num) (by positivity) (by positivity) hη hψ hηs hψs hα hβ
  have hr : ((Real.log x)^C)^2*((Real.log x)^C)^2*((Real.log x)^G)^3*(Real.log x)^3=
      (Real.log x)^(4*C+3*G+3) := by
    simp_rw [←Real.rpow_mul_natCast hLp.le]
    rw [←Real.rpow_ofNat (Real.log x) 3]
    rw [←Real.rpow_add hLp,←Real.rpow_add hLp,←Real.rpow_add hLp]
    congr 1
    ring
  have hcoef : 0≤64*(2*Cψ+1)*1^2*((Real.log x)^C)^2*((Real.log x)^C)^2*1*((Real.log x)^G)^3*Y := by positivity
  calc
    _ ≤ _ := hm
    _ ≤ 64*(2*Cψ+1)*1^2*((Real.log x)^C)^2*((Real.log x)^C)^2*1*((Real.log x)^G)^3*Y*
        (T*x*(Real.log x)^3)*(8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))) := by
      apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      apply mul_le_mul_of_nonneg_right _ (by have := Real.log_nonneg (by norm_num : (1:ℝ)≤4); positivity)
      exact mul_le_mul_of_nonneg_left (ht N hN) hcoef
    _ = x*Y*(Q*(Real.log x)^(4*C+3*G+3)*Real.exp (-((Real.log x)^(1/10:ℝ)))) := by
      rw [←hr]
      dsimp only [Q]
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left he (by positivity)

end Elliptic.Operator.SignedMajorCollisionSaving
