module

public import Elliptic.Operator.DirichletSampling

/-!
# Counting the exceptional unit intervals of a growing prime polynomial

Actual exceeding points, one from each unit interval, are split into
three residue classes. The coefficient-independent sample estimate and
unique-factorization energy yield a finite, completely explicit version
of the counting inequality (5.12), uniform in the real shift.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SmallPrimePower
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance primeExceptionalDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The explicit sampling constant, independent of all polynomial coefficients. -/
def sampleBudget (Y : ℕ) (a b : ℝ) : ℝ :=
  (2+(Real.log (Y:ℝ))^2)*(b+1-a+4*(Y:ℝ)*(1+Real.log (Y:ℝ)))

theorem sampleBudget_nonneg (Y : ℕ) (hY : 1≤Y) (a b : ℝ) (hab : a≤b) :
    0≤sampleBudget Y a b := by
  have hl : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast hY)
  have ha : 0≤b+1-a := by linarith
  unfold sampleBudget
  positivity

/-- A growing-prime 2j-th moment over arbitrary separated real samples. -/
theorem separated_prime_moment {ι : Type*} (s : Finset ι) (τ : ι→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hsep : ∀i∈s,∀k∈s,i≠k→1≤|τ i-τ k|)
    (S : Finset ℕ) (j : ℕ) (hprime : ∀p∈S,p.Prime) (B : ℕ)
    (hBpos : 1≤B) (hB : ∀p∈S,p≤B) (c : S→ℂ) :
    (∑i∈s,‖∑p : S,c p*Artin.MarkedReplacement.archimedeanPhase (τ i) p.val‖^(2*j))≤
      sampleBudget (B^j) a b*((j.factorial:ℝ)*(∑p : S,‖c p‖^2)^j) := by
  have hY : 1≤B^j := one_le_pow₀ hBpos
  have he (t : ℝ) : ‖∑p : S,c p*Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j)=
      ‖DirichletMeanSquare.polynomial (B^j) (powerCoefficient S j c) t‖^2 := by
    rw [←polynomial_power_eq_full S j hprime B hB,norm_pow,←pow_mul]
    congr 1
    omega
  simp_rw [he]
  exact (DirichletMeanSquare.separated_mean_square s τ a b hab hτ hsep (B^j) hY _).trans
    (mul_le_mul_of_nonneg_left (full_powerCoefficient_l2 S j hprime B hB c)
      (sampleBudget_nonneg (B^j) hY a b hab))

/-- Source normalized coefficients in the separated growing moment estimate. -/
theorem separated_normalized_prime_moment {ι : Type*} (s : Finset ι) (τ : ι→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hsep : ∀i∈s,∀k∈s,i≠k→1≤|τ i-τ k|)
    (S : Finset ℕ) (j : ℕ) (hprime : ∀p∈S,p.Prime) (B : ℕ)
    (hBpos : 1≤B) (hB : ∀p∈S,p≤B) (Pscale : ℝ) (hP : 0<Pscale)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (ξ : ℝ) :
    (∑i∈s,‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
      Artin.MarkedReplacement.archimedeanPhase (τ i) p.val‖^(2*j))≤
      sampleBudget (B^j) a b*((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j) := by
  have hY : 1≤B^j := one_le_pow₀ hBpos
  have he (t : ℝ) : ‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
        Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j)=
      ‖DirichletMeanSquare.polynomial (B^j)
        (powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ)) t‖^2 := by
    rw [←polynomial_power_eq_full S j hprime B hB,norm_pow,←pow_mul]
    congr 1
    omega
  simp_rw [he]
  apply (DirichletMeanSquare.separated_mean_square s τ a b hab hτ hsep (B^j) hY _).trans
  apply mul_le_mul_of_nonneg_left _ (sampleBudget_nonneg (B^j) hY a b hab)
  have hec : (∑n∈products S j,‖powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ) n‖^2)=
      ∑n∈Finset.Icc 1 (B^j),‖powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ) n‖^2 := by
    apply Finset.sum_subset (products_subset_Icc S j hprime B hB)
    intro n hn hnS
    simp [powerCoefficient_eq_zero_of_not_mem S j _ hnS]
  rw [←hec]
  exact normalizedPrimeCoefficient_power_l2 S j hprime Pscale hP χ ξ

/-- Intervals whose integer endpoints agree modulo three supply separated samples. -/
theorem mod_three_samples_separated (s : Finset ℤ) (τ : ℤ→ℝ)
    (hcell : ∀i∈s,(i:ℝ)≤τ i∧τ i≤(i:ℝ)+1) (r : ℤ) :
    ∀i∈s.filter (fun i=>i%3=r),∀k∈s.filter (fun k=>k%3=r),
      i≠k→1≤|τ i-τ k| := by
  intro i hi k hk hik
  obtain ⟨his,hir⟩ := Finset.mem_filter.mp hi
  obtain ⟨hks,hkr⟩ := Finset.mem_filter.mp hk
  have hiτ := hcell i his
  have hkτ := hcell k hks
  rcases lt_or_gt_of_ne hik with hik|hki
  · have hgap : i+3≤k := by omega
    have hgapR : (i:ℝ)+3≤(k:ℝ) := by exact_mod_cast hgap
    rw [abs_of_nonpos (by linarith : τ i-τ k≤0)]
    linarith
  · have hgap : k+3 ≤ i := by omega
    have hgapR : (k:ℝ)+3≤(i:ℝ) := by exact_mod_cast hgap
    rw [abs_of_nonneg (by linarith : 0≤τ i-τ k)]
    linarith

/-- Literal finite unit-interval exceptional count, with the exact growing factorial.
Every interval is witnessed by an actual exceeding point in its closure. -/
theorem unit_interval_exceedance_card (s : Finset ℤ) (τ : ℤ→ℝ)
    (a b : ℝ) (hab : a≤b) (hτ : ∀i∈s,a≤τ i∧τ i≤b)
    (hcell : ∀i∈s,(i:ℝ)≤τ i∧τ i≤(i:ℝ)+1)
    (S : Finset ℕ) (j : ℕ) (hprime : ∀p∈S,p.Prime) (B : ℕ)
    (hBpos : 1≤B) (hB : ∀p∈S,p≤B) (Pscale : ℝ) (hP : 0<Pscale)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (ξ ε : ℝ) (hε : 0<ε)
    (hex : ∀i∈s,ε≤‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
      Artin.MarkedReplacement.archimedeanPhase (τ i) p.val‖) :
    (s.card:ℝ)≤3*sampleBudget (B^j) a b*
      ((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j)/ε^(2*j) := by
  let f : ℤ→ℝ := fun i=>‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
      Artin.MarkedReplacement.archimedeanPhase (τ i) p.val‖^(2*j)
  let E := sampleBudget (B^j) a b*((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j)
  have hc (r : ℤ) : (∑i∈s.filter (fun i=>i%3=r),f i)≤E := by
    apply separated_normalized_prime_moment _ τ a b hab
      (fun i hi=>hτ i (Finset.mem_filter.mp hi).1)
      (mod_three_samples_separated s τ hcell r) S j hprime B hBpos hB Pscale hP χ ξ
  have hm : ∀i∈s,i%3∈Finset.Icc (0:ℤ) 2 := by
    intro i hi
    simp only [Finset.mem_Icc]
    omega
  have hsum : (∑i∈s,f i)≤3*E := by
    rw [←Finset.sum_fiberwise_of_maps_to hm]
    calc
      _ ≤ ∑r∈Finset.Icc (0:ℤ) 2,E := Finset.sum_le_sum fun r _=>hc r
      _ = 3*E := by norm_num
  have hlo : (s.card:ℝ)*ε^(2*j)≤∑i∈s,f i := by
    calc
      _ = ∑_i∈s,ε^(2*j) := by simp
      _ ≤ _ := Finset.sum_le_sum fun i hi=>pow_le_pow_left₀ hε.le (hex i hi) (2*j)
  apply (le_div_iff₀ (pow_pos hε _)).mpr
  have hh := hlo.trans hsum
  simpa only [E,mul_assoc] using hh

end Elliptic.Operator.SmallPrimePower
