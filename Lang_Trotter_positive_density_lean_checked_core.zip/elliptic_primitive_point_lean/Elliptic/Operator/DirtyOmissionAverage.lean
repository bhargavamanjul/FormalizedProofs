module

public import Elliptic.Operator.DirtyFreshDraws
public import Elliptic.Operator.PhysicalMemoryEdges
public import Mathlib.GroupTheory.Perm.Fin

/-!
# Exact source omission averaging

The two endpoint symmetrizations are actual uniform permutation averages.
This file proves that the source's last-slot omission is exactly uniform:
each omission tuple has the same number of permutations of its retained
slots. Thus the factor M^(-K) in the dirty row is an identity, not an
assumed normalization.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

/-- A permutation is an omitted last-slot value and a permutation of its
remaining slots. -/
def lastSlotPermutationEquiv (J : ℕ) :
    Equiv.Perm (Fin (J+1)) ≃ Fin (J+1) × Equiv.Perm (Fin J) :=
  (Equiv.mulRight (Equiv.swap (0 : Fin (J+1)) (Fin.last J))).trans Equiv.Perm.decomposeFin

theorem lastSlotPermutationEquiv_fst (J : ℕ) (σ : Equiv.Perm (Fin (J+1))) :
    (lastSlotPermutationEquiv J σ).1 = σ (Fin.last J) := by
  have he (τ : Equiv.Perm (Fin (J+1))) : (Equiv.Perm.decomposeFin τ).1 = τ 0 := by
    have h := Equiv.Perm.decomposeFin_symm_apply_zero
      (Equiv.Perm.decomposeFin τ).1 (Equiv.Perm.decomposeFin τ).2
    simpa using h.symm
  simp only [lastSlotPermutationEquiv, Equiv.trans_apply, he]
  simp [Equiv.Perm.mul_apply]

/-- All groupwise source permutations decompose into their actual
omission tuple and the ordered retained-slot permutations. -/
def groupLastSlotPermutationEquiv (I : Type*) (J : ℕ) :
    (I → Equiv.Perm (Fin (J+1))) ≃
      (I → Fin (J+1)) × (I → Equiv.Perm (Fin J)) :=
  (Equiv.piCongrRight (fun _i : I => lastSlotPermutationEquiv J)).trans
    (Equiv.arrowProdEquivProdArrow I (fun _ => Fin (J+1)) (fun _ => Equiv.Perm (Fin J)))

theorem groupLastSlotPermutationEquiv_fst (I : Type*) (J : ℕ)
    (σ : I → Equiv.Perm (Fin (J+1))) :
    (groupLastSlotPermutationEquiv I J σ).1 = fun i => σ i (Fin.last J) := by
  funext i
  exact lastSlotPermutationEquiv_fst J (σ i)

/-- Exact uniform omission averaging from the actual endpoint permutation
average. This also holds when an omission function takes signed values. -/
theorem source_permutation_average_eq_omission_average {I : Type*} [Fintype I] [DecidableEq I]
    (J : ℕ) (f : (I → Fin (J+1)) → ℝ) :
    (∑ σ : I → Equiv.Perm (Fin (J+1)), f (fun i => σ i (Fin.last J))) /
        (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) =
      (∑ o : I → Fin (J+1), f o) / (J+1 : ℝ)^Fintype.card I := by
  classical
  have hsum := Fintype.sum_equiv (groupLastSlotPermutationEquiv I J)
    (fun σ => f (fun i => σ i (Fin.last J))) (fun pair => f pair.1)
    (fun σ => congrArg f (groupLastSlotPermutationEquiv_fst I J σ).symm)
  rw [hsum, Fintype.sum_prod_type]
  simp only [Finset.sum_const, nsmul_eq_mul, ← Finset.mul_sum, Finset.card_univ,
    Fintype.card_fun, Fintype.card_perm, Fintype.card_fin, Nat.cast_pow]
  rw [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one, mul_pow]
  have hf : ((J.factorial : ℝ)^Fintype.card I) ≠ 0 := by positivity
  have hj : ((J : ℝ)+1)^Fintype.card I ≠ 0 := by positivity
  field_simp

/-- Any retained-slot dependence bounded by an omission envelope can be
dropped while preserving the exact uniform omission factor. -/
theorem source_permutation_average_le_omission_average {I : Type*} [Fintype I] [DecidableEq I]
    (J : ℕ) (g : (I → Equiv.Perm (Fin (J+1))) → ℝ)
    (f : (I → Fin (J+1)) → ℝ)
    (h : ∀ σ, g σ ≤ f (fun i => σ i (Fin.last J))) :
    (∑ σ, g σ) / (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) ≤
      (∑ o, f o) / (J+1 : ℝ)^Fintype.card I := by
  rw [← source_permutation_average_eq_omission_average J f]
  apply div_le_div_of_nonneg_right (Finset.sum_le_sum fun σ _ => h σ)
  positivity

/-- The actual two endpoint permutation weights reduce to the same
uniform omission average when the target slots are unrestricted. -/
theorem endpoint_permutation_average_eq_omission_average {I : Type*} [Fintype I] [DecidableEq I]
    (J : ℕ) (f : (I → Fin (J+1)) → ℝ) :
    endpointPermutationWeight I J *
      (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ _τ : I → Equiv.Perm (Fin (J+1)),
        f (fun i => σ i (Fin.last J))) =
      (∑ o : I → Fin (J+1), f o) / (J+1 : ℝ)^Fintype.card I := by
  rw [← source_permutation_average_eq_omission_average J f]
  simp only [Finset.sum_const, nsmul_eq_mul, ← Finset.mul_sum, Finset.card_univ]
  unfold endpointPermutationWeight
  have hc : (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) ≠ 0 := by
    exact_mod_cast (Fintype.card_pos_iff.mpr ⟨fun _ => Equiv.refl _⟩).ne'
  field_simp
  simp only [← Nat.card_eq_fintype_card]

/-- Both actual endpoint permutation averages preserve an omission
upper envelope, including any additional target-position, good-state,
and cutoff restrictions already bounded by that envelope. -/
theorem endpoint_permutation_average_le_omission_average {I : Type*} [Fintype I] [DecidableEq I]
    (J : ℕ) (g : (I → Equiv.Perm (Fin (J+1))) → (I → Equiv.Perm (Fin (J+1))) → ℝ)
    (f : (I → Fin (J+1)) → ℝ)
    (h : ∀ σ τ, g σ τ ≤ f (fun i => σ i (Fin.last J))) :
    endpointPermutationWeight I J * (∑ σ, ∑ τ, g σ τ) ≤
      (∑ o, f o) / (J+1 : ℝ)^Fintype.card I := by
  rw [← endpoint_permutation_average_eq_omission_average J f]
  apply mul_le_mul_of_nonneg_left
  · exact Finset.sum_le_sum fun σ _ => Finset.sum_le_sum fun τ _ => h σ τ
  · unfold endpointPermutationWeight
    positivity

end Elliptic.Operator
