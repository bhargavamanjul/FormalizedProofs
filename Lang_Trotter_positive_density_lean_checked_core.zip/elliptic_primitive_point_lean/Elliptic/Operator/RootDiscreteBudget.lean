module

public import Elliptic.Operator.BonferroniMonomialCount
public import Elliptic.Operator.RootErrorBudget

/-!
# The combined original-record, monomial, and residue enumeration

This counts the actual finite incidence family used in a truncated root
comparison. It does not assume or prove a bound on arbitrary expansion
coefficients. Only a subsequent application with bounded tests can use
the count as an absolute-mass bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootDiscreteBudget
open Filter IntegerRootReplacement BonferroniMonomialCount
open scoped BigOperators

abbrev SourceRecord (K : ℕ) (C L : ℝ) :=
  OriginalPathRecord K (momentMultiplicity L) (momentLength L)
    (rootPositionRadius C L) (rootPrimeCeiling L)

def recordLabels {K : ℕ} {C L : ℝ} (r : SourceRecord K C L) :
    Fin (momentLength L+1) → Fin K → Fin (momentMultiplicity L) → ℕ :=
  fun j i a => (r.2.1 j i a).val

def recordModulus {K : ℕ} {C L : ℝ} (r : SourceRecord K C L)
    (s : Finset ℕ) : ℕ :=
  ∏ p ∈ activePrimeSet (recordLabels r) ∪ s, p

/-- The literal sum of the numbers of residue matrices over selected
original records and retained numerical prime subsets. -/
def incidenceCount {K : ℕ} {C L : ℝ} (records : Finset (SourceRecord K C L))
    (P : Finset ℕ) (T : ℕ) : ℕ :=
  ∑ r ∈ records, ∑ s ∈ truncatedSubsets P T,
    Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r s)))

/-- Literal triples: an original record, a retained monomial prime set,
and a residue matrix for their actual combined modulus. -/
abbrev ResidueIncidence {K : ℕ} {C L : ℝ} (records : Finset (SourceRecord K C L))
    (P : Finset ℕ) (T : ℕ) :=
  (r : records) × (s : truncatedSubsets P T) ×
    Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r.val s.val))

theorem recordLabels_le {K : ℕ} {C L : ℝ} (r : SourceRecord K C L)
    (j : Fin (momentLength L+1)) (i : Fin K) (a : Fin (momentMultiplicity L)) :
    (recordLabels r j i a:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)) := by
  have h := (r.2.1 j i a).isLt
  have hh : recordLabels r j i a ≤ ⌊Real.exp (2*L^(1/5:ℝ))⌋₊ := by
    change (r.2.1 j i a).val ≤ _
    simpa only [rootPrimeCeiling, Nat.lt_add_one_iff] using h
  exact (Nat.le_floor_iff (Real.exp_pos _).le).mp hh

theorem recordModulus_admissible {K : ℕ} {C L : ℝ} (hL : 1 ≤ L)
    (r : SourceRecord K C L) (P s : Finset ℕ) (T : ℕ)
    (hr : ∀ j i a, (recordLabels r j i a).Prime)
    (hP : ∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hs : s ∈ truncatedSubsets P T) (hT : T ≤ ⌈L^(76/100:ℝ)⌉₊) :
    1 ≤ recordModulus r s ∧ Squarefree (recordModulus r s) ∧
      (recordModulus r s:ℝ) ≤ Real.exp ((16*K+4)*L^(98/100:ℝ)) := by
  obtain ⟨hsP, hsT⟩ := mem_truncatedSubsets P T s |>.mp hs
  exact RootErrorBudget.truncated_modulus_admissible K L hL (recordLabels r) s
    hr (fun p hp => (hP p (hsP hp)).1) (recordLabels_le r)
    (fun p hp => (hP p (hsP hp)).2) (hsT.trans hT)

/-- The nested finite count is exactly the cardinality of the literal
triple type. Finiteness of the residue fibers follows from the actual
positive prime modulus; it is not an analytic premise. -/
theorem incidence_card {K : ℕ} {C L : ℝ} (hL : 1 ≤ L)
    (records : Finset (SourceRecord K C L)) (P : Finset ℕ) (T : ℕ)
    (hr : ∀ r ∈ records, ∀ j i a, (recordLabels r j i a).Prime)
    (hP : ∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hT : T ≤ ⌈L^(76/100:ℝ)⌉₊) :
    Nat.card (ResidueIncidence records P T) = incidenceCount records P T := by
  let : ∀ r : records, ∀ s : truncatedSubsets P T,
      Finite (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r.val s.val))) :=
    fun r s => by
      have hS := (recordModulus_admissible hL r.val P s.val T
        (hr r.val r.property) hP s.property hT).1
      let : NeZero (recordModulus r.val s.val) := ⟨by omega⟩
      infer_instance
  simp only [ResidueIncidence, Nat.card_sigma, incidenceCount]
  calc
    _ = ∑ r : records, ∑ s ∈ truncatedSubsets P T,
        Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r.val s))) := by
      apply Finset.sum_congr rfl
      intro r _
      exact Finset.sum_coe_sort (truncatedSubsets P T) (fun s : Finset ℕ =>
        Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r.val s))))
    _ = _ := Finset.sum_coe_sort records (fun r : SourceRecord K C L =>
      ∑ s ∈ truncatedSubsets P T,
        Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r s))))

theorem residue_card_le_exp {K : ℕ} {C L : ℝ} (hL : 1 ≤ L)
    (r : SourceRecord K C L) (P s : Finset ℕ) (T : ℕ)
    (hr : ∀ j i a, (recordLabels r j i a).Prime)
    (hP : ∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hs : s ∈ truncatedSubsets P T) (hT : T ≤ ⌈L^(76/100:ℝ)⌉₊) :
    (Nat.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (recordModulus r s))):ℝ) ≤
      Real.exp ((64*K+16)*L^(98/100:ℝ)) := by
  have hm := recordModulus_admissible hL r P s T hr hP hs hT
  have hb := RootErrorBudget.residue_card_le_exp (recordModulus r s) hm.1 _ hm.2.2
  convert hb using 1
  congr 1
  ring

/-- An exact finite incidence count is bounded by the product of its
three explicitly proved enumeration budgets. -/
theorem incidenceCount_le {K : ℕ} {C L : ℝ} (hL : 1 ≤ L)
    (records : Finset (SourceRecord K C L)) (P : Finset ℕ) (T : ℕ)
    (hr : ∀ r ∈ records, ∀ j i a, (recordLabels r j i a).Prime)
    (hP : ∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hT : T ≤ ⌈L^(76/100:ℝ)⌉₊) :
    (incidenceCount records P T:ℝ) ≤
      (Fintype.card (SourceRecord K C L):ℝ) * ((truncatedSubsets P T).card:ℝ) *
        Real.exp ((64*K+16)*L^(98/100:ℝ)) := by
  have hrec : (records.card:ℝ) ≤ (Fintype.card (SourceRecord K C L):ℝ) := by
    exact_mod_cast Finset.card_le_univ records
  unfold incidenceCount
  push_cast
  calc
    _ ≤ ∑ _r ∈ records, ∑ _s ∈ truncatedSubsets P T,
        Real.exp ((64*K+16)*L^(98/100:ℝ)) := by
      apply Finset.sum_le_sum
      intro r hr'
      apply Finset.sum_le_sum
      intro s hs
      exact residue_card_le_exp hL r P s T (hr r hr') hP hs hT
    _ = (records.card:ℝ)*((truncatedSubsets P T).card:ℝ)*
        Real.exp ((64*K+16)*L^(98/100:ℝ)) := by
      simp only [Finset.sum_const, nsmul_eq_mul]
      ring
    _ ≤ _ := by gcongr

/-- One threshold precedes the selected original records, numerical
prime pool, and degree. The conclusion counts residue incidences, not
unbounded coefficient weights. -/
theorem eventually_incidenceCount_le_exp (K : ℕ) (C : ℝ) (hC : 0 ≤ C) :
    ∀ᶠ L : ℝ in atTop, ∀ records : Finset (SourceRecord K C L),
      ∀ P : Finset ℕ, ∀ T : ℕ,
      (∀ r ∈ records, ∀ j i a, (recordLabels r j i a).Prime) →
      (∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) →
      T ≤ ⌈L^(76/100:ℝ)⌉₊ →
      (incidenceCount records P T:ℝ) ≤ Real.exp ((64*K+27)*L^(98/100:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_originalPathRecord_card_le_source_budget K C hC,
    eventually_truncatedSubsets_card_le_exp] with L hL hrecords hsubsets
  intro records P T hr hP hT
  have hmon := hsubsets P T (fun p hp => (hP p hp).2) hT
  have h73 : L^(73/100:ℝ) ≤ L^(98/100:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hL (by norm_num)
  have h96 : L^(96/100:ℝ) ≤ L^(98/100:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hL (by norm_num)
  calc
    _ ≤ (Fintype.card (SourceRecord K C L):ℝ) * ((truncatedSubsets P T).card:ℝ) *
        Real.exp ((64*K+16)*L^(98/100:ℝ)) := incidenceCount_le hL records P T hr hP hT
    _ ≤ Real.exp (L^(73/100:ℝ))*Real.exp (10*L^(96/100:ℝ))*
        Real.exp ((64*K+16)*L^(98/100:ℝ)) := by gcongr
    _ = Real.exp (L^(73/100:ℝ)+10*L^(96/100:ℝ)+(64*K+16)*L^(98/100:ℝ)) := by
      rw [← Real.exp_add, ← Real.exp_add]
    _ ≤ _ := Real.exp_le_exp.mpr (by nlinarith)

/-- For bounded tests on these literal triples the same count is an
absolute bound. This is not a premise that the full path coefficients
are bounded: that application must establish the displayed norm bound. -/
theorem eventually_bounded_incidence_sum (K : ℕ) (C : ℝ) (hC : 0 ≤ C) :
    ∀ᶠ L : ℝ in atTop, ∀ records : Finset (SourceRecord K C L),
      ∀ P : Finset ℕ, ∀ T : ℕ,
      (∀ r ∈ records, ∀ j i a, (recordLabels r j i a).Prime) →
      (∀ p ∈ P, p.Prime ∧ (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) →
      T ≤ ⌈L^(76/100:ℝ)⌉₊ →
      ∀ [Fintype (ResidueIncidence records P T)],
      ∀ f : ResidueIncidence records P T → ℂ,
      (∀ t, ‖f t‖ ≤ 1) →
      ‖∑ t, f t‖ ≤ Real.exp ((64*K+27)*L^(98/100:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_incidenceCount_le_exp K C hC] with L hL hcount
  intro records P T hr hP hT inst f hf
  have hc := incidence_card hL records P T hr hP hT
  rw [Nat.card_eq_fintype_card] at hc
  calc
    _ ≤ ∑ t, ‖f t‖ := norm_sum_le _ _
    _ ≤ ∑ _t : ResidueIncidence records P T, (1:ℝ) :=
      Finset.sum_le_sum (fun t _ => hf t)
    _ = (incidenceCount records P T:ℝ) := by simp [hc]
    _ ≤ _ := hcount records P T hr hP hT

end Elliptic.Operator.RootDiscreteBudget
