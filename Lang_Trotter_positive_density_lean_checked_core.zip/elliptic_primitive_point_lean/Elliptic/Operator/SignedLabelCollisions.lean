module
public import Elliptic.Operator.SignedDampingAsymptotics

/-! Counting actual selected prime-product labels with a common prime.
Injectivity of the product map retains the reciprocal-square saving. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedLabelCollisions
open scoped BigOperators
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDamping
attribute [local instance] Classical.propDecidable
local instance labelCollisionDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
variable {K : ℕ}

theorem labelProduct_injective (b : Bands K) (x : ℝ)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    Function.Injective (labelProduct b x) := by
  intro a c he
  funext i
  apply Subtype.ext
  apply (band_prime_dvd_labelProduct b x c hdis i (a i).val (a i).property).mp
  rw [←he]
  exact Finset.dvd_prod_of_mem _ (Finset.mem_univ i)

def labelsUpTo (b : Bands K) (x Y : ℝ) : Finset (LabelTuple b x) :=
  Finset.univ.filter (fun a=>(labelProduct b x a:ℝ)≤4*Y)

def multipleLabels (b : Bands K) (x Y : ℝ) (p : ℕ) : Finset (LabelTuple b x) :=
  (labelsUpTo b x Y).filter (fun a=>p∣labelProduct b x a)

theorem multipleLabels_card (b : Bands K) (x Y : ℝ) (hY : 0≤Y)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (p : ℕ) (hp : 0<p) : ((multipleLabels b x Y p).card:ℝ)≤4*Y/p := by
  let f := fun a : LabelTuple b x=>labelProduct b x a/p
  have hinj : Set.InjOn f (multipleLabels b x Y p) := by
    intro a ha c hc he
    apply labelProduct_injective b x hdis
    have h := congrArg (fun n : ℕ=>p*n) he
    dsimp [f] at h
    simpa only [Nat.mul_div_cancel' (Finset.mem_filter.mp ha).2,
      Nat.mul_div_cancel' (Finset.mem_filter.mp hc).2] using h
  have hsub : (multipleLabels b x Y p).image f⊆Finset.Icc 1 ⌊4*Y/(p:ℝ)⌋₊ := by
    intro q hq
    obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp hq
    obtain ⟨hal,hd⟩ := Finset.mem_filter.mp ha
    have hu := (Finset.mem_filter.mp hal).2
    apply Finset.mem_Icc.mpr
    constructor
    · exact Nat.div_pos (Nat.le_of_dvd (labelProduct_pos b x a) hd) hp
    · apply Nat.le_floor
      have he : (f a:ℝ)=(labelProduct b x a:ℝ)/p := by
        exact Nat.cast_div hd (by exact_mod_cast hp.ne')
      rw [he]
      exact div_le_div_of_nonneg_right hu (Nat.cast_nonneg p)
  have hc : (multipleLabels b x Y p).card≤⌊4*Y/(p:ℝ)⌋₊ := by
    calc
      _ = ((multipleLabels b x Y p).image f).card := (Finset.card_image_of_injOn hinj).symm
      _ ≤ (Finset.Icc 1 ⌊4*Y/(p:ℝ)⌋₊).card := Finset.card_le_card hsub
      _ = _ := by simp
  exact (show ((multipleLabels b x Y p).card:ℝ)≤⌊4*Y/(p:ℝ)⌋₊ by exact_mod_cast hc).trans
    (Nat.floor_le (by positivity))

theorem labelsUpTo_card (b : Bands K) (x Y : ℝ) (hY : 0≤Y)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ((labelsUpTo b x Y).card:ℝ)≤4*Y := by
  simpa only [multipleLabels,one_dvd,Finset.filter_true, Nat.cast_one,div_one]
    using multipleLabels_card b x Y hY hdis 1 (by norm_num)

def collisionPairs (b : Bands K) (x Y : ℝ) : Finset (LabelTuple b x×LabelTuple b x) :=
  (labelsUpTo b x Y×ˢlabelsUpTo b x Y).filter
    (fun ab=>¬(labelProduct b x ab.1).Coprime (labelProduct b x ab.2))

theorem collisionPairs_card (b : Bands K) (x Y : ℝ) (hY : 0≤Y)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ((collisionPairs b x Y).card:ℝ)≤16*Y^2*
      ∑i : Fin K,∑p∈b.group x i,(p:ℝ)⁻¹^2 := by
  let Z := fun i : Fin K=>fun p : ℕ=>multipleLabels b x Y p×ˢmultipleLabels b x Y p
  have hsub : collisionPairs b x Y⊆Finset.univ.biUnion
      (fun i : Fin K=>(b.group x i).biUnion (Z i)) := by
    intro ab hab
    obtain ⟨hab,hnc⟩ := Finset.mem_filter.mp hab
    obtain ⟨p,hp,hpa,hpb⟩ := Nat.Prime.not_coprime_iff_dvd.mp hnc
    obtain ⟨i,_,hi⟩ := hp.prime.exists_mem_finset_dvd hpa
    have he : p=(ab.1 i).val := (Nat.prime_dvd_prime_iff_eq hp
      (b.group_prime x (ab.1 i).property)).mp hi
    have hpm : p∈b.group x i := he ▸ (ab.1 i).property
    apply Finset.mem_biUnion.mpr ⟨i,Finset.mem_univ _,?_⟩
    apply Finset.mem_biUnion.mpr ⟨p,hpm,?_⟩
    exact Finset.mem_product.mpr ⟨Finset.mem_filter.mpr ⟨(Finset.mem_product.mp hab).1,hpa⟩,
      Finset.mem_filter.mpr ⟨(Finset.mem_product.mp hab).2,hpb⟩⟩
  have hc := (Finset.card_le_card hsub).trans
    (Finset.card_biUnion_le.trans (Finset.sum_le_sum (fun i _=>Finset.card_biUnion_le)))
  have hcR : ((collisionPairs b x Y).card:ℝ)≤
      ∑i : Fin K,∑p∈b.group x i,((multipleLabels b x Y p).card:ℝ)^2 := by
    simp only [Z,Finset.card_product] at hc
    simp only [pow_two]
    exact_mod_cast hc
  apply hcR.trans
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro p hp
  calc
    _ ≤ (4*Y/(p:ℝ))^2 := pow_le_pow_left₀ (Nat.cast_nonneg _)
      (multipleLabels_card b x Y hY hdis p (b.group_prime x hp).pos) 2
    _ = _ := by simp only [div_eq_mul_inv]; ring

theorem collisionPairs_card_exp (b : Bands K) (x Y : ℝ) (hY : 0≤Y)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) (hL : 1≤Real.log x) :
    ((collisionPairs b x Y).card:ℝ)≤16*Y^2*(8*Real.log 4*K)*
      Real.exp (-((Real.log x)^(1/10:ℝ))) := by
  apply (collisionPairs_card b x Y hY hdis).trans
  have h := mul_le_mul_of_nonneg_left (SignedDampingAsymptotics.band_square_tail b x hL)
    (show 0≤16*Y^2 by positivity)
  simpa only [mul_assoc] using h

end Elliptic.Operator.SignedLabelCollisions
