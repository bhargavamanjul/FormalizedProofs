module
public import Elliptic.Operator.MajorArcScaleEndpointSaving

/-! Removing integer unit-cell bookkeeping from source centered frequency windows. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcCenteredWindow
open Filter MeasureTheory Set
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem eventually_rpow_le_exp (J : ℝ) : ∀ᶠL:ℝ in atTop,L^J≤Real.exp L := by
  have hh := (isLittleO_rpow_exp_atTop J).bound (by norm_num : (0:ℝ)<1)
  filter_upwards [hh,eventually_ge_atTop (0:ℝ)] with L hL hL0
  simpa only [Real.norm_eq_abs,abs_of_nonneg (Real.rpow_nonneg hL0 _),abs_of_pos (Real.exp_pos _),one_mul] using hL

/-- A literal interval about any center of size at most T is covered by one
integer-cell interval in the same cancellation range, at only one log-power cost. -/
 theorem centered_energy_of_cell_bound
    (L X J E : ℝ) (hL : 3≤L) (hX : 1≤X) (hJ : 0≤J)
    (hXmax : X≤Real.exp (2*L)) (hpow : L^(J+1)≤Real.exp L)
    (F : ℝ→ℂ) (hF : Continuous F)
    (hcell : ∀K:ℕ,1≤K→(K:ℝ)≤Real.exp (3*L)→(K:ℝ)≤X*L^(J+1)→∀a:ℝ,
      (∀v∈Icc (a+1) (a+(K:ℝ)+1),|v|≤2*X*L^(J+1))→
      (∫v in Icc (a+1) (a+(K:ℝ)+1),‖F v‖^2)≤E)
    (u : ℝ) (hu : |u|≤X*L^J) :
    (∫v in Icc (u-X*L^J) (u+X*L^J),‖F v‖^2)≤E := by
  have hLp : 0<L := by linarith
  have hJone : 1≤L^J := Real.one_le_rpow (by linarith) hJ
  let T := X*L^J
  have hT : 1≤T := by dsimp [T];nlinarith
  let K : ℕ := ⌈2*T⌉₊
  have hK : 1≤K := Nat.one_le_ceil_iff.mpr (by linarith)
  have hKlo : 2*T≤(K:ℝ) := Nat.le_ceil _
  have hKhi : (K:ℝ)≤3*T := by have := Nat.ceil_lt_add_one (show 0≤2*T by linarith);dsimp [K];linarith
  have hpower : X*L^(J+1)=T*L := by rw [Real.rpow_add hLp,Real.rpow_one];dsimp [T];ring
  have hKprod : (K:ℝ)≤X*L^(J+1) := by rw [hpower];nlinarith
  have hKmax : (K:ℝ)≤Real.exp (3*L) := by
    apply hKprod.trans
    calc
      _ ≤ Real.exp (2*L)*Real.exp L := mul_le_mul hXmax hpow (Real.rpow_nonneg hLp.le _) (Real.exp_pos _).le
      _ = _ := by rw [←Real.exp_add];congr 1;ring
  have hfreq : ∀v∈Icc ((u-T-1)+1) ((u-T-1)+(K:ℝ)+1),|v|≤2*X*L^(J+1) := by
    intro v hv
    rw [mul_assoc 2 X,hpower]
    have hu' := abs_le.mp hu
    change -T≤u ∧ u≤T at hu'
    apply abs_le.mpr
    constructor <;> nlinarith [hv.1,hv.2]
  have hsub : Icc (u-T) (u+T)⊆Icc ((u-T-1)+1) ((u-T-1)+(K:ℝ)+1) := by
    intro v hv
    constructor <;> linarith [hv.1,hv.2]
  have hi : IntegrableOn (fun v=>‖F v‖^2) (Icc ((u-T-1)+1) ((u-T-1)+(K:ℝ)+1)) :=
    (hF.norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  exact (setIntegral_mono_set hi (ae_of_all _ (fun v=>sq_nonneg _)) (ae_of_all _ hsub)).trans
    (hcell K hK hKmax hKprod (u-T-1) hfreq)

end Elliptic.Operator.MajorArcCenteredWindow
