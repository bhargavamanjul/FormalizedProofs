module
public import Elliptic.Operator.ProductDirichletMeanSquare
public import Elliptic.Operator.SignedDivisorProgressionScale

/-! Absolute raw scalar sums from the proved unit-shift divisor estimate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalAbsoluteRaw
open scoped BigOperators ComplexConjugate
open SignedDivisorProgression Filter
attribute [local instance 10000] Classical.propDecidable
local instance rawDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 150000

def cofactorCount (s t : Finset ℕ) (a h : ℕ) : ℝ :=
  ∑m∈s,∑n∈t,if m*n+1=a*h then 1 else 0

theorem cofactorCount_nonneg (s t : Finset ℕ) (a h : ℕ) : 0≤cofactorCount s t a h :=
  Finset.sum_nonneg (fun _ _=>Finset.sum_nonneg (fun _ _=>by split_ifs <;> norm_num))

theorem cofactorCount_le_divisors (s t : Finset ℕ) (a h : ℕ)
    (hs : ∀m∈s,0<m) (hprod : ∀m∈s,∀n∈t,0<m*n) :
    cofactorCount s t a h≤((a*h-1).divisors.card:ℝ) := by
  let F := (s×ˢt).filter (fun p=>p.1*p.2+1=a*h)
  have he : cofactorCount s t a h=(F.card:ℝ) := by
    unfold cofactorCount
    rw [←Finset.sum_product (f:=fun p : ℕ×ℕ=>if p.1*p.2+1=a*h then (1:ℝ) else 0)]
    simp [F]
  rw [he]
  have hinj : Set.InjOn (Prod.fst : ℕ×ℕ→ℕ) (↑F : Set (ℕ×ℕ)) := by
    intro p hp q hq hpq
    have hp' := Finset.mem_filter.mp hp
    have hq' := Finset.mem_filter.mp hq
    apply Prod.ext hpq
    apply Nat.eq_of_mul_eq_mul_left (hs _ (Finset.mem_product.mp hp'.1).1)
    have he : p.1*p.2=q.1*q.2 := Nat.add_right_cancel (hp'.2.trans hq'.2.symm)
    simpa only [hpq] using he
  have hsub : F.image Prod.fst⊆(a*h-1).divisors := by
    intro m hm
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hm
    have hp' := Finset.mem_filter.mp hp
    have hpst := Finset.mem_product.mp hp'.1
    have hpos := hprod _ hpst.1 _ hpst.2
    have he : a*h-1=p.1*p.2 := by rw [←hp'.2,Nat.add_sub_cancel]
    apply Nat.mem_divisors.mpr
    rw [he]
    exact ⟨dvd_mul_right _ _,hpos.ne'⟩
  exact_mod_cast (Finset.card_image_of_injOn hinj).symm.trans_le (Finset.card_le_card hsub)

theorem common_cofactor_indicator_le (s t : Finset ℕ) (a b H m n r q : ℕ) :
    (if ∃h∈Finset.Icc 1 H,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)≤
      ∑h∈Finset.Icc 1 H,(if m*n+1=a*h then (1:ℝ) else 0)*(if r*q+1=b*h then 1 else 0) := by
  split_ifs with he
  · obtain ⟨h,hh,ha,hb⟩ := he
    have hs := Finset.single_le_sum
      (f:=fun h=>(if m*n+1=a*h then (1:ℝ) else 0)*(if r*q+1=b*h then 1 else 0))
      (fun h _=>by positivity) hh
    simpa only [ha,hb,ite_true,one_mul] using hs
  · exact Finset.sum_nonneg (fun h _=>by positivity)

theorem common_cofactor_count_le (s t : Finset ℕ) (a b H : ℕ)
    (hs : ∀m∈s,0<m) (hprod : ∀m∈s,∀n∈t,0<m*n) :
    (∑m∈s,∑n∈t,∑r∈s,∑q∈t,
      if ∃h∈Finset.Icc 1 H,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)≤
      ((∑h∈Finset.Icc 1 H,((a*h-1).divisors.card:ℝ)^2)+
        (∑h∈Finset.Icc 1 H,((b*h-1).divisors.card:ℝ)^2))/2 := by
  calc
    _ ≤ ∑m∈s,∑n∈t,∑r∈s,∑q∈t,∑h∈Finset.Icc 1 H,
        (if m*n+1=a*h then (1:ℝ) else 0)*(if r*q+1=b*h then 1 else 0) := by
      exact Finset.sum_le_sum (fun m _=>Finset.sum_le_sum (fun n _=>
        Finset.sum_le_sum (fun r _=>Finset.sum_le_sum (fun q _=>common_cofactor_indicator_le s t a b H m n r q))))
    _ = ∑h∈Finset.Icc 1 H,cofactorCount s t a h*cofactorCount s t b h := by
      simp_rw [Finset.sum_comm (s:=t) (t:=Finset.Icc 1 H),
        Finset.sum_comm (s:=s) (t:=Finset.Icc 1 H),
        Finset.sum_comm (s:=t) (t:=Finset.Icc 1 H),
        Finset.sum_comm (s:=s) (t:=Finset.Icc 1 H)]
      simp_rw [cofactorCount,Finset.sum_mul,Finset.mul_sum]
    _ ≤ ∑h∈Finset.Icc 1 H,(((a*h-1).divisors.card:ℝ)^2+((b*h-1).divisors.card:ℝ)^2)/2 := by
      apply Finset.sum_le_sum
      intro h hh
      have hp := mul_le_mul (cofactorCount_le_divisors s t a h hs hprod)
        (cofactorCount_le_divisors s t b h hs hprod) (cofactorCount_nonneg s t b h) (Nat.cast_nonneg _)
      nlinarith [sq_nonneg (((a*h-1).divisors.card:ℝ)-((b*h-1).divisors.card:ℝ))]
    _ = _ := by rw [←Finset.sum_div,Finset.sum_add_distrib]

/-- Uniform source-scale common-cofactor count, including pairs with common
prime labels. No coprimality or progression-moment assumption is imposed. -/
theorem eventually_common_cofactor_count (D : ℝ) (hD : 0≤D) :
    ∀ᶠ x : ℝ in atTop,∀(s t : Finset ℕ) (a b : ℕ) (Y : ℝ),
      (∀m∈s,0<m) → (∀m∈s,∀n∈t,0<m*n) →
      0<Y → Y≤a → (a:ℝ)≤4*Y → Y≤b → (b:ℝ)≤4*Y →
      (a:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (b:ℝ)≤Real.exp (D*(Real.log x)^(1/5:ℝ)) →
      (∑m∈s,∑n∈t,∑r∈s,∑q∈t,
        if ∃h∈Finset.Icc 1 ⌊x/Y⌋₊,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0)≤
        32*(x/Y)*(1+Real.log (8*x))^3 := by
  filter_upwards [eventually_predecessor_band D hD] with x hx
  intro s t a b Y hs hpos hY ha ha' hb hb' hau hbu
  have hap : 1≤a := by exact_mod_cast hY.trans_le ha
  have hbp : 1≤b := by exact_mod_cast hY.trans_le hb
  have h₁ := hx a Y hap hY ha ha' hau
  have h₂ := hx b Y hbp hY hb hb' hbu
  exact (common_cofactor_count_le s t a b ⌊x/Y⌋₊ hs hpos).trans (by linarith)

end Elliptic.Operator.SignedPhysicalAbsoluteRaw
