module

public import Elliptic.Operator.GhostSetRealization
public import Elliptic.Operator.EdgeIndexedTransfer
public import Elliptic.Operator.LifespanSchedule
public import Elliptic.Operator.ScheduledGhostStep

/-!
# A scheduled store/promotion step is an actual indexed edge

For an arbitrary ordered representative of a distinct pending prime set,
the prescribed promotion identifies a unique old index.  The actual edge
deletes that index and appends the optional source store.  These identities
include the cutoff and both literal endpoint hit factors.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- The set removed or stored by a one-slot scheduled edge. -/
def optionalPrimeSet {P : Type*} (b : Bool) (p : P) : Finset P :=
  if b then {p} else ∅

@[simp] theorem optionalPrimeSet_card {P : Type*} (b : Bool) (p : P) :
    (optionalPrimeSet b p).card = b.toNat := by
  cases b <;> simp [optionalPrimeSet]

/-- The concrete index for promotion is read from the given ordered
representative; a fresh target remains the literal fresh-prime choice. -/
def scheduledEdgeChoice {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    EdgeGroupChoice m :=
  (store, if h : promote = true then
    Sum.inl ((memoryPrimeSetEquiv A ℓ m hm).symm ⟨target,hp h⟩)
  else Sum.inr target)

@[simp] theorem scheduledEdgeChoice_store {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    (scheduledEdgeChoice A ℓ m hm store promote target hp).1 = store := rfl

theorem memoryPrimeSetEquiv_symm_prime {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (p : A) :
    (m.values ((memoryPrimeSetEquiv A ℓ m hm).symm p)).1 = p.val :=
  congrArg Subtype.val ((memoryPrimeSetEquiv A ℓ m hm).apply_symm_apply p)

@[simp] theorem scheduledEdgeChoice_target {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    edgeTargetPrime m (scheduledEdgeChoice A ℓ m hm store promote target hp) = target := by
  unfold scheduledEdgeChoice edgeTargetPrime
  split_ifs
  · exact memoryPrimeSetEquiv_symm_prime A ℓ m hm _
  · rfl

/-- The selected old index is exactly the deletion set of the scheduled
promotion, independent of the ordering of the pending memory. -/
theorem scheduledEdgeChoice_indices {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    edgePromotedIndices (scheduledEdgeChoice A ℓ m hm store promote target hp) =
      ghostDeletionIndices m (optionalPrimeSet promote target) := by
  classical
  cases promote with
  | false => simp [scheduledEdgeChoice,edgePromotedIndices,optionalPrimeSet,ghostDeletionIndices]
  | true =>
    ext i
    simp only [scheduledEdgeChoice, dite_true, edgePromotedIndices, Finset.mem_singleton,
      mem_ghostDeletionIndices, optionalPrimeSet, ite_true]
    constructor
    · rintro rfl
      exact memoryPrimeSetEquiv_symm_prime A ℓ m hm _
    · intro hi
      apply hm.1
      exact hi.trans (memoryPrimeSetEquiv_symm_prime A ℓ m hm ⟨target,hp rfl⟩).symm

theorem optionalPromotion_subset {P : Type*} (A : Finset P) (promote : Bool)
    (target : P) (hp : promote = true → target ∈ A) :
    optionalPrimeSet promote target ⊆ A := by
  classical
  cases promote <;> simp_all [optionalPrimeSet]

theorem scheduledEdgeChoice_size {P : Type*} [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    edgeGroupOutputSize (scheduledEdgeChoice A ℓ m hm store promote target hp) =
      (A \ optionalPrimeSet promote target).card + store.toNat := by
  unfold edgeGroupOutputSize
  rw [scheduledEdgeChoice_indices, scheduledEdgeChoice_store,
    ghostDeletionIndices_compl_card A _ ℓ m hm (optionalPromotion_subset A promote target hp)]

theorem scheduledEdgeChoice_valid {P : Type*} [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ targetAnchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A)
    (hmatch : promote = true → ℓ target = targetAnchor target)
    (hcut : (A \ optionalPrimeSet promote target).card + store.toNat ≤ B) :
    EdgeGroupChoice.Valid targetAnchor m (scheduledEdgeChoice A ℓ m hm store promote target hp) := by
  refine ⟨?_, (scheduledEdgeChoice_size A ℓ m hm store promote target hp).le.trans hcut⟩
  unfold edgePromotionHits scheduledEdgeChoice
  split_ifs with h
  · change particleHits targetAnchor (m.values _)
    rw [hm.2.2]
    change ℓ _ = targetAnchor _
    rw [memoryPrimeSetEquiv_symm_prime]
    exact hmatch h
  · trivial

/-- Literal output bag equals the scheduled set update.  A source store
is required to be fresh to the old pending set, as in a legal lifespan. -/
theorem scheduledEdgeChoice_output_bag {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ sourceAnchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (source target : P) (hp : promote = true → target ∈ A)
    (hs : store = true → source ∉ A)
    (hmatch : store = true → ℓ source = sourceAnchor source)
    (hc : edgeGroupOutputSize (scheduledEdgeChoice A ℓ m hm store promote target hp) ≤ B) :
    tupleBag (edgeGroupOutput sourceAnchor source m
      (scheduledEdgeChoice A ℓ m hm store promote target hp) hc).values =
      LifespanSchedule.bag ℓ
        ((A \ optionalPrimeSet promote target) ∪ optionalPrimeSet store source) := by
  classical
  rw [edgeGroupOutput_tupleBag, scheduledEdgeChoice_indices, scheduledEdgeChoice_store,
    ghostSet_survivorBag A _ ℓ m hm]
  have hd : Disjoint (A \ optionalPrimeSet promote target) (optionalPrimeSet store source) := by
    cases store <;> simp_all [optionalPrimeSet,Finset.disjoint_singleton_right]
  unfold LifespanSchedule.bag
  rw [Finset.union_val, ← Multiset.add_eq_union_iff_disjoint.mpr
    (Finset.disjoint_val.mpr hd), Multiset.map_add]
  congr 1
  cases store with
  | false => simp [optionalPrimeSet]
  | true =>
    simp only [ite_true, optionalPrimeSet,
      Finset.singleton_val, Multiset.map_singleton]
    congr 1
    exact Sigma.ext rfl (heq_of_eq (hmatch rfl).symm)

/-- Hit counts depend only on the scheduled bag, including its retained
line at each prime. -/
theorem scheduledBag_hit_count {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hm : tupleBag m.values = LifespanSchedule.bag ℓ A) :
    (memoryHits anchor m).card = (A.filter (fun p => ℓ p = anchor p)).card := by
  classical
  have h := survivorBag_hits_card anchor m (∅ : Finset (Fin m.size))
  have he : survivorBag (∅ : Finset (Fin m.size)) m.values = tupleBag m.values := by
    simp [survivorBag_eq_sub, selectedBag]
  rw [he,Finset.sdiff_empty,hm] at h
  rw [← h, LifespanSchedule.bag, Multiset.filter_map, Multiset.card_map]
  rfl

/-- The integration at the target is the actual fresh mass or the actual
promotion factor; it has no extra ordering multiplicity. -/
theorem scheduledEdgeChoice_target_weight {P : Type*} {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V : ℝ) (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A) :
    edgeTargetWeight ν V (scheduledEdgeChoice A ℓ m hm store promote target hp) =
      if promote then V⁻¹ else ν target := by
  unfold scheduledEdgeChoice edgeTargetWeight
  split_ifs <;> rfl

/-- An ordered representative has exactly one choice with the prescribed
store flag, target prime, and fresh/promotion status. -/
theorem scheduledEdgeChoice_unique {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (target : P) (hp : promote = true → target ∈ A)
    (c : EdgeGroupChoice m) (hs : c.1 = store) (ht : edgeTargetPrime m c = target)
    (hpStatus : (match c.2 with | .inl _ => true | .inr _ => false) = promote) :
    c = scheduledEdgeChoice A ℓ m hm store promote target hp := by
  rcases c with ⟨b, c⟩
  change b = store at hs
  subst b
  cases c with
  | inl i =>
    change true = promote at hpStatus
    subst promote
    change (m.values i).1 = target at ht
    apply Prod.ext
    · rfl
    change Sum.inl i = Sum.inl ((memoryPrimeSetEquiv A ℓ m hm).symm ⟨target,hp rfl⟩)
    congr 1
    exact hm.1 (ht.trans (memoryPrimeSetEquiv_symm_prime A ℓ m hm ⟨target,hp rfl⟩).symm)
  | inr p =>
    change false = promote at hpStatus
    subst promote
    change p = target at ht
    subst p
    rfl

/-- Complete coefficient of the actual indexed edge. The two hit counts
are derived from its input and output sets, rather than assumed. -/
theorem scheduledEdgeChoice_weight {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (A : Finset P) (ℓ sourceAnchor targetAnchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (source target : P) (hp : promote = true → target ∈ A)
    (hs : store = true → source ∉ A)
    (hmatch : store = true → ℓ source = sourceAnchor source)
    (hc : edgeGroupOutputSize (scheduledEdgeChoice A ℓ m hm store promote target hp) ≤ B) :
    edgeGroupWeight ν V ρ sourceAnchor targetAnchor source m
      (scheduledEdgeChoice A ℓ m hm store promote target hp) hc =
      ρ ^ (A.filter (fun p => ℓ p = sourceAnchor p)).card *
        (if promote then V⁻¹ else ν target) *
      ρ ^ (((A \ optionalPrimeSet promote target) ∪ optionalPrimeSet store source).filter
        (fun p => ℓ p = targetAnchor p)).card := by
  classical
  have hi := ghostSet_surviving_hits A ∅ ℓ sourceAnchor m hm
  simp [ghostDeletionIndices] at hi
  have ho := scheduledBag_hit_count _ ℓ targetAnchor _
    (scheduledEdgeChoice_output_bag A ℓ sourceAnchor m hm store promote source target hp hs hmatch hc)
  unfold edgeGroupWeight
  rw [hi,ho,scheduledEdgeChoice_target_weight]

/-- The actual output is again a distinct ordered representative, so the
next scheduled step may start from it without choosing a new ordering. -/
theorem scheduledEdgeChoice_output_enumerates {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ sourceAnchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (store promote : Bool) (source target : P) (hp : promote = true → target ∈ A)
    (hs : store = true → source ∉ A)
    (hmatch : store = true → ℓ source = sourceAnchor source)
    (hc : edgeGroupOutputSize (scheduledEdgeChoice A ℓ m hm store promote target hp) ≤ B) :
    MemoryEnumeratesSet
      ((A \ optionalPrimeSet promote target) ∪ optionalPrimeSet store source) ℓ
      (edgeGroupOutput sourceAnchor source m
        (scheduledEdgeChoice A ℓ m hm store promote target hp) hc) :=
  memoryEnumeratesSet_of_bag _ ℓ _
    (scheduledEdgeChoice_output_bag A ℓ sourceAnchor m hm store promote source target hp hs hmatch hc)

/-- At a one-slot lifespan edge the schedule itself provides the legal
promotion and disjoint store. The next scheduled cutoff suffices for
actual indexed validity, and the literal output remains an ordered
representative of the next scheduled set. -/
theorem lifespanSchedule_edge_realizes {P : Type*} [Fintype P]
    {Line : P → Type*} {B N : ℕ}
    (ν : P → ℝ) (V ρ : ℝ) (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ)
    (ℓ sourceAnchor targetAnchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hm : MemoryEnumeratesSet (LifespanSchedule.after S L j) ℓ m)
    (store promote : Bool) (source target : P)
    (hprom : LifespanSchedule.promotions S L j = optionalPrimeSet promote target)
    (hstore : LifespanSchedule.stores S L j = optionalPrimeSet store source)
    (hmatchS : store = true → ℓ source = sourceAnchor source)
    (hmatchT : promote = true → ℓ target = targetAnchor target)
    (hcut : (LifespanSchedule.before S L (j+1)).card ≤ B) :
    ∃ c : EdgeGroupChoice m,
      c.1 = store ∧ edgeTargetPrime m c = target ∧
      ∃ hc : EdgeGroupChoice.Valid targetAnchor m c,
        MemoryEnumeratesSet (LifespanSchedule.before S L (j+1)) ℓ
          (edgeGroupOutput sourceAnchor source m c hc.2) ∧
        edgeGroupWeight ν V ρ sourceAnchor targetAnchor source m c hc.2 =
          ρ ^ ((LifespanSchedule.after S L j).filter (fun p => ℓ p = sourceAnchor p)).card *
            (if promote then V⁻¹ else ν target) *
          ρ ^ ((LifespanSchedule.before S L (j+1)).filter (fun p => ℓ p = targetAnchor p)).card := by
  classical
  have hp : promote = true → target ∈ LifespanSchedule.after S L j := by
    intro ht
    apply LifespanSchedule.promotions_subset_after S L j
    rw [hprom]
    simp [optionalPrimeSet,ht]
  have hs : store = true → source ∉ LifespanSchedule.after S L j := by
    intro ht ha
    have hmS : source ∈ LifespanSchedule.stores S L j := by
      rw [hstore]
      simp [optionalPrimeSet,ht]
    exact Finset.disjoint_left.mp (LifespanSchedule.stores_disjoint_after S L j) hmS ha
  have hstep : (LifespanSchedule.after S L j \ optionalPrimeSet promote target) ∪
      optionalPrimeSet store source = LifespanSchedule.before S L (j+1) := by
    rw [← hprom, ← hstore, ← LifespanSchedule.edge_recurrence]
  have hd : Disjoint (LifespanSchedule.after S L j \ optionalPrimeSet promote target)
      (optionalPrimeSet store source) := by
    rw [← hstore]
    exact (LifespanSchedule.stores_disjoint_after S L j).symm.mono_left Finset.sdiff_subset
  have hcut' : (LifespanSchedule.after S L j \ optionalPrimeSet promote target).card +
      store.toNat ≤ B := by
    rw [← optionalPrimeSet_card store source, ← Finset.card_union_of_disjoint hd, hstep]
    exact hcut
  let c := scheduledEdgeChoice (LifespanSchedule.after S L j) ℓ m hm store promote target hp
  have hc : EdgeGroupChoice.Valid targetAnchor m c :=
    scheduledEdgeChoice_valid _ ℓ targetAnchor m hm store promote target hp hmatchT hcut'
  refine ⟨c,rfl,scheduledEdgeChoice_target _ ℓ m hm store promote target hp,hc,?_,?_⟩
  · simpa only [hstep] using scheduledEdgeChoice_output_enumerates _ ℓ sourceAnchor m hm
      store promote source target hp hs hmatchS hc.2
  · simpa only [hstep] using scheduledEdgeChoice_weight ν V ρ _ ℓ sourceAnchor targetAnchor m hm
      store promote source target hp hs hmatchS hc.2

end Elliptic.Operator
