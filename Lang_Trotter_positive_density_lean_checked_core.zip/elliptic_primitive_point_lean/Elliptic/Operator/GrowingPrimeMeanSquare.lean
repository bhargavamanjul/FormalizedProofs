module

public import Elliptic.Operator.DirichletMeanSquare

/-!
# Actual growing-prime moments on a continuous frequency interval

The coefficient-independent Dirichlet mean square is applied to the
literal arbitrary-degree prime polynomial. Unique factorization supplies
the factorial coefficient estimate; no moment bound is an extra premise.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SmallPrimePower
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance growingPrimeDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable (S : Finset ℕ) (j : ℕ)

theorem powerCoefficient_eq_zero_of_not_mem (c : S→ℂ) {n : ℕ}
    (hn : n∉products S j) : powerCoefficient S j c n=0 := by
  have hf : fiber S j n=∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro a ha
    apply hn
    exact Finset.mem_image.mpr ⟨a,Finset.mem_univ a,(Finset.mem_filter.mp ha).2⟩
  simp [powerCoefficient,hf]

/-- Every product of j primes from S lies in the literal interval [1,B^j]. -/
theorem products_subset_Icc (hprime : ∀p∈S,p.Prime) (B : ℕ) (hB : ∀p∈S,p≤B) :
    products S j⊆Finset.Icc 1 (B^j) := by
  intro n hn
  obtain ⟨a,_,rfl⟩ := Finset.mem_image.mp hn
  apply Finset.mem_Icc.mpr
  constructor
  · exact Nat.succ_le_iff.mpr (Finset.prod_pos fun i _=>(hprime (a i) (a i).property).pos)
  · calc
      tupleProduct S j a ≤ ∏_i : Fin j,B :=
        Finset.prod_le_prod fun i _=>hB (a i) (a i).property
      _ = B^j := by simp

/-- The source power expansion is also the full-interval Dirichlet polynomial. -/
theorem polynomial_power_eq_full (hprime : ∀p∈S,p.Prime) (B : ℕ) (hB : ∀p∈S,p≤B)
    (c : S→ℂ) (t : ℝ) :
    (∑p : S,c p*Artin.MarkedReplacement.archimedeanPhase t p.val)^j =
      DirichletMeanSquare.polynomial (B^j) (powerCoefficient S j c) t := by
  rw [polynomial_power_expansion S j hprime]
  unfold DirichletMeanSquare.polynomial
  apply Finset.sum_subset (products_subset_Icc S j hprime B hB)
  intro n hn hnS
  rw [powerCoefficient_eq_zero_of_not_mem S j c hnS,zero_mul]

/-- Coefficient energy is unchanged by extending by zero to the full interval. -/
theorem full_powerCoefficient_l2 (hprime : ∀p∈S,p.Prime) (B : ℕ) (hB : ∀p∈S,p≤B)
    (c : S→ℂ) :
    (∑n∈Finset.Icc 1 (B^j),‖powerCoefficient S j c n‖^2)≤
      (j.factorial:ℝ)*(∑p : S,‖c p‖^2)^j := by
  have he : (∑n∈products S j,‖powerCoefficient S j c n‖^2)=
      ∑n∈Finset.Icc 1 (B^j),‖powerCoefficient S j c n‖^2 := by
    apply Finset.sum_subset (products_subset_Icc S j hprime B hB)
    intro n hn hnS
    simp [powerCoefficient_eq_zero_of_not_mem S j c hnS]
  rw [←he]
  exact powerCoefficient_l2 S j hprime c

/-- A proved 2j-th moment for the actual prime polynomial, uniformly in j. -/
theorem continuous_prime_moment (hprime : ∀p∈S,p.Prime) (B : ℕ) (hBpos : 1≤B)
    (hB : ∀p∈S,p≤B) (c : S→ℂ) (a b : ℝ) (hab : a≤b) :
    (∫t in a..b,‖∑p : S,c p*Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j))≤
      (b-a+4*(B^j:ℕ)*(1+Real.log (B^j:ℕ)))*
        ((j.factorial:ℝ)*(∑p : S,‖c p‖^2)^j) := by
  have hY : 1≤B^j := one_le_pow₀ hBpos
  have hm := DirichletMeanSquare.continuous_mean_square a b hab (B^j) hY
    (powerCoefficient S j c)
  have he (t : ℝ) : ‖∑p : S,c p*Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j)=
      ‖DirichletMeanSquare.polynomial (B^j) (powerCoefficient S j c) t‖^2 := by
    rw [←polynomial_power_eq_full S j hprime B hB, norm_pow,←pow_mul]
    congr 1
    omega
  simp_rw [he]
  apply hm.trans
  apply mul_le_mul_of_nonneg_left (full_powerCoefficient_l2 S j hprime B hB c)
  have hlog : 0≤Real.log (B^j:ℕ) := Real.log_nonneg (by exact_mod_cast hY)
  positivity

/-- The normalized source small-prime moment is uniform in every real shift ξ. -/
theorem continuous_normalized_prime_moment (hprime : ∀p∈S,p.Prime) (B : ℕ)
    (hBpos : 1≤B) (hB : ∀p∈S,p≤B) (Pscale : ℝ) (hP : 0<Pscale)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (ξ a b : ℝ) (hab : a≤b) :
    (∫t in a..b,‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
      Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j))≤
      (b-a+4*(B^j:ℕ)*(1+Real.log (B^j:ℕ)))*
        ((j.factorial:ℝ)*((S.card:ℝ)/Pscale^2)^j) := by
  have hY : 1≤B^j := one_le_pow₀ hBpos
  have hm := DirichletMeanSquare.continuous_mean_square a b hab (B^j) hY
    (powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ))
  have he (t : ℝ) : ‖∑p : S,normalizedPrimeCoefficient S Pscale χ ξ p*
        Artin.MarkedReplacement.archimedeanPhase t p.val‖^(2*j)=
      ‖DirichletMeanSquare.polynomial (B^j)
        (powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ)) t‖^2 := by
    rw [←polynomial_power_eq_full S j hprime B hB,norm_pow,←pow_mul]
    congr 1
    omega
  simp_rw [he]
  apply hm.trans
  apply mul_le_mul_of_nonneg_left _ (by
    have hlog : 0≤Real.log (B^j:ℕ) := Real.log_nonneg (by exact_mod_cast hY)
    positivity)
  have hec : (∑n∈products S j,‖powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ) n‖^2)=
      ∑n∈Finset.Icc 1 (B^j),‖powerCoefficient S j (normalizedPrimeCoefficient S Pscale χ ξ) n‖^2 := by
    apply Finset.sum_subset (products_subset_Icc S j hprime B hB)
    intro n hn hnS
    simp [powerCoefficient_eq_zero_of_not_mem S j _ hnS]
  rw [←hec]
  exact normalizedPrimeCoefficient_power_l2 S j hprime Pscale hP χ ξ

end Elliptic.Operator.SmallPrimePower
