module

public import Elliptic.Operator.BirthRankCounting
public import Elliptic.Operator.MomentWord
public import Mathlib.Analysis.SpecificLimits.Basic

/-!
# Exact high- and low-rank summation for the memory word

The sums here are the actual finite rank sums in the permutation expansion
of global birth distinctness.  They combine the atom saving on high ranks
and the signed word bound on low ranks.  Neither of those bounds is imported
as a source moment theorem: their concrete operator hypotheses remain to be
discharged by the memory realization.
-/

@[expose] public section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- The geometric high-rank tail for any finite set of ranks. -/
theorem finite_geometric_tail_le (ranks : Finset ℕ) (r₀ : ℕ) (z : ℝ)
    (hz : 0 ≤ z) (hz1 : z < 1) (hranks : ∀ r ∈ ranks, r₀ ≤ r) :
    (∑ r ∈ ranks, z ^ r) ≤ z ^ r₀ / (1-z) := by
  classical
  have hinj : Set.InjOn (fun r : ℕ => r-r₀) (ranks : Set ℕ) := by
    intro r hr u hu heq
    have hr' := hranks r hr
    have hu' := hranks u hu
    dsimp only at heq
    omega
  have hshift : (∑ r ∈ ranks, z ^ r) =
      z ^ r₀ * ∑ n ∈ ranks.image (fun r => r-r₀), z ^ n := by
    rw [Finset.sum_image hinj, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro r hr
    rw [← pow_add, Nat.add_sub_of_le (hranks r hr)]
  rw [hshift]
  calc
    _ ≤ z ^ r₀ * ∑' n : ℕ, z ^ n :=
      mul_le_mul_of_nonneg_left
        ((summable_geometric_of_lt_one hz hz1).sum_le_tsum _ (fun _ _ => pow_nonneg hz _))
        (pow_nonneg hz _)
    _ = _ := by rw [tsum_geometric_of_lt_one hz hz1]; rfl

/-- Summation of the actual high-rank complex contributions. -/
theorem high_rank_sum_bound (ranks : Finset ℕ) (r₀ : ℕ)
    (term : ℕ → ℂ) (H Q Δ : ℝ) (hH : 0 ≤ H) (_hQ : 0 ≤ Q) (hΔ : 0 ≤ Δ)
    (hsmall : Q^2*Δ < 1) (hranks : ∀ r ∈ ranks, r₀ ≤ r)
    (hterm : ∀ r ∈ ranks, ‖term r‖ ≤ Q^(2*r) * (H*Δ^r)) :
    ‖∑ r ∈ ranks, term r‖ ≤ H * ((Q^2*Δ)^r₀ / (1-Q^2*Δ)) := by
  calc
    _ ≤ ∑ r ∈ ranks, ‖term r‖ := norm_sum_le _ _
    _ ≤ ∑ r ∈ ranks, Q^(2*r) * (H*Δ^r) := Finset.sum_le_sum hterm
    _ = H * ∑ r ∈ ranks, (Q^2*Δ)^r := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro r hr
      rw [mul_pow, ← pow_mul]
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (finite_geometric_tail_le ranks r₀ (Q^2*Δ) (mul_nonneg (sq_nonneg _) hΔ)
        hsmall hranks) hH

/-- The rank-dependent penalty after counting all permutations of a rank. -/
noncomputable def rankPenalty (N r : ℕ) (good bad Q : ℝ) : ℝ :=
  good ^ (N-2*r) * (Q*bad) ^ (2*r)

theorem rankPenalty_mono {N r u : ℕ} (good bad Q : ℝ)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hQbad : 1 ≤ Q*bad) (hru : r ≤ u) :
    rankPenalty N r good bad Q ≤ rankPenalty N u good bad Q := by
  have htwice : 2*r ≤ 2*u := Nat.mul_le_mul_left 2 hru
  exact mul_le_mul
    (pow_le_pow_of_le_one hgood hgood1 (Nat.sub_le_sub_left htwice N))
    (pow_le_pow_right₀ hQbad htwice) (pow_nonneg (by linarith) _)
    (pow_nonneg hgood _)

/-- The low-rank contribution with the source's actual exponent loss,
without a hidden constant depending on the number of permutations. -/
theorem low_rank_sum_bound (ranks : Finset ℕ) (N r₀ : ℕ)
    (term : ℕ → ℂ) (H good bad Q : ℝ) (hH : 0 ≤ H)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hQbad : 1 ≤ Q*bad)
    (hranks : ∀ r ∈ ranks, r < r₀)
    (hterm : ∀ r ∈ ranks, ‖term r‖ ≤
      Q^(2*r) * (H * good^(N-2*r) * bad^(2*r))) :
    ‖∑ r ∈ ranks, term r‖ ≤ (r₀ : ℝ) * H * rankPenalty N r₀ good bad Q := by
  have hcard : ranks.card ≤ r₀ := by
    simpa only [Finset.card_range] using
      (Finset.card_le_card (show ranks ⊆ Finset.range r₀ from
        fun r hr => Finset.mem_range.mpr (hranks r hr)))
  have hbound : ∀ r ∈ ranks, ‖term r‖ ≤ H * rankPenalty N r₀ good bad Q := by
    intro r hr
    calc
      _ ≤ Q^(2*r) * (H * good^(N-2*r) * bad^(2*r)) := hterm r hr
      _ = H * rankPenalty N r good bad Q := by
        unfold rankPenalty
        rw [mul_pow]
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_left
        (rankPenalty_mono good bad Q hgood hgood1 hQbad (hranks r hr).le) hH
  calc
    _ ≤ ∑ r ∈ ranks, ‖term r‖ := norm_sum_le _ _
    _ ≤ ∑ _r ∈ ranks, H * rankPenalty N r₀ good bad Q := Finset.sum_le_sum hbound
    _ = (ranks.card : ℝ) * (H * rankPenalty N r₀ good bad Q) := by simp
    _ ≤ (r₀ : ℝ) * (H * rankPenalty N r₀ good bad Q) :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hcard)
        (mul_nonneg hH (mul_nonneg (pow_nonneg hgood _)
          (pow_nonneg (by linarith) _)))
    _ = _ := by ring

/-- The two rank regimes combined on the actual signed permutation sum.
The displayed per-permutation hypotheses are the remaining concrete
operator estimates, not an imported moment or signed source criterion. -/
theorem signed_permutation_moment_bound {α : Type*} [Fintype α] [DecidableEq α]
    (term : Equiv.Perm α → ℂ) (N r₀ : ℕ)
    (Hlow Hhigh good bad Δ : ℝ)
    (hHlow : 0 ≤ Hlow) (hHhigh : 0 ≤ Hhigh)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hbad : 0 ≤ bad)
    (hQbad : 1 ≤ (Fintype.card α : ℝ)*bad) (hΔ : 0 ≤ Δ)
    (hsmall : (Fintype.card α : ℝ)^2*Δ < 1)
    (hlow : ∀ σ, birthCycleRank σ < r₀ → ‖term σ‖ ≤
      Hlow * good^(N-2*birthCycleRank σ) * bad^(2*birthCycleRank σ))
    (hhigh : ∀ σ, r₀ ≤ birthCycleRank σ → ‖term σ‖ ≤ Hhigh*Δ^birthCycleRank σ) :
    ‖∑ σ : Equiv.Perm α, (permutationSign σ : ℂ)*term σ‖ ≤
      (r₀ : ℝ)*Hlow*rankPenalty N r₀ good bad (Fintype.card α) +
      Hhigh*((((Fintype.card α : ℝ)^2*Δ)^r₀)/(1-(Fintype.card α : ℝ)^2*Δ)) := by
  classical
  let ranks := Finset.range (Fintype.card α+1)
  let rankTerm := fun r => ∑ σ ∈ birthRankPermutations α r,
    (permutationSign σ : ℂ)*term σ
  have hlo : ‖∑ r ∈ ranks.filter (fun r => r < r₀), rankTerm r‖ ≤
      (r₀ : ℝ)*Hlow*rankPenalty N r₀ good bad (Fintype.card α) := by
    apply low_rank_sum_bound _ N r₀ rankTerm Hlow good bad (Fintype.card α)
      hHlow hgood hgood1 hQbad
    · exact fun r hr => (Finset.mem_filter.mp hr).2
    · intro r hr
      apply norm_birthRank_contribution_le r term
        (mul_nonneg (mul_nonneg hHlow (pow_nonneg hgood _)) (pow_nonneg hbad _))
      intro σ hσ
      simpa only [hσ] using hlow σ (hσ ▸ (Finset.mem_filter.mp hr).2)
  have hhi : ‖∑ r ∈ ranks.filter (fun r => ¬r < r₀), rankTerm r‖ ≤
      Hhigh*((((Fintype.card α : ℝ)^2*Δ)^r₀)/(1-(Fintype.card α : ℝ)^2*Δ)) := by
    apply high_rank_sum_bound _ r₀ rankTerm Hhigh (Fintype.card α) Δ
      hHhigh (Nat.cast_nonneg _) hΔ hsmall
    · exact fun r hr => Nat.le_of_not_gt (Finset.mem_filter.mp hr).2
    · intro r hr
      apply norm_birthRank_contribution_le r term (mul_nonneg hHhigh (pow_nonneg hΔ _))
      intro σ hσ
      simpa only [hσ] using hhigh σ (hσ ▸ Nat.le_of_not_gt (Finset.mem_filter.mp hr).2)
  rw [signed_permutation_sum_by_birthRank]
  change ‖∑ r ∈ ranks, rankTerm r‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not ranks (fun r => r < r₀) rankTerm]
  exact (norm_add_le _ _).trans (add_le_add hlo hhi)

/-- The same bound on the literal finite distinct-birth history sum. -/
theorem distinct_history_moment_bound {α β H : Type*}
    [Fintype α] [DecidableEq α] (histories : Finset H)
    (birth : H → α → Option β) (weight : H → ℂ) (N r₀ : ℕ)
    (Hlow Hhigh good bad Δ : ℝ)
    (hHlow : 0 ≤ Hlow) (hHhigh : 0 ≤ Hhigh)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hbad : 0 ≤ bad)
    (hQbad : 1 ≤ (Fintype.card α : ℝ)*bad) (hΔ : 0 ≤ Δ)
    (hsmall : (Fintype.card α : ℝ)^2*Δ < 1)
    (hlow : ∀ σ, birthCycleRank σ < r₀ →
      ‖∑ h ∈ histories, if BirthPreserving (birth h) σ then weight h else 0‖ ≤
        Hlow * good^(N-2*birthCycleRank σ) * bad^(2*birthCycleRank σ))
    (hhigh : ∀ σ, r₀ ≤ birthCycleRank σ →
      ‖∑ h ∈ histories, if BirthPreserving (birth h) σ then weight h else 0‖ ≤
        Hhigh*Δ^birthCycleRank σ) :
    ‖∑ h ∈ histories, if BirthsDistinct (birth h) then weight h else 0‖ ≤
      (r₀ : ℝ)*Hlow*rankPenalty N r₀ good bad (Fintype.card α) +
      Hhigh*((((Fintype.card α : ℝ)^2*Δ)^r₀)/(1-(Fintype.card α : ℝ)^2*Δ)) := by
  classical
  rw [weighted_birth_distinctness_expansion]
  exact signed_permutation_moment_bound _ N r₀ Hlow Hhigh good bad Δ hHlow hHhigh
    hgood hgood1 hbad hQbad hΔ hsmall hlow hhigh

end Elliptic.Operator
