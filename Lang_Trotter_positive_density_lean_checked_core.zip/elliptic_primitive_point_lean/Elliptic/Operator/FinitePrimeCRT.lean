module

public import Elliptic.Operator.SignedBonferroniTransfer
public import Elliptic.Operator.ProjectiveCoordinates

/-!
# Concrete CRT lines for finite sets of numerical primes

The modulus is literally the finite-set product used by root records.
The prime coordinate is direct matrix reduction, so integer-root coherence
holds for every subset without a further hypothesis.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.FinitePrimeCRT
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

variable (S : Finset ℕ) (hprime : ∀p∈S,p.Prime)

include hprime in
/-- Distinct elements of a finite prime set are pairwise coprime. -/
theorem pairwise_coprime : Pairwise (fun p q : S=>p.val.Coprime q.val) := by
  intro p q hne
  exact (Nat.coprime_primes (hprime p p.property) (hprime q q.property)).mpr
    (fun h=>hne (Subtype.ext h))

/-- Direct line reduction from any modulus divisible by the prime set. -/
def residueLinesModulus (m : ℕ) (hdiv : ∀p∈S,p∣m)
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod m)) (p : S) : Option (ZMod p.val) :=
  letI : Fact p.val.Prime := ⟨hprime p p.property⟩
  RootResidues.projectiveLineEquivOption (ZMod p.val)
    (RootResidues.kernelLine (ZMod p.val)
      (Matrix.SpecialLinearGroup.map (ZMod.castHom (hdiv p p.property) (ZMod p.val)) g))

/-- Literal optional projective-line coordinates of a root residue matrix. -/
def residueLines (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏p∈S,p)))
    (p : S) : Option (ZMod p.val) :=
  residueLinesModulus S hprime (∏p∈S,p)
    (fun p hp=>Finset.dvd_prod_of_mem (fun p : ℕ=>p) hp) g p

/-- The same integral root yields the same local line in every subset modulus. -/
theorem residueLines_map_int (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (p : S) :
    residueLines S hprime (Matrix.SpecialLinearGroup.map
      (Int.castRingHom (ZMod (∏p∈S,p))) g) p =
      (letI : Fact p.val.Prime := ⟨hprime p p.property⟩
       RootResidues.projectiveLineEquivOption (ZMod p.val)
         (RootResidues.kernelLine (ZMod p.val)
           (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod p.val)) g))) := by
  unfold residueLines residueLinesModulus
  congr 2
  ext a b
  change ZMod.castHom (Finset.dvd_prod_of_mem (fun p : ℕ=>p) p.property) (ZMod p.val)
    ((g a b:ℤ):ZMod (∏p∈S,p))=(g a b:ZMod p.val)
  simp

/-- One global family of prime lines for an integral root matrix. -/
def integerLines (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (p : ℕ) : Option (ZMod p) :=
  if hp : p.Prime then
    letI : Fact p.Prime := ⟨hp⟩
    RootResidues.projectiveLineEquivOption (ZMod p)
      (RootResidues.kernelLine (ZMod p)
        (Matrix.SpecialLinearGroup.map (Int.castRingHom (ZMod p)) g))
  else none

/-- Every finite subset reads the restriction of the same integer-root lines. -/
theorem residueLines_map_int_global (g : Matrix.SpecialLinearGroup (Fin 2) ℤ) (p : S) :
    residueLines S hprime (Matrix.SpecialLinearGroup.map
      (Int.castRingHom (ZMod (∏p∈S,p))) g) p=integerLines g p.val := by
  rw [residueLines_map_int]
  simp only [integerLines,dif_pos (hprime p p.property)]

/-- Exact CRT averaging, with the modulus equality isolated before
introducing its finite matrix type. -/
theorem residueLinesModulus_average (m : ℕ) (hdiv : ∀p∈S,p∣m)
    (hm : m=∏p : S,p.val) [Fintype (ZMod m)]
    (f : (∀p : S,Option (ZMod p.val))→ℂ) :
    letI : ∀p : S,Fact p.val.Prime := fun p=>⟨hprime p p.property⟩
    (∑g : Matrix.SpecialLinearGroup (Fin 2) (ZMod m),f (residueLinesModulus S hprime m hdiv g)) /
      (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod m)):ℂ) =
      (∑ℓ : ∀p : S,Option (ZMod p.val),f ℓ)/((∏p : S,(p.val+1):ℕ):ℂ) := by
  subst m
  letI : ∀p : S,Fact p.val.Prime := fun p=>⟨hprime p p.property⟩
  have h := RootResidues.crt_kernel_option_average (fun p : S=>p.val)
    (pairwise_coprime S hprime) f
  have hline (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏p : S,p.val))) (p : S) :
      RootResidues.sl2CRT (fun p : S=>p.val) (pairwise_coprime S hprime) g p =
        Matrix.SpecialLinearGroup.map (ZMod.castHom (hdiv p p.property) (ZMod p.val)) g := by
    ext a b
    exact RootResidues.sl2CRT_entry _ _ _ _ _ _
  simp_rw [hline] at h
  unfold residueLinesModulus
  exact h

/-- Exact uniform averaging for the finite-set modulus and an arbitrary
coupled signed test of all its prime lines. -/
theorem residueLines_average [Fintype (ZMod (∏p∈S,p))]
    (f : (∀p : S,Option (ZMod p.val))→ℂ) :
    letI : ∀p : S,Fact p.val.Prime := fun p=>⟨hprime p p.property⟩
    (∑g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏p∈S,p)),f (residueLines S hprime g)) /
      (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏p∈S,p))):ℂ) =
      (∑ℓ : ∀p : S,Option (ZMod p.val),f ℓ)/((∏p∈S,(p+1):ℕ):ℂ) := by
  unfold residueLines
  have h := residueLinesModulus_average S hprime (∏p∈S,p)
      (fun p hp=>Finset.dvd_prod_of_mem (fun p : ℕ=>p) hp)
      (Finset.prod_coe_sort S (fun p : ℕ=>p)).symm f
  rw [Finset.prod_coe_sort S (fun p : ℕ=>p+1)] at h
  exact h

end Elliptic.Operator.FinitePrimeCRT
