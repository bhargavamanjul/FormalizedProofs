module

public import Elliptic.Operator.RootGridPartition
public import Mathlib.MeasureTheory.Integral.Prod
public import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-!
# Lebesgue integration on the literal disjoint root grid

The partition uses precisely the interval endpoint conventions of the
finite root sum. Its actual three-dimensional Lebesgue cell volume is
15/n^3, and its integrals partition the whole normalized root box.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGridMeasure
open SourceRootCount RootArchimedeanGrid RootGridPartition MeasureTheory Set
open scoped BigOperators ENNReal
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

abbrev RootPoint := ℝ × ℝ × ℝ

def intervalSet (a b : ℝ) (n i : ℕ) : Set ℝ := {t | (partCell a b n i).Contains t}

def partSet (n : ℕ) (j : Index) : Set RootPoint := {q | PartContains n j q}

def rootBox : Set RootPoint := {q | InRootBox q}

theorem intervalSet_eq (a b : ℝ) (n i : ℕ) :
    intervalSet a b n i = if i+1=n then
      Icc (cell a b n i).lower (cell a b n i).upper else
      Ico (cell a b n i).lower (cell a b n i).upper := by
  ext t
  by_cases h : i+1=n <;> simp [intervalSet,partCell,RootInterval.Contains,cell,h]

theorem intervalSet_measurable (a b : ℝ) (n i : ℕ) : MeasurableSet (intervalSet a b n i) := by
  rw [intervalSet_eq]
  split_ifs <;> measurability

theorem intervalSet_volume (a b : ℝ) (n i : ℕ) :
    volume (intervalSet a b n i) = ENNReal.ofReal ((b-a)/(n:ℝ)) := by
  rw [intervalSet_eq]
  split_ifs <;> simp only [Real.volume_Icc,Real.volume_Ico]
  all_goals congr 1; dsimp [cell]; ring

theorem partSet_eq (n : ℕ) (j : Index) : partSet n j =
    intervalSet 1 16 n j.1 ×ˢ (intervalSet 1 2 n j.2.1 ×ˢ intervalSet 0 1 n j.2.2) := rfl

theorem partSet_measurable (n : ℕ) (j : Index) : MeasurableSet (partSet n j) := by
  rw [partSet_eq]
  exact (intervalSet_measurable _ _ _ _).prod
    ((intervalSet_measurable _ _ _ _).prod (intervalSet_measurable _ _ _ _))

theorem partSet_volume (n : ℕ) (j : Index) :
    volume (partSet n j) = ENNReal.ofReal (15/(n:ℝ)^3) := by
  rw [partSet_eq,Measure.volume_eq_prod,Measure.prod_prod,
    Measure.volume_eq_prod,Measure.prod_prod]
  rw [intervalSet_volume,intervalSet_volume,intervalSet_volume]
  norm_num only [Nat.cast_ofNat,sub_zero,one_div,show (16:ℝ)-1=15 by norm_num,
    show (2:ℝ)-1=1 by norm_num]
  rw [← ENNReal.ofReal_mul (by positivity),← ENNReal.ofReal_mul (by positivity)]
  congr 1
  ring

theorem partSet_volume_real (n : ℕ) (j : Index) :
    volume.real (partSet n j) = 15/(n:ℝ)^3 := by
  rw [measureReal_def,partSet_volume,ENNReal.toReal_ofReal (by positivity)]

theorem partSet_pairwise (n : ℕ) : Set.Pairwise (↑(grid n) : Set Index) (fun j k => Disjoint (partSet n j) (partSet n k)) := by
  intro j hj k hk hne
  apply Set.disjoint_left.mpr
  intro q hjq hkq
  exact hne (grid_partition_unique n j k hj hk q hjq hkq)

theorem rootBox_union (n : ℕ) (hn : 0<n) : rootBox=⋃j∈grid n, partSet n j := by
  ext q
  constructor
  · intro hq
    obtain ⟨j,hj,hjq⟩ := grid_partition_cover n hn q hq
    exact Set.mem_iUnion.mpr ⟨j,Set.mem_iUnion.mpr ⟨hj,hjq⟩⟩
  · intro hq
    obtain ⟨j,hq'⟩ := Set.mem_iUnion.mp hq
    obtain ⟨hj,hjq⟩ := Set.mem_iUnion.mp hq'
    exact part_inRootBox n j hj q hjq

theorem partSet_subset (n : ℕ) (j : Index) (hj : j∈grid n) : partSet n j⊆rootBox :=
  fun q hq => part_inRootBox n j hj q hq

theorem rootBox_measurable : MeasurableSet rootBox := by
  rw [rootBox_union 1 (by norm_num)]
  exact Finset.measurableSet_biUnion _ fun j _ => partSet_measurable 1 j

/-- Exact integral partition on the same cells as the root sums. -/
theorem integral_partition (n : ℕ) (hn : 0<n) (f : RootPoint → ℂ)
    (hf : IntegrableOn f rootBox) :
    ∫ q in rootBox, f q = ∑j∈grid n, ∫q in partSet n j, f q := by
  rw [rootBox_union n hn]
  exact integral_biUnion_finset (grid n) (fun j _ => partSet_measurable n j)
    (partSet_pairwise n) (fun j hj => hf.mono_set (partSet_subset n j hj))

/-- A bounded unit-norm kernel contributes at most the literal cell
volume, with no integrability premise needed for this upper bound. -/
theorem norm_integral_partSet_le (n : ℕ) (j : Index) (f : RootPoint → ℂ)
    (hf : ∀q∈partSet n j, ‖f q‖≤1) :
    ‖∫q in partSet n j, f q‖ ≤ 15/(n:ℝ)^3 := by
  have h := norm_setIntegral_le_of_norm_le_const
    (show volume (partSet n j)<⊤ by rw [partSet_volume]; exact ENNReal.ofReal_lt_top) hf
  simpa only [one_mul,partSet_volume_real] using h

end Elliptic.Operator.RootGridMeasure
