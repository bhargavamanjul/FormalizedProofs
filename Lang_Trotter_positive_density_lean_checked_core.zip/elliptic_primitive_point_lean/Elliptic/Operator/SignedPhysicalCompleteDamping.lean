module
public import Elliptic.Operator.SignedPhysicalPairEndpoints

/-! Complete position support removes all artificial vertex damping. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open PhysicalVertexDamping SingleEdgePhysicalRestoration SingleEdgeRootIncidence
open Artin.MarkedCriterion
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {K J : ℕ}

theorem vertexWeight_eq_one_of_complete
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (z : ℤ×ℤ) (hz₁ : 0≤z.1) (hz₂ : 0≤z.2)
    (hinc : ∀i j,((a i j).val:ℤ)∣z.1) (S T : Finset ℕ)
    (hrough : ∀m∈S,∀p∈groupPool groups,¬p∣m)
    (hc : completeCounts groups J z.1.toNat ∧
      z.1.toNat/supportedPart (groupPool groups) z.1.toNat∈S ∧ z.2.toNat∈T) (θ : ℝ) :
    vertexWeight (fun i=>fun p : groups i=>p.val) (groupPool groups) θ z a=1 := by
  obtain ⟨m,hm,s,hs,rfl⟩ := endpoint_reconstruct groups hp a hinj z hz₁ hz₂ hinc S T hc
  exact vertexWeight_position_eq_one (fun i=>fun p : groups i=>p.val) (fun i p=>hp i p.val p.property)
    (groupPool groups) (groupPool_prime groups hp) a m s (hrough m hm) θ

theorem completeLeft_vertexWeight_eq_one
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (z : ℤ×ℤ) (hz₁ : 0≤z.1) (hz₂ : 0≤z.2)
    (hinc : ∀i j,((a i j).val:ℤ)∣z.1) (S T : Finset ℕ)
    (hrough : ∀m∈S,∀p∈groupPool groups,¬p∣m)
    (α β : ℕ→ℂ) (hn : completeLeft groups J S T α β z≠0) (θ : ℝ) :
    vertexWeight (fun i=>fun p : groups i=>p.val) (groupPool groups) θ z a=1 := by
  apply vertexWeight_eq_one_of_complete groups hp a hinj z hz₁ hz₂ hinc S T hrough _ θ
  by_contra h
  simp [completeLeft,h] at hn

theorem completeRight_vertexWeight_eq_one
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (a : PhysicalActiveLists (fun i=>groups i) J)
    (hinj : Function.Injective (fun ij : Fin K×Fin (J+1)=>(a ij.1 ij.2).val))
    (z : ℤ×ℤ) (hz₁ : 0≤z.1) (hz₂ : 0≤z.2)
    (hinc : ∀i j,((a i j).val:ℤ)∣z.1) (S T : Finset ℕ)
    (hrough : ∀m∈S,∀p∈groupPool groups,¬p∣m)
    (α β : ℕ→ℂ) (hn : completeRight groups J S T α β z≠0) (θ : ℝ) :
    vertexWeight (fun i=>fun p : groups i=>p.val) (groupPool groups) θ z a=1 := by
  apply vertexWeight_eq_one_of_complete groups hp a hinj z hz₁ hz₂ hinc S T hrough _ θ
  by_contra h
  simp [completeRight,h] at hn

/-- Damping removal for every actual fixed-list physical pairing summand.
The ban, incidence, and physical support hypotheses are recovered from the kernel. -/
theorem damped_physicalKernel_endpoints_eq
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (U V d₀ Y H θ : ℝ) (hU : 0≤U) (hV : 0≤V) (η ψ : ℝ→ℂ) (σ : ℤ)
    (S T : Finset ℕ) (hrough : ∀m∈S,∀p∈groupPool groups,¬p∣m) (α β : ℕ→ℂ)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists (fun i=>groups i) J) :
    completeLeft groups J S T α β z*
      dampedGeometry (fun i=>fun p : groups i=>p.val) (groupPool groups) θ
        (fun z a w b=>physicalKernel (fun i=>fun p : groups i=>p.val) good U V d₀ Y H η ψ σ (z,a) (w,b)) z a w b*
      completeRight groups J S T α β w =
    completeLeft groups J S T α β z*
      physicalKernel (fun i=>fun p : groups i=>p.val) good U V d₀ Y H η ψ σ (z,a) (w,b)*
        completeRight groups J S T α β w := by
  by_cases hl : completeLeft groups J S T α β z=0
  · simp [hl]
  by_cases hr : completeRight groups J S T α β w=0
  · simp [hr]
  by_cases hk : physicalKernel (fun i=>fun p : groups i=>p.val) good U V d₀ Y H η ψ σ (z,a) (w,b)=0
  · simp [dampedGeometry,hk]
  have hinc : physicalIncidence (fun i=>fun p : groups i=>p.val) a b z w := by
    by_contra h
    simp [physicalKernel,h] at hk
  have ha : sourcePhysicalEdgeAllowed (fun i=>fun p : groups i=>p.val) good 1 0 0 U V d₀ z a w b := by
    by_contra h
    simp [physicalKernel,sourcePhysicalEdgeGeometry,h] at hk
  have hz : (0:ℤ)≤z.1 ∧ (0:ℤ)≤z.2 := by
    have hh := ha.1
    simp only [sourcePhysicalPositionAllowed,rootPhysicalPosition,latticeTau,zero_mul,add_zero,one_mul,zero_add,div_one] at hh
    exact ⟨by exact_mod_cast hU.trans hh.2.1,by exact_mod_cast hV.trans hh.2.2.2.1⟩
  have hw : (0:ℤ)≤w.1 ∧ (0:ℤ)≤w.2 := by
    have hh := ha.2.1
    simp only [sourcePhysicalPositionAllowed,rootPhysicalPosition,latticeTau,zero_mul,add_zero,one_mul,zero_add,div_one] at hh
    exact ⟨by exact_mod_cast hU.trans hh.2.1,by exact_mod_cast hV.trans hh.2.2.2.1⟩
  have hban := ha.2.2.2.2.1
  have hlw := completeLeft_vertexWeight_eq_one groups hp a
    (physicalSourceLabels_injective_of_ban (fun i=>fun p : groups i=>p.val) a b hban) z hz.1 hz.2 hinc.1 S T hrough α β hl θ
  have hrw := completeRight_vertexWeight_eq_one groups hp b
    (physicalSourceLabels_injective_of_ban (fun i=>fun p : groups i=>p.val) b a
      (sourceCrossEdgeBan_symm (fun i=>fun p : groups i=>p.val) hban)) w hw.1 hw.2 hinc.2 S T hrough α β hr θ
  simp only [dampedGeometry,hlw,hrw,Complex.ofReal_one,one_mul,mul_one]

/-- Damping removal commutes with the full finite pairing, for arbitrary
finite endpoint sets and any real artificial damping parameter. -/
theorem finitePairing_damping_removal
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (U V d₀ Y H θ : ℝ) (hU : 0≤U) (hV : 0≤V) (η ψ : ℝ→ℂ) (σ : ℤ)
    (S T : Finset ℕ) (hrough : ∀m∈S,∀p∈groupPool groups,¬p∣m) (α β : ℕ→ℂ)
    (E F : Finset (PhysicalEndpoint (fun i=>groups i) J)) :
    Elliptic.SourceContracts.finitePairing E F
      (fun za wb=>dampedGeometry (fun i=>fun p : groups i=>p.val) (groupPool groups) θ
        (fun z a w b=>physicalKernel (fun i=>fun p : groups i=>p.val) good U V d₀ Y H η ψ σ (z,a) (w,b))
        za.1 za.2 wb.1 wb.2)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1) =
    Elliptic.SourceContracts.finitePairing E F
      (physicalKernel (fun i=>fun p : groups i=>p.val) good U V d₀ Y H η ψ σ)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1) := by
  unfold Elliptic.SourceContracts.finitePairing
  apply Finset.sum_congr rfl
  intro za hza
  apply Finset.sum_congr rfl
  intro wb hwb
  exact damped_physicalKernel_endpoints_eq groups hp good U V d₀ Y H θ hU hV η ψ σ S T hrough α β
    za.1 wb.1 za.2 wb.2

end Elliptic.Operator.SignedPhysicalPairBridge
