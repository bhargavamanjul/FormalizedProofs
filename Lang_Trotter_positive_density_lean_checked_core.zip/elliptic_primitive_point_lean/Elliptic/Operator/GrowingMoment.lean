module

public import Elliptic.Operator.MomentBounds

/-!
# Uniform finite moments with the source's literal growing parameters

This is the numerical and combinatorial assembly, conditional on the two
per-permutation estimates for the actual memory word.  Those estimates are
explicit hypotheses, not imported source conclusions or new axioms.

The threshold here is chosen before the address type, the word, and its
coefficients.  Thus the result is uniform in bands and selectors whenever
the concrete operator estimates have the fixed displayed constants.
-/

@[expose] public section
namespace Elliptic.Operator
open Filter
open scoped Topology BigOperators

/-- The exact rank assembly also permits an upper bound on the number of
birth addresses; no padding or unproved identification is needed. -/
theorem signed_permutation_moment_bound_of_card_le {α : Type*}
    [Fintype α] [DecidableEq α] (term : Equiv.Perm α → ℂ) (N r₀ : ℕ)
    (Hlow Hhigh good bad Q Δ : ℝ)
    (hcard : (Fintype.card α : ℝ) ≤ Q)
    (hHlow : 0 ≤ Hlow) (hHhigh : 0 ≤ Hhigh)
    (hgood : 0 ≤ good) (hgood1 : good ≤ 1) (hbad : 0 ≤ bad)
    (hQbad : 1 ≤ Q*bad) (hΔ : 0 ≤ Δ) (hsmall : Q^2*Δ < 1)
    (hlow : ∀ σ, birthCycleRank σ < r₀ → ‖term σ‖ ≤
      Hlow * good^(N-2*birthCycleRank σ) * bad^(2*birthCycleRank σ))
    (hhigh : ∀ σ, r₀ ≤ birthCycleRank σ → ‖term σ‖ ≤ Hhigh*Δ^birthCycleRank σ) :
    ‖∑ σ : Equiv.Perm α, (permutationSign σ : ℂ)*term σ‖ ≤
      (r₀ : ℝ)*Hlow*rankPenalty N r₀ good bad Q +
      Hhigh*((Q^2*Δ)^r₀/(1-Q^2*Δ)) := by
  classical
  have hQ : 0 ≤ Q := (Nat.cast_nonneg _).trans hcard
  let ranks := Finset.range (Fintype.card α+1)
  let rankTerm := fun r => ∑ σ ∈ birthRankPermutations α r,
    (permutationSign σ : ℂ)*term σ
  have hcount (r : ℕ) (B : ℝ) (hB : 0 ≤ B)
      (hb : ∀ σ, birthCycleRank σ = r → ‖term σ‖ ≤ B) :
      ‖rankTerm r‖ ≤ Q^(2*r)*B :=
    (norm_birthRank_contribution_le r term hB hb).trans
      (mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (Nat.cast_nonneg _) hcard _) hB)
  have hlo : ‖∑ r ∈ ranks.filter (fun r => r < r₀), rankTerm r‖ ≤
      (r₀ : ℝ)*Hlow*rankPenalty N r₀ good bad Q := by
    apply low_rank_sum_bound _ N r₀ rankTerm Hlow good bad Q
      hHlow hgood hgood1 hQbad
    · exact fun r hr => (Finset.mem_filter.mp hr).2
    · intro r hr
      apply hcount r _ (by positivity)
      intro σ hσ
      simpa only [hσ] using hlow σ (hσ ▸ (Finset.mem_filter.mp hr).2)
  have hhi : ‖∑ r ∈ ranks.filter (fun r => ¬r < r₀), rankTerm r‖ ≤
      Hhigh*((Q^2*Δ)^r₀/(1-Q^2*Δ)) := by
    apply high_rank_sum_bound _ r₀ rankTerm Hhigh Q Δ
      hHhigh hQ hΔ hsmall
    · exact fun r hr => Nat.le_of_not_gt (Finset.mem_filter.mp hr).2
    · intro r hr
      apply hcount r _ (by positivity)
      intro σ hσ
      simpa only [hσ] using hhigh σ (hσ ▸ Nat.le_of_not_gt (Finset.mem_filter.mp hr).2)
  rw [signed_permutation_sum_by_birthRank]
  change ‖∑ r ∈ ranks, rankTerm r‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not ranks (fun r => r < r₀) rankTerm]
  exact (norm_add_le _ _).trans (add_le_add hlo hhi)

theorem birthAddressBudget_pos {K : ℕ} (hK : 0 < K) (L : ℝ) :
    0 < birthAddressBudget K L := by
  have hM : 0 < momentMultiplicity L := by unfold momentMultiplicity; omega
  have hKM := Nat.mul_pos hK hM
  unfold birthAddressBudget
  omega

universe u

/-- Literal source parameter choices imply every prescribed moment saving
from the two actual per-permutation bounds.  In particular the asymptotic
threshold is independent of the finite address type and the summand. -/
theorem eventually_uniform_permutation_moment (K : ℕ) (hK : 0 < K)
    {C Cg D E : ℝ} (hC : 0 ≤ C) (hCg : 1 ≤ Cg) (hD : 0 ≤ D) (hE : 0 ≤ E) :
    ∀ᶠ L : ℝ in atTop, ∀ (α : Type u) [Fintype α] [DecidableEq α]
      (term : Equiv.Perm α → ℂ), Fintype.card α ≤ birthAddressBudget K L →
      (∀ σ, birthCycleRank σ < rankCutoff (sourceRankConstant C E) L →
        ‖term σ‖ ≤ (Cg^(momentLength L+1)*2) *
          (L^(-sourceContractionExponent E))^(momentLength L-2*birthCycleRank σ) *
          (L^C)^(2*birthCycleRank σ)) →
      (∀ σ, rankCutoff (sourceRankConstant C E) L ≤ birthCycleRank σ →
        ‖term σ‖ ≤ L^(C*((momentLength L : ℝ)+1)) *
          (D*Real.exp (-L^(1/10:ℝ)))^birthCycleRank σ) →
      ‖∑ σ : Equiv.Perm α, (permutationSign σ : ℂ)*term σ‖ ≤
        L^(-E*(momentLength L : ℝ)) := by
  filter_upwards [eventually_sourceMomentMajorant_le K hC hCg hD hE,
    eventually_birth_atom_ratio K hD, eventually_ge_atTop (2:ℝ)] with L hbound hatom hL
  intro α _ _ term hcard hlow hhigh
  have hL1 : 1 ≤ L := by linarith
  have hL0 : 0 ≤ L := by linarith
  have hgood : L^(-sourceContractionExponent E) ≤ 1 := by
    calc
      _ ≤ L^(0:ℝ) := Real.rpow_le_rpow_of_exponent_le hL1
        (by unfold sourceContractionExponent; linarith)
      _ = _ := Real.rpow_zero L
  have hQ : (1:ℝ) ≤ birthAddressBudget K L := by
    exact_mod_cast birthAddressBudget_pos hK L
  have hbad := Real.one_le_rpow hL1 hC
  have hQB : 1 ≤ (birthAddressBudget K L : ℝ)*L^C := by nlinarith
  have h := signed_permutation_moment_bound_of_card_le term (momentLength L)
    (rankCutoff (sourceRankConstant C E) L) (Cg^(momentLength L+1)*2)
    (L^(C*((momentLength L : ℝ)+1))) (L^(-sourceContractionExponent E)) (L^C)
    (birthAddressBudget K L) (D*Real.exp (-L^(1/10:ℝ)))
    (by exact_mod_cast hcard) (by positivity) (by positivity) (by positivity)
    hgood (by positivity) hQB (by positivity) (by linarith [hatom.2]) hlow hhigh
  exact h.trans hbound

end Elliptic.Operator
