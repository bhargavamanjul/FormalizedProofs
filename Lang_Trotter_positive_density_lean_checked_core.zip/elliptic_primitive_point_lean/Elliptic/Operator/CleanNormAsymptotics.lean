module

public import Elliptic.Operator.PhysicalCleanNorm
public import Elliptic.Operator.MomentParameters

/-!
# Uniform logarithmic savings for the proved clean determinant norm

The major-arc exponent is selected from the requested saving before any
fixed group count, mass constant or pad cell varies. The resulting single
threshold is uniform over every balanced box and every admissible Y.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open Filter
open scoped SchwartzMap

/-- Balanced area and the two lower width bounds control each side. -/
theorem balanced_side_div_le (A B : ℕ) (C Y : ℝ) (hY : 0<Y)
    (hB : Y^(1/5:ℝ) ≤ B) (harea : (A:ℝ)*B ≤ C*Y) :
    (A:ℝ)/Y ≤ C/(Y^(1/5:ℝ)) := by
  have hp : 0<Y^(1/5:ℝ) := Real.rpow_pos_of_pos hY _
  apply (div_le_div_iff₀ hY hp).mpr
  exact (mul_le_mul_of_nonneg_left hB (Nat.cast_nonneg A)).trans harea

/-- An explicit envelope with no box or determinant-denominator left.
Only the zeroth and first Fourier moments of the fixed cutoff enter. -/
theorem smoothedDeterminantBudget_le_envelope
    (ψ : 𝓢(ℝ, ℂ)) (A B : ℕ) (C H Y : ℝ)
    (hC : 1≤C) (hH : 1≤H) (hY : 1≤Y)
    (hA : Y^(1/5:ℝ) ≤ A) (hB : Y^(1/5:ℝ) ≤ B)
    (harea : (A:ℝ)*B ≤ C*Y) :
    smoothedDeterminantBudget ψ A B H Y 1 ≤
      (24*cutoffFourierMoment ψ 0*(C+1)+2*cutoffFourierMoment ψ 1*C) *
        (1+Real.log (2*Y)) * (1/H+1/(Y^(1/5:ℝ))) := by
  have hY0 : 0<Y := by linarith
  have hH0 : 0<H := by linarith
  have hC0 : 0≤C := by linarith
  let Q : ℝ := ⌈Y/H⌉₊
  let T : ℝ := 1+Real.log (2*Y)
  let δ : ℝ := Y^(1/5:ℝ)
  have hδ : 0<δ := Real.rpow_pos_of_pos hY0 _
  have hδY : δ≤Y := by
    dsimp [δ]
    exact (Real.rpow_le_rpow_of_exponent_le hY (show (1/5:ℝ)≤1 by norm_num)).trans_eq
      (Real.rpow_one Y)
  have hT : 1≤T := by
    have hlog := Real.log_nonneg (show 1≤2*Y by linarith)
    dsimp [T]
    linarith
  have hQ1 : 1≤Q := by
    have hh := Nat.ceil_pos.mpr (div_pos hY0 hH0)
    dsimp [Q]
    exact_mod_cast hh
  have hQ : Q≤Y/H+1 := (Nat.ceil_lt_add_one (div_nonneg hY0.le hH0.le)).le
  have hQY : Q≤2*Y := by
    have hh : Y/H≤Y := (div_le_self hY0.le hH)
    linarith
  have hlog : 1+Real.log Q≤T := by
    dsimp [T]
    exact add_le_add_right (Real.log_le_log (by linarith) hQY) 1
  have hAY : (A:ℝ)/Y≤C/δ := balanced_side_div_le A B C Y hY0 hB harea
  have hBY : (B:ℝ)/Y≤C/δ := by
    apply balanced_side_div_le B A C Y hY0 hA
    simpa only [mul_comm] using harea
  have hQdiv : Q/Y≤1/H+1/δ := by
    calc
      _ ≤ (Y/H+1)/Y := div_le_div_of_nonneg_right hQ hY0.le
      _ = 1/H+1/Y := by field_simp
      _ ≤ _ := add_le_add_right (one_div_le_one_div_of_le hδ hδY) _
  have harea' : (A:ℝ)*B/(H*Y)≤C/H := by
    apply (div_le_div_iff₀ (mul_pos hH0 hY0) hH0).mpr
    nlinarith
  have hminor : minorDeterminantBudget A B H Y/Y ≤
      24*(C+1)*T*(1/H+1/δ) := by
    have he : minorDeterminantBudget A B H Y/Y =
        12*((A:ℝ)*B/(H*Y)+((A:ℝ)/Y+Q/Y)*(1+Real.log Q)+(B:ℝ)/Y) := by
      dsimp [minorDeterminantBudget,Q]
      ring
    rw [he]
    calc
      _ ≤ 12*(C/H+(C/δ+(1/H+1/δ))*T+C/δ) := by
        gcongr
      _ ≤ _ := by
        have h1 : 0≤1/H := by positivity
        have h2 : 0≤1/δ := by positivity
        have hc := mul_nonneg (show 0≤C by linarith) (show 0≤T-1 by linarith)
        have hx := mul_nonneg hc h1
        have hy := mul_nonneg (show 0≤C*T+C*(T-1)+T by nlinarith) h2
        simp only [div_eq_mul_inv] at *
        nlinarith
  have hf0 := cutoffFourierMoment_nonneg ψ 0
  have hf1 := cutoffFourierMoment_nonneg ψ 1
  have hareaY : (A:ℝ)*B/Y≤C := (div_le_iff₀ hY0).mpr harea
  have he : smoothedDeterminantBudget ψ A B H Y 1 =
      cutoffFourierMoment ψ 0*(minorDeterminantBudget A B H Y/Y)+
      (2/H)*cutoffFourierMoment ψ 1*((A:ℝ)*B/Y) := by
    unfold smoothedDeterminantBudget
    ring
  rw [he]
  calc
    _ ≤ cutoffFourierMoment ψ 0*(24*(C+1)*T*(1/H+1/δ))+
        (2/H)*cutoffFourierMoment ψ 1*C := by gcongr
    _ ≤ _ := by
      change _ ≤ (24*cutoffFourierMoment ψ 0*(C+1)+2*cutoffFourierMoment ψ 1*C)*T*(1/H+1/δ)
      have h1 : 1/H≤T*(1/H+1/δ) := by
        have hnon : 0≤1/δ := by positivity
        have hm := mul_le_mul_of_nonneg_right hT (show 0≤1/H+1/δ by positivity)
        linarith
      have hm := mul_le_mul_of_nonneg_left h1 (show 0≤2*cutoffFourierMoment ψ 1*C by positivity)
      simp only [div_eq_mul_inv] at *
      nlinarith

/-- A single threshold controls every admissible Y and every balanced box.
The major-arc exponent is G+3, independent of every fixed prefactor. -/
theorem eventually_smoothed_clean_saving
    (ψ : 𝓢(ℝ, ℂ)) (C M G : ℝ) (hC : 1≤C) (hM : 0≤M) (hG : 0≤G) :
    ∀ᶠ L : ℝ in atTop, ∀ (Y : ℝ) (A B : ℕ),
      Real.exp (L^(1/10:ℝ)) ≤ Y → Y ≤ Real.exp L →
      Y^(1/5:ℝ) ≤ A → Y^(1/5:ℝ) ≤ B → (A:ℝ)*B ≤ C*Y →
      M*smoothedDeterminantBudget ψ A B (L^(G+3)) Y 1 ≤ L^(-G) := by
  let D : ℝ := M*(24*cutoffFourierMoment ψ 0*(C+1)+2*cutoffFourierMoment ψ 1*C)
  have hD : 0≤D := by
    dsimp [D]
    have := cutoffFourierMoment_nonneg ψ 0
    have := cutoffFourierMoment_nonneg ψ 1
    positivity
  have hdec : Tendsto (fun L : ℝ => 3*D*(L^(-2:ℝ)+
      L^(G+1)*Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)))) atTop (nhds 0) := by
    have hp := tendsto_rpow_neg_atTop (show (0:ℝ)<2 by norm_num)
    have he := tendsto_power_mul_exp_neg_rpow (G+1)
      (show (0:ℝ)<1/5 by norm_num) (show (0:ℝ)<1/10 by norm_num)
    simpa using (hp.add he).const_mul (3*D)
  filter_upwards [eventually_ge_atTop (1:ℝ),
    hdec.eventually_lt_const (show (0:ℝ)<1 by norm_num)] with L hL hsmall
  intro Y A B hYlo hYhi hA hB harea
  have hL0 : 0<L := by linarith
  have hY : 1≤Y := (Real.one_le_exp (by positivity)).trans hYlo
  have hY0 : 0<Y := by linarith
  have hH : 1≤L^(G+3) := Real.one_le_rpow hL (by linarith)
  have hlog : 1+Real.log (2*Y) ≤ 3*L := by
    rw [Real.log_mul (by norm_num : (2:ℝ)≠0) hY0.ne']
    have hylog : Real.log Y≤L := (Real.log_le_iff_le_exp hY0).mpr hYhi
    have htwo : Real.log 2≤1 := by have := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2); norm_num at this ⊢; exact this
    linarith
  have hpow : 1/(Y^(1/5:ℝ)) ≤ Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)) := by
    have hh := Real.rpow_le_rpow_of_nonpos (Real.exp_pos _) hYlo (show (-(1/5):ℝ)≤0 by norm_num)
    rw [Real.rpow_neg (by positivity),Real.rpow_def_of_pos (Real.exp_pos _),Real.log_exp] at hh
    simpa only [one_div,mul_comm] using hh
  have henv := smoothedDeterminantBudget_le_envelope ψ A B C (L^(G+3)) Y hC hH hY hA hB harea
  have hbound : M*smoothedDeterminantBudget ψ A B (L^(G+3)) Y 1 ≤
      D*(3*L)*(1/(L^(G+3))+Real.exp (-(1/5:ℝ)*L^(1/10:ℝ))) := by
    calc
      _ ≤ D*(1+Real.log (2*Y))*(1/(L^(G+3))+1/(Y^(1/5:ℝ))) := by
        have hm := mul_le_mul_of_nonneg_left henv hM
        convert hm using 1 <;> dsimp [D] <;> ring
      _ ≤ _ := by gcongr
  have he : (D*(3*L)*(1/(L^(G+3))+Real.exp (-(1/5:ℝ)*L^(1/10:ℝ))))*L^G =
      3*D*(L^(-2:ℝ)+L^(G+1)*Real.exp (-(1/5:ℝ)*L^(1/10:ℝ))) := by
    have hp : L*(L^(G+3))⁻¹*L^G = L^(-2:ℝ) := by
      rw [← Real.rpow_neg hL0.le]
      nth_rw 1 [← Real.rpow_one L]
      rw [← Real.rpow_add hL0,← Real.rpow_add hL0]
      congr 1
      ring
    have hp' : L*L^G=L^(G+1) := by
      nth_rw 1 [← Real.rpow_one L]
      rw [← Real.rpow_add hL0]
      congr 1
      ring
    calc
      _ = 3*D*(L*(L^(G+3))⁻¹*L^G+(L*L^G)*Real.exp (-(1/5:ℝ)*L^(1/10:ℝ))) := by ring
      _ = _ := by rw [hp,hp']
  apply (mul_le_mul_iff_right₀ (Real.rpow_pos_of_pos hL0 G)).mp
  calc
    L^G*(M*smoothedDeterminantBudget ψ A B (L^(G+3)) Y 1) ≤
        L^G*(D*(3*L)*(1/(L^(G+3))+Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)))) :=
      mul_le_mul_of_nonneg_left hbound (by positivity)
    _ ≤ 1 := by rw [mul_comm,he]; exact hsmall.le
    _ = L^G*L^(-G) := by rw [← Real.rpow_add hL0]; simp

end Elliptic.Operator
