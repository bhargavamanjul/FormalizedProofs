module

public import Elliptic.Operator.PhysicalRootMomentNumeric
public import Elliptic.Operator.OriginalNumericAverage
public import Elliptic.Operator.OriginalBoundaryTail

/-!
# The actual closed-record main term is an independent boundary integral

Both endpoint vectors fix the root position to `(1,0)` and leave the active
lists free. The prime measure is the literal transformed prime measure;
its normalization and the geometric support conditions are proved here.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootIndependentMoment
open scoped BigOperators
open MeasureTheory OriginalLifespanSchedule OriginalPathWeights RootRecordEncoding
open PhysicalRootRecordEncoding PhysicalRootMomentNumeric RootRecordKernel RootRecordComparison
open RootIntegratedBonferroni RootGridMeasure IndependentLineNormalization CanonicalBoundaryAssembly
attribute [local instance] Classical.propDecidable
local instance physicalIndependentDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q B : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

/-- The actual numerical image of the grouped prime alphabet. -/
def primePool (value : ∀i,P i→ℕ) : Finset ℕ :=
  Finset.univ.image (fun s : Sigma P=>value s.1 s.2)

instance primePool_fact (value : ∀i,P i→ℕ) [∀i p,Fact (value i p).Prime]
    (p : primePool value) : Fact p.val.Prime := by
  obtain ⟨s,_,hs⟩ := Finset.mem_image.mp p.property
  exact ⟨hs ▸ (inferInstance : Fact (value s.1 s.2).Prime).out⟩

/-- Root position fixed, all endpoint active lists summed freely. -/
def rootEndpoint : BoundaryIndex (Fin K) ↥(integerPositionBox R) P J→ℂ :=
  fun x=>if x.1.val=(1,0) then 1 else 0

theorem originalGeometry_shared (value : ∀i,P i→ℕ) [∀i p,Fact (value i p).Prime]
    (μ : ∀i,P i→ℝ) (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ)
    (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (q : RootGridMeasure.RootPoint) (j : ℕ) (z w : ↥(integerPositionBox R)) (a b : PhysicalActiveLists P J)
    (h : originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q j z a w b≠0)
    (i : Fin K) (k : Fin J) :
    primeResidueAnchor (value i (a i k.castSucc)) z.val =
      primeResidueAnchor (value i (a i k.castSucc)) w.val :=
  orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint j) value
    (RootLiteralGeometry.sourceGood value μ d₀ Y L exponents q)
    (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y smooth ψ major σ z.val w.val a b h i k

theorem originalGeometry_crossEdgeBan (value : ∀i,P i→ℕ)
    (μ : ∀i,P i→ℝ) (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ)
    (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (q : RootGridMeasure.RootPoint) (j : ℕ) (z w : ↥(integerPositionBox R)) (a b : PhysicalActiveLists P J)
    (h : originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q j z a w b≠0) :
    sourceCrossEdgeBan value a b :=
  orientedSourceEdgeGeometry_nonzero_crossEdgeBan (adjoint j) value
    (RootLiteralGeometry.sourceGood value μ d₀ Y L exponents q)
    (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y smooth ψ major σ z.val w.val a b h

theorem closed_record_sum_eq_paths (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (damping : ℕ→ℝ) (q : RootGridMeasure.RootPoint) :
    (normalization VM J N:ℂ)*
      (∑rec∈closedRecords (J:=J) (N:=N) (R:=R) value hv,
        recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L exponents smooth ψ major σ q *
          fullAverage rec (primePool value) damping) =
    ∑r : FinitePath K J N R P,
      r.boundaryFactor (originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q)
        VM rootEndpoint rootEndpoint *
      (r.independentAverage (fun z i p=>primeResidueAnchor (value i p) z.val) damping:ℂ) := by
  have hi : ∀i,Function.Injective (value i) := fun i a b h=>by
    have hs := hinj (a₁:=⟨i,a⟩) (a₂:=⟨i,b⟩) h
    exact eq_of_heq (Sigma.mk.inj_iff.mp hs).2
  unfold closedRecords
  rw [Finset.sum_image (encode_injective id Function.injective_id value hv hi).injOn]
  rw [closedFinitePaths,Finset.sum_filter,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  dsimp only [primePool]
  rw [OriginalIndependentCRT.fullAverage_encode id value hv hinj]
  rw [boundaryFactor_encode id value hv hi]
  have h0 : OriginalPath.visit (N:=N) 0=0 := Fin.ext (Nat.zero_min _)
  have hN : OriginalPath.visit (N:=N) N=Fin.last N := Fin.ext (Nat.min_self _)
  simp only [rootEndpoint,OriginalPath.positionAt,h0,hN]
  by_cases hfirst : (r.position 0).val=(1,0) <;>
    by_cases hlast : (r.position (Fin.last N)).val=(1,0) <;>
      simp [hfirst,hlast,mul_assoc]

/-- The source transformed mass, with the full set of moment visits. -/
def transformedMass (value : ∀i,P i→ℕ) (VM : Fin K→ℝ) (damping : ℕ→ℝ) (N : ℕ) :
    ∀i,P i→ℝ :=
  fun i p=>transformedPrimeMass (Finset.range (N+1)) damping (VM i) (value i p)

def baselineProduct (value : ∀i,P i→ℕ) (damping : ℕ→ℝ) (N : ℕ) : ℝ :=
  ∏i,∏p,baseline (Finset.range (N+1)) damping ((value i p:ℝ)+1)

/-- Literal independent memory boundary pairing, with root position fixed
at both endpoints and unrestricted endpoint active lists. -/
def independentBoundary (value : ∀i,P i→ℕ) [∀i p,Fact (value i p).Prime]
    (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ) (damping : ℕ→ℝ) (ρ : ℝ)
    (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootGridMeasure.RootPoint) : ℂ :=
  boundaryPairing (J:=J) (B:=B) (transformedMass value VM damping N) VM damping
    (fun j=>1-damping j) ρ (fun z i p=>primeResidueAnchor (value i p) z.val)
    (originalGeometry (R:=R) id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q)
    value N rootEndpoint rootEndpoint

/-- Exact finite independent boundary reconstruction; the local prime-mass
normalization and geometric support conditions are consequences, not inputs. -/
theorem closed_record_sum_eq_boundary (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (hVM : ∀i,VM i≠0) (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (damping : ℕ→ℝ)
    (hdamping : ∀j<N+1,damping j≤1) (hsize : ∀i p,N<value i p)
    (ρ : ℝ) (hρ : ρ≠0) (hN : 0<N) (hB : (∑i,Fintype.card (P i))≤B)
    (q : RootGridMeasure.RootPoint) :
    (normalization VM J N:ℂ)*
      (∑rec∈closedRecords (J:=J) (N:=N) (R:=R) value hv,
        recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L exponents smooth ψ major σ q *
          fullAverage rec (primePool value) damping) =
    (baselineProduct value damping N:ℂ)*
      independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) value μ VM damping ρ
        adjoint U V d₀ Y L exponents smooth ψ major σ q := by
  rw [closed_record_sum_eq_paths value hv hinj]
  have hbase (i : Fin K) (p : P i) :
      ((value i p:ℝ)+1)-∑j∈Finset.range (N+1),damping j≠0 := by
    have hs : (∑j∈Finset.range (N+1),damping j)≤(N+1:ℕ) := by
      calc
        _ ≤ ∑j∈Finset.range (N+1),(1:ℝ) := Finset.sum_le_sum (fun j hj=>hdamping j (Finset.mem_range.mp hj))
        _ = _ := by simp
    have hp : (N:ℝ)<value i p := by exact_mod_cast hsize i p
    push_cast at hs
    linarith
  have he := all_independent_paths_eq_baseline_boundary (J:=J) (N:=N) (B:=B)
    (anchor:=fun z : ↥(integerPositionBox R)=>fun i p=>primeResidueAnchor (value i p) z.val)
    value (transformedMass value VM damping N) VM damping ρ
    (originalGeometry id value μ adjoint U V d₀ Y L exponents smooth ψ major σ q)
    hinj
    (fun j z c w d h i k=>originalGeometry_shared value μ adjoint U V d₀ Y L
      exponents smooth ψ major σ q j z w c d h i k)
    (fun j z c w d h=>originalGeometry_crossEdgeBan value μ adjoint U V d₀ Y L
      exponents smooth ψ major σ q j z w c d h)
    hρ hVM hN
    (fun i p=>by simp only [Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one]; positivity)
    (fun i p=>by simpa only [Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one] using hbase i p)
    (fun i p=>by
      simpa only [transformedMass,Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one] using
        transformedPrimeMass_normalization (Finset.range (N+1)) damping (VM i) (value i p) (hVM i))
    hB (rootEndpoint (J:=J)) rootEndpoint
  simpa only [baselineProduct,independentBoundary,Fintype.card_option,ZMod.card,Nat.cast_add,Nat.cast_one] using he

/-- Finite record integration keeps the exact primitive-root density. -/
theorem integrated_record_sum_eq_integral
    (records : Finset (Record K J N R Q)) (primes : Finset ℕ)
    [∀p : primes,Fact p.val.Prime] (damping : ℕ→ℝ) (U V n : ℝ)
    (G : Record K J N R Q→RootGridMeasure.RootPoint→ℂ)
    (hG : ∀rec∈records,IntegrableOn (G rec) rootBox) :
    (n:ℂ)*(∑rec∈records,integralComplete rec primes damping U V (G rec)) =
      ((U*V/(Real.pi^2/6):ℝ):ℂ)*
        (∫q in rootBox,(n:ℂ)*(∑rec∈records,G rec q*fullAverage rec primes damping)) := by
  rw [integral_const_mul,integral_finsetSum records
    (fun rec hr=>(hG rec hr).mul_const (fullAverage rec primes damping))]
  simp only [integral_mul_const,integralComplete,mul_assoc,←Finset.mul_sum]
  ring

/-- The complete integrated numerical main term is exactly the actual
independent boundary integral. Neither a local normalization identity nor
shared-line/cross-edge support is assumed. -/
theorem integrated_closed_records_eq_boundary
    (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : Function.Injective (fun s : Sigma P=>value s.1 s.2))
    [∀i p,Fact (value i p).Prime] (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ)
    (hVM : ∀i,VM i≠0) (adjoint : ℕ→Bool) (U V d₀ Y L : ℝ) (hd : 0<d₀)
    (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (hsmooth : ∀t,‖smooth t‖≤1) (hψ : ∀t,‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) (damping : ℕ→ℝ)
    (hdamping : ∀j<N+1,damping j≤1) (hsize : ∀i p,N<value i p)
    (ρ : ℝ) (hρ : ρ≠0) (hN : 0<N) (hB : (∑i,Fintype.card (P i))≤B) :
    (normalization VM J N:ℂ)*
      (∑rec∈closedRecords (J:=J) (N:=N) (R:=R) value hv,
        integralComplete rec (primePool value) damping U V
          (recordGeometry rec (fun j=>adjoint j.val) value μ U V d₀ Y L exponents smooth ψ major σ)) =
    ((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping N:ℂ)*
      (∫q in rootBox,independentBoundary (J:=J) (N:=N) (R:=R) (B:=B) value μ VM damping ρ
        adjoint U V d₀ Y L exponents smooth ψ major σ q) := by
  rw [integrated_record_sum_eq_integral _ _ damping U V _ _ (fun rec _=>
    RootArchimedeanTransfer.bounded_measurable_integrable _
      (recordGeometry_measurable rec (fun j=>adjoint j.val) value μ U V d₀ Y L
        exponents smooth ψ major σ)
      (recordGeometry_norm_le_one rec (fun j=>adjoint j.val) value μ U V d₀ Y L hd
        exponents smooth ψ hsmooth hψ major hmajor σ))]
  simp_rw [closed_record_sum_eq_boundary value hv hinj μ VM hVM adjoint U V d₀ Y L
    exponents smooth ψ major σ damping hdamping hsize ρ hρ hN hB]
  rw [integral_const_mul,mul_assoc]

end Elliptic.Operator.PhysicalRootIndependentMoment
