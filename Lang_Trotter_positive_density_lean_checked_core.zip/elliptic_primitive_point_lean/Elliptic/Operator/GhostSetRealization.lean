module

public import Elliptic.Operator.DistinctBirthBatches

/-!
# Realizing finite-set ghost schedules by actual indexed choices

An old memory lists distinct primes with retained lines.  Deleting a
specified subset means deleting the corresponding actual old indices.
Fresh births are literal ordered tuples.  The theorems below derive choice
validity, the exact output bag, and the complete signed ordering-fiber sum.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- A literal old memory enumerates the prime set without repetition and
retains the prescribed line for each prime. -/
def MemoryEnumeratesSet {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) : Prop :=
  Function.Injective (fun i => (m.values i).1) ∧
  (∀ p, p ∈ A ↔ ∃ i, (m.values i).1 = p) ∧
  ∀ i, m.values i = anchorPrime ℓ (m.values i).1

def memoryPrimeSetEquiv {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    Fin m.size ≃ A :=
  Equiv.ofBijective (fun i => ⟨(m.values i).1, (hm.2.1 _).mpr ⟨i,rfl⟩⟩)
    ⟨fun i j h => hm.1 (congrArg Subtype.val h), by
      intro p
      obtain ⟨i,hi⟩ := (hm.2.1 p.val).mp p.property
      exact ⟨i,Subtype.ext hi⟩⟩

theorem memoryEnumeratesSet_size {P : Type*} {Line : P → Type*} {B : ℕ}
    (A : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    m.size = A.card := by
  simpa using Fintype.card_congr (memoryPrimeSetEquiv A ℓ m hm)

/-- The actual indexed deletion associated with a scheduled prime set. -/
def ghostDeletionIndices {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (D : Finset P) :
    Finset (Fin m.size) := by
  classical
  exact Finset.univ.filter (fun i => (m.values i).1 ∈ D)

@[simp] theorem mem_ghostDeletionIndices {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (D : Finset P) (i : Fin m.size) :
    i ∈ ghostDeletionIndices m D ↔ (m.values i).1 ∈ D := by
  simp [ghostDeletionIndices]

def ghostDeletedPrimeEquiv {P : Type*} {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) : (ghostDeletionIndices m D) ≃ D :=
  Equiv.ofBijective
    (fun i => ⟨(m.values i.val).1, (mem_ghostDeletionIndices m D i.val).mp i.property⟩)
    ⟨fun i j h => Subtype.ext (hm.1 (congrArg Subtype.val h)), by
      intro p
      obtain ⟨i,hi⟩ := (hm.2.1 p.val).mp (hD p.property)
      refine ⟨⟨i,(mem_ghostDeletionIndices m D i).mpr ?_⟩,Subtype.ext hi⟩
      simpa only [hi] using p.property⟩

theorem ghostDeletionIndices_card {P : Type*} {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) : (ghostDeletionIndices m D).card = D.card := by
  simpa only [Fintype.card_coe] using Fintype.card_congr (ghostDeletedPrimeEquiv A D ℓ m hm hD)

def ghostSurvivingPrimeEquiv {P : Type*} [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    {i : Fin m.size // i ∉ ghostDeletionIndices m D} ≃ ↥(A \ D) := by
  classical
  refine Equiv.ofBijective
    (fun i => ⟨(m.values i.val).1, Finset.mem_sdiff.mpr
      ⟨(hm.2.1 _).mpr ⟨i.val,rfl⟩,fun h => i.property ((mem_ghostDeletionIndices m D i.val).mpr h)⟩⟩)
    ⟨?_,?_⟩
  · intro i j h
    exact Subtype.ext (hm.1 (congrArg Subtype.val h))
  · intro p
    obtain ⟨i,hi⟩ := (hm.2.1 p.val).mp (Finset.mem_sdiff.mp p.property).1
    refine ⟨⟨i,?_⟩,Subtype.ext hi⟩
    intro h
    exact (Finset.mem_sdiff.mp p.property).2 (hi ▸ (mem_ghostDeletionIndices m D i).mp h)

/-- Surviving old indices give exactly the prescribed prime-set difference. -/
theorem ghostSet_survivorBag {P : Type*} [Fintype P] [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    survivorBag (ghostDeletionIndices m D) m.values = (A \ D).val.map (anchorPrime ℓ) := by
  classical
  rw [← selectedBag_eq_map (A \ D) (anchorPrime ℓ)]
  calc
    _ = ∑ i : {i : Fin m.size // i ∉ ghostDeletionIndices m D},
        ({anchorPrime ℓ (m.values i.val).1} : Multiset (AnchoredParticle P Line)) := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [hm.2.2 i.val]
      rfl
    _ = _ := Equiv.sum_comp (ghostSurvivingPrimeEquiv A D ℓ m hm)
      (fun p : ↥(A \ D) => ({anchorPrime ℓ p.val} : Multiset (AnchoredParticle P Line)))

/-- Matching retained and current anchors on the death set derives the
actual hit condition required by ghost validity. -/
theorem ghostDeletionIndices_subset_hits {P : Type*} {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hmatch : ∀ p ∈ D, ℓ p = anchor p) :
    ghostDeletionIndices m D ⊆ memoryHits anchor m := by
  classical
  intro i hi
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _,?_⟩
  rw [hm.2.2 i]
  exact hmatch _ ((mem_ghostDeletionIndices m D i).mp hi)

theorem ghostDeletionIndices_compl_card {P : Type*} [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) : (ghostDeletionIndices m D)ᶜ.card = (A \ D).card := by
  classical
  rw [Finset.card_compl, Fintype.card_fin, ghostDeletionIndices_card A D ℓ m hm hD]
  rw [memoryEnumeratesSet_size A ℓ m hm, Finset.card_sdiff_of_subset hD]

/-- The exact surviving-hit exponent is a count of scheduled surviving
primes whose retained lines meet the current anchor. -/
theorem ghostSet_surviving_hits {P : Type*} [Fintype P] [DecidableEq P] {Line : P → Type*} {B : ℕ}
    (A D : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m) :
    (memoryHits anchor m \ ghostDeletionIndices m D).card =
      ((A \ D).filter (fun p => ℓ p = anchor p)).card := by
  classical
  rw [← survivorBag_hits_card, ghostSet_survivorBag A D ℓ m hm,
    Multiset.filter_map, Multiset.card_map]
  rfl

/-- Set-level cutoff and line incidence derive literal indexed validity. -/
theorem ghostSetChoice_valid {P : Type*} [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A D T : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) (hmatch : ∀ p ∈ D, ℓ p = anchor p)
    (hT : T.card ≤ B) (hcut : (A \ D).card + T.card ≤ B)
    (x : Fin T.card → P) :
    GhostChoice.Valid anchor m
      (distinctFreshGhostChoice m (ghostDeletionIndices m D) T hT x) := by
  apply distinctFreshGhostChoice_valid
  · exact ghostDeletionIndices_subset_hits A D ℓ anchor m hm hmatch
  · rw [ghostDeletionIndices_compl_card A D ℓ m hm hD]
    exact hcut

theorem anchored_set_map_congr {P : Type*} {Line : P → Type*}
    (T : Finset P) (ℓ anchor : ∀ p, Line p) (hmatch : ∀ p ∈ T, ℓ p = anchor p) :
    T.val.map (anchorPrime anchor) = T.val.map (anchorPrime ℓ) := by
  apply Multiset.map_congr rfl
  intro p hp
  exact Sigma.ext rfl (heq_of_eq (hmatch p hp).symm)

/-- The scheduled finite-set transition agrees with the actual survivor
and fresh-batch multiset, before any choice of fresh order is made. -/
theorem ghostSet_output_bag_sum {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A D T : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hAT : Disjoint A T) (hmatchT : ∀ p ∈ T, ℓ p = anchor p) :
    survivorBag (ghostDeletionIndices m D) m.values + T.val.map (anchorPrime anchor) =
      ((A \ D) ∪ T).val.map (anchorPrime ℓ) := by
  rw [ghostSet_survivorBag A D ℓ m hm, anchored_set_map_congr T ℓ anchor hmatchT,
    Finset.union_val, ← Multiset.add_eq_union_iff_disjoint.mpr
      (Finset.disjoint_val.mpr (hAT.mono_left Finset.sdiff_subset)), Multiset.map_add]

/-- Every actual ordered representative of the distinct fresh set gives
the prescribed next memory bag, with validity already derived above. -/
theorem ghostSet_actual_output_bag {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (A D T : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) (hAT : Disjoint A T)
    (hmatchD : ∀ p ∈ D, ℓ p = anchor p) (hmatchT : ∀ p ∈ T, ℓ p = anchor p)
    (hT : T.card ≤ B) (hcut : (A \ D).card + T.card ≤ B)
    (x : DistinctBirthTuple T) :
    tupleBag (ghostOutput anchor m
      (distinctFreshGhostChoice m (ghostDeletionIndices m D) T hT x.val)
      (ghostSetChoice_valid A D T ℓ anchor m hm hD hmatchD hT hcut x.val)).values =
        ((A \ D) ∪ T).val.map (anchorPrime ℓ) := by
  rw [ghostOutput_tupleBag]
  change survivorBag (ghostDeletionIndices m D) m.values +
    tupleBag (fun i => anchorPrime anchor (x.val i)) = _
  rw [distinctBirthTuple_bag]
  exact ghostSet_output_bag_sum A D T ℓ anchor m hm hAT hmatchT

/-- Exact signed coefficient fiber for a finite-set ghost schedule. The
factorial is canceled by the actual distinct ordering fiber, and the
survival exponent is the count of the remaining prime-line incidences. -/
theorem ghostSet_actual_coefficient_fiber {P : Type*} [Fintype P] [DecidableEq P]
    {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (A D T : Finset P) (ℓ anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hm : MemoryEnumeratesSet A ℓ m)
    (hD : D ⊆ A) (hAT : Disjoint A T)
    (hmatchD : ∀ p ∈ D, ℓ p = anchor p) (hmatchT : ∀ p ∈ T, ℓ p = anchor p)
    (hT : T.card ≤ B) (hcut : (A \ D).card + T.card ≤ B)
    (F : Multiset (AnchoredParticle P Line) → ℂ) :
    (∑ x : DistinctBirthTuple T,
      (ghostChoiceWeight ν V η q ρ anchor m
        (distinctFreshGhostChoice m (ghostDeletionIndices m D) T hT x.val) : ℂ) *
      F (tupleBag (ghostOutput anchor m
        (distinctFreshGhostChoice m (ghostDeletionIndices m D) T hT x.val)
        (ghostSetChoice_valid A D T ℓ anchor m hm hD hmatchD hT hcut x.val)).values)) =
      (((-η/ρ)^D.card * (q/ρ^2)^((A \ D).filter (fun p => ℓ p = anchor p)).card *
        (-η*V/ρ)^T.card : ℝ) : ℂ) *
        (∏ p ∈ T, (ν p : ℂ)) * F (((A \ D) ∪ T).val.map (anchorPrime ℓ)) := by
  have hS := ghostDeletionIndices_subset_hits A D ℓ anchor m hm hmatchD
  have hidx : (ghostDeletionIndices m D)ᶜ.card + T.card ≤ B := by
    rw [ghostDeletionIndices_compl_card A D ℓ m hm hD]
    exact hcut
  have h := distinct_birth_actual_ghost_sum ν V η q ρ anchor m
    (ghostDeletionIndices m D) T hT hS hidx F
  rw [ghostSet_output_bag_sum A D T ℓ anchor m hm hAT hmatchT] at h
  simpa only [ghostDeletionIndices_card A D ℓ m hm hD,
    ghostSet_surviving_hits A D ℓ anchor m hm] using h

end Elliptic.Operator
