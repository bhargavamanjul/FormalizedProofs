module

public import Elliptic.Operator.SmallPrimePower
public import Elliptic.Operator.ExponentialGram
public import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
public import Mathlib.NumberTheory.Harmonic.Bounds
public import Mathlib.Data.Nat.Dist

/-!
# Coefficient-independent continuous Dirichlet-polynomial mean square

The logarithmic phases and interval integrals are literal. The estimate
is derived by expanding the actual Gram kernel, rather than importing a
mean-square hypothesis tailored to the growing prime polynomial.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.DirichletMeanSquare
open scoped BigOperators ComplexConjugate
open MeasureTheory
attribute [local instance] Classical.propDecidable
local instance dirichletMeanDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- An off-diagonal logarithmic phase has a literal endpoint integral bound. -/
theorem phase_integral_norm_le (a b ω : ℝ) (hω : ω≠0) :
    ‖∫t in a..b,Complex.exp (Complex.I*(ω:ℂ)*(t:ℂ))‖≤2/|ω| := by
  rw [integral_exp_mul_complex (mul_ne_zero Complex.I_ne_zero (by exact_mod_cast hω)),norm_div]
  have hn (t : ℝ) : ‖Complex.exp (Complex.I*(ω:ℂ)*(t:ℂ))‖=1 := by
    rw [mul_assoc,←Complex.ofReal_mul]
    exact Complex.norm_exp_I_mul_ofReal _
  calc
    _ ≤ (‖Complex.exp (Complex.I*(ω:ℂ)*(b:ℂ))‖+
      ‖Complex.exp (Complex.I*(ω:ℂ)*(a:ℂ))‖)/‖Complex.I*(ω:ℂ)‖ :=
      div_le_div_of_nonneg_right (norm_sub_le _ _) (norm_nonneg _)
    _ = _ := by rw [hn,hn,norm_mul,Complex.norm_I,one_mul,Complex.norm_real,Real.norm_eq_abs]; norm_num

/-- On [1,Y], the difference of logs is at least the integer gap divided by Y. -/
theorem log_gap_lower (Y m n : ℕ) (hm : 0<m) (hmn : m<n) (hnY : n≤Y) :
    ((n-m:ℕ):ℝ)/(Y:ℝ)≤Real.log (n:ℝ)-Real.log (m:ℝ) := by
  have hm0 : (0:ℝ)<m := by exact_mod_cast hm
  have hn0 : (0:ℝ)<n := by exact_mod_cast (hm.trans hmn)
  have hY0 : (0:ℝ)<Y := hn0.trans_le (by exact_mod_cast hnY)
  have h := Real.one_sub_inv_le_log_of_pos (div_pos hn0 hm0)
  rw [Real.log_div hn0.ne' hm0.ne',inv_div] at h
  have hgap : ((n-m:ℕ):ℝ)=(n:ℝ)-(m:ℝ) := by rw [Nat.cast_sub hmn.le]
  rw [hgap]
  calc
    _ ≤ ((n:ℝ)-(m:ℝ))/(n:ℝ) := by
      apply div_le_div_of_nonneg_left (sub_nonneg.mpr (by exact_mod_cast hmn.le)) hn0
      exact_mod_cast hnY
    _ = 1-(m:ℝ)/(n:ℝ) := by field_simp
    _ ≤ _ := h

/-- At most two integers have a specified positive distance from m. -/
theorem distance_fiber_card (Y m d : ℕ) :
    (((Finset.Icc 1 Y).erase m).filter (fun n=>Nat.dist m n=d)).card≤2 := by
  have hsub : ((Finset.Icc 1 Y).erase m).filter (fun n=>Nat.dist m n=d)⊆{m-d,m+d} := by
    intro n hn
    have hd := (Finset.mem_filter.mp hn).2
    simp only [Finset.mem_insert,Finset.mem_singleton]
    unfold Nat.dist at hd
    omega
  exact (Finset.card_le_card hsub).trans (by simpa using Finset.card_insert_le (m-d) {m+d})

/-- The reciprocal-distance row is bounded by twice the harmonic sum. -/
theorem distance_row_le (Y m : ℕ) (hm : m∈Finset.Icc 1 Y) :
    (∑n∈(Finset.Icc 1 Y).erase m,((Nat.dist m n:ℕ):ℝ)⁻¹)≤
      2*∑d∈Finset.Icc 1 Y,(d:ℝ)⁻¹ := by
  have hmap : ∀n∈(Finset.Icc 1 Y).erase m,Nat.dist m n∈Finset.Icc 1 Y := by
    intro n hn
    have hne := (Finset.mem_erase.mp hn).1
    have hn' := Finset.mem_Icc.mp (Finset.mem_erase.mp hn).2
    have hm' := Finset.mem_Icc.mp hm
    simp only [Finset.mem_Icc]
    unfold Nat.dist
    omega
  rw [←Finset.sum_fiberwise_of_maps_to hmap]
  calc
    _ = ∑d∈Finset.Icc 1 Y,
        ((((Finset.Icc 1 Y).erase m).filter (fun n=>Nat.dist m n=d)).card:ℝ)*(d:ℝ)⁻¹ := by
      apply Finset.sum_congr rfl
      intro d hd
      simp only [Finset.sum_filter]
      calc
        _ = ∑n∈(Finset.Icc 1 Y).erase m,if Nat.dist m n=d then (d:ℝ)⁻¹ else 0 := by
          apply Finset.sum_congr rfl
          intro n _
          split_ifs with h
          · rw [h]
          · rfl
        _ = _ := by rw [←Finset.sum_filter]; simp
    _ ≤ ∑d∈Finset.Icc 1 Y,2*(d:ℝ)⁻¹ := by
      apply Finset.sum_le_sum
      intro d hd
      exact mul_le_mul_of_nonneg_right (by exact_mod_cast distance_fiber_card Y m d) (by positivity)
    _ = _ := (Finset.mul_sum _ _ _).symm

/-- Symmetric form of the logarithmic separation estimate. -/
theorem log_gap_abs_lower (Y m n : ℕ) (hm : 0<m) (hn : 0<n)
    (hmY : m≤Y) (hnY : n≤Y) (hne : m≠n) :
    ((Nat.dist m n:ℕ):ℝ)/(Y:ℝ)≤|Real.log (n:ℝ)-Real.log (m:ℝ)| := by
  rcases lt_or_gt_of_ne hne with hmn|hnm
  · rw [Nat.dist_eq_sub_of_le hmn.le,abs_of_pos (sub_pos.mpr
      (Real.log_lt_log (by exact_mod_cast hm) (by exact_mod_cast hmn)))]
    exact log_gap_lower Y m n hm hmn hnY
  · rw [Nat.dist_eq_sub_of_le_right hnm.le,abs_of_neg (sub_neg.mpr
      (Real.log_lt_log (by exact_mod_cast hn) (by exact_mod_cast hnm))),neg_sub]
    exact log_gap_lower Y n m hn hnm hmY

/-- The actual continuous Gram kernel for logarithmic phases. -/
def gram (a b : ℝ) (m n : ℕ) : ℂ :=
  ∫t in a..b,Complex.exp (Complex.I*((Real.log (n:ℝ)-Real.log (m:ℝ)):ℂ)*(t:ℂ))

theorem gram_diag (a b : ℝ) (m : ℕ) : ‖gram a b m m‖=|b-a| := by
  simp only [gram,sub_self,Complex.ofReal_zero,mul_zero,zero_mul,Complex.exp_zero,intervalIntegral.integral_const,smul_eq_mul,mul_one]
  rw [norm_smul,Real.norm_eq_abs,norm_one,mul_one]

/-- The off-diagonal integral has the sharp reciprocal integer-distance form. -/
theorem gram_offdiag (a b : ℝ) (Y m n : ℕ) (hm : 0<m) (hn : 0<n)
    (hmY : m≤Y) (hnY : n≤Y) (hne : m≠n) :
    ‖gram a b m n‖≤2*(Y:ℝ)*((Nat.dist m n:ℕ):ℝ)⁻¹ := by
  have hY : (0:ℝ)<Y := by exact_mod_cast (hm.trans_le hmY)
  have hd : (0:ℝ)<(Nat.dist m n:ℕ) := by
    exact_mod_cast Nat.pos_of_ne_zero (fun h=>hne (Nat.eq_of_dist_eq_zero h))
  have hg := log_gap_abs_lower Y m n hm hn hmY hnY hne
  have hω : Real.log (n:ℝ)-Real.log (m:ℝ)≠0 := by
    have ha : 0 < |Real.log (n:ℝ)-Real.log (m:ℝ)| := (div_pos hd hY).trans_le hg
    exact abs_pos.mp ha
  calc
    ‖gram a b m n‖ ≤ 2/|Real.log (n:ℝ)-Real.log (m:ℝ)| := by
      unfold gram
      simpa only [Complex.ofReal_sub] using phase_integral_norm_le a b _ hω
    _ ≤ 2/(((Nat.dist m n:ℕ):ℝ)/(Y:ℝ)) :=
      div_le_div_of_nonneg_left (by norm_num) (div_pos hd hY) hg
    _ = 2*(Y:ℝ)*((Nat.dist m n:ℕ):ℝ)⁻¹ := by field_simp

/-- Explicit harmonic row budget, independent of all coefficients. -/
theorem gram_row_le (a b : ℝ) (Y m : ℕ) (hm : m∈Finset.Icc 1 Y) :
    (∑n∈Finset.Icc 1 Y,‖gram a b m n‖)≤|b-a|+4*(Y:ℝ)*(1+Real.log (Y:ℝ)) := by
  have hm' := Finset.mem_Icc.mp hm
  rw [←Finset.sum_erase_add (Finset.Icc 1 Y) (fun n=>‖gram a b m n‖) hm,gram_diag]
  have hdist := distance_row_le Y m hm
  have hH : (∑d∈Finset.Icc 1 Y,(d:ℝ)⁻¹)≤1+Real.log (Y:ℝ) := by
    simpa only [harmonic_eq_sum_Icc,Rat.cast_sum,Rat.cast_inv,Rat.cast_natCast] using harmonic_le_one_add_log Y
  calc
    _ ≤ (∑n∈(Finset.Icc 1 Y).erase m,2*(Y:ℝ)*((Nat.dist m n:ℕ):ℝ)⁻¹)+|b-a| := by
      apply add_le_add _ (le_refl _)
      apply Finset.sum_le_sum
      intro n hn
      have hn' := Finset.mem_Icc.mp (Finset.mem_erase.mp hn).2
      exact gram_offdiag a b Y m n hm'.1 hn'.1 hm'.2 hn'.2 (Finset.mem_erase.mp hn).1.symm
    _ = 2*(Y:ℝ)*(∑n∈(Finset.Icc 1 Y).erase m,((Nat.dist m n:ℕ):ℝ)⁻¹)+|b-a| := by rw [Finset.mul_sum]
    _ ≤ 2*(Y:ℝ)*(2*(1+Real.log (Y:ℝ)))+|b-a| := by
      apply add_le_add _ (le_refl _)
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact hdist.trans (mul_le_mul_of_nonneg_left hH (by norm_num))
    _ = _ := by ring

/-- Literal logarithmic polynomial, with arbitrary complex coefficients. -/
def polynomial (Y : ℕ) (c : ℕ→ℂ) (t : ℝ) : ℂ :=
  ∑n∈Finset.Icc 1 Y,c n*Artin.MarkedReplacement.archimedeanPhase t n

theorem phase_conj_mul (t : ℝ) (m n : ℕ) :
    conj (Artin.MarkedReplacement.archimedeanPhase t m)*
      Artin.MarkedReplacement.archimedeanPhase t n =
      Complex.exp (Complex.I*((Real.log (n:ℝ)-Real.log (m:ℝ)):ℂ)*(t:ℂ)) := by
  unfold Artin.MarkedReplacement.archimedeanPhase
  rw [←Complex.exp_conj,←Complex.exp_add]
  congr 1
  simp only [map_mul,Complex.conj_I,Complex.conj_ofReal,Complex.ofReal_sub,Complex.ofReal_mul]
  ring

theorem gram_conj (a b : ℝ) (m n : ℕ) : conj (gram a b m n)=gram a b n m := by
  unfold gram intervalIntegral
  rw [map_sub,←integral_conj,←integral_conj]
  congr 1 <;> apply integral_congr_ae <;> filter_upwards [] with t
  all_goals
    rw [←Complex.exp_conj]
    congr 1
    simp only [map_mul,map_sub,Complex.conj_I,Complex.conj_ofReal,Complex.ofReal_sub]
    ring

theorem polynomial_continuous (Y : ℕ) (c : ℕ→ℂ) : Continuous (polynomial Y c) := by
  unfold polynomial Artin.MarkedReplacement.archimedeanPhase
  fun_prop

/-- The interval integral of the squared polynomial is its actual Gram pairing. -/
theorem gram_pairing (a b : ℝ) (Y : ℕ) (c : ℕ→ℂ) :
    finiteMeasuredPairing (Finset.Icc 1 Y) (Finset.Icc 1 Y)
      (fun _=>1) (fun _=>1) (gram a b) (fun n=>conj (c n)) c =
      ((∫t in a..b,‖polynomial Y c t‖^2 : ℝ):ℂ) := by
  rw [←intervalIntegral.integral_ofReal]
  simp only [Complex.ofReal_pow,←Complex.conj_mul',polynomial,map_sum,map_mul,Finset.sum_mul,Finset.mul_sum]
  conv_rhs => arg 1; ext t; rw [Finset.sum_comm]
  have hcont (m n : ℕ) : Continuous (fun t:ℝ=>
      conj (c m)*conj (Artin.MarkedReplacement.archimedeanPhase t m)*
        (c n*Artin.MarkedReplacement.archimedeanPhase t n)) := by
    unfold Artin.MarkedReplacement.archimedeanPhase
    fun_prop
  rw [intervalIntegral.integral_finsetSum]
  · simp only [finiteMeasuredPairing,finiteKernelApply,Complex.ofReal_one,one_mul,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro m hm
    rw [intervalIntegral.integral_finsetSum]
    · apply Finset.sum_congr rfl
      intro n hn
      calc
        _ = conj (c m)*c n*gram a b m n := by ring
        _ = ∫t in a..b,(conj (c m)*c n)*
            (conj (Artin.MarkedReplacement.archimedeanPhase t m)*
              Artin.MarkedReplacement.archimedeanPhase t n) := by
          rw [intervalIntegral.integral_const_mul]
          simp_rw [phase_conj_mul]
          rfl
        _ = _ := by congr 1; ext t; ring
    · intro n hn
      exact (hcont m n).intervalIntegrable _ _
  · intro m hm
    apply Continuous.intervalIntegrable
    apply continuous_finset_sum
    intro n hn
    exact hcont m n

/-- A coefficient-independent continuous mean square, with an explicit
harmonic loss. No condition is imposed on the coefficient sequence. -/
theorem continuous_mean_square (a b : ℝ) (hab : a≤b) (Y : ℕ) (hY : 1≤Y)
    (c : ℕ→ℂ) :
    (∫t in a..b,‖polynomial Y c t‖^2)≤
      (b-a+4*(Y:ℝ)*(1+Real.log (Y:ℝ)))*∑n∈Finset.Icc 1 Y,‖c n‖^2 := by
  let R := |b-a|+4*(Y:ℝ)*(1+Real.log (Y:ℝ))
  have hR : 0≤R := by
    have hlog : 0≤Real.log (Y:ℝ) := Real.log_nonneg (by exact_mod_cast hY)
    dsimp [R]
    positivity
  have hcol : ∀n∈Finset.Icc 1 Y,(∑m∈Finset.Icc 1 Y,‖gram a b m n‖)≤R := by
    intro n hn
    simpa only [←gram_conj a b n,Complex.norm_conj] using gram_row_le a b Y n hn
  have h := finite_weighted_schur_bilinear
    (Finset.Icc 1 Y) (Finset.Icc 1 Y)
    (fun _=>1) (fun _=>1) (fun _=>1) (fun _=>1) (gram a b) R R
    (fun _ _=>zero_le_one) (fun _ _=>zero_le_one)
    (fun _ _=>zero_lt_one) (fun _ _=>zero_lt_one) hR hR
    (by simpa using gram_row_le a b Y) (by simpa using hcol)
    (fun n=>conj (c n)) c
  rw [gram_pairing,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg (intervalIntegral.integral_nonneg_of_forall hab (fun t=>sq_nonneg _)),
    ←pow_two R,Real.sqrt_sq hR] at h
  have he : finiteL2 (Finset.Icc 1 Y) (fun _=>1) (fun n=>conj (c n))=
      finiteL2 (Finset.Icc 1 Y) (fun _=>1) c := by simp [finiteL2,finiteL2Sq]
  rw [he,mul_assoc,finiteL2,Real.mul_self_sqrt
    (finiteL2Sq_nonneg _ _ (fun _ _=>zero_le_one) _)] at h
  simpa only [R,abs_of_nonneg (sub_nonneg.mpr hab),finiteL2Sq,one_mul] using h

end Elliptic.Operator.DirichletMeanSquare
