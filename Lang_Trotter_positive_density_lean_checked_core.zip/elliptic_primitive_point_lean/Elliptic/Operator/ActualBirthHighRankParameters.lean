module
public import Elliptic.Operator.ActualBirthHighRankUniform
public import Elliptic.Operator.BoundaryMass

/-! Uniform polynomial prefactors for the literal growing high-rank word. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualBirthHighRank
open Filter
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

/-- The initial slot count is smaller than the growing word length. -/
theorem padding_le_length {L : ℝ} (hL : 1 ≤ L) :
    momentPadding L ≤ momentLength L := by
  have hf := Nat.floor_le (Real.rpow_nonneg (by linarith : 0 ≤ L) (1/100:ℝ))
  have hr := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/100:ℝ) ≤ 1/2)
  have hn := momentLength_lower L
  exact_mod_cast (hf.trans (hr.trans hn))

/-- Fixed Schur parameters contribute a constant, and the physical cap
contributes only a degree-two polynomial per group. -/
theorem edgeBudget_le_polynomial {K B : ℕ} {L G g v0 vmin s : ℝ}
    (hL : 1 ≤ L) (hv : 0 < v0) (hmin : 0 < vmin) (hs : 0 ≤ s)
    (hG : 0 ≤ G) (hgeom : G ≤ L^g) (hB : (B:ℝ) ≤ 2*L^2) :
    edgeBudget K B G v0 vmin s ≤
      ((1+v0)*max 1 (2*vmin⁻¹/v0+s))^K * L^(g+2*(K:ℝ)) := by
  have hL0 : 0 ≤ L := by linarith
  have hLp : 0 < L := by linarith
  have hL2 : 1 ≤ L^2 := one_le_pow₀ hL
  let c := max 1 (2*vmin⁻¹/v0+s)
  have hc : 0 ≤ c := (by norm_num : (0:ℝ) ≤ 1).trans (le_max_left _ _)
  have hinner : max 1 ((B:ℝ)*vmin⁻¹/v0+s) ≤ c*L^2 := by
    apply max_le
    · exact le_trans hL2 (le_mul_of_one_le_left (sq_nonneg L) (le_max_left _ _))
    · calc
        _ ≤ (2*L^2)*vmin⁻¹/v0+s*L^2 := by
          exact add_le_add
            (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hB (inv_nonneg.mpr hmin.le)) hv.le)
            (le_mul_of_one_le_right hs hL2)
        _ = (2*vmin⁻¹/v0+s)*L^2 := by ring
        _ ≤ c*L^2 := mul_le_mul_of_nonneg_right (le_max_right _ _) (sq_nonneg L)
  unfold edgeBudget
  calc
    _ ≤ L^g*((1+v0)*(c*L^2))^K := by
      apply mul_le_mul hgeom
        (pow_le_pow_left₀ (by positivity) (mul_le_mul_of_nonneg_left hinner (by linarith)) K)
        (by positivity) (by positivity)
    _ = ((1+v0)*c)^K*L^(g+2*(K:ℝ)) := by
      rw [Real.rpow_add hLp,Real.rpow_mul_natCast hL0,Real.rpow_ofNat]
      rw [show (1+v0)*(c*L^2) = ((1+v0)*c)*L^2 by ring,mul_pow]
      ring

noncomputable def prefactor (K J B N : ℕ) (D s G v0 vmin : ℝ) : ℝ :=
  (Real.exp (D*s)^K*max 1 (edgeBudget K B G v0 vmin s))^(N+1)*s^(K*(J+1))

/-- The same fixed exponent works for every actual geometry with the
specified polynomial fixed-label row bound. -/
theorem eventually_prefactor_le (K : ℕ) (D s g v0 vmin : ℝ)
    (hs : 1 ≤ s) (hg : 0 ≤ g) (hv : 0 < v0) (hmin : 0 < vmin) :
    ∀ᶠ L : ℝ in atTop, ∀ G : ℝ, 0 ≤ G → G ≤ L^g →
      prefactor K (momentPadding L) (memoryCutoff L) (momentLength L) D s G v0 vmin ≤
        L^((g+2*(K:ℝ)+1)*((momentLength L:ℝ)+1)) := by
  let Ce := ((1+v0)*max 1 (2*vmin⁻¹/v0+s))^K
  let C := Real.exp (D*s)^K*max 1 Ce*s^K
  have hs0 : 0 ≤ s := by linarith
  have hC : 0 ≤ C := by dsimp [C];positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop C] with L hL hCL
  intro G hG hgeom
  have hLp : 0 < L := by linarith
  have hL0 : 0 ≤ L := by linarith
  have hB : (memoryCutoff L:ℝ) ≤ 2*L^2 := by
    have hb := memoryCutoff_upper L
    have hsq : 1 ≤ L^2 := one_le_pow₀ hL
    linarith
  have he := edgeBudget_le_polynomial hL hv hmin hs0 hG hgeom hB (K:=K)
  have hemax : max 1 (edgeBudget K (memoryCutoff L) G v0 vmin s) ≤
      max 1 Ce*L^(g+2*(K:ℝ)) := by
    apply max_le
    · have hc : (1:ℝ) ≤ max 1 Ce := le_max_left _ _
      have hp := Real.one_le_rpow hL (show 0 ≤ g+2*(K:ℝ) by positivity)
      nlinarith
    · exact he.trans (mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity))
  have hp := padding_le_length hL
  have hm : s^(K*(momentPadding L+1)) ≤ (s^K)^(momentLength L+1) := by
    rw [←pow_mul]
    exact pow_le_pow_right₀ hs (Nat.mul_le_mul_left _ (by omega))
  unfold prefactor
  calc
    _ ≤ (Real.exp (D*s)^K*(max 1 Ce*L^(g+2*(K:ℝ))))^(momentLength L+1)*
        (s^K)^(momentLength L+1) := by
      exact mul_le_mul
        (pow_le_pow_left₀ (by positivity) (mul_le_mul_of_nonneg_left hemax (by positivity)) _)
        hm (by positivity) (by positivity)
    _ = (C*L^(g+2*(K:ℝ)))^(momentLength L+1) := by
      rw [←mul_pow]
      congr 1
      dsimp [C]
      ring
    _ ≤ (L*L^(g+2*(K:ℝ)))^(momentLength L+1) :=
      pow_le_pow_left₀ (by positivity) (mul_le_mul_of_nonneg_right hCL (by positivity)) _
    _ = _ := by
      have hm : L*L^(g+2*(K:ℝ)) = L^(g+2*(K:ℝ)+1) := by
        rw [Real.rpow_add hLp (g+2*(K:ℝ)) 1,Real.rpow_one]
        ring
      rw [hm,←Real.rpow_mul_natCast hL0]
      congr 1
      push_cast
      ring

attribute [local instance 100000] Classical.propDecidable
local instance parameterDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

/-- An actual signed physical high-rank term has the source polynomial
prefactor and exact exponentially small prime atom at every cycle rank. -/
theorem eventually_term_norm_le (K : ℕ) (D s g v0 vmin Catom ρ : ℝ)
    (hD : 1 ≤ D) (hs : 1 ≤ s) (hg : 0 ≤ g) (hv : 0 < v0)
    (hmin : 0 < vmin) (hatom : 0 ≤ Catom) (hρ : 0 < ρ) (hρ1 : ρ ≤ 1) :
    ∀ᶠ L : ℝ in atTop, ∀ (I Z : Type) [Fintype I] [Fintype Z], Fintype.card I = K →
      ∀ (P : I → Type) [∀ i, Fintype (P i)] (Line : ∀ i, P i → Type)
        (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ)
        (anchor : Z → ∀ i p, Line i p)
        (geometry : ℕ → Z → PhysicalActiveLists P (momentPadding L) →
          Z → PhysicalActiveLists P (momentPadding L) → ℂ)
        (value : ∀ i, P i → ℕ),
      Function.Injective (fun p : Sigma P => value p.1 p.2) →
      (∀ i p, 0 ≤ ν i p) → (∀ j, 0 ≤ η j) → (∀ j, 0 ≤ q j) →
      (∀ i, vmin ≤ V i) → (∀ i, (∑ p, ν i p) ≤ s) →
      (∀ i p, ν i p ≤ Catom*Real.exp (-L^(1/10:ℝ))) →
      (∀ j, q j/ρ^2+η j/(ρ*v0) ≤ 1) → (∀ j i, η j*V i/ρ*v0 ≤ D) →
      (∀ j z a b, (∑ w : Z, ‖geometry j z a w b‖) ≤ L^g) →
      ∀ (F : PhysicalMemoryState (Z:=Z) P Line (momentPadding L) (memoryCutoff L) → ℂ),
      (∀ t, ‖F t‖ ≤ physicalMemorySchurWeight v0 t) →
      ∀ (σ : Equiv.Perm (ActualHistoryBirths.Address I (momentPadding L)
        (memoryCutoff L) (momentLength L))) (z : Z),
      ‖term ν V η q ρ anchor geometry value σ F z‖ ≤
        L^((g+2*(K:ℝ)+1)*((momentLength L:ℝ)+1))*
          ((D*Catom)*Real.exp (-L^(1/10:ℝ)))^(birthCycleRank σ) := by
  filter_upwards [eventually_prefactor_le K D s g v0 vmin hs hg hv hmin,
    eventually_ge_atTop (1:ℝ)] with L hpre hL
  intro I Z _ _ hI P _ Line ν V η q anchor geometry value hinj hν hη hq hV hmass hprime
    hsurvive hbase hgeometry F hF σ z
  letI (priority := 100000) : DecidableEq (ActualHistoryBirths.Address I (momentPadding L)
      (memoryCutoff L) (momentLength L)) := Classical.typeDecidableEq _
  have hL0 : 0 ≤ L := by linarith
  have h := term_norm_le_uniform ν V η q ρ v0 (Catom*Real.exp (-L^(1/10:ℝ)))
    D s (L^g) vmin anchor geometry value hinj σ hν hη hq hρ hρ1 hv
    (by positivity) hprime hsurvive hD hmin hV (by positivity) hmass hs hbase hgeometry F hF z
  have hp := hpre (L^g) (by positivity) le_rfl
  rw [hI] at h
  apply h.trans
  calc
    _ ≤ L^((g+2*(K:ℝ)+1)*((momentLength L:ℝ)+1))*
        (D*(Catom*Real.exp (-L^(1/10:ℝ))))^(birthCycleRank σ) :=
      mul_le_mul_of_nonneg_right hp (by positivity)
    _ = _ := by rw [mul_assoc]

end Elliptic.Operator.ActualBirthHighRank
