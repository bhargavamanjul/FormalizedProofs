module
public import Elliptic.Operator.SignedMajorUnitSupport
public import Elliptic.Operator.SignedSourceDyads
public import Elliptic.Operator.SignedCollisionAsymptotics

/-! Actual source parameters discharge the small-arc and unit-support conditions. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorSourceParameters
open Filter Artin Artin.MarkedSource Artin.MarkedCriterion
open SignedMajorMellinIdentity SignedSourceDyads SignedSmoothDyads SignedCauchyExpansion
set_option backward.isDefEq.respectTransparency false

/-- Every actual band prime satisfies the common lower cutoff; no gap
between its band exponent and 1/10 enters the threshold. -/
theorem band_prime_lower {K : ℕ} (b : Bands K) (x : ℝ) (hL : 1≤Real.log x)
    (i : Fin K) (p : ℕ) (hp : p∈b.group x i) :
    Real.exp ((Real.log x)^(1/10:ℝ))≤(p:ℝ) := by
  have hl := (MarkedBandTail.primeBand_properties _ _
    (by simpa [b.group_eq_markedBandTail x i] using hp)).2.1
  exact (Real.exp_le_exp.mpr
    (Real.rpow_le_rpow_of_exponent_le hL (b.lower i).le)).trans hl

/-- The cutoff support loses at most the fixed factor four at the lower
edge of an active source dyad. This version is uniform in all bands. -/
theorem source_dyad_lower_uniform {K : ℕ} (b : Bands K) (hK : 1≤K)
    (x : ℝ) (hL : 1≤Real.log x) (d : ℕ) (hd : d∈sourceDyads b x) :
    Real.exp ((Real.log x)^(1/10:ℝ))≤4*(2:ℝ)^d := by
  have hp (a : LabelTuple b x) :
      Real.exp ((Real.log x)^(1/10:ℝ))≤(labelProduct b x a:ℝ) := by
    exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL
      (b.lower ⟨0,by omega⟩).le)).trans (labelProduct_lower b hK x a)
  have hh := (activeDyads_scale_bounds (fun a : LabelTuple b x=>(labelProduct b x a:ℝ))
    (sourceCount K x) (Real.exp ((Real.log x)^(1/10:ℝ)))
    (Real.exp (2*K*(Real.log x)^(1/5:ℝ)))
    (fun a=>⟨hp a,labelProduct_upper b x hL a⟩) d hd).2.1
  linarith

/-- One onset precedes the band count, actual bands, modulus, coefficient
indices, and active dyad. It supplies all finite-major unit and radius inputs. -/
theorem eventually_source_major_parameters (G : ℝ) :
    ∀ᶠx : ℝ in atTop,2≤Real.log x ∧
      (∀k : ℕ,0<k→(k:ℝ)≤(Real.log x)^G→∀n : ℕ,
        IsRough (W x) n→n.Coprime k) ∧
      (∀K : ℕ,∀b : Bands K,
        (∀k : ℕ,0<k→(k:ℝ)≤(Real.log x)^G→∀a : LabelTuple b x,
          (labelProduct b x a).Coprime k) ∧
        (1≤K→∀d∈sourceDyads b x,2*(Real.log x)^G/(2:ℝ)^d<1/2)) := by
  filter_upwards [eventually_source_unit_support G,
    Real.tendsto_log_atTop.eventually (SignedCollisionAsymptotics.eventually_rpow_exp_loss 32 G 0),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (2:ℝ))] with x hu hs hL
  have hL1 : 1≤Real.log x := by linarith
  have hLp : 0<Real.log x := by linarith
  have hs' : 32*(Real.log x)^G≤Real.exp ((Real.log x)^(1/10:ℝ)) := by
    rw [show Real.exp ((Real.log x)^(1/10:ℝ))=1*Real.exp ((Real.log x)^(1/10:ℝ)) by ring]
    apply (div_le_iff₀ (Real.exp_pos _)).mp
    simpa only [neg_zero,Real.rpow_zero,Real.exp_neg,div_eq_mul_inv,one_mul] using hs
  refine ⟨hL,hu.1,?_⟩
  intro K b
  refine ⟨hu.2 K b (band_prime_lower b x hL1),?_⟩
  intro hK d hd
  have hy := source_dyad_lower_uniform b hK x hL1 d hd
  apply (div_lt_iff₀ (by positivity : (0:ℝ)<2^d)).mpr
  have hH : 0<(Real.log x)^G := Real.rpow_pos_of_pos hLp G
  linarith

/-- The nine polylogarithmic character/arc costs and the factor four are
absorbed by two extra logarithmic powers. -/
theorem finite_major_cost_absorption (L G A Y X : ℝ) (hL : 2≤L)
    (hY : 0≤Y) (hX : 0≤X) :
    4*(L^G)^9*Y*X*L^(-(A+9*G+2))≤Y*X*L^(-A) := by
  have hLp : 0<L := by linarith
  have he : (L^G)^9*L^(-(A+9*G+2))=L^(-A-2) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_add hLp]
    congr 1
    push_cast
    ring
  calc
    _ = 4*(Y*X)*L^(-A-2) := by rw [←he]; ring
    _ ≤ L^2*(Y*X)*L^(-A-2) := by
      apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hLp.le _)
      exact mul_le_mul_of_nonneg_right (by nlinarith) (mul_nonneg hY hX)
    _ = Y*X*L^(-A) := by
      rw [←Real.rpow_ofNat L 2]
      calc
        _ = Y*X*(L^(2:ℝ)*L^(-A-2)) := by ring
        _ = _ := by rw [←Real.rpow_add hLp]; congr 2; ring

end Elliptic.Operator.SignedMajorSourceParameters
