module

public import Elliptic.Operator.SignedSquareCount
public import Elliptic.Operator.RootErrorBudget
public import Elliptic.ReciprocalPrimeTail

/-! The original damping replacement, with an arbitrary logarithmic
saving. The only imported statement is the already declared classical
lower bound for reciprocal-prime band masses. The square-divisibility
count and reciprocal-square upper tail are proved here/from Chebyshev. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedDampingAsymptotics
open scoped BigOperators Topology
open Filter Artin Artin.MarkedSource SignedDampingBounds SignedSquareCount
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

theorem band_square_tail (b : Bands K) (x : ℝ) (hL : 1≤Real.log x) :
    (∑ i : Fin K,∑ p∈b.group x i,(p:ℝ)⁻¹^2) ≤
      (8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))) := by
  have hpow : 1≤(Real.log x)^(1/10:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hY : 1<Real.exp ((Real.log x)^(1/10:ℝ)) := Real.one_lt_exp_iff.mpr (by linarith)
  have hcoef : 0≤8*Real.log (4:ℝ) := by positivity
  have hi (i : Fin K) : (∑ p∈b.group x i,(p:ℝ)⁻¹^2) ≤
      (8*Real.log 4)*Real.exp (-((Real.log x)^(1/10:ℝ))) := by
    have htail := reciprocal_prime_tail_le (b.group x i) _ hY (fun p hp=>b.group_prime x hp)
      (fun p hp=> (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (b.lower i).le)).trans
        (MarkedBandTail.primeBand_properties _ _ (by simpa [b.group_eq_markedBandTail x i] using hp)).2.1)
    have hsum : (∑ p∈b.group x i,(p:ℝ)⁻¹^2) ≤ ∑ p∈b.group x i,1/((p:ℝ)*(p-1)) := by
      apply Finset.sum_le_sum
      intro p hp
      have hp2 : (2:ℝ)≤p := by exact_mod_cast (b.group_prime x hp).two_le
      have hp0 : (0:ℝ)<p := by linarith
      have hpm : (0:ℝ)<(p:ℝ)-1 := by linarith
      rw [inv_pow,inv_eq_one_div]
      apply one_div_le_one_div_of_le (by positivity)
      nlinarith
    apply hsum.trans (htail.trans _)
    rw [Real.log_exp,Real.exp_neg]
    calc
      _ ≤ (8*Real.log 4)/Real.exp ((Real.log x)^(1/10:ℝ)) :=
        div_le_div_of_nonneg_left hcoef (Real.exp_pos _)
          (by nlinarith [Real.exp_pos ((Real.log x)^(1/10:ℝ))])
      _ = _ := div_eq_mul_inv _ _
  calc
    _ ≤ ∑ i : Fin K,(8*Real.log 4)*Real.exp (-((Real.log x)^(1/10:ℝ))) := Finset.sum_le_sum (fun i _=>hi i)
    _ = _ := by simp; ring

theorem eventually_band_squares_small (δ : ℝ) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop, ∀ K : ℕ, ∀ b : Bands K, ∀ i p,
      p∈b.group x i → (p:ℝ)^2≤x^δ := by
  have hg := Real.tendsto_log_atTop.eventually (RootErrorBudget.eventually_subpower_exponent_le 4 δ hδ)
  filter_upwards [eventually_gt_atTop (0:ℝ),Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),hg]
    with x hx hL hg
  intro K b i p hp
  have hu := (MarkedBandTail.primeBand_properties _ _ (by simpa [b.group_eq_markedBandTail x i] using hp)).2.2
  have hp20 := Real.rpow_le_rpow_of_exponent_le hL (b.upper i).le
  have hp98 := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/5:ℝ)≤98/100)
  calc
    _ ≤ (Real.exp (2*(Real.log x)^b.exponent i))^2 := pow_le_pow_left₀ (Nat.cast_nonneg _) hu 2
    _ = Real.exp (4*(Real.log x)^b.exponent i) := by rw [←Real.exp_nat_mul]; congr 1; ring
    _ ≤ Real.exp (δ*Real.log x) := Real.exp_le_exp.mpr (by linarith)
    _ = x^δ := by rw [Real.rpow_def_of_pos hx]; congr 1; ring

def uniformWeightBound (K : ℕ) (q : ℝ) : ℝ :=
  ((1-q)⁻¹/((Real.log 2)/2))^K

theorem weightBound_le_uniform (b : Bands K) (q x : ℝ) (hq : q<1)
    (hmass : ∀i,(Real.log 2)/2≤b.mass x i) :
    SignedDampingBounds.weightBound b q x≤uniformWeightBound K q := by
  have hv : 0<(Real.log (2:ℝ))/2 := by positivity
  unfold SignedDampingBounds.weightBound uniformWeightBound
  calc
    _ ≤ ∏ i : Fin K,(1-q)⁻¹/((Real.log 2)/2) := by
      apply Finset.prod_le_prod₀
      · intro i _
        exact div_nonneg (inv_nonneg.mpr (by linarith)) (hv.le.trans (hmass i))
      · intro i _
        exact div_le_div_of_nonneg_left (inv_nonneg.mpr (by linarith)) hv (hmass i)
    _ = _ := by simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]

/-- A single threshold works for every selector, interval, coefficient
pair and dyad. K is fixed before this error is estimated, and need not be
increased to handle any of those varying objects. -/
theorem eventually_bilinear_replacement (hbands : ClassicalBandMass)
    (b : Bands K) (δ C D q : ℝ) (hδ : 0<δ) (hq : 0≤q) (hq1 : q<1) :
    ∀ᶠ x : ℝ in atTop, ∀ Hm Hn : ℝ, 1≤Hm → 1≤Hn → x^δ≤Hn →
      ∀ s t : Finset ℕ, InDyad Hm s → InDyad Hn t →
      ∀ α β F : ℕ→ℂ,
      (∀m∈s,‖α m‖≤(Real.log x)^C) → (∀n∈t,‖β n‖≤(Real.log x)^C) →
      (∀n,‖F n‖≤1) →
      ‖Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(markedWeight b q x n:ℂ))-
        Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ))‖ ≤
        (Hm*Hn)*(Real.log x)^(-D) := by
  let A : ℝ := 9*uniformWeightBound K q*(8*Real.log 4*K)
  have hlim : Tendsto (fun L : ℝ=>A*(L^(2*C+D)*Real.exp (-(L^(1/10:ℝ))))) atTop (𝓝 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow (2*C+D)
      (by norm_num : (0:ℝ)<1) (by norm_num : (0:ℝ)<1/10)).const_mul A
  have hdis := MarkedBandTail.eventual_bands_disjoint Finset.univ b.exponent
    (fun i _ j _ h=>b.increasing.injective h)
  filter_upwards [hbands K b,eventually_band_squares_small δ hδ,hdis,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),
    Real.tendsto_log_atTop.eventually (hlim.eventually_lt_const (by norm_num : (0:ℝ)<1))]
    with x hV hsquare hdis hL hsmall
  intro Hm Hn hHm hHn hH s t hs ht α β F hα hβ hF
  have hLp : 0<Real.log x := by linarith
  have hv : ∀i,0≤b.mass x i := fun i=>(by positivity : 0≤(Real.log (2:ℝ))/2).trans (hV i)
  have hd : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)) := by
    intro i j hij
    simpa only [b.group_eq_markedBandTail x i,b.group_eq_markedBandTail x j] using hdis i (Finset.mem_univ _) j (Finset.mem_univ _) hij
  have hw := weightBound_le_uniform b q x hq1 hV
  have hcount := square_exception_count b x Hm Hn hHm hHn
    (fun i p hp=>(hsquare K b i p hp).trans hH) s t hs ht
  have htail := band_square_tail b x hL
  have herror := bilinear_replacement_error b q x s t α β F ((Real.log x)^C) ((Real.log x)^C)
    hα hβ hF hd hq hq1 hv
  have hu : 0≤uniformWeightBound K q := by unfold uniformWeightBound; positivity
  have hC : 0≤(Real.log x)^C := Real.rpow_nonneg hLp.le _
  have hscale : A*((Real.log x)^(2*C)*Real.exp (-((Real.log x)^(1/10:ℝ)))) ≤ (Real.log x)^(-D) := by
    rw [Real.rpow_neg hLp.le,←one_div]
    apply (le_div_iff₀ (Real.rpow_pos_of_pos hLp D)).mpr
    have he : (Real.log x)^(2*C+D)=(Real.log x)^(2*C)*(Real.log x)^D := Real.rpow_add hLp _ _
    rw [he] at hsmall
    nlinarith
  calc
    _ ≤ (Real.log x)^C*(Real.log x)^C*SignedDampingBounds.weightBound b q x*
        (((s×ˢt).filter (fun mn=>squareException b x (mn.1*mn.2+1))).card:ℝ) := herror
    _ ≤ (Real.log x)^C*(Real.log x)^C*uniformWeightBound K q*
        (9*(Hm*Hn)*((8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))))) := by
      apply mul_le_mul (mul_le_mul_of_nonneg_left hw (mul_nonneg hC hC))
        (hcount.trans (mul_le_mul_of_nonneg_left htail (by positivity))) (Nat.cast_nonneg _) (by positivity)
    _ = (Hm*Hn)*(A*((Real.log x)^(2*C)*Real.exp (-((Real.log x)^(1/10:ℝ))))) := by
      rw [show (Real.log x)^(2*C)=(Real.log x)^C*(Real.log x)^C by rw [←Real.rpow_add hLp]; congr 1; ring]
      dsimp [A]
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hscale (by positivity)

end Elliptic.Operator.SignedDampingAsymptotics
