module

public import Elliptic.Operator.DirtyOuterBudget

/-!
# Outer integration of actual endpoint-averaged dirty raw rows

This theorem sums the actual raw-choice estimate over stores, fresh/free
promotion modes and the one distinguished old index. The fresh masses and
promotion factors are the literal Schur coefficients. Phase separation,
the primitive source complement and raw-support membership remain explicit.
There is no assumed row estimate or assumed operator norm.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyOuter
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- Exactly the choices still outside the indexed damping estimate:
one distinguished old index, its store bit, all other store bits, and
fresh/free-promotion modes in all other groups. -/
abbrev Key (i₀ : Fin K) :=
  Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).size ×
  Bool × ({i : Fin K // i ≠ i₀} → Bool) ×
  (∀ i : {i : Fin K // i ≠ i₀}, Option (P i))

/-- Literal coefficient attached to this outer key. -/
def coefficient (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (i₀ : Fin K) (k : Key value s i₀) : ℝ :=
  ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i)
    (DirtyOuterBudget.stores i₀ k.2.1 k.2.2.1 i)
    (DirtyOuterBudget.modes
      (s.memory P (fun i p => Option (ZMod (value i p))) J B) i₀ k.1 k.2.2.2 i)

variable [Fintype Z] [∀ i, Fintype (P i)]

/-- Fully integrated coefficient bound with only one memory-cutoff loss. -/
theorem sum_coefficient_le (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin mass : ℝ)
    (i₀ : Fin K) (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i)
    (hmin : 0 < vmin) (hv0 : 0 < v0) (hρ : ρ < 1)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ k : Key value s i₀, coefficient value s ν V ρ v0 i₀ k) ≤
      B * ((1 + v0) * vmin⁻¹ / v0) *
        ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^
          Fintype.card {i : Fin K // i ≠ i₀} := by
  unfold Key coefficient
  simp only [Fintype.sum_prod_type]
  exact DirtyOuterBudget.sum_assembled_product_le ν V ρ v0 vmin mass
    (s.memory P (fun i p => Option (ZMod (value i p))) J B) i₀
    hν hV hmin hv0 hρ hmass

/-- Summing actual endpoint-averaged raw-choice fibers over every remaining
outer parameter gives the `B / (J+1)^K` gain with an explicit constant.
The phase test is required for the actual fresh product of each fiber.
This is a raw coefficient estimate; geometric cutoff sizes, exceptional
fresh draws and the opposite Schur side are not asserted here. -/
theorem endpoint_averaged_outer_sum_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 vmin mass : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ = 1 ∨ σ = -1)
    (i₀ : Fin K) (T : Key value s i₀ → ℕ) (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Key value s i₀ → Finset (PhysicalEdgeChoice s))
    (δ : Key value s i₀ → ℝ)
    (hsep : ∀ k : Key value s i₀, (S k).Nonempty → PhaseSeparated
      (dirtyProductSupport
        (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B))
        (PhysicalDirtyCoordinates.rawOtherProducts value position s good u v r U W d₀ σ i₀ k.1 (T k)))
      ((T k : ℝ) * (latticeTau r w /
        latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B)))) (δ k))
    (hwidth : ∀ k : Key value s i₀, 2 * (16 / (value i₀
      ((s.memory P (fun i p => Option (ZMod (value i p))) J B i₀).values k.1).1 : ℝ)) < δ k)
    (hS : ∀ k, S k ⊆ PhysicalDirtyCoordinates.rawChoices
      value position s good u v r U W d₀ σ i₀ k.1 (T k))
    (hmode : ∀ k, ∀ c ∈ S k, ∀ i,
      c.group i ∈ dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i)
        (DirtyOuterBudget.stores i₀ k.2.1 k.2.2.1 i)
        (DirtyOuterBudget.modes
          (s.memory P (fun i p => Option (ZMod (value i p))) J B) i₀ k.1 k.2.2.2 i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, vmin ≤ V i)
    (hmin : 0 < vmin) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ k : Key value s i₀, endpointPermutationWeight (Fin K) J *
      ∑ c ∈ S k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      (33 * (B * ((1 + v0) * vmin⁻¹ / v0) *
        ((1 + v0) * (vmin⁻¹ / (v0 * (1 - ρ)) + mass)) ^
          Fintype.card {i : Fin K // i ≠ i₀})) / (J+1 : ℝ)^K := by
  have hf (k : Key value s i₀) :
      endpointPermutationWeight (Fin K) J *
        (∑ c ∈ S k, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
        (33 * coefficient value s ν V ρ v0 i₀ k) / (J+1 : ℝ)^K := by
    by_cases he : S k = ∅
    · simp only [he, Finset.sum_empty, mul_zero]
      apply div_nonneg
      · apply mul_nonneg (by norm_num)
        exact Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg
          (ν i) (V i) ρ v0 _ _ _ (hν i) (hmin.trans_le (hV i)).le hρ1 hv0.le
      · positivity
    · exact PhysicalDirtyWeighted.rawChoices_endpoint_averaged_sum_le value position s
        hposition hprime ν V ρ v0
        (DirtyOuterBudget.stores i₀ k.2.1 k.2.2.1)
        (DirtyOuterBudget.modes
          (s.memory P (fun i p => Option (ZMod (value i p))) J B) i₀ k.1 k.2.2.2)
        good u v r U W d₀ σ hU hσ i₀ k.1 (T k) w hzw (δ k)
        (hsep k (Finset.nonempty_iff_ne_empty.mpr he)) (hwidth k)
        (S k) (hS k) (hmode k) hν (fun i => (hmin.trans_le (hV i)).le) hρ0 hρ1 hv0
  calc
    _ ≤ ∑ k : Key value s i₀,
        (33 * coefficient value s ν V ρ v0 i₀ k) / (J+1 : ℝ)^K :=
      Finset.sum_le_sum fun k _ => hf k
    _ = (33 * ∑ k : Key value s i₀, coefficient value s ν V ρ v0 i₀ k) /
        (J+1 : ℝ)^K := by rw [← Finset.sum_div, ← Finset.mul_sum]
    _ ≤ _ := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact sum_coefficient_le value s ν V ρ v0 vmin mass i₀ hν hV hmin hv0 hρ1 hmass

end Elliptic.Operator.PhysicalDirtyOuter
