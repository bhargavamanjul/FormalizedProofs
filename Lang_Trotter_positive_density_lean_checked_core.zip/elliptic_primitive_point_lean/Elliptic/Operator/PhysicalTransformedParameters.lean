module
public import Elliptic.Operator.ActualBirthSourceMass
public import Elliptic.Operator.SourceSecondGoodState

/-! All elementary mass inputs, including the unrestricted initial active
mass, are discharged for the literal transformed source measure. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalTransformedParameters
open Filter
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

 theorem transformed_fin_eq_range (N : ℕ) (η : ℕ→ℝ) (V : ℝ) (p : ℕ) :
    transformedPrimeMass Finset.univ (fun j : Fin (N+1)=>η j.val) V p=
      transformedPrimeMass (Finset.range (N+1)) η V p := by
  simp only [transformedPrimeMass,Fin.sum_univ_eq_sum_range]

 theorem eventually_source_mass_parameters (K : ℕ) (vmin : ℝ) (hmin : 0<vmin) :
    ∀ᶠL : ℝ in atTop,∀(groups : Fin K→Finset ℕ) (V : Fin K→ℝ) (η : ℕ→ℝ),
      (∀i,vmin≤V i)→(∀i,V i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^(1/10:ℝ))≤(p:ℝ))→(∀j,η j≤1)→
      let ν := fun i p=>transformedPrimeMass (Finset.range (momentLength L+1)) η (V i) p
      (∀i,∀p∈groups i,0<ν i p) ∧
      (∀i,∀p∈groups i,ν i p≤(2/vmin)/p) ∧
      (∀i,(∑p:groups i,ν i p.val)≤2) ∧
      (∀i (p:groups i),ν i p.val≤2*(1/(V i*p.val))) ∧
      (∏i,(∑p:groups i,ν i p.val)^(momentPadding L+1))≤2 := by
  filter_upwards [eventually_memory_visits_le_prime_cutoff,
    ActualBirthHighRank.eventually_transformed_mass_parameters vmin hmin,
    eventually_transformed_boundary_mass_le_two K] with L hsize hmass hboundary
  intro groups V η hV hVsum hband hη
  let ν := fun i p=>transformedPrimeMass (Finset.range (momentLength L+1)) η (V i) p
  have hVpos : ∀i,0<V i := fun i=>hmin.trans_le (hV i)
  have hsize' : 2*((Finset.range (momentLength L+1)).card:ℝ)≤Real.exp (L^(1/10:ℝ)) := by
    simpa only [Finset.card_range,Nat.cast_add,Nat.cast_one] using hsize
  have hp (i : Fin K) (p : ℕ) (hp : p∈groups i) : 0<p := by
    have hh := (Real.exp_pos _).trans_le (hband i p hp)
    exact_mod_cast hh
  have hpos : ∀i,∀p∈groups i,0<ν i p := by
    intro i p hpi
    exact ActualBirthHighRank.transformedPrimeMass_pos _ η (V i) p (hVpos i) (hp i p hpi)
      (fun j _=>hη j) (hsize'.trans (hband i p hpi))
  have hrec : ∀i,∀p∈groups i,ν i p≤(2/vmin)/p := by
    intro i p hpi
    apply (transformedPrimeMass_bounds _ η (V i) p (hVpos i) (hp i p hpi)
      (fun j _=>hη j) (hsize'.trans (hband i p hpi))).2.trans
    exact div_le_div_of_nonneg_right (div_le_div_of_nonneg_left (by norm_num) hmin (hV i))
      (Nat.cast_nonneg _)
  have hsum : ∀i,(∑p:groups i,ν i p.val)≤2 := by
    intro i
    have hh := (hmass (fun j : Fin (momentLength L+1)=>η j.val) (groups i) (V i)
      (hV i) (hVsum i) (hband i) (fun j=>hη j.val)).2.1
    simpa only [transformed_fin_eq_range] using hh
  have hdom : ∀i (p:groups i),ν i p.val≤2*(1/(V i*p.val)) := by
    intro i p
    exact (SourceSecondGoodState.transformedPrimeMass_le_twice _ η (V i)
      (Real.exp (L^(1/10:ℝ))) p.val (hVpos i) (Real.exp_pos _) (hband i p.val p.property)
      (fun j _=>hη j) hsize').2
  refine ⟨hpos,hrec,hsum,hdom,?_⟩
  have hh := hboundary (Fin K) (Fintype.card_fin K) (Real.exp (L^(1/10:ℝ)))
    (fun j : Fin (momentLength L+1)=>η j.val) groups V hVpos hVsum le_rfl hband (fun j=>hη j.val)
  simp only [transformed_fin_eq_range,momentMultiplicity] at hh
  have he i : (∑p:groups i,ν i p.val)=∑p∈groups i,ν i p := by
    exact (Finset.sum_subtype (groups i) (fun _=>Iff.rfl) _).symm
  simpa only [he,ν] using hh

end Elliptic.Operator.PhysicalTransformedParameters
