module
public import Elliptic.Operator.PhysicalBoundaryOrientedSaving
public import Elliptic.Operator.PhysicalTransformedParameters

/-! The actual oriented physical boundary moment for the literal
transformed source measure. All elementary mass and initial norm inputs
are derived from reciprocal normalization and the exponential prime bands. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBoundaryTransformedSaving
open Filter
open scoped BigOperators SchwartzMap
open CanonicalBoundaryAssembly PhysicalBoundaryMoment PhysicalLowRankOrientedSaving
open PhysicalTransformedParameters
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 500000

 theorem exists_group_count_for_transformed_boundary (E : ℝ) (hE : 0≤E) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ ρ vmin vmax Qg : ℝ),
      1≤C→0≤Aψ→0<ρ→ρ<1→0<vmin→Qg<ρ^2→
      (∀x,‖η x‖≤1)→(∀x,η x≠0→1≤x)→
      (∀x,‖ψ x‖≤Aψ)→(∀x,ψ x≠0→|x|≤C)→
      ∀ᶠ L : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i (p:groups i),Fintype (ZMod p.val)),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀V : Fin K→ℝ,(∀i,vmin≤V i)→(∀i,V i≤vmax)→
      (∀i,V i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      ∀(d₀ Y : ℝ) (qroot : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤qroot.1→qroot.1≤16→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀(ηg qg : ℕ→ℝ),(∀j,0≤qg j)→(∀j,qg j≤Qg)→
      (∀j,0≤ηg j)→(∀j,ηg j≤1)→∀(adjoint : ℕ→Bool) (sign : ℕ→ℤ),(∀j,sign j=1∨sign j= -1)→
      ∀z₀ z₁ : positions,
      let ν := fun i p=>transformedPrimeMass (Finset.range (momentLength L+1)) ηg (V i) p
      let μ := fun i (p:groups i)=>1/(V i*p.val)
      ‖boundaryPairing (J:=momentPadding L) (B:=memoryCutoff L) (fun i (p:groups i)=>ν i p.val) V ηg qg ρ
        (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:positions=>z.val))
        (literalOrientedGeometry positions groups μ d₀ Y L a qroot U W η ψ (L^(sourceContractionExponent E+6)) adjoint sign)
        (fun i (p:groups i)=>p.val) (momentLength L) (atPosition z₀) (atPosition z₁)‖≤
      L^(-E*(momentLength L:ℝ)) := by
  obtain ⟨K₀,hK₀,hbound⟩ := PhysicalBoundaryOrientedSaving.exists_group_count_for_actual_oriented_boundary E hE
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ψ η C Aψ ρ vmin vmax Qg hC hAψ hρ hρ1 hmin hQg hη hηsupport hψ hψsupport
  have hcoeff : 0≤2/vmin := by positivity
  filter_upwards [hbound K hK (fun _=>2/vmin) (fun _=>hcoeff) ψ η C Aψ 2 (2/vmin) ρ vmin vmax Qg
      hC hAψ (by norm_num) hcoeff (fun _=>le_rfl) hρ hρ1 hmin hQg hη hηsupport hψ hψsupport,
    eventually_source_mass_parameters K vmin hmin,eventually_ge_atTop (1:ℝ)] with L hb hm hL
  intro a ha positions groups instLine hprime hdis V hVlo hVhi hVsum hband d₀ Y qroot U W
    hU hq hq' hd₀ hY hYlo hYhi ηg qg hq0 hqQ hη0 hη1 adjoint sign hsign z₀ z₁
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  have hband0 : ∀i,∀p∈groups i,Real.exp (L^(1/10:ℝ))≤(p:ℝ) := by
    intro i p hp
    exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (ha i))).trans (hband i p hp)
  obtain ⟨hpos,hrec,hmass,hdom,hboundary⟩ := hm groups V ηg hVlo hVsum hband0 hη1
  exact hb a ha positions groups instLine hprime hdis
    (fun i p=>transformedPrimeMass (Finset.range (momentLength L+1)) ηg (V i) p)
    (fun i (p:groups i)=>1/(V i*p.val)) V hpos hrec hmass hdom hVlo hVhi hband hboundary
    d₀ Y qroot U W hU hq hq' hd₀ hY hYlo hYhi ηg qg hq0 hqQ hη0 hη1 adjoint sign hsign z₀ z₁

end Elliptic.Operator.PhysicalBoundaryTransformedSaving
