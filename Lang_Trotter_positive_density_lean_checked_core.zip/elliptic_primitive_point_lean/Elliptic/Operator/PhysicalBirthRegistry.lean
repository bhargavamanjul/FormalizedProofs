module

public import Elliptic.Operator.ActualHistoryBirths
public import Elliptic.Operator.BirthAddressGroups

/-! # A causal registry of the actual performed birth values

The registry starts with the initial active labels. Every operation writes
only its own current birth addresses; promotions write none. Its final
contents coincide with the existing actual-history birth logger.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalBirthRegistryDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i→Type} {J B : ℕ}

/-- Natural visit indices avoid changing the registry type in tail histories. -/
abbrev Address (I : Type) (J B : ℕ) :=
  (I×Fin (J+1)) ⊕ ((ℕ×I×Fin B) ⊕ (ℕ×I))
abbrev Registry (I : Type) (J B : ℕ) := Address I J B→Option ℕ

def embed {N : ℕ} : ActualHistoryBirths.Address I J B N→Address I J B
  | .inl a => .inl a
  | .inr (.inl a) => .inr (.inl (a.1.val,a.2))
  | .inr (.inr a) => .inr (.inr (a.1.val,a.2))

/-- Only the initial lists are known before the first operation. -/
def initial (value : ∀i,P i→ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B) : Registry I J B
  | .inl a => some (value a.1 (s.active P Line J B a.1 a.2))
  | .inr _ => none

/-- Record a literal ghost batch at its actual visit, including padded none. -/
def afterGhost (value : ∀i,P i→ℕ) (j : ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalGhostChoice s)
    (r : Registry I J B) : Registry I J B
  | .inl a => r (.inl a)
  | .inr (.inl a) => if a.1=j then (ActualHistoryBirths.ghostSlot c a.2.1 a.2.2).map (value a.2.1)
      else r (.inr (.inl a))
  | .inr (.inr a) => r (.inr (.inr a))

/-- A promotion is recorded as absent, while the actual fresh prime is recorded. -/
def afterEdge (value : ∀i,P i→ℕ) (j : ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (r : Registry I J B) : Registry I J B
  | .inl a => r (.inl a)
  | .inr (.inl a) => r (.inr (.inl a))
  | .inr (.inr a) => if a.1=j then (ActualHistoryBirths.freshSlot c a.2).map (value a.2)
      else r (.inr (.inr a))

variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (anchor : Z→∀i p,Line i p)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
variable (value : ∀i,P i→ℕ)

/-- Fold the original actual dependent choices into the earlier-value registry. -/
def record : (n j : ℕ)→(s : PhysicalMemoryState (Z:=Z) P Line J B)→
    ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s→
    Registry I J B→Registry I J B
  | 0,j,_,h,r => afterGhost value j h.1.val r
  | n+1,j,_,h,r => record n (j+1) _ h.2.2
      (afterEdge value j h.2.1.val (afterGhost value j h.1.val r))

/-- Subsequent operations never alter an initial birth. -/
theorem record_initial (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (a : I×Fin (J+1)) :
    record ν V η q ρ anchor geometry value n j s h r (.inl a)=r (.inl a) := by
  induction n generalizing j s r with
  | zero => rfl
  | succ n ih => exact ih _ _ h.2.2 _

/-- The registry never overwrites ghost values at earlier visits. -/
theorem record_pastGhost (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (t : ℕ) (ht : t<j) (i:I) (a:Fin B) :
    record ν V η q ρ anchor geometry value n j s h r (.inr (.inl (t,i,a)))=
      r (.inr (.inl (t,i,a))) := by
  induction n generalizing j s r with
  | zero => simp [record,afterGhost,ne_of_lt ht]
  | succ n ih =>
      rw [record,ih _ _ h.2.2 _ (by omega)]
      simp [afterEdge,afterGhost,ne_of_lt ht]

/-- The registry never overwrites fresh edge values at earlier visits. -/
theorem record_pastEdge (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (t : ℕ) (ht : t<j) (i:I) :
    record ν V η q ρ anchor geometry value n j s h r (.inr (.inr (t,i)))=
      r (.inr (.inr (t,i))) := by
  induction n generalizing j s r with
  | zero => rfl
  | succ n ih =>
      rw [record,ih _ _ h.2.2 _ (by omega)]
      simp [afterEdge,afterGhost,ne_of_lt ht]

/-- The final registry records the same actual ghost values as the logger. -/
theorem record_ghostAt (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (k:Fin (n+1)) (i:I) (a:Fin B) :
    record ν V η q ρ anchor geometry value n j s h r (.inr (.inl (j+k.val,i,a)))=
      (ActualHistoryBirths.ghostAt ν V η q ρ anchor geometry n j s h k i a).map (value i) := by
  induction n generalizing j s r with
  | zero => have hk : k=0 := Fin.ext (by omega); subst k; simp [record,afterGhost,ActualHistoryBirths.ghostAt]
  | succ n ih =>
      refine Fin.cases ?_ (fun k=>?_) k
      · simp only [Fin.val_zero,Nat.add_zero,record]
        rw [record_pastGhost ν V η q ρ anchor geometry value n (j+1) _ h.2.2 _ j (by omega)]
        simp [afterEdge,afterGhost,ActualHistoryBirths.ghostAt]
      · have hj : j+k.succ.val=(j+1)+k.val := by simp; omega
        rw [hj,record,ih]
        simp only [ActualHistoryBirths.ghostAt,Fin.cases_succ]

/-- The final registry records the same actual fresh/promoted flag as the logger. -/
theorem record_freshAt (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (ActualHistoryBirths.operations ν V η q ρ anchor geometry j n) s)
    (r : Registry I J B) (k:Fin n) (i:I) :
    record ν V η q ρ anchor geometry value n j s h r (.inr (.inr (j+k.val,i)))=
      (ActualHistoryBirths.freshAt ν V η q ρ anchor geometry n j s h k i).map (value i) := by
  induction n generalizing j s r with
  | zero => exact Fin.elim0 k
  | succ n ih =>
      refine Fin.cases ?_ (fun k=>?_) k
      · simp only [Fin.val_zero,Nat.add_zero,record]
        rw [record_pastEdge ν V η q ρ anchor geometry value n (j+1) _ h.2.2 _ j (by omega)]
        simp [afterEdge,ActualHistoryBirths.freshAt]
      · have hj : j+k.succ.val=(j+1)+k.val := by simp; omega
        rw [hj,record,ih]
        simp only [ActualHistoryBirths.freshAt,Fin.cases_succ]

/-- Exact equality to the existing finite actual-history birth log. -/
theorem record_eq_labels (N : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (a : ActualHistoryBirths.Address I J B N) :
    record ν V η q ρ anchor geometry value N 0 s h (initial value s) (embed a)=
      ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h a := by
  rcases a with a|(a|a)
  · exact record_initial ν V η q ρ anchor geometry value N 0 s h (initial value s) a
  · simpa only [embed,Nat.zero_add,ActualHistoryBirths.labels] using
      record_ghostAt ν V η q ρ anchor geometry value N 0 s h (initial value s) a.1 a.2.1 a.2.2
  · simpa only [embed,Nat.zero_add,ActualHistoryBirths.labels] using
      record_freshAt ν V η q ρ anchor geometry value N 0 s h (initial value s) a.1 a.2

end Elliptic.Operator.PhysicalBirthRegistry
