module

public import Elliptic.Operator.PhysicalMaskedSchur
public import Elliptic.Operator.PhysicalDirtyRow
public import Elliptic.Operator.PhysicalFreshRow
public import Elliptic.Operator.SourceRawSymmetry

/-!
# Actual raw masked matrix rows

The exact raw geometric indicator and bounded amplitude convert the
proved indexed counting estimates into rows of the actual physical bag
matrix. Mask membership is read from the literal physical choices.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRawMaskedRow
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
local instance rawMaskedRowDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 400000

variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable [Fintype Z] [∀ i, Fintype (P i)]
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable [∀ i p, Fintype (ZMod (value i p))]
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)

/-- The literal source anchor used throughout the physical row. -/
def anchor (z : Z) (i : Fin K) (p : P i) := primeResidueAnchor (value i p) (position z)

/-- The actual raw subrow selected by both Boolean masks. -/
def choices (S I : Fin K → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) : Finset (PhysicalEdgeChoice s) :=
  Finset.univ.filter (fun c => PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c ∧
    ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i)

/-- The raw amplitude estimate retains exactly the actual indexed mask
support. It does not replace that support by a Cartesian product. -/
theorem choiceRow_le_raw
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (S I : Fin K → Bool) (ρ v0 A : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0)
    (hamp : ∀ z a w b, sourceRawAllowed value good u v r U W d₀ σ z a w b → ‖amplitude z a w b‖ ≤ A) :
    choiceRow ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) a (position w) b) s ≤
    A * (endpointPermutationWeight (Fin K) J *
      ∑ c ∈ choices value position s S I good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) := by
  unfold choiceRow choices
  simp only [Finset.sum_filter,Finset.mul_sum]
  conv_lhs =>
    arg 1
    equals (Finset.univ : Finset (PhysicalEdgeChoice s)) =>
      ext c
      simp only [Finset.mem_univ]
  apply Finset.sum_le_sum
  intro c _
  by_cases hc : c.Valid (anchor value position) s
  · rw [dite_eq_left hc]
    by_cases hm : ∀ i, (c.group i).1=S i ∧ edgeChoicePromotes (c.group i)=I i
    · rw [ite_eq_left hm]
      by_cases hg : sourceRawAllowed value good u v r U W d₀ σ
          (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) c.sourceLists
          (position c.target) c.targetLists
      · have hr : PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c := ⟨hc,hg.1,hg.2⟩
        rw [ite_eq_left ⟨hr,hm⟩]
        rw [physicalEdgeChoiceWeight_norm_mul_ratio ν V ρ v0 _ _ s c hc hν hV hρ]
        simp only [sourceRawGeometry,ite_eq_left hg]
        have hw := PhysicalDirtyWeighted.choiceWeight_nonneg value position s ν V ρ v0 c hν hV hρ hv0
        change endpointPermutationWeight (Fin K) J * ‖amplitude _ _ _ _‖ *
          PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c ≤ _
        calc
          _ ≤ endpointPermutationWeight (Fin K) J * A *
              PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c := by
            exact mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left (hamp _ _ _ _ hg)
                (by unfold endpointPermutationWeight; positivity)) hw
          _ = _ := by ring
      · have hr : ¬PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c :=
          fun h => hg ⟨h.2.1,h.2.2⟩
        rw [ite_eq_right (fun h => hr h.1)]
        simp only [physicalEdgeChoiceWeight,sourceRawGeometry,ite_eq_right hg,mul_zero,zero_mul,norm_zero]
        exact le_rfl
    · rw [ite_eq_right hm,ite_eq_right (fun h => hm h.2)]
      simp
  · have hr : ¬PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c := fun h => hc h.1
    rw [dite_eq_right hc,ite_eq_right (fun h => hr h.1)]
    simp

/-- A nonempty promotion mask makes every selected choice genuinely dirty. -/
theorem choices_subset_dirty (S I : Fin K → Bool) (hI : ∃ i, I i=true)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) :
    choices value position s S I good u v r U W d₀ σ ⊆
      PhysicalDirtyPartition.rawDirtyChoices value position s good u v r U W d₀ σ := by
  intro c hc
  obtain ⟨hr,hm⟩ := (Finset.mem_filter.mp hc).2
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _,hr,?_⟩
  obtain ⟨i,hi⟩ := hI
  refine ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩⟩
  have hp : edgeChoicePromotes (c.group i)=true := (hm i).2.trans hi
  cases he : (c.group i).2 with
  | inl a => exact ⟨a,rfl⟩
  | inr p => simp [edgeChoicePromotes,he] at hp

/-- An empty promotion mask means no old particle is promoted. Stores
remain unrestricted by this assertion. -/
theorem choices_no_promotion (S I : Fin K → Bool) (hI : ∀ i, I i=false)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (c : PhysicalEdgeChoice s)
    (hc : c ∈ choices value position s S I good u v r U W d₀ σ) : c.promotedGroups=∅ := by
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro i hi
  obtain ⟨a,ha⟩ := (Finset.mem_filter.mp hi).2
  have hp := ((Finset.mem_filter.mp hc).2.2 i).2
  simp [edgeChoicePromotes,ha,hI i] at hp

/-- The actual bag row has the same literal raw masked bound. -/
theorem bag_row_le_raw
    (ν : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool) (ρ v0 A : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0)
    (hamp : ∀ z a w b, sourceRawAllowed value good u v r U W d₀ σ z a w b → ‖amplitude z a w b‖ ≤ A) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) a (position w) b)
      (ofOrdered s) ≤
    A * (endpointPermutationWeight (Fin K) J *
      ∑ c ∈ choices value position s S I good u v r U W d₀ σ,
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) :=
  (row_le_choices_named ν (fun i p => (hνpos i p).ne') V S I ρ v0 hv0 _ _ s).trans
    (choiceRow_le_raw value position s ν V S I ρ v0 A good u v r U W d₀ σ amplitude
      (fun i p => (hνpos i p).le) hV hρ hv0 hamp)

/-- The sharp actual promotion bound for a specified mask. -/
theorem promotion_row_le
    (hposition : Function.Injective position) (hprime : ∀ i p, (value i p).Prime)
    (ν μ : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool) (hI : ∃ i, I i=true)
    (ρ v0 vmin M L A : ℝ) (a : Fin K → ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U) (hσ : σ=1 ∨ σ= -1)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w=1)
    (hgood : SourceSecondGoodState.SecondGoodTest value
      (physicalSourceLabels value (s.active P (fun i p => Option (ZMod (value i p))) J B)) μ d₀
      (latticeTau r w/latticeTau r (position (s.position P (fun i p => Option (ZMod (value i p))) J B))) L a)
    (hband : ∀ i p, Real.exp (L^a i) ≤ (value i p:ℝ))
    (hνμ : ∀ i p, ν i p ≤ 2*μ i p) (hV : ∀ i, vmin ≤ V i) (hmin : 0 < vmin)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z a w b, sourceRawAllowed value good u v r U W d₀ σ z a w b → ‖amplitude z a w b‖ ≤ A) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) a (position w) b)
      (ofOrdered s) ≤
    A * (PhysicalDirtyRow.separatedBudget K J B ρ v0 vmin M +
      PhysicalDirtyRow.exceptionalBudget K B ρ v0 vmin L a) := by
  apply (bag_row_le_raw value position s ν hνpos V S I ρ v0 A good u v r U W d₀ σ amplitude
    (fun i => (hmin.trans_le (hV i)).le) hρ0 hv0.le hamp).trans
  apply mul_le_mul_of_nonneg_left _ hA
  calc
    _ ≤ endpointPermutationWeight (Fin K) J *
        ∑ c ∈ PhysicalDirtyPartition.rawDirtyChoices value position s good u v r U W d₀ σ,
          PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c := by
      apply mul_le_mul_of_nonneg_left _ (by unfold endpointPermutationWeight; positivity)
      apply Finset.sum_le_sum_of_subset_of_nonneg
        (choices_subset_dirty value position s S I hI good u v r U W d₀ σ)
      intro c _ _
      exact PhysicalDirtyWeighted.choiceWeight_nonneg value position s ν V ρ v0 c
        (fun i p => (hνpos i p).le) (fun i => (hmin.trans_le (hV i)).le) hρ0 hv0.le
    _ ≤ _ := PhysicalDirtyRow.raw_promotion_row_le_source value position s hposition hprime ν μ V
      ρ v0 vmin M L a good u v r U W d₀ σ hU hσ w hzw hgood hband
      (fun i p => (hνpos i p).le) hνμ hV hmin hρ0 hρ1 hv0 hmass

/-- The no-promotion mask has a bound independent of the memory cutoff,
including any specified store mask. -/
theorem fresh_row_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (hνpos : ∀ i p, 0 < ν i p)
    (V : Fin K → ℝ) (S I : Fin K → Bool) (hI : ∀ i, I i=false)
    (ρ v0 M A : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (amplitude : (ℤ × ℤ) → PhysicalActiveLists P J → (ℤ × ℤ) → PhysicalActiveLists P J → ℂ)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w=1)
    (hV : ∀ i, 0 ≤ V i) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) (hA : 0 ≤ A)
    (hmass : ∀ i, (∑ p, ν i p) ≤ M)
    (hamp : ∀ z a w b, sourceRawAllowed value good u v r U W d₀ σ z a w b → ‖amplitude z a w b‖ ≤ A) :
    row ν V S I ρ v0 (anchor value position)
      (fun z a w b => sourceRawGeometry value good u v r U W d₀ σ amplitude (position z) a (position w) b)
      (ofOrdered s) ≤ A * (33*((1+v0)*M)^K) := by
  apply (bag_row_le_raw value position s ν hνpos V S I ρ v0 A good u v r U W d₀ σ amplitude
    hV hρ0 hv0.le hamp).trans
  apply mul_le_mul_of_nonneg_left _ hA
  apply PhysicalFreshRow.no_promotion_row_le value position s hposition ν V ρ v0 M
    good u v r U W d₀ σ hU w hzw
    (choices value position s S I good u v r U W d₀ σ)
  · intro c hc
    exact (Finset.mem_filter.mp hc).2.1
  · exact choices_no_promotion value position s S I hI good u v r U W d₀ σ
  · exact fun i p => (hνpos i p).le
  · exact hV
  · exact hρ0
  · exact hρ1
  · exact hv0
  · exact hmass

end Elliptic.Operator.PhysicalRawMaskedRow
