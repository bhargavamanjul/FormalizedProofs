module

public import Elliptic.Operator.PhysicalPhasedEdgeNorm
public import Elliptic.Operator.PhysicalBagNorm

/-! The actual birth-phased edge estimate in the original factorial norm.
The only bridge is the proved pushforward measure and total-memory cutoff. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdgeOrderedNorm
open scoped BigOperators
open PhysicalPhasedWord PhysicalBirthFactors PhysicalBagNorm PhysicalMaskedKernel PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B : ℕ}
variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (ρ : ℝ) (anchor : Z→∀i p,Line i p)
variable (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
variable (value : ∀i,P i→ℕ)

 theorem kernel_row_zero (E : I→Option ℕ→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) (hs : ¬Total s) :
    PhysicalPhasedEdge.kernel value ν V ρ anchor geometry E s t=0 := by
  simp [PhysicalPhasedEdge.kernel,originalKernel,PhysicalMaskedKernel.kernel,hs]

 theorem phasedApply_l2_of_kernel_bound (hν : ∀i p,ν i p≠0) (E : I→Option ℕ→ℂ) (C : ℝ)
    (hbound : ∀f : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ,
      finiteL2 Finset.univ (mass ν)
        (fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ anchor geometry E s t*f t)≤
      C*finiteL2 Finset.univ (mass ν) f)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
        (fun _ c=>edgeFactor value (fun _=>E) 0 c) F)≤
    C*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
  obtain ⟨f,rfl⟩ := hF
  have hp : (fun s=>f (ofOrdered s))=(fun s=>cutoff f (ofOrdered s)) := by
    funext s;exact (cutoff_ofOrdered f s).symm
  rw [hp]
  have he := PhysicalPhasedEdge.phasedApply_eq_kernel value ν V ρ anchor geometry hν E (cutoff f)
  have he' : phasedApply (physicalEdgeOperation ν V ρ anchor geometry)
      (fun _ c=>edgeFactor value (fun _=>E) 0 c) (fun s=>cutoff f (ofOrdered s)) =
      (fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ anchor geometry E (ofOrdered s) t*cutoff f t) :=
    funext he
  rw [he']
  let g : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ :=
    fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ anchor geometry E s t*cutoff f t
  have hg : ∀s,¬Total s→g s=0 := by
    intro s hs
    simp only [g,kernel_row_zero ν V ρ anchor geometry value E s _ hs,zero_mul,Finset.sum_const_zero]
  change finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) (fun s=>g (ofOrdered s))≤_
  rw [pullback_norm_eq ν g hg,pullback_norm ν (cutoff f)]
  have hcut : cutoff (cutoff f)=cutoff f := by funext s;by_cases hs : Total s <;> simp [cutoff,hs]
  rw [hcut]
  exact hbound (cutoff f)

end Elliptic.Operator.PhysicalPhasedEdgeOrderedNorm
