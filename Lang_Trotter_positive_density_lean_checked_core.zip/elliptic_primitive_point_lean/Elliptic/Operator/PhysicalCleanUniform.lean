module

public import Elliptic.Operator.PhysicalCleanOperator

/-! One scalar asymptotic budget absorbs both the proved local clean
estimate and the fixed number of actual physical slope offsets. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanUniform
open Filter
open scoped BigOperators SchwartzMap
set_option backward.isDefEq.respectTransparency false

variable {I : Type*} [Fintype I]

/-- The local saving with exponent `G+1` absorbs the actual fixed offset
count. The major-arc exponent `G+5` is independent of the number of bands. -/
theorem eventually_budget
    (Cweight : I → ℝ) (hCweight : ∀ i, 0≤Cweight i)
    (ψ : 𝓢(ℝ,ℂ)) (C Aψ Cmass Catom G : ℝ)
    (hC : 0≤C) (hAψ : 0≤Aψ) (hmass : 1≤Cmass) (hatom : 0≤Catom) (hG : 0≤G) :
    ∀ᶠ L : ℝ in atTop,
      1≤L^(G+5) ∧ 0≤L^(-(G+1)) ∧
      ((2*⌈512*C+1⌉₊+1:ℕ):ℝ)*L^(-(G+1))≤L^(-G) ∧
      ∀ (groups : I → Finset ℕ) (Y : ℝ) (A B : ℕ),
        Real.exp (L^(1/10:ℝ))≤Y → Y≤Real.exp L →
        Y^(1/5:ℝ)≤A → Y^(1/5:ℝ)≤B →
        (A:ℝ)*B≤72*(256*((⌈512*C+1⌉₊:ℝ)+1))^2*Y →
        PhysicalCleanOperator.budget groups Cweight ψ ((⌈512*C+1⌉₊:ℝ)+1)
          (L^(G+5)) Y Aψ Cmass (Catom*Real.exp (-L^(1/10:ℝ))) 1 A B
          ≤L^(-(G+1)) := by
  let Cgeo : ℝ := 72*(256*((⌈512*C+1⌉₊:ℝ)+1))^2
  let N : ℕ := 2*⌈512*C+1⌉₊+1
  have hcell : 1≤((⌈512*C+1⌉₊:ℝ)+1) := by
    have hceil := Nat.le_ceil (512*C+1)
    linarith
  have hgeo : 1≤Cgeo := by dsimp [Cgeo]; nlinarith
  have hweight : 0≤∏ i, Cweight i := Finset.prod_nonneg (fun i _ => hCweight i)
  have hlocal := eventually_banned_clean_saving ψ Cgeo (∏ i, Cweight i)
    Aψ Cmass Catom (G+1) (Fintype.card I) hgeo hweight hAψ (by linarith) hatom (by linarith)
  filter_upwards [hlocal,eventually_ge_atTop (2:ℝ),eventually_ge_atTop (N:ℝ)] with L hlocal hL hN
  have hL0 : 0<L := by linarith
  have hpow : L^(-(G+1))=L^(-G)/L := by
    rw [show -(G+1)= -G + (-1) by ring,Real.rpow_add hL0,Real.rpow_neg_one]
    ring
  refine ⟨Real.one_le_rpow (by linarith) (by linarith),Real.rpow_nonneg hL0.le _,?_,?_⟩
  · change (N:ℝ)*L^(-(G+1))≤L^(-G)
    rw [hpow,← mul_div_assoc]
    apply (div_le_iff₀ hL0).mpr
    have hp : 0≤L^(-G) := Real.rpow_nonneg hL0.le _
    nlinarith
  · intro groups Y A B hlo hhi hA hB harea
    have h := hlocal Y A B hlo hhi hA hB harea
    simpa only [PhysicalCleanOperator.budget,Cgeo,show G+1+4=G+5 by ring] using h

end Elliptic.Operator.PhysicalCleanUniform
