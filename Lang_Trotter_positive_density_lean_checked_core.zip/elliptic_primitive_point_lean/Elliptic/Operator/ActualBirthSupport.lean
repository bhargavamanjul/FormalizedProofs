module

public import Elliptic.Operator.GroupedMemoryGhost
public import Elliptic.Operator.MemoryOutputBags

/-!
# Prime support of actual physical transitions

The invariant in this file is stated on the literal active and pending
prime labels. It uses no lifespan schedule or reconstruction premise.
Ghost deletions, promotions, and stores preserve joint distinctness;
only genuinely fresh draws require a disjointness hypothesis.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator

local instance actualBirthSupportDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α

variable {P : Type*} {Line : P → Type*} {J B : ℕ}

/-- Active labels and pending labels, taken together, have no repetition. -/
def ActivePendingDistinct (a : Fin (J+1) → P)
    (m : MemoryState (AnchoredParticle P Line) B) : Prop :=
  Function.Injective a ∧ Function.Injective (fun j => (m.values j).1) ∧
    ∀ j k, a j ≠ (m.values k).1

/-- Projecting an actual appended particle tuple gives the appended prime tuples. -/
theorem append_particle_primes {k n : ℕ}
    (u : Fin k → AnchoredParticle P Line) (v : Fin n → AnchoredParticle P Line) :
    (fun j => (Fin.append u v j).1) =
      Fin.append (fun j => (u j).1) (fun j => (v j).1) := by
  funext j
  exact Fin.addCases (fun _ => by simp) (fun _ => by simp) j

theorem survivor_prime_injective
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size))
    (hm : Function.Injective (fun j => (m.values j).1)) :
    Function.Injective (fun j => (ghostSurvivors m S j).1) := by
  exact hm.comp (Sᶜ.orderEmbOfFin rfl).injective

/-- A ghost step retains joint distinctness under local conditions on its
actual fresh batch. Deleted old primes are permitted to be among the excluded
old support; thus the condition is strong enough for global birth uniqueness. -/
theorem ghostOutput_activePendingDistinct
    (anchor : ∀ p, Line p) (a : Fin (J+1) → P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c)
    (h : ActivePendingDistinct a m)
    (hfresh : Function.Injective c.2.values)
    (hactive : ∀ j k, a j ≠ c.2.values k)
    (hpending : ∀ j k, (m.values j).1 ≠ c.2.values k) :
    ActivePendingDistinct a (ghostOutput anchor m c hc) := by
  refine ⟨h.1, ?_, ?_⟩
  · change Function.Injective (fun j =>
      (Fin.append (ghostSurvivors m c.1)
        (fun k => anchorPrime anchor (c.2.values k)) j).1)
    rw [append_particle_primes]
    apply Fin.append_injective_iff.mpr
    exact ⟨survivor_prime_injective m c.1 h.2.1, hfresh,
      fun j k => hpending _ k⟩
  · intro j k
    change a j ≠ (Fin.append (ghostSurvivors m c.1)
      (fun l => anchorPrime anchor (c.2.values l)) k).1
    exact Fin.addCases (fun l => by simpa only [Fin.append_left, ghostSurvivors] using h.2.2 j _)
      (fun l => by simpa only [Fin.append_right, anchorPrime] using hactive j l) k

/-- Ghost support records actual undeleted old indices and actual fresh
values, and therefore retains correct multiplicities at the choice level. -/
theorem ghostOutput_prime_exists_iff
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c) (p : P) :
    (∃ j, ((ghostOutput anchor m c hc).values j).1 = p) ↔
      (∃ k, k ∉ c.1 ∧ (m.values k).1 = p) ∨
        (∃ k, c.2.values k = p) := by
  constructor
  · rintro ⟨j,hj⟩
    change (Fin.append (ghostSurvivors m c.1)
      (fun k => anchorPrime anchor (c.2.values k)) j).1 = p at hj
    revert hj
    refine Fin.addCases (fun k hk => ?_) (fun k hk => ?_) j
    · refine Or.inl ⟨c.1ᶜ.orderEmbOfFin rfl k, ?_, ?_⟩
      · exact Finset.mem_compl.mp (Finset.orderEmbOfFin_mem _ _ _)
      · simpa only [Fin.append_left, ghostSurvivors] using hk
    · exact Or.inr ⟨k, by simpa only [Fin.append_right, anchorPrime] using hk⟩
  · rintro (⟨k,hk,hp⟩ | ⟨k,hp⟩)
    · obtain ⟨j,hj⟩ := (ghostSurvivors_exists_iff m c.1 (m.values k)).mpr ⟨k,hk,rfl⟩
      refine ⟨j.castAdd c.2.size, ?_⟩
      change (Fin.append (ghostSurvivors m c.1)
        (fun k => anchorPrime anchor (c.2.values k)) (j.castAdd c.2.size)).1 = p
      rw [Fin.append_left, hj]
      exact hp
    · refine ⟨k.natAdd c.1ᶜ.card, ?_⟩
      change (Fin.append (ghostSurvivors m c.1)
        (fun k => anchorPrime anchor (c.2.values k)) (k.natAdd c.1ᶜ.card)).1 = p
      simpa only [Fin.append_right, anchorPrime] using hp

/-- With empty pending memory, the joint invariant is exactly active
injectivity. This supplies the actual initial-state condition. -/
theorem activePendingDistinct_empty_iff (a : Fin (J+1) → P) :
    ActivePendingDistinct a (MemoryState.empty (AnchoredParticle P Line) B) ↔
      Function.Injective a := by
  constructor
  · exact fun h => h.1
  · intro h
    refine ⟨h, ?_, ?_⟩
    · intro j
      exact Fin.elim0 j
    · intro j k
      exact Fin.elim0 k

/-- The prime at a promoted old index differs from every surviving pending
prime. No source/target disjointness assumption is required for this fact. -/
theorem edgeTargetPrime_ne_survivor
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hm : Function.Injective (fun j => (m.values j).1))
    (hfresh : ∀ p, c.2 = Sum.inr p → ∀ k, p ≠ (m.values k).1)
    (j : Fin (edgePromotedIndices c)ᶜ.card) :
    edgeTargetPrime m c ≠ (ghostSurvivors m (edgePromotedIndices c) j).1 := by
  rcases c with ⟨store, k | p⟩
  · intro he
    have he' : k = (edgePromotedIndices (store, Sum.inl k))ᶜ.orderEmbOfFin rfl j :=
      hm he
    have hn := Finset.mem_compl.mp
      (Finset.orderEmbOfFin_mem (edgePromotedIndices (store, Sum.inl k))ᶜ rfl j)
    simp only [edgePromotedIndices, Finset.mem_singleton] at hn
    exact hn he'.symm
  · exact hfresh p rfl _

/-- Literal support of the pending output, after forgetting retained lines. -/
theorem edgeGroupOutput_prime_exists_iff
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) (p : P) :
    (∃ j, ((edgeGroupOutput anchor source m c hc).values j).1 = p) ↔
      (∃ k, k ∉ edgePromotedIndices c ∧ (m.values k).1 = p) ∨
        (c.1 = true ∧ source = p) := by
  constructor
  · rintro ⟨j, hj⟩
    have h := (edgeGroupOutput_exists_iff anchor source m c hc
      ((edgeGroupOutput anchor source m c hc).values j)).mp ⟨j,rfl⟩
    rcases h with ⟨k,hk,he⟩ | ⟨hs,he⟩
    · exact Or.inl ⟨k,hk,(congrArg Sigma.fst he).trans hj⟩
    · exact Or.inr ⟨hs,(congrArg Sigma.fst he).trans hj⟩
  · rintro (⟨k,hk,hp⟩ | ⟨hs,hp⟩)
    · obtain ⟨j,hj⟩ := (edgeGroupOutput_exists_iff anchor source m c hc (m.values k)).mpr
        (Or.inl ⟨k,hk,rfl⟩)
      exact ⟨j,(congrArg Sigma.fst hj).trans hp⟩
    · obtain ⟨j,hj⟩ := (edgeGroupOutput_exists_iff anchor source m c hc
        (anchorPrime anchor source)).mpr (Or.inr ⟨hs,rfl⟩)
      exact ⟨j,(congrArg Sigma.fst hj).trans hp⟩

/-- A physical edge has distinct pending prime labels whenever the source
active prime was disjoint from the old pending support. -/
theorem edgeGroupOutput_prime_injective
    (anchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B)
    (hm : Function.Injective (fun j => (m.values j).1))
    (hsource : ∀ j, source ≠ (m.values j).1) :
    Function.Injective (fun j => ((edgeGroupOutput anchor source m c hc).values j).1) := by
  change Function.Injective (fun j =>
    (Fin.append (ghostSurvivors m (edgePromotedIndices c))
      (fun _ : Fin c.1.toNat => anchorPrime anchor source) j).1)
  rw [append_particle_primes]
  apply Fin.append_injective_iff.mpr
  refine ⟨survivor_prime_injective m _ hm, ?_, ?_⟩
  · intro j k _
    apply Fin.ext
    have hj := j.isLt
    have hk := k.isLt
    have hb : c.1.toNat ≤ 1 := by cases c.1 <;> decide
    omega
  · intro j _ he
    exact hsource _ he.symm

/-- An edge preserves joint active/pending distinctness. Promotion only moves
an existing label; a store only moves the departed source label. The only
new disjointness condition is imposed on a genuinely fresh target draw. -/
theorem edgeGroupOutput_activePendingDistinct
    (anchor : ∀ p, Line p) (a : Fin (J+1) → P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) (h : ActivePendingDistinct a m)
    (hfresh : ∀ p, c.2 = Sum.inr p →
      (∀ j, p ≠ a j) ∧ (∀ k, p ≠ (m.values k).1)) :
    ActivePendingDistinct
      (Fin.lastCases (edgeTargetPrime m c) (fun j => a j.castSucc))
      (edgeGroupOutput anchor (a (Fin.last J)) m c hc) := by
  have htarget : ∀ j, edgeTargetPrime m c ≠ a j := by
    intro j
    rcases c with ⟨store, k | p⟩
    · exact (h.2.2 j k).symm
    · exact (hfresh p rfl).1 j
  have htargetMem := edgeTargetPrime_ne_survivor m c h.2.1
    (fun p hp => (hfresh p hp).2)
  refine ⟨?_, edgeGroupOutput_prime_injective anchor _ m c hc h.2.1 (h.2.2 _), ?_⟩
  · intro j k
    refine Fin.lastCases ?_ (fun j' => ?_) j <;>
      refine Fin.lastCases ?_ (fun k' => ?_) k
    · intro _; rfl
    · intro he
      exact False.elim (htarget _ (by simpa using he))
    · intro he
      exact False.elim (htarget _ (by simpa using he.symm))
    · intro he
      exact h.1 (by simpa using he)
  · intro j k
    change Fin.lastCases (edgeTargetPrime m c) (fun j => a j.castSucc) j ≠
      (Fin.append (ghostSurvivors m (edgePromotedIndices c))
        (fun _ : Fin c.1.toNat => anchorPrime anchor (a (Fin.last J))) k).1
    refine Fin.lastCases ?_ (fun j' => ?_) j <;>
      refine Fin.addCases (fun k' => ?_) (fun k' => ?_) k
    · simpa only [Fin.lastCases_last, Fin.append_left] using htargetMem k'
    · simpa only [Fin.lastCases_last, Fin.append_right, anchorPrime] using htarget (Fin.last J)
    · simpa only [Fin.lastCases_castSucc, Fin.append_left, ghostSurvivors] using h.2.2 j'.castSucc
        ((edgePromotedIndices c)ᶜ.orderEmbOfFin rfl k')
    · intro he
      have hx := h.1 (by simpa [anchorPrime] using he)
      exact Fin.castSucc_ne_last j' hx

namespace PhysicalMemoryState

variable {I Z : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- Each actual physical group has distinct active and pending prime labels. -/
def LiveDistinct (s : PhysicalMemoryState (Z:=Z) P Line J B) : Prop :=
  ∀ i, ActivePendingDistinct (s.active P Line J B i) (s.memory P Line J B i)

end PhysicalMemoryState

variable {I Z : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- Actual grouped ghost output preserves the joint support invariant. -/
theorem PhysicalGhostChoice.output_liveDistinct
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (hs : s.LiveDistinct)
    (hfresh : ∀ i, Function.Injective (c i).2.values)
    (hactive : ∀ i j k, s.active P Line J B i j ≠ (c i).2.values k)
    (hpending : ∀ i j k, ((s.memory P Line J B i).values j).1 ≠ (c i).2.values k) :
    (c.output anchor s hc).LiveDistinct := by
  intro i
  exact ghostOutput_activePendingDistinct _ _ _ _ (hc.1 i) (hs i)
    (hfresh i) (hactive i) (hpending i)

/-- Actual physical edge output, including both endpoint permutations,
preserves joint support distinctness. Only a genuinely fresh draw must avoid
old active and pending labels; no prescribed schedule is used. -/
theorem PhysicalEdgeChoice.output_liveDistinct
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (hs : s.LiveDistinct)
    (hfresh : ∀ i p, (c.group i).2 = Sum.inr p →
      (∀ j, p ≠ s.active P Line J B i j) ∧
      (∀ k, p ≠ ((s.memory P Line J B i).values k).1)) :
    (c.output anchor s hc).LiveDistinct := by
  intro i
  have hsource : ActivePendingDistinct (c.sourceLists i) (s.memory P Line J B i) :=
    ⟨(hs i).1.comp (c.sourcePerm i).injective, (hs i).2.1,
      fun j k => (hs i).2.2 _ k⟩
  have hout := edgeGroupOutput_activePendingDistinct
    (anchor (s.position P Line J B) i) (c.sourceLists i)
    (s.memory P Line J B i) (c.group i) (hc.1 i).2 hsource
    (fun p hp => ⟨fun j => (hfresh i p hp).1 _, (hfresh i p hp).2⟩)
  exact ⟨hout.1.comp (c.targetPerm i).injective, hout.2.1,
    fun j k => hout.2.2 _ k⟩

end Elliptic.Operator
