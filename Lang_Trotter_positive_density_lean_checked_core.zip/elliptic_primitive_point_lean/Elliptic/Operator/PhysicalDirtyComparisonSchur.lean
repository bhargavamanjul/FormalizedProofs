module

public import Elliptic.Operator.PhysicalComparisonSchur
public import Elliptic.Operator.PhysicalDirtyMasks
public import Elliptic.Operator.FiniteOperatorSum

/-! Full literal dirty comparison operator: finite mask summation after
the retained-line Schur saving, with no signed or weighted-row assumption. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyComparisonSchur
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalComparisonMaskedRow PhysicalMaskScaling
open PhysicalComparisonSchur PhysicalDirtyMasks
attribute [local instance] Classical.propDecidable
local instance dirtyComparisonSchurDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {K J B : ℕ} {Z : Type} {P : Fin K→Type}
variable [Fintype Z] [∀i,Fintype (P i)]
variable (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
variable [∀i p,Fintype (ZMod (value i p))]

/-- Explicit combined two-sided comparison mask budget. -/
def allMaskBudget (B : ℕ) (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (v0 A Y C R : ℝ) : ℝ :=
  Real.sqrt (((dirtyMasks (G:=Fin K)).card:ℝ)*∑m∈dirtyMasks,
    (Real.sqrt ((A*(countFactor Y C R m.2*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))*
      (reverseFactor V m.2 m.1*A*(countFactor Y C R m.1*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))))^2)

 theorem dirty_comparison_schur
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ)
    (ρ v0 A : ℝ) (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y C R : ℝ) (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hY : 1≤Y) (hC : 1≤C) (hR : 0<R)
    (hband : ∀i p,R≤(value i p:ℝ))
    (hg : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hV : ∀i,0<V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) (hA : 0≤A)
    (amplitude : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (hamp : ∀z a w b,sourceComparisonAllowed value good u v r U W d₀ Y C z a w b→‖amplitude z a w b‖≤A/Y)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s=>∑t,dirtyKernel ν V ρ (anchor value position)
        (fun z a w b=>sourceComparisonGeometry value good u v r U W d₀ Y C amplitude (position z) a (position w) b) s t*F t)≤
    allMaskBudget B ν V v0 A Y C R*finiteL2 Finset.univ (mass ν) F := by
  let f := fun (m : Mask (G:=Fin K)) s=>∑t,
    comparisonKernel value position ν V m.1 m.2 ρ good u v r U W d₀ Y C amplitude s t*F t
  have hm (m : Mask (G:=Fin K)) (_ : m∈dirtyMasks) := masked_comparison_schur value position
    hposition hprime ν hνpos V m.1 m.2 ρ v0 A good u v r U W d₀ Y C R hU hu hu'
    hd hY hC hR hband hg hV hρ0 hρ1 hv0 hA amplitude hamp F
  have hs := finiteL2_sum_le Finset.univ (dirtyMasks (G:=Fin K)) (mass ν)
    (fun s _=>(mass_pos ν hνpos s).le) f
    (fun m=>Real.sqrt ((A*(countFactor Y C R m.2*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))*
      (reverseFactor V m.2 m.1*A*(countFactor Y C R m.1*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))))
    (finiteL2 Finset.univ (mass ν) F) (Real.sqrt_nonneg _) (fun _ _=>Real.sqrt_nonneg _) hm
  apply (le_of_eq ?_).trans hs
  apply congrArg (finiteL2 Finset.univ (mass ν))
  funext s
  unfold dirtyKernel
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  unfold f comparisonKernel
  apply Finset.sum_congr
  · ext t
    simp only [Finset.mem_univ]
  · intro t ht
    rfl

end Elliptic.Operator.PhysicalDirtyComparisonSchur
