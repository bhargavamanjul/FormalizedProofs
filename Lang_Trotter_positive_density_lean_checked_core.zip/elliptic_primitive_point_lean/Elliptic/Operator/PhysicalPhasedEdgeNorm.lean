module

public import Elliptic.Operator.PhysicalPhasedEdge
public import Elliptic.Operator.PhysicalDirtySignedSchur

/-! Crude norm bound for the literal birth-phased signed physical edge.
All masks, including the clean mask, are bounded through raw/comparison
Schur estimates. Bounded phases therefore require no clean cancellation. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdgeNorm
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedSchur PhysicalDirtyMasks PhysicalMaskScaling
open PhysicalPhasedEdge PhysicalRawGlobalRow
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 800000
variable {K J B : ℕ} {Z : Type} {P : Fin K→Type}
variable [Fintype Z] [∀i,Fintype (P i)]
variable (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
variable [∀i p,Fintype (ZMod (value i p))]

 def rawCost (K J B : ℕ) (V : Fin K→ℝ) (ρ v0 vmin M L A : ℝ)
    (a : Fin K→ℝ) (S I : Fin K→Bool) : ℝ :=
  Real.sqrt ((A*budget K J B ρ v0 vmin M L a I)*
    (reverseFactor V I S*A*budget K J B ρ v0 vmin M L a S))

 def comparisonCost (B : ℕ) (ν : ∀i,P i→ℝ) (V : Fin K→ℝ)
    (v0 A Y C R : ℝ) (S I : Fin K→Bool) : ℝ :=
  Real.sqrt ((A*(PhysicalComparisonMaskedRow.countFactor Y C R I*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0))*
    (reverseFactor V I S*A*(PhysicalComparisonMaskedRow.countFactor Y C R S*PhysicalChoiceFiberWeight.budget (B:=B) ν V v0)))

 def maskCost (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (ρ v0 vmin M L A H Y C R : ℝ)
    (a : Fin K→ℝ) (m : Mask (G:=Fin K)) : ℝ :=
  Real.sqrt (2*((rawCost K J B V ρ v0 vmin M L A a m.1 m.2)^2+
    (comparisonCost B ν V v0 (4*A*H^3) Y C R m.1 m.2)^2))

 theorem phased_masked_schur
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν μ : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ) (S I : Fin K→Bool)
    (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y H C R Aη Aψ : ℝ) (η ψ : ℝ→ℂ) (σ : ℤ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U) (hd : 0<d₀) (hY : 1≤Y)
    (hH : 0≤H) (hC : 1≤C) (hR : 0<R) (hσ : σ=1 ∨ σ= -1)
    (hη : ∀t,‖η t‖≤Aη) (hψ : ∀t,‖ψ t‖≤Aψ) (hψsupport : ∀t,ψ t≠0→|t|≤C)
    (hfirst : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hsecond : GoodProjection value μ d₀ r L a good)
    (hband : ∀i p,Real.exp (L^a i)≤(value i p:ℝ)) (hband' : ∀i p,R≤(value i p:ℝ))
    (hνμ : ∀i p,ν i p≤2*μ i p) (hV : ∀i,vmin≤V i) (hmin : 0<vmin)
    (hρ0 : 0≤ρ) (hρ1 : ρ<1) (hv0 : 0<v0) (hM : 0≤M) (hmass : ∀i,(∑p,ν i p)≤M)
    (E : Fin K→Option ℕ→ℂ) (hE : ∀i b,‖E i b‖≤1)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s=>∑t,originalKernel ν V S I ρ (PhysicalRawMaskedRow.anchor value position)
        (phaseGeometry value I E (fun z a w b=>sourcePhysicalEdgeGeometry value good
          u v r U W d₀ Y η ψ (sourceMajorArcs H Y) σ (position z) a (position w) b)) s t*F t)≤
    maskCost (J:=J) (B:=B) ν V ρ v0 vmin M L (Aη^2*Aψ) H Y C R a (S,I)*
      finiteL2 Finset.univ (mass ν) F := by
  have hψ0 := (norm_nonneg (ψ 0)).trans (hψ 0)
  have hA : 0≤Aη^2*Aψ := mul_nonneg (sq_nonneg _) hψ0
  have hVp : ∀i,0<V i := fun i=>hmin.trans_le (hV i)
  let rawAmp := fun (z : ℤ×ℤ) (b : PhysicalActiveLists P J) (w : ℤ×ℤ) (c : PhysicalActiveLists P J)=>targetFactor value I E c*sourceRawAmplitude value d₀ Y η ψ z b w c
  let compAmp := fun (z : ℤ×ℤ) (b : PhysicalActiveLists P J) (w : ℤ×ℤ) (c : PhysicalActiveLists P J)=>targetFactor value I E c*
    sourceComparisonAmplitude value d₀ Y η ψ (sourceMajorArcs H Y) σ z b w c
  let raw := fun z b w c=>sourceRawGeometry value good u v r U W d₀ σ rawAmp (position z) b (position w) c
  let comp := fun z b w c=>sourceComparisonGeometry value good u v r U W d₀ Y C compAmp (position z) b (position w) c
  have hr := PhysicalRawSchur.masked_raw_schur value position hposition hprime ν μ hνpos V S I
    ρ v0 vmin M L (Aη^2*Aψ) a good u v r U W d₀ σ hU hσ rawAmp hsecond hband hνμ
    hV hmin hρ0 hρ1 hv0 hM hA hmass (by
      intro z b w c ha
      dsimp [rawAmp]
      rw [norm_mul]
      apply (mul_le_mul_of_nonneg_right (targetFactor_norm_le value I E hE c) (norm_nonneg _)).trans
      rw [one_mul]
      exact sourceRawAmplitude_norm_le value good u v r U W d₀ Y σ η ψ Aη Aψ hd hη hψ z b w c ha) F
  have hc := PhysicalComparisonSchur.masked_comparison_schur value position hposition hprime ν hνpos V S I
    ρ v0 (4*(Aη^2*Aψ)*H^3) good u v r U W d₀ Y C R hU hu hu' hd hY hC hR hband' hfirst
    hVp hρ0 hρ1.le hv0 (by positivity) compAmp (by
      intro z b w c ha
      dsimp [compAmp]
      rw [norm_mul]
      apply (mul_le_mul_of_nonneg_right (targetFactor_norm_le value I E hE c) (norm_nonneg _)).trans
      rw [one_mul]
      exact (sourceComparisonAmplitude_norm_le value good u v r U W d₀ Y H η ψ Aη Aψ σ
        hd (by linarith) hH hη hψ z b w c ha.1).trans_eq (by ring)) F
  have hs := finiteL2_sub_le_of_le Finset.univ (mass ν) (fun s _=>(mass_pos ν hνpos s).le)
    (fun s=>∑t,originalKernel ν V S I ρ (PhysicalRawMaskedRow.anchor value position) raw s t*F t)
    (fun s=>∑t,originalKernel ν V S I ρ (PhysicalRawMaskedRow.anchor value position) comp s t*F t)
    _ _ (finiteL2 Finset.univ (mass ν) F) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) (Real.sqrt_nonneg _) hr hc
  apply (le_of_eq ?_).trans hs
  apply congrArg (finiteL2 Finset.univ (mass ν))
  funext s
  have he : phaseGeometry value I E (fun z a w b=>sourcePhysicalEdgeGeometry value good
      u v r U W d₀ Y η ψ (sourceMajorArcs H Y) σ (position z) a (position w) b) =
      (fun z b w c=>raw z b w c-comp z b w c) := by
    funext z b w c
    dsimp [phaseGeometry,raw,comp,rawAmp,compAmp]
    rw [sourcePhysicalGeometry_eq_raw_sub_comparison value good u v r U W d₀ Y C η ψ
      (sourceMajorArcs H Y) σ (by linarith) hψsupport]
    unfold sourceRawGeometry sourceComparisonGeometry
    split_ifs <;> ring
  rw [he]
  simp_rw [PhysicalKernelLinearity.originalKernel_sub,sub_mul,Finset.sum_sub_distrib]

 def allMaskBudget (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (ρ v0 vmin M L A H Y C R : ℝ)
    (a : Fin K→ℝ) : ℝ :=
  Real.sqrt ((Fintype.card (Mask (G:=Fin K)):ℝ)*∑m : Mask (G:=Fin K),
    (maskCost (J:=J) (B:=B) ν V ρ v0 vmin M L A H Y C R a m)^2)

 theorem actual_phased_edge_schur
    (hposition : Function.Injective position) (hprime : ∀i p,(value i p).Prime)
    (ν μ : ∀i,P i→ℝ) (hνpos : ∀i p,0<ν i p) (V : Fin K→ℝ)
    (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y H C R Aη Aψ : ℝ) (η ψ : ℝ→ℂ) (σ : ℤ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U) (hd : 0<d₀) (hY : 1≤Y)
    (hH : 0≤H) (hC : 1≤C) (hR : 0<R) (hσ : σ=1 ∨ σ= -1)
    (hη : ∀t,‖η t‖≤Aη) (hψ : ∀t,‖ψ t‖≤Aψ) (hψsupport : ∀t,ψ t≠0→|t|≤C)
    (hfirst : PhysicalComparisonChoices.GoodProjection value r Y good)
    (hsecond : GoodProjection value μ d₀ r L a good)
    (hband : ∀i p,Real.exp (L^a i)≤(value i p:ℝ)) (hband' : ∀i p,R≤(value i p:ℝ))
    (hνμ : ∀i p,ν i p≤2*μ i p) (hV : ∀i,vmin≤V i) (hmin : 0<vmin)
    (hρ0 : 0≤ρ) (hρ1 : ρ<1) (hv0 : 0<v0) (hM : 0≤M) (hmass : ∀i,(∑p,ν i p)≤M)
    (E : Fin K→Option ℕ→ℂ) (hE : ∀i b,‖E i b‖≤1)
    (F : State (Z:=Z) (P:=P) (Line:=fun i p=>Option (ZMod (value i p))) (J:=J) (B:=B)→ℂ) :
    finiteL2 Finset.univ (mass ν)
      (fun s=>∑t,PhysicalPhasedEdge.kernel value ν V ρ (PhysicalRawMaskedRow.anchor value position)
        (fun z a w b=>sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
          (sourceMajorArcs H Y) σ (position z) a (position w) b) E s t*F t)≤
    allMaskBudget (J:=J) (B:=B) ν V ρ v0 vmin M L (Aη^2*Aψ) H Y C R a*
      finiteL2 Finset.univ (mass ν) F := by
  let geo := fun z a w b=>sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
    (sourceMajorArcs H Y) σ (position z) a (position w) b
  let f := fun (m : Mask (G:=Fin K)) s=>∑t,originalKernel ν V m.1 m.2 ρ
    (PhysicalRawMaskedRow.anchor value position) (phaseGeometry value m.2 E geo) s t*F t
  have hm (m : Mask (G:=Fin K)) (_ : m∈(Finset.univ : Finset (Mask (G:=Fin K)))) :=
    phased_masked_schur value position hposition hprime ν μ hνpos V m.1 m.2
      ρ v0 vmin M L a good u v r U W d₀ Y H C R Aη Aψ η ψ σ hU hu hu' hd hY hH hC hR
      hσ hη hψ hψsupport hfirst hsecond hband hband' hνμ hV hmin hρ0 hρ1 hv0 hM hmass E hE F
  have hs := finiteL2_sum_le Finset.univ (Finset.univ : Finset (Mask (G:=Fin K))) (mass ν)
    (fun s _=>(mass_pos ν hνpos s).le) f
    (maskCost (J:=J) (B:=B) ν V ρ v0 vmin M L (Aη^2*Aψ) H Y C R a)
    (finiteL2 Finset.univ (mass ν) F) (Real.sqrt_nonneg _) (fun _ _=>Real.sqrt_nonneg _) hm
  apply (le_of_eq ?_).trans hs
  apply congrArg (finiteL2 Finset.univ (mass ν))
  funext s
  unfold PhysicalPhasedEdge.kernel
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr
  · ext m; simp only [Finset.mem_univ]
  · intro m hm
    unfold f
    apply Finset.sum_congr
    · ext t; simp only [Finset.mem_univ]
    · intro t ht; rfl

end Elliptic.Operator.PhysicalPhasedEdgeNorm
