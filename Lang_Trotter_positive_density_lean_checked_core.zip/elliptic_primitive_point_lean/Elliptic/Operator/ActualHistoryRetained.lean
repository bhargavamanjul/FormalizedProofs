module

public import Elliptic.Operator.ActualHistoryLifespans
public import Elliptic.Operator.SharedLineRetention
public import Elliptic.Operator.ActualHistoryObservation

/-!
# Retained-line coherence along actual histories

The predicates below concern literal physical states, without a supplied
schedule. Shared active slots must transport their actual residue anchors;
promotions use their existing hit tests and stores use the source anchor.
A prime which has no future birth therefore keeps one line throughout the
entire remaining actual history, including repeated store/promotion cycles.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath
attribute [local instance] Classical.propDecidable
local instance actualHistoryRetainedDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

namespace ActualHistoryRetained
variable {I Z : Type} [Fintype I]
variable {P : I → Type} {Line : ∀ i, P i → Type} {J B : ℕ}
variable (anchor : Z → ∀ i p, Line i p)

/-- Every actual occurrence of this prime has the specified line: active
occurrences use the physical position, pending occurrences their stored line. -/
def StateLine (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (i : I) (p : P i) (l : Line i p) : Prop :=
  (∀ a, s.active P Line J B i a = p → anchor (s.position P Line J B) i p = l) ∧
    ∀ a, ((s.memory P Line J B i).values a).1 = p →
      (s.memory P Line J B i).values a = ⟨p,l⟩

/-- With no pending occurrence, an active prime is coherently anchored at
its actual position. In particular this applies at the empty initial boundary. -/
theorem stateLine_of_no_pending
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (i : I) (p : P i)
    (hm : ¬ ∃ a, ((s.memory P Line J B i).values a).1 = p) :
    StateLine anchor s i p (anchor (s.position P Line J B) i p) := by
  exact ⟨fun _ _ => rfl, fun a ha => (hm ⟨a,ha⟩).elim⟩

/-- Joint distinctness supplies coherence at an active occurrence. -/
theorem stateLine_of_active
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : s.LiveDistinct)
    (i : I) (a : Fin (J+1)) :
    StateLine anchor s i (s.active P Line J B i a)
      (anchor (s.position P Line J B) i (s.active P Line J B i a)) := by
  apply stateLine_of_no_pending
  rintro ⟨b,hb⟩
  exact (hs i).2.2 a b hb.symm

/-- A unique pending prime determines a coherent line even if it is not
incident with the current physical position. -/
theorem stateLine_of_pending
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : s.LiveDistinct)
    (i : I) (a : Fin (s.memory P Line J B i).size) :
    StateLine anchor s i ((s.memory P Line J B i).values a).1
      ((s.memory P Line J B i).values a).2 := by
  constructor
  · intro b hb
    exact ((hs i).2.2 b a hb).elim
  · intro b hb
    have he : b = a := (hs i).2.1 hb
    subst b
    rfl

/-- A ghost operation cannot change an already assigned line unless it
performs a fresh birth of that same prime. -/
theorem ghost_preserves_line
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i) (l : Line i p)
    (hs : StateLine anchor s i p l) (hfresh : ∀ a, (c i).2.values a ≠ p) :
    StateLine anchor (c.output anchor s hc) i p l := by
  refine ⟨hs.1, ?_⟩
  intro a
  change (Fin.append (ghostSurvivors (s.memory P Line J B i) (c i).1)
    (fun b => anchorPrime (anchor (s.position P Line J B) i) ((c i).2.values b)) a).1 = p → _
  refine Fin.addCases (fun b hb => ?_) (fun b hb => ?_) a
  · simpa only [PhysicalGhostChoice.output_memory, ghostOutput, MemoryState.values,
      Fin.append_left, ghostSurvivors] using hs.2 ((c i).1ᶜ.orderEmbOfFin rfl b)
        (by simpa only [Fin.append_left,ghostSurvivors] using hb)
  · exact (hfresh b (by simpa only [Fin.append_right,anchorPrime] using hb)).elim

/-- Shared active slots, old pending survivors, stores and promotions all
preserve the same assigned line. A fresh target of this prime is excluded. -/
theorem edge_preserves_line
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i) (l : Line i p)
    (hs : StateLine anchor s i p l) (hfresh : (c.group i).2 ≠ Sum.inr p)
    (hshared : ∀ a : Fin J,
      anchor (s.position P Line J B) i (c.sourceLists i a.castSucc) =
        anchor c.target i (c.sourceLists i a.castSucc)) :
    StateLine anchor (c.output anchor s hc) i p l := by
  constructor
  · intro a
    change c.targetLists i (c.targetPerm i a) = p → anchor c.target i p = l
    generalize c.targetPerm i a = k
    refine Fin.lastCases ?_ (fun b hb => ?_) k
    · intro hp
      have hp' : edgeTargetPrime (s.memory P Line J B i) (c.group i) = p := by
        simpa only [PhysicalEdgeChoice.targetLists_last] using hp
      cases he : (c.group i).2 with
      | inl b =>
          have hb : ((s.memory P Line J B i).values b).1 = p := by
            simpa only [edgeTargetPrime,he] using hp'
          have hh : particleHits (anchor c.target i) ((s.memory P Line J B i).values b) := by
            simpa only [edgePromotionHits,he] using (hc.1 i).1
          rw [hs.2 b hb] at hh
          exact hh.symm
      | inr q =>
          have hqp : q = p := by simpa only [edgeTargetPrime,he] using hp'
          exact (hfresh (he.trans (congrArg Sum.inr hqp))).elim
    · have hb' : c.sourceLists i b.castSucc = p := by
        simpa only [PhysicalEdgeChoice.targetLists_shared] using hb
      have ht := hshared b
      rw [hb'] at ht
      exact ht.symm.trans (hs.1 (c.sourcePerm i b.castSucc) hb')
  · intro a ha
    have he := (edgeGroupOutput_exists_iff (anchor (s.position P Line J B) i)
      (c.sourcePrime i) (s.memory P Line J B i) (c.group i) (hc.1 i).2
      (((c.output anchor s hc).memory P Line J B i).values a)).mp ⟨a,rfl⟩
    rcases he with ⟨b,_,hb⟩ | ⟨_,hb⟩
    · exact hb.symm.trans (hs.2 b ((congrArg Sigma.fst hb).trans ha))
    · have hp : c.sourcePrime i = p := (congrArg Sigma.fst hb).trans ha
      have hl := hs.1 (c.sourcePerm i (Fin.last J)) hp
      rw [← hb]
      exact (congrArg (anchorPrime (anchor (s.position P Line J B) i)) hp).trans
        (by simp only [anchorPrime,hl])

/-- Absence imposes no condition on the proposed retained line. -/
theorem stateLine_of_absent
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (i : I) (p : P i) (l : Line i p)
    (hn : ¬ ActualHistoryLifespans.StateHas s i p) : StateLine anchor s i p l := by
  exact ⟨fun a ha => (hn (Or.inl ⟨a,ha⟩)).elim,
    fun a ha => (hn (Or.inr ⟨a,ha⟩)).elim⟩

/-- If a prime is absent before a ghost step, every occurrence created by
that step is anchored at this visit's actual position. -/
theorem ghost_line_of_absent
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i)
    (hn : ¬ ActualHistoryLifespans.StateHas s i p) :
    StateLine anchor (c.output anchor s hc) i p
      (anchor (s.position P Line J B) i p) := by
  constructor
  · intro _ _; rfl
  · intro a
    change (Fin.append (ghostSurvivors (s.memory P Line J B i) (c i).1)
      (fun b => anchorPrime (anchor (s.position P Line J B) i) ((c i).2.values b)) a).1 = p → _
    refine Fin.addCases (fun b hb => ?_) (fun b hb => ?_) a
    · exact (hn (Or.inr ⟨(c i).1ᶜ.orderEmbOfFin rfl b,
        by simpa only [Fin.append_left,ghostSurvivors] using hb⟩)).elim
    · have hp : (c i).2.values b = p := by simpa only [Fin.append_right,anchorPrime] using hb
      change Fin.append (ghostSurvivors (s.memory P Line J B i) (c i).1)
        (fun b => anchorPrime (anchor (s.position P Line J B) i) ((c i).2.values b))
          (b.natAdd (c i).1ᶜ.card) = _
      rw [Fin.append_right]
      exact congrArg (anchorPrime (anchor (s.position P Line J B) i)) hp

/-- Every jointly distinct state has a coherent line for each prime,
including primes which are absent from that state. -/
theorem exists_stateLine
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : s.LiveDistinct)
    (i : I) (p : P i) : ∃ l, StateLine anchor s i p l := by
  by_cases ha : ∃ a, s.active P Line J B i a = p
  · obtain ⟨a,ha⟩ := ha
    subst p
    exact ⟨_,stateLine_of_active anchor s hs i a⟩
  by_cases hm : ∃ a, ((s.memory P Line J B i).values a).1 = p
  · obtain ⟨a,hm⟩ := hm
    subst p
    exact ⟨_,stateLine_of_pending anchor s hs i a⟩
  · exact ⟨_,stateLine_of_no_pending anchor s i p hm⟩

/-- A selected ghost death is a literal hit, so its coherent retained
line equals the physical anchor at the death visit. -/
theorem ghost_death_line
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i) (l : Line i p)
    (hs : StateLine anchor s i p l)
    (a : Fin (s.memory P Line J B i).size) (ha : a ∈ (c i).1)
    (hp : ((s.memory P Line J B i).values a).1 = p) :
    l = anchor (s.position P Line J B) i p := by
  have hh := (hc.1 i).1 ha
  have hh' : particleHits (anchor (s.position P Line J B) i)
      ((s.memory P Line J B i).values a) := (Finset.mem_filter.mp hh).2
  rw [hs.2 a hp] at hh'
  exact hh'

/-- Every fresh ghost draw literally stores this visit's anchor. -/
theorem ghost_birth_line
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i) (l : Line i p)
    (hs : StateLine anchor (c.output anchor s hc) i p l)
    (a : Fin (c i).2.size) (ha : (c i).2.values a = p) :
    l = anchor (s.position P Line J B) i p := by
  have he : ((c.output anchor s hc).memory P Line J B i).values
      (a.natAdd (c i).1ᶜ.card) = anchorPrime (anchor (s.position P Line J B) i) p := by
    change Fin.append (ghostSurvivors (s.memory P Line J B i) (c i).1)
      (fun b => anchorPrime (anchor (s.position P Line J B) i) ((c i).2.values b))
      (a.natAdd (c i).1ᶜ.card) = _
    rw [Fin.append_right]
    exact congrArg (anchorPrime (anchor (s.position P Line J B) i)) ha
  have hp : (((c.output anchor s hc).memory P Line J B i).values
      (a.natAdd (c i).1ᶜ.card)).1 = p := congrArg Sigma.fst he
  have hh := (hs.2 _ hp).symm.trans he
  simpa only [anchorPrime,Sigma.mk.injEq,heq_eq_eq,true_and] using hh

/-- Promotion checks the already retained line at the actual target. -/
theorem edge_promotion_line
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (i : I) (p : P i) (l : Line i p)
    (hs : StateLine anchor s i p l)
    (a : Fin (s.memory P Line J B i).size) (ha : (c.group i).2 = Sum.inl a)
    (hp : ((s.memory P Line J B i).values a).1 = p) :
    l = anchor c.target i p := by
  have hh : particleHits (anchor c.target i) ((s.memory P Line J B i).values a) := by
    simpa only [edgePromotionHits,ha] using (hc.1 i).1
  rw [hs.2 a hp] at hh
  exact hh

/-- Any live occurrence determines its coherent line uniquely. -/
theorem stateLine_unique_of_present
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (i : I) (p : P i) (l m : Line i p)
    (hl : StateLine anchor s i p l) (hm : StateLine anchor s i p m)
    (hp : ActualHistoryLifespans.StateHas s i p) : l = m := by
  rcases hp with ⟨a,ha⟩ | ⟨a,ha⟩
  · exact (hl.1 a ha).symm.trans (hm.1 a ha)
  · have he := (hl.2 a ha).symm.trans (hm.2 a ha)
    simpa only [Sigma.mk.injEq,heq_eq_eq,true_and] using he

variable [Fintype Z] [∀ i, Fintype (P i)]
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

/-- Literal shared-slot transport for every edge actually chosen in a
history. It will be deduced from the support of its nonzero coefficient. -/
def SharedTransport : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s → Prop
  | 0,_,_,_ => True
  | n+1,j,s,h =>
      (∀ i (a : Fin J),
        anchor (s.position P Line J B) i (h.2.1.val.sourceLists i a.castSucc) =
          anchor h.2.1.val.target i (h.2.1.val.sourceLists i a.castSucc)) ∧
      SharedTransport n (j+1) _ h.2.2

/-- Coherence at all literal states, before and after every ghost visit. -/
def AllLines (i : I) (p : P i) (l : Line i p) :
    (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s → Prop
  | 0,j,s,h => StateLine anchor s i p l ∧
      StateLine anchor ((physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property) i p l
  | n+1,j,s,h => StateLine anchor s i p l ∧
      StateLine anchor ((physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property) i p l ∧
      AllLines i p l n (j+1) _ h.2.2

/-- No later numerical birth can change this prime's retained line. The
proof follows the actual choices, not a pre-existing schedule. -/
theorem allLines_of_no_future_birth (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i) (l : Line i p)
    (hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h)
    (hs : StateLine anchor s i p l)
    (ht : SharedTransport anchor ν V η q ρ geometry n j s h) :
    AllLines anchor ν V η q ρ geometry i p l n j s h := by
  induction n generalizing j s with
  | zero =>
      refine ⟨hs,ghost_preserves_line anchor s h.1.val h.1.property i p l hs ?_⟩
      intro a ha
      apply hn
      refine ⟨.inl (0,i,⟨a.val,lt_of_lt_of_le a.isLt (h.1.val i).2.size_le⟩),?_⟩
      simpa only [ActualHistorySupport.firstGhost,ha] using
        ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry 0 j s h i a
  | succ n ih =>
      let sg := (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
      let se := (physicalEdgeOperation ν V ρ anchor (geometry j)).output sg h.2.1.val h.2.1.property
      have hg : StateLine anchor sg i p l := by
        apply ghost_preserves_line anchor s h.1.val h.1.property i p l hs
        intro a ha
        apply hn
        refine ⟨.inl (0,i,⟨a.val,lt_of_lt_of_le a.isLt (h.1.val i).2.size_le⟩),?_⟩
        simpa only [ActualHistorySupport.firstGhost,ha] using
          ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i a
      have he : StateLine anchor se i p l := by
        apply edge_preserves_line anchor sg h.2.1.val h.2.1.property i p l hg
        · intro hf
          exact hn ⟨.inr (0,i),ActualHistorySupport.futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hf⟩
        · exact ht.1 i
      have hnt : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2 := by
        rintro ⟨a,ha⟩
        exact hn ⟨ActualHistorySupport.tailAddress a,by rw [ActualHistorySupport.futureLabels_tail]; exact ha⟩
      exact ⟨hs,hg,ih (j+1) se h.2.2 hnt he ht.2⟩

/-- The recursive invariant exposes coherence at any actual visit. -/
theorem allLines_observed (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i) (l : Line i p)
    (hl : AllLines anchor ν V η q ρ geometry i p l n j s h) (k : Fin (n+1)) :
    StateLine anchor (beforeStateAt ν V η q ρ geometry n j s h k) i p l ∧
      StateLine anchor (afterStateAt ν V η q ρ geometry n j s h k) i p l := by
  induction n generalizing j s with
  | zero => exact hl
  | succ n ih =>
      refine Fin.cases ?_ (fun k => ?_) k
      · exact ⟨hl.1,hl.2.1⟩
      · exact ih (j+1) _ h.2.2 hl.2.2 k

/-- Every recorded ghost deletion has the recovered retained line at
its actual visit position. This uses the literal indexed deletion test. -/
theorem ghostAt_death_line (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i) (l : Line i p)
    (hl : AllLines anchor ν V η q ρ geometry i p l n j s h) (k : Fin (n+1))
    (hp : p ∈ (ActualHistoryObservation.ghostAt ν V η q ρ anchor geometry n j s h k).deleted i) :
    l = anchor ((beforeStateAt ν V η q ρ geometry n j s h k).position P Line J B) i p := by
  induction n generalizing j s with
  | zero =>
      obtain ⟨a,ha,hp⟩ := Finset.mem_image.mp hp
      exact ghost_death_line anchor s h.1.val h.1.property i p l hl.1 a ha hp
  | succ n ih =>
      revert hp
      refine Fin.cases ?_ (fun k hp => ?_) k
      · intro hp
        obtain ⟨a,ha,hp⟩ := Finset.mem_image.mp hp
        exact ghost_death_line anchor s h.1.val h.1.property i p l hl.1 a ha hp
      · exact ih (j+1) _ h.2.2 hl.2.2 k hp

/-- Every recorded ghost birth has the recovered retained line at its
actual visit position. The proof uses the appended anchored particle. -/
theorem ghostAt_birth_line (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (i : I) (p : P i) (l : Line i p)
    (hl : AllLines anchor ν V η q ρ geometry i p l n j s h) (k : Fin (n+1))
    (hp : p ∈ (ActualHistoryObservation.ghostAt ν V η q ρ anchor geometry n j s h k).fresh i) :
    l = anchor ((beforeStateAt ν V η q ρ geometry n j s h k).position P Line J B) i p := by
  induction n generalizing j s with
  | zero =>
      have hp' : p ∈ tupleBag (h.1.val i).2.values := hp
      obtain ⟨a,ha⟩ : ∃ a, (h.1.val i).2.values a = p := by
        simpa only [tupleBag_eq_map,Multiset.mem_map,Finset.mem_val,Finset.mem_univ,true_and] using hp'
      exact ghost_birth_line anchor s h.1.val h.1.property i p l hl.2 a ha
  | succ n ih =>
      revert hp
      refine Fin.cases ?_ (fun k hp => ?_) k
      · intro hp
        have hp' : p ∈ tupleBag (h.1.val i).2.values := hp
        obtain ⟨a,ha⟩ : ∃ a, (h.1.val i).2.values a = p := by
          simpa only [tupleBag_eq_map,Multiset.mem_map,Finset.mem_val,Finset.mem_univ,true_and] using hp'
        exact ghost_birth_line anchor s h.1.val h.1.property i p l hl.2.1 a ha
      · exact ih (j+1) _ h.2.2 hl.2.2 k hp

/-- Global existence of one retained line for each prime of an actual
history. Distinct numerical births, literal initial distinctness and
future-birth avoidance are enough; no lifespan schedule is supplied. -/
theorem exists_allLines_of_future_distinct (value : ∀ i, P i → ℕ) (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry n j s h))
    (hs : s.LiveDistinct)
    (hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n j s h) s)
    (ht : SharedTransport anchor ν V η q ρ geometry n j s h)
    (i : I) (p : P i) :
    ∃ l, AllLines anchor ν V η q ρ geometry i p l n j s h := by
  induction n generalizing j s with
  | zero =>
      by_cases hp : ActualHistoryLifespans.StateHas s i p
      · have hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry 0 j s h := by
          rcases hp with ⟨a,ha⟩ | ⟨a,ha⟩
          · simpa only [ha] using hav.1 i a
          · simpa only [ha] using hav.2 i a
        obtain ⟨l,hl⟩ := exists_stateLine anchor s hs i p
        exact ⟨l,allLines_of_no_future_birth anchor ν V η q ρ geometry value 0 j s h i p l hn hl ht⟩
      · exact ⟨anchor (s.position P Line J B) i p,
          stateLine_of_absent anchor s i p _ hp,
          ghost_line_of_absent anchor s h.1.val h.1.property i p hp⟩
  | succ n ih =>
      by_cases hp : ActualHistoryLifespans.StateHas s i p
      · have hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry (n+1) j s h := by
          rcases hp with ⟨a,ha⟩ | ⟨a,ha⟩
          · simpa only [ha] using hav.1 i a
          · simpa only [ha] using hav.2 i a
        obtain ⟨l,hl⟩ := exists_stateLine anchor s hs i p
        exact ⟨l,allLines_of_no_future_birth anchor ν V η q ρ geometry value (n+1) j s h i p l hn hl ht⟩
      let sg := (physicalGhostOperation ν V (η j) (q j) ρ anchor).output s h.1.val h.1.property
      let se := (physicalEdgeOperation ν V ρ anchor (geometry j)).output sg h.2.1.val h.2.1.property
      have hi := ActualHistorySupport.tail_future_invariants value ν V η q ρ anchor geometry n j s h hd hav
      by_cases hg : ActualHistoryLifespans.StateHas sg i p
      · let l := anchor (s.position P Line J B) i p
        have hsg : StateLine anchor sg i p l := ghost_line_of_absent anchor s h.1.val h.1.property i p hp
        have hn : value i p ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2 := by
          rcases hg with ⟨a,ha⟩ | ⟨a,ha⟩
          · have hh : value i (sg.active P Line J B i a) ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2 := hi.2.2.1.1 i a
            simpa only [ha] using hh
          · have hh : value i ((sg.memory P Line J B i).values a).1 ∉ ActualHistorySupport.futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2 := hi.2.2.1.2 i a
            simpa only [ha] using hh
        have hf : (h.2.1.val.group i).2 ≠ Sum.inr p := by
          intro hf
          obtain hOld | ⟨a,ha⟩ := ActualHistoryLifespans.ghost_has_source_or_birth anchor s h.1.val h.1.property i p hg
          · exact hp hOld
          · have hga := ActualHistorySupport.futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i a
            have hfa := ActualHistorySupport.futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hf
            have he := hd _ _ (value i p) (by simpa only [ActualHistorySupport.firstGhost,ha] using hga) hfa
            cases he
        have hse : StateLine anchor se i p l :=
          edge_preserves_line anchor sg h.2.1.val h.2.1.property i p l hsg hf (ht.1 i)
        exact ⟨l,stateLine_of_absent anchor s i p l hp,hsg,
          allLines_of_no_future_birth anchor ν V η q ρ geometry value n (j+1) se h.2.2 i p l hn hse ht.2⟩
      · have hall := ActualHistorySupport.allLive_of_future_distinct value ν V η q ρ anchor geometry (n+1) j s h hd hs hav
        have hse : se.LiveDistinct := by cases n <;> exact hall.2.2.1
        obtain ⟨l,hl⟩ := ih (j+1) se h.2.2 hi.1 hse hi.2.2.2 ht.2
        exact ⟨l,stateLine_of_absent anchor s i p l hp,
          stateLine_of_absent anchor sg i p l hg,hl⟩

/-- Nonzero literal coefficients impose shared transport whenever the
geometric multiplier has the established shared-residue support property. -/
theorem sharedTransport_of_weight_ne_zero
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hw : h.weight ≠ 0) : SharedTransport anchor ν V η q ρ geometry n j s h := by
  have hg := ActualHistoryObservation.allGeometryNonzero_of_weight_ne_zero
    ν V η q ρ anchor geometry n j s h hw
  clear hw
  induction n generalizing j s with
  | zero => trivial
  | succ n ih =>
      exact ⟨hgeometry j _ _ _ _ hg.1, ih (j+1) _ h.2.2 hg.2⟩

/-- Complete performed-birth distinctness and the empty initial memory
suffice to construct coherent retained lines for all used primes. The
returned function is harmlessly defined for unused primes as well. -/
theorem exists_retained_of_birthsDistinct (value : ∀ i, P i → ℕ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0)
    (ht : SharedTransport anchor ν V η q ρ geometry N 0 s h) :
    ∃ retained : ∀ i p, Line i p,
      ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h := by
  have hall := ActualHistorySupport.allLive_of_birthsDistinct value ν V η q ρ anchor geometry N s h hd hempty
  have hs : s.LiveDistinct := by cases N <;> exact hall.1
  have hdf : BirthsDistinct (ActualHistorySupport.futureLabels value ν V η q ρ anchor geometry N 0 s h) := by
    intro a b p hap hbp
    apply Sum.inr.inj (hd (.inr a) (.inr b) p ?_ ?_)
    · cases a <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using hap
    · cases b <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using hbp
  have hav : ActualHistorySupport.Avoids value
      (ActualHistorySupport.futureValues value ν V η q ρ anchor geometry N 0 s h) s := by
    constructor
    · intro i k hp
      obtain ⟨a,ha⟩ := hp
      have he := hd (.inl (i,k)) (.inr a) _ rfl (by
        cases a <;> simpa only [ActualHistoryBirths.labels,ActualHistorySupport.futureLabels] using ha)
      cases he
    · intro i k
      have hk := k.isLt
      have he := hempty i
      omega
  have hex : ∀ i p, ∃ l, AllLines anchor ν V η q ρ geometry i p l N 0 s h :=
    fun i p => exists_allLines_of_future_distinct anchor ν V η q ρ geometry value N 0 s h hdf hs hav ht i p
  exact ⟨fun i p => Classical.choose (hex i p),fun i p => Classical.choose_spec (hex i p)⟩

/-- The entire retained-line existence assertion follows from the actual
nonzero weight, rather than a separate all-active line hypothesis. -/
theorem exists_retained_of_weight_ne_zero (value : ∀ i, P i → ℕ) (N : ℕ)
    (hgeometry : ∀ j z a w b, geometry j z a w b ≠ 0 → ∀ i (k : Fin J),
      anchor z i (a i k.castSucc) = anchor w i (a i k.castSucc))
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0) (hw : h.weight ≠ 0) :
    ∃ retained : ∀ i p, Line i p,
      ∀ i p, AllLines anchor ν V η q ρ geometry i p (retained i p) N 0 s h := by
  exact exists_retained_of_birthsDistinct anchor ν V η q ρ geometry value N s h hd hempty
    (sharedTransport_of_weight_ne_zero anchor ν V η q ρ geometry hgeometry N 0 s h hw)

end ActualHistoryRetained

namespace ActualHistoryRetained
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)] {J B : ℕ}

/-- Specialization to the actual signed source geometry, including either
orientation and any integer shift. Shared transport is proved from the
source pad condition and primality, not imposed as a history premise. -/
theorem exists_retained_of_source_geometry
    (value : ∀ i, P i → ℕ) (hprime : ∀ i p, (value i p).Prime)
    (position : Z → ℤ × ℤ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ) (major : Set ProductCircle)
    (σ : ℤ) (adjoint : ℕ → Bool)
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ) (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ
      (fun z i p => primeResidueAnchor (value i p) (position z))
      (fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
        u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b) N) s)
    (hd : BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ
      (fun z i p => primeResidueAnchor (value i p) (position z))
      (fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
        u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b) value N s h))
    (hempty : ∀ i, (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size = 0)
    (hw : h.weight ≠ 0) :
    ∃ retained : ∀ i p, Option (ZMod (value i p)),
      ∀ i p, AllLines (fun z i p => primeResidueAnchor (value i p) (position z))
        ν V η q ρ
        (fun j z a w b => orientedSourceEdgeGeometry (adjoint j) value good
          u v r U W d₀ Y smooth ψ major σ (position z) a (position w) b)
        i p (retained i p) N 0 s h := by
  apply exists_retained_of_weight_ne_zero _ ν V η q ρ _ value N ?_ s h hd hempty hw
  intro j z a w b hn i k
  let : Fact (value i (a i k.castSucc)).Prime := ⟨hprime i _⟩
  exact orientedSourceEdgeGeometry_nonzero_sharedLine (adjoint j) value good
    u v r U W d₀ Y smooth ψ major σ (position z) (position w) a b hn i k

end ActualHistoryRetained
end Elliptic.Operator
