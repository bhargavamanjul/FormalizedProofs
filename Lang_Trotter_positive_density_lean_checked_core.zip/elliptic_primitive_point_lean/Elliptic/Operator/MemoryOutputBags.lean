module
public import Elliptic.Operator.MemoryEdges

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

/-- Appending actual ordered tuples adds their particle multisets. -/
theorem tupleBag_append {X : Type*} {k a : ℕ} (u : Fin k → X) (v : Fin a → X) :
    tupleBag (Fin.append u v) = tupleBag u + tupleBag v := by
  simp only [tupleBag, Fin.sum_univ_add, Fin.append_left, Fin.append_right]

/-- Increasing-order survivors have exactly the indexed survivor multiset. -/
theorem ghostSurvivors_tupleBag {P : Type*} {Line : P → Type*} {B : ℕ}
    (m : MemoryState (AnchoredParticle P Line) B) (S : Finset (Fin m.size)) :
    tupleBag (ghostSurvivors m S) = survivorBag S m.values := by
  let e : Fin Sᶜ.card ≃ {i : Fin m.size // i ∉ S} :=
    (Sᶜ.orderIsoOfFin rfl).toEquiv.trans (Equiv.subtypeEquivRight (fun i => Finset.mem_compl))
  exact Equiv.sum_comp e (fun i => ({m.values i} : Multiset (AnchoredParticle P Line)))

/-- The actual ghost output consists of old survivors and its anchored batch. -/
theorem ghostOutput_tupleBag {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) (hc : GhostChoice.Valid anchor m c) :
    tupleBag (ghostOutput anchor m c hc).values =
      survivorBag c.1 m.values + tupleBag (fun j => anchorPrime anchor (c.2.values j)) := by
  change tupleBag (Fin.append (ghostSurvivors m c.1)
    (fun j => anchorPrime anchor (c.2.values j))) = _
  rw [tupleBag_append, ghostSurvivors_tupleBag]

/-- The actual edge output consists of unpromoted old particles and its
optional newly stored source particle. -/
theorem edgeGroupOutput_tupleBag {P : Type*} {Line : P → Type*} {B : ℕ}
    (sourceAnchor : ∀ p, Line p) (sourcePrime : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m)
    (hc : edgeGroupOutputSize c ≤ B) :
    tupleBag (edgeGroupOutput sourceAnchor sourcePrime m c hc).values =
      survivorBag (edgePromotedIndices c) m.values +
        if c.1 then {anchorPrime sourceAnchor sourcePrime} else 0 := by
  change tupleBag (Fin.append (ghostSurvivors m (edgePromotedIndices c))
    (fun _ : Fin c.1.toNat => anchorPrime sourceAnchor sourcePrime)) = _
  rw [tupleBag_append, ghostSurvivors_tupleBag]
  congr 1
  cases c.1 <;> simp [tupleBag]

end Elliptic.Operator
