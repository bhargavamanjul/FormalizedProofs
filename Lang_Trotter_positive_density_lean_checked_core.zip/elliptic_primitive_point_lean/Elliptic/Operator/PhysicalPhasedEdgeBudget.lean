module

public import Elliptic.Operator.PhysicalPhasedEdgeNorm
public import Elliptic.Operator.PhysicalMaskBudgetBounds

/-! A polynomial crude bound on all phase-modified edge masks. The clean
mask is included through its absolute raw/comparison row constants. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPhasedEdgeBudget
open scoped BigOperators
open PhysicalPhasedEdgeNorm PhysicalMaskBudgetBounds PhysicalMaskScaling PhysicalRawGlobalRow PhysicalDirtyMasks
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 theorem sqrt_cost_le (A x y r Q T : ℝ) (hA : 0≤A) (hx : 0≤x) (hy : 0≤y)
    (hr : 0≤r) (hQ : 0≤Q) (hT : 0≤T) (hxT : x≤T) (hyT : y≤T) (hrQ : r≤Q) :
    Real.sqrt ((A*x)*(r*A*y))≤A*Real.sqrt Q*T := by
  calc
    _ ≤ Real.sqrt ((A*T)*(Q*A*T)) := by gcongr
    _ = Real.sqrt ((A*T)^2*Q) := by congr 1;ring
    _ = _ := by rw [Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq (mul_nonneg hA hT)];ring

 theorem raw_budget_le (K J B : ℕ) (ρ v0 vmin M L : ℝ) (a : Fin K→ℝ) (I : Fin K→Bool)
    (hv0 : 0<v0) (hM : 0≤M) (hs : rawSaving K J B ρ v0 vmin M L a≤1) :
    budget K J B ρ v0 vmin M L a I≤33*((1+v0)*M)^K+1 := by
  unfold budget
  change (if ∃i,I i=true then rawSaving K J B ρ v0 vmin M L a else _)≤_
  split_ifs <;> linarith [show 0≤33*((1+v0)*M)^K by positivity]

 theorem comparison_count_le {K : ℕ} (Y C R : ℝ) (I : Fin K→Bool)
    (hC : 0≤C) (hs : comparisonSaving Y R≤2) :
    PhysicalComparisonMaskedRow.countFactor Y C R I≤comparisonCoarse C+2*comparisonGeo C := by
  have hc : 0≤comparisonCoarse C := by unfold comparisonCoarse;positivity
  have hg : 0≤comparisonGeo C := by unfold comparisonGeo;positivity
  unfold PhysicalComparisonMaskedRow.countFactor
  change (if ∃i,I i=true then comparisonGeo C*comparisonSaving Y R else comparisonCoarse C)≤_
  split_ifs <;> nlinarith

 def crudeRaw (K : ℕ) (v0 vmin vmax M A : ℝ) : ℝ :=
  A*Real.sqrt (reverseBound K vmin vmax)*(33*((1+v0)*M)^K+1)

 def crudeComparison (K B : ℕ) (v0 vmin vmax M A H C : ℝ) : ℝ :=
  (4*A*H^3)*Real.sqrt (reverseBound K vmin vmax)*
    ((comparisonCoarse C+2*comparisonGeo C)*((1+v0)*((B:ℝ)*vmin⁻¹/v0+M))^K)

 theorem rawCost_le {K J B : ℕ} (V : Fin K→ℝ) (ρ v0 vmin vmax M L A : ℝ)
    (a : Fin K→ℝ) (S I : Fin K→Bool)
    (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax)
    (hs : rawSaving K J B ρ v0 vmin M L a≤1) :
    rawCost K J B V ρ v0 vmin M L A a S I≤crudeRaw K v0 vmin vmax M A := by
  apply sqrt_cost_le A _ _ _ _ _ hA
    (budget_nonneg K J B ρ v0 vmin M L a I hρ hv0 hmin hM)
    (budget_nonneg K J B ρ v0 vmin M L a S hρ hv0 hmin hM)
    (reverseFactor_pos V (fun i=>hmin.trans_le (hlo i)) I S).le
    (by unfold reverseBound;positivity) (by positivity)
    (raw_budget_le K J B ρ v0 vmin M L a I hv0 hM hs)
    (raw_budget_le K J B ρ v0 vmin M L a S hv0 hM hs)
    (reverseFactor_le V I S vmin vmax hmin hlo hhi)

 theorem comparisonCost_le {K B : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (v0 vmin vmax M A H Y C R : ℝ) (S I : Fin K→Bool)
    (hν : ∀i p,0≤ν i p) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA : 0≤A) (hH : 0≤H)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax) (hmass : ∀i,(∑p,ν i p)≤M)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R) (hs : comparisonSaving Y R≤2) :
    comparisonCost B ν V v0 (4*A*H^3) Y C R S I≤crudeComparison K B v0 vmin vmax M A H C := by
  have hP : 0≤PhysicalChoiceFiberWeight.budget (B:=B) ν V v0 := by
    unfold PhysicalChoiceFiberWeight.budget
    apply Finset.prod_nonneg
    intro i _
    have hv := hmin.trans_le (hlo i)
    have hn : 0≤∑p,ν i p := Finset.sum_nonneg (fun p _=>hν i p)
    positivity
  have hpb := comparison_memory_budget_le (B:=B) ν V v0 vmin M hν hv0 hmin hlo hmass
  have hcount (I : Fin K→Bool) := PhysicalComparisonMaskedRow.countFactor_nonneg Y C R I hY hC hR
  have hc (I : Fin K→Bool) : PhysicalComparisonMaskedRow.countFactor Y C R I*
      PhysicalChoiceFiberWeight.budget (B:=B) ν V v0≤
      (comparisonCoarse C+2*comparisonGeo C)*((1+v0)*((B:ℝ)*vmin⁻¹/v0+M))^K := by
    exact mul_le_mul (comparison_count_le Y C R I hC hs) hpb hP
      (by unfold comparisonCoarse comparisonGeo;positivity)
  apply sqrt_cost_le (4*A*H^3) _ _ _ _ _ (by positivity)
    (mul_nonneg (hcount I) hP) (mul_nonneg (hcount S) hP)
    (reverseFactor_pos V (fun i=>hmin.trans_le (hlo i)) I S).le
    (by unfold reverseBound;positivity)
    (by unfold comparisonCoarse comparisonGeo;positivity) (hc I) (hc S)
    (reverseFactor_le V I S vmin vmax hmin hlo hhi)

 theorem allMaskBudget_le {K J B : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (ρ v0 vmin vmax M L A H Y C R : ℝ) (a : Fin K→ℝ)
    (hν : ∀i p,0≤ν i p) (hρ : ρ<1) (hv0 : 0<v0) (hmin : 0<vmin)
    (hM : 0≤M) (hA : 0≤A) (hH : 0≤H)
    (hlo : ∀i,vmin≤V i) (hhi : ∀i,V i≤vmax) (hmass : ∀i,(∑p,ν i p)≤M)
    (hY : 0≤Y) (hC : 0≤C) (hR : 0≤R)
    (hraw : rawSaving K J B ρ v0 vmin M L a≤1) (hcomp : comparisonSaving Y R≤2) :
    allMaskBudget (J:=J) (B:=B) ν V ρ v0 vmin M L A H Y C R a≤
      (4:ℝ)^K*Real.sqrt (2*((crudeRaw K v0 vmin vmax M A)^2+
        (crudeComparison K B v0 vmin vmax M A H C)^2)) := by
  let T := 2*((crudeRaw K v0 vmin vmax M A)^2+(crudeComparison K B v0 vmin vmax M A H C)^2)
  have hT : 0≤T := by dsimp [T];positivity
  have hc (m : Mask (G:=Fin K)) : (maskCost (J:=J) (B:=B) ν V ρ v0 vmin M L A H Y C R a m)^2≤T := by
    rw [maskCost,Real.sq_sqrt (by positivity)]
    have hr := pow_le_pow_left₀ (Real.sqrt_nonneg _) (rawCost_le V ρ v0 vmin vmax M L A a m.1 m.2
      hρ hv0 hmin hM hA hlo hhi hraw) 2
    have he := pow_le_pow_left₀ (Real.sqrt_nonneg _) (comparisonCost_le (B:=B) ν V v0 vmin vmax M A H Y C R m.1 m.2
      hν hv0 hmin hM hA hH hlo hhi hmass hY hC hR hcomp) 2
    dsimp [T,rawCost,comparisonCost]
    linarith
  have hcard : (Fintype.card (Mask (G:=Fin K)):ℝ)=(4:ℝ)^K := by
    simp [Mask,Fintype.card_prod,Fintype.card_fun,←mul_pow]
  unfold allMaskBudget
  calc
    _ ≤ Real.sqrt ((4:ℝ)^K*((4:ℝ)^K*T)) := by
      rw [hcard]
      apply Real.sqrt_le_sqrt
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      calc
        _ ≤ ∑_m : Mask (G:=Fin K),T := Finset.sum_le_sum (fun m _=>hc m)
        _ = _ := by rw [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,hcard]
    _ = _ := by rw [←mul_assoc,←pow_two,Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq (by positivity)]

end Elliptic.Operator.PhysicalPhasedEdgeBudget
