module

public import Elliptic.Operator.MellinDeterminantBound
public import Elliptic.Operator.SignedSmoothDyads

/-! Fixed logarithmic cutoffs for the literal source dyadic determinant. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinPlateau
open MeasureTheory Set MellinPlane MellinPlaneUniform
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

def plateau (a b:ℝ) (t:ℝ) : ℂ :=
  (Real.smoothTransition (t-a+1)*Real.smoothTransition (b+1-t):ℝ)

theorem plateau_smooth (a b:ℝ) : Smooth (plateau a b) := by
  apply Complex.ofRealCLM.contDiff.comp
  exact (Real.smoothTransition.contDiff.comp ((contDiff_id.sub contDiff_const).add contDiff_const)).mul
    (Real.smoothTransition.contDiff.comp (contDiff_const.sub contDiff_id))

theorem plateau_one (a b t:ℝ) (ht:t∈Icc a b) : plateau a b t=1 := by
  simp [plateau,Real.smoothTransition.one_of_one_le (show 1≤t-a+1 by linarith [ht.1]),
    Real.smoothTransition.one_of_one_le (show 1≤b+1-t by linarith [ht.2])]

theorem plateau_compact (a b:ℝ) : HasCompactSupport (plateau a b) := by
  apply HasCompactSupport.of_support_subset_isCompact (isCompact_Icc : IsCompact (Icc (a-1) (b+1)))
  intro t ht
  constructor
  · by_contra h
    have hz := Real.smoothTransition.zero_of_nonpos (show t-a+1≤0 by linarith)
    exact ht (by simp [plateau,hz])
  · by_contra h
    have hz := Real.smoothTransition.zero_of_nonpos (show b+1-t≤0 by linarith)
    exact ht (by simp [plateau,hz])

def rho : ℝ→ℂ := plateau (-5) 5
def sigma : ℝ→ℂ := plateau 0 (Real.log 16)

theorem rho_one_on_determinant_support (X w w':ℝ) (hX:0<X)
    (hw:1≤w) (hw':1≤w')
    (hψ:SignedSmoothDyads.determinantCutoff (X*(w-w'))≠0) :
    rho (X*Real.log (w/w'))=1 := by
  apply plateau_one
  have hh := scaled_log_ratio_le 1 X w w' 5 (by norm_num) hX hw hw'
    (SignedSmoothDyads.determinantCutoff_support _ hψ)
  change -5≤X*Real.log (w/w') ∧ X*Real.log (w/w')≤5
  simpa only [div_one,abs_le] using hh

theorem sigma_one (w:ℝ) (hw:w∈Icc 1 16) : sigma (Real.log w)=1 := by
  apply plateau_one
  exact ⟨Real.log_nonneg hw.1,Real.log_le_log (by linarith [hw.1]) hw.2⟩

/-- Source dyad geometry supplies both fixed cutoff plateaus; the exact
Mellin separation has no additional cutoff-equals-one premise. -/
theorem source_determinant_pair_separation {ι κ:Type*} (I:Finset ι) (J:Finset κ)
    (a:ι→ℂ) (b:κ→ℂ) (w:ι→ℝ) (w':κ→ℝ) (X lam:ℝ) (hX:0<X)
    (hw:∀i∈I,w i∈Icc 1 16) (hw':∀j∈J,w' j∈Icc 1 16) :
    (∑i∈I,∑j∈J,a i*b j*
      (SignedSmoothDyads.determinantCutoff (X*(w i-w' j))*
        Elliptic.SourceContracts.additivePhase (lam*(X*(w i-w' j)))))=
      (X:ℂ)⁻¹*(∫t:ℝ,∫s:ℝ,
        mellinKernel (determinantSchwartz SignedSmoothDyads.determinantCutoff rho sigma
          SignedSmoothDyads.determinantCutoff_contDiff (plateau_smooth (-5) 5)
          (plateau_smooth 0 (Real.log 16)) (plateau_compact (-5) 5)
          (plateau_compact 0 (Real.log 16)) X lam) (t/X) s*
        (∑i∈I,a i*LogPhaseProgression.phase t (w i))*
        (∑j∈J,b j*LogPhaseProgression.phase (s-t) (w' j))) := by
  apply determinant_pair_mellin_separation
  · exact hX
  · intro i hi; linarith [(hw i hi).1]
  · intro j hj; linarith [(hw' j hj).1]
  · intro i hi j hj hψ
    exact rho_one_on_determinant_support X (w i) (w' j) hX (hw i hi).1 (hw' j hj).1 hψ
  · intro j hj
    exact sigma_one (w' j) (hw' j hj)

end Elliptic.Operator.MellinPlateau
