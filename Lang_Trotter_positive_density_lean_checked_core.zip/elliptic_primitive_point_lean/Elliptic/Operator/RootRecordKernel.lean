module

public import Elliptic.Operator.RootLiteralPowerTransfer
public import Elliptic.Operator.OriginalPathWeights
public import Elliptic.Operator.RootRecordGood

/-!
# Root transfer for the original records with both endpoint permutations

The incoming and outgoing lists at a vertex need not use the same
permutation. This module retains the two literal permutation families
in OriginalPathWeights.edgeGeometry throughout the root transfer.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordKernel
open Filter MeasureTheory SourceRootCount SourceRootTransfer
open RootArchimedeanGrid RootGridPartition RootGridMeasure RootGridTransfer
open RootArchimedeanTransfer RootVariableSum RootLiteralGeometry
open RootBoundaryCover RootBoundaryBudget RootEndpointBudget IntegerRootReplacement
open RootLiteralPowerTransfer OriginalPathWeights RootDiscreteBudget RootRecordGood
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

abbrev RootPoint := ℝ×ℝ×ℝ
variable {K J N R Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def leftList (rec : Record K J N R Q) (e : Fin N) : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J :=
  fun i a=>rec.2.1 e.castSucc i (rec.2.2.1 e i a)

def rightList (rec : Record K J N R Q) (e : Fin N) : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J :=
  fun i a=>rec.2.1 e.succ i (rec.2.2.2 e i a)

def recordGeometry (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootPoint) : ℂ :=
  ∏e, edgeGeometry rec adjoint (freshGood value μ d₀ Y L exponents q)
    (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ e

def recordKernel (S : ℕ) (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (q : RootPoint) (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) : ℂ :=
  recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ q * ρ g

theorem edgeGeometry_eq (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (q : RootPoint) (e : Fin N) :
    edgeGeometry rec adjoint (freshGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ e =
      freshGeometry (adjoint e) value μ U V d₀ Y L exponents η ψ major σ
        (rec.1 e.castSucc).val (leftList rec e) (rec.1 e.succ).val (rightList rec e) q := rfl

theorem recordGeometry_measurable (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) :
    Measurable (recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ) := by
  change Measurable (fun q=>∏e : Fin N, freshGeometry (adjoint e) value μ U V d₀ Y L exponents
    η ψ major σ (rec.1 e.castSucc).val (leftList rec e) (rec.1 e.succ).val (rightList rec e) q)
  exact Finset.measurable_prod _ (fun e _=>freshGeometry_measurable (adjoint e) value μ
    U V d₀ Y L exponents η ψ major σ
      (rec.1 e.castSucc).val (leftList rec e) (rec.1 e.succ).val (rightList rec e))

theorem recordGeometry_norm_le_one (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (hη : ∀t, ‖η t‖≤1) (hψ : ∀t, ‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ) (q : RootPoint) :
    ‖recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ q‖≤1 := by
  unfold recordGeometry
  rw [norm_prod]
  exact Finset.prod_le_one₀ (fun _ _=>norm_nonneg _) (fun e _=>
    edgeGeometry_norm_le_one rec adjoint _ _ _ _ U V d₀ Y η ψ major hmajor σ hd hη hψ e)

theorem recordKernel_norm_le_one (S : ℕ) (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (U V d₀ Y L : ℝ) (hd : 0<d₀) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (hη : ∀t, ‖η t‖≤1) (hψ : ∀t, ‖ψ t‖≤1)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) (hρ : ∀g, ‖ρ g‖≤1)
    (q : RootPoint) (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) :
    ‖recordKernel S rec adjoint value μ U V d₀ Y L exponents η ψ major σ ρ q g‖≤1 := by
  rw [recordKernel,norm_mul]
  have h := mul_le_mul (recordGeometry_norm_le_one rec adjoint value μ U V d₀ Y L hd exponents η ψ hη hψ
    major hmajor σ q) (hρ g) (norm_nonneg _) (by norm_num : (0:ℝ)≤1)
  simpa only [one_mul] using h

theorem recordKernel_constant (S : ℕ) (rec : Record K J N R Q) (adjoint : Fin N→Bool)
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (hK : 1≤K) (hQ : 2≤Q) (hv : ∀i p,value i p≤Q)
    (U V d₀ Y L : ℝ) (hY : 1≤Y) (hU : 0<U) (hV : 0<V) (exponents : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (hsupport : ∀t,η t≠0→1/2≤t) (major : Set ProductCircle) (σ : ℤ)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ)
    (n : ℕ) (j : Index) (hj : j∈grid n)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q)
    (g : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)) :
    recordKernel S rec adjoint value μ U V d₀ Y L exponents η ψ major σ ρ p g =
      recordKernel S rec adjoint value μ U V d₀ Y L exponents η ψ major σ ρ q g := by
  unfold recordKernel recordGeometry
  congr 1
  apply Finset.prod_congr rfl
  intro e he
  change freshGeometry (adjoint e) value μ U V d₀ Y L exponents η ψ major σ
    (rec.1 e.castSucc).val (leftList rec e) (rec.1 e.succ).val (rightList rec e) p =
    freshGeometry (adjoint e) value μ U V d₀ Y L exponents η ψ major σ
    (rec.1 e.castSucc).val (leftList rec e) (rec.1 e.succ).val (rightList rec e) q
  exact freshGeometry_constant (adjoint e) value μ R hK hQ hv d₀ Y L exponents hY
    n j hj U V hU hV η ψ hsupport major σ hout
    (rec.1 e.castSucc).val (rec.1 e.succ).val (rec.1 e.castSucc).property (rec.1 e.succ).property
    (leftList rec e) (rightList rec e) p q hp hq

theorem eventually_record_power (hPD : RootCountContract)
    (K : ℕ) (hK : 1≤K) (C δ C_S : ℝ) (hC : 0≤C) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ P : Fin K→Type, ∀ [∀i,Fintype (P i)],
      ∀ U V d₀ Y : ℝ, ∀ S : ℕ, ∀ [Fintype (ZMod S)],
      x^δ≤U → U≤x^2 → x^δ≤V → V≤x^2 → 1≤U*V → 0<d₀ → 1≤Y →
      1≤S → Squarefree S → (S:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ)) →
      ∀ rec : SourceRecord K C (Real.log x),
      ∀ value : (i : Fin K)→P i→ℕ, ∀ μ : (i : Fin K)→P i→ℝ,
      (∀i p,value i p≤rootPrimeCeiling (Real.log x)) →
      ∀ exponents : Fin K→ℝ, ∀ η ψ : ℝ→ℂ,
      (∀t, ‖η t‖≤1) → (∀t, ‖ψ t‖≤1) → (∀t,η t≠0→1/2≤t) →
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      ∀ adjoint : Fin (momentLength (Real.log x))→Bool,
      ∀ ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ, (∀g, ‖ρ g‖≤1) →
      ‖variableRootSum U V S (fullInterval 1 16) (fullInterval 1 2) (fullInterval 0 1)
          (recordKernel S rec adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ ρ) -
        rootIntegral U V S
          (recordKernel S rec adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ ρ)‖ ≤
        U*V*x^(-(δ/32000)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_subdivisions δ hδ,
    eventually_variable_root_transfer hPD δ C_S hδ hCS,
    eventually_combinedFaces_small K C δ hC hδ,eventually_transfer_cost δ hδ] with x hx hn ht hb hcost
  intro P instP U V d₀ Y S inst hU hU' hV hV' hUV hd hY hS hSq hSize
    rec value μ hv exponents η ψ hη hψ hsupport major hmajor σ adjoint ρ hρ
  let n := subdivisions δ x
  let R := rootPositionRadius C (Real.log x)
  let Q := rootPrimeCeiling (Real.log x)
  let bad := combinedFaces n (integerPositionBox R) U V
    (sourceEndpoints (J:=momentPadding (Real.log x)) R Q Y (Real.log x) exponents)
  let F := recordKernel S rec adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ ρ
  have hx0 : 0<x := by linarith
  have hUp : 0<U := (Real.rpow_pos_of_pos hx0 δ).trans_le hU
  have hVp : 0<V := (Real.rpow_pos_of_pos hx0 δ).trans_le hV
  have hQ : 2≤Q := primeCeiling_ge_two (Real.log x) (Real.log_nonneg hx)
  have hbad : bad⊆grid n := combinedFaces_subset_grid _ _ _ _ _
  have hvolume : coverVolume n bad≤x^(-(δ/16000)) := by
    simpa only [bad,n,R,Q,sourceEndpoints,sourceMultiplierCeiling,momentMultiplicity] using
      hb U V Y exponents hUV hY
  have hF : ∀q g, ‖F q g‖≤1 :=
    recordKernel_norm_le_one S rec adjoint value μ U V d₀ Y (Real.log x) hd exponents η ψ hη hψ
      major hmajor σ ρ hρ
  have hmeas (g) : Measurable (fun q=>F q g) :=
    (recordGeometry_measurable rec adjoint value μ U V d₀ Y (Real.log x) exponents η ψ major σ).mul_const (ρ g)
  have hstable : ∀j∈grid n,j∉bad→∀q,PartContains n j q→∀g,F q g=F (representative n j) g := by
    intro j hj hjbad q hq g
    exact recordKernel_constant S rec adjoint value μ hK hQ hv U V d₀ Y (Real.log x) hY hUp hVp
      exponents η ψ hsupport major σ ρ n j hj hjbad q (representative n j)
      (part_subset_closed n j q hq) (part_subset_closed n j _ (representative_mem n hn.1 j)) g
  exact (ht n bad hn.1 hbad hn.2.1 U V (x^(-(δ/16000))) S
    hU hU' hV hV' hvolume hS hSq hSize F (fun j=>F (representative n j)) hF
      (fun j _ g=>hF _ g)
      (averageKernel_integrable S F (fun g=>bounded_measurable_integrable _ (hmeas g) (fun q=>hF q g)))
      hstable).trans (hcost U V (by linarith))

end Elliptic.Operator.RootRecordKernel
