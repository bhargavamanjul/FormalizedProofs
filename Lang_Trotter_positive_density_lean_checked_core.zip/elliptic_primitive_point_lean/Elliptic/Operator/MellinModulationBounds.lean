module

public import Elliptic.Operator.FourierL1Control
public import Mathlib.Analysis.Calculus.Deriv.Support

/-!
# Uniform control of the endpoint Mellin modulation

The modulation exp(i λ exp z) has two explicit derivatives. Its second
derivative after multiplying a fixed compact profile is bounded by a
fixed integrable function times (1+|λ|)^2. Combined with the proved
Fourier L1 bound this gives the source's polynomial cost in λ.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinModulationBounds
open MeasureTheory FourierTransform
set_option backward.isDefEq.respectTransparency false

abbrev Smooth (h : ℝ→ℂ) := ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) h

def modulation (lam x : ℝ) : ℂ := Complex.exp (Complex.I*((lam*Real.exp x:ℝ):ℂ))
def rate (lam x : ℝ) : ℂ := Complex.I*((lam*Real.exp x:ℝ):ℂ)
def modulated (h : ℝ→ℂ) (lam x : ℝ) : ℂ := h x*modulation lam x

theorem modulation_norm (lam x : ℝ) : ‖modulation lam x‖=1 :=
  Complex.norm_exp_I_mul_ofReal _

theorem rate_norm (lam x : ℝ) : ‖rate lam x‖=|lam| *Real.exp x := by
  rw [rate,norm_mul,Complex.norm_I,one_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_mul,abs_of_pos (Real.exp_pos x)]

theorem modulation_hasDerivAt (lam x : ℝ) :
    HasDerivAt (modulation lam) (modulation lam x*rate lam x) x := by
  have hh := (((Real.hasDerivAt_exp x).const_mul lam).ofReal_comp.const_mul Complex.I).cexp
  unfold modulation rate
  exact hh

theorem rate_hasDerivAt (lam x : ℝ) : HasDerivAt (rate lam) (rate lam x) x := by
  exact ((Real.hasDerivAt_exp x).const_mul lam).ofReal_comp.const_mul Complex.I

theorem modulated_smooth (h : ℝ→ℂ) (hh : Smooth h) (lam : ℝ) : Smooth (modulated h lam) := by
  unfold modulated modulation
  apply hh.mul
  apply ContDiff.cexp
  have hr : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun x:ℝ=>lam*Real.exp x) := by fun_prop
  have hc : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun x:ℝ=>((lam*Real.exp x:ℝ):ℂ)) :=
    Complex.ofRealCLM.contDiff.comp hr
  exact contDiff_const.mul hc

theorem modulated_deriv (h : ℝ→ℂ) (hh : Smooth h) (lam : ℝ) :
    deriv (modulated h lam)=fun x=>deriv h x*modulation lam x+h x*(modulation lam x*rate lam x) := by
  funext x
  exact (((contDiff_infty_iff_deriv.mp hh).1 x).hasDerivAt.mul (modulation_hasDerivAt lam x)).deriv

/-- The literal second derivative, retaining both linear and quadratic λ terms. -/
theorem modulated_second_deriv (h : ℝ→ℂ) (hh : Smooth h) (lam x : ℝ) :
    deriv (deriv (modulated h lam)) x=
      deriv (deriv h) x*modulation lam x+
      2*deriv h x*modulation lam x*rate lam x+
      h x*modulation lam x*((rate lam x)^2+rate lam x) := by
  have hd := (contDiff_infty_iff_deriv.mp hh).1
  have hd' := (contDiff_infty_iff_deriv.mp (contDiff_infty_iff_deriv.mp hh).2).1
  have hh' := ((hd' x).hasDerivAt.mul (modulation_hasDerivAt lam x)).add
    ((hd x).hasDerivAt.mul ((modulation_hasDerivAt lam x).mul (rate_hasDerivAt lam x)))
  rw [modulated_deriv h hh lam]
  convert hh'.deriv using 1 <;> simp only [Pi.mul_apply,Pi.add_apply] <;> ring

/-- Fixed integrable majorant for all modulation parameters. -/
def derivativeBudget (h : ℝ→ℂ) (x : ℝ) : ℝ :=
  ‖deriv (deriv h) x‖+2*‖deriv h x‖*Real.exp x+
    ‖h x‖*((Real.exp x)^2+Real.exp x)

theorem derivativeBudget_nonneg (h : ℝ→ℂ) (x : ℝ) : 0≤derivativeBudget h x := by
  unfold derivativeBudget
  positivity

theorem derivativeBudget_integrable (h : ℝ→ℂ) (hc : HasCompactSupport h) (hh : Smooth h) :
    Integrable (derivativeBudget h) := by
  have hh' := (contDiff_infty_iff_deriv.mp hh).2
  have hh'' := (contDiff_infty_iff_deriv.mp hh').2
  have hcont : Continuous (derivativeBudget h) := by
    unfold derivativeBudget
    fun_prop
  have hsupp : HasCompactSupport (derivativeBudget h) :=
    (hc.deriv.deriv.norm.add (hc.deriv.norm.mul_left.mul_right)).add hc.norm.mul_right
  exact hcont.integrable_of_hasCompactSupport hsupp

/-- Uniform second-derivative norm bound. -/
theorem modulated_second_norm_le (h : ℝ→ℂ) (hh : Smooth h) (lam x : ℝ) :
    ‖deriv (deriv (modulated h lam)) x‖≤(1+|lam|)^2*derivativeBudget h x := by
  have hL0 : 0≤|lam| := abs_nonneg lam
  have hL1 : 1≤(1+|lam|)^2 := by nlinarith
  have hL : |lam| ≤(1+|lam|)^2 := by nlinarith [sq_nonneg |lam|]
  have hL2 : |lam|^2≤(1+|lam|)^2 := by nlinarith
  rw [modulated_second_deriv h hh lam x]
  calc
    _ ≤ ‖deriv (deriv h) x*modulation lam x‖+
        ‖2*deriv h x*modulation lam x*rate lam x‖+
        ‖h x*modulation lam x*((rate lam x)^2+rate lam x)‖ :=
      (norm_add_le _ _).trans (add_le_add_left (norm_add_le _ _) _)
    _ ≤ ‖deriv (deriv h) x‖+2*‖deriv h x‖*(|lam| *Real.exp x)+
        ‖h x‖*((|lam| *Real.exp x)^2+|lam| *Real.exp x) := by
      simp only [norm_mul,modulation_norm,mul_one,rate_norm,Complex.norm_ofNat]
      apply add_le_add_right
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      exact (norm_add_le _ _).trans_eq (by rw [norm_pow,rate_norm])
    _ ≤ (1+|lam|)^2*‖deriv (deriv h) x‖+
        (1+|lam|)^2*(2*‖deriv h x‖*Real.exp x)+
        (1+|lam|)^2*(‖h x‖*((Real.exp x)^2+Real.exp x)) := by
      apply add_le_add
      · apply add_le_add
        · exact le_mul_of_one_le_left (norm_nonneg _) hL1
        · nlinarith [mul_le_mul_of_nonneg_right hL (show 0≤2*‖deriv h x‖*Real.exp x by positivity)]
      · have h1 := mul_le_mul_of_nonneg_right hL2 (show 0≤‖h x‖*(Real.exp x)^2 by positivity)
        have h2 := mul_le_mul_of_nonneg_right hL (show 0≤‖h x‖*Real.exp x by positivity)
        nlinarith
    _ = _ := by unfold derivativeBudget; ring

/-- A uniform L1 cost for modulation of any fixed smooth compact profile. -/
theorem modulated_fourier_L1 (h : ℝ→ℂ) (hc : HasCompactSupport h) (hh : Smooth h) :
    ∃C:ℝ,0<C∧∀lam:ℝ,(∫v:ℝ,‖𝓕 (modulated h lam) v‖)≤C*(1+|lam|)^2 := by
  let A := ∫x:ℝ,‖h x‖
  let B := ∫x:ℝ,derivativeBudget h x
  let C := 1+Real.pi*(A+(2*Real.pi)^(-2:ℤ)*B)
  have hA : 0≤A := integral_nonneg fun x=>norm_nonneg _
  have hB : 0≤B := integral_nonneg (derivativeBudget_nonneg h)
  have hC : 0<C := by dsimp [C]; positivity
  refine ⟨C,hC,?_⟩
  intro lam
  have hmodc : HasCompactSupport (modulated h lam) := hc.mul_right
  have hmods := modulated_smooth h hh lam
  have hs := FourierL1Control.compact_profile_fourier_L1 (modulated h lam) hmodc hmods
  have hi : Integrable (fun x=>‖deriv (deriv (modulated h lam)) x‖) := by
    have hh1 := (contDiff_infty_iff_deriv.mp hmods).2
    have hh2 := (contDiff_infty_iff_deriv.mp hh1).2
    exact (hh2.continuous.norm).integrable_of_hasCompactSupport hmodc.deriv.deriv.norm
  have hd := integral_mono hi ((derivativeBudget_integrable h hc hh).const_mul ((1+|lam|)^2))
    (modulated_second_norm_le h hh lam)
  rw [integral_const_mul] at hd
  have hnorm : (∫x:ℝ,‖modulated h lam x‖)=A := by
    simp only [modulated,norm_mul,modulation_norm,mul_one,A]
  rw [hnorm] at hs
  have hL : 1≤(1+|lam|)^2 := by nlinarith [abs_nonneg lam]
  have hp : 0≤(2*Real.pi)^(-2:ℤ) := by positivity
  have hmul := mul_le_mul_of_nonneg_left hd hp
  have ha := mul_le_mul_of_nonneg_right hL hA
  have hpi := mul_le_mul_of_nonneg_left (add_le_add ha hmul) Real.pi_pos.le
  dsimp [C]
  dsimp [A,B] at *
  nlinarith [sq_nonneg (1+|lam|)]

/-- The logarithmic profile of the source cutoff is compactly supported. -/
theorem logProfile_compact (η : ℝ→ℂ) (hη : Artin.MarkedSource.SmoothCompactWeight η) :
    HasCompactSupport (fun x:ℝ=>η (Real.exp x)) := by
  apply HasCompactSupport.of_support_subset_isCompact (isCompact_Icc : IsCompact (Set.Icc (0:ℝ) (Real.log 2)))
  intro x hx
  have hs := hη.2.2 hx
  constructor
  · have := Real.exp_lt_exp.mp (by simpa using hs.1 : Real.exp 0<Real.exp x)
    exact this.le
  · exact ((Real.le_log_iff_exp_le (by norm_num : (0:ℝ)<2)).mpr hs.2.le)

theorem twistedCutoff_logProfile (η : ℝ→ℂ) (lam : ℝ) :
    (fun x:ℝ=>MellinPrimeSeparation.twistedCutoff η lam (Real.exp x))=
      modulated (fun x:ℝ=>η (Real.exp x)) (-2*Real.pi*lam) := by
  funext x
  unfold MellinPrimeSeparation.twistedCutoff Elliptic.SourceContracts.additivePhase modulated modulation
  congr 2
  push_cast
  ring

/-- The source C5 polynomial cost is proved for its literal Mellin kernel,
uniformly in both the additive parameter and the positive scale. -/
theorem twisted_scaledKernel_L1 (η : ℝ→ℂ) (hη : Artin.MarkedSource.SmoothCompactWeight η) :
    ∃C:ℝ,0<C∧∀lam Y:ℝ,
      (∫v:ℝ,‖Artin.MarkedSource.scaledKernel (MellinPrimeSeparation.twistedCutoff η lam) Y v‖)
        ≤C*(1+|lam|)^2 := by
  have hc := logProfile_compact η hη
  have hh : Smooth (fun x:ℝ=>η (Real.exp x)) := hη.1.comp Real.contDiff_exp
  obtain ⟨C,hC,hbound⟩ := modulated_fourier_L1 _ hc hh
  refine ⟨C*(1+2*Real.pi)^2,by positivity,?_⟩
  intro lam Y
  simp_rw [FourierL1Control.scaledKernel_norm]
  rw [FourierL1Control.fourierKernel_L1_eq,twistedCutoff_logProfile]
  have hb := hbound (-2*Real.pi*lam)
  have he : |-2*Real.pi*lam|=2*Real.pi*|lam| := by
    rw [abs_mul,abs_mul,abs_of_pos Real.pi_pos]
    norm_num
  rw [he] at hb
  have hlin : 1+2*Real.pi*|lam| ≤(1+2*Real.pi)*(1+|lam|) := by
    nlinarith [abs_nonneg lam,Real.pi_pos]
  have hsq := pow_le_pow_left₀ (by positivity : 0≤1+2*Real.pi*|lam|) hlin 2
  have hm := mul_le_mul_of_nonneg_left hsq hC.le
  exact hb.trans (by nlinarith [hm])

end Elliptic.Operator.MellinModulationBounds
