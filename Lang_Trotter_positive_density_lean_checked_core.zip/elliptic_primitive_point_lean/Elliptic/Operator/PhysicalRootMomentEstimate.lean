module

public import Elliptic.Operator.PhysicalRootIndependentTail

/-! Absorption of the root integral and comparison errors into the final
physical moment saving. The root box has its literal volume, fifteen. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootIndependentMoment
open MeasureTheory RootGridMeasure
open scoped BigOperators

theorem norm_le_of_root_integral_error
    (z : ℂ) (β U V L E : ℝ) (N : ℕ) (F : RootPoint→ℂ)
    (hUV : 0≤U*V) (hL : 16≤L) (hN : 1≤N) (hβ : |β|≤1)
    (herror : ‖z-((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)*(∫q in rootBox,F q)‖
      ≤U*V*L^(-(E+1)*(N:ℝ)))
    (hbound : ∀q∈rootBox,‖F q‖≤L^(-(E+2)*(N:ℝ))) :
    ‖z‖≤U*V*L^(-E*(N:ℝ)) := by
  have hL1 : 1≤L := by linarith
  have hz : 1≤Real.pi^2/6 := by nlinarith [Real.pi_gt_three]
  have hscale : ‖((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)‖≤U*V := by
    rw [norm_mul,Complex.norm_real,Complex.norm_real,Real.norm_eq_abs,Real.norm_eq_abs,
      abs_of_nonneg (div_nonneg hUV (by linarith))]
    calc
      _ ≤ (U*V/(Real.pi^2/6))*1 := mul_le_mul_of_nonneg_left hβ (by positivity)
      _ ≤ _ := by rw [mul_one]; exact div_le_self hUV hz
  have hint : ‖∫q in rootBox,F q‖≤15*L^(-(E+2)*(N:ℝ)) := by
    have hi := norm_setIntegral_le_of_norm_le_const
      (show volume rootBox<⊤ by rw [RootArchimedeanTransfer.rootBox_volume]; norm_num) hbound
    simpa only [Measure.real,RootArchimedeanTransfer.rootBox_volume,ENNReal.toReal_ofNat,mul_comm] using hi
  have hmain : ‖((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)*(∫q in rootBox,F q)‖
      ≤U*V*L^(-(E+1)*(N:ℝ)) := by
    rw [norm_mul]
    apply (mul_le_mul hscale hint (norm_nonneg _) hUV).trans
    apply mul_le_mul_of_nonneg_left _ hUV
    convert const_mul_rpow_moment_le (a:=E+1) hL1 (by linarith : (15:ℝ)≤L) hN using 1 <;>
      congr 2 <;> ring
  calc
    ‖z‖ ≤ ‖z-((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)*(∫q in rootBox,F q)‖+
        ‖((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)*(∫q in rootBox,F q)‖ := by
      let w : ℂ := ((U*V/(Real.pi^2/6):ℝ):ℂ)*(β:ℂ)*(∫q in rootBox,F q)
      change ‖z‖≤‖z-w‖+‖w‖
      have hh := norm_add_le (z-w) w
      have heq : z-w+w=z := sub_add_cancel _ _
      rw [heq] at hh
      exact hh
    _ ≤ U*V*L^(-(E+1)*(N:ℝ))+U*V*L^(-(E+1)*(N:ℝ)) := add_le_add herror hmain
    _ = U*V*(2*L^(-(E+1)*(N:ℝ))) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (const_mul_rpow_moment_le hL1 (by linarith : (2:ℝ)≤L) hN) hUV

theorem norm_le_of_baseline_root_integral_error
    {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]
    (value : ∀i,P i→ℕ) (damping : ℕ→ℝ)
    (z : ℂ) (U V L E : ℝ) (N : ℕ) (F : RootPoint→ℂ)
    (hUV : 0≤U*V) (hL : 16≤L) (hN : 1≤N)
    (hdamping : ∀j<N+1,0≤damping j ∧ damping j≤1) (hsize : ∀i p,N<value i p)
    (herror : ‖z-((U*V/(Real.pi^2/6):ℝ):ℂ)*(baselineProduct value damping N:ℂ)*
      (∫q in rootBox,F q)‖≤U*V*L^(-(E+1)*(N:ℝ)))
    (hbound : ∀q∈rootBox,‖F q‖≤L^(-(E+2)*(N:ℝ))) :
    ‖z‖≤U*V*L^(-E*(N:ℝ)) :=
  norm_le_of_root_integral_error z (baselineProduct value damping N) U V L E N F
    hUV hL hN (baselineProduct_abs_le_one value damping hdamping hsize) herror hbound

end Elliptic.Operator.PhysicalRootIndependentMoment
