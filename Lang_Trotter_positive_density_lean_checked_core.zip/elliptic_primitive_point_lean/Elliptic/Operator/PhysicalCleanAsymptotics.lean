module
public import Elliptic.Operator.PhysicalCleanBanNorm
public import Elliptic.Operator.CleanBanAsymptotics

/-! One uniform logarithmic saving for the cancellation estimate and its
proved coincidence-ban error. The major-arc exponent G+4 is chosen before
any fixed number of groups, mass constant, or cell partition varies. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open Filter
open scoped SchwartzMap

/-- The actual prime lower bound gives the small atom used to restore
the coincidence ban. -/
theorem clean_prime_atom_le (ν C p T : ℝ) (hC : 0≤C)
    (hp : Real.exp T≤p) (hν : ν≤C/p) : ν≤C*Real.exp (-T) := by
  have hp0 : 0<p := (Real.exp_pos T).trans_le hp
  apply hν.trans
  have hh := div_le_div_of_nonneg_left hC (Real.exp_pos T) hp
  simpa only [div_eq_mul_inv,← Real.exp_neg] using hh

/-- Uniformly over all allowed Y and balanced boxes, the ban-restored
clean budget has arbitrary logarithmic saving. The exponent G+4 is
independent of K and all fixed multiplicative constants. -/
theorem eventually_banned_clean_saving
    (ψ : 𝓢(ℝ,ℂ)) (Cgeo M Aψ Cmass Catom G : ℝ) (K : ℕ)
    (hgeo : 1≤Cgeo) (hM : 0≤M) (hAψ : 0≤Aψ)
    (hmass : 0≤Cmass) (hatom : 0≤Catom) (hG : 0≤G) :
    ∀ᶠ L : ℝ in atTop, ∀ (Y : ℝ) (A B : ℕ),
      Real.exp (L^(1/10:ℝ))≤Y → Y≤Real.exp L →
      Y^(1/5:ℝ)≤A → Y^(1/5:ℝ)≤B → (A:ℝ)*B≤Cgeo*Y →
      M*smoothedDeterminantBudget ψ A B (L^(G+4)) Y 1 +
        (Aψ*(33+4*Cgeo*(L^(G+4))^3))*
          ((K:ℝ)*(Catom*Real.exp (-L^(1/10:ℝ)))*Cmass^K) ≤ L^(-G) := by
  let D := Aψ*(33+4*Cgeo)*((K:ℝ)*Catom*Cmass^K)
  have hcore := eventually_smoothed_clean_saving ψ Cgeo M (G+1) hgeo hM (by linarith)
  have hban := eventually_clean_ban_atom_saving D (3*(G+4)) (G+1)
  filter_upwards [eventually_ge_atTop (2:ℝ),hcore,hban] with L hL hc hb
  intro Y A B hYlo hYhi hA hB harea
  have hL0 : 0<L := by linarith
  have hc' : M*smoothedDeterminantBudget ψ A B (L^(G+4)) Y 1≤L^(-(G+1)) := by
    convert hc Y A B hYlo hYhi hA hB harea using 1 <;> congr 3 <;> ring
  have hpow : (L^(G+4))^3=L^(3*(G+4)) := by
    rw [← Real.rpow_natCast (L^(G+4)) 3,← Real.rpow_mul hL0.le]
    congr 1
    ring
  have hrow : (Aψ*(33+4*Cgeo*(L^(G+4))^3))*
      ((K:ℝ)*(Catom*Real.exp (-L^(1/10:ℝ)))*Cmass^K) ≤
      D*(1+L^(3*(G+4)))*Real.exp (-L^(1/10:ℝ)) := by
    rw [hpow]
    have hCg : 0≤Cgeo := by linarith
    have hnon : 0≤(K:ℝ)*Catom*Cmass^K := by positivity
    have hp : 0≤L^(3*(G+4)) := Real.rpow_nonneg hL0.le _
    have hh : 33+4*Cgeo*L^(3*(G+4))≤(33+4*Cgeo)*(1+L^(3*(G+4))) := by nlinarith
    have hm := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hh hAψ)
      (mul_nonneg hnon (Real.exp_pos (-L^(1/10:ℝ))).le)
    convert hm using 1 <;> (try dsimp [D]) <;> ring
  have hp : L^(-(G+1))=L^(-G)/L := by
    rw [show -(G+1)= -G + (-1) by ring,Real.rpow_add hL0,Real.rpow_neg_one]
    ring
  calc
    _ ≤ L^(-(G+1))+L^(-(G+1)) := add_le_add hc' (hrow.trans hb)
    _ ≤ L^(-G) := by
      rw [hp]
      rw [← add_div]
      apply (div_le_iff₀ hL0).mpr
      have hpos : 0≤L^(-G) := Real.rpow_nonneg hL0.le _
      nlinarith

end Elliptic.Operator
