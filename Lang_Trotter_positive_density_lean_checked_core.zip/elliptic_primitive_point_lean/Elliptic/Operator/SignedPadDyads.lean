module
public import Elliptic.Operator.SignedSourceDyads
public import Elliptic.Operator.PhysicalEndpointNorm
public import Elliptic.Operator.SignedPhysicalPairBridge
public import Mathlib.Data.Nat.Log

/-! Exact ordinary pad dyads and their uniform height/count budgets. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPadDyads
open scoped BigOperators
open SignedSourceDyads SignedPhysicalPairBridge
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

def padDyads (T : ℝ) : Finset ℕ := Finset.range (dyadCount T+1)

theorem padDyads_partition (T : ℝ) (D : ℕ) (hD : 0<D) (hDT : (D:ℝ)≤Real.exp T) :
    (∑j∈padDyads T,if (2:ℝ)^j≤D ∧ (D:ℝ)<2*(2:ℝ)^j then (1:ℝ) else 0)=1 := by
  have hpow : D≤2^dyadCount T := by exact_mod_cast hDT.trans (exp_le_two_pow_dyadCount T)
  have hj : Nat.log 2 D∈padDyads T := by
    apply Finset.mem_range.mpr
    have h := Nat.log_monotone (b:=2) hpow
    rw [Nat.log_pow (by norm_num : 1<2)] at h
    omega
  have he (j : ℕ) : ((2:ℝ)^j≤D ∧ (D:ℝ)<2*(2:ℝ)^j) ↔ Nat.log 2 D=j := by
    rw [Nat.log_eq_iff (Or.inr ⟨by norm_num,hD.ne'⟩)]
    constructor
    · rintro ⟨h1,h2⟩
      refine ⟨by exact_mod_cast h1,?_⟩
      have hh : D<2*2^j := by exact_mod_cast h2
      simpa only [pow_succ,mul_comm] using hh
    · rintro ⟨h1,h2⟩
      refine ⟨by exact_mod_cast h1,?_⟩
      have hh : (D:ℝ)<(2:ℝ)^(j+1) := by exact_mod_cast h2
      simpa only [pow_succ,mul_comm] using hh
  simp_rw [he]
  simp [hj]

theorem padDyads_card (T : ℝ) (hT : 0≤T) :
    ((padDyads T).card:ℝ)≤T/Real.log 2+3 := by
  have h := dyadCount_le T hT
  simp only [padDyads,Finset.card_range,Nat.cast_add,Nat.cast_one]
  linarith

theorem padDyads_card_log (K : ℕ) (L : ℝ) (hL : 1≤L) :
    ((padDyads (4*K*L^(21/100:ℝ))).card:ℝ)≤(4*K/Real.log 2+3)*L := by
  have hpow : L^(21/100:ℝ)≤L := by
    simpa using Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (21/100:ℝ)≤1)
  apply (padDyads_card _ (by positivity)).trans
  calc
    _ = (4*K/Real.log 2)*L^(21/100:ℝ)+3 := by ring
    _ ≤ (4*K/Real.log 2)*L+3*L := add_le_add
      (mul_le_mul_of_nonneg_left hpow (by positivity)) (by linarith)
    _ = _ := by ring

variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem activeProduct_height (L : ℝ) (hL : 1≤L) (value : ∀i,P i→ℕ)
    (hu : ∀i p,(value i p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))
    (a : PhysicalActiveLists P (momentPadding L)) :
    (activeProduct value a:ℝ)≤Real.exp (4*K*L^(21/100:ℝ)) := by
  have hLp : 0<L := by linarith
  have hm := momentMultiplicity_le_two_rpow hL
  have hm' : (momentPadding L:ℝ)+1≤2*L^(1/100:ℝ) := by
    simpa only [momentMultiplicity,Nat.cast_add,Nat.cast_one] using hm
  apply (PhysicalEndpointNorm.listProduct_le_exp L value hu a).trans
  apply Real.exp_le_exp.mpr
  calc
    _ ≤ 2*K*(2*L^(1/100:ℝ))*L^(1/5:ℝ) := by gcongr
    _ = _ := by rw [show (21/100:ℝ)=1/100+1/5 by norm_num,Real.rpow_add hLp]; ring

/-- The padded source scale has exponent .21, including all growing slots. -/
theorem pad_scale_height (L : ℝ) (hL : 1≤L) (value : ∀i,P i→ℕ)
    (hu : ∀i p,(value i p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))
    (a : PhysicalActiveLists P (momentPadding L)) (d₀ Y : ℝ)
    (hY : 0≤Y) (hd : d₀≤sourcePadProduct value a)
    (hy : Y≤sourceUnsharedProduct value a) :
    d₀*Y≤Real.exp (4*K*L^(21/100:ℝ)) := by
  calc
    _ ≤ (sourcePadProduct value a:ℝ)*(sourceUnsharedProduct value a:ℝ) :=
      mul_le_mul hd hy hY (Nat.cast_nonneg _)
    _ = (activeProduct value a:ℝ) := by rw [activeProduct_eq,Nat.cast_mul]
    _ ≤ _ := activeProduct_height L hL value hu a

end Elliptic.Operator.SignedPadDyads
