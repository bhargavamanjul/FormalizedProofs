module

public import Elliptic.Operator.PhysicalBirthRegistry
public import Elliptic.Operator.PrescribedPhysicalGhost
public import Elliptic.Operator.PrescribedEdgeRow

/-! # Causal lookup of prescribed pivot values

A ghost prescription reads either an earlier operation or an earlier
coordinate of its own actual ordered batch. Edge prescriptions read the
registry after the current ghost visit. Future labels are never queried.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthRegistry
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalPivotLookupDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

variable {I : Type} {J B : ℕ}

/-- Addresses already available before ghost visit j. -/
def BeforeGhost (j : ℕ) : Address I J B → Prop
  | .inl _ => True
  | .inr (.inl a) => a.1<j
  | .inr (.inr a) => a.1<j

/-- Addresses already available before edge j, including its ghost visit. -/
def BeforeEdge (j : ℕ) : Address I J B → Prop
  | .inl _ => True
  | .inr (.inl a) => a.1≤j
  | .inr (.inr a) => a.1<j

/-- An adaptive ghost target can additionally read its earlier batch coordinates. -/
def GhostPrecedes (j : ℕ) (i:I) (k:ℕ) (a : Address I J B) : Prop :=
  BeforeGhost j a ∨ ∃l : Fin B,l.val<k ∧ a=.inr (.inl (j,i,l))

/-- Numeric earlier-coordinate lookup, with zero only as an unused default. -/
def lookupGhost (r : Registry I J B) (j : ℕ) (i:I) {k:ℕ} (earlier : Fin k → ℕ) :
    Address I J B → ℕ
  | .inl a => (r (.inl a)).getD 0
  | .inr (.inl a) => if a.1=j ∧ a.2.1=i then
      if h : a.2.2.val<k then earlier ⟨a.2.2.val,h⟩ else 0
    else (r (.inr (.inl a))).getD 0
  | .inr (.inr a) => (r (.inr (.inr a))).getD 0

theorem lookupGhost_past (r : Registry I J B) (j : ℕ) (i:I) {k:ℕ} (earlier : Fin k → ℕ)
    (a : Address I J B) (ha : BeforeGhost j a) :
    lookupGhost r j i earlier a=(r a).getD 0 := by
  rcases a with a|(a|a)
  · rfl
  · have ht : a.1≠j := ne_of_lt ha
    simp [lookupGhost,ht]
  · rfl

theorem lookupGhost_current (r : Registry I J B) (j : ℕ) (i:I) {k:ℕ} (earlier : Fin k → ℕ)
    (l:Fin B) (hl:l.val<k) :
    lookupGhost r j i earlier (.inr (.inl (j,i,l)))=earlier ⟨l.val,hl⟩ := by
  simp [lookupGhost,hl]

/-- Lookup agrees with the completed log whenever only already available
values are consulted. This does not assume future information in r. -/
theorem lookupGhost_eq (r f : Registry I J B) (j : ℕ) (i:I) {k:ℕ} (earlier : Fin k → ℕ)
    (hbefore : ∀a,BeforeGhost j a → r a=f a)
    (hcurrent : ∀l : Fin B,∀hl:l.val<k,f (.inr (.inl (j,i,l)))=some (earlier ⟨l.val,hl⟩))
    (a : Address I J B) (ha : GhostPrecedes j i k a) :
    lookupGhost r j i earlier a=(f a).getD 0 := by
  rcases ha with ha|⟨l,hl,rfl⟩
  · rw [lookupGhost_past r j i earlier a ha,hbefore a ha]
  · rw [lookupGhost_current r j i earlier l hl,hcurrent l hl]
    rfl

variable {Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type}

/-- Updating a ghost visit advances exactly the available registry frontier. -/
theorem afterGhost_agrees (value : ∀i,P i → ℕ) (j:ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalGhostChoice s)
    (r f : Registry I J B) (hpast : ∀a,BeforeGhost j a → r a=f a)
    (hcurrent : ∀i a,f (.inr (.inl (j,i,a)))=
      (ActualHistoryBirths.ghostSlot c i a).map (value i)) :
    ∀a,BeforeEdge j a → afterGhost value j c r a=f a := by
  rintro (a|(a|a)) ha
  · exact hpast _ trivial
  · by_cases hj : a.1=j
    · subst hj
      simpa [afterGhost] using (hcurrent a.2.1 a.2.2).symm
    · have ht : a.1<j := lt_of_le_of_ne ha hj
      simpa [afterGhost,hj] using hpast (.inr (.inl a)) ht
  · exact hpast _ ha

/-- Updating an edge makes all its fresh flags available at the next visit. -/
theorem afterEdge_agrees (value : ∀i,P i → ℕ) (j:ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (r f : Registry I J B) (hpast : ∀a,BeforeEdge j a → r a=f a)
    (hcurrent : ∀i,f (.inr (.inr (j,i)))=(ActualHistoryBirths.freshSlot c i).map (value i)) :
    ∀a,BeforeGhost (j+1) a → afterEdge value j c r a=f a := by
  rintro (a|(a|a)) ha
  · exact hpast _ trivial
  · exact hpast _ (Nat.le_of_lt_succ ha)
  · by_cases hj : a.1=j
    · subst hj
      simpa [afterEdge] using (hcurrent a.2).symm
    · have ht : a.1<j := by change a.1<j+1 at ha; omega
      simpa [afterEdge,hj] using hpast (.inr (.inr a)) ht

end Elliptic.Operator.PhysicalBirthRegistry
