module

public import Elliptic.Operator.GhostBounds
public import Elliptic.Operator.MemoryTransitions
public import Mathlib.Algebra.BigOperators.Fin

/-!
# Actual ghost rows and the indexed factorial calculation

The actual ordered-state transition matrix is bounded by its literal
operation choices, retaining multiplicities of equal output tuples. This
file connects that finite weighted row to the calculation in GhostBounds.
It does not identify the adjoint column on the symmetric memory space.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators

/-- Exact enumeration of ordered prime batches by their length. -/
theorem sum_memoryState_by_length {P : Type*} [Fintype P] (B : ℕ)
    (F : (l : ℕ) → (Fin l → P) → ℝ) :
    (∑ fresh : MemoryState P B, F fresh.size fresh.values) =
      ∑ l ∈ Finset.range (B + 1), ∑ fresh : Fin l → P, F l fresh := by
  rw [Fintype.sum_sigma]
  simpa [MemoryState.size, MemoryState.values] using
    (Fin.sum_univ_eq_sum_range (fun l => ∑ fresh : Fin l → P, F l fresh) (B + 1))

/-- Indexed deletion choices and actual finite batches reindex to the
powerset/range/tuple sum in the exact ghost row formula. -/
theorem sum_ghost_choices_hits {P : Type*} [Fintype P] (k B : ℕ)
    (hits : Finset (Fin k)) (F : (S : Finset (Fin k)) → (l : ℕ) → (Fin l → P) → ℝ) :
    (∑ c : Finset (Fin k) × MemoryState P B,
      if c.1 ⊆ hits then F c.1 c.2.size c.2.values else 0) =
      ∑ S ∈ hits.powerset, ∑ l ∈ Finset.range (B + 1), ∑ fresh : Fin l → P, F S l fresh := by
  classical
  rw [Fintype.sum_prod_type]
  calc
    _ = ∑ S : Finset (Fin k), if S ∈ hits.powerset then
        ∑ fresh : MemoryState P B, F S fresh.size fresh.values else 0 := by
      apply Finset.sum_congr rfl
      intro S hS
      by_cases h : S ⊆ hits <;> simp [Finset.mem_powerset, h]
    _ = ∑ S ∈ hits.powerset, ∑ fresh : MemoryState P B, F S fresh.size fresh.values :=
      Finset.sum_ite_mem_eq _ _
    _ = _ := Finset.sum_congr rfl fun S hS => sum_memoryState_by_length B (F S)

/-- Absolute values of the actual signed ghost coefficients give exactly
the forward nonnegative coefficients used in the row calculation. -/
theorem ghostChoiceWeight_abs {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V) (hη : 0 ≤ η) (hq : 0 ≤ q) (hρ : 0 ≤ ρ) :
    |ghostChoiceWeight ν V η q ρ anchor m c| =
      (η / ρ) ^ c.1.card * (q / ρ ^ 2) ^ (memoryHits anchor m \ c.1).card *
        (η * V / ρ) ^ c.2.size * tupleWeight ν c.2.values / (c.2.size.factorial : ℝ) := by
  have ht : 0 ≤ tupleWeight ν c.2.values := Finset.prod_nonneg fun i _ => hν (c.2.values i)
  unfold ghostChoiceWeight
  simp only [abs_div, abs_mul, abs_pow, abs_neg, abs_of_nonneg hη, abs_of_nonneg hρ,
    abs_of_nonneg hq, abs_of_nonneg hV, abs_of_nonneg ht, abs_of_nonneg (show (0 : ℝ) ≤ (c.2.size.factorial : ℝ) by positivity)]

/-- The normalized absolute weighted row over literal operation choices. -/
def ghostAbsoluteChoiceRow {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) : ℝ := by
  classical
  exact ∑ c : GhostChoice m, if hc : GhostChoice.Valid anchor m c then
    |ghostChoiceWeight ν V η q ρ anchor m c| *
      (v0 ^ (ghostOutput anchor m c hc).size / v0 ^ m.size) else 0

/-- Dropping only the output-size truncation bounds the actual operation
choices by the proved indexed ghost row; the indexed hit condition is
retained exactly. -/
theorem ghostAbsoluteChoiceRow_le_indexed {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hV : 0 ≤ V) (hη : 0 ≤ η) (hq : 0 ≤ q)
    (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0) :
    ghostAbsoluteChoiceRow ν V η q ρ v0 anchor m ≤
      ghostIndexedWeightedRow m.size (memoryHits anchor m) ν
        (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 B := by
  classical
  let F := fun (S : Finset (Fin m.size)) (l : ℕ) (fresh : Fin l → P) =>
    ((η / ρ) ^ S.card * (q / ρ ^ 2) ^ ((memoryHits anchor m).card - S.card) *
      (η * V / ρ) ^ l * tupleWeight ν fresh / (l.factorial : ℝ)) *
        (v0 ^ (m.size - S.card + l) / v0 ^ m.size)
  have hpoint (c : GhostChoice m) :
      (if hc : GhostChoice.Valid anchor m c then
        |ghostChoiceWeight ν V η q ρ anchor m c| *
          (v0 ^ (ghostOutput anchor m c hc).size / v0 ^ m.size) else 0) ≤
        if c.1 ⊆ memoryHits anchor m then F c.1 c.2.size c.2.values else 0 := by
    by_cases hc : GhostChoice.Valid anchor m c
    · rw [dite_eq_left hc, ite_eq_left hc.1, ghostOutput_size,
        ghostChoiceWeight_abs ν V η q ρ anchor m c hν hV hη hq hρ,
        Finset.card_sdiff_of_subset hc.1]
    · rw [dite_eq_right hc]
      split_ifs with hS
      · exact ghost_choice_weight_nonneg m.size (memoryHits anchor m) c.1 ν
          (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 c.2.size c.2.values hν
          (div_nonneg hq (sq_nonneg ρ)) (div_nonneg hη hρ)
          (div_nonneg (mul_nonneg hη hV) hρ) hv0
      · exact le_rfl
  unfold ghostAbsoluteChoiceRow
  apply (Finset.sum_le_sum fun c _ => hpoint c).trans_eq
  exact sum_ghost_choices_hits m.size B (memoryHits anchor m) F

/-- The actual transition row is dominated by its indexed operation-choice
row, even if many different choices have the same output tuple. -/
theorem ghostTransition_weighted_row_le_choices {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (hv0 : 0 ≤ v0) :
    (∑ n : MemoryState (AnchoredParticle P Line) B,
      ‖ghostTransition ν V η q ρ anchor m n‖ * (v0 ^ n.size / v0 ^ m.size)) ≤
      ghostAbsoluteChoiceRow ν V η q ρ v0 anchor m := by
  classical
  unfold ghostTransition ghostApply ghostAbsoluteChoiceRow
  calc
    _ ≤ ∑ n : MemoryState (AnchoredParticle P Line) B,
        (∑ c : GhostChoice m, ‖if hc : GhostChoice.Valid anchor m c then
          (ghostChoiceWeight ν V η q ρ anchor m c : ℂ) *
            (if ghostOutput anchor m c hc = n then 1 else 0) else 0‖) *
          (v0 ^ n.size / v0 ^ m.size) := by
      apply Finset.sum_le_sum
      intro n hn
      exact mul_le_mul_of_nonneg_right (norm_sum_le _ _)
        (div_nonneg (pow_nonneg hv0 _) (pow_nonneg hv0 _))
    _ = _ := by
      simp_rw [Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro c hc
      by_cases hvalid : GhostChoice.Valid anchor m c
      · simp only [dite_eq_left hvalid]
        rw [Finset.sum_eq_single (ghostOutput anchor m c hvalid)]
        · simp [Complex.norm_real, Real.norm_eq_abs]
        · intro n hn hne
          simp [Ne.symm hne]
        · intro hnot
          exact (hnot (Finset.mem_univ _)).elim
      · simp [hvalid]

/-- The measured ghost-kernel row is exactly the transition row, since
the actual positive factorial target mass cancels its density denominator. -/
theorem ghostKernel_weighted_row_eq_transition {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (hν : ∀ p, 0 < ν p) (V η q ρ v0 : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) :
    (∑ n : MemoryState (AnchoredParticle P Line) B,
      n.mass (anchoredParticleMass ν) * ‖ghostKernel ν V η q ρ anchor m n‖ *
        (v0 ^ n.size / v0 ^ m.size)) =
      ∑ n : MemoryState (AnchoredParticle P Line) B,
        ‖ghostTransition ν V η q ρ anchor m n‖ * (v0 ^ n.size / v0 ^ m.size) := by
  apply Finset.sum_congr rfl
  intro n hn
  have hnpos : 0 < n.mass (anchoredParticleMass ν) :=
    MemoryState.mass_pos (anchoredParticleMass ν) (fun x => hν x.1) n
  unfold ghostKernel
  rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hnpos]
  field_simp

/-- A concrete measured-kernel weighted row estimate from the actual
indexed source choices and actual prime masses. -/
theorem ghostKernel_weighted_row_le_indexed {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 < ν p) (hV : 0 ≤ V) (hη : 0 ≤ η) (hq : 0 ≤ q)
    (hρ : 0 ≤ ρ) (hv0 : 0 ≤ v0) :
    (∑ n : MemoryState (AnchoredParticle P Line) B,
      n.mass (anchoredParticleMass ν) * ‖ghostKernel ν V η q ρ anchor m n‖ *
        (v0 ^ n.size / v0 ^ m.size)) ≤
      ghostIndexedWeightedRow m.size (memoryHits anchor m) ν
        (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 B := by
  rw [ghostKernel_weighted_row_eq_transition ν hν]
  exact (ghostTransition_weighted_row_le_choices ν V η q ρ v0 anchor m hv0).trans
    (ghostAbsoluteChoiceRow_le_indexed ν V η q ρ v0 anchor m
      (fun p => (hν p).le) hV hη hq hρ hv0)

/-- The concrete forward Schur row, with its input weight restored and
one constant uniform in all memory states and cutoffs. The corresponding
symmetric-space adjoint-column identification is not asserted here. -/
theorem ghostKernel_weighted_row_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 < ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ ^ 2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    let v0 := ghostSchurWeight ρ Q Vmax
    (∑ n : MemoryState (AnchoredParticle P Line) B,
      n.mass (anchoredParticleMass ν) * ‖ghostKernel ν V η q ρ anchor m n‖ * v0 ^ n.size) ≤
        Real.exp (v0 * max 1 Vmax * s / ρ) * v0 ^ m.size := by
  dsimp
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hindexed := (ghost_forward_adjoint_uniform m.size (memoryHits anchor m) ν
    q η ρ V Q Vmax s B (fun p => (hν p).le) hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax).1
  have hbound := (ghostKernel_weighted_row_le_indexed ν V η q ρ
    (ghostSchurWeight ρ Q Vmax) anchor m hν hV0 hη0 hq0 hρ.le hv.le).trans hindexed
  apply (div_le_iff₀ (pow_pos hv m.size)).mp
  simpa only [Finset.sum_div, mul_div_assoc] using hbound

end Elliptic.Operator
