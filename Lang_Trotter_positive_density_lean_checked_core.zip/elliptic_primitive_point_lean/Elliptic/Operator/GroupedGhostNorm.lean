module

public import Elliptic.Operator.GroupedMemoryGhost
public import Elliptic.Operator.GhostNorm

/-!
# The literal grouped ghost as a compressed tensor operation

The tensor below is built from the actual one-group indexed choices.  Its
kernel is proved to be the product of the actual one-group transitions.
The physical operation is its total-memory-cutoff compression, with the
position and active lists unchanged.  No tensor norm or column bound is
an assumption in these identifications.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance groupedGhostNormDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

def ghostChoiceTarget {P : Type*} {Line : P → Type*} {B : ℕ}
    (anchor : ∀ p, Line p) (m : MemoryState (AnchoredParticle P Line) B)
    (c : GhostChoice m) : MemoryState (AnchoredParticle P Line) B :=
  if hc : GhostChoice.Valid anchor m c then ghostOutput anchor m c hc else m

def ghostSignedCoefficient {P : Type*} [Fintype P] {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B) (c : GhostChoice m) : ℂ :=
  if GhostChoice.Valid anchor m c then (ghostChoiceWeight ν V η q ρ anchor m c : ℂ) else 0

theorem ghostApply_eq_signed_choice_sum {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (V η q ρ : ℝ)
    (anchor : ∀ p, Line p) (F : MemoryState (AnchoredParticle P Line) B → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    ghostApply ν V η q ρ anchor F m = ∑ c : GhostChoice m,
      ghostSignedCoefficient ν V η q ρ anchor m c * F (ghostChoiceTarget anchor m c) := by
  unfold ghostApply ghostSignedCoefficient ghostChoiceTarget
  apply Finset.sum_congr rfl
  intro c _
  split_ifs <;> simp

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}

def groupedGhostTensorApply [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : ∀ i p, Line i p) (F : PhysicalMemories P Line B → ℂ)
    (m : PhysicalMemories P Line B) : ℂ :=
  ∑ c : ∀ i, GhostChoice (m i),
    (∏ i, ghostSignedCoefficient (ν i) (V i) η q ρ (anchor i) (m i) (c i)) *
      F (fun i => ghostChoiceTarget (anchor i) (m i) (c i))

/-- On elementary tensors, this is precisely the tensor product of the
actual one-group ghosts, including all indexed-choice multiplicities. -/
theorem groupedGhostTensorApply_product [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : ∀ i p, Line i p)
    (F : ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B → ℂ)
    (m : PhysicalMemories P Line B) :
    groupedGhostTensorApply ν V η q ρ anchor (fun n => ∏ i, F i (n i)) m =
      ∏ i, ghostApply (ν i) (V i) η q ρ (anchor i) (F i) (m i) := by
  unfold groupedGhostTensorApply
  simp_rw [ghostApply_eq_signed_choice_sum]
  rw [Fintype.prod_sum]
  apply Finset.sum_congr rfl
  intro c _
  exact (Finset.prod_mul_distrib).symm

theorem product_coordinate_indicator {X : I → Type*}
    [∀ i, DecidableEq (X i)] [DecidableEq (∀ i, X i)]
    (a b : ∀ i, X i) :
    (∏ i, if a i = b i then (1:ℂ) else 0) = if a=b then 1 else 0 := by
  rw [Finset.prod_ite_zero]
  simp only [Finset.mem_univ, forall_true_left, Finset.prod_const_one]
  simp only [funext_iff]

/-- The full coupled-test action has the actual product transition
matrix. Thus the elementary-tensor identification is not the only bridge. -/
theorem groupedGhostTensorApply_eq_transition_sum [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : ∀ i p, Line i p) (F : PhysicalMemories P Line B → ℂ)
    (m : PhysicalMemories P Line B) :
    groupedGhostTensorApply ν V η q ρ anchor F m =
      ∑ n : PhysicalMemories P Line B,
        (∏ i, ghostTransition (ν i) (V i) η q ρ (anchor i) (m i) (n i)) * F n := by
  unfold ghostTransition
  simp_rw [ghostApply_eq_signed_choice_sum, Fintype.prod_sum, Finset.sum_mul]
  rw [Finset.sum_comm]
  unfold groupedGhostTensorApply
  apply Finset.sum_congr rfl
  intro c _
  simp_rw [Finset.prod_mul_distrib]
  have hδ (n : PhysicalMemories P Line B) :
      (∏ i, if ghostChoiceTarget (anchor i) (m i) (c i) = n i then (1:ℂ) else 0) =
        if (fun i => ghostChoiceTarget (anchor i) (m i) (c i)) = n then 1 else 0 :=
    product_coordinate_indicator (fun i => ghostChoiceTarget (anchor i) (m i) (c i)) n
  simp_rw [hδ]
  simp [mul_ite]

/-- Extension by zero imposes the source's total cutoff, rather than an
additional independent cutoff assumption on each tensor factor. -/
def physicalGhostZeroExtension (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (z : Z) (a : PhysicalActiveLists P J) (m : PhysicalMemories P Line B) : ℂ :=
  if h : (∑ i, (m i).size) ≤ B then F ⟨(z,a,m),h⟩ else 0

theorem physicalGhostOperation_eq_compressed_tensor [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    (physicalGhostOperation ν V η q ρ anchor).apply F s =
      groupedGhostTensorApply ν V η q ρ (anchor (s.position P Line J B))
        (physicalGhostZeroExtension F (s.position P Line J B) (s.active P Line J B))
        (s.memory P Line J B) := by
  rw [ChoiceOperation.apply_eq_all_choices]
  change (∑ c : PhysicalGhostChoice s, if hc : c.Valid anchor s then
    physicalGhostChoiceWeight ν V η q ρ anchor s c * F (c.output anchor s hc) else 0) = _
  unfold groupedGhostTensorApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hl : ∀ i, GhostChoice.Valid (anchor (s.position P Line J B) i)
      (s.memory P Line J B i) (c i)
  · have hcoef : (∏ i, ghostSignedCoefficient (ν i) (V i) η q ρ
        (anchor (s.position P Line J B) i) (s.memory P Line J B i) (c i)) =
        physicalGhostChoiceWeight ν V η q ρ anchor s c := by
      apply Finset.prod_congr rfl
      intro i _
      simp only [ghostSignedCoefficient, ite_eq_left (hl i)]
    rw [hcoef]
    have hout : (fun i => ghostChoiceTarget (anchor (s.position P Line J B) i)
        (s.memory P Line J B i) (c i)) =
        fun i => ghostOutput (anchor (s.position P Line J B) i)
          (s.memory P Line J B i) (c i) (hl i) := by
      funext i
      simp only [ghostChoiceTarget, dite_eq_left (hl i)]
    rw [hout]
    by_cases ht : (∑ i, c.outputSize i) ≤ B
    · have hv : c.Valid anchor s := ⟨hl,ht⟩
      rw [dite_eq_left hv]
      unfold physicalGhostZeroExtension
      simp only [ghostOutput_size]
      simp only [PhysicalGhostChoice.outputSize] at ht
      rw [dite_eq_left ht]
      rfl
    · have hv : ¬ c.Valid anchor s := fun h => ht h.2
      rw [dite_eq_right hv]
      unfold physicalGhostZeroExtension
      simp only [ghostOutput_size]
      simp only [PhysicalGhostChoice.outputSize] at ht
      rw [dite_eq_right ht, mul_zero]
  · obtain ⟨i,hi⟩ := not_forall.mp hl
    have hzero : (∏ i, ghostSignedCoefficient (ν i) (V i) η q ρ
        (anchor (s.position P Line J B) i) (s.memory P Line J B i) (c i)) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i) (by simp [ghostSignedCoefficient,hi])
    have hv : ¬ c.Valid anchor s := fun h => hi (h.1 i)
    rw [dite_eq_right hv, hzero, zero_mul]

/-- The physical measure factors into the unchanged active measure and
the exact factorial product memory measure. -/
theorem physicalMemory_mass_factorization
    (ν : ∀ i, P i → ℝ) (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    PhysicalMemoryState.mass P Line J B ν s =
      (∏ i, tupleWeight (ν i) (s.active P Line J B i)) *
        ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (s.memory P Line J B i) := by
  exact Finset.prod_mul_distrib

theorem sum_subtype_zero_extension {X : Type*} [Fintype X]
    (p : X → Prop) [DecidablePred p] (f : {x // p x} → ℝ) :
    (∑ x : {x // p x}, f x) = ∑ x : X, if h : p x then f ⟨x,h⟩ else 0 := by
  symm
  rw [Finset.sum_dite]
  simp only [Finset.sum_const_zero, add_zero]
  exact (Equiv.subtypeEquivRight (by simp)).sum_comp f

/-- Extension by zero is an exact isometry into the full product memory
space, after summing the unchanged physical/active coordinates. -/
theorem physicalGhostZeroExtension_l2_sq [Fintype Z] [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ) :
    finiteL2Sq Finset.univ (PhysicalMemoryState.mass P Line J B ν) F =
      ∑ z : Z, ∑ a : PhysicalActiveLists P J,
        (∏ i, tupleWeight (ν i) (a i)) *
          finiteL2Sq Finset.univ
            (fun m : PhysicalMemories P Line B =>
              ∏ i, MemoryState.mass (anchoredParticleMass (ν i)) (m i))
            (physicalGhostZeroExtension F z a) := by
  unfold finiteL2Sq
  rw [sum_subtype_zero_extension
    (fun x : Z × (PhysicalActiveLists P J × PhysicalMemories P Line B) =>
      (∑ i, (x.2.2 i).size) ≤ B)
    (fun s => PhysicalMemoryState.mass P Line J B ν s * ‖F s‖^2)]
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro z _
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro a _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m _
  by_cases h : (∑ i, (m i).size) ≤ B
  · simp only [h, dite_true, physicalGhostZeroExtension]
    rw [physicalMemory_mass_factorization]
    simp only [PhysicalMemoryState.active, PhysicalMemoryState.memory, mul_assoc]
  · simp [h, physicalGhostZeroExtension]

/-- The total cutoff is symmetric in every memory group.  Consequently
zero extension of a separately bag-symmetric physical test stays in the
separately symmetric tensor subspace required by the ghost norm. -/
theorem physicalGhostZeroExtension_bag_test
    (H : Z → PhysicalActiveLists P J →
      (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (z : Z) (a : PhysicalActiveLists P J) (m : PhysicalMemories P Line B) :
    physicalGhostZeroExtension
      (fun s => H (s.position P Line J B) (s.active P Line J B)
        (fun i => tupleBag (s.memory P Line J B i).values)) z a m =
      (if (∑ i, (tupleBag (m i).values).card) ≤ B then
        H z a (fun i => tupleBag (m i).values) else 0) := by
  simp only [tupleBag_card, Fintype.card_fin, physicalGhostZeroExtension]
  split_ifs <;> rfl

theorem ghostTransition_weighted_row_uniform {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (V η q ρ Q Vmax s : ℝ) (anchor : ∀ p, Line p)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    (∑ n : MemoryState (AnchoredParticle P Line) B,
      ‖ghostTransition ν V η q ρ anchor m n‖ * (ghostSchurWeight ρ Q Vmax)^n.size) ≤
      Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ) *
        (ghostSchurWeight ρ Q Vmax)^m.size := by
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hindexed := (ghost_forward_adjoint_uniform m.size (memoryHits anchor m) ν
    q η ρ V Q Vmax s B hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax).1
  have hbound := ((ghostTransition_weighted_row_le_choices ν V η q ρ
    (ghostSchurWeight ρ Q Vmax) anchor m hv.le).trans
      (ghostAbsoluteChoiceRow_le_indexed ν V η q ρ (ghostSchurWeight ρ Q Vmax)
        anchor m hν hV0 hη0 hq0 hρ.le hv.le)).trans hindexed
  apply (div_le_iff₀ (pow_pos hv m.size)).mp
  simpa only [Finset.sum_div, mul_div_assoc] using hbound

/-- The tensor's actual absolute weighted row has the product constant,
uniformly in the cutoff.  This is a row statement, not a claim about the
adjoint of the raw ordered-state matrix. -/
theorem groupedGhostTransition_weighted_row_uniform [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : ∀ i p, Line i p) (m : PhysicalMemories P Line B)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    (∑ n : PhysicalMemories P Line B,
      ‖∏ i, ghostTransition (ν i) (V i) η q ρ (anchor i) (m i) (n i)‖ *
        (ghostSchurWeight ρ Q Vmax)^(∑ i, (n i).size)) ≤
      (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I) *
        (ghostSchurWeight ρ Q Vmax)^(∑ i, (m i).size) := by
  let v := ghostSchurWeight ρ Q Vmax
  let C := Real.exp (v * max 1 Vmax*s/ρ)
  have hv : 0 ≤ v := (ghostSchurWeight_pos ρ Q Vmax hρ hQ).le
  have hrow i := ghostTransition_weighted_row_uniform (ν i) (V i) η q ρ Q Vmax s
    (anchor i) (m i) (hν i) (hs i) hs0 hρ hQ hq0 hqQ hη0 hη1 (hV0 i) (hVmax i)
  change (∑ n : PhysicalMemories P Line B,
    ‖∏ i, ghostTransition (ν i) (V i) η q ρ (anchor i) (m i) (n i)‖ *
      v^(∑ i, (n i).size)) ≤ C^(Fintype.card I)*v^(∑ i, (m i).size)
  calc
    _ = ∏ i, ∑ n : MemoryState (AnchoredParticle (P i) (Line i)) B,
        ‖ghostTransition (ν i) (V i) η q ρ (anchor i) (m i) n‖*v^n.size := by
      rw [Fintype.prod_sum]
      apply Finset.sum_congr rfl
      intro n _
      rw [norm_prod, ← Finset.prod_pow_eq_pow_sum, Finset.prod_mul_distrib]
    _ ≤ ∏ i, C*v^(m i).size := Finset.prod_le_prod₀
      (fun i _ => Finset.sum_nonneg (fun n _ => mul_nonneg (norm_nonneg _) (pow_nonneg hv _)))
      (fun i _ => hrow i)
    _ = _ := by
      rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ,
        Finset.prod_pow_eq_pow_sum]

/-- The total-memory compression only decreases the proven absolute row.
The constant is independent of both the individual and total cutoffs. -/
theorem groupedGhostCompressed_weighted_row_uniform [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q ρ Q Vmax s : ℝ)
    (anchor : ∀ i p, Line i p) (m : PhysicalMemories P Line B)
    (hν : ∀ i p, 0 ≤ ν i p) (hs : ∀ i, (∑ p, ν i p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ^2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : ∀ i, 0 ≤ V i) (hVmax : ∀ i, V i ≤ Vmax) :
    (∑ n : PhysicalMemories P Line B,
      if (∑ i, (n i).size) ≤ B then
        ‖∏ i, ghostTransition (ν i) (V i) η q ρ (anchor i) (m i) (n i)‖ *
          (ghostSchurWeight ρ Q Vmax)^(∑ i, (n i).size) else 0) ≤
      (Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax*s/ρ))^(Fintype.card I) *
        (ghostSchurWeight ρ Q Vmax)^(∑ i, (m i).size) := by
  refine (Finset.sum_le_sum fun n _ => ?_).trans
    (groupedGhostTransition_weighted_row_uniform ν V η q ρ Q Vmax s anchor m
      hν hs hs0 hρ hQ hq0 hqQ hη0 hη1 hV0 hVmax)
  split_ifs
  · exact le_rfl
  · exact mul_nonneg (norm_nonneg _) (pow_nonneg (ghostSchurWeight_pos ρ Q Vmax hρ hQ).le _)

end Elliptic.Operator
