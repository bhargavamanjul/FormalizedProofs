module

public import Elliptic.Operator.OriginalLifespanSchedule

/-!
# Recovering finite original leaves from chronological schedules
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators
open LifespanSchedule ScheduledPhysicalPath
attribute [local instance] Classical.propDecidable
local instance keyEquivDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace OriginalLeaf

/-- Read the finite original coordinates and one interval for every used
prime from an existing chronological schedule. Off-horizon data disappear. -/
def ofSchedule (d : ScheduledPhysicalPath anchor N J B) :
    OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) where
  position j := d.position j.val
  active j := d.active j.val
  sourcePerm j := d.sourcePerm j.val
  targetPerm j := d.targetPerm j.val
  interval i p := if hp : p ∈ d.primes i then
    some (⟨(d.lifespan i p).birth, Nat.lt_succ_of_le
      ((d.lifespan i p).birth_le_death.trans (d.lifespan i p).death_le)⟩,
      ⟨(d.lifespan i p).death, Nat.lt_succ_of_le (d.lifespan i p).death_le⟩)
    else none

variable (d : ScheduledPhysicalPath anchor N J B)

@[simp] theorem ofSchedule_position (j : ℕ) (hj : j≤N) :
    (ofSchedule d).positionAt j=d.position j := by
  simp [ofSchedule,OriginalPath.positionAt,OriginalPath.visit,Nat.min_eq_left hj]

@[simp] theorem ofSchedule_active (j : ℕ) (hj : j≤N) :
    (ofSchedule d).activeAt j=d.active j := by
  simp [ofSchedule,OriginalPath.activeAt,OriginalPath.visit,Nat.min_eq_left hj]

@[simp] theorem ofSchedule_sourcePerm (j : ℕ) (hj : j<N) :
    (ofSchedule d).sourcePermAt j=d.sourcePerm j := by
  simp [ofSchedule,OriginalPath.sourcePermAt,hj]

@[simp] theorem ofSchedule_targetPerm (j : ℕ) (hj : j<N) :
    (ofSchedule d).targetPermAt j=d.targetPerm j := by
  simp [ofSchedule,OriginalPath.targetPermAt,hj]

@[simp] theorem ofSchedule_primes (i : I) : (ofSchedule d).primes i=d.primes i := by
  ext p
  simp [mem_primes,ofSchedule]

@[simp] theorem ofSchedule_birth (i : I) (p : P i) (hp : p ∈ d.primes i) :
    (ofSchedule d).birth i p=(d.lifespan i p).birth := by
  simp [birth,ofSchedule,hp]

@[simp] theorem ofSchedule_death (i : I) (p : P i) (hp : p ∈ d.primes i) :
    (ofSchedule d).death i p=(d.lifespan i p).death := by
  simp [death,ofSchedule,hp]

@[simp] theorem ofSchedule_activeVisits (i : I) (p : P i) (hp : p ∈ d.primes i) :
    (ofSchedule d).toOriginalPath.activeVisits i p=(d.lifespan i p).active := by
  ext j
  rw [OriginalPath.mem_activeVisits]
  constructor
  · rintro ⟨hj,ha⟩
    rw [ofSchedule_active d j hj] at ha
    exact ((d.active_lifespan j hj i p).mpr ha).2
  · intro ha
    have hj := ((d.lifespan i p).active_bounds j ha).2.trans (d.lifespan i p).death_le
    rw [ofSchedule_active d j hj]
    exact ⟨hj,(d.active_lifespan j hj i p).mp ⟨hp,ha⟩⟩

@[simp] theorem ofSchedule_sourceLists (j : ℕ) (hj : j<N) :
    (ofSchedule d).sourceLists j=d.sourceLists j := by
  funext i k
  simp [OriginalPath.sourceLists,ofSchedule_active d j hj.le,
    ofSchedule_sourcePerm d j hj,ScheduledPhysicalPath.sourceLists]

@[simp] theorem ofSchedule_targetLists (j : ℕ) (hj : j<N) :
    (ofSchedule d).targetLists j=d.targetLists j := by
  funext i k
  simp only [OriginalPath.targetLists,ofSchedule_active d (j+1) hj,ofSchedule_targetPerm d j hj]
  rw [d.active_next j hj]
  simp [ScheduledPhysicalPath.targetLists,ScheduledPhysicalPath.sourceLists]

@[simp] theorem ofSchedule_sourcePrime (j : ℕ) (hj : j<N) (i : I) :
    (ofSchedule d).sourcePrime j i=d.active j i (d.sourcePerm j i (Fin.last J)) := by
  simp [OriginalPath.sourcePrime,ofSchedule_sourceLists d j hj,ScheduledPhysicalPath.sourceLists]

@[simp] theorem ofSchedule_targetPrime (j : ℕ) (hj : j<N) (i : I) :
    (ofSchedule d).targetPrime j i=d.targetPrime j i := by
  simp [OriginalPath.targetPrime,ofSchedule_targetLists d j hj,ScheduledPhysicalPath.targetLists]

@[simp] theorem ofSchedule_beforeSet (j : ℕ) (i : I) :
    (ofSchedule d).beforeSet j i=before (d.primes i) (d.lifespan i) j := by
  unfold beforeSet before
  rw [ofSchedule_primes]
  apply Finset.filter_congr
  intro p hp
  simp [ofSchedule_birth d i p hp,ofSchedule_death d i p hp,
    ofSchedule_activeVisits d i p hp,PrimeLifespan.beforeGhost]

@[simp] theorem ofSchedule_afterSet (j : ℕ) (i : I) :
    (ofSchedule d).afterSet j i=after (d.primes i) (d.lifespan i) j := by
  unfold afterSet after
  rw [ofSchedule_primes]
  apply Finset.filter_congr
  intro p hp
  simp [ofSchedule_birth d i p hp,ofSchedule_death d i p hp,
    ofSchedule_activeVisits d i p hp,PrimeLifespan.afterGhost]

/-- The exact converse leaf construction. The all-active incidence
hypothesis is proved for the source geometry by existing transport lemmas;
the other leaf axioms come directly from the checked schedule. -/
theorem ofSchedule_valid (hbirth : d.ActiveBirthAnchored)
    (hactive : ∀ j, j≤N → ∀ i p, p ∈ d.primes i → j ∈ (d.lifespan i p).active →
      d.retained i p=anchor (d.position j) i p) :
    (ofSchedule d).Valid anchor B := by
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · intro j hj i
    rw [ofSchedule_active d j hj]
    exact d.active_distinct j hj i
  · intro j hj i k
    rw [ofSchedule_targetLists d j hj,ofSchedule_sourceLists d j hj]
    simp [ScheduledPhysicalPath.targetLists]
  · intro i p hn
    have hp : p ∉ d.primes i := by simpa [ofSchedule] using hn
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro j hj
    obtain ⟨hj,ha⟩ := (OriginalPath.mem_activeVisits _ _ _ _).mp hj
    rw [ofSchedule_active d j hj] at ha
    exact hp ((d.active_lifespan j hj i p).mpr ha).1
  · intro i p bd he
    by_cases hp : p ∈ d.primes i
    · simp only [ofSchedule,hp,↓reduceDIte,Option.some.injEq] at he
      subst bd
      exact (d.lifespan i p).birth_le_death
    · simp [ofSchedule,hp] at he
  · intro i p bd he j hj
    by_cases hp : p ∈ d.primes i
    · simp only [ofSchedule,hp,↓reduceDIte,Option.some.injEq] at he
      subst bd
      rw [ofSchedule_activeVisits d i p hp] at hj
      exact (d.lifespan i p).active_bounds j hj
    · simp [ofSchedule,hp] at he
  · intro i p bd he hs
    by_cases hp : p ∈ d.primes i
    · simp only [ofSchedule,hp,↓reduceDIte,Option.some.injEq] at he
      subst bd
      rw [ofSchedule_activeVisits d i p hp]
      exact (d.lifespan i p).singleton_active (congrArg Fin.val hs)
    · simp [ofSchedule,hp] at he
  · intro i p bd he j hj hcases
    by_cases hp : p ∈ d.primes i
    · simp only [ofSchedule,hp,↓reduceDIte,Option.some.injEq] at he
      subst bd
      have hbN := (d.lifespan i p).birth_le_death.trans (d.lifespan i p).death_le
      rw [ofSchedule_position d _ hbN,ofSchedule_position d j hj]
      rw [ofSchedule_activeVisits d i p hp] at hcases
      have hb := d.retained_eq_birth_anchor hbirth i p hp
      apply hb.symm.trans
      rcases hcases with hb' | hd' | ha
      · simpa only [hb'] using hb
      · by_cases ha : (d.lifespan i p).death ∈ (d.lifespan i p).active
        · exact hactive j hj i p hp (hd' ▸ ha)
        · apply d.death_line j hj i p
          exact Finset.mem_filter.mpr ⟨hp,hd',hd' ▸ ha⟩
      · exact hactive j hj i p hp ha
    · simp [ofSchedule,hp] at he
  · intro j hj
    simp_rw [ofSchedule_beforeSet]
    exact d.before_cutoff j hj
  · intro j hj
    simp_rw [ofSchedule_afterSet]
    exact d.after_cutoff j hj



/-- Used lifespans are recovered exactly, not just up to coefficients. -/
theorem ofSchedule_lifespan (h : (ofSchedule d).Valid anchor B)
    (i : I) (p : P i) (hp : p ∈ d.primes i) :
    (ofSchedule d).lifespan anchor h i p=d.lifespan i p := by
  have hp' : p ∈ (ofSchedule d).primes i := by simpa using hp
  rcases (ofSchedule d).lifespan_fields anchor h i p hp' with ⟨hb,hd,ha⟩
  apply PrimeLifespan.eq_of_observable_traces
  · intro j hj
    rw [ha,ofSchedule_activeVisits d i p hp]
  · intro j hj
    rw [PrimeLifespan.live_iff,PrimeLifespan.live_iff,hb,hd,
      ofSchedule_birth d i p hp,ofSchedule_death d i p hp]

theorem ofSchedule_stores (h : (ofSchedule d).Valid anchor B) (j : ℕ) (i : I) :
    stores ((ofSchedule d).primes i) ((ofSchedule d).lifespan anchor h i) j =
      stores (d.primes i) (d.lifespan i) j := by
  unfold stores
  rw [ofSchedule_primes]
  apply Finset.filter_congr
  intro p hp
  rw [ofSchedule_lifespan d h i p hp]

theorem ofSchedule_promotions (h : (ofSchedule d).Valid anchor B) (j : ℕ) (i : I) :
    promotions ((ofSchedule d).primes i) ((ofSchedule d).lifespan anchor h i) j =
      promotions (d.primes i) (d.lifespan i) j := by
  unfold promotions
  rw [ofSchedule_primes]
  apply Finset.filter_congr
  intro p hp
  rw [ofSchedule_lifespan d h i p hp]

theorem ofSchedule_store (h : (ofSchedule d).Valid anchor B) (j : ℕ) (hj : j<N) (i : I) :
    (ofSchedule d).store anchor h j i=d.store j i := by
  unfold store
  rw [ofSchedule_stores d h j i,d.store_set j hj i,ofSchedule_sourcePrime d j hj i]
  cases he : d.store j i <;> simp [optionalPrimeSet,he]

theorem ofSchedule_promote (h : (ofSchedule d).Valid anchor B) (j : ℕ) (hj : j<N) (i : I) :
    (ofSchedule d).promote anchor h j i=d.promote j i := by
  unfold promote
  rw [ofSchedule_promotions d h j i,d.promote_set j hj i,ofSchedule_targetPrime d j hj i]
  cases he : d.promote j i <;> simp [optionalPrimeSet,he]

/-- The converse construction recovers every field of the existing key,
including the derived store/promote flags and fresh target labels. -/
theorem ofSchedule_key (h : (ofSchedule d).Valid anchor B) :
    (ofSchedule d).key anchor h=d.canonicalKey := by
  apply CanonicalHistoryKey.ext
  · funext j
    rw [key_position]
    rfl
  · funext j
    rw [key_active]
    rfl
  · funext i p
    change Finset.filter _ Finset.univ = Finset.filter _ Finset.univ
    apply Finset.filter_congr
    intro j hj
    change (p ∈ (ofSchedule d).primes i ∧
      ((ofSchedule d).lifespan anchor h i p).birth≤j.val ∧
      j.val≤((ofSchedule d).lifespan anchor h i p).death) ↔
      p ∈ d.primes i ∧ (d.lifespan i p).birth≤j.val ∧ j.val≤(d.lifespan i p).death
    rw [ofSchedule_primes]
    by_cases hp : p ∈ d.primes i
    · rw [ofSchedule_lifespan d h i p hp]
    · simp [hp]
  · funext j
    rw [key_sourcePerm]
    rfl
  · funext j
    rw [key_targetPerm]
    rfl
  · funext j i
    exact ofSchedule_store d h j.val j.isLt i
  · funext j i
    exact ofSchedule_promote d h j.val j.isLt i
  · funext j i
    exact ofSchedule_targetPrime d j.val j.isLt i

/-- Forward and reverse constructions preserve the finite original leaf.
All original path coordinates and prime intervals are recovered. -/
theorem ofSchedule_toSchedule
    (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N)) (h : e.Valid anchor B) :
    ofSchedule (e.toSchedule anchor h)=e := by
  apply OriginalLeaf.ext
  · funext j
    exact e.key_position anchor h j
  · funext j
    exact e.key_active anchor h j
  · funext j
    exact e.key_sourcePerm anchor h j
  · funext j
    exact e.key_targetPerm anchor h j
  · funext i p
    cases he : e.interval i p with
    | none => simp [ofSchedule,toSchedule,mem_primes,he]
    | some bd => simp [ofSchedule,toSchedule,mem_primes,lifespan,he]

end OriginalLeaf
end Elliptic.Operator.OriginalLifespanSchedule
