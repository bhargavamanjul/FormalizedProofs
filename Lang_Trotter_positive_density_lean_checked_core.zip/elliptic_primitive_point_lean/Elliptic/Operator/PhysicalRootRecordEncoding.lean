module

public import Elliptic.Operator.PhysicalRootMomentReindex
public import Elliptic.Operator.OriginalResidueEncoding
public import Elliptic.Operator.RootRecordComparison

/-!
# Closed physical root paths in the numerical record space

The selected finite record family has exactly the two position endpoint
conditions. Numerical encoding does not duplicate paths or identify distinct
prime labels. All actual inactive-prime factors are preserved.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalRootRecordEncoding
open scoped BigOperators
open OriginalLifespanSchedule PhysicalPathRootEncoding PhysicalPathRootFinite
open PhysicalPathResidues PhysicalRootMomentReindex RootRecordEncoding
open SourceRootCount SingleEdgeRootEncoding OriginalPathWeights RootRecordKernel
attribute [local instance] Classical.propDecidable
local instance physicalRecordDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

abbrev FinitePath (K J N R : ℕ) (P : Fin K→Type) :=
  OriginalPath (Fin K) ↥(integerPositionBox R) P J N

def rawPath (r : FinitePath K J N R P) : OriginalPath (Fin K) (ℤ×ℤ) P J N :=
  mapPositions Subtype.val r

theorem rawPath_injective : Function.Injective (rawPath (K:=K) (J:=J) (N:=N) (R:=R) (P:=P)) :=
  mapPositions_injective _ Subtype.val_injective

def closedFinitePaths : Finset (FinitePath K J N R P) :=
  Finset.univ.filter (fun r=>(r.position 0).val=(1,0) ∧ (r.position (Fin.last N)).val=(1,0))

theorem closedFinitePaths_image :
    (closedFinitePaths (K:=K) (J:=J) (N:=N) (R:=R) (P:=P)).image rawPath=closedRootPaths R := by
  ext r
  constructor
  · intro h
    obtain ⟨s,hs,rfl⟩ := Finset.mem_image.mp h
    have hp := (Finset.mem_filter.mp hs).2
    exact Finset.mem_filter.mpr
      ⟨(mem_rootedPaths R _).mpr ⟨fun j=>(s.position j).property,hp.1⟩,hp.2⟩
  · intro h
    obtain ⟨hr,he⟩ := Finset.mem_filter.mp h
    obtain ⟨hpos,hs⟩ := (mem_rootedPaths R r).mp hr
    let s : FinitePath K J N R P :=
      {position:=fun j=>⟨r.position j,hpos j⟩,active:=r.active,
       sourcePerm:=r.sourcePerm,targetPerm:=r.targetPerm}
    exact Finset.mem_image.mpr ⟨s,Finset.mem_filter.mpr ⟨Finset.mem_univ _,hs,he⟩,rfl⟩

theorem numericActiveVisits_encode (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (r : FinitePath K J N R P) (p : ℕ) :
    OriginalPathWeights.activeVisits (encode id value hv r) p=numericActiveVisits value (rawPath r) p := by
  ext t
  simp only [OriginalPathWeights.activeVisits,numericActiveVisits,Finset.mem_filter]
  apply and_congr_right
  intro ht
  have hv' : OriginalPath.visit (N:=N) t=⟨t,Finset.mem_range.mp ht⟩ :=
    Fin.ext (Nat.min_eq_left (by have := Finset.mem_range.mp ht; omega))
  change (∃j : Fin (N+1),j.val=t ∧ ∃i k,value i (r.active j i k)=p) ↔
    ∃i k,value i (r.active (OriginalPath.visit t) i k)=p
  rw [hv']
  constructor
  · rintro ⟨j,hj,i,k,hk⟩
    have he : j=⟨t,Finset.mem_range.mp ht⟩ := Fin.ext hj
    subst j
    exact ⟨i,k,hk⟩
  · rintro ⟨i,k,hk⟩
    exact ⟨⟨t,Finset.mem_range.mp ht⟩,rfl,i,k,hk⟩

theorem residueFactor_encode (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (r : FinitePath K J N R P) (primes : Finset ℕ) (η : ℕ→ℝ)
    (ℓ : (p : ℕ)→Option (ZMod p)) :
    OriginalPathWeights.residueFactor (encode id value hv r) primes η ℓ =
      rootResidue value primes η (rawPath r) ℓ := by
  unfold OriginalPathWeights.residueFactor rootResidue
  apply Finset.prod_congr rfl
  intro p hp
  rw [numericActiveVisits_encode value hv r p]
  apply OriginalIndependentCRT.lineFactor_congr_visits
    (Finset.range (N+1)) _ (Finset.filter_subset _ _)
  intro j hj
  rw [OriginalIndependentCRT.positionAt_encode id value hv r j (Finset.mem_range.mp hj)]
  rfl

theorem recordGeometry_encode_root (value : ∀i,P i→ℕ) (hv : ∀i p,value i p<Q)
    (hinj : ∀i,Function.Injective (value i)) (μ : ∀i,P i→ℝ)
    (r : FinitePath K J N R P) (adjoint : ℕ→Bool)
    (U V d₀ Y L : ℝ) (hU : 0<U) (hV : 0<V) (exponents : Fin K→ℝ)
    (smooth ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ) (t : RootTriple) :
    recordGeometry (encode id value hv r) (fun j=>adjoint j.val) value μ U V d₀ Y L
      exponents smooth ψ major σ (RootVariableSum.normalizedRoot U V t) =
    rootGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint (rawPath r) t := by
  rw [recordGeometry_encode_range id value hv hinj]
  have hu : U*((t.1:ℝ)/U)=t.1 := mul_div_cancel₀ _ hU.ne'
  have hv' : V*((t.2.1:ℝ)/V)=t.2.1 := mul_div_cancel₀ _ hV.ne'
  unfold originalGeometry RootLiteralGeometry.geometry rootGeometry
  simp only [RootVariableSum.normalizedRoot,hu,hv',id_eq]
  rfl

end Elliptic.Operator.PhysicalRootRecordEncoding
