module
public import Elliptic.Operator.PrimeExceptionalCells
public import Elliptic.Operator.MajorArcSparseAsymptotics

/-! The literal small-prime exceptional cell count is subexponential,
uniformly in its character, shift, prime subset, and interval translate. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrimeExceptionalEnvelope
open Filter
open scoped BigOperators
open SmallPrimePower PrimeExceptionalCells MajorArcSparseAsymptotics
attribute [local instance] Classical.propDecidable
set_option maxHeartbeats 500000

 theorem sampleBudget_le (Y K : ℕ) (a : ℝ) (hY : 1≤Y) (hK : K≤Y) :
    sampleBudget Y (a+1) (a+(K:ℝ)+1)≤12*(Y:ℝ)*(1+Real.log (Y:ℝ))^3 := by
  have hy : (1:ℝ)≤Y := by exact_mod_cast hY
  have hk : (K:ℝ)≤Y := by exact_mod_cast hK
  have hl : 0≤Real.log (Y:ℝ) := Real.log_nonneg hy
  unfold sampleBudget
  have h1 : 2+(Real.log (Y:ℝ))^2≤2*(1+Real.log (Y:ℝ))^2 := by nlinarith
  have h2 : a+(K:ℝ)+1+1-(a+1)+4*(Y:ℝ)*(1+Real.log (Y:ℝ))≤
      6*(Y:ℝ)*(1+Real.log (Y:ℝ)) := by nlinarith
  calc
    _ ≤ (2*(1+Real.log (Y:ℝ))^2)*(6*(Y:ℝ)*(1+Real.log (Y:ℝ))) :=
      mul_le_mul h1 h2 (by nlinarith) (by positivity)
    _ = _ := by ring

 theorem prime_card_le (S : Finset ℕ) (P : ℝ) (hP : 1≤P)
    (hp : ∀p∈S,p.Prime) (hhi : ∀p∈S,(p:ℝ)≤2*P) : (S.card:ℝ)≤3*P := by
  let B := ⌈2*P⌉₊
  have hb : (B:ℝ)<2*P+1 := Nat.ceil_lt_add_one (by linarith : 0≤2*P)
  have hsub : S⊆Finset.Icc 1 B := by
    intro p hpS
    refine Finset.mem_Icc.mpr ⟨(hp p hpS).pos,?_⟩
    exact_mod_cast (hhi p hpS).trans (Nat.le_ceil (2*P))
  have hc : S.card≤B := by simpa using Finset.card_le_card hsub
  have hcR : (S.card:ℝ)≤B := by exact_mod_cast hc
  linarith

 theorem numerical_log_bound (K B j : ℕ) (a L P As : ℝ)
    (hL : 9≤L) (hP : 1≤P) (hB : 1≤B) (hK : K≤B^j)
    (hBP : (B:ℝ)≤3*P) (hj : (j:ℝ)≤L^2) (hlogB : Real.log (B:ℝ)≤L)
    (S : Finset ℕ) (hcard : (S.card:ℝ)≤3*P) :
    3*sampleBudget (B^j) (a+1) (a+(K:ℝ)+1)*
      ((j.factorial:ℝ)*((S.card:ℝ)/P^2)^j)/(L^(-As))^(2*j)≤
      Real.exp (Real.log 36+(12+(3+2*As)*(j:ℝ))*Real.log L) := by
  have hLp : 0<L := by linarith
  have hPp : 0<P := by linarith
  have hb : (1:ℝ)≤B := by exact_mod_cast hB
  have hl : 0≤Real.log (B:ℝ) := Real.log_nonneg hb
  have hlj : Real.log ((B:ℝ)^j)≤L^3 := by
    rw [Real.log_pow]
    calc
      _ ≤ L^2*L := mul_le_mul hj hlogB hl (sq_nonneg _)
      _ = _ := by ring
  have hpoly : 1+Real.log ((B:ℝ)^j)≤L^4 := by
    have hp3 : 1≤L^3 := one_le_pow₀ (by linarith)
    calc
      _ ≤ 1+L^3 := add_le_add le_rfl hlj
      _ ≤ 2*L^3 := by linarith
      _ ≤ L*L^3 := mul_le_mul_of_nonneg_right (by linarith) (by positivity)
      _ = _ := by ring
  have hf : (j.factorial:ℝ)≤(L^2)^j := by
    have hjf : (j.factorial:ℝ)≤(j:ℝ)^j := by exact_mod_cast Nat.factorial_le_pow j
    exact hjf.trans (pow_le_pow_left₀ (Nat.cast_nonneg _) hj _)
  have hc : (B:ℝ)*((S.card:ℝ)/P^2)≤9 := by
    rw [←mul_div_assoc,div_le_iff₀ (sq_pos_of_pos hPp)]
    nlinarith [mul_le_mul hBP hcard (Nat.cast_nonneg S.card) (by positivity : 0≤3*P)]
  have hcancel : (B:ℝ)^j*((S.card:ℝ)/P^2)^j≤L^j := by
    rw [←mul_pow]
    exact pow_le_pow_left₀ (by positivity) (hc.trans hL) _
  have hs := sampleBudget_le (B^j) K a (one_le_pow₀ hB) hK
  have hsample : 3*sampleBudget (B^j) (a+1) (a+(K:ℝ)+1)*
      ((j.factorial:ℝ)*((S.card:ℝ)/P^2)^j)≤36*(L^4)^3*(L^2)^j*L^j := by
    calc
      _ ≤ 3*(12*((B:ℝ)^j)*(1+Real.log ((B:ℝ)^j))^3)*
          ((j.factorial:ℝ)*((S.card:ℝ)/P^2)^j) := by
        exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (by simpa using hs) (by norm_num)) (by positivity)
      _ = 36*(1+Real.log ((B:ℝ)^j))^3*(j.factorial:ℝ)*
          ((B:ℝ)^j*((S.card:ℝ)/P^2)^j) := by ring
      _ ≤ 36*(L^4)^3*(L^2)^j*L^j := by
        gcongr
        exact add_nonneg (by norm_num) (Real.log_nonneg (one_le_pow₀ hb))
  apply (div_le_div_of_nonneg_right hsample (by positivity)).trans_eq
  have hexp : (L^(-As))^(2*j)=Real.exp ((-As)*(2*(j:ℝ))*Real.log L) := by
    rw [Real.rpow_def_of_pos hLp,←Real.exp_nat_mul]
    congr 1
    push_cast
    ring
  rw [hexp]
  have hpow (n:ℕ) : L^n=Real.exp ((n:ℝ)*Real.log L) := by
    rw [Real.exp_nat_mul,Real.exp_log hLp]
  rw [hpow 4,hpow 2,hpow j,←Real.exp_nat_mul,←Real.exp_nat_mul]
  rw [show (36:ℝ)=Real.exp (Real.log 36) by rw [Real.exp_log (by norm_num)],
    ←Real.exp_add,←Real.exp_add,←Real.exp_add,←Real.exp_sub]
  congr 1
  push_cast
  rw [Real.log_exp]
  ring

 theorem eventually_log_le_small_rpow :
    ∀ᶠ L : ℝ in atTop,Real.log L≤L^(1/100:ℝ) := by
  have ht := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<1/100)).tendsto_div_nhds_zero
  filter_upwards [ht.eventually_lt_const (by norm_num : (0:ℝ)<1),eventually_gt_atTop (0:ℝ)] with L h hL
  have hh : Real.log L/L^(1/100:ℝ)≤1 := by simpa using h.le
  simpa only [one_mul] using (div_le_iff₀ (Real.rpow_pos_of_pos hL (1/100:ℝ))).mp hh

/-- No exceptional-count hypothesis is supplied: the actual prime polynomial
and its actual unit cells satisfy the source subexponential envelope. -/
 theorem eventually_exceptionalCells_card (A c C As : ℝ) (hA : 0<A) (hc : 0<c)
    (hC : 0≤C) (hAs : 0≤As) :
    ∃H : ℝ,0<H ∧ ∀ᶠ L : ℝ in atTop,∀(K : ℕ) (a P : ℝ),
      (K:ℝ)≤Real.exp (A*L)→0<P→c*L^(1/10:ℝ)≤Real.log P→
      Real.log P≤C*L^(1/5:ℝ)→∀S : Finset ℕ,
      (∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q : ℕ) (χ : DirichletCharacter ℂ q) (ξ : ℝ),
      ((exceptionalCells K a (L^(-As)) (primePolynomial S P χ ξ)).card:ℝ)≤
        Real.exp (H*L^(91/100:ℝ)) := by
  let D := A/c
  let D' := D+1
  let H := 48+(3+2*As)*D'
  have hD : 0<D := div_pos hA hc
  have hD' : 0<D' := by dsimp [D'];linarith
  have hH : 0<H := by dsimp [H];positivity
  refine ⟨H,hH,?_⟩
  filter_upwards [eventually_log_le_small_rpow,
    eventually_mul_rpow_le D' 1 (9/10) 2 (by norm_num) (by norm_num),
    eventually_mul_rpow_le (Real.log 3+C) 1 (1/5) 1 (by norm_num) (by norm_num),
    eventually_ge_atTop (9:ℝ)] with L hlogL hjsmall hBsmall hL
  intro K a P hKexp hPp hlogPlo hlogPhi S hprime hShi q χ ξ
  have hLp : 0<L := by linarith
  have hLone : 1≤L := by linarith
  have hP : 1≤P := ((Real.log_pos_iff hPp.le).mp
    ((mul_pos hc (Real.rpow_pos_of_pos hLp _)).trans_le hlogPlo)).le
  let j := ⌈D*L^(9/10:ℝ)⌉₊
  let B := ⌈2*P⌉₊
  have hjlo : D*L^(9/10:ℝ)≤(j:ℝ) := Nat.le_ceil _
  have hjhi : (j:ℝ)≤D'*L^(9/10:ℝ) := by
    have hh := (Nat.ceil_lt_add_one (by positivity : 0≤D*L^(9/10:ℝ))).le
    have hpow : 1≤L^(9/10:ℝ) := Real.one_le_rpow hLone (by norm_num)
    dsimp only [j,D']
    nlinarith
  have hj : (j:ℝ)≤L^2 := by
    exact hjhi.trans (by simpa only [one_mul,Real.rpow_two] using hjsmall)
  have hBreal : 2*P≤(B:ℝ) := Nat.le_ceil _
  have hBP : (B:ℝ)≤3*P := by
    have hh := Nat.ceil_lt_add_one (by linarith : 0≤2*P)
    dsimp only [B]
    linarith
  have hB : 1≤B := by exact_mod_cast (show (1:ℝ)≤B by linarith)
  have hBpos : (0:ℝ)<B := by exact_mod_cast (by omega : 0<B)
  have hlogB : Real.log (B:ℝ)≤L := by
    have hb := Real.log_le_log hBpos hBP
    rw [Real.log_mul (by norm_num : (3:ℝ)≠0) hPp.ne'] at hb
    have h3 : 0≤Real.log 3 := Real.log_nonneg (by norm_num)
    have hpow : 1≤L^(1/5:ℝ) := Real.one_le_rpow hLone (by norm_num)
    have he : Real.log 3+Real.log P≤(Real.log 3+C)*L^(1/5:ℝ) := by nlinarith
    exact (hb.trans he).trans (by simpa only [one_mul,Real.rpow_one] using hBsmall)
  have hK : K≤B^j := by
    have hlo : c*L^(1/10:ℝ)≤Real.log (B:ℝ) :=
      hlogPlo.trans (Real.log_le_log hPp (by linarith))
    have hal : A*L=(D*L^(9/10:ℝ))*(c*L^(1/10:ℝ)) := by
      calc
        _ = (D*c)*L := by dsimp [D];field_simp
        _ = (D*c)*(L^(9/10:ℝ)*L^(1/10:ℝ)) := by rw [←Real.rpow_add hLp];norm_num
        _ = _ := by ring
    have he : A*L≤(j:ℝ)*Real.log (B:ℝ) := by
      rw [hal]
      exact mul_le_mul hjlo hlo (by positivity) (Nat.cast_nonneg _)
    have hh := hKexp.trans (Real.exp_le_exp.mpr he)
    rw [Real.exp_nat_mul,Real.exp_log hBpos] at hh
    exact_mod_cast hh
  have hBprime : ∀p∈S,p≤B := by
    intro p hp
    exact_mod_cast (hShi p hp).trans hBreal
  have hcard := prime_card_le S P hP hprime hShi
  have hh := (exceptionalCells_card K a (L^(-As)) (Real.rpow_pos_of_pos hLp _) S j hprime B hB
    hBprime P hPp χ ξ).trans (numerical_log_bound K B j a L P As hL hP hB hK hBP hj hlogB S hcard)
  apply hh.trans
  apply Real.exp_le_exp.mpr
  have hlog0 : 0≤Real.log L := Real.log_nonneg hLone
  have hp91 : 1≤L^(91/100:ℝ) := Real.one_le_rpow hLone (by norm_num)
  have hconst : Real.log 36≤36*L^(91/100:ℝ) := by
    have ht := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<36)
    nlinarith
  have hlinear : 12*Real.log L≤12*L^(91/100:ℝ) :=
    mul_le_mul_of_nonneg_left (hlogL.trans
      (Real.rpow_le_rpow_of_exponent_le hLone (by norm_num))) (by norm_num)
  have hmain : (3+2*As)*(j:ℝ)*Real.log L≤((3+2*As)*D')*L^(91/100:ℝ) := by
    calc
      _ ≤ (3+2*As)*(D'*L^(9/10:ℝ))*L^(1/100:ℝ) := by gcongr
      _ = _ := by
        rw [mul_assoc (3+2*As),mul_assoc D',←Real.rpow_add hLp]
        norm_num
        ring
  dsimp [H]
  nlinarith only [hconst,hlinear,hmain]

end Elliptic.Operator.PrimeExceptionalEnvelope
