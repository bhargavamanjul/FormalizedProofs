module

public import Elliptic.Operator.SourceBoundaryAssembly
public import Elliptic.Operator.IndependentLifespanCoefficient
public import Elliptic.Operator.OriginalPathWeights

/-!
# Constructing chronological schedules from original paths and prime lifespans

The independent-line expansion chooses a single optional interval for each
prime. The physical store and promotion flags are consequences of those
intervals and the original active lists. This file makes that construction
explicit, keeping the finite pending-memory cutoff on the leaf side.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators
open LifespanSchedule ScheduledPhysicalPath
attribute [local instance] Classical.propDecidable
local instance localDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable (I Z : Type) (P : I → Type) (J N : ℕ)

/-- The original path data, with both endpoint permutations retained.
`targetPerm` acts from the pre-symmetrized target list to the next list. -/
@[ext] structure OriginalPath where
  position : Fin (N+1) → Z
  active : Fin (N+1) → ∀ i, Fin (J+1) → P i
  sourcePerm : Fin N → ∀ _i : I, Equiv.Perm (Fin (J+1))
  targetPerm : Fin N → ∀ _i : I, Equiv.Perm (Fin (J+1))

variable {I Z P J N}
variable [Fintype I] [Fintype Z] [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {B : ℕ}

set_option synthInstance.maxSize 4096 in
instance : Fintype (OriginalPath I Z P J N) := derive_fintype% _

namespace OriginalPath
variable (r : OriginalPath I Z P J N)

def visit (j : ℕ) : Fin (N+1) := ⟨min j N, Nat.lt_succ_of_le (Nat.min_le_right _ _)⟩
def positionAt (j : ℕ) : Z := r.position (visit (N:=N) j)
def activeAt (j : ℕ) : PhysicalActiveLists P J := r.active (visit (N:=N) j)
def sourcePermAt (j : ℕ) : ∀ _i : I, Equiv.Perm (Fin (J+1)) :=
  if h : j < N then r.sourcePerm ⟨j,h⟩ else fun _ => Equiv.refl _
def targetPermAt (j : ℕ) : ∀ _i : I, Equiv.Perm (Fin (J+1)) :=
  if h : j < N then r.targetPerm ⟨j,h⟩ else fun _ => Equiv.refl _
def sourceLists (j : ℕ) : PhysicalActiveLists P J :=
  fun i k => r.activeAt j i (r.sourcePermAt j i k)
def targetLists (j : ℕ) : PhysicalActiveLists P J :=
  fun i k => r.activeAt (j+1) i ((r.targetPermAt j i).symm k)
def sourcePrime (j : ℕ) (i : I) : P i := r.sourceLists j i (Fin.last J)
def targetPrime (j : ℕ) (i : I) : P i := r.targetLists j i (Fin.last J)
def activeVisits (i : I) (p : P i) : Finset ℕ :=
  (Finset.range (N+1)).filter (fun j => ∃ k, r.activeAt j i k = p)

@[simp] theorem visit_coe (j : ℕ) (hj : j ≤ N) : (visit (N:=N) j).val = j :=
  Nat.min_eq_left hj

@[simp] theorem mem_activeVisits (i : I) (p : P i) (j : ℕ) :
    j ∈ r.activeVisits i p ↔ j ≤ N ∧ ∃ k, r.activeAt j i k = p := by
  simp [activeVisits, Nat.lt_succ_iff]

/-- The common-slot condition already present in the original geometry
forces the exact active-list update used by chronological memory edges. -/
theorem active_next_of_shared (j : ℕ)
    (hshared : ∀ i (k : Fin J), r.targetLists j i k.castSucc = r.sourceLists j i k.castSucc) :
    ∀ i k, r.activeAt (j+1) i k =
      Fin.lastCases (r.targetPrime j i)
        (fun t : Fin J => r.activeAt j i (r.sourcePermAt j i t.castSucc))
        (r.targetPermAt j i k) := by
  intro i k
  have hh : ∀ a, r.targetLists j i a =
      Fin.lastCases (r.targetPrime j i) (fun t : Fin J => r.sourceLists j i t.castSucc) a := by
    intro a
    refine Fin.lastCases ?_ (fun t => ?_) a
    · simp [targetPrime]
    · simpa using hshared i t
  have h := hh (r.targetPermAt j i k)
  simpa [targetLists, sourceLists] using h

/-- A disappearing active label is exactly the original unshared source
label. This is a membership statement, with no memory assumption. -/
theorem departed_eq_sourcePrime (j : ℕ) (i : I) (p : P i)
    (hshared : ∀ i (k : Fin J), r.targetLists j i k.castSucc = r.sourceLists j i k.castSucc)
    (hp : ∃ k, r.activeAt j i k=p) (hn : ¬∃ k, r.activeAt (j+1) i k=p) :
    p=r.sourcePrime j i := by
  obtain ⟨k,hk⟩ := hp
  let a := (r.sourcePermAt j i).symm k
  have ha : r.sourceLists j i a = p := by simp [sourceLists,a,hk]
  by_cases halast : a=Fin.last J
  · simpa [sourcePrime,halast] using ha.symm
  · have hac : a.val<J := by have := a.isLt; have hn : a.val ≠ J := fun h => halast (Fin.ext h); omega
    let t : Fin J := ⟨a.val,hac⟩
    have ht : t.castSucc=a := Fin.ext rfl
    apply False.elim
    apply hn
    refine ⟨(r.targetPermAt j i).symm ((t : Fin J).castSucc), ?_⟩
    have h := hshared i t
    rw [ht] at h
    simpa [targetLists,ha,ht] using h

/-- A newly active label is the original unshared target label. -/
theorem arrived_eq_targetPrime (j : ℕ) (i : I) (p : P i)
    (hshared : ∀ i (k : Fin J), r.targetLists j i k.castSucc = r.sourceLists j i k.castSucc)
    (hp : ∃ k, r.activeAt (j+1) i k=p) (hn : ¬∃ k, r.activeAt j i k=p) :
    p=r.targetPrime j i := by
  obtain ⟨k,hk⟩ := hp
  let a := r.targetPermAt j i k
  have ha : r.targetLists j i a = p := by simp [targetLists,a,hk]
  by_cases halast : a=Fin.last J
  · simpa [targetPrime,halast] using ha.symm
  · have hac : a.val<J := by have := a.isLt; have hn : a.val ≠ J := fun h => halast (Fin.ext h); omega
    let t : Fin J := ⟨a.val,hac⟩
    have ht : t.castSucc=a := Fin.ext rfl
    apply False.elim
    apply hn
    refine ⟨r.sourcePermAt j i t.castSucc, ?_⟩
    have h := hshared i t
    rw [ht] at h
    exact h.symm.trans ha

end OriginalPath



/-- The finite leaf data of the original primewise expansion. `none`
means the prime contributes only its extracted baseline. -/
@[ext] structure OriginalLeaf extends OriginalPath I Z P J N where
  interval : ∀ i, P i → Option (Fin (N+1) × Fin (N+1))

set_option synthInstance.maxSize 4096 in
instance : Fintype (OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N)) := derive_fintype% _

namespace OriginalLeaf
variable (d : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N))

def primes (i : I) : Finset (P i) := Finset.univ.filter (fun p => (d.interval i p).isSome)
def birth (i : I) (p : P i) : ℕ := ((d.interval i p).map (fun x => x.1.val)).getD 0
def death (i : I) (p : P i) : ℕ := ((d.interval i p).map (fun x => x.2.val)).getD 0
def beforeSet (j : ℕ) (i : I) : Finset (P i) := (d.primes i).filter (fun p =>
  d.birth i p < j ∧ j ≤ d.death i p ∧ j ∉ d.toOriginalPath.activeVisits i p)
def afterSet (j : ℕ) (i : I) : Finset (P i) := (d.primes i).filter (fun p =>
  d.birth i p ≤ j ∧ j < d.death i p ∧ j ∉ d.toOriginalPath.activeVisits i p)
def retained (anchor : Z → ∀ i p, Line i p) (i : I) (p : P i) : Line i p :=
  anchor (d.positionAt (d.birth i p)) i p

/-- Literal local leaf conditions: active visits belong to the chosen
interval, its endpoints/active visits have the retained line, common slots
are copied, and the explicitly chosen memory cutoff is respected. -/
structure Valid (anchor : Z → ∀ i p, Line i p) (B : ℕ) : Prop where
  active_distinct : ∀ j, j ≤ N → ∀ i, Function.Injective (d.activeAt j i)
  shared : ∀ j, j < N → ∀ i (k : Fin J), d.targetLists j i k.castSucc = d.sourceLists j i k.castSucc
  unused : ∀ i p, d.interval i p = none → d.toOriginalPath.activeVisits i p = ∅
  ordered : ∀ i p bd, d.interval i p = some bd → bd.1 ≤ bd.2
  contains_active : ∀ i p bd, d.interval i p = some bd → ∀ j ∈ d.toOriginalPath.activeVisits i p,
    bd.1.val ≤ j ∧ j ≤ bd.2.val
  singleton_active : ∀ i p bd, d.interval i p = some bd → bd.1 = bd.2 →
    bd.1.val ∈ d.toOriginalPath.activeVisits i p
  incidence : ∀ i p bd, d.interval i p = some bd → ∀ j, j ≤ N →
    (j=bd.1.val ∨ j=bd.2.val ∨ j ∈ d.toOriginalPath.activeVisits i p) →
    anchor (d.positionAt bd.1.val) i p = anchor (d.positionAt j) i p
  before_cutoff : ∀ j, j ≤ N → (∑ i, (d.beforeSet j i).card) ≤ B
  after_cutoff : ∀ j, j ≤ N → (∑ i, (d.afterSet j i).card) ≤ B

/-- Off the used prime set, a harmless fixed lifespan fills a total
function. No unused choice contributes to the leaf or its key. -/
def lifespan (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B) (i : I) (p : P i) : PrimeLifespan N :=
  if hi : (d.interval i p).isSome then
    let bd := (d.interval i p).get hi
    { birth := bd.1.val
      death := bd.2.val
      birth_le_death := h.ordered i p bd (Option.some_get hi).symm
      death_le := Nat.le_of_lt_succ bd.2.isLt
      active := d.toOriginalPath.activeVisits i p
      active_bounds := h.contains_active i p bd (Option.some_get hi).symm
      singleton_active := fun he => h.singleton_active i p bd (Option.some_get hi).symm (Fin.ext he) }
  else
    { birth := 0
      death := 0
      birth_le_death := le_rfl
      death_le := Nat.zero_le _
      active := {0}
      active_bounds := by intro j hj; simp only [Finset.mem_singleton] at hj; subst j; exact ⟨le_rfl,le_rfl⟩
      singleton_active := by simp }

@[simp] theorem mem_primes (i : I) (p : P i) :
    p ∈ d.primes i ↔ (d.interval i p).isSome := by simp [primes]

theorem lifespan_fields (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B)
    (i : I) (p : P i) (hp : p ∈ d.primes i) :
    (d.lifespan anchor h i p).birth = d.birth i p ∧
      (d.lifespan anchor h i p).death = d.death i p ∧
      (d.lifespan anchor h i p).active = d.toOriginalPath.activeVisits i p := by
  cases he : d.interval i p with
  | none => simp [mem_primes,he] at hp
  | some bd => simp [lifespan,birth,death,he]

theorem active_lifespan (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B)
    (j : ℕ) (hj : j ≤ N) (i : I) (p : P i) :
    (p ∈ d.primes i ∧ j ∈ (d.lifespan anchor h i p).active) ↔ ∃ k, d.activeAt j i k=p := by
  by_cases hp : p ∈ d.primes i
  · rw [(d.lifespan_fields anchor h i p hp).2.2]
    simp [hp,hj]
  · have hn : d.interval i p = none := by
      cases he : d.interval i p with
      | none => rfl
      | some bd => exact False.elim (hp (by simp [mem_primes,he]))
    have he := h.unused i p hn
    have hh : ¬ ∃ k, d.activeAt j i k=p := by
      intro ha
      have hm : j ∈ d.toOriginalPath.activeVisits i p := (OriginalPath.mem_activeVisits _ _ _ _).mpr ⟨hj,ha⟩
      rw [he] at hm
      exact Finset.notMem_empty _ hm
    simp [hp,hh]

theorem before_eq (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B) (j : ℕ) (i : I) :
    before (d.primes i) (d.lifespan anchor h i) j = d.beforeSet j i := by
  apply Finset.filter_congr
  intro p hp
  rcases d.lifespan_fields anchor h i p hp with ⟨hb,hd,ha⟩
  simp [PrimeLifespan.beforeGhost,hb,hd,ha]

theorem after_eq (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B) (j : ℕ) (i : I) :
    after (d.primes i) (d.lifespan anchor h i) j = d.afterSet j i := by
  apply Finset.filter_congr
  intro p hp
  rcases d.lifespan_fields anchor h i p hp with ⟨hb,hd,ha⟩
  simp [PrimeLifespan.afterGhost,hb,hd,ha]



variable (anchor : Z → ∀ i p, Line i p) (h : d.Valid anchor B)

def store (j : ℕ) (i : I) : Bool :=
  decide (d.sourcePrime j i ∈ stores (d.primes i) (d.lifespan anchor h i) j)
def promote (j : ℕ) (i : I) : Bool :=
  decide (d.targetPrime j i ∈ promotions (d.primes i) (d.lifespan anchor h i) j)

theorem store_set (j : ℕ) (hj : j<N) (i : I) :
    stores (d.primes i) (d.lifespan anchor h i) j =
      optionalPrimeSet (d.store anchor h j i) (d.sourcePrime j i) := by
  have hsingle : ∀ p ∈ stores (d.primes i) (d.lifespan anchor h i) j, p=d.sourcePrime j i := by
    intro p hp
    obtain ⟨hused,ha,hd,hn⟩ := Finset.mem_filter.mp hp
    apply d.toOriginalPath.departed_eq_sourcePrime j i p (h.shared j hj)
    · exact (d.active_lifespan anchor h j hj.le i p).mp ⟨hused,ha⟩
    · intro hnext
      exact hn ((d.active_lifespan anchor h (j+1) hj i p).mpr hnext).2
  ext p
  by_cases hsource : d.sourcePrime j i ∈ stores (d.primes i) (d.lifespan anchor h i) j
  · simp only [store,hsource,decide_true,optionalPrimeSet,ite_true,Finset.mem_singleton, Bool.true_eq]
    exact ⟨fun hp => hsingle p hp,fun hp => hp ▸ hsource⟩
  · simp only [store,hsource,decide_false,optionalPrimeSet,Bool.false_eq_true,ite_false,Finset.notMem_empty,iff_false]
    intro hp
    exact hsource ((hsingle p hp) ▸ hp)

theorem promote_set (j : ℕ) (hj : j<N) (i : I) :
    promotions (d.primes i) (d.lifespan anchor h i) j =
      optionalPrimeSet (d.promote anchor h j i) (d.targetPrime j i) := by
  have hsingle : ∀ p ∈ promotions (d.primes i) (d.lifespan anchor h i) j, p=d.targetPrime j i := by
    intro p hp
    obtain ⟨hused,ha,hb,hn⟩ := Finset.mem_filter.mp hp
    apply d.toOriginalPath.arrived_eq_targetPrime j i p (h.shared j hj)
    · exact (d.active_lifespan anchor h (j+1) hj i p).mp ⟨hused,ha⟩
    · intro hprev
      exact hn ((d.active_lifespan anchor h j hj.le i p).mpr hprev).2
  ext p
  by_cases htarget : d.targetPrime j i ∈ promotions (d.primes i) (d.lifespan anchor h i) j
  · simp only [promote,htarget,decide_true,optionalPrimeSet,ite_true,Finset.mem_singleton,Bool.true_eq]
    exact ⟨fun hp => hsingle p hp,fun hp => hp ▸ htarget⟩
  · simp only [promote,htarget,decide_false,optionalPrimeSet,Bool.false_eq_true,ite_false,Finset.notMem_empty,iff_false]
    intro hp
    exact htarget ((hsingle p hp) ▸ hp)

theorem retained_line (i : I) (p : P i) (hp : p ∈ d.primes i)
    (j : ℕ) (hj : j≤N)
    (hjp : j=(d.lifespan anchor h i p).birth ∨ j=(d.lifespan anchor h i p).death ∨
      j∈(d.lifespan anchor h i p).active) :
    d.retained anchor i p=anchor (d.positionAt j) i p := by
  cases he : d.interval i p with
  | none => simp [mem_primes,he] at hp
  | some bd =>
    have hh := h.incidence i p bd he j hj
    simp only [lifespan,he,Option.isSome_some,Bool.true_eq,↓reduceDIte,Option.get_some] at hjp
    simpa [retained,birth,he] using hh hjp

/-- Every supported primewise leaf has its actual chronological schedule.
No schedule, store/promotion flags, or history coefficient is supplied. -/
def toSchedule : ScheduledPhysicalPath anchor N J B where
  primes := d.primes
  lifespan := d.lifespan anchor h
  retained := d.retained anchor
  position := d.positionAt
  active := d.activeAt
  active_distinct := h.active_distinct
  active_lifespan := d.active_lifespan anchor h
  sourcePerm := d.sourcePermAt
  targetPerm := d.targetPermAt
  store := d.store anchor h
  promote := d.promote anchor h
  targetPrime := d.targetPrime
  active_next := fun j hj => d.toOriginalPath.active_next_of_shared j (h.shared j hj)
  store_set := d.store_set anchor h
  promote_set := d.promote_set anchor h
  death_line := by
    intro j hj i p hp
    obtain ⟨hused,hd,ha⟩ := Finset.mem_filter.mp hp
    exact d.retained_line anchor h i p hused j hj (Or.inr (Or.inl hd))
  birth_line := by
    intro j hj i p hp
    obtain ⟨hused,hb,ha⟩ := Finset.mem_filter.mp hp
    exact d.retained_line anchor h i p hused j hj (Or.inl hb)
  store_line := by
    intro j hj i p hp
    obtain ⟨hused,ha,hd,hn⟩ := Finset.mem_filter.mp hp
    exact d.retained_line anchor h i p hused j hj.le (Or.inr (Or.inr ha))
  promote_line := by
    intro j hj i p hp
    obtain ⟨hused,ha,hb,hn⟩ := Finset.mem_filter.mp hp
    exact d.retained_line anchor h i p hused (j+1) hj (Or.inr (Or.inr ha))
  before_cutoff := by
    intro j hj
    simp_rw [d.before_eq anchor h]
    exact h.before_cutoff j hj
  after_cutoff := by
    intro j hj
    simp_rw [d.after_eq anchor h]
    exact h.after_cutoff j hj

theorem toSchedule_activeBirthAnchored : (d.toSchedule anchor h).ActiveBirthAnchored := by
  rw [ScheduledPhysicalPath.activeBirthAnchored_iff_birth_anchor]
  intro i p hp
  change d.retained anchor i p = anchor (d.positionAt (d.lifespan anchor h i p).birth) i p
  rw [(d.lifespan_fields anchor h i p hp).1]
  rfl



/-- The complete existing finite key of the schedule constructed from a
leaf, not a newly postulated representation. -/
def key : CanonicalHistoryKey I Z P J N := (d.toSchedule anchor h).canonicalKey

@[simp] theorem key_position (j : Fin (N+1)) : (d.key anchor h).position j = d.position j := by
  simp [key,toSchedule,ScheduledPhysicalPath.canonicalKey,OriginalPath.positionAt,
    OriginalPath.visit,Nat.min_eq_left (Nat.le_of_lt_succ j.isLt)]

@[simp] theorem key_active (j : Fin (N+1)) : (d.key anchor h).active j = d.active j := by
  simp [key,toSchedule,ScheduledPhysicalPath.canonicalKey,OriginalPath.activeAt,
    OriginalPath.visit,Nat.min_eq_left (Nat.le_of_lt_succ j.isLt)]

@[simp] theorem key_sourcePerm (j : Fin N) : (d.key anchor h).sourcePerm j = d.sourcePerm j := by
  simp [key,toSchedule,ScheduledPhysicalPath.canonicalKey,OriginalPath.sourcePermAt,j.isLt]

@[simp] theorem key_targetPerm (j : Fin N) : (d.key anchor h).targetPerm j = d.targetPerm j := by
  simp [key,toSchedule,ScheduledPhysicalPath.canonicalKey,OriginalPath.targetPermAt,j.isLt]

/-- Birth and death are recovered from the checked canonical key. Hence
unused primes carry no artificial interval or retained-line multiplicity. -/
theorem key_interval (i : I) (p : P i) :
    ((d.key anchor h).birth i p).bind (fun b => ((d.key anchor h).death i p).map (fun e => (b,e))) = d.interval i p := by
  cases he : d.interval i p with
  | none =>
    have hnot : p ∉ (d.key anchor h).primes i := by
      simp [key,ScheduledPhysicalPath.canonicalKey_primes,toSchedule,mem_primes,he]
    have hb := (CanonicalHistoryKey.birth_eq_none (d.key anchor h) i p).mpr hnot
    rw [hb]
    rfl
  | some bd =>
    have hp : p ∈ (d.toSchedule anchor h).primes i := by
      change p ∈ d.primes i
      simp [mem_primes,he]
    rw [key,ScheduledPhysicalPath.canonicalKey_birth _ i p hp,
      ScheduledPhysicalPath.canonicalKey_death _ i p hp]
    simp [toSchedule,lifespan,he]

/-- Distinct finite original leaves give distinct existing canonical keys.
This is the global injectivity needed for reindexing the complete sum. -/
theorem key_injective : Function.Injective
    (fun e : {d : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) // d.Valid anchor B} =>
      e.val.key anchor e.property) := by
  intro e f he
  dsimp only at he
  apply Subtype.ext
  apply OriginalLeaf.ext
  · funext j
    simpa only [key_position] using congrArg (fun k : CanonicalHistoryKey I Z P J N => k.position j) he
  · funext j
    simpa only [key_active] using congrArg (fun k : CanonicalHistoryKey I Z P J N => k.active j) he
  · funext j
    simpa only [key_sourcePerm] using congrArg (fun k : CanonicalHistoryKey I Z P J N => k.sourcePerm j) he
  · funext j
    simpa only [key_targetPerm] using congrArg (fun k : CanonicalHistoryKey I Z P J N => k.targetPerm j) he
  · funext i p
    rw [← e.val.key_interval anchor e.property i p, ← f.val.key_interval anchor f.property i p, he]

end OriginalLeaf
end Elliptic.Operator.OriginalLifespanSchedule
