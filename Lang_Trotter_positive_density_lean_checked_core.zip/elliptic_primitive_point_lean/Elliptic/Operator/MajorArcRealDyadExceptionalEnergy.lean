module
public import Elliptic.Operator.MajorArcRealDyad
public import Elliptic.Operator.MajorArcActualExceptionalEnergy

/-! Exceptional energy for the literal real-scale long Dirichlet polynomial. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcRealDyadExceptionalEnergy
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource Artin.MarkedReplacement MajorArcScaleCancellation MajorArcPolynomialEnergy
open MajorArcRealDyad PrimeExceptionalCells MajorArcFrequencySplit ClassicalDerivativeTest
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

/-- The actual exceptional subset has measure at most its unit-cell count. -/
theorem exceptional_measure_le (K:ℕ) (a ε:ℝ) (P:ℝ→ℂ) :
    volume.real (Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | ε<‖P t‖})≤
      ((exceptionalCells K a ε P).card:ℝ) := by
  have hh := exceptional_energy_le_samples (fun _:ℝ=>(1:ℂ)) continuous_const
    (exceptionalCells K a ε P) a _ (exceptionalCells_cover K a ε P) (fun _=>0)
    (by intros; exact le_rfl)
  simpa only [norm_one,one_pow,setIntegral_const,smul_eq_mul,mul_one,
    Finset.sum_const,nsmul_eq_mul,mul_one] using hh

/-- The endpoint missed by the integer beta block is negligible uniformly in the real dyad. -/
theorem eventually_actual_exceptional_long_energy (hvdC:FixedOrderDerivativeTest)
    (δ c C As:ℝ) (hδ:0<δ) (hc:0<c) (hC:0≤C) (hAs:0≤As) :
    ∃Cβ:ℝ,0<Cβ ∧ ∀ᶠL:ℝ in atTop,∀K:ℕ,1≤K→(K:ℝ)≤Real.exp (3*L)→
      ∀H:ℝ,Real.exp (δ*L)≤H→
      ∀a P:ℝ,0<P→c*L^(1/10:ℝ)≤Real.log P→Real.log P≤C*L^(1/5:ℝ)→
      ∀S:Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀q:ℕ,∀χ:DirichletCharacter ℂ q,∀ξ B:ℝ,0≤B→
      ∀s:Finset ℕ,InDyad H s→∀α:ℕ→ℂ,(∀n∈s,‖α n‖≤B)→
      ∀k:ℕ,∀χ':DirichletCharacter ℂ k,
      (∫t in Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | L^(-As)<‖primePolynomial S P χ ξ t‖},
        ‖longPolynomial s α H χ' t‖^2)≤Cβ*B^2*L := by
  obtain ⟨Cβ,hCβ,henergy⟩ := MajorArcActualExceptionalEnergy.eventually_actual_exceptional_beta_energy hvdC
    δ c C As hδ hc hC hAs
  obtain ⟨D,hD,hcount⟩ := PrimeExceptionalEnvelope.eventually_exceptionalCells_card 3 c C As
    (by norm_num) hc hC hAs
  refine ⟨8*Cβ+2,by positivity,?_⟩
  filter_upwards [henergy,hcount,MajorArcSparseAsymptotics.eventually_mul_rpow_le D δ (91/100) 1 hδ (by norm_num),
    eventually_ge_atTop (1:ℝ)] with L henergy hcount hsmall hL
  intro K hK hKmax H hHmin a P hP hlo hhi S hprime hShi q χ ξ B hB s hs α hα k χ'
  have hH : 1≤H := (Real.one_le_exp_iff.mpr (mul_nonneg hδ.le (by linarith))).trans hHmin
  have hHp : 0<H := by linarith
  let E := Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | L^(-As)<‖primePolynomial S P χ ξ t‖}
  have hE : MeasurableSet E := measurableSet_Ioc.inter
    ((isOpen_lt continuous_const (primePolynomial_continuous S P χ ξ).norm).measurableSet)
  have he := longPolynomial_energy_le s α H B hH hB hs hα χ' E hE (a+1) (a+(K:ℝ)+1)
    (fun t ht=>Ioc_subset_Icc_self ht.1)
  have hN : 1≤⌈H⌉₊ := Nat.one_le_ceil_iff.mpr hHp
  have hb := henergy K ⌈H⌉₊ hK hN hKmax (hHmin.trans (Nat.le_ceil H)) a P hP hlo hhi S hprime hShi q χ ξ B hB
    (dyadCoefficient s α H χ') (fun n _=>dyadCoefficient_norm_le s α H B hB hα χ' n)
  have hcard := hcount K a P hKmax hP hlo hhi S hprime hShi q χ ξ
  have hv : volume.real E≤H := by
    apply (exceptional_measure_le K a (L^(-As)) (primePolynomial S P χ ξ)).trans
    apply hcard.trans
    apply (Real.exp_le_exp.mpr _).trans hHmin
    simpa only [Real.rpow_one] using hsmall
  have herr : 2*(B/H)^2*volume.real E≤2*B^2 := by
    have hh := mul_le_mul_of_nonneg_left (hv.trans (by nlinarith : H≤H^2))
      (by positivity : 0≤2*(B/H)^2)
    convert hh using 1
    field_simp
  apply he.trans
  calc
    _ ≤ 8*(Cβ*B^2*L)+2*B^2 := add_le_add (mul_le_mul_of_nonneg_left hb (by norm_num)) herr
    _ ≤ (8*Cβ+2)*B^2*L := by nlinarith [mul_le_mul_of_nonneg_left hL (sq_nonneg B)]

end Elliptic.Operator.MajorArcRealDyadExceptionalEnergy
