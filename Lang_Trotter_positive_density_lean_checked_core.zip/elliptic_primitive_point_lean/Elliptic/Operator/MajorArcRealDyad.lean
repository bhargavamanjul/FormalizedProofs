module
public import Elliptic.Operator.MajorArcPolynomialEnergy
public import Mathlib.Algebra.BigOperators.Intervals

/-! Exact passage from a real source dyad to the normalized integer beta polynomial. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcRealDyad
open scoped BigOperators
open MeasureTheory Set
open Artin.MarkedSource Artin.MarkedReplacement MajorArcScaleCancellation MajorArcPolynomialEnergy
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000
attribute [local instance] Classical.propDecidable

/-- The coefficient vector on the integer block [ceil H,2 ceil H). -/
def dyadCoefficient (s:Finset ℕ) (α:ℕ→ℂ) (H:ℝ) {k:ℕ}
    (χ:DirichletCharacter ℂ k) (n:ℕ) : ℂ :=
  if ⌈H⌉₊+n∈s then α (⌈H⌉₊+n)*χ ((⌈H⌉₊+n:ℕ):ZMod k) else 0

/-- The one possible endpoint not contained in the half-open integer block. -/
def endpointPolynomial (s:Finset ℕ) (α:ℕ→ℂ) (H:ℝ) {k:ℕ}
    (χ:DirichletCharacter ℂ k) (t:ℝ) : ℂ :=
  if 2*⌈H⌉₊∈s then (H:ℂ)⁻¹*α (2*⌈H⌉₊)*χ ((2*⌈H⌉₊:ℕ):ZMod k)*archimedeanPhase t (2*⌈H⌉₊) else 0

theorem inDyad_subset (s:Finset ℕ) (H:ℝ) (hs:InDyad H s) :
    s⊆Finset.Icc ⌈H⌉₊ (2*⌈H⌉₊) := by
  intro n hn
  obtain ⟨hl,hu⟩ := hs n hn
  apply Finset.mem_Icc.mpr
  constructor
  · exact Nat.ceil_le.mpr hl
  · have hh := Nat.le_ceil H
    exact_mod_cast (show (n:ℝ)≤2*(⌈H⌉₊:ℝ) by linarith)

theorem sum_dyad_decomposition {F:Type*} [AddCommMonoid F]
    (s:Finset ℕ) (f:ℕ→F) (N:ℕ) (hs:s⊆Finset.Icc N (2*N)) :
    (∑n∈s,f n)=(∑n∈Finset.range N,if N+n∈s then f (N+n) else 0)+
      (if 2*N∈s then f (2*N) else 0) := by
  have hh : (∑n∈s,f n)=∑n∈Finset.Icc N (2*N),if n∈s then f n else 0 := by
    calc
      _ = ∑n∈s,if n∈s then f n else 0 := Finset.sum_congr rfl (fun n hn=>by simp [hn])
      _ = _ := Finset.sum_subset hs (by intro n hn hns; simp [hns])
  rw [hh,←Finset.Ico_insert_right (by omega : N≤2*N),Finset.sum_insert (by simp),
    Finset.sum_Ico_eq_sum_range]
  rw [show 2*N-N=N by omega,add_comm]

/-- Exact real-scale normalization, including its possible endpoint term. -/
theorem longPolynomial_eq (s:Finset ℕ) (α:ℕ→ℂ) (H:ℝ) (hH:1≤H)
    (hs:InDyad H s) {k:ℕ} (χ:DirichletCharacter ℂ k) (t:ℝ) :
    longPolynomial s α H χ t=
      ((⌈H⌉₊:ℂ)/(H:ℂ))*betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t+
      endpointPolynomial s α H χ t := by
  have hN : 1≤⌈H⌉₊ := Nat.one_le_ceil_iff.mpr (by linarith)
  have hNC : (⌈H⌉₊:ℂ)≠0 := by exact_mod_cast (by omega : ⌈H⌉₊≠0)
  unfold longPolynomial
  rw [sum_dyad_decomposition s _ ⌈H⌉₊ (inDyad_subset s H hs),mul_add]
  have he : (∑n∈Finset.range ⌈H⌉₊,
      if ⌈H⌉₊+n∈s then α (⌈H⌉₊+n)*χ ((⌈H⌉₊+n:ℕ):ZMod k)*archimedeanPhase t (⌈H⌉₊+n) else 0)=
      ∑n∈Finset.range ⌈H⌉₊,dyadCoefficient s α H χ n*LogPhaseProgression.phase t ((⌈H⌉₊:ℝ)+n) := by
    apply Finset.sum_congr rfl
    intro n hn
    rw [dyadCoefficient]
    split_ifs <;> (try simp only [zero_mul])
    rw [←Nat.cast_add,LogPhaseProgression.phase_nat]
  rw [he,betaPolynomial]
  have hmain : (H:ℂ)⁻¹*(∑n∈Finset.range ⌈H⌉₊,dyadCoefficient s α H χ n*LogPhaseProgression.phase t ((⌈H⌉₊:ℝ)+n))=
      ((⌈H⌉₊:ℂ)/(H:ℂ))*((⌈H⌉₊:ℂ)⁻¹*∑n∈Finset.range ⌈H⌉₊,dyadCoefficient s α H χ n*LogPhaseProgression.phase t ((⌈H⌉₊:ℝ)+n)) := by
    field_simp
  rw [hmain]
  congr 1
  unfold endpointPolynomial
  split_ifs <;> (try simp only [mul_zero]) <;> ring

/-- Character twisting and zero extension preserve the coefficient bound. -/
theorem dyadCoefficient_norm_le (s:Finset ℕ) (α:ℕ→ℂ) (H B:ℝ) (hB:0≤B)
    (hα:∀n∈s,‖α n‖≤B) {k:ℕ} (χ:DirichletCharacter ℂ k) (n:ℕ) :
    ‖dyadCoefficient s α H χ n‖≤B := by
  unfold dyadCoefficient
  split_ifs with hn
  · rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg _)).trans (by simpa using hα _ hn)
  · simpa using hB

theorem ceil_ratio_le_two (H:ℝ) (hH:1≤H) : (⌈H⌉₊:ℝ)/H≤2 := by
  apply (div_le_iff₀ (by linarith : 0<H)).mpr
  have hh := Nat.ceil_lt_add_one (by linarith : 0≤H)
  linarith

/-- The possible endpoint costs only one original coefficient divided by H. -/
theorem endpointPolynomial_norm_le (s:Finset ℕ) (α:ℕ→ℂ) (H B:ℝ) (hH:1≤H) (hB:0≤B)
    (hα:∀n∈s,‖α n‖≤B) {k:ℕ} (χ:DirichletCharacter ℂ k) (t:ℝ) :
    ‖endpointPolynomial s α H χ t‖≤B/H := by
  unfold endpointPolynomial
  split_ifs with hn
  · rw [norm_mul,norm_mul,norm_mul,archimedeanPhase_norm,mul_one,norm_inv,
      Complex.norm_real,Real.norm_eq_abs,abs_of_pos (by linarith : 0<H)]
    calc
      _ ≤ H⁻¹*B*1 := mul_le_mul
        (mul_le_mul_of_nonneg_left (hα _ hn) (by positivity)) (χ.norm_le_one _) (norm_nonneg _) (by positivity)
      _ = _ := by ring
  · rw [norm_zero]
    positivity

/-- The real dyad differs from the normalized beta block by one controlled term. -/
theorem longPolynomial_norm_le (s:Finset ℕ) (α:ℕ→ℂ) (H B:ℝ) (hH:1≤H) (hB:0≤B)
    (hs:InDyad H s) (hα:∀n∈s,‖α n‖≤B) {k:ℕ} (χ:DirichletCharacter ℂ k) (t:ℝ) :
    ‖longPolynomial s α H χ t‖≤2*‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖+B/H := by
  rw [longPolynomial_eq s α H hH hs χ t]
  apply (norm_add_le _ _).trans
  apply add_le_add _ (endpointPolynomial_norm_le s α H B hH hB hα χ t)
  rw [norm_mul,norm_div,Complex.norm_natCast,Complex.norm_real,Real.norm_eq_abs,
    abs_of_pos (by linarith : 0<H)]
  exact mul_le_mul_of_nonneg_right (ceil_ratio_le_two H hH) (norm_nonneg _)

/-- Squared energies transfer with absolute constants and a singleton error. -/
theorem longPolynomial_sq_le (s:Finset ℕ) (α:ℕ→ℂ) (H B:ℝ) (hH:1≤H) (hB:0≤B)
    (hs:InDyad H s) (hα:∀n∈s,‖α n‖≤B) {k:ℕ} (χ:DirichletCharacter ℂ k) (t:ℝ) :
    ‖longPolynomial s α H χ t‖^2≤8*‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖^2+2*(B/H)^2 := by
  have hh := longPolynomial_norm_le s α H B hH hB hs hα χ t
  have hb : 0≤B/H := div_nonneg hB (by linarith)
  have hn := norm_nonneg (longPolynomial s α H χ t)
  have hn' := norm_nonneg (betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t)
  nlinarith [sq_nonneg (2*‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖-B/H)]

/-- Integration over any bounded measurable exceptional set preserves the explicit endpoint cost. -/
theorem longPolynomial_energy_le (s:Finset ℕ) (α:ℕ→ℂ) (H B:ℝ) (hH:1≤H) (hB:0≤B)
    (hs:InDyad H s) (hα:∀n∈s,‖α n‖≤B) {k:ℕ} (χ:DirichletCharacter ℂ k)
    (E:Set ℝ) (hE:MeasurableSet E) (a b:ℝ) (hsub:E⊆Icc a b) :
    (∫t in E,‖longPolynomial s α H χ t‖^2)≤
      8*(∫t in E,‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖^2)+
        2*(B/H)^2*volume.real E := by
  have hi : IntegrableOn (fun t=>‖longPolynomial s α H χ t‖^2) E :=
    (((longPolynomial_continuous s α H χ).norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc).mono_set hsub
  have hi' : IntegrableOn (fun t=>‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖^2) E :=
    (((betaPolynomial_continuous ⌈H⌉₊ (dyadCoefficient s α H χ)).norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc).mono_set hsub
  have hc : IntegrableOn (fun _:ℝ=>2*(B/H)^2) E :=
    (continuous_const.continuousOn.integrableOn_compact isCompact_Icc).mono_set hsub
  calc
    _ ≤ ∫t in E,8*‖betaPolynomial ⌈H⌉₊ (dyadCoefficient s α H χ) t‖^2+2*(B/H)^2 := by
      apply setIntegral_mono_on hi ((hi'.const_mul 8).add hc) hE
      intro t ht
      exact longPolynomial_sq_le s α H B hH hB hs hα χ t
    _ = _ := by
      rw [integral_add (hi'.const_mul 8) hc,integral_const_mul,setIntegral_const]
      simp only [smul_eq_mul]
      ring

end Elliptic.Operator.MajorArcRealDyad
