module

public import Elliptic.Operator.PhysicalPathGeometry
public import Elliptic.Operator.FinitePrimeCRT

/-!
# Literal physical prime factors under the whole-path root map

This includes every active incidence and every inactive damping factor.
It identifies the ordinary divisibility tests on the physical first
coordinates with the canonical matrix's actual projective kernel lines.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPathResidues
open scoped BigOperators
open SourceRootCount SingleEdgeRootEncoding PhysicalPathRootEncoding
open IndependentLineNormalization
attribute [local instance] Classical.propDecidable
local instance pathResidueDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The physical one-prime factor, before changing root coordinates. -/
def physicalFactor (visits active : Finset ℕ) (position : ℕ→ℤ×ℤ)
    (η : ℕ→ℝ) (p : ℕ) : ℝ :=
  (∏j∈active,if (p:ℤ)∣(position j).1 then (1:ℝ) else 0) *
    ∏j∈visits\active,(1-if (p:ℤ)∣(position j).1 then η j else 0)

theorem integerLine_eq_anchor_iff (p : ℕ) (hp : p.Prime)
    (t : RootTriple) (ht : Canonical t) (z : ℤ×ℤ) (hz : IsCoprime z.1 z.2) :
    primeResidueAnchor p z=FinitePrimeCRT.integerLines (canonicalSL2 t ht) p ↔
      (p:ℤ)∣(decode t z).1 := by
  letI : Fact p.Prime := ⟨hp⟩
  rw [eq_comm]
  have hh := RootResidues.kernel_coordinate_eq_anchor_iff_dvd p (canonicalSL2 t ht) z hz
  simpa [FinitePrimeCRT.integerLines,hp,decode,canonicalSL2,rootMatrix] using hh

theorem physicalFactor_decode (visits active : Finset ℕ) (hactive : active⊆visits)
    (position : ℕ→ℤ×ℤ) (hposition : ∀j∈visits,IsCoprime (position j).1 (position j).2)
    (η : ℕ→ℝ) (p : ℕ) (hp : p.Prime) (t : RootTriple) (ht : Canonical t) :
    physicalFactor visits active (fun j=>decode t (position j)) η p =
      lineFactor visits active (fun j=>primeResidueAnchor p (position j)) η
        (FinitePrimeCRT.integerLines (canonicalSL2 t ht) p) := by
  unfold physicalFactor lineFactor
  congr 1
  · apply Finset.prod_congr rfl
    intro j hj
    simp only [integerLine_eq_anchor_iff p hp t ht _ (hposition j (hactive hj))]
  · apply Finset.prod_congr rfl
    intro j hj
    unfold Elliptic.PrimewiseMemory.hitWeight
    simp only [integerLine_eq_anchor_iff p hp t ht _ (hposition j (Finset.mem_sdiff.mp hj).1)]

/-- The complete all-prime physical factor is the rooted coupled residue
factor, including prime repetitions and every inactive visit. -/
theorem physical_prime_product_decode (primes visits : Finset ℕ)
    (hprime : ∀p∈primes,p.Prime) (active : ℕ→Finset ℕ)
    (hactive : ∀p∈primes,active p⊆visits) (position : ℕ→ℤ×ℤ)
    (hposition : ∀j∈visits,IsCoprime (position j).1 (position j).2)
    (η : ℕ→ℝ) (t : RootTriple) (ht : Canonical t) :
    (∏p∈primes,physicalFactor visits (active p) (fun j=>decode t (position j)) η p) =
      ∏p∈primes,lineFactor visits (active p) (fun j=>primeResidueAnchor p (position j)) η
        (FinitePrimeCRT.integerLines (canonicalSL2 t ht) p) := by
  apply Finset.prod_congr rfl
  intro p hp
  exact physicalFactor_decode visits (active p) (hactive p hp) position hposition η p
    (hprime p hp) t ht

/-- Direct specialization to exactly the position and active-visit arrays
used by OriginalPathWeights.residueFactor. -/
theorem original_record_residue (K J N R Q : ℕ)
    (rec : OriginalPathWeights.Record K J N R Q) (primes : Finset ℕ)
    (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ)
    (hposition : ∀j<N+1,IsCoprime (OriginalPathWeights.positionAt rec j).1
      (OriginalPathWeights.positionAt rec j).2)
    (t : RootTriple) (ht : Canonical t) :
    (∏p∈primes,physicalFactor (Finset.range (N+1)) (OriginalPathWeights.activeVisits rec p)
      (fun j=>decode t (OriginalPathWeights.positionAt rec j)) η p) =
      OriginalPathWeights.residueFactor rec primes η (FinitePrimeCRT.integerLines (canonicalSL2 t ht)) := by
  exact physical_prime_product_decode primes (Finset.range (N+1)) hprime
    (OriginalPathWeights.activeVisits rec)
    (fun p _=>Finset.filter_subset _ _) (OriginalPathWeights.positionAt rec)
    (fun j hj=>hposition j (Finset.mem_range.mp hj)) η t ht

open OriginalLifespanSchedule PhysicalPathGeometry RootLiteralGeometry
variable {K J N : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def numericActiveVisits (value : ∀i,P i→ℕ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (p : ℕ) : Finset ℕ :=
  (Finset.range (N+1)).filter (fun j=>∃i k,value i (r.activeAt j i k)=p)

def physicalResidue (value : ∀i,P i→ℕ) (primes : Finset ℕ) (η : ℕ→ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) : ℝ :=
  ∏p∈primes,physicalFactor (Finset.range (N+1)) (numericActiveVisits value r p) r.positionAt η p

def rootResidue (value : ∀i,P i→ℕ) (primes : Finset ℕ) (η : ℕ→ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N)
    (ℓ : (p : ℕ)→Option (ZMod p)) : ℝ :=
  ∏p∈primes,lineFactor (Finset.range (N+1)) (numericActiveVisits value r p)
    (fun j=>primeResidueAnchor p (r.positionAt j)) η (ℓ p)

theorem physicalResidue_coordinates (value : ∀i,P i→ℕ)
    (primes : Finset ℕ) (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N)
    (hposition : ∀j≤N,IsCoprime (r.positionAt j).1 (r.positionAt j).2)
    (t : RootTriple) (ht : Canonical t) :
    physicalResidue value primes η r = rootResidue value primes η (rootPath t r)
      (FinitePrimeCRT.integerLines (canonicalSL2 t ht)) := by
  have hp : ∀j∈Finset.range (N+1),IsCoprime ((rootPath t r).positionAt j).1
      ((rootPath t r).positionAt j).2 := by
    intro j hj
    apply (decode_isCoprime t ht _).mp
    simpa only [rootPath_positionAt,decode_coordinates t ht] using
      hposition j (by have := Finset.mem_range.mp hj; omega)
  have hh := physical_prime_product_decode primes (Finset.range (N+1)) hprime
    (numericActiveVisits value (rootPath t r))
    (fun p _=>Finset.filter_subset _ _) (rootPath t r).positionAt hp η t ht
  have he : (fun j=>decode t ((rootPath t r).positionAt j))=r.positionAt := by
    funext j
    exact decode_coordinates t ht _
  rw [he] at hh
  exact hh

/-- The whole rooted projected edge product, before numerical encoding. -/
def rootGeometry (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (t : RootTriple) : ℂ :=
  ∏j∈Finset.range N,orientedSourceEdgeGeometry (adjoint j) value
    (sourceGood value μ d₀ Y L exponents (RootVariableSum.normalizedRoot U V t))
    (t.1:ℝ) (t.2.1:ℝ) ((t.2.2:ℝ)/t.1) U V d₀ Y η ψ major σ
    (r.positionAt j) (r.sourceLists j) (r.positionAt (j+1)) (r.targetLists j)

theorem rootGeometry_coordinates (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (t : RootTriple) (ht : Canonical t) (hU : 0<U) :
    rootGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint (rootPath t r) t =
      pathGeometry value μ d₀ Y L U V exponents η ψ major σ adjoint r :=
  edge_product_coordinates r adjoint value μ d₀ Y L exponents t ht U V hU η ψ major σ

/-- The complete physical path summand equals its actual rooted signed
geometry times the coupled line factor. Primitivity is deduced from the
nonzero geometric product, not added as a new source hypothesis. -/
theorem term_coordinates (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L U V : ℝ) (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (adjoint : ℕ→Bool) (hN : 0<N) (hU : 0<U)
    (primes : Finset ℕ) (hprime : ∀p∈primes,p.Prime) (η : ℕ→ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (t : RootTriple) (ht : Canonical t) :
    pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r*
      (physicalResidue value primes η r:ℂ) =
    rootGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint (rootPath t r) t*
      (rootResidue value primes η (rootPath t r) (FinitePrimeCRT.integerLines (canonicalSL2 t ht)):ℂ) := by
  rw [rootGeometry_coordinates value μ d₀ Y L U V exponents smooth ψ major σ adjoint r t ht hU]
  by_cases hg : pathGeometry value μ d₀ Y L U V exponents smooth ψ major σ adjoint r=0
  · simp [hg]
  · rw [physicalResidue_coordinates value primes hprime η r
      (fun j hj=>(physical_support value μ d₀ Y L U V exponents smooth ψ major σ adjoint r hN hg j hj).1)
      t ht]

end Elliptic.Operator.PhysicalPathResidues
