module

public import Elliptic.Operator.MellinEndpointEnergy
public import Elliptic.Operator.SignedDyadicCauchy

/-! Exact harmonic mass and literal coefficient pushforward for prime labels. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcLabelMass
open scoped BigOperators
open MeasureTheory Set Artin.MarkedSource SignedCauchyExpansion SignedDyadicCauchy
attribute [local instance] Classical.propDecidable
local instance labelMassDecEq {α:Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- The actual independent prime labels have exactly the product harmonic mass. -/
theorem label_harmonic_mass {K:ℕ} (b:Bands K) (x:ℝ) :
    (∑l:LabelTuple b x,(labelProduct b x l:ℝ)⁻¹)=∏i:Fin K,b.mass x i := by
  have hm (i:Fin K) : b.mass x i=∑p:(b.group x i:Type),(p.val:ℝ)⁻¹ := by
    exact (Finset.sum_coe_sort _ (fun p:ℕ=>(p:ℝ)⁻¹)).symm
  simp only [labelProduct,Nat.cast_prod,←Finset.prod_inv_distrib,hm]
  rw [Fintype.prod_sum]

theorem normalized_label_harmonic_mass {K:ℕ} (b:Bands K) (x:ℝ)
    (hm:∀i,b.mass x i≠0) :
    massNormalization b x*(∑l:LabelTuple b x,(labelProduct b x l:ℝ)⁻¹)=1 := by
  rw [label_harmonic_mass,massNormalization,←Finset.prod_mul_distrib]
  simp only [inv_mul_cancel₀ (hm _),Finset.prod_const_one]

/-- A dyadic mass bound follows from its harmonic mass, without counting products. -/
theorem finite_mass_from_harmonic {ι:Type*} (s:Finset ι) (p:ι→ℝ) (c:ι→ℂ)
    (P Y C:ℝ) (hP:0<P) (hY:0<Y) (hC:0≤C)
    (hp:∀i∈s,0<p i) (hupper:∀i∈s,p i≤C*Y/P) :
    (P/Y)*(∑i∈s,‖c i‖)≤C*(∑i∈s,‖c i‖/p i) := by
  rw [Finset.mul_sum,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  have hu := (le_div_iff₀ hP).mp (hupper i hi)
  have hmul : (P/Y)*p i≤C := by
    rw [div_mul_eq_mul_div]
    exact (div_le_iff₀ hY).mpr (by nlinarith)
  have hh := mul_le_mul_of_nonneg_right hmul (div_nonneg (norm_nonneg (c i)) (hp i hi).le)
  calc
    _ = ((P/Y)*p i)*(‖c i‖/p i) := by field_simp [(hp i hi).ne']
    _ ≤_ := hh

/-- Coefficients on arbitrary finite labels are pushed to their literal integer product. -/
def pushedCoefficient {ι:Type*} [Fintype ι] (p:ι→ℕ) (c:ι→ℂ) (n:ℕ) : ℂ :=
  ∑i,if p i=n then c i else 0

theorem pushed_sum {ι:Type*} [Fintype ι] (p:ι→ℕ) (c:ι→ℂ) (R:Finset ℕ) (F:ℕ→ℂ) :
    (∑n∈R,pushedCoefficient p c n*F n)=
      ∑i,if p i∈R then c i*F (p i) else 0 := by
  simp only [pushedCoefficient,Finset.sum_mul,ite_mul,zero_mul]
  rw [Finset.sum_comm]
  simp

theorem pushed_harmonic_mass {ι:Type*} [Fintype ι] (p:ι→ℕ) (c:ι→ℂ) (R:Finset ℕ) :
    (∑n∈R,‖pushedCoefficient p c n‖/(n:ℝ))≤∑i,‖c i‖/(p i:ℝ) := by
  calc
    _ ≤∑n∈R,∑i,if p i=n then ‖c i‖/(n:ℝ) else 0 := by
      apply Finset.sum_le_sum
      intro n hn
      have hh := div_le_div_of_nonneg_right (norm_sum_le Finset.univ (fun i=>if p i=n then c i else 0))
        (Nat.cast_nonneg (α:=ℝ) n)
      simpa only [pushedCoefficient,Finset.sum_div,apply_ite,norm_zero,ite_div,zero_div] using hh
    _ =∑i,if p i∈R then ‖c i‖/(p i:ℝ) else 0 := by rw [Finset.sum_comm]; simp
    _ ≤_ := by
      apply Finset.sum_le_sum
      intro i hi
      split_ifs <;> simp [div_nonneg (norm_nonneg _) (Nat.cast_nonneg (p i))]

/-- Actual remaining-label coefficient mass, including multiplicities if
different label tuples have the same product. -/
theorem pushed_remaining_mass {ι:Type*} [Fintype ι] (p:ι→ℕ) (c:ι→ℂ)
    (R:Finset ℕ) (P Y:ℝ) (hP:0<P) (hY:0<Y)
    (hR:∀n∈R,0<n ∧ (n:ℝ)≤4*Y/P) :
    (P/Y)*(∑n∈R,‖pushedCoefficient p c n‖)≤4*(∑i,‖c i‖/(p i:ℝ)) := by
  exact (finite_mass_from_harmonic R (fun n=>(n:ℝ)) (pushedCoefficient p c) P Y 4 hP hY (by norm_num)
    (fun n hn=>by exact_mod_cast (hR n hn).1) (fun n hn=>(hR n hn).2)).trans
    (mul_le_mul_of_nonneg_left (pushed_harmonic_mass p c R) (by norm_num))

abbrev Labels {ι:Type*} (G:ι→Finset ℕ) := ∀i,(G i:Type)
def product {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (l:Labels G) : ℕ := ∏i,(l i).val
def normalization {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) : ℝ :=
  ∏i,(∑p∈G i,(p:ℝ)⁻¹)⁻¹

theorem harmonic_mass {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) :
    (∑l:Labels G,(product G l:ℝ)⁻¹)=∏i,∑p∈G i,(p:ℝ)⁻¹ := by
  have hm (i:ι) : (∑p∈G i,(p:ℝ)⁻¹)=∑p:(G i:Type),(p.val:ℝ)⁻¹ :=
    (Finset.sum_coe_sort _ (fun p:ℕ=>(p:ℝ)⁻¹)).symm
  simp only [product,Nat.cast_prod,←Finset.prod_inv_distrib,hm]
  rw [Fintype.prod_sum]

theorem normalization_nonneg {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) : 0≤normalization G := by
  unfold normalization
  positivity

theorem normalized_harmonic_mass {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hm:∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0) :
    normalization G*(∑l:Labels G,(product G l:ℝ)⁻¹)=1 := by
  rw [harmonic_mass,normalization,←Finset.prod_mul_distrib]
  simp only [inv_mul_cancel₀ (hm _),Finset.prod_const_one]

theorem product_pos {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hG:∀i,∀p∈G i,0<p) (l:Labels G) : 0<product G l :=
  Finset.prod_pos (fun i hi=>hG i (l i).val (l i).property)

/-- Characters cannot increase the normalized harmonic mass of any set
of remaining independent labels. -/
theorem character_harmonic_mass {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hm:∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0) {q:ℕ} (χ:DirichletCharacter ℂ q) :
    (∑l:Labels G,‖(normalization G:ℂ)*χ (product G l:ZMod q)‖/(product G l:ℝ))≤1 := by
  calc
    _ ≤∑l:Labels G,normalization G/(product G l:ℝ) := by
      apply Finset.sum_le_sum
      intro l hl
      apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
      rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (normalization_nonneg G)]
      exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (normalization_nonneg G)).trans_eq (mul_one _)
    _ =normalization G*(∑l:Labels G,(product G l:ℝ)⁻¹) := by rw [Finset.mul_sum]; simp only [div_eq_mul_inv]
    _ =1 := normalized_harmonic_mass G hm

def remainingPool {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (P Y:ℝ) : Finset ℕ :=
  (Finset.univ.image (product G)).filter (fun r=>(r:ℝ)≤4*Y/P)

theorem remainingPool_pos {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hG:∀i,∀p∈G i,0<p) (P Y:ℝ) (r:ℕ) (hr:r∈remainingPool G P Y) : 0<r := by
  obtain ⟨l,hl,rfl⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hr).1
  exact product_pos G hG l

/-- The exact remaining coefficient mass required by MellinEndpointEnergy
is at most four, independently of the number of labels or the active dyad. -/
theorem normalized_remaining_mass {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hG:∀i,∀p∈G i,0<p) (hm:∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)
    {q:ℕ} (χ:DirichletCharacter ℂ q) (P Y:ℝ) (hP:0<P) (hY:0<Y) :
    (P/Y)*(∑r∈remainingPool G P Y,
      ‖pushedCoefficient (product G) (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q)) r‖)≤4 := by
  apply (pushed_remaining_mass (product G) _ (remainingPool G P Y) P Y hP hY
    (fun r hr=>⟨remainingPool_pos G hG P Y r hr,(Finset.mem_filter.mp hr).2⟩)).trans
  have hh := mul_le_mul_of_nonneg_left (character_harmonic_mass G hm χ) (show (0:ℝ)≤4 by norm_num)
  simpa only [mul_one] using hh

/-- The remaining-product cutoff is exact on each isolated prime block. -/
theorem pushed_cutoff_sum {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (c:Labels G→ℂ)
    (η:ℝ→ℂ) (hη:∀y,η y≠0→y≤4) (P Y lam t:ℝ) (hP:0<P) (hY:0<Y)
    (p:ℕ) (hp:P≤(p:ℝ)) :
    (∑r∈remainingPool G P Y,pushedCoefficient (product G) c r*
      MellinPrimeSeparation.twistedCutoff η lam ((p*r:ℕ)/Y)*
        Artin.MarkedReplacement.archimedeanPhase t (p*r))=
      ∑l:Labels G,c l*MellinPrimeSeparation.twistedCutoff η lam ((p*product G l:ℕ)/Y)*
        Artin.MarkedReplacement.archimedeanPhase t (p*product G l) := by
  simp_rw [mul_assoc]
  rw [pushed_sum]
  apply Finset.sum_congr rfl
  intro l hl
  by_cases hm:product G l∈remainingPool G P Y
  · simp [hm]
  · rw [if_neg hm]
    have hzero : η ((p*product G l:ℕ)/Y)=0 := by
      by_contra hn
      have hh := hη _ hn
      have hu : (p:ℝ)*(product G l:ℝ)≤4*Y := by
        rw [Nat.cast_mul] at hh
        exact (div_le_iff₀ hY).mp hh
      have hm' : (product G l:ℝ)≤4*Y/P := by
        apply (le_div_iff₀ hP).mpr
        have hmul := mul_le_mul_of_nonneg_right hp (Nat.cast_nonneg (α:=ℝ) (product G l))
        nlinarith
      exact hm (Finset.mem_filter.mpr ⟨Finset.mem_image.mpr ⟨l,Finset.mem_univ _,rfl⟩,hm'⟩)
    simp only [MellinPrimeSeparation.twistedCutoff,hzero,zero_mul,mul_zero]

/-- A normalized full label endpoint is uniformly bounded by four. -/
theorem full_label_endpoint_norm {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hG:∀i,∀p∈G i,0<p) (hm:∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)
    (η:ℝ→ℂ) (hη:∀y,‖η y‖≤1) (hsupp:∀y,η y≠0→y≤4)
    (Y:ℝ) (hY:0<Y) (c:Labels G→ℂ) (hc:∀l,‖c l‖≤1) :
    ‖((normalization G/Y:ℝ):ℂ)*∑l:Labels G,η ((product G l:ℝ)/Y)*c l‖≤4 := by
  have hn := normalization_nonneg G
  have hpoint (l:Labels G) : ‖η ((product G l:ℝ)/Y)*c l‖≤4*Y*(product G l:ℝ)⁻¹ := by
    have hp : (0:ℝ)<product G l := by exact_mod_cast product_pos G hG l
    by_cases hz:η ((product G l:ℝ)/Y)=0
    · simp only [hz,zero_mul,norm_zero]
      positivity
    · have hu := (div_le_iff₀ hY).mp (hsupp _ hz)
      have hh : (1:ℝ)≤4*Y*(product G l:ℝ)⁻¹ := by
        rw [←div_eq_mul_inv]
        exact (le_div_iff₀ hp).mpr (by simpa using hu)
      rw [norm_mul]
      exact (mul_le_one₀ (hη _) (norm_nonneg _) (hc l)).trans hh
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (div_nonneg hn hY.le)]
  calc
    _ ≤ (normalization G/Y)*(∑l:Labels G,4*Y*(product G l:ℝ)⁻¹) :=
      mul_le_mul_of_nonneg_left ((norm_sum_le _ _).trans (Finset.sum_le_sum (fun l hl=>hpoint l))) (div_nonneg hn hY.le)
    _ =4*(normalization G*(∑l:Labels G,(product G l:ℝ)⁻¹)) := by rw [←Finset.mul_sum]; field_simp
    _ =4 := by rw [normalized_harmonic_mass G hm,mul_one]

/-- Splitting one coordinate of the actual label product is exact. -/
theorem product_split_at {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (i₀:ι) (l:Labels G) :
    product G l=(l i₀).val*product (fun i:{i:ι // i≠i₀}=>G i) (fun i=>l i) := by
  letI : Fintype {i:ι // i=i₀} := Subtype.fintype (fun i:ι=>i=i₀)
  have h := Fintype.prod_subtype_mul_prod_subtype (fun i:ι=>i=i₀) (fun i=>(l i).val)
  have hp : (∏i:{i:ι // i=i₀},(l i).val)=(l i₀).val := by
    apply Finset.prod_eq_single (s:=Finset.univ) (f:=fun i:{i:ι // i=i₀}=>(l i).val) ⟨i₀,rfl⟩
    · intro i hi hne
      exact False.elim (hne (Subtype.ext i.property))
    · intro hnot
      exact False.elim (hnot (Finset.mem_univ _))
  calc
    _ = (∏i:{i:ι // i=i₀},(l i).val)*∏i:{i:ι // i≠i₀},(l i).val := h.symm
    _ = _ := congrArg (fun n=>n*product (fun i:{i:ι // i≠i₀}=>G i) (fun i=>l i)) hp

/-- One chosen prime coordinate can be isolated from the literal full label sum. -/
theorem sum_product_split_at {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (i₀:ι) (F:ℕ→ℂ) :
    (∑l:Labels G,F (product G l))=
      ∑p:(G i₀:Type),∑r:Labels (fun i:{i:ι // i≠i₀}=>G i),F (p.val*product _ r) := by
  let e := Equiv.piSplitAt i₀ (fun i=>(G i:Type))
  let U := (G i₀ : Type)
  let V := Labels (fun i : {i:ι // i≠i₀}=>G i)
  calc
    _ =∑ z : U × V,F (z.1.val*product _ z.2) := by
      apply Fintype.sum_equiv e
      intro l
      exact congrArg F (product_split_at G i₀ l)
    _ =_ := Fintype.sum_prod_type _

theorem normalization_split_at {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (i₀:ι) :
    normalization G=(∑p∈G i₀,(p:ℝ)⁻¹)⁻¹*normalization (fun i:{i:ι // i≠i₀}=>G i) := by
  letI : Fintype {i:ι // i=i₀} := Subtype.fintype (fun i:ι=>i=i₀)
  have h := Fintype.prod_subtype_mul_prod_subtype (fun i:ι=>i=i₀) (fun i=>(∑p∈G i,(p:ℝ)⁻¹)⁻¹)
  have hp : (∏i:{i:ι // i=i₀},(∑p∈G i,(p:ℝ)⁻¹)⁻¹)=(∑p∈G i₀,(p:ℝ)⁻¹)⁻¹ := by
    apply Finset.prod_eq_single (s:=Finset.univ) (f:=fun i:{i:ι // i=i₀}=>(∑p∈G i,(p:ℝ)⁻¹)⁻¹) ⟨i₀,rfl⟩
    · intro i hi hne
      exact False.elim (hne (Subtype.ext i.property))
    · intro hnot
      exact False.elim (hnot (Finset.mem_univ _))
  calc
    _ = (∏i:{i:ι // i=i₀},(∑p∈G i,(p:ℝ)⁻¹)⁻¹)*normalization (fun i:{i:ι // i≠i₀}=>G i) := h.symm
    _ = _ := congrArg (fun n=>n*normalization (fun i:{i:ι // i≠i₀}=>G i)) hp

/-- Each isolated prime block is the literal endpoint used by the analytic
energy theorem, with its remaining coefficients given by actual label products. -/
theorem isolated_block_eq_endpoint {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (S:Finset ℕ) {q:ℕ} (χ:DirichletCharacter ℂ q)
    (η:ℝ→ℂ) (hη:∀y,η y≠0→y≤4) (P Y lam t:ℝ) (hP:0<P) (hY:0<Y)
    (hS:∀p∈S,P≤(p:ℝ)) :
    (normalization G:ℂ)*(∑p∈S,∑l:Labels G,
      χ ((p*product G l:ℕ):ZMod q)*MellinPrimeSeparation.twistedCutoff η lam ((p*product G l:ℕ)/Y)*
        Artin.MarkedReplacement.archimedeanPhase t (p*product G l))=
      MellinPrimeSeparation.endpoint S (remainingPool G P Y) (fun p=>χ (p:ZMod q))
        (pushedCoefficient (product G) (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q))) η lam Y t := by
  unfold MellinPrimeSeparation.endpoint
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro p hp
  have h := pushed_cutoff_sum G (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q)) η hη P Y lam t hP hY p (hS p hp)
  calc
    _ =(χ (p:ZMod q))*(∑l:Labels G,
        ((normalization G:ℂ)*χ (product G l:ZMod q))*
          MellinPrimeSeparation.twistedCutoff η lam ((p*product G l:ℕ)/Y)*
            Artin.MarkedReplacement.archimedeanPhase t (p*product G l)) := by
      rw [Finset.mul_sum,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro l hl
      rw [Nat.cast_mul,map_mul]
      ring
    _ =_ := by rw [←h,Finset.mul_sum]; apply Finset.sum_congr rfl; intro r hr; ring

/-- The full normalized product-label endpoint used in the source major arc. -/
def fullEndpoint {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    {q:ℕ} (χ:DirichletCharacter ℂ q) (η:ℝ→ℂ) (lam Y t:ℝ) : ℂ :=
  ((normalization G/Y:ℝ):ℂ)*∑l:Labels G,
    χ (product G l:ZMod q)*MellinPrimeSeparation.twistedCutoff η lam ((product G l:ℝ)/Y)*
      Artin.MarkedReplacement.archimedeanPhase t (product G l)

theorem fullEndpoint_continuous {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    {q:ℕ} (χ:DirichletCharacter ℂ q) (η:ℝ→ℂ) (lam Y:ℝ) :
    Continuous (fullEndpoint G χ η lam Y) := by
  unfold fullEndpoint Artin.MarkedReplacement.archimedeanPhase
  fun_prop

theorem fullEndpoint_norm {ι:Type*} [Fintype ι] (G:ι→Finset ℕ)
    (hG:∀i,∀p∈G i,0<p) (hm:∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)
    {q:ℕ} (χ:DirichletCharacter ℂ q)
    (η:ℝ→ℂ) (hη:∀y,‖η y‖≤1) (hsupp:∀y,η y≠0→y≤4)
    (lam Y t:ℝ) (hY:0<Y) : ‖fullEndpoint G χ η lam Y t‖≤4 := by
  have h := full_label_endpoint_norm G hG hm η hη hsupp Y hY
    (fun l=>χ (product G l:ZMod q)*Elliptic.SourceContracts.additivePhase (-lam*((product G l:ℝ)/Y))*
      Artin.MarkedReplacement.archimedeanPhase t (product G l))
    (fun l=>by simpa only [norm_mul,Elliptic.SourceContracts.additivePhase_norm,
      Artin.MarkedReplacement.archimedeanPhase_norm,mul_one] using χ.norm_le_one (product G l:ZMod q))
  convert h using 1
  unfold fullEndpoint
  congr 2
  apply Finset.sum_congr rfl
  intro l hl
  unfold MellinPrimeSeparation.twistedCutoff
  ring

/-- Exact isolation of one prime coordinate, including its harmonic mass. -/
theorem fullEndpoint_split {ι:Type*} [Fintype ι] (G:ι→Finset ℕ) (i₀:ι)
    {q:ℕ} (χ:DirichletCharacter ℂ q) (η:ℝ→ℂ) (lam Y t:ℝ) :
    fullEndpoint G χ η lam Y t=
      (((∑p∈G i₀,(p:ℝ)⁻¹)⁻¹:ℝ):ℂ)*
      ((normalization (fun i:{i:ι // i≠i₀}=>G i)/Y:ℝ):ℂ)*
        ∑p∈G i₀,∑l:Labels (fun i:{i:ι // i≠i₀}=>G i),
          χ (p:ZMod q)*χ (product _ l:ZMod q)*
            MellinPrimeSeparation.twistedCutoff η lam ((p*product _ l:ℕ)/Y)*
              Artin.MarkedReplacement.archimedeanPhase t (p*product _ l) := by
  unfold fullEndpoint
  rw [sum_product_split_at G i₀ (fun n=>χ (n:ZMod q)*MellinPrimeSeparation.twistedCutoff η lam ((n:ℝ)/Y)*
    Artin.MarkedReplacement.archimedeanPhase t n),normalization_split_at G i₀]
  rw [Finset.sum_coe_sort (G i₀) (fun p:ℕ=>∑l:Labels (fun i:{i:ι // i≠i₀}=>G i),
    χ ((p*product _ l:ℕ):ZMod q)*MellinPrimeSeparation.twistedCutoff η lam ((p*product _ l:ℕ)/Y)*
      Artin.MarkedReplacement.archimedeanPhase t (p*product _ l))]
  simp only [Nat.cast_mul,map_mul,Complex.ofReal_div,Complex.ofReal_mul]
  ring

end Elliptic.Operator.MajorArcLabelMass
