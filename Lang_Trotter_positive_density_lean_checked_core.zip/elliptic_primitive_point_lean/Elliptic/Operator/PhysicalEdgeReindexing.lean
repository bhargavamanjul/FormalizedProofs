module

public import Elliptic.Operator.CrudePhysicalRow
public import Elliptic.Operator.DirtyOmissionAverage
public import Mathlib.Logic.Equiv.Sum

/-!
# Exact coordinates for the full physical weighted edge row

The target permutation is absent from the absolute Schur summand, and its
uniform average therefore cancels exactly. The group choices are then
reindexed by store bits, fresh/promotion bits and their actual payloads.
These are identities, retaining the geometry, hit tests and total cutoff.
They do not assert the missing sharp dirty row estimate.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

variable {I Z : Type*} [Fintype I]
variable {P : I → Type} {Line : ∀ i, P i → Type*} {J B : ℕ}

/-- A group payload is an old indexed particle when the bit is false,
and a fresh prime when the bit is true. -/
def EdgeBranchPayload (m : PhysicalMemories P Line B) (fresh : I → Bool) (i : I) :=
  bif fresh i then P i else Fin (m i).size

instance edgeBranchPayloadFintype [∀ i, Fintype (P i)]
    (m : PhysicalMemories P Line B) (fresh : I → Bool) (i : I) :
    Fintype (EdgeBranchPayload m fresh i) := by
  unfold EdgeBranchPayload
  cases fresh i <;> dsimp only [Bool.cond_false, Bool.cond_true] <;> infer_instance

/-- The branch/payload data specify the literal sum-type target choice. -/
def edgeBranchTarget (m : PhysicalMemories P Line B) (fresh : I → Bool)
    (payload : ∀ i, EdgeBranchPayload m fresh i) (i : I) : Fin (m i).size ⊕ P i :=
  (Equiv.sumEquivSigmaBool (Fin (m i).size) (P i)).symm ⟨fresh i, payload i⟩

/-- The literal store/promotion/fresh choices reconstructed from coordinates. -/
def edgeBranchChoices (m : PhysicalMemories P Line B) (store fresh : I → Bool)
    (payload : ∀ i, EdgeBranchPayload m fresh i) : ∀ i, EdgeGroupChoice (m i) :=
  fun i => (store i, edgeBranchTarget m fresh payload i)

/-- Choice of the branch and choice in its fiber commute with dependent
products. This is an actual equivalence, including empty promotion fibers. -/
def edgeBranchEquiv (m : PhysicalMemories P Line B) :
    (∀ i, EdgeGroupChoice (m i)) ≃
      (I → Bool) × (Σ fresh : I → Bool, ∀ i, EdgeBranchPayload m fresh i) := by
  let splitStore : (∀ i, EdgeGroupChoice (m i)) ≃
      (I → Bool) × (∀ i, Fin (m i).size ⊕ P i) :=
    Equiv.arrowProdEquivProdArrow I (fun _ => Bool) (fun i => Fin (m i).size ⊕ P i)
  let splitTarget : (∀ i, Fin (m i).size ⊕ P i) ≃
      (∀ i, Σ fresh : Bool, bif fresh then P i else Fin (m i).size) :=
    Equiv.piCongrRight fun i => Equiv.sumEquivSigmaBool (Fin (m i).size) (P i)
  let moveBranch : (∀ i, Σ fresh : Bool, bif fresh then P i else Fin (m i).size) ≃
      (Σ fresh : I → Bool, ∀ i, EdgeBranchPayload m fresh i) :=
    { toFun := fun f => ⟨fun i => (f i).1, fun i => (f i).2⟩
      invFun := fun f i => ⟨f.1 i, f.2 i⟩
      left_inv := fun _ => rfl
      right_inv := fun ⟨_, _⟩ => rfl }
  exact splitStore.trans (Equiv.prodCongr (Equiv.refl _) (splitTarget.trans moveBranch))

omit [Fintype I] in
theorem edgeBranchEquiv_symm_apply (m : PhysicalMemories P Line B)
    (store fresh : I → Bool) (payload : ∀ i, EdgeBranchPayload m fresh i) :
    (edgeBranchEquiv m).symm (store, ⟨fresh, payload⟩) =
      edgeBranchChoices m store fresh payload := rfl

/-- Arbitrary coupled functions of all actual choices reindex exactly;
no independence of the geometry or cutoff is required. -/
theorem sum_edgeGroupChoices_eq_branches [∀ i, Fintype (P i)]
    (m : PhysicalMemories P Line B) (f : (∀ i, EdgeGroupChoice (m i)) → ℝ) :
    (∑ c, f c) = ∑ store : I → Bool, ∑ fresh : I → Bool,
      ∑ payload : ∀ i, EdgeBranchPayload m fresh i,
        f (edgeBranchChoices m store fresh payload) := by
  classical
  rw [Fintype.sum_equiv (edgeBranchEquiv m) f (fun c => f ((edgeBranchEquiv m).symm c))
    (fun _ => by simp)]
  simp only [Fintype.sum_prod_type, Fintype.sum_sigma, edgeBranchEquiv_symm_apply]

/-- Assemble the independent old indices and independent fresh primes
without introducing dummy values in either set of groups. -/
def edgeBranchPayloadJoin (m : PhysicalMemories P Line B) (fresh : I → Bool)
    (old : ∀ i : {i // fresh i = false}, Fin (m i).size)
    (new : ∀ i : {i // fresh i = true}, P i) : ∀ i, EdgeBranchPayload m fresh i := fun i => by
  by_cases hi : fresh i = true
  · simpa only [EdgeBranchPayload, hi, Bool.cond_true] using new ⟨i, hi⟩
  · have hf : fresh i = false := Bool.eq_false_iff.mpr hi
    simpa only [EdgeBranchPayload, hf, Bool.cond_false] using old ⟨i, hf⟩

/-- Separate the selected payload coordinates into the actual old-index
tuple and actual fresh-prime tuple. Both inverses are literal. -/
def edgeBranchPayloadSplit (m : PhysicalMemories P Line B) (fresh : I → Bool) :
    (∀ i, EdgeBranchPayload m fresh i) ≃
      (∀ i : {i // fresh i = false}, Fin (m i).size) ×
      (∀ i : {i // fresh i = true}, P i) where
  toFun payload :=
    (fun i => by simpa only [EdgeBranchPayload, i.property, Bool.cond_false] using payload i,
      fun i => by simpa only [EdgeBranchPayload, i.property, Bool.cond_true] using payload i)
  invFun pair := edgeBranchPayloadJoin m fresh pair.1 pair.2
  left_inv payload := by
    funext i
    cases hi : fresh i <;> simp [edgeBranchPayloadJoin, hi]
  right_inv pair := by
    apply Prod.ext <;> funext i <;> simp [edgeBranchPayloadJoin, i.property]

/-- Exact separation of fresh-prime integration from indexed promotions. -/
theorem sum_edgeBranchPayload_eq_old_fresh [∀ i, Fintype (P i)]
    (m : PhysicalMemories P Line B) (fresh : I → Bool)
    (f : (∀ i, EdgeBranchPayload m fresh i) → ℝ) :
    (∑ payload, f payload) =
      ∑ old : ∀ i : {i // fresh i = false}, Fin (m i).size,
        ∑ new : ∀ i : {i // fresh i = true}, P i,
          f (edgeBranchPayloadJoin m fresh old new) := by
  classical
  rw [Fintype.sum_equiv (edgeBranchPayloadSplit m fresh) f
    (fun pair => f ((edgeBranchPayloadSplit m fresh).symm pair)) (fun _ => by simp)]
  rw [Fintype.sum_prod_type]
  rfl

/-- For a general source-permutation-dependent summand, the omission
average and retained-slot average are both exact. No slot invariance is
assumed or silently used to delete the retained permutations. -/
theorem source_permutation_average_eq_omission_retained_average
    (J : ℕ) (f : (I → Equiv.Perm (Fin (J+1))) → ℝ) :
    (∑ σ, f σ) / (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) =
      ((∑ o : I → Fin (J+1), ∑ τ : I → Equiv.Perm (Fin J),
        f ((groupLastSlotPermutationEquiv I J).symm (o, τ))) /
          (Fintype.card (I → Equiv.Perm (Fin J)) : ℝ)) /
            (J+1 : ℝ)^Fintype.card I := by
  classical
  have hs := Fintype.sum_equiv (groupLastSlotPermutationEquiv I J) f
    (fun pair => f ((groupLastSlotPermutationEquiv I J).symm pair)) (fun _ => by simp)
  rw [hs, Fintype.sum_prod_type]
  have hc : (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) =
      (J+1 : ℝ)^Fintype.card I * (Fintype.card (I → Equiv.Perm (Fin J)) : ℝ) := by
    simp only [Fintype.card_fun, Fintype.card_perm, Fintype.card_fin, Nat.factorial_succ,
      Nat.cast_pow, Nat.cast_mul, Nat.cast_add, Nat.cast_one, mul_pow]
  rw [hc, div_div, mul_comm ((J+1 : ℝ)^Fintype.card I)]

/-- A target-permutation-free local weighted summand. All actual local
hit tests and the total output-memory cutoff remain inside the sum. -/
def physicalEdgeLocalAbsoluteSummand
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (σ : I → Equiv.Perm (Fin (J+1))) (c : ∀ i, EdgeGroupChoice (s.memory P Line J B i)) : ℝ :=
  let e : PhysicalEdgeChoice s := (z, σ, c, fun _ => Equiv.refl _)
  if e.Valid anchor s then
    ‖geometry (s.position P Line J B) e.sourceLists e.target e.targetLists‖ *
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
        (anchor z i) (e.sourcePrime i) (s.memory P Line J B i) (c i)
  else 0

/-- The full weighted summand has no target-permutation dependence.
In particular this does not assume that the geometric multiplier is symmetric. -/
theorem physicalEdge_absolute_summand_eq
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    (if hc : c.Valid anchor s then
      ‖physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc‖ *
        (physicalMemorySchurWeight v0 (c.output anchor s hc) / physicalMemorySchurWeight v0 s)
      else 0) =
      endpointPermutationWeight I J * physicalEdgeLocalAbsoluteSummand
        ν V ρ v0 anchor geometry s c.target c.sourcePerm c.group := by
  unfold physicalEdgeLocalAbsoluteSummand
  have hv : PhysicalEdgeChoice.Valid anchor s
      (c.target, c.sourcePerm, c.group, fun _ => Equiv.refl _) ↔ c.Valid anchor s := Iff.rfl
  simp only [hv]
  split_ifs with hc
  · rw [physicalEdgeChoiceWeight_norm_mul_ratio ν V ρ v0 anchor geometry s c hc hν hV hρ]
    change endpointPermutationWeight I J *
      ‖geometry (s.position P Line J B) c.sourceLists c.target c.targetLists‖ *
      (∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
        (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i)) =
      endpointPermutationWeight I J *
      (‖geometry (s.position P Line J B) c.sourceLists c.target c.targetLists‖ *
      ∏ i, edgeWeightedChoice (ν i) (V i) ρ v0 (anchor (s.position P Line J B) i)
        (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i) (c.group i))
    exact mul_assoc _ _ _
  · simp

/-- Exactly one endpoint average remains in the actual absolute Schur row.
The other cancels by summing its equal summands. -/
theorem physicalEdgeAbsoluteChoiceRow_eq_local [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s =
      (∑ z : Z, ∑ σ : I → Equiv.Perm (Fin (J+1)),
        ∑ c : ∀ i, EdgeGroupChoice (s.memory P Line J B i),
          physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z σ c) /
        (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) := by
  classical
  unfold physicalEdgeAbsoluteChoiceRow
  simp_rw [physicalEdge_absolute_summand_eq ν V ρ v0 anchor geometry s _ hν hV hρ]
  simp only [Fintype.sum_prod_type]
  change (∑ z : Z, ∑ σ : I → Equiv.Perm (Fin (J+1)),
    ∑ c : ∀ i, EdgeGroupChoice (s.memory P Line J B i),
    ∑ _τ : I → Equiv.Perm (Fin (J+1)), endpointPermutationWeight I J *
      physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z σ c) = _
  simp only [Finset.sum_const, nsmul_eq_mul, Finset.card_univ]
  simp_rw [← Finset.mul_sum]
  unfold endpointPermutationWeight
  have hn : (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) ≠ 0 := by
    exact_mod_cast (Fintype.card_pos_iff.mpr ⟨fun _ => Equiv.refl _⟩).ne'
  field_simp

/-- Exact finite coordinates for the actual full weighted edge row:
positions, source permutations, optional stores, promotion pattern and
old-index/fresh-prime payloads. Restrictions have not been discarded. -/
theorem physicalEdgeAbsoluteChoiceRow_eq_branches [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s =
      (∑ z : Z, ∑ σ : I → Equiv.Perm (Fin (J+1)),
        ∑ store : I → Bool, ∑ fresh : I → Bool,
          ∑ payload : ∀ i, EdgeBranchPayload (s.memory P Line J B) fresh i,
            physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z σ
              (edgeBranchChoices (s.memory P Line J B) store fresh payload)) /
        (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) := by
  rw [physicalEdgeAbsoluteChoiceRow_eq_local ν V ρ v0 anchor geometry s hν hV hρ]
  congr 1
  apply Finset.sum_congr rfl
  intro z _
  apply Finset.sum_congr rfl
  intro σ _
  exact sum_edgeGroupChoices_eq_branches _ _

/-- The actual full row as a sum over independent fresh-prime tuples and
old indexed promotions, with exactly the remaining source average. -/
theorem physicalEdgeAbsoluteChoiceRow_eq_old_fresh [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s =
      (∑ z : Z, ∑ σ : I → Equiv.Perm (Fin (J+1)),
        ∑ store : I → Bool, ∑ fresh : I → Bool,
          ∑ old : ∀ i : {i // fresh i = false}, Fin (s.memory P Line J B i).size,
            ∑ new : ∀ i : {i // fresh i = true}, P i,
              physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z σ
                (edgeBranchChoices (s.memory P Line J B) store fresh
                  (edgeBranchPayloadJoin (s.memory P Line J B) fresh old new))) /
        (Fintype.card (I → Equiv.Perm (Fin (J+1))) : ℝ) := by
  rw [physicalEdgeAbsoluteChoiceRow_eq_branches ν V ρ v0 anchor geometry s hν hV hρ]
  simp_rw [sum_edgeBranchPayload_eq_old_fresh]

/-- The source omission normalization on the actual full physical row.
Dependence on permutations of retained slots is averaged, not assumed
away, and the cutoff and geometry remain literal. -/
theorem physicalEdgeAbsoluteChoiceRow_eq_omission_retained
    [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ v0 : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i) (hρ : 0 ≤ ρ) :
    physicalEdgeAbsoluteChoiceRow ν V ρ v0 anchor geometry s =
      ((∑ o : I → Fin (J+1), ∑ τ : I → Equiv.Perm (Fin J), ∑ z : Z,
        ∑ c : ∀ i, EdgeGroupChoice (s.memory P Line J B i),
          physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z
            ((groupLastSlotPermutationEquiv I J).symm (o, τ)) c) /
              (Fintype.card (I → Equiv.Perm (Fin J)) : ℝ)) /
                (J+1 : ℝ)^Fintype.card I := by
  rw [physicalEdgeAbsoluteChoiceRow_eq_local ν V ρ v0 anchor geometry s hν hV hρ,
    Finset.sum_comm]
  exact source_permutation_average_eq_omission_retained_average J
    (fun σ : I → Equiv.Perm (Fin (J+1)) => ∑ z : Z,
      ∑ c : ∀ i, EdgeGroupChoice (s.memory P Line J B i),
        physicalEdgeLocalAbsoluteSummand ν V ρ v0 anchor geometry s z σ c)

end Elliptic.Operator
