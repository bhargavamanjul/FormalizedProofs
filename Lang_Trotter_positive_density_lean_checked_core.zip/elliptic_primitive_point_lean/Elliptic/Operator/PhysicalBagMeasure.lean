module

public import Elliptic.Operator.PhysicalMaskedKernel

/-!
# Exact physical measure on the finite memory-bag quotient

Summing the ordered factorial measure over each bag fiber produces the
literal bag mass. The grouped pushforward allows arbitrary coupled test
functions and preserves the physical total-memory cutoff exactly.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBagMeasure
open scoped BigOperators
open PhysicalEdgeAdjoint PhysicalMaskedKernel
attribute [local instance] Classical.propDecidable
local instance physicalBagMeasureDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Coordinatewise pushforward of a finite product measure, for an
arbitrary coupled function on the quotient coordinates. -/
theorem sum_pi_pushforward {I : Type*} [Fintype I]
    {X Y : I → Type*} [∀ i, Fintype (X i)] [∀ i, Fintype (Y i)]
    {R : Type*} [CommSemiring R]
    (w : ∀ i, X i → R) (q : ∀ i, X i → Y i) (F : (∀ i, Y i) → R) :
    (∑ x : ∀ i, X i, (∏ i, w i (x i)) * F (fun i => q i (x i))) =
      ∑ y : ∀ i, Y i,
        (∏ i, ∑ x : X i, if q i x = y i then w i x else 0) * F y := by
  symm
  simp_rw [Fintype.prod_sum]
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  rw [Finset.sum_eq_single (fun i => q i (x i))]
  · simp
  · intro y _ hy
    have hi : ∃ i, q i (x i) ≠ y i := by
      by_contra hn
      push Not at hn
      exact hy (funext (fun i => (hn i).symm))
    obtain ⟨i,hi⟩ := hi
    have hz : (∏ i, if q i (x i) = y i then w i (x i) else 0) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i) (by simp [hi])
    rw [hz,zero_mul]
  · simp

/-- Subtype integration is exactly zero-extension, for any additive codomain. -/
theorem sum_subtype_zero {X R : Type*} [Fintype X] [AddCommMonoid R]
    (p : X → Prop) [DecidablePred p] (f : {x // p x} → R) :
    (∑ x : {x // p x}, f x) = ∑ x : X, if h : p x then f ⟨x,h⟩ else 0 := by
  symm
  rw [Finset.sum_dite]
  simp only [Finset.sum_const_zero,add_zero]
  exact (Equiv.subtypeEquivRight (by simp)).sum_comp f

variable {G Z : Type*} [Fintype G]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

/-- The physical product measure with coefficients in an arbitrary field. -/
def orderedMass {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : R :=
  ∏ i, tupleWeight (ν i) (s.active P Line J B i) *
    MemoryState.mass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1)
      (s.memory P Line J B i)

/-- The grouped memory measure pushes forward exactly, with no
factorization assumption on the test function. -/
theorem memory_integral {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (F : Bags (P:=P) (Line:=Line) (B:=B) → R) :
    (∑ m : PhysicalMemories P Line B,
      (∏ i, MemoryState.mass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (m i)) *
        F (fun i => memoryBagOf (m i))) =
    ∑ b : Bags (P:=P) (Line:=Line) (B:=B),
      (∏ i, memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (b i)) * F b := by
  have h := sum_pi_pushforward
    (fun i (m : MemoryState (AnchoredParticle (P i) (Line i)) B) =>
      m.mass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1))
    (fun _ m => memoryBagOf m) F
  refine h.trans ?_
  apply Finset.sum_congr rfl
  intro b _
  apply congrArg (· * F b)
  apply Finset.prod_congr rfl
  intro i _
  unfold memoryBagMass
  apply Finset.sum_congr rfl
  intro m _
  by_cases hm : memoryBagOf m = b i
  · have hp : tupleBag m.values = (b i).val := congrArg Subtype.val hm
    simp only [ite_eq_left hm,ite_eq_left hp]
  · have hp : tupleBag m.values ≠ (b i).val := fun he => hm (Subtype.ext he)
    simp only [ite_eq_right hm,ite_eq_right hp]

/-- Exact physical quotient integration, retaining the source's single
total memory cutoff and every repeated-particle ordering multiplicity. -/
theorem integral_eq_bag [Fintype Z] {R : Type*} [Field R]
    (ν : ∀ i, P i → R)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → R) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      orderedMass ν s * F (ofOrdered s)) =
    ∑ s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
      mass ν s * (if Total s then F s else 0) := by
  rw [sum_subtype_zero
    (fun x : Z × (PhysicalActiveLists P J × PhysicalMemories P Line B) =>
      (∑ i, (x.2.2 i).size) ≤ B)
    (fun s => orderedMass ν s * F (ofOrdered s))]
  simp only [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro z _
  apply Finset.sum_congr rfl
  intro a _
  let w : R := ∏ i, tupleWeight (ν i) (a i)
  let H : Bags (P:=P) (Line:=Line) (B:=B) → R :=
    fun b => if Total (z,a,b) then F (z,a,b) else 0
  calc
    _ = w * (∑ m : PhysicalMemories P Line B,
        (∏ i, MemoryState.mass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (m i)) *
          H (fun i => memoryBagOf (m i))) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m _
      by_cases hm : (∑ i, (m i).size) ≤ B
      · simp only [hm,dite_true,orderedMass,ofOrdered,PhysicalMemoryState.position,
          PhysicalMemoryState.active,PhysicalMemoryState.memory,H,Total,bags,memoryBagOf_card,
          ite_true,w,Finset.prod_mul_distrib,mul_assoc]
      · simp only [hm,dite_false,H,Total,bags,memoryBagOf_card,ite_false,mul_zero]
    _ = w * (∑ b : Bags (P:=P) (Line:=Line) (B:=B),
        (∏ i, memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (b i)) * H b) := by
      rw [memory_integral ν H]
    _ = _ := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b _
      simp only [w,H,mass,active,bags,Finset.prod_mul_distrib,mul_assoc]

/-- The real ordered mass is the original physical mass definition. -/
theorem orderedMass_real (ν : ∀ i, P i → ℝ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    orderedMass ν s = PhysicalMemoryState.mass P Line J B ν s := rfl

/-- Exact integration for the original real physical measure. -/
theorem physical_integral_eq_bag [Fintype Z]
    (ν : ∀ i, P i → ℝ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℝ) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      PhysicalMemoryState.mass P Line J B ν s * F (ofOrdered s)) =
    ∑ s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
      mass ν s * (if Total s then F s else 0) :=
  integral_eq_bag ν F

/-- Complexifying the measure preserves the literal factorial weights. -/
theorem orderedMass_complex (ν : ∀ i, P i → ℝ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    orderedMass (fun i p => (ν i p : ℂ)) s =
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) := by
  simp [orderedMass,PhysicalMemoryState.mass,MemoryState.mass,anchoredParticleMass,
    tupleWeight,Complex.ofReal_prod]

/-- The original complex bilinear physical pairing uses exactly this
finite bag quotient measure, with the total cutoff retained. -/
theorem physical_complex_integral_eq_bag [Fintype Z]
    (ν : ∀ i, P i → ℝ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) → ℂ) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) * F (ofOrdered s)) =
    ∑ s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B),
      mass (fun i p => (ν i p : ℂ)) s * (if Total s then F s else 0) := by
  simpa only [orderedMass_complex] using integral_eq_bag (fun i p => (ν i p : ℂ)) F

end Elliptic.Operator.PhysicalBagMeasure
