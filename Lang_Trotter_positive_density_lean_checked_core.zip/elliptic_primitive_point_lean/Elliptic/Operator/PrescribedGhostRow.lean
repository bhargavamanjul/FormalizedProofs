module

public import Elliptic.Operator.PrescribedPrimeTuple

/-!
# Actual ghost rows with chronological prescribed prime values

The named ordered coordinates must really be reached by the birth batch.
Each prescribed value may depend on all earlier coordinates in that batch.
The actual factorial 1/l! is retained. The resulting atom saving is uniform
in the old memory, its hit pattern, and the birth-batch cutoff.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PrescribedGhostRow
open scoped BigOperators
open PrescribedPrimeTuple
attribute [local instance] Classical.propDecidable
local instance prescribedGhostDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- The finite shifted exponential series is dominated by the full
unshifted partial series, with no loss in the number of named coordinates. -/
theorem shifted_sum_le_exp (x : ℝ) (hx : 0 ≤ x) (s B : ℕ) :
    (∑ l ∈ (Finset.range (B+1)).filter (fun l => s ≤ l),
      x^(l-s) / ((l-s).factorial : ℝ)) ≤ Real.exp x := by
  apply (Finset.sum_le_sum_of_injOn (fun l => l-s) ?_ ?_ ?_ ?_).trans
    (Real.sum_le_exp_of_nonneg hx (B+1))
  · intro l hl k hk he
    have hsl := (Finset.mem_filter.mp hl).2
    have hsk := (Finset.mem_filter.mp hk).2
    dsimp only at he
    omega
  · intro k hk
    obtain ⟨l,hl,rfl⟩ := Finset.mem_image.mp hk
    exact Finset.mem_range.mpr (lt_of_le_of_lt (Nat.sub_le _ _) (Finset.mem_range.mp (Finset.mem_filter.mp hl).1))
  · intro l hl
    exact le_rfl
  · intro k hk hnot
    positivity

/-- The factorial denominator absorbs the prescribed-coordinate shift. -/
theorem factorial_term_le (c Δ m : ℝ) (hc : 0 ≤ c) (hΔ : 0 ≤ Δ) (hm : 0 ≤ m)
    (s l : ℕ) (hsl : s ≤ l) :
    c^l / (l.factorial : ℝ) * (Δ^s * m^(l-s)) ≤
      (c*Δ)^s * ((c*m)^(l-s) / ((l-s).factorial : ℝ)) := by
  have hfac : ((l-s).factorial : ℝ) ≤ (l.factorial : ℝ) :=
    Nat.cast_le.mpr (Nat.factorial_le (Nat.sub_le _ _))
  have hnum : c^l * (Δ^s*m^(l-s)) = (c*Δ)^s*(c*m)^(l-s) := by
    have hp : c^l = c^s*c^(l-s) := by
      rw [← pow_add]
      congr 1
      omega
    rw [hp,mul_pow,mul_pow]
    ring
  calc
    _ = (c^l * (Δ^s*m^(l-s))) / (l.factorial : ℝ) := by ring
    _ ≤ (c^l * (Δ^s*m^(l-s))) / ((l-s).factorial : ℝ) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity) hfac
    _ = _ := by rw [hnum]; ring

variable {P : Type*} [Fintype P]

/-- The literal factorial fresh-batch series, with performed flags and
adaptive prescriptions at the named ordered coordinates. -/
def batchSeries (ν : P → ℝ) (value : P → ℕ) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (c : ℝ) (B : ℕ) : ℝ :=
  ∑ l ∈ Finset.range (B+1),
    c^l / (l.factorial : ℝ) *
      (if S ⊆ Finset.range l then
        ∑ x : Fin l → P, if Allowed value S target x then tupleWeight ν x else 0
      else 0)

/-- Source (4.49), proved for arbitrary dependence on earlier batch values.
The reached-index requirement is kept explicitly on the left. -/
theorem batchSeries_le (ν : P → ℝ) (value : P → ℕ)
    (hinj : Function.Injective value) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (c Δ : ℝ) (B : ℕ)
    (hν : ∀ p, 0 ≤ ν p) (hc : 0 ≤ c) (hΔ : 0 ≤ Δ) (hatom : ∀ p, ν p ≤ Δ) :
    batchSeries ν value S target c B ≤
      (c*Δ)^S.card * Real.exp (c*∑ p,ν p) := by
  have hm : 0 ≤ ∑ p,ν p := Finset.sum_nonneg (fun p _ => hν p)
  have hx : 0 ≤ c * ∑ p,ν p := mul_nonneg hc hm
  calc
    _ ≤ ∑ l ∈ Finset.range (B+1), if S.card ≤ l then
        (c*Δ)^S.card * ((c*∑ p,ν p)^(l-S.card) / ((l-S.card).factorial : ℝ)) else 0 := by
      unfold batchSeries
      apply Finset.sum_le_sum
      intro l _
      by_cases hS : S ⊆ Finset.range l
      · have hsl : S.card ≤ l := (Finset.card_le_card hS).trans_eq (Finset.card_range l)
        rw [ite_eq_left hS,ite_eq_left hsl]
        exact (mul_le_mul_of_nonneg_left
          (sum_le_atoms ν value hinj S target Δ hν hΔ hatom l hS) (by positivity)).trans
          (factorial_term_le c Δ (∑ p,ν p) hc hΔ hm S.card l hsl)
      · rw [ite_eq_right hS,mul_zero]
        split_ifs <;> positivity
    _ = (c*Δ)^S.card *
        (∑ l ∈ (Finset.range (B+1)).filter (fun l => S.card ≤ l),
          (c*∑ p,ν p)^(l-S.card) / ((l-S.card).factorial : ℝ)) := by
      simp only [Finset.sum_filter,Finset.mul_sum,mul_ite,mul_zero]
    _ ≤ _ := mul_le_mul_of_nonneg_left (shifted_sum_le_exp _ hx S.card B) (by positivity)

/-- The actual named fresh coordinates must be performed; no value is
assigned to padding or to a batch that ends before a named coordinate. -/
def BatchAllowed (value : P → ℕ) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) {B : ℕ} (m : MemoryState P B) : Prop :=
  S ⊆ Finset.range m.size ∧ Allowed value S target m.values

/-- The actual absolute weighted row restricted to its literal fresh tuple. -/
def choiceRow {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p,Line p)
    (value : P → ℕ) (S : Finset ℕ) (target : ∀ j : ℕ, (Fin j → P) → ℕ)
    (m : MemoryState (AnchoredParticle P Line) B) : ℝ :=
  ∑ c : GhostChoice m, if hc : GhostChoice.Valid anchor m c then
    if BatchAllowed value S target c.2 then
      |ghostChoiceWeight ν V η q ρ anchor m c| *
        (v0^(ghostOutput anchor m c hc).size / v0^m.size) else 0
  else 0

/-- The indexed majorant retains the exact hit deletion sum and every
prescribed fresh coordinate; only the output-size restriction is dropped. -/
def indexedRow (k : ℕ) (hits : Finset (Fin k))
    (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (value : P → ℕ) (S : Finset ℕ) (target : ∀ j : ℕ, (Fin j → P) → ℕ) : ℝ :=
  ∑ D ∈ hits.powerset, ∑ l ∈ Finset.range (B+1), ∑ fresh : Fin l → P,
    if S ⊆ Finset.range l ∧ Allowed value S target fresh then
      (delete^D.card * survive^(hits.card-D.card) * birth^l * tupleWeight ν fresh /
        (l.factorial : ℝ)) * (v0^(k-D.card+l) / v0^k) else 0

/-- Exact factorization of the actual prescribed indexed ghost row. -/
theorem indexedRow_eq (k : ℕ) (hits : Finset (Fin k))
    (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (value : P → ℕ) (S : Finset ℕ) (target : ∀ j : ℕ, (Fin j → P) → ℕ)
    (hv0 : v0 ≠ 0) :
    indexedRow k hits ν survive delete birth v0 B value S target =
      (survive+delete/v0)^hits.card * batchSeries ν value S target (birth*v0) B := by
  unfold indexedRow batchSeries
  rw [← ghostHitChoiceSum_eq hits survive delete v0]
  unfold ghostHitChoiceSum
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro D hD
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro l hl
  have hsub := Finset.mem_powerset.mp hD
  have hcard : D.card ≤ k := (Finset.card_le_card hsub).trans
    ((Finset.card_le_univ _).trans_eq (Fintype.card_fin k))
  by_cases hS : S ⊆ Finset.range l
  · rw [ite_eq_left hS,Finset.mul_sum,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro fresh _
    by_cases hf : Allowed value S target fresh
    · rw [ite_eq_left ⟨hS,hf⟩,ite_eq_left hf,
        ghost_memory_weight_ratio k D.card l v0 hv0 hcard]
      simp only [Finset.prod_const,Finset.card_sdiff_of_subset hsub,div_pow,mul_pow]
      ring
    · simp [hS,hf]
  · simp [hS]

/-- The old-memory deletion and survival factor is at most one, leaving
exactly the source atom gain and exponential fresh-batch constant. -/
theorem indexedRow_le (k : ℕ) (hits : Finset (Fin k))
    (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (value : P → ℕ) (hinj : Function.Injective value) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (Δ : ℝ)
    (hν : ∀ p,0≤ν p) (hsurvive : 0≤survive) (hdelete : 0≤delete) (hbirth : 0≤birth)
    (hv0 : 0<v0) (hparenthesis : survive+delete/v0≤1)
    (hΔ : 0≤Δ) (hatom : ∀ p,ν p≤Δ) :
    indexedRow k hits ν survive delete birth v0 B value S target ≤
      (birth*v0*Δ)^S.card * Real.exp (birth*v0*∑ p,ν p) := by
  rw [indexedRow_eq k hits ν survive delete birth v0 B value S target hv0.ne']
  have hp : 0≤survive+delete/v0 := by positivity
  have h := batchSeries_le ν value hinj S target (birth*v0) Δ B hν (by positivity) hΔ hatom
  calc
    _ ≤ (survive+delete/v0)^hits.card *
        ((birth*v0*Δ)^S.card * Real.exp (birth*v0*∑ p,ν p)) :=
      mul_le_mul_of_nonneg_left h (pow_nonneg hp _)
    _ ≤ 1 * ((birth*v0*Δ)^S.card * Real.exp (birth*v0*∑ p,ν p)) :=
      mul_le_mul_of_nonneg_right (pow_le_one₀ hp hparenthesis) (by positivity)
    _ = _ := one_mul _

/-- Comparison is made directly on the literal ordered operation choices,
including every indexed deletion and the actual reached-index flags. -/
theorem choiceRow_le_indexed {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p,Line p)
    (value : P → ℕ) (S : Finset ℕ) (target : ∀ j : ℕ, (Fin j → P) → ℕ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p,0≤ν p) (hV : 0≤V) (hη : 0≤η) (hq : 0≤q) (hρ : 0≤ρ) (hv0 : 0≤v0) :
    choiceRow ν V η q ρ v0 anchor value S target m ≤
      indexedRow m.size (memoryHits anchor m) ν (q/ρ^2) (η/ρ) (η*V/ρ) v0 B value S target := by
  let F := fun (D : Finset (Fin m.size)) (l : ℕ) (fresh : Fin l → P) =>
    if S ⊆ Finset.range l ∧ Allowed value S target fresh then
      ((η/ρ)^D.card * (q/ρ^2)^((memoryHits anchor m).card-D.card) *
        (η*V/ρ)^l * tupleWeight ν fresh / (l.factorial : ℝ)) *
        (v0^(m.size-D.card+l)/v0^m.size) else 0
  have hpoint (c : GhostChoice m) :
      (if hc : GhostChoice.Valid anchor m c then
        if BatchAllowed value S target c.2 then
          |ghostChoiceWeight ν V η q ρ anchor m c| *
            (v0^(ghostOutput anchor m c hc).size/v0^m.size) else 0 else 0) ≤
      if c.1 ⊆ memoryHits anchor m then F c.1 c.2.size c.2.values else 0 := by
    by_cases hc : GhostChoice.Valid anchor m c
    · rw [dite_eq_left hc,ite_eq_left hc.1]
      by_cases hb : BatchAllowed value S target c.2
      · rw [ite_eq_left hb,ghostOutput_size,
          ghostChoiceWeight_abs ν V η q ρ anchor m c hν hV hη hq hρ,
          Finset.card_sdiff_of_subset hc.1]
        have hb' : S ⊆ Finset.range c.2.size ∧ Allowed value S target c.2.values := hb
        exact le_of_eq (by simp only [F,ite_eq_left hb'])
      · simp only [F,BatchAllowed] at hb ⊢
        simp only [ite_eq_right hb]
        exact le_rfl
    · rw [dite_eq_right hc]
      have ht : 0 ≤ tupleWeight ν c.2.values := Finset.prod_nonneg (fun _ _ => hν _)
      simp only [F]
      split_ifs <;> positivity
  unfold choiceRow
  apply (Finset.sum_le_sum (fun c _ => hpoint c)).trans_eq
  exact sum_ghost_choices_hits m.size B (memoryHits anchor m) F

/-- Actual one-group source (4.49), with its adaptive prescribed values
and its deletion/survival factor discharged from the literal coefficients. -/
theorem choiceRow_le {Line : P → Type*} {B : ℕ}
    (ν : P → ℝ) (V η q ρ v0 : ℝ) (anchor : ∀ p,Line p)
    (value : P → ℕ) (hinj : Function.Injective value) (S : Finset ℕ)
    (target : ∀ j : ℕ, (Fin j → P) → ℕ) (Δ : ℝ)
    (m : MemoryState (AnchoredParticle P Line) B)
    (hν : ∀ p,0≤ν p) (hV : 0≤V) (hη : 0≤η) (hq : 0≤q) (hρ : 0<ρ) (hv0 : 0<v0)
    (hparenthesis : q/ρ^2+η/(ρ*v0)≤1) (hΔ : 0≤Δ) (hatom : ∀ p,ν p≤Δ) :
    choiceRow ν V η q ρ v0 anchor value S target m ≤
      ((η*V/ρ)*v0*Δ)^S.card * Real.exp ((η*V/ρ)*v0*∑ p,ν p) := by
  apply (choiceRow_le_indexed ν V η q ρ v0 anchor value S target m
    hν hV hη hq hρ.le hv0.le).trans
  apply indexedRow_le m.size (memoryHits anchor m) ν (q/ρ^2) (η/ρ) (η*V/ρ) v0 B
    value hinj S target Δ hν (by positivity) (by positivity) (by positivity) hv0 _ hΔ hatom
  simpa only [div_div] using hparenthesis

end Elliptic.Operator.PrescribedGhostRow
