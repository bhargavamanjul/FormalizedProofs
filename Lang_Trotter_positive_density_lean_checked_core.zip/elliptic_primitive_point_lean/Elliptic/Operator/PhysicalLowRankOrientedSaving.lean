module

public import Elliptic.Operator.PhysicalOrientedEdgeAsymptotics
public import Elliptic.Operator.PhysicalPhasedEdgeActualCrude
public import Elliptic.Operator.PhysicalLowRankBoundary
public import Elliptic.Operator.BirthRankInstances

/-! The actual low-rank physical boundary contribution, with both edge
estimates discharged for the literal root geometry. The two vacuum factors
retain the full transformed initial mass. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalLowRankOrientedSaving
open Filter
open scoped BigOperators SchwartzMap ComplexConjugate
open ActualHistoryBirths RootLiteralGeometry PhysicalBagNorm PhysicalPhasedWord PhysicalBirthFactors PhysicalFourierWord
open PhysicalLowRankBoundary PhysicalFullEdgeAsymptotics PhysicalOrientedEdgeAsymptotics
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem phased_edge_congr_geometry {I Z : Type} [Fintype I] [Fintype Z]
    {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} {J B : ℕ}
    (ν : ∀i,P i→ℝ) (V : I→ℝ) (ρ : ℝ) (anchor : Z→∀i p,Line i p)
    (g h : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ) (he : g=h)
    (phase : (s : PhysicalMemoryState (Z:=Z) P Line J B)→PhysicalEdgeChoice s→ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) :
    phasedApply (physicalEdgeOperation ν V ρ anchor g) phase F=
      phasedApply (physicalEdgeOperation ν V ρ anchor h) phase F := by
  subst h
  rfl

 def literalOrientedGeometry {K J : ℕ} (positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
    (μ : ∀i,groups i→ℝ) (d₀ Y L : ℝ) (a : Fin K→ℝ) (q : RootPhysicalCell.RootPoint)
    (U W : ℝ) (η ψ : ℝ→ℂ) (H : ℝ) (adjoint : ℕ→Bool) (sign : ℕ→ℤ) :
    ℕ→positions→PhysicalActiveLists (fun i=>groups i) J→positions→PhysicalActiveLists (fun i=>groups i) J→ℂ :=
  fun j z b w c=>orientedSourceEdgeGeometry (adjoint j) (fun i (p:groups i)=>p.val)
    (sourceGood (fun i (p:groups i)=>p.val) μ d₀ Y L a q)
    (U*q.1) (W*q.2.1) q.2.2 U W d₀ Y η ψ (sourceMajorArcs H Y) (sign j) z.val b w.val c

 theorem exists_group_count_for_actual_oriented_lowrank (G : ℝ) (hG : 0≤G) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(Cweight : Fin K→ℝ),(∀i,0≤Cweight i)→
      ∀(ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ Cmass Catom ρ vmin vmax : ℝ),
      1≤C→0≤Aψ→1≤Cmass→0≤Catom→(∀i,Cweight i≤Catom)→
      0<ρ→ρ<1→0<vmin→
      (∀x,‖η x‖≤1)→(∀x,η x≠0→1≤x)→
      (∀x,‖ψ x‖≤Aψ)→(∀x,ψ x≠0→|x|≤C)→
      ∀ᶠ L : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i (p:groups i),Fintype (ZMod p.val)),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀(ν : Fin K→ℕ→ℝ) (μ : ∀i,groups i→ℝ) (V : Fin K→ℝ),
      (∀i,∀p∈groups i,0<ν i p)→(∀i,∀p∈groups i,ν i p≤Cweight i/p)→
      (∀i,∑p:groups i,ν i p.val≤Cmass)→(∀i (p:groups i),ν i p.val≤2*μ i p)→
      (∀i,vmin≤V i)→(∀i,V i≤vmax)→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      (∏i,(∑p:groups i,ν i p.val)^(momentPadding L+1))≤2→
      ∀(d₀ Y : ℝ) (qroot : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤qroot.1→qroot.1≤16→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀(ηg qg : ℕ→ℝ) (Qg : ℝ),Qg<ρ^2→(∀j,0≤qg j)→(∀j,qg j≤Qg)→
      (∀j,0≤ηg j)→(∀j,ηg j≤1)→∀(adjoint : ℕ→Bool) (sign : ℕ→ℤ),(∀j,sign j=1∨sign j= -1)→
      ∀N : ℕ,∀σ : Equiv.Perm (Address (Fin K) (momentPadding L) (memoryCutoff L) N),
      ∀(z₀ z₁ : positions) (b₀ b₁ : PhysicalActiveLists (fun i=>groups i) (momentPadding L)→ℂ),
      (∀t,‖b₀ t‖≤1)→(∀t,‖b₁ t‖≤1)→
      ‖term (fun i (p:groups i)=>ν i p.val) V ηg qg ρ
        (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:positions=>z.val))
        (literalOrientedGeometry positions groups μ d₀ Y L a qroot U W η ψ (L^(G+6)) adjoint sign)
        (fun i (p:groups i)=>p.val) σ
        (fun u=>if u.1=z₀ then b₀ u.2 else 0) (fun u=>if u.1=z₁ then b₁ u.2 else 0)‖≤
      2*(((Real.exp (ghostSchurWeight ρ Qg vmax*max 1 vmax*Cmass/ρ))^K)^(N+1)*
        (L^(PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1))^(2*birthCycleRank σ)*
        (L^(-G))^(N-2*birthCycleRank σ)) := by
  obtain ⟨Kc,hKc,hclean⟩ := exists_group_count_for_actual_oriented_saving G hG
  obtain ⟨Km,hKm,hmod⟩ := PhysicalPhasedEdgeActualCrude.exists_group_count_for_actual_modified_bound
  refine ⟨max Kc Km,hKc.trans (le_max_left _ _),?_⟩
  intro K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax
    hC hAψ hmassC hCatom hweight hρ hρ1 hmin hη hηsupport hψ hψsupport
  have hm0 : 0≤Cmass := (by norm_num : (0:ℝ)≤1).trans hmassC
  filter_upwards [hclean K ((le_max_left _ _).trans hK) Cweight hCweight ψ η C Aψ Cmass Catom
    ρ vmin vmax hC hAψ hmassC hCatom hweight hρ.le hρ1 hmin hη hηsupport hψ hψsupport,
    hmod K ((le_max_right _ _).trans hK) ρ 1 vmin vmax Cmass 1 Aψ (G+6) C
      hρ.le hρ1 (by norm_num) hmin hm0 hAψ hC,eventually_ge_atTop (1:ℝ)] with L hc hm hL
  intro a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband hmassTwo
    d₀ Y qroot U W hU hq hq' hd₀ hY hYlo hYhi ηg qg Qg hQg hq0 hqQ hη0 hη1 adjoint sign hsign
    N σ z₀ z₁ b₀ b₁ hb₀ hb₁
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  let value : ∀i,groups i→ℕ := fun _ p=>p.val
  let ν' : ∀i,groups i→ℝ := fun i p=>ν i p.val
  let anchor := PhysicalRawMaskedRow.anchor value (fun z:positions=>z.val)
  let geom := literalOrientedGeometry (J:=momentPadding L) positions groups μ d₀ Y L a qroot U W η ψ (L^(G+6)) adjoint sign
  let Q := Finset.univ.sup (fun p : Sigma (fun i=>groups i)=>p.2.val)+1
  have hQpos : 0<Q := Nat.succ_pos _
  letI : NeZero Q := ⟨Nat.ne_of_gt hQpos⟩
  have hvalue : ∀i p,value i p<Q := by
    intro i p
    exact Nat.lt_succ_of_le (Finset.le_sup (f:=fun p : Sigma (fun i=>groups i)=>p.2.val) (Finset.mem_univ ⟨i,p⟩))
  have hplain (j : ℕ) (F : PhysicalMemoryState (Z:=positions) (fun i=>groups i)
      (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L)→ℂ) (hF : IsBagFunction F) :=
    hc a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband
      d₀ Y qroot U W hU hq hq' hd₀ hY hYlo hYhi (adjoint j) (sign j) (hsign j) F hF
  have hmodified (θ : Address (Fin K) (momentPadding L) (memoryCutoff L) N→ZMod Q)
      (j : ℕ) (F : PhysicalMemoryState (Z:=positions) (fun i=>groups i)
      (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L)→ℂ) (hF : IsBagFunction F) :
      finiteL2 Finset.univ (PhysicalMemoryState.mass (fun i=>groups i)
        (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L) ν')
        (phasedApply (physicalEdgeOperation ν' V ρ anchor (geom j))
          (fun s (c:PhysicalEdgeChoice s)=>edgeFactor value (edgePhase σ θ) j c) F)≤
      L^(PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1)*
        finiteL2 Finset.univ (PhysicalMemoryState.mass (fun i=>groups i)
          (fun i p=>Option (ZMod p.val)) (momentPadding L) (memoryCutoff L) ν') F := by
    have hmod := fun (η' ψ' : ℝ→ℂ) (hη' : ∀t,‖η' t‖≤1) (hψ' : ∀t,‖ψ' t‖≤Aψ)
        (hsupport : ∀t,ψ' t≠0→|t|≤C)=>
      hm a ha positions groups instLine hprime ν' μ V (fun i p=>hν i p.val p.property) hνμ hmass hVlo hVhi
        (fun i p=>hband i p.val p.property) qroot U W d₀ Y (L^(G+6)) η' ψ' (sign j) hU hq hq' hd₀ hYlo
        (Real.rpow_nonneg (by linarith) _) le_rfl (hsign j) hη' hψ' hsupport
        (edgePhase σ θ j) ((phase_bounds σ θ).2.2 j) F hF
    let geo := fun (η' ψ' : ℝ→ℂ) (z:positions) b (w:positions) c=>
      sourcePhysicalEdgeGeometry (J:=momentPadding L) value (sourceGood value μ d₀ Y L a qroot)
        (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y η' ψ' (sourceMajorArcs (L^(G+6)) Y) (sign j) z.val b w.val c
    cases hdir : adjoint j
    · have hge : geom j=geo η ψ := by
        funext z b w c
        simp only [geom,literalOrientedGeometry,hdir,orientedSourceEdgeGeometry,Bool.false_eq_true,ite_false,geo,value]
      rw [phased_edge_congr_geometry ν' V ρ anchor (geom j) (geo η ψ) hge
        (fun s (c:PhysicalEdgeChoice s)=>edgeFactor value (edgePhase σ θ) j c) F]
      exact complete_support_norm_bound _ _ (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) _ _ _ _ (hmod η ψ hη hψ hψsupport)
    · have hge : geom j=geo (fun t=>conj (η t)) (fun t=>conj (ψ (-t))) := by
        funext z b w c
        simp only [geom,literalOrientedGeometry,hdir,oriented_geometry_true,geo,value]
      rw [phased_edge_congr_geometry ν' V ρ anchor (geom j)
        (geo (fun t=>conj (η t)) (fun t=>conj (ψ (-t)))) hge
        (fun s (c:PhysicalEdgeChoice s)=>edgeFactor value (edgePhase σ θ) j c) F]
      have hn := reverse_cutoffs_norm_le η ψ 1 Aψ hη hψ
      exact complete_support_norm_bound _ _ (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) _ _ _ _
        (hmod (fun t=>conj (η t)) (fun t=>conj (ψ (-t))) hn.1 hn.2 (reverse_cutoff_support ψ C hψsupport))
  have hbad : 1≤L^(PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1) := by
    apply Real.one_le_rpow hL
    unfold PhysicalPhasedEdgeAsymptotics.degree
    positivity
  have hout := actual_term_position_norm_le (Q:=Q) ν' V ηg qg ρ anchor geom value σ Qg vmax Cmass
    (L^(-G)) (L^(PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1))
    (fun i p=>hν i p.val p.property) hmass hm0 hρ hQg hq0 hqQ hη0 hη1
    (fun i=>(hmin.le.trans (hVlo i))) hVhi (Real.rpow_nonneg (by linarith) _)
    (Real.rpow_le_one_of_one_le_of_nonpos hL (neg_nonpos.mpr hG)) hbad
    (by
      intro j F hF
      exact complete_support_norm_bound _ _ (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) _ _ _ _ (hplain j F hF))
    (by
      intro θ j F hF
      exact complete_support_norm_bound _ _ (by intro x; simp only [Finset.mem_univ])
        (by intro x; simp only [Finset.mem_univ]) _ _ _ _ (hmodified θ j F hF)) hvalue hmassTwo
    z₀ z₁ b₀ b₁ hb₀ hb₁
  have hb0eq : (fun u : CanonicalBoundaryAssembly.BoundaryIndex (Fin K) positions (fun i=>groups i) (momentPadding L)=>
      @ite ℂ (u.1=z₀) (PhysicalLowRankBoundary.lowRankBoundaryDecEq u.1 z₀) (b₀ u.2) 0)=
      (fun u=>if u.1=z₀ then b₀ u.2 else 0) := by
    funext u
    by_cases hu : u.1=z₀ <;> simp only [hu,ite_true,ite_false]
  have hb1eq : (fun u : CanonicalBoundaryAssembly.BoundaryIndex (Fin K) positions (fun i=>groups i) (momentPadding L)=>
      @ite ℂ (u.1=z₁) (PhysicalLowRankBoundary.lowRankBoundaryDecEq u.1 z₁) (b₁ u.2) 0)=
      (fun u=>if u.1=z₁ then b₁ u.2 else 0) := by
    funext u
    by_cases hu : u.1=z₁ <;> simp only [hu,ite_true,ite_false]
  rw [hb0eq,hb1eq] at hout
  simp only [birthCycleRank_decidableEq] at hout ⊢
  simpa only [Fintype.card_fin] using hout

end Elliptic.Operator.PhysicalLowRankOrientedSaving
