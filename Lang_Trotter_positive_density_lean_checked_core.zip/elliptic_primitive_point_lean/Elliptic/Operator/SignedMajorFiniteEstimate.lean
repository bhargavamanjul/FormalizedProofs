module
public import Elliptic.Operator.SignedMajorEndpointPolynomials
public import Elliptic.Operator.MajorArcIntegralCover

/-! Finite major-arc estimate with every character, arc and scale cost explicit. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorMellinIdentity
open scoped BigOperators ComplexConjugate
open MeasureTheory Set SignedMajorCharacter SignedPhysicalPairBridge
open Artin.MarkedReplacement MajorArcScaleCancellation
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

theorem labelPolynomial_continuous {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (χ : DirichletCharacter ℂ k) (η : ℝ→ℂ) (Y lam : ℝ) :
    Continuous (labelPolynomial A value χ η Y lam) := by
  unfold labelPolynomial archimedeanPhase
  fun_prop

theorem normalizedLeft_continuous {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam : ℝ) : Continuous (normalizedLeft A value S T χ η α β Y Hm Hn lam) := by
  exact (((by unfold LogPhaseProgression.phase;fun_prop : Continuous
    (fun t=>LogPhaseProgression.phase (-t) (Y*(Hm*Hn)))).mul
      (labelPolynomial_continuous A value (χ 1) η Y (-lam))).mul
      (longPolynomial_continuous S α Hm (χ 2))).mul (longPolynomial_continuous T β Hn (χ 3))

theorem normalizedRight_continuous {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam : ℝ) : Continuous (normalizedRight A value S T χ η α β Y Hm Hn lam) := by
  exact (((by unfold LogPhaseProgression.phase;fun_prop : Continuous
    (fun t=>LogPhaseProgression.phase (-t) (Y*(Hm*Hn)))).mul
      (labelPolynomial_continuous A value (χ 0) η Y lam)).mul
      (longPolynomial_continuous S (fun n=>conj (α n)) Hm (χ 4))).mul
      (longPolynomial_continuous T (fun n=>conj (β n)) Hn (χ 5))

theorem normalizedLeft_norm {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) :
    ‖normalizedLeft A value S T χ η α β Y Hm Hn lam t‖=
      ‖labelPolynomial A value (χ 1) η Y (-lam) t*
        longPolynomial S α Hm (χ 2) t*longPolynomial T β Hn (χ 3) t‖ := by
  simp only [normalizedLeft,norm_mul,LogPhaseProgression.phase_norm,one_mul]

theorem normalizedRight_norm {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (Y Hm Hn lam t : ℝ) :
    ‖normalizedRight A value S T χ η α β Y Hm Hn lam t‖=
      ‖labelPolynomial A value (χ 0) η Y lam t*
        longPolynomial S (fun n=>conj (α n)) Hm (χ 4) t*
          longPolynomial T (fun n=>conj (β n)) Hn (χ 5) t‖ := by
  simp only [normalizedRight,norm_mul,LogPhaseProgression.phase_norm,one_mul]

/-- The fixed inverse prime masses multiply both normalized endpoints. -/
theorem weighted_characterPair_eq {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (Y Hm Hn lam M : ℝ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,1≤(value a:ℝ)/Y ∧ (value a:ℝ)/Y≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T) :
    (M:ℂ)^2*characterPair A value S T χ Y lam η SignedSmoothDyads.determinantCutoff α β=
      ((Y^2*(Hm*Hn):ℝ):ℂ)*(∫t:ℝ,∫s:ℝ,sourceMellinKernel (Hm*Hn) lam t s*
        ((M:ℂ)*normalizedLeft A value S T χ η α β Y Hm Hn lam t)*
        ((M:ℂ)*normalizedRight A value S T χ η α β Y Hm Hn lam (s-t))) := by
  rw [characterPair_normalized_mellin A value S T χ Y Hm Hn lam η α β hY hHm hHn ha hm hn]
  have hmul (a b c z:ℂ) : a*(z*b)*(z*c)=z^2*(a*b*c) := by ring
  simp_rw [hmul,integral_const_mul]
  ring

theorem weighted_characterPair_norm_le {ι : Type*} {k : ℕ} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (χ : CharacterTuple k 6) (Y Hm Hn lam M E : ℝ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn)
    (ha : ∀a∈A,1≤(value a:ℝ)/Y ∧ (value a:ℝ)/Y≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T)
    (hb : ‖∫t:ℝ,∫s:ℝ,sourceMellinKernel (Hm*Hn) lam t s*
        ((M:ℂ)*normalizedLeft A value S T χ η α β Y Hm Hn lam t)*
        ((M:ℂ)*normalizedRight A value S T χ η α β Y Hm Hn lam (s-t))‖≤E) :
    ‖(M:ℂ)^2*characterPair A value S T χ Y lam η SignedSmoothDyads.determinantCutoff α β‖≤
      Y^2*(Hm*Hn)*E := by
  rw [weighted_characterPair_eq A value S T χ Y Hm Hn lam M η α β hY hHm hHn ha hm hn,
    norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos (by positivity : 0<Y^2*(Hm*Hn))]
  exact mul_le_mul_of_nonneg_left hb (by positivity)

/-- Arithmetic inversion costs at most k⁶ for the actual bounded rational phase. -/
theorem pairIntegrand_norm_le_of_integrals {ι : Type*} (A : Finset ι) (value : ι→ℕ)
    (S T : Finset ℕ) (k : ℕ) [NeZero k] (h : ℤ) (Y Hm Hn lam M E : ℝ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn) (hE : 0≤E)
    (ha : ∀a∈A,1≤(value a:ℝ)/Y ∧ (value a:ℝ)/Y≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T)
    (hau : ∀a∈A,(value a).Coprime k)
    (hmu : ∀m∈S,α m≠0 → m.Coprime k) (hnu : ∀n∈T,β n≠0 → n.Coprime k)
    (hb : ∀χ : CharacterTuple k 6,
      ‖∫t:ℝ,∫s:ℝ,sourceMellinKernel (Hm*Hn) lam t s*
        ((M:ℂ)*normalizedLeft A value S T χ η α β Y Hm Hn lam t)*
        ((M:ℂ)*normalizedRight A value S T χ η α β Y Hm Hn lam (s-t))‖≤E) :
    ‖(M:ℂ)^2*pairIntegrand A value S T Y η SignedSmoothDyads.determinantCutoff α β
      (((h:ℝ)/k+lam/Y:ℝ):ProductCircle)‖≤(k:ℝ)^6*(Y^2*(Hm*Hn)*E) := by
  rw [pairIntegrand_characters A value S T k h Y lam η SignedSmoothDyads.determinantCutoff α β hau hmu hnu,
    Finset.mul_sum]
  have hmul (a b c:ℂ) : a*(b*c)=b*(a*c) := by ring
  apply (norm_sum_le _ _).trans
  calc
    _ ≤ ∑χ : CharacterTuple k 6,‖coefficient k 6 (signedRationalPhase k h (-1)) χ‖*(Y^2*(Hm*Hn)*E) := by
      apply Finset.sum_le_sum
      intro χ _
      rw [hmul,norm_mul]
      exact mul_le_mul_of_nonneg_left
        (weighted_characterPair_norm_le A value S T χ Y Hm Hn lam M E η α β hY hHm hHn ha hm hn (hb χ))
        (norm_nonneg _)
    _ = (∑χ : CharacterTuple k 6,‖coefficient k 6 (signedRationalPhase k h (-1)) χ‖)*(Y^2*(Hm*Hn)*E) :=
      (Finset.sum_mul _ _ _).symm
    _ ≤ _ := by
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      exact (signedRationalPhase_separation k h (-1)).2.trans
        (pow_le_pow_left₀ (Nat.cast_nonneg _) (by exact_mod_cast Nat.totient_le k) 6)


/-- Finite literal major-arc estimate. No cancellation estimate is hidden in
this lemma: the only analytic input is the displayed normalized two-dimensional
integral. The costs are k⁶, H² arcs, length 4H, and the Y⁻¹ arc Jacobian. -/
theorem record_scalarMajor_norm_le_of_integrals {K : ℕ} (b : Artin.MarkedSource.Bands K)
    (x Y Hm Hn H M E : ℝ) (S T : Finset ℕ) (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (hY : 0<Y) (hHm : 0<Hm) (hHn : 0<Hn) (hH : 0≤H) (hE : 0≤E)
    (hsmall : 2*H/Y<1/2) (hη : ∀v,η v≠0 → 1≤v ∧ v≤4)
    (hm : Artin.MarkedSource.InDyad Hm S) (hn : Artin.MarkedSource.InDyad Hn T)
    (hau : ∀k:ℕ,0<k → (k:ℝ)≤H → ∀a:SignedCauchyExpansion.LabelTuple b x,
      (SignedCauchyExpansion.labelProduct b x a).Coprime k)
    (hmu : ∀k:ℕ,0<k → (k:ℝ)≤H → ∀m∈S,α m≠0 → m.Coprime k)
    (hnu : ∀k:ℕ,0<k → (k:ℝ)≤H → ∀n∈T,β n≠0 → n.Coprime k)
    (hb : ∀k:ℕ,0<k → (k:ℝ)≤H → ∀χ : CharacterTuple k 6,∀lam:ℝ,|lam|≤2*H →
      let A := Finset.univ.filter (fun a:SignedCauchyExpansion.LabelTuple b x=>
        η ((SignedCauchyExpansion.labelProduct b x a:ℝ)/Y)≠0)
      ‖∫t:ℝ,∫s:ℝ,sourceMellinKernel (Hm*Hn) lam t s*
        ((M:ℂ)*normalizedLeft A (SignedCauchyExpansion.labelProduct b x) S T χ η α β Y Hm Hn lam t)*
        ((M:ℂ)*normalizedRight A (SignedCauchyExpansion.labelProduct b x) S T χ η α β Y Hm Hn lam (s-t))‖≤E) :
    ‖(M:ℂ)^2*(∑r : SignedCauchyExpansion.Record b x S T,∑u : SignedCauchyExpansion.Record b x S T,
      scalarMajor (SignedCauchyExpansion.labelProduct b x r.2.2)
        (SignedCauchyExpansion.labelProduct b x u.2.2)
        r.1.val r.2.1.val u.1.val u.2.1.val Y H η SignedSmoothDyads.determinantCutoff α β)‖≤
      4*H^9*Y*(Hm*Hn)*E := by
  let A := Finset.univ.filter (fun a:SignedCauchyExpansion.LabelTuple b x=>
    η ((SignedCauchyExpansion.labelProduct b x a:ℝ)/Y)≠0)
  let F : ProductCircle→ℂ := fun θ=>(M:ℂ)^2*pairIntegrand Finset.univ
    (SignedCauchyExpansion.labelProduct b x) S T Y η SignedSmoothDyads.determinantCutoff α β θ
  have hFc : Continuous F := continuous_const.mul (pairIntegrand_continuous _ _ _ _ _ _ _ _ _)
  have hFi : Integrable F productCircleMeasure :=
    hFc.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  have hpoint (k:ℕ) (hk:0<k) (hkH:(k:ℝ)≤H) (h:ℤ) (lam:ℝ) (hlam:|lam|≤2*H) :
      ‖F (((h:ℝ)/k+lam/Y:ℝ):ProductCircle)‖≤(k:ℝ)^6*(Y^2*(Hm*Hn)*E) := by
    letI : NeZero k := ⟨hk.ne'⟩
    dsimp only [F]
    rw [←pairIntegrand_filter Finset.univ (SignedCauchyExpansion.labelProduct b x)
      S T Y η SignedSmoothDyads.determinantCutoff α β]
    apply pairIntegrand_norm_le_of_integrals A (SignedCauchyExpansion.labelProduct b x)
      S T k h Y Hm Hn lam M E η α β hY hHm hHn hE
    · intro a haA
      exact hη _ (Finset.mem_filter.mp haA).2
    · exact hm
    · exact hn
    · intro a haA
      exact hau k hk hkH a
    · exact hmu k hk hkH
    · exact hnu k hk hkH
    · intro χ
      exact hb k hk hkH χ lam hlam
  have hlocal (d : Finset.Icc 1 ⌊H⌋₊) (c : Finset.range ⌊H⌋₊) :
      (∫lam in (-2*H)..(2*H),‖F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)‖)≤
        ((d:ℕ):ℝ)^6*(4*H*(Y^2*(Hm*Hn)*E)) := by
    have hd : 0<(d:ℕ) := (Finset.mem_Icc.mp d.property).1
    have hdH : ((d:ℕ):ℝ)≤H :=
      (show ((d:ℕ):ℝ)≤⌊H⌋₊ by exact_mod_cast (Finset.mem_Icc.mp d.property).2).trans (Nat.floor_le hH)
    have hc : Continuous (fun lam:ℝ=>F ((((c:ℕ):ℝ)/(d:ℕ)+lam/Y:ℝ):ProductCircle)) :=
      hFc.comp (by fun_prop)
    have hh := intervalIntegral.integral_mono_on (show -2*H≤2*H by linarith)
      (hc.norm.intervalIntegrable (μ:=volume) _ _) (continuous_const.intervalIntegrable (μ:=volume) _ _)
      (fun lam hlam=>by
        have hp := hpoint d.val hd hdH (c.val:ℤ) lam (abs_le.mpr ⟨by linarith [hlam.1],hlam.2⟩)
        simpa only [Int.cast_natCast] using hp)
    rw [intervalIntegral.integral_const] at hh
    simp only [smul_eq_mul] at hh
    convert hh using 1 <;> ring
  have hh := MajorArcIntegralCover.major_integral_le_character_budget H Y
    (4*H*(Y^2*(Hm*Hn)*E)) hH hY (by positivity) hsmall F hFi hlocal
  rw [record_scalarMajor_sum_integral,←integral_const_mul]
  apply hh.trans_eq
  field_simp

end Elliptic.Operator.SignedMajorMellinIdentity
