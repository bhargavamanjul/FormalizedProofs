module

public import Elliptic.Operator.SourceMemoryEdges
public import Mathlib.Data.Finset.Prod

/-!
# Finite support of actual integer position paths

The support is derived from bounded edge determinants and the physical
box, rather than assumed as a cardinality estimate. The constants below
are deliberately coarse and independent of the path and its labels.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators

def latticeSlope (r : ℝ) (z : ℤ × ℤ) : ℝ := (z.2:ℝ) / latticeTau r z

theorem latticeSlope_sub (r : ℝ) (z w : ℤ × ℤ)
    (hz : latticeTau r z ≠ 0) (hw : latticeTau r w ≠ 0) :
    latticeSlope r w - latticeSlope r z =
      (latticeDet z w : ℝ) / (latticeTau r z * latticeTau r w) := by
  unfold latticeSlope
  field_simp
  simp only [latticeTau, latticeDet, Int.cast_sub, Int.cast_mul]
  ring

theorem latticeSlope_step_le (r a H : ℝ) (z w : ℤ × ℤ)
    (ha : 0<a) (hH : 0≤H) (hz : a≤latticeTau r z) (hw : a≤latticeTau r w)
    (hd : |(latticeDet z w:ℝ)|≤H) :
    |latticeSlope r w-latticeSlope r z|≤H/a^2 := by
  have hz0 := ha.trans_le hz
  have hw0 := ha.trans_le hw
  rw [latticeSlope_sub r z w hz0.ne' hw0.ne',abs_div,
    abs_of_pos (mul_pos hz0 hw0)]
  apply (div_le_div_of_nonneg_right hd (mul_pos hz0 hw0).le).trans
  apply div_le_div_of_nonneg_left hH (sq_pos_of_pos ha)
  nlinarith [mul_le_mul hz hw ha.le hz0.le]

/-- Telescoping the actual determinant identity bounds every visited slope. -/
theorem path_latticeSlope_le (z : ℕ → ℤ × ℤ) (r a H : ℝ) (N : ℕ)
    (ha : 0<a) (hH : 0≤H) (hstart : z 0=(1,0))
    (htau : ∀ j≤N,a≤latticeTau r (z j))
    (hdet : ∀ j<N, |(latticeDet (z j) (z (j+1)):ℝ)|≤H) :
    ∀ j≤N, |latticeSlope r (z j)|≤(j:ℝ)*(H/a^2) := by
  intro j hj
  induction j with
  | zero => simp [hstart,latticeSlope]
  | succ j ih =>
    have hjN : j≤N := by omega
    have hstep := latticeSlope_step_le r a H (z j) (z (j+1)) ha hH
      (htau j hjN) (htau (j+1) hj) (hdet j (by omega))
    calc
      _ = |(latticeSlope r (z (j+1))-latticeSlope r (z j))+latticeSlope r (z j)| := by ring_nf
      _ ≤ |latticeSlope r (z (j+1))-latticeSlope r (z j)|+|latticeSlope r (z j)| := abs_add_le _ _
      _ ≤ H/a^2+(j:ℝ)*(H/a^2) := add_le_add hstep (ih hjN)
      _ = _ := by push_cast; ring

/-- The actual source box gives the uniform tau interval when the root
is itself in that box. -/
theorem sourcePhysicalPosition_tau_bounds (u v r U W : ℝ) (z : ℤ × ℤ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hz : sourcePhysicalPositionAllowed u v r U W z) :
    1/16≤latticeTau r z ∧ latticeTau r z≤16 := by
  have hu0 : 0<u := hU.trans_le hu
  have hlo : U≤u*latticeTau r z := hz.2.1
  have hhi : u*latticeTau r z≤16*U := hz.2.2.1
  have ht : 0<latticeTau r z := by nlinarith
  constructor
  · nlinarith [mul_le_mul_of_nonneg_right hu' ht.le]
  · nlinarith [mul_le_mul_of_nonneg_right hu ht.le]

/-- Explicit version of the coordinate part of the source's (3.30). -/
theorem physical_path_coordinates (z : ℕ → ℤ × ℤ) (r H : ℝ) (N : ℕ)
    (hH : 0≤H) (hr : |r|≤1) (hstart : z 0=(1,0))
    (htau : ∀ j≤N,1/16≤latticeTau r (z j) ∧ latticeTau r (z j)≤16)
    (hdet : ∀ j<N, |(latticeDet (z j) (z (j+1)):ℝ)|≤H)
    (j : ℕ) (hj : j≤N) :
    |((z j).2:ℝ)|≤4096*(N:ℝ)*H ∧
    |((z j).1:ℝ)|≤16+4096*(N:ℝ)*H := by
  have hs := path_latticeSlope_le z r (1/16) H N (by norm_num) hH hstart
    (fun k hk => (htau k hk).1) hdet j hj
  have ht := htau j hj
  have ht0 : 0<latticeTau r (z j) := by linarith
  have hjR : (j:ℝ)≤N := by exact_mod_cast hj
  have hy : |((z j).2:ℝ)|≤4096*(N:ℝ)*H := by
    unfold latticeSlope at hs
    rw [abs_div,abs_of_pos ht0] at hs
    have hm := (div_le_iff₀ ht0).mp hs
    norm_num at hm
    have hb : (j:ℝ)*(H*256)*latticeTau r (z j)≤(N:ℝ)*(H*256)*16 := by
      gcongr
      exact ht.2
    nlinarith
  refine ⟨hy,?_⟩
  have he : ((z j).1:ℝ)=latticeTau r (z j)-r*((z j).2:ℝ) := by unfold latticeTau; ring
  rw [he]
  calc
    _ ≤ |latticeTau r (z j)|+|r*((z j).2:ℝ)| := by simpa only [Real.norm_eq_abs] using norm_sub_le (latticeTau r (z j)) (r*((z j).2:ℝ))
    _ = latticeTau r (z j)+|r| * |((z j).2:ℝ)| := by rw [abs_of_pos ht0,abs_mul]
    _ ≤ 16+4096*(N:ℝ)*H := by
      have hm := mul_le_mul_of_nonneg_right hr (abs_nonneg ((z j).2:ℝ))
      nlinarith

/-- A concrete finite position type for the subsequent memory operators. -/
def integerPositionBox (R : ℕ) : Finset (ℤ × ℤ) :=
  (Finset.Icc (-(R:ℤ)) R) ×ˢ (Finset.Icc (-(R:ℤ)) R)

theorem integerPositionBox_card (R : ℕ) : (integerPositionBox R).card=(2*R+1)^2 := by
  rw [integerPositionBox,Finset.card_product,Int.card_Icc]
  have he : ((R:ℤ)+1- -(R:ℤ)).toNat=2*R+1 := by omega
  rw [he]
  ring

theorem mem_integerPositionBox_of_abs (R : ℕ) (z : ℤ × ℤ)
    (hx : |(z.1:ℝ)|≤R) (hy : |(z.2:ℝ)|≤R) : z∈integerPositionBox R := by
  rcases abs_le.mp hx with ⟨hx0,hx1⟩
  rcases abs_le.mp hy with ⟨hy0,hy1⟩
  simp only [integerPositionBox,Finset.mem_product,Finset.mem_Icc]
  exact ⟨⟨by exact_mod_cast hx0, by exact_mod_cast hx1⟩,
    ⟨by exact_mod_cast hy0, by exact_mod_cast hy1⟩⟩

theorem physical_path_mem_positionBox (z : ℕ → ℤ × ℤ) (r H : ℝ) (N : ℕ)
    (hH : 0≤H) (hr : |r|≤1) (hstart : z 0=(1,0))
    (htau : ∀ j≤N,1/16≤latticeTau r (z j) ∧ latticeTau r (z j)≤16)
    (hdet : ∀ j<N, |(latticeDet (z j) (z (j+1)):ℝ)|≤H)
    (j : ℕ) (hj : j≤N) :
    z j∈integerPositionBox ⌈16+4096*(N:ℝ)*H⌉₊ := by
  have hc := physical_path_coordinates z r H N hH hr hstart htau hdet j hj
  have hceil := Nat.le_ceil (16+4096*(N:ℝ)*H)
  apply mem_integerPositionBox_of_abs
  · exact hc.2.trans hceil
  · exact hc.1.trans ((by linarith : 4096*(N:ℝ)*H≤16+4096*(N:ℝ)*H).trans hceil)

/-- The pad dyad and cutoff support bound the determinant of every
nonzero source edge, for every shift sign. -/
theorem source_geometry_nonzero_det_bound {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C)
    (hψ : ∀ t, ψ t≠0 → |t|≤C)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (hn : sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b≠0) :
    |(latticeDet z w:ℝ)|≤2*d₀*Y*C := by
  have ha : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
    by_contra h
    simp [sourcePhysicalEdgeGeometry,h] at hn
  rcases ha with ⟨hz,hw,hgz,hgw,hban,hD,hDu,hdiv⟩
  let D := sourcePadProduct value a
  let t := latticeDet z w/(D:ℤ)
  have htest : ψ ((t:ℝ)/Y)≠0 := by
    intro he
    have ha : sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b :=
      ⟨hz,hw,hgz,hgw,hban,hD,hDu,hdiv⟩
    change ψ (((latticeDet z w/(sourcePadProduct value a:ℤ):ℤ):ℝ)/Y)=0 at he
    simp [sourcePhysicalEdgeGeometry,ha,he] at hn
  have ht := hψ _ htest
  rw [abs_div,abs_of_pos hY] at ht
  have ht' := (div_le_iff₀ hY).mp ht
  have hid : t*(D:ℤ)=latticeDet z w := Int.ediv_mul_cancel hdiv
  have hidR : (t:ℝ)*(D:ℝ)=(latticeDet z w:ℝ) := by exact_mod_cast hid
  rw [← hidR,abs_mul]
  rw [abs_of_nonneg (show (0:ℝ)≤(D:ℝ) from Nat.cast_nonneg D)]
  have hDp : (0:ℝ)≤D := Nat.cast_nonneg D
  have hDle : (D:ℝ)≤2*d₀ := hDu.le
  calc
    _ ≤ (C*Y)*(2*d₀) := mul_le_mul ht' hDle hDp (by positivity)
    _ = _ := by ring

theorem oriented_geometry_nonzero_det_bound {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (adjoint : Bool) (value : ∀ i,P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀ t,ψ t≠0 → |t|≤C)
    (z w : ℤ × ℤ) (a b : PhysicalActiveLists P J)
    (hn : orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ major σ z a w b≠0) :
    |(latticeDet z w:ℝ)|≤2*d₀*Y*C := by
  cases adjoint
  · exact source_geometry_nonzero_det_bound value good u v r U W d₀ Y C η ψ major σ
      hd hY hC hψ z w a b hn
  · have hn' : sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ w b z a≠0 := by
      intro h
      simp [orientedSourceEdgeGeometry,h] at hn
    have h := source_geometry_nonzero_det_bound value good u v r U W d₀ Y C η ψ major σ
      hd hY hC hψ w z b a hn'
    have he : latticeDet w z = -latticeDet z w := by unfold latticeDet; ring
    simpa only [he,Int.cast_neg,abs_neg] using h

/-- The derived finite box contains every position of an actual supported
source path, including alternating orientations and either shift sign. -/
theorem source_path_mem_positionBox {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i,P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ Y C : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hd : 0<d₀) (hY : 0<Y) (hC : 0≤C) (hψ : ∀ t,ψ t≠0 → |t|≤C)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U) (hr : |r|≤1)
    (z : ℕ → ℤ × ℤ) (a : ℕ → PhysicalActiveLists P J) (orientation : ℕ → Bool) (N : ℕ)
    (hstart : z 0=(1,0))
    (hpositions : ∀ j≤N,sourcePhysicalPositionAllowed u v r U W (z j))
    (hedges : ∀ j<N,orientedSourceEdgeGeometry (orientation j) value good
      u v r U W d₀ Y η ψ major σ (z j) (a j) (z (j+1)) (a (j+1))≠0)
    (j : ℕ) (hj : j≤N) :
    z j∈integerPositionBox ⌈16+4096*(N:ℝ)*(2*d₀*Y*C)⌉₊ := by
  apply physical_path_mem_positionBox z r (2*d₀*Y*C) N (by positivity) hr hstart
  · intro k hk
    exact sourcePhysicalPosition_tau_bounds u v r U W (z k) hU hu hu' (hpositions k hk)
  · intro k hk
    exact oriented_geometry_nonzero_det_bound (orientation k) value good u v r U W d₀ Y C
      η ψ major σ hd hY hC hψ (z k) (z (k+1)) (a k) (a (k+1)) (hedges k hk)
  · exact hj

end Elliptic.Operator
