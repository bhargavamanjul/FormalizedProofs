module

public import Elliptic.Operator.RootEndpointBudget
public import Elliptic.Operator.RootBoundaryCover

/-! Uniform power saving for the literal combined curved and scalar
boundary cover, with the original growing position radius and all source
good-state endpoints. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootBoundaryBudget
open Filter IntegerRootReplacement RootEndpointBudget RootGoodProductBounds
open RootBoundaryCover RootGridTransfer
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

theorem eventually_position_cost_subpower (C ε : ℝ) (hC : 0≤C) (hε : 0<ε) :
    ∀ᶠ L : ℝ in atTop,
      ((integerPositionBox (rootPositionRadius C L)).card:ℝ)*
        (16864*(rootPositionRadius C L:ℝ)+120) ≤ Real.exp (ε*L) := by
  have hl := (isLittleO_log_rpow_atTop (by norm_num : (0:ℝ)<21/100)).bound
    (by norm_num : (0:ℝ)<1)
  have hc := (tendsto_rpow_atTop (by norm_num : (0:ℝ)<21/100)).eventually
    (eventually_ge_atTop (Real.log 8227))
  let D : ℝ := 4*C+12+Real.log 16984
  have hD : 0≤D := by dsimp [D]; positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),hl,hc,
    RootErrorBudget.eventually_subpower_exponent_le D ε hε] with L hL hl hc hd
  have hL0 : 0<L := by linarith
  have ht : 1≤L^(21/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hlog : Real.log L≤L^(21/100:ℝ) := by
    simpa [Real.norm_eq_abs,abs_of_nonneg (Real.log_nonneg hL),
      abs_of_nonneg (Real.rpow_nonneg hL0.le _)] using hl
  let A := (2*C+6)*L^(21/100:ℝ)
  have hA : 0≤A := by dsimp [A]; positivity
  have hAe : 1≤Real.exp A := Real.one_le_exp hA
  have hr := rootPositionRadius_square_le_exp C L hC hL hlog hc
  have hrc : ((integerPositionBox (rootPositionRadius C L)).card:ℝ)≤Real.exp A := by
    simpa only [integerPositionBox_card,Nat.cast_pow] using hr
  have hR : (rootPositionRadius C L:ℝ)≤Real.exp A := by
    push_cast at hr
    nlinarith [sq_nonneg (rootPositionRadius C L:ℝ)]
  calc
    _ ≤ Real.exp A*(16864*Real.exp A+120) := by gcongr
    _ ≤ 16984*(Real.exp A*Real.exp A) := by nlinarith [Real.exp_pos A]
    _ = Real.exp (Real.log 16984+2*A) := by
      rw [Real.exp_add (Real.log 16984),Real.exp_log (by norm_num : (0:ℝ)<16984),
        show 2*A=A+A by ring,Real.exp_add]
    _ ≤ Real.exp (D*L^(21/100:ℝ)) := Real.exp_le_exp.mpr (by
      dsimp [D,A]
      have hg : 0≤Real.log 16984 := Real.log_nonneg (by norm_num)
      nlinarith)
    _ ≤ Real.exp (D*L^(98/100:ℝ)) := Real.exp_le_exp.mpr
      (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hL (by norm_num)) hD)
    _ ≤ _ := Real.exp_le_exp.mpr hd

theorem eventually_boundary_numerator_subpower (K : ℕ) (C ε : ℝ)
    (hC : 0≤C) (hε : 0<ε) :
    ∀ᶠ x : ℝ in atTop, ∀ Y : ℝ, ∀ a : Fin K→ℝ, 1≤Y →
      ((integerPositionBox (rootPositionRadius C (Real.log x))).card:ℝ)*
        (16864*(rootPositionRadius C (Real.log x):ℝ)+120) +
        30*((allEndpoints (rootPositionRadius C (Real.log x))
          (sourceMultiplierCeiling K (Real.log x)) (radii K Y (Real.log x) a)).card:ℝ)
        ≤ x^ε := by
  have hp := Real.tendsto_log_atTop.eventually
    (eventually_position_cost_subpower C (ε/2) hC (by positivity))
  have he := eventually_allEndpoints_subpower_x K C (ε/2) hC (by positivity)
  have hc := (tendsto_rpow_atTop (show 0<ε/2 by positivity)).eventually
    (eventually_ge_atTop (31:ℝ))
  filter_upwards [eventually_gt_atTop (0:ℝ),hp,he,hc] with x hx hp he hc
  intro Y a hY
  have hp' : ((integerPositionBox (rootPositionRadius C (Real.log x))).card:ℝ)*
        (16864*(rootPositionRadius C (Real.log x):ℝ)+120) ≤ x^(ε/2) := by
    simpa [Real.rpow_def_of_pos hx,mul_comm] using hp
  calc
    _ ≤ x^(ε/2)+30*x^(ε/2) := by gcongr; exact he Y a hY
    _ ≤ x^(ε/2)*x^(ε/2) := by nlinarith [Real.rpow_pos_of_pos hx (ε/2)]
    _ = _ := by rw [←Real.rpow_add hx]; congr 1; ring

/-- A single threshold handles every physical scale, every dyad and all
radii. This proves the boundary error for the actual growing construction. -/
theorem eventually_combinedFaces_small (K : ℕ) (C δ : ℝ)
    (hC : 0≤C) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop, ∀ U V Y : ℝ, ∀ a : Fin K→ℝ,
      1≤U*V → 1≤Y →
      coverVolume (subdivisions δ x)
        (combinedFaces (subdivisions δ x) (integerPositionBox (rootPositionRadius C (Real.log x)))
          U V (allEndpoints (rootPositionRadius C (Real.log x))
            (sourceMultiplierCeiling K (Real.log x)) (radii K Y (Real.log x) a))) ≤
          x^(-(δ/16000)) := by
  have hb := eventually_boundary_numerator_subpower K C (δ/32000) hC (by positivity)
  have hc := (tendsto_rpow_atTop (show 0<δ/32000 by positivity)).eventually
    (eventually_ge_atTop (2:ℝ))
  filter_upwards [eventually_gt_atTop (0:ℝ),eventually_subdivisions δ hδ,hb,hc] with x hx hn hb hc
  intro U V Y a hUV hY
  have hR : ∀ z∈integerPositionBox (rootPositionRadius C (Real.log x)),
      |(z.2:ℝ)|≤(rootPositionRadius C (Real.log x):ℝ) := by
    intro z hz
    have hz' := (Finset.mem_product.mp hz).2
    have hh := Finset.mem_Icc.mp hz'
    rw [abs_le]
    constructor
    · exact_mod_cast hh.1
    · exact_mod_cast hh.2
  have h := combinedFaces_volume (subdivisions δ x) hn.1
    (integerPositionBox (rootPositionRadius C (Real.log x))) U V
    (rootPositionRadius C (Real.log x))
    (allEndpoints (rootPositionRadius C (Real.log x))
      (sourceMultiplierCeiling K (Real.log x)) (radii K Y (Real.log x) a)) hUV hR
  calc
    _ ≤ _ := h
    _ ≤ x^(δ/32000)*(2*x^(-(δ/8000))) := by
      rw [div_eq_mul_inv]
      apply mul_le_mul (hb Y a hY)
      · simpa only [one_div] using hn.2.2
      · positivity
      · positivity
    _ ≤ x^(δ/32000)*(x^(δ/32000)*x^(-(δ/8000))) := by gcongr
    _ = _ := by rw [←Real.rpow_add hx,←Real.rpow_add hx]; congr 1; ring

end Elliptic.Operator.RootBoundaryBudget
