module
public import Elliptic.Operator.PhysicalRootBoundarySaving
public import Elliptic.Operator.PhysicalMomentIdentification
public import Elliptic.Operator.PhysicalRootMomentEstimate

/-! Arbitrary moment saving for the original physical operator, obtained
from the exact root comparison and the proved independent boundary bound. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalMomentSaving
open Filter MeasureTheory
open scoped BigOperators SchwartzMap
open PhysicalRootIndependentMoment PhysicalRootBoundarySaving PhysicalBoundaryMoment
open PhysicalRootMomentNumeric IntegerRootReplacement SourceRootCount
open OriginalLifespanSchedule CanonicalBoundaryAssembly PhysicalVertexDamping
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000

theorem height_of_product_bound_21 (D Cψ L d₀ Y : ℝ) (hCψ : 0≤Cψ)
    (hL : 1≤L) (hd : 0≤d₀) (hY : 0≤Y)
    (hprod : d₀*Y≤Real.exp (D*L^(21/100:ℝ))) :
    2*d₀*Y*Cψ≤Real.exp (sourceRadiusExponent D Cψ*L^(21/100:ℝ)) := by
  have hm : 0<max 1 (2*Cψ) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hlog : 0≤Real.log (max 1 (2*Cψ)) := Real.log_nonneg (le_max_left _ _)
  have hone : 1≤L^(21/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  calc
    _ = (2*Cψ)*(d₀*Y) := by ring
    _ ≤ max 1 (2*Cψ)*Real.exp (D*L^(21/100:ℝ)) :=
      mul_le_mul (le_max_right _ _) hprod (mul_nonneg hd hY) hm.le
    _ = Real.exp (Real.log (max 1 (2*Cψ))+D*L^(21/100:ℝ)) := by
      rw [Real.exp_add,Real.exp_log hm]
    _ ≤ _ := Real.exp_le_exp.mpr (by
      unfold sourceRadiusExponent
      nlinarith [mul_le_mul_of_nonneg_left hone hlog])

 theorem exists_group_count_for_physical_moment (hPD : RootCountContract) (E : ℝ) (hE : 0≤E) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(ψ : 𝓢(ℝ,ℂ)) (smooth : ℝ→ℂ) (D δ Cψ ρ vmin vmax Qg : ℝ),
      0≤D→0<δ→1≤Cψ→0<ρ→ρ<1→0<vmin→Qg<ρ^2→
      (∀t,‖smooth t‖≤1)→(∀t,smooth t≠0→1≤t)→
      (∀t,‖ψ t‖≤1)→(∀t,ψ t≠0→|t|≤Cψ)→
      ∀ᶠx : ℝ in atTop,let L := Real.log x
      ∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀groups : Fin K→Finset ℕ,∀[∀i (p:groups i),Fact p.val.Prime],
      (∀i j,i≠j→Disjoint (groups i) (groups j))→∀VM : Fin K→ℝ,
      (∀i,vmin≤VM i)→(∀i,VM i≤vmax)→(∀i,VM i=∑p∈groups i,1/(p:ℝ))→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      (∀i,∀p∈groups i,(p:ℝ)≤Real.exp (2*L^(1/5:ℝ)))→
      ∀(U V d₀ Y : ℝ),x^δ≤U→U≤x^2→x^δ≤V→V≤x^2→1≤U*V→0<d₀→
      1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→d₀*Y≤Real.exp (D*L^(21/100:ℝ))→
      ∀damping : ℕ→ℝ,(∀j,0≤damping j)→(∀j,damping j≤1)→(∀j,1-damping j≤Qg)→
      ∀(adjoint : ℕ→Bool) (σ : ℤ),(σ=1∨σ= -1)→
      ‖physicalMoment (J:=momentPadding L) (N:=momentLength L) (fun i (p:groups i)=>p.val)
        (fun i (p:groups i)=>1/(VM i*p.val)) VM d₀ Y L U V a smooth ψ
        (sourceMajorArcs (L^(sourceContractionExponent (E+2)+6)) Y) σ adjoint
        (primePool (fun i (p:groups i)=>p.val)) damping‖≤U*V*L^(-E*(momentLength L:ℝ)) := by
  obtain ⟨K₀,hK₀,hboundary⟩ := exists_group_count_for_root_integrand (E+2) (by linarith)
  refine ⟨K₀,hK₀,?_⟩
  intro K hK ψ smooth D δ Cψ ρ vmin vmax Qg hD hδ hCψ hρ hρ1 hmin hQg hsmooth hsupport hψ hsuppψ
  let C := sourceRadiusExponent D Cψ
  have hC : 0≤C := sourceRadiusExponent_nonneg D Cψ hD
  have hK1 : 1≤K := hK₀.trans hK
  filter_upwards [eventually_physical_moment_small_cap hPD K hK1 C δ ρ Qg vmin vmax (E+1)
      hC hδ hρ hρ1 hQg hmin (by linarith),
    Real.tendsto_log_atTop.eventually (hboundary K hK ψ smooth Cψ ρ vmin vmax Qg
      hCψ hρ hρ1 hmin hQg hsmooth hsupport hψ hsuppψ),
    Real.tendsto_log_atTop.eventually eventually_memory_visits_le_prime_cutoff,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (16:ℝ)),eventually_ge_atTop (2:ℝ)]
      with x hcomp hb hsize hL hx
  dsimp only
  let L := Real.log x
  intro a ha groups instPr hdis VM hVlo hVhi hVsum hband hupper U V d₀ Y hU hU' hV hV' hUV hd hY hYlo hYhi hprod
    damping hd0 hd1 hq adjoint σ hσ
  letI : ∀i (p:groups i),Fact p.val.Prime := instPr
  let value : ∀i,groups i→ℕ := fun _ p=>p.val
  let μ := fun i (p:groups i)=>1/(VM i*p.val)
  let H := L^(sourceContractionExponent (E+2)+6)
  have hL1 : 1≤L := by change 1≤Real.log x; linarith
  have hLp : 0<L := by linarith
  have hUp : 0<U := (Real.rpow_pos_of_pos (by linarith : 0<x) δ).trans_le hU
  have hinj : Function.Injective (fun s : Sigma (fun i=>groups i)=>value s.1 s.2) :=
    PhysicalBoundaryActualSaving.disjoint_value_injective groups hdis
  have hband0 : ∀i (p:groups i),Real.exp (L^(1/10:ℝ))≤(p.val:ℝ) := by
    intro i p
    exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL1 (ha i))).trans (hband i p.val p.property)
  have hsize' : ∀i (p:groups i),2*(momentLength L+1)≤p.val := by
    intro i p
    have hh := hsize.trans (hband0 i p)
    exact_mod_cast hh
  have hVsum' : ∀i,VM i=∑p:groups i,1/(p.val:ℝ) := by
    intro i
    rw [hVsum i]
    exact Finset.sum_subtype (groups i) (fun _=>Iff.rfl) _
  have hheight : 2*d₀*Y*Cψ≤Real.exp (C*L^(21/100:ℝ)) :=
    height_of_product_bound_21 D Cψ L d₀ Y (by linarith) hL1 hd.le (by linarith) hprod
  have he := @hcomp (fun i=>groups i) inferInstance value instPr hinj
    (fun i p=>hupper i p.val p.property) hsize' μ VM hVlo hVhi hVsum' damping hd0 hd1 hq
    U V d₀ Y hU hU' hV hV' hUV hd hY a smooth ψ hsmooth hψ
    (fun t ht=>by linarith [hsupport t ht]) Cψ (by linarith) hsuppψ hheight
    (sourceMajorArcs H Y) (sourceMajorArcs_measurable H Y) σ adjoint
  have hi : ∀q∈RootGridMeasure.rootBox,
      ‖independentBoundary (J:=momentPadding L) (N:=momentLength L) (R:=rootPositionRadius C L)
        (B:=memoryCutoff L) value μ VM damping ρ adjoint U V d₀ Y L a smooth ψ
        (sourceMajorArcs H Y) σ q‖≤L^(-(E+2)*(momentLength L:ℝ)) := by
    intro q hqbox
    exact @hb a ha groups instPr hdis VM hVlo hVhi hVsum hband (rootPositionRadius C L)
      (rootPositionRadius_one_le C L) d₀ Y U V hUp hd hY hYlo hYhi damping hd0 hd1 hq adjoint σ hσ q hqbox
  exact norm_le_of_baseline_root_integral_error value damping _ U V L E (momentLength L) _
    (by linarith) hL (momentLength_pos hLp) (fun j _=>⟨hd0 j,hd1 j⟩)
    (fun i p=>by have hh:=hsize' i p; change momentLength L<p.val; omega) he hi

end Elliptic.Operator.PhysicalMomentSaving
