module

public import Elliptic.Operator.PhysicalMaskBudgetBounds
public import Elliptic.Operator.MomentParameters

/-! The complete comparison mask budget decays faster than every fixed
power of L. Its threshold is uniform in the finite prime bands, their
masses, bounded arrays V(L), and every allowed Y and R above exp(L^.1). -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalComparisonBudgetAsymptotics
open Filter PhysicalMaskBudgetBounds
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 theorem comparisonSaving_le (L Y R : ℝ) (hL : 0≤L)
    (hY : Real.exp (L^(1/10:ℝ))≤Y) (hR : Real.exp (L^(1/10:ℝ))≤R) :
    comparisonSaving Y R≤2*Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)) := by
  have ht : 0≤L^(1/10:ℝ) := Real.rpow_nonneg hL _
  have hr : R⁻¹≤Real.exp (-L^(1/10:ℝ)) := by
    rw [Real.exp_neg]
    simpa only [one_div] using one_div_le_one_div_of_le (Real.exp_pos _) hR
  have hy : Y^(-(1/5:ℝ))≤Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)) := by
    apply (Real.rpow_le_rpow_of_nonpos (Real.exp_pos _) hY (by norm_num : -(1/5:ℝ)≤0)).trans_eq
    rw [←Real.exp_mul]
    congr 1
    ring
  have he : Real.exp (-L^(1/10:ℝ))≤Real.exp (-(1/5:ℝ)*L^(1/10:ℝ)) := Real.exp_le_exp.mpr (by linarith)
  unfold comparisonSaving
  linarith

 theorem comparisonSaving_le_two (L Y R : ℝ) (hL : 0≤L)
    (hY : Real.exp (L^(1/10:ℝ))≤Y) (hR : Real.exp (L^(1/10:ℝ))≤R) :
    comparisonSaving Y R≤2 := by
  have hh := comparisonSaving_le L Y R hL hY hR
  have he : Real.exp (-(1/5:ℝ)*L^(1/10:ℝ))≤1 := Real.exp_le_one_iff.mpr (by have hh := Real.rpow_nonneg hL (1/10:ℝ);linarith)
  linarith

 theorem sqrt_comparisonSaving_le (L Y R : ℝ) (hL : 0≤L)
    (hY : Real.exp (L^(1/10:ℝ))≤Y) (hR : Real.exp (L^(1/10:ℝ))≤R) :
    Real.sqrt (comparisonSaving Y R)≤Real.sqrt 2*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ)) := by
  apply (Real.sqrt_le_sqrt (comparisonSaving_le L Y R hL hY hR)).trans_eq
  rw [Real.sqrt_mul (by norm_num : (0:ℝ)≤2),←Real.exp_half]
  congr 2
  ring

 theorem memory_polynomial_le (K : ℕ) (L v0 vmin M : ℝ)
    (hL : 1≤L) (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) :
    ((1+v0)*((memoryCutoff L:ℝ)*vmin⁻¹/v0+M))^K≤
      ((1+v0)*(2*vmin⁻¹/v0+M))^K*L^(2*(K:ℝ)) := by
  have hL0 : 0<L := by linarith
  have h1 : 1≤L^2 := one_le_pow₀ hL
  have hB : (memoryCutoff L:ℝ)≤2*L^2 := by linarith [memoryCutoff_upper L]
  have hb : (1+v0)*((memoryCutoff L:ℝ)*vmin⁻¹/v0+M)≤
      ((1+v0)*(2*vmin⁻¹/v0+M))*L^2 := by
    calc
      _ ≤ (1+v0)*((2*L^2)*vmin⁻¹/v0+M*L^2) := by gcongr;exact le_mul_of_one_le_right hM h1
      _ = _ := by ring
  apply (pow_le_pow_left₀ (by positivity) hb K).trans_eq
  rw [mul_pow,←pow_mul]
  have he : L^(2*K)=L^(2*(K:ℝ)) := by rw [←Real.rpow_natCast L (2*K)];norm_cast
  rw [he]

 theorem eventually_polynomial_exp_small (C E D : ℝ) :
    ∀ᶠL : ℝ in atTop,C*L^E*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ))≤L^(-D) := by
  have hlim : Tendsto (fun L : ℝ=>C*(L^(E+D)*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ)))) atTop (nhds 0) := by
    simpa using (tendsto_power_mul_exp_neg_rpow (E+D)
      (by norm_num : (0:ℝ)<1/10) (by norm_num : (0:ℝ)<1/10)).const_mul C
  filter_upwards [eventually_ge_atTop (1:ℝ),hlim.eventually_lt_const (by norm_num : (0:ℝ)<1)] with L hL hh
  have hL0 : 0<L := by linarith
  apply (mul_le_mul_iff_right₀ (Real.rpow_pos_of_pos hL0 D)).mp
  rw [←Real.rpow_add hL0]
  norm_num
  calc
    _ = C*(L^(E+D)*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ))) := by rw [Real.rpow_add hL0];ring
    _ ≤ 1 := hh.le

 def majorant (K B : ℕ) (v0 vmin vmax M A Y C R : ℝ) : ℝ :=
  ((4:ℝ)^K*A*((1+v0)*((B:ℝ)*vmin⁻¹/v0+M))^K)*
    Real.sqrt ((reverseBound K vmin vmax*comparisonGeo C*(comparisonCoarse C+2*comparisonGeo C))*comparisonSaving Y R)

 theorem eventually_majorant_small (K : ℕ) (v0 vmin vmax M A0 E C G : ℝ)
    (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA0 : 0≤A0) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀A Y R : ℝ,0≤A→A≤A0*L^E→
      Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
      majorant K (memoryCutoff L) v0 vmin vmax M A Y C R≤L^(-G) := by
  let D := reverseBound K vmin vmax*comparisonGeo C*(comparisonCoarse C+2*comparisonGeo C)
  let P0 := ((1+v0)*(2*vmin⁻¹/v0+M))^K
  let T := (4:ℝ)^K*A0*P0*Real.sqrt D*Real.sqrt 2
  have hD : 0≤D := by dsimp [D,reverseBound,comparisonGeo,comparisonCoarse];positivity
  have hP0 : 0≤P0 := by dsimp [P0];positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_polynomial_exp_small T (E+2*K) G] with L hL ht
  intro A Y R hA hAl hY hR
  have hL0 : 0<L := by linarith
  have hp := memory_polynomial_le K L v0 vmin M hL hv0 hmin hM
  have hs := sqrt_comparisonSaving_le L Y R hL0.le hY hR
  calc
    _ = ((4:ℝ)^K*A*((1+v0)*((memoryCutoff L:ℝ)*vmin⁻¹/v0+M))^K)*Real.sqrt D*Real.sqrt (comparisonSaving Y R) := by
      unfold majorant
      rw [Real.sqrt_mul hD]
      ring
    _ ≤ ((4:ℝ)^K*(A0*L^E)*(P0*L^(2*(K:ℝ))))*Real.sqrt D*
        (Real.sqrt 2*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ))) := by
      gcongr
    _ = T*L^(E+2*K)*Real.exp (-(1/10:ℝ)*L^(1/10:ℝ)) := by
      dsimp [T]
      rw [Real.rpow_add hL0]
      ring
    _ ≤ _ := ht

 theorem eventually_actual_comparison_saving (K : ℕ) (v0 vmin vmax M A0 E C G : ℝ)
    (hv0 : 0<v0) (hmin : 0<vmin) (hM : 0≤M) (hA0 : 0≤A0) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀(P : Fin K→Type) (_ : ∀i,Fintype (P i)),
      ∀(ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (A Y R : ℝ),
      (∀i p,0≤ν i p)→(∀i,(∑p,ν i p)≤M)→(∀i,vmin≤V i)→(∀i,V i≤vmax)→
      0≤A→A≤A0*L^E→Real.exp (L^(1/10:ℝ))≤Y→Real.exp (L^(1/10:ℝ))≤R→
      PhysicalDirtyComparisonSchur.allMaskBudget (memoryCutoff L) ν V v0 A Y C R≤L^(-G) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_majorant_small K v0 vmin vmax M A0 E C G hv0 hmin hM hA0 hC]
    with L hL hh
  intro P inst ν V A Y R hν hmass hlo hhi hA hAl hY hR
  letI : ∀i,Fintype (P i) := inst
  have hY0 := (Real.exp_pos _).le.trans hY
  have hR0 := (Real.exp_pos _).le.trans hR
  exact (comparison_allMaskBudget_le ν V v0 vmin vmax M A Y C R hν hv0 hmin hM hA hlo hhi hmass
    hY0 hC hR0 (comparisonSaving_le_two L Y R (by linarith) hY hR)).trans (hh A Y R hA hAl hY hR)

end Elliptic.Operator.PhysicalComparisonBudgetAsymptotics
