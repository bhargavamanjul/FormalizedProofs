module

public import Elliptic.Operator.PhysicalPivotHistory
public import Mathlib.Order.Prod.Lex.Basic

/-! A fixed chronological order on actual padded birth addresses. It orders
visits first, then batch slots, and uses the finite group index only to
break ties. It is chosen without seeing any sampled prime values. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthChronologicalOrder
open ActualHistoryBirths
attribute [local instance] Classical.propDecidable
local instance {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type} [Fintype I] {J B N : ℕ}

def key : Address I J B N → ℕ ×ₗ (ℕ ×ₗ Fin (Fintype.card I))
  | .inl a => toLex (0,toLex (a.2.val,Fintype.equivFin I a.1))
  | .inr (.inl a) => toLex (2*a.1.val+1,toLex (a.2.2.val,Fintype.equivFin I a.2.1))
  | .inr (.inr a) => toLex (2*a.1.val+2,toLex (0,Fintype.equivFin I a.2))

theorem key_injective : Function.Injective (key (I:=I) (J:=J) (B:=B) (N:=N)) := by
  rintro (⟨i,k⟩|(⟨j,i,k⟩|⟨j,i⟩)) (⟨i',k'⟩|(⟨j',i',k'⟩|⟨j',i'⟩)) h
  all_goals simp only [key,toLex_inj,Prod.mk.injEq] at h
  · have hi := (Fintype.equivFin I).injective h.2.2
    have hk := Fin.ext h.2.1
    subst i'; subst k'; rfl
  · omega
  · omega
  · omega
  · have hi := (Fintype.equivFin I).injective h.2.2
    have hk := Fin.ext h.2.1
    have hj : j=j' := Fin.ext (by omega)
    subst i'; subst k'; subst j'; rfl
  · omega
  · omega
  · omega
  · have hi := (Fintype.equivFin I).injective h.2.2
    have hj : j=j' := Fin.ext (by omega)
    subst i'; subst j'; rfl

def order : LinearOrder (Address I J B N) := LinearOrder.lift' key key_injective

local instance : LinearOrder (Address I J B N) := order

theorem lt_ghost_same_group (a : Address I J B N) (j : Fin (N+1)) (i:I) (k:Fin B)
    (ha : a < .inr (.inl (j,i,k))) (hg : addressGroup a=i) :
    PhysicalBirthRegistry.GhostPrecedes j.val i k.val (PhysicalBirthRegistry.embed a) := by
  change key a < key (.inr (.inl (j,i,k))) at ha
  rcases a with ⟨i',k'⟩|(⟨j',i',k'⟩|⟨j',i'⟩)
  · exact Or.inl trivial
  · change i'=i at hg
    subst i'
    simp only [key,Prod.Lex.toLex_lt_toLex,lt_self_iff_false,and_false,or_false] at ha
    rcases ha with ht|⟨ht,hk⟩
    · exact Or.inl (by change j'.val<j.val; omega)
    · have hj : j'=j := Fin.ext (by omega)
      subst j'
      exact Or.inr ⟨k',hk,rfl⟩
  · simp only [key,Prod.Lex.toLex_lt_toLex] at ha
    exact Or.inl (by change j'.val<j.val; omega)

theorem lt_edge_same_group (a : Address I J B N) (j : Fin N) (i:I)
    (ha : a < .inr (.inr (j,i))) (hg : addressGroup a=i) :
    PhysicalBirthRegistry.BeforeEdge j.val (PhysicalBirthRegistry.embed a) := by
  change key a < key (.inr (.inr (j,i))) at ha
  rcases a with ⟨i',k'⟩|(⟨j',i',k'⟩|⟨j',i'⟩)
  · trivial
  · simp only [key,Prod.Lex.toLex_lt_toLex] at ha
    change j'.val≤j.val
    omega
  · change i'=i at hg
    subst i'
    simp only [key,Prod.Lex.toLex_lt_toLex,lt_self_iff_false,and_false,or_false] at ha
    change j'.val<j.val
    omega

theorem lt_initial_same_group (a : Address I J B N) (i:I) (k:Fin (J+1))
    (ha : a < .inl (i,k)) (hg : addressGroup a=i) :
    ∃l : Fin (J+1),l.val<k.val ∧ a=.inl (i,l) := by
  change key a < key (.inl (i,k)) at ha
  rcases a with ⟨i',k'⟩|(⟨j',i',k'⟩|⟨j',i'⟩)
  · change i'=i at hg
    subst i'
    simp only [key,Prod.Lex.toLex_lt_toLex,lt_self_iff_false,and_false,or_false,
      true_and] at ha
    exact ⟨k',by simpa using ha,rfl⟩
  · simp only [key,Prod.Lex.toLex_lt_toLex] at ha
    omega
  · simp only [key,Prod.Lex.toLex_lt_toLex] at ha
    omega

end Elliptic.Operator.BirthChronologicalOrder
