module

public import Elliptic.Operator.DistinctBirthBatches
public import Elliptic.Operator.LifespanSchedule

/-!
# Simultaneous fresh-batch ordering fibers

Local factorial cancellation is insufficient if the continuation depends on
all visits. Here every fresh-batch ordering is retained simultaneously, and
an arbitrary function of the entire family of output bags is allowed.
This is not yet a bijection with dependent physical choice histories.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- The actual simultaneous fiber of all distinct fresh-batch tuples. -/
abbrev GlobalBirthFiber {J P : Type*} (T : J → Finset P) :=
  ∀ j, DistinctBirthTuple (T j)

/-- All ordering choices are present; the cardinality is the product of
actual factorials, even if the continuation couples the visits. -/
theorem globalBirthFiber_card {J P : Type*} [Fintype J] [Fintype P]
    (T : J → Finset P) :
    Fintype.card (GlobalBirthFiber T) = ∏ j, (T j).card.factorial := by
  classical
  simp only [GlobalBirthFiber, Fintype.card_pi, distinctBirthTuple_card]

/-- Cancellation of every factorial for an arbitrary global symmetric
continuation. Symmetry is expressed by passing bags, not ordered tuples. -/
theorem global_distinct_birth_sum {J P X R : Type*}
    [Fintype J] [Fintype P] [Field R] [CharZero R]
    (T : J → Finset P) (ν : J → P → R) (f : J → P → X)
    (survivors : J → Multiset X) (F : (J → Multiset X) → R) :
    (∑ x : GlobalBirthFiber T,
      (∏ j, tupleWeight (ν j) (x j).val / ((T j).card.factorial : R)) *
      F (fun j => survivors j + tupleBag (fun i => f j ((x j).val i)))) =
    (∏ j, ∏ p ∈ T j, ν j p) *
      F (fun j => survivors j + (T j).val.map (f j)) := by
  classical
  simp_rw [distinctBirthTuple_weight, distinctBirthTuple_bag]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
    globalBirthFiber_card, Nat.cast_prod, Finset.prod_div_distrib]
  have hfac : (∏ j, ((T j).card.factorial : R)) ≠ 0 := by
    exact Finset.prod_ne_zero_iff.mpr (fun j _ => Nat.cast_ne_zero.mpr (T j).card.factorial_ne_zero)
  field_simp

/-- Disjoint birth sets imply globally distinct numerical labels in every
actual ordering fiber, not merely distinct memory slots. -/
theorem globalBirthFiber_labels_injective {J P : Type*}
    (T : J → Finset P) (hdis : Pairwise (fun j k => Disjoint (T j) (T k)))
    (x : GlobalBirthFiber T) :
    Function.Injective (fun ji : (j : J) × Fin (T j).card => (x ji.1).val ji.2) := by
  classical
  intro ji ki h
  rcases ji with ⟨j,i⟩
  rcases ki with ⟨k,l⟩
  have hj : (x j).val i ∈ T j := ((x j).property.2 _).mpr ⟨i,rfl⟩
  have hk : (x k).val l ∈ T k := ((x k).property.2 _).mpr ⟨l,rfl⟩
  have he : j = k := by
    by_contra hne
    exact (Finset.disjoint_left.mp (hdis hne)) hj (by simpa only [h] using hk)
  subst k
  have hi : i = l := (x j).property.1 h
  subst l
  rfl

/-- The numerical labels of the literal lifespan birth partition satisfy
that global distinctness condition across all visits. -/
theorem lifespan_birth_fiber_labels_injective {P : Type*} {N : ℕ}
    (S : Finset P) (L : P → PrimeLifespan N)
    (x : GlobalBirthFiber (fun j : Fin (N+1) =>
      LifespanSchedule.births S L j.val ∪ LifespanSchedule.activeBirths S L j.val)) :
    Function.Injective (fun ji : (j : Fin (N+1)) ×
      Fin (LifespanSchedule.births S L j.val ∪
        LifespanSchedule.activeBirths S L j.val).card => (x ji.1).val ji.2) := by
  apply globalBirthFiber_labels_injective
  intro j k hjk
  exact LifespanSchedule.birth_visits_disjoint S L
    (fun h => hjk (Fin.ext h))

/-- Each prime contributes its birth mass exactly once across the whole
schedule, regardless of the number of its active runs. -/
theorem lifespan_birth_product {P R : Type*} {N : ℕ} [CommMonoid R]
    (S : Finset P) (L : P → PrimeLifespan N) (ν : P → R) :
    (∏ j ∈ Finset.range (N+1),
      ∏ p ∈ LifespanSchedule.births S L j ∪ LifespanSchedule.activeBirths S L j, ν p) =
      ∏ p ∈ S, ν p := by
  classical
  simp_rw [LifespanSchedule.birth_partition]
  apply Finset.prod_fiberwise_of_maps_to
  intro p hp
  exact Finset.mem_range.mpr (Nat.lt_succ_of_le
    ((L p).birth_le_death.trans (L p).death_le))

/-- Splitting the birth mass into ghost and active births leaves the same
single factor for each numerical prime. This is only the birth measure;
it does not assert cancellation of active-run normalization factors. -/
theorem lifespan_split_birth_product {P R : Type*} {N : ℕ} [CommMonoid R]
    (S : Finset P) (L : P → PrimeLifespan N) (ν : P → R) :
    (∏ j ∈ Finset.range (N+1),
      (∏ p ∈ LifespanSchedule.births S L j, ν p) *
        (∏ p ∈ LifespanSchedule.activeBirths S L j, ν p)) = ∏ p ∈ S, ν p := by
  classical
  have h := lifespan_birth_product S L ν
  rw [← h]
  apply Finset.prod_congr rfl
  intro j hj
  exact (Finset.prod_union (LifespanSchedule.births_disjoint_activeBirths S L j)).symm

end Elliptic.Operator
