module

public import Elliptic.Operator.BonferroniBudget
public import Mathlib.Data.Nat.Choose.Bounds

/-!
# Counting the actual truncated prime subsets

The family consists of subsets of a finite numerical prime pool, not
ordered lists with possible repeated numerical primes. The cardinality
bound supplies one discrete enumeration budget for root replacement.
It asserts neither a bound on expansion coefficients nor a root-count
comparison or an archimedean grid estimate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BonferroniMonomialCount
open scoped BigOperators
open Filter IntegerRootReplacement

/-- The monomial prime sets retained through degree `T`. -/
def truncatedSubsets (P : Finset ℕ) (T : ℕ) : Finset (Finset ℕ) :=
  P.powerset.filter (fun s => s.card ≤ T)

@[simp] theorem mem_truncatedSubsets (P : Finset ℕ) (T : ℕ) (s : Finset ℕ) :
    s ∈ truncatedSubsets P T ↔ s ⊆ P ∧ s.card ≤ T := by
  simp [truncatedSubsets]

set_option backward.isDefEq.respectTransparency false in
theorem truncatedSubsets_eq_disjiUnion (P : Finset ℕ) (T : ℕ) :
    truncatedSubsets P T =
      (Finset.range (T+1)).disjiUnion (fun k => P.powersetCard k)
        (P.pairwise_disjoint_powersetCard.set_pairwise _) := by
  ext s
  rw [mem_truncatedSubsets, Finset.mem_disjiUnion]
  constructor
  · rintro ⟨hs, hcard⟩
    exact ⟨s.card, Finset.mem_range.mpr (by omega),
      Finset.mem_powersetCard.mpr ⟨hs, rfl⟩⟩
  · rintro ⟨k, hk, hs⟩
    obtain ⟨hsP, hsk⟩ := Finset.mem_powersetCard.mp hs
    exact ⟨hsP, by have := Finset.mem_range.mp hk; omega⟩

set_option backward.isDefEq.respectTransparency false in
/-- Exact finite count; high degrees automatically contribute zero. -/
theorem truncatedSubsets_card (P : Finset ℕ) (T : ℕ) :
    (truncatedSubsets P T).card =
      ∑ k ∈ Finset.range (T+1), P.card.choose k := by
  rw [truncatedSubsets_eq_disjiUnion, Finset.card_disjiUnion]
  simp only [Finset.card_powersetCard]

theorem truncatedSubsets_card_le (P : Finset ℕ) (T : ℕ) :
    (truncatedSubsets P T).card ≤ (T+1)*(P.card+1)^T := by
  rw [truncatedSubsets_card]
  calc
    _ ≤ ∑ _k ∈ Finset.range (T+1), (P.card+1)^T := by
      apply Finset.sum_le_sum
      intro k hk
      calc
        _ ≤ P.card^k := Nat.choose_le_pow _ _
        _ ≤ (P.card+1)^k := pow_le_pow_left' (by omega) k
        _ ≤ _ := pow_le_pow_right' (by omega) (by
          have := Finset.mem_range.mp hk
          omega)
    _ = _ := by simp

/-- An arbitrary finite numerical pool in the source band has the
cardinality of a subset of the literal finite label ceiling. -/
theorem primePool_card_le (L : ℝ) (P : Finset ℕ)
    (hP : ∀ p ∈ P, (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) :
    P.card ≤ rootPrimeCeiling L := by
  calc
    _ ≤ (Finset.range (rootPrimeCeiling L)).card := Finset.card_le_card (by
      intro p hp
      exact Finset.mem_range.mpr (label_lt_rootPrimeCeiling L p (hP p hp)))
    _ = _ := Finset.card_range _

/-- The cardinality budget is uniform in the numerical prime pool and
in every truncation degree below the source ceiling. Primality is not
needed for this upper bound. -/
theorem truncatedSubsets_card_le_exp (L : ℝ) (hL : 1 ≤ L)
    (hlog : Real.log 2 ≤ L^(1/5:ℝ)) (P : Finset ℕ) (T : ℕ)
    (hP : ∀ p ∈ P, (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ)))
    (hT : T ≤ ⌈L^(76/100:ℝ)⌉₊) :
    ((truncatedSubsets P T).card : ℝ) ≤ Real.exp (10*L^(96/100:ℝ)) := by
  have hLpos : 0 < L := by linarith
  have hroot := rootPrimeCeiling_le_exp L hlog
  have hcard0 : (P.card:ℝ) ≤ (rootPrimeCeiling L:ℝ) := by
    exact_mod_cast primePool_card_le L P hP
  have hcard : (P.card:ℝ) ≤ Real.exp (3*L^(1/5:ℝ)) := hcard0.trans hroot
  have hexp : 1 ≤ Real.exp (3*L^(1/5:ℝ)) := Real.one_le_exp (by positivity)
  have htwo : (2:ℝ) ≤ Real.exp (L^(1/5:ℝ)) := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ)<2)] using Real.exp_le_exp.mpr hlog
  have hbase : (P.card:ℝ)+1 ≤ Real.exp (4*L^(1/5:ℝ)) := by
    calc
      _ ≤ 2*Real.exp (3*L^(1/5:ℝ)) := by linarith
      _ ≤ Real.exp (L^(1/5:ℝ))*Real.exp (3*L^(1/5:ℝ)) :=
        mul_le_mul_of_nonneg_right htwo (Real.exp_pos _).le
      _ = _ := by rw [← Real.exp_add]; congr 1; ring
  have hpow : 1 ≤ L^(76/100:ℝ) := Real.one_le_rpow hL (by norm_num)
  have hceil := (Nat.ceil_lt_add_one (show 0 ≤ L^(76/100:ℝ) by positivity)).le
  have hTreal : (T:ℝ) ≤ 2*L^(76/100:ℝ) := by
    have hTc : (T:ℝ) ≤ (⌈L^(76/100:ℝ)⌉₊:ℝ) := by exact_mod_cast hT
    linarith
  have hprod : L^(76/100:ℝ)*L^(1/5:ℝ) = L^(96/100:ℝ) := by
    rw [← Real.rpow_add hLpos]
    norm_num
  have h76 : L^(76/100:ℝ) ≤ L^(96/100:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hL (by norm_num)
  have hcost : (T:ℝ) + (T:ℝ)*(4*L^(1/5:ℝ)) ≤ 10*L^(96/100:ℝ) := by
    have ht := mul_le_mul_of_nonneg_right hTreal (show 0 ≤ 4*L^(1/5:ℝ) by positivity)
    nlinarith [hprod]
  have hfinite : ((truncatedSubsets P T).card:ℝ) ≤ ((T:ℝ)+1)*((P.card:ℝ)+1)^T := by
    exact_mod_cast truncatedSubsets_card_le P T
  calc
    _ ≤ ((T:ℝ)+1)*((P.card:ℝ)+1)^T := hfinite
    _ ≤ Real.exp (T:ℝ)*(Real.exp (4*L^(1/5:ℝ)))^T := by
      apply mul_le_mul
      · exact Real.add_one_le_exp _
      · exact pow_le_pow_left₀ (by positivity) hbase T
      · positivity
      · positivity
    _ = Real.exp ((T:ℝ)+(T:ℝ)*(4*L^(1/5:ℝ))) := by
      rw [← Real.exp_nat_mul, ← Real.exp_add]
    _ ≤ _ := Real.exp_le_exp.mpr hcost

/-- One eventual threshold precedes every finite prime pool and degree. -/
theorem eventually_truncatedSubsets_card_le_exp :
    ∀ᶠ L : ℝ in atTop, ∀ P : Finset ℕ, ∀ T : ℕ,
      (∀ p ∈ P, (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) →
      T ≤ ⌈L^(76/100:ℝ)⌉₊ →
      ((truncatedSubsets P T).card:ℝ) ≤ Real.exp (10*L^(96/100:ℝ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/5)).eventually
      (eventually_ge_atTop (Real.log 2))] with L hL hlog
  exact fun P T hP hT => truncatedSubsets_card_le_exp L hL hlog P T hP hT

/-- The actual odd depth used by the inactive-prime sandwich satisfies
the same uniform enumeration bound. -/
theorem eventually_actualDepth_card_le_exp :
    ∀ᶠ L : ℝ in atTop, ∀ P : Finset ℕ,
      (∀ p ∈ P, (p:ℝ) ≤ Real.exp (2*L^(1/5:ℝ))) →
      ((truncatedSubsets P (2*BonferroniBudget.truncationIndex L+1)).card:ℝ) ≤
        Real.exp (10*L^(96/100:ℝ)) := by
  filter_upwards [eventually_truncatedSubsets_card_le_exp,
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<76/100)).eventually
      (eventually_ge_atTop (2:ℝ))] with L hcount hdepth
  intro P hP
  exact hcount P _ hP (BonferroniBudget.depth_bounds L hdepth).2

end Elliptic.Operator.BonferroniMonomialCount
