module

public import Elliptic.Operator.SparseFrequencyEnergy
public import Artin.MarkedSource

/-!
# Exact Mellin isolation of one prime label

The cutoff η(y)e(-lamy) is an actual smooth compact weight. The existing
classical Fourier-inversion contract is applied to that weight, and all
finite sums and normalization factors are then separated exactly. The
Mellin kernel is the literal `Artin.MarkedSource.scaledKernel`, not a free
function satisfying a desired arithmetic bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinPrimeSeparation
open scoped BigOperators
open MeasureTheory
open Artin.MarkedReplacement Artin.MarkedSource
open Elliptic.SourceContracts
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- The source major-arc endpoint cutoff, including its additive lam phase. -/
def twistedCutoff (η : ℝ→ℂ) (lam : ℝ) (y : ℝ) : ℂ :=
  η y*additivePhase (-lam*y)

theorem twistedCutoff_smooth (η : ℝ→ℂ) (hη : SmoothCompactWeight η) (lam : ℝ) :
    SmoothCompactWeight (twistedCutoff η lam) := by
  refine ⟨?_,?_,?_⟩
  · unfold twistedCutoff additivePhase
    apply hη.1.mul
    apply ContDiff.cexp
    have hr : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun x:ℝ=>2*Real.pi*(-lam*x)) := by fun_prop
    have hc : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun x:ℝ=>((2*Real.pi*(-lam*x):ℝ):ℂ)) :=
      Complex.ofRealCLM.contDiff.comp hr
    exact hc.mul contDiff_const
  · exact hη.2.1.mul_right
  · exact (Function.support_mul_subset_left η (fun y=>additivePhase (-lam*y))).trans hη.2.2

/-- Frequency shifts multiply the actual logarithmic phases. -/
theorem archimedeanPhase_add (t ξ : ℝ) (n : ℕ) :
    archimedeanPhase (t+ξ) n=archimedeanPhase t n*archimedeanPhase ξ n := by
  unfold archimedeanPhase
  rw [←Complex.exp_add]
  congr 1
  push_cast
  ring

/-- The literal unnormalized finite endpoint sum with one label isolated. -/
def endpoint (S R : Finset ℕ) (c d : ℕ→ℂ) (η : ℝ→ℂ)
    (lam Y t : ℝ) : ℂ :=
  ∑p∈S,∑r∈R,c p*d r*twistedCutoff η lam ((p*r:ℕ)/Y)*archimedeanPhase t (p*r)

def primePolynomial (S : Finset ℕ) (c : ℕ→ℂ) (P t : ℝ) : ℂ :=
  (P:ℂ)⁻¹*∑p∈S,c p*archimedeanPhase t p

def remainingPolynomial (R : Finset ℕ) (d : ℕ→ℂ) (P Y t : ℝ) : ℂ :=
  ((P/Y:ℝ):ℂ)*∑r∈R,d r*archimedeanPhase t r

/-- The exact finite Mellin separation before normalizing the two factors. -/
theorem endpoint_separation (hFourier : ClassicalFourierInversion)
    (S R : Finset ℕ) (hS : ∀p∈S,0<p) (hR : ∀r∈R,0<r)
    (c d : ℕ→ℂ) (η : ℝ→ℂ) (hη : SmoothCompactWeight η)
    (lam Y t : ℝ) (hY : 0<Y) :
    endpoint S R c d η lam Y t=
      ∫ξ:ℝ,scaledKernel (twistedCutoff η lam) Y ξ*
        (∑p∈S,c p*archimedeanPhase (t+ξ) p)*
        (∑r∈R,d r*archimedeanPhase (t+ξ) r) := by
  obtain ⟨B,hB,hmain,hint,htail⟩ := hFourier (twistedCutoff η lam) (twistedCutoff_smooth η hη lam)
  have hh := smooth_separation S R
    (fun p=>c p*archimedeanPhase t p) (fun r=>d r*archimedeanPhase t r)
    (fun _=>1) (fun n=>twistedCutoff η lam ((n:ℝ)/Y))
    (scaledKernel (twistedCutoff η lam) Y) archimedeanPhase
    (fun p hp r hr=>(hmain Y hY).2.2 p r (hS p hp) (hR r hr))
    (fun p hp r hr=>hint Y hY p r (hS p hp) (hR r hr))
  calc
    _ = ∑p∈S,∑r∈R,(c p*archimedeanPhase t p)*(d r*archimedeanPhase t r)*
        1*twistedCutoff η lam ((p*r:ℕ)/Y) := by
      unfold endpoint
      apply Finset.sum_congr rfl
      intro p hp
      apply Finset.sum_congr rfl
      intro r hr
      rw [archimedeanPhase_mul t (hS p hp).ne' (hR r hr).ne']
      ring
    _ = _ := by
      rw [hh]
      apply integral_congr_ae
      filter_upwards [] with ξ
      simp only [bilinear,archimedeanPhase_add,Finset.mul_sum,Finset.sum_mul]
      conv_rhs => rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro p hp
      apply Finset.sum_congr rfl
      intro r hr
      ring

/-- Exact source normalization: the prime factor is divided by P and the
remaining-label factor is multiplied by P/Y. No scale factor is omitted. -/
theorem normalized_endpoint_separation (hFourier : ClassicalFourierInversion)
    (S R : Finset ℕ) (hS : ∀p∈S,0<p) (hR : ∀r∈R,0<r)
    (c d : ℕ→ℂ) (η : ℝ→ℂ) (hη : SmoothCompactWeight η)
    (lam P Y t : ℝ) (hP : 0<P) (hY : 0<Y) :
    (Y:ℂ)⁻¹*endpoint S R c d η lam Y t=
      ∫ξ:ℝ,scaledKernel (twistedCutoff η lam) Y ξ*
        primePolynomial S c P (t+ξ)*remainingPolynomial R d P Y (t+ξ) := by
  rw [endpoint_separation hFourier S R hS hR c d η hη lam Y t hY,←integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with ξ
  unfold primePolynomial remainingPolynomial
  have hPC : (P:ℂ)≠0 := by exact_mod_cast hP.ne'
  push_cast
  field_simp

/-- The remaining factor is controlled by its actual coefficient mass. -/
theorem remainingPolynomial_norm_le (R : Finset ℕ) (d : ℕ→ℂ) (P Y t : ℝ)
    (hP : 0≤P) (hY : 0<Y) :
    ‖remainingPolynomial R d P Y t‖≤(P/Y)*(∑r∈R,‖d r‖) := by
  rw [remainingPolynomial,norm_mul,Complex.norm_real,Real.norm_eq_abs,
    abs_of_nonneg (div_nonneg hP hY.le)]
  apply mul_le_mul_of_nonneg_left _ (div_nonneg hP hY.le)
  calc
    _ ≤ ∑r∈R,‖d r*archimedeanPhase t r‖ := norm_sum_le _ _
    _ = _ := by simp only [norm_mul,archimedeanPhase_norm,mul_one]

/-- The transformed cutoff has a genuine finite L1 norm for each lam,
from the unchanged classical Fourier-inversion input. -/
theorem twistedCutoff_fourier_L1 (hFourier : ClassicalFourierInversion)
    (η : ℝ→ℂ) (hη : SmoothCompactWeight η) (lam : ℝ) :
    ∃B:ℝ,0<B∧∀Y:ℝ,0<Y→Integrable (scaledKernel (twistedCutoff η lam) Y)∧
      (∫ξ:ℝ,‖scaledKernel (twistedCutoff η lam) Y ξ‖)≤B := by
  obtain ⟨B,hB,hmain,hint,htail⟩ := hFourier (twistedCutoff η lam) (twistedCutoff_smooth η hη lam)
  exact ⟨B,hB,fun Y hY=>⟨(hmain Y hY).1,(hmain Y hY).2.1⟩⟩

/-- The determinant's source scale factors combine to XY exactly. -/
theorem determinant_normalization (X Y : ℝ) (hX : X≠0) (hY : Y≠0) :
    (Y*X)^2*X⁻¹*Y⁻¹=X*Y := by field_simp

end Elliptic.Operator.MellinPrimeSeparation
