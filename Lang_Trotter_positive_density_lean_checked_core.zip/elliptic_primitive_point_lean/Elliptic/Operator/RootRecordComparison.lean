module

public import Elliptic.Operator.RootLiteralSum
public import Elliptic.Operator.RootConstantAccumulation

/-!
# The signed, normalized full-record Bonferroni comparison

Both remainders are actual expressions: the canonical integer-root gap
and the independent finite-line gap integrated over the real root box.
The two polynomial comparison inputs are finite discrepancies, supplied
separately by the explicit root-count replacement modules.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordComparison
open scoped BigOperators
open MeasureTheory RootLiteralSum RootRecordBonferroni RootRecordGap
open RootIntegratedBonferroni OriginalPathWeights RootGridMeasure
open SourceBonferroni BonferroniMonomialCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

def rootComplete (rec : Record K J N R Q) (primes : Finset ℕ) (η : ℕ→ℝ)
    (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) : ℂ :=
  literalRootSum U V (fun q g=>G q*(residueFactor rec primes η (ℓ g):ℂ))

def rootPolynomial (rec : Record K J N R Q) (primes : Finset ℕ) (η : ℕ→ℝ)
    (T : ℕ) (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) : ℂ :=
  ∑s∈truncatedSubsets primes T,literalRootSum U V (fun q g=>G q*subsetTest rec η s (fun p=>ℓ g p))

def rootGap (rec : Record K J N R Q) (primes : Finset ℕ) (η : ℕ→ℝ)
    (T : ℕ) (U V : ℝ)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p)) : ℝ :=
  literalGap U V (fun g=>elementary primes (fun p=>loss rec η p (ℓ g p)) T)

def integralComplete (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact p.val.Prime] (η : ℕ→ℝ)
    (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ) : ℂ :=
  ((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫q in rootBox,G q)*fullAverage rec primes η

def integralPolynomial (rec : Record K J N R Q) (primes : Finset ℕ)
    [∀p : primes,Fact p.val.Prime] (η : ℕ→ℝ)
    (T : ℕ) (U V : ℝ) (G : RootGridMeasure.RootPoint→ℂ) : ℂ :=
  ((U*V/(Real.pi^2/6):ℝ):ℂ)*(∫q in rootBox,G q)*truncatedAverage rec primes η T

/-- Actual finite-record signed comparison. The geometric phases are
retained in the signed polynomial and only bounded in the two tails. -/
theorem comparison (records : Finset (Record K J N R Q)) (primes : Finset ℕ)
    [∀p : primes,Fact p.val.Prime] (hA : ∀rec∈records,activePrimes rec⊆primes)
    (η : ℕ→ℝ) (hη : ∀j<N+1,0≤η j ∧ η j≤1) (m : ℕ)
    (U V n : ℝ) (hUV : 0≤U*V) (G : Record K J N R Q→RootGridMeasure.RootPoint→ℂ)
    (hG : ∀rec∈records,∀q,‖G rec q‖≤1)
    (ℓ : Matrix.SpecialLinearGroup (Fin 2) ℤ→(p : ℕ)→Option (ZMod p))
    (Epoly Egap : ℝ)
    (hpoly : ‖(n:ℂ)*((∑rec∈records,rootPolynomial rec primes η (2*m) U V (G rec) ℓ)-
      ∑rec∈records,integralPolynomial rec primes η (2*m) U V (G rec))‖≤Epoly)
    (hgap : |n| *(∑rec∈records,rootGap rec primes η (2*m+1) U V ℓ)-
      (15*(U*V/(Real.pi^2/6)))*(|n| *(∑rec∈records,gap rec primes η (2*m+1)))≤Egap) :
    ‖(n:ℂ)*((∑rec∈records,rootComplete rec primes η U V (G rec) ℓ)-
      ∑rec∈records,integralComplete rec primes η U V (G rec))‖ ≤
      Epoly+Egap+2*(15*(U*V/(Real.pi^2/6)))*
        (|n| *(∑rec∈records,gap rec primes η (2*m+1))) := by
  have hroot : ‖(n:ℂ)*((∑rec∈records,rootComplete rec primes η U V (G rec) ℓ)-
      ∑rec∈records,rootPolynomial rec primes η (2*m) U V (G rec) ℓ)‖≤
        |n| *(∑rec∈records,rootGap rec primes η (2*m+1) U V ℓ) := by
    rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,←Finset.sum_sub_distrib]
    apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
    apply (norm_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro rec hr
    exact literal_remainder rec primes (hA rec hr) η hη m U V (G rec) (hG rec hr) ℓ
  have hint : ‖(n:ℂ)*((∑rec∈records,integralComplete rec primes η U V (G rec))-
      ∑rec∈records,integralPolynomial rec primes η (2*m) U V (G rec))‖≤
        (15*(U*V/(Real.pi^2/6)))*(|n| *(∑rec∈records,gap rec primes η (2*m+1))) := by
    rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,←Finset.sum_sub_distrib]
    calc
      _ ≤ |n| *(∑rec∈records,(15*(U*V/(Real.pi^2/6)))*gap rec primes η (2*m+1)) := by
        apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
        apply (norm_sum_le _ _).trans
        apply Finset.sum_le_sum
        intro rec hr
        exact integrated_remainder rec primes (hA rec hr) η hη m U V hUV (G rec) (hG rec hr)
      _ = _ := by rw [←Finset.mul_sum]; ring
  let A := (n:ℂ)*(∑rec∈records,rootComplete rec primes η U V (G rec) ℓ)
  let B := (n:ℂ)*(∑rec∈records,rootPolynomial rec primes η (2*m) U V (G rec) ℓ)
  let C := (n:ℂ)*(∑rec∈records,integralPolynomial rec primes η (2*m) U V (G rec))
  let D := (n:ℂ)*(∑rec∈records,integralComplete rec primes η U V (G rec))
  have ht := norm_sub_le_norm_sub_add_norm_sub A B D
  have ht' := norm_sub_le_norm_sub_add_norm_sub B C D
  have hr : ‖A-B‖≤|n| *(∑rec∈records,rootGap rec primes η (2*m+1) U V ℓ) := by
    simpa only [A,B,←mul_sub] using hroot
  have hp : ‖B-C‖≤Epoly := by simpa only [B,C,←mul_sub] using hpoly
  have hi : ‖C-D‖≤(15*(U*V/(Real.pi^2/6)))*(|n| *(∑rec∈records,gap rec primes η (2*m+1))) := by
    rw [norm_sub_rev]
    simpa only [C,D,←mul_sub] using hint
  have he : (n:ℂ)*((∑rec∈records,rootComplete rec primes η U V (G rec) ℓ)-
      ∑rec∈records,integralComplete rec primes η U V (G rec))=A-D := by dsimp [A,D]; ring
  rw [he]
  linarith

end Elliptic.Operator.RootRecordComparison
