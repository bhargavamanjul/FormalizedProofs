module
public import Elliptic.Operator.PhysicalEndpointPairing
public import Elliptic.Operator.SignedPhysicalPairSupport

/-! The actual damped row pairing is the original scalar physical
pairing on complete endpoint coefficient functions. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators ComplexConjugate
open PhysicalRootedMoment PhysicalMomentIdentification PhysicalVertexDamping
open PhysicalRootIndependentMoment PhysicalEndpointPairing SingleEdgePhysicalRestoration
open SingleEdgeRootEncoding RootLiteralGeometry SingleEdgeRootIncidence
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {K J : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem dampedGeometry_insert_incidence (value : ∀i,P i→ℕ) (primes : Finset ℕ)
    (hprimes : ∀i p,value i p∈primes) (θ : ℝ)
    (g : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (z w : ℤ×ℤ) (a b : PhysicalActiveLists P J) :
    dampedGeometry value primes θ g z a w b=
      dampedGeometry value primes θ
        (fun z a w b=>if physicalIncidence value a b z w then g z a w b else 0) z a w b := by
  by_cases hi : physicalIncidence value a b z w
  · simp only [dampedGeometry,hi,ite_true]
  by_cases hz : vertexWeight value primes θ z a=0
  · simp [dampedGeometry,hz]
  by_cases hw : vertexWeight value primes θ w b=0
  · simp [dampedGeometry,hw]
  exact (hi ⟨PhysicalAdmissibleMoment.vertexWeight_nonzero_incidence value primes hprimes θ z a hz,
    PhysicalAdmissibleMoment.vertexWeight_nonzero_incidence value primes hprimes θ w b hw⟩).elim

theorem primePool_eq_groupPool (groups : Fin K→Finset ℕ) :
    primePool (fun i=>fun p : groups i=>p.val)=groupPool groups := by
  ext p
  simp only [primePool,Finset.mem_image,Finset.mem_univ,true_and,groupPool,Finset.mem_biUnion]
  constructor
  · rintro ⟨⟨i,r⟩,rfl⟩
    exact ⟨i,r.property⟩
  · rintro ⟨i,hp⟩
    exact ⟨⟨i,⟨p,hp⟩⟩,rfl⟩

theorem pairing_complete_eq_original
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (VM : Fin K→ℝ) (μ : ∀i,groups i→ℝ)
    (U V d₀ Y L H θ : ℝ) (hU : 0≤U) (hV : 0≤V) (a : Fin K→ℝ)
    (η ψ : ℝ→ℂ) (σ : ℤ) (S T : Finset ℕ)
    (α β : ℕ→ℂ) (hrough : ∀m∈S,α m≠0→∀p∈groupPool groups,¬p∣m) :
    pairing VM (fun x : State (Z:=primitiveSources U V) (P:=fun i=>groups i) (J:=J)=>
        conj (completeLeft groups J S T α β x.1.val))
      (rowApply VM (physicalGeometry (fun i=>fun p : groups i=>p.val) μ d₀ Y L U V a η ψ
        (sourceMajorArcs H Y) σ (primePool (fun i=>fun p : groups i=>p.val)) θ)
        (fun x=>completeRight groups J S T α β x.1.val)) =
    originalPairing (J:=J) (fun i=>fun p : groups i=>p.val) VM
      (sourceGood (fun i=>fun p : groups i=>p.val) μ d₀ Y L a (1,1,0)) U V d₀ Y H η ψ σ
      (fun x=>completeLeft groups J S T α β x.1) (fun x=>completeRight groups J S T α β x.1) := by
  let value := fun i=>fun p : groups i=>p.val
  let good := sourceGood (J:=J) value μ d₀ Y L a (1,1,0)
  rw [←pairing_physicalKernel_eq_original (J:=J) value VM good U V d₀ Y H η ψ σ
    (completeLeft groups J S T α β) (completeRight groups J S T α β)]
  rw [pairing_position_functions VM _ (fun z : primitiveSources U V=>completeLeft groups J S T α β z.val)
      (fun z : primitiveSources U V=>completeRight groups J S T α β z.val),
    pairing_position_functions VM _ (fun z : primitiveSources U V=>completeLeft groups J S T α β z.val)
      (fun z : primitiveSources U V=>completeRight groups J S T α β z.val)]
  congr 1
  apply Finset.sum_congr (by ext; simp)
  intro z hz
  apply Finset.sum_congr (by ext; simp)
  intro w hw
  apply Finset.sum_congr (by ext; simp)
  intro u hu
  apply Finset.sum_congr (by ext; simp)
  intro v hv
  unfold physicalGeometry
  rw [primePool_eq_groupPool]
  rw [dampedGeometry_insert_incidence value (groupPool groups)
    (fun i p=>Finset.mem_biUnion.mpr ⟨i,Finset.mem_univ _,p.property⟩)]
  have he := damped_physicalKernel_endpoints_eq groups hp good U V d₀ Y H θ hU hV η ψ σ
    (S.filter (fun m=>α m≠0)) (T.filter (fun n=>β n≠0))
    (fun m hm=>hrough m (Finset.mem_filter.mp hm).1 (Finset.mem_filter.mp hm).2) α β z.val w.val u v
  simpa only [completeLeft_filter_support,completeRight_filter_support,physicalKernel,
    baseGeometry,value,good] using he

end Elliptic.Operator.SignedPhysicalPairBridge
