module
public import Elliptic.Operator.PhysicalCleanSymmetry
public import Elliptic.Operator.PhysicalActiveReindex

/-! Exact shared-list and unchanged-bag conditioning of the clean edge.
The original fixed mass cancels in the kernel density; it is retained in
both endpoint L2 measures, so there is no number-of-bags factor. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalCleanBlocksDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

theorem finiteL2_scale_measure {X : Type*} (s : Finset X) (μ : X → ℝ)
    (c : ℝ) (hc : 0≤c) (a : X → ℂ) :
    finiteL2 s (fun x => c*μ x) a = Real.sqrt c*finiteL2 s μ a := by
  unfold finiteL2 finiteL2Sq
  rw [show (∑ x∈s, c*μ x*‖a x‖^2)=c*(∑ x∈s, μ x*‖a x‖^2) by
    simp only [Finset.mul_sum,mul_assoc]]
  exact Real.sqrt_mul hc _

theorem finiteKernelBound_scale_measure {X Y : Type*}
    (s : Finset X) (t : Finset Y) (μ : X → ℝ) (ν : Y → ℝ)
    (K : X → Y → ℂ) (M c : ℝ) (hc : 0<c)
    (hK : FiniteKernelBound s t μ ν K M) :
    FiniteKernelBound s t (fun x => c*μ x) (fun y => c*ν y)
      (fun x y => K x y/(c:ℂ)) M := by
  intro b
  have he : finiteKernelApply t (fun y => c*ν y) (fun x y => K x y/(c:ℂ)) b =
      finiteKernelApply t ν K b := by
    funext x
    unfold finiteKernelApply
    apply Finset.sum_congr rfl
    intro y hy
    have hc' : (c:ℂ)≠0 := by exact_mod_cast hc.ne'
    push_cast
    field_simp
  rw [he,finiteL2_scale_measure s μ c hc.le,finiteL2_scale_measure t ν c hc.le]
  have h := mul_le_mul_of_nonneg_left (hK b) (Real.sqrt_nonneg c)
  nlinarith

namespace PhysicalCleanBlocks
open PhysicalEdgeAdjoint PhysicalMaskedKernel PhysicalMaskedSchur
open PhysicalCleanMemory PhysicalCleanSymmetry

variable {G Z : Type*} [Fintype G] [Fintype Z]
variable {P : G → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

abbrev Block := PhysicalActiveReindex.SharedLists P J × Bags (P:=P) (Line:=Line) (B:=B)
abbrev Free := Z × (∀ i, P i)

def assemble (shared : PhysicalActiveReindex.SharedLists P J) (prime : ∀ i, P i) :
    PhysicalActiveLists P J := PhysicalActiveReindex.assemble (fun _ => Equiv.refl _) shared prime

/-- The actual state splits bijectively into fixed shared/bag data and
free position/unshared-prime data. -/
def equiv : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B) ≃
    Block (P:=P) (Line:=Line) (J:=J) (B:=B) × Free (Z:=Z) (P:=P) where
  toFun s := ((fun i (j : Fin J) => active s i j.castSucc,bags s),(position s,fun i => active s i (Fin.last J)))
  invFun x := (x.2.1,assemble x.1.1 x.2.2,x.1.2)
  left_inv s := by
    change (position s,assemble (fun i (j : Fin J) => active s i j.castSucc)
      (fun i => active s i (Fin.last J)),bags s) = (position s,active s,bags s)
    have he := PhysicalActiveReindex.assemble_of_list (fun _ => Equiv.refl _) (active s)
    simpa only [assemble,Equiv.refl_apply] using congrArg
      (fun a => (position s,a,bags s)) he
  right_inv x := by
    rcases x with ⟨⟨shared,bag⟩,z,prime⟩
    simp [assemble,PhysicalActiveReindex.assemble,position,active,bags]

def fixedMass (ν : ∀ i, P i → ℝ) (b : Block (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℝ :=
  ∏ i, (∏ j, ν i (b.1 i j))*memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (b.2 i)

def freeMass (ν : ∀ i, P i → ℝ) (x : Free (Z:=Z) (P:=P)) : ℝ := ∏ i, ν i (x.2 i)

theorem fixedMass_pos (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0<ν i p)
    (b : Block (P:=P) (Line:=Line) (J:=J) (B:=B)) : 0<fixedMass ν b := by
  exact Finset.prod_pos (fun i _ => mul_pos (Finset.prod_pos (fun j _ => hν i _))
    (memoryBagMass_pos _ (fun x : AnchoredParticle (P i) (Line i) => hν i x.1) _))

theorem freeMass_pos (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0<ν i p)
    (x : Free (Z:=Z) (P:=P)) : 0<freeMass ν x := Finset.prod_pos (fun i _ => hν i _)

theorem mass_split (ν : ∀ i, P i → ℝ)
    (s : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    mass ν s=fixedMass ν (equiv s).1*freeMass ν (equiv s).2 := by
  unfold mass fixedMass freeMass
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i hi
  rw [tupleWeight,Fin.prod_univ_castSucc]
  change ((∏ j : Fin J, ν i (active s i j.castSucc))*ν i (active s i (Fin.last J)))*_ = _
  change ((∏ j : Fin J, ν i (active s i j.castSucc))*ν i (active s i (Fin.last J)))*
    memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (bags s i) =
    ((∏ j : Fin J, ν i (active s i j.castSucc))*
      memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (bags s i))*
        ν i (active s i (Fin.last J))
  ring

/-- The remaining genuine geometry in one fixed shared-list/bag block. -/
def core (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (b : Block (P:=P) (Line:=Line) (J:=J) (B:=B))
    (x y : Free (Z:=Z) (P:=P)) : ℂ :=
  damping anchor (ρ:ℂ) b.2 x.1 * geometry x.1 (assemble b.1 x.2) y.1 (assemble b.1 y.2) *
    damping anchor (ρ:ℂ) b.2 y.1

/-- The exact identity-permutation clean density is a true diagonal
block kernel; every fixed factorial/shared mass occurs in its denominator. -/
theorem termDensity_eq_blocks
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0<ν i p) (V : G → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) :
    termDensity ν V ρ anchor geometry (fun _ => Equiv.refl _) (fun _ => Equiv.refl _) s t =
      blockDiagonalKernel (fun b x y => core ρ anchor geometry b x y/(fixedMass ν b:ℂ))
        (equiv s) (equiv t) := by
  have hν' : ∀ i p, (ν i p:ℂ)≠0 := by intro i p; exact_mod_cast (hν i p).ne'
  unfold termDensity
  rw [term_clean _ hν']
  have hblock : (equiv s).1=(equiv t).1 ↔
      Shared s t (fun _ => Equiv.refl _) (fun _ => Equiv.refl _) ∧ bags s=bags t := by
    change ((fun i (j : Fin J) => active s i j.castSucc),bags s)=((fun i (j : Fin J) => active t i j.castSucc),bags t) ↔ _
    simp only [Prod.mk.injEq,Shared,Equiv.refl_apply,funext_iff]
  by_cases hb : (equiv s).1=(equiv t).1
  · rw [ite_eq_left (hblock.mp hb)]
    simp only [blockDiagonalKernel,ite_eq_left hb]
    have hslist : assemble (equiv s).1.1 (equiv s).2.2=active s := by
      exact PhysicalActiveReindex.assemble_of_list (fun _ => Equiv.refl _) (active s)
    have htlist : assemble (equiv s).1.1 (equiv t).2.2=active t := by
      rw [hb]
      exact PhysicalActiveReindex.assemble_of_list (fun _ => Equiv.refl _) (active t)
    have hmass := mass_split ν t
    rw [← hb] at hmass
    have hf := freeMass_pos ν hν (equiv t).2
    have hbpos := fixedMass_pos ν hν (equiv s).1
    have hf' : ((freeMass ν (equiv t).2:ℝ):ℂ)≠0 := by exact_mod_cast hf.ne'
    have hb' : ((fixedMass ν (equiv s).1:ℝ):ℂ)≠0 := by exact_mod_cast hbpos.ne'
    rw [hmass]
    simp only [core,hslist,htlist,Equiv.refl_apply,Complex.ofReal_mul]
    change _ = damping anchor (ρ:ℂ) (bags s) (position s) *
      geometry (position s) (active s) (position t) (active t) *
      damping anchor (ρ:ℂ) (bags s) (position t) / _
    have hp : (∏ i, (ν i (active t i (Fin.last J)):ℂ)) = ((freeMass ν (equiv t).2:ℝ):ℂ) := by
      simp only [freeMass,Complex.ofReal_prod]
      rfl
    rw [hp]
    field_simp
  · rw [ite_eq_right (fun h => hb (hblock.mpr h))]
    simp [blockDiagonalKernel,hb]

/-- Full unchanged-memory and shared-label assembly on the literal physical
state space. The only input is the geometric norm for each fixed shared
list; no bound on a memory or permutation operator is assumed. -/
theorem clean_kernel_bound_of_shared_geometry
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0<ν i p) (V : G → ℝ) (ρ M : ℝ)
    (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hM : 0≤M)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (hgeom : ∀ shared : PhysicalActiveReindex.SharedLists P J,
      FiniteMeasuredBilinearBound Finset.univ Finset.univ (freeMass (Z:=Z) ν) (freeMass (Z:=Z) ν)
        (fun x y => geometry x.1 (assemble shared x.2) y.1 (assemble shared y.2)) M) :
    FiniteMeasuredBilinearBound Finset.univ Finset.univ (mass (B:=B) ν) (mass (B:=B) ν)
      (fun s t => originalKernel ν V (fun _ => false) (fun _ => false) ρ anchor geometry s t /
        ((mass ν t:ℝ):ℂ)) M := by
  apply clean_kernel_bound_of_identity ν hν V ρ M hM anchor geometry
  let Bl := Block (P:=P) (Line:=Line) (J:=J) (B:=B)
  let Fr := Free (Z:=Z) (P:=P)
  have hfree : ∀ x : Fr, 0≤freeMass ν x := fun x => (freeMass_pos ν hν x).le
  have hfixed : ∀ b : Bl, 0<fixedMass ν b := fixedMass_pos ν hν
  have hcore (b : Bl) : FiniteKernelBound Finset.univ Finset.univ
      (freeMass ν) (freeMass ν) (core ρ anchor geometry b) M := by
    apply finiteKernelBound_of_measured_bilinear _ _ _ _ (fun x _ => hfree x) _ M hM
    exact measured_clean_endpoint_bound _ _ _ _ (fun x _ => hfree x) (fun x _ => hfree x)
      _ M hM (fun x => damping anchor (ρ:ℂ) b.2 x.1) (fun y => damping anchor (ρ:ℂ) b.2 y.1)
      (fun x _ => damping_norm_le_one anchor ρ hρ0 hρ1 b.2 x.1)
      (fun y _ => damping_norm_le_one anchor ρ hρ0 hρ1 b.2 y.1) (hgeom b.1)
  have hb := blockDiagonalKernel_bound (Finset.univ : Finset Bl) (Finset.univ : Finset Fr)
    (Finset.univ : Finset Fr) (fun b x => fixedMass ν b*freeMass ν x)
    (fun b x => fixedMass ν b*freeMass ν x)
    (fun b x y => core ρ anchor geometry b x y/(fixedMass ν b:ℂ)) M hM
    (fun b _ x _ => mul_nonneg (hfixed b).le (hfree x))
    (fun b _ x _ => mul_nonneg (hfixed b).le (hfree x))
    (fun b _ => finiteKernelBound_scale_measure _ _ _ _ _ M (fixedMass ν b) (hfixed b) (hcore b))
  simp only [Finset.univ_product_univ] at hb
  have hbil := finiteMeasuredBilinearBound_of_kernel_bound _ _ _ _
    (fun x _ => mul_nonneg (hfixed x.1).le (hfree x.2)) _ M hb
  have htrans := finiteMeasuredBilinearBound_equiv equiv equiv (mass (B:=B) ν) (mass (B:=B) ν)
    (fun x : Bl×Fr => fixedMass ν x.1*freeMass ν x.2)
    (fun x : Bl×Fr => fixedMass ν x.1*freeMass ν x.2)
    (mass_split ν) (mass_split ν) _ M hbil
  have he : termDensity (B:=B) ν V ρ anchor geometry
      (fun _ => Equiv.refl _) (fun _ => Equiv.refl _) =
      fun x y => blockDiagonalKernel (fun b x y => core ρ anchor geometry b x y/(fixedMass ν b:ℂ))
        (equiv x) (equiv y) := by
    funext x y
    exact termDensity_eq_blocks ν hν V ρ anchor geometry x y
  rw [he]
  exact htrans

end PhysicalCleanBlocks
end Elliptic.Operator
