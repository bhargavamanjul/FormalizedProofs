module

public import Elliptic.Operator.OriginalIntervalAverage
public import Elliptic.Operator.OriginalLeafNormalization

/-!
# Independent prime intervals and the actual finite original leaves

This file retains the complete dependent product of the one-prime optional
lifespans. The conversion to finite original leaves is injective and has an
explicit inverse. Line-incidence and unused-prime restrictions are recovered
from the literal local weights, not imposed as a new counting hypothesis.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open ScheduledPhysicalPath CanonicalBoundaryAssembly SourceHistoryCoefficient
open OriginalIntervalAverage
attribute [local instance] Classical.propDecidable
local instance independentChoiceDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}

namespace OriginalPath

abbrev PrimeChoices (r : OriginalPath I Z P J N) :=
  ∀ i p, Option (Span N (r.activeVisits i p))

structure SourceValid (r : OriginalPath I Z P J N) (value : ∀ i, P i → ℕ) : Prop where
  active_distinct : ∀ j, j≤N → ∀ i, Function.Injective (r.activeAt j i)
  crossEdgeBan : ∀ j, j<N → sourceCrossEdgeBan value (r.sourceLists j) (r.targetLists j)

abbrev SourcePaths (value : ∀ i, P i → ℕ) (J N : ℕ) :=
  {r : OriginalPath I Z P J N // r.SourceValid value}

variable (r : OriginalPath I Z P J N)

def choiceLeaf (C : r.PrimeChoices) : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N) where
  toOriginalPath := r
  interval i p := (C i p).map endpoints

/-- Literal source path coordinates are untouched by prime interval expansion. -/
@[simp] theorem choiceLeaf_path (C : r.PrimeChoices) : (r.choiceLeaf C).toOriginalPath=r := rfl

theorem choiceLeaf_injective : Function.Injective r.choiceLeaf := by
  intro C D he
  funext i p
  have hi := congrArg (fun e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N)=>e.interval i p) he
  change Option.map endpoints (C i p)=Option.map endpoints (D i p) at hi
  cases hc : C i p with
  | none =>
    cases hd : D i p with
    | none => rfl
    | some L => simp [hc,hd] at hi
  | some L =>
    cases hd : D i p with
    | none => simp [hc,hd] at hi
    | some M =>
      simp only [hc,hd,Option.map_some,Option.some.injEq] at hi
      exact congrArg some (endpoints_injective _ hi)

def choicesWeight (anchor : Z → ∀ i p, Line i p)
    (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ) (C : r.PrimeChoices) : ℝ :=
  ∏ i, ∏ p, choiceWeight (r.activeVisits i p)
    (fun j=>anchor (r.positionAt j) i p) η (μ i p) (C i p)

/-- Unused labels and all retained-line incidences are forced whenever
the complete literal product weight is nonzero. -/
theorem local_conditions_of_weight_ne_zero
    (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ) (C : r.PrimeChoices)
    (hw : r.choicesWeight anchor η μ C≠0) :
    (∀ i p, C i p=none → r.activeVisits i p=∅) ∧
      (∀ i p L, C i p=some L → Incidence (fun j=>anchor (r.positionAt j) i p) L.val) := by
  have hloc (i : I) (p : P i) :
      choiceWeight (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η (μ i p) (C i p)≠0 := by
    exact (Finset.prod_ne_zero_iff.mp (Finset.prod_ne_zero_iff.mp hw i (Finset.mem_univ _))) p (Finset.mem_univ _)
  constructor
  · intro i p hn
    have h := hloc i p
    rw [hn] at h
    by_contra hh
    simp [choiceWeight,hh] at h
  · intro i p L hs
    have h := hloc i p
    rw [hs] at h
    by_contra hh
    simp [choiceWeight,spanWeight,hh] at h

/-- A bound by all available primes makes the finite memory cutoff automatic.
It is deliberately explicit and is not the manuscript's smaller cutoff. -/
theorem choiceLeaf_valid_of_large_cutoff
    (value : ∀ i, P i → ℕ) (hr : r.SourceValid value)
    (C : r.PrimeChoices)
    (hnone : ∀ i p, C i p=none → r.activeVisits i p=∅)
    (hinc : ∀ i p L, C i p=some L → Incidence (fun j=>anchor (r.positionAt j) i p) L.val)
    (hB : (∑ i,Fintype.card (P i))≤B) :
    (r.choiceLeaf C).SourceValid anchor value B := by
  refine ⟨⟨hr.active_distinct,?_,?_,?_,?_,?_,?_,?_,?_⟩,hr.crossEdgeBan⟩
  · intro j hj i k
    exact (hr.crossEdgeBan j hj).1 i k
  · intro i p hn
    apply hnone i p
    simpa [choiceLeaf] using hn
  · intro i p bd hb
    cases hc : C i p with
    | none => simp [choiceLeaf,hc] at hb
    | some L =>
      simp only [choiceLeaf,hc,Option.map_some,Option.some.injEq] at hb
      subst bd
      exact L.val.birth_le_death
  · intro i p bd hb j hj
    cases hc : C i p with
    | none => simp [choiceLeaf,hc] at hb
    | some L =>
      simp only [choiceLeaf,hc,Option.map_some,Option.some.injEq] at hb
      subst bd
      apply L.val.active_bounds j
      change j∈r.activeVisits i p at hj
      simpa only [L.property.1] using hj
  · intro i p bd hb he
    cases hc : C i p with
    | none => simp [choiceLeaf,hc] at hb
    | some L =>
      simp only [choiceLeaf,hc,Option.map_some,Option.some.injEq] at hb
      subst bd
      change L.val.birth∈r.activeVisits i p
      simpa only [L.property.1] using L.val.singleton_active (congrArg Fin.val he)
  · intro i p bd hb j hj hcases
    cases hc : C i p with
    | none => simp [choiceLeaf,hc] at hb
    | some L =>
      simp only [choiceLeaf,hc,Option.map_some,Option.some.injEq] at hb
      subst bd
      have hi := hinc i p L hc
      change anchor (r.positionAt L.val.birth) i p=anchor (r.positionAt j) i p
      change j=L.val.birth ∨ j=L.val.death ∨ j∈r.activeVisits i p at hcases
      rcases hcases with h | h | h
      · simpa only [h]
      · simpa only [h] using hi.1
      · exact (hi.2 j (by simpa only [L.property.1] using h)).symm
  · intro j hj
    exact (Finset.sum_le_sum (fun i _=>Finset.card_le_univ ((r.choiceLeaf C).beforeSet j i))).trans hB
  · intro j hj
    exact (Finset.sum_le_sum (fun i _=>Finset.card_le_univ ((r.choiceLeaf C).afterSet j i))).trans hB

end OriginalPath

namespace OriginalLeaf

variable (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N)) (h : e.Valid anchor B)

/-- Read the actual local lifespan choices back from a finite original leaf. -/
def primeChoices : e.toOriginalPath.PrimeChoices := fun i p =>
  if hp : p∈e.primes i then some ⟨e.lifespan anchor h i p,
    (e.lifespan_fields anchor h i p hp).2.2,by
      have hf := (e.lifespan_fields anchor h i p hp).1
      exact Finset.mem_range.mpr (Nat.lt_succ_of_le
        ((e.lifespan anchor h i p).birth_le_death.trans (e.lifespan anchor h i p).death_le)),by
      exact Finset.mem_range.mpr (Nat.lt_succ_of_le (e.lifespan anchor h i p).death_le)⟩
    else none

/-- No original coordinate or interval is lost in the reconstruction. -/
theorem choiceLeaf_primeChoices : e.toOriginalPath.choiceLeaf (e.primeChoices h)=e := by
  apply OriginalLeaf.ext
  · rfl
  · rfl
  · rfl
  · rfl
  · funext i p
    cases he : e.interval i p with
    | none => simp [OriginalPath.choiceLeaf,primeChoices,mem_primes,he]
    | some bd => simp [OriginalPath.choiceLeaf,primeChoices,mem_primes,he,endpoints,lifespan]

/-- The dependent family is recovered exactly once its leaf is valid. -/
theorem primeChoices_choiceLeaf (r : OriginalPath I Z P J N) (C : r.PrimeChoices)
    (h : (r.choiceLeaf C).Valid anchor B) :
    (r.choiceLeaf C).primeChoices h=C := by
  apply r.choiceLeaf_injective
  exact choiceLeaf_primeChoices (r.choiceLeaf C) h

/-- Valid original line incidences give the literal local independent-line
weight, with one normalized line mass for each used prime. -/
theorem primeChoices_weight (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ) :
    e.toOriginalPath.choicesWeight anchor η μ (e.primeChoices h) =
      ∏ i, ∏ p∈e.primes i, μ i p *
        ∏ j∈Finset.range (N+1), (e.lifespan anchor h i p).lifespanVisitFactor 1 η (fun j=>1-η j)
          (fun j=>e.retained anchor i p=anchor (e.positionAt j) i p) j := by
  unfold OriginalPath.choicesWeight
  apply Finset.prod_congr rfl
  intro i _
  rw [← Finset.prod_subset (Finset.subset_univ (e.primes i))]
  · apply Finset.prod_congr rfl
    intro p hp
    have hf := e.lifespan_fields anchor h i p hp
    have hret : e.retained anchor i p=anchor (e.positionAt (e.lifespan anchor h i p).birth) i p := by
      simp only [retained,hf.1]
    have hi : Incidence (fun j=>anchor (e.positionAt j) i p) (e.lifespan anchor h i p) := by
      constructor
      · exact hret.symm.trans (e.retained_line anchor h i p hp _
          (e.lifespan anchor h i p).death_le (Or.inr (Or.inl rfl)))
      · intro j hj
        have hjN := ((e.lifespan anchor h i p).active_bounds j hj).2.trans
          (e.lifespan anchor h i p).death_le
        exact (e.retained_line anchor h i p hp j hjN (Or.inr (Or.inr hj))).symm.trans hret
    simp only [primeChoices,hp,↓reduceDIte,choiceWeight,spanWeight]
    rw [if_pos hi]
    congr 1
    apply Finset.prod_congr rfl
    intro j _
    simp only [PrimeLifespan.lifespanVisitFactor,hret,eq_comm]
  · intro p _ hp
    have he : e.interval i p=none := by
      cases hh : e.interval i p with
      | none => rfl
      | some bd => exact False.elim (hp (by simp [mem_primes,hh]))
    have ha := h.unused i p he
    simp [primeChoices,hp,choiceWeight,ha]

variable (value : ∀ i, P i → ℕ)

abbrev SourceRecord := Σ r : OriginalPath.SourcePaths (I:=I) (Z:=Z) value J N, r.val.PrimeChoices

/-- All original path data together with the independent local choices. -/
def sourceRecord (e : SourceLeaves anchor value J B N) : SourceRecord (Z:=Z) (J:=J) (N:=N) value :=
  ⟨⟨e.val.toOriginalPath,⟨e.property.valid.active_distinct,e.property.crossEdgeBan⟩⟩,
    e.val.primeChoices e.property.valid⟩

/-- The record map has no overcounting, even though the dependent active
visit sets vary with the full path. -/
theorem sourceRecord_injective :
    Function.Injective (sourceRecord (anchor:=anchor) (B:=B) (N:=N) (J:=J) value) := by
  intro e f he
  apply Subtype.ext
  have hh := congrArg (fun r : SourceRecord (Z:=Z) (J:=J) (N:=N) value=>r.1.val.choiceLeaf r.2) he
  simpa only [sourceRecord,choiceLeaf_primeChoices] using hh

/-- Every nonzero independent choice has a source leaf at the stated large
cutoff. The unused and incidence conditions come from its actual weight. -/
theorem sourceRecord_covers_nonzero
    (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ)
    (hB : (∑ i,Fintype.card (P i))≤B)
    (r : SourceRecord (Z:=Z) (J:=J) (N:=N) value)
    (hw : r.1.val.choicesWeight anchor η μ r.2≠0) :
    ∃ e : SourceLeaves anchor value J B N, sourceRecord value e=r := by
  have hc := r.1.val.local_conditions_of_weight_ne_zero η μ r.2 hw
  have hv := r.1.val.choiceLeaf_valid_of_large_cutoff value r.1.property r.2 hc.1 hc.2 hB
  refine ⟨⟨r.1.val.choiceLeaf r.2,hv⟩,?_⟩
  apply Sigma.ext
  · exact Subtype.ext rfl
  · simpa only [sourceRecord] using heq_of_eq (primeChoices_choiceLeaf r.1.val r.2 hv.valid)

/-- Global reindexing of every source path and every independent prime
interval. Arbitrary complex path data remain coupled throughout. -/
theorem sourceLeaves_weighted_sum
    (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ)
    (hB : (∑ i,Fintype.card (P i))≤B)
    (F : OriginalPath I Z P J N → ℂ) :
    (∑ e : SourceLeaves anchor value J B N,
      F e.val.toOriginalPath *
        (e.val.toOriginalPath.choicesWeight anchor η μ (e.val.primeChoices e.property.valid) : ℂ)) =
    ∑ r : OriginalPath.SourcePaths (Z:=Z) value J N,
      F r.val * ∑ C : r.val.PrimeChoices, (r.val.choicesWeight anchor η μ C : ℂ) := by
  calc
    _ = ∑ r : SourceRecord (Z:=Z) (J:=J) (N:=N) value,
        F r.1.val * (r.1.val.choicesWeight anchor η μ r.2 : ℂ) := by
      apply Finset.sum_bij_ne_zero (fun e _ _ => sourceRecord value e)
      · intros; exact Finset.mem_univ _
      · intro e _ _ f _ _ he
        exact sourceRecord_injective value he
      · intro r _ hr
        have hw : r.1.val.choicesWeight anchor η μ r.2≠0 := by
          intro hh
          simp only [hh,Complex.ofReal_zero,mul_zero,ne_eq,not_true_eq_false] at hr
        obtain ⟨e,he⟩ := sourceRecord_covers_nonzero value η μ hB r hw
        refine ⟨e,Finset.mem_univ _,?_,he⟩
        have hw' := congrArg (fun r : SourceRecord (Z:=Z) (J:=J) (N:=N) value=>
          F r.1.val*(r.1.val.choicesWeight anchor η μ r.2 : ℂ)) he
        exact fun hz=>hr (hw'.symm.trans hz)
      · intros; rfl
    _ = _ := by
      rw [Fintype.sum_sigma]
      apply Finset.sum_congr rfl
      intro r _
      rw [Finset.mul_sum]

end OriginalLeaf

namespace OriginalPath

/-- Finite distributivity factors the literal product of all local choices.
The dependent active visit sets vary with the original path without changing
or dropping any prime factor. -/
theorem sum_choicesWeight (r : OriginalPath I Z P J N)
    (η : ℕ → ℝ) (μ : ∀ i, P i → ℝ) :
    (∑ C : r.PrimeChoices,r.choicesWeight anchor η μ C) =
      ∏ i, ∏ p, ∑ L : Option (Span N (r.activeVisits i p)),
        choiceWeight (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η (μ i p) L := by
  unfold choicesWeight
  calc
    _ = ∏ i, ∑ C : ∀ p : P i, Option (Span N (r.activeVisits i p)),
        ∏ p, choiceWeight (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η (μ i p) (C p) :=
      (Fintype.prod_sum (fun i (C : ∀ p : P i, Option (Span N (r.activeVisits i p)))=>
        ∏ p, choiceWeight (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η (μ i p) (C p))).symm
    _ = _ := by
      apply Finset.prod_congr rfl
      intro i _
      exact (Fintype.prod_sum (fun p (L : Option (Span N (r.activeVisits i p)))=>
        choiceWeight (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η (μ i p) L)).symm

/-- The exact entire independent-line expectation equals the extracted
baseline times the complete independent optional-interval expansion. -/
theorem independent_average_eq_choices [∀ i p,Fintype (Line i p)]
    (r : OriginalPath I Z P J N) (η : ℕ → ℝ)
    (hn : ∀ i p,(Fintype.card (Line i p) : ℝ)≠0)
    (hbase : ∀ i p,(Fintype.card (Line i p) : ℝ)-∑j∈Finset.range (N+1),η j≠0) :
    (∏ i, ∏ p, IndependentLineNormalization.lineAverage (Finset.range (N+1))
      (r.activeVisits i p) (fun j=>anchor (r.positionAt j) i p) η) =
    (∏ i, ∏ p, IndependentLineNormalization.baseline (Finset.range (N+1)) η
      (Fintype.card (Line i p))) *
    ∑ C : r.PrimeChoices,r.choicesWeight anchor η
      (fun i p=>IndependentLineNormalization.normalizedLineMass (Finset.range (N+1)) η
        (Fintype.card (Line i p))) C := by
  rw [sum_choicesWeight]
  have havg (i : I) (p : P i) := average_eq_optional_intervals
    (r.activeVisits i p) (Finset.filter_subset _ _) (fun j=>anchor (r.positionAt j) i p) η
    (hn i p) (hbase i p)
  simp_rw [havg,Finset.prod_mul_distrib]

end OriginalPath
end Elliptic.Operator.OriginalLifespanSchedule
