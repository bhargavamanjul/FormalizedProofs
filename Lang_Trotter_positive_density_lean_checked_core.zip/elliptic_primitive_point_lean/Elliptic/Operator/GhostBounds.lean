module

public import Elliptic.Operator.MemoryAdjoint
public import Elliptic.Operator.WeightedSchur
public import Mathlib.Analysis.Complex.Exponential

/-!
# Actual factorial batch sums in the ghost Schur bounds

The sums below run over indexed deletion subsets and actual ordered tuples
of a finite prime alphabet. Repeated prime values are allowed. Fresh tuples
carry the product of their prime masses and the factorial denominator from
the symmetric memory measure. These are the finite calculations underlying
source equations (4.20)--(4.22), rather than assumptions of a ghost norm bound.
-/

@[expose] public section

noncomputable section

namespace Elliptic.Operator

open scoped BigOperators

/-- The actual total product mass of ordered batches of a given length. -/
theorem ghost_tuple_mass_sum {P : Type*} [Fintype P] (ν : P → ℝ) (l : ℕ) :
    (∑ fresh : Fin l → P, tupleWeight ν fresh) = (∑ p, ν p) ^ l := by
  classical
  simpa [tupleWeight] using
    (Finset.sum_pow' (Finset.univ : Finset P) ν l).symm

/-- The finite fresh-batch series after weighting each new memory
coordinate by `v0`. Its inner sum is over actual ordered prime tuples. -/
def ghostFreshBatchSeries {P : Type*} [Fintype P]
    (ν : P → ℝ) (birth v0 : ℝ) (B : ℕ) : ℝ :=
  ∑ l ∈ Finset.range (B + 1),
    (birth * v0) ^ l / (l.factorial : ℝ) * ∑ fresh : Fin l → P, tupleWeight ν fresh

theorem ghostFreshBatchSeries_eq {P : Type*} [Fintype P]
    (ν : P → ℝ) (birth v0 : ℝ) (B : ℕ) :
    ghostFreshBatchSeries ν birth v0 B =
      ∑ l ∈ Finset.range (B + 1), (v0 * birth * ∑ p, ν p) ^ l / (l.factorial : ℝ) := by
  unfold ghostFreshBatchSeries
  simp_rw [ghost_tuple_mass_sum]
  apply Finset.sum_congr rfl
  intro l hl
  rw [mul_pow, mul_pow]
  ring

/-- Factorial tuple summation is bounded by the exponential of its actual
one-particle mass. There is no dependence on the batch cutoff. -/
theorem ghostFreshBatchSeries_le_exp {P : Type*} [Fintype P]
    (ν : P → ℝ) (birth v0 : ℝ) (B : ℕ)
    (hν : ∀ p, 0 ≤ ν p) (hbirth : 0 ≤ birth) (hv0 : 0 ≤ v0) :
    ghostFreshBatchSeries ν birth v0 B ≤ Real.exp (v0 * birth * ∑ p, ν p) := by
  rw [ghostFreshBatchSeries_eq]
  exact Real.sum_le_exp_of_nonneg
    (mul_nonneg (mul_nonneg hv0 hbirth) (Finset.sum_nonneg fun p _ => hν p)) _

/-- The deletion sum is over subsets of the old coordinate index set,
so equal old prime values still give distinct choices. -/
def ghostHitChoiceSum {ι : Type*} [DecidableEq ι] (hits : Finset ι)
    (survive delete v0 : ℝ) : ℝ :=
  ∑ S ∈ hits.powerset, (∏ _i ∈ S, delete / v0) * ∏ _i ∈ hits \ S, survive

/-- Exact deletion/survival sum, with the inverse memory weight for each
deleted coordinate. -/
theorem ghostHitChoiceSum_eq {ι : Type*} [DecidableEq ι] (hits : Finset ι)
    (survive delete v0 : ℝ) :
    ghostHitChoiceSum hits survive delete v0 = (survive + delete / v0) ^ hits.card := by
  unfold ghostHitChoiceSum
  rw [← Finset.prod_add]
  simp [add_comm]

/-- The actual memory-weight ratio under indexed deletion and fresh
append, before extracting the independent deletion and birth factors. -/
theorem ghost_memory_weight_ratio (k d l : ℕ) (v0 : ℝ)
    (hv0 : v0 ≠ 0) (hd : d ≤ k) :
    v0 ^ (k - d + l) / v0 ^ k = v0 ^ l / v0 ^ d := by
  have hk : v0 ^ k = v0 ^ (k - d) * v0 ^ d := by
    rw [← pow_add, Nat.sub_add_cancel hd]
  rw [hk, pow_add]
  field_simp

/-- The complete finite absolute weighted choice sum at a memory list of
length `k`, with a specified set of hit indices. -/
def ghostIndexedWeightedRow {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ) : ℝ :=
  ∑ S ∈ hits.powerset, ∑ l ∈ Finset.range (B + 1),
    ∑ fresh : Fin l → P,
      (delete ^ S.card * survive ^ (hits.card - S.card) * birth ^ l *
        tupleWeight ν fresh / (l.factorial : ℝ)) *
        (v0 ^ (k - S.card + l) / v0 ^ k)

/-- The actual indexed row calculation factors into the old-hit
polynomial and the factorial fresh-prime batch series. -/
theorem ghostIndexedWeightedRow_eq {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (hv0 : v0 ≠ 0) :
    ghostIndexedWeightedRow k hits ν survive delete birth v0 B =
      (survive + delete / v0) ^ hits.card * ghostFreshBatchSeries ν birth v0 B := by
  have heach (S : Finset (Fin k)) (hS : S ∈ hits.powerset) (l : ℕ)
      (fresh : Fin l → P) :
      (delete ^ S.card * survive ^ (hits.card - S.card) * birth ^ l *
        tupleWeight ν fresh / (l.factorial : ℝ)) *
        (v0 ^ (k - S.card + l) / v0 ^ k) =
      ((∏ _i ∈ S, delete / v0) * ∏ _i ∈ hits \ S, survive) *
        ((birth * v0) ^ l / (l.factorial : ℝ) * tupleWeight ν fresh) := by
    have hsub := Finset.mem_powerset.mp hS
    have hcard : S.card ≤ k := (Finset.card_le_card hsub).trans
      ((Finset.card_le_univ _).trans_eq (Fintype.card_fin k))
    rw [ghost_memory_weight_ratio k S.card l v0 hv0 hcard]
    simp only [Finset.prod_const, Finset.card_sdiff_of_subset hsub, div_pow, mul_pow]
    ring
  unfold ghostIndexedWeightedRow
  apply Eq.trans (Finset.sum_congr rfl fun S hS =>
    Finset.sum_congr rfl fun l hl => Finset.sum_congr rfl fun fresh _ => heach S hS l fresh)
  simp_rw [← Finset.mul_sum]
  rw [← Finset.sum_mul]
  change ghostHitChoiceSum hits survive delete v0 * ghostFreshBatchSeries ν birth v0 B = _
  rw [ghostHitChoiceSum_eq]

/-- Once the old-hit parenthesis is at most one, the full finite indexed
row is bounded uniformly in the old memory size and the batch cutoff. -/
theorem ghostIndexedWeightedRow_le_exp {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 s : ℝ) (B : ℕ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s)
    (hsurvive : 0 ≤ survive) (hdelete : 0 ≤ delete) (hbirth : 0 ≤ birth)
    (hv0 : 0 < v0) (hparenthesis : survive + delete / v0 ≤ 1) :
    ghostIndexedWeightedRow k hits ν survive delete birth v0 B ≤ Real.exp (v0 * birth * s) := by
  rw [ghostIndexedWeightedRow_eq k hits ν survive delete birth v0 B hv0.ne']
  have hb : 0 ≤ survive + delete / v0 :=
    add_nonneg hsurvive (div_nonneg hdelete hv0.le)
  calc
    _ ≤ (survive + delete / v0) ^ hits.card * Real.exp (v0 * birth * ∑ p, ν p) :=
      mul_le_mul_of_nonneg_left (ghostFreshBatchSeries_le_exp ν birth v0 B hν hbirth hv0.le)
        (pow_nonneg hb _)
    _ ≤ 1 * Real.exp (v0 * birth * ∑ p, ν p) :=
      mul_le_mul_of_nonneg_right (pow_le_one₀ hb hparenthesis) (Real.exp_nonneg _)
    _ ≤ _ := by
      rw [one_mul]
      apply Real.exp_le_exp.mpr
      exact mul_le_mul_of_nonneg_left hs (mul_nonneg hv0.le hbirth)

/-- Source (4.20), before bounding the actual fresh-batch series by its
exponential. Both the indexed deletion sum and the factorial tuple sum
are explicitly present on the left and in `ghostFreshBatchSeries`. -/
theorem ghost_forward_row_calculation {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (q η ρ V v0 : ℝ) (B : ℕ) (hv0 : v0 ≠ 0) :
    ghostIndexedWeightedRow k hits ν (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 B =
      (q / ρ ^ 2 + η / (ρ * v0)) ^ hits.card * ghostFreshBatchSeries ν (η * V / ρ) v0 B := by
  rw [ghostIndexedWeightedRow_eq k hits ν (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 B hv0]
  simp only [div_div]

/-- Source (4.21): exchanging birth and deletion coefficients gives the
adjoint calculation, with the same actual prime tuple integrals. -/
theorem ghost_adjoint_row_calculation {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (q η ρ V v0 : ℝ) (B : ℕ) (hv0 : v0 ≠ 0) :
    ghostIndexedWeightedRow k hits ν (q / ρ ^ 2) (η * V / ρ) (η / ρ) v0 B =
      (q / ρ ^ 2 + η * V / (ρ * v0)) ^ hits.card * ghostFreshBatchSeries ν (η / ρ) v0 B := by
  rw [ghostIndexedWeightedRow_eq k hits ν (q / ρ ^ 2) (η * V / ρ) (η / ρ) v0 B hv0]
  simp only [div_div]

/-- One explicit positive Schur-weight base that works for all hit counts,
all groups with `V ≤ Vmax`, and all hit multipliers `q ≤ Q < ρ²`. -/
def ghostSchurWeight (ρ Q Vmax : ℝ) : ℝ :=
  1 + max 1 Vmax / (ρ * (1 - Q / ρ ^ 2))

theorem ghostSchurWeight_gap_pos (ρ Q : ℝ) (hρ : 0 < ρ) (hQ : Q < ρ ^ 2) :
    0 < 1 - Q / ρ ^ 2 := by
  exact sub_pos.mpr ((div_lt_one (pow_pos hρ 2)).mpr hQ)

theorem ghostSchurWeight_pos (ρ Q Vmax : ℝ) (hρ : 0 < ρ) (hQ : Q < ρ ^ 2) :
    0 < ghostSchurWeight ρ Q Vmax := by
  have hg := ghostSchurWeight_gap_pos ρ Q hρ hQ
  have hC : 0 < max 1 Vmax := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  unfold ghostSchurWeight
  positivity

/-- The chosen weight absorbs both deletion coefficients uniformly. -/
theorem ghostSchurWeight_gap (ρ Q Vmax : ℝ) (hρ : 0 < ρ) (hQ : Q < ρ ^ 2) :
    max 1 Vmax / (ρ * ghostSchurWeight ρ Q Vmax) ≤ 1 - Q / ρ ^ 2 := by
  have hg := ghostSchurWeight_gap_pos ρ Q hρ hQ
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hweight : max 1 Vmax / (ρ * (1 - Q / ρ ^ 2)) ≤ ghostSchurWeight ρ Q Vmax := by
    unfold ghostSchurWeight
    linarith
  have hm := (div_le_iff₀ (mul_pos hρ hg)).mp hweight
  apply (div_le_iff₀ (mul_pos hρ hv)).mpr
  nlinarith [hm]

/-- A single generic uniform bound covers the forward and adjoint ghost
rows. The coefficient bounds will be instantiated with `η/ρ` and `ηV/ρ`. -/
theorem ghostIndexedWeightedRow_uniform {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth ρ Q Vmax s : ℝ) (B : ℕ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ ^ 2)
    (hsurvive : 0 ≤ survive) (hdelete : 0 ≤ delete) (hbirth : 0 ≤ birth)
    (hsurviveQ : survive ≤ Q / ρ ^ 2)
    (hdeleteC : delete ≤ max 1 Vmax / ρ) (hbirthC : birth ≤ max 1 Vmax / ρ) :
    ghostIndexedWeightedRow k hits ν survive delete birth (ghostSchurWeight ρ Q Vmax) B ≤
      Real.exp (ghostSchurWeight ρ Q Vmax * max 1 Vmax * s / ρ) := by
  have hv := ghostSchurWeight_pos ρ Q Vmax hρ hQ
  have hparenthesis : survive + delete / ghostSchurWeight ρ Q Vmax ≤ 1 := by
    have hd := div_le_div_of_nonneg_right hdeleteC hv.le
    rw [div_div] at hd
    have hg := ghostSchurWeight_gap ρ Q Vmax hρ hQ
    linarith
  apply (ghostIndexedWeightedRow_le_exp k hits ν survive delete birth
    (ghostSchurWeight ρ Q Vmax) s B hν hs hsurvive hdelete hbirth hv hparenthesis).trans
  apply Real.exp_le_exp.mpr
  calc
    _ ≤ ghostSchurWeight ρ Q Vmax * (max 1 Vmax / ρ) * s :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hbirthC hv.le) hs0
    _ = _ := by ring

/-- The forward and adjoint ghost bounds share one explicit constant,
independent of old memory length, hit count, and the truncation cutoff. -/
theorem ghost_forward_adjoint_uniform {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (q η ρ V Q Vmax s : ℝ) (B : ℕ)
    (hν : ∀ p, 0 ≤ ν p) (hs : (∑ p, ν p) ≤ s) (hs0 : 0 ≤ s)
    (hρ : 0 < ρ) (hQ : Q < ρ ^ 2) (hq0 : 0 ≤ q) (hqQ : q ≤ Q)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (hV0 : 0 ≤ V) (hVmax : V ≤ Vmax) :
    let v0 := ghostSchurWeight ρ Q Vmax
    let C := Real.exp (v0 * max 1 Vmax * s / ρ)
    ghostIndexedWeightedRow k hits ν (q / ρ ^ 2) (η / ρ) (η * V / ρ) v0 B ≤ C ∧
      ghostIndexedWeightedRow k hits ν (q / ρ ^ 2) (η * V / ρ) (η / ρ) v0 B ≤ C := by
  dsimp
  have hq := div_nonneg hq0 (sq_nonneg ρ)
  have hqb := div_le_div_of_nonneg_right hqQ (sq_nonneg ρ)
  have hη := div_nonneg hη0 hρ.le
  have hηV := div_nonneg (mul_nonneg hη0 hV0) hρ.le
  have hηb : η / ρ ≤ max 1 Vmax / ρ := div_le_div_of_nonneg_right
    (hη1.trans (le_max_left _ _)) hρ.le
  have hηVb : η * V / ρ ≤ max 1 Vmax / ρ := by
    apply div_le_div_of_nonneg_right _ hρ.le
    exact ((mul_le_mul_of_nonneg_right hη1 hV0).trans_eq (one_mul V)).trans
      (hVmax.trans (le_max_right _ _))
  constructor
  · exact ghostIndexedWeightedRow_uniform k hits ν _ _ _ ρ Q Vmax s B
      hν hs hs0 hρ hQ hq hη hηV hqb hηb hηVb
  · exact ghostIndexedWeightedRow_uniform k hits ν _ _ _ ρ Q Vmax s B
      hν hs hs0 hρ hQ hq hηV hη hqb hηVb hηb

/-- Each unmodified absolute indexed choice has nonnegative weight. -/
theorem ghost_choice_weight_nonneg {P : Type*} [Fintype P] (k : ℕ)
    (hits S : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 : ℝ)
    (l : ℕ) (fresh : Fin l → P)
    (hν : ∀ p, 0 ≤ ν p) (hsurvive : 0 ≤ survive) (hdelete : 0 ≤ delete)
    (hbirth : 0 ≤ birth) (hv0 : 0 ≤ v0) :
    0 ≤ (delete ^ S.card * survive ^ (hits.card - S.card) * birth ^ l *
      tupleWeight ν fresh / (l.factorial : ℝ)) * (v0 ^ (k - S.card + l) / v0 ^ k) := by
  have ht : 0 ≤ tupleWeight ν fresh := Finset.prod_nonneg fun i _ => hν (fresh i)
  positivity

/-- A literal bounded local choice multiplier may encode memory-size
truncation or any other restriction; it cannot increase the positive
weighted sum. Symmetry needed for the operator domain is a separate issue. -/
def ghostIndexedWeightedRowModified {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (χ : (S : Finset (Fin k)) → (l : ℕ) → (Fin l → P) → ℝ) : ℝ :=
  ∑ S ∈ hits.powerset, ∑ l ∈ Finset.range (B + 1), ∑ fresh : Fin l → P,
    χ S l fresh * ((delete ^ S.card * survive ^ (hits.card - S.card) * birth ^ l *
      tupleWeight ν fresh / (l.factorial : ℝ)) * (v0 ^ (k - S.card + l) / v0 ^ k))

theorem ghostIndexedWeightedRowModified_le {P : Type*} [Fintype P] (k : ℕ)
    (hits : Finset (Fin k)) (ν : P → ℝ) (survive delete birth v0 : ℝ) (B : ℕ)
    (χ : (S : Finset (Fin k)) → (l : ℕ) → (Fin l → P) → ℝ)
    (hν : ∀ p, 0 ≤ ν p) (hsurvive : 0 ≤ survive) (hdelete : 0 ≤ delete)
    (hbirth : 0 ≤ birth) (hv0 : 0 ≤ v0)
    (hχ : ∀ S ∈ hits.powerset, ∀ l ∈ Finset.range (B + 1), ∀ fresh, χ S l fresh ≤ 1) :
    ghostIndexedWeightedRowModified k hits ν survive delete birth v0 B χ ≤
      ghostIndexedWeightedRow k hits ν survive delete birth v0 B := by
  apply Finset.sum_le_sum
  intro S hS
  apply Finset.sum_le_sum
  intro l hl
  apply Finset.sum_le_sum
  intro fresh hf
  exact (mul_le_mul_of_nonneg_right (hχ S hS l hl fresh)
    (ghost_choice_weight_nonneg k hits S ν survive delete birth v0 l fresh
      hν hsurvive hdelete hbirth hv0)).trans_eq (one_mul _)

/-- A product of the one-group absolute bounds gives an explicit constant
for finitely many groups, without dependence on any memory size. -/
theorem ghost_group_product_bound {ι : Type*} (I : Finset ι)
    (rows exponents : ι → ℝ) (hrows0 : ∀ i ∈ I, 0 ≤ rows i)
    (hrows : ∀ i ∈ I, rows i ≤ Real.exp (exponents i)) :
    (∏ i ∈ I, rows i) ≤ Real.exp (∑ i ∈ I, exponents i) := by
  rw [Real.exp_sum]
  exact Finset.prod_le_prod₀ hrows0 hrows

end Elliptic.Operator
