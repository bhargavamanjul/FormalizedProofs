module

public import Elliptic.Operator.RootSourceScale

/-!
# Numeric active records with the actual fresh-prime alphabets

An active label list can be encoded by integers without replacing the
fresh-prime alphabets used in the promoted second test. This separation
is essential: extending the probability weights by zero alone would not
preserve the set of promotion products.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordGood
open RootArchimedeanGrid RootPhysicalCell RootBoundaryCover RootGoodBoundary
open RootEndpointBudget RootGoodProductBounds RootPhaseMeasure RootLiteralGeometry
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def numericValue (K Q : ℕ) : (i : Fin K)→Fin Q→ℕ := fun _ p=>p.val

def freshGood (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (q : RootPoint) (z : ℤ×ℤ)
    (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) : Prop :=
  sourceTests value (activeLabel (numericValue K Q) a) μ d₀ Y L exponents
    (phase z (chosenComplement z) q.2.2)

theorem freshGood_measurable (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (z : ℤ×ℤ)
    (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) :
    MeasurableSet {q : RootPoint | freshGood value μ d₀ Y L exponents q z a} :=
  (RootGoodMeasurable.bothGoodTests_root_measurable value (activeLabel (numericValue K Q) a)
    μ d₀ Y L exponents z (chosenComplement z)).preimage (measurable_snd.comp measurable_snd)

theorem projectedGood_constant (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z : ℤ×ℤ) (hz : z∈integerPositionBox R)
    (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    (sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z ∧
      freshGood value μ d₀ Y L exponents p z a) ↔
    (sourcePhysicalPositionAllowed (U*q.1) (V*q.2.1) q.2.2 U V z ∧
      freshGood value μ d₀ Y L exponents q z a) := by
  have hphys := source_allowed_constant_of_outside n j hj (integerPositionBox R)
    (sourceEndpoints (J:=J) R Q Y L exponents) U V hU hV hout z hz p q hp hq
  by_cases hpa : sourcePhysicalPositionAllowed (U*p.1) (V*p.2.1) p.2.2 U V z
  · exact and_congr hphys (sourceTests_constant_at_physical value μ R Q hQ hv d₀ Y L exponents
      hY n j hj U V hU hV hout z hz (activeLabel (numericValue K Q) a)
      (fun ij=>(a ij.1 ij.2).isLt.le) p q hp hq hpa)
  · have hqa := mt hphys.mpr hpa
    simp [hpa,hqa]

theorem edge_geometry_constant (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R : ℕ) (hQ : 1≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : Y^(1/5:ℝ)≤(Q^(2*K):ℝ))
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z w : ℤ×ℤ) (hz : z∈integerPositionBox R) (hw : w∈integerPositionBox R)
    (a b : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    sourcePhysicalEdgeGeometry (numericValue K Q) (freshGood value μ d₀ Y L exponents p)
      (U*p.1) (V*p.2.1) p.2.2 U V d₀ Y η ψ major σ z a w b =
    sourcePhysicalEdgeGeometry (numericValue K Q) (freshGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b := by
  have hza := projectedGood_constant value μ R hQ hv d₀ Y L exponents hY n j hj U V hU hV
    hout z hz a p q hp hq
  have hwb := projectedGood_constant value μ R hQ hv d₀ Y L exponents hY n j hj U V hU hV
    hout w hw b p q hp hq
  have he : sourcePhysicalEdgeAllowed (numericValue K Q) (freshGood value μ d₀ Y L exponents p)
      (U*p.1) (V*p.2.1) p.2.2 U V d₀ z a w b ↔
    sourcePhysicalEdgeAllowed (numericValue K Q) (freshGood value μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ z a w b := by
    constructor
    · rintro ⟨hzp,hwp,hzg,hwg,hrest⟩
      exact ⟨(hza.mp ⟨hzp,hzg⟩).1,(hwb.mp ⟨hwp,hwg⟩).1,
        (hza.mp ⟨hzp,hzg⟩).2,(hwb.mp ⟨hwp,hwg⟩).2,hrest⟩
    · rintro ⟨hzp,hwp,hzg,hwg,hrest⟩
      exact ⟨(hza.mpr ⟨hzp,hzg⟩).1,(hwb.mpr ⟨hwp,hwg⟩).1,
        (hza.mpr ⟨hzp,hzg⟩).2,(hwb.mpr ⟨hwp,hwg⟩).2,hrest⟩
  unfold sourcePhysicalEdgeGeometry
  rw [propext he]

def freshGeometry (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z : ℤ×ℤ)
    (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) (w : ℤ×ℤ)
    (b : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) (q : RootPoint) : ℂ :=
  orientedSourceEdgeGeometry adjoint (numericValue K Q) (freshGood value μ d₀ Y L exponents q)
    (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y η ψ major σ z a w b

theorem freshGeometry_measurable (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (z : ℤ×ℤ)
    (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) (w : ℤ×ℤ)
    (b : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) :
    Measurable (freshGeometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b) :=
  RootSourceGeometry.oriented_geometry_measurable (numericValue K Q) (freshGood value μ d₀ Y L exponents)
    (freshGood_measurable value μ d₀ Y L exponents) adjoint U V d₀ Y η ψ major σ z w a b

theorem freshGeometry_constant (adjoint : Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (R : ℕ) (hK : 1≤K) (hQ : 2≤Q) (hv : ∀i p,value i p≤Q)
    (d₀ Y L : ℝ) (exponents : Fin K→ℝ) (hY : 1≤Y)
    (n : ℕ) (j : Index) (hj : j∈grid n) (U V : ℝ) (hU : 0<U) (hV : 0<V)
    (η ψ : ℝ→ℂ) (hsupport : ∀t,η t≠0→1/2≤t) (major : Set ProductCircle) (σ : ℤ)
    (hout : j∉combinedFaces n (integerPositionBox R) U V (sourceEndpoints (J:=J) R Q Y L exponents))
    (z w : ℤ×ℤ) (hz : z∈integerPositionBox R) (hw : w∈integerPositionBox R)
    (a b : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J)
    (p q : RootPoint) (hp : Contains n j p) (hq : Contains n j q) :
    freshGeometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b p =
      freshGeometry adjoint value μ U V d₀ Y L exponents η ψ major σ z a w b q := by
  by_cases hscale : Y^(1/5:ℝ)≤(Q^(2*K):ℝ)
  · cases adjoint
    · exact edge_geometry_constant value μ R (by omega) hv d₀ Y L exponents hscale n j hj U V hU hV
        η ψ major σ hout z w hz hw a b p q hp hq
    · apply congrArg star
      exact edge_geometry_constant value μ R (by omega) hv d₀ Y L exponents hscale n j hj U V hU hV
        η ψ major σ hout w z hw hz b a p q hp hq
  · have he (a : PhysicalActiveLists (fun _ : Fin K=>Fin Q) J) :
        η ((sourceUnsharedProduct (numericValue K Q) a:ℝ)/Y)=0 := by
      by_contra hn
      exact hscale (RootSourceScale.cutoff_nonzero_scale (numericValue K Q) Q hK hQ
        (fun _ p=>p.isLt.le) Y hY η hsupport a hn)
    cases adjoint <;> simp [freshGeometry,orientedSourceEdgeGeometry,sourcePhysicalEdgeGeometry,he]

end Elliptic.Operator.RootRecordGood
