module

public import Elliptic.Operator.SourceGoodState
public import Elliptic.Operator.RootGoodBoundary
public import Elliptic.Operator.IntegerRootReplacement

/-!
# Short integral complements for the actual root phases

The determinant-one complement is constructed from the previously proved
nearest-integer lattice reduction. Its size is controlled by the position
size, rather than supplied as an independent root-grid hypothesis.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootShortComplement
open SourceGoodState
attribute [local instance] Classical.propDecidable

theorem height_zero_one (z : ℤ × ℤ) :
    height 0 1 z = max |(z.1 : ℝ)| |(z.2 : ℝ)| := by
  simp [height]

theorem height_zero_one_ge_one (z : ℤ × ℤ) (hz : z ≠ (0,0)) :
    1 ≤ height 0 1 z := by
  rw [height_zero_one]
  by_cases h1 : z.1 = 0
  · have h2 : z.2 ≠ 0 := by intro h2; exact hz (Prod.ext h1 h2)
    have h : (1:ℝ) ≤ |(z.2:ℝ)| := by exact_mod_cast Int.one_le_abs h2
    exact h.trans (le_max_right _ _)
  · have h : (1:ℝ) ≤ |(z.1:ℝ)| := by exact_mod_cast Int.one_le_abs h1
    exact h.trans (le_max_left _ _)

/-- Every primitive vector has an actual integral complement whose two
coordinates are bounded by one plus its supremum norm. -/
theorem exists_short (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) :
    ∃ w : ℤ × ℤ, latticeDet z w = 1 ∧
      |(w.1:ℝ)| ≤ 1 + max |(z.1:ℝ)| |(z.2:ℝ)| ∧
      |(w.2:ℝ)| ≤ 1 + max |(z.1:ℝ)| |(z.2:ℝ)| := by
  obtain ⟨w,hw,hb⟩ := exists_reduced_complement 0 1 (by norm_num) z hz
  have hz0 : z ≠ (0,0) := by intro he; simp [he,latticeDet] at hw
  have hl := height_zero_one_ge_one z hz0
  have hlp : 0 < height 0 1 z := by linarith
  have hsize : (1/(1:ℝ)+(height 0 1 z)^2/2)/(height 0 1 z) ≤ 1+height 0 1 z := by
    apply (div_le_iff₀ hlp).mpr
    have hs := sq_nonneg (height 0 1 z)
    norm_num
    nlinarith
  have hmax := hb.trans hsize
  rw [height_zero_one, height_zero_one] at hmax
  exact ⟨w,hw,(le_max_left _ _).trans hmax,(le_max_right _ _).trans hmax⟩

/-- A canonical choice can now be used across all finite position paths. -/
def complement (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) : ℤ × ℤ :=
  Classical.choose (exists_short z hz)

theorem complement_spec (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2) :
    latticeDet z (complement z hz) = 1 ∧
      |((complement z hz).1:ℝ)| ≤ 1 + max |(z.1:ℝ)| |(z.2:ℝ)| ∧
      |((complement z hz).2:ℝ)| ≤ 1 + max |(z.1:ℝ)| |(z.2:ℝ)| :=
  Classical.choose_spec (exists_short z hz)

theorem complement_coordinate_bound (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2)
    (R : ℝ) (h1 : |(z.1:ℝ)| ≤ R) (h2 : |(z.2:ℝ)| ≤ R) :
    |((complement z hz).1:ℝ)| ≤ 1+R ∧
      |((complement z hz).2:ℝ)| ≤ 1+R := by
  have h := complement_spec z hz
  exact ⟨h.2.1.trans (by gcongr; exact max_le h1 h2),
    h.2.2.trans (by gcongr; exact max_le h1 h2)⟩

theorem phase_bound (z : ℤ × ℤ) (hz : IsCoprime z.1 z.2)
    (R r : ℝ) (h1 : |(z.1:ℝ)| ≤ R) (h2 : |(z.2:ℝ)| ≤ R)
    (hr : 0≤r) (hr' : r≤1) (ht : 1/16 ≤ latticeTau r z) :
    |RootGoodBoundary.phase z (complement z hz) r| ≤ 32*(1+R) := by
  have hw := complement_coordinate_bound z hz R h1 h2
  have hp := RootGoodBoundary.phase_bound z (complement z hz) r hr hr' ht
  linarith

end Elliptic.Operator.RootShortComplement
