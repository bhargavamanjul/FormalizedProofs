module

public import Elliptic.Operator.GroupedMemoryGhost

/-!
# Actual history truncation and doubled births

The cutoff is an actual projection at every state of the chronological
choice word. Its complement is exactly the sum of histories which exceed
that cutoff. Size accounting, rather than an assumed truncation estimate,
supplies the power of two in the tail bound. The absolute doubled-birth
history sum on the right still requires a separate analytic bound.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

namespace ChoiceOperation
variable {X : Type*}

/-- Inserting the literal state-size projection at every stage, including
the two endpoints. -/
def cutoffWordApply (size : X → ℕ) (T : ℕ) :
    List (ChoiceOperation X) → (X → ℂ) → X → ℂ
  | [], F, x => if size x ≤ T then F x else 0
  | O :: ops, F, x =>
      if size x ≤ T then O.apply (cutoffWordApply size T ops F) x else 0

theorem cutoffWordApply_eq_history_sum (size : X → ℕ) (T : ℕ)
    (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X) :
    cutoffWordApply size T ops F x =
      ∑ h : History ops x, if h.peakSize size ≤ T then h.weight * F h.final else 0 := by
  induction ops generalizing x with
  | nil =>
      simp only [cutoffWordApply, History.peakSize, History.weight, History.final, one_mul,
        Finset.sum_const, Finset.card_univ, Fintype.card_unique, one_nsmul]
  | cons O ops ih =>
      change (if size x ≤ T then
          ∑ c : O.ValidChoice x, O.coefficient x c.val *
            cutoffWordApply size T ops F (O.output x c.val c.property) else 0) =
        ∑ h : (Σ c : O.ValidChoice x, History ops (O.output x c.val c.property)),
          if max (size x) (h.2.peakSize size) ≤ T then
            O.coefficient x h.1.val * h.2.weight * F h.2.final else 0
      rw [Fintype.sum_sigma]
      by_cases hx : size x ≤ T
      · simp only [hx, ↓reduceIte, max_le_iff, true_and]
        apply Finset.sum_congr rfl
        intro c hc
        rw [ih, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro h hh
        split_ifs <;> simp [mul_assoc]
      · simp [hx, max_le_iff]

/-- Exact removal of the retained histories; no triangle inequality yet. -/
theorem word_sub_cutoff_eq_tail (size : X → ℕ) (T : ℕ)
    (ops : List (ChoiceOperation X)) (F : X → ℂ) (x : X) :
    wordApply ops F x - cutoffWordApply size T ops F x =
      ∑ h : History ops x, if T < h.peakSize size then h.weight * F h.final else 0 := by
  rw [wordApply_eq_history_sum, cutoffWordApply_eq_history_sum, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro h hh
  by_cases hp : h.peakSize size ≤ T
  · simp [hp, Nat.not_lt.mpr hp]
  · simp [hp, Nat.lt_of_not_ge hp]

/-- The literal absolute majorant with each actual ghost birth doubled. -/
def doubledBirthWord : List (ChoiceOperation X) → (X → ℝ) → X → ℝ
  | [], F => F
  | O :: ops, F => fun x => ∑ c : O.ValidChoice x,
      (2:ℝ)^(O.ghostBirths x c.val) * ‖O.coefficient x c.val‖ *
        doubledBirthWord ops F (O.output x c.val c.property)

theorem doubledBirthWord_eq_history_sum (ops : List (ChoiceOperation X))
    (F : X → ℝ) (x : X) :
    doubledBirthWord ops F x =
      ∑ h : History ops x, (2:ℝ)^h.ghostBirths * ‖h.weight‖ * F h.final := by
  induction ops generalizing x with
  | nil => simp [doubledBirthWord, History.ghostBirths, History.weight, History.final,
      Fintype.card_unique]
  | cons O ops ih =>
      change (∑ c : O.ValidChoice x,
        (2:ℝ)^(O.ghostBirths x c.val) * ‖O.coefficient x c.val‖ *
          doubledBirthWord ops F (O.output x c.val c.property)) =
        ∑ h : (Σ c : O.ValidChoice x, History ops (O.output x c.val c.property)),
          (2:ℝ)^(O.ghostBirths x h.1.val + h.2.ghostBirths) *
            ‖O.coefficient x h.1.val * h.2.weight‖ * F h.2.final
      rw [Fintype.sum_sigma]
      apply Finset.sum_congr rfl
      intro c hc
      rw [ih, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro h hh
      rw [pow_add, norm_mul]
      ring

/-- Actual tail bound for literal operations whose output-size growth is
paid for by the two counters. The doubled-birth word is not replaced by an
assumed small error. -/
theorem norm_word_sub_cutoff_le_doubledBirthWord
    (size : X → ℕ) (T S : ℕ) (ops : List (ChoiceOperation X))
    (hstep : ∀ O ∈ ops, ∀ x (c : O.ValidChoice x),
      size (O.output x c.val c.property) ≤
        size x + O.ghostBirths x c.val + O.stores x c.val)
    (F : X → ℂ) (x : X) (hzero : size x=0)
    (hstores : ∀ h : History ops x, h.stores≤S) (hST : S≤T) :
    ‖wordApply ops F x - cutoffWordApply size T ops F x‖ ≤
      ((2:ℝ)^(T-S))⁻¹ * doubledBirthWord ops (fun y => ‖F y‖) x := by
  rw [word_sub_cutoff_eq_tail, doubledBirthWord_eq_history_sum, Finset.mul_sum]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro h hh
  have hnonneg : 0 ≤ (2:ℝ)^h.ghostBirths * ‖h.weight‖ * ‖F h.final‖ :=
    mul_nonneg (mul_nonneg (by positivity) (norm_nonneg _)) (norm_nonneg _)
  by_cases hp : T < h.peakSize size
  · simp only [hp, ↓reduceIte, norm_mul]
    have hg := h.ghostBirths_large_of_peak size ops hstep x T S hzero (hstores h) hST hp
    have hpowers : (2:ℝ)^(T-S) ≤ (2:ℝ)^h.ghostBirths :=
      pow_le_pow_right₀ (by norm_num) hg.le
    have hdiv : (1:ℝ) ≤ ((2:ℝ)^(T-S))⁻¹ * (2:ℝ)^h.ghostBirths := by
      exact (one_le_inv_mul₀ (by positivity)).mpr hpowers
    calc
      _ = 1 * (‖h.weight‖ * ‖F h.final‖) := by ring
      _ ≤ (((2:ℝ)^(T-S))⁻¹ * (2:ℝ)^h.ghostBirths) *
          (‖h.weight‖ * ‖F h.final‖) :=
        mul_le_mul_of_nonneg_right hdiv (mul_nonneg (norm_nonneg _) (norm_nonneg _))
      _ = _ := by ring
  · simp only [hp, ↓reduceIte, norm_zero]
    exact mul_nonneg (by positivity) hnonneg

end ChoiceOperation

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

/-- The actual chronological word, with time-dependent ghost deficits
and physical edge geometry. -/
def physicalMemoryOperations (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (η q : ℕ → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N : ℕ) : List (ChoiceOperation (PhysicalMemoryState (Z:=Z) P Line J B)) :=
  memoryOperationsFrom
    (fun j => physicalGhostOperation ν V (η j) (q j) ρ anchor)
    (fun j => physicalEdgeOperation ν V ρ anchor (geometry j)) 0 N

theorem physical_history_stores_le (ν : ∀ i, P i → ℝ) (V : I → ℝ)
    (η q : ℕ → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    h.stores ≤ Fintype.card I * N := by
  exact history_stores_le_edges _ _ (Fintype.card I)
    (by intros; rfl) (fun _ s c => physicalEdgeOperation_stores_le ν V ρ anchor _ s c)
    0 N s h

/-- The source cutoff suppression for the actual grouped ghost/edge
choices, including the total-memory cutoff in their validity predicates. -/
theorem physical_memory_truncation_bound
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (N T : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (hempty : physicalMemorySize s=0) (hT : Fintype.card I*N≤T) :
    ‖ChoiceOperation.wordApply (physicalMemoryOperations ν V η q ρ anchor geometry N) F s -
      ChoiceOperation.cutoffWordApply physicalMemorySize T
        (physicalMemoryOperations ν V η q ρ anchor geometry N) F s‖ ≤
      ((2:ℝ)^(T-Fintype.card I*N))⁻¹ *
        ChoiceOperation.doubledBirthWord
          (physicalMemoryOperations ν V η q ρ anchor geometry N) (fun y => ‖F y‖) s := by
  apply ChoiceOperation.norm_word_sub_cutoff_le_doubledBirthWord
    physicalMemorySize T (Fintype.card I*N) _ _ F s hempty _ hT
  · exact memoryOperationsFrom_step_size physicalMemorySize _ _
      (fun _ s c => physicalGhostOperation_size ν V _ _ ρ anchor s c)
      (fun _ s c => physicalEdgeOperation_size ν V ρ anchor _ s c) 0 N
  · exact physical_history_stores_le ν V η q ρ anchor geometry N s

end Elliptic.Operator
