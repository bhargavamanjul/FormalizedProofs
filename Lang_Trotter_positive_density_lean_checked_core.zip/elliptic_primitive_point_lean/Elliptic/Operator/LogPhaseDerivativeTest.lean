module

public import Elliptic.Operator.ClassicalDerivativeTest

/-!
# Literal logarithmic progressions and the classical derivative test

The derivatives are computed here. Only the generic fixed-order classical
estimate, separately named in ClassicalDerivativeTest, is an external input.
Its constant is chosen before the progression, length and frequency.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.LogPhaseDerivativeTest
open scoped BigOperators
open Set ClassicalDerivativeTest LogPhaseProgression
set_option backward.isDefEq.respectTransparency false

def jet (a q t : ℝ) : ℕ→ℝ→ℝ
  | 0 => fun y=>t/(2*Real.pi)*Real.log (a+q*y)
  | j+1 => fun y=>t/(2*Real.pi)*(-1)^j*(j.factorial:ℝ)*q^(j+1)/(a+q*y)^(j+1)

theorem jet_derivative (a q t y : ℝ) (hy : a+q*y≠0) (j : ℕ) :
    HasDerivAt (jet a q t j) (jet a q t (j+1) y) y := by
  have haff : HasDerivAt (fun z:ℝ=>a+q*z) q y := by
    simpa using ((hasDerivAt_id y).const_mul q).const_add a
  cases j with
  | zero =>
    have h := (haff.log hy).const_mul (t/(2*Real.pi))
    simpa [jet,div_eq_mul_inv,mul_assoc] using h
  | succ j =>
    have h := (haff.pow (j+1)).inv (pow_ne_zero _ hy)
    have hc := h.const_mul (t/(2*Real.pi)*(-1)^j*(j.factorial:ℝ)*q^(j+1))
    convert hc using 1
    · funext z
      simp only [jet,div_eq_mul_inv,Pi.inv_apply,Pi.pow_apply]
    · simp only [jet,Nat.add_sub_cancel,Nat.factorial_succ,Nat.cast_mul,Nat.cast_add,Nat.cast_one,
        Pi.pow_apply,Pi.inv_apply]
      field_simp
      ring

theorem jet_continuousOn (a q t : ℝ) (M : ℕ) (ha : 0<a) (hq : 0≤q) (j : ℕ) :
    ContinuousOn (jet a q t j) (Icc (0:ℝ) M) := by
  intro y hy
  exact (jet_derivative a q t y (ne_of_gt (by nlinarith [mul_nonneg hq hy.1])) j).continuousAt.continuousWithinAt

theorem phase_eq_jet (a q t y : ℝ) :
    phase t (a+q*y)=Complex.exp (Complex.I*((2*Real.pi*jet a q t 0 y:ℝ):ℂ)) := by
  unfold phase jet
  congr 2
  field_simp

theorem jet_abs (a q t y : ℝ) (k : ℕ) (hk : 1≤k)
    (hq : 0≤q) (hy : 0<a+q*y) :
    |jet a q t k y|=|t|/(2*Real.pi)*((k-1).factorial:ℝ)*q^k/(a+q*y)^k := by
  obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k≠0)
  simp only [jet,Nat.succ_eq_add_one,abs_div,abs_mul,abs_pow,abs_neg,abs_one,one_pow,mul_one,
    Nat.add_sub_cancel,abs_of_nonneg (show (0:ℝ)≤j.factorial from Nat.cast_nonneg _),
    abs_of_nonneg hq,abs_of_pos hy,abs_of_pos Real.pi_pos,abs_of_pos (by norm_num : (0:ℝ)<2)]

def lowerDerivative (k : ℕ) (a q t : ℝ) : ℝ :=
  |t|/(2*Real.pi)*((k-1).factorial:ℝ)*q^k/(2*a)^k

theorem jet_bounds (k M : ℕ) (hk : 1≤k) (a q t : ℝ)
    (ha : 0<a) (hq : 0≤q) (hqa : q*(M:ℝ)≤a)
    (y : ℝ) (hy : y∈Icc (0:ℝ) M) :
    lowerDerivative k a q t≤|jet a q t k y| ∧
      |jet a q t k y|≤(2:ℝ)^k*lowerDerivative k a q t := by
  have hay : 0<a+q*y := by nlinarith [mul_nonneg hq hy.1]
  have hlow : a≤a+q*y := by nlinarith [mul_nonneg hq hy.1]
  have hhigh : a+q*y≤2*a := by nlinarith [mul_le_mul_of_nonneg_left hy.2 hq]
  rw [jet_abs a q t y k hk hq hay]
  let c := |t|/(2*Real.pi)*((k-1).factorial:ℝ)*q^k
  have hc : 0≤c := by dsimp [c]; positivity
  constructor
  · exact div_le_div_of_nonneg_left hc (pow_pos hay k) (pow_le_pow_left₀ hay.le hhigh k)
  · calc
      c/(a+q*y)^k ≤ c/a^k := div_le_div_of_nonneg_left hc (pow_pos ha k)
        (pow_le_pow_left₀ ha.le hlow k)
      _ = (2:ℝ)^k*lowerDerivative k a q t := by
        unfold lowerDerivative
        rw [mul_pow]
        dsimp [c]
        field_simp

/-- The fixed-order bound for the literal progression, with the constant
chosen before its length, residue, spacing, and frequency. -/
theorem progression_derivative_bound (hvdC : FixedOrderDerivativeTest)
    (k : ℕ) (hk : 2≤k) : ∃ C : ℝ, 0<C ∧
    ∀ M : ℕ, 1≤M → ∀ a q t : ℝ, 0<a → 0<q → q*(M:ℝ)≤a → t≠0 →
    ‖∑n∈Finset.range M,phase t (a+q*n)‖≤
      C*((M:ℝ)*(lowerDerivative k a q t)^(exponent k)+
        (M:ℝ)^(secondaryExponent k)*(lowerDerivative k a q t)^(-exponent k)) := by
  obtain ⟨C,hC,hbound⟩ := hvdC k hk ((2:ℝ)^k) (one_le_pow₀ (by norm_num))
  refine ⟨C,hC,?_⟩
  intro M hM a q t ha hq hqa ht
  have hpos : 0<lowerDerivative k a q t := by
    unfold lowerDerivative
    have hf : (0:ℝ)<(k-1).factorial := by exact_mod_cast Nat.factorial_pos (k-1)
    have ht' := abs_pos.mpr ht
    positivity
  simp_rw [phase_eq_jet]
  apply hbound M hM (jet a q t) _ hpos
  · intro j hj
    exact jet_continuousOn a q t M ha hq.le j
  · intro j hj y hy
    exact jet_derivative a q t y (ne_of_gt (by nlinarith [mul_nonneg hq.le hy.1])) j
  · intro y hy
    exact jet_bounds k M (by omega) a q t ha hq.le hqa y hy

end Elliptic.Operator.LogPhaseDerivativeTest
