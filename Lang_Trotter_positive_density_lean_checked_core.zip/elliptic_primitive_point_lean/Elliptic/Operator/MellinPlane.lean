module

public import Elliptic.Operator.MellinModulationBounds
public import Mathlib.MeasureTheory.Constructions.Pi
public import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
public import Mathlib.MeasureTheory.Integral.Prod

/-!
# Exact two-dimensional Mellin coordinates and normalization

Fourier inversion on the literal smooth compact determinant profile is
proved using mathlib's Schwartz Fourier equivalence. Coordinate changes
retain the factor X⁻¹ and both factors 2π explicitly.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinPlane
open MeasureTheory FourierTransform
open scoped SchwartzMap BigOperators
set_option backward.isDefEq.respectTransparency false

abbrev Plane := EuclideanSpace ℝ (Fin 2)
def vec (v s : ℝ) : Plane := WithLp.toLp 2 ![v,s]
def coordinates : Plane≃ᵐ(ℝ×ℝ) :=
  (MeasurableEquiv.toLp 2 (Fin 2→ℝ)).symm.trans MeasurableEquiv.finTwoArrow

theorem coordinates_preserving : MeasurePreserving coordinates volume volume :=
  (volume_preserving_finTwoArrow ℝ).comp (PiLp.volume_preserving_ofLp (Fin 2))

theorem coordinates_symm (v s : ℝ) : coordinates.symm (v,s)=vec v s := rfl

def coordinateHomeomorph : Plane≃ₜ(ℝ×ℝ) :=
  (PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin 2=>ℝ)).toHomeomorph.trans (Homeomorph.piFinTwo (fun _=>ℝ))

theorem inner_vec (v s ζ z : ℝ) : inner ℝ (vec v s) (vec ζ z)=v*ζ+s*z := by
  rw [PiLp.inner_apply]
  simp [vec,Fin.sum_univ_two,real_inner_comm,mul_comm]

/-- Product Lebesgue measure is the actual Euclidean Fourier measure. -/
theorem plane_integral (f : Plane→ℂ) (hf : Integrable f) :
    (∫w:Plane,f w)=∫v:ℝ,∫s:ℝ,f (vec v s) := by
  have h := coordinates_preserving.symm.integral_comp' f
  rw [←h]
  apply integral_prod
  exact coordinates_preserving.symm.integrable_comp_of_integrable hf

/-- Inversion with the standard 2π convention, before frequency rescaling. -/
theorem schwartz_inversion (F : 𝓢(Plane,ℂ)) (ζ z : ℝ) :
    F (vec ζ z)=∫v:ℝ,∫s:ℝ,
      (𝓕 F) (vec v s)*Complex.exp (Complex.I*((2*Real.pi*(v*ζ+s*z):ℝ):ℂ)) := by
  have hinv := congrArg (fun G:𝓢(Plane,ℂ)=>G (vec ζ z)) (fourierInv_fourier_eq (F:=𝓢(Plane,ℂ)) F)
  rw [SchwartzMap.fourierInv_coe,Real.fourierInv_eq'] at hinv
  have hphase : Integrable (fun w:Plane=>Complex.exp (((2*Real.pi*inner ℝ w (vec ζ z):ℝ):ℂ)*Complex.I)*(𝓕 F) w) := by
    apply ((𝓕 F).integrable (μ:=volume)).bdd_mul (c:=1)
    · apply Continuous.aestronglyMeasurable
      fun_prop
    · filter_upwards [] with w
      rw [mul_comm,Complex.norm_exp_I_mul_ofReal]
  simp only [smul_eq_mul] at hinv
  rw [plane_integral _ hphase] at hinv
  symm at hinv
  apply hinv.trans
  apply integral_congr_ae
  filter_upwards [] with v
  apply integral_congr_ae
  filter_upwards [] with s
  rw [inner_vec]
  have he : Complex.exp (((2*Real.pi*(v*ζ+s*z):ℝ):ℂ)*Complex.I)=
      Complex.exp (Complex.I*((2*Real.pi*(v*ζ+s*z):ℝ):ℂ)) := by congr 1; ring
  rw [he,mul_comm]

/-- Exact change of both real frequency variables. -/
theorem rescale_double_integral (g : ℝ→ℝ→ℂ) (c d : ℝ) (hc : 0<c) (hd : 0<d) :
    (∫t:ℝ,∫s:ℝ,g (t/c) (s/d))=((c*d:ℝ):ℂ)*(∫v:ℝ,∫s:ℝ,g v s) := by
  have hi (t:ℝ) : (∫s:ℝ,g (t/c) (s/d))=(d:ℂ)*(∫s:ℝ,g (t/c) s) := by
    have h := Measure.integral_comp_mul_right (g (t/c)) d⁻¹
    simpa only [div_eq_mul_inv,inv_inv,abs_of_pos hd,Complex.real_smul] using h
  simp_rw [hi]
  rw [integral_const_mul]
  have ho := Measure.integral_comp_mul_right (fun v:ℝ=>∫s:ℝ,g v s) c⁻¹
  have ho' : (∫t:ℝ,∫s:ℝ,g (t/c) s)=(c:ℂ)*(∫v:ℝ,∫s:ℝ,g v s) := by
    simpa only [div_eq_mul_inv,inv_inv,abs_of_pos hc,Complex.real_smul] using ho
  rw [ho']
  push_cast
  ring

/-- Fourier normalization used by the manuscript's two-dimensional Mellin kernel. -/
def mellinKernel (F : 𝓢(Plane,ℂ)) (v s : ℝ) : ℂ :=
  (((2*Real.pi)^2:ℝ):ℂ)⁻¹*(𝓕 F) (vec (v/(2*Real.pi)) (s/(2*Real.pi)))

/-- Exact X⁻¹ Jacobian in the two-dimensional Mellin separation. -/
theorem schwartz_mellin_inversion (F : 𝓢(Plane,ℂ)) (X ζ z : ℝ) (hX : 0<X) :
    F (vec ζ z)=(X:ℂ)⁻¹*(∫t:ℝ,∫s:ℝ,mellinKernel F (t/X) s*
      Complex.exp (Complex.I*((t*ζ/X+s*z:ℝ):ℂ))) := by
  let r : ℝ := 2*Real.pi
  have hr : 0<r := by dsimp [r]; positivity
  let g : ℝ→ℝ→ℂ := fun v s=>(𝓕 F) (vec v s)*Complex.exp (Complex.I*((r*(v*ζ+s*z):ℝ):ℂ))
  have hi : F (vec ζ z)=∫v:ℝ,∫s:ℝ,g v s := schwartz_inversion F ζ z
  have hs := rescale_double_integral g (r*X) r (mul_pos hr hX) hr
  have he (t s:ℝ) : mellinKernel F (t/X) s*Complex.exp (Complex.I*((t*ζ/X+s*z:ℝ):ℂ))=
      (((r^2:ℝ):ℂ)⁻¹)*g (t/(r*X)) (s/r) := by
    unfold mellinKernel
    dsimp [g]
    have harg : t/X/r=t/(r*X) := by field_simp
    rw [harg]
    have hp : t*ζ/X+s*z=r*(t/(r*X)*ζ+s/r*z) := by field_simp
    rw [hp]
    dsimp [r]
    ring
  simp_rw [he]
  simp_rw [integral_const_mul]
  rw [hs,←hi]
  have hrC : (r:ℂ)≠0 := by exact_mod_cast hr.ne'
  have hXC : (X:ℂ)≠0 := by exact_mod_cast hX.ne'
  push_cast
  field_simp

/-- The literal profile in coordinates ζ=X log(w/w′), z=log w′. -/
def determinantProfile (ψ ρ σ : ℝ→ℂ) (X lam : ℝ) (u : Plane) : ℂ :=
  ρ (u 0)*σ (u 1)*ψ (X*Real.exp (u 1)*(Real.exp (u 0/X)-1))*
    Elliptic.SourceContracts.additivePhase (lam*(X*Real.exp (u 1)*(Real.exp (u 0/X)-1)))

theorem determinantProfile_smooth (ψ ρ σ : ℝ→ℂ)
    (hψ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ψ)
    (hρ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ρ)
    (hσ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) σ) (X lam : ℝ) :
    ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (determinantProfile ψ ρ σ X lam) := by
  have hc0 : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun u:Plane=>u 0) :=
    (contDiff_apply ℝ (fun _:Fin 2=>ℝ) 0).comp (EuclideanSpace.equiv (Fin 2) ℝ).contDiff
  have hc1 : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) (fun u:Plane=>u 1) :=
    (contDiff_apply ℝ (fun _:Fin 2=>ℝ) 1).comp (EuclideanSpace.equiv (Fin 2) ℝ).contDiff
  have hr : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞)
      (fun u:Plane=>X*Real.exp (u 1)*(Real.exp (u 0/X)-1)) := by fun_prop
  have ha := ((hρ.comp hc0).mul (hσ.comp hc1)).mul (hψ.comp hr)
  have hpR : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞)
      (fun u:Plane=>2*Real.pi*(lam*(X*Real.exp (u 1)*(Real.exp (u 0/X)-1)))) := by fun_prop
  have hp := Complex.ofRealCLM.contDiff.comp hpR
  exact ha.mul ((hp.mul contDiff_const).cexp)

theorem determinantProfile_compact (ψ ρ σ : ℝ→ℂ)
    (hρ : HasCompactSupport ρ) (hσ : HasCompactSupport σ) (X lam : ℝ) :
    HasCompactSupport (determinantProfile ψ ρ σ X lam) := by
  apply HasCompactSupport.of_support_subset_isCompact
    (coordinateHomeomorph.isCompact_preimage.mpr (hρ.isCompact.prod hσ.isCompact))
  intro u hu
  change u 0∈tsupport ρ ∧ u 1∈tsupport σ
  have hne : determinantProfile ψ ρ σ X lam u≠0 := hu
  unfold determinantProfile at hne
  have hρne : ρ (u 0)≠0 := by intro hh; simp [hh] at hne
  have hσne : σ (u 1)≠0 := by intro hh; simp [hh] at hne
  exact ⟨subset_tsupport _ hρne,subset_tsupport _ hσne⟩

def determinantSchwartz (ψ ρ σ : ℝ→ℂ)
    (hψ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ψ)
    (hρ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ρ)
    (hσ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) σ)
    (hcρ : HasCompactSupport ρ) (hcσ : HasCompactSupport σ) (X lam : ℝ) : 𝓢(Plane,ℂ) :=
  (determinantProfile_compact ψ ρ σ hcρ hcσ X lam).toSchwartzMap
    (determinantProfile_smooth ψ ρ σ hψ hρ hσ X lam)

/-- The coordinate profile agrees with the original determinant kernel
where the inserted fixed cutoffs equal one. -/
theorem determinantProfile_eval (ψ ρ σ : ℝ→ℂ) (X lam w w' : ℝ)
    (hX : 0<X) (hw : 0<w) (hw' : 0<w')
    (hρ : ρ (X*Real.log (w/w'))=1) (hσ : σ (Real.log w')=1) :
    determinantProfile ψ ρ σ X lam (vec (X*Real.log (w/w')) (Real.log w'))=
      ψ (X*(w-w'))*Elliptic.SourceContracts.additivePhase (lam*(X*(w-w'))) := by
  have hex : X*Real.exp (Real.log w')*(Real.exp (X*Real.log (w/w')/X)-1)=X*(w-w') := by
    rw [Real.exp_log hw',mul_div_cancel_left₀ _ hX.ne',Real.exp_log (div_pos hw hw')]
    field_simp
  dsimp [determinantProfile,vec]
  rw [hρ,hσ,one_mul,one_mul,hex]

/-- The literal two-factor Mellin phase identity, with exact frequency signs. -/
theorem mellin_phase (X w w' t s : ℝ) (hX : 0<X) (hw : 0<w) (hw' : 0<w') :
    Complex.exp (Complex.I*((t*(X*Real.log (w/w'))/X+s*Real.log w':ℝ):ℂ))=
      LogPhaseProgression.phase t w*LogPhaseProgression.phase (s-t) w' := by
  unfold LogPhaseProgression.phase
  rw [←Complex.exp_add,Real.log_div hw.ne' hw'.ne']
  congr 1
  push_cast
  have hXC : (X:ℂ)≠0 := by exact_mod_cast hX.ne'
  field_simp [hXC]
  ring

/-- Exact source equation (5.15) on coefficient support, derived from actual
Schwartz Fourier inversion rather than an assumed Mellin factorization. -/
theorem determinant_mellin_separation (ψ ρ σ : ℝ→ℂ)
    (hψ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ψ)
    (hρ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) ρ)
    (hσ : ContDiff ℝ (↑(⊤:ℕ∞):WithTop ℕ∞) σ)
    (hcρ : HasCompactSupport ρ) (hcσ : HasCompactSupport σ)
    (X lam w w' : ℝ) (hX : 0<X) (hw : 0<w) (hw' : 0<w')
    (hρone : ρ (X*Real.log (w/w'))=1) (hσone : σ (Real.log w')=1) :
    ψ (X*(w-w'))*Elliptic.SourceContracts.additivePhase (lam*(X*(w-w')))=
      (X:ℂ)⁻¹*(∫t:ℝ,∫s:ℝ,
        mellinKernel (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam) (t/X) s*
        LogPhaseProgression.phase t w*LogPhaseProgression.phase (s-t) w') := by
  have h := schwartz_mellin_inversion (determinantSchwartz ψ ρ σ hψ hρ hσ hcρ hcσ X lam)
    X (X*Real.log (w/w')) (Real.log w') hX
  change determinantProfile ψ ρ σ X lam (vec (X*Real.log (w/w')) (Real.log w'))=_ at h
  rw [determinantProfile_eval ψ ρ σ X lam w w' hX hw hw' hρone hσone] at h
  simp_rw [mellin_phase X w w' _ _ hX hw hw',←mul_assoc] at h
  simpa only [mul_assoc] using h

end Elliptic.Operator.MellinPlane
