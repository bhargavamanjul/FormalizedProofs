module

public import Elliptic.Operator.TensorDeterminant
public import Mathlib.Algebra.Field.GeomSum

/-!
# Actual exponential Gram matrices

This module proves cancellation bounds for finite exponential matrices
from their actual geometric sums. The resulting determinant bound has
an explicit scalar reciprocal-distance sum, rather than an assumed
one-dimensional operator estimate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators ComplexConjugate
open Elliptic.SourceContracts

/-- The actual column Gram matrix of a finite complex kernel. -/
def finiteGram {ι κ : Type*} (s : Finset ι) (K : ι → κ → ℂ) (j k : κ) : ℂ :=
  ∑ i ∈ s, conj (K i j) * K i k

theorem finiteGram_conj {ι κ : Type*} (s : Finset ι) (K : ι → κ → ℂ) (j k : κ) :
    conj (finiteGram s K j k) = finiteGram s K k j := by
  simp only [finiteGram, map_sum, map_mul, Complex.conj_conj]
  apply Finset.sum_congr rfl
  intro i hi
  ring

/-- The Gram quadratic form is exactly the output energy. -/
theorem finiteGram_pairing {ι κ : Type*} (s : Finset ι) (t : Finset κ)
    (K : ι → κ → ℂ) (b : κ → ℂ) :
    finiteMeasuredPairing t t (fun _ => 1) (fun _ => 1) (finiteGram s K)
      (fun j => conj (b j)) b =
      (finiteL2Sq s (fun _ => 1) (finiteKernelApply t (fun _ => 1) K b) : ℂ) := by
  calc
    _ = finiteMeasuredPairing s t (fun _ => 1) (fun _ => 1) K
        (fun i => conj (finiteKernelApply t (fun _ => 1) K b i)) b := by
      simp only [finiteMeasuredPairing, finiteKernelApply, finiteGram,
        Complex.ofReal_one, one_mul, Finset.mul_sum, Finset.sum_mul, map_sum, map_mul]
      rw [Finset.sum_comm]
      conv_lhs => arg 2; ext k; rw [Finset.sum_comm]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro i hi
      apply Finset.sum_congr rfl
      intro j hj
      apply Finset.sum_congr rfl
      intro k hk
      ring
    _ = _ := by
      simp [finiteMeasuredPairing, finiteL2Sq, Complex.conj_mul',
        Complex.ofReal_sum, Complex.ofReal_pow]

/-- A row bound for the actual Gram matrix yields its square-root norm
bound. Hermitian symmetry supplies the column bound automatically. -/
theorem finiteKernelBound_of_gram_rows {ι κ : Type*} (s : Finset ι) (t : Finset κ)
    (K : ι → κ → ℂ) (R : ℝ) (hR : 0 ≤ R)
    (hrow : ∀ j ∈ t, ∑ k ∈ t, ‖finiteGram s K j k‖ ≤ R) :
    FiniteKernelBound s t (fun _ => 1) (fun _ => 1) K (Real.sqrt R) := by
  have hcol : ∀ k ∈ t, ∑ j ∈ t, ‖finiteGram s K j k‖ ≤ R := by
    intro k hk
    simpa only [← finiteGram_conj s K k, Complex.norm_conj] using hrow k hk
  have hG : FiniteKernelBound t t (fun _ => 1) (fun _ => 1) (finiteGram s K) R := by
    intro b
    have h := finite_weighted_schur t t (fun _ => 1) (fun _ => 1)
      (fun _ => 1) (fun _ => 1) (finiteGram s K) R R
      (fun _ _ => zero_le_one) (fun _ _ => zero_le_one)
      (fun _ _ => zero_lt_one) (fun _ _ => zero_lt_one) hR hR
      (by simpa using hrow) (by simpa using hcol) b
    simpa only [← pow_two R, Real.sqrt_sq hR] using h
  intro b
  have h := finiteMeasuredBilinearBound_of_kernel_bound t t (fun _ => 1) (fun _ => 1)
    (fun _ _ => zero_le_one) (finiteGram s K) R hG (fun j => conj (b j)) b
  rw [finiteGram_pairing] at h
  have he : finiteL2 t (fun _ => 1) (fun j => conj (b j)) =
      finiteL2 t (fun _ => 1) b := by simp [finiteL2, finiteL2Sq]
  rw [he, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (finiteL2Sq_nonneg s _ (fun _ _ => zero_le_one) _)] at h
  have hs : finiteL2Sq s (fun _ => 1) (finiteKernelApply t (fun _ => 1) K b) ≤
      R * finiteL2Sq t (fun _ => 1) b := by
    calc
      _ ≤ _ := h
      _ = _ := by rw [mul_assoc, finiteL2, Real.mul_self_sqrt
        (finiteL2Sq_nonneg t _ (fun _ _ => zero_le_one) _)]
  exact (Real.sqrt_le_sqrt hs).trans_eq (Real.sqrt_mul hR _)


/-- The usual geometric-series bound, including the resonant case. -/
def geometricPhaseBound (B : ℕ) (θ : ℝ) : ℝ :=
  if additivePhase θ = 1 then B else min (B : ℝ) (2 / ‖additivePhase θ - 1‖)

theorem geometricPhaseBound_nonneg (B : ℕ) (θ : ℝ) :
    0 ≤ geometricPhaseBound B θ := by
  unfold geometricPhaseBound
  split_ifs <;> positivity

theorem additivePhase_nat_mul (θ : ℝ) (n : ℕ) :
    additivePhase (θ * n) = additivePhase θ ^ n := by
  induction n with
  | zero => simp [additivePhase]
  | succ n ih =>
    rw [Nat.cast_add, Nat.cast_one, mul_add, mul_one, additivePhase_add, ih, pow_succ]

theorem geometricPhaseSum_bound (B : ℕ) (θ : ℝ) :
    ‖∑ k ∈ Finset.range B, additivePhase (θ * k)‖ ≤ geometricPhaseBound B θ := by
  have htriv : ‖∑ k ∈ Finset.range B, additivePhase (θ * k)‖ ≤ (B : ℝ) := by
    calc
      _ ≤ ∑ k ∈ Finset.range B, ‖additivePhase (θ * k)‖ := norm_sum_le _ _
      _ = _ := by simp [additivePhase_norm]
  unfold geometricPhaseBound
  split_ifs with h
  · exact htriv
  · apply le_min htriv
    simp_rw [additivePhase_nat_mul]
    rw [geom_sum_eq h, norm_div]
    apply div_le_div_of_nonneg_right _ (norm_nonneg _)
    calc
      _ ≤ ‖additivePhase θ ^ B‖ + ‖(1 : ℂ)‖ := norm_sub_le _ _
      _ = 2 := by simp [norm_pow, additivePhase_norm]; norm_num

/-- The row origin contributes only a unit phase to a geometric sum. -/
theorem shifted_geometricPhaseSum_bound (B : ℕ) (θ a : ℝ) :
    ‖∑ k ∈ Finset.range B, additivePhase (θ * (a+k))‖ ≤ geometricPhaseBound B θ := by
  have he : (∑ k ∈ Finset.range B, additivePhase (θ * (a+k))) =
      additivePhase (θ*a) * ∑ k ∈ Finset.range B, additivePhase (θ*k) := by
    simp_rw [mul_add, additivePhase_add, Finset.mul_sum]
  rw [he, norm_mul, additivePhase_norm, one_mul]
  exact geometricPhaseSum_bound B θ

/-- Explicit Gram entry for translated consecutive integer coordinates. -/
theorem exponentialGram_entry (B : ℕ) (θ a b : ℝ) (j k : ℕ) :
    finiteGram (Finset.range B)
      (fun i j : ℕ => additivePhase (θ * (a+i) * (b+j))) j k =
        ∑ i ∈ Finset.range B, additivePhase ((θ * ((k : ℝ)-j)) * (a+i)) := by
  unfold finiteGram
  apply Finset.sum_congr rfl
  intro i hi
  rw [additivePhase_conj, ← additivePhase_add]
  congr 1
  ring

/-- A scalar sum over all possible row differences, retaining the exact
geometric-series cancellation and with no operator premise. -/
def exponentialGramBudget (A B : ℕ) (θ : ℝ) : ℝ :=
  ∑ h ∈ Finset.Icc (-(A : ℤ)) (A : ℤ), geometricPhaseBound B (θ*h)

theorem exponentialGramBudget_nonneg (A B : ℕ) (θ : ℝ) :
    0 ≤ exponentialGramBudget A B θ :=
  Finset.sum_nonneg fun _ _ => geometricPhaseBound_nonneg B _

theorem exponentialGram_row_bound (A B : ℕ) (θ a b : ℝ) (j : ℕ)
    (hj : j ∈ Finset.range A) :
    ∑ k ∈ Finset.range A, ‖finiteGram (Finset.range B)
      (fun i j : ℕ => additivePhase (θ * (a+i) * (b+j))) j k‖ ≤
        exponentialGramBudget A B θ := by
  have hjA := Finset.mem_range.mp hj
  let f : ℕ → ℤ := fun k => (k : ℤ)-j
  have hinj : Function.Injective f := by
    intro k l hkl
    dsimp [f] at hkl
    omega
  have hsub : (Finset.range A).image f ⊆ Finset.Icc (-(A : ℤ)) (A : ℤ) := by
    intro h hh
    obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hh
    have hkA := Finset.mem_range.mp hk
    simp only [Finset.mem_Icc, f]
    omega
  calc
    _ ≤ ∑ k ∈ Finset.range A, geometricPhaseBound B (θ * (f k : ℝ)) := by
      apply Finset.sum_le_sum
      intro k hk
      rw [exponentialGram_entry]
      simpa [f] using shifted_geometricPhaseSum_bound B (θ*((k:ℝ)-j)) a
    _ = ∑ h ∈ (Finset.range A).image f, geometricPhaseBound B (θ*h) := by
      rw [Finset.sum_image]
      exact fun k hk l hl hkl => hinj hkl
    _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg hsub
      (fun h hh hnot => geometricPhaseBound_nonneg B _)

/-- An unconditional finite exponential-matrix estimate. The remaining
minor-arc number theory is reduced to an explicit scalar sum. -/
theorem exponential_kernel_bound (A B : ℕ) (θ a b : ℝ) :
    FiniteKernelBound (Finset.range B) (Finset.range A) (fun _ => 1) (fun _ => 1)
      (fun i j : ℕ => additivePhase (θ * (a+i) * (b+j)))
      (Real.sqrt (exponentialGramBudget A B θ)) :=
  finiteKernelBound_of_gram_rows _ _ _ _ (exponentialGramBudget_nonneg A B θ)
    (exponentialGram_row_bound A B θ a b)

/-- The actual two-dimensional determinant matrix is bounded by the
explicit one-dimensional geometric-sum budget, with no abstract matrix
estimate left as a hypothesis. Both coordinate intervals may be translated. -/
theorem determinant_kernel_bound_of_geometric_sum (A B : ℕ) (θ a b : ℝ) :
    FiniteKernelBound (Finset.range B ×ˢ Finset.range A)
      (Finset.range A ×ˢ Finset.range B) (fun _ => 1) (fun _ => 1)
      (fun p q => additivePhase (θ * ((a+p.1)*(b+q.1) - (b+p.2)*(a+q.2))))
      (exponentialGramBudget A B θ) := by
  have h := determinant_kernel_bound (Finset.range B) (Finset.range A)
    (fun i : ℕ => a+i) (fun j : ℕ => b+j) θ
    (Real.sqrt (exponentialGramBudget A B θ)) (Real.sqrt_nonneg _)
    (exponential_kernel_bound A B θ a b)
  simpa only [Real.sq_sqrt (exponentialGramBudget_nonneg A B θ)] using h

end Elliptic.Operator
