module
public import Elliptic.Operator.MellinWeightedEnergy
public import Elliptic.Operator.MellinGeneralCutoff
public import Elliptic.Operator.MajorArcActualProductEnergy

/-! Actual one-prime endpoint energy with exact Mellin normalization. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MellinEndpointEnergy
open MeasureTheory Set FourierTransform
open scoped BigOperators
open Artin.MarkedReplacement Artin.MarkedSource MellinPrimeSeparation
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

 theorem primePolynomial_eq (S : Finset ℕ) (P : ℝ) {q : ℕ} (χ : DirichletCharacter ℂ q) (ξ t : ℝ) :
    MellinPrimeSeparation.primePolynomial S (fun p=>χ (p:ZMod q)) P (t+ξ)=
      PrimeExceptionalCells.primePolynomial S P χ ξ t := by
  unfold MellinPrimeSeparation.primePolynomial PrimeExceptionalCells.primePolynomial
    SmallPrimePower.normalizedPrimeCoefficient
  rw [Finset.mul_sum,←Finset.sum_attach]
  apply Finset.sum_congr rfl
  intro p hp
  rw [MellinPrimeSeparation.archimedeanPhase_add]
  push_cast
  ring

 theorem scaledKernel_continuous (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi) (Y : ℝ) :
    Continuous (scaledKernel η Y) := by
  let f := (MellinGeneralCutoff.logProfile_compact η lo hi hlo hsupp).toSchwartzMap (hη.comp Real.contDiff_exp)
  have hf : Continuous (𝓕 (fun x:ℝ=>η (Real.exp x))) := (𝓕 f).continuous
  have hfour : Continuous (fourierKernel η) := by
    change Continuous (fun v=>fourierKernel η v)
    simp_rw [FourierL1Control.fourierKernel_eq]
    exact continuous_const.mul (hf.comp (continuous_id.div_const _))
  unfold scaledKernel
  apply hfour.mul
  fun_prop

/-- The literal endpoint cutoff inherits every uniform shifted prime energy
bound. Remaining labels cost only their exact normalized coefficient mass. -/
 theorem normalized_endpoint_energy
    (S R : Finset ℕ) (hS : ∀p∈S,0<p) (hR : ∀r∈R,0<r)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (d : ℕ→ℂ)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (lam P Y a b E BM BN : ℝ) (hP : 0<P) (hY : 0<Y)
    (M N : ℝ→ℂ) (hM : Continuous M) (hN : Continuous N) (hBM : 0≤BM) (hBN : 0≤BN)
    (hMb : ∀t,‖M t‖≤BM) (hNb : ∀t,‖N t‖≤BN)
    (henergy : ∀ξ,(∫t in Icc a b,‖PrimeExceptionalCells.primePolynomial S P χ ξ t*M t*N t‖^2)≤E) :
    (∫t in Icc a b,‖(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y t*M t*N t‖^2)≤
      (∫ξ:ℝ,‖scaledKernel (twistedCutoff η lam) Y ξ‖)^2*
        ((P/Y)*(∑r∈R,‖d r‖))^2*E := by
  let C := (P/Y)*(∑r∈R,‖d r‖)
  have hC : 0≤C := by dsimp [C];positivity
  let F : ℝ→ℝ→ℂ := fun ξ t=>
    MellinPrimeSeparation.primePolynomial S (fun p=>χ (p:ZMod q)) P (t+ξ)*
      remainingPolynomial R d P Y (t+ξ)*M t*N t
  have hFc : Continuous (Function.uncurry F) := by
    unfold F MellinPrimeSeparation.primePolynomial remainingPolynomial archimedeanPhase
    fun_prop
  have hr (ξ t:ℝ) : ‖remainingPolynomial R d P Y (t+ξ)‖≤C :=
    remainingPolynomial_norm_le R d P Y (t+ξ) hP.le hY
  have hFb : ∀ξ t,‖F ξ t‖≤((S.card:ℝ)/P)*C*BM*BN := by
    intro ξ t
    dsimp [F]
    rw [primePolynomial_eq,norm_mul,norm_mul,norm_mul]
    apply mul_le_mul _ (hNb t) (norm_nonneg _) (by positivity)
    apply mul_le_mul _ (hMb t) (norm_nonneg _) (by positivity)
    exact mul_le_mul (PrimeExceptionalCells.primePolynomial_norm_le S P hP χ ξ t) (hr ξ t)
      (norm_nonneg _) (by positivity)
  have hFe : ∀ξ,(∫t in Icc a b,‖F ξ t‖^2)≤C^2*E := by
    intro ξ
    have hpc := PrimeExceptionalCells.primePolynomial_continuous S P χ ξ
    calc
      _ ≤ ∫t in Icc a b,C^2*‖PrimeExceptionalCells.primePolynomial S P χ ξ t*M t*N t‖^2 := by
        apply setIntegral_mono_on
          (((hFc.comp (continuous_const.prodMk continuous_id)).norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc)
          (((((hpc.mul hM).mul hN).norm.pow 2).const_mul (C^2)).continuousOn.integrableOn_compact isCompact_Icc)
          measurableSet_Icc
        intro t ht
        have hh := pow_le_pow_left₀ (norm_nonneg _) (hr ξ t) 2
        have hm := mul_le_mul_of_nonneg_right hh
          (sq_nonneg ‖PrimeExceptionalCells.primePolynomial S P χ ξ t*M t*N t‖)
        dsimp [F]
        rw [primePolynomial_eq]
        simpa only [norm_mul,mul_pow,mul_assoc,mul_comm,mul_left_comm] using hm
      _ = C^2*(∫t in Icc a b,‖PrimeExceptionalCells.primePolynomial S P χ ξ t*M t*N t‖^2) := integral_const_mul _ _
      _ ≤ C^2*E := mul_le_mul_of_nonneg_left (henergy ξ) (sq_nonneg _)
  have htw := MellinGeneralCutoff.twisted_smooth η hη lam
  have htwSupp := MellinGeneralCutoff.twisted_support η lo hi lam hsupp
  have hkernel := MellinGeneralCutoff.scaledKernel_integrable _ htw lo hi hlo htwSupp Y
  have hbound := MellinWeightedEnergy.kernel_energy (scaledKernel (twistedCutoff η lam) Y) F
    (scaledKernel_continuous _ htw lo hi hlo htwSupp Y) hkernel hFc
    (((S.card:ℝ)/P)*C*BM*BN) (C^2*E) a b (by positivity) hFb hFe
  have he (t:ℝ) : (Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y t*M t*N t=
      ∫ξ:ℝ,scaledKernel (twistedCutoff η lam) Y ξ*F ξ t := by
    rw [MellinGeneralCutoff.normalized_endpoint_separation S R hS hR _ d η hη lo hi hlo hsupp lam P Y t hP hY,
      ←integral_mul_const,←integral_mul_const]
    apply integral_congr_ae
    filter_upwards [] with ξ
    dsimp [F]
    ring
  simp_rw [he]
  simpa only [mul_assoc,C] using hbound


/-- Every actual finite long polynomial has a uniform coefficient-mass bound. -/
 theorem longPolynomial_norm_le_mass (s : Finset ℕ) (α : ℕ→ℂ) (H : ℝ) (hH : 0<H)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (t : ℝ) :
    ‖MajorArcScaleCancellation.longPolynomial s α H χ t‖≤H⁻¹*(∑n∈s,‖α n‖) := by
  unfold MajorArcScaleCancellation.longPolynomial
  rw [norm_mul,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hH]
  apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr hH.le)
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro n hn
  rw [norm_mul,norm_mul,archimedeanPhase_norm,mul_one]
  simpa only [mul_one] using mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg (α n))

/-- The actual two long factors need no additional global boundedness assumption. -/
 theorem normalized_long_endpoint_energy
    (S R : Finset ℕ) (hS : ∀p∈S,0<p) (hR : ∀r∈R,0<r)
    {q k l : ℕ} (χ : DirichletCharacter ℂ q) (χm : DirichletCharacter ℂ k) (χn : DirichletCharacter ℂ l)
    (d : ℕ→ℂ) (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η)
    (lo hi : ℝ) (hlo : 0<lo) (hsupp : ∀y,η y≠0→lo≤y ∧ y≤hi)
    (s t : Finset ℕ) (α β : ℕ→ℂ) (Hm Hn : ℝ) (hm : 0<Hm) (hn : 0<Hn)
    (lam P Y a b E : ℝ) (hP : 0<P) (hY : 0<Y)
    (henergy : ∀ξ,(∫v in Icc a b,‖PrimeExceptionalCells.primePolynomial S P χ ξ v*
      MajorArcScaleCancellation.longPolynomial s α Hm χm v*
      MajorArcScaleCancellation.longPolynomial t β Hn χn v‖^2)≤E) :
    (∫v in Icc a b,‖(Y:ℂ)⁻¹*endpoint S R (fun p=>χ (p:ZMod q)) d η lam Y v*
      MajorArcScaleCancellation.longPolynomial s α Hm χm v*
      MajorArcScaleCancellation.longPolynomial t β Hn χn v‖^2)≤
      (∫ξ:ℝ,‖scaledKernel (twistedCutoff η lam) Y ξ‖)^2*((P/Y)*(∑r∈R,‖d r‖))^2*E := by
  apply normalized_endpoint_energy S R hS hR χ d η hη lo hi hlo hsupp lam P Y a b E
    (Hm⁻¹*(∑n∈s,‖α n‖)) (Hn⁻¹*(∑n∈t,‖β n‖)) hP hY
    _ _ (MajorArcScaleCancellation.longPolynomial_continuous s α Hm χm)
    (MajorArcScaleCancellation.longPolynomial_continuous t β Hn χn) (by positivity) (by positivity)
    (longPolynomial_norm_le_mass s α Hm hm χm) (longPolynomial_norm_le_mass t β Hn hn χn) henergy

end Elliptic.Operator.MellinEndpointEnergy
