module

public import Elliptic.Operator.BirthAddressGroups
public import Elliptic.Operator.BirthFourierLocalization

/-! Local address factors on the actual dependent physical choices.
This identifies the product read by the complete birth logger with the
chronological ghost/edge factors, before estimating any operator norm. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBirthFactors
open scoped BigOperators
open ActualHistoryBirths
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
variable (value : ∀ i, P i → ℕ)

def ghostFactor (G : ℕ→I→Fin B→Option ℕ→ℂ) (j : ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalGhostChoice s) : ℂ :=
  ∏i,∏a : Fin B,G j i a ((ghostSlot c i a).map (value i))

def edgeFactor (E : ℕ→I→Option ℕ→ℂ) (j : ℕ)
    {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s) : ℂ :=
  ∏i,E j i ((freshSlot c i).map (value i))

def historyFactor (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ) :
    (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s → ℂ
  | 0,j,_,h => ghostFactor value G j h.1.val
  | n+1,j,_,h => ghostFactor value G j h.1.val * edgeFactor value E j h.2.1.val *
      historyFactor G E n (j+1) _ h.2.2

theorem historyFactor_eq_logger_products
    (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ)
    (n j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s) :
    historyFactor ν V η q ρ anchor geometry value G E n j s h =
      (∏k : Fin (n+1),∏i,∏a : Fin B,
        G (j+k.val) i a ((ghostAt ν V η q ρ anchor geometry n j s h k i a).map (value i))) *
      (∏k : Fin n,∏i,
        E (j+k.val) i ((freshAt ν V η q ρ anchor geometry n j s h k i).map (value i))) := by
  induction n generalizing j s with
  | zero => simp [historyFactor,ghostFactor,ghostAt]
  | succ n ih =>
      rw [Fin.prod_univ_succ (f := fun k : Fin (n+1+1) => ∏i,∏a : Fin B,
        G (j+k.val) i a ((ghostAt ν V η q ρ anchor geometry (n+1) j s h k i a).map (value i))),
        Fin.prod_univ_succ (f := fun k : Fin (n+1) => ∏i,
        E (j+k.val) i ((freshAt ν V η q ρ anchor geometry (n+1) j s h k i).map (value i)))]
      simp only [Fin.val_zero,Nat.add_zero,Fin.val_succ,ghostAt,freshAt,
        Fin.cases_zero,Fin.cases_succ]
      rw [historyFactor,ih]
      have he (k : ℕ) : j+1+k=j+(k+1) := by omega
      simp only [he,ghostFactor,edgeFactor]
      ring

def initialFactor (A : I→Fin (J+1)→Option ℕ→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  ∏i,∏a,A i a (some (value i (s.active P Line J B i a)))

def addressFactor {N : ℕ} (A : I→Fin (J+1)→Option ℕ→ℂ)
    (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ) :
    Address I J B N → Option ℕ → ℂ
  | .inl a => A a.1 a.2
  | .inr (.inl a) => G a.1.val a.2.1 a.2.2
  | .inr (.inr a) => E a.1.val a.2

theorem logger_factorization (N : ℕ) (A : I→Fin (J+1)→Option ℕ→ℂ)
    (G : ℕ→I→Fin B→Option ℕ→ℂ) (E : ℕ→I→Option ℕ→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s) :
    (∏a : Address I J B N,addressFactor A G E a
      (labels ν V η q ρ anchor geometry value N s h a)) =
      initialFactor value A s * historyFactor ν V η q ρ anchor geometry value G E N 0 s h := by
  rw [historyFactor_eq_logger_products]
  simp only [Fintype.prod_sum_type,Fintype.prod_prod_type,addressFactor,labels,
    initialFactor,Nat.zero_add]

theorem actual_labels_bound {N Q : ℕ} (hvalue : ∀i p,value i p<Q)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (a : Address I J B N) (v : ℕ)
    (ha : labels ν V η q ρ anchor geometry value N s h a=some v) : v<Q := by
  obtain ⟨p,hp⟩ := label_mem_band ν V η q ρ anchor geometry value s h a v ha
  rw [←hp]
  exact hvalue _ p

theorem actual_birthFourier_average {N Q : ℕ} [NeZero Q]
    (hvalue : ∀i p,value i p<Q)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (σ : Equiv.Perm (Address I J B N))
    (W : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s→ℂ) :
    (∑h,if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ then W h else 0) =
      BirthFourierLocalization.average (fun θ=>∑h,
        (∏a,BirthFourierLocalization.localPhase
          (labels ν V η q ρ anchor geometry value N s h) (fun v=>(v:ZMod Q)) σ θ a)*W h) := by
  apply BirthFourierLocalization.weighted_birthPreserving_average
  intro h _
  exact BirthFourierLocalization.natural_code_faithful _
    (actual_labels_bound ν V η q ρ anchor geometry value hvalue s h)

end Elliptic.Operator.PhysicalBirthFactors
