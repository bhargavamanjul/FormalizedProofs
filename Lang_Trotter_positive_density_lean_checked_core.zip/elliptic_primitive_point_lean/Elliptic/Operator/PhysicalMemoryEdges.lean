module

public import Elliptic.Operator.MemoryEdges
public import Elliptic.Operator.FourierFiber

/-!
# Full finite physical memory edge rows

States carry the position, all ordered active prime lists, and all ordered
pending memories, with the source's TOTAL memory cutoff. Edge choices
include the target position, both endpoint slot permutations, and the
literal store/promotion/fresh choices of `MemoryEdges`. The row is an
actual finite sum; no norm estimate is assumed.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators ComplexConjugate
attribute [local instance] Classical.propDecidable
local instance {α : Type*} : DecidableEq α := Classical.typeDecidableEq α

variable {I Z : Type*} [Fintype I]
variable (P : I → Type*) (Line : ∀ i, P i → Type*) (J B : ℕ)

abbrev PhysicalActiveLists := ∀ i, Fin (J+1) → P i
abbrev PhysicalMemories := ∀ i, MemoryState (AnchoredParticle (P i) (Line i)) B

/-- Positions have counting measure; the total pending count is truncated. -/
abbrev PhysicalMemoryState :=
  {s : Z × (PhysicalActiveLists P J × PhysicalMemories P Line B) //
    (∑ i, (s.2.2 i).size) ≤ B}

namespace PhysicalMemoryState

def position (s : PhysicalMemoryState (Z:=Z) P Line J B) : Z := s.val.1

def active (s : PhysicalMemoryState (Z:=Z) P Line J B) : PhysicalActiveLists P J := s.val.2.1

def memory (s : PhysicalMemoryState (Z:=Z) P Line J B) : PhysicalMemories P Line B := s.val.2.2

/-- Literal product active measure and factorial pending measure. -/
def mass (ν : ∀ i, P i → ℝ) (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℝ :=
  ∏ i, tupleWeight (ν i) (s.active P Line J B i) *
    MemoryState.mass (anchoredParticleMass (ν i)) (s.memory P Line J B i)

theorem mass_pos (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : 0 < mass P Line J B ν s := by
  apply Finset.prod_pos
  intro i _
  apply mul_pos
  · exact Finset.prod_pos (fun j _ => hν i _)
  · exact MemoryState.mass_pos _ (fun x : AnchoredParticle (P i) (Line i) => hν i x.1) _

end PhysicalMemoryState

variable {P Line J B}

/-- Both endpoint averages are literal permutations of all active slots. -/
abbrev PhysicalEdgeChoice (s : PhysicalMemoryState (Z:=Z) P Line J B) :=
  Z × ((∀ _i : I, Equiv.Perm (Fin (J+1))) ×
    ((∀ i, EdgeGroupChoice (s.memory P Line J B i)) ×
      (∀ _i : I, Equiv.Perm (Fin (J+1)))))

namespace PhysicalEdgeChoice

def target {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s) : Z := c.1

def sourcePerm {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (i : I) : Equiv.Perm (Fin (J+1)) := c.2.1 i

def group {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (i : I) : EdgeGroupChoice (s.memory P Line J B i) := c.2.2.1 i

def targetPerm {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (i : I) : Equiv.Perm (Fin (J+1)) := c.2.2.2 i

/-- Source lists after the first endpoint symmetrization. -/
def sourceLists {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s) :
    PhysicalActiveLists P J := fun i j => s.active P Line J B i (c.sourcePerm i j)

/-- The last source slot is exactly the unshared source prime. -/
def sourcePrime {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s)
    (i : I) : P i := c.sourceLists i (Fin.last J)

/-- Before the target symmetrization, shared slots copy verbatim and the
last slot is the promoted or fresh prime. -/
def targetLists {s : PhysicalMemoryState (Z:=Z) P Line J B} (c : PhysicalEdgeChoice s) :
    PhysicalActiveLists P J := fun i =>
  Fin.lastCases (edgeTargetPrime (s.memory P Line J B i) (c.group i))
    (fun j => c.sourceLists i j.castSucc)

@[simp] theorem targetLists_shared {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalEdgeChoice s) (i : I) (j : Fin J) :
    c.targetLists i j.castSucc = c.sourceLists i j.castSucc := by
  simp [targetLists]

@[simp] theorem targetLists_last {s : PhysicalMemoryState (Z:=Z) P Line J B}
    (c : PhysicalEdgeChoice s) (i : I) :
    c.targetLists i (Fin.last J) = edgeTargetPrime (s.memory P Line J B i) (c.group i) := by
  simp [targetLists]

/-- Local hit validity and the source's total, rather than per-group, cutoff. -/
def Valid (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s) : Prop :=
  (∀ i, EdgeGroupChoice.Valid (anchor c.target i) (s.memory P Line J B i) (c.group i)) ∧
    (∑ i, edgeGroupOutputSize (c.group i)) ≤ B

/-- Deterministic full output of all group choices. -/
def output (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : Valid anchor s c) : PhysicalMemoryState (Z:=Z) P Line J B :=
  ⟨(c.target, (fun i j => c.targetLists i (c.targetPerm i j),
    fun i => edgeGroupOutput (anchor (s.position P Line J B) i) (c.sourcePrime i)
      (s.memory P Line J B i) (c.group i) (hc.1 i).2)), by
      simpa only [edgeGroupOutput_size] using hc.2⟩

@[simp] theorem output_position (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : Valid anchor s c) : (c.output anchor s hc).position P Line J B = c.target := rfl

@[simp] theorem output_active (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : Valid anchor s c) (i : I) (j : Fin (J+1)) :
    (c.output anchor s hc).active P Line J B i j = c.targetLists i (c.targetPerm i j) := rfl

@[simp] theorem output_memory (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : Valid anchor s c) (i : I) :
    (c.output anchor s hc).memory P Line J B i =
      edgeGroupOutput (anchor (s.position P Line J B) i) (c.sourcePrime i)
        (s.memory P Line J B i) (c.group i) (hc.1 i).2 := rfl

end PhysicalEdgeChoice

/-- The literal product of the two uniform endpoint permutation weights. -/
def endpointPermutationWeight (I : Type*) [Fintype I] (J : ℕ) : ℝ :=
  (Fintype.card (∀ _i : I, Equiv.Perm (Fin (J+1))) : ℝ)⁻¹ ^ 2

/-- Full signed choice coefficient. The geometric factor depends on actual
endpoints and actual pre-symmetrization lists; restrictions are inside it. -/
def physicalEdgeChoiceWeight (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) : ℂ :=
  (endpointPermutationWeight I J : ℂ) *
    geometry (s.position P Line J B) c.sourceLists c.target c.targetLists *
      (∏ i, (edgeGroupWeight (ν i) (V i) ρ (anchor (s.position P Line J B) i)
        (anchor c.target i) (c.sourcePrime i) (s.memory P Line J B i)
        (c.group i) (hc.1 i).2 : ℂ))

/-- Actual finite full edge action, with counting measure on target positions. -/
def physicalEdgeApply [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ := by
  classical
  exact ∑ c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc * F (c.output anchor s hc)
  else 0

/-- Collecting choices with equal output states retains all multiplicities. -/
def physicalEdgeTransition [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ := by
  classical
  exact physicalEdgeApply ν V ρ anchor geometry (fun out => if out=t then 1 else 0) s

theorem physicalEdgeApply_eq_transition_sum [Fintype Z] [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    physicalEdgeApply ν V ρ anchor geometry F s =
      ∑ t, physicalEdgeTransition ν V ρ anchor geometry s t * F t := by
  classical
  unfold physicalEdgeTransition physicalEdgeApply
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  split_ifs <;> simp

/-- Density with respect to the actual active/factorial product measure. -/
def physicalEdgeKernel [Fintype Z] [∀ i, Fintype (P i)]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (s t : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  physicalEdgeTransition ν V ρ anchor geometry s t /
    ((PhysicalMemoryState.mass P Line J B ν t : ℝ) : ℂ)

theorem finiteKernelApply_physicalEdgeKernel [Fintype Z] [∀ i, Fintype (P i)]
    [∀ i p, Fintype (Line i p)]
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, 0 < ν i p)
    (V : I → ℝ) (ρ : ℝ) (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F : PhysicalMemoryState (Z:=Z) P Line J B → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    finiteKernelApply Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (physicalEdgeKernel ν V ρ anchor geometry) F s =
      physicalEdgeApply ν V ρ anchor geometry F s := by
  rw [physicalEdgeApply_eq_transition_sum]
  unfold finiteKernelApply physicalEdgeKernel
  apply Finset.sum_congr rfl
  intro t _
  have ht : ((PhysicalMemoryState.mass P Line J B ν t : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (PhysicalMemoryState.mass_pos P Line J B ν hν t).ne'
  field_simp

end Elliptic.Operator
