module
public import Elliptic.Operator.BirthPermutationPlan
public import Elliptic.Operator.PhysicalPivotRow

/-! # The chronological named-coordinate count is exactly the permutation rank -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthPermutationPlan
open scoped BigOperators
open ActualHistoryBirths BirthCyclePivots
attribute [local instance] Classical.propDecidable
local instance birthPermutationCountDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type} [Fintype I] {J B N : ℕ}
local instance (priority := 100000) birthPermutationAddressDecEq : DecidableEq (Address I J B N) := Classical.typeDecidableEq _
local instance birthPermutationCountOrder : LinearOrder (Address I J B N) := BirthChronologicalOrder.order

theorem initialSlots_card (σ:Equiv.Perm (Address I J B N)) (i:I) :
    (initialSlots σ i).card=∑k:Fin (J+1),if (.inl (i,k))∈nonpivots σ then 1 else 0 := by
  rw [initialSlots,Finset.card_image_of_injective _ (@Fin.val_injective (J+1)),Finset.card_eq_sum_ones,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro k _
  split_ifs <;> rfl

theorem ghostSlots_card (σ:Equiv.Perm (Address I J B N)) (j:Fin (N+1)) (i:I) :
    (ghostSlots σ j.val i).card=∑k:Fin B,if (.inr (.inl (j,i,k)))∈nonpivots σ then 1 else 0 := by
  rw [ghostSlots,dite_eq_left j.isLt,Finset.card_image_of_injective _ (@Fin.val_injective B),
    Finset.card_eq_sum_ones,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro k _
  split_ifs <;> rfl

theorem edgeGroups_card (σ:Equiv.Perm (Address I J B N)) (j:Fin N) :
    (edgeGroups σ j.val).card=∑i:I,if (.inr (.inr (j,i)))∈nonpivots σ then 1 else 0 := by
  rw [edgeGroups,dite_eq_left j.isLt,Finset.card_eq_sum_ones,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro k _
  split_ifs <;> rfl

/-- Initial, ghost, and fresh-edge addresses are disjoint and exhaustive. -/
theorem named_count_partition (σ:Equiv.Perm (Address I J B N)) :
    (∑i,(initialSlots σ i).card)+
      ((∑j:Fin (N+1),∑i,(ghostSlots σ j.val i).card)+(∑j:Fin N,(edgeGroups σ j.val).card))=
      birthCycleRank σ := by
  rw [← nonpivots_card σ]
  have hc : (nonpivots σ).card=∑a:Address I J B N,if a∈nonpivots σ then 1 else 0 := by
    simp
  rw [hc]
  simp only [initialSlots_card,ghostSlots_card,edgeGroups_card,Fintype.sum_sum_type,Fintype.sum_prod_type]

theorem futureCount_sum (p:PhysicalBirthRegistry.PivotPlan I J B) (j n:ℕ) :
    p.futureCount j n=(∑k:Fin (n+1),∑i,(p.ghostSlots (j+k.val) i).card)+
      (∑k:Fin n,(p.edgeGroups (j+k.val)).card) := by
  induction n generalizing j with
  | zero => simp [PhysicalBirthRegistry.PivotPlan.futureCount]
  | succ n ih =>
      rw [PhysicalBirthRegistry.PivotPlan.futureCount,ih,
        Fin.sum_univ_succ (f:=fun k:Fin (n+1+1)=>∑i,(p.ghostSlots (j+k.val) i).card),
        Fin.sum_univ_succ (f:=fun k:Fin (n+1)=>(p.edgeGroups (j+k.val)).card)]
      simp only [Fin.val_zero,Fin.val_succ,Nat.add_zero]
      have he : ∀k:ℕ,j+1+k=j+(k+1):=fun k=>by omega
      simp only [he]
      omega

/-- The exponent in the actual initial-plus-history bound is precisely r. -/
theorem total_count_eq_rank (σ:Equiv.Perm (Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) :
    (∑i,((initialPlan σ hgroup).slots i).card)+(plan σ hgroup).futureCount 0 N=birthCycleRank σ := by
  rw [futureCount_sum]
  simpa only [plan,initialPlan,Nat.zero_add] using named_count_partition σ

end Elliptic.Operator.BirthPermutationPlan
