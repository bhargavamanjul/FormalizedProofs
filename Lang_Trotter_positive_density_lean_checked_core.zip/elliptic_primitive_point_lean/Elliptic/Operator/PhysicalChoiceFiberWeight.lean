module

public import Elliptic.Operator.PhysicalDirtyCrude

/-! Weighted summation over literal combinatorial keys. The only counting
input is a finite fiber inequality; actual comparison geometry discharges
it separately. Fresh-prime masses are summed, never counted. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalChoiceFiberWeight
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance fiberWeightDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

variable {Q : Type*} {Line : Q→Type*} {B : ℕ}

def coefficient (ν : Q→ℝ) (V v0 : ℝ)
    {m : MemoryState (AnchoredParticle Q Line) B} (c : EdgeGroupChoice m) : ℝ :=
  (match c.2 with | .inl _=>V⁻¹/v0 | .inr p=>ν p)*v0^c.1.toNat

 theorem coefficient_nonneg (ν : Q→ℝ) (V v0 : ℝ)
    {m : MemoryState (AnchoredParticle Q Line) B} (c : EdgeGroupChoice m)
    (hν : ∀p,0≤ν p) (hV : 0≤V) (hv0 : 0≤v0) : 0≤coefficient ν V v0 c := by
  rcases c with ⟨b,i|p⟩
  · exact mul_nonneg (div_nonneg (inv_nonneg.mpr hV) hv0) (pow_nonneg hv0 _)
  · exact mul_nonneg (hν p) (pow_nonneg hv0 _)

 theorem weightedChoice_le (ν : Q→ℝ) (V ρ v0 : ℝ)
    (sourceAnchor targetAnchor : ∀p,Line p) (source : Q)
    (m : MemoryState (AnchoredParticle Q Line) B) (c : EdgeGroupChoice m)
    (hν : ∀p,0≤ν p) (hV : 0≤V) (hρ0 : 0≤ρ) (hρ1 : ρ≤1) (hv0 : 0<v0) :
    edgeWeightedChoice ν V ρ v0 sourceAnchor targetAnchor source m c≤coefficient ν V v0 c := by
  rcases c with ⟨b,i|p⟩
  · exact (edgeWeightedChoice_promotion_le_coefficient ν V ρ v0 sourceAnchor targetAnchor source m b i
      hV hρ0 hρ1 hv0).trans_eq (by unfold coefficient;ring)
  · exact edgeWeightedChoice_fresh_le ν V ρ v0 sourceAnchor targetAnchor source m b p hν hρ0 hρ1 hv0

 theorem sum_coefficient [Fintype Q] (ν : Q→ℝ) (V v0 : ℝ)
    (m : MemoryState (AnchoredParticle Q Line) B) :
    (∑c : EdgeGroupChoice m,coefficient ν V v0 c)=
      (1+v0)*((m.size:ℝ)*V⁻¹/v0+∑p,ν p) := by
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_sum_type,coefficient,Finset.sum_mul,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  simp only [Fintype.sum_bool,Bool.toNat_false,Bool.toNat_true,pow_zero,pow_one,←Finset.sum_mul]
  ring

variable {K J : ℕ} {Z : Type} [Fintype Z] {P : Fin K→Type} [∀i,Fintype (P i)]
variable (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p=>Option (ZMod (value i p))) J B)

/-- A polynomial memory budget, independent of the cardinality of the
fresh prime bands and of either endpoint permutation group. -/
def budget (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (v0 : ℝ) : ℝ :=
  ∏i,(1+v0)*((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)

 theorem endpoint_sum_le (ν : ∀i,P i→ℝ) (V : Fin K→ℝ) (ρ v0 C : ℝ)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (hv0 : 0<v0) (hC : 0≤C) (S : Finset (PhysicalEdgeChoice s))
    (hcount : ∀k : PhysicalDirtyCrude.Key value s,
      ((S.filter (fun c=>PhysicalDirtyCrude.key value s c=k)).card:ℝ)≤C) :
    endpointPermutationWeight (Fin K) J *
      (∑c∈S,PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c)≤
      C*budget (B:=B) ν V v0 := by
  let f := fun k : PhysicalDirtyCrude.Key value s =>
    ∏i,coefficient (ν i) (V i) v0 (k.2.1 i)
  have hf (k : PhysicalDirtyCrude.Key value s) : 0≤f k :=
    Finset.prod_nonneg fun i _=>coefficient_nonneg _ _ _ _ (hν i) (hV i) hv0.le
  have hc (c : PhysicalEdgeChoice s) :
      PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c≤f (PhysicalDirtyCrude.key value s c) := by
    apply Finset.prod_le_prod₀
    · intro i _
      exact edgeWeightedChoice_nonneg _ _ _ _ _ _ _ _ _ (hν i) (hV i) hρ0 hv0.le
    · intro i _
      exact weightedChoice_le _ _ _ _ _ _ _ _ _ (hν i) (hV i) hρ0 hρ1 hv0
  have hsum : (∑c∈S,PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c)≤
      C*∑k : PhysicalDirtyCrude.Key value s,f k := by
    rw [←Finset.sum_fiberwise_of_maps_to (fun c (_ : c∈S)=>Finset.mem_univ (PhysicalDirtyCrude.key value s c))
      (PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0),Finset.mul_sum]
    apply Finset.sum_le_sum
    intro k _
    calc
      _ ≤ ∑_c∈S.filter (fun c=>PhysicalDirtyCrude.key value s c=k),f k := by
        apply Finset.sum_le_sum
        intro c hcc
        simpa only [(Finset.mem_filter.mp hcc).2] using hc c
      _ = ((S.filter (fun c=>PhysicalDirtyCrude.key value s c=k)).card:ℝ)*f k := by simp
      _ ≤ C*f k := mul_le_mul_of_nonneg_right (hcount k) (hf k)
  have hprod : (∏i,∑c : EdgeGroupChoice (s.memory P (fun i p=>Option (ZMod (value i p))) J B i),
      coefficient (ν i) (V i) v0 c)≤budget (B:=B) ν V v0 := by
    apply Finset.prod_le_prod₀
    · intro i _
      exact Finset.sum_nonneg fun c _=>coefficient_nonneg _ _ _ _ (hν i) (hV i) hv0.le
    · intro i _
      rw [sum_coefficient]
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply add_le_add _ le_rfl
      apply div_le_div_of_nonneg_right _ hv0.le
      apply mul_le_mul_of_nonneg_right _ (inv_nonneg.mpr (hV i))
      exact_mod_cast (s.memory P (fun i p=>Option (ZMod (value i p))) J B i).size_le
  calc
    _ ≤ endpointPermutationWeight (Fin K) J*(C*∑k : PhysicalDirtyCrude.Key value s,f k) :=
      mul_le_mul_of_nonneg_left hsum (by unfold endpointPermutationWeight;positivity)
    _ = C*(∏i,∑c : EdgeGroupChoice (s.memory P (fun i p=>Option (ZMod (value i p))) J B i),
        coefficient (ν i) (V i) v0 c) := by
      simp only [PhysicalDirtyCrude.Key,Fintype.sum_prod_type,f,Finset.sum_const,
        Finset.card_univ,nsmul_eq_mul,←Fintype.prod_sum]
      simp only [endpointPermutationWeight,Fintype.card_fun,Fintype.card_perm,Fintype.card_fin]
      have hn : (Nat.factorial (J+1):ℝ)≠0 := by positivity
      field_simp
      rw [←Finset.mul_sum]
      simp_rw [←Fintype.sum_prod_type]
      rw [←Fintype.prod_sum]
      ring
    _ ≤ C*budget (B:=B) ν V v0 := mul_le_mul_of_nonneg_left hprod hC

end Elliptic.Operator.PhysicalChoiceFiberWeight
