module
public import Elliptic.Operator.EdgeSymmetricAdjoint
public import Elliptic.Operator.MemoryOutputBags

/-! Exact indexed store/promotion transfer at fixed endpoint labels. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- The actual optional source store as a multiset, after old retrieval. -/
def edgeStoredBag {X : Type*} (source : X) (s : Multiset X) (store : Bool) : Multiset X :=
  s + if store then {source} else 0

/-- Literal two choices for an optional store, with the actual cutoff. -/
def indexedStoreContinuation {X R : Type*} [Field R]
    (B : ℕ) (source : X) (store : R) (F : Multiset X → R) (s : Multiset X) : R :=
  ∑ b : Bool, if s.card+b.toNat ≤ B then store^b.toNat * F (edgeStoredBag source s b) else 0

theorem indexedStoreContinuation_eq_bagBirth {X R : Type*} [Fintype X]
    [Field R] [CharZero R] (B : ℕ) (μ : X → R) (source : X) (store : R)
    (hμ : μ source ≠ 0) (F : Multiset X → R) (s : Multiset X) :
    indexedStoreContinuation B source store F s =
      bagBirth B μ (edgeStoreBatch source (μ source) store) F s := by
  rw [bagBirth_edgeStoreBatch B μ source store hμ]
  simp [indexedStoreContinuation, edgeStoredBag, add_comm]

theorem particle_eq_anchorPrime_iff {P : Type*} {Line : P → Type*}
    (anchor : ∀ p, Line p) (x : AnchoredParticle P Line) (q : P) :
    x=anchorPrime anchor q ↔ x.1=q ∧ particleHits anchor x := by
  constructor
  · rintro rfl
    simp [anchorPrime, particleHits]
  · rcases x with ⟨p,l⟩
    rintro ⟨hp,hl⟩
    change p=q at hp
    subst p
    exact Sigma.ext rfl (heq_of_eq hl)

/-- Actual indexed choices, restricted to the specified target active label.
This is a subrow of the same `EdgeGroupChoice` used by the physical edge. -/
def fixedTargetEdgeChoiceApply {P R : Type*} [Fintype P] {Line : P → Type*}
    {B : ℕ} [Field R] (ν : P → R) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) : R := by
  classical
  exact ∑ c : EdgeGroupChoice m, if hc : EdgeGroupChoice.Valid targetAnchor m c then
    if edgeTargetPrime m c = target then
      store^c.1.toNat * (match c.2 with | .inl _ => promote | .inr p => ν p) *
        F (tupleBag (edgeGroupOutput sourceAnchor source m c hc.2).values)
    else 0
  else 0

/-- Exact reindexing of the actual old-index/fresh choice sum into its
fresh target and indexed old-particle retrieval parts. -/
theorem fixedTargetEdgeChoiceApply_eq {P R : Type*} [Fintype P] {Line : P → Type*}
    {B : ℕ} [Field R] (ν : P → R) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    fixedTargetEdgeChoiceApply ν store promote sourceAnchor targetAnchor source target F m =
      ν target * indexedStoreContinuation B (anchorPrime sourceAnchor source) store F
        (tupleBag m.values) +
      promote * ∑ i : Fin m.size, if m.values i = anchorPrime targetAnchor target then
        indexedStoreContinuation B (anchorPrime sourceAnchor source) store F
          (survivorBag {i} m.values) else 0 := by
  classical
  have hsize (c : EdgeGroupChoice m) : edgeGroupOutputSize c =
      (survivorBag (edgePromotedIndices c) m.values).card+c.1.toNat := by
    rw [edgeGroupOutputSize_eq, survivorBag_card]
  have hempty : survivorBag (∅ : Finset (Fin m.size)) m.values = tupleBag m.values := by
    simp [survivorBag_eq_sub, selectedBag]
  unfold fixedTargetEdgeChoiceApply
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_sum_type]
  have hf (b : Bool) (p : P) :
      (if hc : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inr p) then
        if edgeTargetPrime m (b,Sum.inr p)=target then
          store^b.toNat * ν p *
            F (tupleBag (edgeGroupOutput sourceAnchor source m (b,Sum.inr p) hc.2).values)
        else 0 else 0) =
      if p=target then ν target *
        (if (tupleBag m.values).card+b.toNat ≤ B then
          store^b.toNat * F (edgeStoredBag (anchorPrime sourceAnchor source) (tupleBag m.values) b)
        else 0) else 0 := by
    have hviff : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inr p) ↔
        (tupleBag m.values).card+b.toNat ≤ B := by
      simp only [EdgeGroupChoice.Valid, edgePromotionHits, true_and]
      rw [hsize]
      simp only [edgePromotedIndices, hempty]
    by_cases hv : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inr p)
    · have hb := hviff.mp hv
      rw [dite_eq_left hv, edgeGroupOutput_tupleBag]
      simp only [edgePromotedIndices, hempty, edgeTargetPrime]
      by_cases hpt : p=target
      · subst p
        simp [hb, edgeStoredBag, mul_comm, mul_assoc]
      · simp [hpt]
    · rw [dite_eq_right hv]
      have hb := mt hviff.mpr hv
      simp [hb]
  have hp (b : Bool) (i : Fin m.size) :
      (if hc : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inl i) then
        if edgeTargetPrime m (b,Sum.inl i)=target then
          store^b.toNat * promote *
            F (tupleBag (edgeGroupOutput sourceAnchor source m (b,Sum.inl i) hc.2).values)
        else 0 else 0) =
      promote * (if m.values i=anchorPrime targetAnchor target then
        (if (survivorBag {i} m.values).card+b.toNat ≤ B then
          store^b.toNat * F (edgeStoredBag (anchorPrime sourceAnchor source)
            (survivorBag {i} m.values) b)
        else 0) else 0) := by
    have hviff : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inl i) ↔
        particleHits targetAnchor (m.values i) ∧
          (survivorBag {i} m.values).card+b.toNat ≤ B := by
      simp only [EdgeGroupChoice.Valid, edgePromotionHits]
      rw [hsize]
      rfl
    by_cases hv : EdgeGroupChoice.Valid targetAnchor m (b,Sum.inl i)
    · obtain ⟨hh,hb⟩ := hviff.mp hv
      rw [dite_eq_left hv, edgeGroupOutput_tupleBag]
      simp only [edgePromotedIndices, edgeTargetPrime, particle_eq_anchorPrime_iff,
        hh, and_true, hb, ite_true]
      by_cases hl : (m.values i).1=target <;>
        simp [hl, edgeStoredBag, mul_comm, mul_assoc]
    · rw [dite_eq_right hv]
      by_cases he : m.values i=anchorPrime targetAnchor target
      · have hh := ((particle_eq_anchorPrime_iff targetAnchor (m.values i) target).mp he).2
        have hb : ¬(survivorBag {i} m.values).card+b.toNat ≤ B :=
          fun hb => hv (hviff.mpr ⟨hh,hb⟩)
        simp [he,hb]
      · simp [he]
  simp_rw [hf,hp]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true, Finset.sum_add_distrib]
  rw [Finset.sum_comm]
  simp only [← Finset.mul_sum]
  have hb (i : Fin m.size) :
      (∑ b : Bool, if m.values i=anchorPrime targetAnchor target then
        (if (survivorBag {i} m.values).card+b.toNat ≤ B then
          store^b.toNat * F (edgeStoredBag (anchorPrime sourceAnchor source)
            (survivorBag {i} m.values) b) else 0) else 0) =
      if m.values i=anchorPrime targetAnchor target then
        indexedStoreContinuation B (anchorPrime sourceAnchor source) store F
          (survivorBag {i} m.values) else 0 := by
    split_ifs <;> simp [indexedStoreContinuation]
  simp_rw [hb]
  rw [add_comm]
  rfl

/-- The local actual indexed edge is the symmetric singleton transfer.
This is the required identification, not an assumed memory identity. -/
theorem fixedTargetEdgeChoiceApply_eq_bagTransfer {P R : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    fixedTargetEdgeChoiceApply ν store promote sourceAnchor targetAnchor source target F m =
      bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
        (anchorPrime sourceAnchor source) (anchorPrime targetAnchor target)
        (ν source) (ν target) store promote (fun _ => 1) (fun _ => 1) F
        (tupleBag m.values) := by
  rw [fixedTargetEdgeChoiceApply_eq]
  unfold bagEdgeTransfer
  simp only [one_mul]
  rw [bagDeletion_edgePromotionBatch, bagPointRemoval_tupleBag]
  simp_rw [indexedStoreContinuation_eq_bagBirth B
    (fun x : AnchoredParticle P Line => ν x.1) (anchorPrime sourceAnchor source)
    store (hν source)]
  apply congrArg₂ (·+·)
  · rfl
  · apply congrArg (fun z => promote*z)
    apply Finset.sum_congr rfl
    intro i _
    split_ifs <;> rfl

theorem bagSurvival_tupleBag_eq_hits {P R : Type*} {Line : P → Type*}
    {B : ℕ} [CommSemiring R] (anchor : ∀ p, Line p) (ρ : R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    bagSurvival anchor ρ (tupleBag m.values) = ρ^(memoryHits anchor m).card := by
  have h := survivorBag_hits_card anchor m (∅ : Finset (Fin m.size))
  have he : survivorBag (∅ : Finset (Fin m.size)) m.values = tupleBag m.values := by
    simp [survivorBag_eq_sub, selectedBag]
  rw [he, Finset.sdiff_empty] at h
  simp only [bagSurvival, h]

/-- The original actual local edge, on symmetric test functions, is exactly
the sum of its fixed-target indexed subrows, with both actual hit factors. -/
theorem edgeGroupApply_eq_fixedTargets {P : Type*} [Fintype P]
    {Line : P → Type*} {B : ℕ} (ν : P → ℝ) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (F : P → Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    edgeGroupApply ν V ρ sourceAnchor targetAnchor source
      (fun out => F out.1 (tupleBag out.2.values)) m =
    bagSurvival sourceAnchor (ρ : ℂ) (tupleBag m.values) *
      ∑ q, fixedTargetEdgeChoiceApply (fun p => (ν p : ℂ)) 1 (V : ℂ)⁻¹
        sourceAnchor targetAnchor source q
        (fun s => bagSurvival targetAnchor (ρ : ℂ) s * F q s) m := by
  classical
  unfold edgeGroupApply fixedTargetEdgeChoiceApply
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : EdgeGroupChoice.Valid targetAnchor m c
  · simp only [dite_eq_left hc, mul_ite, mul_zero, one_pow, one_mul,
      Finset.sum_ite_eq, Finset.mem_univ, ite_true,
      bagSurvival_tupleBag_eq_hits, edgeGroupWeight, Complex.ofReal_mul, Complex.ofReal_pow]
    cases he : c.2 <;> simp [edgeTargetWeight, he, mul_assoc]
  · simp [hc]

/-- Complete local identification with the factorial symmetric transfer.
No assertion is made for nonsymmetric test functions on ordered memories. -/
theorem edgeGroupApply_eq_bagTransfers {P : Type*} [Fintype P]
    {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}
    (ν : P → ℝ) (hν : ∀ p, ν p ≠ 0) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (F : P → Multiset (AnchoredParticle P Line) → ℂ)
    (m : MemoryState (AnchoredParticle P Line) B) :
    edgeGroupApply ν V ρ sourceAnchor targetAnchor source
      (fun out => F out.1 (tupleBag out.2.values)) m =
      ∑ q, bagEdgeTransfer B (fun x : AnchoredParticle P Line => (ν x.1 : ℂ))
        (anchorPrime sourceAnchor source) (anchorPrime targetAnchor q)
        (ν source : ℂ) (ν q : ℂ) 1 (V : ℂ)⁻¹
        (bagSurvival sourceAnchor (ρ : ℂ)) (bagSurvival targetAnchor (ρ : ℂ))
        (F q) (tupleBag m.values) := by
  rw [edgeGroupApply_eq_fixedTargets, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro q _
  have hn (p : P) : (ν p : ℂ) ≠ 0 := by exact_mod_cast hν p
  rw [fixedTargetEdgeChoiceApply_eq_bagTransfer _ hn]
  simp only [bagEdgeTransfer, one_mul]

end Elliptic.Operator
