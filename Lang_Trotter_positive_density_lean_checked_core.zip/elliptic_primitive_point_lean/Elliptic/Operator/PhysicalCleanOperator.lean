module
public import Elliptic.Operator.PhysicalCleanGlobal
public import Elliptic.Operator.PhysicalCleanLocalGeometry
public import Elliptic.Operator.PhysicalPathSupport
public import Elliptic.Operator.PhysicalComparisonChoices

/-! The actual physical clean geometry assembled from proved balanced
pad-cell cancellation, the literal fresh-prime exclusion, and the finite
pad/slope direct sum. No entrywise cancellation premise is used. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators SchwartzMap
attribute [local instance] Classical.propDecidable
local instance physicalCleanOperatorDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1600000

namespace PhysicalCleanOperator
open PhysicalCleanLocalGeometry PhysicalCleanBlocks PhysicalCleanBanNorm
variable {I : Type*} [Fintype I] {J : ℕ}

def budget (groups : I→Finset ℕ) (Cweight : I→ℝ) (ψ : 𝓢(ℝ,ℂ))
    (Ccell H Y Aψ Cmass δ : ℝ) (k A B : ℕ) : ℝ :=
  (∏ i, Cweight i)*smoothedDeterminantBudget ψ A B H Y k +
    (Aψ*(33+4*(72*(256*Ccell)^2)*H^3))*((Fintype.card I:ℝ)*δ*Cmass^(Fintype.card I))

theorem budget_nonneg (groups : I→Finset ℕ) (Cweight : I→ℝ) (hCweight : ∀i,0≤Cweight i)
    (ψ : 𝓢(ℝ,ℂ)) (Ccell H Y Aψ Cmass δ : ℝ) (k A B : ℕ)
    (hH : 1≤H) (hY : 0<Y) (hAψ : 0≤Aψ) (hmass : 0≤Cmass) (hδ : 0≤δ) :
    0≤budget groups Cweight ψ Ccell H Y Aψ Cmass δ k A B := by
  have hh := smoothedDeterminantBudget_nonneg ψ A B H Y k (by linarith) hY
  have hH0 : 0≤H := by linarith
  unfold budget
  exact add_nonneg (mul_nonneg (Finset.prod_nonneg (fun i _=>hCweight i)) hh) (by positivity)

/-- The source's exact geometry on one actual good cell, including both
eta factors, the dyadic d0/D factor and the literal cross-edge ban. -/
theorem source_good_pad_cell_bound
    (groups : I→Finset ℕ)
    (hprime : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j))
    (ν : I→ℕ→ℝ) (Cweight : I→ℝ) (hCweight : ∀i,0≤Cweight i)
    (hν : ∀i,∀p∈groups i,0≤ν i p) (hνbound : ∀i,∀p∈groups i,ν i p≤Cweight i/p)
    (shared : PhysicalActiveReindex.SharedLists (fun i=>groups i) J)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (z w : ℤ×ℤ) (hzw : latticeDet z w=1)
    (u v r U W d₀ Y Ccell : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hD : d₀≤(sharedProduct groups shared:ℝ))
    (hD' : (sharedProduct groups shared:ℝ)<2*d₀) (hY : 1≤Y) (hCcell : 1≤Ccell)
    (hz : sourcePhysicalPositionAllowed u v r U W z)
    (hg : SourceGoodState.FirstGoodTest ((sharedProduct groups shared:ℝ)*latticeTau r w/latticeTau r z) Y)
    (s t : Finset (PadPosition z (sharedProduct groups shared:ℤ) × (∀i,groups i)))
    (hspos : ∀p∈s,sourcePhysicalPositionAllowed u v r U W p.1.val)
    (htpos : ∀p∈t,sourcePhysicalPositionAllowed u v r U W p.1.val)
    (hsgood : ∀p∈s,good p.1.val (assemble shared p.2))
    (htgood : ∀p∈t,good p.1.val (assemble shared p.2))
    (hsinj : ∀p∈s,∀i,Function.Injective (assemble shared p.2 i))
    (htinj : ∀p∈t,∀i,Function.Injective (assemble shared p.2 i))
    (hscell : ∀p∈s,|latticeSlope r p.1.val-latticeSlope r z|≤Ccell*d₀*Y)
    (htcell : ∀p∈t,|latticeSlope r p.1.val-latticeSlope r z|≤Ccell*d₀*Y)
    (hs : ∀p∈s,Y≤((∏i,(p.2 i).val):ℕ))
    (ht : ∀p∈t,Y≤((∏i,(p.2 i).val):ℕ))
    (η : ℝ→ℂ) (hη : ∀x,‖η x‖≤1) (ψ : 𝓢(ℝ,ℂ)) (H : ℝ) (hH : 1≤H) (k : ℕ)
    (Aψ Cmass δ : ℝ) (hAψ : 0≤Aψ) (hψ : ∀x,‖ψ x‖≤Aψ)
    (hmassC : 1≤Cmass) (hδ : 0≤δ)
    (hmass : ∀i,∑p:groups i,ν i p.val≤Cmass)
    (hatom : ∀i,∀p∈groups i,ν i p≤δ) (σ : ℤ) (hσ : σ=1∨σ= -1) :
    ∃A B:ℕ,Y^(1/5:ℝ)≤A ∧ Y^(1/5:ℝ)≤B ∧
      (A:ℝ)*B≤72*(256*Ccell)^2*Y ∧
      FiniteMeasuredBilinearBound s t
        (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
        (fun p q=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good u v r U W d₀ Y η ψ
          (sourceMajorArcs H Y) σ p.1.val (assemble shared p.2) q.1.val (assemble shared q.2))
        (budget groups Cweight ψ Ccell H Y Aψ Cmass δ k A B) := by
  obtain ⟨A,B,hA,hB,harea,hbound⟩ := actual_banned_good_pad_cell_bound groups hprime hdis ν Cweight hCweight hν hνbound
    z w hzw (sharedProduct groups shared:ℤ) u v r U W d₀ Y Ccell hU hu hu' hd (by exact_mod_cast hD)
    hY hCcell hz (by exact_mod_cast hg) s t hspos htpos hscell htcell hs ht ψ H hH k
    Aψ Cmass δ hAψ hψ hmassC hδ hmass hatom σ hσ
  refine ⟨A,B,hA,hB,harea,?_⟩
  have hM := budget_nonneg groups Cweight hCweight ψ Ccell H Y Aψ Cmass δ k A B hH (by linarith) hAψ (by linarith) hδ
  have hscale : ‖((d₀/(sharedProduct groups shared:ℝ):ℝ):ℂ)‖≤1 := by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (div_nonneg hd.le (hd.trans_le hD).le)]
    exact (div_le_one (hd.trans_le hD)).mpr hD
  have he := PhysicalCleanMemory.measured_clean_endpoint_bound s t
    (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property))
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property))
    (bannedKernel groups z (sharedProduct groups shared:ℤ) ψ H Y σ)
    (budget groups Cweight ψ Ccell H Y Aψ Cmass δ k A B) hM
    (fun p=>((d₀/(sharedProduct groups shared:ℝ):ℝ):ℂ)*η (((∏i,(p.2 i).val):ℕ)/Y))
    (fun p=>η (((∏i,(p.2 i).val):ℕ)/Y))
    (by intro p hp; rw [norm_mul]; exact mul_le_one₀ hscale (norm_nonneg _) (hη _))
    (fun p _=>hη _) hbound
  apply finiteMeasuredBilinearBound_congr _ _ _ _ _ _ _ ?_ he
  intro p hp q hq
  exact (source_geometry_eq groups hdis shared z w hzw good u v r U W d₀ H Y η ψ σ p q
    (hspos p hp) (htpos q hq) (hsgood p hp) (htgood q hq) (hsinj p hp) (htinj q hq) hD hD').symm

/-- The literal finite support embeds into a pad without enlarging its
position or prime-label multiplicity. -/
def liftPad (groups : I→Finset ℕ) (z : ℤ×ℤ) (D : ℤ)
    (s : Finset ((ℤ×ℤ)×(∀i,groups i)))
    (hs : ∀p∈s,D∣latticeDet z p.1) :
    s ↪ PadPosition z D × (∀i,groups i) where
  toFun p := (⟨p.val.1,hs p.val p.property⟩,p.val.2)
  inj' := by
    intro p q h
    apply Subtype.ext
    apply Prod.ext
    · exact congrArg (fun p : PadPosition z D×(∀i,groups i)=>p.1.val) h
    · exact congrArg (fun p : PadPosition z D×(∀i,groups i)=>p.2) h

/-- Pulling back an actual pad estimate returns the original finite
supports and original product masses exactly. -/
theorem liftPad_bound
    (groups : I→Finset ℕ) (ν : I→ℕ→ℝ) (z : ℤ×ℤ) (D : ℤ)
    (s t : Finset ((ℤ×ℤ)×(∀i,groups i)))
    (hs : ∀p∈s,D∣latticeDet z p.1) (ht : ∀p∈t,D∣latticeDet z p.1)
    (K : ((ℤ×ℤ)×(∀i,groups i))→((ℤ×ℤ)×(∀i,groups i))→ℂ) (M : ℝ)
    (hK : FiniteMeasuredBilinearBound (s.attach.map (liftPad groups z D s hs))
      (t.attach.map (liftPad groups z D t ht))
      (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
      (fun p q=>K (p.1.val,p.2) (q.1.val,q.2)) M) :
    FiniteMeasuredBilinearBound s t (fun p=>∏i,ν i (p.2 i).val)
      (fun p=>∏i,ν i (p.2 i).val) K M := by
  have h := finiteMeasuredBilinearBound_embedding s.attach t.attach
    (liftPad groups z D s hs) (liftPad groups z D t ht) _ _ _ M hK
  change FiniteMeasuredBilinearBound s.attach t.attach
    (fun p=>∏i,ν i (p.val.2 i).val) (fun p=>∏i,ν i (p.val.2 i).val)
    (fun p q=>K p.val q.val) M at h
  intro a b
  have hh := h (fun p=>a p.val) (fun q=>b q.val)
  let μ := fun p : (ℤ×ℤ)×(∀i,groups i)=>∏i,ν i (p.2 i).val
  have hsL : finiteL2 s.attach (fun p=>μ p.val) (fun p=>a p.val)=finiteL2 s μ a := by
    exact congrArg Real.sqrt (Finset.sum_attach s (fun p=>μ p*‖a p‖^2))
  have htL : finiteL2 t.attach (fun p=>μ p.val) (fun p=>b p.val)=finiteL2 t μ b := by
    exact congrArg Real.sqrt (Finset.sum_attach t (fun p=>μ p*‖b p‖^2))
  have hp : finiteMeasuredPairing s.attach t.attach (fun p=>μ p.val) (fun p=>μ p.val)
      (fun p q=>K p.val q.val) (fun p=>a p.val) (fun p=>b p.val)=
      finiteMeasuredPairing s t μ μ K a b := by
    unfold finiteMeasuredPairing finiteKernelApply
    calc
      _ = ∑x∈s.attach,(μ x.val:ℂ)*a x.val*(∑y∈t,(μ y:ℂ)*K x.val y*b y) := by
        apply Finset.sum_congr rfl
        intro x hx
        rw [Finset.sum_attach t (fun y=>(μ y:ℂ)*K x.val y*b y)]
      _ = _ := Finset.sum_attach s (fun x=>(μ x:ℂ)*a x*(∑y∈t,(μ y:ℂ)*K x y*b y))
  change ‖finiteMeasuredPairing s.attach t.attach (fun p=>μ p.val) (fun p=>μ p.val)
    (fun p q=>K p.val q.val) (fun p=>a p.val) (fun p=>b p.val)‖≤
    M*finiteL2 s.attach (fun p=>μ p.val) (fun p=>a p.val)*
      finiteL2 t.attach (fun p=>μ p.val) (fun p=>b p.val) at hh
  rwa [hp,hsL,htL] at hh

/-- The only analytic scalar premise is an explicit bound for all
balanced integer-box budgets; no physical operator bound is assumed. -/
theorem global_source_bound
    (groups : I→Finset ℕ)
    (hprime : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j))
    (ν : I→ℕ→ℝ) (Cweight : I→ℝ) (hCweight : ∀i,0≤Cweight i)
    (hν : ∀i,∀p∈groups i,0≤ν i p) (hνbound : ∀i,∀p∈groups i,ν i p≤Cweight i/p)
    (shared : PhysicalActiveReindex.SharedLists (fun i=>groups i) J)
    (good : (ℤ×ℤ)→PhysicalActiveLists (fun i=>groups i) J→Prop)
    (u v r U W d₀ Y C : ℝ)
    (hU : 0<U) (hu : U≤u) (hu' : u≤16*U)
    (hd : 0<d₀) (hD : d₀≤(sharedProduct groups shared:ℝ))
    (hD' : (sharedProduct groups shared:ℝ)<2*d₀) (hY : 1≤Y) (hC : 0≤C)
    (s t : Finset ((ℤ×ℤ)×(∀i,groups i)))
    (hspos : ∀p∈s,sourcePhysicalPositionAllowed u v r U W p.1)
    (htpos : ∀p∈t,sourcePhysicalPositionAllowed u v r U W p.1)
    (hsgood : ∀p∈s,good p.1 (assemble shared p.2))
    (htgood : ∀p∈t,good p.1 (assemble shared p.2))
    (hsinj : ∀p∈s,∀i,Function.Injective (assemble shared p.2 i))
    (htinj : ∀p∈t,∀i,Function.Injective (assemble shared p.2 i))
    (hfirst : ∀p∈s,∃w,latticeDet p.1 w=1 ∧
      SourceGoodState.FirstGoodTest ((sharedProduct groups shared:ℝ)*latticeTau r w/latticeTau r p.1) Y)
    (hs : ∀p∈s,Y≤((∏i,(p.2 i).val):ℕ))
    (ht : ∀p∈t,Y≤((∏i,(p.2 i).val):ℕ))
    (η : ℝ→ℂ) (hη : ∀x,‖η x‖≤1) (ψ : 𝓢(ℝ,ℂ)) (H : ℝ) (hH : 1≤H) (k : ℕ)
    (Aψ Cmass δ M : ℝ) (hAψ : 0≤Aψ) (hψ : ∀x,‖ψ x‖≤Aψ)
    (hψsupport : ∀x,ψ x≠0→|x|≤C)
    (hmassC : 1≤Cmass) (hδ : 0≤δ) (hM : 0≤M)
    (hmass : ∀i,∑p:groups i,ν i p.val≤Cmass)
    (hatom : ∀i,∀p∈groups i,ν i p≤δ) (σ : ℤ) (hσ : σ=1∨σ= -1)
    (hbudget : ∀A B:ℕ,Y^(1/5:ℝ)≤A→Y^(1/5:ℝ)≤B→
      (A:ℝ)*B≤72*(256*((⌈512*C+1⌉₊:ℝ)+1))^2*Y→
      budget groups Cweight ψ ((⌈512*C+1⌉₊:ℝ)+1) H Y Aψ Cmass δ k A B≤M) :
    FiniteKernelBound s t (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
      (fun p q=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good u v r U W d₀ Y η ψ
        (sourceMajorArcs H Y) σ p.1 (assemble shared p.2) q.1 (assemble shared q.2))
      ((2*⌈512*C+1⌉₊+1:ℕ)*M) := by
  let K := fun p q : (ℤ×ℤ)×(∀i,groups i)=>sourcePhysicalEdgeGeometry (fun _ p=>p.val) good
    u v r U W d₀ Y η ψ (sourceMajorArcs H Y) σ p.1 (assemble shared p.2) q.1 (assemble shared q.2)
  have hallowed (p q : (ℤ×ℤ)×(∀i,groups i)) (hn : K p q≠0) :
      sourcePhysicalEdgeAllowed (fun _ p=>p.val) good u v r U W d₀ p.1 (assemble shared p.2) q.1 (assemble shared q.2) := by
    by_contra hn'
    simp [K,sourcePhysicalEdgeGeometry,hn'] at hn
  apply PhysicalCleanGlobal.global_bound_from_source_base s t (fun z : ℤ×ℤ=>z) Prod.fst Prod.fst
    (fun p hp=>(hspos p hp).1) (fun p hp=>(htpos p hp).1)
    (sharedProduct groups shared:ℤ) r d₀ Y (512*C) hd (by linarith)
    (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val) K M
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property))
    (fun p _=>Finset.prod_nonneg (fun i _=>hν i _ (p.2 i).property)) hM
  · intro p hp q hq hn
    have hh := (hallowed p q hn).2.2.2.2.2.2.2
    simpa only [padProduct_assemble] using hh
  · intro p hp q hq hn
    have hdet := source_geometry_nonzero_det_bound (fun i (p:groups i)=>p.val) good
      u v r U W d₀ Y C η ψ (sourceMajorArcs H Y) σ hd (by linarith) hC hψsupport
      p.1 q.1 (assemble shared p.2) (assemble shared q.2) hn
    have hpτ := sourcePhysicalPosition_tau_bounds u v r U W p.1 hU hu hu' (hspos p hp)
    have hqτ := sourcePhysicalPosition_tau_bounds u v r U W q.1 hU hu hu' (htpos q hq)
    have hh := latticeSlope_step_le r (1/16) (2*d₀*Y*C) p.1 q.1 (by norm_num)
      (by positivity) hpτ.1 hqτ.1 hdet
    change |latticeSlope r p.1-latticeSlope r q.1|≤_
    rw [abs_sub_comm]
    convert hh using 1 <;> ring
  · intro p₀ hp₀ s' hss t' htt hsgeo htgeo
    obtain ⟨w,hw,hg⟩ := hfirst p₀ hp₀
    let D : ℤ := sharedProduct groups shared
    have hsdiv : ∀p∈s',D∣latticeDet p₀.1 p.1 := fun p hp=>(hsgeo p hp).1
    have htdiv : ∀p∈t',D∣latticeDet p₀.1 p.1 := fun p hp=>(htgeo p hp).1
    let e := liftPad groups p₀.1 D s' hsdiv
    let f := liftPad groups p₀.1 D t' htdiv
    let sp := s'.attach.map e
    let tp := t'.attach.map f
    have hsp {P : ((ℤ×ℤ)×(∀i,groups i))→Prop} (hh : ∀p∈s',P p) :
        ∀p∈sp,P (p.1.val,p.2) := by
      intro p hp
      obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp
      exact hh q.val q.property
    have htp {P : ((ℤ×ℤ)×(∀i,groups i))→Prop} (hh : ∀p∈t',P p) :
        ∀p∈tp,P (p.1.val,p.2) := by
      intro p hp
      obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp hp
      exact hh q.val q.property
    obtain ⟨A,B,hA,hB,harea,hbound⟩ := source_good_pad_cell_bound groups hprime hdis ν Cweight hCweight hν hνbound
      shared good p₀.1 w hw u v r U W d₀ Y ((⌈512*C+1⌉₊:ℝ)+1) hU hu hu' hd hD hD' hY (by have hh := Nat.cast_nonneg (α:=ℝ) ⌈512*C+1⌉₊; linarith)
      (hspos p₀ hp₀) hg sp tp
      (hsp (fun p hp=>hspos p (hss hp))) (htp (fun p hp=>htpos p (htt hp)))
      (hsp (fun p hp=>hsgood p (hss hp))) (htp (fun p hp=>htgood p (htt hp)))
      (hsp (fun p hp=>hsinj p (hss hp))) (htp (fun p hp=>htinj p (htt hp)))
      (by intro p hp; rw [abs_sub_comm]; exact hsp (fun p hp=>(hsgeo p hp).2) p hp)
      (by intro p hp; rw [abs_sub_comm]; exact htp (fun p hp=>(htgeo p hp).2) p hp)
      (hsp (fun p hp=>hs p (hss hp))) (htp (fun p hp=>ht p (htt hp)))
      η hη ψ H hH k Aψ Cmass δ hAψ hψ hmassC hδ hmass hatom σ hσ
    have hb : FiniteMeasuredBilinearBound sp tp
        (fun p=>∏i,ν i (p.2 i).val) (fun p=>∏i,ν i (p.2 i).val)
        (fun p q=>K (p.1.val,p.2) (q.1.val,q.2)) M := by
      intro a b
      exact (hbound a b).trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right (hbudget A B hA hB harea) (Real.sqrt_nonneg _)) (Real.sqrt_nonneg _))
    exact liftPad_bound groups ν p₀.1 D s' t' hsdiv htdiv K M hb

end PhysicalCleanOperator
end Elliptic.Operator
