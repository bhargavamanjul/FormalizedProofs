module
public import Elliptic.Operator.SignedPhysicalPadRecovery
public import Elliptic.Operator.SignedPhysicalPadDyadSum

/-! Concrete finite transfer from the actual physical operator to the
normalized unpadded scalar determinant error. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalPairBridge
open scoped BigOperators
open SignedPadDyads SignedPhysicalPadMass SingleEdgePhysicalRestoration
open Artin Artin.MarkedCriterion Artin.MarkedSource
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

theorem sum_four_swap {R : Type*} [AddCommMonoid R] (S T : Finset ℕ)
    (F : ℕ→ℕ→ℕ→ℕ→R) :
    (∑m∈S,∑q∈T,∑r∈S,∑n∈T,F m n r q)=∑m∈S,∑n∈T,∑r∈S,∑q∈T,F m n r q := by
  apply Finset.sum_congr rfl
  intro m hm
  rw [Finset.sum_comm]
  calc
    _ = ∑r∈S,∑n∈T,∑q∈T,F m n r q := by
      apply Finset.sum_congr rfl
      intro r hr
      rw [Finset.sum_comm]
    _ = _ := Finset.sum_comm

variable {K : ℕ}

def scalarPairSum (groups : Fin K→Finset ℕ) (Vmass : Fin K→ℝ)
    (S T : Finset ℕ) (Y H : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  ∑a : ∀i,groups i,∑b : ∀i,groups i,
    if (∏i,(a i).val).Coprime (∏i,(b i).val) then
      ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*∑m∈S,∑n∈T,∑r∈S,∑q∈T,
        scalarError (∏i,(a i).val) (∏i,(b i).val) m n r q Y H η ψ α β else 0

def scalarAbsoluteSum (groups : Fin K→Finset ℕ)
    (S T : Finset ℕ) (Y H : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) : ℝ :=
  ∑a : ∀i,groups i,∑b : ∀i,groups i,
    if (∏i,(a i).val).Coprime (∏i,(b i).val) then
      ∑m∈S,∑n∈T,∑r∈S,∑q∈T,
        ‖scalarError (∏i,(a i).val) (∏i,(b i).val) m n r q Y H η ψ α β‖ else 0

theorem scalarPairSum_eq_swapped (groups : Fin K→Finset ℕ) (Vmass : Fin K→ℝ)
    (S T : Finset ℕ) (Y H : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    scalarPairSum groups Vmass S T Y H η ψ α β=
    ∑a : ∀i,groups i,∑b : ∀i,groups i,
      if (∏i,(a i).val).Coprime (∏i,(b i).val) then
        ((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*∑m∈S,∑q∈T,∑r∈S,∑n∈T,
          scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β else 0 := by
  unfold scalarPairSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro b hb
  rw [sum_four_swap]
  congr 1
  exact propext Nat.coprime_comm

theorem scalarAbsoluteSum_eq_swapped (groups : Fin K→Finset ℕ)
    (S T : Finset ℕ) (Y H : ℝ) (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) :
    scalarAbsoluteSum groups S T Y H η ψ α β=
    ∑a : ∀i,groups i,∑b : ∀i,groups i,
      if (∏i,(a i).val).Coprime (∏i,(b i).val) then
        ∑m∈S,∑q∈T,∑r∈S,∑n∈T,
          ‖scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β‖ else 0 := by
  unfold scalarAbsoluteSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro b hb
  rw [sum_four_swap]
  congr 1
  exact propext Nat.coprime_comm

theorem norm_four_sum_le (S T : Finset ℕ) (F : ℕ→ℕ→ℕ→ℕ→ℂ) :
    ‖∑m∈S,∑q∈T,∑r∈S,∑n∈T,F m n r q‖≤
      ∑m∈S,∑q∈T,∑r∈S,∑n∈T,‖F m n r q‖ := by
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro m hm
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro q hq
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro r hr
  exact norm_sum_le _ _

theorem scalarError_norm_le_physical_plus_pad_loss {K J : ℕ} (hK : 0<K)
    (groups : Fin K→Finset ℕ) (hp : ∀i,∀p∈groups i,p.Prime)
    (hdis : ∀i k,i≠k→Disjoint (groups i) (groups k))
    (W : ℝ) (hsmall : ∀i,∀p∈groups i,(p:ℝ)≤W)
    (S T : Finset ℕ) (Hm Hn : ℝ) (hHm : 0≤Hm) (hHn : 0≤Hn)
    (hS : InDyad Hm S) (hT : InDyad Hn T)
    (α β : ℕ→ℂ)
    (hroughS : ∀m∈S,α m≠0→IsRough W m) (hroughT : ∀n∈T,β n≠0→IsRough W n)
    (Vmass : Fin K→ℝ) (Θ Y H C : ℝ) (hY : 0<Y) (hCY : C*Y≤W)
    (η ψ : ℝ→ℂ) (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hψ : ∀t,ψ t≠0→|t|≤C)
    (hheight : ∀(pads : ∀i,Fin J→groups i) (a : ∀i,groups i),
      ((∏i,∏j,(pads i j).val:ℕ):ℝ)≤Real.exp Θ)
    (vmin pmin : ℝ) (hvmin : 0<vmin) (hpmin : 0<pmin)
    (hV : ∀i,vmin≤Vmass i) (hpmin' : ∀i,∀p∈groups i,pmin≤(p:ℝ))
    (hVsum : ∀i,Vmass i=∑p : groups i,1/(p.val:ℝ)) :


    ‖scalarPairSum groups Vmass S T Y H η ψ α β‖≤
      ‖∑j∈padDyads Θ,
        originalPairing (J:=J) (fun i=>fun p : groups i=>p.val) Vmass (fun _ _=>True)
          ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
          (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
          (((2:ℝ)^j:ℝ):ℂ)‖+
      ((K:ℝ)*((J:ℝ)*(J+3)/2)/(vmin*pmin))*(∏i,(Vmass i)⁻¹^2)*
        scalarAbsoluteSum groups S T Y H η ψ α β := by
  let value := fun i=>fun p : groups i=>p.val
  let F := fun a b : ∀i,groups i=>((∏i,(Vmass i)⁻¹^2:ℝ):ℂ)*
    ∑m∈S,∑q∈T,∑r∈S,∑n∈T,scalarError (∏i,(b i).val) (∏i,(a i).val) m n r q Y H η ψ α β
  have hVpos i : 0<Vmass i := hvmin.trans_le (hV i)
  have hrecovery := coprime_pad_recovery_norm_le (J:=J) value (fun i p=>hp i p.val p.property)
    (groupValue_injective groups hdis) (harmonicMass value Vmass)
    (harmonicMass_nonneg value Vmass (fun i=>(hVpos i).le))
    (harmonicMass_sum value Vmass (fun i=>(hVpos i).ne') hVsum)
    (1/(vmin*pmin)) (by positivity)
    (harmonicMass_atom_le value Vmass vmin pmin hvmin hpmin hV (fun i p=>hpmin' i p.val p.property)) F
  have he := sum_padDyads_originalPairing_div_eq_padded hK groups hp hdis W hsmall S T Hm Hn hHm hHn hS hT
    α β hroughS hroughT Vmass Θ Y H C hY hCY η ψ hη hψ hheight
  have hscalar := scalarPairSum_eq_swapped groups Vmass S T Y H η ψ α β
  change _=∑a,∑b,if (∏i,value i (a i)).Coprime (∏i,value i (b i)) then F a b else 0 at hscalar
  rw [←hscalar,←he] at hrecovery
  have hnorm0 : 0≤(∏i,(Vmass i)⁻¹^2:ℝ) := Finset.prod_nonneg (fun i _=>sq_nonneg _)
  have hsum : (∑a,∑b,if (∏i,value i (a i)).Coprime (∏i,value i (b i)) then ‖F a b‖ else 0)≤
      (∏i,(Vmass i)⁻¹^2)*scalarAbsoluteSum groups S T Y H η ψ α β := by
    rw [scalarAbsoluteSum_eq_swapped,Finset.mul_sum]
    apply Finset.sum_le_sum
    intro a ha
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro b hb
    by_cases hc : (∏i,value i (a i)).Coprime (∏i,value i (b i))
    · simp only [value] at hc ⊢
      rw [ite_eq_left hc,ite_eq_left hc]
      simp only [F,norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hnorm0]
      exact mul_le_mul_of_nonneg_left (norm_four_sum_le S T _) hnorm0
    · simp only [value] at hc ⊢
      rw [ite_eq_right hc,ite_eq_right hc]
      simp
  have hcost : 0≤(K:ℝ)*((J:ℝ)*(J+3)/2)*(1/(vmin*pmin)) := by positivity
  have hh := hrecovery.trans (mul_le_mul_of_nonneg_left hsum hcost)
  have htri := norm_add_le (scalarPairSum groups Vmass S T Y H η ψ α β-
    (∑j∈padDyads Θ,originalPairing (J:=J) value Vmass (fun _ _=>True)
      ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
      (((2:ℝ)^j:ℝ):ℂ)))
    (∑j∈padDyads Θ,originalPairing (J:=J) value Vmass (fun _ _=>True)
      ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
      (((2:ℝ)^j:ℝ):ℂ))
  rw [sub_add_cancel] at htri
  apply htri.trans
  have hfinal := add_le_add_right hh ‖∑j∈padDyads Θ,originalPairing (J:=J) value Vmass (fun _ _=>True)
      ((2:ℝ)^j*Y*Hm) Hn ((2:ℝ)^j) Y H η ψ (-1)
      (fun za=>completeLeft groups J S T α β za.1) (fun wb=>completeRight groups J S T α β wb.1)/
      (((2:ℝ)^j:ℝ):ℂ)‖
  convert hfinal using 1 <;> ring

end Elliptic.Operator.SignedPhysicalPairBridge
