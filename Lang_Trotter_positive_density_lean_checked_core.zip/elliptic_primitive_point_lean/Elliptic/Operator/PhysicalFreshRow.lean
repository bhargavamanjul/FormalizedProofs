module

public import Elliptic.Operator.PhysicalDirtyCrude

/-! # Bounded raw rows without promotions
The exact indexed mode cardinality gives a bound independent of the memory
cutoff when every target label is fresh; arbitrary stores are retained.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFreshRow
open scoped BigOperators
open PhysicalDirtyCrude
attribute [local instance] Classical.propDecidable
local instance freshRowDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
variable {K J B : ℕ} {Z : Type} {P : Fin K → Type}
variable (value : ∀ i, P i → ℕ) (position : Z → ℤ × ℤ)
variable (s : PhysicalMemoryState (Z:=Z) P (fun i p => Option (ZMod (value i p))) J B)
variable [Fintype Z] [∀ i, Fintype (P i)]

/-- The literal mode cardinalities, with both factorial averages canceled. -/
theorem endpoint_averaged_sum_le_exact_count
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool)
    (mode : ∀ i, Option (Fin (s.memory P (fun i p => Option (ZMod (value i p))) J B i).size ⊕ P i))
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀ c ∈ S, PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hmode : ∀ c ∈ S, ∀ i, c.group i ∈ dirtyGroupChoices
      (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * (∏ i, ((dirtyGroupChoices
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)).card : ℝ)) *
      ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
        (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i) := by
  let modes := Fintype.piFinset (fun i => dirtyGroupChoices
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i))
  let keys : Finset (Key value s) := Finset.univ.product (modes.product Finset.univ)
  let C := ∏ i, dirtyGroupCoefficient (ν i) (V i) ρ v0
    (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)
  have hC : 0 ≤ C := Finset.prod_nonneg fun i _ => dirtyGroupCoefficient_nonneg
    (ν i) (V i) ρ v0 _ _ _ (hν i) (hV i) hρ1 hv0.le
  have hmap : ∀ c ∈ S, key value s c ∈ keys := by
    intro c hc
    apply Finset.mem_product.mpr
    refine ⟨Finset.mem_univ _, Finset.mem_product.mpr ⟨?_,Finset.mem_univ _⟩⟩
    exact Fintype.mem_piFinset.mpr (hmode c hc)
  have hf (k : Key value s) :
      (∑ c ∈ S.filter (fun c => key value s c = k),
        PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤ 33*C := by
    have hc : (S.filter (fun c => key value s c = k)).card ≤ 33 := by
      apply fixed_key_card_le value position s hposition good u v r U W d₀ σ hU w hzw
      · intro c hc
        exact hS c (Finset.mem_filter.mp hc).1
      · intro c hc d hd
        exact (Finset.mem_filter.mp hc).2.trans (Finset.mem_filter.mp hd).2.symm
    calc
      _ ≤ ∑ _c ∈ S.filter (fun c => key value s c = k), C := by
        apply Finset.sum_le_sum
        intro c hc
        exact choiceWeight_le value position s ν V ρ v0 store mode c
          (hmode c (Finset.mem_filter.mp hc).1) hν hV hρ0 hρ1 hv0
      _ = (S.filter (fun c => key value s c = k)).card * C := by simp
      _ ≤ 33*C := mul_le_mul_of_nonneg_right (by exact_mod_cast hc) hC
  have hsum : (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      keys.card * (33*C) := by
    rw [← Finset.sum_fiberwise_of_maps_to hmap (PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0)]
    calc
      _ ≤ ∑ _k ∈ keys, 33*C := Finset.sum_le_sum fun k _ => hf k
      _ = _ := by simp
  let n : ℝ := Fintype.card (Fin K → Equiv.Perm (Fin (J+1)))
  have hn : n ≠ 0 := by dsimp [n]; positivity
  have hk : (keys.card : ℝ) = n * ((modes.card : ℝ) * n) := by
    have h₁ := Finset.card_product
      (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))
      (modes.product (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1)))))
    change keys.card = _ at h₁
    have h₂ := Finset.card_product modes
      (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))
    change (modes.product (Finset.univ : Finset (Fin K → Equiv.Perm (Fin (J+1))))).card = _ at h₂
    rw [h₂, Finset.card_univ] at h₁
    dsimp only [n]
    exact_mod_cast h₁
  calc
    _ ≤ endpointPermutationWeight (Fin K) J * (keys.card * (33*C)) :=
      mul_le_mul_of_nonneg_left hsum (by unfold endpointPermutationWeight; positivity)
    _ = 33 * modes.card * C := by
      rw [hk]
      simp only [endpointPermutationWeight, n, Fintype.card_fun, Fintype.card_perm, Fintype.card_fin] at *
      field_simp
    _ = _ := by
      have hm : (modes.card : ℝ) = ∏ i, ((dirtyGroupChoices
          (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (store i) (mode i)).card : ℝ) := by
        rw [Fintype.card_piFinset]
        simp only [Nat.cast_prod]
      rw [hm]

/-- Fixed fresh prime draws retain their original masses and allow every
store pattern, with no dependence on the memory cutoff. -/
theorem fixed_fresh_sum_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 : ℝ)
    (store : Fin K → Bool) (fresh : ∀ i, P i)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀ c ∈ S, PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hgroups : ∀ c ∈ S, ∀ i, c.group i = (store i,Sum.inr (fresh i)))
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * ∏ i, ν i (fresh i) * v0 ^ (store i).toNat := by
  have h := endpoint_averaged_sum_le_exact_count value position s hposition ν V ρ v0 store
    (fun i => some (Sum.inr (fresh i))) good u v r U W d₀ σ hU w hzw S hS
    (fun c hc i => by simp only [dirtyGroupChoices,Finset.mem_singleton]; exact hgroups c hc i)
    hν hV hρ0 hρ1 hv0
  simpa only [dirtyGroupChoices,Finset.card_singleton,Nat.cast_one,Finset.prod_const_one,
    mul_one,dirtyGroupCoefficient] using h

/-- Numeric keys for arbitrary store choices and all fresh prime draws. -/
abbrev FreshKey := ∀ i : Fin K, Bool × P i

def freshKey (c : PhysicalEdgeChoice s) : FreshKey (P:=P) :=
  fun i => ((c.group i).1, edgeTargetPrime (s.memory P (fun i p => Option (ZMod (value i p))) J B i) (c.group i))

/-- An edge with no promotions reconstructs exactly from its fresh key. -/
theorem group_eq_freshKey (c : PhysicalEdgeChoice s) (h : c.promotedGroups = ∅) (i : Fin K) :
    c.group i = ((freshKey value s c i).1, Sum.inr (freshKey value s c i).2) := by
  cases he : (c.group i).2 with
  | inl a =>
      have hi : i ∈ c.promotedGroups := by simp [PhysicalEdgeChoice.promotedGroups,he]
      simpa [h] using hi
  | inr p =>
      apply Prod.ext
      · rfl
      · simp only [freshKey,edgeTargetPrime,he]

/-- Product integration of the literal store/fresh coefficient. -/
theorem sum_fresh_coeff_le
    (ν : ∀ i, P i → ℝ) (v0 mass : ℝ)
    (hν : ∀ i p, 0 ≤ ν i p) (hv0 : 0 ≤ v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    (∑ k : FreshKey (P:=P), ∏ i, ν i (k i).2 * v0 ^ (k i).1.toNat) ≤
      ((1+v0)*mass)^K := by
  change (∑ k : ∀ i, Bool × P i, ∏ i, ν i (k i).2 * v0 ^ (k i).1.toNat) ≤ _
  rw [← Fintype.prod_sum (fun i (k : Bool × P i) => ν i k.2 * v0 ^ k.1.toNat)]
  calc
    _ ≤ ∏ _i : Fin K, ((1+v0)*mass) := by
      apply Finset.prod_le_prod₀
      · intro i _
        exact Finset.sum_nonneg fun k _ => mul_nonneg (hν i _) (pow_nonneg hv0 _)
      · intro i _
        have he : (∑ k : Bool × P i, ν i k.2 * v0 ^ k.1.toNat) =
            (1+v0) * ∑ p, ν i p := by
          simp only [Fintype.sum_prod_type,Fintype.sum_bool,Bool.toNat_true,Bool.toNat_false,
            pow_one,pow_zero,mul_one,← Finset.sum_mul]
          ring
        rw [he]
        exact mul_le_mul_of_nonneg_left (hmass i) (by positivity)
    _ = _ := by simp

/-- The actual raw no-promotion row, including all stores, is bounded
independently of B. This is the bounded Schur side paired with a small
promotion side in the source's four-case dirty table. -/
theorem no_promotion_row_le
    (hposition : Function.Injective position)
    (ν : ∀ i, P i → ℝ) (V : Fin K → ℝ) (ρ v0 mass : ℝ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (u v r U W d₀ : ℝ) (σ : ℤ) (hU : 0 < U)
    (w : ℤ × ℤ)
    (hzw : latticeDet (position (s.position P (fun i p => Option (ZMod (value i p))) J B)) w = 1)
    (S : Finset (PhysicalEdgeChoice s))
    (hS : ∀ c ∈ S, PhysicalDirtyCoordinates.RawSupport value position s good u v r U W d₀ σ c)
    (hprom : ∀ c ∈ S, c.promotedGroups = ∅)
    (hν : ∀ i p, 0 ≤ ν i p) (hV : ∀ i, 0 ≤ V i)
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hv0 : 0 < v0)
    (hmass : ∀ i, (∑ p, ν i p) ≤ mass) :
    endpointPermutationWeight (Fin K) J *
      (∑ c ∈ S, PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
      33 * ((1+v0)*mass)^K := by
  have hf (k : FreshKey (P:=P)) :
      endpointPermutationWeight (Fin K) J *
        (∑ c ∈ S.filter (fun c => freshKey value s c = k),
          PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) ≤
        33 * ∏ i, ν i (k i).2 * v0 ^ (k i).1.toNat := by
    apply fixed_fresh_sum_le value position s hposition ν V ρ v0
      (fun i => (k i).1) (fun i => (k i).2) good u v r U W d₀ σ hU w hzw
    · intro c hc
      exact hS c (Finset.mem_filter.mp hc).1
    · intro c hc i
      have h := group_eq_freshKey value s c (hprom c (Finset.mem_filter.mp hc).1) i
      rw [(Finset.mem_filter.mp hc).2] at h
      exact h
    · exact hν
    · exact hV
    · exact hρ0
    · exact hρ1
    · exact hv0
  calc
    _ = ∑ k : FreshKey (P:=P), endpointPermutationWeight (Fin K) J *
        (∑ c ∈ S.filter (fun c => freshKey value s c = k),
          PhysicalDirtyWeighted.choiceWeight value position s ν V ρ v0 c) := by
      rw [← Finset.mul_sum, Finset.sum_fiberwise_of_maps_to
        (fun c (_hc : c ∈ S) => Finset.mem_univ (freshKey value s c))]
    _ ≤ ∑ k : FreshKey (P:=P), 33 * ∏ i, ν i (k i).2 * v0 ^ (k i).1.toNat :=
      Finset.sum_le_sum fun k _ => hf k
    _ = 33 * ∑ k : FreshKey (P:=P), ∏ i, ν i (k i).2 * v0 ^ (k i).1.toNat := by
      rw [Finset.mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (sum_fresh_coeff_le ν v0 mass hν hv0.le hmass)
      (by norm_num)

end Elliptic.Operator.PhysicalFreshRow
