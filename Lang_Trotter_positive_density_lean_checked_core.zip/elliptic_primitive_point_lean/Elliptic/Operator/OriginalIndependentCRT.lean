module

public import Elliptic.Operator.RootRecordIntegral
public import Elliptic.Operator.OriginalBoundaryTail

/-!
# Literal grouped-prime CRT average of the original path factors

The coupled finite residue test is the actual product of active incidences
and inactive damping, with one optional projective line per original prime.
Its uniform average is exactly the independent average already identified
with the chronological boundary operator.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalIndependentCRT
open scoped BigOperators
open OriginalLifespanSchedule IndependentLineNormalization
attribute [local instance] Classical.propDecidable
local instance originalCRTDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J N : ℕ}

/-- The full coupled test before taking its independent line average. -/
def coupledLineTest (anchor : Z→∀i p,Line i p) (η : ℕ→ℝ)
    (r : OriginalPath I Z P J N) (ℓ : ∀s : Sigma P,Line s.1 s.2) : ℂ :=
  ((∏s : Sigma P,lineFactor (Finset.range (N+1)) (r.activeVisits s.1 s.2)
    (fun j=>anchor (r.positionAt j) s.1 s.2) η (ℓ s) : ℝ) : ℂ)

/-- No independence hypothesis is assumed: finite distributivity proves
that the coupled uniform average is the product of the literal marginals. -/
theorem coupledLineTest_average (anchor : Z→∀i p,Line i p) (η : ℕ→ℝ)
    (r : OriginalPath I Z P J N) :
    (∑ℓ : ∀s : Sigma P,Line s.1 s.2,coupledLineTest anchor η r ℓ) /
      (∏s : Sigma P,(Fintype.card (Line s.1 s.2):ℂ)) = (r.independentAverage anchor η:ℂ) := by
  have h := independent_line_average_factorization (fun s : Sigma P=>Line s.1 s.2)
    (fun _=>Finset.range (N+1)) (fun s=>r.activeVisits s.1 s.2)
    (fun s j=>anchor (r.positionAt j) s.1 s.2) (fun _=>η)
  rw [Finset.prod_inv_distrib] at h
  have hc := congrArg (fun t : ℝ=>(t:ℂ)) h
  simp only [Complex.ofReal_mul,Complex.ofReal_inv,Complex.ofReal_prod,Complex.ofReal_sum,
    Complex.ofReal_natCast] at hc
  rw [mul_comm] at hc
  simp only [coupledLineTest,div_eq_mul_inv,Fintype.prod_sigma,OriginalPath.independentAverage,Complex.ofReal_prod] at hc ⊢
  convert hc using 1
  congr 2
  ext ℓ
  simp only [Finset.mem_univ]

section PrimeLines
variable (value : ∀i,P i→ℕ) [∀i p,Fact (value i p).Prime]

/-- The denominator is exactly the product of the actual p+1 line counts. -/
theorem coupledLineTest_prime_average
    (anchor : Z→∀i p,Option (ZMod (value i p))) (η : ℕ→ℝ)
    (r : OriginalPath I Z P J N) :
    (∑ℓ : ∀s : Sigma P,Option (ZMod (value s.1 s.2)),coupledLineTest anchor η r ℓ) /
      ((∏s : Sigma P,(value s.1 s.2+1):ℕ):ℂ) = (r.independentAverage anchor η:ℂ) := by
  have h := coupledLineTest_average anchor η r
  simpa only [RootResidues.card_prime_option_lines,Nat.cast_prod] using h

/-- CRT identifies the full matrix average with the already verified
independent model. This finite identity makes no analytic claim for the
large product modulus; analytic replacement uses the smaller subset moduli. -/
theorem crt_average_eq_independentAverage
    (hp : Pairwise (fun a b : Sigma P=>(value a.1 a.2).Coprime (value b.1 b.2)))
    [Fintype (ZMod (∏s : Sigma P,value s.1 s.2))]
    (anchor : Z→∀i p,Option (ZMod (value i p))) (η : ℕ→ℝ)
    (r : OriginalPath I Z P J N) :
    (∑g : Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏s : Sigma P,value s.1 s.2)),
      coupledLineTest anchor η r (fun s=>RootResidues.projectiveLineEquivOption (ZMod (value s.1 s.2))
        (RootResidues.kernelLine (ZMod (value s.1 s.2))
          (RootResidues.sl2CRT (fun s : Sigma P=>value s.1 s.2) hp g s)))) /
      (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (∏s : Sigma P,value s.1 s.2))):ℂ) =
      (r.independentAverage anchor η:ℂ) := by
  rw [RootResidues.crt_kernel_option_average, coupledLineTest_prime_average]

end PrimeLines
end Elliptic.Operator.OriginalIndependentCRT
