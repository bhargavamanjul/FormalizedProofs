module

public import Elliptic.Operator.PhysicalMaskedSchur

/-! Exact decomposition of the literal dirty physical operator into its
store/promotion masks. Dirty means at least one store or one promotion. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalDirtyMasks
open scoped BigOperators
open PhysicalMaskedKernel PhysicalMaskedChoices PhysicalMaskedIdentification PhysicalMaskedSchur
attribute [local instance] Classical.propDecidable
local instance maskDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {G : Type*} [Fintype G]

abbrev Mask := (G → Bool) × (G → Bool)

def Dirty (m : Mask (G:=G)) : Prop := ∃i,m.1 i=true ∨ m.2 i=true

def dirtyMasks : Finset (Mask (G:=G)) := Finset.univ.filter Dirty

theorem match_iff (S I : G → Bool) (m : Mask (G:=G)) :
    (∀i,S i=m.1 i ∧ I i=m.2 i) ↔ (S,I)=m := by
  constructor
  · intro h
    exact Prod.ext (funext fun i=>(h i).1) (funext fun i=>(h i).2)
  · rintro rfl
    simp

theorem masks_card_le : (dirtyMasks (G:=G)).card≤4^Fintype.card G := by
  calc
    _ ≤ Fintype.card (Mask (G:=G)) := Finset.card_le_card (Finset.filter_subset _ _)
    _ = _ := by simp [Mask,Fintype.card_prod,Fintype.card_fun,←mul_pow]

variable {Z : Type*} [Fintype Z] {J B : ℕ}
variable {P : G → Type*} [∀ i,Fintype (P i)]
variable {Line : ∀i,P i→Type*} [∀i p,Fintype (Line i p)]

/-- Literal dirty action, retaining both actual endpoint permutations and
the total memory cutoff. -/
def dirtyApply (ν : ∀i,P i→ℝ) (V : G→ℝ) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  ∑c : PhysicalEdgeChoice s, if hc : c.Valid anchor s then
    if ∃i,(c.group i).1=true ∨ edgeChoicePromotes (c.group i)=true then
      physicalEdgeChoiceWeight ν V ρ anchor geometry s c hc * F (ofOrdered (c.output anchor s hc))
    else 0
  else 0

/-- Every literal dirty indexed choice occurs in exactly one mask. -/
theorem dirtyApply_eq_sum (ν : ∀i,P i→ℝ) (V : G→ℝ) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    dirtyApply ν V ρ anchor geometry F s =
      ∑m∈dirtyMasks,originalMaskedApply ν V m.1 m.2 ρ anchor geometry F s := by
  unfold dirtyApply originalMaskedApply
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : c.Valid anchor s
  · simp only [dite_eq_left hc]
    simp_rw [match_iff]
    simp only [Finset.sum_ite_eq,Finset.mem_filter,Finset.mem_univ,true_and,dirtyMasks,Dirty]
  · simp [hc]

/-- The exact collected bag matrix of all dirty masks. -/
def dirtyKernel (ν : ∀i,P i→ℝ) (V : G→ℝ) (ρ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (s t : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)) : ℂ :=
  ∑m∈dirtyMasks,originalKernel ν V m.1 m.2 ρ anchor geometry s t

/-- Collecting equal outputs does not change the literal dirty action. -/
theorem dirtyApply_eq_kernel (ν : ∀i,P i→ℝ) (hν : ∀i p,ν i p≠0)
    (V : G→ℝ) (ρ : ℝ) (anchor : Z→∀i p,Line i p)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (F : State (Z:=Z) (P:=P) (Line:=Line) (J:=J) (B:=B)→ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    dirtyApply ν V ρ anchor geometry F s =
      ∑t,dirtyKernel ν V ρ anchor geometry (ofOrdered s) t*F t := by
  have hn : ∀i p,(ν i p:ℂ)≠0 := by intro i p;exact_mod_cast hν i p
  have h (m : Mask (G:=G)) := PhysicalMaskedIdentification.physicalApply_eq_kernel
    (fun i p=>(ν i p:ℂ)) hn (fun _=>1) (fun i=>(V i:ℂ)⁻¹)
    m.1 m.2 (ρ:ℂ) anchor geometry F s
  simp_rw [PhysicalMaskedChoices.physicalApply_original] at h
  rw [dirtyApply_eq_sum]
  simp_rw [h]
  unfold dirtyKernel originalKernel
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]

end Elliptic.Operator.PhysicalDirtyMasks
