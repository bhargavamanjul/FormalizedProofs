module

public import Elliptic.Operator.OriginalBoundaryCutoff
public import Elliptic.Operator.OriginalPathSupport

/-!
# Quantified reduction of the independent model to the actual memory cap

The exact large-cap identity and the exact cap-change bridge are combined
with the previously proved doubled-birth truncation estimate. Both boundary
vectors and their actual initial mass are included in the error. No tail
estimate is imported as a new assumption.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalLifespanSchedule
open scoped BigOperators ComplexConjugate
open CanonicalBoundaryAssembly OriginalLeaf IndependentLineNormalization
attribute [local instance] Classical.propDecidable
local instance boundaryTailDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i→Type} {J B N : ℕ}
variable {anchor : Z→∀ i p,Line i p}

/-- Empty-memory boundary data have the literal vacuum Schur bound. -/
theorem vacuumLift_norm_le_schur (b : BoundaryIndex I Z P J→ℂ)
    (hb : ∀ x,‖b x‖≤1) (v : ℝ) (hv : 0≤v)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    ‖vacuumLift b s‖≤physicalMemorySchurWeight v s := by
  by_cases hs : ∀ i,(s.memory P Line J B i).size=0
  · have hz : physicalMemorySize s=0 := by simp only [physicalMemorySize,hs,Finset.sum_const_zero]
    simpa [vacuumLift, hs, physicalMemorySchurWeight, physicalMemorySize] using hb (boundaryIndex s)
  · simp only [vacuumLift,hs,ite_false,norm_zero,physicalMemorySchurWeight]
    exact pow_nonneg hv _

/-- Initial endpoint mass and left vector, exactly as in the true pairing. -/
def initialBoundaryNorm (ν : ∀ i,P i→ℝ) (a : BoundaryIndex I Z P J→ℂ) : ℝ :=
  ∑ u : BoundaryIndex I Z P J,
    ‖(PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ)‖*‖a u‖

/-- The entire actual boundary tail is bounded by concrete ghost/edge row
constants derived from the literal operations. -/
theorem boundary_cap_tail_explicit
    (value : ∀ i,P i→ℕ) (ν μ : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ)
    (ρ Q Vmax s G : ℝ)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (hν0 : ∀ i p,0≤ν i p) (hs : ∀ i,(∑p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤q j) (hqQ : ∀ j,q j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hV : ∀ i,V i≠0) (hVmax : ∀ i,V i≤Vmax)
    (hν : ∀ i p,V i*ν i p=μ i p)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (T : ℕ) (hTB : T≤B) (hT : Fintype.card I*N≤T)
    (a b : BoundaryIndex I Z P J→ℂ) (hb : ∀ x,‖b x‖≤1) :
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    ‖boundaryPairing (B:=B) ν V η q ρ anchor geometry value N a b-
      boundaryPairing (B:=T) ν V η q ρ anchor geometry value N a b‖ ≤
      initialBoundaryNorm (Line:=Line) (B:=B) ν a *
        (((2:ℝ)^(T-Fintype.card I*N))⁻¹*(Cghost^(N+1)*Cedge^N)) := by
  dsimp only
  rw [← cutoffBoundaryPairing_eq_small_cap value ν V η q ρ geometry hvalue hshared hban
    μ hρ.ne' hV hν T hTB]
  unfold boundaryPairing cutoffBoundaryPairing
  rw [← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ u : BoundaryIndex I Z P J,
        ‖(PhysicalMemoryState.mass P Line J B ν (emptyState (Line:=Line) (B:=B) u) : ℂ)‖*‖a u‖*
        (((2:ℝ)^(T-Fintype.card I*N))⁻¹*
          ((Real.exp (ghostSchurWeight ρ Q (2*Vmax)*max 1 (2*Vmax)*s/ρ))^(Fintype.card I))^(N+1)*
          ((Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ
            (ghostSchurWeight ρ Q (2*Vmax)))^N) := by
      apply (norm_sum_le _ _).trans
      apply Finset.sum_le_sum
      intro u _
      rw [← mul_sub,norm_mul,norm_mul,Complex.norm_conj]
      have htail := physical_selected_memory_truncation_explicit_bound
        ν V η q ρ Q Vmax s G anchor geometry N T (emptyState (Line:=Line) (B:=B) u)
        (vacuumLift b)
        (fun h=>if BirthsDistinct (ActualHistoryBirths.labels ν V η q ρ anchor geometry value N
          (emptyState (B:=B) u) h) then 1 else 0)
        hν0 hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0 hVmax hG hgeometry
        (vacuumLift_norm_le_schur b hb _ (ghostSchurWeight_pos ρ Q (2*Vmax) hρ hQ).le)
        (by intro h; split_ifs <;> simp)
        (by simp only [physicalMemorySize,emptyState_memory,Finset.sum_const_zero]) hT
      dsimp only at htail
      apply mul_le_mul_of_nonneg_left (htail.trans_eq ?_) (by positivity)
      ring
    _ = _ := by unfold initialBoundaryNorm; rw [← Finset.sum_mul]; ring

/-- The original independent-line path sum is now compared with the actual
small-cap operator pairing, with the complete finite truncation error. -/
theorem independent_path_sum_small_cap_error [∀ i p,Fintype (Line i p)]
    (value : ∀ i,P i→ℕ) (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η : ℕ→ℝ)
    (ρ Q Vmax s G : ℝ)
    (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hvalue : Function.Injective (fun z : Sigma P=>value z.1 z.2))
    (hshared : ∀ j z a w b,geometry j z a w b≠0→∀ i (k : Fin J),
      anchor z i (a i k.castSucc)=anchor w i (a i k.castSucc))
    (hban : ∀ j z a w b,geometry j z a w b≠0→sourceCrossEdgeBan value a b)
    (hν0 : ∀ i p,0≤ν i p) (hs : ∀ i,(∑p,ν i p)≤s) (hs0 : 0≤s)
    (hρ : 0<ρ) (hρ1 : ρ<1) (hQ : Q<ρ^2)
    (hq0 : ∀ j,0≤1-η j) (hqQ : ∀ j,1-η j≤Q)
    (hη0 : ∀ j,0≤η j) (hη1 : ∀ j,η j≤1)
    (hV0 : ∀ i,0≤V i) (hV : ∀ i,V i≠0) (hVmax : ∀ i,V i≤Vmax)
    (hG : 0≤G) (hgeometry : ∀ j z a w b,‖geometry j z a w b‖≤G)
    (hN : 0<N) (hn : ∀ i p,(Fintype.card (Line i p) : ℝ)≠0)
    (hbase : ∀ i p,(Fintype.card (Line i p) : ℝ)-∑j∈Finset.range (N+1),η j≠0)
    (hν : ∀ i p,V i*ν i p=normalizedLineMass (Finset.range (N+1)) η (Fintype.card (Line i p)))
    (hB : (∑ i,Fintype.card (P i))≤B) (T : ℕ) (hTB : T≤B) (hT : Fintype.card I*N≤T)
    (a b : BoundaryIndex I Z P J→ℂ) (hb : ∀ x,‖b x‖≤1) :
    let base := ∏ i, ∏ p,baseline (Finset.range (N+1)) η (Fintype.card (Line i p))
    let v0 := ghostSchurWeight ρ Q (2*Vmax)
    let Cghost := (Real.exp (v0*max 1 (2*Vmax)*s/ρ))^(Fintype.card I)
    let Cedge := (Fintype.card Z:ℝ)*G*∏ i,physicalEdgeLocalRowConstant (ν i) (V i) ρ v0
    ‖(∑ r : OriginalPath I Z P J N,r.boundaryFactor geometry V a b*(r.independentAverage anchor η : ℂ))-
      (base:ℂ)*boundaryPairing (B:=T) ν V η (fun j=>1-η j) ρ anchor geometry value N a b‖ ≤
      |base| *initialBoundaryNorm (Line:=Line) (B:=B) ν a *
        (((2:ℝ)^(T-Fintype.card I*N))⁻¹*(Cghost^(N+1)*Cedge^N)) := by
  dsimp only
  rw [all_independent_paths_eq_baseline_boundary value ν V η ρ geometry hvalue hshared hban
    hρ.ne' hV hN hn hbase hν hB,← mul_sub,norm_mul,Complex.norm_real,Real.norm_eq_abs]
  exact (mul_le_mul_of_nonneg_left
    (boundary_cap_tail_explicit value ν _ V η (fun j=>1-η j) ρ Q Vmax s G geometry
      hvalue hshared hban hν0 hs hs0 hρ hρ1 hQ hq0 hqQ hη0 hη1 hV0 hV hVmax hν hG hgeometry
      T hTB hT a b hb) (abs_nonneg _)).trans_eq (by ring)

end Elliptic.Operator.OriginalLifespanSchedule
