module

public import Elliptic.Operator.PhysicalPhasedWordNorm

/-! At most twice the birth-cycle rank can incur the crude edge cost.
All unmodified edges are the literal original operators, and phased ghosts
retain their uniform factorial norm bound. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalLowRankWord
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthFactors PhysicalPhasedWord PhysicalFourierWord PhysicalPhasedWordNorm PhysicalBagNorm
attribute [local instance] Classical.propDecidable
local instance lowRankDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B N Q : ℕ} [NeZero Q]

 def modifiedEdges (σ : Equiv.Perm (Address I J B N)) : Finset (Fin N) :=
  Finset.univ.filter (fun j=>2*j.val+2∈σ.support.image operation)

 theorem modifiedEdges_card (σ : Equiv.Perm (Address I J B N)) :
    (modifiedEdges σ).card≤2*birthCycleRank σ := by
  have hi : Function.Injective (fun j : Fin N=>2*j.val+2) := by
    intro a b hab
    apply Fin.ext
    dsimp only at hab
    omega
  calc
    _ = ((modifiedEdges σ).image (fun j=>2*j.val+2)).card := (Finset.card_image_of_injective _ hi).symm
    _ ≤ (σ.support.image operation).card := Finset.card_le_card (by
      intro x hx
      obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hx
      exact (Finset.mem_filter.mp hj).2)
    _ ≤ _ := modified_operations_count σ

 theorem edgeCost_product_le (σ : Equiv.Perm (Address I J B N)) (good bad : ℝ)
    (hgood : 0≤good) (hgood1 : good≤1) (hbad : 1≤bad) :
    (∏j : Fin N,if 2*j.val+2∈σ.support.image operation then bad else good)≤
      bad^(2*birthCycleRank σ)*good^(N-2*birthCycleRank σ) := by
  rw [Finset.prod_ite]
  simp only [Finset.prod_const]
  have hc := Finset.card_filter_add_card_filter_not (s:=(Finset.univ : Finset (Fin N)))
    (fun j=>2*j.val+2∈σ.support.image operation)
  have hs := modifiedEdges_card σ
  change (Finset.univ.filter (fun j : Fin N=>2*j.val+2∈σ.support.image operation)).card≤_ at hs
  have ht : N-2*birthCycleRank σ≤
      (Finset.univ.filter (fun j : Fin N=>¬2*j.val+2∈σ.support.image operation)).card := by
    simp only [Finset.card_univ,Fintype.card_fin] at hc
    omega
  exact mul_le_mul (pow_le_pow_right₀ hbad hs) (pow_le_pow_of_le_one hgood hgood1 ht)
    (pow_nonneg hgood _) (pow_nonneg (by linarith) _)

 theorem wordCost_low_rank (σ : Equiv.Perm (Address I J B N)) (ghost good bad : ℝ)
    (hghost : 0≤ghost) (hgood : 0≤good) (hgood1 : good≤1) (hbad : 1≤bad) :
    wordCost (fun _=>ghost) (fun j=>if 2*j+2∈σ.support.image operation then bad else good) N 0≤
      ghost^(N+1)*bad^(2*birthCycleRank σ)*good^(N-2*birthCycleRank σ) := by
  rw [wordCost_eq_products]
  simp only [Nat.zero_add,Finset.prod_const,Finset.card_univ,Fintype.card_fin]
  exact (mul_le_mul_of_nonneg_left (edgeCost_product_le σ good bad hgood hgood1 hbad)
    (pow_nonneg hghost _)).trans_eq (by ring)

 variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
 variable (anchor : Z→∀i p,Line i p)
 variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
 variable (value : ∀i,P i→ℕ)

 theorem actual_fourier_word_l2_le
    (σ : Equiv.Perm (Address I J B N)) (θ : Address I J B N→ZMod Q)
    (Qghost Vmax M good bad : ℝ)
    (hν : ∀i p,0<ν i p) (hmass : ∀i,(∑p,ν i p)≤M) (hM : 0≤M)
    (hρ : 0<ρ) (hQ : Qghost<ρ^2) (hq0 : ∀j,0≤q j) (hqQ : ∀j,q j≤Qghost)
    (hη0 : ∀j,0≤η j) (hη1 : ∀j,η j≤1) (hV0 : ∀i,0≤V i) (hVmax : ∀i,V i≤Vmax)
    (hgood : 0≤good) (hgood1 : good≤1) (hbad : 1≤bad)
    (hplain : ∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        ((physicalEdgeOperation ν V ρ anchor (geometry j)).apply F)≤
      good*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (hmodified : ∀j F,IsBagFunction F→
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
          (fun _ c=>edgeFactor value (edgePhase σ θ) j c) F)≤
      bad*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F)
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (word ν V η q ρ anchor geometry value (ghostPhase σ θ) (edgePhase σ θ) N 0 F)≤
    ((Real.exp (ghostSchurWeight ρ Qghost Vmax*max 1 Vmax*M/ρ))^(Fintype.card I))^(N+1)*
      bad^(2*birthCycleRank σ)*good^(N-2*birthCycleRank σ)*
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
  let Cg := (Real.exp (ghostSchurWeight ρ Qghost Vmax*max 1 Vmax*M/ρ))^(Fintype.card I)
  let Ce := fun j=>if 2*j+2∈σ.support.image operation then bad else good
  have hg (j : ℕ) (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalGhostOperation ν V (η j) (q j) ρ anchor)
          (fun _ c=>ghostFactor value (ghostPhase σ θ) j c) F)≤
      Cg*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
    obtain ⟨H,rfl⟩ := (isBagFunction_iff F).mp hF
    exact physicalGhostPhased_symmetric_l2_uniform ν V (η j) (q j) ρ Qghost Vmax M anchor
      (fun _ c=>ghostFactor value (ghostPhase σ θ) j c) H
      (fun s c=>ghostFactor_norm_le value σ θ j s c) (fun i p=>(hν i p).le) hmass hM hρ hQ
      (hq0 j) (hqQ j) (hη0 j) (hη1 j) hV0 hVmax
  have he (j : ℕ) (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hF : IsBagFunction F) :
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j))
          (fun _ c=>edgeFactor value (edgePhase σ θ) j c) F)≤
      Ce j*finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν) F := by
    by_cases hj : 2*j+2∈σ.support.image operation
    · simpa only [Ce,if_pos hj] using hmodified j F hF
    · have hf : (fun (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : (physicalEdgeOperation ν V ρ anchor (geometry j)).Choice s)=>
          edgeFactor value (edgePhase σ θ) j c)=(fun _ _=>1) := by
        funext s c
        exact edgeFactor_unmodified value σ θ j hj s c
      simp only [Ce,if_neg hj]
      rw [hf]
      have hone : phasedApply (physicalEdgeOperation ν V ρ anchor (geometry j)) (fun _ _=>1) F=
          (physicalEdgeOperation ν V ρ anchor (geometry j)).apply F :=
        funext (phasedApply_one _ F)
      rw [hone]
      exact hplain j F hF
  have hw := word_l2_le ν V η q ρ anchor geometry value (fun i p=>(hν i p).ne')
    (ghostPhase σ θ) (edgePhase σ θ) (fun _=>Cg) Ce (fun _=>by dsimp [Cg];positivity)
    (fun j=>by dsimp [Ce];split_ifs <;> linarith) hg he N 0 F hF
  exact hw.trans (mul_le_mul_of_nonneg_right
    (wordCost_low_rank σ Cg good bad (by dsimp [Cg];positivity) hgood hgood1 hbad) (Real.sqrt_nonneg _))

end Elliptic.Operator.PhysicalLowRankWord
