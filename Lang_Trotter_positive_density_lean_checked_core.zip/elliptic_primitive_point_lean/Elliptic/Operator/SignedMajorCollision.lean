module
public import Elliptic.Operator.SignedLabelCollisions
public import Elliptic.Operator.SignedPhysicalAbsoluteMajor
public import Elliptic.Operator.SignedCollisionAsymptotics

/-! Removing common-label pairs from the unrestricted major-circle sum
costs an exponentially small reciprocal-prime-square tail. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedMajorCollision
open scoped BigOperators
open Artin Artin.MarkedSource SignedCauchyExpansion SignedLabelCollisions
open SignedPhysicalPairBridge SignedPhysicalAbsoluteMajor
attribute [local instance] Classical.propDecidable
local instance majorCollisionDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
variable {K : ℕ}

theorem sum_real_const {ι : Type*} (s : Finset ι) (c : ℝ) :
    (∑_i∈s,c)=(s.card:ℝ)*c := by
  simp only [Finset.sum_const,nsmul_eq_mul]

theorem collision_numeric_simplify (C Y H Aη Aψ A B Z T E : ℝ) (hY : Y≠0) :
    (16*Y^2*T*E)*((Aη^2*A^2*B^2*Aψ*(4*H^3/Y))*(2*C+1)*Z)=
      64*(2*C+1)*Aη^2*A^2*B^2*Aψ*H^3*Y*Z*T*E := by
  field_simp
  ring

def pairAbsolute (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (a c : LabelTuple b x) : ℝ :=
  ∑m∈s,∑n∈t,∑r∈s,∑q∈t,
    ‖scalarMajor (labelProduct b x a) (labelProduct b x c) m n r q Y H η ψ α β‖

theorem pairAbsolute_zero (b : Bands K) (x Y H : ℝ) (s t : Finset ℕ)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (a c : LabelTuple b x)
    (hz : η ((labelProduct b x a:ℝ)/Y)=0 ∨ η ((labelProduct b x c:ℝ)/Y)=0) :
    pairAbsolute b x Y H s t η ψ α β a c=0 := by
  rcases hz with hz|hz <;> simp [pairAbsolute,scalarMajor,hz]

theorem collision_scalarMajor_sum_le (b : Bands K) (x : ℝ)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) (hL : 1≤Real.log x)
    (s t : Finset ℕ) (N : ℕ) (hs : ∀m∈s,0<m)
    (hprod : ∀m∈s,∀n∈t,m*n∈Finset.Icc 1 N)
    (C Y H : ℝ) (hC : 0≤C) (hY : 0<Y) (hH : 0≤H)
    (η ψ : ℝ→ℂ) (α β : ℕ→ℂ) (Aη Aψ A B : ℝ)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (hA : 0≤A) (hB : 0≤B)
    (hη : ∀v,‖η v‖≤Aη) (hψ : ∀v,‖ψ v‖≤Aψ)
    (hηsupp : ∀v,η v≠0→1≤v ∧ v≤4) (hψsupp : ∀v,ψ v≠0→|v|≤C)
    (hα : ∀m∈s,‖α m‖≤A) (hβ : ∀n∈t,‖β n‖≤B) :
    (∑a : LabelTuple b x,∑c : LabelTuple b x,
      if ¬(labelProduct b x a).Coprime (labelProduct b x c) then
        pairAbsolute b x Y H s t η ψ α β a c else 0)≤
      64*(2*C+1)*Aη^2*A^2*B^2*Aψ*H^3*Y*
        (∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2)*(8*Real.log 4*K)*
        Real.exp (-((Real.log x)^(1/10:ℝ))) := by
  let F := fun ac : LabelTuple b x×LabelTuple b x=>
    if ¬(labelProduct b x ac.1).Coprime (labelProduct b x ac.2) then
      pairAbsolute b x Y H s t η ψ α β ac.1 ac.2 else 0
  let M := (Aη^2*A^2*B^2*Aψ*(4*H^3/Y))*(2*C+1)*
        ∑u∈Finset.Icc 1 N,(u.divisors.card:ℝ)^2
  have hM : 0≤M := by dsimp [M]; positivity
  have hsupp (a : LabelTuple b x) (hn : η ((labelProduct b x a:ℝ)/Y)≠0) :
      Y≤(labelProduct b x a:ℝ) ∧ (labelProduct b x a:ℝ)≤4*Y := by
    have h := hηsupp _ hn
    exact ⟨by simpa using (le_div_iff₀ hY).mp h.1,(div_le_iff₀ hY).mp h.2⟩
  have hz (ac : LabelTuple b x×LabelTuple b x) (hn : ac∉collisionPairs b x Y) : F ac=0 := by
    by_cases hc : (labelProduct b x ac.1).Coprime (labelProduct b x ac.2)
    · simp [F,hc]
    by_cases ha : η ((labelProduct b x ac.1:ℝ)/Y)=0
    · simp only [F,ite_eq_left hc,pairAbsolute_zero b x Y H s t η ψ α β ac.1 ac.2 (Or.inl ha)]
    by_cases hb : η ((labelProduct b x ac.2:ℝ)/Y)=0
    · simp only [F,ite_eq_left hc,pairAbsolute_zero b x Y H s t η ψ α β ac.1 ac.2 (Or.inr hb)]
    exact (hn (Finset.mem_filter.mpr ⟨Finset.mem_product.mpr
      ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,(hsupp ac.1 ha).2⟩,
       Finset.mem_filter.mpr ⟨Finset.mem_univ _,(hsupp ac.2 hb).2⟩⟩,hc⟩)).elim
  have hterm (ac : LabelTuple b x×LabelTuple b x) : F ac≤M := by
    by_cases hc : (labelProduct b x ac.1).Coprime (labelProduct b x ac.2)
    · simpa [F,hc] using hM
    rw [show F ac=pairAbsolute b x Y H s t η ψ α β ac.1 ac.2 by simp [F,hc]]
    by_cases ha : η ((labelProduct b x ac.1:ℝ)/Y)=0
    · rw [pairAbsolute_zero b x Y H s t η ψ α β ac.1 ac.2 (Or.inl ha)]; exact hM
    by_cases hb : η ((labelProduct b x ac.2:ℝ)/Y)=0
    · rw [pairAbsolute_zero b x Y H s t η ψ α β ac.1 ac.2 (Or.inr hb)]; exact hM
    exact scalarMajor_sum_le s t N _ _ hs hprod C Y H hC hY hH
      (hsupp ac.1 ha).1 (hsupp ac.2 hb).1 η ψ α β Aη Aψ A B hAη hAψ hA hB hη hψ hψsupp hα hβ
  calc
    _ = ∑ac,F ac := (Fintype.sum_prod_type F).symm
    _ = ∑ac∈collisionPairs b x Y,F ac :=
      (Finset.sum_subset (Finset.subset_univ _) (fun ac _ hn=>hz ac hn)).symm
    _ ≤ ∑_ac∈collisionPairs b x Y,M := Finset.sum_le_sum (fun ac _=>hterm ac)
    _ = (collisionPairs b x Y).card*M := sum_real_const _ _
    _ ≤ (16*Y^2*(8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))))*M :=
      mul_le_mul_of_nonneg_right (collisionPairs_card_exp b x Y hY.le hdis hL) hM
    _ = _ := collision_numeric_simplify C Y H Aη Aψ A B _ _ _ hY.ne'

end Elliptic.Operator.SignedMajorCollision
