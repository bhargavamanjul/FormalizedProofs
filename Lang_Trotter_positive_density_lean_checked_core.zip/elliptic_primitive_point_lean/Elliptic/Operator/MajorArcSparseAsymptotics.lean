module

public import Elliptic.Operator.LogPhaseHighFrequency
public import Elliptic.Operator.MomentParameters

/-!
# Absorbing the actual sparse-frequency losses

A threshold exp(L^.95) is convenient here. Fixed-order cancellation works
for every positive threshold, and .95 is strictly between the exceptional
count exponent .91 and the ambient length exponent 1. No growing-order
mean-value theorem is used.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcSparseAsymptotics
open Filter ClassicalDerivativeTest LogPhaseHighFrequency LogPhaseProgression
set_option backward.isDefEq.respectTransparency false

/-- Every smaller real power is eventually dominated with any fixed constant. -/
theorem eventually_mul_rpow_le (a b r s : ℝ) (hb : 0<b) (hrs : r<s) :
    ∀ᶠ L:ℝ in atTop,a*L^r≤b*L^s := by
  have hh := (tendsto_rpow_atTop (sub_pos.mpr hrs)).eventually (eventually_ge_atTop (a/b))
  filter_upwards [hh,eventually_gt_atTop (0:ℝ)] with L hL hL0
  have hm := mul_le_mul_of_nonneg_right ((div_le_iff₀ hb).mp hL) (Real.rpow_nonneg hL0.le r)
  have he : b*L^(s-r)*L^r=b*L^s := by
    rw [mul_assoc,←Real.rpow_add hL0]
    congr 1
    ring
  nlinarith [hm]

/-- Both sparse Gram losses are negligible uniformly over all lengths and
all exceptional families satisfying the displayed numerical envelopes. -/
theorem eventually_sparse_losses (δ e H C : ℝ) (hδ : 0<δ) (he : 0<e)
    (hH : 0≤H) (hC : 0<C) :
    ∀ᶠ L:ℝ in atTop,∀R N:ℝ,0≤R→R≤Real.exp (H*L^(91/100:ℝ))→
      Real.exp (δ*L)≤N→
      R*Real.exp (L^(95/100:ℝ))/N≤1 ∧
      R^2*C*(N^(-e)+(Real.exp (L^(95/100:ℝ)))^(-1/2:ℝ))≤1 := by
  have h1 := eventually_mul_rpow_le H (δ/4) (91/100) 1 (by positivity) (by norm_num)
  have h2 := eventually_mul_rpow_le 1 (δ/4) (95/100) 1 (by positivity) (by norm_num)
  have h3 := eventually_mul_rpow_le (2*H) (δ*e/2) (91/100) 1 (by positivity) (by norm_num)
  have h4 := eventually_mul_rpow_le (2*H) (1/4) (91/100) (95/100) (by norm_num) (by norm_num)
  have hc1 := (Elliptic.Operator.tendsto_power_mul_exp_neg_rpow 0
    (show 0<δ*e/2 by positivity) (show (0:ℝ)<1 by norm_num)).const_mul C
  have hc2 := (Elliptic.Operator.tendsto_power_mul_exp_neg_rpow 0
    (show (0:ℝ)<1/4 by norm_num) (show (0:ℝ)<95/100 by norm_num)).const_mul C
  simp only [mul_zero] at hc1 hc2
  have hh1 := hc1.eventually_lt_const (show (0:ℝ)<1/2 by norm_num)
  have hh2 := hc2.eventually_lt_const (show (0:ℝ)<1/2 by norm_num)
  simp only [Real.rpow_zero,Real.rpow_one,one_mul,mul_zero] at h1 h2 h3 hh1 hh2
  filter_upwards [h1,h2,h3,h4,hh1,hh2,eventually_gt_atTop (0:ℝ)] with L h1 h2 h3 h4 hc1 hc2 hL
  intro R N hR hRmax hN
  have hN0 := (Real.exp_pos (δ*L)).trans_le hN
  constructor
  · apply (div_le_iff₀ hN0).mpr
    have hr := mul_le_mul_of_nonneg_right hRmax (Real.exp_pos (L^(95/100:ℝ))).le
    rw [←Real.exp_add] at hr
    have hex : Real.exp (H*L^(91/100:ℝ)+L^(95/100:ℝ))≤Real.exp (δ*L) := by
      apply Real.exp_le_exp.mpr
      nlinarith
    simpa using hr.trans (hex.trans hN)
  · have hr2 := pow_le_pow_left₀ hR hRmax 2
    have hn := Real.rpow_le_rpow_of_nonpos (Real.exp_pos (δ*L)) hN (neg_nonpos.mpr he.le)
    have heN : (Real.exp (δ*L))^(-e)=Real.exp (-δ*e*L) := by
      rw [Real.rpow_def_of_pos (Real.exp_pos _),Real.log_exp]
      congr 1
      ring
    have heT : (Real.exp (L^(95/100:ℝ)))^(-1/2:ℝ)=Real.exp (-(1/2:ℝ)*L^(95/100:ℝ)) := by
      rw [Real.rpow_def_of_pos (Real.exp_pos _),Real.log_exp]
      congr 1
      ring
    rw [heN] at hn
    rw [heT]
    have hrpow : (Real.exp (H*L^(91/100:ℝ)))^2=Real.exp (2*H*L^(91/100:ℝ)) := by
      rw [sq,←Real.exp_add]
      congr 1
      ring
    rw [hrpow] at hr2
    have hfirst : R^2*C*N^(-e)≤C*Real.exp (-(δ*e/2)*L) := by
      calc
        _ ≤ Real.exp (2*H*L^(91/100:ℝ))*C*Real.exp (-δ*e*L) :=
          mul_le_mul (mul_le_mul_of_nonneg_right hr2 hC.le) hn
            (Real.rpow_nonneg hN0.le _) (by positivity)
        _ = C*Real.exp (2*H*L^(91/100:ℝ)-δ*e*L) := by rw [show -δ*e*L= -(δ*e*L) by ring,sub_eq_add_neg,Real.exp_add]; ring
        _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) hC.le
    have hsecond : R^2*C*Real.exp (-(1/2:ℝ)*L^(95/100:ℝ))≤C*Real.exp (-(1/4:ℝ)*L^(95/100:ℝ)) := by
      calc
        _ ≤ Real.exp (2*H*L^(91/100:ℝ))*C*Real.exp (-(1/2:ℝ)*L^(95/100:ℝ)) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hr2 hC.le) (Real.exp_pos _).le
        _ = C*Real.exp (2*H*L^(91/100:ℝ)-(1/2:ℝ)*L^(95/100:ℝ)) := by
          rw [sub_eq_add_neg,Real.exp_add]; ring
        _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) hC.le
    nlinarith

/-- A fixed derivative order suffices for the entire long-cofactor range. -/
theorem exists_degree (δ : ℝ) (hδ : 0<δ) : ∃d:ℕ,2≤d∧4≤δ*((d-1:ℕ):ℝ) := by
  refine ⟨⌈4/δ⌉₊+2,by omega,?_⟩
  have hc : 4/δ≤(⌈4/δ⌉₊:ℝ) := Nat.le_ceil _
  have hh := (div_le_iff₀ hδ).mp hc
  have he : ⌈4/δ⌉₊+2-1=⌈4/δ⌉₊+1 := by omega
  rw [he,Nat.cast_add,Nat.cast_one]
  nlinarith

/-- Source-form sparse energy: the constant and threshold are uniform over
all sample locations, coefficients, dyads and exceptional families. -/
theorem eventually_normalized_sparse_energy
    (hvdC : FixedOrderDerivativeTest) (δ H J : ℝ) (hδ : 0<δ) (hH : 0≤H) (hJ : 0≤J) :
    ∃C:ℝ,0<C∧∀ᶠL:ℝ in atTop,∀(s:Finset ℕ)(τ:ℕ→ℝ)(K:ℕ),
      1≤K→s⊆Finset.Icc 1 K→Real.log (K:ℝ)≤J*L→∀a:ℝ,
      (∀i∈s,a+i≤τ i∧τ i≤a+i+1)→(s.card:ℝ)≤Real.exp (H*L^(91/100:ℝ))→
      ∀N:ℕ,1≤N→Real.exp (δ*L)≤N→
      (∀i∈s,∀j∈s,|τ i-τ j|≤Real.exp (4*L))→∀B:ℝ,0≤B→∀c:ℕ→ℂ,
      (∀n∈Finset.range N,‖c n‖≤B)→
      (∑i∈s,‖(N:ℂ)⁻¹*∑n∈Finset.range N,c n*phase (τ i) ((N:ℝ)+n)‖^2)≤C*B^2*L := by
  obtain ⟨d,hd,hdegree⟩ := exists_degree δ hδ
  obtain ⟨C,hC,hbound⟩ := normalized_sparse_energy hvdC d hd
  have he := exponent_pos d hd
  have hsmall := eventually_sparse_losses δ (exponent d) H C hδ he hH hC
  refine ⟨3*(15+12*J),by positivity,?_⟩
  filter_upwards [hsmall,eventually_ge_atTop (1:ℝ)] with L hsmall hL
  intro s τ K hK hs hlog a hcell hcard N hN hNmin hdiam B hB c hc
  have hL0 : 0≤L := by linarith
  have hN0 : (0:ℝ)<N := by exact_mod_cast (show 0<N by omega)
  have hmax : Real.exp (4*L)≤(N:ℝ)^(d-1) := by
    have hp := pow_le_pow_left₀ (Real.exp_pos (δ*L)).le hNmin (d-1)
    rw [←Real.exp_nat_mul] at hp
    apply le_trans _ hp
    apply Real.exp_le_exp.mpr
    nlinarith [mul_le_mul_of_nonneg_right hdegree hL0]
  have hh := hbound s τ K hK hs a hcell N hN (Real.exp (L^(95/100:ℝ))) B
    (Real.exp_pos _) hB (fun i hi j hj=>(hdiam i hi j hj).trans hmax) c hc
  have hb := hsmall s.card N (Nat.cast_nonneg _) hcard hNmin
  have hlogs : 1+12*(1+Real.log (K:ℝ))+(s.card:ℝ)*Real.exp (L^(95/100:ℝ))/N+
      (s.card:ℝ)^2*C*((N:ℝ)^(-exponent d)+(Real.exp (L^(95/100:ℝ)))^(-1/2:ℝ))≤
        (15+12*J)*L := by nlinarith [hb.1,hb.2]
  have hm := mul_le_mul_of_nonneg_left hlogs (show 0≤3*B^2 by positivity)
  exact hh.trans (by nlinarith [hm])

end Elliptic.Operator.MajorArcSparseAsymptotics
