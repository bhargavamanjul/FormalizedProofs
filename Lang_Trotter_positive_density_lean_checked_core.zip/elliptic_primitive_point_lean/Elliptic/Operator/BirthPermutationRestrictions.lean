module

public import Elliptic.Operator.BirthPermutationPlan
public import Elliptic.Operator.PhysicalPivotBoundary

/-! Actual birth-preserving histories satisfy the constructed causal
prescriptions, including the initial active draws. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.BirthPermutationPlan
open scoped BigOperators
open ActualHistoryBirths BirthCyclePivots
attribute [local instance] Classical.propDecidable
local instance restrictionsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type} [Fintype I] {J B N : ℕ}
local instance chronologicalOrderRestriction : LinearOrder (Address I J B N) := BirthChronologicalOrder.order

theorem plan_equalities (σ : Equiv.Perm (Address I J B N))
    (hgroup : ∀a,addressGroup (σ a)=addressGroup a)
    (birth : Address I J B N→Option ℕ) (f : PhysicalBirthRegistry.Registry I J B)
    (hf : ∀a,f (PhysicalBirthRegistry.embed a)=birth a) (hp : BirthPreserving birth σ) :
    (plan σ hgroup).Equalities f := by
  constructor
  · intro j i k hk
    obtain ⟨hj,a,rfl,ha⟩ := (mem_ghostSlots σ j i k).mp hk
    exact prescribed_equalities σ birth f hf hp (.inr (.inl (⟨j,hj⟩,i,a))) ha
  · intro j i hi
    obtain ⟨hj,ha⟩ := (mem_edgeGroups σ j i).mp hi
    exact prescribed_equalities σ birth f hf hp (.inr (.inr (⟨j,hj⟩,i))) ha

theorem initialPlan_equalities (σ : Equiv.Perm (Address I J B N))
    (hgroup : ∀a,addressGroup (σ a)=addressGroup a)
    (birth : Address I J B N→Option ℕ) (f : PhysicalBirthRegistry.Registry I J B)
    (hf : ∀a,f (PhysicalBirthRegistry.embed a)=birth a) (hp : BirthPreserving birth σ) :
    (initialPlan σ hgroup).Equalities f := by
  intro i k hk
  obtain ⟨a,rfl,ha⟩ := (mem_initialSlots σ i k).mp hk
  exact prescribed_equalities σ birth f hf hp (.inl (i,a)) ha

variable {Z : Type} [Fintype Z] {P : I→Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i→Type}

theorem actual_completed_restrictions
    (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ:ℝ)
    (anchor:Z→∀i p,Line i p)
    (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value:∀i,P i→ℕ) (σ : Equiv.Perm (Address I J B N))
    (hgroup : ∀a,addressGroup (σ a)=addressGroup a)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hp : BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ) :
    let f := PhysicalBirthRegistry.record ν V η q ρ anchor geometry value N 0 s h
      (PhysicalBirthRegistry.initial value s)
    (initialPlan σ hgroup).Equalities f ∧ (plan σ hgroup).Equalities f := by
  dsimp only
  have hf := PhysicalBirthRegistry.record_eq_labels ν V η q ρ anchor geometry value N s h
  exact ⟨initialPlan_equalities σ hgroup _ _ hf hp,plan_equalities σ hgroup _ _ hf hp⟩

end Elliptic.Operator.BirthPermutationPlan
