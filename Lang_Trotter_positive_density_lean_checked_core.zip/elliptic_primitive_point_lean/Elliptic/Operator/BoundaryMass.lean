module

public import Elliptic.Operator.CleanPhysicalTransport
public import Elliptic.Operator.MomentParameters

/-!
# The actual normalized prime masses and boundary normalization

This is the elementary normalization behind source (4.12).  It uses the
literal transformed mass (4.3) and the identity `V = sum_p 1/p`; a mere
factor-two domination by the original prime measure would not suffice.
-/

@[expose] public section
namespace Elliptic.Operator
open Filter
open scoped BigOperators

theorem transformedPrimeMass_sharp_bound {τ : Type*} (visits : Finset τ)
    (η : τ → ℝ) (V pmin : ℝ) (p : ℕ) (hV : 0 < V) (hpmin : 0 < pmin)
    (hp : pmin ≤ (p:ℝ)) (hη : ∀ j ∈ visits, η j ≤ 1)
    (hsize : 2*(visits.card:ℝ) ≤ pmin) :
    0 ≤ transformedPrimeMass visits η V p ∧
      transformedPrimeMass visits η V p ≤
        (1+2*(visits.card:ℝ)/pmin) * (1/(V*(p:ℝ))) := by
  have hpR : 0 < (p:ℝ) := hpmin.trans_le hp
  have hsum : (∑ j ∈ visits, η j) ≤ (visits.card:ℝ) := by
    calc
      _ ≤ ∑ j ∈ visits, (1:ℝ) := Finset.sum_le_sum hη
      _ = _ := by simp
  let d := (p:ℝ)+1-∑ j ∈ visits, η j
  have hdhalf : pmin/2 ≤ d := by dsimp [d]; linarith
  have hd : 0 < d := (half_pos hpmin).trans_le hdhalf
  have hratio : (p:ℝ) ≤ (1+2*(visits.card:ℝ)/pmin)*d := by
    have hmul := mul_le_mul_of_nonneg_left hdhalf
      (show 0 ≤ 2*(visits.card:ℝ)/pmin by positivity)
    have heq : (2*(visits.card:ℝ)/pmin)*(pmin/2) = (visits.card:ℝ) := by
      field_simp
    rw [heq] at hmul
    dsimp [d] at *
    nlinarith
  rw [transformedPrimeMass_eq]
  change 0 ≤ 1/(V*d) ∧ 1/(V*d) ≤ _
  refine ⟨by positivity, ?_⟩
  rw [mul_one_div]
  apply (div_le_div_iff₀ (mul_pos hV hd) (mul_pos hV hpR)).2
  nlinarith [mul_le_mul_of_nonneg_left hratio hV.le]

/-- The small relative error survives the exact normalization by `V`. -/
theorem transformedPrimeMass_sum_le {τ : Type*} (visits : Finset τ)
    (η : τ → ℝ) (primes : Finset ℕ) (V pmin : ℝ)
    (hV : 0 < V) (hVsum : V = ∑ p ∈ primes, 1/(p:ℝ))
    (hpmin : 0 < pmin) (hp : ∀ p ∈ primes, pmin ≤ (p:ℝ))
    (hη : ∀ j ∈ visits, η j ≤ 1) (hsize : 2*(visits.card:ℝ) ≤ pmin) :
    0 ≤ ∑ p ∈ primes, transformedPrimeMass visits η V p ∧
      (∑ p ∈ primes, transformedPrimeMass visits η V p) ≤
        1+2*(visits.card:ℝ)/pmin := by
  have hnorm : (∑ p ∈ primes, 1/(V*(p:ℝ))) = 1 := by
    simp_rw [← one_div_mul_one_div]
    rw [← Finset.mul_sum, ← hVsum]
    field_simp
  refine ⟨Finset.sum_nonneg (fun p hp' =>
    (transformedPrimeMass_sharp_bound visits η V pmin p hV hpmin (hp p hp') hη hsize).1), ?_⟩
  calc
    _ ≤ ∑ p ∈ primes, (1+2*(visits.card:ℝ)/pmin)*(1/(V*(p:ℝ))) :=
      Finset.sum_le_sum (fun p hp' =>
        (transformedPrimeMass_sharp_bound visits η V pmin p hV hpmin (hp p hp') hη hsize).2)
    _ = _ := by rw [← Finset.mul_sum, hnorm, mul_one]

theorem product_powers_le_exp {I : Type*} [Fintype I]
    (s : I → ℝ) (M : ℕ) (δ : ℝ) (hs0 : ∀ i, 0 ≤ s i)
    (hs : ∀ i, s i ≤ 1+δ) :
    (∏ i, s i^M) ≤ Real.exp ((Fintype.card I:ℝ)*M*δ) := by
  have he : 1+δ ≤ Real.exp δ := by simpa [add_comm] using Real.add_one_le_exp δ
  calc
    _ ≤ ∏ _i : I, (Real.exp δ)^M := Finset.prod_le_prod₀
      (fun i _ => pow_nonneg (hs0 i) _)
      (fun i _ => pow_le_pow_left₀ (hs0 i) ((hs i).trans he) _)
    _ = _ := by
      simp only [Finset.prod_const, Finset.card_univ, ← Real.exp_nat_mul]
      congr 1
      ring

/-- The squared boundary mass for `M` unrestricted active coordinates in
each of `K` groups, with every group normalized by its own reciprocal sum. -/
theorem transformed_boundary_mass_le_exp {I τ : Type*} [Fintype I]
    (visits : Finset τ) (η : τ → ℝ) (groups : I → Finset ℕ)
    (V : I → ℝ) (pmin : ℝ) (M : ℕ)
    (hV : ∀ i, 0 < V i) (hVsum : ∀ i, V i = ∑ p ∈ groups i, 1/(p:ℝ))
    (hpmin : 0 < pmin) (hp : ∀ i p, p ∈ groups i → pmin ≤ (p:ℝ))
    (hη : ∀ j ∈ visits, η j ≤ 1) (hsize : 2*(visits.card:ℝ) ≤ pmin) :
    (∏ i, (∑ p ∈ groups i, transformedPrimeMass visits η (V i) p)^M) ≤
      Real.exp (2*(Fintype.card I:ℝ)*M*(visits.card:ℝ)/pmin) := by
  have hs i := transformedPrimeMass_sum_le visits η (groups i) (V i) pmin
    (hV i) (hVsum i) hpmin (hp i) hη hsize
  convert product_powers_le_exp (fun i => ∑ p ∈ groups i, transformedPrimeMass visits η (V i) p)
    M (2*(visits.card:ℝ)/pmin) (fun i => (hs i).1) (fun i => (hs i).2) using 1
  congr 1
  ring

/-- The finite boundary calculation matches the literal asymptotic
majorant of `MomentParameters`, at the source's exponential prime cutoff. -/
theorem transformed_boundary_mass_le_majorant {I : Type*} [Fintype I]
    (L pmin : ℝ) (η : Fin (momentLength L+1) → ℝ)
    (groups : I → Finset ℕ) (V : I → ℝ)
    (hV : ∀ i, 0 < V i) (hVsum : ∀ i, V i = ∑ p ∈ groups i, 1/(p:ℝ))
    (hpmin : Real.exp (L^(1/10:ℝ)) ≤ pmin)
    (hp : ∀ i p, p ∈ groups i → pmin ≤ (p:ℝ))
    (hη : ∀ j, η j ≤ 1) (hsize : 2*((momentLength L:ℝ)+1) ≤ pmin) :
    (∏ i, (∑ p ∈ groups i, transformedPrimeMass Finset.univ η (V i) p)^
      momentMultiplicity L) ≤ boundaryNormMajorant (2*(Fintype.card I:ℝ)) L := by
  have hpmin0 := (Real.exp_pos (L^(1/10:ℝ))).trans_le hpmin
  have h := transformed_boundary_mass_le_exp Finset.univ η groups V pmin
    (momentMultiplicity L) hV hVsum hpmin0 hp (fun j _ => hη j)
    (by simpa using hsize)
  have hinv : 1/pmin ≤ Real.exp (-L^(1/10:ℝ)) := by
    rw [Real.exp_neg]
    simpa only [one_div] using one_div_le_one_div_of_le (Real.exp_pos _) hpmin
  refine h.trans ?_
  unfold boundaryNormMajorant
  apply Real.exp_le_exp.mpr
  simp only [Finset.card_univ, Fintype.card_fin, Nat.cast_add, Nat.cast_one]
  have hmul := mul_le_mul_of_nonneg_left hinv
    (show 0 ≤ 2*(Fintype.card I:ℝ)*(momentMultiplicity L:ℝ)*((momentLength L:ℝ)+1)
      by positivity)
  simpa only [mul_one_div] using hmul

universe u

/-- The boundary normalization is uniform over all actual prime bands,
all allowed deficits, and all exponential lower prime cutoffs. -/
theorem eventually_transformed_boundary_mass_le_two (K : ℕ) :
    ∀ᶠ L : ℝ in atTop, ∀ (I : Type u) [Fintype I], Fintype.card I = K →
      ∀ (pmin : ℝ) (η : Fin (momentLength L+1) → ℝ)
        (groups : I → Finset ℕ) (V : I → ℝ),
      (∀ i, 0 < V i) → (∀ i, V i = ∑ p ∈ groups i, 1/(p:ℝ)) →
      Real.exp (L^(1/10:ℝ)) ≤ pmin →
      (∀ i p, p ∈ groups i → pmin ≤ (p:ℝ)) → (∀ j, η j ≤ 1) →
      (∏ i, (∑ p ∈ groups i, transformedPrimeMass Finset.univ η (V i) p)^
        momentMultiplicity L) ≤ 2 := by
  filter_upwards [eventually_memory_visits_le_prime_cutoff,
    eventually_boundaryNormMajorant_le_two (D:=2*(K:ℝ)) (by positivity)] with L hsize hb
  intro I _ hI pmin η groups V hV hVsum hpmin hp hη
  have h := transformed_boundary_mass_le_majorant L pmin η groups V
    hV hVsum hpmin hp hη (hsize.trans hpmin)
  rw [hI] at h
  exact h.trans hb

end Elliptic.Operator
