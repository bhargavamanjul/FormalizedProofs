module

public import Elliptic.Operator.ActualHistoryBirths
public import Elliptic.Operator.ActualBirthSupport

/-!
# Global support invariants of the literal performed-birth history

Birth addresses below are read from the actual dependent choices. No
lifespan schedule is an input. The global distinct-birth restriction
supplies the local freshness conditions used by physical transitions.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance actualHistorySupportDecidableEq {α : Type*} : DecidableEq α :=
  Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B : ℕ}

namespace ActualHistorySupport

variable (value : ∀ i, P i → ℕ)

/-- None of the currently live labels lies in the specified set of future
birth values. Retained line data is not discarded from the actual state. -/
def Avoids (A : Set ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B) : Prop :=
  (∀ i j, value i (s.active P Line J B i j) ∉ A) ∧
    (∀ i k, value i ((s.memory P Line J B i).values k).1 ∉ A)

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem ghost_output_avoids (A : Set ℕ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalGhostChoice s)
    (hc : c.Valid anchor s) (hs : Avoids value A s)
    (hfresh : ∀ i k, value i ((c i).2.values k) ∉ A) :
    Avoids value A (c.output anchor s hc) := by
  refine ⟨hs.1, ?_⟩
  intro i k
  have hm := (ghostOutput_prime_exists_iff _ _ _ (hc.1 i)
    (((c.output anchor s hc).memory P Line J B i).values k).1).mp ⟨k,rfl⟩
  rcases hm with ⟨l,_,hl⟩ | ⟨l,hl⟩
  · rw [← hl]; exact hs.2 i l
  · rw [← hl]; exact hfresh i l

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem edge_output_avoids (A : Set ℕ)
    (anchor : Z → ∀ i p, Line i p)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hc : c.Valid anchor s) (hs : Avoids value A s)
    (hfresh : ∀ i p, (c.group i).2 = Sum.inr p → value i p ∉ A) :
    Avoids value A (c.output anchor s hc) := by
  have htarget (i : I) : value i (edgeTargetPrime (s.memory P Line J B i) (c.group i)) ∉ A := by
    cases he : (c.group i).2 with
    | inl k => simpa [edgeTargetPrime, he] using hs.2 i k
    | inr p => simpa [edgeTargetPrime, he] using hfresh i p he
  constructor
  · intro i j
    change value i (c.targetLists i (c.targetPerm i j)) ∉ A
    generalize c.targetPerm i j = k
    refine Fin.lastCases ?_ (fun l => ?_) k
    · simpa using htarget i
    · simpa [PhysicalEdgeChoice.sourceLists] using hs.1 i (c.sourcePerm i l.castSucc)
  · intro i k
    have hm := (edgeGroupOutput_prime_exists_iff _ _ _ _ (hc.1 i).2
      (((c.output anchor s hc).memory P Line J B i).values k).1).mp ⟨k,rfl⟩
    rcases hm with ⟨l,_,hl⟩ | ⟨_,hl⟩
    · rw [← hl]; exact hs.2 i l
    · rw [← hl]; exact hs.1 i (c.sourcePerm i (Fin.last J))

abbrev FutureAddress (I : Type) (B n : ℕ) :=
  (Fin (n+1) × I × Fin B) ⊕ (Fin n × I)

variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (anchor : Z → ∀ i p, Line i p)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)

open ActualHistoryBirths

def futureLabels (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s) :
    FutureAddress I B n → Option ℕ
  | .inl a => (ghostAt ν V η q ρ anchor geometry n j s h a.1 a.2.1 a.2.2).map (value a.2.1)
  | .inr a => (freshAt ν V η q ρ anchor geometry n j s h a.1 a.2).map (value a.2)

def futureValues (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s) : Set ℕ :=
  {p | ∃ a, futureLabels value ν V η q ρ anchor geometry n j s h a = some p}

/-- The invariant records both sides of every performed ghost and edge. -/
def AllLive : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s → Prop
  | 0,_,s,h => s.LiveDistinct ∧ (h.1.val.output anchor s h.1.property).LiveDistinct
  | n+1,j,s,h => s.LiveDistinct ∧
      (h.1.val.output anchor s h.1.property).LiveDistinct ∧
      AllLive n (j+1) _ h.2.2

def firstGhost : (n j : ℕ) → (s : PhysicalMemoryState (Z:=Z) P Line J B) →
    ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s →
    {c : PhysicalGhostChoice s // c.Valid anchor s}
  | 0,_,_,h => h.1
  | _+1,_,_,h => h.1

/-- Embedding of later birth addresses after removing the first ghost/edge. -/
def tailAddress {n : ℕ} : FutureAddress I B n → FutureAddress I B (n+1)
  | .inl a => .inl (a.1.succ, a.2)
  | .inr a => .inr (a.1.succ, a.2)

omit [Fintype I] in
theorem tailAddress_injective (n : ℕ) :
    Function.Injective (tailAddress (I:=I) (B:=B) (n:=n)) := by
  rintro (⟨k,i,a⟩ | ⟨k,i⟩) (⟨l,j,b⟩ | ⟨l,j⟩) he <;>
    simp_all [tailAddress]

@[simp] theorem futureLabels_tail (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j (n+1)) s)
    (a : FutureAddress I B n) :
    futureLabels value ν V η q ρ anchor geometry (n+1) j s h (tailAddress a) =
      futureLabels value ν V η q ρ anchor geometry n (j+1) _ h.2.2 a := by
  rcases a with ⟨k,i,a⟩ | ⟨k,i⟩ <;>
    simp [futureLabels, tailAddress, ghostAt, freshAt]

theorem futureLabels_firstGhost (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s)
    (i : I) (k : Fin ((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size) :
    futureLabels value ν V η q ρ anchor geometry n j s h
      (.inl (0,i,⟨k.val, lt_of_lt_of_le k.isLt ((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size_le⟩)) =
        some (value i (((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.values k)) := by
  cases n <;> simp [firstGhost, futureLabels, ghostAt, ghostSlot]

theorem futureLabels_firstFresh (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j (n+1)) s)
    (i : I) (p : P i) (hp : (h.2.1.val.group i).2 = Sum.inr p) :
    futureLabels value ν V η q ρ anchor geometry (n+1) j s h (.inr (0,i)) =
      some (value i p) := by
  simp [futureLabels, freshAt, freshSlot, hp]

/-- Distinct actual birth addresses imply that the first ghost batch is
injective as a tuple of physical prime labels. -/
theorem firstGhost_injective (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s)
    (hd : BirthsDistinct (futureLabels value ν V η q ρ anchor geometry n j s h))
    (i : I) : Function.Injective ((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.values := by
  intro k l he
  have hk := futureLabels_firstGhost value ν V η q ρ anchor geometry n j s h i k
  have hl := futureLabels_firstGhost value ν V η q ρ anchor geometry n j s h i l
  rw [← he] at hl
  have hab := hd _ _ _ hk hl
  have hv : k.val = l.val := by simpa using congrArg (fun a =>
    match a with | .inl b => b.2.2.val | .inr _ => 0) hab
  exact Fin.ext hv

/-- Actual ghost output is jointly distinct under global birth distinctness
and disjointness of the old live support from all later births. -/
theorem firstGhost_live (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s)
    (hd : BirthsDistinct (futureLabels value ν V η q ρ anchor geometry n j s h))
    (hs : s.LiveDistinct)
    (ha : Avoids value (futureValues value ν V η q ρ anchor geometry n j s h) s) :
    ((firstGhost ν V η q ρ anchor geometry n j s h).val.output anchor s (firstGhost ν V η q ρ anchor geometry n j s h).property).LiveDistinct := by
  apply PhysicalGhostChoice.output_liveDistinct anchor s (firstGhost ν V η q ρ anchor geometry n j s h).val (firstGhost ν V η q ρ anchor geometry n j s h).property hs
  · exact firstGhost_injective value ν V η q ρ anchor geometry n j s h hd
  · intro i k l he
    apply ha.1 i k
    refine ⟨.inl (0,i,⟨l.val, lt_of_lt_of_le l.isLt
      ((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size_le⟩), ?_⟩
    simpa [he] using futureLabels_firstGhost value ν V η q ρ anchor geometry n j s h i l
  · intro i k l he
    apply ha.2 i k
    refine ⟨.inl (0,i,⟨l.val, lt_of_lt_of_le l.isLt
      ((firstGhost ν V η q ρ anchor geometry n j s h).val i).2.size_le⟩), ?_⟩
    simpa [he] using futureLabels_firstGhost value ν V η q ρ anchor geometry n j s h i l

/-- Distinct performed addresses imply that current and immediate output
support avoid every birth of the remaining suffix. This is the causal
non-reentry invariant used to reconstruct actual lifespans. -/
theorem tail_future_invariants (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j (n+1)) s)
    (hd : BirthsDistinct (futureLabels value ν V η q ρ anchor geometry (n+1) j s h))
    (ha : Avoids value (futureValues value ν V η q ρ anchor geometry (n+1) j s h) s) :
    let sg := h.1.val.output anchor s h.1.property
    let se := h.2.1.val.output anchor sg h.2.1.property
    let A := futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2
    BirthsDistinct (futureLabels value ν V η q ρ anchor geometry n (j+1) se h.2.2) ∧
      Avoids value A s ∧ Avoids value A sg ∧ Avoids value A se := by
  let sg := h.1.val.output anchor s h.1.property
  let se := h.2.1.val.output anchor sg h.2.1.property
  let A := futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2
  have hdtail : BirthsDistinct
      (futureLabels value ν V η q ρ anchor geometry n (j+1) se h.2.2) := by
    intro a b p hap hbp
    apply tailAddress_injective n
    apply hd _ _ p
    · simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using hap
    · simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using hbp
  have hAsub : A ⊆ futureValues value ν V η q ρ anchor geometry (n+1) j s h := by
    rintro p ⟨a,ha⟩
    exact ⟨tailAddress a, by
      simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using ha⟩
  have hbeforeA : Avoids value A s :=
    ⟨fun i k hp => ha.1 i k (hAsub hp), fun i k hp => ha.2 i k (hAsub hp)⟩
  have hghostA : ∀ i k, value i ((h.1.val i).2.values k) ∉ A := by
    intro i k hp
    obtain ⟨a,hap⟩ := hp
    have hk := futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i k
    have he := hd _ (tailAddress a) _ hk (by
      simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation, firstGhost]
        using hap)
    rcases a with ⟨l,i',b⟩ | ⟨l,i'⟩ <;> simp [tailAddress] at he
    all_goals
      have hv := congrArg Fin.val he.1
      simp at hv
  have hgA : Avoids value A sg := ghost_output_avoids value A anchor s h.1.val
    h.1.property hbeforeA hghostA
  have hedgeA : ∀ i p, (h.2.1.val.group i).2 = Sum.inr p → value i p ∉ A := by
    intro i p hp hA
    obtain ⟨a,hap⟩ := hA
    have hk := futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hp
    have he := hd _ (tailAddress a) _ hk (by
      simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using hap)
    rcases a with ⟨l,i',b⟩ | ⟨l,i'⟩ <;> simp [tailAddress] at he
    all_goals
      have hv := congrArg Fin.val he.1
      simp at hv
  exact ⟨hdtail,hbeforeA,hgA,edge_output_avoids value A anchor sg h.2.1.val
    h.2.1.property hgA hedgeA⟩

theorem allLive_of_future_distinct (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations ν V η q ρ anchor geometry j n) s)
    (hd : BirthsDistinct (futureLabels value ν V η q ρ anchor geometry n j s h))
    (hs : s.LiveDistinct)
    (ha : Avoids value (futureValues value ν V η q ρ anchor geometry n j s h) s) :
    AllLive ν V η q ρ anchor geometry n j s h := by
  induction n generalizing j s with
  | zero => exact ⟨hs, firstGhost_live value ν V η q ρ anchor geometry 0 j s h hd hs ha⟩
  | succ n ih =>
    let sg := h.1.val.output anchor s h.1.property
    let se := h.2.1.val.output anchor sg h.2.1.property
    let tail := futureLabels value ν V η q ρ anchor geometry n (j+1) se h.2.2
    let A := futureValues value ν V η q ρ anchor geometry n (j+1) se h.2.2
    let E : Set ℕ := {p | ∃ i, futureLabels value ν V η q ρ anchor geometry
      (n+1) j s h (.inr (0,i)) = some p}
    have hdtail : BirthsDistinct tail := by
      intro a b p hap hbp
      apply tailAddress_injective n
      apply hd _ _ p
      · simpa only [futureLabels_tail, tail, se, sg, physicalEdgeOperation, physicalGhostOperation, firstGhost] using hap
      · simpa only [futureLabels_tail, tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using hbp
    have hAsub : A ⊆ futureValues value ν V η q ρ anchor geometry (n+1) j s h := by
      rintro p ⟨a,ha⟩
      exact ⟨tailAddress a, by simpa only [futureLabels_tail, se, sg, physicalEdgeOperation, physicalGhostOperation] using ha⟩
    have hEsub : E ⊆ futureValues value ν V η q ρ anchor geometry (n+1) j s h := by
      rintro p ⟨i,hi⟩
      exact ⟨.inr (0,i),hi⟩
    have hbeforeA : Avoids value A s :=
      ⟨fun i k hp => ha.1 i k (hAsub hp), fun i k hp => ha.2 i k (hAsub hp)⟩
    have hbeforeE : Avoids value E s :=
      ⟨fun i k hp => ha.1 i k (hEsub hp), fun i k hp => ha.2 i k (hEsub hp)⟩
    have hghostA : ∀ i k, value i ((h.1.val i).2.values k) ∉ A := by
      intro i k hp
      obtain ⟨a,hap⟩ := hp
      have hk := futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i k
      have he := hd _ (tailAddress a) _ hk (by simpa only [futureLabels_tail, tail, se, sg, physicalEdgeOperation, physicalGhostOperation, firstGhost] using hap)
      rcases a with ⟨l,i',b⟩ | ⟨l,i'⟩ <;> simp [tailAddress] at he
      all_goals
        have hv := congrArg Fin.val he.1
        simp at hv
    have hghostE : ∀ i k, value i ((h.1.val i).2.values k) ∉ E := by
      intro i k hp
      obtain ⟨i',hi'⟩ := hp
      have hk := futureLabels_firstGhost value ν V η q ρ anchor geometry (n+1) j s h i k
      have he := hd _ _ _ hk hi'
      cases he
    have hgA : Avoids value A sg := ghost_output_avoids value A anchor s h.1.val
      h.1.property hbeforeA hghostA
    have hgE : Avoids value E sg := ghost_output_avoids value E anchor s h.1.val
      h.1.property hbeforeE hghostE
    have hgLive : sg.LiveDistinct := firstGhost_live value ν V η q ρ anchor geometry
      (n+1) j s h hd hs ha
    have hfreshMem : ∀ i p, (h.2.1.val.group i).2 = Sum.inr p → value i p ∈ E := by
      intro i p hp
      exact ⟨i,futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hp⟩
    have heLive : se.LiveDistinct := by
      apply PhysicalEdgeChoice.output_liveDistinct anchor sg h.2.1.val h.2.1.property hgLive
      intro i p hp
      constructor
      · intro k he
        apply hgE.1 i k
        rw [← he]
        exact hfreshMem i p hp
      · intro k he
        apply hgE.2 i k
        rw [← he]
        exact hfreshMem i p hp
    have hedgeA : ∀ i p, (h.2.1.val.group i).2 = Sum.inr p → value i p ∉ A := by
      intro i p hp hA
      obtain ⟨a,hap⟩ := hA
      have hk := futureLabels_firstFresh value ν V η q ρ anchor geometry n j s h i p hp
      have he := hd _ (tailAddress a) _ hk (by simpa only [futureLabels_tail, tail, se, sg, physicalEdgeOperation, physicalGhostOperation, firstGhost] using hap)
      rcases a with ⟨l,i',b⟩ | ⟨l,i'⟩ <;> simp [tailAddress] at he
      all_goals
        have hv := congrArg Fin.val he.1
        simp at hv
    have heA : Avoids value A se := edge_output_avoids value A anchor sg h.2.1.val
      h.2.1.property hgA hedgeA
    exact ⟨hs,hgLive,ih (j+1) se h.2.2 hdtail heLive heA⟩

/-- Global performed numerical birth distinctness, with initially empty
pending memories, forces joint active/pending distinctness at every state
of the actual history. No schedule, local freshness assumption, or injective
numerical-label map is an input. -/
theorem allLive_of_birthsDistinct (N : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hd : BirthsDistinct (labels ν V η q ρ anchor geometry value N s h))
    (hempty : ∀ i, (s.memory P Line J B i).size = 0) :
    AllLive ν V η q ρ anchor geometry N 0 s h := by
  apply allLive_of_future_distinct value ν V η q ρ anchor geometry N 0 s h
  · intro a b p hap hbp
    apply Sum.inr.inj (hd (.inr a) (.inr b) p ?_ ?_)
    · cases a <;> simpa only [labels, futureLabels] using hap
    · cases b <;> simpa only [labels, futureLabels] using hbp
  · intro i
    refine ⟨?_, ?_, ?_⟩
    · intro k l he
      have hn := initial_labels_injective ν V η q ρ anchor geometry value N s h hd (a₁:=(i,k)) (a₂:=(i,l))
        (show value i (s.active P Line J B i k) = value i (s.active P Line J B i l)
          from congrArg (value i) he)
      exact congrArg Prod.snd hn
    · intro k
      have hk := k.isLt
      have he := hempty i
      omega
    · intro k l
      have hl := l.isLt
      have he := hempty i
      omega
  · constructor
    · intro i k hp
      obtain ⟨a,ha⟩ := hp
      have he := hd (.inl (i,k)) (.inr a) _ rfl (by
        cases a <;> simpa only [labels, futureLabels] using ha)
      cases he
    · intro i k
      have hk := k.isLt
      have he := hempty i
      omega

end ActualHistorySupport
end Elliptic.Operator
