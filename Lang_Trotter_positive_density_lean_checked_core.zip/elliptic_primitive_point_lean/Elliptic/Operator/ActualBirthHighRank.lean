module

public import Elliptic.Operator.BirthPermutationRestrictions
public import Elliptic.Operator.BirthPermutationCount

/-! # Actual per-permutation high-rank prime-atom saving

The bound is on the literal initial prime mass and dependent physical
histories. It derives exactly one atom per cycle rank from actual earlier
pivots, including initial draws, ghost batches, and fresh edge choices.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.ActualBirthHighRank
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthRegistry
attribute [local instance 100000] Classical.propDecidable
local instance actualBirthHighRankDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 400000

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B N : ℕ}
local instance (priority := 100000) actualBirthHighRankAddressDecEq :
    DecidableEq (ActualHistoryBirths.Address I J B N) := Classical.typeDecidableEq _

/-- Actual positive mass for one fixed address permutation. -/
def mass
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (F:PhysicalMemoryState (Z:=Z) P Line J B → ℝ) (z:Z) : ℝ :=
  ∑a:PhysicalActiveLists P J,(∏i,tupleWeight (ν i) (a i))*
    (∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (vacuumState (Line:=Line) (B:=B) z a),
      if BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
      then ‖h.weight‖*F h.final else 0)

/-- Exact cycle-rank saving for every group-compatible permutation.
All row and initial-prime estimates are discharged by the preceding actual
coefficient lemmas; no high-rank mass estimate is assumed. -/
theorem mass_le
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ v0 Δ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (hinj:∀i,Function.Injective (value i))
    (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) (G:ℕ → ℝ)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:∀j,0≤η j) (hq:∀j,0≤q j)
    (hρ:0<ρ) (hρ1:ρ≤1) (hv0:0<v0) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ)
    (hp:∀j,q j/ρ^2+η j/(ρ*v0)≤1) (hG:∀j,0≤G j)
    (hgeometry:∀j z a b,(∑w:Z,‖geometry j z a w b‖)≤G j)
    (F:PhysicalMemoryState (Z:=Z) P Line J B → ℝ)
    (hF0:∀s,0≤F s) (hF:∀s,F s≤physicalMemorySchurWeight v0 s) (z:Z) :
    mass ν V η q ρ anchor geometry value σ F z ≤
      (BirthPermutationPlan.plan σ hgroup).wordFactor ν V η ρ v0 G 0 N *
      Δ^(birthCycleRank σ) *
      ∏i,(∑p,ν i p)^((J+1)-(BirthPermutationPlan.initialSlots σ i).card) := by
  have hb:=boundary_sum_le ν V η q ρ v0 Δ anchor geometry value hinj
    (BirthPermutationPlan.plan σ hgroup) (BirthPermutationPlan.initialPlan σ hgroup) G
    hν hV hη hq hρ hρ1 hv0 hΔ hatom hp hG hgeometry F hF0 hF N z
  rw [BirthPermutationPlan.total_count_eq_rank σ hgroup] at hb
  apply le_trans ?_ hb
  unfold mass
  apply Finset.sum_le_sum
  intro a _
  apply mul_le_mul_of_nonneg_left ?_
    (Finset.prod_nonneg (fun i _=>Finset.prod_nonneg (fun k _=>hν i (a i k))))
  apply Finset.sum_le_sum
  intro h _
  by_cases hp:BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
  · have hr:=BirthPermutationPlan.actual_completed_restrictions ν V η q ρ anchor geometry value σ hgroup
      (vacuumState (Line:=Line) (B:=B) z a) h hp
    simp only [ite_eq_left hp,ite_eq_left hr]
    exact le_rfl
  · rw [ite_eq_right hp]
    split_ifs
    · exact mul_nonneg (norm_nonneg _) (hF0 _)
    · exact le_rfl

/-- A permutation mixing disjoint prime bands has exactly zero actual mass. -/
theorem mass_eq_zero_of_not_group
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (hinj:Function.Injective (fun a:Sigma P=>value a.1 a.2))
    (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (hgroup:¬∀a,addressGroup (σ a)=addressGroup a)
    (F:PhysicalMemoryState (Z:=Z) P Line J B → ℝ) (z:Z) :
    mass ν V η q ρ anchor geometry value σ F z=0 := by
  unfold mass
  apply Finset.sum_eq_zero
  intro a _
  have he : (∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (vacuumState (Line:=Line) (B:=B) z a),
      if BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
      then ‖h.weight‖*F h.final else 0)=0 := by
    apply Finset.sum_eq_zero
    intro h _
    apply ite_eq_right
    intro hp
    exact hgroup (birthPreserving_group ν V η q ρ anchor geometry value _ h hinj σ hp)
  rw [he,mul_zero]

/-- The literal signed boundary contribution for one address permutation. -/
def term
    (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ:ℝ)
    (anchor:Z→∀i p,Line i p)
    (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value:∀i,P i→ℕ) (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (z:Z):ℂ:=
  ∑a:PhysicalActiveLists P J,((∏i,tupleWeight (ν i) (a i):ℝ):ℂ)*
    ∑h:ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N)
      (vacuumState (Line:=Line) (B:=B) z a),
      if BirthPreserving (labels ν V η q ρ anchor geometry value N _ h) σ
      then h.weight*F h.final else 0

theorem term_norm_le_mass
    (ν : ∀i,P i→ℝ) (V:I→ℝ) (η q:ℕ→ℝ) (ρ:ℝ)
    (anchor:Z→∀i p,Line i p)
    (geometry:ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value:∀i,P i→ℕ) (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (hν:∀i p,0≤ν i p) (z:Z):
    ‖term ν V η q ρ anchor geometry value σ F z‖≤
      mass ν V η q ρ anchor geometry value σ (fun s=>‖F s‖) z:=by
  unfold term mass
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro a _
  have hm:0≤∏i,tupleWeight (ν i) (a i):=
    Finset.prod_nonneg (fun i _=>Finset.prod_nonneg (fun k _=>hν i _))
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hm]
  apply mul_le_mul_of_nonneg_left ?_ hm
  apply (norm_sum_le _ _).trans_eq
  apply Finset.sum_congr rfl
  intro h _
  split_ifs <;> simp [norm_mul]

/-- High-rank atom saving for the actual signed physical boundary term. -/
theorem term_norm_le
    (ν : ∀i,P i → ℝ) (V:I → ℝ) (η q:ℕ → ℝ) (ρ v0 Δ:ℝ)
    (anchor:Z → ∀i p,Line i p)
    (geometry:ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (value:∀i,P i → ℕ) (hinj:∀i,Function.Injective (value i))
    (σ:Equiv.Perm (ActualHistoryBirths.Address I J B N))
    (hgroup:∀a,addressGroup (σ a)=addressGroup a) (G:ℕ → ℝ)
    (hν:∀i p,0≤ν i p) (hV:∀i,0≤V i) (hη:∀j,0≤η j) (hq:∀j,0≤q j)
    (hρ:0<ρ) (hρ1:ρ≤1) (hv0:0<v0) (hΔ:0≤Δ) (hatom:∀i p,ν i p≤Δ)
    (hp:∀j,q j/ρ^2+η j/(ρ*v0)≤1) (hG:∀j,0≤G j)
    (hgeometry:∀j z a b,(∑w:Z,‖geometry j z a w b‖)≤G j)
    (F:PhysicalMemoryState (Z:=Z) P Line J B→ℂ)
    (hF:∀s,‖F s‖≤physicalMemorySchurWeight v0 s) (z:Z):
    ‖term ν V η q ρ anchor geometry value σ F z‖ ≤
      (BirthPermutationPlan.plan σ hgroup).wordFactor ν V η ρ v0 G 0 N *
      Δ^(birthCycleRank σ) *
      ∏i,(∑p,ν i p)^((J+1)-(BirthPermutationPlan.initialSlots σ i).card):=
  (term_norm_le_mass ν V η q ρ anchor geometry value σ F hν z).trans
    (mass_le ν V η q ρ v0 Δ anchor geometry value hinj σ hgroup G
      hν hV hη hq hρ hρ1 hv0 hΔ hatom hp hG hgeometry
      (fun s=>‖F s‖) (fun _=>norm_nonneg _) hF z)

end Elliptic.Operator.ActualBirthHighRank
