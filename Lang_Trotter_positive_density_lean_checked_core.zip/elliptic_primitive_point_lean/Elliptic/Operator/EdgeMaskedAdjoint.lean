module

public import Elliptic.Operator.PhysicalEdgeAdjoint

/-!
# Exact store/promotion masks under measured reversal

The four physical edge cases must retain their masks: reversal exchanges
stores and promotions. The coefficient extraction below is identified with
the literal indexed mask, and the existing measured reversal then applies
to each of the four pieces separately.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

/-- Boolean coefficient of a bilinear polynomial, evaluated on {0,1}². -/
def edgeMaskComponent {R : Type*} [Ring R] (s p : Bool) (f : R → R → R) : R :=
  if s then
    if p then f 1 1 - f 1 0 - f 0 1 + f 0 0 else f 1 0 - f 0 0
  else if p then f 0 1 - f 0 0 else f 0 0

theorem edgeMaskComponent_sum {R : Type*} [CommRing R] {X : Type*}
    (S : Finset X) (s p : Bool) (f : X → R → R → R) :
    edgeMaskComponent s p (fun a b => ∑ x ∈ S, f x a b) =
      ∑ x ∈ S, edgeMaskComponent s p (f x) := by
  cases s <;> cases p <;> simp [edgeMaskComponent,Finset.sum_sub_distrib,Finset.sum_add_distrib]

theorem edgeMaskComponent_mul {R : Type*} [CommRing R]
    (s p : Bool) (c : R) (f : R → R → R) :
    edgeMaskComponent s p (fun a b => c * f a b) = c * edgeMaskComponent s p f := by
  cases s <;> cases p <;> simp [edgeMaskComponent] <;> ring

theorem edgeMaskComponent_swap {R : Type*} [CommRing R]
    (s p : Bool) (f : R → R → R) :
    edgeMaskComponent s p (fun a b => f b a) = edgeMaskComponent p s f := by
  cases s <;> cases p <;> simp [edgeMaskComponent] <;> ring

/-- The original old/fresh branch, read without identifying repeated indices. -/
def edgeChoicePromotes {P : Type*} {Line : P → Type*} {B : ℕ}
    {m : MemoryState (AnchoredParticle P Line) B} (c : EdgeGroupChoice m) : Bool :=
  match c.2 with | .inl _ => true | .inr _ => false

/-- Literal indexed edge with exact store and promotion masks. -/
def maskedFixedTargetApply {P R : Type*} [Fintype P] {Line : P → Type*}
    {B : ℕ} [Field R] (ν : P → R) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) : R :=
  ∑ c : EdgeGroupChoice m, if hc : EdgeGroupChoice.Valid targetAnchor m c then
    if edgeTargetPrime m c = target ∧ c.1 = S ∧ edgeChoicePromotes c = I then
      store^c.1.toNat * (match c.2 with | .inl _ => promote | .inr p => ν p) *
        F (tupleBag (edgeGroupOutput sourceAnchor source m c hc.2).values)
    else 0
  else 0

/-- The mask extraction is exactly the actual indexed restriction,
including each repeated old-particle choice with its original coefficient. -/
theorem maskedFixedTargetApply_eq_component {P R : Type*} [Fintype P] {Line : P → Type*}
    {B : ℕ} [Field R] (ν : P → R) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    maskedFixedTargetApply ν store promote S I sourceAnchor targetAnchor source target F m =
      store ^ S.toNat * promote ^ I.toNat * edgeMaskComponent S I
        (fun a b => fixedTargetEdgeChoiceApply ν a b sourceAnchor targetAnchor source target F m) := by
  unfold fixedTargetEdgeChoiceApply
  rw [edgeMaskComponent_sum, Finset.mul_sum]
  unfold maskedFixedTargetApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : EdgeGroupChoice.Valid targetAnchor m c
  · simp only [dite_eq_left hc]
    by_cases ht : edgeTargetPrime m c = target
    · simp only [ht,true_and,ite_true]
      rcases c with ⟨st,choice⟩
      cases st <;> cases choice <;> cases S <;> cases I <;>
        simp [edgeMaskComponent,edgeChoicePromotes,mul_assoc]
    · simp [ht,edgeMaskComponent]
  · simp [hc,edgeMaskComponent]

namespace PhysicalEdgeAdjoint
variable {P : Type*} [Fintype P] {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}

/-- Exact masked indexed transfer with both endpoint damping functions. -/
def dampedMaskedFixedTargetApply {R : Type*} [Field R]
    (ν : P → R) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) : R :=
  sourceDamping (tupleBag m.values) *
    maskedFixedTargetApply ν store promote S I sourceAnchor targetAnchor source target
      (fun t => targetDamping t * F t) m

theorem dampedMaskedFixedTargetApply_eq_component {R : Type*} [Field R]
    (ν : P → R) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    dampedMaskedFixedTargetApply ν store promote S I sourceAnchor targetAnchor source target
      sourceDamping targetDamping F m =
    store ^ S.toNat * promote ^ I.toNat * edgeMaskComponent S I
      (fun a b => dampedFixedTargetApply ν a b sourceAnchor targetAnchor source target
        sourceDamping targetDamping F m) := by
  unfold dampedMaskedFixedTargetApply dampedFixedTargetApply
  rw [maskedFixedTargetApply_eq_component,edgeMaskComponent_mul]
  ring

/-- Measured reversal exchanges the two exact masks as well as the
store/promotion coefficients. This statement is for literal indexed edges. -/
theorem dampedMaskedFixedTargetApply_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F G : Multiset (AnchoredParticle P Line) → R) :
    ν source * (∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun x : AnchoredParticle P Line => ν x.1) * G (tupleBag m.values) *
        dampedMaskedFixedTargetApply ν store promote S I sourceAnchor targetAnchor source target
          sourceDamping targetDamping F m) =
    ν target * (∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun x : AnchoredParticle P Line => ν x.1) * F (tupleBag m.values) *
        dampedMaskedFixedTargetApply ν promote store I S targetAnchor sourceAnchor target source
          targetDamping sourceDamping G m) := by
  have he (a b : R) := dampedFixedTargetApply_adjoint (B:=B) ν hν a b sourceAnchor targetAnchor
    source target sourceDamping targetDamping F G
  have hc := congrArg (edgeMaskComponent S I) (funext fun a => funext fun b => he a b)
  simp only [edgeMaskComponent_mul,edgeMaskComponent_sum] at hc
  simp_rw [← edgeMaskComponent_mul] at hc
  have hr : edgeMaskComponent S I
      (fun a b => ν target * ∑ m : MemoryState (AnchoredParticle P Line) B,
        m.mass (fun x : AnchoredParticle P Line => ν x.1) * F (tupleBag m.values) *
        dampedFixedTargetApply ν b a targetAnchor sourceAnchor target source
          targetDamping sourceDamping G m) =
      edgeMaskComponent I S
      (fun a b => ν target * ∑ m : MemoryState (AnchoredParticle P Line) B,
        m.mass (fun x : AnchoredParticle P Line => ν x.1) * F (tupleBag m.values) *
        dampedFixedTargetApply ν a b targetAnchor sourceAnchor target source
          targetDamping sourceDamping G m) := edgeMaskComponent_swap S I _
  have hb := congrArg (fun x : R => store ^ S.toNat * promote ^ I.toNat * x)
    ((congrArg (edgeMaskComponent S I) (funext fun a => funext fun b => he a b)).trans hr)
  simp only [edgeMaskComponent_mul,edgeMaskComponent_sum,Finset.mul_sum,
    dampedMaskedFixedTargetApply_eq_component] at *
  convert hb using 1 <;>
    apply Finset.sum_congr rfl <;> intro m _ <;> ring

/-- The actual quotient kernel for one exact store/promotion mask. -/
def maskedDampedBagKernel {R : Type*} [Field R]
    (ν : P → R) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (s t : MemoryBag (AnchoredParticle P Line) B) : R :=
  store ^ S.toNat * promote ^ I.toNat * edgeMaskComponent S I
    (fun a b => dampedBagKernel ν a b sourceAnchor targetAnchor source target
      sourceDamping targetDamping s t)

/-- The mask kernel acts on the actual indexed memory choices; it is not
an independently assumed adjoint matrix. -/
theorem maskedDampedBagKernel_eq_indexed {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B)
    (t : MemoryBag (AnchoredParticle P Line) B) :
    maskedDampedBagKernel ν store promote S I sourceAnchor targetAnchor source target
      sourceDamping targetDamping (memoryBagOf m) t =
    dampedMaskedFixedTargetApply ν store promote S I sourceAnchor targetAnchor source target
      sourceDamping targetDamping (fun b => if b = t.val then 1 else 0) m := by
  rw [dampedMaskedFixedTargetApply_eq_component]
  simp_rw [dampedFixedTargetApply_eq_bagTransfer ν hν]
  rfl

/-- Pointwise measured reversal on the actual bag quotient exchanges the
exact store and promotion masks. -/
theorem maskedDampedBagKernel_balance {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R) (S I : Bool)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (s t : MemoryBag (AnchoredParticle P Line) B) :
    ν source * memoryBagMass (fun x : AnchoredParticle P Line => ν x.1) s *
      maskedDampedBagKernel ν store promote S I sourceAnchor targetAnchor source target
        sourceDamping targetDamping s t =
    ν target * memoryBagMass (fun x : AnchoredParticle P Line => ν x.1) t *
      maskedDampedBagKernel ν promote store I S targetAnchor sourceAnchor target source
        targetDamping sourceDamping t s := by
  have he (a b : R) := dampedBagKernel_balance ν hν a b sourceAnchor targetAnchor
    source target sourceDamping targetDamping s t
  have hh := congrArg (edgeMaskComponent S I) (funext fun a => funext fun b => he a b)
  rw [edgeMaskComponent_swap S I (fun a b => ν target *
    memoryBagMass (fun x : AnchoredParticle P Line => ν x.1) t *
    dampedBagKernel ν a b targetAnchor sourceAnchor target source targetDamping sourceDamping t s)] at hh
  simp only [edgeMaskComponent_mul] at hh
  unfold maskedDampedBagKernel
  linear_combination (store ^ S.toNat * promote ^ I.toNat) * hh

variable {G : Type*} [Fintype G]
variable {Q : G → Type*} [∀ i, Fintype (Q i)]
variable {Lines : ∀ i, Q i → Type*} [∀ i p, Fintype (Lines i p)]

/-- Full grouped mask kernel on the actual finite bag quotient. -/
def groupedMaskedBagKernel {R : Type*} [Field R]
    (ν : ∀ i, Q i → R) (store promote : G → R) (S I : G → Bool)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (Q i) (Lines i)) → R)
    (s t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B)) : R :=
  ∏ i, maskedDampedBagKernel (ν i) (store i) (promote i) (S i) (I i)
    (sourceAnchor i) (targetAnchor i) (s i).1 (t i).1
    (sourceDamping i) (targetDamping i) (s i).2 (t i).2

/-- All groups retain the exact factorial bag measure and both masks. -/
theorem groupedMaskedBagKernel_balance {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (Q i) (Lines i)) → R)
    (s t : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B)) :
    groupedBagMass ν s * groupedMaskedBagKernel ν store promote S I
      sourceAnchor targetAnchor sourceDamping targetDamping s t =
    groupedBagMass ν t * groupedMaskedBagKernel ν promote store I S
      targetAnchor sourceAnchor targetDamping sourceDamping t s := by
  unfold groupedBagMass groupedMaskedBagKernel
  rw [← Finset.prod_mul_distrib, ← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  exact maskedDampedBagKernel_balance (ν i) (hν i) (store i) (promote i) (S i) (I i)
    (sourceAnchor i) (targetAnchor i) (s i).1 (t i).1
    (sourceDamping i) (targetDamping i) (s i).2 (t i).2

/-- Measured reversal of each of the four grouped store/promotion cases,
with arbitrary coupled endpoint restrictions and total cutoff. -/
theorem groupedMaskedBagKernel_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, Q i → R) (hν : ∀ i p, ν i p ≠ 0)
    (store promote : G → R) (S I : G → Bool)
    (sourceAnchor targetAnchor : ∀ i p, Lines i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (Q i) (Lines i)) → R)
    (geometry : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B) →
      GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B) → R)
    (F H : GroupedBagOutput (P:=Q) (Line:=Lines) (B:=B) → R) :
    (∑ s, groupedBagMass ν s * H s * ∑ t, geometry s t *
      groupedMaskedBagKernel ν store promote S I sourceAnchor targetAnchor sourceDamping targetDamping s t * F t) =
    ∑ t, groupedBagMass ν t * F t * ∑ s, geometry s t *
      groupedMaskedBagKernel ν promote store I S targetAnchor sourceAnchor targetDamping sourceDamping t s * H s := by
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t _
  apply Finset.sum_congr rfl
  intro s _
  have h := groupedMaskedBagKernel_balance ν hν store promote S I sourceAnchor targetAnchor
    sourceDamping targetDamping s t
  calc
    _ = (groupedBagMass ν s * groupedMaskedBagKernel ν store promote S I sourceAnchor targetAnchor
        sourceDamping targetDamping s t) * (geometry s t * F t * H s) := by ring
    _ = (groupedBagMass ν t * groupedMaskedBagKernel ν promote store I S targetAnchor sourceAnchor
        targetDamping sourceDamping t s) * (geometry s t * F t * H s) := by rw [h]
    _ = _ := by ring

end PhysicalEdgeAdjoint
end Elliptic.Operator
