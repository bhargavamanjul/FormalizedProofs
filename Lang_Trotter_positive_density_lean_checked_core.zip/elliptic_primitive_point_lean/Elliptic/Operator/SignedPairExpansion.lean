module

public import Elliptic.Operator.SignedDeterminantReduction

/-! Exact reconstruction of the literal scalar sum and its expanded
pair square. Finite dyadic partition identities are algebraic hypotheses,
not estimates for any desired signed bilinear form. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPairExpansion
open scoped BigOperators ComplexConjugate
open Artin Artin.MarkedSource SignedCauchyExpansion SignedDamping SignedDampingBounds
open SignedDyadicCauchy SignedDeterminantReduction
attribute [local instance] Classical.propDecidable
local instance decEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {K : ℕ}

theorem replaced_bilinear_eq_records (b : Bands K) (q x : ℝ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (hF : InvariantSelector b x F)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ))=
      dyadicSum b q x 1 s t (fun _=>1) α β F := by
  unfold Sieve.SignedReplacement.bilinear replacedWeight dyadicSum records
  rw [Finset.sum_filter,Fintype.sum_prod_type]
  simp_rw [Fintype.sum_prod_type]
  simp only [cofactor]
  rw [Finset.sum_coe_sort s (fun m : ℕ=>∑ n : t,∑ p : LabelTuple b x,
    if Divides b x p (m*n.val+1) then α m*β n.val*1*
      (cofactorDamping b q x ((m*n.val+1)/labelProduct b x p):ℂ)*F ((m*n.val+1)/labelProduct b x p) else 0)]
  apply Finset.sum_congr rfl
  intro m _
  rw [Finset.sum_coe_sort t (fun n : ℕ=>∑ p : LabelTuple b x,
    if Divides b x p (m*n+1) then α m*β n*1*
      (cofactorDamping b q x ((m*n+1)/labelProduct b x p):ℂ)*F ((m*n+1)/labelProduct b x p) else 0)]
  apply Finset.sum_congr rfl
  intro n _
  push_cast
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hp : Divides b x p (m*n+1)
  · simp only [if_pos hp,mul_one]
    rw [selector_eq_cofactor b x F hF p hdisjoint (m*n+1) (by omega) hp]
    ring
  · simp [hp]

/-- Any actual finite partition of the selected label products reconstructs
exactly the full replaced successor sum. -/
theorem sum_dyadicSum_eq_replaced {ι : Type*} (J : Finset ι)
    (b : Bands K) (q x : ℝ) (Y : ι→ℝ) (η : ι→ℝ→ℂ)
    (s t : Finset ℕ) (α β F : ℕ→ℂ) (hF : InvariantSelector b x F)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hpartition : ∀p : LabelTuple b x,∑j∈J,η j ((labelProduct b x p:ℝ)/Y j)=1) :
    (∑j∈J,dyadicSum b q x (Y j) s t (η j) α β F)=
      Sieve.SignedReplacement.bilinear s t α β (fun n=>F n*(replacedWeight b q x n:ℂ)) := by
  rw [replaced_bilinear_eq_records b q x s t α β F hF hdisjoint]
  unfold dyadicSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro r _
  simp only [←Finset.sum_mul,←Finset.mul_sum,hpartition,mul_one]

theorem fiber_square_eq_pairs (b : Bands K) (x Y : ℝ) (s t : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) :
    ((∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2:ℝ):ℂ)=
      ∑r∈dyadicRecords b x Y s t η,∑u∈dyadicRecords b x Y s t η,
        if cofactor b x s t r=cofactor b x s t u then
          undampedCoefficient b x Y s t η α β r*conj (undampedCoefficient b x Y s t η α β u) else 0 := by
  rw [actual_fiber_square_expansion]
  have hf := Finset.sum_fiberwise_of_maps_to
    (s:=dyadicRecords b x Y s t η) (t:=dyadicCofactors b x Y s t η)
    (g:=cofactor b x s t) (fun r hr=>Finset.mem_image.mpr ⟨r,hr,rfl⟩)
    (fun r=>∑u∈dyadicRecords b x Y s t η,if cofactor b x s t r=cofactor b x s t u then
      undampedCoefficient b x Y s t η α β r*conj (undampedCoefficient b x Y s t η α β u) else 0)
  rw [←hf]
  apply Finset.sum_congr rfl
  intro h _
  apply Finset.sum_congr rfl
  intro r hr
  rw [Finset.sum_filter,(Finset.mem_filter.mp hr).2]
  apply Finset.sum_congr rfl
  intro u _
  simp only [eq_comm]

/-- Actual equation (3.8), with the determinant replacement already in
successor orientation. The positive fiber energy remains the definition,
so the complex pair expansion introduces no positivity assumption. -/
theorem fiber_square_eq_signed_determinants (b : Bands K) (x Y : ℝ) (s t : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ)
    (hdisjoint : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j))) :
    ((∑h∈dyadicCofactors b x Y s t η,‖undampedFiber b x Y s t η α β h‖^2:ℝ):ℂ)=
      ∑r∈dyadicRecords b x Y s t η,∑u∈dyadicRecords b x Y s t η,
        if (labelProduct b x u.2.2:ℤ)*r.1.val*r.2.1.val-
          (labelProduct b x r.2.2:ℤ)*u.1.val*u.2.1.val=
          (labelProduct b x r.2.2:ℤ)-labelProduct b x u.2.2 then
          undampedCoefficient b x Y s t η α β r*conj (undampedCoefficient b x Y s t η α β u) else 0 := by
  rw [fiber_square_eq_pairs]
  apply Finset.sum_congr rfl
  intro r hr
  apply Finset.sum_congr rfl
  intro u hu
  simp only [actual_record_cofactor_iff b x s t hdisjoint r u
    (Finset.mem_filter.mp hr).1 (Finset.mem_filter.mp hu).1]

end Elliptic.Operator.SignedPairExpansion
