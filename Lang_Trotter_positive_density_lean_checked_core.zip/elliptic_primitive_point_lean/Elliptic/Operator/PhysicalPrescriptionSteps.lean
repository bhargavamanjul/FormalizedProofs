module

public import Elliptic.Operator.ChronologicalPrescription
public import Elliptic.Operator.PrescribedPhysicalGhost
public import Elliptic.Operator.PrescribedEdgeRow

/-! # Certified chronological steps for the literal physical operations

The constructors discharge the prescribed-row estimates from actual choice
coefficients. Registry updates may record any information from past choices;
no terminal endpoint is included in a prescribed target.
-/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPrescriptionSteps
open scoped BigOperators
open ChronologicalPrescription
attribute [local instance] Classical.propDecidable
local instance physicalPrescriptionStepsDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

/-- Put the actual validity test inside an arbitrary finite choice sum. -/
theorem sum_valid {X : Type*} (O : ChoiceOperation X) (x:X)
    (f : O.ValidChoice x → ℝ) :
    (∑c : O.ValidChoice x,f c) =
      ∑c : O.Choice x,if hc : O.valid x c then f ⟨c,hc⟩ else 0 := by
  symm
  rw [Finset.sum_dite]
  simp only [Finset.sum_const_zero,add_zero]
  exact (Equiv.subtypeEquivRight (by simp)).sum_comp f

variable {I Z R : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀i,Fintype (P i)]
variable {Line : ∀i,P i → Type} {J B : ℕ}

/-- Actual ghost operation with adaptive named performed coordinates. -/
def ghost
    (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q ρ v0 Δ : ℝ)
    (anchor : Z→∀i p,Line i p) (value : ∀i,P i→ℕ)
    (hinj : ∀i,Function.Injective (value i)) (S : I→Finset ℕ)
    (target : R→∀i k,(Fin k→P i)→ℕ)
    (update : ∀s : PhysicalMemoryState (Z:=Z) P Line J B,R→PhysicalGhostChoice s→R)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hη : 0≤η) (hq : 0≤q)
    (hρ : 0<ρ) (hv0 : 0<v0) (hp : q/ρ^2+η/(ρ*v0)≤1)
    (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ) :
    Step (PhysicalMemoryState (Z:=Z) P Line J B) R (physicalMemorySchurWeight v0) Δ where
  operation := physicalGhostOperation ν V η q ρ anchor
  allowed s r c := PrescribedPhysicalGhost.Allowed value S (target r) c.val
  update s r c := update s r c.val
  count := ∑i,(S i).card
  factor := ∏i,((η*V i/ρ)*v0)^(S i).card *Real.exp ((η*V i/ρ)*v0*∑p,ν i p)
  factor_nonneg := Finset.prod_nonneg (fun i _ => by
    have hVi := hV i
    positivity)
  row_bound s r := by
    rw [sum_valid]
    exact PrescribedPhysicalGhost.row_le_atoms ν V η q ρ v0 Δ anchor value hinj S (target r) s
      hν hV hη hq hρ hv0 hp hΔ hatom

/-- Actual edge operation with prescribed fresh-group values. The target
position sum has already been estimated with all prime labels fixed. -/
def edge
    (ν : ∀i,P i→ℝ) (V : I→ℝ) (ρ v0 G Δ : ℝ)
    (anchor : Z→∀i p,Line i p)
    (geometry : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (value : ∀i,P i→ℕ) (hinj : ∀i,Function.Injective (value i))
    (S : Finset I) (target : R→I→ℕ)
    (update : ∀s : PhysicalMemoryState (Z:=Z) P Line J B,R→PhysicalEdgeChoice s→R)
    (hν : ∀i p,0≤ν i p) (hV : ∀i,0≤V i) (hρ0 : 0≤ρ) (hρ1 : ρ≤1)
    (hv0 : 0<v0) (hG : 0≤G) (hΔ : 0≤Δ) (hatom : ∀i p,ν i p≤Δ)
    (hgeometry : ∀z a b,(∑w : Z,‖geometry z a w b‖)≤G) :
    Step (PhysicalMemoryState (Z:=Z) P Line J B) R (physicalMemorySchurWeight v0) Δ where
  operation := physicalEdgeOperation ν V ρ anchor geometry
  allowed s r c := ∀i∈S,PrescribedEdgeRow.Prescribed (value i) (target r i) (c.val.group i)
  update s r c := update s r c.val
  count := S.card
  factor := G*∏i,(1+v0)*max 1 ((B:ℝ)*(V i)⁻¹/v0+∑p,ν i p)
  factor_nonneg := mul_nonneg hG (Finset.prod_nonneg (fun i _ => by positivity))
  row_bound s r := by
    apply (div_le_iff₀ (physicalMemorySchurWeight_pos hv0 s)).mp
    have hh := PrescribedEdgeRow.choiceRow_le_atoms ν V ρ v0 G Δ anchor geometry value hinj
      S (target r) s hν hV hρ0 hρ1 hv0 hG hΔ hatom (hgeometry _)
    convert hh using 1
    rw [sum_valid,Finset.sum_div]
    apply Finset.sum_congr rfl
    intro c _
    by_cases hc : c.Valid anchor s
    · simp only [physicalEdgeOperation,dite_eq_left hc]
      split_ifs <;> simp only [mul_div_assoc,zero_div]
    · simp only [physicalEdgeOperation,dite_eq_right hc,zero_div]

end Elliptic.Operator.PhysicalPrescriptionSteps
