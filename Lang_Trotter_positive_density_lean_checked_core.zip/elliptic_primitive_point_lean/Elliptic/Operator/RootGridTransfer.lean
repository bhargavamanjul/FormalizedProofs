module

public import Elliptic.Operator.RootArchimedeanGrid
public import Elliptic.Operator.RootGridPartition

/-!
# Applying the root-count contract to the constructed grid

The grid size and valid source intervals are proved from the concrete
construction. A single eventual threshold controls all grids, all
selected subfamilies, and their independently chosen residue tests.
The grid with `floor(x^(delta/8000))` subdivisions is admissible and
has mesh comparable with the specified power of x.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootGridTransfer
open Filter SourceRootCount SourceRootTransfer RootArchimedeanGrid
open RootGridPartition
open scoped BigOperators

theorem eventually_constructed_grid_transfer (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ) (s : Finset Index),
      s⊆grid n → (n:ℝ)^3 ≤ x^(δ/2000) →
      ∀ U V : ℝ, ∀ S : Index → ℕ, ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
      (∀ j∈s, 1≤S j ∧ Squarefree (S j) ∧
        (S j:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ))) →
      ∀ f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j∈s, ∀ g, ‖f j g‖≤1) →
      ‖(∑ j∈s, weightedRootSum U V (S j)
          (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)) -
        ∑ j∈s, (rootVolume U V (cell 1 16 n j.1) (cell 1 2 n j.2.1)
          (cell 0 1 n j.2.2):ℂ) *
            ((∑ g, f j g)/(Fintype.card
              (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ))‖ ≤
          U*V*x^(-(δ/4000)) := by
  filter_upwards [RootBoxFamily.eventually_bounded_box_family hPD δ C_S hδ hCS] with x hx
  intro n s hs hn U V S inst hU hU' hV hV' hS f hf
  apply hx Index s U V S hU hU' hV hV'
    (show (s.card:ℝ)≤x^(δ/2000) from ?_)
    (fun j => cell 1 16 n j.1) (fun j => cell 1 2 n j.2.1)
    (fun j => cell 0 1 n j.2.2) ?_ f hf
  · have hc : (s.card:ℝ) ≤ (n:ℝ)^3 := by
      have := (Finset.card_le_card hs).trans_eq (grid_card n)
      exact_mod_cast this
    exact hc.trans hn
  · intro j hj
    exact ⟨(hS j hj).1,(hS j hj).2.1,(hS j hj).2.2,grid_inRange n j (hs hj)⟩

/-- The same uniform discrepancy bound for the disjoint half-open root partition. -/
theorem eventually_partition_grid_transfer (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ) (s : Finset Index),
      s⊆grid n → (n:ℝ)^3 ≤ x^(δ/2000) →
      ∀ U V : ℝ, ∀ S : Index → ℕ, ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
      (∀ j∈s, 1≤S j ∧ Squarefree (S j) ∧
        (S j:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ))) →
      ∀ f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j∈s, ∀ g, ‖f j g‖≤1) →
      ‖(∑ j∈s, weightedRootSum U V (S j)
          (partCell 1 16 n j.1) (partCell 1 2 n j.2.1) (partCell 0 1 n j.2.2) (f j)) -
        ∑ j∈s, (rootVolume U V (partCell 1 16 n j.1) (partCell 1 2 n j.2.1)
          (partCell 0 1 n j.2.2):ℂ) *
            ((∑ g, f j g)/(Fintype.card
              (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ))‖ ≤
          U*V*x^(-(δ/4000)) := by
  filter_upwards [RootBoxFamily.eventually_bounded_box_family hPD δ C_S hδ hCS] with x hx
  intro n s hs hn U V S inst hU hU' hV hV' hS f hf
  apply hx Index s U V S hU hU' hV hV'
    (show (s.card:ℝ)≤x^(δ/2000) from ?_)
    (fun j => partCell 1 16 n j.1) (fun j => partCell 1 2 n j.2.1)
    (fun j => partCell 0 1 n j.2.2) ?_ f hf
  · have hc : (s.card:ℝ) ≤ (n:ℝ)^3 := by
      have := (Finset.card_le_card hs).trans_eq (grid_card n)
      exact_mod_cast this
    exact hc.trans hn
  · intro j hj
    exact ⟨(hS j hj).1,(hS j hj).2.1,(hS j hj).2.2,grid_inRange n j (hs hj)⟩

def subdivisions (δ x : ℝ) : ℕ := ⌊x^(δ/8000)⌋₊

theorem subdivisions_card_admissible (δ x : ℝ) (hδ : 0≤δ) (hx : 1≤x) :
    ((subdivisions δ x):ℝ)^3 ≤ x^(δ/2000) := by
  have hx0 : 0<x := by linarith
  calc
    _ ≤ (x^(δ/8000))^3 :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) (Nat.floor_le (by positivity)) 3
    _ = x^((δ/8000)*3) := by rw [←Real.rpow_mul_natCast hx0.le]; norm_num
    _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hx (by linarith)

theorem subdivisions_mesh (δ x : ℝ) (hx : 0<x) (hsize : 2≤x^(δ/8000)) :
    0<subdivisions δ x ∧
      (1:ℝ)/(subdivisions δ x) ≤ 2*x^(-(δ/8000)) := by
  have hf := Nat.lt_floor_add_one (x^(δ/8000))
  have hhalf : x^(δ/8000)/2 ≤ (subdivisions δ x:ℝ) := by
    dsimp [subdivisions]
    linarith
  have hnR : 0<(subdivisions δ x:ℝ) := by linarith
  refine ⟨by exact_mod_cast hnR,?_⟩
  rw [Real.rpow_neg hx.le]
  apply (div_le_iff₀ hnR).mpr
  have hp : 0<x^(δ/8000) := by positivity
  calc
    1 ≤ (2*(subdivisions δ x:ℝ))/x^(δ/8000) := (le_div_iff₀ hp).mpr (by linarith)
    _ = _ := by ring

theorem eventually_subdivisions (δ : ℝ) (hδ : 0<δ) :
    ∀ᶠ x : ℝ in atTop,
      0<subdivisions δ x ∧
      ((subdivisions δ x):ℝ)^3 ≤ x^(δ/2000) ∧
      (1:ℝ)/(subdivisions δ x) ≤ 2*x^(-(δ/8000)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop (show 0<δ/8000 by positivity)).eventually
      (eventually_ge_atTop (2:ℝ))] with x hx hsize
  have hm := subdivisions_mesh δ x (by linarith) hsize
  exact ⟨hm.1,subdivisions_card_admissible δ x hδ.le hx,hm.2⟩

theorem grid_rootVolume (U V : ℝ) (n : ℕ) (j : Index) :
    rootVolume U V (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) =
      (U*V/(Real.pi^2/6))*cellVolume n j := by
  dsimp [rootVolume,cellVolume]
  ring

theorem bounded_average_norm {G : Type*} [Fintype G] [Nonempty G]
    (f : G→ℂ) (hf : ∀ g, ‖f g‖≤1) :
    ‖(∑ g, f g)/(Fintype.card G:ℂ)‖ ≤ 1 := by
  rw [norm_div,Complex.norm_natCast]
  apply (div_le_one (by exact_mod_cast Fintype.card_pos)).mpr
  exact (norm_sum_le _ _).trans (by
    simpa only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one] using
      Finset.sum_le_sum (s:=Finset.univ) (fun g _ => hf g))

theorem grid_mainTerm_norm_le (U V : ℝ) (hU : 0≤U) (hV : 0≤V)
    (n : ℕ) (s : Finset Index) (S : Index→ℕ) [∀ j, Fintype (ZMod (S j))]
    (f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ)
    (hf : ∀ j∈s, ∀ g, ‖f j g‖≤1) :
    ‖∑ j∈s, (rootVolume U V (cell 1 16 n j.1) (cell 1 2 n j.2.1)
      (cell 0 1 n j.2.2):ℂ)*((∑ g, f j g)/(Fintype.card
        (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ))‖ ≤
      (U*V/(Real.pi^2/6))*∑ j∈s, cellVolume n j := by
  simp only [grid_rootVolume,Finset.mul_sum]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro j hj
  have hvol : 0≤cellVolume n j := by rw [cellVolume_eq]; positivity
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (by positivity)]
  exact mul_le_of_le_one_right (by positivity) (bounded_average_norm (f j) (hf j hj))

/-- Literal integer-root mass in the constructed boundary cubes is
controlled by their proved volume plus the uniform root-count error.
The family, endpoints, moduli and bounded tests may all vary after x. -/
theorem eventually_boundary_root_mass (hPD : RootCountContract)
    (δ C_S : ℝ) (hδ : 0<δ) (hCS : 0≤C_S) :
    ∀ᶠ x : ℝ in atTop, ∀ (n : ℕ), 0<n → (n:ℝ)^3 ≤ x^(δ/2000) →
      ∀ ends : Finset ℝ, ∀ U V : ℝ, ∀ S : Index → ℕ,
      ∀ [∀ j, Fintype (ZMod (S j))],
      x^δ ≤ U → U ≤ x^2 → x^δ ≤ V → V ≤ x^2 →
      (∀ j∈boundaryFamily n ends, 1≤S j ∧ Squarefree (S j) ∧
        (S j:ℝ)≤Real.exp (C_S*(Real.log x)^(98/100:ℝ))) →
      ∀ f : (j : Index) → Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j)) → ℂ,
      (∀ j∈boundaryFamily n ends, ∀ g, ‖f j g‖≤1) →
      ‖∑ j∈boundaryFamily n ends, weightedRootSum U V (S j)
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)‖ ≤
        (U*V/(Real.pi^2/6))*(30*(ends.card:ℝ)/n) + U*V*x^(-(δ/4000)) := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    eventually_constructed_grid_transfer hPD δ C_S hδ hCS] with x hx ht
  intro n hn hn' ends U V S inst hU hU' hV hV' hS f hf
  have hUp : 0≤U := (Real.rpow_pos_of_pos hx δ).le.trans hU
  have hVp : 0≤V := (Real.rpow_pos_of_pos hx δ).le.trans hV
  have htransfer := ht n (boundaryFamily n ends) (boundaryFamily_subset_grid n ends)
    hn' U V S hU hU' hV hV' hS f hf
  have hmain := grid_mainTerm_norm_le U V hUp hVp n (boundaryFamily n ends) S f hf
  have hvol := boundaryFamily_volume n hn ends
  have hmass := mul_le_mul_of_nonneg_left hvol (show 0≤U*V/(Real.pi^2/6) by positivity)
  have htri := norm_add_le
    ((∑ j∈boundaryFamily n ends, weightedRootSum U V (S j)
        (cell 1 16 n j.1) (cell 1 2 n j.2.1) (cell 0 1 n j.2.2) (f j)) -
      ∑ j∈boundaryFamily n ends, (rootVolume U V (cell 1 16 n j.1)
        (cell 1 2 n j.2.1) (cell 0 1 n j.2.2):ℂ)*
        ((∑ g, f j g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ)))
    (∑ j∈boundaryFamily n ends, (rootVolume U V (cell 1 16 n j.1)
      (cell 1 2 n j.2.1) (cell 0 1 n j.2.2):ℂ)*
      ((∑ g, f j g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (S j))):ℂ)))
  rw [sub_add_cancel] at htri
  linarith

end Elliptic.Operator.RootGridTransfer
