module

public import Elliptic.Operator.PhysicalCleanGoodProjection
public import Elliptic.Operator.PhysicalCleanFull

/-! The first-test premise of the full clean operator is discharged by
the literal source good predicate on its actual root coordinates. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalCleanRootProjection
open PhysicalCleanGoodProjection RootLiteralGeometry RootEndpointBudget
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 300000

variable {K J : ℕ}

/-- Physical eligibility supplies primitivity; the source's own chosen
complement therefore witnesses the full clean first-test projection. -/
theorem sourceGood_firstProjection
    (groups : Fin K → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (μ : ∀ i, groups i → ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K → ℝ) (q : RootPhysicalCell.RootPoint)
    (u v U W : ℝ) :
    PhysicalCleanFull.FirstProjection (J:=J) groups
      (sourceGood (fun _ p => p.val) μ d₀ Y L exponents q)
      u v q.2.2 U W d₀ Y := by
  intro z a hphysical hgood hinj hD hD'
  refine ⟨chosenComplement z,(chosenComplement_spec z hphysical.1).1,?_⟩
  exact sourceGood_first_chosen (P:=fun i => (groups i : Type))
    (fun _ p => p.val) μ d₀ Y L exponents q z a
    (actual_activeLabel_injective groups hdis a hinj) hD hD' hgood

/-- The full clean projection at the literal physical root coordinates.
No extra root-box hypothesis is required for this scalar implication. -/
theorem root_sourceGood_firstProjection
    (groups : Fin K → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j))
    (μ : ∀ i, groups i → ℝ)
    (d₀ Y L : ℝ) (exponents : Fin K → ℝ) (q : RootPhysicalCell.RootPoint)
    (U V : ℝ) :
    PhysicalCleanFull.FirstProjection (J:=J) groups
      (sourceGood (fun _ p => p.val) μ d₀ Y L exponents q)
      (U*q.1) (V*q.2.1) q.2.2 U V d₀ Y :=
  sourceGood_firstProjection groups hdis μ d₀ Y L exponents q (U*q.1) (V*q.2.1) U V

end Elliptic.Operator.PhysicalCleanRootProjection
