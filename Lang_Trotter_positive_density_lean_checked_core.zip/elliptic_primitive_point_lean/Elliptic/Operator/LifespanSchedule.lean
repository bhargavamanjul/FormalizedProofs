module

public import Elliptic.Operator.LifespanHistories
public import Elliptic.Operator.MemoryOutputBags

/-!
# The actual finite-set memory schedule of prime lifespans

For a chosen family of primewise lifespans this file constructs the pending,
birth, death, store, and promotion sets at every visit. The literal recurrences
are proved, including the disjointness which makes indexed deletion and a
fresh batch reproduce these sets. No operator/lifespan identity is a premise.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

namespace LifespanSchedule
variable {P : Type*} {N : ℕ}

def before (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).beforeGhost j)
def after (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).afterGhost j)
def births (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).ghostBorn j)
def deaths (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).ghostDies j)
def stores (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).stored j)
def promotions (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).promoted j)
def activeBirths (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) : Finset P :=
  S.filter (fun p => (L p).freshActive j)

theorem deaths_subset_before (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    deaths S L j ⊆ before S L j := by
  intro p hp
  obtain ⟨hp,hj⟩ := Finset.mem_filter.mp hp
  refine Finset.mem_filter.mpr ⟨hp,?_,?_,hj.2⟩
  · simpa only [hj.1] using (L p).ghostDies_birth_lt_death hj
  · exact hj.1.le

theorem births_disjoint_before (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    Disjoint (births S L j) (before S L j) := by
  rw [Finset.disjoint_left]
  intro p hp hq
  have hb := (Finset.mem_filter.mp hp).2
  have ht := (Finset.mem_filter.mp hq).2
  unfold PrimeLifespan.ghostBorn at hb
  unfold PrimeLifespan.beforeGhost at ht
  omega

/-- Exactly the survivors of the old pending set followed by fresh births. -/
theorem ghost_recurrence (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    after S L j = (before S L j \ deaths S L j) ∪ births S L j := by
  classical
  ext p
  simp only [after,before,deaths,births,Finset.mem_filter,Finset.mem_union,Finset.mem_sdiff]
  rw [(L p).afterGhost_iff]
  tauto

theorem promotions_subset_after (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    promotions S L j ⊆ after S L j := by
  intro p hp
  obtain ⟨hp,hj⟩ := Finset.mem_filter.mp hp
  exact Finset.mem_filter.mpr ⟨hp,(L p).promoted_was_pending hj⟩

theorem stores_disjoint_after (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    Disjoint (stores S L j) (after S L j) := by
  rw [Finset.disjoint_left]
  intro p hp hq
  have hs := (Finset.mem_filter.mp hp).2
  have ha := (Finset.mem_filter.mp hq).2
  exact ha.2.2 hs.1

theorem stores_disjoint_promotions (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    Disjoint (stores S L j) (promotions S L j) :=
  (stores_disjoint_after S L j).mono_right (promotions_subset_after S L j)

/-- Promotions remove old particles; storing the departing active prime
happens afterwards, and hence cannot promote that new particle. -/
theorem edge_recurrence (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    before S L (j+1) = (after S L j \ promotions S L j) ∪ stores S L j := by
  classical
  ext p
  simp only [after,before,promotions,stores,Finset.mem_filter,Finset.mem_union,Finset.mem_sdiff]
  rw [(L p).beforeGhost_succ_iff]
  tauto

@[simp] theorem before_zero (S : Finset P) (L : P → PrimeLifespan N) :
    before S L 0 = ∅ := by
  ext p
  simp [before,PrimeLifespan.beforeGhost_zero]

@[simp] theorem after_final (S : Finset P) (L : P → PrimeLifespan N) :
    after S L N = ∅ := by
  ext p
  simp [after,PrimeLifespan.afterGhost_final]

/-- Active and ghost births partition the one birth address of each prime. -/
theorem birth_partition (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    births S L j ∪ activeBirths S L j = S.filter (fun p => (L p).birth=j) := by
  classical
  ext p
  simp only [births,activeBirths,Finset.mem_union,Finset.mem_filter,
    PrimeLifespan.ghostBorn,PrimeLifespan.freshActive]
  constructor
  · rintro (⟨hp,hj,hn⟩ | ⟨hp,hj,ha⟩) <;> exact ⟨hp,hj.symm⟩
  · rintro ⟨hp,hj⟩
    by_cases ha : j ∈ (L p).active
    · exact Or.inr ⟨hp,hj.symm,ha⟩
    · exact Or.inl ⟨hp,hj.symm,ha⟩

theorem births_disjoint_activeBirths (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    Disjoint (births S L j) (activeBirths S L j) := by
  rw [Finset.disjoint_left]
  intro p hp hq
  exact (Finset.mem_filter.mp hp).2.2 (Finset.mem_filter.mp hq).2.2

/-- No numerical prime is born at two distinct visits. -/
theorem birth_visits_disjoint (S : Finset P) (L : P → PrimeLifespan N)
    {j k : ℕ} (hjk : j≠k) :
    Disjoint (births S L j ∪ activeBirths S L j)
      (births S L k ∪ activeBirths S L k) := by
  classical
  rw [birth_partition,birth_partition,Finset.disjoint_left]
  intro p hp hq
  exact hjk ((Finset.mem_filter.mp hp).2.symm.trans (Finset.mem_filter.mp hq).2)

/-- A scheduled particle retains its chosen line, including across gaps
between active runs. -/
def bag {Line : P → Type*} (ℓ : ∀ p, Line p) (A : Finset P) :
    Multiset (AnchoredParticle P Line) := A.val.map (anchorPrime ℓ)

theorem bag_union {Line : P → Type*} (ℓ : ∀ p, Line p)
    (A T : Finset P) (h : Disjoint A T) :
    bag ℓ (A∪T) = bag ℓ A + bag ℓ T := by
  classical
  unfold bag
  rw [Finset.union_val, ← Multiset.add_eq_union_iff_disjoint.mpr (Finset.disjoint_val.mpr h),
    Multiset.map_add]

theorem ghost_bag_recurrence {Line : P → Type*} (ℓ : ∀ p, Line p)
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    bag ℓ (after S L j) =
      bag ℓ (before S L j \ deaths S L j) + bag ℓ (births S L j) := by
  classical
  rw [ghost_recurrence,bag_union]
  exact (births_disjoint_before S L j).symm.mono_left Finset.sdiff_subset

theorem edge_bag_recurrence {Line : P → Type*} (ℓ : ∀ p, Line p)
    (S : Finset P) (L : P → PrimeLifespan N) (j : ℕ) :
    bag ℓ (before S L (j+1)) =
      bag ℓ (after S L j \ promotions S L j) + bag ℓ (stores S L j) := by
  classical
  rw [edge_recurrence,bag_union]
  exact (stores_disjoint_after S L j).symm.mono_left Finset.sdiff_subset

end LifespanSchedule
end Elliptic.Operator
