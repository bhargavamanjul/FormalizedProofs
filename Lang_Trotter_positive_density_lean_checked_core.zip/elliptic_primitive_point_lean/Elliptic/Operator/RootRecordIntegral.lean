module

public import Elliptic.Operator.RootRecordEncoding

/-!
# Exact separation of the archimedean and residue factors

The integral supplied by root replacement retains the actual signed
geometric product. Its residue average factors exactly, so the already
proved CRT kernel-line averaging theorem can be applied without a new
independence hypothesis.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordIntegral
open MeasureTheory RootArchimedeanTransfer RootGridMeasure RootRecordKernel OriginalPathWeights
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

theorem average_recordKernel (S : ℕ) [Fintype (ZMod S)]
    (rec : Record K J N R Q) (adjoint : Fin N→Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) (q : RootPhysicalCell.RootPoint) :
    averageKernel S (recordKernel S rec adjoint value μ U V d₀ Y L exponents η ψ major σ ρ) q =
      recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ q *
        ((∑g,ρ g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ)) := by
  unfold averageKernel recordKernel
  rw [←Finset.mul_sum,mul_div_assoc]

theorem rootIntegral_recordKernel (S : ℕ) [Fintype (ZMod S)]
    (rec : Record K J N R Q) (adjoint : Fin N→Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ)
    (ρ : Matrix.SpecialLinearGroup (Fin 2) (ZMod S)→ℂ) :
    rootIntegral U V S (recordKernel S rec adjoint value μ U V d₀ Y L exponents η ψ major σ ρ) =
      ((U*V/(Real.pi^2/6):ℝ):ℂ) *
        (∫q in rootBox, recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ q) *
        ((∑g,ρ g)/(Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod S)):ℂ)) := by
  unfold rootIntegral
  simp only [average_recordKernel]
  rw [integral_mul_const,mul_assoc]

/-- The residue term is the exact joint average over the literal
Option(ZMod p) memory-line coordinates, even for a coupled signed test. -/
theorem rootIntegral_recordKernel_crt {ι : Type} [Fintype ι] [DecidableEq ι]
    (p : ι→ℕ) [∀i,Fact (p i).Prime]
    (hp : Pairwise (fun i j=>(p i).Coprime (p j))) [Fintype (ZMod (∏i,p i))]
    (rec : Record K J N R Q) (adjoint : Fin N→Bool) (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ)
    (U V d₀ Y L : ℝ) (exponents : Fin K→ℝ) (η ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (f : (∀i,Option (ZMod (p i)))→ℂ) :
    rootIntegral U V (∏i,p i) (recordKernel (∏i,p i) rec adjoint value μ U V d₀ Y L
      exponents η ψ major σ (fun g=>f (fun i=>RootResidues.projectiveLineEquivOption (ZMod (p i))
        (RootResidues.kernelLine (ZMod (p i)) (RootResidues.sl2CRT p hp g i))))) =
      ((U*V/(Real.pi^2/6):ℝ):ℂ) *
        (∫q in rootBox,recordGeometry rec adjoint value μ U V d₀ Y L exponents η ψ major σ q) *
        ((∑ℓ : (∀i,Option (ZMod (p i))),f ℓ)/((∏i,(p i+1)):ℕ)) := by
  rw [rootIntegral_recordKernel,RootResidues.crt_kernel_option_average p hp f]

end Elliptic.Operator.RootRecordIntegral
