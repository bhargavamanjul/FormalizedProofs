module

public import Elliptic.Operator.DirtyOmissionAverage
public import Elliptic.Operator.DistinctBirthBatches
public import Elliptic.Operator.SourceMemoryEdges

/-!
# Exact endpoint permutation fibers for distinct active lists

The target permutation of a distinct prescribed output list is unique.
Once the source omission is prescribed, the remaining source orderings
have cardinality `J!` in each group. Both assertions concern the literal
ordered lists used by the physical edge definition.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance endpointPermutationDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

/-- A tuple bag remembers precisely the values occurring in the tuple. -/
theorem mem_tupleBag_iff {α P : Type*} [Fintype α] (x : α → P) (p : P) :
    p ∈ tupleBag x ↔ ∃ j, x j = p := by
  simp [tupleBag_eq_map]

/-- Distinct ordered tuples are precisely those with a duplicate-free bag. -/
theorem tupleBag_nodup_iff {α P : Type*} [Fintype α] (x : α → P) :
    (tupleBag x).Nodup ↔ Function.Injective x := by
  rw [tupleBag_eq_map, Multiset.nodup_map_iff_inj_on Finset.univ.nodup]
  simp [Function.Injective]

/-- Two distinct tuples with the same bag have one and only one actual
slot permutation taking the first tuple to the second. -/
theorem existsUnique_target_permutation {α P : Type*} [Fintype α]
    (x y : α → P) (hx : Function.Injective x) (hy : Function.Injective y)
    (hbag : tupleBag x = tupleBag y) :
    ∃! τ : Equiv.Perm α, ∀ j, x (τ j) = y j := by
  have hex (j : α) : ∃ k, x k = y j := by
    apply (mem_tupleBag_iff x (y j)).mp
    rw [hbag]
    exact (mem_tupleBag_iff y (y j)).mpr ⟨j,rfl⟩
  choose f hf using hex
  have hinj : Function.Injective f := by
    intro a b hab
    exact hy ((hf a).symm.trans ((congrArg x hab).trans (hf b)))
  let τ := Equiv.ofBijective f ⟨hinj, Finite.injective_iff_surjective.mp hinj⟩
  refine ⟨τ,hf,?_⟩
  intro σ hσ
  apply Equiv.ext
  intro j
  exact hx ((hσ j).trans (hf j).symm)

/-- A fixed last-slot omission leaves exactly the permutations of the
retained source slots. This is an explicit fiber equivalence. -/
def sourceOmissionFiberEquiv (J : ℕ) (o : Fin (J+1)) :
    {σ : Equiv.Perm (Fin (J+1)) // σ (Fin.last J) = o} ≃
      Equiv.Perm (Fin J) where
  toFun σ := (lastSlotPermutationEquiv J σ.val).2
  invFun π := ⟨(lastSlotPermutationEquiv J).symm (o,π), by
    rw [← lastSlotPermutationEquiv_fst]
    simp⟩
  left_inv σ := by
    apply Subtype.ext
    apply (lastSlotPermutationEquiv J).injective
    simp only [Equiv.apply_symm_apply]
    apply Prod.ext
    · exact σ.property.symm.trans (lastSlotPermutationEquiv_fst J σ.val).symm
    · rfl
  right_inv π := by simp

theorem source_omission_fiber_card (J : ℕ) (o : Fin (J+1)) :
    Fintype.card {σ : Equiv.Perm (Fin (J+1)) // σ (Fin.last J) = o} =
      J.factorial := by
  rw [Fintype.card_congr (sourceOmissionFiberEquiv J o)]
  rw [Fintype.card_perm, Fintype.card_fin]

/-- Replacement before the final endpoint permutation: all retained slots
keep their source ordering and the new target prime occupies the last slot. -/
def endpointReplacement {P : Type*} {J : ℕ} (x : Fin (J+1) → P)
    (σ : Equiv.Perm (Fin (J+1))) (b : P) : Fin (J+1) → P :=
  Fin.lastCases b (fun j : Fin J => x (σ j.castSucc))

/-- Replacement removes precisely the actual omitted prime and inserts
precisely the target prime, independently of the retained-slot ordering. -/
theorem endpointReplacement_bag_balance {P : Type*} {J : ℕ}
    (x : Fin (J+1) → P) (σ : Equiv.Perm (Fin (J+1))) (b : P) :
    tupleBag (endpointReplacement x σ b) + {x (σ (Fin.last J))} =
      tupleBag x + {b} := by
  have hs : tupleBag (fun j => x (σ j)) = tupleBag x :=
    Equiv.sum_comp σ (fun j => ({x j} : Multiset P))
  have hparts : tupleBag (fun j => x (σ j)) =
      (∑ j : Fin J, ({x (σ j.castSucc)} : Multiset P)) +
        {x (σ (Fin.last J))} := Fin.sum_univ_castSucc _
  rw [← hs, hparts]
  unfold tupleBag endpointReplacement
  rw [Fin.sum_univ_castSucc]
  simp only [Fin.lastCases_castSucc, Fin.lastCases_last]
  ac_rfl

/-- The balance equation for the prescribed output proves bag equality
for every source ordering with the prescribed omission. -/
theorem endpointReplacement_bag {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hbalance : tupleBag y + {x o} = tupleBag x + {b})
    (σ : Equiv.Perm (Fin (J+1))) (hσ : σ (Fin.last J) = o) :
    tupleBag (endpointReplacement x σ b) = tupleBag y := by
  apply add_right_cancel (b := ({x o} : Multiset P))
  rw [← hσ, endpointReplacement_bag_balance, hσ, hbalance]

/-- Distinctness of the desired list and the replacement balance force
unique target permutation for each source permutation in the omission fiber. -/
theorem endpointReplacement_unique_target {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b})
    (σ : Equiv.Perm (Fin (J+1))) (hσ : σ (Fin.last J) = o) :
    ∃! τ : Equiv.Perm (Fin (J+1)),
      ∀ j, endpointReplacement x σ b (τ j) = y j := by
  have hb := endpointReplacement_bag x y b o hbalance σ hσ
  have hx : Function.Injective (endpointReplacement x σ b) := by
    rw [← tupleBag_nodup_iff, hb, tupleBag_nodup_iff]
    exact hy
  exact existsUnique_target_permutation _ y hx hy hb

/-- The unique target slot permutation, constructed from the actual tuple
balance, rather than supplied as part of a multiplicity hypothesis. -/
def endpointTargetPermutation {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b})
    (σ : Equiv.Perm (Fin (J+1))) (hσ : σ (Fin.last J) = o) :
    Equiv.Perm (Fin (J+1)) :=
  Classical.choose (endpointReplacement_unique_target x y b o hy hbalance σ hσ)

theorem endpointTargetPermutation_spec {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b})
    (σ : Equiv.Perm (Fin (J+1))) (hσ : σ (Fin.last J) = o) (j : Fin (J+1)) :
    endpointReplacement x σ b
      (endpointTargetPermutation x y b o hy hbalance σ hσ j) = y j :=
  (Classical.choose_spec
    (endpointReplacement_unique_target x y b o hy hbalance σ hσ)).1 j

/-- Both endpoint permutations producing the prescribed distinct active
list, with its prescribed omitted source slot. -/
abbrev EndpointPermutationFiber {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1)) :=
  {c : Equiv.Perm (Fin (J+1)) × Equiv.Perm (Fin (J+1)) //
    c.1 (Fin.last J) = o ∧ ∀ j, endpointReplacement x c.1 b (c.2 j) = y j}

/-- The exact simultaneous source/target fiber is the retained source-slot
permutation group. The target order is forced for every source order. -/
def endpointPermutationFiberEquiv {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b}) :
    EndpointPermutationFiber x y b o ≃ Equiv.Perm (Fin J) :=
  (show EndpointPermutationFiber x y b o ≃
      {σ : Equiv.Perm (Fin (J+1)) // σ (Fin.last J) = o} from
    { toFun := fun c => ⟨c.val.1,c.property.1⟩
      invFun := fun σ => ⟨(σ.val,endpointTargetPermutation x y b o hy hbalance σ.val σ.property),
        σ.property,endpointTargetPermutation_spec x y b o hy hbalance σ.val σ.property⟩
      left_inv := by
        intro c
        apply Subtype.ext
        apply Prod.ext
        · rfl
        · exact ((Classical.choose_spec
          (endpointReplacement_unique_target x y b o hy hbalance c.val.1 c.property.1)).2
            c.val.2 c.property.2).symm
      right_inv := by intro σ; rfl }).trans (sourceOmissionFiberEquiv J o)

theorem endpoint_permutation_fiber_card {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b}) :
    Fintype.card (EndpointPermutationFiber x y b o) = J.factorial := by
  rw [Fintype.card_congr (endpointPermutationFiberEquiv x y b o hy hbalance),
    Fintype.card_perm, Fintype.card_fin]

/-- The literal pair of all groupwise endpoint permutations, restricted
only by their actual omitted source slots and actual ordered outputs. -/
abbrev GroupEndpointPermutationFiber {I : Type*} {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1)) :=
  {c : (I → Equiv.Perm (Fin (J+1))) × (I → Equiv.Perm (Fin (J+1))) //
    ∀ i, c.1 i (Fin.last J) = o i ∧
      ∀ j, endpointReplacement (x i) (c.1 i) (b i) (c.2 i j) = y i j}

/-- The independent groupwise fibers are exactly the physical two-endpoint
fiber; no compatibility condition is discarded. -/
def groupEndpointPermutationFiberEquiv {I : Type*} {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i}) :
    GroupEndpointPermutationFiber x y b o ≃ (I → Equiv.Perm (Fin J)) :=
  (show GroupEndpointPermutationFiber x y b o ≃
      (∀ i, EndpointPermutationFiber (x i) (y i) (b i) (o i)) from
    { toFun := fun c i => ⟨(c.val.1 i,c.val.2 i),c.property i⟩
      invFun := fun d => ⟨(fun i => (d i).val.1,fun i => (d i).val.2),
        fun i => (d i).property⟩
      left_inv := by intro c; rfl
      right_inv := by intro d; rfl }).trans
    (Equiv.piCongrRight (fun i =>
      endpointPermutationFiberEquiv (x i) (y i) (b i) (o i) (hy i) (hbalance i)))

theorem group_endpoint_permutation_fiber_card {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i}) :
    Fintype.card (GroupEndpointPermutationFiber x y b o) =
      J.factorial ^ Fintype.card I := by
  rw [Fintype.card_congr (groupEndpointPermutationFiberEquiv x y b o hy hbalance),
    Fintype.card_fun, Fintype.card_perm, Fintype.card_fin]

/-- Exact counting in the two unrestricted physical permutation sums.
The output target is a fixed ordered list, so its permutation multiplicity
is one, not `(J+1)!`. -/
theorem group_endpoint_permutation_sum {I R : Type*} [Fintype I] [Semiring R]
    {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i})
    (r : R) :
    (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ τ : I → Equiv.Perm (Fin (J+1)),
      if ∀ i, σ i (Fin.last J) = o i ∧
        ∀ j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j then r else 0) =
      (J.factorial ^ Fintype.card I : ℕ) * r := by
  rw [← Fintype.sum_prod_type (fun c : (I → Equiv.Perm (Fin (J+1))) ×
      (I → Equiv.Perm (Fin (J+1))) =>
    if ∀ i, c.1 i (Fin.last J) = o i ∧
      ∀ j, endpointReplacement (x i) (c.1 i) (b i) (c.2 i j) = y i j then r else 0)]
  rw [← Finset.sum_filter]
  rw [Finset.sum_subtype (p := fun c => ∀ i, c.1 i (Fin.last J) = o i ∧
      ∀ j, endpointReplacement (x i) (c.1 i) (b i) (c.2 i j) = y i j)
    _ (fun _ => by simp) (fun _ => r)]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  rw [group_endpoint_permutation_fiber_card x y b o hy hbalance]

/-- Exact remaining coefficient after the actual two uniform endpoint
weights and both finite permutation sums have been applied. -/
theorem normalized_group_endpoint_permutation_sum {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i})
    (r : ℂ) :
    (endpointPermutationWeight I J : ℂ) *
      (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ τ : I → Equiv.Perm (Fin (J+1)),
        if ∀ i, σ i (Fin.last J) = o i ∧
          ∀ j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j then r else 0) =
      ((J.factorial : ℂ) ^ Fintype.card I /
        (((J+1).factorial : ℂ) ^ Fintype.card I)^2) * r := by
  rw [group_endpoint_permutation_sum x y b o hy hbalance]
  simp only [endpointPermutationWeight, Fintype.card_fun, Fintype.card_perm,
    Fintype.card_fin, Nat.cast_pow, Complex.ofReal_pow, Complex.ofReal_inv,
    Complex.ofReal_natCast, div_eq_mul_inv, inv_pow]
  ring

/-- For a fixed source ordering in the omission fiber, summing over the
actual target permutations evaluates an arbitrary target-dependent term
at the uniquely determined matching permutation. -/
theorem target_permutation_sum {P R : Type*} {J : ℕ} [AddCommMonoid R]
    (x y : Fin (J+1) → P) (b : P) (o : Fin (J+1))
    (hy : Function.Injective y)
    (hbalance : tupleBag y + {x o} = tupleBag x + {b})
    (σ : Equiv.Perm (Fin (J+1))) (hσ : σ (Fin.last J) = o)
    (f : Equiv.Perm (Fin (J+1)) → R) :
    (∑ τ : Equiv.Perm (Fin (J+1)),
      if ∀ j, endpointReplacement x σ b (τ j) = y j then f τ else 0) =
      f (endpointTargetPermutation x y b o hy hbalance σ hσ) := by
  have he (τ : Equiv.Perm (Fin (J+1))) :
      (∀ j, endpointReplacement x σ b (τ j) = y j) ↔
        τ = endpointTargetPermutation x y b o hy hbalance σ hσ := by
    constructor
    · exact (Classical.choose_spec
        (endpointReplacement_unique_target x y b o hy hbalance σ hσ)).2 τ
    · intro h
      subst τ
      exact endpointTargetPermutation_spec x y b o hy hbalance σ hσ
  simp_rw [he]
  exact Fintype.sum_ite_eq' _ _

/-- With the source ordering fixed, the groupwise target fiber is still a
singleton, and its unique target permutation evaluates any continuation. -/
theorem group_target_permutation_sum {I R : Type*} [Fintype I] [AddCommMonoid R]
    {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i})
    (σ : I → Equiv.Perm (Fin (J+1))) (hσ : ∀ i, σ i (Fin.last J) = o i)
    (f : (I → Equiv.Perm (Fin (J+1))) → R) :
    (∑ τ : I → Equiv.Perm (Fin (J+1)),
      if ∀ i j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j then f τ else 0) =
      f (fun i => endpointTargetPermutation (x i) (y i) (b i) (o i)
        (hy i) (hbalance i) (σ i) (hσ i)) := by
  let τ₀ := fun i => endpointTargetPermutation (x i) (y i) (b i) (o i)
    (hy i) (hbalance i) (σ i) (hσ i)
  have he (τ : I → Equiv.Perm (Fin (J+1))) :
      (∀ i j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j) ↔ τ = τ₀ := by
    constructor
    · intro h
      funext i
      exact (Classical.choose_spec (endpointReplacement_unique_target
        (x i) (y i) (b i) (o i) (hy i) (hbalance i) (σ i) (hσ i))).2 (τ i) (h i)
    · intro h
      subst τ
      intro i
      exact endpointTargetPermutation_spec (x i) (y i) (b i) (o i)
        (hy i) (hbalance i) (σ i) (hσ i)
  simp_rw [he]
  exact Fintype.sum_ite_eq' _ _

/-- Target-order elimination preserves arbitrary dependence on the retained
source ordering. In particular, it may be applied before proving any
shared-slot symmetry of an actual geometric coefficient. -/
theorem weighted_group_endpoint_permutation_sum {I R : Type*}
    [Fintype I] [AddCommMonoid R] {P : I → Type*} {J : ℕ}
    (x y : ∀ i, Fin (J+1) → P i) (b : ∀ i, P i) (o : I → Fin (J+1))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {x i (o i)} = tupleBag (x i) + {b i})
    (f : (I → Equiv.Perm (Fin (J+1))) → R) :
    (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ τ : I → Equiv.Perm (Fin (J+1)),
      if ∀ i, σ i (Fin.last J) = o i ∧
        ∀ j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j then f σ else 0) =
      ∑ σ : I → Equiv.Perm (Fin (J+1)),
        if ∀ i, σ i (Fin.last J) = o i then f σ else 0 := by
  apply Finset.sum_congr rfl
  intro σ _
  by_cases hσ : ∀ i, σ i (Fin.last J) = o i
  · simp only [hσ, true_and, implies_true, ite_true]
    exact group_target_permutation_sum x y b o hy hbalance σ hσ (fun _ => f σ)
  · have he (τ : I → Equiv.Perm (Fin (J+1))) :
        ¬ ∀ i, σ i (Fin.last J) = o i ∧
          ∀ j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j := by
      intro h
      exact hσ (fun i => (h i).1)
    simp only [he, hσ, ite_false, Finset.sum_const_zero]

/-- Fix the nonpermutation choices and vary the two literal physical
endpoint permutations. -/
def physicalEndpointChoice {I Z : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (g : ∀ i, EdgeGroupChoice (s.memory P Line J B i))
    (σ τ : I → Equiv.Perm (Fin (J+1))) : PhysicalEdgeChoice s :=
  (z,(σ,(g,τ)))

/-- The abstract replacement tuple used for the fiber count is exactly
the pre-symmetrization target list of the actual physical edge. -/
theorem physicalEdge_targetLists_eq_endpointReplacement
    {I Z : Type*} [Fintype I] {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s) (i : I) :
    c.targetLists i = endpointReplacement (s.active P Line J B i) (c.sourcePerm i)
      (edgeTargetPrime (s.memory P Line J B i) (c.group i)) := rfl

/-- Physical validity is independent of both endpoint slot permutations. -/
theorem physicalEndpointChoice_valid {I Z : Type*} [Fintype I]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (g : ∀ i, EdgeGroupChoice (s.memory P Line J B i))
    (anchor : Z → ∀ i p, Line i p)
    (hg : ∀ i, EdgeGroupChoice.Valid (anchor z i) (s.memory P Line J B i) (g i))
    (hcut : (∑ i, edgeGroupOutputSize (g i)) ≤ B)
    (σ τ : I → Equiv.Perm (Fin (J+1))) :
    PhysicalEdgeChoice.Valid anchor s (physicalEndpointChoice s z g σ τ) :=
  ⟨hg,hcut⟩

/-- For fixed nonpermutation choices, the actual physical output condition
has exactly the counted endpoint fiber. This is a counting identity only:
a coefficient depending on retained source order cannot be replaced by a
constant without a separate invariance proof. -/
theorem physical_endpoint_output_fiber_sum {I Z R : Type*} [Fintype I] [Semiring R]
    {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (g : ∀ i, EdgeGroupChoice (s.memory P Line J B i))
    (anchor : Z → ∀ i p, Line i p)
    (hg : ∀ i, EdgeGroupChoice.Valid (anchor z i) (s.memory P Line J B i) (g i))
    (hcut : (∑ i, edgeGroupOutputSize (g i)) ≤ B)
    (y : ∀ i, Fin (J+1) → P i) (o : I → Fin (J+1))
    (hx : ∀ i, Function.Injective (s.active P Line J B i))
    (hy : ∀ i, Function.Injective (y i))
    (hbalance : ∀ i, tupleBag (y i) + {s.active P Line J B i (o i)} =
      tupleBag (s.active P Line J B i) + {edgeTargetPrime (s.memory P Line J B i) (g i)})
    (r : R) :
    (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ τ : I → Equiv.Perm (Fin (J+1)),
      if ∀ i,
        (physicalEndpointChoice s z g σ τ).sourcePrime i = s.active P Line J B i (o i) ∧
        ∀ j, ((physicalEndpointChoice s z g σ τ).output anchor s
          (physicalEndpointChoice_valid s z g anchor hg hcut σ τ)).active P Line J B i j = y i j
      then r else 0) = (J.factorial ^ Fintype.card I : ℕ) * r := by
  change (∑ σ : I → Equiv.Perm (Fin (J+1)), ∑ τ : I → Equiv.Perm (Fin (J+1)),
    if ∀ i, s.active P Line J B i (σ i (Fin.last J)) = s.active P Line J B i (o i) ∧
      ∀ j, endpointReplacement (s.active P Line J B i) (σ i)
        (edgeTargetPrime (s.memory P Line J B i) (g i)) (τ i j) = y i j then r else 0) = _
  simp_rw [(hx _).eq_iff]
  exact group_endpoint_permutation_sum (s.active P Line J B) y
    (fun i => edgeTargetPrime (s.memory P Line J B i) (g i)) o hy hbalance r

/-- Changing only the target permutation leaves the actual signed edge
choice coefficient unchanged; its geometry uses pre-permutation lists.
This does not assert source shared-slot symmetry of that geometry. -/
theorem physicalEdgeChoiceWeight_targetPerm_invariant
    {I Z : Type*} [Fintype I] {P : I → Type*} {Line : ∀ i, P i → Type*} {J B : ℕ}
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (g : ∀ i, EdgeGroupChoice (s.memory P Line J B i))
    (anchor : Z → ∀ i p, Line i p)
    (hg : ∀ i, EdgeGroupChoice.Valid (anchor z i) (s.memory P Line J B i) (g i))
    (hcut : (∑ i, edgeGroupOutputSize (g i)) ≤ B)
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (σ τ τ' : I → Equiv.Perm (Fin (J+1))) :
    physicalEdgeChoiceWeight ν V ρ anchor geometry s (physicalEndpointChoice s z g σ τ)
      (physicalEndpointChoice_valid s z g anchor hg hcut σ τ) =
    physicalEdgeChoiceWeight ν V ρ anchor geometry s (physicalEndpointChoice s z g σ τ')
      (physicalEndpointChoice_valid s z g anchor hg hcut σ τ') := rfl

/-- The actual cross-edge ban excludes the departing prime from every
target active slot, including the newly inserted prime. -/
theorem crossEdgeBan_source_last_not_target {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (a b : PhysicalActiveLists P J) (h : sourceCrossEdgeBan value a b)
    (i : I) (j : Fin (J+1)) : a i (Fin.last J) ≠ b i j := by
  intro he
  have hv := congrArg (value i) he
  induction j using Fin.lastCases with
  | last =>
    have heq : (i,Sum.inr false) = (i,Sum.inr true) := h.2
      (show sourceCrossEdgeLabels value a b (i,Sum.inr false) =
        sourceCrossEdgeLabels value a b (i,Sum.inr true) from hv)
    cases heq
  | cast j =>
    rw [h.1 i j] at hv
    have heq : (i,Sum.inr false) = (i,Sum.inl j) := h.2
      (show sourceCrossEdgeLabels value a b (i,Sum.inr false) =
        sourceCrossEdgeLabels value a b (i,Sum.inl j) from hv)
    cases heq

/-- An active source slot absent from a prescribed target list must be
the omitted slot of every physical endpoint representation of that list. -/
theorem endpoint_omission_of_absent_source {P : Type*} {J : ℕ}
    (x y : Fin (J+1) → P) (b : P)
    (σ τ : Equiv.Perm (Fin (J+1)))
    (hmatch : ∀ j, endpointReplacement x σ b (τ j) = y j)
    (o : Fin (J+1)) (habsent : ∀ j, x o ≠ y j) :
    σ (Fin.last J) = o := by
  by_contra hne
  have hnot : σ.symm o ≠ Fin.last J := by
    intro he
    apply hne
    rw [← he, Equiv.apply_symm_apply]
  obtain ⟨k,hk⟩ := Fin.eq_castSucc_of_ne_last hnot
  have hslot : σ k.castSucc = o := by rw [hk, Equiv.apply_symm_apply]
  have htarget := hmatch (τ.symm k.castSucc)
  rw [Equiv.apply_symm_apply] at htarget
  simp only [endpointReplacement, Fin.lastCases_castSucc, hslot] at htarget
  exact habsent _ htarget

/-- The cross-edge ban makes the omitted source slot intrinsic to the
prescribed ordered endpoints. Hence two allowed representations cannot
select different departures, even before fixing an omission in a sum. -/
theorem allowed_endpoint_omission_unique {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (x y : ∀ i, Fin (J+1) → P i) (b b' : ∀ i, P i)
    (σ τ σ' τ' : I → Equiv.Perm (Fin (J+1)))
    (hcross : sourceCrossEdgeBan value (fun i j => x i (σ i j))
      (fun i => endpointReplacement (x i) (σ i) (b i)))
    (hmatch : ∀ i j, endpointReplacement (x i) (σ i) (b i) (τ i j) = y i j)
    (hmatch' : ∀ i j, endpointReplacement (x i) (σ' i) (b' i) (τ' i j) = y i j)
    (i : I) : σ i (Fin.last J) = σ' i (Fin.last J) := by
  symm
  apply endpoint_omission_of_absent_source (x i) (y i) (b' i) (σ' i) (τ' i) (hmatch' i)
  intro j he
  apply crossEdgeBan_source_last_not_target value _ _ hcross i (τ i j)
  exact he.trans (hmatch i j).symm

/-- Reorder the retained slots in each group while fixing its final slot. -/
def permuteSharedSlots {I : Type*} {P : I → Type*} {J : ℕ}
    (π : I → Equiv.Perm (Fin J)) (a : PhysicalActiveLists P J) :
    PhysicalActiveLists P J := fun i =>
  Fin.lastCases (a i (Fin.last J)) (fun j : Fin J => a i (π i j).castSucc)

/-- The full unordered list is unchanged by a shared-slot permutation. -/
theorem permuteSharedSlots_tupleBag {I : Type*} {P : I → Type*} {J : ℕ}
    (π : I → Equiv.Perm (Fin J)) (a : PhysicalActiveLists P J) (i : I) :
    tupleBag (permuteSharedSlots π a i) = tupleBag (a i) := by
  unfold tupleBag
  rw [Fin.sum_univ_castSucc, Fin.sum_univ_castSucc]
  simp only [permuteSharedSlots, Fin.lastCases_castSucc, Fin.lastCases_last]
  rw [Equiv.sum_comp (π i) (fun j => ({a i j.castSucc} : Multiset (P i)))]

/-- The actual pad product is independent of the retained-slot ordering. -/
theorem sourcePadProduct_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (π : I → Equiv.Perm (Fin J)) (a : PhysicalActiveLists P J) :
    sourcePadProduct value (permuteSharedSlots π a) = sourcePadProduct value a := by
  unfold sourcePadProduct
  apply Finset.prod_congr rfl
  intro i _
  simp only [permuteSharedSlots, Fin.lastCases_castSucc]
  exact Equiv.prod_comp (π i) (fun j => value i (a i j.castSucc))

/-- The unshared labels stay in the final slots. -/
theorem sourceUnsharedProduct_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (π : I → Equiv.Perm (Fin J)) (a : PhysicalActiveLists P J) :
    sourceUnsharedProduct value (permuteSharedSlots π a) = sourceUnsharedProduct value a := by
  simp [sourceUnsharedProduct, permuteSharedSlots]

/-- Relabel the shared-prime addresses and fix both unshared addresses. -/
def sharedCrossLabelEquiv {I : Type*} {J : ℕ} (π : I → Equiv.Perm (Fin J)) :
    Equiv.Perm (I × (Fin J ⊕ Bool)) where
  toFun x := (x.1, Sum.map (π x.1) id x.2)
  invFun x := (x.1, Sum.map (π x.1).symm id x.2)
  left_inv := by rintro ⟨i,j|b⟩ <;> simp
  right_inv := by rintro ⟨i,j|b⟩ <;> simp

/-- The actual numerical cross-edge label map changes only by a bijection
of its addresses. This preserves every cross-group distinctness condition. -/
theorem sourceCrossEdgeLabels_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (π : I → Equiv.Perm (Fin J)) (a b : PhysicalActiveLists P J) :
    sourceCrossEdgeLabels value (permuteSharedSlots π a) (permuteSharedSlots π b) =
      sourceCrossEdgeLabels value a b ∘ sharedCrossLabelEquiv π := by
  funext x
  rcases x with ⟨i,j|t⟩
  · simp [sourceCrossEdgeLabels, permuteSharedSlots, sharedCrossLabelEquiv]
  · cases t <;> simp [sourceCrossEdgeLabels, permuteSharedSlots, sharedCrossLabelEquiv]

/-- The copied-slot relation and the full numerical cross-edge ban are
both invariant under the same retained-slot permutation at both endpoints. -/
theorem sourceCrossEdgeBan_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (π : I → Equiv.Perm (Fin J)) (a b : PhysicalActiveLists P J) :
    sourceCrossEdgeBan value (permuteSharedSlots π a) (permuteSharedSlots π b) ↔
      sourceCrossEdgeBan value a b := by
  unfold sourceCrossEdgeBan
  rw [sourceCrossEdgeLabels_permuteSharedSlots,
    (sharedCrossLabelEquiv π).injective_comp]
  simp only [permuteSharedSlots, Fin.lastCases_castSucc]
  constructor
  · rintro ⟨hc,hd⟩
    refine ⟨?_,hd⟩
    intro i j
    simpa using hc i ((π i).symm j)
  · rintro ⟨hc,hd⟩
    exact ⟨fun i j => hc i (π i j),hd⟩

/-- Isolate exactly the required endpoint-goodness premise. All physical
boxes, pad conditions, and cross-edge support restrictions are proved
invariant. This theorem does not supply symmetry of an arbitrary `good`. -/
theorem sourcePhysicalEdgeAllowed_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (π : I → Equiv.Perm (Fin J)) (a b : PhysicalActiveLists P J)
    (u v r U W d₀ : ℝ) (z w : ℤ × ℤ)
    (hgoodz : good z (permuteSharedSlots π a) ↔ good z a)
    (hgoodw : good w (permuteSharedSlots π b) ↔ good w b) :
    sourcePhysicalEdgeAllowed value good u v r U W d₀ z (permuteSharedSlots π a)
      w (permuteSharedSlots π b) ↔
    sourcePhysicalEdgeAllowed value good u v r U W d₀ z a w b := by
  simp only [sourcePhysicalEdgeAllowed, hgoodz, hgoodw,
    sourceCrossEdgeBan_permuteSharedSlots, sourcePadProduct_permuteSharedSlots]

/-- Exact retained-slot invariance of the source's signed geometric
multiplier, for every shift sign, conditional only on the two raw goodness
symmetries. No operator norm or moment estimate is a hypothesis. -/
theorem sourcePhysicalEdgeGeometry_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (π : I → Equiv.Perm (Fin J)) (a b : PhysicalActiveLists P J)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ)
    (hgoodz : good z (permuteSharedSlots π a) ↔ good z a)
    (hgoodw : good w (permuteSharedSlots π b) ↔ good w b) :
    sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ
      z (permuteSharedSlots π a) w (permuteSharedSlots π b) =
    sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ major σ z a w b := by
  simp only [sourcePhysicalEdgeGeometry,
    sourcePhysicalEdgeAllowed_permuteSharedSlots value good π a b
      u v r U W d₀ z w hgoodz hgoodw,
    sourcePadProduct_permuteSharedSlots, sourceUnsharedProduct_permuteSharedSlots]

/-- The same exact symmetry holds for both physical orientations. -/
theorem orientedSourceEdgeGeometry_permuteSharedSlots {I : Type*} [Fintype I]
    {P : I → Type*} {J : ℕ} (adjoint : Bool) (value : ∀ i, P i → ℕ)
    (good : (ℤ × ℤ) → PhysicalActiveLists P J → Prop)
    (π : I → Equiv.Perm (Fin J)) (a b : PhysicalActiveLists P J)
    (u v r U W d₀ Y : ℝ) (η ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (z w : ℤ × ℤ)
    (hgoodz : good z (permuteSharedSlots π a) ↔ good z a)
    (hgoodw : good w (permuteSharedSlots π b) ↔ good w b) :
    orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ major σ
      z (permuteSharedSlots π a) w (permuteSharedSlots π b) =
    orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ major σ z a w b := by
  cases adjoint <;> simp only [orientedSourceEdgeGeometry, Bool.false_eq_true,
    ite_false, ite_true]
  · exact sourcePhysicalEdgeGeometry_permuteSharedSlots value good π a b
      u v r U W d₀ Y η ψ major σ z w hgoodz hgoodw
  · rw [sourcePhysicalEdgeGeometry_permuteSharedSlots value good π b a
      u v r U W d₀ Y η ψ major σ w z hgoodw hgoodz]

end Elliptic.Operator
