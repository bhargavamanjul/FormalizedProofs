module
public import Elliptic.Operator.SignedLabelCollisions
public import Elliptic.Operator.SignedPhysicalPairSquare
public import Elliptic.Operator.SignedPhysicalCofactorScale
public import Elliptic.Operator.SignedCollisionAsymptotics
public import Elliptic.Operator.SignedSourceDyads

/-! Deletion of collisions in the actual selected-record square. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.SignedPhysicalCollisionSaving
open scoped BigOperators ComplexConjugate
open Filter Artin Artin.MarkedSource SignedCauchyExpansion SignedDyadicCauchy
open SignedPhysicalPairBridge SignedLabelCollisions SignedPhysicalAbsoluteRaw
attribute [local instance 10000] Classical.propDecidable
local instance collisionDecEq {X : Type*} : DecidableEq X := Classical.typeDecidableEq X
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {K : ℕ}

def collisionTerm (b : Bands K) (x Y : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) : ℂ :=
  ∑r∈dyadicRecords b x Y S T η,∑u∈dyadicRecords b x Y S T η,
    if ¬(labelProduct b x r.2.2).Coprime (labelProduct b x u.2.2) then
      recordRaw b x Y S T η α β r u else 0

def collisionRecords (b : Bands K) (x Y : ℝ) (S T : Finset ℕ) (η : ℝ→ℂ) :=
  (dyadicRecords b x Y S T η×ˢdyadicRecords b x Y S T η).filter
    (fun ru=>¬(labelProduct b x ru.1.2.2).Coprime (labelProduct b x ru.2.2.2) ∧
      scalarDet (labelProduct b x ru.1.2.2) (labelProduct b x ru.2.2.2)
        ru.1.1.val ru.1.2.1.val ru.2.1.val ru.2.2.1.val=
          (labelProduct b x ru.1.2.2:ℤ)-labelProduct b x ru.2.2.2)

def activeCollisionPairs (b : Bands K) (x Y : ℝ) :=
  (collisionPairs b x Y).filter
    (fun ab=>Y≤(labelProduct b x ab.1:ℝ) ∧ Y≤(labelProduct b x ab.2:ℝ))

def commonSolutions (S T : Finset ℕ) (a b H : ℕ) :=
  ((S×ˢT)×ˢ(S×ˢT)).filter (fun mnrs=>∃h∈Finset.Icc 1 H,
    mnrs.1.1*mnrs.1.2+1=a*h ∧ mnrs.2.1*mnrs.2.2+1=b*h)

theorem commonSolutions_card (S T : Finset ℕ) (a b H : ℕ) :
    ((commonSolutions S T a b H).card:ℝ)=
      ∑m∈S,∑n∈T,∑r∈S,∑q∈T,
        if ∃h∈Finset.Icc 1 H,m*n+1=a*h ∧ r*q+1=b*h then (1:ℝ) else 0 := by
  simp only [commonSolutions,Finset.card_eq_sum_ones,Finset.sum_filter,
    Finset.sum_product,Nat.cast_sum,Nat.cast_ite,Nat.cast_one,Nat.cast_zero]

theorem selected_common_cofactor (b : Bands K) (x Y X : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (hY : 0<Y)
    (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hprod : ∀m∈S,∀n∈T,(m*n+1:ℕ)≤X)
    (r u : Record b x S T) (hr : r∈dyadicRecords b x Y S T η)
    (hu : u∈dyadicRecords b x Y S T η)
    (hd : scalarDet (labelProduct b x r.2.2) (labelProduct b x u.2.2)
      r.1.val r.2.1.val u.1.val u.2.1.val=(labelProduct b x r.2.2:ℤ)-labelProduct b x u.2.2) :
    ∃h∈Finset.Icc 1 ⌊X/Y⌋₊,
      r.1.val*r.2.1.val+1=labelProduct b x r.2.2*h ∧
      u.1.val*u.2.1.val+1=labelProduct b x u.2.2*h := by
  have hrParts : r∈records b x S T ∧ η ((labelProduct b x r.2.2:ℝ)/Y)≠0 := by
    simpa only [dyadicRecords,Finset.mem_filter] using hr
  have huParts : u∈records b x S T ∧ η ((labelProduct b x u.2.2:ℝ)/Y)≠0 := by
    simpa only [dyadicRecords,Finset.mem_filter] using hu
  have hr' := hrParts.1
  have hu' := huParts.1
  have heq := (SignedDeterminantReduction.actual_record_cofactor_iff b x S T hdis r u hr' hu').mpr hd
  have hrd := labelProduct_dvd b x r.2.2 hdis _
    (show Divides b x r.2.2 (r.1.val*r.2.1.val+1) by
      simpa only [records,Finset.mem_filter,Finset.mem_univ,true_and] using hr')
  have hud := labelProduct_dvd b x u.2.2 hdis _
    (show Divides b x u.2.2 (u.1.val*u.2.1.val+1) by
      simpa only [records,Finset.mem_filter,Finset.mem_univ,true_and] using hu')
  have hrp := labelProduct_pos b x r.2.2
  have hco : 0<cofactor b x S T r := Nat.div_pos (Nat.le_of_dvd (Nat.succ_pos _) hrd) hrp
  have hre : r.1.val*r.2.1.val+1=labelProduct b x r.2.2*cofactor b x S T r :=
    (Nat.mul_div_cancel' hrd).symm
  have hue : u.1.val*u.2.1.val+1=labelProduct b x u.2.2*cofactor b x S T r := by
    rw [heq]
    exact (Nat.mul_div_cancel' hud).symm
  refine ⟨cofactor b x S T r,Finset.mem_Icc.mpr ⟨hco,?_⟩,hre,hue⟩
  apply Nat.le_floor
  apply (le_div_iff₀ hY).mpr
  have hlo : Y≤(labelProduct b x r.2.2:ℝ) :=
    by simpa only [one_mul] using (le_div_iff₀ hY).mp (hη _ hrParts.2).1
  have hpr := hprod r.1.val r.1.property r.2.1.val r.2.1.property
  have hh : (r.1.val:ℝ)*r.2.1.val+1=(labelProduct b x r.2.2:ℝ)*cofactor b x S T r := by
    exact_mod_cast hre
  push_cast at hpr
  nlinarith [mul_le_mul_of_nonneg_right hlo (Nat.cast_nonneg (cofactor b x S T r): (0:ℝ)≤_)]

theorem collisionRecords_card_le (b : Bands K) (x Y X : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (hY : 0<Y) (hη : ∀t,η t≠0→1≤t ∧ t≤4)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hprod : ∀m∈S,∀n∈T,(m*n+1:ℕ)≤X) :
    (collisionRecords b x Y S T η).card≤
      ∑ab∈activeCollisionPairs b x Y,
        (commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊X/Y⌋₊).card := by
  let target := (activeCollisionPairs b x Y).biUnion (fun ab=>
    (commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊X/Y⌋₊).image (fun r=>(ab,r)))
  let encode := fun ru : Record b x S T×Record b x S T=>
    ((ru.1.2.2,ru.2.2.2),((ru.1.1.val,ru.1.2.1.val),(ru.2.1.val,ru.2.2.1.val)))
  have hmap : ∀ru∈collisionRecords b x Y S T η,encode ru∈target := by
    intro ru hru
    obtain ⟨hru,hcop,hd⟩ := Finset.mem_filter.mp hru
    obtain ⟨hr,hu⟩ := Finset.mem_product.mp hru
    have hrη : η ((labelProduct b x ru.1.2.2:ℝ)/Y)≠0 := by
      have hh : ru.1∈records b x S T ∧ η ((labelProduct b x ru.1.2.2:ℝ)/Y)≠0 := by
        simpa only [dyadicRecords,Finset.mem_filter] using hr
      exact hh.2
    have huη : η ((labelProduct b x ru.2.2.2:ℝ)/Y)≠0 := by
      have hh : ru.2∈records b x S T ∧ η ((labelProduct b x ru.2.2.2:ℝ)/Y)≠0 := by
        simpa only [dyadicRecords,Finset.mem_filter] using hu
      exact hh.2
    have hbr := hη _ hrη
    have hbu := hη _ huη
    have hrl : Y≤(labelProduct b x ru.1.2.2:ℝ) := by simpa only [one_mul] using (le_div_iff₀ hY).mp hbr.1
    have hru : (labelProduct b x ru.1.2.2:ℝ)≤4*Y := (div_le_iff₀ hY).mp hbr.2
    have hul : Y≤(labelProduct b x ru.2.2.2:ℝ) := by simpa only [one_mul] using (le_div_iff₀ hY).mp hbu.1
    have huu : (labelProduct b x ru.2.2.2:ℝ)≤4*Y := (div_le_iff₀ hY).mp hbu.2
    apply Finset.mem_biUnion.mpr
    refine ⟨(ru.1.2.2,ru.2.2.2),?_,?_⟩
    · simp only [activeCollisionPairs,collisionPairs,labelsUpTo,Finset.mem_filter,
        Finset.mem_product,Finset.mem_univ,true_and]
      exact ⟨⟨⟨hru,huu⟩,hcop⟩,hrl,hul⟩
    · apply Finset.mem_image.mpr
      refine ⟨((ru.1.1.val,ru.1.2.1.val),(ru.2.1.val,ru.2.2.1.val)),?_,rfl⟩
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_product.mpr ⟨Finset.mem_product.mpr ⟨ru.1.1.property,ru.1.2.1.property⟩,
        Finset.mem_product.mpr ⟨ru.2.1.property,ru.2.2.1.property⟩⟩,?_⟩
      exact selected_common_cofactor b x Y X S T η hY hη hdis hprod ru.1 ru.2 hr hu hd
  have hinj : Function.Injective encode := by
    intro ru tv he
    apply Prod.ext
    · apply Prod.ext
      · exact Subtype.ext (congrArg (fun p=>p.2.1.1) he)
      · apply Prod.ext
        · exact Subtype.ext (congrArg (fun p=>p.2.1.2) he)
        · exact congrArg (fun p=>p.1.1) he
    · apply Prod.ext
      · exact Subtype.ext (congrArg (fun p=>p.2.2.1) he)
      · apply Prod.ext
        · exact Subtype.ext (congrArg (fun p=>p.2.2.2) he)
        · exact congrArg (fun p=>p.1.2) he
  exact (Finset.card_le_card_of_injOn encode hmap hinj.injOn).trans
    (Finset.card_biUnion_le.trans (Finset.sum_le_sum (fun ab _=>Finset.card_image_le)))

theorem collisionTerm_eq_sum (b : Bands K) (x Y : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) :
    collisionTerm b x Y S T η α β=
      ∑ru∈collisionRecords b x Y S T η,
        undampedCoefficient b x Y S T η α β ru.1*
          conj (undampedCoefficient b x Y S T η α β ru.2) := by
  unfold collisionTerm collisionRecords
  rw [Finset.sum_filter,Finset.sum_product]
  apply Finset.sum_congr rfl
  intro r hr
  apply Finset.sum_congr rfl
  intro u hu
  unfold recordRaw
  split_ifs <;> simp_all

theorem collisionTerm_norm_le_card (b : Bands K) (x Y : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (M Aη A B : ℝ)
    (hM : 0≤M) (hAη : 0≤Aη) (hA : 0≤A) (hB : 0≤B)
    (hmass : ‖(massNormalization b x:ℂ)‖≤M) (hη : ∀t,‖η t‖≤Aη)
    (hα : ∀m∈S,‖α m‖≤A) (hβ : ∀n∈T,‖β n‖≤B) :
    ‖collisionTerm b x Y S T η α β‖≤
      (M*Aη*A*B)^2*((collisionRecords b x Y S T η).card:ℝ) := by
  have hc (r : Record b x S T) : ‖undampedCoefficient b x Y S T η α β r‖≤M*Aη*A*B := by
    simp only [undampedCoefficient,norm_mul]
    exact mul_le_mul (mul_le_mul (mul_le_mul hmass (hη _) (norm_nonneg _) hM)
      (hα r.1.val r.1.property) (norm_nonneg _) (mul_nonneg hM hAη))
      (hβ r.2.1.val r.2.1.property) (norm_nonneg _) (by positivity)
  rw [collisionTerm_eq_sum]
  apply (norm_sum_le _ _).trans
  have hs := Finset.sum_le_card_nsmul (collisionRecords b x Y S T η)
    (fun ru=>‖undampedCoefficient b x Y S T η α β ru.1*
      conj (undampedCoefficient b x Y S T η α β ru.2)‖) ((M*Aη*A*B)^2) (by
    intro ru hru
    rw [norm_mul,Complex.norm_conj,pow_two]
    exact mul_le_mul (hc ru.1) (hc ru.2) (norm_nonneg _) (by positivity))
  simpa only [nsmul_eq_mul,mul_comm] using hs

theorem collisionTerm_norm_le_common (b : Bands K) (x Y X : ℝ) (S T : Finset ℕ)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (M Aη A B Q : ℝ)
    (hM : 0≤M) (hAη : 0≤Aη) (hA : 0≤A) (hB : 0≤B) (hQ : 0≤Q)
    (hmass : ‖(massNormalization b x:ℂ)‖≤M) (hη : ∀t,‖η t‖≤Aη)
    (hα : ∀m∈S,‖α m‖≤A) (hβ : ∀n∈T,‖β n‖≤B)
    (hY : 0<Y) (hsupp : ∀t,η t≠0→1≤t ∧ t≤4)
    (hdis : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)))
    (hprod : ∀m∈S,∀n∈T,(m*n+1:ℕ)≤X)
    (hcommon : ∀ab∈activeCollisionPairs b x Y,
      ((commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊X/Y⌋₊).card:ℝ)≤Q) :
    ‖collisionTerm b x Y S T η α β‖≤
      (M*Aη*A*B)^2*((collisionPairs b x Y).card:ℝ)*Q := by
  have hc : ((collisionRecords b x Y S T η).card:ℝ)≤
      ∑ab∈activeCollisionPairs b x Y,
        ((commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊X/Y⌋₊).card:ℝ) := by
    exact_mod_cast collisionRecords_card_le b x Y X S T η hY hsupp hdis hprod
  have hc' : ((collisionRecords b x Y S T η).card:ℝ)≤((collisionPairs b x Y).card:ℝ)*Q := by
    apply hc.trans
    apply (show (∑ab∈activeCollisionPairs b x Y,
        ((commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊X/Y⌋₊).card:ℝ))≤
        ((activeCollisionPairs b x Y).card:ℝ)*Q by
      simpa only [nsmul_eq_mul] using Finset.sum_le_card_nsmul _ _ Q hcommon).trans
    apply mul_le_mul_of_nonneg_right _ hQ
    exact_mod_cast Finset.card_filter_le (collisionPairs b x Y)
      (fun ab=>Y≤(labelProduct b x ab.1:ℝ) ∧ Y≤(labelProduct b x ab.2:ℝ))
  exact (collisionTerm_norm_le_card b x Y S T η α β M Aη A B hM hAη hA hB hmass hη hα hβ).trans
    ((mul_le_mul_of_nonneg_left hc' (sq_nonneg _)).trans_eq (by ring))

theorem massNormalization_norm_le (b : Bands K) (x : ℝ)
    (hV : ∀i,Real.log 2/2≤b.mass x i) :
    ‖(massNormalization b x:ℂ)‖≤((Real.log 2/2)⁻¹)^K := by
  have hv : 0<Real.log 2/2 := by positivity
  have hm : 0≤massNormalization b x :=
    Finset.prod_nonneg (fun i _=>inv_nonneg.mpr (hv.le.trans (hV i)))
  rw [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hm]
  calc
    _ ≤ ∏_i : Fin K,(Real.log 2/2)⁻¹ := by
      apply Finset.prod_le_prod₀ (fun i _=>inv_nonneg.mpr (hv.le.trans (hV i)))
      intro i hi
      simpa only [one_div] using one_div_le_one_div_of_le hv (hV i)
    _ = _ := by simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin]

attribute [local instance 1000] Classical.propDecidable

/-- The exact selected-record collision term is arbitrarily small.
The divisor progression bound, label reciprocal-square saving, and
normalization estimate are all discharged inside this theorem. -/
theorem eventually_collisionTerm_small (hbands : ClassicalBandMass)
    (b : Bands K) (C A : ℝ) :
    ∀ᶠ x : ℝ in atTop,∀(Y : ℝ),0<Y→∀(S T : Finset ℕ),
      (∀m∈S,0<m)→(∀m∈S,∀n∈T,0<m*n)→
      (∀m∈S,∀n∈T,(m*n+1:ℕ)≤x)→
      ∀(η : ℝ→ℂ),(∀t,‖η t‖≤1)→(∀t,η t≠0→1≤t ∧ t≤4)→
      ∀(α β : ℕ→ℂ),(∀m∈S,‖α m‖≤(Real.log x)^C)→
      (∀n∈T,‖β n‖≤(Real.log x)^C)→
      ‖collisionTerm b x Y S T η α β‖≤x*Y*(Real.log x)^(-A) := by
  let M := ((Real.log 2/2)⁻¹)^K
  let Cost := 512*M^2*(8*Real.log 4*K)
  have hM : 0≤M := by dsimp [M]; positivity
  have hCost : 0≤Cost := by dsimp [Cost]; positivity
  have hdis := MarkedBandTail.eventual_bands_disjoint Finset.univ b.exponent
    (fun i _ j _ h=>b.increasing.injective h)
  filter_upwards [hbands K b,hdis,eventually_common_cofactor_count (2*K) (by positivity),
    SignedCollisionAsymptotics.eventually_collision_log_loss Cost (4*C) A hCost,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),eventually_ge_atTop (1:ℝ)]
      with x hV hd hc hsmall hL hx
  intro Y hY S T hS hpos hprod η hη hsupp α β hα hβ
  have hLp : 0<Real.log x := by linarith
  have hd' : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)) := by
    intro i j hij
    simpa only [b.group_eq_markedBandTail x i,b.group_eq_markedBandTail x j]
      using hd i (Finset.mem_univ _) j (Finset.mem_univ _) hij
  let Q := 32*(x/Y)*(1+Real.log (8*x))^3
  have hQ : 0≤Q := by
    have hlog : 0≤Real.log (8*x) := Real.log_nonneg (by linarith)
    dsimp [Q]
    positivity
  have hcommon : ∀ab∈activeCollisionPairs b x Y,
      ((commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊x/Y⌋₊).card:ℝ)≤Q := by
    intro ab hab
    simp only [activeCollisionPairs,collisionPairs,labelsUpTo,Finset.mem_filter,
      Finset.mem_product,Finset.mem_univ,true_and] at hab
    obtain ⟨⟨hupper,hcop⟩,hlo⟩ := hab
    rw [commonSolutions_card]
    exact hc S T (labelProduct b x ab.1) (labelProduct b x ab.2) Y hS hpos hY
      hlo.1 hupper.1 hlo.2 hupper.2
      (SignedSourceDyads.labelProduct_upper b x hL ab.1)
      (SignedSourceDyads.labelProduct_upper b x hL ab.2)
  have hb := collisionTerm_norm_le_common b x Y x S T η α β M 1 ((Real.log x)^C) ((Real.log x)^C) Q
    hM (by norm_num) (by positivity) (by positivity) hQ (massNormalization_norm_le b x hV)
    hη hα hβ hY hsupp hd' hprod hcommon
  have hcard := collisionPairs_card_exp b x Y hY.le hd' hL
  have hpow : ((Real.log x)^C)^2*((Real.log x)^C)^2=(Real.log x)^(4*C) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_add hLp]
    congr 1
    norm_num only [Nat.cast_ofNat]
    ring
  calc
    _ ≤ (M*1*(Real.log x)^C*(Real.log x)^C)^2*
        (16*Y^2*(8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))))*Q := by
      apply hb.trans
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hcard (sq_nonneg _)) hQ
    _ = x*Y*(Cost*(Real.log x)^(4*C)*(1+Real.log (8*x))^3*
        Real.exp (-((Real.log x)^(1/10:ℝ)))) := by
      dsimp [Q,Cost]
      simp only [mul_one,mul_pow]
      rw [←hpow]
      field_simp [hY.ne']
      <;> ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hsmall (by positivity)

/-- The actual collision term at any fixed multiple of the source scale is arbitrarily small.
The divisor progression bound, label reciprocal-square saving, and
normalization estimate are all discharged inside this theorem. -/
theorem eventually_collisionTerm_small_scaled (hbands : ClassicalBandMass)
    (b : Bands K) (c C A : ℝ) :
    ∀ᶠ x : ℝ in atTop,∀(Y : ℝ),0<Y→∀(S T : Finset ℕ),
      (∀m∈S,0<m)→(∀m∈S,∀n∈T,0<m*n)→
      (∀m∈S,∀n∈T,(m*n+1:ℕ)≤c*x)→
      ∀(η : ℝ→ℂ),(∀t,‖η t‖≤1)→(∀t,η t≠0→1≤t ∧ t≤4)→
      ∀(α β : ℕ→ℂ),(∀m∈S,‖α m‖≤(Real.log x)^C)→
      (∀n∈T,‖β n‖≤(Real.log x)^C)→
      ‖collisionTerm b x Y S T η α β‖≤x*Y*(Real.log x)^(-A) := by
  let M := ((Real.log 2/2)⁻¹)^K
  let Cost := 16*cofactorScaleConstant c*M^2*(8*Real.log 4*K)
  have hM : 0≤M := by dsimp [M]; positivity
  have hScale := cofactorScaleConstant_nonneg c
  have hCost : 0≤Cost := by dsimp [Cost]; positivity
  have hdis := MarkedBandTail.eventual_bands_disjoint Finset.univ b.exponent
    (fun i _ j _ h=>b.increasing.injective h)
  filter_upwards [hbands K b,hdis,eventually_common_cofactor_count_scaled c (2*K) (by positivity),
    SignedCollisionAsymptotics.eventually_collision_log_loss Cost (4*C) A hCost,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1:ℝ)),eventually_ge_atTop (1:ℝ)]
      with x hV hd hc hsmall hL hx
  intro Y hY S T hS hpos hprod η hη hsupp α β hα hβ
  have hLp : 0<Real.log x := by linarith
  have hd' : Pairwise (fun i j=>Disjoint (b.group x i) (b.group x j)) := by
    intro i j hij
    simpa only [b.group_eq_markedBandTail x i,b.group_eq_markedBandTail x j]
      using hd i (Finset.mem_univ _) j (Finset.mem_univ _) hij
  let Q := cofactorScaleConstant c*(x/Y)*(1+Real.log (8*x))^3
  have hQ : 0≤Q := by
    have hlog : 0≤Real.log (8*x) := Real.log_nonneg (by linarith)
    dsimp [Q]
    positivity
  have hcommon : ∀ab∈activeCollisionPairs b x Y,
      ((commonSolutions S T (labelProduct b x ab.1) (labelProduct b x ab.2) ⌊(c*x)/Y⌋₊).card:ℝ)≤Q := by
    intro ab hab
    simp only [activeCollisionPairs,collisionPairs,labelsUpTo,Finset.mem_filter,
      Finset.mem_product,Finset.mem_univ,true_and] at hab
    obtain ⟨⟨hupper,hcop⟩,hlo⟩ := hab
    rw [commonSolutions_card]
    exact hc S T (labelProduct b x ab.1) (labelProduct b x ab.2) Y hS hpos hY
      hlo.1 hupper.1 hlo.2 hupper.2
      (SignedSourceDyads.labelProduct_upper b x hL ab.1)
      (SignedSourceDyads.labelProduct_upper b x hL ab.2)
  have hb := collisionTerm_norm_le_common b x Y (c*x) S T η α β M 1 ((Real.log x)^C) ((Real.log x)^C) Q
    hM (by norm_num) (by positivity) (by positivity) hQ (massNormalization_norm_le b x hV)
    hη hα hβ hY hsupp hd' hprod hcommon
  have hcard := collisionPairs_card_exp b x Y hY.le hd' hL
  have hpow : ((Real.log x)^C)^2*((Real.log x)^C)^2=(Real.log x)^(4*C) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_add hLp]
    congr 1
    norm_num only [Nat.cast_ofNat]
    ring
  calc
    _ ≤ (M*1*(Real.log x)^C*(Real.log x)^C)^2*
        (16*Y^2*(8*Real.log 4*K)*Real.exp (-((Real.log x)^(1/10:ℝ))))*Q := by
      apply hb.trans
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hcard (sq_nonneg _)) hQ
    _ = x*Y*(Cost*(Real.log x)^(4*C)*(1+Real.log (8*x))^3*
        Real.exp (-((Real.log x)^(1/10:ℝ)))) := by
      dsimp [Q,Cost]
      simp only [mul_one,mul_pow]
      rw [←hpow]
      field_simp [hY.ne']
      <;> ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hsmall (by positivity)

end Elliptic.Operator.SignedPhysicalCollisionSaving
