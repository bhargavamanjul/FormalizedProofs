module
public import Elliptic.Operator.PrimeExceptionalEnvelope
public import Elliptic.Operator.MajorArcPolynomialEnergy

/-! Sparse beta energy for the literal prime-polynomial exceptional set,
with its cardinality bound discharged by the growing prime moment. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcActualExceptionalEnergy
open Filter MeasureTheory Set
open scoped BigOperators
open ClassicalDerivativeTest PrimeExceptionalCells MajorArcPolynomialEnergy
set_option maxHeartbeats 500000

 theorem eventually_actual_exceptional_beta_energy (hvdC : FixedOrderDerivativeTest)
    (δ c C As : ℝ) (hδ : 0<δ) (hc : 0<c) (hC : 0≤C) (hAs : 0≤As) :
    ∃Cβ : ℝ,0<Cβ ∧ ∀ᶠ L : ℝ in atTop,∀K N : ℕ,1≤K→1≤N→
      (K:ℝ)≤Real.exp (3*L)→Real.exp (δ*L)≤N→
      ∀a P : ℝ,0<P→c*L^(1/10:ℝ)≤Real.log P→Real.log P≤C*L^(1/5:ℝ)→
      ∀S : Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q : ℕ) (χ : DirichletCharacter ℂ q) (ξ B : ℝ),0≤B→
      ∀b : ℕ→ℂ,(∀n∈Finset.range N,‖b n‖≤B)→
      (∫t in Ioc (a+1) (a+(K:ℝ)+1)∩{t:ℝ | L^(-As)<‖primePolynomial S P χ ξ t‖},
        ‖betaPolynomial N b t‖^2)≤Cβ*B^2*L := by
  obtain ⟨H,hH,hcount⟩ := PrimeExceptionalEnvelope.eventually_exceptionalCells_card
    3 c C As (by norm_num) hc hC hAs
  obtain ⟨Cβ,hCβ,henergy⟩ := eventually_exceptional_beta_energy hvdC δ H 3 hδ hH.le (by norm_num)
  refine ⟨Cβ,hCβ,?_⟩
  filter_upwards [hcount,henergy,eventually_ge_atTop (1:ℝ)] with L hcount henergy hL
  intro K N hK hN hKmax hNmin a P hP hlo hhi S hprime hShi q χ ξ B hB b hb
  have hlog : Real.log (K:ℝ)≤3*L := by
    have hh := Real.log_le_log (show (0:ℝ)<K by exact_mod_cast (by omega : 0<K)) hKmax
    simpa only [Real.log_exp] using hh
  have hdiam : (K:ℝ)+1≤Real.exp (4*L) := by
    have hk : (1:ℝ)≤K := by exact_mod_cast hK
    have h2 : 2≤Real.exp L := by linarith [Real.add_one_le_exp L]
    calc
      _ ≤ 2*(K:ℝ) := by linarith
      _ ≤ 2*Real.exp (3*L) := mul_le_mul_of_nonneg_left hKmax (by norm_num)
      _ ≤ Real.exp L*Real.exp (3*L) := mul_le_mul_of_nonneg_right h2 (Real.exp_pos _).le
      _ = Real.exp (4*L) := by rw [←Real.exp_add];congr 1;ring
  exact henergy K N hK hN hlog hdiam hNmin a (L^(-As)) (primePolynomial S P χ ξ)
    (hcount K a P hKmax hP hlo hhi S hprime hShi q χ ξ) B hB b hb

/-- Arbitrary logarithmic saving after the literal small/large-prime split.
The two remaining long-factor inputs are pointwise cancellation and its
actual product mean square; neither exceptional energy nor count is assumed. -/
 theorem eventually_small_prime_product_energy_of_long_bounds
    (hvdC : FixedOrderDerivativeTest) (δ c C Cprod Cbeta E : ℝ)
    (hδ : 0<δ) (hc : 0<c) (hC : 0≤C) (hprod : 0≤Cprod) (hbeta : 0≤Cbeta) (hE : 0≤E) :
    ∃As A : ℝ,0<As ∧ 0<A ∧ ∀ᶠ L : ℝ in atTop,∀K N : ℕ,1≤K→1≤N→
      (K:ℝ)≤Real.exp (3*L)→Real.exp (δ*L)≤N→
      ∀a P : ℝ,0<P→c*L^(1/10:ℝ)≤Real.log P→Real.log P≤C*L^(1/5:ℝ)→
      ∀S : Finset ℕ,(∀p∈S,p.Prime)→(∀p∈S,(p:ℝ)≤2*P)→
      ∀(q : ℕ) (χ : DirichletCharacter ℂ q) (ξ : ℝ),
      ∀b : ℕ→ℂ,(∀n∈Finset.range N,‖b n‖≤L^Cbeta)→
      ∀M : ℝ→ℂ,Continuous M→
      (∀t∈Icc (a+1) (a+(K:ℝ)+1),‖M t‖≤L^(-A))→
      (∫t in (a+1)..(a+(K:ℝ)+1),‖M t*betaPolynomial N b t‖^2)≤L^Cprod→
      (∫t in (a+1)..(a+(K:ℝ)+1),
        ‖primePolynomial S P χ ξ t*M t*betaPolynomial N b t‖^2)≤L^(-E) := by
  let As := (Cprod+E+1)/2
  let A := Cbeta+(E+2)/2
  have hAs : 0<As := by dsimp [As];linarith
  have hA : 0<A := by dsimp [A];linarith
  obtain ⟨Cβ,hCβ,henergy⟩ := eventually_actual_exceptional_beta_energy hvdC δ c C As hδ hc hC hAs.le
  refine ⟨As,A,hAs,hA,?_⟩
  filter_upwards [henergy,eventually_ge_atTop (1:ℝ),eventually_ge_atTop (1+9*Cβ)] with L henergy hL hLC
  intro K N hK hN hKmax hNmin a P hP hlo hhi S hprime hShi q χ ξ b hb M hM hMc hMs
  have hLp : 0<L := by linarith
  have hPone : 1≤P := ((Real.log_pos_iff hP.le).mp
    ((mul_pos hc (Real.rpow_pos_of_pos hLp _)).trans_le hlo)).le
  have hcard := PrimeExceptionalEnvelope.prime_card_le S P hPone hprime hShi
  have hprimeNorm : ∀t∈Icc (a+1) (a+(K:ℝ)+1),‖primePolynomial S P χ ξ t‖≤3 := by
    intro t ht
    apply (primePolynomial_norm_le S P hP χ ξ t).trans
    exact (div_le_iff₀ hP).mpr (by nlinarith only [hcard])
  have hlarge := henergy K N hK hN hKmax hNmin a P hP hlo hhi S hprime hShi q χ ξ
    (L^Cbeta) (Real.rpow_nonneg hLp.le _) b hb
  have hab : a+1≤a+(K:ℝ)+1 := by have := Nat.cast_nonneg (α:=ℝ) K;linarith
  have hsplit := MajorArcFrequencySplit.product_energy_split (primePolynomial S P χ ξ) M (betaPolynomial N b)
    (primePolynomial_continuous S P χ ξ) hM (betaPolynomial_continuous N b)
    (a+1) (a+(K:ℝ)+1) hab (L^(-As)) 3 (L^(-A))
    (Real.rpow_nonneg hLp.le _) (by norm_num) (Real.rpow_nonneg hLp.le _) hprimeNorm hMc
  have hs : (L^(-As))^2*L^Cprod=L^(-E-1) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_add hLp]
    congr 1
    dsimp [As]
    norm_num
    ring
  have hl : (3:ℝ)^2*(L^(-A))^2*(Cβ*(L^Cbeta)^2*L)=9*Cβ*L^(-E-1) := by
    rw [←Real.rpow_mul_natCast hLp.le,←Real.rpow_mul_natCast hLp.le]
    calc
      _ = 9*Cβ*((L^((-A)*(2:ℕ)))*L^(Cbeta*(2:ℕ))*L^(1:ℝ)) := by rw [Real.rpow_one];ring
      _ = _ := by
        rw [←Real.rpow_add hLp,←Real.rpow_add hLp]
        congr 2
        dsimp [A]
        norm_num
        ring
  calc
    _ ≤ (L^(-As))^2*L^Cprod+(3:ℝ)^2*(L^(-A))^2*(Cβ*(L^Cbeta)^2*L) :=
      hsplit.trans (add_le_add (mul_le_mul_of_nonneg_left hMs (sq_nonneg _))
        (mul_le_mul_of_nonneg_left hlarge (by positivity)))
    _ = (1+9*Cβ)*L^(-E-1) := by rw [hs,hl];ring
    _ ≤ L*L^(-E-1) := mul_le_mul_of_nonneg_right hLC (Real.rpow_nonneg hLp.le _)
    _ = L^(-E) := by
      conv_lhs => lhs;rw [←Real.rpow_one L]
      rw [←Real.rpow_add hLp]
      congr 1
      ring

end Elliptic.Operator.MajorArcActualExceptionalEnergy
