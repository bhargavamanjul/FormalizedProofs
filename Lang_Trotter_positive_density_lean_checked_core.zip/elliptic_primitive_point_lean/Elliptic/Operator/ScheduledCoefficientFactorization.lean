module

public import Elliptic.Operator.LifespanVisitCoefficients
public import Elliptic.Operator.GlobalBirthFibers

/-!
# The complete scheduled scalar coefficient factors prime by prime

The ghost count powers and both edge hit-count powers are the literal
coefficients from the scheduled physical step modules. Fresh mass factors
are separated from the transition coefficients and counted once per birth.
This proves the global finite scalar algebra; the equivalence with all
original physical histories and permutation fibers is separate.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.LifespanSchedule
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
variable {P R : Type*} {N : ℕ} [Field R]

/-- The ghost coefficient after its actual factorial birth fiber is summed,
but before multiplying the prime masses of that fresh batch. -/
def scheduledGhostFactor (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (η q : ℕ → R) (hit : P → ℕ → Prop) (j : ℕ) : R :=
  (-η j/ρ)^(deaths S L j).card *
    (q j/ρ^2)^((before S L j \ deaths S L j).filter (fun p => hit p j)).card *
    (-η j*V/ρ)^(births S L j).card

/-- The edge coefficient, with fresh target prime masses separated out.
The promotion set has at most one element for an actual one-slot group,
but the factorization below does not need to assume that cardinality. -/
def scheduledEdgeFactor (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (hit : P → ℕ → Prop) (j : ℕ) : R :=
  ρ^((after S L j).filter (fun p => hit p j)).card *
    (V⁻¹)^(promotions S L j).card *
    ρ^((before S L (j+1)).filter (fun p => hit p (j+1))).card

theorem filter_power_product (S : Finset P) (f : P → Prop) [DecidablePred f] (c : R) :
    c^(S.filter f).card = ∏ p ∈ S, if f p then c else 1 := by
  rw [← Finset.prod_filter]
  exact (Finset.prod_const c).symm

theorem surviving_hit_set (S : Finset P) (L : P → PrimeLifespan N)
    (hit : P → ℕ → Prop) (j : ℕ) :
    (before S L j \ deaths S L j).filter (fun p => hit p j) =
      S.filter (fun p => (L p).beforeGhost j ∧ ¬ (L p).ghostDies j ∧ hit p j) := by
  classical
  ext p
  simp only [before,deaths,Finset.mem_filter,Finset.mem_sdiff]
  tauto

/-- Literal cardinality powers are exactly the product of the per-prime
ghost factors; this is not an assumed coefficient matching hypothesis. -/
theorem scheduledGhostFactor_eq_product (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (η q : ℕ → R) (hit : P → ℕ → Prop) (j : ℕ) :
    scheduledGhostFactor S L ρ V η q hit j =
      ∏ p ∈ S, (L p).ghostVisitFactor ρ V η q (hit p) j := by
  classical
  unfold scheduledGhostFactor PrimeLifespan.ghostVisitFactor
  rw [surviving_hit_set]
  simp only [deaths,births,filter_power_product,Finset.prod_mul_distrib]

/-- The same exact primewise factorization for the actual edge count powers. -/
theorem scheduledEdgeFactor_eq_product (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (hit : P → ℕ → Prop) (j : ℕ) :
    scheduledEdgeFactor S L ρ V hit j =
      ∏ p ∈ S, (L p).outgoingFactor ρ (hit p) j *
        (if (L p).promoted j then V⁻¹ else 1) *
        (L p).incomingFactor ρ (hit p) (j+1) := by
  classical
  unfold scheduledEdgeFactor PrimeLifespan.outgoingFactor PrimeLifespan.incomingFactor
  simp only [after,before,promotions,Finset.filter_filter,filter_power_product,
    Finset.prod_mul_distrib]

/-- Repeated promotion factors count the actual promotions of one prime. -/
theorem promotion_factor_product (L : PrimeLifespan N) (V : R) :
    (∏ j ∈ Finset.range N, if L.promoted j then V⁻¹ else 1) =
      (V⁻¹)^L.promotionCount := by
  unfold PrimeLifespan.promotionCount
  rw [← Finset.prod_pow_eq_pow_sum]
  apply Finset.prod_congr rfl
  intro j hj
  by_cases h : L.promoted j <;> simp [h]

/-- Multiplying all edge and ghost count factors equals the complete
per-prime transition coefficient, including all promotion factors. -/
theorem transition_factors_primewise (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (η q : ℕ → R) (hit : P → ℕ → Prop) :
    (∏ j ∈ Finset.range N, scheduledEdgeFactor S L ρ V hit j) *
    (∏ j ∈ Finset.range (N+1), scheduledGhostFactor S L ρ V η q hit j) =
    ∏ p ∈ S, (V⁻¹)^(L p).promotionCount *
      ((∏ j ∈ Finset.range N,
        (L p).outgoingFactor ρ (hit p) j * (L p).incomingFactor ρ (hit p) (j+1)) *
       (∏ j ∈ Finset.range (N+1), (L p).ghostVisitFactor ρ V η q (hit p) j)) := by
  simp_rw [scheduledEdgeFactor_eq_product,scheduledGhostFactor_eq_product]
  rw [Finset.prod_comm (s := Finset.range N),
    Finset.prod_comm (s := Finset.range (N+1)), ← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro p hp
  simp only [Finset.prod_mul_distrib]
  rw [promotion_factor_product]
  ring

/-- The complete scheduled scalar product has one line-mass factor per
prime and exactly one inverse normalization per active run. Endpoint signs
and internal hit factors are retained. Initial active masses and later
active/ghost birth masses are counted separately, with NO active factorial. -/
theorem complete_scheduled_coefficient (S : Finset P) (L : P → PrimeLifespan N)
    (ρ V : R) (ν μ : P → R) (hρ : ρ ≠ 0) (hV : V ≠ 0)
    (hν : ∀ p ∈ S, V * ν p = μ p)
    (η q : ℕ → R) (hit : P → ℕ → Prop)
    (hend : ∀ p ∈ S, ∀ j ≤ N, (L p).ghostBorn j ∨ (L p).ghostDies j → hit p j) :
    (∏ j ∈ Finset.range (N+1),
      (∏ p ∈ births S L j, ν p) * (∏ p ∈ activeBirths S L j, ν p)) *
      ((∏ j ∈ Finset.range N, scheduledEdgeFactor S L ρ V hit j) *
       (∏ j ∈ Finset.range (N+1), scheduledGhostFactor S L ρ V η q hit j)) =
    ∏ p ∈ S, μ p * (V⁻¹)^(L p).activeRunCount *
      (∏ j ∈ Finset.range (N+1), (L p).lifespanVisitFactor 1 η q (hit p) j) := by
  rw [lifespan_split_birth_product,transition_factors_primewise,← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro p hp
  rw [← mul_assoc]
  exact (L p).full_lifespan_coefficient ρ V (ν p) (μ p) hρ hV (hν p hp) η q
    (hit p) (hend p hp)

end Elliptic.Operator.LifespanSchedule
