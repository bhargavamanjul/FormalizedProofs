module

public import Elliptic.Operator.OriginalLeafBoundaryAssembly
public import Elliptic.Operator.RestrictedHistoryTruncation

/-!
# The literal history peak and the finite lifespan cutoff

The memory maximum ranges over every state of the original chronological
word. It equals the cutoff condition on all before/after ghost visits.
For a compatible lifespan leaf, these sizes are the actual pending-set
cardinalities; hence the whole-history cutoff is exactly the leaf cutoff.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
open ScheduledPhysicalPath LifespanSchedule
attribute [local instance] Classical.propDecidable
local instance historyCutoffDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I→Type} [∀ i,Fintype (P i)]
variable {Line : ∀ i,P i→Type} {J B N : ℕ}
variable {anchor : Z→∀ i p,Line i p}

namespace ScheduledPhysicalPath
variable (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

/-- Every state of the chronological word occurs at one of these visits;
there are no unobserved intermediate states omitted from the cutoff. -/
theorem peak_le_iff_observed
    (size : PhysicalMemoryState (Z:=Z) P Line J B→ℕ) (T n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s) :
    h.peakSize size≤T ↔ ∀ k : Fin (n+1),
      size (beforeStateAt ν V η q ρ geometry n j s h k)≤T ∧
      size (afterStateAt ν V η q ρ geometry n j s h k)≤T := by
  induction n generalizing j s with
  | zero =>
    simp only [operations,ChoiceOperation.History.peakSize,beforeStateAt,afterStateAt,max_le_iff]
    exact ⟨fun hh _=>hh,fun hh=>hh 0⟩
  | succ n ih =>
    change max (size s) (max (size _) (h.2.2.peakSize size))≤T ↔ _
    rw [max_le_iff,max_le_iff,ih]
    constructor
    · rintro ⟨hs,hg,ht⟩ k
      exact Fin.cases ⟨hs,hg⟩ (fun t=>ht t) k
    · intro hh
      exact ⟨(hh 0).1,(hh 0).2,fun t=>hh t.succ⟩

variable (d : ScheduledPhysicalPath anchor N J B)

theorem before_memorySize (j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hs : d.Before j s) :
    physicalMemorySize s=∑ i,(before (d.primes i) (d.lifespan i) j).card := by
  unfold physicalMemorySize
  apply Finset.sum_congr rfl
  intro i _
  exact memoryEnumeratesSet_size _ _ _ (hs.2.2 i)

theorem after_memorySize (j : ℕ) (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hs : d.After j s) :
    physicalMemorySize s=∑ i,(after (d.primes i) (d.lifespan i) j).card := by
  unfold physicalMemorySize
  apply Finset.sum_congr rfl
  intro i _
  exact memoryEnumeratesSet_size _ _ _ (hs.2.2 i)

/-- Exact actual peak criterion for every compatible history, independent
of ghost birth ordering and independent of coefficient vanishing. -/
theorem compatible_peak_le_iff (T : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hs : d.Before 0 s)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hc : d.Compatible ν V η q ρ geometry N 0 s h) :
    h.peakSize physicalMemorySize≤T ↔
      ∀ j,j≤N→ (∑ i,(before (d.primes i) (d.lifespan i) j).card)≤T ∧
        (∑ i,(after (d.primes i) (d.lifespan i) j).card)≤T := by
  rw [peak_le_iff_observed ν V η q ρ geometry physicalMemorySize T N 0]
  have hsize (k : Fin (N+1)) := d.compatible_observed_states ν V η q ρ geometry
    N 0 (by omega) s hs h hc k
  simp only [Nat.zero_add] at hsize
  constructor
  · intro hh j hj
    let k : Fin (N+1) := ⟨j,Nat.lt_succ_of_le hj⟩
    have hv := hh k
    rw [d.before_memorySize k.val _ (hsize k).1,d.after_memorySize k.val _ (hsize k).2] at hv
    exact hv
  · intro hh k
    rw [d.before_memorySize k.val _ (hsize k).1,d.after_memorySize k.val _ (hsize k).2]
    exact hh k.val (Nat.le_of_lt_succ k.isLt)

end ScheduledPhysicalPath

namespace OriginalLifespanSchedule.OriginalLeaf
variable (e : OriginalLeaf (I:=I) (Z:=Z) (P:=P) (J:=J) (N:=N)) (he : e.Valid anchor B)
variable (ν : ∀ i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)

/-- The small-cap predicate on the original leaf is exactly the literal
peak restriction on every actual history in its complete compatible fiber. -/
theorem compatible_peak_le_iff_valid (T : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (hs : (e.toSchedule anchor he).Before 0 s)
    (h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s)
    (hc : (e.toSchedule anchor he).Compatible ν V η q ρ geometry N 0 s h) :
    h.peakSize physicalMemorySize≤T ↔ e.Valid anchor T := by
  rw [(e.toSchedule anchor he).compatible_peak_le_iff ν V η q ρ geometry T
    s hs h hc]
  change (∀ j,j≤N→
    (∑ i,(before (e.primes i) (e.lifespan anchor he i) j).card)≤T ∧
    (∑ i,(after (e.primes i) (e.lifespan anchor he i) j).card)≤T) ↔ _
  constructor
  · intro hh
    refine ⟨he.active_distinct,he.shared,he.unused,he.ordered,he.contains_active,
      he.singleton_active,he.incidence,?_,?_⟩
    · intro j hj
      simpa only [e.before_eq anchor he] using (hh j hj).1
    · intro j hj
      simpa only [e.after_eq anchor he] using (hh j hj).2
  · intro ht j hj
    constructor
    · simpa only [e.before_eq anchor he] using ht.before_cutoff j hj
    · simpa only [e.after_eq anchor he] using ht.after_cutoff j hj

end OriginalLifespanSchedule.OriginalLeaf
end Elliptic.Operator
