module

public import Elliptic.Operator.PhysicalLowRankWord
public import Elliptic.Operator.FiniteOperatorSum

/-! The exact normalized Fourier average preserves the proven physical
word norm bound; initial birth phases are contractions in the original
factorial measure. There is no phase-space cardinality loss. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFourierWordNorm
open scoped BigOperators
open ActualHistoryBirths PhysicalBirthFactors PhysicalPhasedWord PhysicalFourierWord BirthFourierLocalization PhysicalBagNorm
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

 theorem finiteL2_average_le {α X : Type*} [Fintype α] [DecidableEq α] [Fintype X]
    {Q : ℕ} [NeZero Q] (μ : X→ℝ) (hμ : ∀x,0≤μ x)
    (f : (α→ZMod Q)→X→ℂ) (T : ℝ) (hT : 0≤T)
    (hf : ∀θ,finiteL2 Finset.univ μ (f θ)≤T) :
    finiteL2 Finset.univ μ (fun x=>average (fun θ=>f θ x))≤T := by
  let n : ℝ := (Q:ℝ)^Fintype.card α
  have hn : 0<n := by dsimp [n];exact pow_pos (by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne Q)) _
  have hcard : (Fintype.card (α→ZMod Q):ℝ)=n := by simp [n,Fintype.card_fun]
  have hs := finiteL2_sum_le Finset.univ (Finset.univ : Finset (α→ZMod Q)) μ (fun x _=>hμ x)
    f (fun _=>T) 1 (by norm_num) (fun _ _=>hT) (fun θ _=>by simpa using hf θ)
  have hs' : finiteL2 Finset.univ μ (fun x=>∑θ,f θ x)≤n*T := by
    apply hs.trans_eq
    rw [mul_one,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,hcard]
    rw [show n*(n*T^2)=(n*T)^2 by ring,Real.sqrt_sq (mul_nonneg hn.le hT)]
  have hd := finiteL2_diagonal_le_mul Finset.univ μ (fun x _=>hμ x)
    (fun _ : X=>((Q:ℂ)^Fintype.card α)⁻¹) (fun x=>∑θ,f θ x) n⁻¹ (inv_nonneg.mpr hn.le)
    (fun _ _=>by simp [n])
  apply hd.trans
  calc
    _ ≤ n⁻¹*(n*T) := mul_le_mul_of_nonneg_left hs' (inv_nonneg.mpr hn.le)
    _ = T := by field_simp

 variable {I Z : Type} [Fintype I] [Fintype Z]
 variable {P : I→Type} [∀i,Fintype (P i)] {Line : ∀i,P i→Type} [∀i p,Fintype (Line i p)] {J B N Q : ℕ} [NeZero Q]
 variable (ν : ∀i,P i→ℝ) (V : I→ℝ) (η q : ℕ→ℝ) (ρ : ℝ)
 variable (anchor : Z→∀i p,Line i p)
 variable (geometry : ℕ→Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
 variable (value : ∀i,P i→ℕ)

 theorem birthPreserving_l2_le_of_word_bound (hν : ∀i p,0≤ν i p) (hvalue : ∀i p,value i p<Q)
    (σ : Equiv.Perm (Address I J B N))
    (F : PhysicalMemoryState (Z:=Z) P Line J B→ℂ) (T : ℝ) (hT : 0≤T)
    (hword : ∀θ : Address I J B N→ZMod Q,
      finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
        (word ν V η q ρ anchor geometry value (ghostPhase σ θ) (edgePhase σ θ) N 0 F)≤T) :
    finiteL2 Finset.univ (PhysicalMemoryState.mass P Line J B ν)
      (fun s=>∑h : ChoiceOperation.History (physicalMemoryOperations ν V η q ρ anchor geometry N) s,
        if BirthPreserving (labels ν V η q ρ anchor geometry value N s h) σ
          then h.weight*F h.final else 0)≤T := by
  have hμ (s : PhysicalMemoryState (Z:=Z) P Line J B) : 0≤PhysicalMemoryState.mass P Line J B ν s := by
    unfold PhysicalMemoryState.mass
    apply Finset.prod_nonneg
    intro i _
    apply mul_nonneg (Finset.prod_nonneg (fun k _=>hν i _))
    unfold MemoryState.mass anchoredParticleMass
    exact div_nonneg (Finset.prod_nonneg (fun k _=>hν i _)) (by positivity)
  simp_rw [birthPreserving_eq_average_word ν V η q ρ anchor geometry value hvalue σ]
  apply finiteL2_average_le _ hμ _ T hT
  intro θ
  have hd := finiteL2_diagonal_le_mul Finset.univ (PhysicalMemoryState.mass P Line J B ν)
    (fun s _=>hμ s) (initialFactor value (initialPhase σ θ))
    (word ν V η q ρ anchor geometry value (ghostPhase σ θ) (edgePhase σ θ) N 0 F)
    1 (by norm_num) (fun s _=>initialFactor_norm_le value σ θ s)
  exact hd.trans ((one_mul _).le.trans (hword θ))

end Elliptic.Operator.PhysicalFourierWordNorm
