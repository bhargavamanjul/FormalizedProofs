module

public import Elliptic.Operator.RootMonomialCRT

/-! # Exact original-record polynomial identification on both sides -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootPolynomialIdentity
open scoped BigOperators
open MeasureTheory RootRecordBonferroni RootRecordGap RootIntegratedBonferroni
open RootMonomialTests RootMonomialAverage RootMonomialCRT RootLiteralSum RootVariableSum
open RootArchimedeanTransfer RootGridMeasure OriginalPathWeights RootRecordComparison
open BonferroniMonomialCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

abbrev Pairs (records : Finset (Record K J N R Q)) (P : Finset ℕ) (T : ℕ) :=
  ↥records × ↥(truncatedSubsets P T)

def primeProof (records : Finset (Record K J N R Q)) (P : Finset ℕ) (T : ℕ)
    (hA : ∀r∈records,activePrimes r⊆P) (hP : ∀p∈P,p.Prime) (t : Pairs records P T) :
    ∀p∈support t.1.val t.2.val,p.Prime :=
  support_prime t.1.val t.2.val P (hA _ t.1.property)
    (mem_truncatedSubsets P T t.2.val |>.mp t.2.property).1 hP

theorem rootPolynomial_eq (records : Finset (Record K J N R Q)) (P : Finset ℕ) (T : ℕ)
    (hA : ∀r∈records,activePrimes r⊆P) (hP : ∀p∈P,p.Prime) (η : ℕ→ℝ)
    (U V : ℝ) (G : Record K J N R Q→RootGridMeasure.RootPoint→ℂ) :
    (∑t : Pairs records P T, variableRootSum U V (modulus t.1.val t.2.val)
      (RootGridPartition.fullInterval 1 16) (RootGridPartition.fullInterval 1 2)
      (RootGridPartition.fullInterval 0 1) (fun q g=>G t.1.val q *
        residueTest t.1.val t.2.val (primeProof records P T hA hP t)
          (subsetTest t.1.val η t.2.val) g)) =
      ∑r∈records,rootPolynomial r P η T U V (G r) FinitePrimeCRT.integerLines := by
  simp_rw [←literal_monomial]
  rw [Fintype.sum_prod_type]
  simp only [rootPolynomial]
  have hi (r : records) : (∑s : truncatedSubsets P T,
      literalRootSum U V (fun q g=>G r.val q*subsetTest r.val η s.val
        (fun p=>FinitePrimeCRT.integerLines g p)))=
      ∑s∈truncatedSubsets P T,literalRootSum U V (fun q g=>G r.val q*subsetTest r.val η s
        (fun p=>FinitePrimeCRT.integerLines g p)) := Finset.sum_coe_sort (truncatedSubsets P T) (fun s : Finset ℕ=>
        literalRootSum U V (fun q g=>G r.val q*subsetTest r.val η s
          (fun p=>FinitePrimeCRT.integerLines g p)))
  simp_rw [hi]
  exact Finset.sum_coe_sort records (fun r : Record K J N R Q=>
    rootPolynomial r P η T U V (G r) FinitePrimeCRT.integerLines)

theorem integralPolynomial_eq (records : Finset (Record K J N R Q)) (P : Finset ℕ) (T : ℕ)
    (hA : ∀r∈records,activePrimes r⊆P) (hP : ∀p∈P,p.Prime) (η : ℕ→ℝ)
    [∀p : P,Fact p.val.Prime]
    [∀t : Pairs records P T,Fintype (ZMod (modulus t.1.val t.2.val))]
    [∀t : Pairs records P T,∀p : support t.1.val t.2.val,Fact p.val.Prime]
    (U V : ℝ) (G : Record K J N R Q→RootGridMeasure.RootPoint→ℂ) :
    (∑t : Pairs records P T, rootIntegral U V (modulus t.1.val t.2.val)
      (fun q g=>G t.1.val q * residueTest t.1.val t.2.val (primeProof records P T hA hP t)
          (subsetTest t.1.val η t.2.val) g)) =
      ∑r∈records,integralPolynomial r P η T U V (G r) := by
  simp_rw [integral_monomial]
  rw [Fintype.sum_prod_type]
  rw [←Finset.sum_coe_sort records]
  apply Finset.sum_congr rfl
  intro r hr
  letI (s : truncatedSubsets P T) (p : ↥(activePrimes r.val∪s.val)) : Fact p.val.Prime :=
    ⟨support_prime r.val s.val P (hA _ r.property)
      (mem_truncatedSubsets P T s.val |>.mp s.property).1 hP p p.property⟩
  rw [integralPolynomial,truncatedAverage_subsets r.val P (hA _ r.property) η T,
    Finset.mul_sum]

/-- The positive root-gap expansion uses no geometric multiplier. -/
theorem rootGap_eq (records : Finset (Record K J N R Q)) (P : Finset ℕ) (k T : ℕ) (hk : k≤T)
    (hA : ∀r∈records,activePrimes r⊆P) (hP : ∀p∈P,p.Prime) (η : ℕ→ℝ) (U V : ℝ) :
    (∑t : Pairs records P T,SourceRootTransfer.weightedRootSum U V (modulus t.1.val t.2.val)
      (RootGridPartition.fullInterval 1 16) (RootGridPartition.fullInterval 1 2)
      (RootGridPartition.fullInterval 0 1)
      (residueTest t.1.val t.2.val (primeProof records P T hA hP t) (gapTest t.1.val η k t.2.val))) =
      ((∑r∈records,rootGap r P η k U V FinitePrimeCRT.integerLines):ℝ) := by
  simp_rw [←variableRootSum_constant]
  have he (t : Pairs records P T) := literal_monomial t.1.val t.2.val
    (primeProof records P T hA hP t) (gapTest t.1.val η k t.2.val) U V (fun _=>1)
  simp only [one_mul] at he
  simp_rw [←he]
  rw [Fintype.sum_prod_type]
  simp only [Complex.ofReal_sum]
  rw [←Finset.sum_coe_sort records]
  apply Finset.sum_congr rfl
  intro r hr
  rw [literalGap_sparse r.val P η k T hk]
  exact Finset.sum_coe_sort (truncatedSubsets P T) (fun s : Finset ℕ=>
    literalRootSum U V (fun _ g=>gapTest r.val η k s (fun p=>FinitePrimeCRT.integerLines g p)))

/-- Exact positive independent mean of the gap-polynomial replacement. -/
theorem integralGap_eq (records : Finset (Record K J N R Q)) (P : Finset ℕ) (k T : ℕ) (hk : k≤T)
    (hA : ∀r∈records,activePrimes r⊆P) (hP : ∀p∈P,p.Prime) (η : ℕ→ℝ)
    [∀p : P,Fact p.val.Prime]
    [∀t : Pairs records P T,Fintype (ZMod (modulus t.1.val t.2.val))]
    [∀t : Pairs records P T,∀p : support t.1.val t.2.val,Fact p.val.Prime]
    (U V : ℝ) :
    (∑t : Pairs records P T,
      (SourceRootTransfer.rootVolume U V (RootGridPartition.fullInterval 1 16)
        (RootGridPartition.fullInterval 1 2) (RootGridPartition.fullInterval 0 1):ℂ)*
      ((∑g,residueTest t.1.val t.2.val (primeProof records P T hA hP t) (gapTest t.1.val η k t.2.val) g)/
        (Fintype.card (Matrix.SpecialLinearGroup (Fin 2) (ZMod (modulus t.1.val t.2.val))):ℂ))) =
      ((15*(U*V/(Real.pi^2/6)))*(∑r∈records,gap r P η k):ℝ) := by
  simp_rw [residueTest_average]
  rw [Fintype.sum_prod_type]
  have hvol : SourceRootTransfer.rootVolume U V (RootGridPartition.fullInterval 1 16)
      (RootGridPartition.fullInterval 1 2) (RootGridPartition.fullInterval 0 1)=15*(U*V/(Real.pi^2/6)) := by
    norm_num [SourceRootTransfer.rootVolume,RootGridPartition.fullInterval,SourceRootCount.RootInterval.length]
    ring
  rw [hvol]
  simp only [←Finset.mul_sum]
  simp only [Complex.ofReal_mul,Complex.ofReal_sum]
  congr 1
  rw [←Finset.sum_coe_sort records]
  apply Finset.sum_congr rfl
  intro r hr
  letI (s : truncatedSubsets P T) (p : ↥(activePrimes r.val∪s.val)) : Fact p.val.Prime :=
    ⟨support_prime r.val s.val P (hA _ r.property)
      (mem_truncatedSubsets P T s.val |>.mp s.property).1 hP p p.property⟩
  exact (gap_average_subsets r.val P (hA _ r.property) η k T hk).symm

end Elliptic.Operator.RootPolynomialIdentity
