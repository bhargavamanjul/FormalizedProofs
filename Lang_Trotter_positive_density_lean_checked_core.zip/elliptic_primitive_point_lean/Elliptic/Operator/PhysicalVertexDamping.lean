module

public import Elliptic.Operator.PhysicalRootMomentNumeric
public import Elliptic.Operator.PhysicalRootedMomentMatrix

/-!
# Actual vertex damping in the physical power moment

An endpoint appears once and an interior vertex twice. Thus the literal
inactive-prime damping is q at the endpoints and 2q-q² in the interior.
Active divisibility indicators are idempotent. These statements retain
the original active lists and both independent endpoint permutations.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalVertexDamping
open scoped BigOperators ComplexConjugate
open OriginalLifespanSchedule PhysicalPathResidues PhysicalPathGeometry
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

def vertexFactor (value : ∀i,P i→ℕ) (q : ℝ) (p : ℕ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : ℝ :=
  if ∃i k,value i (a i k)=p then (if (p:ℤ)∣z.1 then 1 else 0)
  else 1-if (p:ℤ)∣z.1 then q else 0

def vertexWeight (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) : ℝ :=
  ∏p∈primes,vertexFactor value q p z a

def momentDamping (q : ℝ) (N j : ℕ) : ℝ :=
  if j=0 ∨ j=N then q else 2*q-q^2

theorem vertexFactor_sq (value : ∀i,P i→ℕ) (q : ℝ) (p : ℕ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) :
    (vertexFactor value q p z a)^2=vertexFactor value (2*q-q^2) p z a := by
  unfold vertexFactor
  split_ifs <;> ring

theorem vertexWeight_sq (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) :
    (vertexWeight value primes q z a)^2=vertexWeight value primes (2*q-q^2) z a := by
  simp only [vertexWeight,←Finset.prod_pow,vertexFactor_sq]

theorem vertexWeight_permute (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J)
    (π : ∀i : Fin K,Equiv.Perm (Fin (J+1))) :
    vertexWeight value primes q z (fun i k=>a i (π i k))=vertexWeight value primes q z a := by
  apply Finset.prod_congr rfl
  intro p hp
  have he : (∃i k,value i (a i (π i k))=p) ↔ ∃i k,value i (a i k)=p := by
    constructor
    · rintro ⟨i,k,h⟩; exact ⟨i,π i k,h⟩
    · rintro ⟨i,k,h⟩; exact ⟨i,(π i).symm k,by simpa using h⟩
  simp only [vertexFactor,he]

theorem vertexWeight_sourceLists (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (j : ℕ) :
    vertexWeight value primes q (r.positionAt j) (r.sourceLists j)=
      vertexWeight value primes q (r.positionAt j) (r.activeAt j) :=
  vertexWeight_permute value primes q _ _ (r.sourcePermAt j)

theorem vertexWeight_targetLists (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (j : ℕ) :
    vertexWeight value primes q (r.positionAt (j+1)) (r.targetLists j)=
      vertexWeight value primes q (r.positionAt (j+1)) (r.activeAt (j+1)) :=
  vertexWeight_permute value primes q _ _ (fun i=>(r.targetPermAt j i).symm)

theorem prod_edges (f : ℕ→ℝ) (n : ℕ) :
    (∏j∈Finset.range (n+1),f j*f (j+1))=
      f 0*f (n+1)*∏j∈Finset.range n,(f (j+1))^2 := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.prod_range_succ,ih,Finset.prod_range_succ]; ring

theorem physicalResidue_eq_vertex_product (value : ∀i,P i→ℕ) (primes : Finset ℕ)
    (η : ℕ→ℝ) (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) :
    physicalResidue value primes η r=
      ∏j∈Finset.range (N+1),vertexWeight value primes (η j) (r.positionAt j) (r.activeAt j) := by
  unfold physicalResidue vertexWeight
  rw [Finset.prod_comm]
  apply Finset.prod_congr rfl
  intro p hp
  unfold physicalFactor
  have hdiff : Finset.range (N+1)\numericActiveVisits value r p=
      (Finset.range (N+1)).filter (fun j=>¬∃i k,value i (r.activeAt j i k)=p) := by
    ext j
    simp only [Finset.mem_sdiff,numericActiveVisits,Finset.mem_filter]
    constructor
    · rintro ⟨hj,hn⟩
      exact ⟨hj,fun h=>hn ⟨hj,h⟩⟩
    · rintro ⟨hj,hn⟩
      exact ⟨hj,fun h=>hn h.2⟩
  rw [hdiff]
  unfold numericActiveVisits
  rw [←Finset.prod_ite (s:=Finset.range (N+1))
    (p:=fun j=>∃i k,value i (r.activeAt j i k)=p)]
  rfl

theorem vertex_product_eq_edges (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (hN : 0<N) :
    physicalResidue value primes (momentDamping q N) r=
      ∏j∈Finset.range N,
        vertexWeight value primes q (r.positionAt j) (r.sourceLists j)*
        vertexWeight value primes q (r.positionAt (j+1)) (r.targetLists j) := by
  rw [physicalResidue_eq_vertex_product]
  simp_rw [vertexWeight_sourceLists,vertexWeight_targetLists]
  obtain ⟨n,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hN)
  rw [prod_edges,Finset.prod_range_succ,Finset.prod_range_succ']
  simp only [momentDamping,eq_self_iff_true,true_or,ite_true,zero_add]
  have he : (∏j∈Finset.range n,
      vertexWeight value primes (if j+1=0 ∨ j+1=n+1 then q else 2*q-q^2)
        (r.positionAt (j+1)) (r.activeAt (j+1)))=
      ∏j∈Finset.range n,(vertexWeight value primes q (r.positionAt (j+1)) (r.activeAt (j+1)))^2 := by
    apply Finset.prod_congr rfl
    intro j hj
    have hn : ¬(j+1=0 ∨ j+1=n+1) := by have := Finset.mem_range.mp hj; omega
    rw [if_neg hn,vertexWeight_sq]
  rw [he]
  simp only [or_true,ite_true]
  ring

def dampedGeometry (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (g : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (z : ℤ×ℤ) (a : PhysicalActiveLists P J) (w : ℤ×ℤ) (b : PhysicalActiveLists P J) : ℂ :=
  (vertexWeight value primes q z a:ℂ)*g z a w b*(vertexWeight value primes q w b:ℂ)

theorem damped_adjoint (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (g : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ) :
    PhysicalRootedMoment.adjointGeometry (dampedGeometry value primes q g)=
      dampedGeometry value primes q (PhysicalRootedMoment.adjointGeometry g) := by
  funext z a w b
  simp only [PhysicalRootedMoment.adjointGeometry,dampedGeometry,map_mul,Complex.conj_ofReal]
  ring

theorem damped_alternating (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (g : (ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ) (j : ℕ) :
    PhysicalRootedMoment.alternatingGeometry (dampedGeometry value primes q g) j=
      dampedGeometry value primes q (PhysicalRootedMoment.alternatingGeometry g j) := by
  unfold PhysicalRootedMoment.alternatingGeometry
  split_ifs
  · rfl
  · exact damped_adjoint value primes q g

theorem damped_path_product (value : ∀i,P i→ℕ) (primes : Finset ℕ) (q : ℝ)
    (g : ℕ→(ℤ×ℤ)→PhysicalActiveLists P J→(ℤ×ℤ)→PhysicalActiveLists P J→ℂ)
    (r : OriginalPath (Fin K) (ℤ×ℤ) P J N) (hN : 0<N) :
    (∏j∈Finset.range N,dampedGeometry value primes q (g j)
      (r.positionAt j) (r.sourceLists j) (r.positionAt (j+1)) (r.targetLists j))=
    (∏j∈Finset.range N,g j (r.positionAt j) (r.sourceLists j)
      (r.positionAt (j+1)) (r.targetLists j)) *
      (physicalResidue value primes (momentDamping q N) r:ℂ) := by
  rw [vertex_product_eq_edges value primes q r hN]
  push_cast
  rw [←Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro j hj
  unfold dampedGeometry
  ring

theorem momentDamping_bounds (q : ℝ) (hq : 0≤q) (hq' : q≤1) (N j : ℕ) :
    0≤momentDamping q N j ∧ momentDamping q N j≤1 := by
  unfold momentDamping
  split_ifs
  · exact ⟨hq,hq'⟩
  · constructor <;> nlinarith [sq_nonneg (1-q)]

end Elliptic.Operator.PhysicalVertexDamping
