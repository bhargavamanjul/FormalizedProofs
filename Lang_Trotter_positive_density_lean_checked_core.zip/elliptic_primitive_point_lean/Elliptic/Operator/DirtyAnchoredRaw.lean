module

public import Elliptic.Operator.DirtyWeightedRaw
public import Elliptic.Operator.SourceMemoryEdges

/-!
# Actual stored-anchor geometry for dirty promotions

The allowed set below tests equality to the distinguished old particle's
actual residue-projective anchor. Its common h residue class is derived
from that equality and the cross-edge ban; it is not an extra hypothesis.
-/

@[expose] public section
noncomputable section
set_option backward.isDefEq.respectTransparency false
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

/-- Concrete target coordinates testing the actual retained projective line. -/
def anchoredRawChoiceCoordinates {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ : ℤ) (β : ℝ) (z w : ℤ × ℤ) (anchor : Option (ZMod p)) :
    Finset (RawDirtyCoordinate K M) :=
  (Finset.univ.product newProducts).biUnion fun oz =>
    ((targetIntegers β (rawChoiceDeterminant label p T σ oz)).filter
      (fun h => primeResidueAnchor p
        (targetVector z w (rawChoiceDeterminant label p T σ oz) h) = anchor)).image
      (fun h => (oz,h))

theorem mem_anchoredRawChoiceCoordinates {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ : ℤ) (β : ℝ) (z w : ℤ × ℤ) (anchor : Option (ZMod p))
    (c : RawDirtyCoordinate K M) :
    c ∈ anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor ↔
      c.1.2 ∈ newProducts ∧
      |(c.2 : ℝ)+(rawChoiceDeterminant label p T σ c.1 : ℝ)*β| ≤ 16 ∧
      primeResidueAnchor p (targetVector z w (rawChoiceDeterminant label p T σ c.1) c.2) = anchor := by
  rcases c with ⟨⟨o,Z⟩,h⟩
  simp [anchoredRawChoiceCoordinates, mem_targetIntegers]

/-- A reference h coordinate is chosen from the actual compatible set,
or zero when that set is empty. -/
def anchoredRawReference {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) (σ : ℤ) (β : ℝ) (z w : ℤ × ℤ) (anchor : Option (ZMod p)) : ℤ :=
  if h : (anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor).Nonempty then
    h.choose.2 else 0

/-- The actual projective anchor and the cross-edge ban force one h
residue class, uniformly over all omissions and other promoted products. -/
theorem anchoredRawChoiceCoordinates_subset_raw {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) [Fact p.Prime] (σ : ℤ) (β : ℝ)
    {z w : ℤ × ℤ} (hzw : latticeDet z w = 1) (anchor : Option (ZMod p))
    (hprime : ∀ ij, (label ij).Prime) (hban : ∀ ij, label ij ≠ p)
    (hσ : σ=1 ∨ σ= -1) :
    anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor ⊆
      rawChoiceCoordinates label newProducts p T σ
        (anchoredRawReference label newProducts p T σ β z w anchor) β := by
  intro c hc
  have hne : (anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor).Nonempty := ⟨c,hc⟩
  have hc' := (mem_anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor c).mp hc
  have hr := (mem_anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor hne.choose).mp
    hne.choose_spec
  apply (mem_rawChoiceCoordinates _ _ _ _ _ _ _ _).mpr
  refine ⟨hc'.1, hc'.2.1, ?_⟩
  unfold anchoredRawReference
  rw [dite_eq_left hne]
  apply primeResidueAnchor_targetVector_congruence p hzw
      (rawChoiceDeterminant label p T σ c.1)
      (rawChoiceDeterminant label p T σ hne.choose.1) c.2 hne.choose.2
  · simp [rawChoiceDeterminant]
  · have hn := dirty_determinant_nonzero_of_ban p label hprime hban σ
      (copiedProduct label c.1.1) c.1.2 T hσ
    simpa [rawChoiceDeterminant] using hn
  · exact hc'.2.2.trans hr.2.2.symm

/-- Therefore the actual stored-line target set has at most 33 elements
on a phase-separated fresh draw. -/
theorem anchoredRawChoiceCoordinates_card_le {K M : ℕ}
    (label : Fin K × Fin M → ℕ) (newProducts : Finset ℕ)
    (p T : ℕ) [Fact p.Prime] (σ : ℤ) (β δ : ℝ)
    {z w : ℤ × ℤ} (hzw : latticeDet z w = 1) (anchor : Option (ZMod p))
    (hprime : ∀ ij, (label ij).Prime) (hinj : Function.Injective label)
    (hban : ∀ ij, label ij ≠ p)
    (hcoprime : ∀ Z ∈ newProducts, (fullSourceProduct label).Coprime Z)
    (hσ : σ=1 ∨ σ= -1)
    (hsep : PhaseSeparated (dirtyProductSupport label newProducts) ((T : ℝ)*β) δ)
    (hwidth : 2*(16/(p : ℝ)) < δ) :
    (anchoredRawChoiceCoordinates label newProducts p T σ β z w anchor).card ≤ 33 := by
  apply (Finset.card_le_card (anchoredRawChoiceCoordinates_subset_raw label newProducts p T σ β
    hzw anchor hprime hban hσ)).trans
  exact rawChoiceCoordinates_card_le label newProducts p T σ _ β δ
    hprime hinj hcoprime (Fact.out : p.Prime).pos hσ hsep hwidth

end Elliptic.Operator
