module

public import Elliptic.Operator.DirtyUniqueness
public import Mathlib.Data.Int.Interval

/-!
# Actual integer target positions for a dirty raw edge

For an integral source vector `z` with a unimodular complement `w`, every
target has the unique form `h*z+j*w`, with `j=det(z,target)`. The physical
box condition confines `h` to an interval of length 32, giving at most 33
targets. A fixed residue of `h` then yields the circle-distance window
used in the good-state phase-separation test.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable

def latticeDet (z w : ℤ × ℤ) : ℤ := z.1*w.2-z.2*w.1
def latticeTau (r : ℝ) (z : ℤ × ℤ) : ℝ := (z.1 : ℝ)+r*z.2
def targetVector (z w : ℤ × ℤ) (j h : ℤ) : ℤ × ℤ :=
  (h*z.1+j*w.1,h*z.2+j*w.2)

theorem exists_unimodular_complement {z : ℤ × ℤ} (hz : IsCoprime z.1 z.2) :
    ∃ w, latticeDet z w=1 := by
  obtain ⟨a,b,h⟩ := hz
  refine ⟨(-b,a), ?_⟩
  dsimp [latticeDet]
  linear_combination h

theorem targetVector_decomposition {z w : ℤ × ℤ} (hzw : latticeDet z w=1)
    (v : ℤ × ℤ) : targetVector z w (latticeDet z v) (latticeDet v w)=v := by
  apply Prod.ext <;> dsimp [targetVector, latticeDet] at *
  · linear_combination v.1*hzw
  · linear_combination v.2*hzw

theorem latticeDet_targetVector {z w : ℤ × ℤ} (hzw : latticeDet z w=1)
    (j h : ℤ) : latticeDet z (targetVector z w j h)=j := by
  dsimp [targetVector, latticeDet] at *
  linear_combination j*hzw

theorem latticeTau_targetVector (r : ℝ) (z w : ℤ × ℤ) (j h : ℤ) :
    latticeTau r (targetVector z w j h) =
      (h : ℝ)*latticeTau r z+(j : ℝ)*latticeTau r w := by
  simp only [latticeTau, targetVector, Int.cast_add, Int.cast_mul]
  ring

theorem latticeTau_ratio_coordinates {z w : ℤ × ℤ} (hzw : latticeDet z w=1)
    (r : ℝ) (hz : latticeTau r z ≠ 0) (v : ℤ × ℤ) :
    latticeTau r v / latticeTau r z = (latticeDet v w : ℝ)+
      (latticeDet z v : ℝ)*(latticeTau r w/latticeTau r z) := by
  conv_lhs => rw [← targetVector_decomposition hzw v, latticeTau_targetVector]
  field_simp

def targetIntegers (β : ℝ) (j : ℤ) : Finset ℤ :=
  Finset.Icc ⌈-16-(j : ℝ)*β⌉ ⌊16-(j : ℝ)*β⌋

theorem mem_targetIntegers (β : ℝ) (j h : ℤ) :
    h ∈ targetIntegers β j ↔ |(h : ℝ)+(j : ℝ)*β| ≤ 16 := by
  simp only [targetIntegers, Finset.mem_Icc, Int.ceil_le, Int.le_floor, abs_le]
  constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith

theorem targetIntegers_card_le (β : ℝ) (j : ℤ) : (targetIntegers β j).card ≤ 33 := by
  rw [targetIntegers, Int.card_Icc]
  apply Int.toNat_le.mpr
  have hlo := Int.le_ceil (-16-(j : ℝ)*β)
  have hhi := Int.floor_le (16-(j : ℝ)*β)
  have hbound : ((⌊16-(j : ℝ)*β⌋ + 1 - ⌈-16-(j : ℝ)*β⌉ : ℤ) : ℝ) ≤ 33 := by
    push_cast
    linarith
  exact_mod_cast hbound

def rawTargetPositions (z w : ℤ × ℤ) (β : ℝ) (j : ℤ) : Finset (ℤ × ℤ) :=
  (targetIntegers β j).image (targetVector z w j)

theorem rawTargetPositions_card_le (z w : ℤ × ℤ) (β : ℝ) (j : ℤ) :
    (rawTargetPositions z w β j).card ≤ 33 :=
  (Finset.card_image_le).trans (targetIntegers_card_le β j)

theorem mem_rawTargetPositions_of_physical_box {z w : ℤ × ℤ}
    (hzw : latticeDet z w=1) (r : ℝ) (hz : latticeTau r z ≠ 0)
    (j : ℤ) (v : ℤ × ℤ) (hj : latticeDet z v=j)
    (hbox : |latticeTau r v/latticeTau r z| ≤ 16) :
    v ∈ rawTargetPositions z w (latticeTau r w/latticeTau r z) j := by
  apply Finset.mem_image.mpr
  refine ⟨latticeDet v w, ?_, ?_⟩
  · rw [mem_targetIntegers]
    simpa only [latticeTau_ratio_coordinates hzw r hz v, hj] using hbox
  · rw [← hj]
    exact targetVector_decomposition hzw v

/-- The bound applies to the actual physical target set, with any further
primitivity, line, label or memory restrictions retained. -/
theorem physical_targets_card_le {z w : ℤ × ℤ} (hzw : latticeDet z w=1)
    (r : ℝ) (hz : latticeTau r z ≠ 0) (j : ℤ) (s : Finset (ℤ × ℤ))
    (hs : ∀ v ∈ s, latticeDet z v=j ∧ |latticeTau r v/latticeTau r z| ≤ 16) :
    s.card ≤ 33 := by
  apply (Finset.card_le_card (s := s) (t := rawTargetPositions z w
    (latticeTau r w/latticeTau r z) j) ?_).trans (rawTargetPositions_card_le _ _ _ _)
  intro v hv
  exact mem_rawTargetPositions_of_physical_box hzw r hz j v (hs v hv).1 (hs v hv).2

theorem integer_coe_circle_zero (k : ℤ) : (((k : ℝ) : AddCircle (1 : ℝ)))=0 := by
  rw [show (k : ℝ) = k • (1 : ℝ) by simp, AddCircle.coe_zsmul,
    AddCircle.coe_period, smul_zero]

/-- The geometric tube and one residue of the first coordinate imply
exactly the circle window used in (4.36), for either determinant sign. -/
theorem raw_target_phase_window
    (p P D Z T σ j h h₀ : ℤ) (β : ℝ) (hp : 0 < p)
    (hσ : σ=1 ∨ σ= -1) (hj : j=σ*(P-D*p*Z*T))
    (hh : p ∣ h-h₀) (htube : |(h : ℝ)+(j : ℝ)*β| ≤ 16) :
    dist ((((D*Z*T : ℤ) : ℝ)*β : ℝ) : AddCircle (1 : ℝ))
      ((((P : ℝ)*β+(σ*h₀ : ℤ))/(p : ℝ) : ℝ) : AddCircle (1 : ℝ)) ≤ 16/(p : ℝ) := by
  obtain ⟨k,hk⟩ := hh
  have hpR : (0 : ℝ) < p := by exact_mod_cast hp
  have hid : ((D*Z*T : ℤ) : ℝ)*β-((P : ℝ)*β+(σ*h₀ : ℤ))/(p : ℝ) =
      ((σ*k : ℤ) : ℝ) - (σ : ℝ)*((h : ℝ)+(j : ℝ)*β)/(p : ℝ) := by
    have hkR : (h : ℝ)-(h₀ : ℝ)=(p : ℝ)*(k : ℝ) := by exact_mod_cast hk
    rw [hj]
    rcases hσ with rfl | rfl <;> push_cast <;> field_simp <;> nlinarith [hkR]
  rw [dist_eq_norm, ← QuotientAddGroup.mk_sub, hid, AddCircle.coe_sub,
    integer_coe_circle_zero, zero_sub, norm_neg]
  apply (QuotientAddGroup.norm_mk_le_norm).trans
  rw [Real.norm_eq_abs, abs_div, abs_mul, abs_of_pos hpR]
  have hs : |(σ : ℝ)|=1 := by rcases hσ with rfl | rfl <;> norm_num
  rw [hs, one_mul]
  exact div_le_div_of_nonneg_right htube hpR.le

end Elliptic.Operator
