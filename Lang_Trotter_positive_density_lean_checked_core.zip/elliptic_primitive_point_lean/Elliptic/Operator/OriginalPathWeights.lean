module

public import Elliptic.Operator.SourceMinorArc
public import Elliptic.Operator.RootDiscreteBudget
public import Elliptic.Operator.IndependentLineNormalization

/-!
# Absolute weights of the original finite physical path records

The normalization is the original physical measure and one fresh-slot
weight per edge, together with both endpoint permutation averages. The
geometry is the literal signed source multiplier. Residue incidence and
inactive damping are retained prime by prime and bounded pointwise.
This is a coefficient estimate for the explicitly defined finite path
expansion, not yet its identification with the whole operator moment.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.OriginalPathWeights
open scoped BigOperators
open Filter IntegerRootReplacement IndependentLineNormalization
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

abbrev Record (K J N R Q : ℕ) := OriginalPathRecord K (J+1) N R Q

/-- The two literal permutation families act on the lists at the two
ends of each edge. The cross-edge ban remains inside the geometry. -/
def edgeGeometry (rec : Record K J N R Q) (adjoint : Fin N → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists (fun _ : Fin K => Fin Q) J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ)
    (major : Set ProductCircle) (σ : ℤ) (j : Fin N) : ℂ :=
  orientedSourceEdgeGeometry (adjoint j) (fun _ p => p.val) good
    u v r U W d₀ Y smooth ψ major σ
    (rec.1 j.castSucc).val
    (fun i a => rec.2.1 j.castSucc i (rec.2.2.1 j i a))
    (rec.1 j.succ).val
    (fun i a => rec.2.1 j.succ i (rec.2.2.2 j i a))

/-- The initial physical list measure contributes M=J+1 inverse masses;
each of the N edges contributes one further inverse mass per group. -/
def normalization (V : Fin K → ℝ) (J N : ℕ) : ℝ :=
  (∏ i, (V i)⁻¹^(J+1+N)) * (endpointPermutationWeight (Fin K) J)^N

theorem normalization_eq_initial_edges (V : Fin K → ℝ) (J N : ℕ) :
    normalization V J N =
      (∏ i, (V i)⁻¹^(J+1)) *
        ∏ _j : Fin N, endpointPermutationWeight (Fin K) J * ∏ i, (V i)⁻¹ := by
  unfold normalization
  simp only [pow_add, Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ,
    Fintype.card_fin, ← Finset.prod_pow]
  ring

theorem endpoint_weight_bounds (K J : ℕ) :
    0 ≤ endpointPermutationWeight (Fin K) J ∧
      endpointPermutationWeight (Fin K) J ≤ 1 := by
  unfold endpointPermutationWeight
  constructor
  · positivity
  · apply pow_le_one₀ (by positivity)
    apply inv_le_one_of_one_le₀
    simp only [Fintype.card_pi, Fintype.card_perm, Fintype.card_fin,
      Finset.prod_const, Finset.card_univ]
    have h : 1 ≤ (J+1).factorial ^ K := Nat.one_le_pow _ _ (Nat.factorial_pos _)
    exact_mod_cast h

theorem normalization_bounds (V : Fin K → ℝ) (hV : ∀ i, 1 ≤ V i) (J N : ℕ) :
    0 ≤ normalization V J N ∧ normalization V J N ≤ 1 := by
  have hi : ∀ i, 0 ≤ (V i)⁻¹ ∧ (V i)⁻¹ ≤ 1 := fun i =>
    ⟨inv_nonneg.mpr (by linarith [hV i]), inv_le_one_of_one_le₀ (hV i)⟩
  have hp : (∏ i, (V i)⁻¹^(J+1+N)) ≤ 1 :=
    Finset.prod_le_one₀ (fun i _ => pow_nonneg (hi i).1 _) (fun i _ => pow_le_one₀ (hi i).1 (hi i).2)
  have he := endpoint_weight_bounds K J
  constructor
  · exact mul_nonneg (Finset.prod_nonneg fun i _ => pow_nonneg (hi i).1 _) (pow_nonneg he.1 _)
  · exact mul_le_one₀ hp (pow_nonneg he.1 _) (pow_le_one₀ he.1 he.2)

/-- The actual source masses can be below one. Their fixed positive
lower bound gives an explicit inverse-mass cost instead. -/
theorem normalization_le (V : Fin K → ℝ) (vmin : ℝ) (hmin : 0 < vmin)
    (hV : ∀ i, vmin ≤ V i) (J N : ℕ) :
    0 ≤ normalization V J N ∧
      normalization V J N ≤ (vmin⁻¹)^(K*(J+1+N)) := by
  have hi : ∀ i, 0 ≤ (V i)⁻¹ ∧ (V i)⁻¹ ≤ vmin⁻¹ := fun i =>
    ⟨inv_nonneg.mpr (hmin.trans_le (hV i)).le, inv_anti₀ hmin (hV i)⟩
  have hp : (∏ i, (V i)⁻¹^(J+1+N)) ≤ (vmin⁻¹)^(K*(J+1+N)) := by
    calc
      _ ≤ ∏ _i : Fin K, (vmin⁻¹)^(J+1+N) :=
        Finset.prod_le_prod₀ (fun i _ => pow_nonneg (hi i).1 _)
          (fun i _ => pow_le_pow_left₀ (hi i).1 (hi i).2 _)
      _ = _ := by simp [← pow_mul, Nat.mul_comm]
  have he := endpoint_weight_bounds K J
  refine ⟨mul_nonneg (Finset.prod_nonneg fun i _ => pow_nonneg (hi i).1 _) (pow_nonneg he.1 _), ?_⟩
  exact (mul_le_mul_of_nonneg_left (pow_le_one₀ he.1 he.2)
    (Finset.prod_nonneg fun i _ => pow_nonneg (hi i).1 _)).trans (by simpa using hp)

theorem edgeGeometry_norm_le_one (rec : Record K J N R Q) (adjoint : Fin N → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists (fun _ : Fin K => Fin Q) J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (hd : 0 < d₀) (hsmooth : ∀ t, ‖smooth t‖ ≤ 1) (hψ : ∀ t, ‖ψ t‖ ≤ 1)
    (j : Fin N) :
    ‖edgeGeometry rec adjoint good u v r U W d₀ Y smooth ψ major σ j‖ ≤ 1 := by
  simpa only [edgeGeometry, one_pow, one_mul] using
    orientedSourceEdgeGeometry_norm_le_one_factor (adjoint j) (fun (_ : Fin K) (p : Fin Q) => p.val)
      good u v r U W d₀ Y smooth ψ major hmajor σ 1 1 hd (by norm_num) (by norm_num)
      hsmooth hψ (rec.1 j.castSucc).val
      (fun i a => rec.2.1 j.castSucc i (rec.2.2.1 j i a))
      (rec.1 j.succ).val (fun i a => rec.2.1 j.succ i (rec.2.2.2 j i a))

/-- A literal one-prime residue factor lies in [0,1]. Repeated active
visits impose their actual line incidences and introduce no extra mass. -/
theorem lineFactor_bounds {Line : Type*} [DecidableEq Line]
    (visits active : Finset ℕ) (line : ℕ → Line) (η : ℕ → ℝ) (ℓ : Line)
    (hη : ∀ j ∈ visits, 0 ≤ η j ∧ η j ≤ 1) :
    0 ≤ lineFactor visits active line η ℓ ∧ lineFactor visits active line η ℓ ≤ 1 := by
  have ha : ∀ j ∈ active, 0 ≤ (if line j=ℓ then (1:ℝ) else 0) ∧
      (if line j=ℓ then (1:ℝ) else 0) ≤ 1 := by intro j hj; split_ifs <;> norm_num
  have hd : ∀ j ∈ visits \ active, 0 ≤ 1-Elliptic.PrimewiseMemory.hitWeight line η j ℓ ∧
      1-Elliptic.PrimewiseMemory.hitWeight line η j ℓ ≤ 1 := by
    intro j hj
    have h := hη j (Finset.mem_sdiff.mp hj).1
    unfold Elliptic.PrimewiseMemory.hitWeight
    split_ifs <;> constructor <;> linarith
  unfold lineFactor
  exact ⟨mul_nonneg (Finset.prod_nonneg fun j hj => (ha j hj).1)
    (Finset.prod_nonneg fun j hj => (hd j hj).1),
    mul_le_one₀ (Finset.prod_le_one₀ (fun j hj => (ha j hj).1) (fun j hj => (ha j hj).2))
      (Finset.prod_nonneg fun j hj => (hd j hj).1)
      (Finset.prod_le_one₀ (fun j hj => (hd j hj).1) (fun j hj => (hd j hj).2))⟩

/-- The position read by an arbitrary natural-number visit; all factors
below use only visits in range N+1. -/
def positionAt (rec : Record K J N R Q) (t : ℕ) : ℤ × ℤ :=
  if h : t < N+1 then (rec.1 ⟨t,h⟩).val else (0,0)

def activeVisits (rec : Record K J N R Q) (p : ℕ) : Finset ℕ :=
  (Finset.range (N+1)).filter fun t =>
    ∃ j : Fin (N+1), j.val=t ∧ ∃ i a, (rec.2.1 j i a).val=p

/-- Actual active incidences and inactive damping over numerical primes. -/
def residueFactor (rec : Record K J N R Q) (primes : Finset ℕ)
    (η : ℕ → ℝ) (ℓ : (p : ℕ) → Option (ZMod p)) : ℝ :=
  ∏ p ∈ primes, lineFactor (Finset.range (N+1)) (activeVisits rec p)
    (fun t => primeResidueAnchor p (positionAt rec t)) η (ℓ p)

theorem residueFactor_bounds (rec : Record K J N R Q) (primes : Finset ℕ)
    (η : ℕ → ℝ) (ℓ : (p : ℕ) → Option (ZMod p))
    (hη : ∀ j < N+1, 0 ≤ η j ∧ η j ≤ 1) :
    0 ≤ residueFactor rec primes η ℓ ∧ residueFactor rec primes η ℓ ≤ 1 := by
  have h p := lineFactor_bounds (Finset.range (N+1)) (activeVisits rec p)
    (fun t => primeResidueAnchor p (positionAt rec t)) η (ℓ p)
    (fun j hj => hη j (Finset.mem_range.mp hj))
  exact ⟨Finset.prod_nonneg fun p _ => (h p).1,
    Finset.prod_le_one₀ (fun p _ => (h p).1) (fun p _ => (h p).2)⟩

/-- The original normalized path summand, with no memory variables. -/
def weight (rec : Record K J N R Q) (V : Fin K → ℝ) (adjoint : Fin N → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists (fun _ : Fin K => Fin Q) J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ) (major : Set ProductCircle) (σ : ℤ)
    (primes : Finset ℕ) (η : ℕ → ℝ) (ℓ : (p : ℕ) → Option (ZMod p)) : ℂ :=
  (normalization V J N:ℂ) * (∏ j, edgeGeometry rec adjoint good u v r U W d₀ Y smooth ψ major σ j) *
    (residueFactor rec primes η ℓ:ℂ)

theorem weight_norm_le_one (rec : Record K J N R Q) (V : Fin K → ℝ)
    (hV : ∀ i, 1 ≤ V i) (adjoint : Fin N → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists (fun _ : Fin K => Fin Q) J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (hd : 0 < d₀) (hsmooth : ∀ t, ‖smooth t‖ ≤ 1) (hψ : ∀ t, ‖ψ t‖ ≤ 1)
    (primes : Finset ℕ) (η : ℕ → ℝ) (ℓ : (p : ℕ) → Option (ZMod p))
    (hη : ∀ j < N+1, 0 ≤ η j ∧ η j ≤ 1) :
    ‖weight rec V adjoint good u v r U W d₀ Y smooth ψ major σ primes η ℓ‖ ≤ 1 := by
  have hn := normalization_bounds V hV J N
  have hr := residueFactor_bounds rec primes η ℓ hη
  unfold weight
  rw [norm_mul, norm_mul, norm_prod, Complex.norm_real, Complex.norm_real,
    Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg hn.1, abs_of_nonneg hr.1]
  apply mul_le_one₀ _ hr.1 hr.2
  apply mul_le_one₀ hn.2 (Finset.prod_nonneg fun _ _ => norm_nonneg _)
  exact Finset.prod_le_one₀ (fun _ _ => norm_nonneg _)
    (fun j _ => edgeGeometry_norm_le_one rec adjoint good u v r U W d₀ Y smooth ψ major hmajor σ hd hsmooth hψ j)

/-- Explicit original coefficient bound in the source's actual
positive-mass range, without assuming that the masses exceed one. -/
theorem weight_norm_le (rec : Record K J N R Q) (V : Fin K → ℝ)
    (vmin : ℝ) (hmin : 0 < vmin) (hV : ∀ i, vmin ≤ V i) (adjoint : Fin N → Bool)
    (good : (ℤ × ℤ) → PhysicalActiveLists (fun _ : Fin K => Fin Q) J → Prop)
    (u v r U W d₀ Y : ℝ) (smooth ψ : ℝ → ℂ)
    (major : Set ProductCircle) (hmajor : MeasurableSet major) (σ : ℤ)
    (hd : 0 < d₀) (hsmooth : ∀ t, ‖smooth t‖ ≤ 1) (hψ : ∀ t, ‖ψ t‖ ≤ 1)
    (primes : Finset ℕ) (η : ℕ → ℝ) (ℓ : (p : ℕ) → Option (ZMod p))
    (hη : ∀ j < N+1, 0 ≤ η j ∧ η j ≤ 1) :
    ‖weight rec V adjoint good u v r U W d₀ Y smooth ψ major σ primes η ℓ‖ ≤
      (vmin⁻¹)^(K*(J+1+N)) := by
  have hn := normalization_le V vmin hmin hV J N
  have hr := residueFactor_bounds rec primes η ℓ hη
  have he : (∏ j, ‖edgeGeometry rec adjoint good u v r U W d₀ Y smooth ψ major σ j‖) ≤ 1 :=
    Finset.prod_le_one₀ (fun _ _ => norm_nonneg _) (fun j _ =>
      edgeGeometry_norm_le_one rec adjoint good u v r U W d₀ Y smooth ψ major hmajor σ hd hsmooth hψ j)
  unfold weight
  rw [norm_mul, norm_mul, norm_prod, Complex.norm_real, Complex.norm_real,
    Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg hn.1, abs_of_nonneg hr.1]
  calc
    _ ≤ normalization V J N * 1 * 1 :=
      mul_le_mul (mul_le_mul_of_nonneg_left he hn.1) hr.2 hr.1 (by simpa using hn.1)
    _ ≤ _ := by simpa using hn.2

/-- The inverse source masses have a subpower cost even when they are
less than one. The actual growing M and N, not assumed growth bounds,
are used in this estimate. -/
theorem eventually_inverse_mass_cost (K : ℕ) (vmin : ℝ) (hmin : 0 < vmin) :
    ∀ᶠ L : ℝ in atTop,
      (vmin⁻¹)^(K*(momentMultiplicity L+momentLength L)) ≤
        Real.exp (L^(73/100:ℝ)) := by
  let c := max 1 vmin⁻¹
  have hc1 : 1 ≤ c := le_max_left _ _
  have hc0 : 0 < c := lt_of_lt_of_le zero_lt_one hc1
  have hlog : 0 ≤ Real.log c := Real.log_nonneg hc1
  filter_upwards [eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<23/100)).eventually
      (eventually_ge_atTop (6*(K:ℝ)*Real.log c))] with L hL hcost
  have hL0 : 0 < L := by linarith
  have hm := momentMultiplicity_le_two_rpow hL
  have hn := momentLength_add_one_le L hL
  have hl := Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1/100:ℝ)≤1/2)
  have hexp : ((K*(momentMultiplicity L+momentLength L):ℕ):ℝ) ≤
      6*(K:ℝ)*L^(1/2:ℝ) := by
    push_cast
    have hh : (momentMultiplicity L:ℝ)+(momentLength L:ℝ) ≤ 6*L^(1/2:ℝ) := by linarith
    nlinarith [mul_le_mul_of_nonneg_left hh (Nat.cast_nonneg K)]
  calc
    _ ≤ c^(K*(momentMultiplicity L+momentLength L)) :=
      pow_le_pow_left₀ (inv_nonneg.mpr hmin.le) (le_max_right _ _) _
    _ = Real.exp (((K*(momentMultiplicity L+momentLength L):ℕ):ℝ)*Real.log c) := by
      rw [Real.exp_nat_mul, Real.exp_log hc0]
    _ ≤ Real.exp (L^(73/100:ℝ)) := by
      apply Real.exp_le_exp.mpr
      have h1 := mul_le_mul_of_nonneg_right hexp hlog
      have h2 := mul_le_mul_of_nonneg_right hcost (show 0 ≤ L^(1/2:ℝ) by positivity)
      have he : L^(23/100:ℝ)*L^(1/2:ℝ)=L^(73/100:ℝ) := by
        rw [← Real.rpow_add hL0]; norm_num
      nlinarith [he]

/-- The entire finite original-record expansion has an explicit absolute
coefficient budget. No total-mass hypothesis is supplied. Residue lines,
root parameters and the selected records may all vary after the threshold.
The exact identification with the operator moment is a separate step. -/
theorem eventually_total_weight_bound (K : ℕ) (C vmin : ℝ) (hC : 0 ≤ C) (hmin : 0 < vmin) :
    ∀ᶠ L : ℝ in atTop,
      ∀ records : Finset (RootDiscreteBudget.SourceRecord K C L),
      ∀ V : Fin K → ℝ, (∀ i, vmin ≤ V i) →
      ∀ adjoint : Fin (momentLength L) → Bool,
      ∀ good : (ℤ × ℤ) → PhysicalActiveLists
        (fun _ : Fin K => Fin (rootPrimeCeiling L)) (momentPadding L) → Prop,
      ∀ u v r U W d₀ Y : ℝ, ∀ smooth ψ : ℝ → ℂ,
      ∀ major : Set ProductCircle, MeasurableSet major → ∀ σ : ℤ,
      0 < d₀ → (∀ t, ‖smooth t‖ ≤ 1) → (∀ t, ‖ψ t‖ ≤ 1) →
      ∀ primes : Finset ℕ, ∀ η : ℕ → ℝ, ∀ ℓ : (p : ℕ) → Option (ZMod p),
      (∀ j < momentLength L+1, 0 ≤ η j ∧ η j ≤ 1) →
      (∑ rec ∈ records, ‖weight rec V adjoint good u v r U W d₀ Y smooth ψ major σ primes η ℓ‖) ≤
        Real.exp (2*L^(73/100:ℝ)) := by
  filter_upwards [eventually_originalPathRecord_card_le_source_budget K C hC,
    eventually_inverse_mass_cost K vmin hmin] with L hcard hcost
  intro records V hV adjoint good u v r U W d₀ Y smooth ψ major hmajor σ hd hsmooth hψ primes η ℓ hη
  have hrec : (records.card:ℝ) ≤ Real.exp (L^(73/100:ℝ)) := by
    exact le_trans (by exact_mod_cast Finset.card_le_univ records) hcard
  calc
    _ ≤ ∑ _rec ∈ records, (vmin⁻¹)^(K*(momentMultiplicity L+momentLength L)) := by
      apply Finset.sum_le_sum
      intro rec hrec'
      exact weight_norm_le rec V vmin hmin hV adjoint good u v r U W d₀ Y smooth ψ
        major hmajor σ hd hsmooth hψ primes η ℓ hη
    _ = (records.card:ℝ)*(vmin⁻¹)^(K*(momentMultiplicity L+momentLength L)) := by simp
    _ ≤ Real.exp (L^(73/100:ℝ))*Real.exp (L^(73/100:ℝ)) := by gcongr
    _ = _ := by rw [← Real.exp_add]; congr 1; ring

end Elliptic.Operator.OriginalPathWeights
