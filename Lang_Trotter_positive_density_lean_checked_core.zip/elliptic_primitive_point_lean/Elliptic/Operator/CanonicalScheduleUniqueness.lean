module

public import Elliptic.Operator.ScheduledHistoryRecovery
public import Elliptic.Operator.ScheduledLineIncidence

/-!
# Uniqueness of the used finite schedule data

Compatible histories determine every observed edge choice as well as their
used prime lifespans. After birth-line normalization, the retained lines
are determined too. Unused labels and off-horizon fields are excluded.
This proves uniqueness when a schedule exists, not extraction existence.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.ScheduledPhysicalPath
variable {I Z : Type} [Fintype I] [Fintype Z]
variable {P : I → Type} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type} {J B N : ℕ}
variable {anchor : Z → ∀ i p, Line i p}
variable (d e : ScheduledPhysicalPath anchor N J B)
variable (ν : ∀ i, P i → ℝ) (V : I → ℝ) (η q : ℕ → ℝ) (ρ : ℝ)
variable (geometry : ℕ → Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
set_option backward.isDefEq.respectTransparency false

/-- All edge data actually used in the word, without any memory ordering
or unobserved retained-coordinate choices. -/
def EdgeDataEqual (j : ℕ) : Prop :=
  d.position (j+1) = e.position (j+1) ∧ d.sourcePerm j = e.sourcePerm j ∧
  d.targetPerm j = e.targetPerm j ∧ d.store j = e.store j ∧
  d.targetPrime j = e.targetPrime j ∧ d.promote j = e.promote j

omit [Fintype Z] [∀ i, Fintype (P i)] in
theorem edgeDataEqual_of_observed (j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (c : PhysicalEdgeChoice s)
    (hd : d.EdgeObserved j s c) (he : e.EdgeObserved j s c) :
    EdgeDataEqual d e j := by
  refine ⟨hd.1.symm.trans he.1,hd.2.1.symm.trans he.2.1,
    hd.2.2.1.symm.trans he.2.2.1,?_,?_,?_⟩
  · funext i
    exact (hd.2.2.2 i).1.symm.trans (he.2.2.2 i).1
  · funext i
    exact (hd.2.2.2 i).2.1.symm.trans (he.2.2.2 i).2.1
  · funext i
    exact (hd.2.2.2 i).2.2.symm.trans (he.2.2.2 i).2.2

/-- Literal compatibility alone recovers all edge permutations and flags
on the observed interval. No equality of path outputs is assumed. -/
theorem compatible_edge_data_unique (n j : ℕ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry j n) s)
    (hd : d.Compatible ν V η q ρ geometry n j s h)
    (he : e.Compatible ν V η q ρ geometry n j s h) :
    ∀ k, k < n → EdgeDataEqual d e (j+k) := by
  induction n generalizing j s with
  | zero => intro k hk; omega
  | succ n ih =>
      intro k hk
      cases k with
      | zero =>
          simpa using edgeDataEqual_of_observed d e j _ h.2.1.val hd.2.1 he.2.1
      | succ k =>
          have ht := ih (j+1) _ h.2.2 hd.2.2 he.2.2 k (by omega)
          simpa only [Nat.add_assoc, Nat.add_comm 1 k] using ht

/-- Once birth anchors are fixed, the same compatible history determines
every retained line on the used prime support. -/
theorem compatible_anchored_retained_unique
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (hsd : d.Before 0 s) (hse : e.Before 0 s)
    (h : ChoiceOperation.History (operations (anchor:=anchor) ν V η q ρ geometry 0 N) s)
    (hcd : d.Compatible ν V η q ρ geometry N 0 s h)
    (hce : e.Compatible ν V η q ρ geometry N 0 s h)
    (hbd : d.ActiveBirthAnchored) (hbe : e.ActiveBirthAnchored)
    (i : I) (p : P i) (hp : p ∈ d.primes i) : d.retained i p = e.retained i p := by
  have hsets := d.compatible_primes_unique ν V η q ρ geometry e s hsd hse h hcd hce
  have hlife := d.compatible_lifespan_unique ν V η q ρ geometry e s hsd hse h hcd hce i p hp
  have hep : p ∈ e.primes i := by rw [← hsets]; exact hp
  rw [d.retained_eq_birth_anchor hbd i p hp,e.retained_eq_birth_anchor hbe i p hep]
  have hb : (d.lifespan i p).birth ≤ N :=
    (d.lifespan i p).birth_le_death.trans (d.lifespan i p).death_le
  have hpos := (d.compatible_visit_data_unique ν V η q ρ geometry e s hsd hse h hcd hce _ hb).1
  rw [hpos,hlife]

end Elliptic.Operator.ScheduledPhysicalPath
