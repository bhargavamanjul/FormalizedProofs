module

public import Elliptic.Operator.SignedBonferroniTransfer

/-! The independent Option(ZMod p) line law has the literal numerical
prime-subset marginal, with its exact product-of-(p+1) normalization. -/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.FinitePrimeMarginal
open scoped BigOperators
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

theorem average_restrict (S P : Finset ℕ) (hSP : S⊆P)
    [∀p : P,Fact p.val.Prime] [∀p : S,Fact p.val.Prime]
    (f : (∀p : S,Option (ZMod p.val))→ℂ) :
    (∑ℓ : ∀p : P,Option (ZMod p.val),f (fun p : S=>ℓ ⟨p.val,hSP p.property⟩)) /
      ((∏p∈P,(p+1):ℕ):ℂ) =
    (∑ℓ : ∀p : S,Option (ZMod p.val),f ℓ) / ((∏p∈S,(p+1):ℕ):ℂ) := by
  let s : Finset P := Finset.univ.filter (fun p=>p.val∈S)
  let e : s ≃ S :=
    { toFun := fun p=>⟨p.val.val,(Finset.mem_filter.mp p.property).2⟩
      invFun := fun p=>⟨⟨p.val,hSP p.property⟩,by simp [s,p.property]⟩
      left_inv := fun p=>by rfl
      right_inv := fun p=>by rfl }
  let E : (∀p : s,Option (ZMod p.val.val)) ≃ (∀p : S,Option (ZMod p.val)) :=
    Equiv.piCongrLeft (fun p : S=>Option (ZMod p.val)) e
  have hh := SignedBonferroniTransfer.complex_average_restrict
    (fun p : P=>Option (ZMod p.val)) s (fun ℓ=>f (E ℓ))
  have hcardP : Fintype.card (∀p : P,Option (ZMod p.val))=∏p∈P,(p+1) := by
    simp only [Fintype.card_pi,Fintype.card_option,ZMod.card]
    exact Finset.prod_coe_sort P (fun p : ℕ=>p+1)
  have hcardS : Fintype.card (∀p : S,Option (ZMod p.val))=∏p∈S,(p+1) := by
    simp only [Fintype.card_pi,Fintype.card_option,ZMod.card]
    exact Finset.prod_coe_sort S (fun p : ℕ=>p+1)
  rw [hcardP,Fintype.card_congr E,hcardS,E.sum_comp f] at hh
  exact hh

end Elliptic.Operator.FinitePrimeMarginal
