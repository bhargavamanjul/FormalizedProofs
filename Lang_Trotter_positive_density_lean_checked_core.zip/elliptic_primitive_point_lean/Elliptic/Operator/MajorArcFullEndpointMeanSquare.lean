module
public import Elliptic.Operator.MajorArcProductMeanSquare
public import Elliptic.Operator.MajorArcLabelMass
public import Elliptic.Operator.SignedMajorEndpointPolynomials

/-! Global translated mean square for the full normalized source endpoint.
The label factor costs at most sixteen by its exact harmonic mass. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcFullEndpointMeanSquare
open Filter MeasureTheory Set
open scoped BigOperators ComplexConjugate
open Artin.MarkedSource MajorArcScaleCancellation MajorArcProductMeanSquare
attribute [local instance] Classical.propDecidable
local instance endpointDecEq {ι : Type*} : DecidableEq ι := Classical.typeDecidableEq ι
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 500000

theorem bounded_label_factor_mean_square
    (F M N : ℝ→ℂ) (hF : Continuous F) (hM : Continuous M) (hN : Continuous N)
    (a b : ℝ) (hab : a≤b) (hbound : ∀v∈Icc a b,‖F v‖≤4) :
    (∫v in a..b,‖F v*M v*N v‖^2)≤16*(∫v in a..b,‖M v*N v‖^2) := by
  have hpoint : ∀v∈Icc a b,‖F v*M v*N v‖^2≤16*‖M v*N v‖^2 := by
    intro v hv
    have h := mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (norm_nonneg _) (hbound v hv) 2) (sq_nonneg ‖M v*N v‖)
    simpa only [norm_mul,mul_pow,mul_assoc,show (4:ℝ)^2=16 by norm_num] using h
  have h := intervalIntegral.integral_mono_on (μ:=volume) hab
    ((((hF.mul hM).mul hN).norm.pow 2).intervalIntegrable _ _)
    ((continuous_const.mul ((hM.mul hN).norm.pow 2)).intervalIntegrable _ _) hpoint
  simp only [Pi.pow_apply,Pi.mul_apply] at h
  rwa [intervalIntegral.integral_const_mul] at h

/-- One onset works for every continuous label factor of norm at most four,
every character, and every translated frequency interval. -/
theorem eventually_bounded_label_factor_mean_square
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ C : ℝ) (hδ : 0<δ) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀Hm Hn : ℝ,1≤Hm→1≤Hn→
      Real.exp (δ*L)≤Hm*Hn→Hm*Hn≤Real.exp (2*L)→
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^C)→(∀n∈t,‖β n‖≤L^C)→
      ∀(k l : ℕ) (χ : DirichletCharacter ℂ k) (ψ : DirichletCharacter ℂ l),
      ∀F : ℝ→ℂ,Continuous F→∀a b : ℝ,a≤b→(∀v∈Icc a b,‖F v‖≤4)→
      (∫v in a..b,‖F v*longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2)≤
        L^(4*C+6)*(1+(b-a)/(Hm*Hn)) := by
  filter_upwards [eventually_long_product_mean_square hD δ C hδ hC,
    eventually_ge_atTop (16:ℝ)] with L hms hL
  intro Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ F hF a b hab hbound
  have hLp : 0<L := by linarith
  have hX : 0<Hm*Hn := by positivity
  have hh := bounded_label_factor_mean_square F (longPolynomial s α Hm χ)
    (longPolynomial t β Hn ψ) hF (longPolynomial_continuous _ _ _ _)
    (longPolynomial_continuous _ _ _ _) a b hab hbound
  calc
    _ ≤ 16*(L^(4*C+5)*(1+(b-a)/(Hm*Hn))) := hh.trans
      (mul_le_mul_of_nonneg_left (hms Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ a b hab) (by norm_num))
    _ ≤ L*(L^(4*C+5)*(1+(b-a)/(Hm*Hn))) :=
      mul_le_mul_of_nonneg_right hL (by positivity)
    _ = _ := by
      have he : L*L^(4*C+5)=L^(4*C+6) := by
        calc
          _ = L^(1:ℝ)*L^(4*C+5) := by rw [Real.rpow_one]
          _ = _ := by rw [←Real.rpow_add hLp]; congr 1; ring
      rw [←mul_assoc,he]

/-- The actual full normalized label endpoint, including arbitrary character,
modulation, and cutoff, has a uniform global polynomial mean square. -/
theorem eventually_full_endpoint_mean_square
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ C : ℝ) (hδ : 0<δ) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀Hm Hn : ℝ,1≤Hm→1≤Hn→
      Real.exp (δ*L)≤Hm*Hn→Hm*Hn≤Real.exp (2*L)→
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^C)→(∀n∈t,‖β n‖≤L^C)→
      ∀(k l : ℕ) (χ : DirichletCharacter ℂ k) (ψ : DirichletCharacter ℂ l),
      ∀(ι : Type*) [Fintype ι] (G : ι→Finset ℕ),
      (∀i,∀p∈G i,0<p)→(∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)→
      ∀(q : ℕ) (χlabel : DirichletCharacter ℂ q) (η : ℝ→ℂ),
      (∀y,‖η y‖≤1)→(∀y,η y≠0→y≤4)→∀lam Y : ℝ,0<Y→
      ∀a b : ℝ,a≤b→
      (∫v in a..b,‖MajorArcLabelMass.fullEndpoint G χlabel η lam Y v*
        longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2)≤
        L^(4*C+6)*(1+(b-a)/(Hm*Hn)) := by
  filter_upwards [eventually_bounded_label_factor_mean_square hD δ C hδ hC] with L h
  intro Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ ι _ G hG hmass q χlabel η hη hηs lam Y hY a b hab
  exact h Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ
    (MajorArcLabelMass.fullEndpoint G χlabel η lam Y)
    (MajorArcLabelMass.fullEndpoint_continuous G χlabel η lam Y) a b hab
    (fun v _=>MajorArcLabelMass.fullEndpoint_norm G hG hmass χlabel η hη hηs lam Y v hY)

/-- The label factor appearing in the exact Mellin identity is precisely the
full source endpoint after harmonic normalization. -/
theorem fullEndpoint_eq_normalized_labelPolynomial {ι : Type*} [Fintype ι]
    (G : ι→Finset ℕ) {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    MajorArcLabelMass.fullEndpoint G χ η lam Y t=
      (MajorArcLabelMass.normalization G:ℂ)*
        SignedMajorMellinIdentity.labelPolynomial Finset.univ (MajorArcLabelMass.product G) χ η Y lam t := by
  unfold MajorArcLabelMass.fullEndpoint SignedMajorMellinIdentity.labelPolynomial
  rw [Complex.ofReal_div,div_eq_mul_inv,mul_assoc]
  congr 2
  apply Finset.sum_congr rfl
  intro l hl
  unfold MellinPrimeSeparation.twistedCutoff
  ring

theorem source_fullEndpoint_eq_labelPolynomial {K : ℕ} (b : Bands K) (x : ℝ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    MajorArcLabelMass.fullEndpoint (b.group x) χ η lam Y t=
      (SignedDyadicCauchy.massNormalization b x:ℂ)*
        SignedMajorMellinIdentity.labelPolynomial Finset.univ
          (SignedCauchyExpansion.labelProduct b x) χ η Y lam t := by
  rw [fullEndpoint_eq_normalized_labelPolynomial]
  congr 1
  unfold SignedMajorMellinIdentity.labelPolynomial
  congr 1
  apply Finset.sum_congr (by ext; simp)
  intro l hl
  rfl

/-- Conjugation reflects both frequency and additive modulation, with the
literal conjugated character and cutoff. -/
theorem fullEndpoint_conjugate {ι : Type*} [Fintype ι] (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    conj (MajorArcLabelMass.fullEndpoint G χ η lam Y t)=
      MajorArcLabelMass.fullEndpoint G (star χ) (fun y=>conj (η y)) (-lam) Y (-t) := by
  simp only [MajorArcLabelMass.fullEndpoint,MellinPrimeSeparation.twistedCutoff,
    map_mul,map_sum,Complex.conj_ofReal,MulChar.star_apply,additivePhase_conj,
    SignedMajorMellinIdentity.archimedeanPhase_conj,neg_neg,neg_mul]
  simp only [←starRingEnd_apply]

/-- Real cutoffs give the same full endpoint norm at reflected frequency. -/
theorem fullEndpoint_conjugate_norm {ι : Type*} [Fintype ι] (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (hη : ∀y,conj (η y)=η y)
    (lam Y t : ℝ) :
    ‖MajorArcLabelMass.fullEndpoint G χ η lam Y t‖=
      ‖MajorArcLabelMass.fullEndpoint G (star χ) η (-lam) Y (-t)‖ := by
  have h := congrArg norm (fullEndpoint_conjugate G χ η lam Y t)
  simpa only [Complex.norm_conj,hη] using h

theorem eventually_full_endpoint_mean_square_Icc
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (δ C : ℝ) (hδ : 0<δ) (hC : 0≤C) :
    ∀ᶠL : ℝ in atTop,∀Hm Hn : ℝ,1≤Hm→1≤Hn→
      Real.exp (δ*L)≤Hm*Hn→Hm*Hn≤Real.exp (2*L)→
      ∀s t : Finset ℕ,InDyad Hm s→InDyad Hn t→
      ∀α β : ℕ→ℂ,(∀m∈s,‖α m‖≤L^C)→(∀n∈t,‖β n‖≤L^C)→
      ∀(k l : ℕ) (χ : DirichletCharacter ℂ k) (ψ : DirichletCharacter ℂ l),
      ∀(ι : Type*) [Fintype ι] (G : ι→Finset ℕ),
      (∀i,∀p∈G i,0<p)→(∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)→
      ∀(q : ℕ) (χlabel : DirichletCharacter ℂ q) (η : ℝ→ℂ),
      (∀y,‖η y‖≤1)→(∀y,η y≠0→y≤4)→∀lam Y : ℝ,0<Y→
      ∀a b : ℝ,a≤b→
      (∫v in Icc a b,‖MajorArcLabelMass.fullEndpoint G χlabel η lam Y v*
        longPolynomial s α Hm χ v*longPolynomial t β Hn ψ v‖^2)≤
        L^(4*C+6)*(1+(b-a)/(Hm*Hn)) := by
  filter_upwards [eventually_full_endpoint_mean_square hD δ C hδ hC] with L h
  intro Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ ι _ G hG hmass q χlabel η hη hηs lam Y hY a b hab
  have hh := h Hm Hn hm hn hmin hmax s t hs ht α β hα hβ k l χ ψ ι G hG hmass q χlabel η hη hηs lam Y hY a b hab
  simpa only [integral_Icc_eq_integral_Ioc,intervalIntegral.integral_of_le hab] using hh

theorem fullEndpoint_eq_filtered_labelPolynomial {ι : Type*} [Fintype ι]
    (G : ι→Finset ℕ) {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    MajorArcLabelMass.fullEndpoint G χ η lam Y t=
      (MajorArcLabelMass.normalization G:ℂ)*
        SignedMajorMellinIdentity.labelPolynomial
          (Finset.univ.filter (fun l : MajorArcLabelMass.Labels G=>η ((MajorArcLabelMass.product G l:ℝ)/Y)≠0))
          (MajorArcLabelMass.product G) χ η Y lam t := by
  rw [fullEndpoint_eq_normalized_labelPolynomial]
  congr 1
  unfold SignedMajorMellinIdentity.labelPolynomial
  rw [Finset.sum_filter]
  congr 1
  apply Finset.sum_congr rfl
  intro l hl
  split_ifs with h
  · rfl
  · simp only [not_ne_iff.mp h,zero_mul]

/-- The exact finite Mellin left endpoint has the norm of the full physical
label factor times its two long coefficient factors. -/
theorem normalizedLeft_fullEndpoint_norm {ι : Type*} [Fintype ι] (G : ι→Finset ℕ)
    {k : ℕ} (S T : Finset ℕ) (χ : SignedMajorCharacter.CharacterTuple k 6)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (Y Hm Hn lam t : ℝ) :
    ‖(MajorArcLabelMass.normalization G:ℂ)*
      SignedMajorMellinIdentity.normalizedLeft
        (Finset.univ.filter (fun l : MajorArcLabelMass.Labels G=>η ((MajorArcLabelMass.product G l:ℝ)/Y)≠0))
        (MajorArcLabelMass.product G) S T χ η α β Y Hm Hn lam t‖=
      ‖MajorArcLabelMass.fullEndpoint G (χ 1) η (-lam) Y t*
        longPolynomial S α Hm (χ 2) t*longPolynomial T β Hn (χ 3) t‖ := by
  rw [fullEndpoint_eq_filtered_labelPolynomial]
  simp only [SignedMajorMellinIdentity.normalizedLeft,norm_mul,LogPhaseProgression.phase_norm,one_mul]
  ring

theorem normalizedRight_fullEndpoint_norm {ι : Type*} [Fintype ι] (G : ι→Finset ℕ)
    {k : ℕ} (S T : Finset ℕ) (χ : SignedMajorCharacter.CharacterTuple k 6)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (Y Hm Hn lam t : ℝ) :
    ‖(MajorArcLabelMass.normalization G:ℂ)*
      SignedMajorMellinIdentity.normalizedRight
        (Finset.univ.filter (fun l : MajorArcLabelMass.Labels G=>η ((MajorArcLabelMass.product G l:ℝ)/Y)≠0))
        (MajorArcLabelMass.product G) S T χ η α β Y Hm Hn lam t‖=
      ‖MajorArcLabelMass.fullEndpoint G (χ 0) η lam Y t*
        longPolynomial S (fun n=>conj (α n)) Hm (χ 4) t*
        longPolynomial T (fun n=>conj (β n)) Hn (χ 5) t‖ := by
  rw [fullEndpoint_eq_filtered_labelPolynomial]
  simp only [SignedMajorMellinIdentity.normalizedRight,norm_mul,LogPhaseProgression.phase_norm,one_mul]
  ring

/-- The right Mellin endpoint uses the original coefficients at the reflected
frequency, so the source cancellation assumption is unchanged. -/
theorem normalizedRight_reflected_fullEndpoint_norm {ι : Type*} [Fintype ι] (G : ι→Finset ℕ)
    {k : ℕ} (S T : Finset ℕ) (χ : SignedMajorCharacter.CharacterTuple k 6)
    (η : ℝ→ℂ) (hη : ∀y,conj (η y)=η y) (α β : ℕ→ℂ) (Y Hm Hn lam t : ℝ) :
    ‖(MajorArcLabelMass.normalization G:ℂ)*
      SignedMajorMellinIdentity.normalizedRight
        (Finset.univ.filter (fun l : MajorArcLabelMass.Labels G=>η ((MajorArcLabelMass.product G l:ℝ)/Y)≠0))
        (MajorArcLabelMass.product G) S T χ η α β Y Hm Hn lam t‖=
      ‖MajorArcLabelMass.fullEndpoint G (star (χ 0)) η (-lam) Y (-t)*
        longPolynomial S α Hm (star (χ 4)) (-t)*
        longPolynomial T β Hn (star (χ 5)) (-t)‖ := by
  rw [normalizedRight_fullEndpoint_norm]
  simp only [norm_mul,fullEndpoint_conjugate_norm G (χ 0) η hη,
    SignedMajorMellinIdentity.longPolynomial_conjugate_norm]

attribute [-instance] endpointDecEq

/-- Source-band specialization of the filtered left-endpoint identity. -/
theorem source_normalizedLeft_fullEndpoint_norm {K : ℕ} (b : Bands K) (x : ℝ)
    {k : ℕ} (S T : Finset ℕ) (χ : SignedMajorCharacter.CharacterTuple k 6)
    (η : ℝ→ℂ) (α β : ℕ→ℂ) (Y Hm Hn lam t : ℝ) :
    ‖(SignedDyadicCauchy.massNormalization b x:ℂ)*
      SignedMajorMellinIdentity.normalizedLeft
        (Finset.univ.filter (fun l : SignedCauchyExpansion.LabelTuple b x=>
          η ((SignedCauchyExpansion.labelProduct b x l:ℝ)/Y)≠0))
        (SignedCauchyExpansion.labelProduct b x) S T χ η α β Y Hm Hn lam t‖=
      ‖MajorArcLabelMass.fullEndpoint (b.group x) (χ 1) η (-lam) Y t*
        longPolynomial S α Hm (χ 2) t*longPolynomial T β Hn (χ 3) t‖ := by
  have h := normalizedLeft_fullEndpoint_norm (b.group x) S T χ η α β Y Hm Hn lam t
  rw [←h]
  congr 3
  ext l
  simp only [Finset.mem_filter,Finset.mem_univ,true_and,
    SignedCauchyExpansion.labelProduct,MajorArcLabelMass.product]

/-- Source-band specialization of the reflected right-endpoint identity. -/
theorem source_normalizedRight_reflected_fullEndpoint_norm {K : ℕ} (b : Bands K) (x : ℝ)
    {k : ℕ} (S T : Finset ℕ) (χ : SignedMajorCharacter.CharacterTuple k 6)
    (η : ℝ→ℂ) (hη : ∀y,conj (η y)=η y) (α β : ℕ→ℂ) (Y Hm Hn lam t : ℝ) :
    ‖(SignedDyadicCauchy.massNormalization b x:ℂ)*
      SignedMajorMellinIdentity.normalizedRight
        (Finset.univ.filter (fun l : SignedCauchyExpansion.LabelTuple b x=>
          η ((SignedCauchyExpansion.labelProduct b x l:ℝ)/Y)≠0))
        (SignedCauchyExpansion.labelProduct b x) S T χ η α β Y Hm Hn lam t‖=
      ‖MajorArcLabelMass.fullEndpoint (b.group x) (star (χ 0)) η (-lam) Y (-t)*
        longPolynomial S α Hm (star (χ 4)) (-t)*
        longPolynomial T β Hn (star (χ 5)) (-t)‖ := by
  have h := normalizedRight_reflected_fullEndpoint_norm (b.group x) S T χ η hη α β Y Hm Hn lam t
  rw [←h]
  congr 3
  ext l
  simp only [Finset.mem_filter,Finset.mem_univ,true_and,
    SignedCauchyExpansion.labelProduct,MajorArcLabelMass.product]

end Elliptic.Operator.MajorArcFullEndpointMeanSquare
