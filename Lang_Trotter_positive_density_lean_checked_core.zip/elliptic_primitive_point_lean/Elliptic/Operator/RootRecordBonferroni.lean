module

public import Elliptic.Operator.RootRecordIntegral
public import Elliptic.Operator.InactivePrimeBonferroni
public import Elliptic.Operator.SignedBonferroniTransfer
public import Elliptic.Operator.BonferroniMonomialCount

/-!
# Literal active/inactive decomposition of the numerical original record

The active primes keep their complete line factor. At all other primes,
the loss is the actual union of inactive hits. Setting the loss to zero
at active primes permits a common finite subset family for every record.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.RootRecordBonferroni
open scoped BigOperators
open OriginalPathWeights IntegerRootReplacement SourceBonferroni
open SignedBonferroniTransfer BonferroniMonomialCount
attribute [local instance] Classical.propDecidable
set_option backward.isDefEq.respectTransparency false

variable {K J N R Q : ℕ}

def activePrimes (rec : Record K J N R Q) : Finset ℕ :=
  activePrimeSet (fun j i a=>(rec.2.1 j i a).val)

theorem mem_activePrimes (rec : Record K J N R Q) (p : ℕ) :
    p∈activePrimes rec ↔ ∃j i a,(rec.2.1 j i a).val=p := by
  simp [activePrimes,activePrimeSet]

theorem activeVisits_eq_empty (rec : Record K J N R Q) (p : ℕ)
    (hp : p∉activePrimes rec) : activeVisits rec p=∅ := by
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro t ht
  obtain ⟨_,j,_,i,a,ha⟩ := Finset.mem_filter.mp ht
  exact hp ((mem_activePrimes rec p).mpr ⟨j,i,a,ha⟩)

def activeFactor (rec : Record K J N R Q) (η : ℕ→ℝ)
    (ℓ : ∀p : activePrimes rec,Option (ZMod p)) : ℝ :=
  ∏p : activePrimes rec, IndependentLineNormalization.lineFactor
    (Finset.range (N+1)) (activeVisits rec p)
    (fun t=>primeResidueAnchor p (positionAt rec t)) η (ℓ p)

def loss (rec : Record K J N R Q) (η : ℕ→ℝ) (p : ℕ) (ℓ : Option (ZMod p)) : ℝ :=
  if p∈activePrimes rec then 0 else
    inactiveLoss (Finset.range (N+1)) (fun t=>primeResidueAnchor p (positionAt rec t)) η ℓ

theorem activeFactor_bounds (rec : Record K J N R Q) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (ℓ : ∀p : activePrimes rec,Option (ZMod p)) :
    0≤activeFactor rec η ℓ ∧ activeFactor rec η ℓ≤1 := by
  have h (p : activePrimes rec) := lineFactor_bounds (Finset.range (N+1)) (activeVisits rec p)
    (fun t=>primeResidueAnchor p (positionAt rec t)) η (ℓ p)
    (fun j hj=>hη j (Finset.mem_range.mp hj))
  exact ⟨Finset.prod_nonneg fun p _=>(h p).1,
    Finset.prod_le_one₀ (fun p _=>(h p).1) (fun p _=>(h p).2)⟩

theorem loss_bounds (rec : Record K J N R Q) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (p : ℕ) (ℓ : Option (ZMod p)) :
    0≤loss rec η p ℓ ∧ loss rec η p ℓ≤1 := by
  unfold loss
  split_ifs
  · norm_num
  · have h := inactiveLoss_bounds (Finset.range (N+1))
      (fun t=>primeResidueAnchor p (positionAt rec t)) η
      (fun j hj=>hη j (Finset.mem_range.mp hj)) ℓ
    exact ⟨h.1,h.2.1⟩

theorem residueFactor_split (rec : Record K J N R Q) (primes : Finset ℕ)
    (hA : activePrimes rec⊆primes) (η : ℕ→ℝ) (ℓ : (p : ℕ)→Option (ZMod p)) :
    residueFactor rec primes η ℓ = activeFactor rec η (fun p=>ℓ p) *
      ∏p∈primes,(1-loss rec η p (ℓ p)) := by
  have hsplit := Finset.prod_sdiff (f:=fun p=>IndependentLineNormalization.lineFactor
    (Finset.range (N+1)) (activeVisits rec p)
    (fun t=>primeResidueAnchor p (positionAt rec t)) η (ℓ p)) hA
  unfold residueFactor
  rw [←hsplit,mul_comm]
  congr 1
  · exact (Finset.prod_coe_sort _ _).symm
  · rw [←Finset.prod_sdiff (f:=fun p=>1-loss rec η p (ℓ p)) hA]
    have hz : (∏p∈activePrimes rec,(1-loss rec η p (ℓ p)))=1 := by
      apply Finset.prod_eq_one
      intro p hp
      simp [loss,hp]
    rw [hz,mul_one]
    apply Finset.prod_congr rfl
    intro p hp
    have hn := (Finset.mem_sdiff.mp hp).2
    simp [IndependentLineNormalization.lineFactor,activeVisits_eq_empty rec p hn,
      loss,hn,inactiveLoss]

/-- Exact signed expansion indexed by the same subset type that is
charged in the root replacement coefficient budget. -/
theorem truncation_subsets (primes : Finset ℕ) (w : ℕ→ℝ) (T : ℕ) (a : ℂ) :
    a*(truncation primes w T:ℝ) = ∑s∈truncatedSubsets primes T,
      (-1:ℂ)^s.card*(a*∏p∈s,(w p:ℂ)) := by
  rw [truncatedSubsets_eq_disjiUnion,Finset.sum_disjiUnion,truncation_eq_sum]
  simp only [Complex.ofReal_sum,Complex.ofReal_mul,Complex.ofReal_pow,
    Complex.ofReal_neg,Complex.ofReal_one,elementary,Complex.ofReal_prod,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  apply Finset.sum_congr rfl
  intro s hs
  rw [(Finset.mem_powersetCard.mp hs).2]
  ring

/-- The bounded, coupled local test has exactly the active-union-subset
modulus. Its sign is retained inside the test. -/
def subsetTest (rec : Record K J N R Q) (η : ℕ→ℝ) (s : Finset ℕ)
    (ℓ : ∀p : ↥(activePrimes rec∪s),Option (ZMod p)) : ℂ :=
  (-1:ℂ)^s.card * coupledSubsetTest (fun p=>Option (ZMod p)) (activePrimes rec) s
    (fun a=>(activeFactor rec η a:ℂ)) (loss rec η) ℓ

theorem subsetTest_restrict (rec : Record K J N R Q) (η : ℕ→ℝ) (s : Finset ℕ)
    (ℓ : (p : ℕ)→Option (ZMod p)) :
    subsetTest rec η s (fun p=>ℓ p) = (-1:ℂ)^s.card *
      ((activeFactor rec η (fun p=>ℓ p):ℂ)*∏p∈s,(loss rec η p (ℓ p):ℂ)) := by
  rw [subsetTest,coupledSubsetTest_restrict]

theorem subsetTest_norm_le (rec : Record K J N R Q) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (s : Finset ℕ)
    (ℓ : ∀p : ↥(activePrimes rec∪s),Option (ZMod p)) : ‖subsetTest rec η s ℓ‖≤1 := by
  rw [subsetTest,norm_mul,norm_pow,norm_neg,norm_one,one_pow,one_mul]
  apply coupledSubsetTest_norm_le
  · intro a
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (activeFactor_bounds rec η hη a).1]
    exact (activeFactor_bounds rec η hη a).2
  · intro p hp l
    exact loss_bounds rec η hη p l

theorem truncation_subsetTests (rec : Record K J N R Q) (primes : Finset ℕ)
    (η : ℕ→ℝ) (ℓ : (p : ℕ)→Option (ZMod p)) (T : ℕ) :
    (activeFactor rec η (fun p=>ℓ p):ℂ)*
      (truncation primes (fun p=>loss rec η p (ℓ p)) T:ℝ) =
      ∑s∈truncatedSubsets primes T,subsetTest rec η s (fun p=>ℓ p) := by
  simp_rw [subsetTest_restrict]
  exact truncation_subsets _ _ _ _

/-- Complex weights, including all archimedean phases, obey a norm
remainder estimate; no signed sandwich is used. -/
theorem residue_remainder (rec : Record K J N R Q) (primes : Finset ℕ)
    (hA : activePrimes rec⊆primes) (η : ℕ→ℝ)
    (hη : ∀j<N+1,0≤η j ∧ η j≤1) (ℓ : (p : ℕ)→Option (ZMod p))
    (m : ℕ) (a : ℂ) (ha : ‖a‖≤1) :
    ‖a*(residueFactor rec primes η ℓ:ℂ) -
      a*∑s∈truncatedSubsets primes (2*m),subsetTest rec η s (fun p=>ℓ p)‖ ≤
      elementary primes (fun p=>loss rec η p (ℓ p)) (2*m+1) := by
  rw [residueFactor_split rec primes hA,←truncation_subsetTests]
  rw [Complex.ofReal_mul]
  simp only [←mul_assoc]
  apply multiplier_error_le
  · intro p hp
    exact loss_bounds rec η hη p (ℓ p)
  · rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,
      abs_of_nonneg (activeFactor_bounds rec η hη _).1]
    exact mul_le_one₀ ha (activeFactor_bounds rec η hη _).1 (activeFactor_bounds rec η hη _).2

end Elliptic.Operator.RootRecordBonferroni
