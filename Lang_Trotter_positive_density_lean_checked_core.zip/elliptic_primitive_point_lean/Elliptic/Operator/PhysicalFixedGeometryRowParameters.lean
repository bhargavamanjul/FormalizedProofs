module
public import Elliptic.Operator.PhysicalFixedGeometryRow
public import Elliptic.Operator.MomentParameters

/-! The source fixed-list geometry row is uniformly polynomial in log x. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalFixedGeometryRow
open Filter
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false

 theorem eventually_row_constant_le (A C Aη Aψ : ℝ)
    (hA : 0≤A) (hC : 0≤C) (hη : 0≤Aη) (hψ : 0≤Aψ) :
    ∀ᶠ L : ℝ in atTop,
      Aη^2*Aψ*(33+132*(2*C+1)*(L^A)^3)≤L^(3*A+1) := by
  let D := Aη^2*Aψ*(33+132*(2*C+1))
  filter_upwards [eventually_ge_atTop (1:ℝ),eventually_ge_atTop D] with L hL hD
  have hp : 1≤(L^A)^3 := one_le_pow₀ (Real.one_le_rpow hL hA)
  have hLp : 0<L := by linarith
  calc
    _ ≤ D*(L^A)^3 := by dsimp [D];nlinarith [mul_nonneg (sq_nonneg Aη) hψ]
    _ ≤ L*(L^A)^3 := mul_le_mul_of_nonneg_right hD (by positivity)
    _ = _ := by
      rw [←Real.rpow_mul_natCast (by linarith : 0≤L)]
      rw [Real.rpow_add hLp (3*A) 1,Real.rpow_one]
      norm_num only [Nat.cast_ofNat]
      rw [show A*3=3*A by ring,mul_comm]

 theorem source_subtype_row_le {I : Type*} [Fintype I] {P : I→Type*} {J : ℕ}
    (positions : Finset (ℤ×ℤ)) (value : ∀i,P i→ℕ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y H C Aη Aψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (η ψ : ℝ→ℂ)
    (hη : ∀t,‖η t‖≤Aη) (hψ : ∀t,‖ψ t‖≤Aψ)
    (hsupport : ∀t,ψ t≠0→|t|≤C) (σ : ℤ)
    (z : positions) (a b : PhysicalActiveLists P J) :
    (∑ w:positions,‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w.val b‖)≤Aη^2*Aψ*(33+132*(2*C+1)*H^3) := by
  rw [show (∑ w:positions,‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w.val b‖) =
      ∑ w∈positions,‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w b‖ from
    (Finset.sum_subtype positions (fun _ => Iff.rfl)
      (fun w : ℤ×ℤ => ‖sourcePhysicalEdgeGeometry value good u v r U W d₀ Y η ψ
        (sourceMajorArcs H Y) σ z.val a w b‖)).symm]
  exact source_row_le value good u v r U W d₀ Y H C Aη Aψ
    hU hd hY hH hC hAη hAψ η ψ hη hψ hsupport σ z.val a b positions

 theorem oriented_subtype_row_le {I : Type*} [Fintype I] {P : I→Type*} {J : ℕ}
    (adjoint : Bool) (positions : Finset (ℤ×ℤ)) (value : ∀i,P i→ℕ)
    (good : (ℤ×ℤ)→PhysicalActiveLists P J→Prop)
    (u v r U W d₀ Y H C Aη Aψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 1≤Y) (hH : 0≤H) (hC : 0≤C)
    (hAη : 0≤Aη) (hAψ : 0≤Aψ) (η ψ : ℝ→ℂ)
    (hη : ∀t,‖η t‖≤Aη) (hψ : ∀t,‖ψ t‖≤Aψ)
    (hsupport : ∀t,ψ t≠0→|t|≤C) (σ : ℤ)
    (z : positions) (a b : PhysicalActiveLists P J) :
    (∑ w:positions,‖orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w.val b‖)≤Aη^2*Aψ*(33+132*(2*C+1)*H^3) := by
  rw [show (∑ w:positions,‖orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w.val b‖) =
      ∑ w∈positions,‖orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ
      (sourceMajorArcs H Y) σ z.val a w b‖ from
    (Finset.sum_subtype positions (fun _ => Iff.rfl)
      (fun w : ℤ×ℤ => ‖orientedSourceEdgeGeometry adjoint value good u v r U W d₀ Y η ψ
        (sourceMajorArcs H Y) σ z.val a w b‖)).symm]
  exact oriented_row_le adjoint value good u v r U W d₀ Y H C Aη Aψ
    hU hd hY hH hC hAη hAψ η ψ hη hψ hsupport σ z.val a b positions

end Elliptic.Operator.PhysicalFixedGeometryRow
