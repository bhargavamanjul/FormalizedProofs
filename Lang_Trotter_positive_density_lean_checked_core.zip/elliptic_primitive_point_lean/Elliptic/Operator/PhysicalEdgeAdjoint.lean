module

public import Elliptic.Operator.EdgeIndexedTransfer
public import Elliptic.Operator.GroupedGhostNorm
public import Elliptic.Operator.PhysicalEdgeReindexing

/-!
# The full physical edge as a compressed symmetric transfer

The local symmetric transfer is assembled with every actual group,
endpoint permutation, target position, geometric restriction, and the total
memory cutoff. This identifies the literal physical action on arbitrary
coupled functions of memory bags. No operator-adjoint identity is assumed.
The grouped measured reversal is derived on the finite bag quotient with
its actual factorial measure, for arbitrary coupled endpoint restrictions.

Under the existing factorial memory measure, reversal exchanges the local
store coefficient 1 and promotion coefficient 1/V. Thus this file does not
assert self-adjointness of the original physical edge with unchanged V.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance physicalEdgeAdjointDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

namespace PhysicalEdgeAdjoint

/-- Finite bag coordinates represented by the actual ordered memory space. -/
def memoryBagRange (X : Type*) [Fintype X] (B : ℕ) : Finset (Multiset X) :=
  Finset.univ.image (fun m : MemoryState X B => tupleBag m.values)

abbrev MemoryBag (X : Type*) [Fintype X] (B : ℕ) := ↥(memoryBagRange X B)

/-- Forget order, retaining the actual memory bag with all multiplicities. -/
def memoryBagOf {X : Type*} [Fintype X] {B : ℕ} (m : MemoryState X B) : MemoryBag X B :=
  ⟨tupleBag m.values,Finset.mem_image.mpr ⟨m,Finset.mem_univ _,rfl⟩⟩

@[simp] theorem memoryBagOf_card {X : Type*} [Fintype X] {B : ℕ} (m : MemoryState X B) :
    (memoryBagOf m).val.card = m.size := by
  simp [memoryBagOf,tupleBag_card]

variable {P : Type*} [Fintype P] {Line : P → Type*} [∀ p, Fintype (Line p)] {B : ℕ}

abbrev EdgeBagOutput := P × MemoryBag (AnchoredParticle P Line) B

/-- Actual valid local choice, and a harmless fallback on invalid choices. -/
def localOutput (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m) :
    EdgeBagOutput (P:=P) (Line:=Line) (B:=B) :=
  if hc : EdgeGroupChoice.Valid targetAnchor m c then
    (edgeTargetPrime m c,memoryBagOf (edgeGroupOutput sourceAnchor source m c hc.2))
  else (source,memoryBagOf m)

/-- Signed local coefficient, exactly including both endpoint damping factors. -/
def localCoefficient (ν : P → ℝ) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B) (c : EdgeGroupChoice m) : ℂ :=
  if hc : EdgeGroupChoice.Valid targetAnchor m c then
    (edgeGroupWeight ν V ρ sourceAnchor targetAnchor source m c hc.2 : ℂ)
  else 0

/-- Complete local transfer matrix on the finite quotient of actual memories. -/
def localBagKernel (ν : P → ℝ) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (t : EdgeBagOutput (P:=P) (Line:=Line) (B:=B)) : ℂ :=
  bagLabelEdgeApply B (fun p => (ν p : ℂ)) sourceAnchor targetAnchor 1 (V : ℂ)⁻¹
    (bagSurvival sourceAnchor (ρ : ℂ)) (bagSurvival targetAnchor (ρ : ℂ))
    (fun _ _ => 1)
    (fun q b => if q=t.1 ∧ b=t.2.val then 1 else 0) source (tupleBag m.values)

/-- The symmetric local matrix is derived from the actual indexed choices;
it includes every repeated old-particle retrieval with its multiplicity. -/
theorem localBagKernel_eq_choices (ν : P → ℝ) (hν : ∀ p, ν p ≠ 0) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (t : EdgeBagOutput (P:=P) (Line:=Line) (B:=B)) :
    localBagKernel ν V ρ sourceAnchor targetAnchor source m t =
      ∑ c : EdgeGroupChoice m, localCoefficient ν V ρ sourceAnchor targetAnchor source m c *
        (if localOutput sourceAnchor targetAnchor source m c = t then 1 else 0) := by
  have he := edgeGroupApply_eq_bagTransfers ν hν V ρ sourceAnchor targetAnchor source
    (fun q b => if q=t.1 ∧ b=t.2.val then 1 else 0) m
  have hb : localBagKernel ν V ρ sourceAnchor targetAnchor source m t =
      edgeGroupApply ν V ρ sourceAnchor targetAnchor source
        (fun out => if out.1=t.1 ∧ tupleBag out.2.values=t.2.val then 1 else 0) m := by
    rw [he]
    simp only [localBagKernel,bagLabelEdgeApply,one_mul]
  rw [hb]
  unfold edgeGroupApply
  apply Finset.sum_congr rfl
  intro c _
  by_cases hc : EdgeGroupChoice.Valid targetAnchor m c
  · rcases t with ⟨q,b⟩
    simp only [localCoefficient,localOutput,dite_eq_left hc,Prod.mk.injEq,
      Subtype.ext_iff,memoryBagOf]
  · simp [localCoefficient,localOutput,hc]


/-- Literal fixed-endpoint indexed transfer with the two endpoint dampings.
The store and promotion coefficients are independent, so reversal can be
stated without silently changing the original 1 and 1/V normalization. -/
def dampedFixedTargetApply {R : Type*} [Field R]
    (ν : P → R) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) : R :=
  sourceDamping (tupleBag m.values) *
    fixedTargetEdgeChoiceApply ν store promote sourceAnchor targetAnchor source target
      (fun t => targetDamping t * F t) m

/-- The damped transfer is identified directly with the actual indexed
choice sum before any measured reversal is invoked. -/
theorem dampedFixedTargetApply_eq_bagTransfer {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F : Multiset (AnchoredParticle P Line) → R)
    (m : MemoryState (AnchoredParticle P Line) B) :
    dampedFixedTargetApply ν store promote sourceAnchor targetAnchor source target
      sourceDamping targetDamping F m =
    bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
      (anchorPrime sourceAnchor source) (anchorPrime targetAnchor target)
      (ν source) (ν target) store promote sourceDamping targetDamping F (tupleBag m.values) := by
  unfold dampedFixedTargetApply
  rw [fixedTargetEdgeChoiceApply_eq_bagTransfer ν hν]
  simp only [bagEdgeTransfer,one_mul]

/-- Measured adjoint for the literal indexed local edge. The measure is the
actual factorial measure on ordered memories, not a supplied adjoint kernel.
Reversal exchanges both endpoint dampings and the store/promotion coefficients. -/
theorem dampedFixedTargetApply_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping F G : Multiset (AnchoredParticle P Line) → R) :
    ν source * (∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun x : AnchoredParticle P Line => ν x.1) * G (tupleBag m.values) *
        dampedFixedTargetApply ν store promote sourceAnchor targetAnchor source target
          sourceDamping targetDamping F m) =
    ν target * (∑ m : MemoryState (AnchoredParticle P Line) B,
      m.mass (fun x : AnchoredParticle P Line => ν x.1) * F (tupleBag m.values) *
        dampedFixedTargetApply ν promote store targetAnchor sourceAnchor target source
          targetDamping sourceDamping G m) := by
  have he := bagEdgeTransfer_adjoint B (fun x : AnchoredParticle P Line => ν x.1)
    (anchorPrime sourceAnchor source) (anchorPrime targetAnchor target)
    (ν source) (ν target) store promote (hν source) (hν target)
    sourceDamping targetDamping F G
  rw [symmetricMemoryIntegral_eq_sum_states,symmetricMemoryIntegral_eq_sum_states] at he
  simpa only [dampedFixedTargetApply_eq_bagTransfer ν hν,mul_assoc] using he

/-- Summing the literal fixed-endpoint adjoint transposes an arbitrary joint
endpoint multiplier. This is the actual one-group reversal needed inside
the grouped construction; neither multiplier factorization nor symmetry is used. -/
theorem dampedLabelApply_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (geometry : P → P → R) (F G : P → Multiset (AnchoredParticle P Line) → R) :
    (∑ p, ∑ q, geometry p q * (ν p *
      ∑ m : MemoryState (AnchoredParticle P Line) B,
        m.mass (fun x : AnchoredParticle P Line => ν x.1) * G p (tupleBag m.values) *
          dampedFixedTargetApply ν store promote sourceAnchor targetAnchor p q
            sourceDamping targetDamping (F q) m)) =
    (∑ q, ∑ p, geometry p q * (ν q *
      ∑ m : MemoryState (AnchoredParticle P Line) B,
        m.mass (fun x : AnchoredParticle P Line => ν x.1) * F q (tupleBag m.values) *
          dampedFixedTargetApply ν promote store targetAnchor sourceAnchor q p
            targetDamping sourceDamping (G p) m)) := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q _
  apply Finset.sum_congr rfl
  intro p _
  rw [dampedFixedTargetApply_adjoint ν hν]

/-- The quotient measure is the sum of the actual ordered-memory masses
over its bag fiber. It retains repeated-particle factorial multiplicities. -/
def memoryBagMass {X R : Type*} [Fintype X] [Field R] (μ : X → R)
    (b : MemoryBag X B) : R :=
  ∑ m : MemoryState X B, if tupleBag m.values = b.val then m.mass μ else 0

/-- Fixed-label kernel on actual finite memory bags, with independent
store and promotion normalizations. -/
def dampedBagKernel {R : Type*} [Field R]
    (ν : P → R) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (s t : MemoryBag (AnchoredParticle P Line) B) : R :=
  bagEdgeTransfer B (fun x : AnchoredParticle P Line => ν x.1)
    (anchorPrime sourceAnchor source) (anchorPrime targetAnchor target)
    (ν source) (ν target) store promote sourceDamping targetDamping
    (fun b => if b = t.val then 1 else 0) s.val

/-- The local kernel in the full physical compression is exactly the
fixed-label quotient kernel at its original store/promotion normalization. -/
theorem localBagKernel_eq_damped (ν : P → ℝ) (V ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source : P)
    (m : MemoryState (AnchoredParticle P Line) B)
    (t : EdgeBagOutput (P:=P) (Line:=Line) (B:=B)) :
    localBagKernel ν V ρ sourceAnchor targetAnchor source m t =
      dampedBagKernel (fun p => (ν p : ℂ)) 1 (V : ℂ)⁻¹ sourceAnchor targetAnchor
        source t.1 (bagSurvival sourceAnchor (ρ : ℂ)) (bagSurvival targetAnchor (ρ : ℂ))
        (memoryBagOf m) t.2 := by
  unfold localBagKernel bagLabelEdgeApply
  rw [Finset.sum_eq_single t.1]
  · simp only [one_mul,dampedBagKernel,memoryBagOf,true_and]
  · intro q _ hq
    simp [hq,bagEdgeTransfer,bagDeletion,bagBirth,memoryBirthIntegral]
  · simp

/-- Pointwise measured reversal on the actual bag quotient. This is
derived by testing the indexed local pairing against two bag indicators. -/
theorem dampedBagKernel_balance {R : Type*} [Field R] [CharZero R]
    (ν : P → R) (hν : ∀ p, ν p ≠ 0) (store promote : R)
    (sourceAnchor targetAnchor : ∀ p, Line p) (source target : P)
    (sourceDamping targetDamping : Multiset (AnchoredParticle P Line) → R)
    (s t : MemoryBag (AnchoredParticle P Line) B) :
    ν source * memoryBagMass (fun x : AnchoredParticle P Line => ν x.1) s *
      dampedBagKernel ν store promote sourceAnchor targetAnchor source target
        sourceDamping targetDamping s t =
    ν target * memoryBagMass (fun x : AnchoredParticle P Line => ν x.1) t *
      dampedBagKernel ν promote store targetAnchor sourceAnchor target source
        targetDamping sourceDamping t s := by
  have collapse (ν : P → R) (a b : P) (st pr : R)
      (sa ta : ∀ p, Line p)
      (sd td : Multiset (AnchoredParticle P Line) → R)
      (x y : MemoryBag (AnchoredParticle P Line) B) :
      (∑ m : MemoryState (AnchoredParticle P Line) B,
        m.mass (fun z => ν z.1) * (if tupleBag m.values = x.val then 1 else 0) *
          bagEdgeTransfer B (fun z : AnchoredParticle P Line => ν z.1)
            (anchorPrime sa a) (anchorPrime ta b) (ν a) (ν b) st pr sd td
            (fun z => if z = y.val then 1 else 0) (tupleBag m.values)) =
      memoryBagMass (fun z : AnchoredParticle P Line => ν z.1) x *
        dampedBagKernel ν st pr sa ta a b sd td x y := by
    unfold memoryBagMass
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro m _
    by_cases hm : tupleBag m.values = x.val
    · simp only [hm,ite_true,mul_one,dampedBagKernel]
    · simp [hm]
  have he := dampedFixedTargetApply_adjoint (B:=B) ν hν store promote sourceAnchor targetAnchor
    source target sourceDamping targetDamping
    (fun b => if b = t.val then 1 else 0) (fun b => if b = s.val then 1 else 0)
  simp_rw [dampedFixedTargetApply_eq_bagTransfer ν hν] at he
  rw [collapse,collapse] at he
  simpa only [mul_assoc] using he

variable {I Z : Type*} [Fintype I]
variable {P : I → Type*} [∀ i, Fintype (P i)]
variable {Line : ∀ i, P i → Type*} [∀ i p, Fintype (Line i p)] {J B : ℕ}

abbrev GroupedBagOutput := ∀ i, P i × MemoryBag (AnchoredParticle (P i) (Line i)) B

/-- Actual grouped active-prime and factorial bag measure. -/
def groupedBagMass {R : Type*} [Field R] (ν : ∀ i, P i → R)
    (s : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) : R :=
  ∏ i, ν i (s i).1 * memoryBagMass (fun x : AnchoredParticle (P i) (Line i) => ν i x.1) (s i).2

/-- The grouped local kernel retains every memory coordinate, allowing an
arbitrary coupled endpoint multiplier and arbitrary coupled test functions. -/
def groupedDampedBagKernel {R : Type*} [Field R]
    (ν : ∀ i, P i → R) (store promote : I → R)
    (sourceAnchor targetAnchor : ∀ i p, Line i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (P i) (Line i)) → R)
    (s t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) : R :=
  ∏ i, dampedBagKernel (ν i) (store i) (promote i) (sourceAnchor i) (targetAnchor i)
    (s i).1 (t i).1 (sourceDamping i) (targetDamping i) (s i).2 (t i).2

/-- Full grouped pointwise balance, derived from each literal indexed
local edge. No product assumption is imposed on a later test function. -/
theorem groupedDampedBagKernel_balance {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0) (store promote : I → R)
    (sourceAnchor targetAnchor : ∀ i p, Line i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (P i) (Line i)) → R)
    (s t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) :
    groupedBagMass ν s * groupedDampedBagKernel ν store promote sourceAnchor targetAnchor
      sourceDamping targetDamping s t =
    groupedBagMass ν t * groupedDampedBagKernel ν promote store targetAnchor sourceAnchor
      targetDamping sourceDamping t s := by
  simp only [groupedBagMass,groupedDampedBagKernel,← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  exact dampedBagKernel_balance (ν i) (hν i) (store i) (promote i)
    (sourceAnchor i) (targetAnchor i) (s i).1 (t i).1
    (sourceDamping i) (targetDamping i) (s i).2 (t i).2

/-- Complete grouped measured reversal for arbitrary coupled tests and
joint endpoint restrictions (including total memory cutoffs). The endpoint
multiplier is transposed and every store/promotion coefficient is exchanged. -/
theorem groupedDampedBagKernel_adjoint {R : Type*} [Field R] [CharZero R]
    (ν : ∀ i, P i → R) (hν : ∀ i p, ν i p ≠ 0) (store promote : I → R)
    (sourceAnchor targetAnchor : ∀ i p, Line i p)
    (sourceDamping targetDamping : ∀ i, Multiset (AnchoredParticle (P i) (Line i)) → R)
    (geometry : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) →
      GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → R)
    (F G : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → R) :
    (∑ s, groupedBagMass ν s * G s * ∑ t, geometry s t *
      groupedDampedBagKernel ν store promote sourceAnchor targetAnchor sourceDamping targetDamping s t * F t) =
    ∑ t, groupedBagMass ν t * F t * ∑ s, geometry s t *
      groupedDampedBagKernel ν promote store targetAnchor sourceAnchor targetDamping sourceDamping t s * G s := by
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro t _
  apply Finset.sum_congr rfl
  intro s _
  have h := groupedDampedBagKernel_balance ν hν store promote sourceAnchor targetAnchor
    sourceDamping targetDamping s t
  calc
    _ = (groupedBagMass ν s * groupedDampedBagKernel ν store promote sourceAnchor targetAnchor
        sourceDamping targetDamping s t) * (geometry s t * F t * G s) := by ring
    _ = (groupedBagMass ν t * groupedDampedBagKernel ν promote store targetAnchor sourceAnchor
        targetDamping sourceDamping t s) * (geometry s t * F t * G s) := by rw [h]
    _ = _ := by ring

/-- Literal product of all independent local indexed choices. Global
geometry and the total cutoff will stay in the arbitrary coupled test. -/
def groupedChoiceApply (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (source : ∀ i, P i)
    (F : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → ℂ)
    (m : PhysicalMemories P Line B) : ℂ :=
  ∑ c : ∀ i, EdgeGroupChoice (m i),
    (∏ i, localCoefficient (ν i) (V i) ρ (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i)) *
      F (fun i => localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i))

/-- Full coupled symmetric transfer, with no factorization assumption on F. -/
def groupedSymmetricApply (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (source : ∀ i, P i)
    (F : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → ℂ)
    (m : PhysicalMemories P Line B) : ℂ :=
  ∑ t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B),
    (∏ i, localBagKernel (ν i) (V i) ρ (sourceAnchor i) (targetAnchor i) (source i) (m i) (t i)) * F t

/-- The grouped kernel governed by the measured reversal is the actual
grouped symmetric transfer used in the full physical-edge identity. -/
theorem groupedSymmetricApply_eq_dampedKernel
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (source : ∀ i, P i)
    (F : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → ℂ)
    (m : PhysicalMemories P Line B) :
    groupedSymmetricApply ν V ρ sourceAnchor targetAnchor source F m =
      ∑ t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B),
        groupedDampedBagKernel (fun i p => (ν i p : ℂ)) (fun _ => 1) (fun i => (V i : ℂ)⁻¹)
          sourceAnchor targetAnchor
          (fun i => bagSurvival (sourceAnchor i) (ρ : ℂ))
          (fun i => bagSurvival (targetAnchor i) (ρ : ℂ))
          (fun i => (source i,memoryBagOf (m i))) t * F t := by
  simp only [groupedSymmetricApply,groupedDampedBagKernel,localBagKernel_eq_damped]

/-- Tensor assembly is proved on arbitrary coupled quotient tests, rather
than assumed after checking only products of one-group functions. -/
theorem groupedChoiceApply_eq_symmetric (ν : ∀ i, P i → ℝ)
    (hν : ∀ i p, ν i p ≠ 0) (V : I → ℝ) (ρ : ℝ)
    (sourceAnchor targetAnchor : ∀ i p, Line i p) (source : ∀ i, P i)
    (F : GroupedBagOutput (P:=P) (Line:=Line) (B:=B) → ℂ)
    (m : PhysicalMemories P Line B) :
    groupedChoiceApply ν V ρ sourceAnchor targetAnchor source F m =
      groupedSymmetricApply ν V ρ sourceAnchor targetAnchor source F m := by
  unfold groupedSymmetricApply
  simp_rw [localBagKernel_eq_choices _ (hν _),Fintype.prod_sum,Finset.sum_mul]
  rw [Finset.sum_comm]
  unfold groupedChoiceApply
  apply Finset.sum_congr rfl
  intro c _
  simp_rw [Finset.prod_mul_distrib]
  have hδ (t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) :
      (∏ i, if localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i) = t i
        then (1:ℂ) else 0) =
        if (fun i => localOutput (sourceAnchor i) (targetAnchor i) (source i) (m i) (c i)) = t then 1 else 0 :=
    product_coordinate_indicator _ t
  simp_rw [hδ]
  simp [mul_ite]

/-- The unpermuted target active lists retain every actual shared slot. -/
def targetLists (a : PhysicalActiveLists P J)
    (σ : ∀ _i : I, Equiv.Perm (Fin (J+1))) (q : ∀ i, P i) : PhysicalActiveLists P J :=
  fun i => Fin.lastCases (q i) (fun t => a i (σ i t.castSucc))

/-- The coupled test retains the full geometry, both endpoint permutations,
and the single total-memory cutoff of the physical state space. -/
def compressedTest
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (H : Z → PhysicalActiveLists P J → (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (sourceZ targetZ : Z) (a : PhysicalActiveLists P J)
    (σ τ : ∀ _i : I, Equiv.Perm (Fin (J+1)))
    (t : GroupedBagOutput (P:=P) (Line:=Line) (B:=B)) : ℂ :=
  geometry sourceZ (fun i j => a i (σ i j)) targetZ (targetLists a σ (fun i => (t i).1)) *
    if (∑ i, (t i).2.val.card) ≤ B then
      H targetZ (fun i j => targetLists a σ (fun i => (t i).1) i (τ i j)) (fun i => (t i).2.val)
    else 0

/-- Full endpoint-averaged, target-position-integrated symmetric transfer. -/
def symmetricPhysicalApply [Fintype Z]
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (H : Z → PhysicalActiveLists P J → (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) : ℂ :=
  (endpointPermutationWeight I J : ℂ) *
    ∑ z : Z, ∑ σ : ∀ _i : I, Equiv.Perm (Fin (J+1)),
      ∑ τ : ∀ _i : I, Equiv.Perm (Fin (J+1)),
        groupedSymmetricApply ν V ρ (anchor (s.position P Line J B)) (anchor z)
          (fun i => s.active P Line J B i (σ i (Fin.last J)))
          (compressedTest geometry H (s.position P Line J B) z (s.active P Line J B) σ τ)
          (s.memory P Line J B)


/-- Exact coefficient-and-output identity for one full physical choice.
Invalid local choices and the single total cutoff are handled explicitly. -/
theorem choice_eq_compressed
    (ν : ∀ i, P i → ℝ) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (H : Z → PhysicalActiveLists P J → (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) (z : Z)
    (σ τ : ∀ _i : I, Equiv.Perm (Fin (J+1)))
    (c : ∀ i, EdgeGroupChoice (s.memory P Line J B i)) :
    (let e : PhysicalEdgeChoice s := (z,σ,c,τ)
      if hc : e.Valid anchor s then
        physicalEdgeChoiceWeight ν V ρ anchor geometry s e hc *
          H ((e.output anchor s hc).position P Line J B)
            ((e.output anchor s hc).active P Line J B)
            (fun i => tupleBag (((e.output anchor s hc).memory P Line J B i).values))
      else 0) =
    (endpointPermutationWeight I J : ℂ) *
      ((∏ i, localCoefficient (ν i) (V i) ρ (anchor (s.position P Line J B) i) (anchor z i)
          (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i)) *
        compressedTest geometry H (s.position P Line J B) z (s.active P Line J B) σ τ
          (fun i => localOutput (anchor (s.position P Line J B) i) (anchor z i)
            (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i))) := by
  let e : PhysicalEdgeChoice s := (z,σ,c,τ)
  change (if hc : e.Valid anchor s then physicalEdgeChoiceWeight ν V ρ anchor geometry s e hc *
    H ((e.output anchor s hc).position P Line J B) ((e.output anchor s hc).active P Line J B)
      (fun i => tupleBag (((e.output anchor s hc).memory P Line J B i).values)) else 0) = _
  by_cases hl : ∀ i, EdgeGroupChoice.Valid (anchor z i) (s.memory P Line J B i) (c i)
  · have hcoef : (∏ i, localCoefficient (ν i) (V i) ρ (anchor (s.position P Line J B) i) (anchor z i)
        (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i)) =
        ∏ i, (edgeGroupWeight (ν i) (V i) ρ (anchor (s.position P Line J B) i) (anchor z i)
          (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i) (hl i).2 : ℂ) := by
      apply Finset.prod_congr rfl
      intro i _
      simp only [localCoefficient,dite_eq_left (hl i)]
    have hout : (fun i => localOutput (anchor (s.position P Line J B) i) (anchor z i)
        (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i)) =
        fun i => (edgeTargetPrime (s.memory P Line J B i) (c i),
          memoryBagOf (edgeGroupOutput (anchor (s.position P Line J B) i)
            (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i) (hl i).2)) := by
      funext i
      simp only [localOutput,dite_eq_left (hl i)]
    rw [hcoef,hout]
    unfold compressedTest
    simp only [memoryBagOf_card,edgeGroupOutput_size]
    by_cases ht : (∑ i, edgeGroupOutputSize (c i)) ≤ B
    · have hv : e.Valid anchor s := ⟨hl,ht⟩
      rw [dite_eq_left hv,ite_eq_left ht]
      have hsrc : e.sourceLists = fun i j => s.active P Line J B i (σ i j) := rfl
      have htrg : e.targetLists = targetLists (s.active P Line J B) σ
          (fun i => edgeTargetPrime (s.memory P Line J B i) (c i)) := rfl
      have hpos : e.target = z := rfl
      have hprime : e.sourcePrime = fun i => s.active P Line J B i (σ i (Fin.last J)) := rfl
      have hgroup : e.group = c := rfl
      have hperm : e.targetPerm = τ := rfl
      have haout : (e.output anchor s hv).active P Line J B =
          fun i j => targetLists (s.active P Line J B) σ
            (fun i => edgeTargetPrime (s.memory P Line J B i) (c i)) i (τ i j) := by
        funext i j
        rw [PhysicalEdgeChoice.output_active,htrg,hperm]
      have hmout : (fun i => tupleBag (((e.output anchor s hv).memory P Line J B i).values)) =
          fun i => tupleBag ((edgeGroupOutput (anchor (s.position P Line J B) i)
            (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i) (hl i).2).values) := by
        funext i
        rfl
      rw [haout,hmout]
      simp only [physicalEdgeChoiceWeight,PhysicalEdgeChoice.output_position,
        hsrc,htrg,hpos,hprime,hgroup,memoryBagOf]

      ring
    · have hv : ¬ e.Valid anchor s := fun h => ht h.2
      rw [dite_eq_right hv,ite_eq_right ht]
      simp
  · obtain ⟨i,hi⟩ := not_forall.mp hl
    have hv : ¬ e.Valid anchor s := fun h => hi (h.1 i)
    have hz : (∏ i, localCoefficient (ν i) (V i) ρ (anchor (s.position P Line J B) i) (anchor z i)
        (s.active P Line J B i (σ i (Fin.last J))) (s.memory P Line J B i) (c i)) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ i) (by simp [localCoefficient,hi])
    rw [dite_eq_right hv,hz,zero_mul,mul_zero]

/-- The actual full physical edge equals its coupled symmetric transfer.
All local indexed multiplicities, both endpoint averages, arbitrary geometry,
and the total memory cutoff are derived from the definitions. -/
theorem physicalEdgeApply_eq_symmetric [Fintype Z]
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (H : Z → PhysicalActiveLists P J → (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ)
    (s : PhysicalMemoryState (Z:=Z) P Line J B) :
    physicalEdgeApply ν V ρ anchor geometry
      (fun t => H (t.position P Line J B) (t.active P Line J B)
        (fun i => tupleBag ((t.memory P Line J B i).values))) s =
      symmetricPhysicalApply ν V ρ anchor geometry H s := by
  unfold physicalEdgeApply symmetricPhysicalApply
  simp_rw [← groupedChoiceApply_eq_symmetric ν hν V ρ]
  unfold groupedChoiceApply
  simp only [Fintype.sum_prod_type,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro z _
  apply Finset.sum_congr rfl
  intro σ _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro τ _
  apply Finset.sum_congr rfl
  intro c _
  exact choice_eq_compressed ν V ρ anchor geometry H s z σ τ c


/-- The complete physical bilinear pairing has the same exact compressed
symmetric-transfer representation. This retains the original physical
active/factorial measure and arbitrary coupled source and target tests. -/
theorem physicalEdge_pairing_eq_symmetric [Fintype Z]
    (ν : ∀ i, P i → ℝ) (hν : ∀ i p, ν i p ≠ 0) (V : I → ℝ) (ρ : ℝ)
    (anchor : Z → ∀ i p, Line i p)
    (geometry : Z → PhysicalActiveLists P J → Z → PhysicalActiveLists P J → ℂ)
    (F G : Z → PhysicalActiveLists P J → (∀ i, Multiset (AnchoredParticle (P i) (Line i))) → ℂ) :
    (∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) *
        G (s.position P Line J B) (s.active P Line J B)
          (fun i => tupleBag ((s.memory P Line J B i).values)) *
        physicalEdgeApply ν V ρ anchor geometry
          (fun t => F (t.position P Line J B) (t.active P Line J B)
            (fun i => tupleBag ((t.memory P Line J B i).values))) s) =
    ∑ s : PhysicalMemoryState (Z:=Z) P Line J B,
      (PhysicalMemoryState.mass P Line J B ν s : ℂ) *
        G (s.position P Line J B) (s.active P Line J B)
          (fun i => tupleBag ((s.memory P Line J B i).values)) *
        symmetricPhysicalApply ν V ρ anchor geometry F s := by
  simp_rw [physicalEdgeApply_eq_symmetric ν hν]

end PhysicalEdgeAdjoint
end Elliptic.Operator
