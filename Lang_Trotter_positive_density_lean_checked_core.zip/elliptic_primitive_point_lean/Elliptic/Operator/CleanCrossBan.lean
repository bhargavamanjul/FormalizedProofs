module
public import Elliptic.Operator.CleanCoincidence
public import Elliptic.Operator.SourceMemoryEdges

/-! On distinct endpoint active lists, the extra cross-edge ban excludes
exactly a collision between the two fresh labels in the same disjoint
prime band. This is the event bounded in CleanCoincidence. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.CleanCrossBan
open scoped BigOperators
attribute [local instance] Classical.propDecidable
local instance cleanCrossBanDecidableEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false

variable {I : Type*} [Fintype I] {P : I → Type*} {J : ℕ}

def crossPrime (a b : PhysicalActiveLists P J) (i : I) : Fin J ⊕ Bool → P i
  | .inl j => a i j.castSucc
  | .inr false => a i (Fin.last J)
  | .inr true => b i (Fin.last J)

theorem crossPrime_injective (a b : PhysicalActiveLists P J) (i : I)
    (hshared : ∀ j : Fin J, a i j.castSucc=b i j.castSucc)
    (ha : Function.Injective (a i)) (hb : Function.Injective (b i))
    (hf : a i (Fin.last J)≠b i (Fin.last J)) : Function.Injective (crossPrime a b i) := by
  intro x y h
  cases x with
  | inl j =>
    cases y with
    | inl k =>
      have hh := ha h
      have he : j=k := Fin.castSucc_injective J hh
      subst k
      rfl
    | inr c =>
      cases c
      · have hh := ha h
        exact (Fin.castSucc_ne_last j hh).elim
      · have hh : b i j.castSucc=b i (Fin.last J) := (hshared j).symm.trans h
        exact (Fin.castSucc_ne_last j (hb hh)).elim
  | inr c =>
    cases c
    · cases y with
      | inl k =>
        have hh := ha h
        exact (Fin.castSucc_ne_last k hh.symm).elim
      | inr d =>
        cases d
        · rfl
        · exact (hf h).elim
    · cases y with
      | inl k =>
        have hh : b i (Fin.last J)=b i k.castSucc := h.trans (hshared k)
        exact (Fin.castSucc_ne_last k (hb hh).symm).elim
      | inr d =>
        cases d
        · exact (hf h.symm).elim
        · rfl

/-- Distinct bands remove all cross-group coincidences. -/
theorem cross_labels_injective
    (value : ∀ i, P i → ℕ) (hinj : ∀ i, Function.Injective (value i))
    (hsep : ∀ i j, i≠j → ∀ p q, value i p≠value j q)
    (a b : PhysicalActiveLists P J)
    (hshared : ∀ i (j : Fin J), a i j.castSucc=b i j.castSucc)
    (ha : ∀ i, Function.Injective (a i)) (hb : ∀ i, Function.Injective (b i))
    (hf : ∀ i, a i (Fin.last J)≠b i (Fin.last J)) :
    Function.Injective (sourceCrossEdgeLabels value a b) := by
  have he (i : I) (k : Fin J ⊕ Bool) :
      sourceCrossEdgeLabels value a b (i,k)=value i (crossPrime a b i k) := by
    cases k with
    | inl j => rfl
    | inr c => cases c <;> rfl
  rintro ⟨i,k⟩ ⟨j,l⟩ h
  rw [he,he] at h
  have hij : i=j := by
    by_contra hn
    exact hsep i j hn _ _ h
  subst j
  have hkl := crossPrime_injective a b i (hshared i) (ha i) (hb i) (hf i) (hinj i h)
  subst l
  rfl

/-- Exact source ban characterization after endpoint distinctness
projections. This isolates precisely the small-atom event. -/
theorem sourceCrossEdgeBan_iff
    (value : ∀ i, P i → ℕ) (hinj : ∀ i, Function.Injective (value i))
    (hsep : ∀ i j, i≠j → ∀ p q, value i p≠value j q)
    (a b : PhysicalActiveLists P J)
    (hshared : ∀ i (j : Fin J), a i j.castSucc=b i j.castSucc)
    (ha : ∀ i, Function.Injective (a i)) (hb : ∀ i, Function.Injective (b i)) :
    sourceCrossEdgeBan value a b ↔ ∀ i, a i (Fin.last J)≠b i (Fin.last J) := by
  constructor
  · intro h i hi
    have he : sourceCrossEdgeLabels value a b (i,Sum.inr false)=
        sourceCrossEdgeLabels value a b (i,Sum.inr true) := congrArg (value i) hi
    have hh := h.2 he
    have hb := congrArg Prod.snd hh
    simp at hb
  · intro hf
    exact ⟨fun i j => (hshared i j).symm,cross_labels_injective value hinj hsep a b hshared ha hb hf⟩

/-- Actual disjoint finite prime bands satisfy the cross-group premise. -/
theorem actual_band_separation (groups : I → Finset ℕ)
    (hdis : ∀ i j, i≠j → Disjoint (groups i) (groups j)) :
    ∀ i j, i≠j → ∀ (p : groups i) (q : groups j), p.val≠q.val := by
  intro i j hij p q he
  exact Finset.disjoint_left.mp (hdis i j hij) p.property (he.symm ▸ q.property)

end Elliptic.Operator.CleanCrossBan
