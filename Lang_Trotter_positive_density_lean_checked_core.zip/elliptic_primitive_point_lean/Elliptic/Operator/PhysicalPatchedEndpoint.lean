module

public import Elliptic.Operator.PhysicalPatchGluing
public import Elliptic.Operator.PhysicalPatchPartition

/-! The actual physical endpoint estimate after slope-patch localization.
The coefficient-count cost is the largest single patch, and the neighbor
overlap is the only cost of gluing the local spectral estimates. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalPatchedEndpoint
open scoped BigOperators ComplexConjugate
open PhysicalRootedMoment PhysicalAdmissibleMoment PhysicalPatchGluing PhysicalPatchPartition
open PhysicalSlopePatches
attribute [local instance] Classical.propDecidable
local instance patchedEndpointDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
variable {I Z : Type} [Fintype I] [Fintype Z] {P : I→Type} [∀i,Fintype (P i)] {J : ℕ}

/-- Every finite position partition with bounded fibers and bounded
neighbor overlap yields the source endpoint power inequality. All
localized spectral inequalities and the exact row decomposition are proved. -/
theorem patched_endpoint_power_bound (value : ∀i,P i→ℕ) (position : Z→ℤ×ℤ)
    (V : I→ℝ) (hV : ∀i,0≤V i)
    (g : Z→PhysicalActiveLists P J→Z→PhysicalActiveLists P J→ℂ)
    (hg : Supported value position g)
    (κ : Z→ℤ) (s : Finset ℤ) (hs : ∀z,κ z∈s) (D : ℕ)
    (hnear : ∀z a w b,g z a w b≠0→κ w∈neighbors D (κ z))
    (Pcap : ℝ) (hPcap : 0≤Pcap)
    (hcard : ∀i∈s,((Finset.univ.filter (fun z:Z=>κ z=i)).card:ℝ)≤Pcap)
    (R : ℕ) (hR : 2≤R) (B : ℝ) (hB : 0≤B) (f : Z→ℂ) (hf : ∀z,‖f z‖≤B)
    (G : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ) :
    let F := fun x : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)=>f x.1
    ‖pairing V F (rowApply V g G)‖^(2*R)≤
      (2*D+1:ℕ)^R*(pairing V (project value position G) (project value position G)).re^R*
      (pairing V (project value position F) (project value position F)).re^(R-1)*
      (Pcap*B^2)*(rootedPowerMoment V g R).re := by
  dsimp only
  let F : PhysicalRootedMoment.State (Z:=Z) (P:=P) (J:=J)→ℂ := fun x=>f x.1
  let Fi := fun i=>restrict (fun x=>κ x.1) i F
  let Gi := fun i=>nearRestrict (fun x=>κ x.1) D i G
  let parts := fun i=>Finset.univ.filter (fun z:Z=>κ z=i)
  let Floc := fun i=>(pairing V (project value position (Fi i)) (project value position (Fi i))).re
  let Gloc := fun i=>(pairing V (project value position (Gi i)) (project value position (Gi i))).re
  let diag := fun z:Z=>(pairing V (PhysicalRootedMoment.positionVector z)
    (aaStarPower V g R (PhysicalRootedMoment.positionVector z))).re
  let Mloc := fun i=>∑z∈parts i,diag z
  let term := fun i=>pairing V (Fi i) (rowApply V g (Gi i))
  have hRp : 0<R := by omega
  have hdiag : ∀z,0≤diag z := by
    intro z
    dsimp only [diag]
    rw [pairing_power_re]
    exact mul_nonneg (initialMass_nonneg V hV)
      ((aaStarMatrix_posSemidef V g R).re_dotProduct_nonneg _)
  have hFloc : ∀i∈s,0≤Floc i := fun i _=>pairing_self_re_nonneg V hV _
  have hGloc : ∀i∈s,0≤Gloc i := fun i _=>pairing_self_re_nonneg V hV _
  have hMloc : ∀i∈s,0≤Mloc i := fun i _=>Finset.sum_nonneg (fun z _=>hdiag z)
  have hlocal : ∀i∈s,‖term i‖^(2*R)≤Gloc i^R*Floc i^(R-1)*((Pcap*B^2)*Mloc i) := by
    intro i hi
    have h := localized_endpoint_bound_of_card value position V hV g hg R hRp
      (parts i) f (Gi i) B Pcap hB (hcard i hi) (fun z _=>hf z)
    have hFi : Fi i=(fun x=>if x.1∈parts i then f x.1 else 0) := by
      funext x
      simp only [Fi,F,PhysicalPatchPartition.restrict,parts,Finset.mem_filter,Finset.mem_univ,true_and]
    dsimp only [term,Gloc,Floc,Mloc,diag]
    rw [hFi]
    exact h
  have hFsum : (∑i∈s,Floc i)=(pairing V (project value position F) (project value position F)).re := by
    simp only [Floc,Fi,project_restrict]
    exact sum_pairing_restrict_self κ s hs V _
  have hGsum : (∑i∈s,Gloc i)≤(2*D+1:ℕ)*
      (pairing V (project value position G) (project value position G)).re := by
    simp only [Gloc,Gi,project_nearRestrict]
    exact sum_pairing_nearRestrict_self_le κ s D V (initialMass_nonneg V hV) _
  have hMsum : (∑i∈s,Mloc i)=(rootedPowerMoment V g R).re := by
    simp only [Mloc,parts,Finset.sum_filter]
    rw [sum_fibers κ s hs diag]
    simp only [rootedPowerMoment,Complex.re_sum,diag]
  have hMt : 0≤(rootedPowerMoment V g R).re := by
    rw [←hMsum]
    exact Finset.sum_nonneg hMloc
  have hglue := glue_with_overlap s term Floc Gloc Mloc R hR (Pcap*B^2) (2*D+1:ℕ)
    (pairing V (project value position F) (project value position F)).re
    (pairing V (project value position G) (project value position G)).re
    (rootedPowerMoment V g R).re (mul_nonneg hPcap (sq_nonneg _)) (Nat.cast_nonneg _)
    (pairing_self_re_nonneg V hV _) (pairing_self_re_nonneg V hV _) hMt hFloc hGloc hMloc
    hlocal hFsum.le hGsum hMsum.le
  have he : pairing V F (rowApply V g G)=∑i∈s,term i :=
    pairing_partition κ s hs D V g hnear F G
  rw [←he] at hglue
  exact hglue

section Source
open PhysicalMomentIdentification PhysicalVertexDamping SingleEdgeRootEncoding
variable {K : ℕ} {P : Fin K→Type} [∀i,Fintype (P i)]

/-- The literal source geometry supplies every patch hypothesis. The
only coefficient-count factor is O(patchHeight), with no factor depending
on the entire physical position box. -/
theorem physical_patched_endpoint_power_bound
    (value : ∀i,P i→ℕ) (μ : ∀i,P i→ℝ) (VM : Fin K→ℝ) (hVM : ∀i,0≤VM i)
    (d₀ Y L U W : ℝ) (exponents : Fin K→ℝ) (smooth ψ : ℝ→ℂ)
    (major : Set ProductCircle) (σ : ℤ) (primes : Finset ℕ)
    (hprimes : ∀i p,value i p∈primes) (q patchHeight Cψ : ℝ)
    (hU : 0<U) (hd : 0<d₀) (hY : 0<Y) (hH : 1≤patchHeight)
    (hscale : d₀*Y≤patchHeight) (hCψ : 0≤Cψ) (hψ : ∀t,ψ t≠0→|t|≤Cψ)
    (R : ℕ) (hR : 2≤R) (B : ℝ) (hB : 0≤B)
    (f : primitiveSources U W→ℂ) (hf : ∀z,‖f z‖≤B)
    (G : PhysicalRootedMoment.State (Z:=primitiveSources U W) (P:=P) (J:=J)→ℂ) :
    let pos := fun z:primitiveSources U W=>z.val
    let F := fun x : PhysicalRootedMoment.State (Z:=primitiveSources U W) (P:=P) (J:=J)=>f x.1
    let D := (⌈2*Cψ⌉+1).toNat
    ‖pairing VM F (rowApply VM
      (physicalGeometry value μ d₀ Y L U W exponents smooth ψ major σ primes q) G)‖^(2*R)≤
      (2*D+1:ℕ)^R*(pairing VM (project value pos G) (project value pos G)).re^R*
      (pairing VM (project value pos F) (project value pos F)).re^(R-1)*
      ((16929*patchHeight)*B^2)*
      (PhysicalRootMomentNumeric.physicalMoment (J:=J) (N:=2*R) value μ VM d₀ Y L U W
        exponents smooth ψ major σ alternatingAdjoint primes (momentDamping q (2*R))).re := by
  dsimp only
  let pos := fun z:primitiveSources U W=>z.val
  let κ := fun z:primitiveSources U W=>patchIndex U patchHeight z.val
  let s := indices (primitiveSources U W) U patchHeight
  let D := (⌈2*Cψ⌉+1).toNat
  let g := physicalGeometry (J:=J) value μ d₀ Y L U W exponents smooth ψ major σ primes q
  have hs : ∀z,κ z∈s := fun z=>Finset.mem_image_of_mem _ z.property
  have hnear : ∀z a w b,g z a w b≠0→κ w∈neighbors D (κ z) := by
    intro z a w b hn
    have hb : baseGeometry value μ d₀ Y L U W exponents smooth ψ major σ z.val a w.val b≠0 := by
      intro he
      simp [g,physicalGeometry,dampedGeometry,he] at hn
    have hdet := source_geometry_nonzero_det_bound value
      (RootLiteralGeometry.sourceGood value μ d₀ Y L exponents (1,1,0))
      1 0 0 U W d₀ Y Cψ smooth ψ major σ hd hY hCψ hψ z.val w.val a b hb
    have hdet' : |(latticeDet z.val w.val:ℝ)|≤(2*Cψ)*patchHeight := by
      apply hdet.trans
      nlinarith [mul_le_mul_of_nonneg_left hscale (show 0≤2*Cψ by positivity)]
    exact edge_mem_neighbors U patchHeight (2*Cψ) hU (by linarith) (by positivity)
      z.val w.val ((mem_primitiveSources U W z.val).mp z.property).2.1
      ((mem_primitiveSources U W w.val).mp w.property).2.1 hdet'
  have hcard : ∀i∈s,((Finset.univ.filter (fun z:primitiveSources U W=>κ z=i)).card:ℝ)≤16929*patchHeight := by
    intro i hi
    have hc : (Finset.univ.filter (fun z:primitiveSources U W=>κ z=i)).card≤
        (patch (primitiveSources U W) U patchHeight i).card := by
      apply Finset.card_le_card_of_injOn (fun z:primitiveSources U W=>z.val)
      · intro z hz
        exact (mem_patch _ _ _ _ _).mpr ⟨z.property,(Finset.mem_filter.mp hz).2⟩
      · exact Subtype.val_injective.injOn
    have hcR : ((Finset.univ.filter (fun z:primitiveSources U W=>κ z=i)).card:ℝ)≤
        ((patch (primitiveSources U W) U patchHeight i).card:ℝ) := by exact_mod_cast hc
    exact hcR.trans (patch_card_le (primitiveSources U W) U patchHeight hU hH
      (fun z hz=>((mem_primitiveSources U W z).mp hz).1)
      (fun z hz=>⟨((mem_primitiveSources U W z).mp hz).2.1,
        ((mem_primitiveSources U W z).mp hz).2.2.1⟩) i)
  rw [physicalMoment_eq_rootedPowerMoment value μ VM d₀ Y L U W exponents smooth ψ major σ primes q (by omega)]
  exact patched_endpoint_power_bound value pos VM hVM g
    (physicalGeometry_supported value μ d₀ Y L U W exponents smooth ψ major σ primes hprimes q)
    κ s hs D hnear (16929*patchHeight) (by positivity) hcard R hR B hB f hf G

end Source

end Elliptic.Operator.PhysicalPatchedEndpoint
