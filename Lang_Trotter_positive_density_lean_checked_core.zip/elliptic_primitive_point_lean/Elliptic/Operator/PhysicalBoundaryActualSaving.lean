module
public import Elliptic.Operator.PhysicalBoundaryMoment
public import Elliptic.Operator.PhysicalLowRankActualSaving
public import Elliptic.Operator.PhysicalFixedGeometryRowParameters

/-! The literal signed physical boundary sum has every prescribed moment
saving. Both low and high rank estimates are proved for the actual choices. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.PhysicalBoundaryActualSaving
open Filter
open scoped BigOperators SchwartzMap
open ActualHistoryBirths CanonicalBoundaryAssembly PhysicalBoundaryMoment
open PhysicalLowRankActualSaving
attribute [local instance] Classical.propDecidable
local instance actualBoundaryDecEq {α : Type*} : DecidableEq α := Classical.typeDecidableEq α
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1200000

 theorem disjoint_value_injective {K : ℕ} (groups : Fin K→Finset ℕ)
    (hdis : ∀i j,i≠j→Disjoint (groups i) (groups j)) :
    Function.Injective (fun p:Sigma (fun i=>groups i)=>p.2.val) := by
  rintro ⟨i,p⟩ ⟨j,q⟩ h
  have hij : i=j := by
    by_contra hn
    have he : p.val=q.val := h
    exact (Finset.disjoint_left.mp (hdis i j hn)) p.property (by simpa only [he] using q.property)
  subst j
  have hpq : p=q := Subtype.ext h
  subst q
  rfl

 theorem reciprocal_atom_le {L a ν c C : ℝ} {p : ℕ}
    (hL : 1≤L) (ha : (1/10:ℝ)≤a) (hc : 0≤c) (hC : c≤C)
    (hν : ν≤c/p) (hp : Real.exp (L^a)≤(p:ℝ)) :
    ν≤C*Real.exp (-L^(1/10:ℝ)) := by
  have hpp : Real.exp (L^(1/10:ℝ))≤(p:ℝ) :=
    (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL ha)).trans hp
  calc
    _ ≤ C/Real.exp (L^(1/10:ℝ)) := hν.trans
      (div_le_div₀ (hc.trans hC) hC (Real.exp_pos _) hpp)
    _ = _ := by rw [Real.exp_neg];ring

 theorem ghost_survival_bound (ρ Q vmax : ℝ) (hρ : 0<ρ) (hQ : Q<ρ^2)
    (η q : ℕ→ℝ) (hη : ∀j,η j≤1) (hq : ∀j,q j≤Q) :
    ∀j,q j/ρ^2+η j/(ρ*ghostSchurWeight ρ Q vmax)≤1 := by
  intro j
  have hgap := ghostSchurWeight_gap ρ Q vmax hρ hQ
  have hη' : η j/(ρ*ghostSchurWeight ρ Q vmax)≤
      max 1 vmax/(ρ*ghostSchurWeight ρ Q vmax) :=
    div_le_div_of_nonneg_right ((hη j).trans (le_max_left _ _))
      (mul_nonneg hρ.le (ghostSchurWeight_pos ρ Q vmax hρ hQ).le)
  have hq' : q j/ρ^2≤Q/ρ^2 := div_le_div_of_nonneg_right (hq j) (sq_nonneg _)
  linarith

 theorem exists_group_count_for_actual_boundary (E : ℝ) (hE : 0≤E) :
    ∃K₀ : ℕ,1≤K₀ ∧ ∀K : ℕ,K₀≤K→
      ∀(Cweight : Fin K→ℝ),(∀i,0≤Cweight i)→
      ∀(ψ : 𝓢(ℝ,ℂ)) (η : ℝ→ℂ) (C Aψ Cmass Catom ρ vmin vmax Qg : ℝ),
      1≤C→0≤Aψ→1≤Cmass→0≤Catom→(∀i,Cweight i≤Catom)→
      0<ρ→ρ<1→0<vmin→Qg<ρ^2→
      (∀x,‖η x‖≤1)→(∀x,η x≠0→1≤x)→
      (∀x,‖ψ x‖≤Aψ)→(∀x,ψ x≠0→|x|≤C)→
      ∀ᶠ L : ℝ in atTop,∀(a : Fin K→ℝ),(∀i,(1/10:ℝ)≤a i)→
      ∀(positions : Finset (ℤ×ℤ)) (groups : Fin K→Finset ℕ)
        (_ : ∀i (p:groups i),Fintype (ZMod p.val)),
      (∀i,∀p∈groups i,p.Prime)→(∀i j,i≠j→Disjoint (groups i) (groups j))→
      ∀(ν : Fin K→ℕ→ℝ) (μ : ∀i,groups i→ℝ) (V : Fin K→ℝ),
      (∀i,∀p∈groups i,0<ν i p)→(∀i,∀p∈groups i,ν i p≤Cweight i/p)→
      (∀i,∑p:groups i,ν i p.val≤Cmass)→(∀i (p:groups i),ν i p.val≤2*μ i p)→
      (∀i,vmin≤V i)→(∀i,V i≤vmax)→
      (∀i,∀p∈groups i,Real.exp (L^a i)≤(p:ℝ))→
      (∏i,(∑p:groups i,ν i p.val)^(momentPadding L+1))≤2→
      ∀(d₀ Y : ℝ) (qroot : RootPhysicalCell.RootPoint) (U W : ℝ),
      0<U→1≤qroot.1→qroot.1≤16→0<d₀→1≤Y→Real.exp (L^(1/10:ℝ))≤Y→Y≤Real.exp L→
      ∀(ηg qg : ℕ→ℝ),(∀j,0≤qg j)→(∀j,qg j≤Qg)→
      (∀j,0≤ηg j)→(∀j,ηg j≤1)→∀sign : ℕ→ℤ,(∀j,sign j=1∨sign j= -1)→
      ∀z₀ z₁ : positions,
      ‖boundaryPairing (J:=momentPadding L) (B:=memoryCutoff L) (fun i (p:groups i)=>ν i p.val) V ηg qg ρ
        (PhysicalRawMaskedRow.anchor (fun i (p:groups i)=>p.val) (fun z:positions=>z.val))
        (literalGeometry positions groups μ d₀ Y L a qroot U W η ψ (L^(sourceContractionExponent E+6)) sign)
        (fun i (p:groups i)=>p.val) (momentLength L) (atPosition z₀) (atPosition z₁)‖≤
      L^(-E*(momentLength L:ℝ)) := by
  let G := sourceContractionExponent E
  have hG : 0≤G := by dsimp [G,sourceContractionExponent];linarith
  obtain ⟨K₀,hK₀,hlow⟩ := exists_group_count_for_actual_lowrank G hG
  refine ⟨K₀,hK₀,?_⟩
  intro K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax Qg
    hC hAψ hmassC hCatom hweight hρ hρ1 hmin hQg hη hηsupport hψ hψsupport
  let v0 := ghostSchurWeight ρ Qg vmax
  let D := max 1 (max 1 vmax/ρ*v0)
  let g := 3*(G+6)+1
  let degree := max (g+2*(K:ℝ)+1) (PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1)
  let Cg := (Real.exp (v0*max 1 vmax*Cmass/ρ))^K
  have hv : 0<v0 := ghostSchurWeight_pos ρ Qg vmax hρ hQg
  have hD : 1≤D := le_max_left _ _
  have hD0 : 0≤D := (by norm_num : (0:ℝ)≤1).trans hD
  have hg : 0≤g := by dsimp [g];positivity
  have hdg : 0≤degree := le_trans (by positivity : 0≤g+2*(K:ℝ)+1) (le_max_left _ _)
  have hCg : 1≤Cg := by
    apply one_le_pow₀
    apply Real.one_le_exp_iff.mpr
    exact div_nonneg (mul_nonneg (mul_nonneg hv.le
      ((by norm_num : (0:ℝ)≤1).trans (le_max_left _ _))) (by linarith)) hρ.le
  have hKpos : 0<K := lt_of_lt_of_le (by omega : 0<K₀) hK
  filter_upwards [hlow K hK Cweight hCweight ψ η C Aψ Cmass Catom ρ vmin vmax
      hC hAψ hmassC hCatom hweight hρ hρ1 hmin hη hηsupport hψ hψsupport,
    ActualBirthHighRank.eventually_term_norm_le K D Cmass g v0 vmin Catom ρ
      hD hmassC hg hv hmin hCatom hρ hρ1.le,
    PhysicalFixedGeometryRow.eventually_row_constant_le (G+6) C 1 Aψ (by linarith)
      (by linarith) (by norm_num) hAψ,
    eventually_uniform_permutation_moment K hKpos hdg hCg (mul_nonneg hD0 hCatom) hE,
    eventually_ge_atTop (1:ℝ)] with L hlo hhi hgeo hmoment hL
  intro a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband hmassTwo
    d₀ Y qroot U W hU hq hq' hd₀ hY hYlo hYhi ηg qg hq0 hqQ hη0 hη1 sign hsign z₀ z₁
  letI : ∀i (p:groups i),Fintype (ZMod p.val) := instLine
  let value : ∀i,groups i→ℕ := fun _ p=>p.val
  let ν' : ∀i,groups i→ℝ := fun i p=>ν i p.val
  let anchor := PhysicalRawMaskedRow.anchor value (fun z:positions=>z.val)
  let geom := literalGeometry (J:=momentPadding L) positions groups μ d₀ Y L a qroot U W η ψ (L^(G+6)) sign
  let α := Address (Fin K) (momentPadding L) (memoryCutoff L) (momentLength L)
  letI (priority := 100000) : DecidableEq α := Classical.typeDecidableEq _
  let term := fun σ:Equiv.Perm α=>PhysicalLowRankBoundary.term ν' V ηg qg ρ anchor geom value σ
    (atPosition z₀) (atPosition z₁)
  have hinj : Function.Injective (fun p:Sigma (fun i=>groups i)=>value p.1 p.2) :=
    disjoint_value_injective groups hdis
  have hν0 : ∀i p,0≤ν' i p := fun i p=>(hν i p.val p.property).le
  have hatoms : ∀i p,ν' i p≤Catom*Real.exp (-L^(1/10:ℝ)) := by
    intro i p
    exact reciprocal_atom_le hL (ha i) (hCweight i) (hweight i)
      (hνbound i p.val p.property) (hband i p.val p.property)
  have hsurvive := ghost_survival_bound ρ Qg vmax hρ hQg ηg qg hη1 hqQ
  have hbase : ∀j i,ηg j*V i/ρ*v0≤D := by
    intro j i
    have hVi : 0≤V i := hmin.le.trans (hVlo i)
    have hmul : ηg j*V i≤max 1 vmax :=
      (mul_le_of_le_one_left hVi (hη1 j)).trans ((hVhi i).trans (le_max_right _ _))
    exact (mul_le_mul_of_nonneg_right (div_le_div_of_nonneg_right hmul hρ.le) hv.le).trans
      (le_max_right _ _)
  have hgeometry : ∀j z b c,(∑w:positions,‖geom j z b w c‖)≤L^g := by
    intro j z b c
    have hr := PhysicalFixedGeometryRow.source_subtype_row_le positions value
      (RootLiteralGeometry.sourceGood value μ d₀ Y L a qroot)
      (U*qroot.1) (W*qroot.2.1) qroot.2.2 U W d₀ Y (L^(G+6)) C 1 Aψ
      hU hd₀ hY (Real.rpow_nonneg (by linarith) _) (by linarith) (by norm_num) hAψ
      η ψ hη hψ hψsupport (sign j) z b c
    exact hr.trans hgeo
  have hcard : Fintype.card α≤birthAddressBudget K L := by
    rw [address_card]
    simp only [Fintype.card_fin,birthAddressBudget,momentMultiplicity]
    exact le_rfl
  have hlowterm : ∀σ:Equiv.Perm α,birthCycleRank σ<rankCutoff (sourceRankConstant degree E) L→
      ‖term σ‖≤(Cg^(momentLength L+1)*2)*(L^(-sourceContractionExponent E))^
        (momentLength L-2*birthCycleRank σ)*(L^degree)^(2*birthCycleRank σ) := by
    intro σ hrank
    have ht := hlo a ha positions groups instLine hprime hdis ν μ V hν hνbound hmass hνμ hVlo hVhi hband
      hmassTwo d₀ Y qroot U W hU hq hq' hd₀ hY hYlo hYhi ηg qg Qg hQg hq0 hqQ hη0 hη1 sign hsign
      (momentLength L) σ z₀ z₁ (fun _=>1) (fun _=>1) (by intro;norm_num) (by intro;norm_num)
    simp only [position_indicator_eq,birthCycleRank_decidableEq] at ht
    have hbad : (L^(PhysicalPhasedEdgeAsymptotics.degree K (G+6)+1))^(2*birthCycleRank σ)≤
        (L^degree)^(2*birthCycleRank σ) :=
      pow_le_pow_left₀ (Real.rpow_nonneg (by linarith) _)
        (Real.rpow_le_rpow_of_exponent_le hL (le_max_right _ _)) _
    have hh := mul_le_mul_of_nonneg_left hbad
      (show 0≤2*Cg^(momentLength L+1)*(L^(-G))^(momentLength L-2*birthCycleRank σ) by positivity)
    apply ht.trans
    simpa only [birthCycleRank_decidableEq,term,atPosition,ν',anchor,geom,value,Cg,v0,G,mul_assoc,mul_left_comm,mul_comm] using hh
  have hhighterm : ∀σ:Equiv.Perm α,rankCutoff (sourceRankConstant degree E) L≤birthCycleRank σ→
      ‖term σ‖≤L^(degree*((momentLength L:ℝ)+1))*
        ((D*Catom)*Real.exp (-L^(1/10:ℝ)))^birthCycleRank σ := by
    intro σ hrank
    dsimp only [term]
    rw [term_atPosition_eq]
    have ht := hhi (Fin K) positions (by simp) (fun i=>groups i) (fun i p=>Option (ZMod p.val))
      ν' V ηg qg anchor geom value hinj hν0 hη0 hq0 hVlo hmass hatoms hsurvive hbase hgeometry
      (vacuumLift (atPosition z₁))
      (OriginalLifespanSchedule.vacuumLift_norm_le_schur _ (atPosition_norm_le z₁) v0 hv.le) σ z₀
    simp only [birthCycleRank_decidableEq] at ht ⊢
    apply ht.trans
    apply mul_le_mul_of_nonneg_right ?_ (by positivity)
    exact Real.rpow_le_rpow_of_exponent_le hL
      (mul_le_mul_of_nonneg_right (le_max_left _ _) (by positivity))
  have hout := hmoment α term hcard hlowterm hhighterm
  rw [boundaryPairing_eq_signed_terms]
  apply le_trans ?_ hout
  apply le_of_eq
  congr 1
  with_reducible refine Finset.sum_congr ?_ ?_
  · ext σ; simp only [Finset.mem_univ]
  · intro σ _
    simp only [permutationSign_decidableEq]
    rfl

end Elliptic.Operator.PhysicalBoundaryActualSaving
