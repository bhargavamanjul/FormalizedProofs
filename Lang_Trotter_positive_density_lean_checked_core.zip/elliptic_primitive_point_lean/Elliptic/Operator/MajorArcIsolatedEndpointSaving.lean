module
public import Elliptic.Operator.MajorArcPrimeDyads
public import Elliptic.Operator.MajorArcLabelMass

/-! The actual isolated prime and all remaining labels, with every dyadic
and harmonic-mass budget discharged. -/
@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcIsolatedEndpointSaving
open Filter MeasureTheory Set
open scoped BigOperators
open Artin.MarkedSource Artin.MarkedReplacement MajorArcScaleCancellation ClassicalDerivativeTest
open MellinPrimeSeparation MajorArcLabelMass MajorArcPrimeDyads
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 700000
local instance isolatedDecEq {α:Type*} : DecidableEq α := Classical.typeDecidableEq α
attribute [local instance] Classical.propDecidable

 def isolatedEndpoint {ι : Type*} [Fintype ι] (S : Finset ℕ) (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) : ℂ :=
    ((normalization G/Y:ℝ):ℂ)*∑p∈S,∑l:Labels G,
      χ (p:ZMod q)*χ (product G l:ZMod q)*
        twistedCutoff η lam ((p*product G l:ℕ)/Y)*archimedeanPhase t (p*product G l)

 theorem isolatedEndpoint_continuous {ι : Type*} [Fintype ι] (S : Finset ℕ) (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y : ℝ) :
    Continuous (isolatedEndpoint S G χ η lam Y) := by
  unfold isolatedEndpoint archimedeanPhase
  fun_prop

 theorem isolatedEndpoint_partition {ι : Type*} [Fintype ι] (S : Finset ℕ) (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (lam Y t : ℝ) :
    isolatedEndpoint S G χ η lam Y t=∑j∈indices S,isolatedEndpoint (block S j) G χ η lam Y t := by
  unfold isolatedEndpoint
  rw [sum_blocks S,Finset.mul_sum]

 theorem isolatedEndpoint_eq {ι : Type*} [Fintype ι] (S : Finset ℕ) (G : ι→Finset ℕ)
    {q : ℕ} (χ : DirichletCharacter ℂ q) (η : ℝ→ℂ) (hsupp : ∀y,η y≠0→y≤4)
    (lam P Y t : ℝ) (hP : 0<P) (hY : 0<Y) (hS : ∀p∈S,P≤(p:ℝ)) :
    (Y:ℂ)⁻¹*endpoint S (remainingPool G P Y) (fun p=>χ (p:ZMod q))
      (pushedCoefficient (product G) (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q))) η lam Y t=
      isolatedEndpoint S G χ η lam Y t := by
  unfold endpoint isolatedEndpoint
  have he (p:ℕ) (hp:p∈S) := pushed_cutoff_sum G
    (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q)) η hsupp P Y lam t hP hY p (hS p hp)
  calc
    _ = (Y:ℂ)⁻¹*∑p∈S,χ (p:ZMod q)*(∑r∈remainingPool G P Y,
        pushedCoefficient (product G) (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q)) r*
          twistedCutoff η lam ((p*r:ℕ)/Y)*archimedeanPhase t (p*r)) := by
      congr 1
      apply Finset.sum_congr rfl
      intro p hp
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro r hr
      ring
    _ = _ := by
      rw [Finset.mul_sum,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro p hp
      rw [he p hp]
      simp only [Finset.mul_sum,Complex.ofReal_div]
      apply Finset.sum_congr rfl
      intro l hl
      ring

/-- Uniform centered energy for the literal isolated-prime endpoint. All
remaining labels and all prime dyadic blocks have now been summed exactly. -/
 theorem uniform_isolated_endpoint_energy
    (hvdC : FixedOrderDerivativeTest)
    (hD : Elliptic.Sieve.RoughPairNormalization.ClassicalDivisorSquareMoment)
    (η : ℝ→ℂ) (hη : MellinModulationBounds.Smooth η) (hsupp : ∀y,η y≠0→1≤y ∧ y≤4)
    (δ c Cprime Ccoef J E Alam A₀ c₁ c₂ : ℝ)
    (hδ : 0<δ) (hc : 0<c) (hC : 0≤Cprime) (hcoef : 0≤Ccoef) (hJ : 0≤J)
    (hE : 0≤E) (hAlam : 0≤Alam) (hA₀ : 0<A₀)
    {I : Type} (Hm Hn : ℝ→I→ℝ) (active : ℝ→I→Prop) (α : ℝ→I→ℕ→ℂ)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hcancel : ScaleCancellation α active Hm (fun x j=>Hm x j*Hn x j))
    (hα : ∀ᶠx:ℝ in atTop,∀j,active x j→∀n:ℕ,Hm x j≤n→(n:ℝ)≤2*Hm x j→‖α x j n‖≤(Real.log x)^Ccoef) :
    ∀ᶠx:ℝ in atTop,∀j,active x j→∀S:Finset ℕ,(∀p∈S,p.Prime)→
      (∀p∈S,c*(Real.log x)^(1/10:ℝ)≤Real.log p ∧ Real.log p≤Cprime*(Real.log x)^(1/5:ℝ))→
      ∀(ι:Type)[fi:Fintype ι](G:ι→Finset ℕ),(∀i,∀p∈G i,0<p)→(∀i,(∑p∈G i,(p:ℝ)⁻¹)≠0)→
      ∀(q:ℕ)(χ:DirichletCharacter ℂ q),∀s t:Finset ℕ,IntervalInDyad (Hm x j) s→InDyad (Hn x j) t→
      ∀β:ℕ→ℂ,(∀n∈t,‖β n‖≤(Real.log x)^Ccoef)→
      ∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→∀l:ℕ,
      ∀(χm:DirichletCharacter ℂ k)(χn:DirichletCharacter ℂ l),
      ∀lam Y:ℝ,0<Y→|lam|≤(Real.log x)^Alam→∀u:ℝ,|u|≤(Hm x j*Hn x j)*(Real.log x)^J→
      (∫v in Icc (u-(Hm x j*Hn x j)*(Real.log x)^J) (u+(Hm x j*Hn x j)*(Real.log x)^J),
        ‖isolatedEndpoint S G χ η lam Y v*
          longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v‖^2)≤(Real.log x)^(-E) := by
  have henergy := MajorArcCenteredEndpointSaving.uniform_centered_endpoint_energy hvdC hD η hη
    1 4 (by norm_num) hsupp δ (c/2) Cprime Ccoef J (E+2) Alam 1 A₀ c₁ c₂ hδ (by linarith)
    hC hcoef hJ (by linarith) hAlam (by norm_num) hA₀ Hm Hn active α hscale hcancel hα
  filter_upwards [henergy,Real.tendsto_log_atTop.eventually (eventually_source_blocks c Cprime hc hC),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (4:ℝ))] with x henergy hblocks hL
  intro j hj S hprime hlog ι fi G hG hm q χ s t hs ht β hβ k hk hkmax l χm χn lam Y hY hlam u hu
  have hS : ∀p∈S,0<p := fun p hp=>(hprime p hp).pos
  obtain ⟨hcard,hblocklog⟩ := hblocks S hS hlog
  let F : ℕ→ℝ→ℂ := fun e v=>isolatedEndpoint (block S e) G χ η lam Y v*
    longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v
  have heq (v:ℝ) : isolatedEndpoint S G χ η lam Y v*
      longPolynomial s (α x j) (Hm x j) χm v*longPolynomial t β (Hn x j) χn v=
      ∑e∈indices S,F e v := by rw [isolatedEndpoint_partition];simp only [Finset.sum_mul,F]
  simp_rw [heq]
  apply finite_energy_sum_saving (indices S) F (fun e he=>
    ((isolatedEndpoint_continuous (block S e) G χ η lam Y).mul
      (longPolynomial_continuous s (α x j) (Hm x j) χm)).mul
      (longPolynomial_continuous t β (Hn x j) χn)) _ _ (Real.log x) E (by linarith) hcard
  intro e he
  have hP : 0<scale e := by unfold scale;positivity
  have hR := remainingPool_pos G hG (scale e) Y
  have hmass := normalized_remaining_mass G hG hm χ (scale e) Y hP hY
  have hb := henergy j hj (scale e) hP (hblocklog e he).1 (hblocklog e he).2 (block S e)
    (fun p hp=>hprime p (Finset.mem_filter.mp hp).1)
    (fun p hp=>(block_mem S hS e p hp).2.2.le) q χ s t hs ht β hβ k hk hkmax l χm χn
    (remainingPool G (scale e) Y)
    (pushedCoefficient (product G) (fun l=>(normalization G:ℂ)*χ (product G l:ZMod q))) hR
    lam Y hY hlam (by simpa only [Real.rpow_one] using hmass.trans hL) u hu
  have hrep (v:ℝ) := isolatedEndpoint_eq (block S e) G χ η (fun y hy=>(hsupp y hy).2)
    lam (scale e) Y v hP hY (fun p hp=>(block_mem S hS e p hp).2.1)
  simp_rw [hrep] at hb
  convert hb using 1
  congr 1
  ring

end Elliptic.Operator.MajorArcIsolatedEndpointSaving
