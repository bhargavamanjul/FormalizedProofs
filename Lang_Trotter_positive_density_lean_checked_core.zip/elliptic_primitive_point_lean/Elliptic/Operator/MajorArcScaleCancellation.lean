module

public import Artin.MarkedSource
public import Elliptic.Operator.ProductDirichletMeanSquare

/-!
# The general criterion's long factor in the major-arc proof

ScaleCancellation is already a hypothesis of the general scalar criterion,
and is supplied downstream by the accepted source Proposition 10.3. This
module applies that existing hypothesis to the actual normalized finite
Dirichlet polynomial, uniformly across all active dyads and intervals.
-/

@[expose] public section
noncomputable section
namespace Elliptic.Operator.MajorArcScaleCancellation
open scoped BigOperators
open Filter Artin.MarkedSource Artin.MarkedReplacement
set_option backward.isDefEq.respectTransparency false

/-- The literal normalized long polynomial used in the major-arc split. -/
def longPolynomial (s : Finset ℕ) (α : ℕ→ℂ) (H : ℝ) {k : ℕ}
    (χ : DirichletCharacter ℂ k) (t : ℝ) : ℂ :=
  (H:ℂ)⁻¹*∑n∈s,α n*χ (n:ZMod k)*archimedeanPhase t n

theorem longPolynomial_continuous (s : Finset ℕ) (α : ℕ→ℂ) (H : ℝ) {k : ℕ}
    (χ : DirichletCharacter ℂ k) : Continuous (longPolynomial s α H χ) := by
  unfold longPolynomial archimedeanPhase
  fun_prop

/-- The uniform constant and onset precede every interval, character,
frequency and active scale. No new long-coefficient estimate is assumed. -/
theorem uniform_longPolynomial {J : Type} (α : ℝ→J→ℕ→ℂ)
    (active : ℝ→J→Prop) (Hm X : ℝ→J→ℝ)
    (hcancel : ScaleCancellation α active Hm X)
    (hHm : ∀ᶠx:ℝ in atTop,∀j,active x j→0<Hm x j)
    (A₀ B A : ℝ) (hA₀ : 0<A₀) (hB : 0<B) (hA : 0<A) :
    ∃C:ℝ,0<C∧∀ᶠx:ℝ in atTop,∀j,active x j→∀s:Finset ℕ,
      IntervalInDyad (Hm x j) s→∀k:ℕ,0<k→(k:ℝ)≤(Real.log x)^A₀→
      ∀χ:DirichletCharacter ℂ k,∀t:ℝ,|t|≤2*X x j*(Real.log x)^B→
        ‖longPolynomial s (α x j) (Hm x j) χ t‖≤C*(Real.log x)^(-A) := by
  obtain ⟨C,hC,h⟩ := hcancel A₀ B A hA₀ hB hA
  refine ⟨C,hC,?_⟩
  filter_upwards [h,hHm] with x hx hm
  intro j hj s hs k hk hkmax χ t ht
  obtain ⟨lo,hi,rfl,hlo,hhi⟩ := hs
  have hb := hx j hj lo hi k hlo hhi hk hkmax χ t ht
  have hH := hm j hj
  unfold longPolynomial
  rw [norm_mul,norm_inv,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hH]
  have hh := mul_le_mul_of_nonneg_left hb (inv_nonneg.mpr hH.le)
  convert hh using 1
  field_simp

theorem conjugate_longPolynomial_norm (s : Finset ℕ) (α : ℕ→ℂ) (H : ℝ) {k : ℕ}
    (χ : DirichletCharacter ℂ k) (t : ℝ) :
    ‖star (longPolynomial s α H χ t)‖=‖longPolynomial s α H χ t‖ := norm_star _

end Elliptic.Operator.MajorArcScaleCancellation
