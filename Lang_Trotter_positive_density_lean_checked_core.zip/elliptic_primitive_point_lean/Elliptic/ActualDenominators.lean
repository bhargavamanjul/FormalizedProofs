module

public import Elliptic.InfiniteOrder
public import Elliptic.HeightCounting
public import Mathlib.NumberTheory.Height.NumberField

/-!
# Denominators of multiples of the actual rational point

The denominator sequence in this module is computed from the actual elliptic
group law, not supplied as an arbitrary sequence. We use the full reduced
denominator of x(nP); using its square root instead changes only a constant.
The required quadratic height bound is proved in `MainCurveHeight` from
mathlib's approximate parallelogram law. Its actual reduction interpretation
is proved in `Arithmetic/ReductionDenominator`. The definitions here expose the numerical
height property so both generic and specialized deductions can use it.
-/

@[expose] public section
namespace Elliptic

def exampleMultipleDenominator (n : ℕ) : ℕ :=
  (examplePointX (n • examplePoint)).den

theorem exampleMultipleDenominator_pos (n : ℕ) : 0 < exampleMultipleDenominator n :=
  Rat.den_pos _

theorem exampleMultiple_ne_zero {n : ℕ} (hn : 0 < n) : n • examplePoint ≠ 0 := by
  intro h
  apply examplePoint_infinite_order
  exact isOfFinAddOrder_iff_nsmul_eq_zero.mpr ⟨n, hn, h⟩

theorem log_den_le_logHeight (q : ℚ) : Real.log (q.den : ℝ) ≤ Height.logHeight₁ q := by
  rw [Rat.logHeight₁_eq_log_max]
  apply Real.log_le_log
  · exact_mod_cast q.den_pos
  · exact_mod_cast le_max_right q.num.natAbs q.den

/-- The precise quadratic height property for the actual multiples.
`exists_example_quadratic_height_bound` in `MainCurveHeight` proves that it
holds with some positive constant; no height axiom is used. -/
def ExampleQuadraticHeightBound (C : ℝ) : Prop :=
  ∀ n : ℕ, 0 < n → Height.logHeight₁ (examplePointX (n • examplePoint)) ≤ C * (n : ℝ) ^ 2

theorem exampleMultipleDenominator_log_le {C : ℝ}
    (hheight : ExampleQuadraticHeightBound C) {n : ℕ} (hn : 0 < n) :
    Real.log (exampleMultipleDenominator n : ℝ) ≤ C * (n : ℝ) ^ 2 :=
  (log_den_le_logHeight _).trans (hheight n hn)

/-- Counting consequence for the actual rational denominator sequence.
The remaining reduction obligation is to show that every small-order
prime belongs to this explicitly defined divisibility set. -/
theorem actual_denominator_primes_card_le {S : Finset ℕ} {M : ℕ} {x C : ℝ}
    (hx : 1 < x) (hC : 0 ≤ C) (hheight : ExampleQuadraticHeightBound C)
    (hS : ∀ p ∈ S, p.Prime ∧ x ≤ (p : ℝ) ∧
      ∃ n ∈ Finset.Icc 1 M, p ∣ exampleMultipleDenominator n) :
    (S.card : ℝ) ≤ C * (M : ℝ) ^ 3 / Real.log x := by
  apply denominator_primes_card_le hx hC
    (fun n _ => exampleMultipleDenominator_pos n) _ hS
  intro n hn
  exact exampleMultipleDenominator_log_le hheight (Finset.mem_Icc.mp hn).1

end Elliptic
