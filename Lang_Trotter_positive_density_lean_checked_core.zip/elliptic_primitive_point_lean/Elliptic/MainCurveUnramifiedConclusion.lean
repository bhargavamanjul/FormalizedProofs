module

public import Elliptic.MainCurveConstructedConclusion
public import Elliptic.Arithmetic.UnramifiedLocalData

/-!
# Main-curve conclusion with constructed fields and arithmetic Frobenius

The division fields, their Galois property, the arithmetic Frobenius, its
residue action and the cyclic decomposition groups are now constructed.
The exact remaining elliptic inputs are geometric divisibility and
rank-two torsion, global Kummer/determinant/different statements, and
unramifiedness together with the usual specialization and Frobenius
polynomial at the eligible primes. The signed scalar criterion remains
an explicit original analytic obligation.
-/

@[expose] public section
noncomputable section

namespace Elliptic

open Filter Arithmetic
open scoped Topology

/-- Actual unramified reduction data for the specified main curve, with
Frobenius and its decomposition-group property derived rather than given. -/
def MainUnramifiedLocalInputs (D : MainGeometricDivisionFamily) (Y₀ : ℝ) : Prop :=
  ∀ n : ℕ, n.Prime → Y₀ < (n : ℝ) →
    ∀ p : ℕ, ∀ hp : p.Prime, ∀ hp8 : p % 8 = 3, n < p →
      letI : Fact p.Prime := ⟨hp⟩
      Nonempty ((D n).UnramifiedLocalInputs p (reductionCurve p)
        (reductionPoint p (by omega : p ≠ 2)))

theorem MainUnramifiedLocalInputs.toGeometric
    {D : MainGeometricDivisionFamily} {Y₀ : ℝ}
    (h : MainUnramifiedLocalInputs D Y₀) : MainGeometricLocalInputs D Y₀ := by
  intro n hn hYn p hp hp8 hnp
  let : Fact p.Prime := ⟨hp⟩
  obtain ⟨d⟩ := h n hn hYn p hp hp8 hnp
  exact ⟨d.toLocalInputs⟩

/-- The quantitative conclusion for the actual curve and point, with
canonical coordinate fields and canonical arithmetic Frobenius. -/
theorem main_curve_proportion_from_constructed_unramified_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : d.toGeometricDivisionFamily.GlobalInputs S Yarith)
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f) :
    ∃ κ : ℝ, 0 < κ ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (κ / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤
          goodPrimeCount MainPrimitivePrime x :=
  main_curve_proportion_from_constructed_fields signed sources d S Yarith
    hglobal hlocal.toGeometric f hanalytic

theorem main_curve_infinitely_many_from_constructed_unramified_fields
    (signed : Sieve.SignedReplacement.SignedScalarCriterion)
    (sources : Sieve.AcceptedSuccessorSieveSources)
    (d : AlgebraicClosureDivisionFamily exampleCurve examplePoint)
    (S : Finset ℕ) (Yarith : ℝ)
    (hglobal : d.toGeometricDivisionFamily.GlobalInputs S Yarith)
    (hlocal : MainUnramifiedLocalInputs d.toGeometricDivisionFamily Yarith)
    (f : SplittingSmoothing) (hanalytic : ClassicalDedekindAnalyticStatements f)
    {N : ℝ} (hN : 2 ≤ N) (hQRH : DedekindQRH N) :
    Set.Infinite {p : ℕ | p.Prime ∧ MainPrimitivePrime p} :=
  main_curve_infinitely_many_of_quantitative_bound
    (main_curve_proportion_from_constructed_unramified_fields signed sources d S Yarith
      hglobal hlocal f hanalytic) hN hQRH

end Elliptic
