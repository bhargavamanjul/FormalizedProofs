module

public import Elliptic.Assembly
public import Elliptic.CurveReduction
public import Elliptic.CyclicReduction

/-!
# The concrete elliptic family used by the counting assembly

At an odd prime the group and point are the actual mathlib reduction of
`y²=x³-2x` and `(2,2)`. At all other natural-number parameters we use the
trivial group, so that the counting interface is a total family. No
assertion about generation is made at those excluded parameters.
-/

@[expose] public section

noncomputable section

set_option backward.isDefEq.respectTransparency false

namespace Elliptic

structure ConcretePointFiber where
  Carrier : Type
  group : AddCommGroup Carrier
  finite : Finite Carrier
  point : Carrier

def ConcretePointFiber.equiv {F H : ConcretePointFiber} (h : F = H) :
    letI := F.group
    letI := H.group
    F.Carrier ≃+ H.Carrier := by
  cases h
  letI := F.group
  exact AddEquiv.refl _

theorem ConcretePointFiber.equiv_point {F H : ConcretePointFiber} (h : F = H) :
    ConcretePointFiber.equiv h F.point = H.point := by
  cases h
  rfl

def mainCurveGoodFiber (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) : ConcretePointFiber where
  Carrier := (reductionCurve p).toAffine.Point
  group := inferInstance
  finite := inferInstance
  point := reductionPoint p hp2

def mainCurveFiber (p : ℕ) : ConcretePointFiber :=
  if hp : p.Prime ∧ p ≠ 2 then
    letI : Fact p.Prime := ⟨hp.1⟩
    mainCurveGoodFiber p hp.2
  else
    { Carrier := PUnit
      group := inferInstance
      finite := inferInstance
      point := PUnit.unit }

theorem mainCurveFiber_eq_good (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) :
    mainCurveFiber p = mainCurveGoodFiber p hp2 := by
  unfold mainCurveFiber
  rw [dite_eq_left (show p.Prime ∧ p ≠ 2 from ⟨hp.out, hp2⟩)]

def mainCurveGroup (p : ℕ) : Type := (mainCurveFiber p).Carrier

instance mainCurveGroupAddCommGroup (p : ℕ) : AddCommGroup (mainCurveGroup p) :=
  (mainCurveFiber p).group

instance mainCurveGroupFinite (p : ℕ) : Finite (mainCurveGroup p) :=
  (mainCurveFiber p).finite

def mainCurvePoint (p : ℕ) : mainCurveGroup p := (mainCurveFiber p).point

def mainCurveFamily : FinitePointFamily where
  Group := mainCurveGroup
  group := fun _ => inferInstance
  finite := mainCurveGroupFinite
  point := mainCurvePoint

/-- Identify the total family with the actual elliptic group at an odd prime. -/
def mainCurveGroupEquiv (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) :
    mainCurveGroup p ≃+ (reductionCurve p).toAffine.Point :=
  ConcretePointFiber.equiv (mainCurveFiber_eq_good p hp2)

theorem mainCurveGroupEquiv_point (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) :
    mainCurveGroupEquiv p hp2 (mainCurvePoint p) = reductionPoint p hp2 :=
  ConcretePointFiber.equiv_point (mainCurveFiber_eq_good p hp2)

/-- The group in the counting theorem has the proved cardinality `p+1`. -/
theorem mainCurveFamily_card (p : ℕ) [hp : Fact p.Prime] (hp4 : p % 4 = 3) :
    Nat.card (mainCurveFamily.Group p) = p + 1 := by
  have hp2 : p ≠ 2 := by omega
  calc
    _ = Nat.card (reductionCurve p).toAffine.Point :=
      Nat.card_congr (mainCurveGroupEquiv p hp2).toEquiv
    _ = _ := card_reduction_points p hp4

/-- The selected point is not a double on the progression used in Theorem 1. -/
theorem mainCurveFamily_not_double (p : ℕ) [hp : Fact p.Prime] (hp8 : p % 8 = 3) :
    ¬ ∃ R : mainCurveFamily.Group p, (2 : ℕ) • R = mainCurveFamily.point p := by
  have hp2 : p ≠ 2 := by omega
  rintro ⟨R, hR⟩
  change (2 : ℕ) • R = mainCurvePoint p at hR
  have h := congrArg (mainCurveGroupEquiv p hp2) hR
  rw [map_nsmul, mainCurveGroupEquiv_point, two_nsmul] at h
  exact reductionPoint_not_double p hp2 hp8 _ h

/-- The actual group has at most one nonidentity element killed by two. -/
theorem mainCurveFamily_two_torsion (p : ℕ) [hp : Fact p.Prime] (hp8 : p % 8 = 3) :
    ∃ T : mainCurveFamily.Group p, T ≠ 0 ∧
      ∀ R : mainCurveFamily.Group p, (2 : ℕ) • R = 0 ↔ R = 0 ∨ R = T := by
  have hp2 : p ≠ 2 := by omega
  let e := mainCurveGroupEquiv p hp2
  refine ⟨e.symm (reductionTwoTorsion p hp2), ?_, ?_⟩
  · intro hT
    have h := congrArg e hT
    simp only [AddEquiv.apply_symm_apply, map_zero] at h
    exact reductionTwoTorsion_ne_zero p hp2 h
  · intro R
    have h := reduction_two_torsion_iff p hp2 hp8 (e R)
    rw [← two_nsmul, ← map_nsmul, ← map_zero e] at h
    simpa only [e.injective.eq_iff, ← e.eq_symm_apply] using h

/-- The exact classical finite-field elliptic group structure theorem used
at the current arithmetic boundary. Its existence is not asserted here.
In particular this is an arithmetic input, not an analytic estimate. -/
def ExampleFiniteGroupStructure : Prop :=
  ∀ p : ℕ, p.Prime → p % 8 = 3 →
    ∃ d₁ d₂ : ℕ, 0 < d₁ ∧ 0 < d₂ ∧
      ∃ _e : mainCurveGroup p ≃+ ZMod d₁ × ZMod d₂,
        d₁ ∣ d₂ ∧ d₁ ∣ p - 1

/-- Cyclicity is deduced from the exact classical structure input, the
proved point count, and the proved uniqueness of nonzero 2-torsion. -/
theorem mainCurveFamily_cyclic (hstructure : ExampleFiniteGroupStructure)
    (p : ℕ) [hp : Fact p.Prime] (hp8 : p % 8 = 3) :
    IsAddCyclic (mainCurveFamily.Group p) := by
  change IsAddCyclic (mainCurveGroup p)
  obtain ⟨d₁, d₂, hd₁, hd₂, e, hdiv, hminus⟩ := hstructure p hp.out hp8
  obtain ⟨T, _, hT⟩ := mainCurveFamily_two_torsion p hp8
  have htwo : Nat.card (TwoTorsion (mainCurveGroup p)) ≤ 2 :=
    card_twoTorsion_le_two T (fun R hR => (hT R).1 hR)
  have hp4 : p % 4 = 3 := by omega
  exact isAddCyclic_of_elliptic_structure (G := mainCurveGroup p)
    hp.out.one_le hd₁ hd₂ e hdiv hminus
    (mainCurveFamily_card p hp4) htwo

end Elliptic
