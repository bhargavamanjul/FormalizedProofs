module

public import Elliptic.FinalReduction

/-! # Infinitude from a positive proportion of actual primes -/

@[expose] public section
namespace Elliptic
open Filter
open scoped Topology

/-- A positive eventual proportion gives infinitely many actual good primes;
only Euclid's theorem through the divergence of prime counting is used. -/
theorem infinite_good_primes_of_positive_proportion (Good : ℕ → Prop)
    (h : HasPositivePrimeProportion Good) : Set.Infinite {p : ℕ | p.Prime ∧ Good p} := by
  classical
  intro hfinite
  obtain ⟨d, hd, hbound⟩ := h
  let s := hfinite.toFinset
  have hupper (x : ℝ) : goodPrimeCount Good x ≤ (s.card : ℝ) := by
    apply Nat.cast_le.mpr
    apply Finset.card_le_card
    intro p hp
    have hp' := Finset.mem_filter.mp hp
    have hprime := (Nat.mem_primesLE.mp hp'.1).2
    exact hfinite.mem_toFinset.mpr ⟨hprime, hp'.2⟩
  have hnat := (tendsto_natCast_atTop_atTop : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop).eventually hbound
  have hpi : Tendsto (fun n : ℕ => (Nat.primeCounting n : ℝ)) atTop atTop :=
    tendsto_natCast_atTop_atTop.comp Nat.tendsto_primeCounting
  have hlarge : ∀ᶠ n : ℕ in atTop, (s.card : ℝ) < d * (Nat.primeCounting n : ℝ) :=
    (hpi.const_mul_atTop hd).eventually (eventually_gt_atTop (s.card : ℝ))
  obtain ⟨n, hn, hl⟩ := (hnat.and hlarge).exists
  have hn' : d * (Nat.primeCounting n : ℝ) ≤ goodPrimeCount Good n := by simpa using hn
  exact (not_lt_of_ge (hn'.trans (hupper n))) hl

end Elliptic
