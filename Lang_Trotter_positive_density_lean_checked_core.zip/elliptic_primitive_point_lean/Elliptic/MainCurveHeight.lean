module

public import Elliptic.ActualDenominators
public import Mathlib.NumberTheory.Height.EllipticCurve

/-!
# The quadratic height bound for the actual rational multiples

Mathlib proves the approximate parallelogram law for the naive height of
elliptic points. A discrete second-difference argument below deduces the
quadratic bound along `n • P`. Thus the height bound used in the counting
argument is a theorem, not an additional analytic or arithmetic assumption.
-/

@[expose] public section

namespace Elliptic

/-- A bounded second difference gives quadratic growth. No convergence or
canonical-height existence theorem is needed for this upper bound. -/
theorem quadratic_bound_of_second_difference
    (u : ℕ → ℝ) (C : ℝ) (hzero : u 0 = 0)
    (hstep : ∀ n : ℕ, u (n + 2) + u n - 2 * u (n + 1) ≤ 2 * u 1 + C) :
    ∃ D : ℝ, 0 < D ∧ ∀ n : ℕ, u n ≤ D * (n : ℝ) ^ 2 := by
  let D := |u 1| + |C| + 1
  have hD : 0 < D := by dsimp [D]; positivity
  have hfirst : u 1 ≤ D := by
    have hu := le_abs_self (u 1)
    have hC := abs_nonneg C
    dsimp [D]
    linarith
  have hsecond : 2 * u 1 + C ≤ 2 * D := by
    have hu := le_abs_self (u 1)
    have hC := le_abs_self C
    have hC0 := abs_nonneg C
    dsimp [D]
    linarith
  have hdiff : ∀ n : ℕ, u (n + 1) - u n ≤ D * (2 * (n : ℝ) + 1) := by
    intro n
    induction n with
    | zero => simpa only [Nat.cast_zero, mul_zero, zero_add, mul_one, hzero,
        sub_zero] using hfirst
    | succ n ih =>
      have hs := hstep n
      simp only [Nat.cast_add, Nat.cast_one]
      change u (n + 2) - u (n + 1) ≤ D * (2 * ((n : ℝ) + 1) + 1)
      linarith
  refine ⟨D, hD, ?_⟩
  intro n
  induction n with
  | zero => simp [hzero]
  | succ n ih =>
    have hd := hdiff n
    simp only [Nat.cast_add, Nat.cast_one]
    change u (n + 1) ≤ D * ((n : ℝ) + 1) ^ 2
    nlinarith

theorem examplePoint_naiveHeight_eq (Q : exampleCurve.toAffine.Point) :
    Q.naiveHeight = Height.logHeight₁ (examplePointX Q) := by
  rw [WeierstrassCurve.Affine.Point.naiveHeight_eq_logHeight₁]
  cases Q with
  | zero => simp [examplePointX, WeierstrassCurve.Affine.Point.xRep]
  | some x y h => rfl

/-- The required quadratic height bound is derived from mathlib's proved
elliptic approximate parallelogram law, for the actual curve and point. -/
theorem exists_example_quadratic_height_bound :
    ∃ C : ℝ, 0 < C ∧ ExampleQuadraticHeightBound C := by
  classical
  obtain ⟨C, hC⟩ :=
    WeierstrassCurve.Affine.approx_parallelogram_law exampleCurve.toAffine
  let u : ℕ → ℝ := fun n => (n • examplePoint).naiveHeight
  have hzero : u 0 = 0 := by
    dsimp [u]
    rw [zero_nsmul, examplePoint_naiveHeight_eq]
    simp [examplePointX]
  have hstep : ∀ n : ℕ, u (n + 2) + u n - 2 * u (n + 1) ≤ 2 * u 1 + C := by
    intro n
    have h := (le_abs_self _).trans (hC ((n + 1) • examplePoint) examplePoint)
    have hadd : (n + 1) • examplePoint + examplePoint = (n + 2) • examplePoint := by
      simp only [add_nsmul, one_nsmul, two_nsmul, add_assoc]
    have hsub : (n + 1) • examplePoint - examplePoint = n • examplePoint := by
      rw [add_nsmul, one_nsmul, add_sub_cancel_right]
    rw [hadd, hsub] at h
    have hu1 : u 1 = examplePoint.naiveHeight := by simp [u]
    change u (n + 2) + u n - 2 * (u (n + 1) + examplePoint.naiveHeight) ≤ C at h
    rw [← hu1] at h
    linarith
  obtain ⟨D, hD, hu⟩ := quadratic_bound_of_second_difference u C hzero hstep
  refine ⟨D, hD, ?_⟩
  intro n _hn
  simpa only [u, examplePoint_naiveHeight_eq] using hu n

/-- Consequently the actual denominator sequence has a uniform quadratic
logarithmic bound, with no height-bound hypothesis. -/
theorem exists_example_denominator_log_bound :
    ∃ C : ℝ, 0 < C ∧ ∀ n : ℕ, 0 < n →
      Real.log (exampleMultipleDenominator n : ℝ) ≤ C * (n : ℝ) ^ 2 := by
  obtain ⟨C, hC, hheight⟩ := exists_example_quadratic_height_bound
  exact ⟨C, hC, fun _ hn => exampleMultipleDenominator_log_le hheight hn⟩

end Elliptic
