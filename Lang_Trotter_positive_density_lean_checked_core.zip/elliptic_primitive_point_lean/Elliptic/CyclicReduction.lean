module

public import Elliptic.GroupBridge

/-!
# Cyclicity from the classical elliptic group structure

The standard structure theorem for an elliptic curve over a finite field
gives invariant factors `d₁ ∣ d₂` with `d₁ ∣ p-1`. This file proves the
remaining deduction for a group of order `p+1` with at most two points killed
by two. The structure theorem is an explicit input, not asserted here.
-/

@[expose] public section

noncomputable section

namespace Elliptic

abbrev TwoTorsion (G : Type*) [AddGroup G] := {g : G // (2 : ℕ) • g = 0}

def twoTorsionEquiv {G H : Type*} [AddGroup G] [AddGroup H] (e : G ≃+ H) :
    TwoTorsion G ≃ TwoTorsion H where
  toFun g := ⟨e g, by rw [← map_nsmul, g.property, map_zero]⟩
  invFun h := ⟨e.symm h, by rw [← map_nsmul, h.property, map_zero]⟩
  left_inv g := by apply Subtype.ext; exact e.symm_apply_apply g
  right_inv h := by apply Subtype.ext; exact e.apply_symm_apply h

def twoTorsionProdEquiv (G H : Type*) [AddGroup G] [AddGroup H] :
    TwoTorsion (G × H) ≃ TwoTorsion G × TwoTorsion H where
  toFun z := (⟨z.val.1, congrArg Prod.fst z.property⟩,
    ⟨z.val.2, congrArg Prod.snd z.property⟩)
  invFun z := ⟨(z.1.val, z.2.val), Prod.ext z.1.property z.2.property⟩
  left_inv z := by apply Subtype.ext; rfl
  right_inv z := by cases z; rfl

theorem card_twoTorsion_zmod (d : ℕ) [NeZero d] :
    Nat.card (TwoTorsion (ZMod d)) = d.gcd 2 := by
  change Nat.card (nsmulAddMonoidHom (2 : ℕ) : ZMod d →+ ZMod d).ker = _
  simpa only [Nat.card_zmod] using
    IsAddCyclic.card_nsmulAddMonoidHom_ker (ZMod d) 2

/-- At most one specified nonzero point of order two gives the cardinal
bound needed below. The designated point need not actually be nonzero for
this upper bound. -/
theorem card_twoTorsion_le_two {G : Type*} [AddGroup G] [Finite G]
    (T : G) (h : ∀ R : G, (2 : ℕ) • R = 0 → R = 0 ∨ R = T) :
    Nat.card (TwoTorsion G) ≤ 2 := by
  classical
  let f : TwoTorsion G → Bool := fun R => decide (R.val = 0)
  have hf : Function.Injective f := by
    intro R S heq
    apply Subtype.ext
    have hRS : (R.val = 0) ↔ S.val = 0 := by
      simpa only [f, decide_eq_decide] using heq
    rcases h R.val R.property with hR | hR
    · exact hR.trans (hRS.mp hR).symm
    · rcases h S.val S.property with hS | hS
      · exact (hRS.mpr hS).trans hS.symm
      · exact hR.trans hS.symm
  have hb : Nat.card Bool = 2 := by simp [Nat.card_eq_fintype_card]
  simpa only [hb] using Nat.card_le_card_of_injective f hf

/-- The finite-group deduction of cyclicity from the exact invariant-factor
form of the classical elliptic group structure theorem. -/
theorem isAddCyclic_of_elliptic_structure {G : Type*} [AddCommGroup G] [Finite G]
    {p d₁ d₂ : ℕ} (hp : 1 ≤ p) (hd₁ : 0 < d₁) (hd₂ : 0 < d₂)
    (e : G ≃+ ZMod d₁ × ZMod d₂) (hdiv : d₁ ∣ d₂) (hminus : d₁ ∣ p - 1)
    (hcard : Nat.card G = p + 1) (htwo : Nat.card (TwoTorsion G) ≤ 2) :
    IsAddCyclic G := by
  classical
  have : NeZero d₁ := ⟨hd₁.ne'⟩
  have : NeZero d₂ := ⟨hd₂.ne'⟩
  have hprod : Nat.card G = d₁ * d₂ := by
    rw [Nat.card_congr e.toEquiv, Nat.card_prod, Nat.card_zmod, Nat.card_zmod]
  have hplus : d₁ ∣ p + 1 := ⟨d₂, hcard.symm.trans hprod⟩
  have hdvd2 : d₁ ∣ 2 := by
    have hsub := Nat.dvd_sub hplus hminus
    have heq : p + 1 - (p - 1) = 2 := by omega
    simpa only [heq] using hsub
  rcases (Nat.dvd_prime Nat.prime_two).mp hdvd2 with hone | htwoeq
  · subst d₁
    let f : G →+ ZMod d₂ := (AddMonoidHom.snd (ZMod 1) (ZMod d₂)).comp e.toAddMonoidHom
    apply isAddCyclic_of_injective f
    intro a b hab
    apply e.injective
    exact Prod.ext (Subsingleton.elim _ _) hab
  · have hcardTwo : Nat.card (TwoTorsion G) = 4 := by
      rw [Nat.card_congr (twoTorsionEquiv e),
        Nat.card_congr (twoTorsionProdEquiv (ZMod d₁) (ZMod d₂)), Nat.card_prod,
        card_twoTorsion_zmod, card_twoTorsion_zmod, htwoeq]
      have hgcd : d₂.gcd 2 = 2 := Nat.gcd_eq_right_iff_dvd.mpr (htwoeq ▸ hdiv)
      simp [hgcd]
    omega

end Elliptic
