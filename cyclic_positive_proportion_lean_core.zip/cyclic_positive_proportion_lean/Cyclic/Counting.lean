import Mathlib

/-!
# Removing finitely many splitting obstructions

These lemmas are purely finite combinatorics. They implement the union bound
used in Section 5 of the cyclic-reduction manuscript; no independence of the
candidate condition and the splitting conditions is assumed.
-/

namespace Cyclic

open scoped BigOperators

variable {α ι : Type*} [DecidableEq α]

/-- The cardinality of a finite union is at most the sum of the cardinalities. -/
theorem obstruction_union_card_le (indices : Finset ι) (bad : ι → Finset α) :
    (indices.biUnion bad).card ≤ ∑ i ∈ indices, (bad i).card := by
  exact Finset.card_biUnion_le

/-- Every candidate is either good or has one of the indexed obstructions. -/
theorem candidate_card_le_good_add_obstructions
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad) :
    candidates.card ≤ good.card + ∑ i ∈ indices, (bad i).card := by
  calc
    candidates.card ≤ (good ∪ indices.biUnion bad).card := Finset.card_le_card hcover
    _ ≤ good.card + (indices.biUnion bad).card := Finset.card_union_le _ _
    _ ≤ good.card + ∑ i ∈ indices, (bad i).card :=
      Nat.add_le_add_left (obstruction_union_card_le indices bad) good.card

/-- The real-valued subtraction form needed for the analytic lower bounds. -/
theorem candidate_removal
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad) :
    (candidates.card : ℝ) - ∑ i ∈ indices, ((bad i).card : ℝ) ≤
      (good.card : ℝ) := by
  have hnat := candidate_card_le_good_add_obstructions candidates good indices bad hcover
  have hreal : (candidates.card : ℝ) ≤
      (good.card : ℝ) + ∑ i ∈ indices, ((bad i).card : ℝ) := by
    exact_mod_cast hnat
  linarith

/-- A pointwise obstruction statement is enough to construct the covering. -/
theorem candidate_removal_of_witness
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hwitness : ∀ p ∈ candidates, p ∉ good → ∃ i ∈ indices, p ∈ bad i) :
    (candidates.card : ℝ) - ∑ i ∈ indices, ((bad i).card : ℝ) ≤
      (good.card : ℝ) := by
  apply candidate_removal
  intro p hp
  by_cases hgood : p ∈ good
  · exact Finset.mem_union_left _ hgood
  · rcases hwitness p hp hgood with ⟨i, hi, hbad⟩
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨i, hi, hbad⟩)

/-- Combine a candidate lower bound and an unrestricted obstruction upper bound. -/
theorem candidate_removal_bounds
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (candidateLower badUpper : ℝ)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad)
    (hcandidates : candidateLower ≤ (candidates.card : ℝ))
    (hbad : (∑ i ∈ indices, ((bad i).card : ℝ)) ≤ badUpper) :
    candidateLower - badUpper ≤ (good.card : ℝ) := by
  have hremove := candidate_removal candidates good indices bad hcover
  linarith

end Cyclic
