import Cyclic.Main
import Cyclic.AnalyticInputs
import Cyclic.EllipticModel
import Cyclic.Character
import Cyclic.Necessity
import Cyclic.ArithmeticInputs

/-!
# Manuscript theorem, with its complete conditional interface

The conclusion refers to Mathlib's actual elliptic point groups over ZMod p.
The deep analytic inputs and the classical arithmetic realization are explicit
arguments, not axioms or hidden instances. The character/CRT progression is
proved. The construction of division fields and their zeta functions and the
standard Galois/torsion theorems remain external.
-/

noncomputable section
open Filter
open scoped Topology
namespace Cyclic

def ellipticData (W : WeierstrassCurve ℤ) (split : ℕ → ℕ → Prop) : ReductionData where
  good := EllipticModel.GoodReduction W
  cyclic := EllipticModel.CyclicReduction W
  split := split

/-- Actual prime count for good cyclic reductions of an integral equation. -/
def ellipticCyclicCount (W : WeierstrassCurve ℤ) (X : ℝ) : ℝ :=
  (primeUpTo (fun p => EllipticModel.GoodReduction W p ∧
    EllipticModel.CyclicReduction W p) X).card

/-- Explicit boundary for the classical arithmetic and its realization.

* `character` uses the 2-division-field quotient and Kronecker--Weber.
* `criterion` is the standard torsion/Frobenius criterion,
  Weil pairing, and Hasse bound.
* `fields` is Serre open image/CM and the ramification/discriminant estimate.

The concrete character, CRT, exact-power-of-two, and progression deductions
are proved in the arithmetic modules. Only the listed classical arithmetic
realizations are inputs.
-/
structure ClassicalArithmetic (W : WeierstrassCurve ℤ) where
  split : ℕ → ℕ → Prop
  division : DivisionFields (ellipticData W split)
  fields : RawFieldBounds division
  character : EllipticModel.Admissible W → Nonempty (TwoDivisionCharacter (ellipticData W split))
  criterion : CyclicityCriterion (ellipticData W split)

/-- The reusable predecessor sieve, for every admissible fixed progression.
This is the cited varying-cofactor consequence of the agreed earlier work and
OpenAI marked estimates, not a new axiom declaration. -/
def PredecessorSieveTheorem : Prop := ∀ g : Progression, CofactorSieve g

/-- The quantitative manuscript theorem for actual reduction point groups.
The same c>0 works for every N for which the zero-free hypothesis is supplied. -/
theorem quantitative_cyclic_reductions
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.Admissible W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → ZeroFree arith.division N →
      (∀ᶠ x : ℝ in atTop, c/(N*Real.log N)*(x/Real.log x) ≤
        ellipticCyclicCount W (2*x)-ellipticCyclicCount W x) ∧
      c/(N*Real.log N) ≤
        Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop := by
  rcases arith.character hW with ⟨char⟩
  rcases progression_from_two_division_character _ char arith.criterion with ⟨g,hg⟩
  exact quantitative_of_sieve_and_split_bound
    (ellipticData W arith.split) g (ZeroFree arith.division) hg (sieve g)
    (exists_uniform_split_bound _ arith.division arith.fields.toFieldBounds explicit primes) pnt

/-- The positive-proportion conclusion at the agreed Cureton--Thorner width.
No full-density statement is asserted. -/
theorem positive_proportion_cyclic_reductions
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.Admissible W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) (cureton_thorner : ZeroFree arith.division 32) :
    0 < Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop := by
  rcases arith.character hW with ⟨char⟩
  rcases progression_from_two_division_character _ char arith.criterion with ⟨g,hg⟩
  exact positive_proportion_of_width_32
    (ellipticData W arith.split) g (ZeroFree arith.division) hg (sieve g)
    (exists_uniform_split_bound _ arith.division arith.fields.toFieldBounds explicit primes) pnt
    cureton_thorner

/-- Standard injectivity of prime-to-p torsion specialization. The group
theoretic obstruction and zero-density conclusion below are proved. -/
def TwoTorsionSpecialization (W : WeierstrassCurve ℤ) : Prop :=
  EllipticModel.FullRationalTwoTorsion W →
    ∀ p : ℕ, ∀ hp : p.Prime, 3 ≤ p → EllipticModel.GoodReduction W p →
      letI : Fact p.Prime := ⟨hp⟩
      ∃ P Q : (EllipticModel.reduction W p).toAffine.Point,
        P ≠ 0 ∧ Q ≠ 0 ∧ P ≠ Q ∧ (2 : ℕ) • P = 0 ∧ (2 : ℕ) • Q = 0

theorem zero_proportion_of_full_rational_two_torsion
    (W : WeierstrassCurve ℤ) (hfull : EllipticModel.FullRationalTwoTorsion W)
    (specialization : TwoTorsionSpecialization W) (pnt : PrimeNumberTheorem) :
    Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop = 0 := by
  apply cyclic_liminf_eq_zero_of_odd_noncyclic (ellipticData W (fun _ _ => False))
  · intro p hp hp3 hgood
    letI : Fact p.Prime := ⟨hp⟩
    rcases specialization hfull p hp hp3 hgood with ⟨P,Q,hP,hQ,hPQ,hP2,hQ2⟩
    exact EllipticModel.not_cyclicReduction_of_two_torsion W p hP hQ hPQ hP2 hQ2
  · exact pnt

theorem positive_proportion_iff_no_full_rational_two_torsion
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.RationalElliptic W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) (cureton_thorner : ZeroFree arith.division 32)
    (specialization : TwoTorsionSpecialization W) :
    (0 < Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop) ↔
      ¬EllipticModel.FullRationalTwoTorsion W := by
  constructor
  · intro hpos hfull
    rw [zero_proportion_of_full_rational_two_torsion W hfull specialization pnt] at hpos
    exact (lt_irrefl 0) hpos
  · intro hnotfull
    exact positive_proportion_cyclic_reductions W ⟨hW,hnotfull⟩ arith explicit
      sieve primes pnt cureton_thorner

end Cyclic
