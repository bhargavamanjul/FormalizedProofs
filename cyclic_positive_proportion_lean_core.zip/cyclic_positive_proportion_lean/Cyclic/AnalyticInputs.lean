import Cyclic.Definitions
import Cyclic.Splitting
import Cyclic.FieldDiscriminant

/-!
# Explicit external analytic inputs and their uniform consequence

`DivisionFields` records the numerical and analytic data of the division
fields. It does not assert that those data come from a number field. Their
connection with the reduction predicates is made explicitly by the
prime-ideal contribution hypothesis below. The arithmetic construction of
these data and the cited analytic theorems are external inputs.

The theorem at the end proves the bound needed for subtraction; the uniform
summed bound itself is not an assumption.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

structure DivisionFields (D : ReductionData) where
  degree : ℕ → ℕ
  logDisc : ℕ → ℝ
  zeta : ℕ → ℂ → ℂ
  idealSum : ℕ → ℝ → ℝ

/-- The asserted zero-free half-plane, excluding the pole at one. -/
def ZeroFree {D : ReductionData} (f : DivisionFields D) (N : ℝ) : Prop :=
  ∀ ell : ℕ, ell.Prime → ∀ s : ℂ,
    1 - 1 / N < s.re → s ≠ 1 → f.zeta ell s ≠ 0

/-- Degree and root-discriminant estimates, with constants independent of N. -/
structure FieldBounds {D : ReductionData} (f : DivisionFields D) where
  a : ℝ
  K : ℝ
  a_pos : 0 < a
  K_pos : 0 < K
  degree_lower : ∀ ell : ℕ, ell.Prime → a * (ell : ℝ) ^ 2 ≤ f.degree ell
  root_discriminant : ∀ ell : ℕ, ell.Prime →
    f.logDisc ell + (f.degree ell : ℝ) ≤
      K * (f.degree ell : ℝ) * Real.log (2 * (ell : ℝ))

/-- A less processed version of the classical field inputs. The root-
discriminant estimate is derived from these inequalities by `toFieldBounds`. -/
structure RawFieldBounds {D : ReductionData} (f : DivisionFields D) where
  R : ℝ
  R_one_le : 1 ≤ R
  a : ℝ
  a_pos : 0 < a
  degree_lower : ∀ ell : ℕ, ell.Prime → a * (ell : ℝ) ^ 2 ≤ f.degree ell
  degree_upper : ∀ ell : ℕ, ell.Prime → (f.degree ell : ℝ) ≤ (ell : ℝ) ^ (4 : ℕ)
  raw_discriminant : ∀ ell : ℕ, ell.Prime →
    f.logDisc ell ≤ ((f.degree ell : ℝ) - 1) *
      (Real.log R + Real.log (ell : ℝ)) +
        (f.degree ell : ℝ) * Real.log (f.degree ell : ℝ)

/-- Construct the required uniform field bounds from the raw arithmetic
inequalities; the logarithmic manipulation is proved, not an extra input. -/
def RawFieldBounds.toFieldBounds {D : ReductionData} {f : DivisionFields D}
    (raw : RawFieldBounds f) : FieldBounds f where
  a := raw.a
  K := rootDiscriminantConstant raw.R
  a_pos := raw.a_pos
  K_pos := rootDiscriminantConstant_pos raw.R_one_le
  degree_lower := raw.degree_lower
  root_discriminant := by
    intro ell hell
    have hellpos : (0 : ℝ) < ell := by exact_mod_cast hell.pos
    have hdegreepos : (0 : ℝ) < f.degree ell :=
      lt_of_lt_of_le (mul_pos raw.a_pos (sq_pos_of_pos hellpos))
        (raw.degree_lower ell hell)
    have hdegreeposNat : 0 < f.degree ell := by exact_mod_cast hdegreepos
    have hdegreeone : 1 ≤ f.degree ell := Nat.succ_le_of_lt hdegreeposNat
    apply root_discriminant_from_raw
    · exact_mod_cast hdegreeone
    · exact_mod_cast hell.two_le
    · exact raw.R_one_le
    · exact raw.degree_upper ell hell
    · exact raw.raw_discriminant ell hell

/-- The cited smoothed explicit formula and the standard contribution of
completely split primes to its nonnegative ideal sum are kept visible. -/
structure SmoothedExplicitFormula (D : ReductionData) (f : DivisionFields D) where
  F : ℝ
  F_pos : 0 < F
  split_contribution : ∀ ell : ℕ, ell.Prime → ∀ x : ℝ, 2 ≤ x →
    splitCount D ell x * (f.degree ell : ℝ) * Real.log x ≤ f.idealSum ell x
  upper : ∀ N : ℝ, 2 ≤ N → ZeroFree f N → ∀ ell : ℕ, ell.Prime →
    ∀ x : ℝ, 2 ≤ x →
      f.idealSum ell x ≤
        F * (x + x ^ (1 - 1 / N) * (f.logDisc ell + (f.degree ell : ℝ)))

/-- The elementary prime reciprocal-square tail and Chebyshev bound. -/
structure PrimeEstimates where
  H : ℝ
  J : ℝ
  H_nonneg : 0 ≤ H
  J_nonneg : 0 ≤ J
  reciprocal : ∀ Y z : ℝ, 3 ≤ Y → 2 ≤ z →
    (∑ ell ∈ primeIndices Y z, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y)
  chebyshev : ∀ Y z : ℝ, 3 ≤ Y → 2 ≤ z →
    (∑ ell ∈ primeIndices Y z, Real.log (2 * (ell : ℝ))) ≤ J * z

/-- Uniformity in the zero-free width is a proved consequence of the input
quantifiers: the constants are chosen before N, ε, and Y. -/
theorem exists_uniform_split_bound
    (D : ReductionData) (f : DivisionFields D)
    (fields : FieldBounds f) (explicit : SmoothedExplicitFormula D f)
    (primes : PrimeEstimates) :
    ∃ C₁ C₂ : ℝ, ∀ N : ℝ, 2 ≤ N → ZeroFree f N →
      ∀ ε Y : ℝ, 0 < ε → 3 ≤ Y →
        ∀ᶠ x : ℝ in atTop,
          (∑ ell ∈ primeIndices Y (x ^ ε), splitCount D ell x) ≤
            (C₁ / (Y * Real.log Y) + C₂ * x ^ (-1 / N + ε)) *
              (x / Real.log x) := by
  refine ⟨(explicit.F / fields.a) * primes.H,
    (explicit.F * fields.K) * primes.J, ?_⟩
  intro N hN hzero ε Y hε hY
  have hgrowth : Tendsto (fun x : ℝ => x ^ ε) atTop atTop :=
    tendsto_rpow_atTop hε
  filter_upwards [eventually_ge_atTop (2 : ℝ),
    hgrowth.eventually (eventually_ge_atTop (2 : ℝ))] with x hx hxε
  have hxone : 1 < x := lt_of_lt_of_le (by norm_num) hx
  have hxpos : 0 < x := lt_trans zero_lt_one hxone
  have hlog : 0 < Real.log x := Real.log_pos hxone
  apply split_sum_normalized (primeIndices Y (x ^ ε)) (fun ell => splitCount D ell x)
    hxone (div_nonneg explicit.F_pos.le fields.a_pos.le)
    (mul_nonneg explicit.F_pos.le fields.K_pos.le)
  · intro ell hell
    have hellprime : ell.Prime := (mem_primeIndices.mp hell).1
    have hellpos : (0 : ℝ) < ell := by exact_mod_cast hellprime.pos
    have hn : (0 : ℝ) < f.degree ell :=
      lt_of_lt_of_le (mul_pos fields.a_pos (sq_pos_of_pos hellpos))
        (fields.degree_lower ell hellprime)
    exact split_individual_bound hn hellpos hxpos.le hlog
      (Real.rpow_nonneg hxpos.le _) explicit.F_pos.le fields.a_pos
      (explicit.split_contribution ell hellprime x hx)
      (explicit.upper N hN hzero ell hellprime x hx)
      (fields.degree_lower ell hellprime) (fields.root_discriminant ell hellprime)
  · exact primes.reciprocal Y (x ^ ε) hY hxε
  · exact primes.chebyshev Y (x ^ ε) hY hxε

end Cyclic
