import Cyclic.Theorems

/-!
The only kernel axioms expected below are propext, Classical.choice, Quot.sound.
The analytic and classical arithmetic assumptions are explicit theorem
arguments, so they are NOT enumerated by `#print axioms`. See ASSUMPTIONS.md.
-/

#print axioms Cyclic.exists_compatible_dirichlet_integer
#print axioms Cyclic.progression_from_two_division_character
#print axioms Cyclic.short_obstruction
#print axioms Cyclic.root_discriminant_from_raw
#print axioms Cyclic.exists_uniform_split_bound
#print axioms Cyclic.exists_uniform_parameters
#print axioms Cyclic.lower_proportion_of_dyadic
#print axioms Cyclic.quantitative_cyclic_reductions
#print axioms Cyclic.positive_proportion_cyclic_reductions
#print axioms Cyclic.positive_proportion_iff_no_full_rational_two_torsion
