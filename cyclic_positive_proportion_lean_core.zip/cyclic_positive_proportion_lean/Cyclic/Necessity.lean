import Cyclic.Definitions
import Cyclic.EllipticModel
import Cyclic.Density

/-!
# Necessity of excluding full rational two-torsion

The arithmetic specialization of rational two-torsion is an explicitly
separate input.  Once odd good reductions are noncyclic, this module proves
that the cyclic-prime count is at most one and that its proportion tends to
zero.  The convergence uses the stated PNT input; it is not assumed.
-/

noncomputable section
open Filter
open scoped Topology

namespace Cyclic

/-- If every good reduction at a prime at least three is noncyclic, only the
prime two can contribute to the cyclic-prime count. -/
theorem cyclicCount_le_one_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (X : ℝ) : cyclicCount D X ≤ 1 := by
  classical
  have hsub : primeUpTo (fun p => D.good p ∧ D.cyclic p) X ⊆ ({2} : Finset ℕ) := by
    intro p hp
    rcases mem_primeUpTo.mp hp with ⟨hprime, _, hgood, hcyclic⟩
    have hp2 : p = 2 := by
      by_contra hne
      have hp3 : 3 ≤ p := by have := hprime.two_le; omega
      exact hodd p hprime hp3 hgood hcyclic
    simpa using hp2
  have hcard : (primeUpTo (fun p => D.good p ∧ D.cyclic p) X).card ≤ 1 := by
    simpa using Finset.card_le_card hsub
  unfold cyclicCount
  exact_mod_cast hcard

/-- PNT implies that the reciprocal prime count tends to zero. -/
theorem inverse_primeCount_tendsto_zero (hPNT : PrimeNumberTheorem) :
    Tendsto (fun X : ℝ => 1 / primeCount X) atTop (𝓝 0) := by
  have hlog : Tendsto (fun X : ℝ => Real.log X / X) atTop (𝓝 0) := by
    simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
  have hratio : Tendsto
      (fun X : ℝ => (Real.log X / X) / (primeCount X / (X / Real.log X)))
      atTop (𝓝 0) := by
    simpa using hlog.div hPNT (by norm_num : (1 : ℝ) ≠ 0)
  apply hratio.congr'
  filter_upwards [eventually_ge_atTop (4 : ℝ),
    eventually_positive_of_pnt primeCount hPNT] with X hX hP
  have hXne : X ≠ 0 := by linarith
  have hlogne : Real.log X ≠ 0 := ne_of_gt (Real.log_pos (by linarith))
  field_simp [hXne, hlogne, ne_of_gt hP]
  ring

/-- A count bounded by one has zero proportion among primes. -/
theorem cyclic_proportion_tendsto_zero_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (hPNT : PrimeNumberTheorem) :
    Tendsto (fun X : ℝ => cyclicCount D X / primeCount X) atTop (𝓝 0) := by
  have hP := eventually_positive_of_pnt primeCount hPNT
  apply squeeze_zero' _ _ (inverse_primeCount_tendsto_zero hPNT)
  · filter_upwards [hP] with X hPX
    exact div_nonneg (cyclicCount_nonneg D X) hPX.le
  · filter_upwards [hP] with X hPX
    exact div_le_div_of_nonneg_right (cyclicCount_le_one_of_odd_noncyclic D hodd X) hPX.le

/-- In particular the lower proportion is zero. -/
theorem cyclic_liminf_eq_zero_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (hPNT : PrimeNumberTheorem) :
    Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop = 0 :=
  (cyclic_proportion_tendsto_zero_of_odd_noncyclic D hodd hPNT).liminf_eq

end Cyclic
