import Mathlib

/-!
# The local character argument

The elementary character compatibility argument does not need orthogonality.
A nontrivial group character constant away from the identity forces the source
group to have exactly two elements. For the units of a prime field, this is
precisely the exceptional prime 3.
-/

namespace Cyclic

section Local

variable {G H : Type*} [Group G] [Group H]

/-- Constancy on a nonempty set stable under multiplication forces that
multiplying element into the kernel. -/
theorem character_eq_one_of_stable_const
    (χ : G →* H) (S : Set G) (hS : S.Nonempty)
    (hconst : ∀ a ∈ S, ∀ b ∈ S, χ a = χ b)
    (h : G) (hstable : ∀ a ∈ S, h * a ∈ S) : χ h = 1 := by
  rcases hS with ⟨a, ha⟩
  have heq := hconst (h * a) (hstable a ha) a ha
  rw [map_mul] at heq
  apply mul_right_cancel (b := χ a)
  simpa using heq

/-- A nontrivial character constant on the nonidentity elements makes those
elements unique. -/
theorem nonidentity_unique_of_character_const
    (χ : G →* H)
    (hconst : ∀ a b : G, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1)
    {a b : G} (ha : a ≠ 1) (hb : b ≠ 1) : a = b := by
  rcases hnontrivial with ⟨g, hg⟩
  have hg1 : g ≠ 1 := by
    intro h
    apply hg
    simp [h]
  have hχa : χ a ≠ 1 := by
    rw [hconst a g ha hg1]
    exact hg
  by_contra hab
  have hab1 : a * b⁻¹ ≠ 1 := by
    intro h
    exact hab (eq_of_mul_inv_eq_one h)
  have hmap : χ (a * b⁻¹) = 1 := by
    rw [map_mul, map_inv, hconst a b ha hb, mul_inv_cancel]
  exact hχa ((hconst (a * b⁻¹) a hab1 ha).symm.trans hmap)

/-- The only finite source group supporting such a nontrivial character has
order two. -/
theorem card_two_of_character_const [Fintype G]
    (χ : G →* H)
    (hconst : ∀ a b : G, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : Fintype.card G = 2 := by
  classical
  rcases hnontrivial with ⟨g, hg⟩
  have hg1 : g ≠ 1 := by
    intro h
    apply hg
    simp [h]
  have hset : (Finset.univ : Finset G) = {1, g} := by
    ext a
    simp only [Finset.mem_univ, Finset.mem_insert, Finset.mem_singleton, true_iff]
    by_cases ha : a = 1
    · exact Or.inl ha
    · exact Or.inr (nonidentity_unique_of_character_const χ hconst ⟨g, hg⟩ ha hg1)
  calc
    Fintype.card G = (Finset.univ : Finset G).card := rfl
    _ = ({1, g} : Finset G).card := congrArg Finset.card hset
    _ = 2 := by simp [hg1, Ne.symm hg1]

/-- The same order-two conclusion holds after a surjective residue map.
Constancy away from the residue identity first kills the residue kernel. -/
theorem quotient_card_two_of_character_const
    {Q : Type*} [Group Q] [Fintype Q]
    (r : G →* Q) (hr : Function.Surjective r) (χ : G →* H)
    (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : Fintype.card Q = 2 := by
  classical
  have hker : ∀ g : G, r g = 1 → χ g = 1 := by
    intro g hg
    apply character_eq_one_of_stable_const χ {a | r a ≠ 1} hallowed
    · intro a ha b hb
      exact hconst a b ha hb
    · intro a ha
      change r (g * a) ≠ 1
      simpa [map_mul, hg] using ha
  rcases hnontrivial with ⟨g, hg⟩
  have hrg : r g ≠ 1 := fun h => hg (hker g h)
  have hunique : ∀ a b : Q, a ≠ 1 → b ≠ 1 → a = b := by
    intro a b ha hb
    obtain ⟨a', rfl⟩ := hr a
    obtain ⟨b', rfl⟩ := hr b
    by_contra hab
    have hquot : r (a' * b'⁻¹) ≠ 1 := by
      rw [map_mul, map_inv]
      intro heq
      exact hab (eq_of_mul_inv_eq_one heq)
    have hmap : χ (a' * b'⁻¹) = 1 := by
      rw [map_mul, map_inv, hconst a' b' ha hb, mul_inv_cancel]
    exact hg ((hconst (a' * b'⁻¹) g hquot hrg).symm.trans hmap)
  have hset : (Finset.univ : Finset Q) = {1, r g} := by
    ext a
    simp only [Finset.mem_univ, Finset.mem_insert, Finset.mem_singleton, true_iff]
    by_cases ha : a = 1
    · exact Or.inl ha
    · exact Or.inr (hunique a (r g) ha hrg)
  calc
    Fintype.card Q = (Finset.univ : Finset Q).card := rfl
    _ = ({1, r g} : Finset Q).card := congrArg Finset.card hset
    _ = 2 := by simp [hrg, Ne.symm hrg]

end Local

/-- The exceptional odd prime in the local character argument is 3. -/
theorem prime_eq_three_of_character_const
    (q : ℕ) [Fact q.Prime] {H : Type*} [Group H]
    (χ : (ZMod q)ˣ →* H)
    (hconst : ∀ a b : (ZMod q)ˣ, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : (ZMod q)ˣ, χ g ≠ 1) : q = 3 := by
  have hcard := card_two_of_character_const χ hconst hnontrivial
  rw [ZMod.card_units] at hcard
  have hq : 2 ≤ q := (Fact.out : q.Prime).two_le
  omega

/-- Prime-power residue-map version of the exceptional-prime conclusion.
Only surjectivity of the unit reduction map is needed. -/
theorem prime_eq_three_of_residue_character_const
    (q : ℕ) [Fact q.Prime] {G H : Type*} [Group G] [Group H]
    (r : G →* (ZMod q)ˣ) (hr : Function.Surjective r)
    (χ : G →* H) (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : q = 3 := by
  have hcard := quotient_card_two_of_character_const r hr χ hallowed hconst hnontrivial
  rw [ZMod.card_units] at hcard
  have hq : 2 ≤ q := (Fact.out : q.Prime).two_le
  omega

/-- The exceptional constant for a complex-valued character is -1. -/
theorem complex_character_eq_neg_one_of_residue_const
    {G Q : Type*} [Group G] [Group Q] [Fintype Q]
    (r : G →* Q) (hr : Function.Surjective r) (χ : G →* ℂˣ)
    (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1)
    {a : G} (ha : r a ≠ 1) : χ a = -1 := by
  have hcard := quotient_card_two_of_character_const r hr χ hallowed hconst hnontrivial
  have hker : ∀ g : G, r g = 1 → χ g = 1 := by
    intro g hg
    apply character_eq_one_of_stable_const χ {a | r a ≠ 1} hallowed
    · intro a ha b hb
      exact hconst a b ha hb
    · intro b hb
      change r (g * b) ≠ 1
      simpa [map_mul, hg] using hb
  have hrpow : r (a * a) = 1 := by
    rw [map_mul, ← pow_two, ← hcard]
    exact pow_card_eq_one
  have hχpow : χ a * χ a = 1 := by
    rw [← map_mul]
    exact hker (a * a) hrpow
  have hv := congrArg (fun u : ℂˣ => (u : ℂ)) hχpow
  simp only [Units.val_mul, Units.val_one] at hv
  have hne : χ a ≠ 1 := by
    rcases hnontrivial with ⟨g, hg⟩
    have hrg : r g ≠ 1 := fun h => hg (hker g h)
    rw [hconst a g ha hrg]
    exact hg
  rcases mul_self_eq_one_iff.mp hv with hval | hval
  · exact False.elim (hne (Units.ext hval))
  · apply Units.ext
    simpa using hval

section Product

open scoped BigOperators

variable {ι : Type*} [Fintype ι] {G : ι → Type*} {H : Type*} [CommGroup H]

/-- If a product of independent local functions is identically one on a
nonempty product set, each local function is constant on its allowed set. -/
theorem local_const_of_product_one
    (χ : ∀ i, G i → H) (allowed : ∀ i, Set (G i))
    (hne : ∀ i, (allowed i).Nonempty)
    (hprod : ∀ a : ∀ i, G i, (∀ i, a i ∈ allowed i) → ∏ i, χ i (a i) = 1)
    (i : ι) : ∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b := by
  classical
  choose base hbase using hne
  let T := ∏ j ∈ (Finset.univ : Finset ι) \ {i}, χ j (base j)
  have hvalue (a : G i) (ha : a ∈ allowed i) : χ i a * T = 1 := by
    have hallowed : ∀ j, Function.update base i a j ∈ allowed j := by
      intro j
      by_cases hji : j = i
      · subst j
        simpa using ha
      · simpa [Function.update_of_ne hji] using hbase j
    have hcomp : (fun j => χ j (Function.update base i a j)) =
        Function.update (fun j => χ j (base j)) i (χ i a) := by
      funext j
      by_cases hji : j = i
      · subst j
        simp
      · simp [Function.update_of_ne hji]
    have hp := hprod (Function.update base i a) hallowed
    change (∏ j, (fun k => χ k (Function.update base i a k)) j) = 1 at hp
    rw [hcomp, Finset.prod_update_of_mem (Finset.mem_univ i)] at hp
    exact hp
  intro a ha b hb
  exact mul_right_cancel ((hvalue a ha).trans (hvalue b hb).symm)

/-- The global compatibility argument: if constant local restrictions are
trivial except possibly at a unique exceptional coordinate, whose constant
value is not one, a nontrivial product character cannot be one on every
allowed tuple. The application has the exceptional coordinate q=3 and
exceptional value -1. -/
theorem exists_allowed_product_ne_one
    (χ : ∀ i, G i → H) (allowed : ∀ i, Set (G i))
    (hne : ∀ i, (allowed i).Nonempty)
    (exceptional : ι → Prop) (z : H) (hz : z ≠ 1)
    (hunique : ∀ i j, exceptional i → exceptional j → i = j)
    (hclassify : ∀ i,
      (∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b) →
      (∀ g, χ i g = 1) ∨ (exceptional i ∧ ∀ a ∈ allowed i, χ i a = z))
    (hnontrivial : ∃ i, ∃ g : G i, χ i g ≠ 1) :
    ∃ a : ∀ i, G i, (∀ i, a i ∈ allowed i) ∧ (∏ i, χ i (a i)) ≠ 1 := by
  classical
  by_contra h
  have hprod : ∀ a : ∀ i, G i, (∀ i, a i ∈ allowed i) → ∏ i, χ i (a i) = 1 := by
    intro a ha
    by_contra hneprod
    exact h ⟨a, ha, hneprod⟩
  have hlocal := local_const_of_product_one χ allowed hne hprod
  rcases hnontrivial with ⟨i, g, hg⟩
  have hi : exceptional i ∧ ∀ a ∈ allowed i, χ i a = z := by
    rcases hclassify i (hlocal i) with htrivial | hexc
    · exact False.elim (hg (htrivial g))
    · exact hexc
  have hother : ∀ j, j ≠ i → ∀ g, χ j g = 1 := by
    intro j hji
    rcases hclassify j (hlocal j) with htrivial | hexc
    · exact htrivial
    · exact False.elim (hji (hunique j i hexc.1 hi.1))
  choose base hbase using hne
  have hp : (∏ j, χ j (base j)) = χ i (base i) := by
    apply Finset.prod_eq_single_of_mem i (Finset.mem_univ i)
    intro j _ hji
    exact hother j hji (base j)
  apply hz
  calc
    z = χ i (base i) := (hi.2 (base i) (hbase i)).symm
    _ = ∏ j, χ j (base j) := hp.symm
    _ = 1 := hprod base hbase

end Product

/-- The local-residue form of manuscript Lemma 4. The maps r are the
surjective unit reductions from prime powers to prime fields. The Chinese
remainder theorem transports the resulting tuple to a residue class modulo
the conductor. -/
theorem exists_compatible_local_residues
    {ι : Type*} [Fintype ι] (q : ι → ℕ) (hq : Function.Injective q)
    (hprime : ∀ i, (q i).Prime)
    {G : ι → Type*} [∀ i, Group (G i)]
    (r : ∀ i, G i →* (ZMod (q i))ˣ)
    (hr : ∀ i, Function.Surjective (r i))
    (χ : ∀ i, G i →* ℂˣ)
    (hnontrivial : ∃ i, ∃ g : G i, χ i g ≠ 1) :
    ∃ a : ∀ i, G i,
      (∀ i, q i ≠ 2 → r i (a i) ≠ 1) ∧ (∏ i, χ i (a i)) ≠ 1 := by
  classical
  let allowed : ∀ i, Set (G i) := fun i => {a | q i = 2 ∨ r i a ≠ 1}
  have hodd_allowed (i : ι) (hi : q i ≠ 2) : ∃ a : G i, r i a ≠ 1 := by
    letI : Fact (q i).Prime := ⟨hprime i⟩
    have hqi : 2 ≤ q i := (hprime i).two_le
    have hc : 1 < Fintype.card (ZMod (q i))ˣ := by
      rw [ZMod.card_units]
      omega
    haveI : Nontrivial (ZMod (q i))ˣ := Fintype.one_lt_card_iff_nontrivial.mp hc
    obtain ⟨b, hb⟩ := exists_ne (1 : (ZMod (q i))ˣ)
    obtain ⟨a, ha⟩ := hr i b
    exact ⟨a, by simpa [ha] using hb⟩
  have hallowed : ∀ i, (allowed i).Nonempty := by
    intro i
    by_cases hi : q i = 2
    · exact ⟨1, Or.inl hi⟩
    · obtain ⟨a, ha⟩ := hodd_allowed i hi
      exact ⟨a, Or.inr ha⟩
  have hminus : (-1 : ℂˣ) ≠ 1 := by
    intro h
    have hv := congrArg (fun u : ℂˣ => (u : ℂ)) h
    norm_num at hv
  have hclassify : ∀ i,
      (∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b) →
      (∀ g, χ i g = 1) ∨ (q i = 3 ∧ ∀ a ∈ allowed i, χ i a = -1) := by
    intro i hconst
    by_cases hi : q i = 2
    · left
      intro g
      simpa using hconst g (Or.inl hi) 1 (Or.inl hi)
    · by_cases htrivial : ∀ g, χ i g = 1
      · exact Or.inl htrivial
      · have hnontrivial_i : ∃ g, χ i g ≠ 1 := by simpa using htrivial
        have hc : ∀ a b : G i, r i a ≠ 1 → r i b ≠ 1 → χ i a = χ i b := by
          intro a b ha hb
          exact hconst a (Or.inr ha) b (Or.inr hb)
        letI : Fact (q i).Prime := ⟨hprime i⟩
        right
        constructor
        · exact prime_eq_three_of_residue_character_const (q i) (r i) (hr i)
            (χ i) (hodd_allowed i hi) hc hnontrivial_i
        · intro a ha
          have ha' : r i a ≠ 1 := ha.resolve_left hi
          exact complex_character_eq_neg_one_of_residue_const (r i) (hr i)
            (χ i) (hodd_allowed i hi) hc hnontrivial_i ha'
  obtain ⟨a, ha, hp⟩ := exists_allowed_product_ne_one (fun i => χ i) allowed
    hallowed (fun i => q i = 3) (-1 : ℂˣ) hminus
    (fun i j hi hj => hq (hi.trans hj.symm)) hclassify hnontrivial
  refine ⟨a, ?_, hp⟩
  intro i hi
  exact (ha i).resolve_left hi

/-- Transport the local argument through a Chinese-remainder multiplicative
equivalence. The character decomposition is proved here rather than assumed. -/
theorem exists_compatible_residue_character
    {ι : Type*} [Fintype ι] (q : ι → ℕ) (hq : Function.Injective q)
    (hprime : ∀ i, (q i).Prime)
    {G : ι → Type*} [∀ i, CommGroup (G i)]
    (r : ∀ i, G i →* (ZMod (q i))ˣ)
    (hr : ∀ i, Function.Surjective (r i))
    {D : Type*} [Group D] (e : D ≃* ∀ i, G i)
    (χ : D →* ℂˣ) (hnontrivial : ∃ d : D, χ d ≠ 1) :
    ∃ d : D, (∀ i, q i ≠ 2 → r i (e d i) ≠ 1) ∧ χ d ≠ 1 := by
  classical
  let χprod : (∀ i, G i) →* ℂˣ := χ.comp e.symm.toMonoidHom
  let χlocal : ∀ i, G i →* ℂˣ := fun i => χprod.comp (MonoidHom.mulSingle G i)
  have hdecomp (a : ∀ i, G i) : (∏ i, χlocal i (a i)) = χprod a := by
    change (∏ i, χprod (Pi.mulSingle i (a i))) = χprod a
    rw [← map_prod, Finset.univ_prod_mulSingle]
  have hnontrivial_local : ∃ i, ∃ g : G i, χlocal i g ≠ 1 := by
    by_contra h
    have htrivial : ∀ i, ∀ g : G i, χlocal i g = 1 := by simpa using h
    rcases hnontrivial with ⟨d, hd⟩
    apply hd
    have hp : (∏ i, χlocal i (e d i)) = 1 := by simp [htrivial]
    rw [hdecomp] at hp
    simpa [χprod] using hp
  obtain ⟨a, ha, hp⟩ := exists_compatible_local_residues q hq hprime r hr χlocal
    hnontrivial_local
  refine ⟨e.symm a, ?_, ?_⟩
  · simpa using ha
  · rw [hdecomp] at hp
    exact hp

end Cyclic
