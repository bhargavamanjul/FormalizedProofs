import Cyclic.Character

/-!
# A compatible residue for a nontrivial Dirichlet character

This is the concrete conductor version of the character lemma in the
manuscript. The finite Chinese remainder equivalence and surjectivity of
unit reduction maps are supplied by mathlib; the character argument is
proved in `Cyclic.Character`.
-/

namespace Cyclic

open scoped BigOperators

/-- Every nontrivial character of the units modulo a positive integer has
a nontrivial value on a unit that avoids 1 modulo every odd prime divisor.
The assertion does not require primitivity of the character. -/
theorem exists_compatible_dirichlet_residue
    (f : ℕ) (hf : 0 < f) (χ : (ZMod f)ˣ →* ℂˣ)
    (hχ : ∃ a : (ZMod f)ˣ, χ a ≠ 1) :
    ∃ a : (ZMod f)ˣ, χ a ≠ 1 ∧
      ∀ (q : ℕ) (_hq : q.Prime) (hqf : q ∣ f), q ≠ 2 →
        ZMod.unitsMap hqf a ≠ 1 := by
  classical
  let I := {q // q ∈ f.primeFactors}
  let modulus : I → ℕ := fun q => (q : ℕ) ^ f.factorization q
  have hp (q : I) : (q : ℕ).Prime := Nat.prime_of_mem_primeFactors q.property
  have hexp (q : I) : 0 < f.factorization q :=
    (hp q).factorization_pos_of_dvd hf.ne' (Nat.dvd_of_mem_primeFactors q.property)
  have hdiv (q : I) : (q : ℕ) ∣ modulus q := dvd_pow_self _ (hexp q).ne'
  have hmod (q : I) : modulus q ≠ 0 := pow_ne_zero _ (hp q).ne_zero
  have hprod : (∏ q : I, modulus q) = f := by
    dsimp [modulus, I]
    rw [Finset.prod_attach f.primeFactors (fun q : ℕ => q ^ f.factorization q)]
    exact Nat.factorization_prod_pow_eq_self hf.ne'
  have hcop : Pairwise (fun a b : I => Nat.Coprime (modulus a) (modulus b)) := by
    intro a b hab
    exact Nat.coprime_pow_primes _ _ (hp a) (hp b) (fun h => hab (Subtype.ext h))
  let eR : ZMod f ≃+* ∀ q : I, ZMod (modulus q) := by
    have e := ZMod.prodEquivPi modulus hcop
    rwa [hprod] at e
  let e : (ZMod f)ˣ ≃* ∀ q : I, (ZMod (modulus q))ˣ :=
    (Units.mapEquiv eR.toMulEquiv).trans MulEquiv.piUnits
  let r : ∀ q : I, (ZMod (modulus q))ˣ →* (ZMod (q : ℕ))ˣ :=
    fun q => ZMod.unitsMap (hdiv q)
  have hr (q : I) : Function.Surjective (r q) := by
    letI : NeZero (modulus q) := ⟨hmod q⟩
    exact ZMod.unitsMap_surjective (hdiv q)
  obtain ⟨a, ha, hχa⟩ := exists_compatible_residue_character (fun q : I => (q : ℕ))
    Subtype.coe_injective hp r hr e χ hχ
  refine ⟨a, hχa, ?_⟩
  intro q hq hqf hq2
  let i : I := ⟨q, Nat.mem_primeFactors.mpr ⟨hq, hqf, hf.ne'⟩⟩
  have hai := ha i hq2
  have hcoordinate : r i (e a i) = ZMod.unitsMap hqf a := by
    apply Units.ext
    let g : ZMod f →+* ZMod q :=
      (ZMod.castHom (hdiv i) (ZMod q)).comp
        ((Pi.evalRingHom (fun j : I => ZMod (modulus j)) i).comp eR.toRingHom)
    have heq : g = ZMod.castHom hqf (ZMod q) := RingHom.ext_zmod _ _
    exact congrArg (fun k : ZMod f →+* ZMod q => k (a : ZMod f)) heq
  rw [hcoordinate] at hai
  exact hai

/-- Positive integer representative, with the coprimality and avoidance
properties in the form used to construct the final progression. -/
theorem exists_compatible_dirichlet_integer
    (f : ℕ) (hf : 1 < f) (χ : (ZMod f)ˣ →* ℂˣ)
    (hχ : ∃ a : (ZMod f)ˣ, χ a ≠ 1) :
    ∃ u : ℕ, ∃ hu : u.Coprime f,
      0 < u ∧ u ≠ 1 ∧ χ (ZMod.unitOfCoprime u hu) ≠ 1 ∧
      ∀ (q : ℕ), q.Prime → q ∣ f → q ≠ 2 → ¬q ∣ u - 1 := by
  classical
  letI : NeZero f := ⟨by omega⟩
  obtain ⟨a, hχa, havoid⟩ := exists_compatible_dirichlet_residue f (by omega) χ hχ
  let u := (a : ZMod f).val
  have hu : u.Coprime f := ZMod.val_coe_unit_coprime a
  have hu0 : 0 < u := by
    by_contra h
    have hz : u = 0 := by omega
    have hf1 : f = 1 := by simpa [hz] using hu
    omega
  have hunit : ZMod.unitOfCoprime u hu = a := by
    apply Units.ext
    simp [ZMod.coe_unitOfCoprime, u]
  have hu1 : u ≠ 1 := by
    intro h
    have ha1 : a = 1 := by
      rw [← hunit]
      apply Units.ext
      simp [ZMod.coe_unitOfCoprime, h]
    exact hχa (by simp [ha1])
  refine ⟨u, hu, hu0, hu1, ?_, ?_⟩
  · simpa [hunit] using hχa
  · intro q hq hqf hq2 hdiv
    apply havoid q hq hqf hq2
    apply Units.ext
    change (ZMod.cast (a : ZMod f) : ZMod q) = 1
    rw [ZMod.cast_eq_val]
    change (u : ZMod q) = 1
    have hz : ((u - 1 : ℕ) : ZMod q) = 0 :=
      (ZMod.natCast_zmod_eq_zero_iff_dvd (u - 1) q).mpr hdiv
    rw [Nat.cast_sub (by omega : 1 ≤ u), Nat.cast_one] at hz
    exact sub_eq_zero.mp hz

end Cyclic
