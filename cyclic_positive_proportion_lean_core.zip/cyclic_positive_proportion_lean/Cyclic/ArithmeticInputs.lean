import Cyclic.Definitions
import Cyclic.DirichletCharacter
import Cyclic.Progression

/-!
# Classical character input and the proved progression construction

The standard 2-division-field quotient and Kronecker--Weber theorem supply a
nontrivial character. Its modulus may contain 2 and all bad primes. Starting
from that precise input, the full progression construction is proved here;
progression existence is not assumed in the final theorem.
-/

namespace Cyclic

/-- Standard arithmetic character associated with a nontrivial abelian
quotient of the 2-division field. The bad primes are absorbed in the modulus. -/
structure TwoDivisionCharacter (D : ReductionData) where
  modulus : ℕ
  modulus_pos : 0 < modulus
  even_modulus : 2 ∣ modulus
  character : (ZMod modulus)ˣ →* ℂˣ
  nontrivial : ∃ a : (ZMod modulus)ˣ, character a ≠ 1
  good_of_unit : ∀ p : ℕ, p.Prime → IsUnit (p : ZMod modulus) → D.good p
  split_character_one : ∀ p : ℕ, p.Prime → ∀ a : (ZMod modulus)ˣ,
    (p : ZMod modulus) = (a : ZMod modulus) → D.split 2 p → character a = 1

/-- The standard cyclicity/Frobenius, Weil pairing, and Hasse consequences. -/
def CyclicityCriterion (D : ReductionData) : Prop :=
  ∀ p, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p →
    ∃ ell, ell.Prime ∧ D.split ell p ∧ ell ∣ p-1 ∧
      (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1

theorem progression_from_two_division_character
    (D : ReductionData) (char : TwoDivisionCharacter D)
    (criterion : CyclicityCriterion D) :
    ∃ g : Progression, ArithmeticFacts D g := by
  have hm2 : 2 ≤ char.modulus := Nat.le_of_dvd char.modulus_pos char.even_modulus
  rcases exists_compatible_dirichlet_integer char.modulus (by omega)
    char.character char.nontrivial with ⟨u,hu,_,huone,hχ,havoid⟩
  rcases exists_progression_of_even_modulus_residue char.modulus_pos
    char.even_modulus hu huone (fun q hq hq2 hqm => havoid q hq hqm hq2) with
    ⟨g,hgu,hmM⟩
  let a := ZMod.unitOfCoprime u hu
  have hresidue (p : ℕ) (hp : InProgression g p) :
      (p : ZMod char.modulus) = (a : ZMod char.modulus) := by
    have hmod : p ≡ g.u [MOD g.M] := hp
    have hsmall := hmod.of_dvd hmM
    rw [hgu] at hsmall
    simpa [a, ZMod.coe_unitOfCoprime] using
      (ZMod.natCast_eq_natCast_iff p u char.modulus).mpr hsmall
  refine ⟨g, ?_⟩
  constructor
  · intro p hp hprog
    apply char.good_of_unit p hp
    rw [hresidue p hprog]
    exact a.isUnit
  · intro p hp hprog hsplit
    exact hχ (char.split_character_one p hp a (hresidue p hprog) hsplit)
  · exact criterion

end Cyclic
