import Mathlib

/-!
# Concrete elliptic-curve predicates

The combinatorial development can be instantiated with an integral Weierstrass
model. These predicates refer to mathlib's actual additive group of nonsingular
points. The comparison with division fields and specialization of rational
torsion remain separately named arithmetic hypotheses of the main adapter.
-/

noncomputable section

namespace Cyclic.EllipticModel

/-- The rational curve defined by an integral Weierstrass equation. -/
def rationalCurve (W : WeierstrassCurve ℤ) : WeierstrassCurve ℚ :=
  W.map (Int.castRingHom ℚ)

/-- Reduction of an integral Weierstrass equation modulo `p`. -/
def reduction (W : WeierstrassCurve ℤ) (p : ℕ) : WeierstrassCurve (ZMod p) :=
  W.map (Int.castRingHom (ZMod p))

def RationalElliptic (W : WeierstrassCurve ℤ) : Prop :=
  (rationalCurve W).IsElliptic

/-- Two distinct nonzero rational points of order two generate full rational
2-torsion for an elliptic curve over `ℚ`. -/
def FullRationalTwoTorsion (W : WeierstrassCurve ℤ) : Prop :=
  ∃ P Q : (rationalCurve W).toAffine.Point,
    P ≠ 0 ∧ Q ≠ 0 ∧ P ≠ Q ∧ (2 : ℕ) • P = 0 ∧ (2 : ℕ) • Q = 0

def Admissible (W : WeierstrassCurve ℤ) : Prop :=
  RationalElliptic W ∧ ¬FullRationalTwoTorsion W

/-- Good reduction for this integral equation. Prime-counting sets separately
impose primality. A nonminimal equation can omit finitely many additional primes. -/
def GoodReduction (W : WeierstrassCurve ℤ) (p : ℕ) : Prop :=
  (reduction W p).IsElliptic

/-- Cyclicity of the actual point group over the prime field `ZMod p`. -/
def CyclicReduction (W : WeierstrassCurve ℤ) (p : ℕ) : Prop :=
  ∃ hp : Nat.Prime p,
    letI : Fact p.Prime := ⟨hp⟩
    IsAddCyclic (reduction W p).toAffine.Point

theorem cyclicReduction_iff (W : WeierstrassCurve ℤ) (p : ℕ) [Fact p.Prime] :
    CyclicReduction W p ↔ IsAddCyclic (reduction W p).toAffine.Point := by
  constructor
  · rintro ⟨hp, h⟩
    exact h
  · intro h
    exact ⟨Fact.out, h⟩

/-- Encoding a point by the point at infinity or its two affine coordinates. -/
def pointCoordinates {F : Type*} [Field F] (W : WeierstrassCurve.Affine F) :
    W.Point → Option (F × F)
  | .zero => none
  | @WeierstrassCurve.Affine.Point.some _ _ _ x y _ => some (x, y)

theorem pointCoordinates_injective {F : Type*} [Field F]
    (W : WeierstrassCurve.Affine F) : Function.Injective (pointCoordinates W) := by
  intro P Q h
  cases P with
  | zero =>
      cases Q with
      | zero => rfl
      | some hQ => simp [pointCoordinates] at h
  | @some x y hP =>
      cases Q with
      | zero => simp [pointCoordinates] at h
      | @some u v hQ =>
          simp only [pointCoordinates, Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨rfl, rfl⟩
          rfl

instance finitePoint {F : Type*} [Field F] [Finite F]
    (W : WeierstrassCurve.Affine F) : Finite W.Point := by
  classical
  letI : Fintype F := Fintype.ofFinite F
  exact Finite.of_injective (pointCoordinates W) (pointCoordinates_injective W)

/-- A finite cyclic group cannot contain two distinct nonzero points killed by 2. -/
theorem not_isAddCyclic_of_two_torsion {G : Type*} [AddGroup G] [Finite G]
    {P Q : G} (hP : P ≠ 0) (hQ : Q ≠ 0) (hPQ : P ≠ Q)
    (hPtwo : (2 : ℕ) • P = 0) (hQtwo : (2 : ℕ) • Q = 0) :
    ¬IsAddCyclic G := by
  classical
  letI : Fintype G := Fintype.ofFinite G
  intro hcyclic
  letI : IsAddCyclic G := hcyclic
  have hbound : ({a : G | (2 : ℕ) • a = 0} : Finset G).card ≤ 2 :=
    IsAddCyclic.card_nsmul_eq_zero_le (by norm_num)
  have hsub : ({0, P, Q} : Finset G) ⊆ ({a : G | (2 : ℕ) • a = 0} : Finset G) := by
    intro a ha
    simp only [Finset.mem_insert, Finset.mem_singleton] at ha
    rcases ha with rfl | rfl | rfl
    · simp
    · simpa using hPtwo
    · simpa using hQtwo
  have hcard : ({0, P, Q} : Finset G).card = 3 := by
    simp [hP, hQ, hPQ, Ne.symm hP, Ne.symm hQ]
  have := Finset.card_le_card hsub
  omega

/-- Full 2-torsion in a reduction prevents its actual point group from being cyclic. -/
theorem not_cyclicReduction_of_two_torsion (W : WeierstrassCurve ℤ) (p : ℕ)
    [Fact p.Prime] {P Q : (reduction W p).toAffine.Point}
    (hP : P ≠ 0) (hQ : Q ≠ 0) (hPQ : P ≠ Q)
    (hPtwo : (2 : ℕ) • P = 0) (hQtwo : (2 : ℕ) • Q = 0) :
    ¬CyclicReduction W p := by
  rw [cyclicReduction_iff]
  exact not_isAddCyclic_of_two_torsion hP hQ hPQ hPtwo hQtwo

end Cyclic.EllipticModel
