import Cyclic.Definitions

/-!
# Checking the local conditions of the fixed progression

The CRT and character-selection inputs provide an integral residue, its exact
power of two, and avoidance of 1 at odd primes dividing the modulus. This file
proves the quotient coprimality needed by the cofactor sieve and constructs the
`Progression` structure. In particular, quotient coprimality is not an input.
-/

namespace Cyclic

/-- Removing the exact power of two leaves a quotient coprime to `M / 2^k`,
provided no odd prime divisor of `M` divides `u - 1`. -/
theorem quotient_coprime_of_local_conditions {M u k : ℕ}
    (hcM : 2^k ∣ M) (hcu : 2^k ∣ u-1)
    (hodd : ((u-1)/2^k) % 2 = 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) :
    Nat.Coprime ((u-1)/2^k) (M/2^k) := by
  apply Nat.coprime_of_dvd
  intro q hq hqa hqb
  by_cases hq2 : q = 2
  · subst q
    have hz := Nat.mod_eq_zero_of_dvd hqa
    omega
  · exact havoid q hq hq2 (hqb.trans (Nat.div_dvd_of_dvd hcM))
      (hqa.trans (Nat.div_dvd_of_dvd hcu))

/-- Exact divisibility by `2^k` makes the quotient odd. -/
theorem quotient_mod_two_eq_one_of_exact_power {a k : ℕ}
    (hdiv : 2^k ∣ a) (hexact : ¬2^(k+1) ∣ a) : (a/2^k) % 2 = 1 := by
  have hlt := Nat.mod_lt (a/2^k) (by norm_num : 0 < 2)
  have hne : (a/2^k) % 2 ≠ 0 := by
    intro hz
    have hd : 2 ∣ a/2^k := Nat.dvd_of_mod_eq_zero hz
    have hm : 2^k * 2 ∣ a := (Nat.dvd_div_iff_mul_dvd hdiv).mp hd
    exact hexact (by simpa [pow_succ] using hm)
  omega

/-- Local data produce precisely the progression conditions used by the sieve. -/
def progressionOfLocalData (M u k : ℕ)
    (hM : 0 < M) (hcM : 2^k ∣ M) (h2cM : 2 * 2^k ∣ M)
    (hunit : Nat.Coprime u M) (hcu : 2^k ∣ u-1)
    (hodd : ((u-1)/2^k) % 2 = 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) : Progression where
  M := M
  u := u
  k := k
  M_pos := hM
  c_dvd_M := hcM
  even_quotient := (Nat.dvd_div_iff_mul_dvd hcM).mpr (by simpa [mul_comm] using h2cM)
  unit := hunit
  c_dvd_u_sub_one := hcu
  reduced_quotient := quotient_coprime_of_local_conditions hcM hcu hodd havoid

/-- An equivalent constructor stated using the exact power of two. -/
def progressionOfExactPower (M u k : ℕ)
    (hM : 0 < M) (hcM : 2^k ∣ M) (h2cM : 2 * 2^k ∣ M)
    (hunit : Nat.Coprime u M) (hcu : 2^k ∣ u-1) (hexact : ¬2^(k+1) ∣ u-1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) : Progression :=
  progressionOfLocalData M u k hM hcM h2cM hunit hcu
    (quotient_mod_two_eq_one_of_exact_power hcu hexact) havoid

/-- A compatible nonidentity unit residue modulo an even modulus extends to a
sieve-admissible progression by increasing only the power of two in the modulus.
No further Chinese remainder argument is needed for this numerical step. -/
theorem exists_progression_of_even_modulus_residue {m u : ℕ}
    (hm : 0 < m) (heven : 2 ∣ m) (hunit : Nat.Coprime u m) (huone : u ≠ 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ m → ¬q ∣ u-1) :
    ∃ g : Progression, g.u = u ∧ m ∣ g.M := by
  have hm_two : 2 ≤ m := Nat.le_of_dvd hm heven
  have hupos : 0 < u := by
    by_contra h
    have hu : u = 0 := by omega
    subst u
    have hm_one : m = 1 := (Nat.coprime_zero_left m).mp hunit
    omega
  have hsub : u-1 ≠ 0 := by omega
  let k := padicValNat 2 (u-1)
  let M := m * 2^(k+1)
  have hM : 0 < M := Nat.mul_pos hm (pow_pos (by norm_num) _)
  have hcu : 2^k ∣ u-1 := pow_padicValNat_dvd
  have hexact : ¬2^(k+1) ∣ u-1 := pow_succ_padicValNat_not_dvd hsub
  have hcM : 2^k ∣ M :=
    dvd_mul_of_dvd_right (pow_dvd_pow 2 (Nat.le_succ k)) m
  have h2cM : 2 * 2^k ∣ M := by
    have heq : 2 * 2^k = 2^(k+1) := by rw [pow_succ, mul_comm]
    rw [heq]
    exact Nat.dvd_mul_left _ _
  have hu_two : Nat.Coprime u 2 := Nat.Coprime.of_dvd_right heven hunit
  have huM : Nat.Coprime u M := hunit.mul_right (hu_two.pow_right (k+1))
  have havoidM : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1 := by
    intro q hq hq_two hqM
    rcases hq.dvd_mul.mp hqM with hqm | hqpow
    · exact havoid q hq hq_two hqm
    · exact (hq_two (Nat.prime_eq_prime_of_dvd_pow hq Nat.prime_two hqpow)).elim
  refine ⟨progressionOfExactPower M u k hM hcM h2cM huM hcu hexact havoidM, rfl, ?_⟩
  exact Nat.dvd_mul_right m _

end Cyclic
