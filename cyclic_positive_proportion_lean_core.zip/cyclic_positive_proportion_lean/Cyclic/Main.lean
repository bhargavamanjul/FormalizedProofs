import Cyclic.Definitions
import Cyclic.Counting
import Cyclic.Obstruction
import Cyclic.Parameters
import Cyclic.Density

/-!
# Positive proportion from the agreed sieve and splitting estimates

Every covering, subtraction, eventual threshold, uniform parameter choice,
and lower-liminf passage is proved. The subsequent `Theorems` module obtains
the splitting estimate from the positive explicit formula and arithmetic data.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

theorem candidates_covered (D : ReductionData) (g : Progression)
    (arith : ArithmeticFacts D g) {x ε Y : ℝ} (hx : 2 < x)
    (hlarge : Real.sqrt (2*x)+1 < x^(9/10 : ℝ)) :
    candidates g x ε Y ⊆ cyclicInterval D x ∪
      (primeIndices Y (x^ε)).biUnion (fun ell => primeInterval (D.split ell) x) := by
  classical
  intro p hp
  rcases mem_primeInterval.mp hp with ⟨hpprime, hpx, hp2x, hprog, r, Q,
    hfactor, hQ, hQlarge, hrbound, hrough⟩
  have hgood := arith.progression_good p hpprime hprog
  by_cases hcyclic : D.cyclic p
  · exact Finset.mem_union_left _ (mem_primeInterval.mpr
      ⟨hpprime, hpx, hp2x, hgood, hcyclic⟩)
  · have hp3 : 3 ≤ p := by
      have : (2 : ℝ) < (p : ℝ) := hx.trans hpx
      have : 2 < p := by exact_mod_cast this
      omega
    rcases arith.obstruction p hpprime hp3 hgood hcyclic with
      ⟨ell, hell, hsplit, hdiv, hhasse⟩
    have hne2 : ell ≠ 2 := by
      intro heq
      subst ell
      exact arith.progression_not_split_two p hpprime hprog hsplit
    have hshort := short_obstruction (show 2 ≤ p by omega) hp2x.le hell hQ hne2
      hfactor hdiv hhasse (hlarge.trans hQlarge) hrough hrbound
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr
      ⟨ell, mem_primeIndices.mpr ⟨hell, hshort⟩,
        mem_primeInterval.mpr ⟨hpprime, hpx, hp2x, hsplit⟩⟩)

/-- The normalized inequality immediately before choosing ε and Y. -/
theorem normalized_cyclic_lower_bound (D : ReductionData) (g : Progression)
    (arith : ArithmeticFacts D g) {A C₁ C₂ N ε Y : ℝ}
    (hcandidate : ∀ᶠ x : ℝ in atTop,
      A*ε/Real.log Y * (x/Real.log x) ≤ ((candidates g x ε Y).card : ℝ))
    (hsplit : ∀ᶠ x : ℝ in atTop,
      (∑ ell ∈ primeIndices Y (x^ε), splitCount D ell x) ≤
        (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x)) :
    ∀ᶠ x : ℝ in atTop,
      (A*ε/Real.log Y-C₁/(Y*Real.log Y)-C₂*x^(-1/N+ε))*(x/Real.log x) ≤
        cyclicCount D (2*x)-cyclicCount D x := by
  classical
  filter_upwards [hcandidate, hsplit, eventually_gt_atTop (2 : ℝ),
    eventually_large_factor_dominates_hasse] with x hc hs hx hl
  have hremove := candidate_removal_bounds (candidates g x ε Y) (cyclicInterval D x)
    (primeIndices Y (x^ε)) (fun ell => primeInterval (D.split ell) x)
    (A*ε/Real.log Y*(x/Real.log x))
    ((C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x))
    (candidates_covered D g arith hx hl) hc hs
  have hinterval := cyclicInterval_le_difference D (show 0 ≤ x by linarith)
  calc
    _ = A*ε/Real.log Y*(x/Real.log x) -
        (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x) := by ring
    _ ≤ ((cyclicInterval D x).card : ℝ) := hremove
    _ ≤ _ := hinterval

/-- A uniform splitting estimate is a proposition, not an axiom. It is proved
from the explicit formula in `AnalyticInputs.exists_uniform_split_bound`. -/
def UniformSplitBound (D : ReductionData) (ZF : ℝ → Prop) : Prop :=
  ∃ C₁ C₂ : ℝ, ∀ N : ℝ, 2 ≤ N → ZF N →
    ∀ ε Y : ℝ, 0 < ε → 3 ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        (∑ ell ∈ primeIndices Y (x^ε), splitCount D ell x) ≤
          (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x)

/-- Both quantitative conclusions, with the same positive constant independent
of N. The zero-free hypothesis is required separately at each N. -/
theorem quantitative_of_sieve_and_split_bound
    (D : ReductionData) (g : Progression) (ZF : ℝ → Prop)
    (arith : ArithmeticFacts D g) (sieve : CofactorSieve g)
    (splitting : UniformSplitBound D ZF) (pnt : PrimeNumberTheorem) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → ZF N →
      (∀ᶠ x : ℝ in atTop, c/(N*Real.log N)*(x/Real.log x) ≤
        cyclicCount D (2*x)-cyclicCount D x) ∧
      c/(N*Real.log N) ≤
        Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop := by
  rcases sieve with ⟨A, ε₀, Y₀, hA, hε₀, _, hcandidates⟩
  rcases splitting with ⟨C₁, C₂, hsplit⟩
  rcases exists_uniform_parameters (Y₀ := Y₀) (C₁ := C₁) (C₂ := C₂) hA hε₀
    with ⟨d, hd, hparams⟩
  refine ⟨d/2, by positivity, ?_⟩
  intro N hN hZF
  have hNpos : 0 < N := by linarith
  have hlogN : 0 < Real.log N := Real.log_pos (by linarith)
  have hden : 0 < N*Real.log N := mul_pos hNpos hlogN
  rcases hparams N hN with ⟨ε,Y,hε,hεlt,hY₀,hY,hcoeff⟩
  have hbefore := normalized_cyclic_lower_bound D g arith
    (hcandidates ε Y hε hεlt hY₀) (hsplit N hN hZF ε Y hε hY)
  have hdyadic : ∀ᶠ x : ℝ in atTop,
      d/(N*Real.log N)*(x/Real.log x) ≤ cyclicCount D (2*x)-cyclicCount D x := by
    filter_upwards [hcoeff,hbefore,eventually_gt_atTop (2 : ℝ)] with x hc hb hx
    have hscale : 0 ≤ x/Real.log x :=
      div_nonneg (by linarith) (Real.log_nonneg (by linarith))
    exact (mul_le_mul_of_nonneg_right hc hscale).trans hb
  constructor
  · filter_upwards [hdyadic,eventually_gt_atTop (2 : ℝ)] with x hdya hx
    have hscale : 0 ≤ x/Real.log x :=
      div_nonneg (by linarith) (Real.log_nonneg (by linarith))
    exact (mul_le_mul_of_nonneg_right
      (div_le_div_of_nonneg_right (show d/2 ≤ d by linarith) hden.le) hscale).trans hdya
  · have hlim := lower_proportion_of_dyadic (cyclicCount D) primeCount
      (d/(N*Real.log N)) (div_nonneg hd.le hden.le)
      (cyclicCount_nonneg D) (Eventually.of_forall (cyclicCount_le_primeCount D))
      (eventually_positive_of_pnt primeCount pnt) pnt hdyadic
    convert hlim using 1
    ring

theorem positive_proportion_of_width_32
    (D : ReductionData) (g : Progression) (ZF : ℝ → Prop)
    (arith : ArithmeticFacts D g) (sieve : CofactorSieve g)
    (splitting : UniformSplitBound D ZF) (pnt : PrimeNumberTheorem)
    (cureton_thorner : ZF 32) :
    0 < Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop := by
  rcases quantitative_of_sieve_and_split_bound D g ZF arith sieve splitting pnt
    with ⟨c,hc,hquant⟩
  have hlim := (hquant 32 (by norm_num) cureton_thorner).2
  have hlog : 0 < Real.log (32 : ℝ) := Real.log_pos (by norm_num)
  exact lt_of_lt_of_le (div_pos hc (mul_pos (by norm_num) hlog)) hlim

end Cyclic
