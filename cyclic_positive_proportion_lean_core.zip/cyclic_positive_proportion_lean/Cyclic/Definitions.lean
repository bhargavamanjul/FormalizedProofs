import Mathlib

/-!
# Concrete finite prime counts and the interfaces used by the proof

The reduction predicates are parameters. `EllipticModel.lean` instantiates them
with integral Weierstrass equations and Mathlib's actual point groups.
No arithmetic or analytic conclusion is built into these definitions.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

structure ReductionData where
  good : ℕ → Prop
  cyclic : ℕ → Prop
  split : ℕ → ℕ → Prop

def primeInterval (P : ℕ → Prop) (x : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈2 * x⌉₊ + 1)).filter
    (fun p => p.Prime ∧ x < (p : ℝ) ∧ (p : ℝ) < 2 * x ∧ P p)

def primeUpTo (P : ℕ → Prop) (X : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈X⌉₊ + 1)).filter
    (fun p => p.Prime ∧ (p : ℝ) ≤ X ∧ P p)

def primeIndices (Y z : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈z⌉₊ + 1)).filter
    (fun ell => ell.Prime ∧ Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z)

@[simp] theorem mem_primeInterval {P : ℕ → Prop} {x : ℝ} {p : ℕ} :
    p ∈ primeInterval P x ↔ p.Prime ∧ x < (p : ℝ) ∧ (p : ℝ) < 2*x ∧ P p := by
  classical
  simp only [primeInterval, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : (p : ℝ) ≤ (⌈2*x⌉₊ : ℝ) := h.2.2.1.le.trans (Nat.le_ceil _)
    exact ⟨Nat.lt_succ_of_le (by exact_mod_cast this), h⟩

@[simp] theorem mem_primeUpTo {P : ℕ → Prop} {X : ℝ} {p : ℕ} :
    p ∈ primeUpTo P X ↔ p.Prime ∧ (p : ℝ) ≤ X ∧ P p := by
  classical
  simp only [primeUpTo, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : p ≤ ⌈X⌉₊ := by exact_mod_cast h.2.1.trans (Nat.le_ceil X)
    exact ⟨Nat.lt_succ_of_le this, h⟩

@[simp] theorem mem_primeIndices {Y z : ℝ} {ell : ℕ} :
    ell ∈ primeIndices Y z ↔ ell.Prime ∧ Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z := by
  classical
  simp only [primeIndices, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : ell ≤ ⌈z⌉₊ := by exact_mod_cast h.2.2.trans (Nat.le_ceil z)
    exact ⟨Nat.lt_succ_of_le this, h⟩

def primeCount (X : ℝ) : ℝ := (primeUpTo (fun _ => True) X).card
def cyclicCount (D : ReductionData) (X : ℝ) : ℝ :=
  (primeUpTo (fun p => D.good p ∧ D.cyclic p) X).card
def cyclicInterval (D : ReductionData) (x : ℝ) : Finset ℕ :=
  primeInterval (fun p => D.good p ∧ D.cyclic p) x
def splitCount (D : ReductionData) (ell : ℕ) (x : ℝ) : ℝ :=
  (primeInterval (D.split ell) x).card

theorem cyclicCount_nonneg (D : ReductionData) (X : ℝ) : 0 ≤ cyclicCount D X := by
  exact Nat.cast_nonneg _

theorem cyclicCount_le_primeCount (D : ReductionData) (X : ℝ) :
    cyclicCount D X ≤ primeCount X := by
  unfold cyclicCount primeCount
  have hs : primeUpTo (fun p => D.good p ∧ D.cyclic p) X ⊆
      primeUpTo (fun _ => True) X := by
    intro p hp
    rcases mem_primeUpTo.mp hp with ⟨hprime, hX, _⟩
    exact mem_primeUpTo.mpr ⟨hprime, hX, trivial⟩
  exact_mod_cast Finset.card_le_card hs

theorem cyclicInterval_le_difference (D : ReductionData) {x : ℝ} (hx : 0 ≤ x) :
    ((cyclicInterval D x).card : ℝ) ≤ cyclicCount D (2*x) - cyclicCount D x := by
  classical
  let A := primeUpTo (fun p => D.good p ∧ D.cyclic p) x
  let B := cyclicInterval D x
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro p hpA hpB
    have hA := (mem_primeUpTo.mp hpA).2.1
    have hB := (mem_primeInterval.mp hpB).2.1
    exact (not_lt_of_ge hA) hB
  have hs : A ∪ B ⊆ primeUpTo (fun p => D.good p ∧ D.cyclic p) (2*x) := by
    intro p hp
    rcases Finset.mem_union.mp hp with ha | hb
    · rcases mem_primeUpTo.mp ha with ⟨hp, hpx, hc⟩
      exact mem_primeUpTo.mpr ⟨hp, hpx.trans (by linarith), hc⟩
    · rcases mem_primeInterval.mp hb with ⟨hp, _, hpx, hc⟩
      exact mem_primeUpTo.mpr ⟨hp, hpx.le, hc⟩
  have hnat := Finset.card_le_card hs
  rw [Finset.card_union_of_disjoint hd] at hnat
  have hr : (A.card : ℝ) + (B.card : ℝ) ≤ cyclicCount D (2*x) := by
    unfold cyclicCount
    exact_mod_cast hnat
  change (B.card : ℝ) ≤ cyclicCount D (2*x) - (A.card : ℝ)
  linarith

/-- A fixed progression, with the exact local admissibility used by the sieve. -/
structure Progression where
  M : ℕ
  u : ℕ
  k : ℕ
  M_pos : 0 < M
  c_dvd_M : 2^k ∣ M
  even_quotient : 2 ∣ M / 2^k
  unit : Nat.Coprime u M
  c_dvd_u_sub_one : 2^k ∣ u-1
  reduced_quotient : Nat.Coprime ((u-1)/2^k) (M/2^k)

def InProgression (g : Progression) (p : ℕ) : Prop := p % g.M = g.u % g.M

def Candidate (g : Progression) (x ε Y : ℝ) (p : ℕ) : Prop :=
  InProgression g p ∧ ∃ r Q : ℕ,
    p-1 = 2^g.k*r*Q ∧ Q.Prime ∧ x^(9/10 : ℝ) < (Q : ℝ) ∧
    (r : ℝ) ≤ x^ε ∧ ∀ q : ℕ, q.Prime → q ∣ r → Y < (q : ℝ)

def candidates (g : Progression) (x ε Y : ℝ) : Finset ℕ :=
  primeInterval (Candidate g x ε Y) x

/-- Classical elliptic facts, stated separately from the analytic black boxes. -/
structure ArithmeticFacts (D : ReductionData) (g : Progression) : Prop where
  progression_good : ∀ p, p.Prime → InProgression g p → D.good p
  progression_not_split_two : ∀ p, p.Prime → InProgression g p → ¬ D.split 2 p
  obstruction : ∀ p, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p →
    ∃ ell, ell.Prime ∧ D.split ell p ∧ ell ∣ p-1 ∧
      (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1

/-- The predecessor form of the varying-cofactor sieve from the agreed earlier work.
The independence of A, ε₀, Y₀ from ε,Y is expressed by the quantifier order. -/
def CofactorSieve (g : Progression) : Prop :=
  ∃ A ε₀ Y₀ : ℝ, 0 < A ∧ 0 < ε₀ ∧ 3 ≤ Y₀ ∧
    ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        A*ε/Real.log Y * (x/Real.log x) ≤ ((candidates g x ε Y).card : ℝ)

/-- Standard PNT, isolated as an external input rather than hidden in a limit axiom. -/
def PrimeNumberTheorem : Prop :=
  Tendsto (fun X : ℝ => primeCount X / (X / Real.log X)) atTop (𝓝 1)

end Cyclic
