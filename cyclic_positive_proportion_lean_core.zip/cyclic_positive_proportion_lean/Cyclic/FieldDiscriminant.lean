import Mathlib

/-!
# Uniform root-discriminant constants

This file proves the elementary logarithmic manipulation in Lemma 6 of the
manuscript. The general discriminant bound, ramification support, and the
faithful action on torsion are external arithmetic inputs; their numerical
consequences are the hypotheses of the theorem below.
-/

noncomputable section
namespace Cyclic

/-- This constant depends only on the fixed bad-reduction product R. -/
def rootDiscriminantConstant (R : ℝ) : ℝ :=
  5 + (Real.log R + 1) / Real.log 2

theorem rootDiscriminantConstant_pos {R : ℝ} (hR : 1 ≤ R) :
    0 < rootDiscriminantConstant R := by
  have hlogR : 0 ≤ Real.log R := Real.log_nonneg hR
  have hlogtwo : 0 < Real.log 2 := Real.log_pos (by norm_num)
  unfold rootDiscriminantConstant
  positivity

/-- The general discriminant inequality and `n ≤ ell⁴` imply a logarithmic
root-discriminant bound with a constant depending on R alone. -/
theorem root_discriminant_from_raw
    {n ell R d : ℝ}
    (hn : 1 ≤ n) (hell : 2 ≤ ell) (hR : 1 ≤ R)
    (hdegree : n ≤ ell ^ (4 : ℕ))
    (hraw : d ≤ (n - 1) * (Real.log R + Real.log ell) + n * Real.log n) :
    d + n ≤ rootDiscriminantConstant R * n * Real.log (2 * ell) := by
  have hnpos : 0 < n := lt_of_lt_of_le zero_lt_one hn
  have hellpos : 0 < ell := lt_of_lt_of_le (by norm_num) hell
  have hlogR : 0 ≤ Real.log R := Real.log_nonneg hR
  have hlogell : 0 ≤ Real.log ell := Real.log_nonneg (by linarith)
  have hlogtwo : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlogn : Real.log n ≤ 4 * Real.log ell := by
    calc
      Real.log n ≤ Real.log (ell ^ (4 : ℕ)) := Real.log_le_log hnpos hdegree
      _ = 4 * Real.log ell := by rw [Real.log_pow]; norm_num
  have hfirst : (n - 1) * (Real.log R + Real.log ell) ≤
      n * (Real.log R + Real.log ell) :=
    mul_le_mul_of_nonneg_right (by linarith) (add_nonneg hlogR hlogell)
  have hsecond : n * Real.log n ≤ n * (4 * Real.log ell) :=
    mul_le_mul_of_nonneg_left hlogn hnpos.le
  have hbase : d + n ≤ n * (Real.log R + 1) + 5 * n * Real.log ell := by
    nlinarith [hraw, hfirst, hsecond]
  have htwo_le : Real.log 2 ≤ Real.log (2 * ell) :=
    Real.log_le_log (by norm_num) (by linarith)
  have hell_le : Real.log ell ≤ Real.log (2 * ell) :=
    Real.log_le_log hellpos (by linarith)
  have hratio : Real.log R + 1 ≤
      ((Real.log R + 1) / Real.log 2) * Real.log (2 * ell) := by
    calc
      Real.log R + 1 = ((Real.log R + 1) / Real.log 2) * Real.log 2 := by
        field_simp
      _ ≤ ((Real.log R + 1) / Real.log 2) * Real.log (2 * ell) :=
        mul_le_mul_of_nonneg_left htwo_le
          (div_nonneg (by linarith) hlogtwo.le)
  calc
    d + n ≤ n * (Real.log R + 1) + 5 * n * Real.log ell := hbase
    _ ≤ n * (((Real.log R + 1) / Real.log 2) * Real.log (2 * ell)) +
        5 * n * Real.log (2 * ell) := by
      exact add_le_add (mul_le_mul_of_nonneg_left hratio hnpos.le)
        (mul_le_mul_of_nonneg_left hell_le (by positivity))
    _ = rootDiscriminantConstant R * n * Real.log (2 * ell) := by
      unfold rootDiscriminantConstant
      ring

/-- The quantifier order makes the independence from division primes explicit. -/
theorem exists_root_discriminant_constant {R : ℝ} (hR : 1 ≤ R) :
    ∃ K : ℝ, 0 < K ∧ ∀ n ell d : ℝ,
      1 ≤ n → 2 ≤ ell → n ≤ ell ^ (4 : ℕ) →
      d ≤ (n - 1) * (Real.log R + Real.log ell) + n * Real.log n →
      d + n ≤ K * n * Real.log (2 * ell) := by
  exact ⟨rootDiscriminantConstant R, rootDiscriminantConstant_pos hR,
    fun n ell d hn hell hdegree hraw =>
      root_discriminant_from_raw hn hell hR hdegree hraw⟩

end Cyclic
