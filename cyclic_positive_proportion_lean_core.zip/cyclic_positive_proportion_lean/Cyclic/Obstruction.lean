import Mathlib

/-!
# Confining cyclicity obstructions to the cofactor

This module proves the elementary new deduction in Section 5 of the manuscript.
The elliptic-curve input is supplied as explicit divisibility and Hasse bounds;
the short-obstruction conclusion is not an assumption.
-/

namespace Cyclic

/-- A prime divisor of `p - 1 = 2^k * r * Q`, other than 2 and `Q`, divides `r`. -/
theorem obstruction_dvd_cofactor {p k r Q ell : ℕ}
    (hell : Nat.Prime ell) (hQ : Nat.Prime Q)
    (hne_two : ell ≠ 2) (hne_Q : ell ≠ Q)
    (hfactor : p - 1 = 2 ^ k * r * Q) (hdiv : ell ∣ p - 1) : ell ∣ r := by
  rw [hfactor] at hdiv
  rcases hell.dvd_mul.mp hdiv with hleft | hright
  · rcases hell.dvd_mul.mp hleft with htwo | hr
    · exact (hne_two (Nat.prime_eq_prime_of_dvd_pow hell Nat.prime_two htwo)).elim
    · exact hr
  · exact (hne_Q ((Nat.prime_dvd_prime_iff_eq hell hQ).mp hright)).elim

/-- Hasse's upper bound excludes the distinguished prime factor. -/
theorem obstruction_ne_large_prime {p Q ell : ℕ} {x : ℝ}
    (hp : (p : ℝ) ≤ 2 * x)
    (hhasse : (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1)
    (hlarge : Real.sqrt (2 * x) + 1 < (Q : ℝ)) : ell ≠ Q := by
  intro heq
  have hsqrt := Real.sqrt_le_sqrt hp
  have hu : (ell : ℝ) ≤ Real.sqrt (2 * x) + 1 :=
    hhasse.trans (add_le_add_right hsqrt 1)
  rw [heq] at hu
  exact (not_lt_of_ge hu) hlarge

/-- Every obstruction for a candidate lies above the roughness threshold and
below the cofactor bound. No distribution assumption enters this theorem. -/
theorem short_obstruction {p k r Q ell : ℕ} {x Y z : ℝ}
    (hp_two : 2 ≤ p) (hp : (p : ℝ) ≤ 2 * x)
    (hell : Nat.Prime ell) (hQ : Nat.Prime Q) (hne_two : ell ≠ 2)
    (hfactor : p - 1 = 2 ^ k * r * Q) (hdiv : ell ∣ p - 1)
    (hhasse : (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1)
    (hlarge : Real.sqrt (2 * x) + 1 < (Q : ℝ))
    (hrough : ∀ q : ℕ, Nat.Prime q → q ∣ r → Y < (q : ℝ))
    (hrbound : (r : ℝ) ≤ z) : Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z := by
  have hdvd : ell ∣ r := obstruction_dvd_cofactor hell hQ hne_two
    (obstruction_ne_large_prime hp hhasse hlarge) hfactor hdiv
  have hrpos : 0 < r := by
    by_contra h
    have hrzero : r = 0 := Nat.eq_zero_of_not_pos h
    simp only [hrzero, mul_zero, zero_mul] at hfactor
    omega
  have hle : (ell : ℝ) ≤ (r : ℝ) := by
    exact_mod_cast Nat.le_of_dvd hrpos hdvd
  exact ⟨hrough ell hell hdvd, hle.trans hrbound⟩

open Filter Topology

/-- The distinguished factor `Q > x^(9/10)` eventually exceeds every Hasse
obstruction for primes in `(x,2*x)`. This is proved from real-power limits. -/
theorem eventually_large_factor_dominates_hasse :
    ∀ᶠ x : ℝ in atTop, Real.sqrt (2 * x) + 1 < x ^ (9 / 10 : ℝ) := by
  have hlim : Tendsto
      (fun x : ℝ => Real.sqrt 2 * x ^ (-(2 / 5 : ℝ)) + x ^ (-(9 / 10 : ℝ)))
      atTop (𝓝 0) := by
    simpa using ((tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 2 / 5)).const_mul
      (Real.sqrt 2)).add (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 9 / 10))
  filter_upwards [hlim.eventually (Iio_mem_nhds (by norm_num : (0 : ℝ) < 1)),
    eventually_gt_atTop (0 : ℝ)] with x hx hxpos
  have hpow₁ : x ^ (-(2 / 5 : ℝ)) * x ^ (9 / 10 : ℝ) = x ^ (1 / 2 : ℝ) := by
    rw [← Real.rpow_add hxpos]
    norm_num
  have hpow₂ : x ^ (-(9 / 10 : ℝ)) * x ^ (9 / 10 : ℝ) = 1 := by
    rw [← Real.rpow_add hxpos]
    norm_num
  calc
    Real.sqrt (2 * x) + 1 =
        (Real.sqrt 2 * x ^ (-(2 / 5 : ℝ)) + x ^ (-(9 / 10 : ℝ))) *
          x ^ (9 / 10 : ℝ) := by
      rw [add_mul, mul_assoc, hpow₁, hpow₂, ← Real.sqrt_eq_rpow,
        ← Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 2)]
    _ < 1 * x ^ (9 / 10 : ℝ) :=
      mul_lt_mul_of_pos_right hx (Real.rpow_pos_of_pos hxpos _)
    _ = x ^ (9 / 10 : ℝ) := one_mul _

end Cyclic
