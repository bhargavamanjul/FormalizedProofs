import Mathlib

/-!
# Positive prime-ideal sums and completely split primes

The input `t` is the nonnegative zero-error factor (later `x ^ (1 - 1/N)`).
The explicit formula, the arithmetic contribution of a completely split
prime, and the degree/root-discriminant estimates are explicit hypotheses.
The division by the degree and the finite summation are proved here.
-/

namespace Cyclic

open scoped BigOperators

/-- Dividing a positive prime-ideal bound by the degree leaves only the root
discriminant in the error term. The constants do not depend on `t`. -/
theorem split_individual_bound
    {b n d psi ell x t F a K : ℝ}
    (hn : 0 < n) (hell : 0 < ell) (hx : 0 ≤ x)
    (hlog : 0 < Real.log x) (ht : 0 ≤ t)
    (hF : 0 ≤ F) (ha : 0 < a)
    (hcontrib : b * n * Real.log x ≤ psi)
    (hexplicit : psi ≤ F * (x + t * (d + n)))
    (hdegree : a * ell ^ 2 ≤ n)
    (hroot : d + n ≤ K * n * Real.log (2 * ell)) :
    b ≤ (F / a) * x / (ell ^ 2 * Real.log x) +
      (F * K) * t * Real.log (2 * ell) / Real.log x := by
  have hupper : b * n * Real.log x ≤
      F * (x + t * (K * n * Real.log (2 * ell))) := by
    calc
      b * n * Real.log x ≤ psi := hcontrib
      _ ≤ F * (x + t * (d + n)) := hexplicit
      _ ≤ F * (x + t * (K * n * Real.log (2 * ell))) :=
        mul_le_mul_of_nonneg_left
          (add_le_add_left (mul_le_mul_of_nonneg_left hroot ht) x) hF
  have hdivide : b ≤ F * x / (n * Real.log x) +
      (F * K) * t * Real.log (2 * ell) / Real.log x := by
    calc
      b ≤ F * (x + t * (K * n * Real.log (2 * ell))) /
          (n * Real.log x) := by
        apply (le_div_iff₀ (mul_pos hn hlog)).2
        simpa only [mul_assoc] using hupper
      _ = F * x / (n * Real.log x) +
          (F * K) * t * Real.log (2 * ell) / Real.log x := by
        field_simp [ne_of_gt hn, ne_of_gt hlog]
        ring
  have hmain : F * x / (n * Real.log x) ≤
      (F / a) * x / (ell ^ 2 * Real.log x) := by
    calc
      F * x / (n * Real.log x) ≤
          F * x / ((a * ell ^ 2) * Real.log x) := by
        exact div_le_div_of_nonneg_left (mul_nonneg hF hx)
          (mul_pos (mul_pos ha (sq_pos_of_pos hell)) hlog)
          (mul_le_mul_of_nonneg_right hdegree hlog.le)
      _ = (F / a) * x / (ell ^ 2 * Real.log x) := by
        simp only [div_eq_mul_inv, mul_inv_rev]
        ring
  exact hdivide.trans (add_le_add_right hmain _)

/-- Summing the individual bounds uses only two elementary prime sums. -/
theorem split_sum_bound
    (S : Finset ℕ) (b : ℕ → ℝ)
    {x t U V H J Y z : ℝ}
    (hx : 0 ≤ x) (hlog : 0 < Real.log x) (ht : 0 ≤ t)
    (hU : 0 ≤ U) (hV : 0 ≤ V)
    (hindividual : ∀ ell ∈ S,
      b ell ≤ U * x / ((ell : ℝ) ^ 2 * Real.log x) +
        V * t * Real.log (2 * (ell : ℝ)) / Real.log x)
    (hreciprocal : (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y))
    (hchebyshev : (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) ≤ J * z) :
    (∑ ell ∈ S, b ell) ≤
      (U * H) * x / (Y * Real.log Y * Real.log x) +
        (V * J) * t * z / Real.log x := by
  have hmain_nonneg : 0 ≤ U * x / Real.log x :=
    div_nonneg (mul_nonneg hU hx) hlog.le
  have herr_nonneg : 0 ≤ V * t / Real.log x :=
    div_nonneg (mul_nonneg hV ht) hlog.le
  calc
    (∑ ell ∈ S, b ell) ≤ ∑ ell ∈ S,
        (U * x / ((ell : ℝ) ^ 2 * Real.log x) +
          V * t * Real.log (2 * (ell : ℝ)) / Real.log x) :=
      Finset.sum_le_sum hindividual
    _ = (U * x / Real.log x) *
          (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) +
        (V * t / Real.log x) *
          (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) := by
      rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
      congr 1 <;> apply Finset.sum_congr rfl <;> intro ell hell
      · simp only [div_eq_mul_inv, mul_inv_rev]
        ring
      · ring
    _ ≤ (U * x / Real.log x) * (H / (Y * Real.log Y)) +
        (V * t / Real.log x) * (J * z) := by
      exact add_le_add
        (mul_le_mul_of_nonneg_left hreciprocal hmain_nonneg)
        (mul_le_mul_of_nonneg_left hchebyshev herr_nonneg)
    _ = (U * H) * x / (Y * Real.log Y * Real.log x) +
        (V * J) * t * z / Real.log x := by
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

/-- The normalized form used when subtracting obstructions from candidates.
Only the error factor contains `N`; the displayed constants remain uniform. -/
theorem split_sum_normalized
    (S : Finset ℕ) (b : ℕ → ℝ)
    {x N ε U V H J Y : ℝ}
    (hx : 1 < x) (hU : 0 ≤ U) (hV : 0 ≤ V)
    (hindividual : ∀ ell ∈ S,
      b ell ≤ U * x / ((ell : ℝ) ^ 2 * Real.log x) +
        V * x ^ (1 - 1 / N) * Real.log (2 * (ell : ℝ)) / Real.log x)
    (hreciprocal : (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y))
    (hchebyshev : (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) ≤ J * x ^ ε) :
    (∑ ell ∈ S, b ell) ≤
      (U * H / (Y * Real.log Y) + V * J * x ^ (-1 / N + ε)) *
        (x / Real.log x) := by
  have hxpos : 0 < x := lt_trans zero_lt_one hx
  have hpower : x ^ (1 - 1 / N) * x ^ ε = x * x ^ (-1 / N + ε) := by
    calc
      x ^ (1 - 1 / N) * x ^ ε = x ^ (1 + (-1 / N + ε)) := by
        rw [← Real.rpow_add hxpos]
        congr 1
        ring
      _ = x ^ (1 : ℝ) * x ^ (-1 / N + ε) := Real.rpow_add hxpos _ _
      _ = x * x ^ (-1 / N + ε) := by rw [Real.rpow_one]
  have hsum := split_sum_bound S b hxpos.le (Real.log_pos hx)
    (Real.rpow_nonneg hxpos.le _) hU hV hindividual hreciprocal hchebyshev
  calc
    (∑ ell ∈ S, b ell) ≤
        (U * H) * x / (Y * Real.log Y * Real.log x) +
          (V * J) * x ^ (1 - 1 / N) * x ^ ε / Real.log x := hsum
    _ = (U * H / (Y * Real.log Y) + V * J * x ^ (-1 / N + ε)) *
        (x / Real.log x) := by
      rw [mul_assoc (V * J), hpower]
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

end Cyclic
