import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

/-!
# Uniform parameter choice for cyclic reductions

This file proves the analytic parameter optimization in Section 5 of the
positive-proportion manuscript. There are no number-theoretic assumptions here.
The decay of the error term is proved from the real-power limit in mathlib.
-/

noncomputable section

open Filter Topology

namespace Cyclic

/-- The exponent supplied by the zero-free strip becomes strictly negative. -/
theorem error_eventually_small {α N t : ℝ} (hα : α < 1) (hN : 0 < N)
    (ht : 0 < t) (C : ℝ) :
    ∀ᶠ x : ℝ in atTop, C * x ^ (-1 / N + α / N) < t := by
  have hδ : 0 < (1 - α) / N := div_pos (sub_pos.mpr hα) hN
  have hexp : -1 / N + α / N = -((1 - α) / N) := by ring
  have hlim : Tendsto (fun x : ℝ => C * x ^ (-1 / N + α / N)) atTop (𝓝 0) := by
    simpa only [hexp, mul_zero] using (tendsto_rpow_neg_atTop hδ).const_mul C
  exact hlim.eventually_lt_const ht

/-- The logarithmic cost is bounded by a constant independent of `N`. -/
theorem log_scale_bound {B N : ℝ} (hB : 2 ≤ B) (hN : 2 ≤ N) :
    Real.log (B * N) ≤ (1 + Real.log B / Real.log 2) * Real.log N := by
  have hBpos : 0 < B := by linarith
  have hNpos : 0 < N := by linarith
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
  have hlogN : Real.log (2 : ℝ) ≤ Real.log N := Real.log_le_log (by norm_num) hN
  have hmul := mul_le_mul_of_nonneg_left hlogN
    (div_nonneg hlogB (le_of_lt hlog2))
  have hcancel : (Real.log B / Real.log 2) * Real.log 2 = Real.log B := by
    field_simp [ne_of_gt hlog2]
  rw [hcancel] at hmul
  rw [Real.log_mul (ne_of_gt hBpos) (ne_of_gt hNpos)]
  nlinarith

/-- Concrete parameters give the manuscript's uniform `1 / (N log N)` bound. -/
theorem parameter_core {A α B C₁ C₂ N : ℝ}
    (hA : 0 < A) (hαpos : 0 < α) (hαone : α < 1)
    (hB : 2 ≤ B) (hC : C₁ / B ≤ A * α / 4) (hN : 2 ≤ N) :
    ∀ᶠ x : ℝ in atTop,
      (A * α / (2 * (1 + Real.log B / Real.log 2))) / (N * Real.log N) ≤
        A * (α / N) / Real.log (B * N) -
          C₁ / ((B * N) * Real.log (B * N)) -
          C₂ * x ^ (-1 / N + α / N) := by
  have hBpos : 0 < B := by linarith
  have hNpos : 0 < N := by linarith
  have hBN : 1 < B * N := by nlinarith
  have hlogBN : 0 < Real.log (B * N) := Real.log_pos hBN
  have hlogN : 0 < Real.log N := Real.log_pos (by linarith)
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
  let K : ℝ := 1 + Real.log B / Real.log 2
  have hK : 0 < K := by dsimp [K]; positivity
  let m : ℝ := A * α / (N * Real.log (B * N))
  have hm : 0 < m := by dsimp [m]; positivity
  have hsmall : C₁ / ((B * N) * Real.log (B * N)) ≤ m / 4 := by
    have h := div_le_div_of_nonneg_right hC
      (le_of_lt (mul_pos hNpos hlogBN))
    convert h using 1 <;> dsimp [m] <;> ring
  have hscale := log_scale_bound hB hN
  have hden : N * Real.log (B * N) ≤ N * (K * Real.log N) := by
    exact mul_le_mul_of_nonneg_left hscale (le_of_lt hNpos)
  have hmain : (A * α / (2 * K)) / (N * Real.log N) ≤ m / 2 := by
    have h := div_le_div_of_nonneg_left (by positivity : 0 ≤ A * α / 2)
      (mul_pos hNpos hlogBN) hden
    convert h using 1 <;> dsimp [m] <;>
      field_simp [ne_of_gt hK, ne_of_gt hNpos, ne_of_gt hlogN, ne_of_gt hlogBN] <;> ring
  have hfirst : A * (α / N) / Real.log (B * N) = m := by
    dsimp [m]
    ring
  filter_upwards [error_eventually_small hαone hNpos (by positivity : 0 < m / 4) C₂]
    with x hx
  change (A * α / (2 * K)) / (N * Real.log N) ≤ _
  rw [hfirst]
  linarith

/-- Uniformity in the zero-free width: the constant is chosen before `N`.

The output parameters are fixed before the eventual limit in `x` is taken.
-/
theorem exists_uniform_parameters {A ε₀ Y₀ C₁ C₂ : ℝ}
    (hA : 0 < A) (hε₀ : 0 < ε₀) :
    ∃ d : ℝ, 0 < d ∧ ∀ N : ℝ, 2 ≤ N →
      ∃ ε Y : ℝ, 0 < ε ∧ ε < ε₀ ∧ Y₀ ≤ Y ∧ 3 ≤ Y ∧
        ∀ᶠ x : ℝ in atTop,
          d / (N * Real.log N) ≤
            A * ε / Real.log Y - C₁ / (Y * Real.log Y) -
              C₂ * x ^ (-1 / N + ε) := by
  let α : ℝ := min (1 / 2) ε₀
  have hαpos : 0 < α := lt_min (by norm_num) hε₀
  have hαhalf : α ≤ 1 / 2 := min_le_left _ _
  have hαε : α ≤ ε₀ := min_le_right _ _
  have hαone : α < 1 := by linarith
  let B : ℝ := max 2 (max Y₀ (4 * C₁ / (A * α)))
  have hB : 2 ≤ B := le_max_left _ _
  have hBY : Y₀ ≤ B := (le_max_left _ _).trans (le_max_right _ _)
  have hBC : 4 * C₁ / (A * α) ≤ B :=
    (le_max_right _ _).trans (le_max_right _ _)
  have hBpos : 0 < B := by linarith
  have hC : C₁ / B ≤ A * α / 4 := by
    have hmul : 4 * C₁ ≤ B * (A * α) := (div_le_iff₀ (mul_pos hA hαpos)).mp hBC
    apply (div_le_iff₀ hBpos).2
    nlinarith
  let d : ℝ := A * α / (2 * (1 + Real.log B / Real.log 2))
  have hd : 0 < d := by
    have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
    have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
    dsimp [d]
    positivity
  refine ⟨d, hd, ?_⟩
  intro N hN
  have hNpos : 0 < N := by linarith
  refine ⟨α / N, B * N, div_pos hαpos hNpos, ?_, ?_, ?_, ?_⟩
  · apply (div_lt_iff₀ hNpos).2
    nlinarith
  · have : B ≤ B * N := by nlinarith
    exact hBY.trans this
  · nlinarith
  · exact parameter_core hA hαpos hαone hB hC hN

end Cyclic
