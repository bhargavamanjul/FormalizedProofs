import Mathlib

/-!
# From dyadic prime counts to a lower proportion

This module contains no analytic black box.  The prime number theorem is an
explicit hypothesis on the counting function `P`; the passage from a dyadic
lower bound to a lower proportion, including the factor `1/2`, is proved here.
-/

open Filter
open scoped Topology

namespace Cyclic

/-- PNT itself supplies eventual positivity of the prime-counting function. -/
theorem eventually_positive_of_pnt
    (P : ℝ → ℝ)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1)) :
    ∀ᶠ X : ℝ in atTop, 0 < P X := by
  have hratio := hPNT.eventually (lt_mem_nhds (by norm_num : (0 : ℝ) < 1))
  filter_upwards [hratio, eventually_ge_atTop (4 : ℝ)] with X hratio hX
  have hscale : 0 < X / Real.log X :=
    div_pos (by linarith) (Real.log_pos (by linarith))
  exact (div_pos_iff_of_pos_right hscale).1 hratio

/-- The dyadic prime scale dominates half the full prime scale. -/
theorem half_prime_scale {X : ℝ} (hX : 4 ≤ X) :
    (X / Real.log X) / 2 ≤ (X / 2) / Real.log (X / 2) := by
  have hhalf : 1 < X / 2 := by linarith
  have hXpos : 0 < X := by linarith
  have hloghalf : 0 < Real.log (X / 2) := Real.log_pos hhalf
  have hlogX : 0 < Real.log X := Real.log_pos (by linarith)
  have hlogs : Real.log (X / 2) ≤ Real.log X :=
    Real.log_le_log (by linarith) (by linarith)
  have hdiv : (X / 2) / Real.log X ≤ (X / 2) / Real.log (X / 2) :=
    div_le_div_of_nonneg_left (by linarith) hloghalf hlogs
  convert hdiv using 1
  ring

/-- A dyadic lower bound implies the matching global lower bound with factor
`1/2`.  No monotonicity hypothesis on `C` is needed. -/
theorem global_bound_of_dyadic
    (C : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop, (k / 2) * (X / Real.log X) ≤ C X := by
  have hhalf : Tendsto (fun X : ℝ => X / 2) atTop atTop :=
    (tendsto_div_const_atTop_of_pos (by norm_num : (0 : ℝ) < 2)).2 tendsto_id
  filter_upwards [hhalf.eventually hdyadic, eventually_ge_atTop (4 : ℝ)] with X hd hX
  have hscale := mul_le_mul_of_nonneg_left (half_prime_scale hX) hk
  have hnonneg := hC (X / 2)
  have htwice : 2 * (X / 2) = X := by ring
  rw [htwice] at hd
  nlinarith

/-- The comparison function arising from PNT tends to the expected constant. -/
theorem density_comparison_tendsto
    (P : ℝ → ℝ) (k : ℝ)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1)) :
    Tendsto (fun X : ℝ => (k / 2) / (P X / (X / Real.log X)))
      atTop (𝓝 (k / 2)) := by
  simpa using
    (tendsto_const_nhds : Tendsto (fun _ : ℝ => k / 2) atTop (𝓝 (k / 2))).div
      hPNT (by norm_num : (1 : ℝ) ≠ 0)

/-- PNT and eventual positivity convert the dyadic bound into an eventual
comparison with a function tending to `k/2`. -/
theorem eventually_density_comparison
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop,
      (k / 2) / (P X / (X / Real.log X)) ≤ C X / P X := by
  filter_upwards [global_bound_of_dyadic C k hk hC hdyadic,
    hP] with X hglobal hPX
  have hdiv := div_le_div_of_nonneg_right hglobal (le_of_lt hPX)
  convert hdiv using 1
  simp [div_eq_mul_inv, mul_assoc, mul_comm, mul_left_comm]

/-- Exact lower-liminf bound.  `C ≤ P` is the natural hypothesis that the
counted primes form a subset of all primes; it also ensures the real liminf
is finite. -/
theorem lower_proportion_of_dyadic
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hsubset : ∀ᶠ X : ℝ in atTop, C X ≤ P X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1))
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    k / 2 ≤ Filter.liminf (fun X : ℝ => C X / P X) atTop := by
  have hlim := density_comparison_tendsto P k hPNT
  have hupper : ∀ᶠ X : ℝ in atTop, C X / P X ≤ 1 := by
    filter_upwards [hsubset, hP] with X hsub hpos
    exact (div_le_one hpos).2 hsub
  have hcomp := eventually_density_comparison C P k hk hC hP hdyadic
  rw [← hlim.liminf_eq]
  exact Filter.liminf_le_liminf hcomp hlim.isBoundedUnder_ge
    (Filter.isCoboundedUnder_ge_of_eventually_le atTop hupper)

/-- A strictly positive eventual lower proportion, convenient when only
positivity (rather than the exact `1/2` factor) is required. -/
theorem eventually_positive_proportion_of_dyadic
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 < k)
    (hC : ∀ X, 0 ≤ C X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1))
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop, k / 4 ≤ C X / P X := by
  have hlim := density_comparison_tendsto P k hPNT
  have hlt : k / 4 < k / 2 := by linarith
  have hevent := hlim.eventually (lt_mem_nhds hlt)
  filter_upwards [hevent,
    eventually_density_comparison C P k (le_of_lt hk) hC hP hdyadic]
    with X hlo hcomp
  exact le_trans (le_of_lt hlo) hcomp

end Cyclic
