import Cyclic.Audit

/-!
Entry point for the conditional formalization of
"Cyclic reductions of elliptic curves at a positive proportion of primes".
See README.md and ASSUMPTIONS.md for the exact scope and external inputs.
-/

