import Mathlib

/-!
# Cyclic reductions at a positive proportion of primes
Single-file export, 25 October 2026. Lean 4.19.0 / Mathlib v4.19.0.

This kernel-checks the deductions conditional on explicit analytic and classical
arithmetic inputs. The conclusion uses actual Mathlib elliptic point groups.
External inputs are theorem arguments: the predecessor cofactor sieve, smoothed
explicit formula, zero-free half-plane, standard division-field/character/torsion
facts, prime estimates, and PNT. Actual number fields and their zeta functions
are not constructed here. See the accompanying project README and ASSUMPTIONS.
No full-density result is claimed.
-/


/-! ## Module: Definitions -/

/-!
# Concrete finite prime counts and the interfaces used by the proof

The reduction predicates are parameters. `EllipticModel.lean` instantiates them
with integral Weierstrass equations and Mathlib's actual point groups.
No arithmetic or analytic conclusion is built into these definitions.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

structure ReductionData where
  good : ℕ → Prop
  cyclic : ℕ → Prop
  split : ℕ → ℕ → Prop

def primeInterval (P : ℕ → Prop) (x : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈2 * x⌉₊ + 1)).filter
    (fun p => p.Prime ∧ x < (p : ℝ) ∧ (p : ℝ) < 2 * x ∧ P p)

def primeUpTo (P : ℕ → Prop) (X : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈X⌉₊ + 1)).filter
    (fun p => p.Prime ∧ (p : ℝ) ≤ X ∧ P p)

def primeIndices (Y z : ℝ) : Finset ℕ := by
  classical
  exact (Finset.range (⌈z⌉₊ + 1)).filter
    (fun ell => ell.Prime ∧ Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z)

@[simp] theorem mem_primeInterval {P : ℕ → Prop} {x : ℝ} {p : ℕ} :
    p ∈ primeInterval P x ↔ p.Prime ∧ x < (p : ℝ) ∧ (p : ℝ) < 2*x ∧ P p := by
  classical
  simp only [primeInterval, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : (p : ℝ) ≤ (⌈2*x⌉₊ : ℝ) := h.2.2.1.le.trans (Nat.le_ceil _)
    exact ⟨Nat.lt_succ_of_le (by exact_mod_cast this), h⟩

@[simp] theorem mem_primeUpTo {P : ℕ → Prop} {X : ℝ} {p : ℕ} :
    p ∈ primeUpTo P X ↔ p.Prime ∧ (p : ℝ) ≤ X ∧ P p := by
  classical
  simp only [primeUpTo, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : p ≤ ⌈X⌉₊ := by exact_mod_cast h.2.1.trans (Nat.le_ceil X)
    exact ⟨Nat.lt_succ_of_le this, h⟩

@[simp] theorem mem_primeIndices {Y z : ℝ} {ell : ℕ} :
    ell ∈ primeIndices Y z ↔ ell.Prime ∧ Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z := by
  classical
  simp only [primeIndices, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact fun h => h.2
  · intro h
    have : ell ≤ ⌈z⌉₊ := by exact_mod_cast h.2.2.trans (Nat.le_ceil z)
    exact ⟨Nat.lt_succ_of_le this, h⟩

def primeCount (X : ℝ) : ℝ := (primeUpTo (fun _ => True) X).card
def cyclicCount (D : ReductionData) (X : ℝ) : ℝ :=
  (primeUpTo (fun p => D.good p ∧ D.cyclic p) X).card
def cyclicInterval (D : ReductionData) (x : ℝ) : Finset ℕ :=
  primeInterval (fun p => D.good p ∧ D.cyclic p) x
def splitCount (D : ReductionData) (ell : ℕ) (x : ℝ) : ℝ :=
  (primeInterval (D.split ell) x).card

theorem cyclicCount_nonneg (D : ReductionData) (X : ℝ) : 0 ≤ cyclicCount D X := by
  exact Nat.cast_nonneg _

theorem cyclicCount_le_primeCount (D : ReductionData) (X : ℝ) :
    cyclicCount D X ≤ primeCount X := by
  unfold cyclicCount primeCount
  have hs : primeUpTo (fun p => D.good p ∧ D.cyclic p) X ⊆
      primeUpTo (fun _ => True) X := by
    intro p hp
    rcases mem_primeUpTo.mp hp with ⟨hprime, hX, _⟩
    exact mem_primeUpTo.mpr ⟨hprime, hX, trivial⟩
  exact_mod_cast Finset.card_le_card hs

theorem cyclicInterval_le_difference (D : ReductionData) {x : ℝ} (hx : 0 ≤ x) :
    ((cyclicInterval D x).card : ℝ) ≤ cyclicCount D (2*x) - cyclicCount D x := by
  classical
  let A := primeUpTo (fun p => D.good p ∧ D.cyclic p) x
  let B := cyclicInterval D x
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro p hpA hpB
    have hA := (mem_primeUpTo.mp hpA).2.1
    have hB := (mem_primeInterval.mp hpB).2.1
    exact (not_lt_of_ge hA) hB
  have hs : A ∪ B ⊆ primeUpTo (fun p => D.good p ∧ D.cyclic p) (2*x) := by
    intro p hp
    rcases Finset.mem_union.mp hp with ha | hb
    · rcases mem_primeUpTo.mp ha with ⟨hp, hpx, hc⟩
      exact mem_primeUpTo.mpr ⟨hp, hpx.trans (by linarith), hc⟩
    · rcases mem_primeInterval.mp hb with ⟨hp, _, hpx, hc⟩
      exact mem_primeUpTo.mpr ⟨hp, hpx.le, hc⟩
  have hnat := Finset.card_le_card hs
  rw [Finset.card_union_of_disjoint hd] at hnat
  have hr : (A.card : ℝ) + (B.card : ℝ) ≤ cyclicCount D (2*x) := by
    unfold cyclicCount
    exact_mod_cast hnat
  change (B.card : ℝ) ≤ cyclicCount D (2*x) - (A.card : ℝ)
  linarith

/-- A fixed progression, with the exact local admissibility used by the sieve. -/
structure Progression where
  M : ℕ
  u : ℕ
  k : ℕ
  M_pos : 0 < M
  c_dvd_M : 2^k ∣ M
  even_quotient : 2 ∣ M / 2^k
  unit : Nat.Coprime u M
  c_dvd_u_sub_one : 2^k ∣ u-1
  reduced_quotient : Nat.Coprime ((u-1)/2^k) (M/2^k)

def InProgression (g : Progression) (p : ℕ) : Prop := p % g.M = g.u % g.M

def Candidate (g : Progression) (x ε Y : ℝ) (p : ℕ) : Prop :=
  InProgression g p ∧ ∃ r Q : ℕ,
    p-1 = 2^g.k*r*Q ∧ Q.Prime ∧ x^(9/10 : ℝ) < (Q : ℝ) ∧
    (r : ℝ) ≤ x^ε ∧ ∀ q : ℕ, q.Prime → q ∣ r → Y < (q : ℝ)

def candidates (g : Progression) (x ε Y : ℝ) : Finset ℕ :=
  primeInterval (Candidate g x ε Y) x

/-- Classical elliptic facts, stated separately from the analytic black boxes. -/
structure ArithmeticFacts (D : ReductionData) (g : Progression) : Prop where
  progression_good : ∀ p, p.Prime → InProgression g p → D.good p
  progression_not_split_two : ∀ p, p.Prime → InProgression g p → ¬ D.split 2 p
  obstruction : ∀ p, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p →
    ∃ ell, ell.Prime ∧ D.split ell p ∧ ell ∣ p-1 ∧
      (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1

/-- The predecessor form of the varying-cofactor sieve from the agreed earlier work.
The independence of A, ε₀, Y₀ from ε,Y is expressed by the quantifier order. -/
def CofactorSieve (g : Progression) : Prop :=
  ∃ A ε₀ Y₀ : ℝ, 0 < A ∧ 0 < ε₀ ∧ 3 ≤ Y₀ ∧
    ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        A*ε/Real.log Y * (x/Real.log x) ≤ ((candidates g x ε Y).card : ℝ)

/-- Standard PNT, isolated as an external input rather than hidden in a limit axiom. -/
def PrimeNumberTheorem : Prop :=
  Tendsto (fun X : ℝ => primeCount X / (X / Real.log X)) atTop (𝓝 1)

end Cyclic

/-! ## Module: Counting -/

/-!
# Removing finitely many splitting obstructions

These lemmas are purely finite combinatorics. They implement the union bound
used in Section 5 of the cyclic-reduction manuscript; no independence of the
candidate condition and the splitting conditions is assumed.
-/

namespace Cyclic

open scoped BigOperators

variable {α ι : Type*} [DecidableEq α]

/-- The cardinality of a finite union is at most the sum of the cardinalities. -/
theorem obstruction_union_card_le (indices : Finset ι) (bad : ι → Finset α) :
    (indices.biUnion bad).card ≤ ∑ i ∈ indices, (bad i).card := by
  exact Finset.card_biUnion_le

/-- Every candidate is either good or has one of the indexed obstructions. -/
theorem candidate_card_le_good_add_obstructions
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad) :
    candidates.card ≤ good.card + ∑ i ∈ indices, (bad i).card := by
  calc
    candidates.card ≤ (good ∪ indices.biUnion bad).card := Finset.card_le_card hcover
    _ ≤ good.card + (indices.biUnion bad).card := Finset.card_union_le _ _
    _ ≤ good.card + ∑ i ∈ indices, (bad i).card :=
      Nat.add_le_add_left (obstruction_union_card_le indices bad) good.card

/-- The real-valued subtraction form needed for the analytic lower bounds. -/
theorem candidate_removal
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad) :
    (candidates.card : ℝ) - ∑ i ∈ indices, ((bad i).card : ℝ) ≤
      (good.card : ℝ) := by
  have hnat := candidate_card_le_good_add_obstructions candidates good indices bad hcover
  have hreal : (candidates.card : ℝ) ≤
      (good.card : ℝ) + ∑ i ∈ indices, ((bad i).card : ℝ) := by
    exact_mod_cast hnat
  linarith

/-- A pointwise obstruction statement is enough to construct the covering. -/
theorem candidate_removal_of_witness
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (hwitness : ∀ p ∈ candidates, p ∉ good → ∃ i ∈ indices, p ∈ bad i) :
    (candidates.card : ℝ) - ∑ i ∈ indices, ((bad i).card : ℝ) ≤
      (good.card : ℝ) := by
  apply candidate_removal
  intro p hp
  by_cases hgood : p ∈ good
  · exact Finset.mem_union_left _ hgood
  · rcases hwitness p hp hgood with ⟨i, hi, hbad⟩
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨i, hi, hbad⟩)

/-- Combine a candidate lower bound and an unrestricted obstruction upper bound. -/
theorem candidate_removal_bounds
    (candidates good : Finset α) (indices : Finset ι) (bad : ι → Finset α)
    (candidateLower badUpper : ℝ)
    (hcover : candidates ⊆ good ∪ indices.biUnion bad)
    (hcandidates : candidateLower ≤ (candidates.card : ℝ))
    (hbad : (∑ i ∈ indices, ((bad i).card : ℝ)) ≤ badUpper) :
    candidateLower - badUpper ≤ (good.card : ℝ) := by
  have hremove := candidate_removal candidates good indices bad hcover
  linarith

end Cyclic

/-! ## Module: Character -/

/-!
# The local character argument

The elementary character compatibility argument does not need orthogonality.
A nontrivial group character constant away from the identity forces the source
group to have exactly two elements. For the units of a prime field, this is
precisely the exceptional prime 3.
-/

namespace Cyclic

section Local

variable {G H : Type*} [Group G] [Group H]

/-- Constancy on a nonempty set stable under multiplication forces that
multiplying element into the kernel. -/
theorem character_eq_one_of_stable_const
    (χ : G →* H) (S : Set G) (hS : S.Nonempty)
    (hconst : ∀ a ∈ S, ∀ b ∈ S, χ a = χ b)
    (h : G) (hstable : ∀ a ∈ S, h * a ∈ S) : χ h = 1 := by
  rcases hS with ⟨a, ha⟩
  have heq := hconst (h * a) (hstable a ha) a ha
  rw [map_mul] at heq
  apply mul_right_cancel (b := χ a)
  simpa using heq

/-- A nontrivial character constant on the nonidentity elements makes those
elements unique. -/
theorem nonidentity_unique_of_character_const
    (χ : G →* H)
    (hconst : ∀ a b : G, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1)
    {a b : G} (ha : a ≠ 1) (hb : b ≠ 1) : a = b := by
  rcases hnontrivial with ⟨g, hg⟩
  have hg1 : g ≠ 1 := by
    intro h
    apply hg
    simp [h]
  have hχa : χ a ≠ 1 := by
    rw [hconst a g ha hg1]
    exact hg
  by_contra hab
  have hab1 : a * b⁻¹ ≠ 1 := by
    intro h
    exact hab (eq_of_mul_inv_eq_one h)
  have hmap : χ (a * b⁻¹) = 1 := by
    rw [map_mul, map_inv, hconst a b ha hb, mul_inv_cancel]
  exact hχa ((hconst (a * b⁻¹) a hab1 ha).symm.trans hmap)

/-- The only finite source group supporting such a nontrivial character has
order two. -/
theorem card_two_of_character_const [Fintype G]
    (χ : G →* H)
    (hconst : ∀ a b : G, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : Fintype.card G = 2 := by
  classical
  rcases hnontrivial with ⟨g, hg⟩
  have hg1 : g ≠ 1 := by
    intro h
    apply hg
    simp [h]
  have hset : (Finset.univ : Finset G) = {1, g} := by
    ext a
    simp only [Finset.mem_univ, Finset.mem_insert, Finset.mem_singleton, true_iff]
    by_cases ha : a = 1
    · exact Or.inl ha
    · exact Or.inr (nonidentity_unique_of_character_const χ hconst ⟨g, hg⟩ ha hg1)
  calc
    Fintype.card G = (Finset.univ : Finset G).card := rfl
    _ = ({1, g} : Finset G).card := congrArg Finset.card hset
    _ = 2 := by simp [hg1, Ne.symm hg1]

/-- The same order-two conclusion holds after a surjective residue map.
Constancy away from the residue identity first kills the residue kernel. -/
theorem quotient_card_two_of_character_const
    {Q : Type*} [Group Q] [Fintype Q]
    (r : G →* Q) (hr : Function.Surjective r) (χ : G →* H)
    (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : Fintype.card Q = 2 := by
  classical
  have hker : ∀ g : G, r g = 1 → χ g = 1 := by
    intro g hg
    apply character_eq_one_of_stable_const χ {a | r a ≠ 1} hallowed
    · intro a ha b hb
      exact hconst a b ha hb
    · intro a ha
      change r (g * a) ≠ 1
      simpa [map_mul, hg] using ha
  rcases hnontrivial with ⟨g, hg⟩
  have hrg : r g ≠ 1 := fun h => hg (hker g h)
  have hunique : ∀ a b : Q, a ≠ 1 → b ≠ 1 → a = b := by
    intro a b ha hb
    obtain ⟨a', rfl⟩ := hr a
    obtain ⟨b', rfl⟩ := hr b
    by_contra hab
    have hquot : r (a' * b'⁻¹) ≠ 1 := by
      rw [map_mul, map_inv]
      intro heq
      exact hab (eq_of_mul_inv_eq_one heq)
    have hmap : χ (a' * b'⁻¹) = 1 := by
      rw [map_mul, map_inv, hconst a' b' ha hb, mul_inv_cancel]
    exact hg ((hconst (a' * b'⁻¹) g hquot hrg).symm.trans hmap)
  have hset : (Finset.univ : Finset Q) = {1, r g} := by
    ext a
    simp only [Finset.mem_univ, Finset.mem_insert, Finset.mem_singleton, true_iff]
    by_cases ha : a = 1
    · exact Or.inl ha
    · exact Or.inr (hunique a (r g) ha hrg)
  calc
    Fintype.card Q = (Finset.univ : Finset Q).card := rfl
    _ = ({1, r g} : Finset Q).card := congrArg Finset.card hset
    _ = 2 := by simp [hrg, Ne.symm hrg]

end Local

/-- The exceptional odd prime in the local character argument is 3. -/
theorem prime_eq_three_of_character_const
    (q : ℕ) [Fact q.Prime] {H : Type*} [Group H]
    (χ : (ZMod q)ˣ →* H)
    (hconst : ∀ a b : (ZMod q)ˣ, a ≠ 1 → b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : (ZMod q)ˣ, χ g ≠ 1) : q = 3 := by
  have hcard := card_two_of_character_const χ hconst hnontrivial
  rw [ZMod.card_units] at hcard
  have hq : 2 ≤ q := (Fact.out : q.Prime).two_le
  omega

/-- Prime-power residue-map version of the exceptional-prime conclusion.
Only surjectivity of the unit reduction map is needed. -/
theorem prime_eq_three_of_residue_character_const
    (q : ℕ) [Fact q.Prime] {G H : Type*} [Group G] [Group H]
    (r : G →* (ZMod q)ˣ) (hr : Function.Surjective r)
    (χ : G →* H) (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1) : q = 3 := by
  have hcard := quotient_card_two_of_character_const r hr χ hallowed hconst hnontrivial
  rw [ZMod.card_units] at hcard
  have hq : 2 ≤ q := (Fact.out : q.Prime).two_le
  omega

/-- The exceptional constant for a complex-valued character is -1. -/
theorem complex_character_eq_neg_one_of_residue_const
    {G Q : Type*} [Group G] [Group Q] [Fintype Q]
    (r : G →* Q) (hr : Function.Surjective r) (χ : G →* ℂˣ)
    (hallowed : ∃ a : G, r a ≠ 1)
    (hconst : ∀ a b : G, r a ≠ 1 → r b ≠ 1 → χ a = χ b)
    (hnontrivial : ∃ g : G, χ g ≠ 1)
    {a : G} (ha : r a ≠ 1) : χ a = -1 := by
  have hcard := quotient_card_two_of_character_const r hr χ hallowed hconst hnontrivial
  have hker : ∀ g : G, r g = 1 → χ g = 1 := by
    intro g hg
    apply character_eq_one_of_stable_const χ {a | r a ≠ 1} hallowed
    · intro a ha b hb
      exact hconst a b ha hb
    · intro b hb
      change r (g * b) ≠ 1
      simpa [map_mul, hg] using hb
  have hrpow : r (a * a) = 1 := by
    rw [map_mul, ← pow_two, ← hcard]
    exact pow_card_eq_one
  have hχpow : χ a * χ a = 1 := by
    rw [← map_mul]
    exact hker (a * a) hrpow
  have hv := congrArg (fun u : ℂˣ => (u : ℂ)) hχpow
  simp only [Units.val_mul, Units.val_one] at hv
  have hne : χ a ≠ 1 := by
    rcases hnontrivial with ⟨g, hg⟩
    have hrg : r g ≠ 1 := fun h => hg (hker g h)
    rw [hconst a g ha hrg]
    exact hg
  rcases mul_self_eq_one_iff.mp hv with hval | hval
  · exact False.elim (hne (Units.ext hval))
  · apply Units.ext
    simpa using hval

section Product

open scoped BigOperators

variable {ι : Type*} [Fintype ι] {G : ι → Type*} {H : Type*} [CommGroup H]

/-- If a product of independent local functions is identically one on a
nonempty product set, each local function is constant on its allowed set. -/
theorem local_const_of_product_one
    (χ : ∀ i, G i → H) (allowed : ∀ i, Set (G i))
    (hne : ∀ i, (allowed i).Nonempty)
    (hprod : ∀ a : ∀ i, G i, (∀ i, a i ∈ allowed i) → ∏ i, χ i (a i) = 1)
    (i : ι) : ∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b := by
  classical
  choose base hbase using hne
  let T := ∏ j ∈ (Finset.univ : Finset ι) \ {i}, χ j (base j)
  have hvalue (a : G i) (ha : a ∈ allowed i) : χ i a * T = 1 := by
    have hallowed : ∀ j, Function.update base i a j ∈ allowed j := by
      intro j
      by_cases hji : j = i
      · subst j
        simpa using ha
      · simpa [Function.update_of_ne hji] using hbase j
    have hcomp : (fun j => χ j (Function.update base i a j)) =
        Function.update (fun j => χ j (base j)) i (χ i a) := by
      funext j
      by_cases hji : j = i
      · subst j
        simp
      · simp [Function.update_of_ne hji]
    have hp := hprod (Function.update base i a) hallowed
    change (∏ j, (fun k => χ k (Function.update base i a k)) j) = 1 at hp
    rw [hcomp, Finset.prod_update_of_mem (Finset.mem_univ i)] at hp
    exact hp
  intro a ha b hb
  exact mul_right_cancel ((hvalue a ha).trans (hvalue b hb).symm)

/-- The global compatibility argument: if constant local restrictions are
trivial except possibly at a unique exceptional coordinate, whose constant
value is not one, a nontrivial product character cannot be one on every
allowed tuple. The application has the exceptional coordinate q=3 and
exceptional value -1. -/
theorem exists_allowed_product_ne_one
    (χ : ∀ i, G i → H) (allowed : ∀ i, Set (G i))
    (hne : ∀ i, (allowed i).Nonempty)
    (exceptional : ι → Prop) (z : H) (hz : z ≠ 1)
    (hunique : ∀ i j, exceptional i → exceptional j → i = j)
    (hclassify : ∀ i,
      (∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b) →
      (∀ g, χ i g = 1) ∨ (exceptional i ∧ ∀ a ∈ allowed i, χ i a = z))
    (hnontrivial : ∃ i, ∃ g : G i, χ i g ≠ 1) :
    ∃ a : ∀ i, G i, (∀ i, a i ∈ allowed i) ∧ (∏ i, χ i (a i)) ≠ 1 := by
  classical
  by_contra h
  have hprod : ∀ a : ∀ i, G i, (∀ i, a i ∈ allowed i) → ∏ i, χ i (a i) = 1 := by
    intro a ha
    by_contra hneprod
    exact h ⟨a, ha, hneprod⟩
  have hlocal := local_const_of_product_one χ allowed hne hprod
  rcases hnontrivial with ⟨i, g, hg⟩
  have hi : exceptional i ∧ ∀ a ∈ allowed i, χ i a = z := by
    rcases hclassify i (hlocal i) with htrivial | hexc
    · exact False.elim (hg (htrivial g))
    · exact hexc
  have hother : ∀ j, j ≠ i → ∀ g, χ j g = 1 := by
    intro j hji
    rcases hclassify j (hlocal j) with htrivial | hexc
    · exact htrivial
    · exact False.elim (hji (hunique j i hexc.1 hi.1))
  choose base hbase using hne
  have hp : (∏ j, χ j (base j)) = χ i (base i) := by
    apply Finset.prod_eq_single_of_mem i (Finset.mem_univ i)
    intro j _ hji
    exact hother j hji (base j)
  apply hz
  calc
    z = χ i (base i) := (hi.2 (base i) (hbase i)).symm
    _ = ∏ j, χ j (base j) := hp.symm
    _ = 1 := hprod base hbase

end Product

/-- The local-residue form of manuscript Lemma 4. The maps r are the
surjective unit reductions from prime powers to prime fields. The Chinese
remainder theorem transports the resulting tuple to a residue class modulo
the conductor. -/
theorem exists_compatible_local_residues
    {ι : Type*} [Fintype ι] (q : ι → ℕ) (hq : Function.Injective q)
    (hprime : ∀ i, (q i).Prime)
    {G : ι → Type*} [∀ i, Group (G i)]
    (r : ∀ i, G i →* (ZMod (q i))ˣ)
    (hr : ∀ i, Function.Surjective (r i))
    (χ : ∀ i, G i →* ℂˣ)
    (hnontrivial : ∃ i, ∃ g : G i, χ i g ≠ 1) :
    ∃ a : ∀ i, G i,
      (∀ i, q i ≠ 2 → r i (a i) ≠ 1) ∧ (∏ i, χ i (a i)) ≠ 1 := by
  classical
  let allowed : ∀ i, Set (G i) := fun i => {a | q i = 2 ∨ r i a ≠ 1}
  have hodd_allowed (i : ι) (hi : q i ≠ 2) : ∃ a : G i, r i a ≠ 1 := by
    letI : Fact (q i).Prime := ⟨hprime i⟩
    have hqi : 2 ≤ q i := (hprime i).two_le
    have hc : 1 < Fintype.card (ZMod (q i))ˣ := by
      rw [ZMod.card_units]
      omega
    haveI : Nontrivial (ZMod (q i))ˣ := Fintype.one_lt_card_iff_nontrivial.mp hc
    obtain ⟨b, hb⟩ := exists_ne (1 : (ZMod (q i))ˣ)
    obtain ⟨a, ha⟩ := hr i b
    exact ⟨a, by simpa [ha] using hb⟩
  have hallowed : ∀ i, (allowed i).Nonempty := by
    intro i
    by_cases hi : q i = 2
    · exact ⟨1, Or.inl hi⟩
    · obtain ⟨a, ha⟩ := hodd_allowed i hi
      exact ⟨a, Or.inr ha⟩
  have hminus : (-1 : ℂˣ) ≠ 1 := by
    intro h
    have hv := congrArg (fun u : ℂˣ => (u : ℂ)) h
    norm_num at hv
  have hclassify : ∀ i,
      (∀ a ∈ allowed i, ∀ b ∈ allowed i, χ i a = χ i b) →
      (∀ g, χ i g = 1) ∨ (q i = 3 ∧ ∀ a ∈ allowed i, χ i a = -1) := by
    intro i hconst
    by_cases hi : q i = 2
    · left
      intro g
      simpa using hconst g (Or.inl hi) 1 (Or.inl hi)
    · by_cases htrivial : ∀ g, χ i g = 1
      · exact Or.inl htrivial
      · have hnontrivial_i : ∃ g, χ i g ≠ 1 := by simpa using htrivial
        have hc : ∀ a b : G i, r i a ≠ 1 → r i b ≠ 1 → χ i a = χ i b := by
          intro a b ha hb
          exact hconst a (Or.inr ha) b (Or.inr hb)
        letI : Fact (q i).Prime := ⟨hprime i⟩
        right
        constructor
        · exact prime_eq_three_of_residue_character_const (q i) (r i) (hr i)
            (χ i) (hodd_allowed i hi) hc hnontrivial_i
        · intro a ha
          have ha' : r i a ≠ 1 := ha.resolve_left hi
          exact complex_character_eq_neg_one_of_residue_const (r i) (hr i)
            (χ i) (hodd_allowed i hi) hc hnontrivial_i ha'
  obtain ⟨a, ha, hp⟩ := exists_allowed_product_ne_one (fun i => χ i) allowed
    hallowed (fun i => q i = 3) (-1 : ℂˣ) hminus
    (fun i j hi hj => hq (hi.trans hj.symm)) hclassify hnontrivial
  refine ⟨a, ?_, hp⟩
  intro i hi
  exact (ha i).resolve_left hi

/-- Transport the local argument through a Chinese-remainder multiplicative
equivalence. The character decomposition is proved here rather than assumed. -/
theorem exists_compatible_residue_character
    {ι : Type*} [Fintype ι] (q : ι → ℕ) (hq : Function.Injective q)
    (hprime : ∀ i, (q i).Prime)
    {G : ι → Type*} [∀ i, CommGroup (G i)]
    (r : ∀ i, G i →* (ZMod (q i))ˣ)
    (hr : ∀ i, Function.Surjective (r i))
    {D : Type*} [Group D] (e : D ≃* ∀ i, G i)
    (χ : D →* ℂˣ) (hnontrivial : ∃ d : D, χ d ≠ 1) :
    ∃ d : D, (∀ i, q i ≠ 2 → r i (e d i) ≠ 1) ∧ χ d ≠ 1 := by
  classical
  let χprod : (∀ i, G i) →* ℂˣ := χ.comp e.symm.toMonoidHom
  let χlocal : ∀ i, G i →* ℂˣ := fun i => χprod.comp (MonoidHom.mulSingle G i)
  have hdecomp (a : ∀ i, G i) : (∏ i, χlocal i (a i)) = χprod a := by
    change (∏ i, χprod (Pi.mulSingle i (a i))) = χprod a
    rw [← map_prod, Finset.univ_prod_mulSingle]
  have hnontrivial_local : ∃ i, ∃ g : G i, χlocal i g ≠ 1 := by
    by_contra h
    have htrivial : ∀ i, ∀ g : G i, χlocal i g = 1 := by simpa using h
    rcases hnontrivial with ⟨d, hd⟩
    apply hd
    have hp : (∏ i, χlocal i (e d i)) = 1 := by simp [htrivial]
    rw [hdecomp] at hp
    simpa [χprod] using hp
  obtain ⟨a, ha, hp⟩ := exists_compatible_local_residues q hq hprime r hr χlocal
    hnontrivial_local
  refine ⟨e.symm a, ?_, ?_⟩
  · simpa using ha
  · rw [hdecomp] at hp
    exact hp

end Cyclic

/-! ## Module: DirichletCharacter -/

/-!
# A compatible residue for a nontrivial Dirichlet character

This is the concrete conductor version of the character lemma in the
manuscript. The finite Chinese remainder equivalence and surjectivity of
unit reduction maps are supplied by mathlib; the character argument is
proved in `Cyclic.Character`.
-/

namespace Cyclic

open scoped BigOperators

/-- Every nontrivial character of the units modulo a positive integer has
a nontrivial value on a unit that avoids 1 modulo every odd prime divisor.
The assertion does not require primitivity of the character. -/
theorem exists_compatible_dirichlet_residue
    (f : ℕ) (hf : 0 < f) (χ : (ZMod f)ˣ →* ℂˣ)
    (hχ : ∃ a : (ZMod f)ˣ, χ a ≠ 1) :
    ∃ a : (ZMod f)ˣ, χ a ≠ 1 ∧
      ∀ (q : ℕ) (_hq : q.Prime) (hqf : q ∣ f), q ≠ 2 →
        ZMod.unitsMap hqf a ≠ 1 := by
  classical
  let I := {q // q ∈ f.primeFactors}
  let modulus : I → ℕ := fun q => (q : ℕ) ^ f.factorization q
  have hp (q : I) : (q : ℕ).Prime := Nat.prime_of_mem_primeFactors q.property
  have hexp (q : I) : 0 < f.factorization q :=
    (hp q).factorization_pos_of_dvd hf.ne' (Nat.dvd_of_mem_primeFactors q.property)
  have hdiv (q : I) : (q : ℕ) ∣ modulus q := dvd_pow_self _ (hexp q).ne'
  have hmod (q : I) : modulus q ≠ 0 := pow_ne_zero _ (hp q).ne_zero
  have hprod : (∏ q : I, modulus q) = f := by
    dsimp [modulus, I]
    rw [Finset.prod_attach f.primeFactors (fun q : ℕ => q ^ f.factorization q)]
    exact Nat.factorization_prod_pow_eq_self hf.ne'
  have hcop : Pairwise (fun a b : I => Nat.Coprime (modulus a) (modulus b)) := by
    intro a b hab
    exact Nat.coprime_pow_primes _ _ (hp a) (hp b) (fun h => hab (Subtype.ext h))
  let eR : ZMod f ≃+* ∀ q : I, ZMod (modulus q) := by
    have e := ZMod.prodEquivPi modulus hcop
    rwa [hprod] at e
  let e : (ZMod f)ˣ ≃* ∀ q : I, (ZMod (modulus q))ˣ :=
    (Units.mapEquiv eR.toMulEquiv).trans MulEquiv.piUnits
  let r : ∀ q : I, (ZMod (modulus q))ˣ →* (ZMod (q : ℕ))ˣ :=
    fun q => ZMod.unitsMap (hdiv q)
  have hr (q : I) : Function.Surjective (r q) := by
    letI : NeZero (modulus q) := ⟨hmod q⟩
    exact ZMod.unitsMap_surjective (hdiv q)
  obtain ⟨a, ha, hχa⟩ := exists_compatible_residue_character (fun q : I => (q : ℕ))
    Subtype.coe_injective hp r hr e χ hχ
  refine ⟨a, hχa, ?_⟩
  intro q hq hqf hq2
  let i : I := ⟨q, Nat.mem_primeFactors.mpr ⟨hq, hqf, hf.ne'⟩⟩
  have hai := ha i hq2
  have hcoordinate : r i (e a i) = ZMod.unitsMap hqf a := by
    apply Units.ext
    let g : ZMod f →+* ZMod q :=
      (ZMod.castHom (hdiv i) (ZMod q)).comp
        ((Pi.evalRingHom (fun j : I => ZMod (modulus j)) i).comp eR.toRingHom)
    have heq : g = ZMod.castHom hqf (ZMod q) := RingHom.ext_zmod _ _
    exact congrArg (fun k : ZMod f →+* ZMod q => k (a : ZMod f)) heq
  rw [hcoordinate] at hai
  exact hai

/-- Positive integer representative, with the coprimality and avoidance
properties in the form used to construct the final progression. -/
theorem exists_compatible_dirichlet_integer
    (f : ℕ) (hf : 1 < f) (χ : (ZMod f)ˣ →* ℂˣ)
    (hχ : ∃ a : (ZMod f)ˣ, χ a ≠ 1) :
    ∃ u : ℕ, ∃ hu : u.Coprime f,
      0 < u ∧ u ≠ 1 ∧ χ (ZMod.unitOfCoprime u hu) ≠ 1 ∧
      ∀ (q : ℕ), q.Prime → q ∣ f → q ≠ 2 → ¬q ∣ u - 1 := by
  classical
  letI : NeZero f := ⟨by omega⟩
  obtain ⟨a, hχa, havoid⟩ := exists_compatible_dirichlet_residue f (by omega) χ hχ
  let u := (a : ZMod f).val
  have hu : u.Coprime f := ZMod.val_coe_unit_coprime a
  have hu0 : 0 < u := by
    by_contra h
    have hz : u = 0 := by omega
    have hf1 : f = 1 := by simpa [hz] using hu
    omega
  have hunit : ZMod.unitOfCoprime u hu = a := by
    apply Units.ext
    simp [ZMod.coe_unitOfCoprime, u]
  have hu1 : u ≠ 1 := by
    intro h
    have ha1 : a = 1 := by
      rw [← hunit]
      apply Units.ext
      simp [ZMod.coe_unitOfCoprime, h]
    exact hχa (by simp [ha1])
  refine ⟨u, hu, hu0, hu1, ?_, ?_⟩
  · simpa [hunit] using hχa
  · intro q hq hqf hq2 hdiv
    apply havoid q hq hqf hq2
    apply Units.ext
    change (ZMod.cast (a : ZMod f) : ZMod q) = 1
    rw [ZMod.cast_eq_val]
    change (u : ZMod q) = 1
    have hz : ((u - 1 : ℕ) : ZMod q) = 0 :=
      (ZMod.natCast_zmod_eq_zero_iff_dvd (u - 1) q).mpr hdiv
    rw [Nat.cast_sub (by omega : 1 ≤ u), Nat.cast_one] at hz
    exact sub_eq_zero.mp hz

end Cyclic

/-! ## Module: Progression -/

/-!
# Checking the local conditions of the fixed progression

The CRT and character-selection inputs provide an integral residue, its exact
power of two, and avoidance of 1 at odd primes dividing the modulus. This file
proves the quotient coprimality needed by the cofactor sieve and constructs the
`Progression` structure. In particular, quotient coprimality is not an input.
-/

namespace Cyclic

/-- Removing the exact power of two leaves a quotient coprime to `M / 2^k`,
provided no odd prime divisor of `M` divides `u - 1`. -/
theorem quotient_coprime_of_local_conditions {M u k : ℕ}
    (hcM : 2^k ∣ M) (hcu : 2^k ∣ u-1)
    (hodd : ((u-1)/2^k) % 2 = 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) :
    Nat.Coprime ((u-1)/2^k) (M/2^k) := by
  apply Nat.coprime_of_dvd
  intro q hq hqa hqb
  by_cases hq2 : q = 2
  · subst q
    have hz := Nat.mod_eq_zero_of_dvd hqa
    omega
  · exact havoid q hq hq2 (hqb.trans (Nat.div_dvd_of_dvd hcM))
      (hqa.trans (Nat.div_dvd_of_dvd hcu))

/-- Exact divisibility by `2^k` makes the quotient odd. -/
theorem quotient_mod_two_eq_one_of_exact_power {a k : ℕ}
    (hdiv : 2^k ∣ a) (hexact : ¬2^(k+1) ∣ a) : (a/2^k) % 2 = 1 := by
  have hlt := Nat.mod_lt (a/2^k) (by norm_num : 0 < 2)
  have hne : (a/2^k) % 2 ≠ 0 := by
    intro hz
    have hd : 2 ∣ a/2^k := Nat.dvd_of_mod_eq_zero hz
    have hm : 2^k * 2 ∣ a := (Nat.dvd_div_iff_mul_dvd hdiv).mp hd
    exact hexact (by simpa [pow_succ] using hm)
  omega

/-- Local data produce precisely the progression conditions used by the sieve. -/
def progressionOfLocalData (M u k : ℕ)
    (hM : 0 < M) (hcM : 2^k ∣ M) (h2cM : 2 * 2^k ∣ M)
    (hunit : Nat.Coprime u M) (hcu : 2^k ∣ u-1)
    (hodd : ((u-1)/2^k) % 2 = 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) : Progression where
  M := M
  u := u
  k := k
  M_pos := hM
  c_dvd_M := hcM
  even_quotient := (Nat.dvd_div_iff_mul_dvd hcM).mpr (by simpa [mul_comm] using h2cM)
  unit := hunit
  c_dvd_u_sub_one := hcu
  reduced_quotient := quotient_coprime_of_local_conditions hcM hcu hodd havoid

/-- An equivalent constructor stated using the exact power of two. -/
def progressionOfExactPower (M u k : ℕ)
    (hM : 0 < M) (hcM : 2^k ∣ M) (h2cM : 2 * 2^k ∣ M)
    (hunit : Nat.Coprime u M) (hcu : 2^k ∣ u-1) (hexact : ¬2^(k+1) ∣ u-1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1) : Progression :=
  progressionOfLocalData M u k hM hcM h2cM hunit hcu
    (quotient_mod_two_eq_one_of_exact_power hcu hexact) havoid

/-- A compatible nonidentity unit residue modulo an even modulus extends to a
sieve-admissible progression by increasing only the power of two in the modulus.
No further Chinese remainder argument is needed for this numerical step. -/
theorem exists_progression_of_even_modulus_residue {m u : ℕ}
    (hm : 0 < m) (heven : 2 ∣ m) (hunit : Nat.Coprime u m) (huone : u ≠ 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ m → ¬q ∣ u-1) :
    ∃ g : Progression, g.u = u ∧ m ∣ g.M := by
  have hm_two : 2 ≤ m := Nat.le_of_dvd hm heven
  have hupos : 0 < u := by
    by_contra h
    have hu : u = 0 := by omega
    subst u
    have hm_one : m = 1 := (Nat.coprime_zero_left m).mp hunit
    omega
  have hsub : u-1 ≠ 0 := by omega
  let k := padicValNat 2 (u-1)
  let M := m * 2^(k+1)
  have hM : 0 < M := Nat.mul_pos hm (pow_pos (by norm_num) _)
  have hcu : 2^k ∣ u-1 := pow_padicValNat_dvd
  have hexact : ¬2^(k+1) ∣ u-1 := pow_succ_padicValNat_not_dvd hsub
  have hcM : 2^k ∣ M :=
    dvd_mul_of_dvd_right (pow_dvd_pow 2 (Nat.le_succ k)) m
  have h2cM : 2 * 2^k ∣ M := by
    have heq : 2 * 2^k = 2^(k+1) := by rw [pow_succ, mul_comm]
    rw [heq]
    exact Nat.dvd_mul_left _ _
  have hu_two : Nat.Coprime u 2 := Nat.Coprime.of_dvd_right heven hunit
  have huM : Nat.Coprime u M := hunit.mul_right (hu_two.pow_right (k+1))
  have havoidM : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → ¬q ∣ u-1 := by
    intro q hq hq_two hqM
    rcases hq.dvd_mul.mp hqM with hqm | hqpow
    · exact havoid q hq hq_two hqm
    · exact (hq_two (Nat.prime_eq_prime_of_dvd_pow hq Nat.prime_two hqpow)).elim
  refine ⟨progressionOfExactPower M u k hM hcM h2cM huM hcu hexact havoidM, rfl, ?_⟩
  exact Nat.dvd_mul_right m _

end Cyclic

/-! ## Module: ArithmeticInputs -/

/-!
# Classical character input and the proved progression construction

The standard 2-division-field quotient and Kronecker--Weber theorem supply a
nontrivial character. Its modulus may contain 2 and all bad primes. Starting
from that precise input, the full progression construction is proved here;
progression existence is not assumed in the final theorem.
-/

namespace Cyclic

/-- Standard arithmetic character associated with a nontrivial abelian
quotient of the 2-division field. The bad primes are absorbed in the modulus. -/
structure TwoDivisionCharacter (D : ReductionData) where
  modulus : ℕ
  modulus_pos : 0 < modulus
  even_modulus : 2 ∣ modulus
  character : (ZMod modulus)ˣ →* ℂˣ
  nontrivial : ∃ a : (ZMod modulus)ˣ, character a ≠ 1
  good_of_unit : ∀ p : ℕ, p.Prime → IsUnit (p : ZMod modulus) → D.good p
  split_character_one : ∀ p : ℕ, p.Prime → ∀ a : (ZMod modulus)ˣ,
    (p : ZMod modulus) = (a : ZMod modulus) → D.split 2 p → character a = 1

/-- The standard cyclicity/Frobenius, Weil pairing, and Hasse consequences. -/
def CyclicityCriterion (D : ReductionData) : Prop :=
  ∀ p, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p →
    ∃ ell, ell.Prime ∧ D.split ell p ∧ ell ∣ p-1 ∧
      (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1

theorem progression_from_two_division_character
    (D : ReductionData) (char : TwoDivisionCharacter D)
    (criterion : CyclicityCriterion D) :
    ∃ g : Progression, ArithmeticFacts D g := by
  have hm2 : 2 ≤ char.modulus := Nat.le_of_dvd char.modulus_pos char.even_modulus
  rcases exists_compatible_dirichlet_integer char.modulus (by omega)
    char.character char.nontrivial with ⟨u,hu,_,huone,hχ,havoid⟩
  rcases exists_progression_of_even_modulus_residue char.modulus_pos
    char.even_modulus hu huone (fun q hq hq2 hqm => havoid q hq hqm hq2) with
    ⟨g,hgu,hmM⟩
  let a := ZMod.unitOfCoprime u hu
  have hresidue (p : ℕ) (hp : InProgression g p) :
      (p : ZMod char.modulus) = (a : ZMod char.modulus) := by
    have hmod : p ≡ g.u [MOD g.M] := hp
    have hsmall := hmod.of_dvd hmM
    rw [hgu] at hsmall
    simpa [a, ZMod.coe_unitOfCoprime] using
      (ZMod.natCast_eq_natCast_iff p u char.modulus).mpr hsmall
  refine ⟨g, ?_⟩
  constructor
  · intro p hp hprog
    apply char.good_of_unit p hp
    rw [hresidue p hprog]
    exact a.isUnit
  · intro p hp hprog hsplit
    exact hχ (char.split_character_one p hp a (hresidue p hprog) hsplit)
  · exact criterion

end Cyclic

/-! ## Module: Obstruction -/

/-!
# Confining cyclicity obstructions to the cofactor

This module proves the elementary new deduction in Section 5 of the manuscript.
The elliptic-curve input is supplied as explicit divisibility and Hasse bounds;
the short-obstruction conclusion is not an assumption.
-/

namespace Cyclic

/-- A prime divisor of `p - 1 = 2^k * r * Q`, other than 2 and `Q`, divides `r`. -/
theorem obstruction_dvd_cofactor {p k r Q ell : ℕ}
    (hell : Nat.Prime ell) (hQ : Nat.Prime Q)
    (hne_two : ell ≠ 2) (hne_Q : ell ≠ Q)
    (hfactor : p - 1 = 2 ^ k * r * Q) (hdiv : ell ∣ p - 1) : ell ∣ r := by
  rw [hfactor] at hdiv
  rcases hell.dvd_mul.mp hdiv with hleft | hright
  · rcases hell.dvd_mul.mp hleft with htwo | hr
    · exact (hne_two (Nat.prime_eq_prime_of_dvd_pow hell Nat.prime_two htwo)).elim
    · exact hr
  · exact (hne_Q ((Nat.prime_dvd_prime_iff_eq hell hQ).mp hright)).elim

/-- Hasse's upper bound excludes the distinguished prime factor. -/
theorem obstruction_ne_large_prime {p Q ell : ℕ} {x : ℝ}
    (hp : (p : ℝ) ≤ 2 * x)
    (hhasse : (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1)
    (hlarge : Real.sqrt (2 * x) + 1 < (Q : ℝ)) : ell ≠ Q := by
  intro heq
  have hsqrt := Real.sqrt_le_sqrt hp
  have hu : (ell : ℝ) ≤ Real.sqrt (2 * x) + 1 :=
    hhasse.trans (add_le_add_right hsqrt 1)
  rw [heq] at hu
  exact (not_lt_of_ge hu) hlarge

/-- Every obstruction for a candidate lies above the roughness threshold and
below the cofactor bound. No distribution assumption enters this theorem. -/
theorem short_obstruction {p k r Q ell : ℕ} {x Y z : ℝ}
    (hp_two : 2 ≤ p) (hp : (p : ℝ) ≤ 2 * x)
    (hell : Nat.Prime ell) (hQ : Nat.Prime Q) (hne_two : ell ≠ 2)
    (hfactor : p - 1 = 2 ^ k * r * Q) (hdiv : ell ∣ p - 1)
    (hhasse : (ell : ℝ) ≤ Real.sqrt (p : ℝ) + 1)
    (hlarge : Real.sqrt (2 * x) + 1 < (Q : ℝ))
    (hrough : ∀ q : ℕ, Nat.Prime q → q ∣ r → Y < (q : ℝ))
    (hrbound : (r : ℝ) ≤ z) : Y < (ell : ℝ) ∧ (ell : ℝ) ≤ z := by
  have hdvd : ell ∣ r := obstruction_dvd_cofactor hell hQ hne_two
    (obstruction_ne_large_prime hp hhasse hlarge) hfactor hdiv
  have hrpos : 0 < r := by
    by_contra h
    have hrzero : r = 0 := Nat.eq_zero_of_not_pos h
    simp only [hrzero, mul_zero, zero_mul] at hfactor
    omega
  have hle : (ell : ℝ) ≤ (r : ℝ) := by
    exact_mod_cast Nat.le_of_dvd hrpos hdvd
  exact ⟨hrough ell hell hdvd, hle.trans hrbound⟩

open Filter Topology

/-- The distinguished factor `Q > x^(9/10)` eventually exceeds every Hasse
obstruction for primes in `(x,2*x)`. This is proved from real-power limits. -/
theorem eventually_large_factor_dominates_hasse :
    ∀ᶠ x : ℝ in atTop, Real.sqrt (2 * x) + 1 < x ^ (9 / 10 : ℝ) := by
  have hlim : Tendsto
      (fun x : ℝ => Real.sqrt 2 * x ^ (-(2 / 5 : ℝ)) + x ^ (-(9 / 10 : ℝ)))
      atTop (𝓝 0) := by
    simpa using ((tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 2 / 5)).const_mul
      (Real.sqrt 2)).add (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 9 / 10))
  filter_upwards [hlim.eventually (Iio_mem_nhds (by norm_num : (0 : ℝ) < 1)),
    eventually_gt_atTop (0 : ℝ)] with x hx hxpos
  have hpow₁ : x ^ (-(2 / 5 : ℝ)) * x ^ (9 / 10 : ℝ) = x ^ (1 / 2 : ℝ) := by
    rw [← Real.rpow_add hxpos]
    norm_num
  have hpow₂ : x ^ (-(9 / 10 : ℝ)) * x ^ (9 / 10 : ℝ) = 1 := by
    rw [← Real.rpow_add hxpos]
    norm_num
  calc
    Real.sqrt (2 * x) + 1 =
        (Real.sqrt 2 * x ^ (-(2 / 5 : ℝ)) + x ^ (-(9 / 10 : ℝ))) *
          x ^ (9 / 10 : ℝ) := by
      rw [add_mul, mul_assoc, hpow₁, hpow₂, ← Real.sqrt_eq_rpow,
        ← Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 2)]
    _ < 1 * x ^ (9 / 10 : ℝ) :=
      mul_lt_mul_of_pos_right hx (Real.rpow_pos_of_pos hxpos _)
    _ = x ^ (9 / 10 : ℝ) := one_mul _

end Cyclic

/-! ## Module: Parameters -/

/-!
# Uniform parameter choice for cyclic reductions

This file proves the analytic parameter optimization in Section 5 of the
positive-proportion manuscript. There are no number-theoretic assumptions here.
The decay of the error term is proved from the real-power limit in mathlib.
-/

noncomputable section

open Filter Topology

namespace Cyclic

/-- The exponent supplied by the zero-free strip becomes strictly negative. -/
theorem error_eventually_small {α N t : ℝ} (hα : α < 1) (hN : 0 < N)
    (ht : 0 < t) (C : ℝ) :
    ∀ᶠ x : ℝ in atTop, C * x ^ (-1 / N + α / N) < t := by
  have hδ : 0 < (1 - α) / N := div_pos (sub_pos.mpr hα) hN
  have hexp : -1 / N + α / N = -((1 - α) / N) := by ring
  have hlim : Tendsto (fun x : ℝ => C * x ^ (-1 / N + α / N)) atTop (𝓝 0) := by
    simpa only [hexp, mul_zero] using (tendsto_rpow_neg_atTop hδ).const_mul C
  exact hlim.eventually_lt_const ht

/-- The logarithmic cost is bounded by a constant independent of `N`. -/
theorem log_scale_bound {B N : ℝ} (hB : 2 ≤ B) (hN : 2 ≤ N) :
    Real.log (B * N) ≤ (1 + Real.log B / Real.log 2) * Real.log N := by
  have hBpos : 0 < B := by linarith
  have hNpos : 0 < N := by linarith
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
  have hlogN : Real.log (2 : ℝ) ≤ Real.log N := Real.log_le_log (by norm_num) hN
  have hmul := mul_le_mul_of_nonneg_left hlogN
    (div_nonneg hlogB (le_of_lt hlog2))
  have hcancel : (Real.log B / Real.log 2) * Real.log 2 = Real.log B := by
    field_simp [ne_of_gt hlog2]
  rw [hcancel] at hmul
  rw [Real.log_mul (ne_of_gt hBpos) (ne_of_gt hNpos)]
  nlinarith

/-- Concrete parameters give the manuscript's uniform `1 / (N log N)` bound. -/
theorem parameter_core {A α B C₁ C₂ N : ℝ}
    (hA : 0 < A) (hαpos : 0 < α) (hαone : α < 1)
    (hB : 2 ≤ B) (hC : C₁ / B ≤ A * α / 4) (hN : 2 ≤ N) :
    ∀ᶠ x : ℝ in atTop,
      (A * α / (2 * (1 + Real.log B / Real.log 2))) / (N * Real.log N) ≤
        A * (α / N) / Real.log (B * N) -
          C₁ / ((B * N) * Real.log (B * N)) -
          C₂ * x ^ (-1 / N + α / N) := by
  have hBpos : 0 < B := by linarith
  have hNpos : 0 < N := by linarith
  have hBN : 1 < B * N := by nlinarith
  have hlogBN : 0 < Real.log (B * N) := Real.log_pos hBN
  have hlogN : 0 < Real.log N := Real.log_pos (by linarith)
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
  let K : ℝ := 1 + Real.log B / Real.log 2
  have hK : 0 < K := by dsimp [K]; positivity
  let m : ℝ := A * α / (N * Real.log (B * N))
  have hm : 0 < m := by dsimp [m]; positivity
  have hsmall : C₁ / ((B * N) * Real.log (B * N)) ≤ m / 4 := by
    have h := div_le_div_of_nonneg_right hC
      (le_of_lt (mul_pos hNpos hlogBN))
    convert h using 1 <;> dsimp [m] <;> ring
  have hscale := log_scale_bound hB hN
  have hden : N * Real.log (B * N) ≤ N * (K * Real.log N) := by
    exact mul_le_mul_of_nonneg_left hscale (le_of_lt hNpos)
  have hmain : (A * α / (2 * K)) / (N * Real.log N) ≤ m / 2 := by
    have h := div_le_div_of_nonneg_left (by positivity : 0 ≤ A * α / 2)
      (mul_pos hNpos hlogBN) hden
    convert h using 1 <;> dsimp [m] <;>
      field_simp [ne_of_gt hK, ne_of_gt hNpos, ne_of_gt hlogN, ne_of_gt hlogBN] <;> ring
  have hfirst : A * (α / N) / Real.log (B * N) = m := by
    dsimp [m]
    ring
  filter_upwards [error_eventually_small hαone hNpos (by positivity : 0 < m / 4) C₂]
    with x hx
  change (A * α / (2 * K)) / (N * Real.log N) ≤ _
  rw [hfirst]
  linarith

/-- Uniformity in the zero-free width: the constant is chosen before `N`.

The output parameters are fixed before the eventual limit in `x` is taken.
-/
theorem exists_uniform_parameters {A ε₀ Y₀ C₁ C₂ : ℝ}
    (hA : 0 < A) (hε₀ : 0 < ε₀) :
    ∃ d : ℝ, 0 < d ∧ ∀ N : ℝ, 2 ≤ N →
      ∃ ε Y : ℝ, 0 < ε ∧ ε < ε₀ ∧ Y₀ ≤ Y ∧ 3 ≤ Y ∧
        ∀ᶠ x : ℝ in atTop,
          d / (N * Real.log N) ≤
            A * ε / Real.log Y - C₁ / (Y * Real.log Y) -
              C₂ * x ^ (-1 / N + ε) := by
  let α : ℝ := min (1 / 2) ε₀
  have hαpos : 0 < α := lt_min (by norm_num) hε₀
  have hαhalf : α ≤ 1 / 2 := min_le_left _ _
  have hαε : α ≤ ε₀ := min_le_right _ _
  have hαone : α < 1 := by linarith
  let B : ℝ := max 2 (max Y₀ (4 * C₁ / (A * α)))
  have hB : 2 ≤ B := le_max_left _ _
  have hBY : Y₀ ≤ B := (le_max_left _ _).trans (le_max_right _ _)
  have hBC : 4 * C₁ / (A * α) ≤ B :=
    (le_max_right _ _).trans (le_max_right _ _)
  have hBpos : 0 < B := by linarith
  have hC : C₁ / B ≤ A * α / 4 := by
    have hmul : 4 * C₁ ≤ B * (A * α) := (div_le_iff₀ (mul_pos hA hαpos)).mp hBC
    apply (div_le_iff₀ hBpos).2
    nlinarith
  let d : ℝ := A * α / (2 * (1 + Real.log B / Real.log 2))
  have hd : 0 < d := by
    have hlogB : 0 ≤ Real.log B := Real.log_nonneg (by linarith)
    have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
    dsimp [d]
    positivity
  refine ⟨d, hd, ?_⟩
  intro N hN
  have hNpos : 0 < N := by linarith
  refine ⟨α / N, B * N, div_pos hαpos hNpos, ?_, ?_, ?_, ?_⟩
  · apply (div_lt_iff₀ hNpos).2
    nlinarith
  · have : B ≤ B * N := by nlinarith
    exact hBY.trans this
  · nlinarith
  · exact parameter_core hA hαpos hαone hB hC hN

end Cyclic

/-! ## Module: Density -/

/-!
# From dyadic prime counts to a lower proportion

This module contains no analytic black box.  The prime number theorem is an
explicit hypothesis on the counting function `P`; the passage from a dyadic
lower bound to a lower proportion, including the factor `1/2`, is proved here.
-/

open Filter
open scoped Topology

namespace Cyclic

/-- PNT itself supplies eventual positivity of the prime-counting function. -/
theorem eventually_positive_of_pnt
    (P : ℝ → ℝ)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1)) :
    ∀ᶠ X : ℝ in atTop, 0 < P X := by
  have hratio := hPNT.eventually (lt_mem_nhds (by norm_num : (0 : ℝ) < 1))
  filter_upwards [hratio, eventually_ge_atTop (4 : ℝ)] with X hratio hX
  have hscale : 0 < X / Real.log X :=
    div_pos (by linarith) (Real.log_pos (by linarith))
  exact (div_pos_iff_of_pos_right hscale).1 hratio

/-- The dyadic prime scale dominates half the full prime scale. -/
theorem half_prime_scale {X : ℝ} (hX : 4 ≤ X) :
    (X / Real.log X) / 2 ≤ (X / 2) / Real.log (X / 2) := by
  have hhalf : 1 < X / 2 := by linarith
  have hXpos : 0 < X := by linarith
  have hloghalf : 0 < Real.log (X / 2) := Real.log_pos hhalf
  have hlogX : 0 < Real.log X := Real.log_pos (by linarith)
  have hlogs : Real.log (X / 2) ≤ Real.log X :=
    Real.log_le_log (by linarith) (by linarith)
  have hdiv : (X / 2) / Real.log X ≤ (X / 2) / Real.log (X / 2) :=
    div_le_div_of_nonneg_left (by linarith) hloghalf hlogs
  convert hdiv using 1
  ring

/-- A dyadic lower bound implies the matching global lower bound with factor
`1/2`.  No monotonicity hypothesis on `C` is needed. -/
theorem global_bound_of_dyadic
    (C : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop, (k / 2) * (X / Real.log X) ≤ C X := by
  have hhalf : Tendsto (fun X : ℝ => X / 2) atTop atTop :=
    (tendsto_div_const_atTop_of_pos (by norm_num : (0 : ℝ) < 2)).2 tendsto_id
  filter_upwards [hhalf.eventually hdyadic, eventually_ge_atTop (4 : ℝ)] with X hd hX
  have hscale := mul_le_mul_of_nonneg_left (half_prime_scale hX) hk
  have hnonneg := hC (X / 2)
  have htwice : 2 * (X / 2) = X := by ring
  rw [htwice] at hd
  nlinarith

/-- The comparison function arising from PNT tends to the expected constant. -/
theorem density_comparison_tendsto
    (P : ℝ → ℝ) (k : ℝ)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1)) :
    Tendsto (fun X : ℝ => (k / 2) / (P X / (X / Real.log X)))
      atTop (𝓝 (k / 2)) := by
  simpa using
    (tendsto_const_nhds : Tendsto (fun _ : ℝ => k / 2) atTop (𝓝 (k / 2))).div
      hPNT (by norm_num : (1 : ℝ) ≠ 0)

/-- PNT and eventual positivity convert the dyadic bound into an eventual
comparison with a function tending to `k/2`. -/
theorem eventually_density_comparison
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop,
      (k / 2) / (P X / (X / Real.log X)) ≤ C X / P X := by
  filter_upwards [global_bound_of_dyadic C k hk hC hdyadic,
    hP] with X hglobal hPX
  have hdiv := div_le_div_of_nonneg_right hglobal (le_of_lt hPX)
  convert hdiv using 1
  simp [div_eq_mul_inv, mul_assoc, mul_comm, mul_left_comm]

/-- Exact lower-liminf bound.  `C ≤ P` is the natural hypothesis that the
counted primes form a subset of all primes; it also ensures the real liminf
is finite. -/
theorem lower_proportion_of_dyadic
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 ≤ k)
    (hC : ∀ X, 0 ≤ C X)
    (hsubset : ∀ᶠ X : ℝ in atTop, C X ≤ P X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1))
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    k / 2 ≤ Filter.liminf (fun X : ℝ => C X / P X) atTop := by
  have hlim := density_comparison_tendsto P k hPNT
  have hupper : ∀ᶠ X : ℝ in atTop, C X / P X ≤ 1 := by
    filter_upwards [hsubset, hP] with X hsub hpos
    exact (div_le_one hpos).2 hsub
  have hcomp := eventually_density_comparison C P k hk hC hP hdyadic
  rw [← hlim.liminf_eq]
  exact Filter.liminf_le_liminf hcomp hlim.isBoundedUnder_ge
    (Filter.isCoboundedUnder_ge_of_eventually_le atTop hupper)

/-- A strictly positive eventual lower proportion, convenient when only
positivity (rather than the exact `1/2` factor) is required. -/
theorem eventually_positive_proportion_of_dyadic
    (C P : ℝ → ℝ) (k : ℝ) (hk : 0 < k)
    (hC : ∀ X, 0 ≤ C X)
    (hP : ∀ᶠ X : ℝ in atTop, 0 < P X)
    (hPNT : Tendsto (fun X : ℝ => P X / (X / Real.log X))
      atTop (𝓝 1))
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      k * (x / Real.log x) ≤ C (2 * x) - C x) :
    ∀ᶠ X : ℝ in atTop, k / 4 ≤ C X / P X := by
  have hlim := density_comparison_tendsto P k hPNT
  have hlt : k / 4 < k / 2 := by linarith
  have hevent := hlim.eventually (lt_mem_nhds hlt)
  filter_upwards [hevent,
    eventually_density_comparison C P k (le_of_lt hk) hC hP hdyadic]
    with X hlo hcomp
  exact le_trans (le_of_lt hlo) hcomp

end Cyclic

/-! ## Module: EllipticModel -/

/-!
# Concrete elliptic-curve predicates

The combinatorial development can be instantiated with an integral Weierstrass
model. These predicates refer to mathlib's actual additive group of nonsingular
points. The comparison with division fields and specialization of rational
torsion remain separately named arithmetic hypotheses of the main adapter.
-/

noncomputable section

namespace Cyclic.EllipticModel

/-- The rational curve defined by an integral Weierstrass equation. -/
def rationalCurve (W : WeierstrassCurve ℤ) : WeierstrassCurve ℚ :=
  W.map (Int.castRingHom ℚ)

/-- Reduction of an integral Weierstrass equation modulo `p`. -/
def reduction (W : WeierstrassCurve ℤ) (p : ℕ) : WeierstrassCurve (ZMod p) :=
  W.map (Int.castRingHom (ZMod p))

def RationalElliptic (W : WeierstrassCurve ℤ) : Prop :=
  (rationalCurve W).IsElliptic

/-- Two distinct nonzero rational points of order two generate full rational
2-torsion for an elliptic curve over `ℚ`. -/
def FullRationalTwoTorsion (W : WeierstrassCurve ℤ) : Prop :=
  ∃ P Q : (rationalCurve W).toAffine.Point,
    P ≠ 0 ∧ Q ≠ 0 ∧ P ≠ Q ∧ (2 : ℕ) • P = 0 ∧ (2 : ℕ) • Q = 0

def Admissible (W : WeierstrassCurve ℤ) : Prop :=
  RationalElliptic W ∧ ¬FullRationalTwoTorsion W

/-- Good reduction for this integral equation. Prime-counting sets separately
impose primality. A nonminimal equation can omit finitely many additional primes. -/
def GoodReduction (W : WeierstrassCurve ℤ) (p : ℕ) : Prop :=
  (reduction W p).IsElliptic

/-- Cyclicity of the actual point group over the prime field `ZMod p`. -/
def CyclicReduction (W : WeierstrassCurve ℤ) (p : ℕ) : Prop :=
  ∃ hp : Nat.Prime p,
    letI : Fact p.Prime := ⟨hp⟩
    IsAddCyclic (reduction W p).toAffine.Point

theorem cyclicReduction_iff (W : WeierstrassCurve ℤ) (p : ℕ) [Fact p.Prime] :
    CyclicReduction W p ↔ IsAddCyclic (reduction W p).toAffine.Point := by
  constructor
  · rintro ⟨hp, h⟩
    exact h
  · intro h
    exact ⟨Fact.out, h⟩

/-- Encoding a point by the point at infinity or its two affine coordinates. -/
def pointCoordinates {F : Type*} [Field F] (W : WeierstrassCurve.Affine F) :
    W.Point → Option (F × F)
  | .zero => none
  | @WeierstrassCurve.Affine.Point.some _ _ _ x y _ => some (x, y)

theorem pointCoordinates_injective {F : Type*} [Field F]
    (W : WeierstrassCurve.Affine F) : Function.Injective (pointCoordinates W) := by
  intro P Q h
  cases P with
  | zero =>
      cases Q with
      | zero => rfl
      | some hQ => simp [pointCoordinates] at h
  | @some x y hP =>
      cases Q with
      | zero => simp [pointCoordinates] at h
      | @some u v hQ =>
          simp only [pointCoordinates, Option.some.injEq, Prod.mk.injEq] at h
          rcases h with ⟨rfl, rfl⟩
          rfl

instance finitePoint {F : Type*} [Field F] [Finite F]
    (W : WeierstrassCurve.Affine F) : Finite W.Point := by
  classical
  letI : Fintype F := Fintype.ofFinite F
  exact Finite.of_injective (pointCoordinates W) (pointCoordinates_injective W)

/-- A finite cyclic group cannot contain two distinct nonzero points killed by 2. -/
theorem not_isAddCyclic_of_two_torsion {G : Type*} [AddGroup G] [Finite G]
    {P Q : G} (hP : P ≠ 0) (hQ : Q ≠ 0) (hPQ : P ≠ Q)
    (hPtwo : (2 : ℕ) • P = 0) (hQtwo : (2 : ℕ) • Q = 0) :
    ¬IsAddCyclic G := by
  classical
  letI : Fintype G := Fintype.ofFinite G
  intro hcyclic
  letI : IsAddCyclic G := hcyclic
  have hbound : ({a : G | (2 : ℕ) • a = 0} : Finset G).card ≤ 2 :=
    IsAddCyclic.card_nsmul_eq_zero_le (by norm_num)
  have hsub : ({0, P, Q} : Finset G) ⊆ ({a : G | (2 : ℕ) • a = 0} : Finset G) := by
    intro a ha
    simp only [Finset.mem_insert, Finset.mem_singleton] at ha
    rcases ha with rfl | rfl | rfl
    · simp
    · simpa using hPtwo
    · simpa using hQtwo
  have hcard : ({0, P, Q} : Finset G).card = 3 := by
    simp [hP, hQ, hPQ, Ne.symm hP, Ne.symm hQ]
  have := Finset.card_le_card hsub
  omega

/-- Full 2-torsion in a reduction prevents its actual point group from being cyclic. -/
theorem not_cyclicReduction_of_two_torsion (W : WeierstrassCurve ℤ) (p : ℕ)
    [Fact p.Prime] {P Q : (reduction W p).toAffine.Point}
    (hP : P ≠ 0) (hQ : Q ≠ 0) (hPQ : P ≠ Q)
    (hPtwo : (2 : ℕ) • P = 0) (hQtwo : (2 : ℕ) • Q = 0) :
    ¬CyclicReduction W p := by
  rw [cyclicReduction_iff]
  exact not_isAddCyclic_of_two_torsion hP hQ hPQ hPtwo hQtwo

end Cyclic.EllipticModel

/-! ## Module: Necessity -/

/-!
# Necessity of excluding full rational two-torsion

The arithmetic specialization of rational two-torsion is an explicitly
separate input.  Once odd good reductions are noncyclic, this module proves
that the cyclic-prime count is at most one and that its proportion tends to
zero.  The convergence uses the stated PNT input; it is not assumed.
-/

noncomputable section
open Filter
open scoped Topology

namespace Cyclic

/-- If every good reduction at a prime at least three is noncyclic, only the
prime two can contribute to the cyclic-prime count. -/
theorem cyclicCount_le_one_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (X : ℝ) : cyclicCount D X ≤ 1 := by
  classical
  have hsub : primeUpTo (fun p => D.good p ∧ D.cyclic p) X ⊆ ({2} : Finset ℕ) := by
    intro p hp
    rcases mem_primeUpTo.mp hp with ⟨hprime, _, hgood, hcyclic⟩
    have hp2 : p = 2 := by
      by_contra hne
      have hp3 : 3 ≤ p := by have := hprime.two_le; omega
      exact hodd p hprime hp3 hgood hcyclic
    simpa using hp2
  have hcard : (primeUpTo (fun p => D.good p ∧ D.cyclic p) X).card ≤ 1 := by
    simpa using Finset.card_le_card hsub
  unfold cyclicCount
  exact_mod_cast hcard

/-- PNT implies that the reciprocal prime count tends to zero. -/
theorem inverse_primeCount_tendsto_zero (hPNT : PrimeNumberTheorem) :
    Tendsto (fun X : ℝ => 1 / primeCount X) atTop (𝓝 0) := by
  have hlog : Tendsto (fun X : ℝ => Real.log X / X) atTop (𝓝 0) := by
    simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
  have hratio : Tendsto
      (fun X : ℝ => (Real.log X / X) / (primeCount X / (X / Real.log X)))
      atTop (𝓝 0) := by
    simpa using hlog.div hPNT (by norm_num : (1 : ℝ) ≠ 0)
  apply hratio.congr'
  filter_upwards [eventually_ge_atTop (4 : ℝ),
    eventually_positive_of_pnt primeCount hPNT] with X hX hP
  have hXne : X ≠ 0 := by linarith
  have hlogne : Real.log X ≠ 0 := ne_of_gt (Real.log_pos (by linarith))
  field_simp [hXne, hlogne, ne_of_gt hP]
  ring

/-- A count bounded by one has zero proportion among primes. -/
theorem cyclic_proportion_tendsto_zero_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (hPNT : PrimeNumberTheorem) :
    Tendsto (fun X : ℝ => cyclicCount D X / primeCount X) atTop (𝓝 0) := by
  have hP := eventually_positive_of_pnt primeCount hPNT
  apply squeeze_zero' _ _ (inverse_primeCount_tendsto_zero hPNT)
  · filter_upwards [hP] with X hPX
    exact div_nonneg (cyclicCount_nonneg D X) hPX.le
  · filter_upwards [hP] with X hPX
    exact div_le_div_of_nonneg_right (cyclicCount_le_one_of_odd_noncyclic D hodd X) hPX.le

/-- In particular the lower proportion is zero. -/
theorem cyclic_liminf_eq_zero_of_odd_noncyclic
    (D : ReductionData)
    (hodd : ∀ p : ℕ, p.Prime → 3 ≤ p → D.good p → ¬ D.cyclic p)
    (hPNT : PrimeNumberTheorem) :
    Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop = 0 :=
  (cyclic_proportion_tendsto_zero_of_odd_noncyclic D hodd hPNT).liminf_eq

end Cyclic

/-! ## Module: Splitting -/

/-!
# Positive prime-ideal sums and completely split primes

The input `t` is the nonnegative zero-error factor (later `x ^ (1 - 1/N)`).
The explicit formula, the arithmetic contribution of a completely split
prime, and the degree/root-discriminant estimates are explicit hypotheses.
The division by the degree and the finite summation are proved here.
-/

namespace Cyclic

open scoped BigOperators

/-- Dividing a positive prime-ideal bound by the degree leaves only the root
discriminant in the error term. The constants do not depend on `t`. -/
theorem split_individual_bound
    {b n d psi ell x t F a K : ℝ}
    (hn : 0 < n) (hell : 0 < ell) (hx : 0 ≤ x)
    (hlog : 0 < Real.log x) (ht : 0 ≤ t)
    (hF : 0 ≤ F) (ha : 0 < a)
    (hcontrib : b * n * Real.log x ≤ psi)
    (hexplicit : psi ≤ F * (x + t * (d + n)))
    (hdegree : a * ell ^ 2 ≤ n)
    (hroot : d + n ≤ K * n * Real.log (2 * ell)) :
    b ≤ (F / a) * x / (ell ^ 2 * Real.log x) +
      (F * K) * t * Real.log (2 * ell) / Real.log x := by
  have hupper : b * n * Real.log x ≤
      F * (x + t * (K * n * Real.log (2 * ell))) := by
    calc
      b * n * Real.log x ≤ psi := hcontrib
      _ ≤ F * (x + t * (d + n)) := hexplicit
      _ ≤ F * (x + t * (K * n * Real.log (2 * ell))) :=
        mul_le_mul_of_nonneg_left
          (add_le_add_left (mul_le_mul_of_nonneg_left hroot ht) x) hF
  have hdivide : b ≤ F * x / (n * Real.log x) +
      (F * K) * t * Real.log (2 * ell) / Real.log x := by
    calc
      b ≤ F * (x + t * (K * n * Real.log (2 * ell))) /
          (n * Real.log x) := by
        apply (le_div_iff₀ (mul_pos hn hlog)).2
        simpa only [mul_assoc] using hupper
      _ = F * x / (n * Real.log x) +
          (F * K) * t * Real.log (2 * ell) / Real.log x := by
        field_simp [ne_of_gt hn, ne_of_gt hlog]
        ring
  have hmain : F * x / (n * Real.log x) ≤
      (F / a) * x / (ell ^ 2 * Real.log x) := by
    calc
      F * x / (n * Real.log x) ≤
          F * x / ((a * ell ^ 2) * Real.log x) := by
        exact div_le_div_of_nonneg_left (mul_nonneg hF hx)
          (mul_pos (mul_pos ha (sq_pos_of_pos hell)) hlog)
          (mul_le_mul_of_nonneg_right hdegree hlog.le)
      _ = (F / a) * x / (ell ^ 2 * Real.log x) := by
        simp only [div_eq_mul_inv, mul_inv_rev]
        ring
  exact hdivide.trans (add_le_add_right hmain _)

/-- Summing the individual bounds uses only two elementary prime sums. -/
theorem split_sum_bound
    (S : Finset ℕ) (b : ℕ → ℝ)
    {x t U V H J Y z : ℝ}
    (hx : 0 ≤ x) (hlog : 0 < Real.log x) (ht : 0 ≤ t)
    (hU : 0 ≤ U) (hV : 0 ≤ V)
    (hindividual : ∀ ell ∈ S,
      b ell ≤ U * x / ((ell : ℝ) ^ 2 * Real.log x) +
        V * t * Real.log (2 * (ell : ℝ)) / Real.log x)
    (hreciprocal : (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y))
    (hchebyshev : (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) ≤ J * z) :
    (∑ ell ∈ S, b ell) ≤
      (U * H) * x / (Y * Real.log Y * Real.log x) +
        (V * J) * t * z / Real.log x := by
  have hmain_nonneg : 0 ≤ U * x / Real.log x :=
    div_nonneg (mul_nonneg hU hx) hlog.le
  have herr_nonneg : 0 ≤ V * t / Real.log x :=
    div_nonneg (mul_nonneg hV ht) hlog.le
  calc
    (∑ ell ∈ S, b ell) ≤ ∑ ell ∈ S,
        (U * x / ((ell : ℝ) ^ 2 * Real.log x) +
          V * t * Real.log (2 * (ell : ℝ)) / Real.log x) :=
      Finset.sum_le_sum hindividual
    _ = (U * x / Real.log x) *
          (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) +
        (V * t / Real.log x) *
          (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) := by
      rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
      congr 1 <;> apply Finset.sum_congr rfl <;> intro ell hell
      · simp only [div_eq_mul_inv, mul_inv_rev]
        ring
      · ring
    _ ≤ (U * x / Real.log x) * (H / (Y * Real.log Y)) +
        (V * t / Real.log x) * (J * z) := by
      exact add_le_add
        (mul_le_mul_of_nonneg_left hreciprocal hmain_nonneg)
        (mul_le_mul_of_nonneg_left hchebyshev herr_nonneg)
    _ = (U * H) * x / (Y * Real.log Y * Real.log x) +
        (V * J) * t * z / Real.log x := by
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

/-- The normalized form used when subtracting obstructions from candidates.
Only the error factor contains `N`; the displayed constants remain uniform. -/
theorem split_sum_normalized
    (S : Finset ℕ) (b : ℕ → ℝ)
    {x N ε U V H J Y : ℝ}
    (hx : 1 < x) (hU : 0 ≤ U) (hV : 0 ≤ V)
    (hindividual : ∀ ell ∈ S,
      b ell ≤ U * x / ((ell : ℝ) ^ 2 * Real.log x) +
        V * x ^ (1 - 1 / N) * Real.log (2 * (ell : ℝ)) / Real.log x)
    (hreciprocal : (∑ ell ∈ S, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y))
    (hchebyshev : (∑ ell ∈ S, Real.log (2 * (ell : ℝ))) ≤ J * x ^ ε) :
    (∑ ell ∈ S, b ell) ≤
      (U * H / (Y * Real.log Y) + V * J * x ^ (-1 / N + ε)) *
        (x / Real.log x) := by
  have hxpos : 0 < x := lt_trans zero_lt_one hx
  have hpower : x ^ (1 - 1 / N) * x ^ ε = x * x ^ (-1 / N + ε) := by
    calc
      x ^ (1 - 1 / N) * x ^ ε = x ^ (1 + (-1 / N + ε)) := by
        rw [← Real.rpow_add hxpos]
        congr 1
        ring
      _ = x ^ (1 : ℝ) * x ^ (-1 / N + ε) := Real.rpow_add hxpos _ _
      _ = x * x ^ (-1 / N + ε) := by rw [Real.rpow_one]
  have hsum := split_sum_bound S b hxpos.le (Real.log_pos hx)
    (Real.rpow_nonneg hxpos.le _) hU hV hindividual hreciprocal hchebyshev
  calc
    (∑ ell ∈ S, b ell) ≤
        (U * H) * x / (Y * Real.log Y * Real.log x) +
          (V * J) * x ^ (1 - 1 / N) * x ^ ε / Real.log x := hsum
    _ = (U * H / (Y * Real.log Y) + V * J * x ^ (-1 / N + ε)) *
        (x / Real.log x) := by
      rw [mul_assoc (V * J), hpower]
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

end Cyclic

/-! ## Module: FieldDiscriminant -/

/-!
# Uniform root-discriminant constants

This file proves the elementary logarithmic manipulation in Lemma 6 of the
manuscript. The general discriminant bound, ramification support, and the
faithful action on torsion are external arithmetic inputs; their numerical
consequences are the hypotheses of the theorem below.
-/

noncomputable section
namespace Cyclic

/-- This constant depends only on the fixed bad-reduction product R. -/
def rootDiscriminantConstant (R : ℝ) : ℝ :=
  5 + (Real.log R + 1) / Real.log 2

theorem rootDiscriminantConstant_pos {R : ℝ} (hR : 1 ≤ R) :
    0 < rootDiscriminantConstant R := by
  have hlogR : 0 ≤ Real.log R := Real.log_nonneg hR
  have hlogtwo : 0 < Real.log 2 := Real.log_pos (by norm_num)
  unfold rootDiscriminantConstant
  positivity

/-- The general discriminant inequality and `n ≤ ell⁴` imply a logarithmic
root-discriminant bound with a constant depending on R alone. -/
theorem root_discriminant_from_raw
    {n ell R d : ℝ}
    (hn : 1 ≤ n) (hell : 2 ≤ ell) (hR : 1 ≤ R)
    (hdegree : n ≤ ell ^ (4 : ℕ))
    (hraw : d ≤ (n - 1) * (Real.log R + Real.log ell) + n * Real.log n) :
    d + n ≤ rootDiscriminantConstant R * n * Real.log (2 * ell) := by
  have hnpos : 0 < n := lt_of_lt_of_le zero_lt_one hn
  have hellpos : 0 < ell := lt_of_lt_of_le (by norm_num) hell
  have hlogR : 0 ≤ Real.log R := Real.log_nonneg hR
  have hlogell : 0 ≤ Real.log ell := Real.log_nonneg (by linarith)
  have hlogtwo : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlogn : Real.log n ≤ 4 * Real.log ell := by
    calc
      Real.log n ≤ Real.log (ell ^ (4 : ℕ)) := Real.log_le_log hnpos hdegree
      _ = 4 * Real.log ell := by rw [Real.log_pow]; norm_num
  have hfirst : (n - 1) * (Real.log R + Real.log ell) ≤
      n * (Real.log R + Real.log ell) :=
    mul_le_mul_of_nonneg_right (by linarith) (add_nonneg hlogR hlogell)
  have hsecond : n * Real.log n ≤ n * (4 * Real.log ell) :=
    mul_le_mul_of_nonneg_left hlogn hnpos.le
  have hbase : d + n ≤ n * (Real.log R + 1) + 5 * n * Real.log ell := by
    nlinarith [hraw, hfirst, hsecond]
  have htwo_le : Real.log 2 ≤ Real.log (2 * ell) :=
    Real.log_le_log (by norm_num) (by linarith)
  have hell_le : Real.log ell ≤ Real.log (2 * ell) :=
    Real.log_le_log hellpos (by linarith)
  have hratio : Real.log R + 1 ≤
      ((Real.log R + 1) / Real.log 2) * Real.log (2 * ell) := by
    calc
      Real.log R + 1 = ((Real.log R + 1) / Real.log 2) * Real.log 2 := by
        field_simp
      _ ≤ ((Real.log R + 1) / Real.log 2) * Real.log (2 * ell) :=
        mul_le_mul_of_nonneg_left htwo_le
          (div_nonneg (by linarith) hlogtwo.le)
  calc
    d + n ≤ n * (Real.log R + 1) + 5 * n * Real.log ell := hbase
    _ ≤ n * (((Real.log R + 1) / Real.log 2) * Real.log (2 * ell)) +
        5 * n * Real.log (2 * ell) := by
      exact add_le_add (mul_le_mul_of_nonneg_left hratio hnpos.le)
        (mul_le_mul_of_nonneg_left hell_le (by positivity))
    _ = rootDiscriminantConstant R * n * Real.log (2 * ell) := by
      unfold rootDiscriminantConstant
      ring

/-- The quantifier order makes the independence from division primes explicit. -/
theorem exists_root_discriminant_constant {R : ℝ} (hR : 1 ≤ R) :
    ∃ K : ℝ, 0 < K ∧ ∀ n ell d : ℝ,
      1 ≤ n → 2 ≤ ell → n ≤ ell ^ (4 : ℕ) →
      d ≤ (n - 1) * (Real.log R + Real.log ell) + n * Real.log n →
      d + n ≤ K * n * Real.log (2 * ell) := by
  exact ⟨rootDiscriminantConstant R, rootDiscriminantConstant_pos hR,
    fun n ell d hn hell hdegree hraw =>
      root_discriminant_from_raw hn hell hR hdegree hraw⟩

end Cyclic

/-! ## Module: AnalyticInputs -/

/-!
# Explicit external analytic inputs and their uniform consequence

`DivisionFields` records the numerical and analytic data of the division
fields. It does not assert that those data come from a number field. Their
connection with the reduction predicates is made explicitly by the
prime-ideal contribution hypothesis below. The arithmetic construction of
these data and the cited analytic theorems are external inputs.

The theorem at the end proves the bound needed for subtraction; the uniform
summed bound itself is not an assumption.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

structure DivisionFields (D : ReductionData) where
  degree : ℕ → ℕ
  logDisc : ℕ → ℝ
  zeta : ℕ → ℂ → ℂ
  idealSum : ℕ → ℝ → ℝ

/-- The asserted zero-free half-plane, excluding the pole at one. -/
def ZeroFree {D : ReductionData} (f : DivisionFields D) (N : ℝ) : Prop :=
  ∀ ell : ℕ, ell.Prime → ∀ s : ℂ,
    1 - 1 / N < s.re → s ≠ 1 → f.zeta ell s ≠ 0

/-- Degree and root-discriminant estimates, with constants independent of N. -/
structure FieldBounds {D : ReductionData} (f : DivisionFields D) where
  a : ℝ
  K : ℝ
  a_pos : 0 < a
  K_pos : 0 < K
  degree_lower : ∀ ell : ℕ, ell.Prime → a * (ell : ℝ) ^ 2 ≤ f.degree ell
  root_discriminant : ∀ ell : ℕ, ell.Prime →
    f.logDisc ell + (f.degree ell : ℝ) ≤
      K * (f.degree ell : ℝ) * Real.log (2 * (ell : ℝ))

/-- A less processed version of the classical field inputs. The root-
discriminant estimate is derived from these inequalities by `toFieldBounds`. -/
structure RawFieldBounds {D : ReductionData} (f : DivisionFields D) where
  R : ℝ
  R_one_le : 1 ≤ R
  a : ℝ
  a_pos : 0 < a
  degree_lower : ∀ ell : ℕ, ell.Prime → a * (ell : ℝ) ^ 2 ≤ f.degree ell
  degree_upper : ∀ ell : ℕ, ell.Prime → (f.degree ell : ℝ) ≤ (ell : ℝ) ^ (4 : ℕ)
  raw_discriminant : ∀ ell : ℕ, ell.Prime →
    f.logDisc ell ≤ ((f.degree ell : ℝ) - 1) *
      (Real.log R + Real.log (ell : ℝ)) +
        (f.degree ell : ℝ) * Real.log (f.degree ell : ℝ)

/-- Construct the required uniform field bounds from the raw arithmetic
inequalities; the logarithmic manipulation is proved, not an extra input. -/
def RawFieldBounds.toFieldBounds {D : ReductionData} {f : DivisionFields D}
    (raw : RawFieldBounds f) : FieldBounds f where
  a := raw.a
  K := rootDiscriminantConstant raw.R
  a_pos := raw.a_pos
  K_pos := rootDiscriminantConstant_pos raw.R_one_le
  degree_lower := raw.degree_lower
  root_discriminant := by
    intro ell hell
    have hellpos : (0 : ℝ) < ell := by exact_mod_cast hell.pos
    have hdegreepos : (0 : ℝ) < f.degree ell :=
      lt_of_lt_of_le (mul_pos raw.a_pos (sq_pos_of_pos hellpos))
        (raw.degree_lower ell hell)
    have hdegreeposNat : 0 < f.degree ell := by exact_mod_cast hdegreepos
    have hdegreeone : 1 ≤ f.degree ell := Nat.succ_le_of_lt hdegreeposNat
    apply root_discriminant_from_raw
    · exact_mod_cast hdegreeone
    · exact_mod_cast hell.two_le
    · exact raw.R_one_le
    · exact raw.degree_upper ell hell
    · exact raw.raw_discriminant ell hell

/-- The cited smoothed explicit formula and the standard contribution of
completely split primes to its nonnegative ideal sum are kept visible. -/
structure SmoothedExplicitFormula (D : ReductionData) (f : DivisionFields D) where
  F : ℝ
  F_pos : 0 < F
  split_contribution : ∀ ell : ℕ, ell.Prime → ∀ x : ℝ, 2 ≤ x →
    splitCount D ell x * (f.degree ell : ℝ) * Real.log x ≤ f.idealSum ell x
  upper : ∀ N : ℝ, 2 ≤ N → ZeroFree f N → ∀ ell : ℕ, ell.Prime →
    ∀ x : ℝ, 2 ≤ x →
      f.idealSum ell x ≤
        F * (x + x ^ (1 - 1 / N) * (f.logDisc ell + (f.degree ell : ℝ)))

/-- The elementary prime reciprocal-square tail and Chebyshev bound. -/
structure PrimeEstimates where
  H : ℝ
  J : ℝ
  H_nonneg : 0 ≤ H
  J_nonneg : 0 ≤ J
  reciprocal : ∀ Y z : ℝ, 3 ≤ Y → 2 ≤ z →
    (∑ ell ∈ primeIndices Y z, (1 : ℝ) / (ell : ℝ) ^ 2) ≤
      H / (Y * Real.log Y)
  chebyshev : ∀ Y z : ℝ, 3 ≤ Y → 2 ≤ z →
    (∑ ell ∈ primeIndices Y z, Real.log (2 * (ell : ℝ))) ≤ J * z

/-- Uniformity in the zero-free width is a proved consequence of the input
quantifiers: the constants are chosen before N, ε, and Y. -/
theorem exists_uniform_split_bound
    (D : ReductionData) (f : DivisionFields D)
    (fields : FieldBounds f) (explicit : SmoothedExplicitFormula D f)
    (primes : PrimeEstimates) :
    ∃ C₁ C₂ : ℝ, ∀ N : ℝ, 2 ≤ N → ZeroFree f N →
      ∀ ε Y : ℝ, 0 < ε → 3 ≤ Y →
        ∀ᶠ x : ℝ in atTop,
          (∑ ell ∈ primeIndices Y (x ^ ε), splitCount D ell x) ≤
            (C₁ / (Y * Real.log Y) + C₂ * x ^ (-1 / N + ε)) *
              (x / Real.log x) := by
  refine ⟨(explicit.F / fields.a) * primes.H,
    (explicit.F * fields.K) * primes.J, ?_⟩
  intro N hN hzero ε Y hε hY
  have hgrowth : Tendsto (fun x : ℝ => x ^ ε) atTop atTop :=
    tendsto_rpow_atTop hε
  filter_upwards [eventually_ge_atTop (2 : ℝ),
    hgrowth.eventually (eventually_ge_atTop (2 : ℝ))] with x hx hxε
  have hxone : 1 < x := lt_of_lt_of_le (by norm_num) hx
  have hxpos : 0 < x := lt_trans zero_lt_one hxone
  have hlog : 0 < Real.log x := Real.log_pos hxone
  apply split_sum_normalized (primeIndices Y (x ^ ε)) (fun ell => splitCount D ell x)
    hxone (div_nonneg explicit.F_pos.le fields.a_pos.le)
    (mul_nonneg explicit.F_pos.le fields.K_pos.le)
  · intro ell hell
    have hellprime : ell.Prime := (mem_primeIndices.mp hell).1
    have hellpos : (0 : ℝ) < ell := by exact_mod_cast hellprime.pos
    have hn : (0 : ℝ) < f.degree ell :=
      lt_of_lt_of_le (mul_pos fields.a_pos (sq_pos_of_pos hellpos))
        (fields.degree_lower ell hellprime)
    exact split_individual_bound hn hellpos hxpos.le hlog
      (Real.rpow_nonneg hxpos.le _) explicit.F_pos.le fields.a_pos
      (explicit.split_contribution ell hellprime x hx)
      (explicit.upper N hN hzero ell hellprime x hx)
      (fields.degree_lower ell hellprime) (fields.root_discriminant ell hellprime)
  · exact primes.reciprocal Y (x ^ ε) hY hxε
  · exact primes.chebyshev Y (x ^ ε) hY hxε

end Cyclic

/-! ## Module: Main -/

/-!
# Positive proportion from the agreed sieve and splitting estimates

Every covering, subtraction, eventual threshold, uniform parameter choice,
and lower-liminf passage is proved. The subsequent `Theorems` module obtains
the splitting estimate from the positive explicit formula and arithmetic data.
-/

noncomputable section
open Filter
open scoped Topology BigOperators
namespace Cyclic

theorem candidates_covered (D : ReductionData) (g : Progression)
    (arith : ArithmeticFacts D g) {x ε Y : ℝ} (hx : 2 < x)
    (hlarge : Real.sqrt (2*x)+1 < x^(9/10 : ℝ)) :
    candidates g x ε Y ⊆ cyclicInterval D x ∪
      (primeIndices Y (x^ε)).biUnion (fun ell => primeInterval (D.split ell) x) := by
  classical
  intro p hp
  rcases mem_primeInterval.mp hp with ⟨hpprime, hpx, hp2x, hprog, r, Q,
    hfactor, hQ, hQlarge, hrbound, hrough⟩
  have hgood := arith.progression_good p hpprime hprog
  by_cases hcyclic : D.cyclic p
  · exact Finset.mem_union_left _ (mem_primeInterval.mpr
      ⟨hpprime, hpx, hp2x, hgood, hcyclic⟩)
  · have hp3 : 3 ≤ p := by
      have : (2 : ℝ) < (p : ℝ) := hx.trans hpx
      have : 2 < p := by exact_mod_cast this
      omega
    rcases arith.obstruction p hpprime hp3 hgood hcyclic with
      ⟨ell, hell, hsplit, hdiv, hhasse⟩
    have hne2 : ell ≠ 2 := by
      intro heq
      subst ell
      exact arith.progression_not_split_two p hpprime hprog hsplit
    have hshort := short_obstruction (show 2 ≤ p by omega) hp2x.le hell hQ hne2
      hfactor hdiv hhasse (hlarge.trans hQlarge) hrough hrbound
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr
      ⟨ell, mem_primeIndices.mpr ⟨hell, hshort⟩,
        mem_primeInterval.mpr ⟨hpprime, hpx, hp2x, hsplit⟩⟩)

/-- The normalized inequality immediately before choosing ε and Y. -/
theorem normalized_cyclic_lower_bound (D : ReductionData) (g : Progression)
    (arith : ArithmeticFacts D g) {A C₁ C₂ N ε Y : ℝ}
    (hcandidate : ∀ᶠ x : ℝ in atTop,
      A*ε/Real.log Y * (x/Real.log x) ≤ ((candidates g x ε Y).card : ℝ))
    (hsplit : ∀ᶠ x : ℝ in atTop,
      (∑ ell ∈ primeIndices Y (x^ε), splitCount D ell x) ≤
        (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x)) :
    ∀ᶠ x : ℝ in atTop,
      (A*ε/Real.log Y-C₁/(Y*Real.log Y)-C₂*x^(-1/N+ε))*(x/Real.log x) ≤
        cyclicCount D (2*x)-cyclicCount D x := by
  classical
  filter_upwards [hcandidate, hsplit, eventually_gt_atTop (2 : ℝ),
    eventually_large_factor_dominates_hasse] with x hc hs hx hl
  have hremove := candidate_removal_bounds (candidates g x ε Y) (cyclicInterval D x)
    (primeIndices Y (x^ε)) (fun ell => primeInterval (D.split ell) x)
    (A*ε/Real.log Y*(x/Real.log x))
    ((C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x))
    (candidates_covered D g arith hx hl) hc hs
  have hinterval := cyclicInterval_le_difference D (show 0 ≤ x by linarith)
  calc
    _ = A*ε/Real.log Y*(x/Real.log x) -
        (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x) := by ring
    _ ≤ ((cyclicInterval D x).card : ℝ) := hremove
    _ ≤ _ := hinterval

/-- A uniform splitting estimate is a proposition, not an axiom. It is proved
from the explicit formula in `AnalyticInputs.exists_uniform_split_bound`. -/
def UniformSplitBound (D : ReductionData) (ZF : ℝ → Prop) : Prop :=
  ∃ C₁ C₂ : ℝ, ∀ N : ℝ, 2 ≤ N → ZF N →
    ∀ ε Y : ℝ, 0 < ε → 3 ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        (∑ ell ∈ primeIndices Y (x^ε), splitCount D ell x) ≤
          (C₁/(Y*Real.log Y)+C₂*x^(-1/N+ε))*(x/Real.log x)

/-- Both quantitative conclusions, with the same positive constant independent
of N. The zero-free hypothesis is required separately at each N. -/
theorem quantitative_of_sieve_and_split_bound
    (D : ReductionData) (g : Progression) (ZF : ℝ → Prop)
    (arith : ArithmeticFacts D g) (sieve : CofactorSieve g)
    (splitting : UniformSplitBound D ZF) (pnt : PrimeNumberTheorem) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → ZF N →
      (∀ᶠ x : ℝ in atTop, c/(N*Real.log N)*(x/Real.log x) ≤
        cyclicCount D (2*x)-cyclicCount D x) ∧
      c/(N*Real.log N) ≤
        Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop := by
  rcases sieve with ⟨A, ε₀, Y₀, hA, hε₀, _, hcandidates⟩
  rcases splitting with ⟨C₁, C₂, hsplit⟩
  rcases exists_uniform_parameters (Y₀ := Y₀) (C₁ := C₁) (C₂ := C₂) hA hε₀
    with ⟨d, hd, hparams⟩
  refine ⟨d/2, by positivity, ?_⟩
  intro N hN hZF
  have hNpos : 0 < N := by linarith
  have hlogN : 0 < Real.log N := Real.log_pos (by linarith)
  have hden : 0 < N*Real.log N := mul_pos hNpos hlogN
  rcases hparams N hN with ⟨ε,Y,hε,hεlt,hY₀,hY,hcoeff⟩
  have hbefore := normalized_cyclic_lower_bound D g arith
    (hcandidates ε Y hε hεlt hY₀) (hsplit N hN hZF ε Y hε hY)
  have hdyadic : ∀ᶠ x : ℝ in atTop,
      d/(N*Real.log N)*(x/Real.log x) ≤ cyclicCount D (2*x)-cyclicCount D x := by
    filter_upwards [hcoeff,hbefore,eventually_gt_atTop (2 : ℝ)] with x hc hb hx
    have hscale : 0 ≤ x/Real.log x :=
      div_nonneg (by linarith) (Real.log_nonneg (by linarith))
    exact (mul_le_mul_of_nonneg_right hc hscale).trans hb
  constructor
  · filter_upwards [hdyadic,eventually_gt_atTop (2 : ℝ)] with x hdya hx
    have hscale : 0 ≤ x/Real.log x :=
      div_nonneg (by linarith) (Real.log_nonneg (by linarith))
    exact (mul_le_mul_of_nonneg_right
      (div_le_div_of_nonneg_right (show d/2 ≤ d by linarith) hden.le) hscale).trans hdya
  · have hlim := lower_proportion_of_dyadic (cyclicCount D) primeCount
      (d/(N*Real.log N)) (div_nonneg hd.le hden.le)
      (cyclicCount_nonneg D) (Eventually.of_forall (cyclicCount_le_primeCount D))
      (eventually_positive_of_pnt primeCount pnt) pnt hdyadic
    convert hlim using 1
    ring

theorem positive_proportion_of_width_32
    (D : ReductionData) (g : Progression) (ZF : ℝ → Prop)
    (arith : ArithmeticFacts D g) (sieve : CofactorSieve g)
    (splitting : UniformSplitBound D ZF) (pnt : PrimeNumberTheorem)
    (cureton_thorner : ZF 32) :
    0 < Filter.liminf (fun X : ℝ => cyclicCount D X / primeCount X) atTop := by
  rcases quantitative_of_sieve_and_split_bound D g ZF arith sieve splitting pnt
    with ⟨c,hc,hquant⟩
  have hlim := (hquant 32 (by norm_num) cureton_thorner).2
  have hlog : 0 < Real.log (32 : ℝ) := Real.log_pos (by norm_num)
  exact lt_of_lt_of_le (div_pos hc (mul_pos (by norm_num) hlog)) hlim

end Cyclic

/-! ## Module: Theorems -/

/-!
# Manuscript theorem, with its complete conditional interface

The conclusion refers to Mathlib's actual elliptic point groups over ZMod p.
The deep analytic inputs and the classical arithmetic realization are explicit
arguments, not axioms or hidden instances. The character/CRT progression is
proved. The construction of division fields and their zeta functions and the
standard Galois/torsion theorems remain external.
-/

noncomputable section
open Filter
open scoped Topology
namespace Cyclic

def ellipticData (W : WeierstrassCurve ℤ) (split : ℕ → ℕ → Prop) : ReductionData where
  good := EllipticModel.GoodReduction W
  cyclic := EllipticModel.CyclicReduction W
  split := split

/-- Actual prime count for good cyclic reductions of an integral equation. -/
def ellipticCyclicCount (W : WeierstrassCurve ℤ) (X : ℝ) : ℝ :=
  (primeUpTo (fun p => EllipticModel.GoodReduction W p ∧
    EllipticModel.CyclicReduction W p) X).card

/-- Explicit boundary for the classical arithmetic and its realization.

* `character` uses the 2-division-field quotient and Kronecker--Weber.
* `criterion` is the standard torsion/Frobenius criterion,
  Weil pairing, and Hasse bound.
* `fields` is Serre open image/CM and the ramification/discriminant estimate.

The concrete character, CRT, exact-power-of-two, and progression deductions
are proved in the arithmetic modules. Only the listed classical arithmetic
realizations are inputs.
-/
structure ClassicalArithmetic (W : WeierstrassCurve ℤ) where
  split : ℕ → ℕ → Prop
  division : DivisionFields (ellipticData W split)
  fields : RawFieldBounds division
  character : EllipticModel.Admissible W → Nonempty (TwoDivisionCharacter (ellipticData W split))
  criterion : CyclicityCriterion (ellipticData W split)

/-- The reusable predecessor sieve, for every admissible fixed progression.
This is the cited varying-cofactor consequence of the agreed earlier work and
OpenAI marked estimates, not a new axiom declaration. -/
def PredecessorSieveTheorem : Prop := ∀ g : Progression, CofactorSieve g

/-- The quantitative manuscript theorem for actual reduction point groups.
The same c>0 works for every N for which the zero-free hypothesis is supplied. -/
theorem quantitative_cyclic_reductions
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.Admissible W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → ZeroFree arith.division N →
      (∀ᶠ x : ℝ in atTop, c/(N*Real.log N)*(x/Real.log x) ≤
        ellipticCyclicCount W (2*x)-ellipticCyclicCount W x) ∧
      c/(N*Real.log N) ≤
        Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop := by
  rcases arith.character hW with ⟨char⟩
  rcases progression_from_two_division_character _ char arith.criterion with ⟨g,hg⟩
  exact quantitative_of_sieve_and_split_bound
    (ellipticData W arith.split) g (ZeroFree arith.division) hg (sieve g)
    (exists_uniform_split_bound _ arith.division arith.fields.toFieldBounds explicit primes) pnt

/-- The positive-proportion conclusion at the agreed Cureton--Thorner width.
No full-density statement is asserted. -/
theorem positive_proportion_cyclic_reductions
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.Admissible W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) (cureton_thorner : ZeroFree arith.division 32) :
    0 < Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop := by
  rcases arith.character hW with ⟨char⟩
  rcases progression_from_two_division_character _ char arith.criterion with ⟨g,hg⟩
  exact positive_proportion_of_width_32
    (ellipticData W arith.split) g (ZeroFree arith.division) hg (sieve g)
    (exists_uniform_split_bound _ arith.division arith.fields.toFieldBounds explicit primes) pnt
    cureton_thorner

/-- Standard injectivity of prime-to-p torsion specialization. The group
theoretic obstruction and zero-density conclusion below are proved. -/
def TwoTorsionSpecialization (W : WeierstrassCurve ℤ) : Prop :=
  EllipticModel.FullRationalTwoTorsion W →
    ∀ p : ℕ, ∀ hp : p.Prime, 3 ≤ p → EllipticModel.GoodReduction W p →
      letI : Fact p.Prime := ⟨hp⟩
      ∃ P Q : (EllipticModel.reduction W p).toAffine.Point,
        P ≠ 0 ∧ Q ≠ 0 ∧ P ≠ Q ∧ (2 : ℕ) • P = 0 ∧ (2 : ℕ) • Q = 0

theorem zero_proportion_of_full_rational_two_torsion
    (W : WeierstrassCurve ℤ) (hfull : EllipticModel.FullRationalTwoTorsion W)
    (specialization : TwoTorsionSpecialization W) (pnt : PrimeNumberTheorem) :
    Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop = 0 := by
  apply cyclic_liminf_eq_zero_of_odd_noncyclic (ellipticData W (fun _ _ => False))
  · intro p hp hp3 hgood
    letI : Fact p.Prime := ⟨hp⟩
    rcases specialization hfull p hp hp3 hgood with ⟨P,Q,hP,hQ,hPQ,hP2,hQ2⟩
    exact EllipticModel.not_cyclicReduction_of_two_torsion W p hP hQ hPQ hP2 hQ2
  · exact pnt

theorem positive_proportion_iff_no_full_rational_two_torsion
    (W : WeierstrassCurve ℤ) (hW : EllipticModel.RationalElliptic W)
    (arith : ClassicalArithmetic W)
    (explicit : SmoothedExplicitFormula (ellipticData W arith.split) arith.division)
    (sieve : PredecessorSieveTheorem) (primes : PrimeEstimates)
    (pnt : PrimeNumberTheorem) (cureton_thorner : ZeroFree arith.division 32)
    (specialization : TwoTorsionSpecialization W) :
    (0 < Filter.liminf (fun X : ℝ => ellipticCyclicCount W X / primeCount X) atTop) ↔
      ¬EllipticModel.FullRationalTwoTorsion W := by
  constructor
  · intro hpos hfull
    rw [zero_proportion_of_full_rational_two_torsion W hfull specialization pnt] at hpos
    exact (lt_irrefl 0) hpos
  · intro hnotfull
    exact positive_proportion_cyclic_reductions W ⟨hW,hnotfull⟩ arith explicit
      sieve primes pnt cureton_thorner

end Cyclic

/-! ## Module: Audit -/

/-!
The only kernel axioms expected below are propext, Classical.choice, Quot.sound.
The analytic and classical arithmetic assumptions are explicit theorem
arguments, so they are NOT enumerated by `#print axioms`. See ASSUMPTIONS.md.
-/

#print axioms Cyclic.exists_compatible_dirichlet_integer
#print axioms Cyclic.progression_from_two_division_character
#print axioms Cyclic.short_obstruction
#print axioms Cyclic.root_discriminant_from_raw
#print axioms Cyclic.exists_uniform_split_bound
#print axioms Cyclic.exists_uniform_parameters
#print axioms Cyclic.lower_proportion_of_dyadic
#print axioms Cyclic.quantitative_cyclic_reductions
#print axioms Cyclic.positive_proportion_cyclic_reductions
#print axioms Cyclic.positive_proportion_iff_no_full_rational_two_torsion
