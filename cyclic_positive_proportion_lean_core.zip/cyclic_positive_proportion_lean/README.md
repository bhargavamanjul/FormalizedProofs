# Cyclic reductions at a positive proportion of primes

A checked conditional Lean formalization of the positive-proportion manuscript
by Manjul Bhargava, dated 24 October 2026. This project concerns the positive
lower proportion and its quantitative `1 / (N log N)` bound, not the later
research note about the full density.

## Main results

`Cyclic.quantitative_cyclic_reductions` proves, from the explicit inputs below,
that one constant `c > 0` works for every real `N >= 2` satisfying the zero-free
condition. It gives both the eventual dyadic lower bound and the lower-liminf
bound in Theorem 2 of the manuscript. The quantifier order enforces that `c`
is chosen before `N`.

`Cyclic.positive_proportion_cyclic_reductions` specializes the result to `N=32`.

`Cyclic.positive_proportion_iff_no_full_rational_two_torsion` also proves the
necessity of the two-torsion restriction, using the separately stated standard
torsion-specialization input.

The conclusion uses concrete finite sets of natural-number primes, real cutoffs,
and Mathlib's actual additive point groups of integral Weierstrass equations
reduced over `ZMod p`. The lower proportion is `Filter.liminf`, not a new
predicate standing for the desired conclusion.

## Scope of the verification

The following deductions are proved in Lean:

- Character compatibility, including the exceptional prime 3, the concrete
  prime-power CRT decomposition, and selection of an integral unit residue.
- Construction of the fixed progression, including the exact power of two
  and quotient coprimality.
- Confinement of every candidate obstruction to `Y < ell <= x^epsilon`, using
  primality, divisibility, and the Hasse bound. The growth comparison with the
  distinguished large prime is proved from real-power limits.
- The finite union bound and subtraction of unrestricted splitting primes.
- The root-discriminant algebra, division of the positive prime-ideal sum by
  the field degree, and summation of the splitting bounds.
- The explicit parameter choice, admissibility, decay of the error term, and
  independence of the final constant from `N`.
- The passage to the lower liminf, with its exact factor `1/2`.
- The finite-group two-torsion obstruction and the zero-proportion conclusion
  when all odd good reductions are noncyclic.

The cited analytic theorems and classical arithmetic realizations are explicit
arguments of the final theorem. They are **not proved or instantiated by this
project**. In particular, it does not construct division fields and their
Dedekind zeta functions, prove Serre's open-image/CM theorems or Kronecker--Weber,
or reprove the imported varying-cofactor sieve. See `ASSUMPTIONS.md` for the
precise boundary and source mapping.

The concrete model is an integral Weierstrass equation whose rationalization is
elliptic. Passing an arbitrary elliptic curve over Q to such a model and
transporting its reductions is standard arithmetic, but that transport is not
formalized here. A nonminimal model may exclude finitely many additional primes.

## Reproduce the check

Install Lean through elan, then run in this directory:

```sh
lake exe cache get
lake build
```

The toolchain is Lean **4.19.0**. Mathlib is pinned by `lake-manifest.json` to
`c44e0c8ee63ca166450922a373c7409c5d26b00b` (tag `v4.19.0`). No special local
compiler modifications or additional proof tools are required.

`Cyclic/Audit.lean` prints the kernel-axiom dependencies of the main results and
the principal intermediate theorems. The checked output contains only
`propext`, `Classical.choice`, and `Quot.sound`. External mathematical inputs
are theorem parameters and therefore do not appear in this list. The source
contains no `sorry`, `admit`, custom axiom declarations, or untrusted decision
procedures.

The archive includes `verification/build.log`, `verification/axioms.log`, and a
source manifest. The separate single-file export can be checked in this same
Mathlib environment with `lake env lean single-file/cyclic_positive_proportion.lean`.

## Source manuscript

The source used is the current `cyclic_reductions.tex`, version 2, 24 October
2026. Its SHA-256 is
`814d12e402011af3a11e52fe01491d4bbc795bdf587f6ae0bcaa73e7860bd213`.
An unchanged copy is included in `manuscript/` to make the theorem mapping
reviewable. Formalization date: 25 October 2026.
