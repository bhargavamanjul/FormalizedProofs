# External mathematical inputs

All inputs are explicit theorem arguments or fields of explicit records.
There are no custom Lean axioms. This distinction matters: an axiom audit alone
does not say that the following mathematical inputs have been proved.

## Agreed analytic black boxes

1. **Cureton--Thorner:** `ZeroFree arith.division 32` is the zero-free half-plane
   `Re(s) > 31/32` for the prime-division zeta functions (excluding the pole at
   one). The quantitative theorem accepts `ZeroFree ... N` separately for
   each `N >= 2`. The functions are supplied by the arithmetic realization;
   their identity with actual Dedekind zeta functions is not constructed here.

2. **Earlier varying-cofactor work, based on the OpenAI marked Type II
   estimates:** `PredecessorSieveTheorem` supplies the fixed-progression
   candidate bound in its predecessor form. It is the exact interface of the
   current manuscript's candidate proposition: constants `A, epsilon0, Y0`
   precede `epsilon,Y`, and the threshold may depend on the latter. Candidates
   are defined by the actual factorization `p-1 = 2^k*r*Q`, roughness of `r`,
   `r <= x^epsilon`, and prime `Q > x^(9/10)`.

   The current development imports this cofactor-sieve consequence of the
   agreed earlier papers. It does not reconstruct the marked bilinear sums,
   selector invariance, sign transfer, Buchstab subtraction, or block sieve
   from the raw OpenAI statements. Thus the formal hypothesis is the reusable
   candidate theorem, not a purported formal import of the OpenAI source code.

3. **Smoothed explicit formula from the primitive-point paper:**
   `SmoothedExplicitFormula.upper` supplies the positive ideal-sum upper bound
   with a constant independent of the field and zero-free width. The standard
   contribution of a completely split prime is separately recorded as
   `split_contribution`. Normalizing by the degree and the entire summed
   splitting estimate are proved here, not supplied as further black boxes.

References are those of the manuscript: Cureton--Thorner,
<https://hexagonmath.org/2610.00200v2>; Bhargava's primitive-point paper,
<https://hexagonmath.org/2610.00294v1>; the earlier primitive-root paper,
<https://hexagonmath.org/2610.00228v1>; and the cited OpenAI marked estimates.

## Classical arithmetic input

`ClassicalArithmetic W` supplies the following data and standard facts for an
integral Weierstrass model `W`:

- The complete-splitting relation, division-field degrees, logarithmic
  discriminants, zeta functions, and smoothed ideal sums. These are interfaces,
  not constructed NumberField objects in this project.
- From admissibility, a nontrivial character of a nontrivial abelian quotient
  of the 2-division field, with an even modulus containing the bad primes.
  `TwoDivisionCharacter` states the associated good-reduction and splitting
  tests. This is the standard subgroup-of-S3/Kronecker--Weber input.
- The noncyclicity/Frobenius criterion and its consequences
  `ell | p-1` and `ell <= sqrt(p)+1`, from good-reduction torsion, the Weil
  pairing, and Hasse's bound.
- The uniform degree lower bound from Serre open image or CM, the elementary
  upper bound `n_ell <= ell^4`, and the raw Galois discriminant inequality with
  ramification supported on `ell*R_E`. The logarithmic root-discriminant
  consequence is proved in `FieldDiscriminant.lean`.

Crucially, **progression existence is proved**, not a field of this input.
`progression_from_two_division_character` invokes the fully proved character,
CRT, integral-residue, and exact-power-of-two arguments.

For the necessity direction only, `TwoTorsionSpecialization W` supplies
injective specialization of rational 2-torsion at odd good primes. The
finite-group obstruction and resulting zero proportion are then proved.

## Classical analytic input

- `PrimeEstimates`: the prime reciprocal-square tail and Chebyshev's logarithmic
  prime sum, with fixed constants. These standard estimates remain hypotheses.
- `PrimeNumberTheorem`: the usual PNT for the concrete prime-counting function.
  The eventual positivity, density comparison, boundedness needed for real
  liminf, and limit deductions are proved from it.

## What this is not

This is a conditional formalization of the manuscript's deductions with the
above classical and cited-theorem boundary. It is not an unconditional Lean
proof from Mathlib alone, nor a formal construction of all arithmetic objects.
It makes no claim about the full cyclicity density or the unresolved
`31/32` full-density estimate discussed subsequently.
