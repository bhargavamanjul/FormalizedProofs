> Historical review from an earlier checkpoint. The original deductions discussed below are now complete relative to the agreed external inputs. See `remaining-obligations.md` and `Artin/ManuscriptTheorem.lean` for the current result; this file preserves the earlier assessment.


# Follow-up audit: is there a mathematical obstruction?

The 13 October follow-up checked the two remaining estimates against the manuscript and the accepted source statements. **No mathematical obstruction was found in this audit.** This is a mathematical assessment, not a completed Lean proof of the two estimates.

## Marked replacement

The manuscript's progression and smooth-weight argument follows the proof of OpenAI's Lemma 12.1. The more general selector is permitted by the explicitly uniform hypotheses of Lemma 10.2. In its proof the invariant selector is removed by Cauchy–Schwarz, so the lower bound on the number of marks does not depend on that selector. This is the key reason the marks can be chosen before the cofactor parameters and the zero-free width.

The checks include:

- Invariance under a marked prime even when that prime already divides the argument.
- Arbitrary subintervals in the coefficient criterion.
- Character cancellation for every fixed logarithmic modulus and frequency range.
- The passage from a modulus `k` to `lcm(M,k)`, bounded by the next logarithmic range for fixed `M`.
- Fourier separation with twists of size at most `log x` and a rapidly decreasing tail.
- Independence of the required number of marks from the particular band exponents, while allowing the eventual threshold to depend on those exponents.

One classical interface identity should be stated explicitly when this is entered into Lean: the finite-simplex definition of the rough density in Proposition 10.3 equals the Buchstab-function definition used in the manuscript. The user's authorization covers that classical identity; it has not yet been entered as a formal input.

## Enlarged cofactor and candidate count

The enlargement `r = s*r₀` has three controlled effects.

1. The reciprocal cofactor mass gains a factor comparable to `ε log x / log Y`. The two exclusions remove at most `1/4 + o(1)` and `1/(τ floor Y)` of the preliminary mass.
2. The progression estimate at each `r` has scale `x/r`. Summing its errors with the weights uses `J = Σ t_r/r`. The strict Bombieri–Vinogradov exponent margin is positive. For the conditioned sieve, `(n,ℓ) ↦ nℓ` is injective because `n` is the only prime factor exceeding `W`. The cited block sieve has the required bounded remainder coefficients when its depth grows.
3. Omitting primes dividing the cofactor changes local factors by at most `exp(10τ+o(1))`. The two-variable upper-sieve error is uniformly negligible for `r ≤ x^0.11`. Its weighted sum uses `J`, not the pointwise marked-weight bound. Hence the semiprime constant can be chosen independently of the number of marks.

These checks support the parameter order

```text
κ, then b, then τ and the finite partition, then K and its bands,
then ε and Y, and finally a sufficiently large x.
```

No circular dependence or parity obstruction was found. The candidate lower bound remains a new deduction from the cited estimates and must still be formalized; it cannot simply be entered as a cited theorem.

## Small-index obstructions

The mathematical route is the smoothed explicit formula, the uniform zero count, and positivity of the ideal sum. A fixed compactly supported smooth weight has a zero-weight sum bounded by a constant times `log|D_K| + [K:Q]`. Dividing the split-prime contribution by `[K:Q] log x` gives the needed degree normalization. The archimedean remainder is absorbed uniformly when the zero-free width is at most `1/2`.

For the Kummer fields, the degree and discriminant bounds then reduce summation to the classical estimates for `Σ log q` and `Σ 1/(q(q−1))`. The finitely many exceptional Kummer primes must be below the fixed cutoff. No new uniformity obstruction was found here.

The formal interface must assert bounds simultaneously for every prime `q` in the growing range at each sufficiently large `x`. An estimate that holds eventually for each fixed `q`, with an uncontrolled `q`-dependent threshold, would not suffice.

`Artin/SmallIndexUnion.lean` now proves the finite union, exact handling of the real cutoffs, and the summation into `SmallIndexEstimate`. Its inputs are the explicitly defined `IndividualPowerResidueEstimate` and `ReciprocalPrimeTail`. The leading constant becomes `m*H`; the error constant becomes `E*(2 log 4 + A)`. Neither input is asserted as an axiom. The module builds successfully and its theorem dependencies are included in the aggregate audit.

## What this assessment establishes

The earlier stopping point was unfinished formalization. The audit gives a concrete route to continue, and has not exposed a failed mathematical step. It does not certify that no further issue can emerge during formalization, and it does not change the current main theorem into a theorem depending only on the accepted citations.

## Subsequent checked progress

The expanded project now defines the actual rational Kummer splitting fields,
their degree and discriminant, and continued Dedekind zeta functions with a
proved uniqueness property. This required avoiding mathlib's raw Dirichlet
series in the critical strip: that series is totalized as zero outside absolute
convergence. The new QRH interface includes continuation existence, so it is
not vacuous. Its critical-strip formulation uses the customary classical
nonvanishing results if translated into a literal half-plane assertion.

The reciprocal-prime tail has now been proved with constant `8 log 4` from
Chebyshev. The source transform-cancellation twisting step, character/Fourier
transfer, actual repeated-prime selector, concrete marking weights, unmarked
cofactor asymptotics, finite prime-power tails, local factors, uniform sieve
error bookkeeping and rough-composite factorization have also been checked.

A separate semantic review found no false statement in the new selector,
candidate-assembly, Dedekind or Kummer modules. It highlighted an essential
trust boundary: `ClassicalKummerInputs` is a sufficient package, not yet a
formal transcription of the source formulas. Its auxiliary sums and weights
are still abstract; matching them to actual ideal sums, all zeros with
multiplicity and Mellin transforms remains work. Likewise, `CandidateSieveData`
has not been constructed from the accepted sources. Its estimates are explicit
premises, not certified consequences merely because later deductions compile.

The next endpoint,
`quantitative_prime_proportion_of_sieve_and_kummer_data`, uses actual QRH and
proves the uniform `c/(N log N)` conclusion from these packages. The remaining
tasks are recorded by manuscript section in `proof-map.md`. Completion still
requires substantive proofs of the source instantiations and their assembly.
