# Proof map for the 12 October manuscript

All source inputs are explicit theorem arguments. “Checked” means the stated implication compiles; it does not mean its source arguments have been supplied globally.

| Manuscript | Checked development | Remaining work |
|---|---|---|
| §2: index and progression | `Arithmetic`; `NonresidueProgression` proves progression properties from a normalized Jacobi seed, local sign selection, CRT and exceptional cases | The cited Lemma 2.4 supplies the progression through `SourceProgression`; independently reproving its general seed is optional under the agreed source boundary |
| §3: marked replacement | `MarkedReplacement`, `MarkedCriterion`, `MarkedSource`: source cancellation, characters, Fourier smoothing, uniform growing dyad families, actual weights and bands | Enter the exact accepted source statements; instantiate later bin and pair applications |
| §4: cofactor mass | `MarkedMultigroupMass`, `MarkedInfiniteMass`, `EnlargedCofactorMass`, `MarkedBandTail`, `MarkedCofactorEstimate`: convergence, exact J factorization, actual tail, finite truncation, retained full mass and classical-prime mass bounds | Supply the explicitly stated classical prime estimates at the final endpoint |
| §5: distribution | `CofactorRepresentation`, `PrimeProgressions`, `PrimeDistribution`, `PrimeSmoothIntegral`, `PrimeMainMass`, `AffineIntegral`, `LogarithmicIntegralCells`, `SieveDistribution`, `WeightedTail`: actual sums, CRT, Abel summation, integral comparison and error conversions | Assemble all uniform varying-cofactor estimates and the full X0 comparison with constants independent of K |
| §6: local factors | `LocalSieveProducts`, `CofactorAsymptotics`, `BuchstabSieve`: exact density products, deletion control, vanishing marked-divisor mass | Apply to actual cofactors and the classical Mertens product asymptotic |
| §7: Buchstab subtraction | `BuchstabSieve`: source block contract, actual predecessor arrays and conditioned remainder injection. `CandidateSieve`: finite-bin subtraction and parameter choices | Actual bin estimates through MR, density continuity/Buchstab identity, finite upper partition, full lower rough-survivor estimate |
| §8: semiprimes | `SquarefreeRho`, `LatticeBoxes`, `SieveLattice`, `DyadicBoxes`: actual CRT counts, errors and cover. `SemiprimeSieve`: uniform error absorption. `SemiprimeReplacement`: two-error identity and cancellation of V². `RoughFactorization`: actual composite factorization | Two-variable upper sieve applied to these arrays; actual MR substitutions and summation over boxes; mark-independent C2 |
| §9: candidate count | `ConcreteSelector`: actual selected survivors and support. `CandidateSieve`: constructor from intermediate estimates | Construct `CandidateSieveData`; never accept it as a source theorem |
| §10: splitting | `DedekindZeroOrder`, `ClassicalFormula`: actual multiplicities, ideal sums, Mellin weights and positive smoothing; convergence and source construction. `KummerArithmetic`: irreducibility, logarithmic normalization and ideal embedding. `SmallIndexUnion`, `ReciprocalPrimeTail`: actual union estimate | Supply separate exact classical/source statements; prove or precisely source the polynomial/cyclotomic/compositum discriminant calculation |
| §11: conclusion | `CandidateBridge`, `OrderExceptions`, `ConcreteCounting`, `Parameters`, `FinalAssembly`, `ClassicalReduction` | The preceding candidate and source obligations |
| §12: proportion | `Density`: dyadic-to-global lower proportion among actual primes; endpoint c/(N log N), c fixed before N | No exact Artin density assertion |

The strongest endpoint is `quantitative_prime_proportion_of_sieve_and_separate_classical_results`. The old package-based endpoints remain available but are not used to conceal assumptions.

Completion requires a theorem whose only external mathematical premises are the exact accepted cited/classical results and QRH at the specified width. The current development has not reached that criterion. `docs/remaining-obligations.md` records the outstanding interfaces and uniformity checks.
