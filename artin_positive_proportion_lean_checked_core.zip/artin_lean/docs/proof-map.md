# Proof map for the 12 October manuscript

All original deductions are complete relative to the explicit accepted cited/classical inputs. The final source-only endpoint is in `Artin/ManuscriptTheorem.lean`.

| Manuscript step | Checked development |
|---|---|
| §2: index and progression | `Arithmetic`, `NonresidueProgression`, `SourceProgression`: actual multiplicative order/index, nonresidue consequences and the cited fixed progression |
| §3: marked replacement | `MarkedReplacement`, `MarkedCriterion`, `MarkedSource`: selector invariance, character/Fourier transfer, uniform growing dyad families, actual bands and weights |
| §4: cofactor mass | `MarkedMultigroupMass`, `MarkedInfiniteMass`, `EnlargedCofactorMass`, `MarkedBandTail`, `MarkedCofactorEstimate`: convergence, exact factorization, actual tails and retained full mass; ordinary prime estimates supply the harmonic lower bound |
| §5: distribution and original mass | `PrimeDistribution`, `PrimeSmoothIntegral`, `AffineIntegral`, `LogarithmicIntegralCells`, `PrimeMassAssembly`, `FullMassComparison`, `ManuscriptMass`, `ManuscriptDistribution`, `ManuscriptTail`: uniform varying-cofactor sums, actual support, `X₀ ≍ xJ/log x`, BV and discarded mass |
| §6: local factors | `LocalSieveProducts`, `MarkedOmission`, `RoughPairNormalization`, `ClassicalSieveNormalization`: exact products, omission factors and ordinary Mertens normalization |
| §7: initial and conditioned sieve | `BuchstabSieve`, `SiftedSupport`, `InitialSieve`, `ConditionedSieve`, `ConditionedSupport`, `ConditionedAssembly`: literal arrays, growing depth, exact remainder ranges, full conditioned mass and normalized bounds |
| §7: Buchstab subtraction | `BuchstabPartition`, `BuchstabMR`, `BuchstabBoxes`, `DisjointPairSums`, `BuchstabBoxCover`, `BuchstabBinEstimate`, `BuchstabNormalization`, `BuchstabRoughReduction`, `BuchstabFiniteCover`, `BuchstabParameters`, `ManuscriptRoughBin`, `ManuscriptRough`: actual finite partition, disjoint cover, replacements, vanishing errors and final rough lower bound |
| §8: semiprimes | `RoughPairSieve`, `ActualRoughPair`, `RoughCompanion`, `SemiprimeMR`, `SemiprimeBoxes`, `SemiprimeCover`, `SemiprimeUpper`, `ManuscriptSemiprime`: source-derived pair upper bound, two replacements and actual narrow-box summation, with the constant before all marks |
| §9: candidate count | `ManuscriptCover`, `ManuscriptCandidateAssembly`, `ManuscriptTheorem`: actual survivor support, prime/composite/tail cover, fixed marking bound, harmonic lower bound, full `CandidateSieveData` construction and candidate estimate |
| §10: splitting | `DedekindZeroOrder`, `ClassicalFormula`, `KummerArithmetic`, `SourceKummer`, `SmallIndexUnion`, `ReciprocalPrimeTail`: actual continued zeta, zeros with multiplicity, ideal sums and Mellin transforms, exact source arithmetic with its fixed exceptional cutoff, and the small-index count |
| §§11–12: conclusion and proportion | `CandidateBridge`, `OrderExceptions`, `ConcreteCounting`, `Parameters`, `FinalAssembly`, `Density`, `ManuscriptTheorem`: actual primitive-root primes and a lower proportion `c/(N log N)`, with `c>0` before `N` |

`AcceptedSieveSources` contains only permitted cited/classical statements. It contains none of the original intermediate estimates listed above. The main endpoint additionally displays the accepted classical explicit-formula inputs and the literal Kummer source contracts. QRH at the desired width remains a separate explicit argument.

The checked conclusion is a positive lower proportion. It makes no assertion of the limiting Artin density or an optimal constant.
