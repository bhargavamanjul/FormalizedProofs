# Block sieve source boundary and applications

`Artin/BuchstabSieve.lean` isolates the exact finite block-sieve input from the cited OpenAI paper, Lemma 11.1 (source pages 70–72), and proves its applications to the manuscript's predecessor arrays. The source statement is a proposition argument, not a global axiom.

## Accepted source

`SourceLemma11_1` quantifies over a finite set of natural-number objects with arbitrary nonnegative real weights and arbitrary bad predicates, and a finite set of prime conditions. For local densities satisfying

- `0 ≤ g(p) ≤ 1 − η`, and
- `Σ_{v<p≤v²} g(p) ≤ C₀` for every `v > 1`,

it chooses a positive error constant `C` and depth threshold `H₀` depending only on `η,C₀`. These are chosen before the array, its weights, the prime set, the main mass, the sieving cutoff, and the even depth.

The two conclusions are exactly the source's block estimate with relative error `C exp(−H)` and product-modulus remainder up to `z^(4H+2)`, and the upper bound at depth two with remainder up to `z^10`. A single positive constant for the two source conclusions is a harmless enlargement of the source constants. Intersections are indexed by subsets of distinct primes and their main densities by products of prime local densities, so multiplicativity is built into the finite formulation. The remainder includes the empty subset (modulus one).

The finite natural-number object formulation is a specialization of the source's arbitrary finite object formulation, not a strengthening. It covers the actual prime variable `Q` and predecessor `c*r*Q+1`. Arbitrary finite sets of other objects can also be enumerated by natural numbers if needed.

## Proved original applications

1. Prime-subset intersections are exactly product-divisibility conditions. Different prime subsets have different product moduli.
2. The actual local factor is zero at primes dividing `M*r`, and `1/(p−1)` otherwise. It has the universal gap `η=1/2` at every odd prime. A reciprocal-prime block bound gives the source's block condition simultaneously for every cofactor.
3. Products of these factors equal precisely `1_{(d,Mr)=1}/φ(d)` at squarefree product moduli, using a proved totient identity for products of distinct primes.
4. Deleting primes dividing the cofactor gives the manuscript's lower local-product bound and the upper factor `exp(10τ)` from the actual omitted reciprocal sum.
5. `source_weighted_cofactor_bounds` applies the source to the actual predecessor predicates, then sums against arbitrary nonnegative cofactor/marking weights. Its source constants are chosen before `M,c`, all arrays, all cofactors, and all marking weights. In particular, no dependence on the number of marks is introduced.
6. `predecessor_blockRemainder_le` converts the source remainder to a single actual divisor-count error sum of the form used by BV, with no divisor-function weight.
7. For conditioning on a large prime `n`, intersections are exactly divisibility by `n*ℓ`, and the conditional main mass is exactly `X/(n−1)`. The pair consisting of `n` and a subset of small primes is uniquely recovered from its product. Thus `conditioned_blockRemainder_sum_le` uses the BV error once.
8. `source_conditioned_upper` combines this with the block source and returns the explicit conditional main term
   `(1+C exp(−H)) X V_r Σ_n 1/(n−1)`
   plus the single BV remainder. This theorem does not assume the manuscript's conditioned estimate.
9. For the actual initial depth `H = 2 floor(1/(40b))`, the file proves evenness, eventual adequacy for every source threshold, `exp(−H) ≤ exp(2) exp(−1/(20b))`, and the remainder range `(x^b)^(4H+2) ≤ x^(1/5+2b)`.

## Remaining assembly

These finite deductions still require the actual BV estimate and the classical reciprocal-prime/Mertens asymptotics to be inserted, followed by the already formalized cofactor-tail control and marked-replacement applications. The construction of a sufficiently fine finite Buchstab partition from continuity, and the final construction of `CandidateSieveData`, are not asserted by this module. The existing finite-partition subtraction theorem applies after the concrete bin estimates and upper-sum bound have been established.
