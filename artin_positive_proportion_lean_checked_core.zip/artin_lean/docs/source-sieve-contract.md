# Block sieve source boundary and applications

`Artin/BuchstabSieve.lean` isolates the exact finite block-sieve input from the cited OpenAI paper, Lemma 11.1 (source pages 70–72), and proves its applications to the manuscript's predecessor arrays. The source statement is a proposition argument, not a global axiom.

## Accepted source

`SourceLemma11_1` quantifies over a finite set of natural-number objects with arbitrary nonnegative real weights and arbitrary bad predicates, and a finite set of prime conditions. For local densities satisfying

- `0 ≤ g(p) ≤ 1 − η`, and
- `Σ_{v<p≤v²} g(p) ≤ C₀` for every `v > 1`,

it chooses a positive error constant `C` and depth threshold `H₀` depending only on `η,C₀`. These are chosen before the array, its weights, the prime set, the main mass, the sieving cutoff, and the even depth.

The two conclusions are exactly the source's block estimate with relative error `C exp(−H)` and product-modulus remainder up to `z^(4H+2)`, and the upper bound at depth two with remainder up to `z^10`. A single positive constant for the two source conclusions is a harmless enlargement of the source constants. Intersections are indexed by subsets of distinct primes and their main densities by products of prime local densities, so multiplicativity is built into the finite formulation. The remainder includes the empty subset (modulus one).

The finite natural-number object formulation is a specialization of the source's arbitrary finite object formulation, not a strengthening. It covers the actual prime variable `Q` and predecessor `c*r*Q+1`. Arbitrary finite sets of other objects can also be enumerated by natural numbers if needed.

## Proved original applications

1. Prime-subset intersections are exactly product-divisibility conditions. Different prime subsets have different product moduli.
2. The actual local factor is zero at primes dividing `M*r`, and `1/(p−1)` otherwise. It has the universal gap `η=1/2` at every odd prime. A reciprocal-prime block bound gives the source's block condition simultaneously for every cofactor.
3. Products of these factors equal precisely `1_{(d,Mr)=1}/φ(d)` at squarefree product moduli, using a proved totient identity for products of distinct primes.
4. Deleting primes dividing the cofactor gives the manuscript's lower local-product bound and the upper factor `exp(10τ)` from the actual omitted reciprocal sum.
5. `source_weighted_cofactor_bounds` applies the source to the actual predecessor predicates, then sums against arbitrary nonnegative cofactor/marking weights. Its source constants are chosen before `M,c`, all arrays, all cofactors, and all marking weights. In particular, no dependence on the number of marks is introduced.
6. `predecessor_blockRemainder_le` converts the source remainder to a single actual divisor-count error sum of the form used by BV, with no divisor-function weight.
7. For conditioning on a large prime `n`, intersections are exactly divisibility by `n*ℓ`, and the conditional main mass is exactly `X/(n−1)`. The pair consisting of `n` and a subset of small primes is uniquely recovered from its product. Thus `conditioned_blockRemainder_sum_le` uses the BV error once.
8. `source_conditioned_upper` combines this with the block source and returns the explicit conditional main term
   `(1+C exp(−H)) X V_r Σ_n 1/(n−1)`
   plus the single BV remainder. This theorem does not assume the manuscript's conditioned estimate.
9. For the actual initial depth `H = 2 floor(1/(40b))`, the file proves evenness, eventual adequacy for every source threshold, `exp(−H) ≤ exp(2) exp(−1/(20b))`, and the remainder range `(x^b)^(4H+2) ≤ x^(1/5+2b)`.

## Checked analytic assembly

`InitialSieve.actual_initial_lower_normalized_uniform` now inserts actual BV, cofactor omission, retained/discarded mass, and the precise classical Mertens product. Its constants `C_s,b0`, and then the cutoff `b`, precede `ε,Y,N` and all marking choices. The normalized lower bound has exponential loss `C_s exp(-1/(20b))` plus an explicitly vanishing error. Its actual sieve sum is proved equal to the prime-rough integer sum, using the fixed unit progression.

`ConditionedSieve.actual_retained_conditioned_upper` now inserts actual weighted BV and omission into the conditional source bound. It proves the growing depth `H=2 ceil((loglog x)^2)`, every source depth condition, and the product-modulus range. It returns
`(1+η) exp(20τ) V_M(W) (Σ_n 1/(n-1)) X₀ + C X₀/(log x)^A`.
The constant in its vanishing error may depend on `ε`; this does not affect the earlier fixed sieve parameters. `ConditionedSupport` and `ConditionedAssembly` complete the full conditioned-tail bridge and classical normalization, giving the exact literal conditioned mass bound.

`RoughPairSieve`, `RoughPairNormalization`, and `ActualRoughPair` also complete the actual two-variable source application. The actual lattice/CRT errors, omitted local factors, divisor-square moment, and full harmonic mass give `C X₀ V(W)^2`, with `C` chosen before all marks and small parameters. `ManuscriptSemiprime` applies the two source-derived replacements and the actual narrow boxes to prove the complete semiprime bound, with the same required ordering of constants.

`BuchstabPartition` constructs the finite density partition from classical continuity and the integral identity; the partition and its upper-sum bound are not assumed. `ManuscriptRough.actual_rough_lower_from_sources` supplies the full actual rough lower estimate; `ManuscriptCandidateAssembly` and `ManuscriptTheorem` use it to construct the actual candidate data and complete the candidate estimate. No original rough lower, bin estimate, pair estimate, or candidate theorem is classified as an accepted source.
