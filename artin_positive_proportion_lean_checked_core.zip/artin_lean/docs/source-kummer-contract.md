# Kummer explicit-formula source contract

`Artin/ClassicalFormula.lean` replaces the unspecified analytic objects in
`ClassicalKummerInputs` by concrete definitions and constructs that package.
It introduces no axioms and contains no `sorry`.

## Concrete objects

- The fields are the existing `KummerField a q`, the splitting fields over
  `ℚ` of `X^q-a`; degree and discriminant are mathlib's actual invariants.
- `fixedSplittingSmoothing` is a proved C∞ bump centred at 3/2, equal to one
  on [1,2], nonnegative, and supported in (1/2,5/2). The mass is the real
  part of its actual Mellin integral at 1, and its strict positivity is proved.
- `smoothedIdealSum` is the sum over nonzero prime ideals P and positive
  integers k of `log(N P) f((N P)^k/x)`. This is the ideal von Mangoldt
  sum, written as prime powers rather than using an arbitrary coefficient
  function.
- `DedekindZeroIndex Z` contains each continued-zeta zero in 0<Re(s)<1,
  repeated `analyticOrderNatAt Z.zeta s` times. Finite analytic order is
  proved from the identity theorem and nonzero residue, and
  `DedekindZeroIndex.covers` proves that no nontrivial zero is omitted.
- The zero weight is the norm of the actual Mellin integral at that zero.
  The zero sum is the real part of the actual complex series
  `sum x^rho * mellin(f,rho)`.
- The remainder is the difference of these actual expressions, not an
  independently chosen function.

The continued zeta is `DedekindContinuation`. The raw totalized Dirichlet
series `NumberField.dedekindZeta` is never evaluated in the critical strip
as a substitute for continuation.

## Separately accepted analytic inputs

The relevant manuscript passage is §10, “The consequence of the zero-free
strip”, proof of Lemma `lem:splitting` in
`sources/manuscript_12_october_2026.tex`.

1. `DedekindContinuationExists`: existence of the classical continuation,
   with agreement on Re(s)>1, holomorphy away from 1, and the actual
   nonzero class-number-formula residue.
2. `ClassicalDyadicZeroCount A`: for every actual number field and every
   continuation, the shell
   `k=floor(log(1+|Im rho|)/log 2)` is finite and its multiplicity-counted
   cardinality is at most
   `A (log |D_K| + [K:Q]) 4^k`. This is an explicitly weakened dyadic
   specialization of the manuscript's classical uniform bound
   `N_K(T) << (T+1)(log|D_K| + [K:Q] log(T+3))`. The numeric passage to
   this loose dyadic form remains on the cited-theorem side of the
   boundary; it is not misrepresented as a Lean deduction here.
3. `ClassicalMellinDecay f B`: on 0<=Re(s)<=1 the actual Mellin transform
   has norm at most `B 8^-k` in the same dyadic shell. This is the cubic
   vertical-decay specialization of the manuscript's rapid-decay fact.
   Repeated integration by parts and the numeric dyadic specialization
   remain on the accepted classical side.
4. `ClassicalSmoothedExplicitFormula f R T`: the actual ideal sum is
   summable and the actual remainder has absolute value at most
   `R [K:Q] log x`, simultaneously for every K and all x>1, x>=T.
   This is the manuscript's `O_f(n log(2x))` formula after increasing an
   absolute threshold to at least 2 and its constant. There is no assumed
   splitting-prime estimate, weighted zero-mass estimate, or QRH width in
   this contract.

The constants A, B, R and threshold T precede K, q, x and the QRH parameter.
No occurrence of the target small-index estimate appears in these inputs.
These four statements are explicit theorem arguments, not asserted
existence theorems in the development. The manuscript states the classical
formula and zero count without a separate pinpoint bibliography reference;
this file does not invent one or claim an independent source audit.

## Arithmetic boundary

The follow-up `Artin/KummerArithmetic.lean` constructs this arithmetic
package from three separate algebraic statements, listed below.

`KummerArithmeticFacts a Y0` separately records the exact degree identity,
normalized discriminant inequality, and an embedding from
`{p : power-residue obstruction} × Fin [K_q:Q]` into the actual nonzero
prime ideals of K_q, with each image ideal having norm p. Distinct pairs
map to distinct ideals. This expresses the complete-splitting criterion
and contains no counting estimate.

The older alternative algebra contracts are individually exposed below; the final source-only theorem instead uses the literal cited interfaces in the next section:

- `ClassicalKummerDegree`: for odd prime q and irreducible X^q-a over ℚ,
  the actual splitting field has degree q(q-1).
- `ClassicalKummerPolynomialDiscriminant`: its integer absolute
  discriminant is at most
  `(q^q |a|^(q-1))^(q-1) (q^(q-2))^q`.
  This records the pure-field polynomial discriminant, cyclotomic
  discriminant, and compositum inequality before logarithmic normalization.
- `ClassicalKummerSplitting`: for each obstruction prime p, the cardinality
  of the actual nonzero prime ideals of norm p equals the actual field
  degree. This is an individual splitting criterion, not a bound on any
  set of rational primes.

## Exact cited-source interface now checked

`Artin/SourceKummer.lean` replaces the stronger globally quantified algebra contracts at the newest endpoint by the actual cited statements:

- OpenAI, *Primitive roots for every admissible integer base* (4 October 2026), Lemma 9.1, equation (9.1), printed pages 60–61: for each fixed integer `|a|>1`, all sufficiently large prime `q` satisfy the exact degree and integer discriminant bounds. `SourceLemma9_1FieldBounds` preserves the existential exceptional cutoff `Q0(a)`; it does not claim the source's onset is `|a|`. The exact bound is `q^(q(q-2)) (q^q |a|^(q-1))^(q-1)`. The source proof cites J. Neukirch, *Algebraic Number Theory*, Chapter I §10 and Chapter III §2, for the cyclotomic and relative discriminant formulas.
- The same paper, Lemma 2.3, equation (2.5), printed page 6: the residue conditions imply complete splitting outside the primes dividing `aq`. `SourceLemma2_3Splitting` retains `p∤a` and `p≠q` explicitly and states complete splitting as the actual ideal count. `obstruction_ideal_count` proves those exclusions from the actual obstruction.

`exists_kummerArithmeticFacts_of_sources` proves the needed arithmetic package at `Y0=max(|a|,Q0)`, including logarithmic normalization and the distinct-ideal embedding. `quantitative_prime_proportion_of_sieve_and_sources` enlarges the fixed sieve threshold and connects this literal source interface to the quantitative conclusion. The zero-free assertion appearing elsewhere in source Lemma 9.1 is deliberately excluded from this arithmetic contract; `DedekindQRH N` remains a separate hypothesis.

The older `ClassicalKummerDegree` and `ClassicalKummerPolynomialDiscriminant` interfaces remain available as stronger alternative assumptions. They are not attributed verbatim to the eventual statement of Lemma 9.1, and the new source endpoint does not require them. This resolves the former exact-discriminant source-matching obligation without assuming a sharper source threshold.

The source PDF was retrieved and checked in this session from:
https://raw.githubusercontent.com/openai/math/main/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026/primitive-roots-all-integer-bases.pdf

## Deductions checked in Lean

- `weight_mass_of_dyadic_count` partitions the actual zeros into finite
  shells, compares each shell with `(A*(log|D|+n)*B) 2^-k`, proves
  summability, and sums the geometric series. Thus
  `sum |mellin(f,rho)| <= 2 A B (log|D|+n)` is derived.
- `smoothedZeroSum_triangle` proves absolute convergence and the complex
  series triangle inequality using `|x^rho|=x^(Re rho)`.
- `idealSum_dominates_powerResidueCount` uses the distinct prime ideals,
  positivity of every prime-power term, f>=1 on [1,2], and log p>=log x
  to prove the domination inequality.
- `classicalKummerInputs_of_classical` constructs the old sufficient
  package with the concrete objects and common constant `2*A*B+R`.
- `smallIndexEstimate_of_classical_theorems` combines these deductions
  with the already proved uniform prime summation and the separately
  supplied reciprocal-prime tail.

The source-based `SourceKummer.exists_smallIndexEstimate_of_sources` uses the fixed smoothing and the enlarged fixed exceptional cutoff. Its external premises are the separate classical analytic formulas and the two literal cited arithmetic statements above. No target splitting-count estimate is assumed.
