# Accepted sources and their proof obligations

The user authorizes accepting results cited in the manuscript and classical analytic results. This file records the exact boundary of the completed formalization. These results are explicit local hypotheses, with no custom global axioms. The original deductions from them are now connected to the final source-only theorem.

## Source ledger

| Source | Permitted input | Checked use in this project |
|---|---|---|
| Cureton–Thorner, *A quasi-Riemann hypothesis for Dedekind zeta functions*, Theorem 1.1, Hexagon 2610.00200v1 | The stated zero-free region for all Dedekind zeta functions at width `1/6000` | Supply this accepted result as `DedekindQRH 6000`. The continued-zeta interface, uniqueness, and restriction to zero families are now checked |
| Same OpenAI paper, Lemma 2.4 | The fixed quadratic-nonresidue progression satisfying (2.1), represented canonically modulo M | `SourceProgression.progression_of_source` converts the source Legendre-symbol statement to the actual nonsquare predicate; no general seed reproof is needed under this authorization |
| OpenAI, *Primitive roots for every admissible integer base*, 4 October 2026, Lemma 10.2 and Proposition 10.3 | Marked Type II criterion and the stated rough-sequence cancellation input | The complete marked adaptation is proved in `MarkedSource`, including growing dyad families; both the semiprime pair and Buchstab bin instantiations are complete |
| Same source, proof of Lemma 12.1 | The stated fixed-progression and smooth-weight separation facts | The fixed progression, smoothing, actual selector and parameter-order deductions are checked; see `source-marked-contract.md` |
| Same source, Lemma 11.1 and cited rough-number results in §§11–12 | Block sieve and rough-number/Buchstab estimates as actually stated | The initial and full conditioned sieves, varying cofactor sums, CRT pair estimate, semiprime removal and full Buchstab subtraction are all proved |
| Classical analytic number theory cited through Montgomery–Vaughan and Hooley | Bombieri–Vinogradov, Mertens estimates, appropriate prime-sum bounds, Dedekind-zeta explicit formula and zero counting | Correct hypotheses, partial summation/smoothing, uniformity in field and degree, summations and specialization to the actual objects |
| Algebraic statements in the cited sources, or facts already in mathlib | Kummer splitting criteria and number-field discriminant/degree theorems with an exact source match | `SourceKummer` translates source Lemmas 9.1 and 2.3, preserves their exceptional primes, and constructs the actual arithmetic package. No original splitting-count estimate is assumed |

The finite Chebyshev bounds used by `Splitting` and `Density` are already proved in mathlib; this project does not add them as assumptions. `ReciprocalPrimeTail` now proves the required reciprocal-prime tail from those bounds, so that tail is no longer an external input at the newest endpoint.

This ledger does not expand the authorization to assume arbitrary uncited algebraic claims. Every eventual external declaration needs either the precise accepted citation or a classical analytic statement within the user's authorized scope; the other deductions must be proved.

## Uniformity checks that must survive translation

- The marked coefficient criterion is quantified over every fixed logarithmic modulus exponent and frequency exponent, and every desired logarithmic saving. A criterion for only a single modulus/frequency range is insufficient.
- Multiplication by a fixed progression character changes a modulus `k` to a divisor of `lcm(M,k)`. Its logarithmic modulus range must be enlarged before applying the cited criterion.
- Selector invariance concerns multiplication by each marked prime, including repeated marked factors. A squarefree-only invariance condition would be weaker than needed.
- The number of marked groups is chosen after the finitely many roughness and dyadic bands, but before the later parameters `ε`, `Y`, and `N`. It must be independent of the invariant selector within the accepted family.
- The block-sieve remainder requires the bounded-coefficient form used in the paper, with its stated dependence on sieve depth. An arbitrary weighted divisor remainder is not interchangeable with it.
- The candidate coefficient and cofactor threshold are fixed before `N`; the threshold in `x` may depend on all previously fixed parameters.
- The splitting error requires a constant uniform in the field degree and the zero-free width. A field-dependent asymptotic alone cannot be summed over growing prime degrees.
- Summing discriminant terms uses a bound for `Σ log q`, not merely a count of the primes. This is implemented in `Splitting` and preserves the logarithm in the final denominator.

## Statements that are not external inputs

The manuscript's MR adaptation, its candidate-prime lower bound, its near-square-root semiprime estimate with the claimed constant dependence, and its final lower-bound formula are original proof obligations. They are not automatically licensed as axioms by accepting the references.

The general predicate `Q : ℝ → Prop` in `FinalAssembly` remains useful for general reductions. `ManuscriptReduction` now instantiates it with `DedekindQRH`: existence of continued Dedekind zeta functions and the bound on their nontrivial zeros. Nothing asserts QRH for every `N`.

`ClassicalKummerInputs` is not itself a cited theorem. `ClassicalFormula` and `KummerArithmetic` now construct it using actual ideal sums, Mellin transforms, multiplicity-counted zeros and separately stated source contracts. `SourceKummer` now supplies the exact cited alternative, preserving the eventual prime cutoff in source Lemma 9.1 and the ramification exclusions of Lemma 2.3. See `source-kummer-contract.md`. `CandidateSieveData` is now constructed in `ManuscriptCandidateAssembly` and `ManuscriptTheorem`; it is never an accepted input.

## References

- [Cureton–Thorner, Hexagon 2610.00200v1](https://hexagonmath.org/pdf/2610.00200v1).
- [OpenAI, Primitive roots for every admissible integer base](https://github.com/openai/math/blob/main/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026/primitive-roots-all-integer-bases.pdf).
- C. Hooley, On Artin's conjecture, *J. Reine Angew. Math.* **225** (1967), 209–220.
- H. L. Montgomery and R. C. Vaughan, *Multiplicative Number Theory I: Classical Theory*, Cambridge University Press, 2007.

## Current detailed ledgers

- `source-marked-contract.md`: exact source objects, growing-family uniformity and proved MR adaptation.
- `source-kummer-contract.md`: actual formula objects, proved deductions, and precise algebra/source boundaries.
- `source-sieve-contract.md`: block-sieve source contract and actual array specializations.
- `remaining-obligations.md`: completion record and the agreed external-input boundary.

## Additional exact classical interfaces used by the assembly

These are ordinary prime estimates, stated for their actual finite sums and products. They are explicit arguments rather than newly declared axioms:

- `ManuscriptSemiprime.ClassicalBandUpperMass`: each fixed actual band has eventual reciprocal mass at most `2 log 2`, complementing the existing lower bound `log 2 / 2`.
- `RoughPairNormalization.ClassicalMertensUpper` and `RoughCompanion.ClassicalMertensLower`: upper and lower constant multiples of `1/log y` for the ordinary product `V(y)`.
- `ClassicalSieveNormalization.ClassicalEulerMertens`: `log y * V(y) → exp(-γ)`.
- `InitialSieve.MertensLocalSource M S_M`: `S_M>0` and `log y * V_M(y) → S_M exp(-γ)` for the actual fixed-modulus sieve product. The ratio limit `V_M(W)/V(W) → S_M` is proved.
- `ClassicalSieveNormalization.ClassicalShiftedPrimeMertens`: ordinary prefix sum `Σ_{p≤y}1/(p-1) - loglog y` converges to a constant. The finite exponent-bin limit and both endpoint conventions are proved from it.
- `RoughPairNormalization.ClassicalPrimeBlockBound`: an absolute bound for `Σ_{v<p≤v²}1/p`, for every `v>1`.
- `RoughPairNormalization.ClassicalDivisorSquareMoment`: the standard bound `Σ_{n≤y}d(n)^2 ≪ y log³ y`.
- `ManuscriptDistribution.ReciprocalTotientSource`: `Σ_{n≤y}1/φ(n) ≪ log y`.

The band and bin estimates above concern ordinary primes only. They contain no marked, primitive-root, or candidate-prime conclusion.
