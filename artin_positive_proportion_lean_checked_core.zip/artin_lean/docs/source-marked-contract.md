# Marked replacement: source contract and checked deduction

`Artin.MarkedSource` supplies a checked deduction of the manuscript's progression-and-smoothing adaptation from precisely separated source and classical analytic hypotheses. It contains no new global axioms and no `sorry`.

The accepted inputs are proposition-valued theorem arguments. Giving these arguments proofs or adding reviewed external declarations is a separate step. No input below is the manuscript's MR statement, a candidate-counting theorem, or the final Artin lower bound.

## Exact objects

- `W x = exp((log x)^(6/25))` is the source roughness cutoff.
- `eulerV y` is the finite product of `1 - 1/p` over primes at most `y`.
- `densityTerm` and `density` are the simplex-integral terms and locally finite sum in source equation (10.11). The integral uses ordinary finite-dimensional product Lebesgue measure and the factor `1/j!`.
- `discrepancy γ x m` is the actual difference of rough indicators, normalized by `density γ (log m / log x) / (log x * eulerV (W x))`.
- `Bands K` requires strictly increasing exponents in `(1/10,1/5)`. Its prime sets are exactly the inclusive bands of source (10.2); its masses are their reciprocal-prime sums.
- `primeBand_eq_markedBandTail`, `Bands.group_eq_markedBandTail`, `Bands.mass_eq_markedBandTail`, and `Bands.primes_eq_markedBandTail` prove exact equality with the objects used by `MarkedBandTail`. `markedWeight_half_eq_markedBandTail` then identifies the complete normalized marking weight with the one in the marked-mass and Rankin-tail modules.
- `markedWeight b q` is the product of `ωᵢ q^(ωᵢ-1)/Vᵢ`, with zero when any count is zero. This is the source's `q^(ω-K) ∏ ωᵢ/Vᵢ` convention. `markedWeight_half` proves that damping `q=1/2` gives exactly `ConcreteSelector.markingWeight`.
- `InvariantSelector` requires the boundedness of `F` and invariance under inserting every marked prime at every positive argument, including repeated factors. `actualSelector_invariant` proves this for the existing complete-prime-power cofactor selector.
- `IntervalInDyad` represents a finite interval by inclusive integer endpoints; arbitrary real half-open intervals in a dyad have such an integer representation. `InDyad` allows an arbitrary finite subset of the second dyad, so in particular the entire half-open integer dyad.

The density is formalized by source (10.11). The manuscript also characterizes the same density by `γ⁻¹ ω_B(w/γ)`. This file does not develop Buchstab's delay differential equation or prove the equivalence of those characterizations. That equality, if the Buchstab definition is introduced independently, is an additional classical analytic identification; it is not an MR hypothesis.

## Accepted arguments

| Argument | Exact content | Source |
|---|---|---|
| `SourceLemma10_2` | Uniform scalar coefficient criterion. The first coefficient has cancellation for every fixed positive logarithmic modulus exponent, frequency exponent, and accuracy, uniformly over all coefficient subintervals and admissible family indices. Both coefficient bounds are `(log x)^C`, supports are `W`-rough, both dyads exceed `x^δ`, and their product is comparable to `x` with fixed positive constants. Conclusion is the unsmoothed marked bilinear bound of (10.5). | OpenAI, *Primitive roots for every admissible integer base*, 4 October 2026, Lemma 10.2 and its explicit uniformity statement. |
| `SourceProposition10_3` | Character-transform cancellation (10.6), and the eventual `(log x)^2` supremum bound, for the exact rough discrepancy on dyads whose full logarithmic exponent interval lies in fixed `[sLo,sHi]`, with `0<γ<sLo<sHi<1`. Dyadic product comparison is included. No marked bilinear conclusion is assumed. | The verification in the proof of the same source's Proposition 10.3. |
| `ClassicalBandMass` | Eventually each exact reciprocal band mass is at least `(log 2)/2`. | Prime number theorem and partial summation, as stated after source (10.4). This is a weaker consequence of `Vᵢ = log 2 + o(1)`. |
| `ClassicalFourierInversion` | For a genuine `C∞` compactly supported weight inside `(1,2)`, integrability, inversion, bounded total Fourier mass, and absolute tails of every logarithmic order for the explicitly defined Fourier transform and scaled kernel. | Classical Fourier inversion and integration by parts; source proof of Lemma 12.1 and manuscript §3. |

The family formulation in `SourceLemma10_2` spells out the uniformity used in its proof. A single cancellation constant and onset must work across all admissible indices; the conclusion must likewise use a single constant and onset. For a single scale, indices are pairs `(fixed-modulus character, real frequency)`. For a growing collection they are triples `(dyad index, fixed-modulus character, real frequency)`; admissibility additionally requires an active dyad and `|v| ≤ log x`. There is no inference from merely pointwise estimates in `v` to a uniform estimate.

## Quantifier order and source audit

`SourceLemma10_2` first fixes only the positive numbers `δ,C,D,q,c₁,c₂`, with `q<1`. It **then chooses `K₀`**, before the band exponents, index type, dyad functions, admissibility predicate, coefficient family, and its uniform cancellation profile. For every `K ≥ K₀`, these later data may be supplied. The output error constant and onset precede every active dyad index, first interval, second coefficient, and bounded invariant selector.

This order is justified by the source proof, not merely by the phrase “fixed data.” In the final paragraph of the proof of Lemma 10.2 (source p. 66; cached text at lines 4055–4063), the square accuracy `D₁` is chosen sufficiently large in terms of `D_*` and the coefficient-bound exponent `C`. The replacement argument then chooses moment accuracy `E₀`, arc exponent `A₀`, and `K`, in that order. The coefficient cancellation is used only afterward in the major-term estimate, with analytic accuracies chosen after `A₀`; equation (10.6) permits every such fixed accuracy. Thus the cancellation constants and thresholds influence the eventual error constant and onset, but do not enter the choice of `K`. The dyad geometry enters through the fixed lower exponent and the fixed product-comparison constants, not through the identity of the dyad functions. The source explicitly states that the logarithmic exponents used to absorb losses are independent of `K`, and that the choices are independent of the particular band exponents.

`ScaleFamily` and `ScaleCancellation` display the required uniformity for a whole indexed collection: one scale onset and one transform constant/onset for every accuracy must work for all active indices. An index can be a natural-number dyad index, with `active x j` specifying the dyads present at scale `x`. No bound on the number of active indices is required for the individual MR estimates. This is the family formulation of the source's uniform scalar estimate, not an inference from a collection of unrelated pointwise asymptotic bounds.

`SourceProposition10_3` uses the same family formulation. Its fixed exponent window `0<γ<sLo<sHi<1` is shared by every active dyad. The proof's prime-product decompositions have a common maximum number of prime factors; all prime scales have logarithms comparable to `log x` with constants from that window. Its character-counting estimate and transform bounds are uniform over permitted subintervals and dyads in that window. These are the shared transform constants needed by `ScaleCancellation`.

The old fixed-scale predicates are retained as `FixedScaleCriterion` and `FixedRoughCancellation`, but are now **proved consequences**, through `sourceLemma10_2_fixed` and `sourceProposition10_3_fixed`. They are not extra accepted inputs.

The source error constant and onset can depend on the fixed bands and on the supplied uniform cancellation profile. They do not depend on which active dyad, interval, twist, second coefficient, or selector is being evaluated. In the application, cofactor sets, fixed factors, and final-prime cutoffs occur only inside the selector. Growing dyadic families are handled by the common family constant; no maximum over a growing list of separately chosen constants is taken.

## Checked deduction

`lowFrequencyMR_of_sources` applies source Lemma 10.2 with `C=2` and `q=1/2`. The actual transform argument is proved in `MarkedCriterion`:

1. A fixed progression character multiplies a varying character at modulus `k` into a character of modulus `lcm(M,k) ≤ (log x)^(A₀+1)` eventually.
2. Rough support supplies the necessary coprimality for the product-character identity.
3. A real phase of size at most `log x` shifts the transform frequency into the source range with the frequency exponent increased by one.
4. Both twists preserve coefficient norms and rough support.

`uniformMR_of_lowFrequency` applies the proved character-orthogonality and Fourier-transfer theorems in `MarkedReplacement`. The number of characters cancels the `φ(M)` denominator. The low-frequency term uses the bounded total Fourier mass. The elementary dyad count gives a global bound of order `X (log x)^2`; a Fourier tail of order `D+2` gives the required `X (log x)^(-D)` error. Finally `X ≤ c₂x` converts to the manuscript normalization. The proof uses this sufficient crude tail bound rather than needing the manuscript's sharper `O_K(X)` observation.

`uniformMR_of_sources` combines these steps with `D=6`. Its conclusion `UniformMR` has the error constant and threshold before the interval, coefficients, and selector.

`actualSelector_MR` substitutes the proved invariant cofactor selector. `mrSum_actual_weight` identifies the finite sum exactly with the existing `ConcreteSelector.arithmeticWeight`, including the progression convention, real smooth weight, full-prime-power selector, and normalized marks. `actualArithmeticWeight_MR` is the resulting actual arithmetic-weight estimate, uniform over the cofactor set, fixed factor, and final-prime cutoff. The stronger endpoint `uniformMRFamilies_of_sources` chooses `K₀` before every dyad family and proves `UniformMRFamily`: one error constant and onset for all active dyads. `uniformMR_uniform_scales` gives the simpler fixed-scale statement with `K₀` still preceding `Hm,Hn`. `actualArithmeticWeight_MRFamily` transfers the simultaneous estimate to the existing concrete arithmetic weight. These complete the original MR adaptation, including growing dyadic collections, conditional only on the displayed source and classical facts.

## Verification

The module is checked with:

```text
/workspace/scratch/dfaac46a4f42/tmp/artin_lean_setup/with-lean.sh lake build Artin.MarkedSource
```

This establishes the deductions conditional on the displayed propositions. It does not manufacture proofs of the accepted external results, formalize Buchstab's equation, or close the separate conditioned-sieve and candidate-counting obligations.
