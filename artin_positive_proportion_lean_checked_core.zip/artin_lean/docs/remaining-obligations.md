# Completion and accepted-input boundary

Snapshot: 13 October 2026, completed continuation session. This filename is retained from the earlier checkpoints.

## Original deductions: complete

The final source-only endpoint is `Artin.quantitative_prime_proportion_of_accepted_sources`, with the `N=6000` specialization `Artin.positive_prime_proportion_at_6000_of_accepted_sources`, in `Artin/ManuscriptTheorem.lean`.

There is no remaining original candidate, rough, bin, semiprime, cofactor-tail, main-mass or splitting-count estimate assumed by those endpoints. The finite candidate structure is constructed by checked proofs. This includes the actual sets, arithmetic support, bounds on the marking weights, three error functions and all required mass inequalities.

| Previously outstanding step | Completed modules |
|---|---|
| Fixed bump, support and uniform mass/distribution | `PositiveBump`, `WeightSupport`, `MarkedScaleSupport`, `PrimeMassAssembly`, `FullMassComparison`, `ManuscriptMass`, `ManuscriptDistribution` |
| Actual retained/discarded partition and tail | `ManuscriptTail`, `MarkedOmission` |
| Initial and full conditioned sieves | `SiftedSupport`, `InitialSieve`, `ConditionedSieve`, `ConditionedSupport`, `ClassicalSieveNormalization`, `ConditionedAssembly` |
| Actual Buchstab partition, dyadic geometry, source replacement and finite subtraction | `BuchstabPartition`, `BuchstabMR`, `BuchstabBoxes`, `DisjointPairSums`, `BuchstabBoxCover`, `BuchstabBinEstimate`, `BuchstabNormalization`, `BuchstabRoughReduction`, `BuchstabFiniteCover`, `BuchstabParameters`, `ManuscriptRoughBin`, `ManuscriptRough` |
| Actual rough pair and semiprime upper bound | `RoughPairSieve`, `RoughPairNormalization`, `ActualRoughPair`, `RoughCompanion`, `SemiprimeMR`, `SemiprimeBoxes`, `SemiprimeCover`, `SemiprimeUpper`, `ManuscriptSemiprime` |
| Actual prime survivor cover and candidate construction | `ManuscriptCover`, `ManuscriptCandidateAssembly`, `ManuscriptTheorem` |
| Exact Kummer source match and exceptional cutoff | `SourceKummer`, using cited Lemmas 9.1 and 2.3, followed by the existing actual zero/ideal/Mellin deductions |

## What remains external by agreement

The accepted cited and classical results themselves are explicit hypotheses, not re-proved here. Their exact contracts appear in `AcceptedSieveSources`, `SourceKummer`, `ClassicalFormula`, and `DedekindHypothesis`. They include the specified QRH statement for the final specialization.

Lean verifies the implications from these contracts. It does not inspect the prose of a cited paper or certify its proof. The source ledgers record the mathematical translation and its limits. There is no global axiom declaring `AcceptedSieveSources` or QRH true.

Independently formalizing the accepted references would be a separate larger project. It is outside the user's agreed scope of accepting cited and classical results. No further session is required to close an original deduction of this manuscript within that scope.

## Uniformity preserved in the completed proof

- The full enlarged harmonic mass `J`, rather than a marking-dependent lower comparison with the unmarked mass, controls `X₀` and the rough pair estimate.
- The selector used by marked replacement remains invariant under inserting every marked prime, including repeated powers. The enlarged-cofactor cutoff is imposed afterward, using the proved tail.
- The two-variable estimate retains the actual cofactor weights; their supremum appears only when converting the final survivor weights to a prime count.
- Common source constants and thresholds are used over growing dyadic families. The finite Buchstab partition supplies a single maximum marking threshold.
- The semiprime constant is fixed before `κ`; the initial cutoff, local tolerance and marking choices precede `ε,Y,N`. The initial-sieve API was strengthened explicitly to preserve this ordering.
- The cited Kummer degree/discriminant statement keeps its eventual prime cutoff. Enlarging the fixed `Y₀` absorbs it before `N` is chosen.

The theorem proves a positive lower proportion of actual primes, with lower bound of the form `c/(N log N)`. It does not prove the existence or exact value of the Artin density, or optimality of this dependence on `N`.
