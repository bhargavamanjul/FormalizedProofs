/* Portability shim: answer only Lean's query for its own known executable path.
 * Does not access /proc, change permissions, or modify proof checking. */
#define _GNU_SOURCE
#include <unistd.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
ssize_t readlink(const char *path, char *buf, size_t size) {
  char own[80];
  snprintf(own, sizeof own, "/proc/%d/exe", (int)getpid());
  const char *known = getenv("ARTIN_LEAN_APP_PATH");
  if (known && strcmp(path, own) == 0) {
    size_t n = strlen(known); if (n > size) n = size;
    memcpy(buf, known, n); return n;
  }
  ssize_t (*real_readlink)(const char *, char *, size_t) = dlsym(RTLD_NEXT, "readlink");
  return real_readlink(path, buf, size);
}
