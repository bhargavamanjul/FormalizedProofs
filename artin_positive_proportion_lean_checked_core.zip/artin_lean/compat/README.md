# Verification-environment executable-path compatibility

In the hosted environment used for this build, Lean 4.35's attempt to discover its own executable through `/proc/<pid>/exe` fails before elaboration starts. The installed toolchain itself is intact.

`explicit_app_path.c` supplies the already-known executable installation path for precisely that runtime query. It performs no `/proc` access for that query, changes no permissions, and does not modify the Lean compiler, kernel, proof terms, or axiom checks. Other `readlink` calls are forwarded normally.

The shim is an environment-specific startup aid, not a project dependency. A normal installation should not need it. The checked sources can be built directly using the pinned toolchain and `lake build`.

To reproduce the hosted setup, compile the shim as a shared object and set `ARTIN_LEAN_APP_PATH` to the absolute path of the installed Lean executable and `LD_PRELOAD` to the absolute shim path. Set `LEAN_SYSROOT` and `LAKE_HOME` to the toolchain directory. No precompiled shim is included in this archive.
