module

public import Mathlib.Data.Nat.Squarefree
public import Mathlib.NumberTheory.ArithmeticFunction.Misc
public import Mathlib.Algebra.Order.BigOperators.Group.Finset
public import Mathlib.Basic.Real.Basic
public import Mathlib.Tactic.NormNum
public meta import Lean.Elab.Tactic.Omega

/-!
# Divisor bounds for the squarefree local mass

The local counts are the actual arithmetic values `p - 1` and `3 * p - 2`.
Their product over a squarefree modulus is bounded by the square of its
divisor count times the modulus.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.SquarefreeRho

/-- A true cutoff selects the three-component forbidden set. -/
def localCount (cutoff : ℕ → Bool) (p : ℕ) : ℕ :=
  if cutoff p then 3 * p - 2 else p - 1

/-- The local mass of a squarefree modulus. -/
def rho (cutoff : ℕ → Bool) (ℓ : ℕ) : ℕ :=
  ∏ p ∈ ℓ.primeFactors, localCount cutoff p

theorem localCount_le_three_mul (cutoff : ℕ → Bool) (p : ℕ) :
    localCount cutoff p ≤ 3 * p := by
  unfold localCount
  split <;> omega

theorem localCount_le_four_mul (cutoff : ℕ → Bool) (p : ℕ) :
    localCount cutoff p ≤ 4 * p := by
  exact (localCount_le_three_mul cutoff p).trans (by omega)

/-- Each prime divisor of a squarefree number can be chosen independently. -/
theorem divisorCard_squarefree {ℓ : ℕ} (hℓ : Squarefree ℓ) :
    ℓ.divisors.card = 2 ^ ℓ.primeFactors.card := by
  rw [Nat.card_divisors hℓ.ne_zero]
  calc
    (∏ p ∈ ℓ.primeFactors, (ℓ.factorization p + 1)) =
        ∏ _p ∈ ℓ.primeFactors, 2 := by
      apply Finset.prod_congr rfl
      intro p hp
      rw [Nat.factorization_eq_one_of_squarefree hℓ
        (Nat.prime_of_mem_primeFactors hp) (Nat.dvd_of_mem_primeFactors hp)]
    _ = _ := by simp

/-- A general product estimate for prime-local counts bounded by `4p`. -/
theorem prod_le_divisors_sq_mul {ℓ : ℕ} (hℓ : Squarefree ℓ)
    (v : ℕ → ℕ) (hv : ∀ p ∈ ℓ.primeFactors, v p ≤ 4 * p) :
    (∏ p ∈ ℓ.primeFactors, v p) ≤ ℓ.divisors.card ^ 2 * ℓ := by
  calc
    (∏ p ∈ ℓ.primeFactors, v p) ≤ ∏ p ∈ ℓ.primeFactors, 4 * p :=
      Finset.prod_le_prod hv
    _ = 4 ^ ℓ.primeFactors.card * ℓ := by
      rw [Finset.prod_mul_distrib, Nat.prod_primeFactors_of_squarefree hℓ]
      simp
    _ = ℓ.divisors.card ^ 2 * ℓ := by
      rw [divisorCard_squarefree hℓ, ← pow_mul, Nat.mul_comm _ 2, pow_mul]
      norm_num

theorem rho_le_divisors_sq_mul (cutoff : ℕ → Bool) {ℓ : ℕ}
    (hℓ : Squarefree ℓ) :
    rho cutoff ℓ ≤ ℓ.divisors.card ^ 2 * ℓ := by
  exact prod_le_divisors_sq_mul hℓ (localCount cutoff)
    (fun p _ => localCount_le_four_mul cutoff p)

theorem rho_le_divisors_sq_mul_real (cutoff : ℕ → Bool) {ℓ : ℕ}
    (hℓ : Squarefree ℓ) :
    (rho cutoff ℓ : ℝ) ≤ (ℓ.divisors.card : ℝ) ^ 2 * ℓ := by
  exact_mod_cast rho_le_divisors_sq_mul cutoff hℓ

end Artin.SquarefreeRho
