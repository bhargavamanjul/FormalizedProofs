module

public import Artin.SourceProgression
public import Artin.ManuscriptSemiprime
public import Artin.BuchstabMR
public import Artin.BuchstabParameters
public import Artin.ClassicalSieveNormalization
public import Artin.CofactorAsymptotics

/-!
# Explicit accepted inputs for the candidate sieve

This record groups cited results and ordinary classical analytic facts.  Its
fields retain their exact source types.  There is no candidate-counting,
marked-replacement specialization, rough lower bound, semiprime estimate,
cofactor-tail estimate, or manuscript main-mass estimate among the fields.
Those are deductions in the other modules.

The record is a proposition supplied to a theorem, not a global axiom or an
assertion that an external source has been checked by Lean.
-/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace Artin

/-- The two ordinary prime estimates used to select unmarked cofactors.
Both concern the empty marking set.  Their constants are fixed before the
cutoffs or any arithmetic weight is chosen. -/
def ClassicalCofactorProducts : Prop :=
  ∃ c₀ Y₀ : ℝ, 0 < c₀ ∧ 1 < Y₀ ∧
    (∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c₀ * Real.log Z / Real.log Y ≤
        ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
          (1 + 1 / (p : ℝ))) ∧
    (∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
        Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ (4 / 3 : ℝ) * Real.log Z)

/-- Accepted cited and classical inputs, with no original manuscript
intermediate estimate included.  Each referenced predicate displays its
full quantifiers and the actual functions to which it applies. -/
structure AcceptedSieveSources : Prop where
  /-- Cited Lemma 2.4: the nonresidue progression. -/
  source2_4 : NonresidueProgression.SourceLemma2_4
  /-- Cited Lemma 10.2: the uniform scalar marked criterion. -/
  source10_2 : MarkedSource.SourceLemma10_2
  /-- Cited Proposition 10.3: the rough discrepancy's transform estimates. -/
  source10_3 : MarkedSource.SourceProposition10_3
  /-- Cited Lemma 11.1: the finite weighted block sieve. -/
  source11_1 : BuchstabSieve.SourceLemma11_1
  /-- Classical maximal Bombieri--Vinogradov below exponent one half. -/
  bombieriVinogradov : PrimeDistribution.BombieriVinogradovSource
  /-- Classical prime number theorem in each fixed reduced progression. -/
  fixedModulusPNT : PrimeDistribution.FixedModulusPNTSource
  /-- The classical logarithmic upper bound for the reciprocal totient sum. -/
  reciprocalTotient : ManuscriptDistribution.ReciprocalTotientSource
  /-- Lower and upper consequences of the ordinary band asymptotic. -/
  bandLower : MarkedSource.ClassicalBandMass
  bandUpper : ManuscriptSemiprime.ClassicalBandUpperMass
  /-- Ordinary Fourier inversion for a compactly supported smooth weight. -/
  fourier : MarkedSource.ClassicalFourierInversion
  /-- Ordinary reciprocal-prime sums on quadratic intervals. -/
  primeBlock : RoughPairNormalization.ClassicalPrimeBlockBound
  /-- Weak upper and lower bounds for the ordinary prime Euler product. -/
  mertensUpper : RoughPairNormalization.ClassicalMertensUpper
  mertensLower : RoughCompanion.ClassicalMertensLower
  /-- The classical second moment of the ordinary divisor count. -/
  divisorSquareMoment : RoughPairNormalization.ClassicalDivisorSquareMoment
  /-- Classical continuity of the exact simplex density. -/
  densityContinuity : BuchstabMR.ClassicalDensityContinuity
  /-- Classical joint continuity, positivity, and the Buchstab identity. -/
  buchstabFacts : BuchstabPartition.ClassicalBuchstabFacts
  /-- Classical rapid convergence of the exact Buchstab density. -/
  buchstabRapid : BuchstabParameters.ClassicalBuchstabRapid
  /-- The ordinary Mertens Euler-product asymptotic. -/
  eulerMertens : ClassicalSieveNormalization.ClassicalEulerMertens
  /-- Prime Mertens in the equivalent shifted-denominator form. -/
  shiftedPrimeMertens : ClassicalSieveNormalization.ClassicalShiftedPrimeMertens
  /-- Mertens for the literal local product at each fixed positive even
  modulus; the positive constant is part of `MertensLocalSource`. -/
  localMertens : ∀ M : ℕ, 0 < M → 2 ∣ M →
    ∃ S : ℝ, InitialSieve.MertensLocalSource M S
  /-- Ordinary product and logarithmic-moment bounds before marking. -/
  cofactorProducts : ClassicalCofactorProducts

/-- The initial and conditioned sieve's shifted reciprocal-prime block
bound follows from the same ordinary prime-block input used by the pair
sieve.  Hence no duplicate analytic assumption is needed in the record. -/
theorem initial_primeBlockSource_of_classical
    (hBlock : RoughPairNormalization.ClassicalPrimeBlockBound) :
    ∃ C₀ : ℝ, 0 < C₀ ∧ InitialSieve.PrimeBlockSource C₀ := by
  classical
  obtain ⟨C, hC, hBlock⟩ := hBlock
  refine ⟨2 * C, by positivity, ?_⟩
  intro S hS v hv
  let T := S.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2)
  let U := (Nat.primesLE ⌊v ^ 2⌋₊).filter (fun p : ℕ => v < (p : ℝ))
  have hTU : T ⊆ U := by
    intro p hp
    obtain ⟨hpS, hpv, hpv2⟩ := Finset.mem_filter.mp hp
    exact Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor hpv2, (hS p hpS).1⟩, hpv⟩
  have hshift : ∀ p ∈ T, 1 / ((p : ℝ) - 1) ≤ 2 * (1 / (p : ℝ)) := by
    intro p hp
    have hp3 : (3 : ℝ) ≤ p := by
      exact_mod_cast (hS p (Finset.mem_filter.mp hp).1).2
    have hp0 : (0 : ℝ) < p := by linarith
    have hp1 : 0 < (p : ℝ) - 1 := by linarith
    rw [mul_one_div, div_le_div_iff₀ hp1 hp0]
    linarith
  calc
    _ ≤ ∑ p ∈ T, 2 * (1 / (p : ℝ)) := Finset.sum_le_sum hshift
    _ = 2 * ∑ p ∈ T, 1 / (p : ℝ) := by rw [Finset.mul_sum]
    _ ≤ 2 * ∑ p ∈ U, 1 / (p : ℝ) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact Finset.sum_le_sum_of_subset_of_nonneg hTU (by intros; positivity)
    _ ≤ 2 * C := mul_le_mul_of_nonneg_left (hBlock v hv) (by norm_num)

/-- Convenience projection with the derived shifted-prime block constant. -/
theorem AcceptedSieveSources.initialPrimeBlock (sources : AcceptedSieveSources) :
    ∃ C₀ : ℝ, 0 < C₀ ∧ InitialSieve.PrimeBlockSource C₀ :=
  initial_primeBlockSource_of_classical sources.primeBlock

end Artin
