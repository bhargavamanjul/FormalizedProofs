module

public import Mathlib.NumberTheory.DirichletCharacter.Orthogonality
public import Mathlib.NumberTheory.DirichletCharacter.Bounds
public import Mathlib.Analysis.Complex.Polynomial.Basic
public import Mathlib.RingTheory.RootsOfUnity.AlgebraicallyClosed
public import Mathlib.MeasureTheory.Integral.Bochner.Basic
public import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-!
# Progression and smooth-weight transfer for marked replacement

This file proves the finite character expansion and the analytic integration
step in Section 3.  Bounds for the *unsmoothed twisted* bilinear form remain
explicit hypotheses.  They are the place where the cited coefficient criterion
and the rough-factor character-transform estimates must be instantiated.

Neither the manuscript's marked-replacement proposition nor the candidate
counting estimate is an axiom of this file.
-/

open scoped BigOperators
open MeasureTheory

@[expose] public section

namespace Artin.MarkedReplacement

/-- A finite bilinear form. The factor `H (m*n-1)` includes the invariant
selector and marked weight; no separability of that factor is required. -/
noncomputable def bilinear (s t : Finset ℕ) (α β H : ℕ → ℂ) : ℂ :=
  ∑ m ∈ s, ∑ n ∈ t, α m * β n * H (m * n - 1)

/-- The corresponding form with a progression restriction and a weight on
its product. -/
noncomputable def progressionSum (M : ℕ) (u : ZMod M) (s t : Finset ℕ)
    (α β H Ψ : ℕ → ℂ) : ℂ :=
  ∑ m ∈ s, ∑ n ∈ t,
    if (m * n : ZMod M) = u then α m * β n * H (m * n - 1) * Ψ (m * n) else 0

/-- Exact orthogonality on a product, including factors that are not coprime
to the modulus. This is proved using mathlib's Dirichlet-character theorem. -/
theorem product_character_orthogonality (M : ℕ) [NeZero M]
    (u : ZMod M) (hu : IsUnit u) (m n : ℕ) :
    (∑ χ : DirichletCharacter ℂ M,
      χ u⁻¹ * χ (m : ZMod M) * χ (n : ZMod M)) =
      if (m * n : ZMod M) = u then (M.totient : ℂ) else 0 := by
  simpa only [← mul_assoc, ← map_mul, eq_comm] using
    DirichletCharacter.sum_char_inv_mul_char_eq ℂ hu ((m : ZMod M) * n)

/-- Multiplication by a fixed character preserves coefficient bounds. -/
theorem character_twist_norm_le (M : ℕ) (χ : DirichletCharacter ℂ M)
    (f : ℕ → ℂ) (B : ℝ) (hf : ∀ n, ‖f n‖ ≤ B) (n : ℕ) :
    ‖f n * χ (n : ZMod M)‖ ≤ B := by
  rw [norm_mul]
  exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg _)).trans
    (by simpa using hf n)

/-- A modulus produced by multiplying a fixed character with one of varying
modulus costs only the fixed factor `M`. -/
theorem lcm_modulus_le (M k : ℕ) : Nat.lcm M k ≤ M * k := by
  by_cases hM : M = 0
  · simp [hM]
  by_cases hk : k = 0
  · simp [hk]
  exact Nat.lcm_le_mul (Nat.pos_of_ne_zero hM) (Nat.pos_of_ne_zero hk)

/-- Exact finite character expansion of the progression-restricted form. -/
theorem progression_expansion (M : ℕ) [NeZero M] (u : ZMod M) (hu : IsUnit u)
    (s t : Finset ℕ) (α β H Ψ : ℕ → ℂ) :
    (M.totient : ℂ) * progressionSum M u s t α β H Ψ =
      ∑ χ : DirichletCharacter ℂ M, χ u⁻¹ *
        ∑ m ∈ s, ∑ n ∈ t,
          (α m * χ (m : ZMod M)) * (β n * χ (n : ZMod M)) *
            H (m * n - 1) * Ψ (m * n) := by
  classical
  simp only [progressionSum, Finset.mul_sum]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro n hn
  have h := product_character_orthogonality M u hu m n
  calc
    (M.totient : ℂ) *
        (if (m * n : ZMod M) = u then α m * β n * H (m*n-1) * Ψ (m*n) else 0) =
      (if (m * n : ZMod M) = u then (M.totient : ℂ) else 0) *
        (α m * β n * H (m*n-1) * Ψ (m*n)) := by split_ifs <;> ring
    _ = (∑ χ : DirichletCharacter ℂ M,
          χ u⁻¹ * χ (m : ZMod M) * χ (n : ZMod M)) *
        (α m * β n * H (m*n-1) * Ψ (m*n)) := by rw [h]
    _ = _ := by rw [Finset.sum_mul]; apply Finset.sum_congr rfl; intro χ hχ; ring

/-- Fourier inversion may be supplied as a classical analytic identity for
`Ψ`, with `phase v n = n^(iv)` and the factor `x^(-iv)` absorbed into `k`.
Finite sums then commute with the integral exactly. -/
theorem smooth_separation (s t : Finset ℕ) (α β H Ψ : ℕ → ℂ)
    (k : ℝ → ℂ) (phase : ℝ → ℕ → ℂ)
    (hinv : ∀ m ∈ s, ∀ n ∈ t,
      Ψ (m*n) = ∫ v : ℝ, k v * phase v m * phase v n)
    (hint : ∀ m ∈ s, ∀ n ∈ t,
      Integrable (fun v : ℝ => k v * phase v m * phase v n)) :
    (∑ m ∈ s, ∑ n ∈ t, α m * β n * H (m*n-1) * Ψ (m*n)) =
      ∫ v : ℝ, k v * bilinear s t
        (fun m => α m * phase v m) (fun n => β n * phase v n) H := by
  classical
  have hi : ∀ m ∈ s, ∀ n ∈ t,
      Integrable (fun v : ℝ =>
        (α m * β n * H (m*n-1)) * (k v * phase v m * phase v n)) := by
    intro m hm n hn
    exact (hint m hm n hn).const_mul _
  calc
    _ = ∑ m ∈ s, ∑ n ∈ t, ∫ v : ℝ,
        (α m * β n * H (m*n-1)) * (k v * phase v m * phase v n) := by
      apply Finset.sum_congr rfl; intro m hm
      apply Finset.sum_congr rfl; intro n hn
      rw [hinv m hm n hn, integral_const_mul]
    _ = ∫ v : ℝ, ∑ m ∈ s, ∑ n ∈ t,
        (α m * β n * H (m*n-1)) * (k v * phase v m * phase v n) := by
      rw [integral_finsetSum s (fun m hm => integrable_finsetSum t (hi m hm))]
      apply Finset.sum_congr rfl; intro m hm
      exact (integral_finsetSum t (hi m hm)).symm
    _ = _ := by
      apply integral_congr_ae
      filter_upwards [] with v
      simp only [bilinear, Finset.mul_sum]
      apply Finset.sum_congr rfl; intro m hm
      apply Finset.sum_congr rfl; intro n hn
      ring

/-- The absolute Fourier tail above the cutoff. -/
noncomputable def tailKernel (L : ℝ) (k : ℝ → ℂ) (v : ℝ) : ℝ :=
  if L < |v| then ‖k v‖ else 0

theorem tailKernel_integrable (L : ℝ) (k : ℝ → ℂ) (hk : Integrable k) :
    Integrable (tailKernel L k) := by
  change Integrable ({v : ℝ | L < |v|}.indicator (fun v => ‖k v‖))
  exact hk.norm.indicator (isOpen_lt continuous_const continuous_abs).measurableSet

/-- Integration of the uniform low-frequency estimate and a crude global
bound. The constants have no dependence on the selector in the bilinear form. -/
theorem integrate_low_frequency_bound (L E T : ℝ) (k S : ℝ → ℂ)
    (hk : Integrable k) (hE : 0 ≤ E) (_hT : 0 ≤ T)
    (hlow : ∀ v, |v| ≤ L → ‖S v‖ ≤ E)
    (hall : ∀ v, ‖S v‖ ≤ T) :
    ‖∫ v : ℝ, k v * S v‖ ≤
      E * (∫ v : ℝ, ‖k v‖) + T * (∫ v : ℝ, tailKernel L k v) := by
  have hmajor : Integrable (fun v : ℝ => E * ‖k v‖ + T * tailKernel L k v) :=
    (hk.norm.const_mul E).add ((tailKernel_integrable L k hk).const_mul T)
  calc
    _ ≤ ∫ v : ℝ, E * ‖k v‖ + T * tailKernel L k v := by
      apply norm_integral_le_of_norm_le hmajor
      filter_upwards [] with v
      rw [norm_mul]
      by_cases hv : |v| ≤ L
      · simp only [tailKernel, ite_eq_right (not_lt.mpr hv), mul_zero, add_zero]
        simpa only [mul_comm] using mul_le_mul_of_nonneg_left (hlow v hv) (norm_nonneg (k v))
      · simp only [tailKernel, ite_eq_left (lt_of_not_ge hv)]
        have ht := mul_le_mul_of_nonneg_left (hall v) (norm_nonneg (k v))
        have he := mul_nonneg hE (norm_nonneg (k v))
        nlinarith
    _ = _ := by
      rw [integral_add (hk.norm.const_mul E) ((tailKernel_integrable L k hk).const_mul T),
        integral_const_mul, integral_const_mul]

/-- The actual unit-modulus archimedean twist used after logarithmic Fourier
inversion. Defining it by the exponential avoids any branch convention. -/
noncomputable def archimedeanPhase (v : ℝ) (n : ℕ) : ℂ :=
  Complex.exp (Complex.I * ((v * Real.log n : ℝ) : ℂ))

theorem archimedeanPhase_norm (v : ℝ) (n : ℕ) : ‖archimedeanPhase v n‖ = 1 := by
  exact Complex.norm_exp_I_mul_ofReal (v * Real.log n)

theorem archimedeanPhase_mul (v : ℝ) {m n : ℕ} (hm : m ≠ 0) (hn : n ≠ 0) :
    archimedeanPhase v (m*n) = archimedeanPhase v m * archimedeanPhase v n := by
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  simp only [archimedeanPhase, Nat.cast_mul, Real.log_mul hm' hn']
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

/-- A genuine unconditional bound for the unsmoothed finite bilinear form.
This supplies the global frequency bound needed to discard the Fourier tail. -/
theorem bilinear_norm_le (s t : Finset ℕ) (α β H : ℕ → ℂ)
    (A B C : ℝ) (hA : 0 ≤ A) (hB : 0 ≤ B) (_hC : 0 ≤ C)
    (hα : ∀ m ∈ s, ‖α m‖ ≤ A) (hβ : ∀ n ∈ t, ‖β n‖ ≤ B)
    (hH : ∀ m ∈ s, ∀ n ∈ t, ‖H (m*n-1)‖ ≤ C) :
    ‖bilinear s t α β H‖ ≤ (s.card : ℝ) * (t.card : ℝ) * A * B * C := by
  unfold bilinear
  calc
    _ ≤ ∑ m ∈ s, ‖∑ n ∈ t, α m * β n * H (m*n-1)‖ := norm_sum_le _ _
    _ ≤ ∑ m ∈ s, ∑ n ∈ t, A * B * C := by
      apply Finset.sum_le_sum
      intro m hm
      calc
        _ ≤ ∑ n ∈ t, ‖α m * β n * H (m*n-1)‖ := norm_sum_le _ _
        _ ≤ _ := by
          apply Finset.sum_le_sum
          intro n hn
          simp only [norm_mul]
          exact mul_le_mul
            (mul_le_mul (hα m hm) (hβ n hn) (norm_nonneg _) hA)
            (hH m hm n hn) (norm_nonneg _) (mul_nonneg hA hB)
    _ = _ := by simp; ring

/-- The crude tail bound is unchanged by both the fixed Dirichlet character
and the actual archimedean twist. -/
theorem twisted_bilinear_norm_le (M : ℕ) (χ : DirichletCharacter ℂ M)
    (s t : Finset ℕ) (α β H : ℕ → ℂ) (v A B C : ℝ)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hC : 0 ≤ C)
    (hα : ∀ m ∈ s, ‖α m‖ ≤ A) (hβ : ∀ n ∈ t, ‖β n‖ ≤ B)
    (hH : ∀ m ∈ s, ∀ n ∈ t, ‖H (m*n-1)‖ ≤ C) :
    ‖bilinear s t (fun m => (α m * χ (m : ZMod M)) * archimedeanPhase v m)
      (fun n => (β n * χ (n : ZMod M)) * archimedeanPhase v n) H‖ ≤
      (s.card : ℝ) * (t.card : ℝ) * A * B * C := by
  apply bilinear_norm_le s t _ _ H A B C hA hB hC
  · intro m hm
    rw [norm_mul, archimedeanPhase_norm, mul_one, norm_mul]
    exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg _)).trans
      (by simpa using hα m hm)
  · intro n hn
    rw [norm_mul, archimedeanPhase_norm, mul_one, norm_mul]
    exact (mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg _)).trans
      (by simpa using hβ n hn)
  · exact hH

/-- Character orthogonality transfers a common twisted bound to a reduced
progression with no extra factor of the number of characters. -/
theorem progression_norm_le (M : ℕ) [NeZero M] (u : ZMod M) (hu : IsUnit u)
    (s t : Finset ℕ) (α β H Ψ : ℕ → ℂ) (B : ℝ)
    (hbound : ∀ χ : DirichletCharacter ℂ M,
      ‖∑ m ∈ s, ∑ n ∈ t,
        (α m * χ (m : ZMod M)) * (β n * χ (n : ZMod M)) *
          H (m*n-1) * Ψ (m*n)‖ ≤ B) :
    ‖progressionSum M u s t α β H Ψ‖ ≤ B := by
  classical
  have hφ : 0 < (M.totient : ℝ) := by
    exact_mod_cast (Nat.totient_pos.mpr (NeZero.pos M))
  have hcard : Fintype.card (DirichletCharacter ℂ M) = M.totient := by
    rw [← Nat.card_eq_fintype_card]
    exact DirichletCharacter.card_eq_totient_of_hasEnoughRootsOfUnity ℂ M
  have hb : (M.totient : ℝ) * ‖progressionSum M u s t α β H Ψ‖ ≤
      (M.totient : ℝ) * B := by
    calc
      _ = ‖(M.totient : ℂ) * progressionSum M u s t α β H Ψ‖ := by
        rw [norm_mul, Complex.norm_natCast]
      _ = ‖∑ χ : DirichletCharacter ℂ M, χ u⁻¹ *
          ∑ m ∈ s, ∑ n ∈ t,
            (α m * χ (m : ZMod M)) * (β n * χ (n : ZMod M)) *
              H (m*n-1) * Ψ (m*n)‖ := congrArg norm (progression_expansion M u hu s t α β H Ψ)
      _ ≤ ∑ χ : DirichletCharacter ℂ M, ‖χ u⁻¹ *
          ∑ m ∈ s, ∑ n ∈ t,
            (α m * χ (m : ZMod M)) * (β n * χ (n : ZMod M)) *
              H (m*n-1) * Ψ (m*n)‖ := norm_sum_le _ _
      _ ≤ ∑ _χ : DirichletCharacter ℂ M, B := by
        apply Finset.sum_le_sum
        intro χ _
        rw [norm_mul]
        exact ((mul_le_mul_of_nonneg_right (χ.norm_le_one _) (norm_nonneg _)).trans
          (by simpa using hbound χ))
      _ = (M.totient : ℝ) * B := by simp [hcard]
  nlinarith

/-- The complete finite progression-and-smoothing transfer. The only
replacement estimate assumed is the explicitly displayed unsmoothed twisted
Type-II bound `hlow`. Fourier inversion and its kernel integrability are
classical analytic inputs. To obtain the manuscript's MR proposition one must
still derive `hlow` for the actual rough discrepancy from the cited coefficient
criterion and verify the Fourier kernel bounds; this theorem does not assume
that proposition. -/
theorem smoothed_progression_bound (M : ℕ) [NeZero M]
    (u : ZMod M) (hu : IsUnit u) (s t : Finset ℕ)
    (α β H Ψ : ℕ → ℂ) (k : ℝ → ℂ) (phase : ℝ → ℕ → ℂ)
    (L E T : ℝ) (hE : 0 ≤ E) (hT : 0 ≤ T) (hk : Integrable k)
    (hinv : ∀ m ∈ s, ∀ n ∈ t,
      Ψ (m*n) = ∫ v : ℝ, k v * phase v m * phase v n)
    (hint : ∀ m ∈ s, ∀ n ∈ t,
      Integrable (fun v : ℝ => k v * phase v m * phase v n))
    (hlow : ∀ (χ : DirichletCharacter ℂ M) (v : ℝ), |v| ≤ L →
      ‖bilinear s t
        (fun m => (α m * χ (m : ZMod M)) * phase v m)
        (fun n => (β n * χ (n : ZMod M)) * phase v n) H‖ ≤ E)
    (hall : ∀ (χ : DirichletCharacter ℂ M) (v : ℝ),
      ‖bilinear s t
        (fun m => (α m * χ (m : ZMod M)) * phase v m)
        (fun n => (β n * χ (n : ZMod M)) * phase v n) H‖ ≤ T) :
    ‖progressionSum M u s t α β H Ψ‖ ≤
      E * (∫ v : ℝ, ‖k v‖) + T * (∫ v : ℝ, tailKernel L k v) := by
  apply progression_norm_le M u hu s t α β H Ψ
  intro χ
  rw [smooth_separation s t (fun m => α m * χ (m : ZMod M))
    (fun n => β n * χ (n : ZMod M)) H Ψ k phase hinv hint]
  exact integrate_low_frequency_bound L E T k _ hk hE hT (hlow χ) (hall χ)

/-- Coefficient bounds supply the Fourier-tail estimate automatically, so
the only bilinear cancellation hypothesis is the low-frequency Type-II bound. -/
theorem smoothed_progression_bound_of_coefficients (M : ℕ) [NeZero M]
    (u : ZMod M) (hu : IsUnit u) (s t : Finset ℕ)
    (α β H Ψ : ℕ → ℂ) (k : ℝ → ℂ) (L E A B C : ℝ)
    (hE : 0 ≤ E) (hA : 0 ≤ A) (hB : 0 ≤ B) (hC : 0 ≤ C)
    (hk : Integrable k)
    (hα : ∀ m ∈ s, ‖α m‖ ≤ A) (hβ : ∀ n ∈ t, ‖β n‖ ≤ B)
    (hH : ∀ m ∈ s, ∀ n ∈ t, ‖H (m*n-1)‖ ≤ C)
    (hinv : ∀ m ∈ s, ∀ n ∈ t,
      Ψ (m*n) = ∫ v : ℝ, k v * archimedeanPhase v m * archimedeanPhase v n)
    (hint : ∀ m ∈ s, ∀ n ∈ t,
      Integrable (fun v : ℝ => k v * archimedeanPhase v m * archimedeanPhase v n))
    (hlow : ∀ (χ : DirichletCharacter ℂ M) (v : ℝ), |v| ≤ L →
      ‖bilinear s t
        (fun m => (α m * χ (m : ZMod M)) * archimedeanPhase v m)
        (fun n => (β n * χ (n : ZMod M)) * archimedeanPhase v n) H‖ ≤ E) :
    ‖progressionSum M u s t α β H Ψ‖ ≤
      E * (∫ v : ℝ, ‖k v‖) +
      ((s.card : ℝ) * (t.card : ℝ) * A * B * C) * (∫ v : ℝ, tailKernel L k v) := by
  apply smoothed_progression_bound M u hu s t α β H Ψ k archimedeanPhase L E _
    hE (by positivity) hk hinv hint hlow
  intro χ v
  exact twisted_bilinear_norm_le M χ s t α β H v A B C hA hB hC hα hβ hH

end Artin.MarkedReplacement
