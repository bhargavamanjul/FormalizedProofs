module

public import Artin.ManuscriptMass

/-!
# A positive lower scale for the full arithmetic mass

The empty subset gives the unmarked cofactor `1`, hence unmarked reciprocal
mass at least one. The exact marked mass is also at least one. Together with
the proved prime-mass comparison, this supplies the weak positive lower
scale needed to absorb the semiprime replacement errors. No Mertens estimate
for the unmarked cofactors is needed for this step.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.ManuscriptMassLower

open CofactorAsymptotics MarkedCofactorEstimate MarkedBandTail ManuscriptMass

/-- The empty product always belongs to the unmarked cofactor family when
its two caps permit it. -/
theorem one_mem_cofactors (S : Finset ℕ) {R τ : ℝ} (hR : 1 ≤ R) (hτ : 0 ≤ τ) :
    1 ∈ cofactors S R τ := by
  classical
  apply Finset.mem_image.mpr
  refine ⟨∅, ?_, by simp⟩
  simp only [goodSubsets, Finset.mem_filter, Finset.mem_powerset, Finset.empty_subset,
    Finset.prod_empty, Nat.cast_one, Finset.sum_empty, true_and]
  exact ⟨hR, hτ⟩

/-- One single unmarked cofactor already contributes reciprocal mass one. -/
theorem cofactor_mass_ge_one (S : Finset ℕ) {R τ : ℝ} (hR : 1 ≤ R) (hτ : 0 ≤ τ) :
    1 ≤ mass S R τ := by
  have hh := Finset.single_le_sum (s := cofactors S R τ) (f := fun r : ℕ => 1 / (r : ℝ))
    (fun _ _ => by positivity) (one_mem_cofactors S hR hτ)
  simpa only [Nat.cast_one, div_one, mass] using hh

/-- At the actual exponential cap this lower bound holds as soon as `x≥1`. -/
theorem scaleMass_ge_one (marked : ℝ → Finset ℕ) {ε Y τ x : ℝ}
    (hε : 0 ≤ ε) (hτ : 0 ≤ τ) (hx : 1 ≤ x) :
    1 ≤ scaleMass marked ε Y τ x := by
  apply cofactor_mass_ge_one
  · apply Real.one_le_exp_iff.mpr
    exact div_nonneg (mul_nonneg hε (Real.log_nonneg hx)) (by norm_num)
  · exact hτ

/-- The genuine full enlarged mass is eventually at least one. The only
prime input is the classical mass of the fixed marked bands. -/
theorem fullMass_eventually_ge_one {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (B v₀ : ℝ) (hv₀ : 0 < v₀) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    {ε Y τ : ℝ} (hε : 0 ≤ ε) (hτ : 0 ≤ τ) :
    ∀ᶠ x : ℝ in atTop, 1 ≤ fullMass I a ε Y τ x := by
  obtain ⟨C, hC, he⟩ := actual_bands_mass_bounds I a B v₀ hv₀ hinj hclassical
  filter_upwards [he, hclassical, eventually_ge_atTop (1 : ℝ)] with x hmark hVx hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x :=
    fun i hi => hv₀.trans_le (hVx i hi).1
  have hH := scaleMass_ge_one (markedPrimes I a) hε hτ hx (Y := Y)
  have hmarked : 1 ≤ MarkedInfiniteMass.supportedMass (markedPrimes I a x)
      (marking I a x) := hmark.1
  unfold fullMass
  rw [full_mass_eq I a ε Y τ x hV]
  nlinarith

/-- The actual original arithmetic mass has a fixed positive lower scale.
Its coefficient depends only on the progression and the chosen fixed bump,
not on the marked bands, their number, or the cofactor parameters. -/
theorem actual_baseMass_lower
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    {ε Y τ : ℝ} (hε : 0 < ε) (hεmax : ε ≤ 1 / 100) (hY : (M₀ : ℝ) ≤ Y)
    (hτ : 0 ≤ τ) :
    ∀ᶠ x : ℝ in atTop,
      lowerConstant c M₀ * x / Real.log x ≤
        baseMass I a c (c * M₀) (c * v + 1) ε Y τ x := by
  have hlow : 0 < lowerConstant c M₀ :=
    (constants_positive c M₀ (by omega) (NeZero.pos M₀)).1
  filter_upwards [actual_full_mass_comparison hPNT hc hu hv I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical ε hε hεmax Y hY τ,
    fullMass_eventually_ge_one I a B v₀ hv₀ hinj hclassical hε.le hτ,
    eventually_gt_atTop (1 : ℝ)] with x hm hJ hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hh := mul_le_mul_of_nonneg_left hJ
    (show 0 ≤ lowerConstant c M₀ * x / Real.log x by positivity)
  have hh' : lowerConstant c M₀ * x / Real.log x ≤
      lowerConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x := by
    simpa only [mul_one] using hh
  exact hh'.trans hm.1

/-- The existential interface used to absorb the total replacement error. -/
theorem actual_baseMass_has_positive_lower_scale
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    {ε Y τ : ℝ} (hε : 0 < ε) (hεmax : ε ≤ 1 / 100) (hY : (M₀ : ℝ) ≤ Y)
    (hτ : 0 ≤ τ) :
    ∃ m : ℝ, 0 < m ∧ ∀ᶠ x : ℝ in atTop,
      m * x / Real.log x ≤ baseMass I a c (c * M₀) (c * v + 1) ε Y τ x :=
  ⟨lowerConstant c M₀, (constants_positive c M₀ (by omega) (NeZero.pos M₀)).1,
    actual_baseMass_lower hPNT hc hu hv I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical hε hεmax hY hτ⟩

end Artin.ManuscriptMassLower
