module

public import Artin.ConcreteSelector
public import Artin.MarkedWeights
public import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-!
# Reciprocal mass of actual marked and unmarked cofactors

The multiplication map from a marked integer and an unmarked integer is
injective. Consequently the finite weighted reciprocal mass factors exactly
over genuine natural-number cofactors, with no multiplicity in the image.
The statements below retain all powers in the marked factor.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.MarkedCofactorMass

open ConcreteSelector

/-- The genuine set of enlarged cofactors `r = s * r₀`. -/
noncomputable def enlargedCofactors (S U : Finset ℕ) : Finset ℕ :=
  (S ×ˢ U).image (fun z => z.1 * z.2)

/-- Disjoint prime supports uniquely determine the two natural factors.
The marked factor may contain repeated powers of marked primes. -/
theorem factor_pair_unique (P : Finset ℕ) {s r s' r' : ℕ}
    (hs : s ≠ 0) (hr : r ≠ 0) (hs' : s' ≠ 0) (hr' : r' ≠ 0)
    (hsp : ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hs'p : ∀ q : ℕ, q.Prime → q ∣ s' → q ∈ P)
    (hrp : ∀ q ∈ P, ¬ q ∣ r) (hr'p : ∀ q ∈ P, ¬ q ∣ r')
    (heq : s * r = s' * r') : s = s' ∧ r = r' := by
  have hstrip := congrArg (strip P) heq
  rw [strip_mul_supported P hs hr hsp, strip_mul_supported P hs' hr' hs'p,
    strip_eq_self_of_avoids P hr hrp, strip_eq_self_of_avoids P hr' hr'p] at hstrip
  refine ⟨?_, hstrip⟩
  rw [hstrip] at heq
  exact Nat.eq_of_mul_eq_mul_right (Nat.pos_of_ne_zero hr') heq

/-- The multiplication map is injective on the actual permitted finite set. -/
theorem cofactor_product_injective (P S U : Finset ℕ)
    (hS : ∀ s ∈ S, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ q ∈ P, ¬ q ∣ r) :
    Set.InjOn (fun z : ℕ × ℕ => z.1 * z.2) (↑(S ×ˢ U) : Set (ℕ × ℕ)) := by
  intro z hz w hw heq
  obtain ⟨hzS, hzU⟩ := Finset.mem_product.mp hz
  obtain ⟨hwS, hwU⟩ := Finset.mem_product.mp hw
  obtain ⟨hleft, hright⟩ := factor_pair_unique P
    (hS z.1 hzS).1 (hU z.2 hzU).1 (hS w.1 hwS).1 (hU w.2 hwU).1
    (hS z.1 hzS).2 (hS w.1 hwS).2 (hU z.2 hzU).2 (hU w.2 hwU).2 heq
  exact Prod.ext hleft hright

/-- Recovery of the marked natural factor from an enlarged cofactor. -/
theorem markedPart_product (P : Finset ℕ) {s r : ℕ}
    (hs : s ≠ 0) (hr : r ≠ 0)
    (hsp : ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hrp : ∀ q ∈ P, ¬ q ∣ r) : markedPart P (s * r) = s := by
  rw [markedPart_mul P hs hr, markedPart_eq_self_of_supported P hs hsp,
    markedPart_eq_one_of_avoids P hrp, mul_one]

/-- The finite identity underlying `J = J_P * J_0`, as a sum over distinct
natural cofactors. No independence or factorization identity is assumed. -/
theorem enlarged_reciprocal_mass (P S U : Finset ℕ) (W : ℕ → ℝ)
    (hS : ∀ s ∈ S, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ q ∈ P, ¬ q ∣ r) :
    (∑ r ∈ enlargedCofactors S U, W (markedPart P r) / (r : ℝ)) =
      (∑ s ∈ S, W s / (s : ℝ)) * (∑ r ∈ U, 1 / (r : ℝ)) := by
  classical
  unfold enlargedCofactors
  rw [Finset.sum_image (cofactor_product_injective P S U hS hU), Finset.sum_product]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro s hs
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  rw [markedPart_product P (hS s hs).1 (hU r hr).1 (hS s hs).2 (hU r hr).2,
    Nat.cast_mul]
  ring

/-- Passing to any larger candidate cofactor family preserves the product
lower bound, because all reciprocal marked weights are nonnegative. -/
theorem candidate_reciprocal_mass_ge (P S U C : Finset ℕ) (W : ℕ → ℝ)
    (hS : ∀ s ∈ S, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ q ∈ P, ¬ q ∣ r)
    (hW : ∀ n, 0 ≤ W n) (hC : enlargedCofactors S U ⊆ C) :
    (∑ s ∈ S, W s / (s : ℝ)) * (∑ r ∈ U, 1 / (r : ℝ)) ≤
      ∑ r ∈ C, W (markedPart P r) / (r : ℝ) := by
  rw [← enlarged_reciprocal_mass P S U W hS hU]
  apply Finset.sum_le_sum_of_subset_of_nonneg hC
  intro r hr _
  exact div_nonneg (hW _) (Nat.cast_nonneg _)

/-- The actual unmarked cofactors from Section 4 avoid every marked prime. -/
theorem unmarked_cofactors_avoid (P T : Finset ℕ)
    (hP : ∀ p ∈ P, p.Prime) (hT : ∀ p ∈ T, p.Prime)
    (hdisjoint : Disjoint P T) (R τ : ℝ) :
    ∀ r ∈ CofactorAsymptotics.cofactors T R τ,
      r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r := by
  intro r hr
  refine ⟨(CofactorAsymptotics.cofactor_pos T hT R τ hr).ne', ?_⟩
  intro p hp hpr
  have hpT := CofactorAsymptotics.prime_dvd_cofactor_mem T hT R τ hr (hP p hp) hpr
  exact Finset.disjoint_left.mp hdisjoint hp hpT

/-- Specialization to the manuscript's actual squarefree unmarked cofactors. -/
theorem enlarged_mass_with_unmarked_cofactors (P S T : Finset ℕ) (W : ℕ → ℝ)
    (hP : ∀ p ∈ P, p.Prime) (hT : ∀ p ∈ T, p.Prime)
    (hdisjoint : Disjoint P T)
    (hS : ∀ s ∈ S, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (R τ : ℝ) :
    (∑ r ∈ enlargedCofactors S (CofactorAsymptotics.cofactors T R τ),
      W (markedPart P r) / (r : ℝ)) =
      (∑ s ∈ S, W s / (s : ℝ)) * CofactorAsymptotics.mass T R τ := by
  exact enlarged_reciprocal_mass P S _ W hS
    (unmarked_cofactors_avoid P T hP hT hdisjoint R τ)

/-- The exact reciprocal product identity for the manuscript's actual
marking weight, expressed at the enlarged integer itself. -/
theorem enlarged_marking_mass {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P S U : Finset ℕ)
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hS : ∀ s ∈ S, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ q ∈ P, ¬ q ∣ r) :
    (∑ r ∈ enlargedCofactors S U, markingWeight I groups V r / (r : ℝ)) =
      (∑ s ∈ S, markingWeight I groups V s / (s : ℝ)) *
        (∑ r ∈ U, 1 / (r : ℝ)) := by
  have h := enlarged_reciprocal_mass P S U (markingWeight I groups V) hS hU
  simpa only [markingWeight_markedPart I groups V P _ hgroups] using h

/-- A concrete finite subfamily of the marked-supported positive integers. -/
noncomputable def squarefreeMarked (P : Finset ℕ) : Finset ℕ :=
  P.powerset.image (fun t => ∏ p ∈ t, p)

theorem squarefreeMarked_supported (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) :
    ∀ s ∈ squarefreeMarked P, s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P := by
  classical
  intro s hs
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hs
  have htP := Finset.mem_powerset.mp ht
  have hprime : ∀ p ∈ t, p.Prime := fun p hp => hP p (htP hp)
  have hpos : 0 < ∏ p ∈ t, p := Finset.prod_pos (fun p hp => (hprime p hp).pos)
  refine ⟨hpos.ne', ?_⟩
  intro q hq hqdvd
  have hmem := hq.mem_primeFactors hqdvd hpos.ne'
  rw [Nat.primeFactors_prod hprime] at hmem
  exact htP hmem

/-- The single-group finite marked Euler identity holds as a sum over the
actual distinct squarefree natural numbers. -/
theorem squarefree_group_mass (P : Finset ℕ) (V : ℝ)
    (hP : ∀ p ∈ P, p.Prime) :
    (∑ s ∈ squarefreeMarked P,
      MarkedWeights.groupWeight (primeCount P s) V / (s : ℝ)) =
      (∑ p ∈ P, (1 / (p : ℝ)) *
        ∏ q ∈ P.erase p, (1 + (1 / (q : ℝ)) / 2)) / V := by
  classical
  unfold squarefreeMarked
  rw [Finset.sum_image (Cofactor.prime_subset_product_injective P hP)]
  calc
    (∑ t ∈ P.powerset,
        MarkedWeights.groupWeight (primeCount P (∏ p ∈ t, p)) V /
          ((∏ p ∈ t, p : ℕ) : ℝ)) =
        (∑ t ∈ P.powerset, MarkedWeights.countFactor t.card *
          ∏ p ∈ t, 1 / (p : ℝ)) / V := by
      rw [Finset.sum_div]
      apply Finset.sum_congr rfl
      intro t ht
      have htP := Finset.mem_powerset.mp ht
      rw [primeCount_product_subset P t htP (fun p hp => hP p (htP hp)),
        Cofactor.reciprocal_product]
      unfold MarkedWeights.groupWeight
      ring
    _ = _ := by
      rw [MarkedWeights.finite_marked_euler_half P (fun p => 1 / (p : ℝ))
        (fun p hp => by positivity)]

/-- The normalized single-group mass is at least one, with no infinite
series argument: the displayed sum ranges over actual natural cofactors. -/
theorem squarefree_group_mass_ge_one (P : Finset ℕ) (V : ℝ)
    (hP : ∀ p ∈ P, p.Prime) (hV : 0 < V)
    (hVsum : V ≤ ∑ p ∈ P, 1 / (p : ℝ)) :
    1 ≤ ∑ s ∈ squarefreeMarked P,
      MarkedWeights.groupWeight (primeCount P s) V / (s : ℝ) := by
  rw [squarefree_group_mass P V hP,
    ← MarkedWeights.finite_marked_euler_half P (fun p => 1 / (p : ℝ))
      (fun p hp => by positivity)]
  exact MarkedWeights.finite_normalized_marked_mass_ge_one P
    (fun p => 1 / (p : ℝ)) (fun p hp => by positivity) V hV hVsum

/-- Enlarging the actual single-group cofactor set, including by prime
powers, cannot decrease its positive normalized reciprocal mass. -/
theorem supported_group_mass_ge_one (P S : Finset ℕ) (V : ℝ)
    (hP : ∀ p ∈ P, p.Prime) (hV : 0 < V)
    (hVsum : V ≤ ∑ p ∈ P, 1 / (p : ℝ)) (hS : squarefreeMarked P ⊆ S) :
    1 ≤ ∑ s ∈ S, MarkedWeights.groupWeight (primeCount P s) V / (s : ℝ) := by
  refine (squarefree_group_mass_ge_one P V hP hV hVsum).trans ?_
  apply Finset.sum_le_sum_of_subset_of_nonneg hS
  intro s hs _
  exact div_nonneg (MarkedWeights.groupWeight_nonneg _ hV) (Nat.cast_nonneg _)

end Artin.MarkedCofactorMass
