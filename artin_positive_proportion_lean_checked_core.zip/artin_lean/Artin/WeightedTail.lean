module

public import Artin.CofactorRepresentation
public import Artin.MarkedBandTail
public import Mathlib.Order.Interval.Finset.Nat

/-!
# The unsieved progression bound and the negligible weighted cofactor tail

No prime distribution theorem is used for the tail.  Counting all positive
integers in the prime variable gives `A_r ≤ x/r`; the proved Rankin tail then
beats every fixed power of the logarithm.
-/

@[expose] public section
namespace Artin.WeightedTail

open Filter
open scoped BigOperators Topology

/-- The exact crude bound used before applying distribution theorems. -/
theorem primeProgressionSum_le {c M u r : ℕ} (Qs : Finset ℕ)
    (Ψ : ℕ → ℝ) {x : ℝ} (hx : 0 ≤ x) (hc : 2 ≤ c) (hr : 0 < r)
    (hQ : ∀ Q ∈ Qs, 0 < Q)
    (hΨ : ∀ d : ℕ, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d : ℕ, 2 * x < (d : ℝ) → Ψ d = 0) :
    CofactorRepresentation.primeProgressionSum c M u Qs Ψ r ≤ x / r := by
  classical
  let T := 2 * x / ((c : ℝ) * r)
  let S := Qs.filter (fun Q => Q ≤ ⌊T⌋₊)
  have hcpos : (0 : ℝ) < c := by exact_mod_cast (by omega : 0 < c)
  have hrpos : (0 : ℝ) < r := by exact_mod_cast hr
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have hsmall : ∀ Q ∈ Qs, Q ∉ S → Ψ (c * r * Q + 1) = 0 := by
    intro Q hq hnot
    have hn : ¬ Q ≤ ⌊T⌋₊ := by simpa [S, hq] using hnot
    have hlarge : T < (Q : ℝ) := lt_of_not_ge (fun h => hn (Nat.le_floor h))
    have hh := (div_lt_iff₀ (mul_pos hcpos hrpos)).mp hlarge
    apply hsupport
    push_cast
    nlinarith
  have heq : CofactorRepresentation.primeProgressionSum c M u Qs Ψ r =
      ∑ Q ∈ S, if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0 := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro Q hq hnot
    rw [hsmall Q hq hnot]
    simp
  have hsub : S ⊆ Finset.Icc 1 ⌊T⌋₊ := by
    intro Q hq
    have hh := Finset.mem_filter.mp hq
    exact Finset.mem_Icc.mpr ⟨hQ Q hh.1, hh.2⟩
  calc
    CofactorRepresentation.primeProgressionSum c M u Qs Ψ r =
        ∑ Q ∈ S, if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0 := heq
    _ ≤ ∑ _Q ∈ S, (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro Q _
      split_ifs
      · exact (hΨ _).2
      · norm_num
    _ = (S.card : ℝ) := by simp
    _ ≤ ((Finset.Icc 1 ⌊T⌋₊).card : ℝ) := by exact_mod_cast Finset.card_le_card hsub
    _ = (⌊T⌋₊ : ℝ) := by simp
    _ ≤ T := Nat.floor_le hT
    _ ≤ x / r := by
      dsimp [T]
      rw [div_mul_eq_div_div]
      apply div_le_div_of_nonneg_right _ hrpos.le
      apply (div_le_iff₀ hcpos).mpr
      have hcc : (2 : ℝ) ≤ c := by exact_mod_cast hc
      nlinarith

/-- Finite positive weighted tails are bounded by their reciprocal mass. -/
theorem weighted_primeProgressionSum_le (R Qs : Finset ℕ)
    (t : ℕ → ℝ) (Ψ : ℕ → ℝ) {c M u : ℕ} {x : ℝ}
    (hx : 0 ≤ x) (hc : 2 ≤ c) (hr : ∀ r ∈ R, 0 < r)
    (ht : ∀ r ∈ R, 0 ≤ t r) (hQ : ∀ Q ∈ Qs, 0 < Q)
    (hΨ : ∀ d : ℕ, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d : ℕ, 2 * x < (d : ℝ) → Ψ d = 0) :
    (∑ r ∈ R, t r * CofactorRepresentation.primeProgressionSum c M u Qs Ψ r) ≤
      x * ∑ r ∈ R, t r / r := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro r hrr
  calc
    t r * CofactorRepresentation.primeProgressionSum c M u Qs Ψ r ≤
        t r * (x / r) := mul_le_mul_of_nonneg_left
          (primeProgressionSum_le Qs Ψ hx hc (hr r hrr) hQ hΨ hsupport) (ht r hrr)
    _ = x * (t r / r) := by ring

/-- The finite tail of the actual arithmetic weight is dominated by the
convergent tail over distinct enlarged integers. -/
theorem weighted_tail_le_enlarged_tail (R Qs P U : Finset ℕ)
    (W : ℕ → ℝ) (Ψ : ℕ → ℝ) {c M u : ℕ} {x X : ℝ}
    (hx : 0 ≤ x) (hc : 2 ≤ c)
    (hR : ∀ r ∈ R, 0 < r ∧ ConcreteSelector.strip P r ∈ U ∧ X < (r : ℝ))
    (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (EnlargedCofactorMass.enlargedReciprocal P U W))
    (hQ : ∀ Q ∈ Qs, 0 < Q)
    (hΨ : ∀ d : ℕ, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d : ℕ, 2 * x < (d : ℝ) → Ψ d = 0) :
    (∑ r ∈ R, W (ConcreteSelector.markedPart P r) *
      CofactorRepresentation.primeProgressionSum c M u Qs Ψ r) ≤
      x * EnlargedCofactorMass.enlargedSizeTail P U W X := by
  classical
  have hs : Summable (fun n : ℕ => if X < (n : ℝ)
      then EnlargedCofactorMass.enlargedReciprocal P U W n else 0) := by
    apply (hsum.indicator {n : ℕ | X < (n : ℝ)}).congr
    intro n
    simp only [Set.indicator_apply, Set.mem_ofPred_eq]
  have hbound := hs.sum_le_tsum R (fun n _ => by
    unfold EnlargedCofactorMass.enlargedReciprocal
    split_ifs <;> first | exact div_nonneg (hW _) (Nat.cast_nonneg _) | exact le_rfl)
  have heq : (∑ r ∈ R, if X < (r : ℝ)
      then EnlargedCofactorMass.enlargedReciprocal P U W r else 0) =
      ∑ r ∈ R, W (ConcreteSelector.markedPart P r) / (r : ℝ) := by
    apply Finset.sum_congr rfl
    intro r hr
    simp [EnlargedCofactorMass.enlargedReciprocal, (hR r hr).1,
      (hR r hr).2.1, (hR r hr).2.2]
  rw [heq] at hbound
  exact (weighted_primeProgressionSum_le R Qs (fun r => W (ConcreteSelector.markedPart P r))
    Ψ hx hc (fun r hr => (hR r hr).1) (fun r _ => hW _) hQ hΨ hsupport).trans
      (mul_le_mul_of_nonneg_left hbound hx)

/-- Stretched-exponential decay in `log x` beats every fixed log power. -/
theorem log_power_mul_tail_tendsto (A : ℝ) {t b : ℝ}
    (ht : 0 < t) (hb : 0 < b) :
    Tendsto (fun x : ℝ => (Real.log x) ^ A *
      Real.exp (-t * (Real.log x) ^ b)) atTop (𝓝 0) := by
  have h := (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (A / b) t ht).comp
    ((tendsto_rpow_atTop hb).comp Real.tendsto_log_atTop)
  apply h.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  dsimp only [Function.comp_def]
  rw [← Real.rpow_mul (Real.log_pos hx).le]
  congr 2
  field_simp

/-- In particular every prescribed logarithmic accuracy is eventually
available, with the parameters fixed before the threshold. -/
theorem eventually_tail_le_log_power (A C : ℝ) {t b : ℝ}
    (ht : 0 < t) (hb : 0 < b) :
    ∀ᶠ x : ℝ in atTop,
      C * Real.exp (-t * (Real.log x) ^ b) ≤ (Real.log x) ^ (-A) := by
  have h := (log_power_mul_tail_tendsto A ht hb).const_mul C
  have hh : ∀ᶠ x : ℝ in atTop,
      C * ((Real.log x) ^ A * Real.exp (-t * (Real.log x) ^ b)) < 1 := by
    exact (tendsto_order.mp (by simpa using h)).2 _ zero_lt_one
  filter_upwards [hh, eventually_gt_atTop (1 : ℝ)] with x hx hx1
  have hL : 0 < Real.log x := Real.log_pos hx1
  rw [Real.rpow_neg hL.le, ← one_div]
  apply (le_div_iff₀ (Real.rpow_pos_of_pos hL A)).mpr
  nlinarith only [hx]

end Artin.WeightedTail
