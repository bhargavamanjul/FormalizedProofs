module

public import Artin.CandidateBridge
public import Artin.AnalyticReduction
public import Artin.CofactorAsymptotics
public import Artin.MarkedWeights
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Finsupp.Basic
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.Positivity

/-!
# The actual marked-prime selector and candidate support

The marked part retains every power of every prime in the marked set. Removing
that part is invariant under multiplication by a marked prime even when that
prime already divides the argument. The selector used below is consequently
invariant under repeated marking, exactly as needed in the cited criterion.

The final lemmas prove support in the actual `StructuredCandidate` predicate.
The fixed progression's quadratic-nonresidue property is a separate hypothesis;
it is not inferred here from an unproved progression-selection theorem.
-/

@[expose] public section

namespace Artin.ConcreteSelector

open scoped BigOperators

/-- The full prime-power part supported on the marked set. -/
noncomputable def markedPart (P : Finset ℕ) (h : ℕ) : ℕ :=
  (h.factorization.filter (fun p => p ∈ P)).prod (· ^ ·)

/-- Delete the full marked part, not just one copy of each marked prime. -/
noncomputable def strip (P : Finset ℕ) (h : ℕ) : ℕ :=
  (h.factorization.filter (fun p => p ∉ P)).prod (· ^ ·)

/-- Exact reconstruction of a positive integer from its marked and unmarked
parts. This also proves that neither part is zero. -/
theorem markedPart_mul_strip (P : Finset ℕ) {h : ℕ} (hh : h ≠ 0) :
    markedPart P h * strip P h = h := by
  rw [markedPart, strip, Finsupp.prod_filter_mul_prod_filter_not,
    Nat.prod_factorization_pow_eq_self hh]

theorem markedPart_pos (P : Finset ℕ) {h : ℕ} (hh : h ≠ 0) :
    0 < markedPart P h := by
  have hid := markedPart_mul_strip P hh
  exact Nat.pos_of_ne_zero (fun hz => hh (by simpa [hz] using hid.symm))

theorem strip_pos (P : Finset ℕ) {h : ℕ} (hh : h ≠ 0) : 0 < strip P h := by
  have hid := markedPart_mul_strip P hh
  exact Nat.pos_of_ne_zero (fun hz => hh (by simpa [hz] using hid.symm))

theorem strip_eq_quotient (P : Finset ℕ) {h : ℕ} (hh : h ≠ 0) :
    strip P h = h / markedPart P h := by
  have hpart := markedPart_pos P hh
  calc
    strip P h = (markedPart P h * strip P h) / markedPart P h :=
      (Nat.mul_div_cancel_left _ hpart).symm
    _ = h / markedPart P h := by rw [markedPart_mul_strip P hh]

/-- Full multiplicativity of the stripped part, without any coprimality
restriction. This is what allows repeated marked primes. -/
theorem strip_mul (P : Finset ℕ) {h k : ℕ} (hh : h ≠ 0) (hk : k ≠ 0) :
    strip P (h * k) = strip P h * strip P k := by
  unfold strip
  rw [Nat.factorization_mul hh hk, Finsupp.filter_add]
  exact Finsupp.prod_add_index' (fun p => pow_zero p) (fun p m n => pow_add p m n)

theorem markedPart_mul (P : Finset ℕ) {h k : ℕ} (hh : h ≠ 0) (hk : k ≠ 0) :
    markedPart P (h * k) = markedPart P h * markedPart P k := by
  unfold markedPart
  rw [Nat.factorization_mul hh hk, Finsupp.filter_add]
  exact Finsupp.prod_add_index' (fun p => pow_zero p) (fun p m n => pow_add p m n)

/-- An integer supported entirely on the marked primes disappears completely
when stripped, including all of its prime powers. -/
theorem strip_eq_one_of_supported (P : Finset ℕ) {s : ℕ}
    (hs : ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P) : strip P s = 1 := by
  have hf : s.factorization.filter (fun p => p ∉ P) = 0 := by
    ext q
    by_cases hq : q ∈ P
    · simp [hq]
    · have hz : s.factorization q = 0 := by
        by_contra hn
        have hmem : q ∈ s.primeFactors := Finsupp.mem_support_iff.mpr hn
        exact hq (hs q (Nat.prime_of_mem_primeFactors hmem) (Nat.dvd_of_mem_primeFactors hmem))
      simp [Finsupp.filter_apply, hz]
  simp [strip, hf]

theorem markedPart_eq_self_of_supported (P : Finset ℕ) {s : ℕ} (hs0 : s ≠ 0)
    (hs : ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P) : markedPart P s = s := by
  have h := markedPart_mul_strip P hs0
  simpa only [strip_eq_one_of_supported P hs, mul_one] using h

theorem strip_mul_supported (P : Finset ℕ) {s h : ℕ} (hs0 : s ≠ 0) (hh : h ≠ 0)
    (hs : ∀ q : ℕ, q.Prime → q ∣ s → q ∈ P) : strip P (s * h) = strip P h := by
  rw [strip_mul P hs0 hh, strip_eq_one_of_supported P hs, one_mul]

/-- The complementary assertion: an integer divisible by no marked prime has
trivial marked part. -/
theorem markedPart_eq_one_of_avoids (P : Finset ℕ) {h : ℕ}
    (hh : ∀ q ∈ P, ¬ q ∣ h) : markedPart P h = 1 := by
  have hf : h.factorization.filter (fun p => p ∈ P) = 0 := by
    ext q
    by_cases hq : q ∈ P
    · simp [hq, Nat.factorization_eq_zero_of_not_dvd (hh q hq)]
    · simp [hq]
  simp [markedPart, hf]

theorem strip_eq_self_of_avoids (P : Finset ℕ) {h : ℕ} (hh0 : h ≠ 0)
    (hh : ∀ q ∈ P, ¬ q ∣ h) : strip P h = h := by
  have hid := markedPart_mul_strip P hh0
  simpa only [markedPart_eq_one_of_avoids P hh, one_mul] using hid

theorem strip_marked_prime (P : Finset ℕ) {ℓ : ℕ}
    (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) : strip P ℓ = 1 := by
  unfold strip
  rw [hℓ.factorization]
  rw [Finsupp.filter_single_of_neg (fun p => p ∉ P) (by simpa using hℓP)]
  simp

/-- The selector is invariant when an already present marked prime is
inserted again; no squarefreeness condition appears. -/
theorem strip_mul_marked_prime (P : Finset ℕ) {ℓ h : ℕ}
    (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) (hh : h ≠ 0) :
    strip P (ℓ * h) = strip P h := by
  rw [strip_mul P hℓ.ne_zero hh, strip_marked_prime P hℓ hℓP, one_mul]

theorem strip_mul_marked_prime_pow (P : Finset ℕ) {ℓ h : ℕ}
    (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) (hh : h ≠ 0) (j : ℕ) :
    strip P (ℓ ^ j * h) = strip P h := by
  induction j with
  | zero => simp
  | succ j ih =>
      have heq : ℓ ^ (j + 1) * h = ℓ * (ℓ ^ j * h) := by rw [pow_succ]; ring
      rw [heq]
      rw [strip_mul_marked_prime P hℓ hℓP (mul_ne_zero (pow_ne_zero _ hℓ.ne_zero) hh)]
      exact ih

/-- The factorization of the marked part is exactly the restricted
factorization of the original integer. -/
theorem factorization_markedPart (P : Finset ℕ) (h : ℕ) :
    (markedPart P h).factorization = h.factorization.filter (fun p => p ∈ P) := by
  unfold markedPart
  apply Nat.factorization_prod_pow_eq_self
  intro p hp
  exact Nat.prime_of_mem_primeFactors (Finset.mem_filter.mp hp).1

theorem prime_dvd_markedPart_mem (P : Finset ℕ) {h q : ℕ}
    (hh : h ≠ 0) (hq : q.Prime) (hqdvd : q ∣ markedPart P h) : q ∈ P := by
  by_contra hnot
  have hpos := hq.factorization_pos_of_dvd (ne_of_gt (markedPart_pos P hh)) hqdvd
  rw [factorization_markedPart] at hpos
  simp only [Finsupp.filter_apply, hnot, ite_false] at hpos
  exact (Nat.lt_irrefl 0) hpos

/-- The distinct marked primes in an integer are exactly the marked prime
divisors of that integer. Multiplicities are preserved by `markedPart` but do
not enter the group counts. -/
theorem primeFactors_markedPart (P : Finset ℕ) (h : ℕ) :
    (markedPart P h).primeFactors = h.primeFactors ∩ P := by
  rw [← Nat.support_factorization, factorization_markedPart, Finsupp.support_filter,
    Nat.support_factorization]
  ext p
  simp

/-- Number of distinct prime divisors in one marked group. -/
noncomputable def primeCount (G : Finset ℕ) (h : ℕ) : ℕ := (h.primeFactors ∩ G).card

theorem primeCount_markedPart (P G : Finset ℕ) (h : ℕ) (hG : G ⊆ P) :
    primeCount G (markedPart P h) = primeCount G h := by
  unfold primeCount
  rw [primeFactors_markedPart]
  congr 1
  ext p
  simp only [Finset.mem_inter]
  exact ⟨fun hp => ⟨hp.1.1, hp.2⟩, fun hp => ⟨⟨hp.1, hG hp.2⟩, hp.2⟩⟩

/-- Distinct-prime subset products have exactly the prescribed group count. -/
theorem primeCount_product_subset (G t : Finset ℕ) (ht : t ⊆ G)
    (hprime : ∀ p ∈ t, p.Prime) : primeCount G (∏ p ∈ t, p) = t.card := by
  unfold primeCount
  rw [Nat.primeFactors_prod hprime, Finset.inter_eq_left.mpr ht]

/-- The manuscript's actual product of normalized marking weights. -/
noncomputable def markingWeight {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (h : ℕ) : ℝ :=
  ∏ i ∈ I, MarkedWeights.groupWeight (primeCount (groups i) h) (V i)

theorem markingWeight_bounds {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (h : ℕ)
    (hV : ∀ i ∈ I, 0 < V i) :
    0 ≤ markingWeight I groups V h ∧
      markingWeight I groups V h ≤ ∏ i ∈ I, 1 / V i := by
  exact MarkedWeights.marked_product_bounds I (fun i => primeCount (groups i) h) V hV

/-- The actual marking weight depends only on the full marked prime-power
part, including when some marked prime occurs repeatedly. -/
theorem markingWeight_markedPart {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ) (h : ℕ)
    (hgroups : ∀ i ∈ I, groups i ⊆ P) :
    markingWeight I groups V (markedPart P h) = markingWeight I groups V h := by
  unfold markingWeight
  apply Finset.prod_congr rfl
  intro i hi
  rw [primeCount_markedPart P (groups i) h (hgroups i hi)]

/-- A witness for the manuscript's selector on `h = d-1`. The cofactor set
is a genuine finite set of natural numbers; the final prime may be required
to exceed the real cutoff `Qmin`. -/
def SelectionWitness (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) (h r₀ Q : ℕ) : Prop :=
  r₀ ∈ allowed ∧ Q.Prime ∧ Qmin < (Q : ℝ) ∧ strip P h = c * r₀ * Q

def Selected (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (h : ℕ) : Prop :=
  ∃ r₀ Q : ℕ, SelectionWitness P c allowed Qmin h r₀ Q

/-- This is an actual indicator function, not an unspecified invariant
selector supplied as a hypothesis. -/
noncomputable def selector (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) (h : ℕ) : ℝ := by
  classical
  exact if Selected P c allowed Qmin h then 1 else 0

theorem selector_bounds (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) (h : ℕ) : 0 ≤ selector P c allowed Qmin h ∧
      selector P c allowed Qmin h ≤ 1 := by
  classical
  unfold selector
  split_ifs <;> norm_num

theorem selector_ne_zero_iff (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) (h : ℕ) :
    selector P c allowed Qmin h ≠ 0 ↔ Selected P c allowed Qmin h := by
  classical
  unfold selector
  split_ifs <;> simp_all

/-- The actual weight on `d`: the fixed progression indicator, a smooth
product-support weight, the invariant selector, and the marking product.
The application chooses `Ψ d = Ψ₀(d/x)` and the marked groups as functions of
`x`; each such choice is a concrete instance of this definition. -/
noncomputable def arithmeticWeight {ι : Type*} (M u : ℕ) (Ψ : ℕ → ℝ)
    (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (d : ℕ) : ℝ :=
  if d % M = u then
    Ψ d * selector P c allowed Qmin (d - 1) * markingWeight I groups V (d - 1)
  else 0

/-- Uniform domination of the actual arithmetic weight, with no dependence on
the size of `d` or on the exponents of its marked prime divisors. -/
theorem arithmeticWeight_bounds {ι : Type*} (M u : ℕ) (Ψ : ℕ → ℝ)
    (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (d : ℕ)
    (hΨ : 0 ≤ Ψ d ∧ Ψ d ≤ 1) (hV : ∀ i ∈ I, 0 < V i) :
    0 ≤ arithmeticWeight M u Ψ I groups V P c allowed Qmin d ∧
      arithmeticWeight M u Ψ I groups V P c allowed Qmin d ≤ ∏ i ∈ I, 1 / V i := by
  have hsel := selector_bounds P c allowed Qmin (d - 1)
  have hw := markingWeight_bounds I groups V (d - 1) hV
  have hp0 : 0 ≤ Ψ d * selector P c allowed Qmin (d - 1) := mul_nonneg hΨ.1 hsel.1
  have hp1 : Ψ d * selector P c allowed Qmin (d - 1) ≤ 1 := by
    have hh := mul_le_mul hΨ.2 hsel.2 hsel.1 (by norm_num : (0 : ℝ) ≤ 1)
    simpa using hh
  unfold arithmeticWeight
  split_ifs
  · exact ⟨mul_nonneg hp0 hw.1,
      by simpa using mul_le_mul hp1 hw.2 hw.1 (by norm_num : (0 : ℝ) ≤ 1)⟩
  · exact ⟨le_rfl, hw.1.trans hw.2⟩

/-- Every nonzero arithmetic weight really obeys the fixed progression and
has a witness for the concrete cofactor selector. -/
theorem arithmeticWeight_ne_zero_support {ι : Type*} (M u : ℕ) (Ψ : ℕ → ℝ)
    (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (d : ℕ)
    (hw : arithmeticWeight M u Ψ I groups V P c allowed Qmin d ≠ 0) :
    d % M = u ∧ Selected P c allowed Qmin (d - 1) := by
  classical
  unfold arithmeticWeight at hw
  split_ifs at hw with hprog
  · refine ⟨hprog, (selector_ne_zero_iff P c allowed Qmin (d - 1)).mp ?_⟩
    intro hz
    simp [hz] at hw
  · exact False.elim (hw rfl)

theorem selected_mul_marked_prime (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) {ℓ h : ℕ} (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) (hh : h ≠ 0) :
    Selected P c allowed Qmin (ℓ * h) ↔ Selected P c allowed Qmin h := by
  unfold Selected SelectionWitness
  rw [strip_mul_marked_prime P hℓ hℓP hh]

theorem selector_mul_marked_prime (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) {ℓ h : ℕ} (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) (hh : h ≠ 0) :
    selector P c allowed Qmin (ℓ * h) = selector P c allowed Qmin h := by
  classical
  unfold selector
  rw [selected_mul_marked_prime P c allowed Qmin hℓ hℓP hh]

/-- Repeated-prime invariance in its directly reusable form. -/
theorem selector_mul_marked_prime_pow (P : Finset ℕ) (c : ℕ) (allowed : Finset ℕ)
    (Qmin : ℝ) {ℓ h : ℕ} (hℓ : ℓ.Prime) (hℓP : ℓ ∈ P) (hh : h ≠ 0) (j : ℕ) :
    selector P c allowed Qmin (ℓ ^ j * h) = selector P c allowed Qmin h := by
  classical
  unfold selector Selected SelectionWitness
  rw [strip_mul_marked_prime_pow P hℓ hℓP hh j]

/-- A selected prime whose enlarged cofactor is below the cutoff has exactly
the arithmetic structure required by the final index argument. -/
theorem structuredCandidate_of_selection
    {a : ℤ} {P : Finset ℕ} {allowed : Finset ℕ} {c Y R p r₀ Q : ℕ} {Qmin : ℝ}
    (hp : p.Prime) (hp2 : p ≠ 2) (ha : (a : ZMod p) ≠ 0)
    (hns : ¬ IsSquare (a : ZMod p)) (hc : c = 2 ∨ c = 4)
    (hmarked : ∀ q ∈ P, Y < q)
    (hallowedpos : ∀ r ∈ allowed, 0 < r)
    (hallowedrough : ∀ r ∈ allowed, ∀ q : ℕ,
      q.Prime → q ∣ r → q ≠ 2 → Y < q)
    (hsel : SelectionWitness P c allowed Qmin (p - 1) r₀ Q)
    (hsize : markedPart P (p - 1) * r₀ ≤ R) :
    StructuredCandidate a Y R p := by
  have hh : p - 1 ≠ 0 := by have := hp.two_le; omega
  obtain ⟨hr₀, hQ, _hQmin, hstrip⟩ := hsel
  have hfactor : p - 1 = c * (markedPart P (p - 1) * r₀) * Q := by
    calc
      p - 1 = markedPart P (p - 1) * strip P (p - 1) := (markedPart_mul_strip P hh).symm
      _ = _ := by rw [hstrip]; ring
  refine ⟨hp, hp2, ha, hns, c, markedPart P (p - 1) * r₀, Q, hc,
    Nat.mul_pos (markedPart_pos P hh) (hallowedpos r₀ hr₀), hQ, hsize, hfactor, ?_⟩
  intro q hq hqdiv hq2
  rcases hq.dvd_mul.mp hqdiv with hpart | hr
  · exact hmarked q (prime_dvd_markedPart_mem P hh hq hpart)
  · exact hallowedrough r₀ hr₀ q hq hr hq2

/-- The actual finite prime set retained after the cofactor tail is removed.
The quadratic nonresidue condition may later be enforced by the fixed
progression, but is part of this set's definition rather than a support axiom. -/
noncomputable def selectedPrimeSurvivors (a : ℤ) (P : Finset ℕ) (c : ℕ)
    (allowed : Finset ℕ) (Qmin ε x : ℝ) : Finset ℕ := by
  classical
  exact (ambientPrimes x).filter (fun p =>
    ¬ IsSquare (a : ZMod p) ∧
      ∃ r₀ Q : ℕ, SelectionWitness P c allowed Qmin (p - 1) r₀ Q ∧
        markedPart P (p - 1) * r₀ ≤ ⌊x ^ ε⌋₊)

/-- Membership in the explicitly constructed survivor set implies membership
in the actual candidate set. All factorization and roughness implications are
proved here; there is no final candidate-support hypothesis. -/
theorem selectedPrimeSurvivors_support
    {a : ℤ} {P : Finset ℕ} {allowed : Finset ℕ} {c : ℕ} {Qmin ε Y x : ℝ}
    (hx : 2 < x) (hc : c = 2 ∨ c = 4)
    (hmarked : ∀ q ∈ P, ⌊Y⌋₊ < q)
    (hallowedpos : ∀ r ∈ allowed, 0 < r)
    (hallowedrough : ∀ r ∈ allowed, ∀ q : ℕ,
      q.Prime → q ∣ r → q ≠ 2 → ⌊Y⌋₊ < q)
    {p : ℕ} (hp : p ∈ selectedPrimeSurvivors a P c allowed Qmin ε x) :
    p ∈ ambientPrimes x ∧ StructuredCandidate a ⌊Y⌋₊ ⌊x ^ ε⌋₊ p := by
  classical
  obtain ⟨hpambient, hns, r₀, Q, hsel, hsize⟩ := Finset.mem_filter.mp hp
  have hprime : p.Prime := (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpambient).1).2
  have hxp : x < (p : ℝ) := (Finset.mem_filter.mp hpambient).2
  have hp2 : p ≠ 2 := by
    intro heq
    rw [heq] at hxp
    norm_num at hxp
    linarith
  have ha : (a : ZMod p) ≠ 0 := by
    intro heq
    apply hns
    rw [heq]
    exact ⟨0, by simp⟩
  exact ⟨hpambient, structuredCandidate_of_selection hprime hp2 ha hns hc hmarked
    hallowedpos hallowedrough hsel hsize⟩

/-- The cardinality comparison with the manuscript's actual candidate count. -/
theorem selectedPrimeSurvivors_card_le
    {a : ℤ} {P : Finset ℕ} {allowed : Finset ℕ} {c : ℕ} {Qmin ε Y x : ℝ}
    (hx : 2 < x) (hc : c = 2 ∨ c = 4)
    (hmarked : ∀ q ∈ P, ⌊Y⌋₊ < q)
    (hallowedpos : ∀ r ∈ allowed, 0 < r)
    (hallowedrough : ∀ r ∈ allowed, ∀ q : ℕ,
      q.Prime → q ∣ r → q ≠ 2 → ⌊Y⌋₊ < q) :
    ((selectedPrimeSurvivors a P c allowed Qmin ε x).card : ℝ) ≤
      structuredCandidateCount a ε Y x := by
  classical
  unfold structuredCandidateCount filteredCard
  apply Nat.cast_le.mpr
  apply Finset.card_le_card
  intro p hp
  exact Finset.mem_filter.mpr
    (selectedPrimeSurvivors_support hx hc hmarked hallowedpos hallowedrough hp)

/-- Any weighted lower bound on the explicitly defined prime survivors
converts to the required actual candidate count, paying only the fixed
pointwise bound on the marking weight. -/
theorem selectedPrimeSurvivors_weighted_count_le
    {a : ℤ} {P : Finset ℕ} {allowed : Finset ℕ} {c : ℕ} {Qmin ε Y x B : ℝ}
    (w : ℕ → ℝ) (hx : 2 < x) (hc : c = 2 ∨ c = 4) (hB : 0 ≤ B)
    (hmarked : ∀ q ∈ P, ⌊Y⌋₊ < q)
    (hallowedpos : ∀ r ∈ allowed, 0 < r)
    (hallowedrough : ∀ r ∈ allowed, ∀ q : ℕ,
      q.Prime → q ∣ r → q ≠ 2 → ⌊Y⌋₊ < q)
    (hweight : ∀ p ∈ selectedPrimeSurvivors a P c allowed Qmin ε x, w p ≤ B) :
    (∑ p ∈ selectedPrimeSurvivors a P c allowed Qmin ε x, w p) ≤
      B * structuredCandidateCount a ε Y x := by
  have hcount := selectedPrimeSurvivors_card_le (a := a) (Qmin := Qmin) (ε := ε)
    hx hc hmarked hallowedpos hallowedrough
  calc
    _ ≤ ((selectedPrimeSurvivors a P c allowed Qmin ε x).card : ℝ) * B :=
      weighted_sum_le_card_mul _ w B hweight
    _ ≤ structuredCandidateCount a ε Y x * B :=
      mul_le_mul_of_nonneg_right hcount hB
    _ = _ := mul_comm _ _

/-- Instantiate candidate support for the actual cofactor family of Section 4.
The positive and rough cofactor properties are proved from membership in that
family, instead of being retained as hypotheses. -/
theorem selectedPrimeSurvivors_support_from_cofactors
    {a : ℤ} {P : Finset ℕ} {c : ℕ} {Qmin ε Y Z R₀ τ x : ℝ}
    (hx : 2 < x) (hY : 0 ≤ Y) (hc : c = 2 ∨ c = 4)
    (hmarked : ∀ q ∈ P, Y < (q : ℝ))
    {p : ℕ} (hp : p ∈ selectedPrimeSurvivors a P c
      (CofactorAsymptotics.cofactors (CofactorAsymptotics.unmarkedPrimes P Y Z) R₀ τ)
      Qmin ε x) :
    p ∈ ambientPrimes x ∧ StructuredCandidate a ⌊Y⌋₊ ⌊x ^ ε⌋₊ p := by
  classical
  have hprimes : ∀ q ∈ CofactorAsymptotics.unmarkedPrimes P Y Z, q.Prime :=
    fun _ hq => CofactorAsymptotics.unmarkedPrimes_prime P Y Z hq
  apply selectedPrimeSurvivors_support hx hc
    (fun q hq => (Nat.floor_lt hY).mpr (hmarked q hq)) ?_ ?_ hp
  · intro r hr
    exact CofactorAsymptotics.cofactor_pos _ hprimes R₀ τ hr
  · intro r hr q hq hqr _hq2
    have hmem := CofactorAsymptotics.prime_dvd_cofactor_mem _ hprimes R₀ τ hr hq hqr
    have hYq : Y < (q : ℝ) := (Finset.mem_filter.mp hmem).2.2.1
    exact (Nat.floor_lt hY).mpr hYq

end Artin.ConcreteSelector
