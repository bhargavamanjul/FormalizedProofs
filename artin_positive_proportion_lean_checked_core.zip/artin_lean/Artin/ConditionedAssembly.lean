module

public import Artin.ConditionedSieve
public import Artin.ClassicalSieveNormalization
public import Artin.ConditionedSupport
public import Artin.BuchstabMR

/-!
# Normalizing the full conditioned sieve

The classical Euler and prime-harmonic limits identify the main coefficient.
The positive gap between the two fixed bin endpoints absorbs all logarithmic
errors, preserving the same singular-series constant as the initial sieve.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter
namespace Artin.ConditionedAssembly
open ClassicalSieveNormalization InitialSieve MarkedSource
  ManuscriptMass ManuscriptTail ManuscriptCover ConditionedSupport ConditionedSieve
  MarkedBandTail ManuscriptDistribution

/-- The ordinary Euler product at the actual roughness cutoff has the
expected logarithmic size. -/
theorem W_euler_normalization (hEuler : ClassicalEulerMertens) :
    Tendsto (fun x : ℝ => (Real.log x) ^ (6 / 25 : ℝ) * eulerV (W x))
      atTop (𝓝 (Real.exp (-Real.eulerMascheroniConstant))) := by
  have hh := hEuler.comp RoughCompanion.W_tendsto
  change Tendsto (fun x : ℝ => Real.log (W x) * eulerV (W x)) atTop
    (𝓝 (Real.exp (-Real.eulerMascheroniConstant))) at hh
  simpa only [W, Real.log_exp] using hh

/-- A squared-logarithmic error is negligible relative to the actual rough
Euler product. This is derived from ordinary Mertens, not a new sieve input. -/
theorem inverse_log_sq_euler_tendsto (hEuler : ClassicalEulerMertens) :
    Tendsto (fun x : ℝ => 1 / ((Real.log x) ^ 2 * eulerV (W x))) atTop (𝓝 0) := by
  have hnum := (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 44/25)).comp
    Real.tendsto_log_atTop
  have hratio := hnum.div (W_euler_normalization hEuler) (Real.exp_pos _).ne'
  simp only [zero_div] at hratio
  apply hratio.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  have hL : 0 < Real.log x := Real.log_pos hx
  change (Real.log x) ^ (-(44 / 25 : ℝ)) /
    ((Real.log x) ^ (6 / 25 : ℝ) * eulerV (W x)) =
    1 / ((Real.log x) ^ 2 * eulerV (W x))
  rw [div_mul_eq_div_div, div_mul_eq_div_div, ← Real.rpow_sub hL]
  norm_num

/-- Classical normalization of a raw conditioned upper bound. The only
remaining premise is the explicit unnormalized estimate proved by the source
and support modules; all scalar error absorption is performed here. -/
theorem normalize_raw_conditioned_upper
    {M : ℕ} {S_M γ γ' η τ C : ℝ}
    (hLocal : MertensLocalSource M S_M) (hEuler : ClassicalEulerMertens)
    (hPrime : ClassicalShiftedPrimeMertens) (hγ : 0 < γ) (hγγ' : γ < γ')
    (hη : 0 < η) (X F : ℝ → ℝ)
    (hX : ∀ᶠ x : ℝ in atTop, 0 ≤ X x)
    (hraw : ∀ᶠ x : ℝ in atTop,
      F x ≤ ((1 + η / 2) * Real.exp (20 * τ) * localSieveProduct M (W x) *
        (∑ p ∈ primeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1))) * X x +
        C * X x / (Real.log x) ^ 2) :
    ∀ᶠ x : ℝ in atTop,
      F x ≤ (1 + η) * Real.exp (20 * τ) * S_M * X x * eulerV (W x) *
        Real.log (γ' / γ) := by
  have hbin := primeInterval_power_sum_tendsto hPrime hγ hγγ'.le
  have hlocal := localProduct_W_ratio_tendsto hLocal hEuler
  have he := (inverse_log_sq_euler_tendsto hEuler).const_mul C
  have hcoef := (((hlocal.mul hbin).const_mul
    ((1 + η / 2) * Real.exp (20 * τ))).add he)
  simp only [mul_zero, add_zero] at hcoef
  have hlog : 0 < Real.log (γ' / γ) :=
    Real.log_pos ((one_lt_div hγ).mpr hγγ')
  have hbase : 0 < Real.exp (20 * τ) * S_M * Real.log (γ' / γ) :=
    mul_pos (mul_pos (Real.exp_pos _) hLocal.1) hlog
  have hgap : ((1 + η / 2) * Real.exp (20 * τ)) * (S_M * Real.log (γ' / γ)) <
      (1 + η) * Real.exp (20 * τ) * S_M * Real.log (γ' / γ) := by
    have hp := mul_pos (show 0 < η / 2 by positivity) hbase
    nlinarith only [hp]
  have hcoefe := hcoef.eventually (eventually_lt_nhds hgap)
  filter_upwards [hraw, hX, hcoefe, eventually_gt_atTop (1 : ℝ)] with x hraw hX hcoef hx
  have hL : Real.log x ≠ 0 := (Real.log_pos hx).ne'
  have hV : 0 < eulerV (W x) := RoughCompanion.eulerV_pos _
  have hm := mul_le_mul_of_nonneg_right hcoef.le (mul_nonneg hX hV.le)
  have heq :
      (((1 + η / 2) * Real.exp (20 * τ)) *
          ((localSieveProduct M (W x) / eulerV (W x)) *
            (∑ p ∈ primeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1))) +
          C * (1 / ((Real.log x) ^ 2 * eulerV (W x)))) * (X x * eulerV (W x)) =
        ((1 + η / 2) * Real.exp (20 * τ) * localSieveProduct M (W x) *
          (∑ p ∈ primeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1))) * X x +
          C * X x / (Real.log x) ^ 2 := by
    field_simp
  rw [heq] at hm
  apply hraw.trans
  convert hm using 1
  ring

/-- The two literal formulations of the conditioned rough-integer mass agree
when the conditioning set consists of primes. -/
theorem roughConditionedMass_eq_conditionedMass
    {ι : Type*} (I : Finset ι) (a : ι → ℝ) (c M u : ℕ)
    (ε Y τ x : ℝ) (N : Finset ℕ) (hN : ∀ n ∈ N, n.Prime) :
    roughConditionedMass I a c M u ε Y τ x N =
      BuchstabMR.conditionedMass (Finset.Icc 2 ⌊2 * x⌋₊) N
        (integerWeight I a c M u ε Y τ x) (W x) := by
  classical
  unfold roughConditionedMass BuchstabMR.conditionedMass
  apply Finset.sum_congr rfl
  intro n hn
  rw [if_pos (hN n hn)]
  simp only [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro d hd
  unfold RoughCompanion.realRoughIndicator
  split_ifs <;> simp_all

/-- Complete upper bound for the original prime-divisor-conditioned rough
mass. The actual growing-depth sieve, exact support expansion, marked tail,
weighted distribution theorem, and classical normalization are all applied.
Only cited source theorems and precise classical analytic limits are inputs. -/
theorem actual_rough_conditioned_bin_upper
    (source : BuchstabSieve.SourceLemma11_1) (C₀ : ℝ)
    (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ γ γ' η τ S_M : ℝ} (hε : 0 < ε) (hεκ : ε < κ)
    (hκ : κ < 1 / 100) (hεγ : ε < γ) (hγγ' : γ < γ')
    (hγ' : γ' ≤ 1/2 - κ) (hη : 0 < η) (hτ : 0 < τ)
    (hLocal : MertensLocalSource (c * M₀) S_M)
    (hEuler : ClassicalEulerMertens) (hPrime : ClassicalShiftedPrimeMertens)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ)
    (hmin : (1/10 : ℝ) ≤ amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (Y : ℝ) (hY : (M₀ : ℝ) ≤ Y) :
    ∀ᶠ x : ℝ in atTop,
      roughConditionedMass I a c (c * M₀) (c * v + 1) ε Y τ x
          (primeInterval (x ^ γ) (x ^ γ')) ≤
        (1 + η) * Real.exp (20 * τ) * S_M *
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x * eulerV (W x) *
            Real.log (γ' / γ) := by
  classical
  have hγ : 0 < γ := hε.trans hεγ
  have hminpos : 0 < amin := by linarith
  have hεmax : ε ≤ 1/100 := (hεκ.trans hκ).le
  have hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, 0 < bandMass (a i) x := by
    filter_upwards [hclassical] with x hx i hi
    exact hv₀.trans_le (hx i hi).1
  obtain ⟨C, hC, hret⟩ := actual_retained_conditioned_upper source C₀ hBlock hBV hPNT hTot
    hc hu hv huM hε hεκ hκ (show (0 : ℝ) < 2 by norm_num)
  have hret' := hret γ (η / 2) hεγ (by positivity) I a amin amax B v₀
    hmin hmax hv₀ ha hinj hclassical Y hY τ hτ
  have hsupport := eventually_conditionedBaseMass_le_retained I a amin amax hminpos hmax
    ha hV c (c * M₀) (c * v + 1) (by omega) ε Y τ γ hεmax hγ
  have htail := actual_discardedMass_le_base_over_log_power hPNT hc hu hv I a
    amin amax B v₀ hminpos hmax hv₀ ha hinj hclassical 2 1 (by norm_num)
    ε hε hεmax Y hY τ
  apply normalize_raw_conditioned_upper (C := C + 2 / γ) hLocal hEuler hPrime
    hγ hγγ' hη (baseMass I a c (c * M₀) (c * v + 1) ε Y τ)
    (fun x => roughConditionedMass I a c (c * M₀) (c * v + 1) ε Y τ x
      (primeInterval (x ^ γ) (x ^ γ')))
  · filter_upwards [hV] with x hx
    apply Finset.sum_nonneg
    intro d hd
    exact integerWeight_nonneg I a c (c * M₀) (c * v + 1) ε Y τ x hx d
  · filter_upwards [hret', hsupport, htail, hV,
      RoughCompanion.W_tendsto.eventually (eventually_ge_atTop (2 : ℝ)),
      eventually_gt_atTop (1 : ℝ)] with x hretx hsupp htailx hVx hW hx
    let N := primeInterval (x ^ γ) (x ^ γ')
    let S := sievePrimes (c * M₀) (W x)
    have hN : ∀ n ∈ N, n.Prime ∧ x ^ γ ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ' := by
      intro n hn
      obtain ⟨hn, hl⟩ := Finset.mem_filter.mp hn
      obtain ⟨hu, hp⟩ := Nat.mem_primesLE.mp hn
      exact ⟨hp, hl.le, (Nat.le_floor_iff
        (Real.rpow_nonneg (by linarith : 0 ≤ x) γ')).mp hu⟩
    have hS : ∀ p ∈ S, p.Prime ∧ (p : ℝ) ≤ W x := by
      intro p hp
      have hh := sievePrimes_properties (c * M₀) (by linarith) hp
      exact ⟨hh.1, hh.2.2.1⟩
    have hrough := roughConditionedMass_le_conditioned I a c (c * M₀) (c * v + 1)
      ε Y τ x N S hVx hS
    have hs := hsupp N S (fun n hn => ⟨(hN n hn).1, (hN n hn).2.1⟩)
    have hr := hretx γ' hγ' N hN
    have ht := mul_le_mul_of_nonneg_left htailx (by positivity : 0 ≤ 2 / γ)
    simp only [Real.rpow_two, one_mul] at ht hr
    have hfull := hrough.trans (hs.trans (add_le_add hr ht))
    convert hfull using 1 <;> dsimp [N, S, localSieveProduct] <;> ring

/-- The complete normalized theorem in the exact conditioned-mass interface
used by the source-derived Buchstab bin estimate. -/
theorem actual_conditionedMass_bin_upper
    (source : BuchstabSieve.SourceLemma11_1) (C₀ : ℝ)
    (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ γ γ' η τ S_M : ℝ} (hε : 0 < ε) (hεκ : ε < κ)
    (hκ : κ < 1 / 100) (hεγ : ε < γ) (hγγ' : γ < γ')
    (hγ' : γ' ≤ 1/2 - κ) (hη : 0 < η) (hτ : 0 < τ)
    (hLocal : MertensLocalSource (c * M₀) S_M)
    (hEuler : ClassicalEulerMertens) (hPrime : ClassicalShiftedPrimeMertens)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ)
    (hmin : (1/10 : ℝ) ≤ amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (Y : ℝ) (hY : (M₀ : ℝ) ≤ Y) :
    ∀ᶠ x : ℝ in atTop,
      BuchstabMR.conditionedMass (Finset.Icc 2 ⌊2 * x⌋₊)
          (primeInterval (x ^ γ) (x ^ γ'))
          (integerWeight I a c (c * M₀) (c * v + 1) ε Y τ x) (W x) ≤
        (1 + η) * Real.exp (20 * τ) * S_M *
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x * eulerV (W x) *
            Real.log (γ' / γ) := by
  have hh := actual_rough_conditioned_bin_upper source C₀ hBlock hBV hPNT hTot
    hc hu hv huM hε hεκ hκ hεγ hγγ' hγ' hη hτ hLocal hEuler hPrime
    I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical Y hY
  filter_upwards [hh] with x hx
  rw [← roughConditionedMass_eq_conditionedMass I a c (c * M₀) (c * v + 1)
    ε Y τ x (primeInterval (x ^ γ) (x ^ γ'))
    (fun n hn => (Nat.mem_primesLE.mp (Finset.mem_filter.mp hn).1).2)]
  exact hx

end Artin.ConditionedAssembly
