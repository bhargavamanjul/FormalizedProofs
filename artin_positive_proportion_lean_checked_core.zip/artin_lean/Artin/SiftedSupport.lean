module

public import Artin.ManuscriptMass
public import Artin.BuchstabSieve

/-! # Exact support identities after sieving the integer variable -/

@[expose] public section
open scoped BigOperators

namespace Artin.SiftedSupport

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate
  MarkedBandTail ManuscriptMass BuchstabSieve

noncomputable def mask (S : Finset ℕ) (Ψ : ℕ → ℝ) (d : ℕ) : ℝ := by
  classical
  exact if ∀ p ∈ S, ¬ p ∣ d then Ψ d else 0

noncomputable def progressionWeight (c M u : ℕ) (Ψ : ℕ → ℝ) (r Q : ℕ) : ℝ :=
  if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0

theorem progressionWeight_nonneg (c M u : ℕ) (Ψ : ℕ → ℝ)
    (hΨ : ∀ d, 0 ≤ Ψ d) (r Q : ℕ) : 0 ≤ progressionWeight c M u Ψ r Q := by
  unfold progressionWeight
  split_ifs <;> first | exact hΨ _ | exact le_rfl

theorem masked_arithmeticWeight {ι : Type*} (S : Finset ℕ)
    (M u : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P U : Finset ℕ) (c : ℕ) (Qmin : ℝ) (d : ℕ) :
    arithmeticWeight M u (mask S Ψ) I groups V P c U Qmin d =
      if ∀ p ∈ S, ¬ p ∣ d then arithmeticWeight M u Ψ I groups V P c U Qmin d else 0 := by
  classical
  unfold arithmeticWeight mask
  split_ifs <;> simp_all

theorem sifted_integer_identity {ι : Type*} (D S : Finset ℕ)
    (M u : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P U : Finset ℕ) (c : ℕ) (Qmin : ℝ) :
    siftedMass D (arithmeticWeight M u Ψ I groups V P c U Qmin)
      (fun p d => p ∣ d) S =
      ∑ d ∈ D, arithmeticWeight M u (mask S Ψ) I groups V P c U Qmin d := by
  classical
  unfold siftedMass
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases h : ∀ p ∈ S, ¬ p ∣ d
  · simp [masked_arithmeticWeight, h]
  · simp [masked_arithmeticWeight, h]

theorem masked_progressionSum (S Qs : Finset ℕ) (c M u r : ℕ) (Ψ : ℕ → ℝ) :
    primeProgressionSum c M u Qs (mask S Ψ) r =
      siftedMass Qs (progressionWeight c M u Ψ r) (fun p Q => p ∣ c * r * Q + 1) S := by
  classical
  unfold primeProgressionSum siftedMass
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro Q hQ
  unfold mask progressionWeight
  split_ifs <;> rfl

/-- The actual original integer mass after any finite collection of prime
exclusions. No support cutoff is inserted into the invariant selector. -/
noncomputable def siftedBaseMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (S : Finset ℕ) : ℝ :=
  siftedMass (Finset.Icc 2 ⌊2 * x⌋₊)
    (arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) c
      (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ))) (fun p d => p ∣ d) S

/-- The exact sieve-array identity on the complete actual cofactor support. -/
theorem siftedBaseMass_eq {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z : ℝ) (S : Finset ℕ) (hx : 2 ≤ x) (hc : 0 < c)
    (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z) :
    siftedBaseMass I a c M u ε Y τ x S =
      ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x),
        marking I a x r *
        siftedMass (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
          (progressionWeight c M u (smoothWeight x) r) (fun p Q => p ∣ c * r * Q + 1) S := by
  classical
  unfold siftedBaseMass
  rw [sifted_integer_identity]
  have hmasked : ∀ d : ℕ, mask S (smoothWeight x) d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ 2 * x := by
    intro d hd
    apply smoothWeight_support hx d
    intro hn
    exact hd (by simp [mask, hn])
  rw [WeightSupport.ambient_weight_sum_eq_real M u c (2 * x) (mask S (smoothWeight x)) I
    (fun i => primeBand (a i) x) (fun i => bandMass (a i) x)
    (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
    (by positivity) hc hcut (fun p hp => ⟨markedPrimes_prime I a x p hp, hP p hp⟩)
    (fun i hi p hp => Finset.mem_biUnion.mpr ⟨i, hi, hp⟩) hcP
    (MarkedScaleSupport.unmarked_positive_avoid I a ε Y τ x) hU hmasked]
  apply Finset.sum_congr rfl
  intro r hr
  rw [masked_progressionSum]
  rfl

/-- Retaining only the small cofactors gives a lower bound for the original
sifted weight. Positivity justifies this after, rather than inside, marking. -/
theorem retained_sifted_le {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z : ℝ) (S : Finset ℕ) (hx : 2 ≤ x) (hc : 0 < c)
    (hε : ε ≤ 1) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    (∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
      marking I a x r *
        siftedMass (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
          (progressionWeight c M u (smoothWeight x) r) (fun p Q => p ∣ c * r * Q + 1) S) ≤
      siftedBaseMass I a c M u ε Y τ x S := by
  rw [siftedBaseMass_eq I a c M u ε Y τ x Z S hx hc hcut hP hcP hU]
  have hXT : x ^ ε ≤ 2 * x := by
    calc
      x ^ ε ≤ x ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith) hε
      _ = x := Real.rpow_one x
      _ ≤ 2 * x := by linarith
  apply Finset.sum_le_sum_of_subset_of_nonneg (FullMassComparison.boundedCofactors_mono _ _ hXT)
  intro r hr hnot
  apply mul_nonneg (markingWeight_bounds I _ _ r hV).1
  apply Finset.sum_nonneg
  intro Q hQ
  exact progressionWeight_nonneg c M u (smoothWeight x) (fun d => (smoothWeight_bounds x d).1) r Q

end Artin.SiftedSupport
