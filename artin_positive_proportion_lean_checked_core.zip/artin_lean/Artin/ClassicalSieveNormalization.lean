module

public import Artin.InitialSieve
public import Artin.RoughCompanion

/-!
# Classical normalization of the conditioned sieve

The hypotheses here are precise classical Mertens statements for ordinary
prime sums and Euler products. No marked-weight, bin, or candidate estimate
is assumed. The actual sieve ratio and prime-bin constants are deductions.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.ClassicalSieveNormalization

open InitialSieve MarkedSource

/-- The ordinary classical Mertens Euler-product asymptotic. -/
def ClassicalEulerMertens : Prop :=
  Tendsto (fun y : ℝ => Real.log y * eulerV y) atTop
    (𝓝 (Real.exp (-Real.eulerMascheroniConstant)))

/-- The actual local sieve product has the same constant in its ratio to
the ordinary Euler product. -/
theorem localProduct_ratio_tendsto {M : ℕ} {S_M : ℝ}
    (hM : MertensLocalSource M S_M) (hEuler : ClassicalEulerMertens) :
    Tendsto (fun y : ℝ => localSieveProduct M y / eulerV y) atTop (𝓝 S_M) := by
  have hh := hM.2.div hEuler (Real.exp_pos _).ne'
  have hconst : (S_M * Real.exp (-Real.eulerMascheroniConstant)) /
      Real.exp (-Real.eulerMascheroniConstant) = S_M := by
    exact mul_div_cancel_right₀ _ (Real.exp_pos _).ne'
  rw [hconst] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with y hy
  have hlog : Real.log y ≠ 0 := (Real.log_pos hy).ne'
  simp only [Pi.div_apply]
  field_simp

/-- Specialization to the source's actual subpower cutoff. -/
theorem localProduct_W_ratio_tendsto {M : ℕ} {S_M : ℝ}
    (hM : MertensLocalSource M S_M) (hEuler : ClassicalEulerMertens) :
    Tendsto (fun x : ℝ => localSieveProduct M (W x) / eulerV (W x))
      atTop (𝓝 S_M) :=
  (localProduct_ratio_tendsto hM hEuler).comp RoughCompanion.W_tendsto

theorem eventual_localProduct_W_ratio_le {M : ℕ} {S_M η : ℝ}
    (hM : MertensLocalSource M S_M) (hEuler : ClassicalEulerMertens) (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop,
      localSieveProduct M (W x) / eulerV (W x) ≤ S_M + η :=
  ((localProduct_W_ratio_tendsto hM hEuler).eventually
    (eventually_lt_nhds (by linarith : S_M < S_M + η))).mono (fun _ h => h.le)

/-- The ordinary prime harmonic sum with the shift occurring in the sieve. -/
noncomputable def shiftedPrimeHarmonic (y : ℝ) : ℝ :=
  ∑ p ∈ Nat.primesLE ⌊y⌋₊, 1 / ((p : ℝ) - 1)

/-- Classical prime Mertens, in its equivalent shifted-denominator form.
The change from `1/p` is an absolutely convergent prime correction. This is
an ordinary one-variable prime asymptotic, not a bin estimate. -/
def ClassicalShiftedPrimeMertens : Prop :=
  ∃ B : ℝ, Tendsto (fun y : ℝ => shiftedPrimeHarmonic y - Real.log (Real.log y))
    atTop (𝓝 B)

/-- The actual half-open prime interval, matching the disjoint Buchstab bins. -/
noncomputable def primeInterval (l u : ℝ) : Finset ℕ :=
  (Nat.primesLE ⌊u⌋₊).filter (fun p : ℕ => l < (p : ℝ))

theorem primeInterval_eq_sdiff {l u : ℝ} (hl : 0 ≤ l) (hu : 0 ≤ u) :
    primeInterval l u = (Nat.primesLE ⌊u⌋₊) \ (Nat.primesLE ⌊l⌋₊) := by
  ext p
  simp only [primeInterval, Finset.mem_filter, Finset.mem_sdiff, Nat.mem_primesLE,
    Nat.le_floor_iff hl, Nat.le_floor_iff hu]
  constructor
  · rintro ⟨⟨hpu, hp⟩, hpl⟩
    exact ⟨⟨hpu, hp⟩, fun hh => (not_le_of_gt hpl) hh.1⟩
  · rintro ⟨⟨hpu, hp⟩, hnot⟩
    exact ⟨⟨hpu, hp⟩, lt_of_not_ge (fun hpl => hnot ⟨hpl, hp⟩)⟩

/-- Exact subtraction of two genuine prime-prefix sums. -/
theorem primeInterval_sum_eq {l u : ℝ} (hl : 0 ≤ l) (hlu : l ≤ u) :
    (∑ p ∈ primeInterval l u, 1 / ((p : ℝ) - 1)) =
      shiftedPrimeHarmonic u - shiftedPrimeHarmonic l := by
  rw [primeInterval_eq_sdiff hl (hl.trans hlu)]
  apply Finset.sum_sdiff_eq_sub
  intro p hp
  have hh := Nat.mem_primesLE.mp hp
  apply Nat.mem_primesLE.mpr
  refine ⟨Nat.le_floor ?_, hh.2⟩
  exact ((Nat.le_floor_iff hl).mp hh.1).trans hlu

/-- The logarithms at a power-scale endpoint separate exactly. -/
theorem log_log_rpow {x γ : ℝ} (hx : 1 < x) (hγ : 0 < γ) :
    Real.log (Real.log (x ^ γ)) = Real.log γ + Real.log (Real.log x) := by
  rw [Real.log_rpow (zero_lt_one.trans hx), Real.log_mul hγ.ne' (Real.log_pos hx).ne']

/-- The coefficient of an actual fixed Buchstab prime bin is the logarithm
of the ratio of its endpoints. Both endpoints may grow with `x`. -/
theorem primeInterval_power_sum_tendsto (hM : ClassicalShiftedPrimeMertens)
    {γ γ' : ℝ} (hγ : 0 < γ) (hγγ' : γ ≤ γ') :
    Tendsto (fun x : ℝ => ∑ p ∈ primeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1))
      atTop (𝓝 (Real.log (γ' / γ))) := by
  obtain ⟨B, hB⟩ := hM
  have hγ' : 0 < γ' := hγ.trans_le hγγ'
  have hl := hB.comp (tendsto_rpow_atTop hγ)
  have hu := hB.comp (tendsto_rpow_atTop hγ')
  have hh := (hu.sub hl).add_const (Real.log (γ' / γ))
  simp only [sub_self, zero_add] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  dsimp only [Function.comp_def]
  rw [primeInterval_sum_eq (Real.rpow_nonneg (zero_lt_one.trans hx).le _)
      (Real.rpow_le_rpow_of_exponent_le hx.le hγγ'),
    log_log_rpow hx hγ, log_log_rpow hx hγ', Real.log_div hγ'.ne' hγ.ne']
  ring

theorem eventual_primeInterval_power_sum_le (hM : ClassicalShiftedPrimeMertens)
    {γ γ' η : ℝ} (hγ : 0 < γ) (hγγ' : γ ≤ γ') (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop,
      (∑ p ∈ primeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1)) ≤
        Real.log (γ' / γ) + η :=
  ((primeInterval_power_sum_tendsto hM hγ hγγ').eventually
    (eventually_lt_nhds (by linarith : Real.log (γ' / γ) < Real.log (γ' / γ) + η))).mono
    (fun _ h => h.le)

/-- An inclusive version, useful when covering bins without endpoint
bookkeeping. Its single possible extra prime has vanishing reciprocal mass. -/
noncomputable def closedPrimeInterval (l u : ℝ) : Finset ℕ :=
  (Nat.primesLE ⌊u⌋₊).filter (fun p : ℕ => l ≤ (p : ℝ))

theorem primeInterval_subset_closed (l u : ℝ) : primeInterval l u ⊆ closedPrimeInterval l u := by
  intro p hp
  exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hp).1, (Finset.mem_filter.mp hp).2.le⟩

theorem closedPrimeInterval_sum_bounds {l u : ℝ} (hl : 1 < l) :
    (∑ p ∈ primeInterval l u, 1 / ((p : ℝ) - 1)) ≤
      (∑ p ∈ closedPrimeInterval l u, 1 / ((p : ℝ) - 1)) ∧
    (∑ p ∈ closedPrimeInterval l u, 1 / ((p : ℝ) - 1)) ≤
      (∑ p ∈ primeInterval l u, 1 / ((p : ℝ) - 1)) + 1 / (l - 1) := by
  classical
  have hsub := primeInterval_subset_closed l u
  have hboundary : ∀ p ∈ closedPrimeInterval l u \ primeInterval l u, (p : ℝ) = l := by
    intro p hp
    have hc := Finset.mem_filter.mp (Finset.mem_sdiff.mp hp).1
    have hn : ¬ l < (p : ℝ) := by
      intro hlt
      exact (Finset.mem_sdiff.mp hp).2 (Finset.mem_filter.mpr ⟨hc.1, hlt⟩)
    linarith [hc.2]
  have hcard : (closedPrimeInterval l u \ primeInterval l u).card ≤ 1 := by
    apply Finset.card_le_one.mpr
    intro p hp q hq
    exact_mod_cast (hboundary p hp).trans (hboundary q hq).symm
  have hdiff : (∑ p ∈ closedPrimeInterval l u \ primeInterval l u, 1 / ((p : ℝ) - 1)) ≤
      1 / (l - 1) := by
    calc
      _ = (closedPrimeInterval l u \ primeInterval l u).card * (1 / (l - 1)) := by
        calc
          _ = ∑ _p ∈ closedPrimeInterval l u \ primeInterval l u, 1 / (l - 1) :=
            Finset.sum_congr rfl (fun p hp => by rw [hboundary p hp])
          _ = _ := by simp
      _ ≤ 1 * (1 / (l - 1)) :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) (by positivity)
      _ = _ := one_mul _
  constructor
  · apply Finset.sum_le_sum_of_subset_of_nonneg hsub
    intro p hp _
    have hh := (Finset.mem_filter.mp hp).2
    have hd : 0 < (p : ℝ) - 1 := by linarith
    positivity
  · have hid := Finset.sum_sdiff_eq_sub (f := fun p : ℕ => 1 / ((p : ℝ) - 1)) hsub
    rw [hid] at hdiff
    linarith

theorem closedPrimeInterval_power_sum_tendsto (hM : ClassicalShiftedPrimeMertens)
    {γ γ' : ℝ} (hγ : 0 < γ) (hγγ' : γ ≤ γ') :
    Tendsto (fun x : ℝ => ∑ p ∈ closedPrimeInterval (x ^ γ) (x ^ γ'), 1 / ((p : ℝ) - 1))
      atTop (𝓝 (Real.log (γ' / γ))) := by
  have hmain := primeInterval_power_sum_tendsto hM hγ hγγ'
  have hscale : Tendsto (fun x : ℝ => x ^ γ - 1) atTop atTop := by
    simpa only [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-1 : ℝ)
      (tendsto_rpow_atTop hγ)
  have htail : Tendsto (fun x : ℝ => 1 / (x ^ γ - 1)) atTop (𝓝 0) := by
    simpa only [one_div, Function.comp_def] using tendsto_inv_atTop_zero.comp hscale
  have hupper := hmain.add htail
  simp only [add_zero] at hupper
  have he : ∀ᶠ x : ℝ in atTop, 1 < x ^ γ :=
    (tendsto_rpow_atTop hγ).eventually (eventually_gt_atTop (1 : ℝ))
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' hmain hupper
    (he.mono (fun _ hx => (closedPrimeInterval_sum_bounds hx).1))
    (he.mono (fun _ hx => (closedPrimeInterval_sum_bounds hx).2))

/-- Every finite subset of the inclusive prime bin has at most the exact
asymptotic bin mass, with an arbitrarily small prescribed error. -/
theorem eventual_primeBin_subset_sum_le (hM : ClassicalShiftedPrimeMertens)
    {γ γ' η : ℝ} (hγ : 0 < γ) (hγγ' : γ ≤ γ') (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop, ∀ N : Finset ℕ,
      (∀ p ∈ N, p.Prime ∧ x ^ γ ≤ (p : ℝ) ∧ (p : ℝ) ≤ x ^ γ') →
      (∑ p ∈ N, 1 / ((p : ℝ) - 1)) ≤ Real.log (γ' / γ) + η := by
  have he := ((closedPrimeInterval_power_sum_tendsto hM hγ hγγ').eventually
    (eventually_lt_nhds (by linarith : Real.log (γ' / γ) < Real.log (γ' / γ) + η)))
  filter_upwards [he] with x he N hN
  apply le_trans _ he.le
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro p hp
    exact Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor (hN p hp).2.2, (hN p hp).1⟩, (hN p hp).2.1⟩
  · intro p hp _
    have hh := (Nat.mem_primesLE.mp (Finset.mem_filter.mp hp).1).2.two_le
    have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hh
    have hden : 0 < (p : ℝ) - 1 := by linarith
    positivity

end Artin.ClassicalSieveNormalization
