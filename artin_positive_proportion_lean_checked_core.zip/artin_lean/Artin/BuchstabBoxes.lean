module

public import Artin.BuchstabMR
public import Artin.DyadicBoxes

/-!
# The actual dyadic family for a Buchstab bin

The first index records the prime factor, the second its complement.  The
sets below are explicit finite sets, including half-open complementary
dyads, so their union has no repeated factor pairs.
-/

@[expose] public section

open Filter
open scoped BigOperators

namespace Artin.BuchstabBoxes

open DyadicBoxes MarkedSource RoughCompanion SemiprimeReplacement SemiprimeMR BuchstabMR

noncomputable def indices (x γ γ' : ℝ) : Finset (ℤ × ℤ) :=
  boxIndices (dyadicIndex (x ^ γ)) (dyadicIndex (x ^ γ')) (dyadicIndex x)

noncomputable def primeScale (_x : ℝ) (ab : ℤ × ℤ) : ℝ := (2 : ℝ) ^ ab.1
noncomputable def complementScale (_x : ℝ) (ab : ℤ × ℤ) : ℝ := (2 : ℝ) ^ ab.2

theorem scale_product_bounds {x γ γ' : ℝ} {ab : ℤ × ℤ} (hx : 0 < x)
    (hab : ab ∈ indices x γ γ') :
    x / 4 ≤ complementScale x ab * primeScale x ab ∧
      complementScale x ab * primeScale x ab ≤ 2 * x := by
  simpa only [complementScale, primeScale, mul_comm] using
    boxIndices_product_bounds hx hab

theorem primeScale_bounds {x γ γ' : ℝ} {ab : ℤ × ℤ} (hx : 0 < x)
    (hab : ab ∈ indices x γ γ') :
    x ^ γ / 2 < primeScale x ab ∧ primeScale x ab ≤ x ^ γ' := by
  have hmem := mem_boxIndices.mp hab
  have hlo := dyadicIndex_inBin (Real.rpow_pos_of_pos hx γ)
  have hhi := dyadicIndex_inBin (Real.rpow_pos_of_pos hx γ')
  have hlower := (bin_endpoint_bounds hlo).1
  have hmono₁ := zpow_le_zpow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hmem.1
  have hmono₂ := zpow_le_zpow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hmem.2.1
  exact ⟨hlower.trans_le hmono₁, hmono₂.trans hhi.1⟩

theorem complementScale_bounds {x γ γ' : ℝ} {ab : ℤ × ℤ} (hx : 0 < x)
    (hab : ab ∈ indices x γ γ') :
    x ^ (1 - γ') / 4 ≤ complementScale x ab ∧
      2 * complementScale x ab ≤ 8 * x ^ (1 - γ) := by
  have hp := primeScale_bounds hx hab
  have hprod := scale_product_bounds hx hab
  have hm : 0 < complementScale x ab := zpow_pos (by norm_num) _
  have hγ : 0 < x ^ γ := Real.rpow_pos_of_pos hx _
  have hγ' : 0 < x ^ γ' := Real.rpow_pos_of_pos hx _
  have heq : x ^ (1 - γ') * x ^ γ' = x := by
    rw [← Real.rpow_add hx, sub_add_cancel, Real.rpow_one]
  have heq' : x ^ (1 - γ) * x ^ γ = x := by
    rw [← Real.rpow_add hx, sub_add_cancel, Real.rpow_one]
  have hlow : x / 4 ≤ complementScale x ab * x ^ γ' :=
    hprod.1.trans (mul_le_mul_of_nonneg_left hp.2 hm.le)
  have hupp : complementScale x ab * (x ^ γ / 2) ≤ 2 * x :=
    (mul_le_mul_of_nonneg_left hp.1.le hm.le).trans hprod.2
  constructor <;> nlinarith

/-- The logarithmic number of boxes follows from the actual finite index
set, with a constant independent of the bin and the marking parameters. -/
theorem indices_card_le {x γ γ' : ℝ} (hx : 1 ≤ x) (hγγ' : γ ≤ γ') :
    ((indices x γ γ').card : ℝ) ≤
      3 * ((γ' - γ) * Real.log x / Real.log 2 + 2) := by
  have hx0 : 0 < x := zero_lt_one.trans_le hx
  have h := boxIndices_card_le_log_width (Real.rpow_pos_of_pos hx0 γ)
    (Real.rpow_le_rpow_of_exponent_le hx hγγ') (dyadicIndex x)
  rw [Real.logb_rpow_eq_mul_logb_of_pos hx0,
    Real.logb_rpow_eq_mul_logb_of_pos hx0] at h
  change ((indices x γ γ').card : ℝ) ≤ _ at h
  convert h using 1
  dsimp [Real.logb]
  ring

theorem indices_card_le_log {x γ γ' : ℝ} (hx : 1 ≤ x)
    (hlog : 1 ≤ Real.log x) (hγγ' : γ ≤ γ') (hwidth : γ' - γ ≤ 1) :
    ((indices x γ γ').card : ℝ) ≤ (3 / Real.log 2 + 6) * Real.log x := by
  have hL : 0 ≤ Real.log x := by linarith
  have h2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hw : (γ' - γ) * Real.log x / Real.log 2 ≤ Real.log x / Real.log 2 :=
    div_le_div_of_nonneg_right (by nlinarith) h2.le
  apply (indices_card_le hx hγγ').trans
  calc
    _ ≤ 3 * (Real.log x / Real.log 2 + 2) := by linarith
    _ = (3 / Real.log 2) * Real.log x + 6 := by ring
    _ ≤ (3 / Real.log 2 + 6) * Real.log x := by nlinarith

/-- The existing strip-index bound remains valid at its lower boundary. -/
theorem dyadicIndex_sum_bounds_le {x m n : ℝ} (hx : 0 < x) (hm : 0 < m)
    (hn : 0 < n) (hlo : x ≤ m * n) (hhi : m * n ≤ 2 * x) :
    -1 ≤ dyadicIndex m + dyadicIndex n - dyadicIndex x ∧
      dyadicIndex m + dyadicIndex n - dyadicIndex x ≤ 1 := by
  have hl := Real.logb_le_logb_of_le (by norm_num : (1 : ℝ) < 2) hx hlo
  have hu := Real.logb_le_logb_of_le (by norm_num : (1 : ℝ) < 2) (mul_pos hm hn) hhi
  rw [Real.logb_mul hm.ne' hn.ne'] at hl hu
  rw [Real.logb_mul (by norm_num : (2 : ℝ) ≠ 0) hx.ne',
    Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2)] at hu
  have hmf := Int.floor_le (Real.logb 2 m)
  have hnf := Int.floor_le (Real.logb 2 n)
  have hxf := Int.floor_le (Real.logb 2 x)
  have hmc := Int.lt_floor_add_one (Real.logb 2 m)
  have hnc := Int.lt_floor_add_one (Real.logb 2 n)
  have hxc := Int.lt_floor_add_one (Real.logb 2 x)
  have h₁ : (dyadicIndex x : ℝ) < dyadicIndex m + dyadicIndex n + 2 := by
    dsimp [dyadicIndex]
    linarith
  have h₂ : (dyadicIndex m : ℝ) + dyadicIndex n < dyadicIndex x + 2 := by
    dsimp [dyadicIndex]
    linarith
  have h₁' : dyadicIndex x < dyadicIndex m + dyadicIndex n + 2 := by exact_mod_cast h₁
  have h₂' : dyadicIndex m + dyadicIndex n < dyadicIndex x + 2 := by exact_mod_cast h₂
  omega

theorem exists_box {x γ γ' m n : ℝ} (hx : 0 < x) (hm : 0 < m) (hn : 0 < n)
    (hnlo : x ^ γ ≤ n) (hnhi : n ≤ x ^ γ')
    (hprod : x ≤ m * n) (hprod' : m * n ≤ 2 * x) :
    ∃ ab ∈ indices x γ γ', DyadicBoxes.InBin ab.2 m ∧ DyadicBoxes.InBin ab.1 n := by
  refine ⟨(dyadicIndex n, dyadicIndex m), ?_, dyadicIndex_inBin hm, dyadicIndex_inBin hn⟩
  rw [indices, mem_boxIndices]
  refine ⟨dyadicIndex_mono (Real.rpow_pos_of_pos hx _) hnlo, dyadicIndex_mono hn hnhi, ?_⟩
  simpa only [mul_comm] using dyadicIndex_sum_bounds_le hx hn hm
    (by simpa only [mul_comm] using hprod) (by simpa only [mul_comm] using hprod')

/-- The exact half-open integer dyad. -/
noncomputable def natDyad (a : ℤ) : Finset ℕ :=
  Finset.Icc ⌈(2 : ℝ) ^ a⌉₊ (⌈(2 : ℝ) ^ (a + 1)⌉₊ - 1)

theorem mem_natDyad {a : ℤ} {m : ℕ} :
    m ∈ natDyad a ↔ DyadicBoxes.InBin a (m : ℝ) := by
  have hpos : 0 < ⌈(2 : ℝ) ^ (a + 1)⌉₊ := Nat.ceil_pos.mpr (zpow_pos (by norm_num) _)
  rw [natDyad, Finset.mem_Icc]
  change (⌈(2 : ℝ) ^ a⌉₊ ≤ m ∧ m ≤ ⌈(2 : ℝ) ^ (a + 1)⌉₊ - 1) ↔ _
  rw [Nat.ceil_le]
  have hh : m ≤ ⌈(2 : ℝ) ^ (a + 1)⌉₊ - 1 ↔ m < ⌈(2 : ℝ) ^ (a + 1)⌉₊ := by omega
  rw [hh, Nat.lt_ceil]
  rfl

theorem natDyad_interval (a : ℤ) : IntervalInDyad ((2 : ℝ) ^ a) (natDyad a) := by
  have hp : 0 < (2 : ℝ) ^ (a + 1) := zpow_pos (by norm_num) _
  have hceil : 1 ≤ ⌈(2 : ℝ) ^ (a + 1)⌉₊ := Nat.ceil_pos.mpr hp
  refine ⟨_, _, rfl, Nat.le_ceil _, ?_⟩
  rw [Nat.cast_sub hceil, Nat.cast_one]
  have h := Nat.ceil_lt_add_one hp.le
  have he : (2 : ℝ) ^ (a + 1) = 2 * (2 : ℝ) ^ a := by
    rw [zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0)]
    norm_num [mul_comm]
  rw [he] at h
  rw [he]
  linarith

noncomputable def primeBin (x γ γ' : ℝ) : Finset ℕ :=
  (Nat.primesLE ⌊x ^ γ'⌋₊).filter (fun n => x ^ γ < (n : ℝ))

theorem mem_primeBin {x γ γ' : ℝ} (hx : 0 < x) {n : ℕ} :
    n ∈ primeBin x γ γ' ↔ n.Prime ∧ x ^ γ < (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ' := by
  rw [primeBin, Finset.mem_filter, Nat.mem_primesLE]
  have hp := (Real.rpow_pos_of_pos hx γ').le
  rw [Nat.le_floor_iff hp]
  tauto

noncomputable def primeBox (x γ γ' : ℝ) (ab : ℤ × ℤ) : Finset ℕ :=
  (primeBin x γ γ').filter (fun n => n ∈ natDyad ab.1)

theorem primeBox_inDyad (x γ γ' : ℝ) (ab : ℤ × ℤ) :
    InDyad (primeScale x ab) (primeBox x γ γ' ab) := by
  intro n hn
  exact (natDyad_interval ab.1).inDyad n (Finset.mem_filter.mp hn).2

theorem primeBox_bounds {x γ γ' : ℝ} (hx : 0 < x) (ab : ℤ × ℤ) {n : ℕ}
    (hn : n ∈ primeBox x γ γ' ab) :
    n.Prime ∧ x ^ γ < (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ' :=
  (mem_primeBin hx).mp (Finset.mem_filter.mp hn).1

/-- Explicit slack absorbs all complete dyad endpoints into the fixed
source window, uniformly across every box of the bin. -/
theorem scale_window_bounds {x b κ γ γ' : ℝ} {ab : ℤ × ℤ}
    (hx : 1 ≤ x) (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ)
    (hlargeB : 8 ≤ x ^ (b / 2)) (hlargeK : 4 ≤ x ^ (κ / 2))
    (hab : ab ∈ indices x γ γ') :
    1 ≤ complementScale x ab ∧ 1 ≤ primeScale x ab ∧
      x ^ (b / 2) ≤ complementScale x ab ∧ x ^ (b / 2) ≤ primeScale x ab ∧
      x ^ (1 / 2 + κ / 2) ≤ complementScale x ab ∧
      2 * complementScale x ab ≤ x ^ (1 - b / 2) := by
  have hx0 : 0 < x := zero_lt_one.trans_le hx
  have hn := primeScale_bounds hx0 hab
  have hm := complementScale_bounds hx0 hab
  have hpowB : x ^ b = x ^ (b / 2) * x ^ (b / 2) := by
    rw [← Real.rpow_add hx0]
    congr 1
    ring
  have hpowLo : x ^ (1 / 2 + κ) = x ^ (1 / 2 + κ / 2) * x ^ (κ / 2) := by
    rw [← Real.rpow_add hx0]
    congr 1
    ring
  have hpowHi : x ^ (1 - b / 2) = x ^ (1 - b) * x ^ (b / 2) := by
    rw [← Real.rpow_add hx0]
    congr 1
    ring
  have hNmono := Real.rpow_le_rpow_of_exponent_le hx hbg
  have hMmono := Real.rpow_le_rpow_of_exponent_le hx
    (show (1 / 2 + κ : ℝ) ≤ 1 - γ' by linarith)
  have hMupper := Real.rpow_le_rpow_of_exponent_le hx
    (show 1 - γ ≤ 1 - b by linarith)
  have hB0 := Real.rpow_pos_of_pos hx0 (b / 2)
  have hLo0 := Real.rpow_pos_of_pos hx0 (1 / 2 + κ / 2)
  have hHi0 := Real.rpow_pos_of_pos hx0 (1 - b)
  have hN : x ^ (b / 2) ≤ primeScale x ab := by
    rw [hpowB] at hNmono
    nlinarith [hn.1]
  have hM : x ^ (1 / 2 + κ / 2) ≤ complementScale x ab := by
    rw [hpowLo] at hMmono
    nlinarith [hm.1]
  have hMU : 2 * complementScale x ab ≤ x ^ (1 - b / 2) := by
    rw [hpowHi]
    nlinarith [hm.2]
  have hdelta : x ^ (b / 2) ≤ x ^ (1 / 2 + κ / 2) :=
    Real.rpow_le_rpow_of_exponent_le hx (by linarith)
  have hOne : 1 ≤ x ^ (b / 2) := Real.one_le_rpow hx (by linarith)
  exact ⟨hOne.trans (hdelta.trans hM), hOne.trans hN, hdelta.trans hM, hN, hM, hMU⟩

theorem eventually_scale_window {b κ γ γ' : ℝ} (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ) :
    ∀ᶠ x : ℝ in atTop, ∀ ab ∈ indices x γ γ',
      1 ≤ complementScale x ab ∧ 1 ≤ primeScale x ab ∧
        x ^ (b / 2) ≤ complementScale x ab ∧ x ^ (b / 2) ≤ primeScale x ab ∧
        x ^ (1 / 2 + κ / 2) ≤ complementScale x ab ∧
        2 * complementScale x ab ≤ x ^ (1 - b / 2) := by
  have hB := (tendsto_rpow_atTop (show (0 : ℝ) < b / 2 by linarith)).eventually_ge_atTop 8
  have hK := (tendsto_rpow_atTop (show (0 : ℝ) < κ / 2 by linarith)).eventually_ge_atTop 4
  filter_upwards [hB, hK, eventually_ge_atTop (1 : ℝ)] with x hxB hxK hx ab hab
  exact scale_window_bounds hx hb hκ hbg hγγ' hupper hxB hxK hab

/-- The actual growing family satisfies every scale premise of the marked
source theorem. No admissible-dyad predicate is assumed here. -/
theorem actual_scaleFamily {b κ γ γ' : ℝ} (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ) :
    ScaleFamily (b / 2) (1 / 4) 2 complementScale primeScale
      (fun x ab => ab ∈ indices x γ γ') := by
  filter_upwards [eventually_scale_window hb hκ hbg hγγ' hupper,
    eventually_gt_atTop (0 : ℝ)] with x hx hx0 ab hab
  have hw := hx ab hab
  have hp := scale_product_bounds hx0 hab
  exact ⟨hw.1, hw.2.1, hw.2.2.1, hw.2.2.2.1, by simpa only [div_eq_mul_inv, one_mul, mul_comm] using hp.1,
    hp.2⟩

/-- The complete complementary dyads lie inside the fixed source exponent
window `[1/2+κ/2, 1-b/2]`, with one threshold for the entire family. -/
theorem actual_exponentWindow {b κ γ γ' : ℝ} (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ) :
    ∀ᶠ x : ℝ in atTop, ∀ ab ∈ indices x γ γ',
      1 / 2 + κ / 2 ≤ Real.log (complementScale x ab) / Real.log x ∧
        Real.log (2 * complementScale x ab) / Real.log x ≤ 1 - b / 2 := by
  filter_upwards [eventually_scale_window hb hκ hbg hγγ' hupper,
    eventually_gt_atTop (1 : ℝ)] with x hx hxx ab hab
  have hw := hx ab hab
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hxx
  have hH : 0 < complementScale x ab := by dsimp [complementScale]; positivity
  constructor
  · apply (le_div_iff₀ hL).mpr
    have hh := Real.log_le_log (Real.rpow_pos_of_pos hx0 _) hw.2.2.2.2.1
    simpa only [Real.log_rpow hx0] using hh
  · apply (div_le_iff₀ hL).mpr
    have hh := Real.log_le_log (by positivity : 0 < 2 * complementScale x ab) hw.2.2.2.2.2
    simpa only [Real.log_rpow hx0] using hh

/-- Source-to-bin replacement on the literal constructed boxes. All scale,
full-dyad exponent-window, interval, and prime-bin support premises have
now been proved for this family. -/
theorem actual_box_bounds_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hcontinuity : ClassicalDensityContinuity)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨsmooth : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    (b κ γ γ' C₀ : ℝ) (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ)
    (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C₀) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ bands : Bands K,
      ∀ η : ℝ, 0 < η → ∃ C : ℝ, 0 < C ∧
      ∀ᶠ x : ℝ in atTop, ∀ ab ∈ indices x γ γ',
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
          pairMass (natDyad ab.2) (primeBox x γ γ' ab)
              (actualWeight bands M u Ψ x c allowed Qmin)
              (realRoughIndicator (x ^ γ)) primeIndicator ≤
            (C₀ + η) / (Real.log x * eulerV (W x)) *
              pairMass (natDyad ab.2) (primeBox x γ γ' ab)
                (actualWeight bands M u Ψ x c allowed Qmin)
                (realRoughIndicator (W x)) primeIndicator +
            C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := bin_upper_from_sources h102 h103 hbands hFourier hcontinuity
    M u hu hunit Ψ hΨsmooth hΨ hsupport γ γ' (1 / 2 + κ / 2) (1 - b / 2)
    (b / 2) (1 / 4) 2 C₀ (by linarith) (by linarith) (by linarith)
    (by linarith) (by linarith) (by linarith) (by norm_num) (by norm_num) hbin
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK bands η hη
  obtain ⟨C, hC, herror⟩ := hK K hKK bands (ℤ × ℤ) complementScale primeScale
    (fun x ab => ab ∈ indices x γ γ')
    (actual_scaleFamily hb hκ hbg hγγ' hupper)
    (actual_exponentWindow hb hκ hbg hγγ' hupper) η hη
  refine ⟨C, hC, ?_⟩
  filter_upwards [herror, eventually_gt_atTop (0 : ℝ)] with x hx hx0
  intro ab hab c allowed Qmin
  exact hx ab hab (natDyad ab.2) (primeBox x γ γ' ab) (natDyad_interval ab.2)
    (primeBox_inDyad x γ γ' ab)
    (fun n hn => ⟨(primeBox_bounds hx0 ab hn).2.1.le, (primeBox_bounds hx0 ab hn).2.2⟩)
    c allowed Qmin

end Artin.BuchstabBoxes
