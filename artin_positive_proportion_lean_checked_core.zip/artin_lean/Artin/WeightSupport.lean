module

public import Artin.WeightedTail
public import Artin.MarkedCofactorEstimate

/-!
# Exhaustive support of the actual arithmetic weight

The selector strips only marked prime powers.  The enlarged cofactor is
reconstructed afterwards, without inserting a size condition into that
selector.  These lemmas identify the ambient integer sum with its complete
finite sum over enlarged cofactors and large primes.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.WeightSupport

open ConcreteSelector CofactorRepresentation

/-- All positive enlarged cofactors up to the indicated finite cutoff. -/
noncomputable def boundedCofactors (P allowed : Finset ℕ) (B : ℕ) : Finset ℕ :=
  (Finset.Icc 1 B).filter (fun r => strip P r ∈ allowed)

/-- The actual prime variable, with its lower and upper cutoffs. -/
noncomputable def boundedLargePrimes (B : ℕ) (Qmin : ℝ) : Finset ℕ :=
  (Nat.primesLE B).filter (fun Q => Qmin < (Q : ℝ))

theorem mem_boundedCofactors {P allowed : Finset ℕ} {B r : ℕ} :
    r ∈ boundedCofactors P allowed B ↔
      0 < r ∧ r ≤ B ∧ strip P r ∈ allowed := by
  simp only [boundedCofactors, Finset.mem_filter, Finset.mem_Icc]
  simp only [Nat.succ_le_iff]
  tauto

theorem mem_boundedLargePrimes {B Q : ℕ} {Qmin : ℝ} :
    Q ∈ boundedLargePrimes B Qmin ↔
      Q.Prime ∧ Q ≤ B ∧ Qmin < (Q : ℝ) := by
  simp only [boundedLargePrimes, Finset.mem_filter, Nat.mem_primesLE]
  tauto

/-- The natural-cutoff family is the same actual cofactor family used in the
finite/infinite marked-mass decomposition. -/
theorem boundedCofactors_eq_marked (P allowed : Finset ℕ) (B : ℕ) :
    boundedCofactors P allowed B = MarkedCofactorEstimate.boundedCofactors P allowed (B : ℝ) := by
  ext r
  rw [mem_boundedCofactors, MarkedCofactorEstimate.mem_boundedCofactors]
  simp only [Nat.cast_le]
  tauto

theorem boundedCofactors_floor_eq_marked (P allowed : Finset ℕ) {X : ℝ}
    (hX : 0 ≤ X) :
    boundedCofactors P allowed ⌊X⌋₊ = MarkedCofactorEstimate.boundedCofactors P allowed X := by
  ext r
  rw [mem_boundedCofactors, MarkedCofactorEstimate.mem_boundedCofactors]
  constructor
  · rintro ⟨hr, hB, hstrip⟩
    exact ⟨hr, hstrip, (by exact_mod_cast hB : (r : ℝ) ≤ (⌊X⌋₊ : ℝ)).trans (Nat.floor_le hX)⟩
  · rintro ⟨hr, hstrip, hB⟩
    exact ⟨hr, Nat.le_floor hB, hstrip⟩

/-- The smooth factor must be nonzero whenever the full weight is nonzero. -/
theorem smooth_ne_zero_of_weight_ne_zero {ι : Type*}
    (M u : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P allowed : Finset ℕ) (c : ℕ) (Qmin : ℝ) (d : ℕ)
    (hw : arithmeticWeight M u Ψ I groups V P c allowed Qmin d ≠ 0) :
    Ψ d ≠ 0 := by
  intro hz
  apply hw
  simp [arithmeticWeight, hz]

/-- Reconstruct the enlarged cofactor from the selector's actual witness.
All marked prime powers are retained. -/
theorem selected_predecessor {P allowed : Finset ℕ} {c d : ℕ} {Qmin : ℝ}
    (hd : 2 ≤ d)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hsel : Selected P c allowed Qmin (d - 1)) :
    ∃ r Q : ℕ, 0 < r ∧ strip P r ∈ allowed ∧ Q.Prime ∧
      Qmin < (Q : ℝ) ∧ d = c * r * Q + 1 := by
  obtain ⟨r₀, Q, hr₀, hQ, hlarge, hstrip⟩ := hsel
  have hh : d - 1 ≠ 0 := by omega
  have hr₀pos := (hallowed r₀ hr₀).1
  have hpartpos := markedPart_pos P hh
  have hsupported : ∀ p : ℕ, p.Prime → p ∣ markedPart P (d - 1) → p ∈ P :=
    fun _ hp hdiv => prime_dvd_markedPart_mem P hh hp hdiv
  have hrstrip : strip P (markedPart P (d - 1) * r₀) = r₀ := by
    rw [strip_mul_supported P hpartpos.ne' hr₀pos.ne' hsupported,
      strip_eq_self_of_avoids P hr₀pos.ne' (hallowed r₀ hr₀).2]
  refine ⟨markedPart P (d - 1) * r₀, Q, Nat.mul_pos hpartpos hr₀pos,
    (by rwa [hrstrip]), hQ, hlarge, ?_⟩
  have hfactor := markedPart_mul_strip P hh
  rw [hstrip] at hfactor
  calc
    d = (d - 1) + 1 := by omega
    _ = (markedPart P (d - 1) * (c * r₀ * Q)) + 1 :=
      congrArg (fun n : ℕ => n + 1) hfactor.symm
    _ = c * (markedPart P (d - 1) * r₀) * Q + 1 := by ring

/-- Every prime divisor of an enlarged cofactor comes either from its marked
part or from its permitted stripped cofactor. -/
theorem boundedCofactors_prime_bound {P allowed : Finset ℕ} {B : ℕ} {Z : ℝ}
    (hP : ∀ p ∈ P, (p : ℝ) ≤ Z)
    (hallowed : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    {r : ℕ} (hr : r ∈ boundedCofactors P allowed B) :
    ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z := by
  obtain ⟨hrpos, _, hrstrip⟩ := mem_boundedCofactors.mp hr
  intro p hp hdiv
  rw [← markedPart_mul_strip P hrpos.ne'] at hdiv
  rcases hp.dvd_mul.mp hdiv with hmark | hstrip
  · exact hP p (prime_dvd_markedPart_mem P hrpos.ne' hp hmark)
  · exact hallowed _ hrstrip p hp hstrip

theorem marked_boundedCofactors_prime_bound {P allowed : Finset ℕ} {X Z : ℝ}
    (hP : ∀ p ∈ P, (p : ℝ) ≤ Z)
    (hallowed : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    {r : ℕ} (hr : r ∈ MarkedCofactorEstimate.boundedCofactors P allowed X) :
    ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z := by
  have hh := (MarkedCofactorEstimate.mem_boundedCofactors P allowed X r).mp hr
  intro p hp hdiv
  rw [← markedPart_mul_strip P hh.1.ne'] at hdiv
  rcases hp.dvd_mul.mp hdiv with hmark | hstrip
  · exact hP p (prime_dvd_markedPart_mem P hh.1.ne' hp hmark)
  · exact hallowed _ hh.2.1 p hp hstrip

/-- Enlarging by marked primes preserves the lower prime-divisor cutoff. -/
theorem marked_boundedCofactors_prime_lower {P allowed : Finset ℕ} {X Y : ℝ}
    (hP : ∀ p ∈ P, Y < (p : ℝ))
    (hallowed : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → Y < (p : ℝ))
    {r : ℕ} (hr : r ∈ MarkedCofactorEstimate.boundedCofactors P allowed X) :
    ∀ p : ℕ, p.Prime → p ∣ r → Y < (p : ℝ) := by
  have hh := (MarkedCofactorEstimate.mem_boundedCofactors P allowed X r).mp hr
  intro p hp hdiv
  rw [← markedPart_mul_strip P hh.1.ne'] at hdiv
  rcases hp.dvd_mul.mp hdiv with hmark | hstrip
  · exact hP p (prime_dvd_markedPart_mem P hh.1.ne' hp hmark)
  · exact hallowed _ hh.2.1 p hp hstrip

/-- Hence every actual enlarged cofactor is a unit modulo any fixed positive
modulus below the prime-divisor cutoff. -/
theorem marked_boundedCofactors_coprime {P allowed : Finset ℕ} {X Y : ℝ} {M : ℕ}
    (hM : 0 < M) (hMY : (M : ℝ) ≤ Y)
    (hP : ∀ p ∈ P, Y < (p : ℝ))
    (hallowed : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → Y < (p : ℝ))
    {r : ℕ} (hr : r ∈ MarkedCofactorEstimate.boundedCofactors P allowed X) :
    r.Coprime M := by
  apply Nat.coprime_of_dvd
  intro p hp hpr hpM
  have hle : (p : ℝ) ≤ M := by exact_mod_cast Nat.le_of_dvd hM hpM
  exact (not_lt_of_ge (hle.trans hMY))
    (marked_boundedCofactors_prime_lower hP hallowed hr p hp hpr)

/-- Each factor in a positive predecessor representation lies below the
represented integer. -/
theorem predecessor_factor_bounds {c r Q d : ℕ}
    (hc : 0 < c) (hr : 0 < r) (hQ : 0 < Q)
    (hd : d = c * r * Q + 1) : r < d ∧ Q < d := by
  have hrle : r ≤ c * r * Q := by
    calc
      r = 1 * r * 1 := by simp
      _ ≤ c * r * Q := Nat.mul_le_mul (Nat.mul_le_mul_right r hc) hQ
  have hQle : Q ≤ c * r * Q := by
    calc
      Q = 1 * Q := by simp
      _ ≤ c * r * Q := Nat.mul_le_mul_right Q (Nat.mul_pos hc hr)
  omega

/-- Exhaustive support using only the ambient upper cutoff. -/
theorem weight_support_predecessor_image {ι : Type*}
    (M u c B : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P allowed : Finset ℕ) (Qmin : ℝ)
    (hc : 0 < c)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → 2 ≤ d ∧ d ≤ B)
    {d : ℕ} (hw : arithmeticWeight M u Ψ I groups V P c allowed Qmin d ≠ 0) :
    d ∈ predecessorIntegers c (boundedCofactors P allowed B) (boundedLargePrimes B Qmin) := by
  have hd := hΨ d (smooth_ne_zero_of_weight_ne_zero M u Ψ I groups V P allowed c Qmin d hw)
  have hs := (arithmeticWeight_ne_zero_support M u Ψ I groups V P c allowed Qmin d hw).2
  obtain ⟨r, Q, hr, hrstrip, hQ, hlarge, hrep⟩ := selected_predecessor hd.1 hallowed hs
  have hb := predecessor_factor_bounds hc hr hQ.pos hrep
  apply Finset.mem_image.mpr
  refine ⟨(r, Q), Finset.mem_product.mpr ⟨?_, ?_⟩, ?_⟩
  · exact mem_boundedCofactors.mpr ⟨hr, hb.1.le.trans hd.2, hrstrip⟩
  · exact mem_boundedLargePrimes.mpr ⟨hQ, hb.2.le.trans hd.2, hlarge⟩
  · exact hrep.symm

/-- Two finite sums agree if both sets contain every nonzero term. -/
theorem sum_eq_of_support (A B : Finset ℕ) (w : ℕ → ℝ)
    (hA : ∀ d : ℕ, w d ≠ 0 → d ∈ A)
    (hB : ∀ d : ℕ, w d ≠ 0 → d ∈ B) :
    (∑ d ∈ A, w d) = ∑ d ∈ B, w d := by
  classical
  have ha : (∑ d ∈ A, w d) = ∑ d ∈ A ∪ B, w d := by
    apply Finset.sum_subset Finset.subset_union_left
    intro d _ hd
    by_contra hn
    exact hd (hA d hn)
  have hb : (∑ d ∈ B, w d) = ∑ d ∈ A ∪ B, w d := by
    apply Finset.sum_subset Finset.subset_union_right
    intro d _ hd
    by_contra hn
    exact hd (hB d hn)
  exact ha.trans hb.symm

/-- The full ambient weight, with exhaustive support now proved, equals the
sum of the actual prime-progression sums over distinct enlarged cofactors. -/
theorem ambient_weight_sum_eq {ι : Type*}
    (M u c B : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P allowed : Finset ℕ) {Z Qmin : ℝ}
    (hc : 0 < c) (hcut : Z ≤ Qmin)
    (hP : ∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ Z)
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hcP : ∀ p ∈ P, ¬ p ∣ c)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hsmall : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → 2 ≤ d ∧ d ≤ B) :
    (∑ d ∈ Finset.Icc 2 B, arithmeticWeight M u Ψ I groups V P c allowed Qmin d) =
      ∑ r ∈ boundedCofactors P allowed B, markingWeight I groups V r *
        primeProgressionSum c M u (boundedLargePrimes B Qmin) Ψ r := by
  rw [sum_eq_of_support (Finset.Icc 2 B)
    (predecessorIntegers c (boundedCofactors P allowed B) (boundedLargePrimes B Qmin))
    (arithmeticWeight M u Ψ I groups V P c allowed Qmin)
    (fun d hd => Finset.mem_Icc.mpr (hΨ d
      (smooth_ne_zero_of_weight_ne_zero M u Ψ I groups V P allowed c Qmin d hd)))
    (fun _ hd => weight_support_predecessor_image M u c B Ψ I groups V P allowed Qmin
      hc hallowed hΨ hd)]
  apply arithmeticWeight_sum_eq M u c Ψ I groups V P allowed
    (boundedCofactors P allowed B) (boundedLargePrimes B Qmin) hc hcut
    (fun p hp => ⟨(hP p hp).1, ((hP p hp).2).trans hcut⟩) hgroups hcP
  · intro r hr
    have hh := mem_boundedCofactors.mp hr
    exact ⟨hh.1.ne', hh.2.2,
      boundedCofactors_prime_bound (fun p hp => (hP p hp).2) hsmall hr⟩
  · intro Q hQ
    have hh := mem_boundedLargePrimes.mp hQ
    exact ⟨hh.1, hh.2.2⟩

/-- Real upper cutoffs use exactly the cofactor set from the marked-mass
theorems, rather than a second enumeration of the same integers. -/
theorem ambient_weight_sum_eq_real {ι : Type*}
    (M u c : ℕ) (X : ℝ) (Ψ : ℕ → ℝ) (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P allowed : Finset ℕ) {Z Qmin : ℝ}
    (hX : 0 ≤ X) (hc : 0 < c) (hcut : Z ≤ Qmin)
    (hP : ∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ Z)
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hcP : ∀ p ∈ P, ¬ p ∣ c)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hsmall : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ X) :
    (∑ d ∈ Finset.Icc 2 ⌊X⌋₊, arithmeticWeight M u Ψ I groups V P c allowed Qmin d) =
      ∑ r ∈ MarkedCofactorEstimate.boundedCofactors P allowed X,
        markingWeight I groups V r *
          primeProgressionSum c M u (boundedLargePrimes ⌊X⌋₊ Qmin) Ψ r := by
  rw [← boundedCofactors_floor_eq_marked P allowed hX]
  exact ambient_weight_sum_eq M u c ⌊X⌋₊ Ψ I groups V P allowed hc hcut hP
    hgroups hcP hallowed hsmall (fun d hd => ⟨(hΨ d hd).1, Nat.le_floor (hΨ d hd).2⟩)

/-- The full selector automatically has no contribution from an enlarged
cofactor above the large-prime scale bound.  This is a support consequence,
not an additional restriction placed inside the invariant selector. -/
theorem primeProgressionSum_eq_zero_of_large_cofactor
    {c M u r : ℕ} (Qs : Finset ℕ) (Ψ : ℕ → ℝ) {x γ : ℝ}
    (hx : 0 < x) (hc : 2 ≤ c)
    (hQ : ∀ Q ∈ Qs, x ^ γ < (Q : ℝ))
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → (d : ℝ) ≤ 2 * x)
    (hr : x ^ (1 - γ) < (r : ℝ)) :
    primeProgressionSum c M u Qs Ψ r = 0 := by
  classical
  apply Finset.sum_eq_zero
  intro Q hQmem
  have hz : Ψ (c * r * Q + 1) = 0 := by
    by_contra hn
    exact (not_lt_of_ge (cofactor_bound_of_large_prime hx hc (hΨ _ hn) (hQ Q hQmem))) hr
  simp [hz]

/-- The actual bounded cofactor family is monotone in its real cutoff. -/
theorem marked_boundedCofactors_mono (P allowed : Finset ℕ) {X Y : ℝ} (hXY : X ≤ Y) :
    MarkedCofactorEstimate.boundedCofactors P allowed X ⊆
      MarkedCofactorEstimate.boundedCofactors P allowed Y := by
  intro r hr
  have hh := (MarkedCofactorEstimate.mem_boundedCofactors P allowed X r).mp hr
  exact (MarkedCofactorEstimate.mem_boundedCofactors P allowed Y r).mpr
    ⟨hh.1, hh.2.1, hh.2.2.trans hXY⟩

/-- One may shorten the outer sum after reindexing whenever the omitted
cofactors are forced to carry zero progression mass. -/
theorem progression_sum_eq_small_cofactors (P allowed Qs : Finset ℕ)
    (t Ψ : ℕ → ℝ) {c M u : ℕ} {x γ X Y : ℝ}
    (hx : 0 < x) (hc : 2 ≤ c) (hXY : X ≤ Y) (hX : x ^ (1 - γ) ≤ X)
    (hQ : ∀ Q ∈ Qs, x ^ γ < (Q : ℝ))
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → (d : ℝ) ≤ 2 * x) :
    (∑ r ∈ MarkedCofactorEstimate.boundedCofactors P allowed Y,
      t r * primeProgressionSum c M u Qs Ψ r) =
      ∑ r ∈ MarkedCofactorEstimate.boundedCofactors P allowed X,
        t r * primeProgressionSum c M u Qs Ψ r := by
  symm
  apply Finset.sum_subset (marked_boundedCofactors_mono P allowed hXY)
  intro r hr hnot
  have hh := (MarkedCofactorEstimate.mem_boundedCofactors P allowed Y r).mp hr
  have hrX : X < (r : ℝ) := by
    by_contra hn
    exact hnot ((MarkedCofactorEstimate.mem_boundedCofactors P allowed X r).mpr
      ⟨hh.1, hh.2.1, le_of_not_gt hn⟩)
  rw [primeProgressionSum_eq_zero_of_large_cofactor Qs Ψ hx hc hQ hΨ (hX.trans_lt hrX), mul_zero]

/-- At the manuscript's scales the full arithmetic weight is already
exhausted by enlarged cofactors at most `x^0.11`.  The finer `x^ε` cutoff
can subsequently be imposed by the quantitative tail estimate. -/
theorem ambient_weight_sum_eq_cofactor_scale {ι : Type*}
    (M u c : ℕ) (x : ℝ) (Ψ : ℕ → ℝ) (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P allowed : Finset ℕ) {Z : ℝ}
    (hx : 1 ≤ x) (hc : c = 2 ∨ c = 4) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ Z)
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hcP : ∀ p ∈ P, ¬ p ∣ c)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hsmall : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hΨ : ∀ d : ℕ, Ψ d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ 2 * x) :
    (∑ d ∈ Finset.Icc 2 ⌊2 * x⌋₊,
      arithmeticWeight M u Ψ I groups V P c allowed (x ^ (9 / 10 : ℝ)) d) =
      ∑ r ∈ MarkedCofactorEstimate.boundedCofactors P allowed (x ^ (11 / 100 : ℝ)),
        markingWeight I groups V r *
          primeProgressionSum c M u (boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))) Ψ r := by
  have hxpos : 0 < x := by linarith
  have hc2 : 2 ≤ c := by rcases hc with rfl | rfl <;> norm_num
  rw [ambient_weight_sum_eq_real M u c (2 * x) Ψ I groups V P allowed
    (by positivity) (by omega) hcut hP hgroups hcP hallowed hsmall hΨ]
  apply progression_sum_eq_small_cofactors P allowed _ (markingWeight I groups V) Ψ
    (γ := (9 / 10 : ℝ)) hxpos hc2
  · have hpow : x ^ (11 / 100 : ℝ) ≤ x := by
      simpa using Real.rpow_le_rpow_of_exponent_le hx (by norm_num : (11 / 100 : ℝ) ≤ 1)
    linarith
  · exact Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
  · intro Q hQ
    exact (mem_boundedLargePrimes.mp hQ).2.2
  · exact fun d hd => (hΨ d hd).2

end Artin.WeightSupport
