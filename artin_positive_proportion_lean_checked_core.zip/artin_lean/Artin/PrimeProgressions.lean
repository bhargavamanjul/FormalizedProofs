module

public import Artin.CofactorRepresentation
public import Artin.ProgressionResidues
public import Mathlib.Data.Nat.ModEq

/-!
# Actual prime progressions in the cofactor distribution argument

The sieve modulus may be composite.  These identities reduce the conditions
on `c*r*Q+1` to one reduced class modulo `M₀*ℓ`; they apply to the actual
finite prime sums, without a multiplicity or a change of normalization.
-/

@[expose] public section
namespace Artin.PrimeProgressions

open scoped BigOperators

/-- Cancel the fixed power of two from the predecessor progression. -/
theorem predecessor_modEq_iff {c M₀ v r Q : ℕ} (hc : c ≠ 0) :
    Nat.ModEq (c * M₀) (c * r * Q + 1) (c * v + 1) ↔
      Nat.ModEq M₀ (r * Q) v := by
  constructor
  · intro h
    apply Nat.ModEq.mul_left_cancel' hc
    simpa only [mul_assoc] using h.add_right_cancel' 1
  · intro h
    simpa only [mul_assoc] using (h.mul_left' c).add_right 1

/-- The corresponding equality of the literal residues used by the weight. -/
theorem predecessor_residue_iff {c M₀ v r Q : ℕ} (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) :
    (c * r * Q + 1) % (c * M₀) = c * v + 1 ↔
      (r : ZMod M₀) * (Q : ZMod M₀) = (v : ZMod M₀) := by
  rw [← Nat.mod_eq_of_lt hu]
  change Nat.ModEq (c * M₀) (c * r * Q + 1) (c * v + 1) ↔ _
  rw [predecessor_modEq_iff hc, ← ZMod.natCast_eq_natCast_iff]
  simp only [Nat.cast_mul]

/-- Solve a linear congruence using a unit; no primality of the modulus is needed. -/
theorem unit_mul_eq_iff {R : Type*} [CommRing R] (k : Rˣ) (y b : R) :
    (k : R) * y = b ↔ y = (↑(k⁻¹) : R) * b := by
  constructor
  · intro h
    calc
      y = (↑(k⁻¹) : R) * ((k : R) * y) := by simp
      _ = _ := congrArg (fun z => (↑(k⁻¹) : R) * z) h
  · rintro rfl
    simp [← mul_assoc]

/-- The fixed reduced residue for the large prime. -/
noncomputable def baseResidue {M₀ r : ℕ} (v : ℕ) (hr : r.Coprime M₀) : ZMod M₀ :=
  (↑((ZMod.unitOfCoprime r hr)⁻¹) : ZMod M₀) * (v : ZMod M₀)

theorem baseResidue_isUnit {M₀ r v : ℕ} (hr : r.Coprime M₀)
    (hv : v.Coprime M₀) : IsUnit (baseResidue v hr) :=
  ((ZMod.unitOfCoprime r hr)⁻¹).isUnit.mul ((ZMod.isUnit_iff_coprime v M₀).mpr hv)

theorem predecessor_eq_baseResidue {c M₀ v r Q : ℕ} (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀) :
    (c * r * Q + 1) % (c * M₀) = c * v + 1 ↔
      (Q : ZMod M₀) = baseResidue v hr := by
  rw [predecessor_residue_iff hc hu]
  exact unit_mul_eq_iff (ZMod.unitOfCoprime r hr) _ _

/-- The sieve class modulo an arbitrary modulus coprime to the coefficient. -/
noncomputable def sieveResidue {k ℓ : ℕ} (hk : k.Coprime ℓ) : ZMod ℓ :=
  -(↑((ZMod.unitOfCoprime k hk)⁻¹) : ZMod ℓ)

theorem divisor_iff_sieveResidue {k ℓ Q : ℕ} (hk : k.Coprime ℓ) :
    ℓ ∣ k * Q + 1 ↔ (Q : ZMod ℓ) = sieveResidue hk := by
  rw [← ZMod.natCast_eq_zero_iff, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  rw [add_eq_zero_iff_eq_neg, ← ZMod.coe_unitOfCoprime k hk,
    unit_mul_eq_iff]
  simp [sieveResidue]

theorem sieveResidue_isUnit {k ℓ : ℕ} (hk : k.Coprime ℓ) :
    IsUnit (sieveResidue hk) := by
  exact ((ZMod.unitOfCoprime k hk)⁻¹).isUnit.neg

/-- Combine the fixed prime class and the sieve class by the actual CRT equivalence. -/
noncomputable def combinedResidue {M₀ k ℓ r : ℕ} (v : ℕ)
    (hM : M₀.Coprime ℓ) (hr : r.Coprime M₀) (hk : k.Coprime ℓ) :
    ZMod (M₀ * ℓ) :=
  (ZMod.chineseRemainder hM).symm (baseResidue v hr, sieveResidue hk)

theorem combinedResidue_isUnit {M₀ k ℓ r v : ℕ}
    (hM : M₀.Coprime ℓ) (hr : r.Coprime M₀) (hk : k.Coprime ℓ)
    (hv : v.Coprime M₀) : IsUnit (combinedResidue v hM hr hk) := by
  exact (Prod.isUnit_iff.mpr ⟨baseResidue_isUnit hr hv, sieveResidue_isUnit hk⟩).map
    (ZMod.chineseRemainder hM).symm.toMonoidHom

/-- The two original conditions are exactly one reduced prime progression. -/
theorem predecessor_sieve_iff {c M₀ v r ℓ Q : ℕ} (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hM : M₀.Coprime ℓ) (hk : (c * r).Coprime ℓ) :
    ((c * r * Q + 1) % (c * M₀) = c * v + 1 ∧ ℓ ∣ c * r * Q + 1) ↔
      (Q : ZMod (M₀ * ℓ)) = combinedResidue v hM hr hk := by
  rw [predecessor_eq_baseResidue hc hu hr, divisor_iff_sieveResidue hk]
  constructor
  · intro h
    apply (ZMod.chineseRemainder hM).injective
    simpa [combinedResidue, map_natCast, Prod.ext_iff] using h
  · intro h
    have h' := congrArg (ZMod.chineseRemainder hM) h
    simpa [combinedResidue, map_natCast, Prod.ext_iff] using h'

/-- The actual count with the additional sieve divisibility condition. -/
noncomputable def sievedPrimeSum (c M u ℓ : ℕ) (Qs : Finset ℕ)
    (Ψ : ℕ → ℝ) (r : ℕ) : ℝ :=
  ∑ Q ∈ Qs, if (c * r * Q + 1) % M = u ∧ ℓ ∣ c * r * Q + 1
    then Ψ (c * r * Q + 1) else 0

theorem sievedPrimeSum_one (c M u : ℕ) (Qs : Finset ℕ) (Ψ : ℕ → ℝ) (r : ℕ) :
    sievedPrimeSum c M u 1 Qs Ψ r =
      CofactorRepresentation.primeProgressionSum c M u Qs Ψ r := by
  simp [sievedPrimeSum, CofactorRepresentation.primeProgressionSum]

/-- Reindexing to the prime residue is literal termwise equality. -/
theorem sievedPrimeSum_eq_progression {c M₀ v r ℓ : ℕ}
    (Qs : Finset ℕ) (Ψ : ℕ → ℝ) (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hM : M₀.Coprime ℓ) (hk : (c * r).Coprime ℓ) :
    sievedPrimeSum c (c * M₀) (c * v + 1) ℓ Qs Ψ r =
      ∑ Q ∈ Qs, if (Q : ZMod (M₀ * ℓ)) = combinedResidue v hM hr hk
        then Ψ (c * r * Q + 1) else 0 := by
  apply Finset.sum_congr rfl
  intro Q _
  simp only [predecessor_sieve_iff hc hu hr hM hk]

/-- A predecessor in the fixed reduced class is coprime to both its
cofactor and the fixed modulus. -/
theorem predecessor_coprime {c M u r Q : ℕ} (hu : u.Coprime M)
    (hres : (c * r * Q + 1) % M = u) :
    (c * r * Q + 1).Coprime (M * r) := by
  have hM : (c * r * Q + 1).Coprime M := by
    apply (ZMod.isUnit_iff_coprime _ _).mp
    have heq : ((c * r * Q + 1 : ℕ) : ZMod M) = (u : ZMod M) := by
      rw [← ZMod.natCast_mod (c * r * Q + 1) M, hres]
    rw [heq]
    exact (ZMod.isUnit_iff_coprime _ _).mpr hu
  have hr : (c * r * Q + 1).Coprime r := by
    have h := (Nat.coprime_mul_left_add_left 1 r (c * Q)).mpr (Nat.coprime_one_left r)
    convert h using 1
    ring
  exact hM.mul_right hr

/-- A non-coprime sieve modulus contributes exactly zero, as required by
the manuscript's local density `g_r`. -/
theorem sievedPrimeSum_eq_zero {c M u ℓ r : ℕ} (Qs : Finset ℕ)
    (Ψ : ℕ → ℝ) (hu : u.Coprime M) (hbad : ¬ ℓ.Coprime (M * r)) :
    sievedPrimeSum c M u ℓ Qs Ψ r = 0 := by
  apply Finset.sum_eq_zero
  intro Q _
  have hn : ¬ ((c * r * Q + 1) % M = u ∧ ℓ ∣ c * r * Q + 1) := by
    rintro ⟨hres, hdiv⟩
    exact hbad ((predecessor_coprime hu hres).of_dvd_left hdiv)
  simp only [ite_eq_right hn]

/-- The reciprocal totient normalization in the direct BV main term. -/
theorem combined_density {M₀ ℓ : ℕ} (hM : M₀.Coprime ℓ) :
    (1 : ℝ) / Nat.totient (M₀ * ℓ) =
      (1 / (Nat.totient ℓ : ℝ)) / Nat.totient M₀ := by
  rw [Nat.totient_mul hM, Nat.cast_mul]
  ring

end Artin.PrimeProgressions
