module

public import Artin.SieveDistribution
public import Artin.PrimeProgressions
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Ring

/-!
# Partial summation of actual prime-progression errors

Finite Abel summation is proved here. The external analytic inputs concern
unweighted prime prefix counts (the classical Bombieri--Vinogradov and
fixed-modulus prime-number theorems), not the manuscript's weighted or
recentered distribution estimate.

`BombieriVinogradovSource` and `FixedModulusPNTSource` are explicit propositions,
never axioms. Their main term is the actual logarithmic integral defined below.
The proved BV application includes arbitrary reduced classes, composite CRT
moduli, zero on excluded moduli, affine smoothing, the growing cofactor range,
and weighted recentering with exact harmonic cofactor mass. Its only additional
summation input is the elementary reciprocal-totient bound, stated as a bound
for the density sum. The PNT application compares actual base sums to the
weighted logarithmic-integral model uniformly for `r ≤ x^0.01`.

The subsequent positive-main-mass and tail assembly is separate: this file
does not assert `X₀ ≍ xJ/log x` or the candidate-prime lower bound.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.PrimeDistribution

noncomputable def prefixSum (f : ℕ → ℝ) (N : ℕ) : ℝ := ∑ n ∈ Finset.range N, f n

theorem prefix_succ (f : ℕ → ℝ) (N : ℕ) : prefixSum f (N + 1) = prefixSum f N + f N := by
  simp [prefixSum, Finset.sum_range_succ]

/-- The exact finite Abel identity, including the terminal boundary term. -/
theorem summation_by_parts (w e : ℕ → ℝ) (N : ℕ) :
    (∑ n ∈ Finset.range N, w n * e n) =
      w N * prefixSum e N +
        ∑ n ∈ Finset.range N, (w n - w (n + 1)) * prefixSum e (n + 1) := by
  induction N with
  | zero => simp [prefixSum]
  | succ N ih =>
    rw [Finset.sum_range_succ, Finset.sum_range_succ, ih, prefix_succ]
    ring

/-- Discrete total variation, with the boundary term used by Abel summation. -/
noncomputable def variation (w : ℕ → ℝ) (N : ℕ) : ℝ :=
  |w N| + ∑ n ∈ Finset.range N, |w n - w (n + 1)|

theorem variation_nonneg (w : ℕ → ℝ) (N : ℕ) : 0 ≤ variation w N := by
  exact add_nonneg (abs_nonneg _) (Finset.sum_nonneg (fun _ _ => abs_nonneg _))

/-- Smoothing costs only total variation; no dependence on the number of
sample points is inserted into the prefixSum error. -/
theorem weighted_error_le_variation (w e : ℕ → ℝ) (N : ℕ) {E : ℝ}
    (hprefix : ∀ n ≤ N, |prefixSum e n| ≤ E) :
    |∑ n ∈ Finset.range N, w n * e n| ≤ variation w N * E := by
  rw [summation_by_parts]
  calc
    _ ≤ |w N * prefixSum e N| +
        |∑ n ∈ Finset.range N, (w n - w (n + 1)) * prefixSum e (n + 1)| := abs_add_le _ _
    _ ≤ |w N * prefixSum e N| +
        ∑ n ∈ Finset.range N, |(w n - w (n + 1)) * prefixSum e (n + 1)| :=
      add_le_add le_rfl (Finset.abs_sum_le_sum_abs _ _)
    _ ≤ |w N| * E + ∑ n ∈ Finset.range N, |w n - w (n + 1)| * E := by
      rw [abs_mul]
      apply add_le_add (mul_le_mul_of_nonneg_left (hprefix N le_rfl) (abs_nonneg _))
      apply Finset.sum_le_sum
      intro n hn
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left (hprefix (n + 1) (by simpa using Finset.mem_range.mp hn))
        (abs_nonneg _)
    _ = variation w N * E := by rw [variation, add_mul, Finset.sum_mul]

/-- The actual indicator of a prime in a specified natural residue class. -/
noncomputable def primeIndicator (q a n : ℕ) : ℝ :=
  if n.Prime ∧ n % q = a then 1 else 0

noncomputable def primePrefix (q a N : ℕ) : ℝ := prefixSum (primeIndicator q a) N

noncomputable def weightedPrimeSum (q a N : ℕ) (w : ℕ → ℝ) : ℝ :=
  ∑ n ∈ Finset.range N, w n * primeIndicator q a n

/-- `primePrefix` is a genuine prime count. -/
theorem primePrefix_eq_card (q a N : ℕ) :
    primePrefix q a N =
      (((Finset.range N).filter (fun n => n.Prime ∧ n % q = a)).card : ℝ) := by
  classical
  simp only [primePrefix, prefixSum, primeIndicator, Finset.sum_boole]

/-- Rewrite to the filtered finite progression sum used by arithmetic bridges. -/
theorem weightedPrimeSum_eq_sum_filter (q a N : ℕ) (w : ℕ → ℝ) :
    weightedPrimeSum q a N w =
      ∑ n ∈ (Finset.range N).filter Nat.Prime, if n % q = a then w n else 0 := by
  classical
  simp only [weightedPrimeSum, primeIndicator, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hp : n.Prime <;> by_cases ha : n % q = a <;> simp [hp, ha]

/-- The finite Stieltjes main term associated to a classical prefixSum main
function. In the application that function is the logarithmic integral. -/
noncomputable def weightedModel (q N : ℕ) (w main : ℕ → ℝ) : ℝ :=
  ∑ n ∈ Finset.range N, w n * ((main (n + 1) - main n) / (q.totient : ℝ))

theorem prefix_prime_error (q a N : ℕ) (main : ℕ → ℝ) (hzero : main 0 = 0) :
    prefixSum (fun n => primeIndicator q a n -
      (main (n + 1) - main n) / (q.totient : ℝ)) N =
      primePrefix q a N - main N / (q.totient : ℝ) := by
  induction N with
  | zero => simp [prefixSum, primePrefix, hzero]
  | succ N ih =>
    rw [prefix_succ, ih]
    change _ = prefixSum (primeIndicator q a) (N + 1) - _
    rw [prefix_succ]
    unfold primePrefix
    ring

/-- Actual smoothed prime-progression error from classical prefixSum errors. -/
theorem weightedPrimeSum_error (q a N : ℕ) (w main : ℕ → ℝ)
    (hzero : main 0 = 0) {E : ℝ}
    (hprefix : ∀ n ≤ N, |primePrefix q a n - main n / (q.totient : ℝ)| ≤ E) :
    |weightedPrimeSum q a N w - weightedModel q N w main| ≤ variation w N * E := by
  have he := weighted_error_le_variation w
    (fun n => primeIndicator q a n - (main (n + 1) - main n) / (q.totient : ℝ)) N
    (fun n hn => by rw [prefix_prime_error q a n main hzero]; exact hprefix n hn)
  simpa only [weightedPrimeSum, weightedModel, mul_sub, Finset.sum_sub_distrib] using he

/-- Uniform regularity under affine rescaling. This is the smoothing estimate
needed when the prime scale changes with the cofactor. -/
theorem variation_affine_le (Ψ : ℝ → ℝ) (N : ℕ) {a b K B : ℝ}
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|)
    (hB : |Ψ (a * N + b)| ≤ B) :
    variation (fun n => Ψ (a * n + b)) N ≤ B + (N : ℝ) * (K * |a|) := by
  unfold variation
  apply add_le_add hB
  calc
    (∑ n ∈ Finset.range N, |Ψ (a * n + b) - Ψ (a * (n + 1 : ℕ) + b)|) ≤
        ∑ _n ∈ Finset.range N, K * |a| := by
      apply Finset.sum_le_sum
      intro n hn
      have h := hLip (a * n + b) (a * (n + 1 : ℕ) + b)
      convert h using 1
      congr 1
      have hid : a * (n : ℝ) + b - (a * ((n + 1 : ℕ) : ℝ) + b) = -a := by
        push_cast
        ring
      rw [hid, abs_neg]
    _ = _ := by simp

/-- If the sampled interval has bounded rescaled length, the variation
constant is independent of its length and of the cofactor. -/
theorem variation_affine_uniform (Ψ : ℝ → ℝ) (N : ℕ) {a b K B H : ℝ}
    (ha : 0 ≤ a) (hK : 0 ≤ K) (hNa : (N : ℝ) * a ≤ H)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|)
    (hB : |Ψ (a * N + b)| ≤ B) :
    variation (fun n => Ψ (a * n + b)) N ≤ B + K * H := by
  calc
    _ ≤ B + (N : ℝ) * (K * |a|) := variation_affine_le Ψ N hLip hB
    _ = B + K * ((N : ℝ) * a) := by rw [abs_of_nonneg ha]; ring
    _ ≤ _ := add_le_add le_rfl (mul_le_mul_of_nonneg_left hNa hK)

/-- Summing over an injective family of moduli preserves the classical BV
majorant. The residue class may depend arbitrarily on the modulus. -/
theorem sum_weightedPrimeSum_errors {ι : Type*} (s : Finset ι) (moduli : Finset ℕ)
    (q a : ι → ℕ) (N : ℕ) (w main : ℕ → ℝ) (E : ℕ → ℝ) {V B : ℝ}
    (hzero : main 0 = 0) (hV : 0 ≤ V) (hvar : variation w N ≤ V)
    (hinj : Set.InjOn q s) (hmod : ∀ i ∈ s, q i ∈ moduli)
    (hE : ∀ d ∈ moduli, 0 ≤ E d)
    (hprefix : ∀ i ∈ s, ∀ n ≤ N,
      |primePrefix (q i) (a i) n - main n / ((q i).totient : ℝ)| ≤ E (q i))
    (hBV : ∑ d ∈ moduli, E d ≤ B) :
    (∑ i ∈ s, |weightedPrimeSum (q i) (a i) N w - weightedModel (q i) N w main|) ≤ V * B := by
  have hsum : (∑ i ∈ s, E (q i)) ≤ ∑ d ∈ moduli, E d := by
    apply Finset.sum_le_sum_of_injOn q hinj
    · intro d hd
      obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hd
      exact hmod i hi
    · intro i hi
      exact le_rfl
    · intro d hd hnot
      exact hE d hd
  calc
    _ ≤ ∑ i ∈ s, V * E (q i) := by
      apply Finset.sum_le_sum
      intro i hi
      exact (weightedPrimeSum_error (q i) (a i) N w main hzero (hprefix i hi)).trans
        (mul_le_mul_of_nonneg_right hvar (hE (q i) (hmod i hi)))
    _ = V * ∑ i ∈ s, E (q i) := (Finset.mul_sum _ _ _).symm
    _ ≤ V * B := mul_le_mul_of_nonneg_left (hsum.trans hBV) hV

/-- No multiplicity appears when the fixed progression multiplies each
sieving modulus. -/
theorem fixed_modulus_injective {M : ℕ} (hM : 0 < M) :
    Function.Injective (fun ℓ : ℕ => M * ℓ) := by
  intro a b hab
  exact Nat.eq_of_mul_eq_mul_left hM hab

/-- CRT factorization of the smooth analytic main term. -/
theorem weightedModel_mul {M ℓ : ℕ} (h : M.Coprime ℓ) (N : ℕ) (w main : ℕ → ℝ) :
    weightedModel (M * ℓ) N w main =
      (1 / (ℓ.totient : ℝ)) * weightedModel M N w main := by
  rw [weightedModel, weightedModel, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro n hn
  rw [Nat.totient_mul h, Nat.cast_mul]
  ring

/-- The manuscript's actual finite `A_r(ℓ)` is one of the weighted prime sums
to which the proved Abel estimate applies. -/
theorem sievedPrimeSum_eq_weightedPrimeSum {c M₀ v r ℓ : ℕ}
    [NeZero M₀] [NeZero ℓ] (N : ℕ) (Ψ : ℕ → ℝ) (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hM : M₀.Coprime ℓ) (hk : (c * r).Coprime ℓ) :
    PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
      ((Finset.range N).filter Nat.Prime) Ψ r =
      weightedPrimeSum (M₀ * ℓ) (PrimeProgressions.combinedResidue v hM hr hk).val N
        (fun Q => Ψ (c * r * Q + 1)) := by
  rw [PrimeProgressions.sievedPrimeSum_eq_progression _ _ hc hu hr hM hk,
    weightedPrimeSum_eq_sum_filter]
  apply Finset.sum_congr rfl
  intro Q hQ
  have heq : ((Q : ZMod (M₀ * ℓ)) = PrimeProgressions.combinedResidue v hM hr hk) ↔
      Q % (M₀ * ℓ) = (PrimeProgressions.combinedResidue v hM hr hk).val := by
    rw [← ZMod.val_natCast]
    exact (ZMod.val_injective (M₀ * ℓ)).eq_iff.symm
  simp only [heq]

/-- The classical logarithmic-integral prefix main term, normalized at two. -/
noncomputable def logarithmicIntegral (N : ℕ) : ℝ :=
  ∫ t in (2 : ℝ)..max 2 (N : ℝ), (Real.log t)⁻¹

theorem logarithmicIntegral_zero : logarithmicIntegral 0 = 0 := by
  simp [logarithmicIntegral]

/-- Exact external Bombieri--Vinogradov input. This is the standard maximal
prefix formulation below a fixed power less than one half. `E` majorizes
every reduced residue and every shorter prefix; only its unweighted sum is
assumed. The weighted and cofactor-summed conclusions are proved separately. -/
def BombieriVinogradovSource : Prop :=
  ∀ A η : ℝ, 0 < A → 0 < η → η < 1 / 2 →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ T : ℝ in Filter.atTop, ∃ E : ℕ → ℝ,
      (∀ q ∈ Finset.Icc 1 ⌊T ^ (1 / 2 - η)⌋₊, 0 ≤ E q) ∧
      (∀ q ∈ Finset.Icc 1 ⌊T ^ (1 / 2 - η)⌋₊, ∀ a : ℕ,
        a < q → a.Coprime q → ∀ N : ℕ, (N : ℝ) ≤ T →
          |primePrefix q a N - logarithmicIntegral N / (q.totient : ℝ)| ≤ E q) ∧
      (∑ q ∈ Finset.Icc 1 ⌊T ^ (1 / 2 - η)⌋₊, E q) ≤
        C * T / (Real.log T) ^ A

/-- Exact fixed-modulus PNT input, again solely for unweighted prime counts.
The uniform shorter-prefix form is convenient for the proved Abel identity. -/
def FixedModulusPNTSource : Prop :=
  ∀ q : ℕ, 0 < q → ∀ A : ℝ, 0 < A → ∃ C : ℝ, 0 < C ∧
    ∀ᶠ T : ℝ in Filter.atTop, ∀ a : ℕ, a < q → a.Coprime q →
      ∀ N : ℕ, (N : ℝ) ≤ T →
        |primePrefix q a N - logarithmicIntegral N / (q.totient : ℝ)| ≤
          C * T / (Real.log T) ^ A

/-- Apply the classical BV statement after the finite Abel argument. Its one
threshold works for every weight of variation at most `V`, every choice of
reduced residues, and every injective family of fixed-modulus multiples. -/
theorem BombieriVinogradovSource.smoothed (hBV : BombieriVinogradovSource)
    {A η V : ℝ} (hA : 0 < A) (hη : 0 < η) (hη' : η < 1 / 2) (hV : 0 ≤ V) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ T : ℝ in Filter.atTop,
      ∀ M : ℕ, 0 < M → ∀ s : Finset ℕ,
      (∀ ℓ ∈ s, 1 ≤ M * ℓ ∧ ((M * ℓ : ℕ) : ℝ) ≤ T ^ (1 / 2 - η)) →
      ∀ a : ℕ → ℕ, (∀ ℓ ∈ s, a ℓ < M * ℓ ∧ (a ℓ).Coprime (M * ℓ)) →
      ∀ N : ℕ, (N : ℝ) ≤ T → ∀ w : ℕ → ℝ, variation w N ≤ V →
      (∑ ℓ ∈ s, |weightedPrimeSum (M * ℓ) (a ℓ) N w -
        weightedModel (M * ℓ) N w logarithmicIntegral|) ≤
          V * (C * T / (Real.log T) ^ A) := by
  obtain ⟨C, hC, he⟩ := hBV A η hA hη hη'
  refine ⟨C, hC, ?_⟩
  filter_upwards [he] with T hT
  obtain ⟨E, hE, hprefix, hsum⟩ := hT
  intro M hM s hs a ha N hN w hw
  have hmod : ∀ ℓ ∈ s, M * ℓ ∈ Finset.Icc 1 ⌊T ^ (1 / 2 - η)⌋₊ := by
    intro ℓ hℓ
    exact Finset.mem_Icc.mpr ⟨(hs ℓ hℓ).1, Nat.le_floor (hs ℓ hℓ).2⟩
  exact sum_weightedPrimeSum_errors s _ (fun ℓ => M * ℓ) a N w logarithmicIntegral E
    logarithmicIntegral_zero hV hw (fixed_modulus_injective hM).injOn hmod hE
    (fun ℓ hℓ n hn => hprefix _ (hmod ℓ hℓ) _ (ha ℓ hℓ).1 (ha ℓ hℓ).2 n
      ((by exact_mod_cast hn : (n : ℝ) ≤ N).trans hN)) hsum

/-- A one-modulus consequence for the actual arithmetic count. -/
theorem sievedPrimeSum_error {c M₀ v r ℓ : ℕ} [NeZero M₀] [NeZero ℓ]
    (N : ℕ) (Ψ : ℕ → ℝ) (main : ℕ → ℝ) (hc : c ≠ 0)
    (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hM : M₀.Coprime ℓ) (hk : (c * r).Coprime ℓ) (hzero : main 0 = 0) {E : ℝ}
    (hprefix : ∀ n ≤ N,
      |primePrefix (M₀ * ℓ) (PrimeProgressions.combinedResidue v hM hr hk).val n -
        main n / ((M₀ * ℓ).totient : ℝ)| ≤ E) :
    |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
        ((Finset.range N).filter Nat.Prime) Ψ r -
      (1 / (ℓ.totient : ℝ)) *
        weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) main| ≤
      variation (fun Q => Ψ (c * r * Q + 1)) N * E := by
  rw [sievedPrimeSum_eq_weightedPrimeSum N Ψ hc hu hr hM hk, ← weightedModel_mul hM]
  exact weightedPrimeSum_error _ _ _ _ _ hzero hprefix

/-- Every combined residue passed to the classical maximal-error theorem is
indeed reduced, including composite squarefree sieve moduli. -/
theorem combinedResidue_val_coprime {M₀ c r ℓ v : ℕ} [NeZero M₀] [NeZero ℓ]
    (hM : M₀.Coprime ℓ) (hr : r.Coprime M₀) (hk : (c * r).Coprime ℓ)
    (hv : v.Coprime M₀) :
    (PrimeProgressions.combinedResidue v hM hr hk).val.Coprime (M₀ * ℓ) := by
  apply (ZMod.isUnit_iff_coprime _ _).mp
  rw [ZMod.natCast_zmod_val]
  exact PrimeProgressions.combinedResidue_isUnit hM hr hk hv

/-- The direct BV reduction for the actual `A_r(ℓ)` on good moduli. The sole
analytic premise is an unweighted maximal prefix-error majorant. -/
theorem sum_sievedPrimeSum_errors {c M₀ v r : ℕ} [NeZero M₀]
    (s moduli : Finset ℕ) (N : ℕ) (Ψ : ℕ → ℝ) (main : ℕ → ℝ) (E : ℕ → ℝ)
    (hc : c ≠ 0) (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀) (hv : v.Coprime M₀)
    (hs : ∀ ℓ ∈ s, 0 < ℓ ∧ M₀.Coprime ℓ ∧ (c * r).Coprime ℓ)
    (hmod : ∀ ℓ ∈ s, M₀ * ℓ ∈ moduli) (hzero : main 0 = 0)
    {V B : ℝ} (hV : 0 ≤ V) (hvar : variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V)
    (hE : ∀ q ∈ moduli, 0 ≤ E q)
    (hprefix : ∀ q ∈ moduli, ∀ a : ℕ, a < q → a.Coprime q → ∀ n ≤ N,
      |primePrefix q a n - main n / (q.totient : ℝ)| ≤ E q)
    (hBV : ∑ q ∈ moduli, E q ≤ B) :
    (∑ ℓ ∈ s, |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
        ((Finset.range N).filter Nat.Prime) Ψ r -
      (1 / (ℓ.totient : ℝ)) *
        weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) main|) ≤ V * B := by
  have hsum : (∑ ℓ ∈ s, E (M₀ * ℓ)) ≤ ∑ q ∈ moduli, E q := by
    apply Finset.sum_le_sum_of_injOn (fun ℓ => M₀ * ℓ)
      (fixed_modulus_injective (NeZero.pos M₀)).injOn
    · intro q hq
      obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.mp hq
      exact hmod ℓ hℓ
    · intro ℓ hℓ
      exact le_rfl
    · intro q hq hnot
      exact hE q hq
  calc
    _ ≤ ∑ ℓ ∈ s, V * E (M₀ * ℓ) := by
      apply Finset.sum_le_sum
      intro ℓ hℓ
      obtain ⟨hℓpos, hM, hk⟩ := hs ℓ hℓ
      let : NeZero ℓ := ⟨hℓpos.ne'⟩
      have he := sievedPrimeSum_error N Ψ main hc hu hr hM hk hzero
        (fun n hn => hprefix _ (hmod ℓ hℓ) _ (ZMod.val_lt _)
          (combinedResidue_val_coprime hM hr hk hv) n hn)
      exact he.trans (mul_le_mul_of_nonneg_right hvar (hE _ (hmod ℓ hℓ)))
    _ = V * ∑ ℓ ∈ s, E (M₀ * ℓ) := (Finset.mul_sum _ _ _).symm
    _ ≤ V * B := mul_le_mul_of_nonneg_left (hsum.trans hBV) hV

/-- The exact manuscript density, including the zero on excluded moduli. -/
noncomputable def sieveDensity (M r ℓ : ℕ) : ℝ :=
  if ℓ.Coprime (M * r) then 1 / (ℓ.totient : ℝ) else 0

theorem sieveDensity_nonneg (M r ℓ : ℕ) : 0 ≤ sieveDensity M r ℓ := by
  unfold sieveDensity
  split <;> positivity

theorem sieveDensity_one (M r : ℕ) : sieveDensity M r 1 = 1 := by
  simp [sieveDensity]

/-- Insert all excluded sieve moduli with zero error. Thus the finite BV
reduction already has exactly the density occurring in the manuscript. -/
theorem sum_all_sievedPrimeSum_errors {c M₀ v r : ℕ} [NeZero M₀]
    (s moduli : Finset ℕ) (N : ℕ) (Ψ : ℕ → ℝ) (main : ℕ → ℝ) (E : ℕ → ℝ)
    (hc : c ≠ 0) (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hv : v.Coprime M₀) (huM : (c * v + 1).Coprime (c * M₀))
    (hs : ∀ ℓ ∈ s, 0 < ℓ)
    (hmod : ∀ ℓ ∈ s, ℓ.Coprime ((c * M₀) * r) → M₀ * ℓ ∈ moduli)
    (hzero : main 0 = 0) {V B : ℝ} (hV : 0 ≤ V)
    (hvar : variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V)
    (hE : ∀ q ∈ moduli, 0 ≤ E q)
    (hprefix : ∀ q ∈ moduli, ∀ a : ℕ, a < q → a.Coprime q → ∀ n ≤ N,
      |primePrefix q a n - main n / (q.totient : ℝ)| ≤ E q)
    (hBV : ∑ q ∈ moduli, E q ≤ B) :
    (∑ ℓ ∈ s, |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
        ((Finset.range N).filter Nat.Prime) Ψ r -
      sieveDensity (c * M₀) r ℓ *
        weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) main|) ≤ V * B := by
  classical
  have hgood : ∀ ℓ ∈ s.filter (fun ℓ => ℓ.Coprime ((c * M₀) * r)),
      0 < ℓ ∧ M₀.Coprime ℓ ∧ (c * r).Coprime ℓ := by
    intro ℓ hℓ
    obtain ⟨hℓs, hcop⟩ := Finset.mem_filter.mp hℓ
    rw [Nat.coprime_mul_iff_right, Nat.coprime_mul_iff_right] at hcop
    exact ⟨hs ℓ hℓs, hcop.1.2.symm, hcop.1.1.symm.mul_left hcop.2.symm⟩
  have he := sum_sievedPrimeSum_errors (s.filter (fun ℓ => ℓ.Coprime ((c * M₀) * r)))
    moduli N Ψ main E hc hu hr hv hgood
    (fun ℓ hℓ => hmod ℓ (Finset.mem_filter.mp hℓ).1 (Finset.mem_filter.mp hℓ).2)
    hzero hV hvar hE hprefix hBV
  rw [Finset.sum_filter] at he
  convert he using 1
  apply Finset.sum_congr rfl
  intro ℓ hℓ
  by_cases hg : ℓ.Coprime ((c * M₀) * r)
  · unfold sieveDensity
    split_ifs
    rfl
  · rw [PrimeProgressions.sievedPrimeSum_eq_zero _ _ huM hg]
    simp [sieveDensity, hg]

/-- The actual recentered error, including the modulus-one base count, is
derived from prefix BV and the classical reciprocal-totient sum. -/
theorem recentered_sievedPrimeSum_errors {c M₀ v r : ℕ} [NeZero M₀]
    (s moduli : Finset ℕ) (N : ℕ) (Ψ : ℕ → ℝ) (main : ℕ → ℝ) (E : ℕ → ℝ)
    (hc : c ≠ 0) (hu : c * v + 1 < c * M₀) (hr : r.Coprime M₀)
    (hv : v.Coprime M₀) (huM : (c * v + 1).Coprime (c * M₀))
    (hs : ∀ ℓ ∈ s, 0 < ℓ) (hone : 1 ∈ s)
    (hmod : ∀ ℓ ∈ s, ℓ.Coprime ((c * M₀) * r) → M₀ * ℓ ∈ moduli)
    (hzero : main 0 = 0) {V B G : ℝ} (hV : 0 ≤ V)
    (hvar : variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V)
    (hE : ∀ q ∈ moduli, 0 ≤ E q)
    (hprefix : ∀ q ∈ moduli, ∀ a : ℕ, a < q → a.Coprime q → ∀ n ≤ N,
      |primePrefix q a n - main n / (q.totient : ℝ)| ≤ E q)
    (hBV : ∑ q ∈ moduli, E q ≤ B)
    (hG : ∑ ℓ ∈ s, sieveDensity (c * M₀) r ℓ ≤ G) :
    (∑ ℓ ∈ s, |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
        ((Finset.range N).filter Nat.Prime) Ψ r -
      sieveDensity (c * M₀) r ℓ *
        CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
          ((Finset.range N).filter Nat.Prime) Ψ r|) ≤ (1 + G) * (V * B) := by
  exact Artin.distribution_error_of_direct_bound s
    (fun ℓ => PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
      ((Finset.range N).filter Nat.Prime) Ψ r)
    (sieveDensity (c * M₀) r) hone _ _ (V * B) G
    (PrimeProgressions.sievedPrimeSum_one _ _ _ _ _ _)
    (sieveDensity_one _ _) (fun ℓ _ => sieveDensity_nonneg _ _ ℓ) hG
    (sum_all_sievedPrimeSum_errors s moduli N Ψ main E hc hu hr hv huM hs hmod
      hzero hV hvar hE hprefix hBV)

/-- The BV source itself now supplies the direct bound for the actual
arithmetic sums, uniformly in all fixed progression and cofactor choices
satisfying the displayed modulus and variation bounds. -/
theorem BombieriVinogradovSource.sieved (hBV : BombieriVinogradovSource)
    {A η V : ℝ} (hA : 0 < A) (hη : 0 < η) (hη' : η < 1 / 2) (hV : 0 ≤ V) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ T : ℝ in Filter.atTop,
      ∀ c M₀ v r : ℕ, ∀ _ : NeZero M₀,
      c ≠ 0 → c * v + 1 < c * M₀ → r.Coprime M₀ → v.Coprime M₀ →
      (c * v + 1).Coprime (c * M₀) →
      ∀ s : Finset ℕ, (∀ ℓ ∈ s, 0 < ℓ) →
      (∀ ℓ ∈ s, ((M₀ * ℓ : ℕ) : ℝ) ≤ T ^ (1 / 2 - η)) →
      ∀ N : ℕ, (N : ℝ) ≤ T → ∀ Ψ : ℕ → ℝ,
      variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V →
      (∑ ℓ ∈ s, |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
          ((Finset.range N).filter Nat.Prime) Ψ r -
        sieveDensity (c * M₀) r ℓ *
          weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) logarithmicIntegral|) ≤
        V * (C * T / (Real.log T) ^ A) := by
  obtain ⟨C, hC, he⟩ := hBV A η hA hη hη'
  refine ⟨C, hC, ?_⟩
  filter_upwards [he] with T hT
  obtain ⟨E, hE, hprefix, hsum⟩ := hT
  intro c M₀ v r hM₀ hc hu hr hv huM s hs hmod N hN Ψ hvar
  exact sum_all_sievedPrimeSum_errors s _ N Ψ logarithmicIntegral E hc hu hr hv huM hs
    (fun ℓ hℓ _ => Finset.mem_Icc.mpr
      ⟨Nat.mul_pos (NeZero.pos M₀) (hs ℓ hℓ), Nat.le_floor (hmod ℓ hℓ)⟩)
    logarithmicIntegral_zero hV hvar hE
    (fun q hq a ha hacop n hn => hprefix q hq a ha hacop n
      ((by exact_mod_cast hn : (n : ℝ) ≤ N).trans hN)) hsum

/-- The changing prime scale has a uniform lower bound for every cofactor. -/
theorem primeScale_lower {x r c ε : ℝ} (hx : 0 < x) (hr : 0 < r)
    (hc : 0 < c) (hrange : r ≤ x ^ ε) :
    x ^ (1 - ε) / c ≤ x / (c * r) := by
  rw [Real.rpow_sub hx, Real.rpow_one]
  calc
    x / x ^ ε / c ≤ (x / r) / c :=
      div_le_div_of_nonneg_right (div_le_div_of_nonneg_left hx.le hr hrange) hc.le
    _ = x / (c * r) := by ring

/-- An arbitrary source threshold is reached simultaneously for all
`r ≤ x^ε`. This makes the eventual quantifier in BV usable at the actual
varying prime scale, rather than separately for each fixed cofactor. -/
theorem eventually_primeScale_ge {c ε : ℝ} (hc : 0 < c) (hε : ε < 1) (T₀ : ℝ) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ r : ℝ,
      0 < r → r ≤ x ^ ε → T₀ ≤ x / (c * r) := by
  have hpow : ∀ᶠ x : ℝ in Filter.atTop, c * T₀ ≤ x ^ (1 - ε) :=
    (tendsto_rpow_atTop (by linarith : 0 < 1 - ε)).eventually (Filter.eventually_ge_atTop _)
  filter_upwards [hpow, Filter.eventually_gt_atTop (0 : ℝ)] with x hp hx
  intro r hr hrange
  have ht : T₀ ≤ x ^ (1 - ε) / c := (le_div_iff₀ hc).mpr (by nlinarith)
  exact ht.trans (primeScale_lower hx hr hc hrange)

/-- A fixed logarithmic comparison, independent of every `ε ≤ 0.01`. -/
theorem eventually_primeScale_log_lower {c : ℝ} (hc : 0 < c) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ ε r : ℝ,
      ε ≤ 1 / 100 → 0 < r → r ≤ x ^ ε →
        (49 / 50 : ℝ) * Real.log x ≤ Real.log (x / (c * r)) := by
  have hpow : ∀ᶠ x : ℝ in Filter.atTop, c ≤ x ^ (1 / 100 : ℝ) :=
    (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 1 / 100)).eventually
      (Filter.eventually_ge_atTop _)
  filter_upwards [hpow, Filter.eventually_gt_atTop (1 : ℝ)] with x hp hx
  intro ε r hε hr hrange
  have hx0 : 0 < x := by linarith
  have hr' : r ≤ x ^ (1 / 100 : ℝ) := hrange.trans
    (Real.rpow_le_rpow_of_exponent_le hx.le hε)
  have hcr : c * r ≤ x ^ (1 / 50 : ℝ) := by
    calc
      c * r ≤ x ^ (1 / 100 : ℝ) * x ^ (1 / 100 : ℝ) :=
        mul_le_mul hp hr' hr.le (Real.rpow_nonneg hx0.le _)
      _ = _ := by rw [← Real.rpow_add hx0]; norm_num
  have hs : x ^ (49 / 50 : ℝ) ≤ x / (c * r) := by
    have hh := div_le_div_of_nonneg_left hx0.le (mul_pos hc hr) hcr
    have hid : x / x ^ (1 / 50 : ℝ) = x ^ (49 / 50 : ℝ) := by
      rw [show (49 / 50 : ℝ) = 1 - 1 / 50 by norm_num, Real.rpow_sub hx0, Real.rpow_one]
    rwa [hid] at hh
  have hlog := Real.log_le_log (Real.rpow_pos_of_pos hx0 _) hs
  simpa only [Real.log_rpow hx0] using hlog

/-- Transfer a classical power-of-log error from the prime scale to `x`.
The constant is independent of the cofactor. -/
theorem primeScale_error_bound {x r c A V C : ℝ}
    (hx : 1 < x) (hr : 0 < r) (hc : 1 ≤ c) (hA : 0 ≤ A)
    (hV : 0 ≤ V) (hC : 0 ≤ C)
    (hlog : (49 / 50 : ℝ) * Real.log x ≤ Real.log (3 * x / (c * r))) :
    V * (C * (3 * x / (c * r)) / (Real.log (3 * x / (c * r))) ^ A) ≤
      (3 * V * C / (49 / 50 : ℝ) ^ A) * (x / r) / (Real.log x) ^ A := by
  have hx0 : 0 < x := by linarith
  have hc0 : 0 < c := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx
  have hδ : 0 < (49 / 50 : ℝ) := by norm_num
  have hden : 0 < ((49 / 50 : ℝ) * Real.log x) ^ A :=
    Real.rpow_pos_of_pos (mul_pos hδ hL) A
  have hpow : ((49 / 50 : ℝ) * Real.log x) ^ A ≤
      (Real.log (3 * x / (c * r))) ^ A :=
    Real.rpow_le_rpow (mul_nonneg hδ.le hL.le) hlog hA
  have hT : 3 * x / (c * r) ≤ 3 * x / r := by
    apply div_le_div_of_nonneg_left (by positivity) hr
    nlinarith
  calc
    _ ≤ V * (C * (3 * x / r) / (((49 / 50 : ℝ) * Real.log x) ^ A)) := by
      apply mul_le_mul_of_nonneg_left _ hV
      exact div_le_div₀ (mul_nonneg hC (by positivity))
        (mul_le_mul_of_nonneg_left hT hC) hden hpow
    _ = _ := by rw [Real.mul_rpow hδ.le hL.le]; ring

/-- The actual direct distribution estimate uniformly over the growing
cofactor range. The external BV input is invoked at `3x/(cr)`, and every
threshold and logarithmic conversion is performed uniformly in `r`. -/
theorem BombieriVinogradovSource.uniform_cofactors (hBV : BombieriVinogradovSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A V : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (hA : 0 < A) (hV : 0 < V) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in Filter.atTop,
      ∀ r : ℕ, 0 < r → (r : ℝ) ≤ x ^ ε → r.Coprime M₀ →
      ∀ s : Finset ℕ, (∀ ℓ ∈ s, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2)) →
      ∀ N : ℕ, (N : ℝ) ≤ 3 * x / ((c : ℝ) * r) → ∀ Ψ : ℕ → ℝ,
      variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V →
      (∑ ℓ ∈ s, |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
          ((Finset.range N).filter Nat.Prime) Ψ r -
        sieveDensity (c * M₀) r ℓ *
          weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) logarithmicIntegral|) ≤
        C * (x / r) / (Real.log x) ^ A := by
  have hc : (0 : ℝ) < c := by exact_mod_cast NeZero.pos c
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  have hc3 : 0 < (c : ℝ) / 3 := by positivity
  have hη : (0 : ℝ) < (κ - ε) / 4 := by linarith
  have hη' : (κ - ε) / 4 < (1 / 2 : ℝ) := by linarith
  obtain ⟨C, hC, he⟩ := hBV.sieved hA hη hη' hV.le
  obtain ⟨T₀, hT₀⟩ := Filter.eventually_atTop.mp he
  have hscale := eventually_primeScale_ge hc3 (show ε < 1 by linarith) T₀
  have hlog := eventually_primeScale_log_lower hc3
  have hmod := Artin.eventually_manuscript_bv_range hc3
    (Nat.cast_nonneg M₀) hε hεκ (show κ < 1 by linarith)
  refine ⟨3 * V * C / (49 / 50 : ℝ) ^ A, by positivity, ?_⟩
  filter_upwards [hscale, hlog, hmod, Filter.eventually_gt_atTop (1 : ℝ)] with x hsc hlg hmd hx
  intro r hr hrange hrM s hs N hN Ψ hvar
  have hr0 : (0 : ℝ) < r := by exact_mod_cast hr
  have hid : x / (((c : ℝ) / 3) * r) = 3 * x / ((c : ℝ) * r) := by ring
  have hT : T₀ ≤ 3 * x / ((c : ℝ) * r) := by
    rw [← hid]
    exact hsc r hr0 hrange
  have hlog' : (49 / 50 : ℝ) * Real.log x ≤ Real.log (3 * x / ((c : ℝ) * r)) := by
    rw [← hid]
    exact hlg ε r (by linarith) hr0 hrange
  have hm : ∀ ℓ ∈ s,
      ((M₀ * ℓ : ℕ) : ℝ) ≤ (3 * x / ((c : ℝ) * r)) ^ (1 / 2 - (κ - ε) / 4) := by
    intro ℓ hℓ
    have hh := hmd r ℓ hr0 hrange (hs ℓ hℓ).2
    simpa only [Nat.cast_mul, hid] using hh
  have hd := hT₀ _ hT c M₀ v r inferInstance (NeZero.ne c) hu hrM hv huM s
    (fun ℓ hℓ => (hs ℓ hℓ).1) hm N hN Ψ hvar
  exact hd.trans (primeScale_error_bound hx hr0 hc1 hA.le hV.le hC.le hlog')

/-- The full cofactor-weighted and recentered distribution estimate. There is
no bound on the number of cofactors or on their weights: their exact harmonic
mass is retained. The remaining density-sum input is the classical elementary
reciprocal-totient estimate, rather than a prime-distribution assertion. -/
theorem BombieriVinogradovSource.weighted_recentered (hBV : BombieriVinogradovSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A V G : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (hA : 0 < A) (hV : 0 < V) (hG : 0 ≤ G) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in Filter.atTop,
      ∀ R s : Finset ℕ,
      (∀ r ∈ R, 0 < r ∧ (r : ℝ) ≤ x ^ ε ∧ r.Coprime M₀) →
      (∀ ℓ ∈ s, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2)) → 1 ∈ s →
      ∀ t : ℕ → ℝ, (∀ r ∈ R, 0 ≤ t r) → ∀ N : ℕ → ℕ,
      (∀ r ∈ R, (N r : ℝ) ≤ 3 * x / ((c : ℝ) * r)) → ∀ Ψ : ℕ → ℝ,
      (∀ r ∈ R, variation (fun Q => Ψ (c * r * Q + 1)) (N r) ≤ V) →
      (∀ r ∈ R, ∑ ℓ ∈ s, sieveDensity (c * M₀) r ℓ ≤ G * Real.log x) →
      (∑ r ∈ R, t r * ∑ ℓ ∈ s,
        |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
            ((Finset.range (N r)).filter Nat.Prime) Ψ r -
          sieveDensity (c * M₀) r ℓ *
            CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
              ((Finset.range (N r)).filter Nat.Prime) Ψ r|) ≤
        C * x / (Real.log x) ^ A * ∑ r ∈ R, t r / r := by
  obtain ⟨C, hC, he⟩ := hBV.uniform_cofactors hu hv huM hε hεκ hκ
    (show 0 < A + 1 by linarith) hV
  refine ⟨(1 + G) * C, by positivity, ?_⟩
  filter_upwards [he, Filter.eventually_ge_atTop (Real.exp 1)] with x hd hx
  have hx1 : 1 < x := (Real.one_lt_exp_iff.mpr (by norm_num : (0 : ℝ) < 1)).trans_le hx
  have hL : 1 ≤ Real.log x := by
    have hh := Real.log_le_log (Real.exp_pos 1) hx
    simpa only [Real.log_exp] using hh
  have hx0 : 0 < x := by linarith
  have hL0 : 0 < Real.log x := Real.log_pos hx1
  intro R s hR hs hone t ht N hN Ψ hvar hsum
  let count : ℕ → ℕ → ℝ := fun r ℓ =>
    PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
      ((Finset.range (N r)).filter Nat.Prime) Ψ r
  let mass : ℕ → ℝ := fun r =>
    CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
      ((Finset.range (N r)).filter Nat.Prime) Ψ r
  let main : ℕ → ℝ := fun r =>
    weightedModel M₀ (N r) (fun Q => Ψ (c * r * Q + 1)) logarithmicIntegral
  have hdirect : ∀ r ∈ R,
      (∑ ℓ ∈ s, |count r ℓ - sieveDensity (c * M₀) r ℓ * main r|) ≤
        x / r * ((C / (Real.log x) ^ A) / Real.log x) := by
    intro r hr
    have hh := hd r (hR r hr).1 (hR r hr).2.1 (hR r hr).2.2 s hs (N r) (hN r hr) Ψ (hvar r hr)
    have heq : C * (x / r) / (Real.log x) ^ (A + 1) =
        x / r * ((C / (Real.log x) ^ A) / Real.log x) := by
      rw [Real.rpow_add hL0, Real.rpow_one]
      ring
    simpa only [heq, count, main] using hh
  have hw := Artin.weighted_distribution_with_log_loss R s t count
    (sieveDensity (c * M₀)) mass main hone x (C / (Real.log x) ^ A) (Real.log x) G
    hx0.le (by positivity) hL ht
    (fun r _ => PrimeProgressions.sievedPrimeSum_one _ _ _ _ _ _)
    (fun r _ => sieveDensity_one _ _)
    (fun r _ ℓ _ => sieveDensity_nonneg _ _ _) hsum hdirect
  convert hw using 1; ring

/-- An upper bound for reciprocal totients immediately bounds every local
density sum, uniformly in the cofactor. -/
theorem sieveDensity_sum_le_reciprocal_totients (M r : ℕ) (s : Finset ℕ) :
    (∑ ℓ ∈ s, sieveDensity M r ℓ) ≤ ∑ ℓ ∈ s, 1 / (ℓ.totient : ℝ) := by
  apply Finset.sum_le_sum
  intro ℓ hℓ
  unfold sieveDensity
  split
  · exact le_rfl
  · positivity

/-- The fixed-modulus prime number theorem after the proved Abel step. -/
theorem FixedModulusPNTSource.smoothed (hPNT : FixedModulusPNTSource)
    {q : ℕ} (hq : 0 < q) {A V : ℝ} (hA : 0 < A) (_hV : 0 ≤ V) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ T : ℝ in Filter.atTop,
      ∀ a : ℕ, a < q → a.Coprime q → ∀ N : ℕ, (N : ℝ) ≤ T →
      ∀ w : ℕ → ℝ, variation w N ≤ V →
        |weightedPrimeSum q a N w - weightedModel q N w logarithmicIntegral| ≤
          V * (C * T / (Real.log T) ^ A) := by
  obtain ⟨C, hC, he⟩ := hPNT q hq A hA
  refine ⟨C, hC, ?_⟩
  filter_upwards [he, Filter.eventually_gt_atTop (1 : ℝ)] with T hT hTpos
  intro a ha hacop N hN w hw
  have hLT : 0 < Real.log T := Real.log_pos hTpos
  have he := weightedPrimeSum_error q a N w logarithmicIntegral logarithmicIntegral_zero
    (fun n hn => hT a ha hacop n ((by exact_mod_cast hn : (n : ℝ) ≤ N).trans hN))
  exact he.trans (mul_le_mul_of_nonneg_right hw (by positivity))

/-- Fixed-modulus PNT for the actual base count, uniformly throughout a fixed
cofactor power range. Constants are chosen before any marking parameters or
smaller exponent `ε` are introduced. -/
theorem FixedModulusPNTSource.uniform_cofactors (hPNT : FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {A V : ℝ} (hA : 0 < A) (hV : 0 < V) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in Filter.atTop,
      ∀ r : ℕ, 0 < r → (r : ℝ) ≤ x ^ (1 / 100 : ℝ) → r.Coprime M₀ →
      ∀ N : ℕ, (N : ℝ) ≤ 3 * x / ((c : ℝ) * r) → ∀ Ψ : ℕ → ℝ,
      variation (fun Q => Ψ (c * r * Q + 1)) N ≤ V →
      |CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
          ((Finset.range N).filter Nat.Prime) Ψ r -
        weightedModel M₀ N (fun Q => Ψ (c * r * Q + 1)) logarithmicIntegral| ≤
        C * (x / r) / (Real.log x) ^ A := by
  have hc : (0 : ℝ) < c := by exact_mod_cast NeZero.pos c
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  have hc3 : 0 < (c : ℝ) / 3 := by positivity
  obtain ⟨C, hC, he⟩ := hPNT M₀ (NeZero.pos M₀) A hA
  obtain ⟨T₀, hT₀⟩ := Filter.eventually_atTop.mp he
  have hscale := eventually_primeScale_ge hc3 (by norm_num : (1 / 100 : ℝ) < 1) T₀
  have hlog := eventually_primeScale_log_lower hc3
  refine ⟨3 * V * C / (49 / 50 : ℝ) ^ A, by positivity, ?_⟩
  filter_upwards [hscale, hlog, Filter.eventually_gt_atTop (1 : ℝ)] with x hsc hlg hx
  intro r hr hrange hrM N hN Ψ hvar
  have hr0 : (0 : ℝ) < r := by exact_mod_cast hr
  have hid : x / (((c : ℝ) / 3) * r) = 3 * x / ((c : ℝ) * r) := by ring
  have hT : T₀ ≤ 3 * x / ((c : ℝ) * r) := by
    rw [← hid]
    exact hsc r hr0 hrange
  have hlog' : (49 / 50 : ℝ) * Real.log x ≤ Real.log (3 * x / ((c : ℝ) * r)) := by
    rw [← hid]
    exact hlg (1 / 100) r le_rfl hr0 hrange
  have hM : M₀.Coprime 1 := Nat.coprime_one_right M₀
  have hk : (c * r).Coprime 1 := Nat.coprime_one_right _
  let a := PrimeProgressions.combinedResidue v hM hrM hk
  have ha : a.val < M₀ := by simpa only [Nat.mul_one] using ZMod.val_lt a
  have hacop : a.val.Coprime M₀ := by
    simpa only [Nat.mul_one] using combinedResidue_val_coprime hM hrM hk hv
  have hpref : ∀ n ≤ N,
      |primePrefix (M₀ * 1) a.val n - logarithmicIntegral n / ((M₀ * 1).totient : ℝ)| ≤
        C * (3 * x / ((c : ℝ) * r)) / (Real.log (3 * x / ((c : ℝ) * r))) ^ A := by
    intro n hn
    simpa only [Nat.mul_one] using hT₀ _ hT a.val ha hacop n
      ((by exact_mod_cast hn : (n : ℝ) ≤ N).trans hN)
  have hbase := sievedPrimeSum_error N Ψ logarithmicIntegral (NeZero.ne c) hu hrM hM hk
    logarithmicIntegral_zero hpref
  simp only [PrimeProgressions.sievedPrimeSum_one, Nat.totient_one, Nat.cast_one,
    div_one, one_mul] at hbase
  have hLT : 0 < Real.log (3 * x / ((c : ℝ) * r)) :=
    lt_of_lt_of_le (mul_pos (by norm_num) (Real.log_pos hx)) hlog'
  have hnn : 0 ≤ C * (3 * x / ((c : ℝ) * r)) /
      (Real.log (3 * x / ((c : ℝ) * r))) ^ A := by positivity
  exact hbase.trans ((mul_le_mul_of_nonneg_right hvar hnn).trans
    (primeScale_error_bound hx hr0 hc1 hA.le hV.le hC.le hlog'))

end Artin.PrimeDistribution
