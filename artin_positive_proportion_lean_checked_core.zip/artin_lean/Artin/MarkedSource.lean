module

public import Artin.MarkedCriterion
public import Artin.ConcreteSelector
public import Artin.MarkedBandTail
public import Mathlib.MeasureTheory.Constructions.Pi
public import Mathlib.Analysis.Calculus.ContDiff.Defs
public import Mathlib.Tactic.FunProp

/-!
# Exact cited-source interface and the marked-replacement application

The cited results in this file are **propositions supplied as theorem arguments**,
not global axioms. `SourceLemma10_2` is the source's scalar coefficient criterion;
it has no progression indicator or smooth product weight. Its coefficient input
is cancellation against every logarithmic modulus and frequency range. In
particular it does not assume MR. The quantitative source constant is uniform
over the selector, intervals, and the admissible coefficient family.
-/

@[expose] public section

open scoped BigOperators
open Filter MeasureTheory
open Artin.MarkedReplacement Artin.MarkedCriterion

namespace Artin.MarkedSource

/-- The exact roughness cutoff in source (10.1). -/
noncomputable def W (x : ℝ) : ℝ := Real.exp ((Real.log x) ^ (6 / 25 : ℝ))

/-- The finite Euler product `V(y)` in source (10.1). -/
noncomputable def eulerV (y : ℝ) : ℝ :=
  ∏ p ∈ Nat.primesLE ⌊y⌋₊, (1 - (p : ℝ)⁻¹)

/-- Prime-product density terms in source (10.11). The `j+2` clause integrates
in exactly `j+1` variables; the remaining prime is determined by their sum. -/
noncomputable def densityTerm (γ w : ℝ) : ℕ → ℝ
  | 0 => 0
  | 1 => w⁻¹
  | j + 2 => ((j + 2).factorial : ℝ)⁻¹ *
      ∫ t : Fin (j + 1) → ℝ in
        {t | (∀ i, γ ≤ t i) ∧ (∑ i, t i) ≤ w - γ},
        (w - ∑ i, t i)⁻¹ * ∏ i, (t i)⁻¹

/-- The cited density. On `w > γ`, this is the locally finite sum (10.11). -/
noncomputable def density (γ w : ℝ) : ℝ := ∑' j : ℕ, densityTerm γ w j

noncomputable def discrepancy (γ x : ℝ) (m : ℕ) : ℂ :=
  roughDiscrepancy (density γ) eulerV γ (6 / 25) x m

/-- One of the actual prime bands (10.2), including both endpoints. -/
noncomputable def primeBand (a x : ℝ) : Finset ℕ := by
  classical
  exact (Nat.primesLE ⌊Real.exp (2 * (Real.log x) ^ a)⌋₊).filter
    (fun p => Real.exp ((Real.log x) ^ a) ≤ (p : ℝ))

structure Bands (K : ℕ) where
  exponent : Fin K → ℝ
  increasing : StrictMono exponent
  lower : ∀ i, (1 / 10 : ℝ) < exponent i
  upper : ∀ i, exponent i < (1 / 5 : ℝ)

noncomputable def Bands.group {K : ℕ} (b : Bands K) (x : ℝ) (i : Fin K) : Finset ℕ :=
  primeBand (b.exponent i) x

noncomputable def Bands.mass {K : ℕ} (b : Bands K) (x : ℝ) (i : Fin K) : ℝ :=
  ∑ p ∈ b.group x i, (p : ℝ)⁻¹

noncomputable def Bands.primes {K : ℕ} (b : Bands K) (x : ℝ) : Finset ℕ :=
  Finset.univ.biUnion (b.group x)

theorem Bands.group_prime {K : ℕ} (b : Bands K) (x : ℝ) {i : Fin K} {p : ℕ}
    (hp : p ∈ b.group x i) : p.Prime :=
  (Nat.mem_primesLE.mp (Finset.mem_filter.mp hp).1).2

theorem Bands.group_subset {K : ℕ} (b : Bands K) (x : ℝ) (i : Fin K) :
    b.group x i ⊆ b.primes x := by
  classical
  intro p hp
  exact Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ _, hp⟩

/-- The MR and mass/tail modules use literally the same closed prime bands;
the different finite enumerations include precisely the same primes. -/
theorem primeBand_eq_markedBandTail (a x : ℝ) :
    primeBand a x = MarkedBandTail.primeBand a x := by
  classical
  ext p
  rw [MarkedBandTail.mem_primeBand]
  rw [primeBand,Finset.mem_filter,Nat.mem_primesLE]
  constructor
  · rintro ⟨⟨hp,hprime⟩,hlower⟩
    exact ⟨hprime,hlower,(Nat.le_floor_iff (Real.exp_pos _).le).mp hp⟩
  · rintro ⟨hprime,hlower,hupper⟩
    exact ⟨⟨Nat.le_floor hupper,hprime⟩,hlower⟩

theorem Bands.group_eq_markedBandTail {K : ℕ} (b : Bands K) (x : ℝ) (i : Fin K) :
    b.group x i = MarkedBandTail.primeBand (b.exponent i) x :=
  primeBand_eq_markedBandTail _ _

theorem Bands.mass_eq_markedBandTail {K : ℕ} (b : Bands K) (x : ℝ) (i : Fin K) :
    b.mass x i = MarkedBandTail.bandMass (b.exponent i) x := by
  simp only [Bands.mass,Bands.group_eq_markedBandTail,MarkedBandTail.bandMass,one_div]

theorem Bands.primes_eq_markedBandTail {K : ℕ} (b : Bands K) (x : ℝ) :
    b.primes x = Finset.univ.biUnion (fun i => MarkedBandTail.primeBand (b.exponent i) x) := by
  unfold Bands.primes
  congr 1
  exact funext (b.group_eq_markedBandTail x)

/-- A product convention valid also when a group count is zero. When every
count is positive it is exactly `q^(ω-K) ∏ ωᵢ/Vᵢ` from (10.4); otherwise both
source and this convention give zero. -/
noncomputable def markedWeight {K : ℕ} (b : Bands K) (q x : ℝ) (h : ℕ) : ℝ :=
  ∏ i : Fin K, ((ConcreteSelector.primeCount (b.group x i) h : ℝ) *
    q ^ (ConcreteSelector.primeCount (b.group x i) h - 1)) / b.mass x i

theorem markedWeight_half {K : ℕ} (b : Bands K) (x : ℝ) (h : ℕ) :
    markedWeight b (1/2) x h =
      ConcreteSelector.markingWeight Finset.univ (b.group x) (b.mass x) h := by
  unfold markedWeight ConcreteSelector.markingWeight
  apply Finset.prod_congr rfl
  intro i _
  simp [MarkedWeights.groupWeight, MarkedWeights.countFactor, div_eq_mul_inv]

/-- Thus the normalized MR weight equals the normalized weight used by the
actual marked-mass and Rankin-tail theorems, with no identification hypothesis. -/
theorem markedWeight_half_eq_markedBandTail {K : ℕ} (b : Bands K) (x : ℝ) (h : ℕ) :
    markedWeight b (1/2) x h =
      ConcreteSelector.markingWeight Finset.univ
        (fun i => MarkedBandTail.primeBand (b.exponent i) x)
        (fun i => MarkedBandTail.bandMass (b.exponent i) x) h := by
  rw [markedWeight_half,funext (b.group_eq_markedBandTail x),
    funext (b.mass_eq_markedBandTail x)]

/-- The source needs invariance for every positive `h`, without a
coprimality or squarefreeness condition. -/
def InvariantSelector {K : ℕ} (b : Bands K) (x : ℝ) (F : ℕ → ℂ) : Prop :=
  (∀ h, ‖F h‖ ≤ 1) ∧
    ∀ i : Fin K, ∀ p ∈ b.group x i, ∀ h : ℕ, 0 < h → F (p*h) = F h

/-- The actual cofactor selector from Section 5, viewed as a complex function. -/
noncomputable def actualSelector {K : ℕ} (b : Bands K) (x : ℝ)
    (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (h : ℕ) : ℂ :=
  (ConcreteSelector.selector (b.primes x) c allowed Qmin h : ℝ)

theorem actualSelector_invariant {K : ℕ} (b : Bands K) (x : ℝ)
    (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) :
    InvariantSelector b x (actualSelector b x c allowed Qmin) := by
  constructor
  · intro h
    rw [actualSelector, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (ConcreteSelector.selector_bounds _ _ _ _ _).1]
    exact (ConcreteSelector.selector_bounds _ _ _ _ _).2
  · intro i p hp h hh
    unfold actualSelector
    rw [ConcreteSelector.selector_mul_marked_prime _ _ _ _
      (b.group_prime x hp) (b.group_subset x i hp) (Nat.ne_of_gt hh)]

/-- Intervals in the m-dyad, represented by their integer endpoints. Empty
intervals are allowed. Every half-open real interval in that dyad has this
representation on the positive integers. -/
def IntervalInDyad (H : ℝ) (s : Finset ℕ) : Prop :=
  ∃ lo hi : ℕ, s = Finset.Icc lo hi ∧ H ≤ lo ∧ (hi : ℝ) ≤ 2*H

def InDyad (H : ℝ) (t : Finset ℕ) : Prop :=
  ∀ n ∈ t, H ≤ n ∧ (n : ℝ) ≤ 2*H

theorem IntervalInDyad.inDyad {H : ℝ} {s : Finset ℕ} (h : IntervalInDyad H s) :
    InDyad H s := by
  obtain ⟨lo, hi, rfl, hlo, hhi⟩ := h
  intro n hn
  obtain ⟨hnl, hnh⟩ := Finset.mem_Icc.mp hn
  exact ⟨hlo.trans (by exact_mod_cast hnl), (by exact_mod_cast hnh : (n:ℝ) ≤ hi).trans hhi⟩

/-- Fixed dyadic scales and fixed comparison constants. The redundant lower
bound `1` records an eventual consequence of `δ > 0`, convenient for counting
integer endpoints. -/
def DyadicScales (δ c₁ c₂ : ℝ) (Hm Hn : ℝ → ℝ) : Prop :=
  ∀ᶠ x : ℝ in atTop, 1 ≤ Hm x ∧ 1 ≤ Hn x ∧
    x ^ δ ≤ Hm x ∧ x ^ δ ≤ Hn x ∧
    c₁*x ≤ Hm x*Hn x ∧ Hm x*Hn x ≤ c₂*x

/-- Uniform version of (10.6). The admissibility predicate allows the real
phase to vary with `x`. One constant and threshold work for *all* indices. -/
def FamilyCancellation {J : Type} (α : ℝ → J → ℕ → ℂ)
    (admissible : ℝ → J → Prop) (Hm X : ℝ → ℝ) : Prop :=
  ∀ A₀ B A : ℝ, 0 < A₀ → 0 < B → 0 < A →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ j, admissible x j → ∀ lo hi k : ℕ,
      Hm x ≤ lo → (hi : ℝ) ≤ 2*Hm x →
      0 < k → (k : ℝ) ≤ (Real.log x)^A₀ →
      ∀ χ : DirichletCharacter ℂ k, ∀ t : ℝ,
      |t| ≤ 2*X x*(Real.log x)^B →
      ‖∑ n ∈ Finset.Icc lo hi, α x j n * χ (n : ZMod k) * archimedeanPhase t n‖ ≤
        C*Hm x*(Real.log x)^(-A)

/-- All non-cancellation hypotheses on a coefficient, restricted to the
finite summation domain. -/
def CoefficientOn (x C : ℝ) (s : Finset ℕ) (α : ℕ → ℂ) : Prop :=
  ∀ n ∈ s, ‖α n‖ ≤ (Real.log x)^C ∧ (α n ≠ 0 → IsRough (W x) n)

/-- A weaker fixed-scale presentation retained for the fixed-scale lemmas.
`sourceLemma10_2_fixed` proves this from the full uniform source contract below;
it is not an additional accepted input. No constant or onset can depend on
an admissible index, selector, interval, or second coefficient. -/
def FixedScaleCriterion : Prop :=
  ∀ (δ C D q c₁ c₂ : ℝ), 0 < δ → 0 < C → 0 < D →
    0 < q → q < 1 → 0 < c₁ → 0 < c₂ →
  ∀ (Hm Hn : ℝ → ℝ), DyadicScales δ c₁ c₂ Hm Hn →
  ∀ (J : Type) (α : ℝ → J → ℕ → ℂ) (admissible : ℝ → J → Prop),
    FamilyCancellation α admissible Hm (fun x => Hm x*Hn x) →
    (∀ᶠ x : ℝ in atTop, ∀ j, admissible x j → ∀ n : ℕ,
      Hm x ≤ n → (n:ℝ) ≤ 2*Hm x →
      ‖α x j n‖ ≤ (Real.log x)^C ∧ (α x j n ≠ 0 → IsRough (W x) n)) →
  ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
    ∃ E : ℝ, 0 < E ∧ ∀ᶠ x : ℝ in atTop,
      ∀ j, admissible x j → ∀ s t : Finset ℕ,
      IntervalInDyad (Hm x) s → InDyad (Hn x) t →
      ∀ β : ℕ → ℂ, CoefficientOn x C t β →
      ∀ F : ℕ → ℂ, InvariantSelector b x F →
      ‖bilinear s t (α x j) β (fun h => F h * (markedWeight b q x h : ℂ))‖ ≤
        E*(Hm x*Hn x)*(Real.log x)^(-D)

/-- The weaker fixed-scale transform/size presentation, proved below from
`SourceProposition10_3`. It contains no marked bilinear conclusion. The source's
real power twists are derived here, rather than assumed. -/
def FixedRoughCancellation : Prop :=
  ∀ γ sLo sHi : ℝ, 0 < γ → γ < sLo → sLo < sHi → sHi < 1 →
  ∀ δ c₁ c₂ : ℝ, 0 < δ → 0 < c₁ → 0 < c₂ →
  ∀ Hm Hn : ℝ → ℝ, DyadicScales δ c₁ c₂ Hm Hn →
    (∀ᶠ x : ℝ in atTop, sLo ≤ Real.log (Hm x)/Real.log x ∧
      Real.log (2*Hm x)/Real.log x ≤ sHi) →
    CoefficientCancellation (discrepancy γ) Hm (fun x => Hm x*Hn x) ∧
      (∀ᶠ x : ℝ in atTop, ∀ n : ℕ, Hm x ≤ n → (n:ℝ) ≤ 2*Hm x →
        ‖discrepancy γ x n‖ ≤ (Real.log x)^(2:ℝ))

/-- Scales may be indexed by a growing admissible collection of dyads.
All comparison constants and onsets are uniform over the active indices. -/
def ScaleFamily {J : Type} (δ c₁ c₂ : ℝ) (Hm Hn : ℝ → J → ℝ)
    (active : ℝ → J → Prop) : Prop :=
  ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
    1 ≤ Hm x j ∧ 1 ≤ Hn x j ∧ x^δ ≤ Hm x j ∧ x^δ ≤ Hn x j ∧
      c₁*x ≤ Hm x j*Hn x j ∧ Hm x j*Hn x j ≤ c₂*x

/-- Uniform (10.6), also across the dyad scales. The displayed transform
constant is common to all active dyads and all their subintervals. -/
def ScaleCancellation {J : Type} (α : ℝ → J → ℕ → ℂ)
    (active : ℝ → J → Prop) (Hm X : ℝ → J → ℝ) : Prop :=
  ∀ A₀ B A : ℝ, 0 < A₀ → 0 < B → 0 < A →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ j, active x j → ∀ lo hi k : ℕ,
      Hm x j ≤ lo → (hi:ℝ) ≤ 2*Hm x j →
      0 < k → (k:ℝ) ≤ (Real.log x)^A₀ →
      ∀ χ : DirichletCharacter ℂ k, ∀ t : ℝ,
      |t| ≤ 2*X x j*(Real.log x)^B →
      ‖∑ n ∈ Finset.Icc lo hi, α x j n * χ (n:ZMod k) * archimedeanPhase t n‖ ≤
        C*Hm x j*(Real.log x)^(-A)

/-- Exact uniform source criterion. The source proof chooses square accuracy
`D₁`, moment accuracy `E₀`, arc exponent `A₀`, and then `K`, before invoking
the coefficient-transform estimates at the resulting accuracies. Consequently
`K₀` depends only on `δ,C,D,q` and the fixed comparison constants: it precedes
both the bands and the scale/coefficient family and its cancellation profile.
The output constant and onset may depend on that *uniform* profile; neither
can depend on an active dyad, interval, second coefficient, or selector.
This is the scalar estimate (10.5), without a progression or smooth weight. -/
def SourceLemma10_2 : Prop :=
  ∀ δ C D q c₁ c₂ : ℝ, 0 < δ → 0 < C → 0 < D →
    0 < q → q < 1 → 0 < c₁ → 0 < c₂ →
  ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
  ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
    ScaleFamily δ c₁ c₂ Hm Hn active →
  ∀ α : ℝ → J → ℕ → ℂ,
    ScaleCancellation α active Hm (fun x j => Hm x j*Hn x j) →
    (∀ᶠ x : ℝ in atTop, ∀ j, active x j → ∀ n : ℕ,
      Hm x j ≤ n → (n:ℝ) ≤ 2*Hm x j →
      ‖α x j n‖ ≤ (Real.log x)^C ∧ (α x j n ≠ 0 → IsRough (W x) n)) →
    ∃ E : ℝ, 0 < E ∧ ∀ᶠ x : ℝ in atTop,
      ∀ j, active x j → ∀ s t : Finset ℕ,
      IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
      ∀ β : ℕ → ℂ, CoefficientOn x C t β →
      ∀ F : ℕ → ℂ, InvariantSelector b x F →
      ‖bilinear s t (α x j) β (fun h => F h*(markedWeight b q x h:ℂ))‖ ≤
        E*(Hm x j*Hn x j)*(Real.log x)^(-D)

/-- Uniform transform and size conclusion verified in the proof of source
Proposition 10.3. The fixed logarithmic exponent window supplies uniformity
across dyads; there is no marked bilinear estimate in this input. -/
def SourceProposition10_3 : Prop :=
  ∀ γ sLo sHi : ℝ, 0 < γ → γ < sLo → sLo < sHi → sHi < 1 →
  ∀ δ c₁ c₂ : ℝ, 0 < δ → 0 < c₁ → 0 < c₂ →
  ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
    ScaleFamily δ c₁ c₂ Hm Hn active →
    (∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      sLo ≤ Real.log (Hm x j)/Real.log x ∧
      Real.log (2*Hm x j)/Real.log x ≤ sHi) →
    ScaleCancellation (fun x _ => discrepancy γ x) active Hm
      (fun x j => Hm x j*Hn x j) ∧
      (∀ᶠ x : ℝ in atTop, ∀ j, active x j → ∀ n : ℕ,
        Hm x j ≤ n → (n:ℝ) ≤ 2*Hm x j →
        ‖discrepancy γ x n‖ ≤ (Real.log x)^(2:ℝ))

/-- The earlier fixed-scale presentation is a consequence of the uniform
source statement; it is not a separate accepted input. -/
theorem sourceLemma10_2_fixed (h : SourceLemma10_2) : FixedScaleCriterion := by
  intro δ C D q c₁ c₂ hδ hC hD hq hq1 hc₁ hc₂ Hm Hn hscale J α active hcan hcoeff
  obtain ⟨K₀,hK₀,hK⟩ := h δ C D q c₁ c₂ hδ hC hD hq hq1 hc₁ hc₂
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b
  apply hK K hKK b J (fun x _ => Hm x) (fun x _ => Hn x) active
    ?_ α hcan hcoeff
  filter_upwards [hscale] with x hx
  intro _ _
  exact hx

theorem sourceProposition10_3_fixed (h : SourceProposition10_3) : FixedRoughCancellation := by
  intro γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂ Hm Hn hscale hexp
  have hsf : ScaleFamily δ c₁ c₂ (fun x (_ : Unit) => Hm x)
      (fun x _ => Hn x) (fun _ _ => True) := by
    filter_upwards [hscale] with x hx
    intro _ _
    exact hx
  have hef : ∀ᶠ x : ℝ in atTop, ∀ _j : Unit, True →
      sLo ≤ Real.log (Hm x)/Real.log x ∧ Real.log (2*Hm x)/Real.log x ≤ sHi := by
    filter_upwards [hexp] with x hx
    intro _ _
    exact hx
  obtain ⟨hcan,hsize⟩ := h γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂ Unit
    (fun x _ => Hm x) (fun x _ => Hn x) (fun _ _ => True) hsf hef
  constructor
  · intro A₀ B A hA₀ hB hA
    obtain ⟨C,hC,hc⟩ := hcan A₀ B A hA₀ hB hA
    refine ⟨C,hC,?_⟩
    filter_upwards [hc] with x hx
    exact hx () trivial
  · filter_upwards [hsize] with x hx
    exact hx () trivial

/-- The normalization consequence of the prime number theorem and partial
summation: `Vᵢ = log 2 + o(1)` supplies a fixed positive lower bound. This is
separate from both cited marked results. -/
def ClassicalBandMass : Prop :=
  ∀ K : ℕ, ∀ b : Bands K, ∀ᶠ x : ℝ in atTop,
    ∀ i : Fin K, (Real.log 2)/2 ≤ b.mass x i

noncomputable def twistedDiscrepancy (γ : ℝ) (M : ℕ)
    (x : ℝ) (j : DirichletCharacter ℂ M × ℝ) (n : ℕ) : ℂ :=
  (discrepancy γ x n * j.1 (n : ZMod M)) * archimedeanPhase j.2 n

theorem discrepancy_family_cancellation {γ : ℝ} {M : ℕ} {Hm X : ℝ → ℝ}
    (hγ : 0 < γ) (hM : 0 < M)
    (hcan : CoefficientCancellation (discrepancy γ) Hm X)
    (hX : ∀ᶠ x : ℝ in atTop, 1 ≤ X x) :
    FamilyCancellation (twistedDiscrepancy γ M)
      (fun x j => |j.2| ≤ Real.log x) Hm X := by
  have h := rough_discrepancy_uniform_twists (density γ) eulerV hγ
    (by norm_num : (0:ℝ) < 6/25) (by norm_num : (6/25:ℝ) < 1) hM hcan hX
  intro A₀ B A hA₀ hB hA
  obtain ⟨C, hC, hc⟩ := h A₀ B A hA₀ hB hA
  refine ⟨C, hC, ?_⟩
  filter_upwards [hc] with x hx
  intro j hj
  exact hx j.1 j.2 hj

theorem discrepancy_family_coefficients {γ : ℝ} {M : ℕ} {Hm : ℝ → ℝ}
    (hγ : 0 < γ)
    (hsize : ∀ᶠ x : ℝ in atTop, ∀ n : ℕ, Hm x ≤ n → (n:ℝ) ≤ 2*Hm x →
      ‖discrepancy γ x n‖ ≤ (Real.log x)^(2:ℝ)) :
    ∀ᶠ x : ℝ in atTop,
      ∀ j : DirichletCharacter ℂ M × ℝ, |j.2| ≤ Real.log x →
      ∀ n : ℕ, Hm x ≤ n → (n:ℝ) ≤ 2*Hm x →
        ‖twistedDiscrepancy γ M x j n‖ ≤ (Real.log x)^(2:ℝ) ∧
          (twistedDiscrepancy γ M x j n ≠ 0 → IsRough (W x) n) := by
  filter_upwards [hsize, rough_cutoff_le_power (by norm_num : (6/25:ℝ)<1) hγ]
    with x hx hcut
  intro j _hj n hn hn'
  constructor
  · exact (twisted_coefficient_norm j.1 (discrepancy γ x) j.2 n).trans (hx n hn hn')
  · exact twisted_coefficient_support j.1 (discrepancy γ x) j.2 _
      (fun n hn => roughDiscrepancy_support (density γ) eulerV γ (6/25) x n hcut hn) n


/-- The manuscript's second coefficient is bounded by one and rough. -/
def BoundedRoughCoefficient (x : ℝ) (t : Finset ℕ) (β : ℕ → ℂ) : Prop :=
  ∀ n ∈ t, ‖β n‖ ≤ 1 ∧ (β n ≠ 0 → IsRough (W x) n)

/-- The intermediate estimate that is *proved* from the coefficient criterion.
Unlike that criterion, it already contains both fixed-progression characters
and real phases, with a single constant for all of them. -/
def LowFrequencyMR {K : ℕ} (b : Bands K) (M : ℕ) (γ D : ℝ)
    (Hm Hn : ℝ → ℝ) : Prop :=
  ∃ E : ℝ, 0 < E ∧ ∀ᶠ x : ℝ in atTop,
    ∀ s t : Finset ℕ, IntervalInDyad (Hm x) s → InDyad (Hn x) t →
    ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
    ∀ F : ℕ → ℂ, InvariantSelector b x F →
    ∀ χ : DirichletCharacter ℂ M, ∀ v : ℝ, |v| ≤ Real.log x →
    ‖bilinear s t
      (fun m => (discrepancy γ x m * χ (m : ZMod M)) * archimedeanPhase v m)
      (fun n => (β n * χ (n : ZMod M)) * archimedeanPhase v n)
      (fun h => F h * (markedWeight b (1/2) x h : ℂ))‖ ≤
        E*(Hm x*Hn x)*(Real.log x)^(-D)

/-- Instantiate the exact cited coefficient criterion, with no remaining
bilinear estimate as a hypothesis. The number of groups is chosen before the
bands and before every selector, interval, second coefficient, and twist. -/
theorem lowFrequencyMR_of_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (M : ℕ) (hM : 0 < M)
    (γ sLo sHi δ D c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hD : 0 < D) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂)
    (Hm Hn : ℝ → ℝ) (hscales : DyadicScales δ c₁ c₂ Hm Hn)
    (hexponents : ∀ᶠ x : ℝ in atTop, sLo ≤ Real.log (Hm x)/Real.log x ∧
      Real.log (2*Hm x)/Real.log x ≤ sHi) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      LowFrequencyMR b M γ D Hm Hn := by
  have h102 := sourceLemma10_2_fixed h102
  have h103 := sourceProposition10_3_fixed h103
  obtain ⟨hcan, hsize⟩ := h103 γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂
    Hm Hn hscales hexponents
  have hX : ∀ᶠ x : ℝ in atTop, 1 ≤ Hm x*Hn x := by
    filter_upwards [hscales] with x hx
    exact one_le_mul_of_one_le_of_one_le hx.1 hx.2.1
  have hfamily := discrepancy_family_cancellation hγ hM hcan hX
  have hcoeff := discrepancy_family_coefficients (M := M) hγ hsize
  obtain ⟨K₀, hK₀, hK⟩ := h102 δ 2 D (1/2) c₁ c₂ hδ (by norm_num) hD
    (by norm_num) (by norm_num) hc₁ hc₂ Hm Hn hscales
    (DirichletCharacter ℂ M × ℝ) (twistedDiscrepancy γ M)
    (fun x j => |j.2| ≤ Real.log x) hfamily hcoeff
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b
  obtain ⟨E, hE, he⟩ := hK K hKK b
  refine ⟨E, hE, ?_⟩
  have hL : ∀ᶠ x : ℝ in atTop, 1 ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop 1)
  filter_upwards [he, hL] with x hx hLx
  intro s t hsm htn β hβ F hF χ v hv
  apply hx (χ,v) hv s t hsm htn
    (fun n => (β n * χ (n : ZMod M)) * archimedeanPhase v n) ?_ F hF
  intro n hn
  constructor
  · exact ((twisted_coefficient_norm χ β v n).trans (hβ n hn).1).trans
      (Real.one_le_rpow hLx (by norm_num : (0:ℝ) ≤ 2))
  · intro hne
    apply (hβ n hn).2
    intro hz
    simp [hz] at hne


/-- Fourier transform convention used in the manuscript. -/
noncomputable def fourierKernel (Ψ : ℝ → ℂ) (v : ℝ) : ℂ :=
  ((2*Real.pi : ℝ)⁻¹ : ℂ) *
    ∫ t : ℝ, Ψ (Real.exp t) * Complex.exp (-Complex.I * (v:ℂ) * (t:ℂ))

noncomputable def scaledKernel (Ψ : ℝ → ℂ) (x v : ℝ) : ℂ :=
  fourierKernel Ψ v * Complex.exp (-Complex.I * (v:ℂ) * (Real.log x:ℂ))

def SmoothCompactWeight (Ψ : ℝ → ℂ) : Prop :=
  ContDiff ℝ (↑(⊤ : ℕ∞) : WithTop ℕ∞) Ψ ∧ HasCompactSupport Ψ ∧
    Function.support Ψ ⊆ Set.Ioo 1 2

/-- A classical Fourier-inversion and rapid-decay statement, for the actual
Fourier transform above. The tail estimate is quantified over every accuracy.
This has no arithmetic or bilinear estimate as an input or conclusion. -/
def FourierControl (Ψ : ℝ → ℂ) : Prop :=
  ∃ B : ℝ, 0 < B ∧
    (∀ x : ℝ, 0 < x → Integrable (scaledKernel Ψ x) ∧
      (∫ v : ℝ, ‖scaledKernel Ψ x v‖) ≤ B ∧
      ∀ m n : ℕ, 0 < m → 0 < n →
        Ψ ((m*n:ℕ)/x) =
          ∫ v : ℝ, scaledKernel Ψ x v * archimedeanPhase v m * archimedeanPhase v n) ∧
    (∀ x : ℝ, 0 < x → ∀ m n : ℕ, 0 < m → 0 < n →
      Integrable (fun v : ℝ => scaledKernel Ψ x v *
        archimedeanPhase v m * archimedeanPhase v n)) ∧
    ∀ A : ℝ, 0 < A → ∃ T : ℝ, 0 < T ∧ ∀ᶠ x : ℝ in atTop,
      (∫ v : ℝ, tailKernel (Real.log x) (scaledKernel Ψ x) v) ≤
        T*(Real.log x)^(-A)

def ClassicalFourierInversion : Prop :=
  ∀ Ψ : ℝ → ℂ, SmoothCompactWeight Ψ → FourierControl Ψ

/-- A crude integer count sufficient for the rapidly decreasing Fourier
 tail. It costs only a fixed factor, also for nonintegral dyad endpoints. -/
theorem dyad_card_le {H : ℝ} {t : Finset ℕ} (hH : 1 ≤ H) (ht : InDyad H t) :
    (t.card : ℝ) ≤ 3*H := by
  have hsub : t ⊆ Finset.range (⌊2*H⌋₊ + 1) := by
    intro n hn
    apply Finset.mem_range.mpr
    exact Nat.lt_succ_of_le ((Nat.le_floor_iff (by linarith : (0:ℝ) ≤ 2*H)).mpr (ht n hn).2)
  have hc : (t.card : ℝ) ≤ (⌊2*H⌋₊ : ℝ)+1 := by
    exact_mod_cast (by simpa only [Finset.card_range] using Finset.card_le_card hsub : t.card ≤ ⌊2*H⌋₊+1)
  have hf := Nat.floor_le (by linarith : (0:ℝ) ≤ 2*H)
  linarith

theorem dyad_member_pos {H : ℝ} {t : Finset ℕ} (hH : 1 ≤ H)
    (ht : InDyad H t) {n : ℕ} (hn : n ∈ t) : 0 < n := by
  have h : (1:ℝ) ≤ n := hH.trans (ht n hn).1
  exact_mod_cast h

/-- A positive constant depending only on the fixed number of bands. -/
noncomputable def weightBound (K : ℕ) : ℝ := (2 / Real.log 2)^K

theorem weightBound_pos (K : ℕ) : 0 < weightBound K := by
  unfold weightBound
  exact pow_pos (div_pos (by norm_num) (Real.log_pos (by norm_num))) _

theorem markedWeight_half_bound {K : ℕ} (b : Bands K) (x : ℝ)
    (hmass : ∀ i : Fin K, Real.log 2/2 ≤ b.mass x i) (h : ℕ) :
    0 ≤ markedWeight b (1/2) x h ∧ markedWeight b (1/2) x h ≤ weightBound K := by
  have hlog : 0 < Real.log 2/2 := div_pos (Real.log_pos (by norm_num)) (by norm_num)
  have hmasspos : ∀ i : Fin K, 0 < b.mass x i := fun i => hlog.trans_le (hmass i)
  rw [markedWeight_half]
  obtain ⟨hpos,hb⟩ := ConcreteSelector.markingWeight_bounds Finset.univ
    (b.group x) (b.mass x) h (fun i _ => hmasspos i)
  refine ⟨hpos, hb.trans ?_⟩
  calc
    (∏ i : Fin K, 1/b.mass x i) ≤ ∏ _i : Fin K, 2/Real.log 2 := by
      apply Finset.prod_le_prod₀
      · intro i _; exact le_of_lt (one_div_pos.mpr (hmasspos i))
      · intro i _
        calc
          1/b.mass x i ≤ 1/(Real.log 2/2) := one_div_le_one_div_of_le hlog (hmass i)
          _ = 2/Real.log 2 := by ring
    _ = weightBound K := by simp [weightBound, div_pow]

theorem invariant_marked_norm_le {K : ℕ} (b : Bands K) (x : ℝ) (F : ℕ → ℂ)
    (hF : InvariantSelector b x F)
    (hmass : ∀ i : Fin K, Real.log 2/2 ≤ b.mass x i) (h : ℕ) :
    ‖F h*(markedWeight b (1/2) x h : ℂ)‖ ≤ weightBound K := by
  obtain ⟨hpos,hb⟩ := markedWeight_half_bound b x hmass h
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hpos]
  exact (mul_le_mul_of_nonneg_right (hF.1 h) hpos).trans (by simpa using hb)

/-- Actual progression-restricted and smoothly weighted rough discrepancy.
Its selector and normalized marking weight appear on `mn-1`, as in MR. -/
noncomputable def mrSum {K : ℕ} (b : Bands K) (M : ℕ) (u : ZMod M)
    (Ψ : ℝ → ℂ) (γ x : ℝ) (s t : Finset ℕ) (β F : ℕ → ℂ) : ℂ :=
  progressionSum M u s t (discrepancy γ x) β
    (fun h => F h * (markedWeight b (1/2) x h : ℂ))
    (fun d => Ψ ((d:ℝ)/x))

/-- The full MR conclusion, with its constant and threshold before the
interval, second coefficient, and selector. -/
def UniformMR {K : ℕ} (b : Bands K) (M : ℕ) (u : ZMod M)
    (Ψ : ℝ → ℂ) (γ D : ℝ) (Hm Hn : ℝ → ℝ) : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
    ∀ s t : Finset ℕ, IntervalInDyad (Hm x) s → InDyad (Hn x) t →
    ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
    ∀ F : ℕ → ℂ, InvariantSelector b x F →
      ‖mrSum b M u Ψ γ x s t β F‖ ≤ C*x*(Real.log x)^(-D)


/-- Complete Fourier/progression deduction from the proved uniform twisted
estimate. The crude tail uses `O_K(X L²)`; decay of order `D+2` absorbs it.
There is no unproved low-frequency estimate once `lowFrequencyMR_of_sources`
is used for `hlow`. -/
theorem uniformMR_of_lowFrequency {K M : ℕ} [NeZero M] (b : Bands K)
    (u : ZMod M) (hu : IsUnit u) (Ψ : ℝ → ℂ)
    (γ D δ c₁ c₂ : ℝ) (hD : 0 < D) (hc₂ : 0 < c₂)
    (Hm Hn : ℝ → ℝ) (hscales : DyadicScales δ c₁ c₂ Hm Hn)
    (hsize : ∀ᶠ x : ℝ in atTop, ∀ n : ℕ, Hm x ≤ n → (n:ℝ) ≤ 2*Hm x →
      ‖discrepancy γ x n‖ ≤ (Real.log x)^(2:ℝ))
    (hmass : ∀ᶠ x : ℝ in atTop, ∀ i : Fin K, Real.log 2/2 ≤ b.mass x i)
    (hfourier : FourierControl Ψ) (hlow : LowFrequencyMR b M γ D Hm Hn) :
    UniformMR b M u Ψ γ D Hm Hn := by
  obtain ⟨E, hE, he⟩ := hlow
  obtain ⟨B, hB, hk, hint, htail⟩ := hfourier
  obtain ⟨T, hT, ht⟩ := htail (D+2) (by linarith)
  let C : ℝ := E*B+9*weightBound K*T
  have hC : 0 < C := by dsimp [C]; positivity [weightBound_pos K]
  refine ⟨C*c₂, mul_pos hC hc₂, ?_⟩
  have hL : ∀ᶠ x : ℝ in atTop, 0 < Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop 0)
  filter_upwards [he, ht, hscales, hmass, hsize, hL, eventually_gt_atTop (0:ℝ)]
    with x hex htx hsx hmx hsz hLx hx
  intro s t hsm htn β hβ F hF
  have hsm' := hsm.inDyad
  have hmc := dyad_card_le hsx.1 hsm'
  have hnc := dyad_card_le hsx.2.1 htn
  have hmn : (s.card:ℝ)*(t.card:ℝ) ≤ 9*(Hm x*Hn x) := by
    have hh := mul_le_mul hmc hnc (Nat.cast_nonneg _) (by linarith : (0:ℝ) ≤ 3*Hm x)
    nlinarith
  have hα : ∀ m ∈ s, ‖discrepancy γ x m‖ ≤ (Real.log x)^(2:ℝ) :=
    fun m hm => hsz m (hsm' m hm).1 (hsm' m hm).2
  have hβ' : ∀ n ∈ t, ‖β n‖ ≤ 1 := fun n hn => (hβ n hn).1
  have hH : ∀ m ∈ s, ∀ n ∈ t,
      ‖F (m*n-1)*(markedWeight b (1/2) x (m*n-1) : ℂ)‖ ≤ weightBound K :=
    fun _ _ _ _ => invariant_marked_norm_le b x F hF hmx _
  have hX : 0 ≤ Hm x*Hn x := mul_nonneg (by linarith [hsx.1]) (by linarith [hsx.2.1])
  have hsave : 0 ≤ (Real.log x)^(-D) := Real.rpow_nonneg hLx.le _
  have hpow : (Real.log x)^(2:ℝ)*(Real.log x)^(-(D+2)) = (Real.log x)^(-D) := by
    rw [← Real.rpow_add hLx]
    congr 1
    ring
  have hbound := smoothed_progression_bound_of_coefficients M u hu s t
    (discrepancy γ x) β (fun h => F h*(markedWeight b (1/2) x h : ℂ))
    (fun d => Ψ ((d:ℝ)/x)) (scaledKernel Ψ x) (Real.log x)
    (E*(Hm x*Hn x)*(Real.log x)^(-D)) ((Real.log x)^(2:ℝ)) 1 (weightBound K)
    (by positivity) (Real.rpow_nonneg hLx.le _) (by norm_num) (weightBound_pos K).le
    (hk x hx).1 hα hβ' hH
    (fun m hm n hn => (hk x hx).2.2 m n
      (dyad_member_pos hsx.1 hsm' hm) (dyad_member_pos hsx.2.1 htn hn))
    (fun m hm n hn => hint x hx m n
      (dyad_member_pos hsx.1 hsm' hm) (dyad_member_pos hsx.2.1 htn hn))
    (hex s t hsm htn β hβ F hF)
  change ‖mrSum b M u Ψ γ x s t β F‖ ≤ _ at hbound
  have hcrude : (s.card:ℝ)*(t.card:ℝ)*(Real.log x)^(2:ℝ)*1*weightBound K ≤
      9*(Hm x*Hn x)*(Real.log x)^(2:ℝ)*1*weightBound K := by
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hmn (Real.rpow_nonneg hLx.le _)) zero_le_one)
      (weightBound_pos K).le
  calc
    ‖mrSum b M u Ψ γ x s t β F‖ ≤
        E*(Hm x*Hn x)*(Real.log x)^(-D)*(∫ v:ℝ, ‖scaledKernel Ψ x v‖) +
        ((s.card:ℝ)*(t.card:ℝ)*(Real.log x)^(2:ℝ)*1*weightBound K)*
          (∫ v:ℝ, tailKernel (Real.log x) (scaledKernel Ψ x) v) := hbound
    _ ≤ E*(Hm x*Hn x)*(Real.log x)^(-D)*B +
        (9*(Hm x*Hn x)*(Real.log x)^(2:ℝ)*1*weightBound K)*
          (T*(Real.log x)^(-(D+2))) := by
      apply add_le_add
      · exact mul_le_mul_of_nonneg_left (hk x hx).2.1 (by positivity)
      · exact mul_le_mul hcrude htx
          (integral_nonneg (fun _ => by unfold tailKernel; split_ifs <;> positivity))
          (by positivity [weightBound_pos K])
    _ = C*(Hm x*Hn x)*(Real.log x)^(-D) := by
      calc
        _ = E*B*(Hm x*Hn x)*(Real.log x)^(-D) +
            9*weightBound K*T*(Hm x*Hn x)*
              ((Real.log x)^(2:ℝ)*(Real.log x)^(-(D+2))) := by ring
        _ = _ := by rw [hpow]; dsimp [C]; ring
    _ ≤ C*(c₂*x)*(Real.log x)^(-D) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hsx.2.2.2.2.2 hC.le) hsave
    _ = (C*c₂)*x*(Real.log x)^(-D) := by ring

/-- The manuscript's original MR adaptation, now derived from the precisely
separated accepted source and classical analytic inputs. The logarithmic
saving is `6` exactly. `K₀` precedes the band exponents and every selector. -/
theorem uniformMR_of_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (M : ℕ) [NeZero M] (u : ZMod M) (hu : IsUnit u)
    (Ψ : ℝ → ℂ) (hΨ : SmoothCompactWeight Ψ)
    (γ sLo sHi δ c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂)
    (Hm Hn : ℝ → ℝ) (hscales : DyadicScales δ c₁ c₂ Hm Hn)
    (hexponents : ∀ᶠ x : ℝ in atTop, sLo ≤ Real.log (Hm x)/Real.log x ∧
      Real.log (2*Hm x)/Real.log x ≤ sHi) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      UniformMR b M u Ψ γ 6 Hm Hn := by
  obtain ⟨K₀,hK₀,hK⟩ := lowFrequencyMR_of_sources h102 h103 M (NeZero.pos M)
    γ sLo sHi δ 6 c₁ c₂ hγ hγs hs hs1 hδ (by norm_num) hc₁ hc₂ Hm Hn hscales hexponents
  have hsize := (sourceProposition10_3_fixed h103 γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂
    Hm Hn hscales hexponents).2
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b
  exact uniformMR_of_lowFrequency b u hu Ψ γ 6 δ c₁ c₂ (by norm_num) hc₂
    Hm Hn hscales hsize (hbands K b) (hFourier Ψ hΨ) (hK K hKK b)

/-- The actual full-prime-power cofactor selector is an instance, with no
assumed selector invariance remaining. The coefficient and threshold are
uniform over the cofactor family, fixed factor, and final-prime cutoff. -/
theorem actualSelector_MR {K M : ℕ} (b : Bands K) (u : ZMod M)
    (Ψ : ℝ → ℂ) (γ D : ℝ) (Hm Hn : ℝ → ℝ)
    (hMR : UniformMR b M u Ψ γ D Hm Hn) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x) s → InDyad (Hn x) t →
      ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        ‖mrSum b M u Ψ γ x s t β (actualSelector b x c allowed Qmin)‖ ≤
          C*x*(Real.log x)^(-D) := by
  obtain ⟨C,hC,h⟩ := hMR
  refine ⟨C,hC,?_⟩
  filter_upwards [h] with x hx
  intro s t hs ht β hβ c allowed Qmin
  exact hx s t hs ht β hβ _ (actualSelector_invariant b x c allowed Qmin)


/-- Exact identification with the arithmetic weight already used by the
candidate construction. This eliminates any ambiguity about the selector,
normalized marks, real smoothing, or progression convention. -/
theorem mrSum_actual_weight {K : ℕ} (b : Bands K) (M u : ℕ) (hu : u < M)
    (Ψ : ℝ → ℝ) (γ x : ℝ) (s t : Finset ℕ) (β : ℕ → ℂ)
    (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) :
    mrSum b M (u : ZMod M) (fun y => (Ψ y : ℂ)) γ x s t β
      (actualSelector b x c allowed Qmin) =
    ∑ m ∈ s, ∑ n ∈ t, discrepancy γ x m * β n *
      (ConcreteSelector.arithmeticWeight M u (fun d => Ψ ((d:ℝ)/x))
        Finset.univ (b.group x) (b.mass x) (b.primes x) c allowed Qmin (m*n) : ℂ) := by
  classical
  unfold mrSum progressionSum
  apply Finset.sum_congr rfl
  intro m _
  apply Finset.sum_congr rfl
  intro n _
  have hmod : (m*n : ZMod M) = (u : ZMod M) ↔ (m*n)%M = u := by
    simpa only [Nat.cast_mul, Nat.mod_eq_of_lt hu] using
      (ZMod.natCast_eq_natCast_iff' (m*n) u M)
  by_cases hmn : (m*n)%M = u
  · have hz := hmod.mpr hmn
    simp only [hz, ite_true, ConcreteSelector.arithmeticWeight, hmn,
      actualSelector, markedWeight_half, Complex.ofReal_mul]
    ring
  · have hz : ¬ (m*n : ZMod M) = (u : ZMod M) := fun hh => hmn (hmod.mp hh)
    simp [hz, ConcreteSelector.arithmeticWeight, hmn]

/-- MR for exactly `ConcreteSelector.arithmeticWeight`, including the
cofactor family and final-prime cutoff used in the manuscript. -/
theorem actualArithmeticWeight_MR {K M : ℕ} (b : Bands K) (u : ℕ) (hu : u < M)
    (Ψ : ℝ → ℝ) (γ D : ℝ) (Hm Hn : ℝ → ℝ)
    (hMR : UniformMR b M (u : ZMod M) (fun y => (Ψ y : ℂ)) γ D Hm Hn) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x) s → InDyad (Hn x) t →
      ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        ‖∑ m ∈ s, ∑ n ∈ t, discrepancy γ x m * β n *
          (ConcreteSelector.arithmeticWeight M u (fun d => Ψ ((d:ℝ)/x))
            Finset.univ (b.group x) (b.mass x) (b.primes x) c allowed Qmin (m*n) : ℂ)‖ ≤
          C*x*(Real.log x)^(-D) := by
  obtain ⟨C,hC,h⟩ := actualSelector_MR b (u : ZMod M) (fun y => (Ψ y : ℂ)) γ D Hm Hn hMR
  refine ⟨C,hC,?_⟩
  filter_upwards [h] with x hx
  intro s t hs ht β hβ c allowed Qmin
  rw [← mrSum_actual_weight b M u hu Ψ γ x s t β c allowed Qmin]
  exact hx s t hs ht β hβ c allowed Qmin


/-- Admissible dyad/character/frequency triples. The first coordinate can
index a growing dyadic collection; the two others are the MR twists. -/
def TwistedActive {J : Type} (M : ℕ) (active : ℝ → J → Prop)
    (x : ℝ) (j : J × DirichletCharacter ℂ M × ℝ) : Prop :=
  active x j.1 ∧ |j.2.2| ≤ Real.log x

/-- Quantifier-preserving twist argument, uniform also over all active
dyads. Its proof is the same product-character and frequency-shift identity
as in `MarkedCriterion`; no compactness or pointwise-to-uniform inference is
used. -/
theorem discrepancy_scale_twists {J : Type} {γ : ℝ} {M : ℕ}
    {Hm X : ℝ → J → ℝ} {active : ℝ → J → Prop}
    (hγ : 0 < γ) (hM : 0 < M)
    (hcan : ScaleCancellation (fun x _ => discrepancy γ x) active Hm X)
    (hX : ∀ᶠ x : ℝ in atTop, ∀ j, active x j → 1 ≤ X x j) :
    ScaleCancellation (fun x (j : J × DirichletCharacter ℂ M × ℝ) n =>
      (discrepancy γ x n * j.2.1 (n : ZMod M)) * archimedeanPhase j.2.2 n)
      (TwistedActive M active) (fun x j => Hm x j.1) (fun x j => X x j.1) := by
  intro A₀ B A hA₀ hB hA
  obtain ⟨C,hC,hc⟩ := hcan (A₀+1) (B+1) A (by linarith) (by linarith) hA
  have hu := roughDiscrepancy_unit_support (density γ) eulerV hγ
    (by norm_num : (0:ℝ)<6/25) (by norm_num : (6/25:ℝ)<1) (A₀+1) (by linarith)
  have hL : ∀ᶠ x : ℝ in atTop, max (M:ℝ) 2 ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop _)
  refine ⟨C,hC,?_⟩
  filter_upwards [hc,hu,hL,hX] with x hx hux hLx hXx
  intro j hj lo hi k hlo hhi hk hkL ψ t ht
  have hL₂ : 2 ≤ Real.log x := (le_max_right _ _).trans hLx
  have hML : (M:ℝ) ≤ Real.log x := (le_max_left _ _).trans hLx
  have hq : 0 < Nat.lcm M k := Nat.pos_of_ne_zero (Nat.lcm_ne_zero hM.ne' hk.ne')
  have hqL := logarithmic_lcm_bound (by linarith : 0 < Real.log x) hML hkL
  rw [twisted_transform_eq (Finset.Icc lo hi) (discrepancy γ x) j.2.1 ψ j.2.2 t
    (fun n _ hn => hux n (Nat.lcm M k) hn hq hqL)]
  exact hx j.1 hj.1 lo hi (Nat.lcm M k) hlo hhi hq hqL (j.2.1.mul ψ) (t+j.2.2)
    (logarithmic_frequency_shift hL₂ (hXx j.1 hj.1) hB.le ht hj.2)

/-- Uniform low-frequency estimate across a potentially growing family of
active dyads. The constant and onset precede the dyad index. -/
def LowFrequencyMRFamily {J : Type} {K : ℕ} (b : Bands K) (M : ℕ) (γ D : ℝ)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop) : Prop :=
  ∃ E : ℝ, 0 < E ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
    ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
    ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
    ∀ F : ℕ → ℂ, InvariantSelector b x F →
    ∀ χ : DirichletCharacter ℂ M, ∀ v : ℝ, |v| ≤ Real.log x →
    ‖bilinear s t
      (fun m => (discrepancy γ x m * χ (m:ZMod M)) * archimedeanPhase v m)
      (fun n => (β n * χ (n:ZMod M)) * archimedeanPhase v n)
      (fun h => F h*(markedWeight b (1/2) x h:ℂ))‖ ≤
        E*(Hm x j*Hn x j)*(Real.log x)^(-D)

/-- The number of groups is chosen before the dyad family, its active set,
and its cancellation profile. The output error constant is uniform across
all active dyads, even when their number grows with `x`. -/
theorem lowFrequencyMRFamilies_of_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (M : ℕ) (hM : 0 < M) (γ sLo sHi δ D c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hD : 0 < D) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active →
      (∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        sLo ≤ Real.log (Hm x j)/Real.log x ∧
        Real.log (2*Hm x j)/Real.log x ≤ sHi) →
      LowFrequencyMRFamily b M γ D Hm Hn active := by
  obtain ⟨K₀,hK₀,hK⟩ := h102 δ 2 D (1/2) c₁ c₂ hδ (by norm_num) hD
    (by norm_num) (by norm_num) hc₁ hc₂
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b J Hm Hn active hscale hexp
  obtain ⟨hcan,hsize⟩ := h103 γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂
    J Hm Hn active hscale hexp
  have hX : ∀ᶠ x : ℝ in atTop, ∀ j, active x j → 1 ≤ Hm x j*Hn x j := by
    filter_upwards [hscale] with x hx
    intro j hj
    exact one_le_mul_of_one_le_of_one_le (hx j hj).1 (hx j hj).2.1
  have htwist := discrepancy_scale_twists hγ hM hcan hX
  have hscaleTw : ScaleFamily δ c₁ c₂
      (fun x (j : J × DirichletCharacter ℂ M × ℝ) => Hm x j.1)
      (fun x j => Hn x j.1) (TwistedActive M active) := by
    filter_upwards [hscale] with x hx
    intro j hj
    exact hx j.1 hj.1
  have hcoeff : ∀ᶠ x : ℝ in atTop,
      ∀ j : J × DirichletCharacter ℂ M × ℝ, TwistedActive M active x j →
      ∀ n : ℕ, Hm x j.1 ≤ n → (n:ℝ) ≤ 2*Hm x j.1 →
      ‖(discrepancy γ x n*j.2.1 (n:ZMod M))*archimedeanPhase j.2.2 n‖ ≤
          (Real.log x)^(2:ℝ) ∧
      ((discrepancy γ x n*j.2.1 (n:ZMod M))*archimedeanPhase j.2.2 n ≠ 0 →
        IsRough (W x) n) := by
    filter_upwards [hsize,rough_cutoff_le_power (by norm_num : (6/25:ℝ)<1) hγ]
      with x hx hcut
    intro j hj n hn hn'
    constructor
    · exact (twisted_coefficient_norm j.2.1 (discrepancy γ x) j.2.2 n).trans
        (hx j.1 hj.1 n hn hn')
    · exact twisted_coefficient_support j.2.1 (discrepancy γ x) j.2.2 _
        (fun n hn => roughDiscrepancy_support (density γ) eulerV γ (6/25) x n hcut hn) n
  obtain ⟨E,hE,he⟩ := hK K hKK b (J × DirichletCharacter ℂ M × ℝ)
    (fun x j => Hm x j.1) (fun x j => Hn x j.1) (TwistedActive M active) hscaleTw
    _ htwist hcoeff
  refine ⟨E,hE,?_⟩
  have hL : ∀ᶠ x : ℝ in atTop, 1 ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop 1)
  filter_upwards [he,hL] with x hx hLx
  intro j hj s t hsm htn β hβ F hF χ v hv
  apply hx (j,χ,v) ⟨hj,hv⟩ s t hsm htn
    (fun n => (β n*χ (n:ZMod M))*archimedeanPhase v n) ?_ F hF
  intro n hn
  constructor
  · exact ((twisted_coefficient_norm χ β v n).trans (hβ n hn).1).trans
      (Real.one_le_rpow hLx (by norm_num : (0:ℝ) ≤ 2))
  · intro hne
    apply (hβ n hn).2
    intro hz
    simp [hz] at hne

/-- MR with one error constant and onset for an entire active dyad family. -/
def UniformMRFamily {J : Type} {K : ℕ} (b : Bands K) (M : ℕ) (u : ZMod M)
    (Ψ : ℝ → ℂ) (γ D : ℝ) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop) : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
    ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
    ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
    ∀ F : ℕ → ℂ, InvariantSelector b x F →
      ‖mrSum b M u Ψ γ x s t β F‖ ≤ C*x*(Real.log x)^(-D)

/-- Fourier transfer with constants uniform over every active dyad. -/
theorem uniformMRFamily_of_lowFrequency {J : Type} {K M : ℕ} [NeZero M] (b : Bands K)
    (u : ZMod M) (hu : IsUnit u) (Ψ : ℝ → ℂ)
    (γ D δ c₁ c₂ : ℝ) (hD : 0 < D) (hc₂ : 0 < c₂)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop)
    (hscales : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hsize : ∀ᶠ x : ℝ in atTop, ∀ j, active x j → ∀ n : ℕ, Hm x j ≤ n → (n:ℝ) ≤ 2*Hm x j →
      ‖discrepancy γ x n‖ ≤ (Real.log x)^(2:ℝ))
    (hmass : ∀ᶠ x : ℝ in atTop, ∀ i : Fin K, Real.log 2/2 ≤ b.mass x i)
    (hfourier : FourierControl Ψ) (hlow : LowFrequencyMRFamily b M γ D Hm Hn active) :
    UniformMRFamily b M u Ψ γ D Hm Hn active := by
  obtain ⟨E, hE, he⟩ := hlow
  obtain ⟨B, hB, hk, hint, htail⟩ := hfourier
  obtain ⟨T, hT, ht⟩ := htail (D+2) (by linarith)
  let C : ℝ := E*B+9*weightBound K*T
  have hC : 0 < C := by dsimp [C]; positivity [weightBound_pos K]
  refine ⟨C*c₂, mul_pos hC hc₂, ?_⟩
  have hL : ∀ᶠ x : ℝ in atTop, 0 < Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop 0)
  filter_upwards [he, ht, hscales, hmass, hsize, hL, eventually_gt_atTop (0:ℝ)]
    with x hex htx hsx hmx hsz hLx hx
  intro j hj s t hsm htn β hβ F hF
  have hsx := hsx j hj
  have hsz := hsz j hj
  have hex := hex j hj
  have hsm' := hsm.inDyad
  have hmc := dyad_card_le hsx.1 hsm'
  have hnc := dyad_card_le hsx.2.1 htn
  have hmn : (s.card:ℝ)*(t.card:ℝ) ≤ 9*(Hm x j*Hn x j) := by
    have hh := mul_le_mul hmc hnc (Nat.cast_nonneg _) (by linarith : (0:ℝ) ≤ 3*Hm x j)
    nlinarith
  have hα : ∀ m ∈ s, ‖discrepancy γ x m‖ ≤ (Real.log x)^(2:ℝ) :=
    fun m hm => hsz m (hsm' m hm).1 (hsm' m hm).2
  have hβ' : ∀ n ∈ t, ‖β n‖ ≤ 1 := fun n hn => (hβ n hn).1
  have hH : ∀ m ∈ s, ∀ n ∈ t,
      ‖F (m*n-1)*(markedWeight b (1/2) x (m*n-1) : ℂ)‖ ≤ weightBound K :=
    fun _ _ _ _ => invariant_marked_norm_le b x F hF hmx _
  have hX : 0 ≤ Hm x j*Hn x j := mul_nonneg (by linarith [hsx.1]) (by linarith [hsx.2.1])
  have hsave : 0 ≤ (Real.log x)^(-D) := Real.rpow_nonneg hLx.le _
  have hpow : (Real.log x)^(2:ℝ)*(Real.log x)^(-(D+2)) = (Real.log x)^(-D) := by
    rw [← Real.rpow_add hLx]
    congr 1
    ring
  have hbound := smoothed_progression_bound_of_coefficients M u hu s t
    (discrepancy γ x) β (fun h => F h*(markedWeight b (1/2) x h : ℂ))
    (fun d => Ψ ((d:ℝ)/x)) (scaledKernel Ψ x) (Real.log x)
    (E*(Hm x j*Hn x j)*(Real.log x)^(-D)) ((Real.log x)^(2:ℝ)) 1 (weightBound K)
    (by positivity) (Real.rpow_nonneg hLx.le _) (by norm_num) (weightBound_pos K).le
    (hk x hx).1 hα hβ' hH
    (fun m hm n hn => (hk x hx).2.2 m n
      (dyad_member_pos hsx.1 hsm' hm) (dyad_member_pos hsx.2.1 htn hn))
    (fun m hm n hn => hint x hx m n
      (dyad_member_pos hsx.1 hsm' hm) (dyad_member_pos hsx.2.1 htn hn))
    (hex s t hsm htn β hβ F hF)
  change ‖mrSum b M u Ψ γ x s t β F‖ ≤ _ at hbound
  have hcrude : (s.card:ℝ)*(t.card:ℝ)*(Real.log x)^(2:ℝ)*1*weightBound K ≤
      9*(Hm x j*Hn x j)*(Real.log x)^(2:ℝ)*1*weightBound K := by
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hmn (Real.rpow_nonneg hLx.le _)) zero_le_one)
      (weightBound_pos K).le
  calc
    ‖mrSum b M u Ψ γ x s t β F‖ ≤
        E*(Hm x j*Hn x j)*(Real.log x)^(-D)*(∫ v:ℝ, ‖scaledKernel Ψ x v‖) +
        ((s.card:ℝ)*(t.card:ℝ)*(Real.log x)^(2:ℝ)*1*weightBound K)*
          (∫ v:ℝ, tailKernel (Real.log x) (scaledKernel Ψ x) v) := hbound
    _ ≤ E*(Hm x j*Hn x j)*(Real.log x)^(-D)*B +
        (9*(Hm x j*Hn x j)*(Real.log x)^(2:ℝ)*1*weightBound K)*
          (T*(Real.log x)^(-(D+2))) := by
      apply add_le_add
      · exact mul_le_mul_of_nonneg_left (hk x hx).2.1 (by positivity)
      · exact mul_le_mul hcrude htx
          (integral_nonneg (fun _ => by unfold tailKernel; split_ifs <;> positivity))
          (by positivity [weightBound_pos K])
    _ = C*(Hm x j*Hn x j)*(Real.log x)^(-D) := by
      calc
        _ = E*B*(Hm x j*Hn x j)*(Real.log x)^(-D) +
            9*weightBound K*T*(Hm x j*Hn x j)*
              ((Real.log x)^(2:ℝ)*(Real.log x)^(-(D+2))) := by ring
        _ = _ := by rw [hpow]; dsimp [C]; ring
    _ ≤ C*(c₂*x)*(Real.log x)^(-D) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hsx.2.2.2.2.2 hC.le) hsave
    _ = (C*c₂)*x*(Real.log x)^(-D) := by ring

/-- Full source-to-MR bridge with the required quantifier order: `K₀` is
chosen before **all** dyad functions and coefficient families. One subsequent
error constant and onset work for every active dyad, interval, coefficient,
and selector, including a growing family indexed by `ℕ`. -/
theorem uniformMRFamilies_of_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (M : ℕ) [NeZero M] (u : ZMod M) (hu : IsUnit u)
    (Ψ : ℝ → ℂ) (hΨ : SmoothCompactWeight Ψ)
    (γ sLo sHi δ c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active →
      (∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        sLo ≤ Real.log (Hm x j)/Real.log x ∧
        Real.log (2*Hm x j)/Real.log x ≤ sHi) →
      UniformMRFamily b M u Ψ γ 6 Hm Hn active := by
  obtain ⟨K₀,hK₀,hK⟩ := lowFrequencyMRFamilies_of_sources h102 h103 M (NeZero.pos M)
    γ sLo sHi δ 6 c₁ c₂ hγ hγs hs hs1 hδ (by norm_num) hc₁ hc₂
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b J Hm Hn active hscale hexp
  have hsize := (h103 γ sLo sHi hγ hγs hs hs1 δ c₁ c₂ hδ hc₁ hc₂
    J Hm Hn active hscale hexp).2
  exact uniformMRFamily_of_lowFrequency b u hu Ψ γ 6 δ c₁ c₂ (by norm_num) hc₂
    Hm Hn active hscale hsize (hbands K b) (hFourier Ψ hΨ)
    (hK K hKK b J Hm Hn active hscale hexp)

/-- Fixed-scale form with `K₀` still chosen before the functions `Hm,Hn`.
The stronger family theorem above supplies simultaneous growing collections. -/
theorem uniformMR_uniform_scales
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (M : ℕ) [NeZero M] (u : ZMod M) (hu : IsUnit u)
    (Ψ : ℝ → ℂ) (hΨ : SmoothCompactWeight Ψ)
    (γ sLo sHi δ c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ Hm Hn : ℝ → ℝ, DyadicScales δ c₁ c₂ Hm Hn →
      (∀ᶠ x : ℝ in atTop, sLo ≤ Real.log (Hm x)/Real.log x ∧
        Real.log (2*Hm x)/Real.log x ≤ sHi) →
      UniformMR b M u Ψ γ 6 Hm Hn := by
  obtain ⟨K₀,hK₀,hK⟩ := uniformMRFamilies_of_sources h102 h103 hbands hFourier M u hu
    Ψ hΨ γ sLo sHi δ c₁ c₂ hγ hγs hs hs1 hδ hc₁ hc₂
  refine ⟨K₀,hK₀,?_⟩
  intro K hKK b Hm Hn hscale hexp
  have hsf : ScaleFamily δ c₁ c₂ (fun x (_:Unit) => Hm x)
      (fun x _ => Hn x) (fun _ _ => True) := by
    filter_upwards [hscale] with x hx
    intro _ _
    exact hx
  have hef : ∀ᶠ x : ℝ in atTop, ∀ _j : Unit, True →
      sLo ≤ Real.log (Hm x)/Real.log x ∧ Real.log (2*Hm x)/Real.log x ≤ sHi := by
    filter_upwards [hexp] with x hx
    intro _ _
    exact hx
  obtain ⟨C,hC,h⟩ := hK K hKK b Unit (fun x _ => Hm x) (fun x _ => Hn x)
    (fun _ _ => True) hsf hef
  refine ⟨C,hC,?_⟩
  filter_upwards [h] with x hx
  exact hx () trivial

/-- The growing-family conclusion for the *actual* arithmetic weight.
Neither the number of active dyads nor their selectors influence the common
constant or onset. -/
theorem actualArithmeticWeight_MRFamily {J : Type} {K M : ℕ} (b : Bands K)
    (u : ℕ) (hu : u < M) (Ψ : ℝ → ℝ) (γ D : ℝ)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop)
    (hMR : UniformMRFamily b M (u:ZMod M) (fun y => (Ψ y:ℂ)) γ D Hm Hn active) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
      ∀ β : ℕ → ℂ, BoundedRoughCoefficient x t β →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        ‖∑ m ∈ s, ∑ n ∈ t, discrepancy γ x m*β n*
          (ConcreteSelector.arithmeticWeight M u (fun d => Ψ ((d:ℝ)/x))
            Finset.univ (b.group x) (b.mass x) (b.primes x) c allowed Qmin (m*n):ℂ)‖ ≤
          C*x*(Real.log x)^(-D) := by
  obtain ⟨C,hC,h⟩ := hMR
  refine ⟨C,hC,?_⟩
  filter_upwards [h] with x hx
  intro j hj s t hs ht β hβ c allowed Qmin
  rw [← mrSum_actual_weight b M u hu Ψ γ x s t β c allowed Qmin]
  exact hx j hj s t hs ht β hβ _ (actualSelector_invariant b x c allowed Qmin)

end Artin.MarkedSource
