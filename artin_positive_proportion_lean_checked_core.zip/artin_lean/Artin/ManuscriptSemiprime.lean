module

public import Artin.SemiprimeUpper
public import Artin.ActualRoughPair
public import Artin.ManuscriptMassLower

/-!
# The manuscript's actual semiprime bound

This module connects the concrete marked bands, invariant cofactor selector,
fixed positive bump, and actual unsieved mass to the semiprime assembly.
All marking parameters follow the main semiprime constant.
-/

@[expose] public section
open Filter
open scoped BigOperators

namespace Artin.ManuscriptSemiprime

open MarkedSource MarkedCofactorEstimate SemiprimeMR RoughCompanion
  SemiprimeBoxes SemiprimeCover SemiprimeUpper

/-- The other elementary consequence of the classical band asymptotic
`Vᵢ = log 2 + o(1)`.  The lower bound is already `ClassicalBandMass`. -/
def ClassicalBandUpperMass : Prop :=
  ∀ K : ℕ, ∀ b : Bands K, ∀ᶠ x : ℝ in atTop,
    ∀ i : Fin K, b.mass x i ≤ 2 * Real.log 2

theorem band_exponent_bounds {K : ℕ} (b : Bands K) :
    ∀ i ∈ (Finset.univ : Finset (Fin K)),
      (1 / 10 : ℝ) ≤ b.exponent i ∧ b.exponent i ≤ 1 / 5 :=
  fun i _ => ⟨(b.lower i).le, (b.upper i).le⟩

theorem band_exponent_injective {K : ℕ} (b : Bands K) :
    Set.InjOn b.exponent (↑(Finset.univ : Finset (Fin K))) :=
  b.increasing.injective.injOn

theorem classical_band_bounds (hlo : ClassicalBandMass) (hhi : ClassicalBandUpperMass)
    {K : ℕ} (b : Bands K) :
    ∀ᶠ x : ℝ in atTop, ∀ i ∈ (Finset.univ : Finset (Fin K)),
      Real.log 2 / 2 ≤ MarkedBandTail.bandMass (b.exponent i) x ∧
      MarkedBandTail.bandMass (b.exponent i) x ≤ 2 * Real.log 2 := by
  filter_upwards [hlo K b, hhi K b] with x hl hu i hi
  exact ⟨by simpa only [b.mass_eq_markedBandTail] using hl i,
    by simpa only [b.mass_eq_markedBandTail] using hu i⟩

/-- The same literal weight used in the manuscript's base mass and its
rough-composite contribution. -/
noncomputable def weight {K : ℕ} (b : Bands K) (c M u : ℕ) (ε Y τ x : ℝ) : ℕ → ℝ :=
  actualWeight b M u PositiveBump.weight x c
    (unmarkedCofactors Finset.univ b.exponent ε Y τ x) (x ^ (9 / 10 : ℝ))

theorem weight_eq {K : ℕ} (b : Bands K) (c M u : ℕ) (ε Y τ x : ℝ) :
    weight b c M u ε Y τ x =
      ConcreteSelector.arithmeticWeight M u (ManuscriptMass.smoothWeight x)
        Finset.univ (fun i => MarkedBandTail.primeBand (b.exponent i) x)
        (fun i => MarkedBandTail.bandMass (b.exponent i) x)
        (markedPrimes Finset.univ b.exponent x) c
        (unmarkedCofactors Finset.univ b.exponent ε Y τ x) (x ^ (9 / 10 : ℝ)) := by
  unfold weight actualWeight
  rw [funext (b.group_eq_markedBandTail x), funext (b.mass_eq_markedBandTail x),
    b.primes_eq_markedBandTail]
  rfl

theorem mass_eq_sum_weight {K : ℕ} (b : Bands K) (c M u : ℕ) (ε Y τ x : ℝ) :
    ManuscriptMass.baseMass Finset.univ b.exponent c M u ε Y τ x =
      ∑ d ∈ Finset.Icc 2 ⌊2 * x⌋₊, weight b c M u ε Y τ x d := by
  rw [weight_eq]
  rfl

/-- The manuscript's semiprime upper bound for its literal arithmetic
weight and literal unsieved mass. All original analytic premises have been
proved in the imported modules. The arguments here are precisely the cited
marked-replacement and block-sieve results and classical prime estimates.
The coefficient `C₂` precedes every small parameter and every marking. -/
theorem actual_semiprime_upper
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (h11 : BuchstabSieve.SourceLemma11_1)
    (hbands : ClassicalBandMass) (hbandUpper : ClassicalBandUpperMass)
    (hFourier : ClassicalFourierInversion)
    (hBlock : RoughPairNormalization.ClassicalPrimeBlockBound)
    (hMertensUpper : RoughPairNormalization.ClassicalMertensUpper)
    (hMertensLower : ClassicalMertensLower)
    (hDiv : RoughPairNormalization.ClassicalDivisorSquareMoment)
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : c = 2 ∨ c = 4)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (hunit : (c * v + 1).Coprime (c * M₀)) :
    ∃ C₂ : ℝ, 0 < C₂ ∧ ∃ K₀ : ℕ, 1 ≤ K₀ ∧
      ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ κ : ℝ, 0 < κ → κ ≤ (1 : ℝ) / 100 →
      ∀ ε : ℝ, 0 < ε → ε ≤ (1 : ℝ) / 100 →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → τ ≤ 1 →
      ∀ᶠ x : ℝ in atTop,
        roughCompositeMass x κ (weight b c (c * M₀) (c * v + 1) ε Y τ x) ≤
          C₂ * κ * ManuscriptMass.baseMass Finset.univ b.exponent
            c (c * M₀) (c * v + 1) ε Y τ x / Real.log x := by
  have hc2 : 2 ≤ c := by rcases hc with rfl | rfl <;> norm_num
  have hcpos : 0 < c := by omega
  let : NeZero (c * M₀) := ⟨(Nat.mul_pos hcpos (NeZero.pos M₀)).ne'⟩
  obtain ⟨A, hA, hpairs⟩ := ActualRoughPair.actual_rough_pair_bound h11 hBlock
    hMertensUpper hMertensLower hDiv hPNT hc hu hv
  obtain ⟨C₂, hC₂, K₀, hK₀, hK⟩ := semiprime_upper_from_sources_and_rough_pairs
    h102 h103 hbands hFourier hMertensLower (c * M₀) (c * v + 1) hu
    ((ZMod.isUnit_iff_coprime _ _).mpr hunit)
    PositiveBump.weight PositiveBump.weight_marked_source PositiveBump.weight_nonneg A hA.le
  refine ⟨C₂, hC₂, K₀, hK₀, ?_⟩
  intro K hKK b κ hκ0 hκ ε hε hεmax Y hY τ hτ hτmax
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hb := classical_band_bounds hbands hbandUpper b
  have hmain := ManuscriptMassLower.actual_baseMass_has_positive_lower_scale hPNT hc2 hu hv
    Finset.univ b.exponent (1 / 10) (1 / 5) (2 * Real.log 2) (Real.log 2 / 2)
    (by norm_num) (by norm_num) (by positivity) (band_exponent_bounds b)
    (band_exponent_injective b) hb hε hεmax hY hτ.le
  have hp := hpairs Finset.univ b.exponent (1 / 5) (2 * Real.log 2) (Real.log 2 / 2)
    (by norm_num) (by positivity) (band_exponent_bounds b) (band_exponent_injective b)
    hb ε hε hεmax Y hY τ hτ hτmax
  apply hK K hKK b κ hκ0 hκ c
    (fun x => unmarkedCofactors Finset.univ b.exponent ε Y τ x)
    (fun x => x ^ (9 / 10 : ℝ))
    (fun x => ManuscriptMass.baseMass Finset.univ b.exponent
      c (c * M₀) (c * v + 1) ε Y τ x) hmain
  filter_upwards [hp, narrow_factorWindow hκ, eventually_gt_atTop (1 : ℝ)]
    with x hpx hwindow hx ab hab
  have hm : 0 < leftScale x ab := zpow_pos (by norm_num) _
  have hn : 0 < rightScale x ab := zpow_pos (by norm_num) _
  have harea := DyadicBoxes.narrowBoxIndices_product_bounds (by linarith : 0 < x) hab
  have hsum : leftScale x ab + rightScale x ab ≤ 2 * x ^ (54 / 100 : ℝ) := by
    have hh := hwindow ab hab
    have hxpow := Real.rpow_nonneg (by linarith : 0 ≤ x) (54 / 100 : ℝ)
    linarith [hh.2.1, hh.2.2.2]
  have hh := hpx (leftScale x ab) (rightScale x ab) hm.le hn.le harea.2 hsum
    (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
    (fun m hm' => (mem_dyadIntegers hm m).mp hm')
    (fun n hn' => (mem_dyadIntegers hn n).mp hn')
  change SemiprimeReplacement.pairMass _ _ (weight b c (c * M₀) (c * v + 1) ε Y τ x)
    _ _ ≤ _
  rw [weight_eq]
  exact hh

end Artin.ManuscriptSemiprime
