module

public import Artin.FullMassComparison
public import Artin.WeightSupport
public import Artin.PositiveBump
public import Artin.PrimeMassAssembly
public import Artin.MarkedScaleSupport

/-!
# The actual unsieved manuscript mass

The definition sums the original invariant arithmetic weight over integers.
The fixed smooth function is positive and independent of all marking choices.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.ManuscriptMass

open ConcreteSelector MarkedCofactorEstimate EnlargedCofactorMass
  FullMassComparison MarkedBandTail

/-- The single fixed smooth cutoff at scale `x`. -/
noncomputable def smoothWeight (x : ℝ) (d : ℕ) : ℝ :=
  PositiveBump.weight ((d : ℝ) / x)

/-- The full marked arithmetic mass, before sieving the integer `d`. -/
noncomputable def baseMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) : ℝ :=
  ∑ d ∈ Finset.Icc 2 ⌊2 * x⌋₊,
    arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) c
      (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) d

/-- The actual convergent full reciprocal mass `J`. -/
noncomputable def fullMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) : ℝ :=
  enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x)

theorem smoothWeight_bounds (x : ℝ) (d : ℕ) :
    0 ≤ smoothWeight x d ∧ smoothWeight x d ≤ 1 :=
  ⟨PositiveBump.weight_nonneg _, PositiveBump.weight_le_one _⟩

theorem smoothWeight_support {x : ℝ} (hx : 2 ≤ x) (d : ℕ)
    (hd : smoothWeight x d ≠ 0) : 2 ≤ d ∧ (d : ℝ) ≤ 2 * x := by
  have hx0 : 0 < x := by linarith
  have hs := PositiveBump.weight_support hd
  have hl : x < (d : ℝ) := by
    simpa using (lt_div_iff₀ hx0).mp hs.1
  have hu : (d : ℝ) < 2 * x := (div_lt_iff₀ hx0).mp hs.2
  exact ⟨by exact_mod_cast (hx.trans hl.le), hu.le⟩

theorem smoothWeight_zero_above {x : ℝ} (hx : 2 ≤ x) (d : ℕ)
    (hd : 2 * x < (d : ℝ)) : smoothWeight x d = 0 := by
  by_contra hn
  exact (not_lt_of_ge (smoothWeight_support hx d hn).2) hd

/-- Exhaustive reindexing of the actual integer mass. The prime support
conditions here will be supplied by the scale bounds for the concrete bands. -/
theorem baseMass_eq_cofactorPrimeMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z : ℝ) (hx : 2 ≤ x) (hc : 0 < c)
    (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z) :
    baseMass I a c M u ε Y τ x =
      cofactorPrimeMass c M u
        (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
        (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (smoothWeight x) (marking I a x) (2 * x) := by
  have hg : ∀ i ∈ I, primeBand (a i) x ⊆ markedPrimes I a x := by
    intro i hi p hp
    exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩
  have hh := WeightSupport.ambient_weight_sum_eq_real M u c (2 * x) (smoothWeight x) I
    (fun i => primeBand (a i) x) (fun i => bandMass (a i) x)
    (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
    (by positivity) hc hcut
    (fun p hp => ⟨markedPrimes_prime I a x p hp, hP p hp⟩) hg hcP
    (fun r hr => ⟨Nat.pos_of_ne_zero (unmarkedCofactors_avoid I a ε Y τ x r hr).1,
      (unmarkedCofactors_avoid I a ε Y τ x r hr).2⟩) hU
    (fun d hd => smoothWeight_support hx d hd)
  change baseMass I a c M u ε Y τ x = _ at hh
  rw [hh]
  unfold cofactorPrimeMass
  apply Finset.sum_congr rfl
  intro r hr
  rw [marking, markingWeight_markedPart I _ _ _ r hg]

/-- Explicit constants for the actual full-mass comparison. They depend
only on the fixed progression and the single fixed positive smooth weight. -/
noncomputable def lowerConstant (c M₀ : ℕ) : ℝ :=
  PrimeMainMass.weightMass PositiveBump.weight / (8 * c * (M₀.totient : ℝ))

noncomputable def upperConstant (c M₀ : ℕ) : ℝ :=
  2 * PrimeMainMass.weightMass PositiveBump.weight / ((c : ℝ) * M₀.totient) + 1

theorem constants_positive (c M₀ : ℕ) (hc : 0 < c) (hM : 0 < M₀) :
    0 < lowerConstant c M₀ ∧ 0 < upperConstant c M₀ := by
  have hc' : (0 : ℝ) < c := by exact_mod_cast hc
  have hφ : (0 : ℝ) < M₀.totient := by exact_mod_cast Nat.totient_pos.mpr hM
  have hμ := PositiveBump.weightMass_pos
  unfold lowerConstant upperConstant
  constructor <;> positivity

/-- The complete mass comparison for the original, untruncated invariant
weight. No cofactor mass, tail bound, prime-count comparison, support identity,
or smooth-weight existence is assumed. The external inputs are exactly
fixed-modulus PNT and classical reciprocal mass bounds for the prime bands.
The displayed constants are fixed before every marking parameter. -/
theorem actual_full_mass_comparison
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∀ ε : ℝ, 0 < ε → ε ≤ 1 / 100 → ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ,
      ∀ᶠ x : ℝ in atTop,
        lowerConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x ≤
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x ∧
        baseMass I a c (c * M₀) (c * v + 1) ε Y τ x ≤
          upperConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x := by
  have hcpos : 0 < c := by omega
  letI : NeZero c := ⟨hcpos.ne'⟩
  obtain ⟨K, hK, hLip⟩ := PositiveBump.weight_abs_sub_le
  have hAr := PrimeMassAssembly.uniform_common_primeSum_bounds hPNT hu hv
    PositiveBump.weight PositiveBump.weight_continuous PositiveBump.weight_nonneg
    (fun _ hy => PositiveBump.weight_eq_zero_of_not_mem_Icc hy)
    (by norm_num : (0 : ℝ) < 1) hK PositiveBump.weight_abs_le_one hLip PositiveBump.weightMass_pos
  intro ε hε hεmax Y hY τ
  filter_upwards [hAr, uniform_retained_full_mass I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical ε hε Y τ,
    actual_tail_le_full_over_log I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical ε hε Y τ,
    MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax c (1 / 2)
      hmin hmax (by norm_num) ha,
    MarkedScaleSupport.eventual_marked_not_dvd I a amin amax hmin hmax ha c hcpos,
    MarkedScaleSupport.eventual_enlarged_coprime I a amin amax ε Y τ hmin hmax ha
      M₀ (NeZero.pos M₀) hY,
    hclassical, eventually_ge_atTop (2 : ℝ)] with x hAx hretain htail hPx hcPx hcop hVx hx
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos (by linarith)
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hW : ∀ n, 0 ≤ marking I a x n := fun n => (markingWeight_bounds I _ _ n hV).1
  have hsum : Summable (enlargedReciprocal (markedPrimes I a x)
      (unmarkedCofactors I a ε Y τ x) (marking I a x)) :=
    summable_enlargedReciprocal _ _ _ (unmarkedCofactors_avoid I a ε Y τ x) hW
      (MarkedInfiniteMass.summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have hXT : x ^ ε ≤ 2 * x := by
    calc
      x ^ ε ≤ x ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
      _ = x := Real.rpow_one x
      _ ≤ 2 * x := by linarith
  have heq := baseMass_eq_cofactorPrimeMass I a c (c * M₀) (c * v + 1) ε Y τ x
    (x ^ (1 / 2 : ℝ)) hx hcpos
    (Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num))
    (fun p hp => (hPx p hp).2.2) hcPx
    (fun r hr p hp hpr => MarkedScaleSupport.unmarked_prime_divisor_le I a ε Y τ (1 / 2)
      hx1 (by linarith) hr hp hpr)
  let low : ℝ := PrimeMainMass.weightMass PositiveBump.weight / (4 * c * (M₀.totient : ℝ))
  let high : ℝ := 2 * PrimeMainMass.weightMass PositiveBump.weight / ((c : ℝ) * M₀.totient)
  have hμ := PositiveBump.weightMass_pos
  have hl : 0 ≤ low := by dsimp [low]; positivity
  have hh : 0 ≤ high := by dsimp [high]; positivity
  have hcounts : ∀ r ∈ boundedCofactors (markedPrimes I a x)
      (unmarkedCofactors I a ε Y τ x) (x ^ ε),
      low * x / r / Real.log x ≤ CofactorRepresentation.primeProgressionSum c (c * M₀)
        (c * v + 1) (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
        (smoothWeight x) r ∧
      CofactorRepresentation.primeProgressionSum c (c * M₀)
        (c * v + 1) (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
        (smoothWeight x) r ≤ high * x / r / Real.log x := by
    intro r hr
    obtain ⟨hrpos, _, hrange⟩ := (mem_boundedCofactors _ _ _ r).mp hr
    have hm := hAx r hrpos (hrange.trans (Real.rpow_le_rpow_of_exponent_le hx1 hεmax))
      (hcop (x ^ ε) r hr)
    change low * ((x / r) / Real.log x) ≤ _ ∧ _ ≤ high * ((x / r) / Real.log x) at hm
    change low * x / r / Real.log x ≤
      CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
        ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => x ^ (9 / 10 : ℝ) < (Q : ℝ)))
        (fun d => PositiveBump.weight ((d : ℝ) / x)) r ∧
      CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
        ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => x ^ (9 / 10 : ℝ) < (Q : ℝ)))
        (fun d => PositiveBump.weight ((d : ℝ) / x)) r ≤ high * x / r / Real.log x
    simpa only [mul_div_assoc] using hm
  have hf := full_mass_comparison c (c * M₀) (c * v + 1)
    (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
    (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (smoothWeight x) (marking I a x)
    hx0.le hL hl hh hc hXT hW hsum
    (fun Q hQ => (WeightSupport.mem_boundedLargePrimes.mp hQ).1.pos)
    (smoothWeight_bounds x) (smoothWeight_zero_above hx) hcounts hretain htail
  rw [← heq] at hf
  have hlid : low / 2 = lowerConstant c M₀ := by dsimp [low, lowerConstant]; ring
  simpa only [hlid, high, upperConstant, fullMass] using hf

end Artin.ManuscriptMass
