module

public import Artin.Counting
public import Artin.Parameters
public import Artin.AnalyticReduction
public import Mathlib.Tactic.FieldSimp

/-!
# Parameter selection and limiting deductions for the candidate sieve

This module proves the analytic bookkeeping in Sections 7--9. In particular,
the semiprime width is fixed before the initial sieve cutoff, the local-product
tolerance is fixed after that cutoff, and all three precede the number of
marks. The errors in the finite sieves and marked replacements are explicit
premises, not assumed cited theorems.

What this module does NOT supply is the application of Bombieri--Vinogradov,
the block sieve, or marked replacement that gives those errors for the actual
arithmetic weights. It proves the deductions once those estimates have been
established.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- The semiprime width can be fixed using only the main local constant and
the mark-independent constant in the two-variable sieve. -/
theorem exists_semiprime_width {S C₂ : ℝ} (hS : 0 < S) (hC₂ : 0 ≤ C₂) :
    ∃ κ : ℝ, 0 < κ ∧ κ < 1 / 100 ∧ C₂ * κ < S / 8 := by
  let κ := min (1 / 200 : ℝ) (S / (16 * (C₂ + 1)))
  have hkpos : 0 < κ := lt_min (by norm_num) (by positivity)
  have hk1 : κ ≤ 1 / 200 := min_le_left _ _
  have hk2 : κ ≤ S / (16 * (C₂ + 1)) := min_le_right _ _
  have hden : 0 < 16 * (C₂ + 1) := by positivity
  have hmul := (le_div_iff₀ hden).mp hk2
  refine ⟨κ, hkpos, by linarith, ?_⟩
  nlinarith

/-- A fixed multiple of `t * exp (-c*t)` tends to zero. This is the
exponential-over-linear estimate used when choosing `b = 1/t`. -/
theorem tendsto_linear_exp_error_zero (A : ℝ) {c : ℝ} (hc : 0 < c) :
    Tendsto (fun t : ℝ => A * t * Real.exp (-c * t)) atTop (𝓝 0) := by
  have h := (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero 1 c hc).const_mul A
  simpa [Real.rpow_one, mul_assoc] using h

/-- Choose the initial cutoff after any prescribed positive upper bound.
This proves the existence asserted in equation (bchoice), rather than taking
smallness of its exponential error as an extra hypothesis. -/
theorem exists_initial_sieve_cutoff (E Cₛ C_d : ℝ) {cₛ c_d b₀ : ℝ}
    (hcₛ : 0 < cₛ) (hc_d : 0 < c_d) (hb₀ : 0 < b₀) :
    ∃ b : ℝ, 0 < b ∧ b < b₀ ∧
      E / b * (Cₛ * Real.exp (-cₛ / b) + C_d * Real.exp (-c_d / b)) < 1 / 10 := by
  have he : Tendsto (fun t : ℝ =>
      E * Cₛ * t * Real.exp (-cₛ * t) +
      E * C_d * t * Real.exp (-c_d * t)) atTop (𝓝 0) := by
    simpa only [zero_add] using
      (tendsto_linear_exp_error_zero (E * Cₛ) hcₛ).add
        (tendsto_linear_exp_error_zero (E * C_d) hc_d)
  have hsmall : ∀ᶠ t : ℝ in atTop,
      E * Cₛ * t * Real.exp (-cₛ * t) +
      E * C_d * t * Real.exp (-c_d * t) < 1 / 10 :=
    (tendsto_order.1 he).2 _ (by norm_num)
  obtain ⟨t, ht, ht₀, ht₁⟩ :=
    (hsmall.and ((eventually_gt_atTop (0 : ℝ)).and
      (eventually_gt_atTop (1 / b₀)))).exists
  refine ⟨1 / t, by positivity, ?_, ?_⟩
  · exact (div_lt_iff₀ ht₀).2 (by simpa [mul_comm] using (div_lt_iff₀ hb₀).1 ht₁)
  · have hs : E / (1 / t) *
        (Cₛ * Real.exp (-cₛ / (1 / t)) + C_d * Real.exp (-c_d / (1 / t))) =
        E * Cₛ * t * Real.exp (-cₛ * t) +
        E * C_d * t * Real.exp (-c_d * t) := by
      simp only [div_div_eq_mul_div, div_one]
      ring
    rw [hs]
    exact ht

/-- The local-product tolerance is chosen AFTER `D = D_b(1)`. Continuity of
the exponential proves that it can also obey any prescribed positive bound. -/
theorem exists_local_product_tolerance (D : ℝ) {τ₀ : ℝ} (hτ₀ : 0 < τ₀) :
    ∃ τ : ℝ, 0 < τ ∧ τ < τ₀ ∧
      (Real.exp (10 * τ) - 1) * (D + 1) < 1 / 10 := by
  have ht : Tendsto (fun τ : ℝ => (Real.exp (10 * τ) - 1) * (D + 1))
      (𝓝 0) (𝓝 0) := by
    have hexp : Tendsto (fun τ : ℝ => Real.exp (10 * τ)) (𝓝 0) (𝓝 1) := by
      have hlin : Tendsto (fun τ : ℝ => 10 * τ) (𝓝 0) (𝓝 0) := by
        simpa using (tendsto_id : Tendsto (fun τ : ℝ => τ) (𝓝 0) (𝓝 0)).const_mul 10
      simpa only [Function.comp_def, Real.exp_zero] using
        (Real.continuous_exp.tendsto (0 : ℝ)).comp hlin
    simpa using (hexp.sub_const 1).mul_const (D + 1)
  have ht' : Tendsto (fun τ : ℝ => (Real.exp (10 * τ) - 1) * (D + 1))
      (𝓝[>] (0 : ℝ)) (𝓝 0) := ht.mono_left nhdsWithin_le_nhds
  have hsmall : ∀ᶠ τ : ℝ in 𝓝[>] (0 : ℝ),
      (Real.exp (10 * τ) - 1) * (D + 1) < 1 / 10 :=
    (tendsto_order.1 ht').2 _ (by norm_num)
  have hupper : ∀ᶠ τ : ℝ in 𝓝[>] (0 : ℝ), τ < τ₀ :=
    (eventually_lt_nhds hτ₀).filter_mono nhdsWithin_le_nhds
  have hpos : ∀ᶠ τ : ℝ in 𝓝[>] (0 : ℝ), 0 < τ := self_mem_nhdsWithin
  obtain ⟨τ, hs, hu, hp⟩ := (hsmall.and (hupper.and hpos)).exists
  exact ⟨τ, hp, hu, hs⟩

/-- The complete fixed-parameter choice before choosing the number of marks.
`D` denotes the classical Buchstab value `D_b(1)`. Its rapid-convergence bound
is displayed explicitly, while the required small exponential errors and
local-product error are proved achievable here. -/
theorem exists_candidate_sieve_parameters
    (S C₂ E Cₛ C_d : ℝ) (D : ℝ → ℝ) {cₛ c_d b₀ : ℝ}
    (hS : 0 < S) (hC₂ : 0 ≤ C₂) (hcₛ : 0 < cₛ)
    (hc_d : 0 < c_d) (hb₀ : 0 < b₀)
    (hD : ∀ b : ℝ, 0 < b → b < b₀ →
      D b ≤ E / b * (1 + C_d * Real.exp (-c_d / b))) :
    ∃ κ b τ : ℝ,
      0 < κ ∧ κ < 1 / 100 ∧ C₂ * κ < S / 8 ∧
      0 < b ∧ b < b₀ ∧ b < 1 / 100 ∧
      0 < τ ∧ τ < 1 / 100 ∧
      (3 : ℝ) / 4 ≤
        E / b * (1 - Cₛ * Real.exp (-cₛ / b)) -
          Real.exp (10 * τ) * (D b - 1 + 1 / 20) := by
  obtain ⟨κ, hkpos, hksmall, hkloss⟩ := exists_semiprime_width hS hC₂
  obtain ⟨b, hbpos, hbsmall, hberror⟩ :=
    exists_initial_sieve_cutoff E Cₛ C_d hcₛ hc_d
      (lt_min hb₀ (by norm_num : (0 : ℝ) < 1 / 100))
  have hbb₀ : b < b₀ := lt_of_lt_of_le hbsmall (min_le_left _ _)
  have hb100 : b < 1 / 100 := lt_of_lt_of_le hbsmall (min_le_right _ _)
  obtain ⟨τ, hτpos, hτsmall, hτerror⟩ :=
    exists_local_product_tolerance (D b) (by norm_num : (0 : ℝ) < 1 / 100)
  refine ⟨κ, b, τ, hkpos, hksmall, hkloss, hbpos, hbb₀, hb100,
    hτpos, hτsmall, ?_⟩
  exact buchstab_subtraction_margin (hD b hbpos hbb₀) hberror.le
    (Real.one_le_exp (by linarith)) hτerror.le

/-- Assemble a fixed finite partition of least-prime-factor bins. Each bin
may have its own vanishing error and its own eventual threshold. The finite
partition lets us sum these errors and intersect these thresholds. The only
input about the partition is its displayed Buchstab upper-sum bound. -/
theorem buchstab_finite_partition_subtraction
    {ι α : Type*} {l : Filter α} (I : Finset ι)
    {mass initial rough e₀ : α → ℝ} {bins errors : ι → α → ℝ}
    {coeff : ι → ℝ} {B D E errorS errorD : ℝ}
    (hD : D ≤ B * (1 + errorD))
    (herror : B * (errorS + errorD) ≤ 1 / 10)
    (hE : 1 ≤ E) (hlocal : (E - 1) * (D + 1) ≤ 1 / 10)
    (hpartition : ∑ i ∈ I, coeff i ≤ D - 1 + 1 / 20)
    (he₀ : Tendsto e₀ l (𝓝 0))
    (herrors : ∀ i ∈ I, Tendsto (errors i) l (𝓝 0))
    (hmass : ∀ᶠ x in l, 0 ≤ mass x)
    (hinitial : ∀ᶠ x in l, (B * (1 - errorS) + e₀ x) * mass x ≤ initial x)
    (hbins : ∀ i ∈ I, ∀ᶠ x in l,
      bins i x ≤ (E * coeff i + errors i x) * mass x)
    (hcover : ∀ᶠ x in l, initial x ≤ rough x + ∑ i ∈ I, bins i x) :
    ∃ e : α → ℝ, Tendsto e l (𝓝 0) ∧
      ∀ᶠ x in l, ((3 : ℝ) / 4 + e x) * mass x ≤ rough x := by
  let e := fun x => e₀ x - ∑ i ∈ I, errors i x
  have hsumzero : Tendsto (fun x => ∑ i ∈ I, errors i x) l (𝓝 0) := by
    simpa only [Finset.sum_const_zero] using tendsto_finsetSum I herrors
  have he : Tendsto e l (𝓝 0) := by
    simpa only [e, sub_zero] using he₀.sub hsumzero
  have hbins' : ∀ᶠ x in l, ∀ i ∈ I,
      bins i x ≤ (E * coeff i + errors i x) * mass x :=
    (eventually_all_finset I).2 hbins
  have hmargin := buchstab_subtraction_margin hD herror hE hlocal
  have hcoeff : (3 : ℝ) / 4 ≤ B * (1 - errorS) - E * ∑ i ∈ I, coeff i := by
    have hh := mul_le_mul_of_nonneg_left hpartition (by linarith : 0 ≤ E)
    linarith
  refine ⟨e, he, ?_⟩
  filter_upwards [hmass, hinitial, hbins', hcover] with x hm hi hb hc
  have hsum := Finset.sum_le_sum hb
  have hsum' : (∑ i ∈ I, bins i x) ≤
      (E * ∑ i ∈ I, coeff i + ∑ i ∈ I, errors i x) * mass x := by
    calc
      (∑ i ∈ I, bins i x) ≤ (∑ i ∈ I, (E * coeff i + errors i x)) * mass x := by
        rw [Finset.sum_mul]
        exact hsum
      _ = (E * ∑ i ∈ I, coeff i + ∑ i ∈ I, errors i x) * mass x := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum]
  have hbound := mul_le_mul_of_nonneg_right hcoeff hm
  dsimp [e]
  nlinarith only [hbound, hi, hsum', hc]

/-- The normalized finite-sieve and marked-replacement errors may all depend
on the parameters fixed before `x`. Their limits suffice for the final loss
budget; no common convergence rate is required. -/
theorem eventually_half_mass_after_sieve
    {ι : Type*} {l : Filter ι}
    {base rough semiprime retained tail e₁ e₂ e₃ : ι → ℝ}
    {S C₂ κ : ℝ} (hS : 0 < S) (hk : C₂ * κ ≤ S / 8)
    (he₁ : Tendsto e₁ l (𝓝 0)) (he₂ : Tendsto e₂ l (𝓝 0))
    (he₃ : Tendsto e₃ l (𝓝 0))
    (hbase : ∀ᶠ x in l, 0 ≤ base x)
    (hrough : ∀ᶠ x in l, ((3 / 4 : ℝ) * S - e₁ x) * base x ≤ rough x)
    (hsemi : ∀ᶠ x in l, semiprime x ≤ (C₂ * κ + e₂ x) * base x)
    (htail : ∀ᶠ x in l, tail x ≤ e₃ x * base x)
    (hcover : ∀ᶠ x in l, rough x ≤ retained x + semiprime x + tail x) :
    ∀ᶠ x in l, (S / 2) * base x ≤ retained x := by
  have he : Tendsto (fun x => e₁ x + e₂ x + e₃ x) l (𝓝 0) := by
    simpa only [zero_add] using (he₁.add he₂).add he₃
  have herr : ∀ᶠ x in l, e₁ x + e₂ x + e₃ x < S / 8 :=
    (tendsto_order.1 he).2 _ (by positivity)
  filter_upwards [hbase, hrough, hsemi, htail, hcover, herr]
    with x hb hr hs ht hc he
  have hmain := mul_le_mul_of_nonneg_right hk hb
  have herror := mul_le_mul_of_nonneg_right he.le hb
  nlinarith

/-- The extra `1/log x` in the dyadic semiprime-box count is a vanishing
error. Thus the fixed width contributes exactly `C₂*κ` to the coefficient. -/
theorem tendsto_semiprime_normalized_error (C₂ : ℝ) {e : ℝ → ℝ}
    (he : Tendsto e atTop (𝓝 0)) :
    Tendsto (fun x : ℝ => C₂ / Real.log x + e x) atTop (𝓝 0) := by
  have hi : Tendsto (fun x : ℝ => (Real.log x)⁻¹) atTop (𝓝 0) :=
    Real.tendsto_log_atTop.inv_tendsto_atTop
  simpa [div_eq_mul_inv] using (hi.const_mul C₂).add he

/-- Removing the bounded marking weight and using the two harmonic-mass
lower bounds gives the claimed coefficient. This is an exact inequality;
all eventual arithmetic estimates can be instantiated at a large `x`. -/
theorem candidate_count_from_harmonic_mass {α : Type*}
    (s : Finset α) (w : α → ℝ)
    {S c d B ε Y x X₀ J : ℝ}
    (hS : 0 < S) (hc : 0 < c) (hd : 0 < d) (hB : 0 < B)
    (hε : 0 < ε) (hY : 1 < Y) (hx : 1 < x)
    (hweight : ∀ p ∈ s, w p ≤ B)
    (hretained : S / 2 * (X₀ / Real.log x) ≤ ∑ p ∈ s, w p)
    (hX₀ : c * x * J / Real.log x ≤ X₀)
    (hJ : d * ε * Real.log x / Real.log Y ≤ J) :
    (S * c * d / (2 * B)) * ε / Real.log Y * (x / Real.log x) ≤
      (s.card : ℝ) := by
  have hxpos : 0 < x := by linarith
  have hlx : 0 < Real.log x := Real.log_pos hx
  have hly : 0 < Real.log Y := Real.log_pos hY
  have hmass₁ := mul_le_mul_of_nonneg_left hJ (by positivity : 0 ≤ c * x / Real.log x)
  have hmass₂ : c * d * ε * x / Real.log Y ≤ X₀ := by
    calc
      c * d * ε * x / Real.log Y =
          c * x / Real.log x * (d * ε * Real.log x / Real.log Y) := by
        field_simp
      _ ≤ c * x / Real.log x * J := hmass₁
      _ = c * x * J / Real.log x := by ring
      _ ≤ X₀ := hX₀
  have hmass₃ := mul_le_mul_of_nonneg_left hmass₂
    (by positivity : 0 ≤ S / (2 * Real.log x))
  have hcount := weighted_sum_le_card_mul s w B hweight
  apply (mul_le_mul_iff_of_pos_right hB).mp
  have heq : (S * c * d / (2 * B) * ε / Real.log Y * (x / Real.log x)) * B =
      S / (2 * Real.log x) * (c * d * ε * x / Real.log Y) := by
    field_simp
  rw [heq]
  have heq₂ : S / (2 * Real.log x) * X₀ = S / 2 * (X₀ / Real.log x) := by ring
  exact le_trans hmass₃ (by rw [heq₂]; exact le_trans hretained hcount)

/-- The complete limiting deduction from the concrete sieve estimates. The
constant in the conclusion uses only `S,c,d,B`; it is independent of `ε,Y`
and of the eventual thresholds of the error terms.

The hypotheses here are intermediate estimates which still have to be
proved for the manuscript's weights. They are not external axioms. -/
theorem eventually_candidate_count_from_sieve_estimates {α : Type*}
    (s : ℝ → Finset α) (w : ℝ → α → ℝ)
    {X₀ J rough semiprime tail e₁ e₂ e₃ : ℝ → ℝ}
    {S C₂ κ c d B ε Y : ℝ}
    (hS : 0 < S) (hc : 0 < c) (hd : 0 < d) (hB : 0 < B)
    (hε : 0 < ε) (hY : 1 < Y) (hk : C₂ * κ ≤ S / 8)
    (he₁ : Tendsto e₁ atTop (𝓝 0)) (he₂ : Tendsto e₂ atTop (𝓝 0))
    (he₃ : Tendsto e₃ atTop (𝓝 0))
    (hbase : ∀ᶠ x in atTop, 0 ≤ X₀ x)
    (hweight : ∀ᶠ x in atTop, ∀ p ∈ s x, w x p ≤ B)
    (hrough : ∀ᶠ x in atTop,
      ((3 / 4 : ℝ) * S - e₁ x) * (X₀ x / Real.log x) ≤ rough x)
    (hsemi : ∀ᶠ x in atTop,
      semiprime x ≤ (C₂ * (κ + 1 / Real.log x) + e₂ x) * (X₀ x / Real.log x))
    (htail : ∀ᶠ x in atTop, tail x ≤ e₃ x * (X₀ x / Real.log x))
    (hcover : ∀ᶠ x in atTop,
      rough x ≤ (∑ p ∈ s x, w x p) + semiprime x + tail x)
    (hX₀ : ∀ᶠ x in atTop, c * x * J x / Real.log x ≤ X₀ x)
    (hJ : ∀ᶠ x in atTop, d * ε * Real.log x / Real.log Y ≤ J x) :
    ∀ᶠ x in atTop,
      (S * c * d / (2 * B)) * ε / Real.log Y * (x / Real.log x) ≤
        ((s x).card : ℝ) := by
  have hbasenonneg : ∀ᶠ x in atTop, 0 ≤ X₀ x / Real.log x := by
    filter_upwards [hbase, eventually_gt_atTop (1 : ℝ)] with x hb hx
    exact div_nonneg hb (Real.log_pos hx).le
  have hsemi' : ∀ᶠ x in atTop,
      semiprime x ≤ (C₂ * κ + (C₂ / Real.log x + e₂ x)) *
        (X₀ x / Real.log x) := by
    filter_upwards [hsemi] with x hx
    convert hx using 1
    ring
  have hretained := eventually_half_mass_after_sieve hS hk
    he₁ (tendsto_semiprime_normalized_error C₂ he₂) he₃
    hbasenonneg hrough hsemi' htail hcover
  filter_upwards [hweight, hretained, hX₀, hJ, eventually_gt_atTop (1 : ℝ)]
    with x hw hr hX hJx hx
  exact candidate_count_from_harmonic_mass (s x) (w x) hS hc hd hB hε hY hx hw hr hX hJx

/-- Exact intermediate proof obligations for one fixed `ε,Y` in the candidate
sieve. The finite sets are linked to the manuscript's actual structured
candidate predicate. This structure asserts no theorem: constructing it
requires proofs of every listed arithmetic and analytic estimate. -/
structure CandidateSieveData (a : ℤ) (S C₂ κ c d B ε Y : ℝ) where
  primes : ℝ → Finset ℕ
  weights : ℝ → ℕ → ℝ
  mainMass : ℝ → ℝ
  harmonicMass : ℝ → ℝ
  roughMass : ℝ → ℝ
  semiprimeMass : ℝ → ℝ
  tailMass : ℝ → ℝ
  roughError : ℝ → ℝ
  semiprimeError : ℝ → ℝ
  tailError : ℝ → ℝ
  roughError_zero : Tendsto roughError atTop (𝓝 0)
  semiprimeError_zero : Tendsto semiprimeError atTop (𝓝 0)
  tailError_zero : Tendsto tailError atTop (𝓝 0)
  mainMass_nonneg : ∀ᶠ x in atTop, 0 ≤ mainMass x
  weights_bounded : ∀ᶠ x in atTop, ∀ p ∈ primes x, weights x p ≤ B
  support : ∀ᶠ x in atTop, ∀ p ∈ primes x,
    p ∈ ambientPrimes x ∧ StructuredCandidate a ⌊Y⌋₊ ⌊x ^ ε⌋₊ p
  rough_lower : ∀ᶠ x in atTop,
    ((3 / 4 : ℝ) * S - roughError x) * (mainMass x / Real.log x) ≤ roughMass x
  semiprime_upper : ∀ᶠ x in atTop,
    semiprimeMass x ≤ (C₂ * (κ + 1 / Real.log x) + semiprimeError x) *
      (mainMass x / Real.log x)
  tail_upper : ∀ᶠ x in atTop, tailMass x ≤ tailError x * (mainMass x / Real.log x)
  cover : ∀ᶠ x in atTop,
    roughMass x ≤ (∑ p ∈ primes x, weights x p) + semiprimeMass x + tailMass x
  mainMass_lower : ∀ᶠ x in atTop, c * x * harmonicMass x / Real.log x ≤ mainMass x
  harmonicMass_lower : ∀ᶠ x in atTop, d * ε * Real.log x / Real.log Y ≤ harmonicMass x

/-- The intermediate sieve data imply a lower bound for the actual candidate
prime count, not merely an abstract sequence of real numbers. -/
theorem candidate_lower_bound_of_sieve_data
    {a : ℤ} {S C₂ κ c d B ε Y : ℝ}
    (hS : 0 < S) (hc : 0 < c) (hd : 0 < d) (hB : 0 < B)
    (hε : 0 < ε) (hY : 1 < Y) (hk : C₂ * κ ≤ S / 8)
    (data : CandidateSieveData a S C₂ κ c d B ε Y) :
    ∀ᶠ x in atTop,
      (S * c * d / (2 * B)) * ε / Real.log Y * (x / Real.log x) ≤
        structuredCandidateCount a ε Y x := by
  classical
  have hcount := eventually_candidate_count_from_sieve_estimates data.primes data.weights
    hS hc hd hB hε hY hk data.roughError_zero data.semiprimeError_zero
    data.tailError_zero data.mainMass_nonneg data.weights_bounded data.rough_lower
    data.semiprime_upper data.tail_upper data.cover data.mainMass_lower data.harmonicMass_lower
  filter_upwards [hcount, data.support] with x hc' hs
  have hsubset : data.primes x ⊆ (ambientPrimes x).filter
      (StructuredCandidate a ⌊Y⌋₊ ⌊x ^ ε⌋₊) := by
    intro p hp
    exact Finset.mem_filter.mpr (hs p hp)
  have hcard : ((data.primes x).card : ℝ) ≤ structuredCandidateCount a ε Y x := by
    unfold structuredCandidateCount filteredCard
    exact_mod_cast Finset.card_le_card hsubset
  exact hc'.trans hcard

/-- Quantifier order is now explicit: all constants `S,C₂,κ,c,d,B,Y₀,ε₀`
are fixed before `ε,Y`, and hence before the later zero-free parameter `N`.
An eventual threshold may depend on the entire supplied sieve datum.

This is a proved constructor for `CandidateEstimate`. Constructing `hdata`
from the permitted cited results remains a separate proof obligation. -/
theorem candidate_estimate_of_intermediate_sieve_data
    {a : ℤ} {S C₂ κ c d B Y₀ ε₀ : ℝ}
    (hS : 0 < S) (hc : 0 < c) (hd : 0 < d) (hB : 0 < B)
    (hk : C₂ * κ ≤ S / 8)
    (hdata : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c d B ε Y)) :
    CandidateEstimate a (S * c * d / (2 * B)) Y₀ ε₀ := by
  intro ε Y hε hε₀ hY₀ hY
  obtain ⟨data⟩ := hdata ε Y hε hε₀ hY₀ hY
  refine ⟨fun _ => 0, tendsto_const_nhds, ?_⟩
  simpa only [add_zero] using candidate_lower_bound_of_sieve_data hS hc hd hB hε hY hk data

end Artin
