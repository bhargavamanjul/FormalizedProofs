module

public import Artin.InitialSieve
public import Artin.SiftedSupport
public import Artin.MarkedSource
public import Artin.RoughCompanion

/-!
# The growing-depth conditioned sieve

The prime in a Buchstab bin is multiplied into the small squarefree sieve
modulus. The explicit depth below makes the source error tend to zero while
keeping every such product inside the proved Bombieri--Vinogradov range.

The final theorem applies the cited block sieve to the literal retained
cofactor arrays. The omitted-prime cost, common BV remainder, bin support,
and comparison with the full arithmetic mass are all proved applications.
The ordinary prime harmonic sum and fixed-modulus Euler product are kept
explicit for the subsequent classical normalization.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter Asymptotics
namespace Artin.ConditionedSieve
open BuchstabSieve

/-- The even depth used for the conditioned upper sieve. -/
noncomputable def growingDepth (x : ℝ) : ℕ :=
  2 * ⌈(Real.log (Real.log x)) ^ 2⌉₊

theorem growingDepth_even (x : ℝ) : Even (growingDepth x) := even_two_mul _

theorem growingDepth_bounds (x : ℝ) :
    2 * (Real.log (Real.log x)) ^ 2 ≤ (growingDepth x : ℝ) ∧
      (growingDepth x : ℝ) ≤ 2 * (Real.log (Real.log x)) ^ 2 + 2 := by
  have hl := Nat.le_ceil ((Real.log (Real.log x)) ^ 2)
  have hu := Nat.ceil_lt_add_one (sq_nonneg (Real.log (Real.log x)))
  unfold growingDepth
  push_cast
  constructor <;> linarith

/-- Every fixed source depth threshold is eventually reached. -/
theorem growingDepth_eventually_ge (H₀ : ℕ) :
    ∀ᶠ x : ℝ in atTop, H₀ ≤ growingDepth x := by
  have he := (Real.tendsto_log_atTop.comp Real.tendsto_log_atTop).eventually
    (eventually_ge_atTop ((H₀ : ℝ) + 1))
  filter_upwards [he] with x hx
  dsimp only [Function.comp_apply] at hx
  have hH := (growingDepth_bounds x).1
  have hH0 : (0 : ℝ) ≤ H₀ := by positivity
  have hs : (H₀ : ℝ) ≤ (growingDepth x : ℝ) := by nlinarith [sq_nonneg (Real.log (Real.log x) - 1)]
  exact_mod_cast hs

/-- The exponential block-sieve loss tends to zero with this depth. -/
theorem growingDepth_error_eventually_le {C η : ℝ} (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop, C * Real.exp (-(growingDepth x : ℝ)) ≤ η := by
  have hnat : Tendsto growingDepth atTop atTop :=
    tendsto_atTop.2 (fun H => growingDepth_eventually_ge H)
  have hreal : Tendsto (fun x : ℝ => (growingDepth x : ℝ)) atTop atTop :=
    tendsto_natCast_atTop_atTop.comp hnat
  have hneg : Tendsto (fun x : ℝ => -(growingDepth x : ℝ)) atTop atBot :=
    tendsto_neg_atTop_atBot.comp hreal
  have hexp := Real.tendsto_exp_atBot.comp hneg
  have hlim : Tendsto (fun x : ℝ => C * Real.exp (-(growingDepth x : ℝ))) atTop (𝓝 0) := by
    simpa only [mul_zero, Function.comp_apply] using hexp.const_mul C
  exact (hlim.eventually (eventually_lt_nhds hη)).mono (fun _ h => h.le)

/-- Despite the growing sieve depth, its small-prime product range is below
any fixed positive power of `x`. -/
theorem growingDepth_modulus_small {δ : ℝ} (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop,
      (MarkedSource.W x) ^ (4 * growingDepth x + 2) ≤ x ^ δ := by
  have hlo := isLittleO_log_rpow_rpow_atTop ((2 : ℕ) : ℝ)
    (show (0 : ℝ) < 19 / 25 by norm_num)
  have he := Real.tendsto_log_atTop.eventually
    (hlo.def (show 0 < δ / 18 by positivity))
  have hLL := (Real.tendsto_log_atTop.comp Real.tendsto_log_atTop).eventually
    (eventually_ge_atTop (1 : ℝ))
  filter_upwards [he, hLL, eventually_gt_atTop (1 : ℝ)] with x he hLL hx
  dsimp only [Function.comp_apply] at hLL
  have hL : 0 < Real.log x := Real.log_pos hx
  have hbound : (Real.log (Real.log x)) ^ 2 ≤
      δ / 18 * (Real.log x) ^ (19 / 25 : ℝ) := by
    rw [← Real.rpow_natCast]
    simpa only [Real.norm_of_nonneg (Real.rpow_nonneg (by linarith : 0 ≤ Real.log (Real.log x)) _),
      Real.norm_of_nonneg (Real.rpow_nonneg hL.le _)] using he
  have hdepth : (4 * growingDepth x + 2 : ℕ) ≤
      18 * (Real.log (Real.log x)) ^ 2 := by
    have hupper := (growingDepth_bounds x).2
    push_cast
    nlinarith [sq_nonneg (Real.log (Real.log x) - 1)]
  have hexponent : ((4 * growingDepth x + 2 : ℕ) : ℝ) *
      (Real.log x) ^ (6 / 25 : ℝ) ≤ δ * Real.log x := by
    calc
      _ ≤ (18 * (Real.log (Real.log x)) ^ 2) * (Real.log x) ^ (6 / 25 : ℝ) :=
        mul_le_mul_of_nonneg_right hdepth (Real.rpow_nonneg hL.le _)
      _ ≤ (18 * (δ / 18 * (Real.log x) ^ (19 / 25 : ℝ))) *
          (Real.log x) ^ (6 / 25 : ℝ) :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hbound (by norm_num))
          (Real.rpow_nonneg hL.le _)
      _ = _ := by
        have heq : (Real.log x) ^ (19 / 25 : ℝ) * (Real.log x) ^ (6 / 25 : ℝ) =
            Real.log x := by rw [← Real.rpow_add hL]; norm_num
        calc
          _ = δ * ((Real.log x) ^ (19 / 25 : ℝ) * (Real.log x) ^ (6 / 25 : ℝ)) := by ring
          _ = _ := by rw [heq]
  unfold MarkedSource.W
  rw [← Real.exp_nat_mul, Real.rpow_def_of_pos (zero_lt_one.trans hx)]
  exact Real.exp_le_exp.mpr (by simpa only [mul_comm] using hexponent)

/-- Multiplying by every prime in a fixed Buchstab bin still leaves room
inside the half-level distribution range. The threshold is uniform in the
bin's two endpoints, its prime, and the squarefree small-prime subset. -/
theorem conditioned_modulus_range {κ : ℝ} (hκ : 0 < κ) :
    ∀ᶠ x : ℝ in atTop, ∀ γ' : ℝ, γ' ≤ 1 / 2 - κ →
      ∀ n ℓ : ℕ, (n : ℝ) ≤ x ^ γ' →
      (ℓ : ℝ) ≤ (MarkedSource.W x) ^ (4 * growingDepth x + 2) →
      ((n * ℓ : ℕ) : ℝ) ≤ x ^ (1 / 2 - κ / 2) := by
  filter_upwards [growingDepth_modulus_small (show 0 < κ / 2 by positivity),
    eventually_ge_atTop (1 : ℝ)] with x hx hx1
  intro γ' hγ n ℓ hn hℓ
  have hx0 : 0 < x := by linarith
  calc
    ((n * ℓ : ℕ) : ℝ) = (n : ℝ) * ℓ := by norm_cast
    _ ≤ x ^ γ' * x ^ (κ / 2) :=
      mul_le_mul hn (hℓ.trans hx) (Nat.cast_nonneg _) (Real.rpow_nonneg hx0.le _)
    _ = x ^ (γ' + κ / 2) := (Real.rpow_add hx0 _ _).symm
    _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate
  MarkedBandTail ManuscriptMass ManuscriptTail ManuscriptDistribution

/-- The exact conditioned mass on the retained enlarged cofactors. -/
noncomputable def retainedConditionedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (N S : Finset ℕ) : ℝ :=
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
    marking I a x r * ∑ n ∈ N,
      siftedMass (Qs.filter (fun Q => n ∣ c * r * Q + 1))
        (InitialSieve.arrayWeight c M u (smoothWeight x) r)
        (fun p Q => p ∣ c * r * Q + 1) S

/-- The conditioned source theorem with exact arithmetic arrays and the one
actual weighted BV error. The source constant precedes all marking data. -/
theorem source_retained_conditioned_upper (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧ ∃ H₀ : ℕ,
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (c M u W₀ : ℕ)
        (ε Y τ x z : ℝ) (N S moduli : Finset ℕ) (H : ℕ),
      (∀ i ∈ I, 0 < bandMass (a i) x) →
      2 ≤ z → Even H → H₀ ≤ H →
      (∀ n ∈ N, n.Prime ∧ W₀ < n) →
      (∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
        ∀ n ∈ N, ¬ n ∣ M * r) →
      (∀ p ∈ S, p.Prime ∧ 3 ≤ p ∧ p ≤ W₀ ∧ (p : ℝ) ≤ z ∧ ¬ p ∣ M) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ S.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / ((p : ℝ) - 1)) ≤ C₀) →
      (∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
        (∑ p ∈ S.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ 2 * τ) →
      (∀ n ∈ N, ∀ T ∈ remainderSubsets S (z ^ (4 * H + 2)),
        n * (∏ p ∈ T, p) ∈ moduli) →
      retainedConditionedMass I a c M u ε Y τ x N S ≤
        ((1 + C * Real.exp (-(H : ℝ))) * Real.exp (20 * τ) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          (∑ n ∈ N, 1 / ((n : ℝ) - 1))) * retainedMass I a c M u ε Y τ x +
        C * smallCofactorError I a c M u ε Y τ x moduli := by
  obtain ⟨C, hC, H₀, he⟩ := source_conditioned_upper source C₀
  refine ⟨C, hC, H₀, ?_⟩
  intro ι I a c M u W₀ ε Y τ x z N S moduli H hV hz hH hH₀ hN havoid hS hblock hτ hmoduli
  let R := boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε)
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  let X := primeProgressionSum c M u Qs (smoothWeight x)
  let A := (1 + C * Real.exp (-(H : ℝ))) * Real.exp (20 * τ) *
    (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
    (∑ n ∈ N, 1 / ((n : ℝ) - 1))
  let E := fun r => ∑ d ∈ moduli,
    |PrimeProgressions.sievedPrimeSum c M u d Qs (smoothWeight x) r -
      PrimeDistribution.sieveDensity M r d * X r|
  have hX : ∀ r, 0 ≤ X r :=
    fun r => FullMassComparison.primeProgressionSum_nonneg c M u Qs (smoothWeight x)
      (fun d => (smoothWeight_bounds x d).1) r
  have hhn : 0 ≤ ∑ n ∈ N, 1 / ((n : ℝ) - 1) := by
    apply Finset.sum_nonneg
    intro n hn
    have hn2 : (2 : ℝ) ≤ n := by exact_mod_cast (hN n hn).1.two_le
    apply div_nonneg (by norm_num)
    linarith
  have hpoint : ∀ r ∈ R,
      (∑ n ∈ N, siftedMass (Qs.filter (fun Q => n ∣ c * r * Q + 1))
        (InitialSieve.arrayWeight c M u (smoothWeight x) r)
        (fun p Q => p ∣ c * r * Q + 1) S) ≤ A * X r + C * E r := by
    intro r hr
    have hs := he Qs N S moduli (InitialSieve.arrayWeight c M u (smoothWeight x) r)
      (fun Q => c * r * Q + 1) M r W₀ (X r) z H hz hH hH₀ (hX r)
      (fun Q _ => by
        unfold InitialSieve.arrayWeight
        split_ifs
        · exact (smoothWeight_bounds x _).1
        · exact le_rfl)
      (fun n hn => ⟨(hN n hn).1, (hN n hn).2, havoid r hr n hn⟩)
      (fun p hp => ⟨(hS p hp).1, (hS p hp).2.1, (hS p hp).2.2.1, (hS p hp).2.2.2.1⟩)
      hblock hmoduli
    have hlocal := (cofactor_localProduct_bounds S M r (fun p hp => (hS p hp).2.1)
      (fun p hp => (hS p hp).1) (fun p hp => (hS p hp).2.2.2.2) (hτ r hr)).2
    have hlocal' : localProduct S (cofactorDensity M r) ≤
        Real.exp (20 * τ) * ∏ p ∈ S, LocalSieveProducts.sieveFactor p := by
      simpa only [show 10 * (2 * τ) = 20 * τ by ring] using hlocal
    have hmain := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hlocal'
        (show 0 ≤ (1 + C * Real.exp (-(H : ℝ))) * X r from
          mul_nonneg (by positivity) (hX r))) hhn
    have herr : (∑ d ∈ moduli,
        |divisorMass Qs (InitialSieve.arrayWeight c M u (smoothWeight x) r)
          (fun Q => c * r * Q + 1) d - productDensity M r d * X r|) = E r := by
      simp only [InitialSieve.divisorMass_eq_sievedPrimeSum, productDensity,
        PrimeDistribution.sieveDensity, E]
    rw [herr] at hs
    dsimp [A]
    nlinarith only [hs, hmain]
  have ht : ∀ r ∈ R, 0 ≤ marking I a x r :=
    fun r _ => (markingWeight_bounds I _ _ r hV).1
  have hsum := Finset.sum_le_sum
    (fun r hr => mul_le_mul_of_nonneg_left (hpoint r hr) (ht r hr))
  change retainedConditionedMass I a c M u ε Y τ x N S ≤ _ at hsum
  calc
    _ ≤ ∑ r ∈ R, marking I a x r * (A * X r + C * E r) := hsum
    _ = A * retainedMass I a c M u ε Y τ x + C * smallCofactorError I a c M u ε Y τ x moduli := by
      simp only [retainedMass, smallCofactorError, R, Qs, X, E]
      rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intros
      ring
    _ = _ := rfl

/-- The entire conditioned prime bin eventually lies beyond the fixed
progression times every retained cofactor. Thus no bin prime divides `Mr`. -/
theorem large_bin_avoids_cofactors (M : ℕ) (hM : 0 < M) {ε b : ℝ} (hεb : ε < b) :
    ∀ᶠ x : ℝ in atTop, ∀ r n : ℕ,
      0 < r → (r : ℝ) ≤ x ^ ε → x ^ b ≤ (n : ℝ) → ¬ n ∣ M * r := by
  have he := (tendsto_rpow_atTop (sub_pos.mpr hεb)).eventually
    (eventually_gt_atTop (M : ℝ))
  filter_upwards [he, eventually_gt_atTop (0 : ℝ)] with x hx hx0
  intro r n hr hrx hn hdiv
  have hmr : ((M * r : ℕ) : ℝ) < x ^ b := by
    calc
      ((M * r : ℕ) : ℝ) = (M : ℝ) * r := by norm_cast
      _ ≤ (M : ℝ) * x ^ ε := mul_le_mul_of_nonneg_left hrx (Nat.cast_nonneg _)
      _ < x ^ (b - ε) * x ^ ε := mul_lt_mul_of_pos_right hx (Real.rpow_pos_of_pos hx0 _)
      _ = x ^ b := by rw [← Real.rpow_add hx0]; congr 1; ring
  have hnle : n ≤ M * r := Nat.le_of_dvd (Nat.mul_pos hM hr) hdiv
  have hnleR : (n : ℝ) ≤ ((M * r : ℕ) : ℝ) := by exact_mod_cast hnle
  exact (not_lt_of_ge (hn.trans hnleR)) hmr

/-- Bin primes lie beyond the small roughness cutoff, uniformly throughout
all bins with a fixed positive lower endpoint. -/
theorem W_lt_bin_start {b : ℝ} (hb : 0 < b) :
    ∀ᶠ x : ℝ in atTop, MarkedSource.W x < x ^ b := by
  filter_upwards [growingDepth_modulus_small (show 0 < b / 2 by positivity),
    RoughCompanion.W_tendsto.eventually (eventually_ge_atTop (1 : ℝ)),
    eventually_gt_atTop (1 : ℝ)] with x hx hW hx1
  calc
    MarkedSource.W x ≤ (MarkedSource.W x) ^ (4 * growingDepth x + 2) :=
      le_self_pow₀ hW (by omega)
    _ ≤ x ^ (b / 2) := hx
    _ < x ^ b := Real.rpow_lt_rpow_of_exponent_lt hx1 (by linarith)

/-- The actual conditioned sieve, with its growing depth, omission bound,
and weighted BV error all discharged. Only the ordinary finite harmonic sum
and the explicit fixed-modulus Euler product remain to normalize. The error
constant is chosen before every marking family and every bin. -/
theorem actual_retained_conditioned_upper
    (source : SourceLemma11_1) (C₀ : ℝ) (hBlock : InitialSieve.PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100) (hA : 0 < A) :
    ∃ C : ℝ, 0 < C ∧ ∀ b η : ℝ, ε < b → 0 < η →
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ),
      (1/10 : ℝ) ≤ amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → ∀ᶠ x : ℝ in atTop,
      ∀ γ' : ℝ, γ' ≤ 1/2 - κ → ∀ N : Finset ℕ,
      (∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ') →
      let S := InitialSieve.sievePrimes (c * M₀) (MarkedSource.W x)
      retainedConditionedMass I a c (c * M₀) (c * v + 1) ε Y τ x N S ≤
        ((1 + η) * Real.exp (20 * τ) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          (∑ n ∈ N, 1 / ((n : ℝ) - 1))) *
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x +
        C * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A := by
  obtain ⟨Cs, hCs, H₀, hs⟩ := source_retained_conditioned_upper source C₀
  obtain ⟨Cd, hCd, hd⟩ := actual_distribution_relative_to_baseMass
    hBV hPNT hTot hc hu hv huM hε hεκ hκ hA
  refine ⟨Cs * Cd, mul_pos hCs hCd, ?_⟩
  intro b η hεb hη ι I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical Y hY τ hτ
  have hcpos : 0 < c := by omega
  have hMpos : 0 < c * M₀ := Nat.mul_pos hcpos (NeZero.pos M₀)
  have hminpos : 0 < amin := by linarith
  have hκpos : 0 < κ := hε.trans hεκ
  have hb : 0 < b := hε.trans hεb
  have hεmax : ε ≤ 1/100 := (hεκ.trans hκ).le
  have ha' : ∀ i ∈ I, (1/10 : ℝ) ≤ a i := fun i hi => hmin.trans (ha i hi).1
  filter_upwards [hd I a amin amax B v₀ hminpos hmax hv₀ ha hinj hclassical Y hY τ,
    MarkedOmission.eventual_reciprocal_cap I a ε hε.le ha' τ hτ,
    eventually_baseMass_partition I a amin amax hminpos hmax ha c (c * M₀)
      (c * v + 1) hcpos ε Y τ hεmax,
    growingDepth_eventually_ge H₀, growingDepth_error_eventually_le (C := Cs) hη,
    conditioned_modulus_range hκpos, large_bin_avoids_cofactors (c * M₀) hMpos hεb,
    W_lt_bin_start hb, RoughCompanion.W_tendsto.eventually (eventually_ge_atTop (2 : ℝ)),
    hclassical, eventually_ge_atTop (2 : ℝ)]
      with x hdist homit hpartition hdepth hdeptherror hmodrange havoid hWbin hW hVx hx
  intro γ' hγ' N hN
  let S := InitialSieve.sievePrimes (c * M₀) (MarkedSource.W x)
  let moduli := Finset.Icc 1 ⌊x ^ (1/2 - κ/2)⌋₊
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hS : ∀ p ∈ S, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ MarkedSource.W x ∧ ¬ p ∣ c * M₀ :=
    fun p hp => InitialSieve.sievePrimes_properties (c * M₀) (by linarith) hp
  have hmod : ∀ ℓ ∈ moduli, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1/2 - κ/2) := by
    intro ℓ hℓ
    have hh := Finset.mem_Icc.mp hℓ
    exact ⟨hh.1, (by exact_mod_cast hh.2 : (ℓ : ℝ) ≤ (⌊x ^ (1/2 - κ/2)⌋₊ : ℝ)).trans
      (Nat.floor_le (Real.rpow_nonneg hx0.le _))⟩
  have hone : 1 ∈ moduli := by
    apply Finset.mem_Icc.mpr
    refine ⟨le_rfl, Nat.le_floor ?_⟩
    simpa only [Nat.cast_one] using
      (Real.one_le_rpow hx1 (show (0 : ℝ) ≤ 1/2 - κ/2 by linarith))
  have herr := hdist moduli hmod hone
  have hrec : ∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
      (∑ p ∈ S.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ 2 * τ := by
    intro r hr
    have hrpos := ((mem_boundedCofactors _ _ _ r).mp hr).1
    apply (MarkedOmission.reciprocal_prime_divisors_le _ hrpos ?_).trans (homit ε Y r hr)
    intro p hp
    have hh := Finset.mem_filter.mp hp
    exact ⟨(hS p hh.1).1, hh.2⟩
  have hNsmall : ∀ n ∈ N, n.Prime ∧ ⌊MarkedSource.W x⌋₊ < n := by
    intro n hn
    refine ⟨(hN n hn).1, ?_⟩
    have hlt : ((⌊MarkedSource.W x⌋₊ : ℕ) : ℝ) < (n : ℝ) :=
      (Nat.floor_le (by linarith : 0 ≤ MarkedSource.W x)).trans_lt
        (hWbin.trans_le (hN n hn).2.1)
    exact_mod_cast hlt
  have hNavoid : ∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
      ∀ n ∈ N, ¬ n ∣ c * M₀ * r := by
    intro r hr n hn
    have hrr := (mem_boundedCofactors _ _ _ r).mp hr
    exact havoid r n hrr.1 hrr.2.2 (hN n hn).2.1
  have hmoduli : ∀ n ∈ N, ∀ T ∈ remainderSubsets S
      ((MarkedSource.W x) ^ (4 * growingDepth x + 2)), (n * ∏ p ∈ T, p) ∈ moduli := by
    intro n hn T hT
    have hsub : T ⊆ S := Finset.mem_powerset.mp (Finset.mem_filter.mp hT).1
    have hp : 0 < ∏ p ∈ T, p := Finset.prod_pos (fun p hp => (hS p (hsub hp)).1.pos)
    apply Finset.mem_Icc.mpr
    refine ⟨Nat.mul_pos (hN n hn).1.pos hp, Nat.le_floor ?_⟩
    exact hmodrange γ' hγ' n (∏ p ∈ T, p) (hN n hn).2.2 (Finset.mem_filter.mp hT).2
  have hsieve := hs I a c (c * M₀) (c * v + 1) ⌊MarkedSource.W x⌋₊ ε Y τ x
    (MarkedSource.W x) N S moduli (growingDepth x) hV hW (growingDepth_even x) hdepth
    hNsmall hNavoid
    (fun p hp => ⟨(hS p hp).1, (hS p hp).2.1, Nat.le_floor (hS p hp).2.2.1,
      (hS p hp).2.2.1, (hS p hp).2.2.2⟩)
    (hBlock S (fun p hp => ⟨(hS p hp).1, (hS p hp).2.1⟩)) hrec hmoduli
  have htail0 := discardedMass_nonneg I a c (c * M₀) (c * v + 1) ε Y τ x hV
  have hret : retainedMass I a c (c * M₀) (c * v + 1) ε Y τ x ≤
      baseMass I a c (c * M₀) (c * v + 1) ε Y τ x := by linarith
  have hret0 : 0 ≤ retainedMass I a c (c * M₀) (c * v + 1) ε Y τ x := by
    apply Finset.sum_nonneg
    intro r hr
    exact mul_nonneg (markingWeight_bounds I _ _ r hV).1
      (FullMassComparison.primeProgressionSum_nonneg _ _ _ _ _
        (fun d => (smoothWeight_bounds x d).1) r)
  have hprod0 : 0 ≤ ∏ p ∈ S, LocalSieveProducts.sieveFactor p :=
    Finset.prod_nonneg (fun p hp => (LocalSieveProducts.sieveFactor_pos (hS p hp).2.1).le)
  have hsum0 : 0 ≤ ∑ n ∈ N, 1 / ((n : ℝ) - 1) := by
    apply Finset.sum_nonneg
    intro n hn
    have hh : (2 : ℝ) ≤ n := by exact_mod_cast (hN n hn).1.two_le
    apply div_nonneg (by norm_num)
    linarith
  have hcoef : ((1 + Cs * Real.exp (-(growingDepth x : ℝ))) * Real.exp (20 * τ) *
      (∏ p ∈ S, LocalSieveProducts.sieveFactor p) * (∑ n ∈ N, 1 / ((n : ℝ) - 1))) ≤
      ((1 + η) * Real.exp (20 * τ) * (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
        (∑ n ∈ N, 1 / ((n : ℝ) - 1))) := by
    gcongr
  have hmain := mul_le_mul hcoef hret hret0 (by positivity)
  have herror := mul_le_mul_of_nonneg_left herr hCs.le
  calc
    _ ≤ _ := hsieve
    _ ≤ _ := add_le_add hmain herror
    _ = _ := by ring

end Artin.ConditionedSieve
