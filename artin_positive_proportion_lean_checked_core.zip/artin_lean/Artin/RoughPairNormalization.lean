module

public import Artin.RoughPairSieve
public import Artin.RoughCompanion
public import Artin.MarkedOmission
public import Artin.ManuscriptMass

/-!
# Classical normalization of the actual rough-pair sieve

The depth-two sieve uses the actual odd primes up to `x^0.001`. Its Euler
products are exactly twice the usual prime Euler products. All estimates
below are stated at these concrete cutoffs and retain constants independent
of the marking intervals.
-/

@[expose] public section
open scoped BigOperators
open Filter

namespace Artin.RoughPairNormalization

open MarkedSource RoughPairSieve BuchstabSieve

/-- The fixed small power used for the pair sieve. -/
noncomputable def sieveScale (x : ℝ) : ℝ := x ^ (1 / 1000 : ℝ)

/-- The actual odd primes in the two-variable sieve. -/
noncomputable def oddPrimes (y : ℝ) : Finset ℕ := (Nat.primesLE ⌊y⌋₊).erase 2

theorem mem_oddPrimes {y : ℝ} {p : ℕ} (hy : 0 ≤ y) :
    p ∈ oddPrimes y ↔ p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ y := by
  simp only [oddPrimes, Finset.mem_erase, Nat.mem_primesLE, Nat.le_floor_iff hy]
  constructor
  · rintro ⟨h2, hp, hprime⟩
    exact ⟨hprime, by have := hprime.two_le; omega, hp⟩
  · rintro ⟨hp, h3, hy⟩
    exact ⟨by omega, hy, hp⟩

/-- Removing the factor at two accounts for the exact factor `2`. -/
theorem odd_euler_product {y : ℝ} (hy : 2 ≤ y) :
    (∏ p ∈ oddPrimes y, (1 - 1 / (p : ℝ))) = 2 * eulerV y := by
  have htwo : 2 ∈ Nat.primesLE ⌊y⌋₊ :=
    Nat.mem_primesLE.mpr ⟨Nat.le_floor hy, Nat.prime_two⟩
  have hp := Finset.mul_prod_erase (s := Nat.primesLE ⌊y⌋₊)
    (f := fun p : ℕ => (1 : ℝ) - 1 / (p : ℝ)) htwo
  norm_num at hp
  change (1 / 2 : ℝ) * (∏ p ∈ (Nat.primesLE ⌊y⌋₊).erase 2,
    (1 - (p : ℝ)⁻¹)) = eulerV y at hp
  simp only [oddPrimes, one_div]
  linarith

/-- The roughness cutoff is a genuine Boolean divisibility condition. -/
noncomputable def roughCutoff (y : ℝ) (p : ℕ) : Bool := decide ((p : ℝ) ≤ y)

theorem odd_filter_rough {y z : ℝ} (hy : 0 ≤ y) (hyz : y ≤ z) :
    (oddPrimes z).filter (fun p => roughCutoff y p = true) = oddPrimes y := by
  ext p
  simp only [Finset.mem_filter, mem_oddPrimes (hy.trans hyz), mem_oddPrimes hy,
    roughCutoff, decide_eq_true_eq]
  constructor
  · rintro ⟨⟨hp, h3, _⟩, hpy⟩
    exact ⟨hp, h3, hpy⟩
  · rintro ⟨hp, h3, hpy⟩
    exact ⟨⟨hp, h3, hpy.trans hyz⟩, hpy⟩

theorem odd_rough_euler_product {y z : ℝ} (hy : 2 ≤ y) (hyz : y ≤ z) :
    (∏ p ∈ (oddPrimes z).filter (fun p => roughCutoff y p = true),
      (1 - 1 / (p : ℝ))) = 2 * eulerV y := by
  rw [odd_filter_rough (by linarith) hyz, odd_euler_product hy]

/-- The upper half of the classical Mertens Euler-product estimate. -/
def ClassicalMertensUpper : Prop :=
  ∃ G : ℝ, 0 < G ∧ ∀ᶠ y : ℝ in atTop, eulerV y ≤ G / Real.log y

/-- A standard reciprocal-prime block estimate, without sieve weights. -/
def ClassicalPrimeBlockBound : Prop :=
  ∃ C₀ : ℝ, 0 < C₀ ∧ ∀ v : ℝ, 1 < v →
    (∑ p ∈ (Nat.primesLE ⌊v ^ 2⌋₊).filter (fun p : ℕ => v < (p : ℝ)),
      1 / (p : ℝ)) ≤ C₀

/-- A classical divisor-square moment estimate with the actual divisor count. -/
def ClassicalDivisorSquareMoment : Prop :=
  ∃ D : ℝ, 0 < D ∧ ∀ᶠ y : ℝ in atTop,
    (∑ ℓ ∈ Finset.Icc 1 ⌊y⌋₊, (ℓ.divisors.card : ℝ) ^ 2) ≤
      D * y * (Real.log y) ^ (3 : ℕ)

theorem sieveScale_tendsto : Tendsto sieveScale atTop atTop :=
  tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 1 / 1000)

/-- The roughness cutoff is eventually below the fixed-power sieve cutoff. -/
theorem eventual_cutoff_order :
    ∀ᶠ x : ℝ in atTop, 2 ≤ W x ∧ W x ≤ sieveScale x ∧ 2 ≤ sieveScale x := by
  have hpower := MarkedCriterion.rough_cutoff_le_power
    (κ := 6 / 25) (γ := 1 / 1000) (by norm_num) (by norm_num)
  filter_upwards [RoughCompanion.W_tendsto.eventually (eventually_ge_atTop (2 : ℝ)), hpower]
    with x hW hpow
  exact ⟨hW, hpow, hW.trans hpow⟩

/-- At the concrete power cutoff, the Euler-product upper constant is fixed
before every marking parameter. -/
theorem eventual_odd_euler_upper (hM : ClassicalMertensUpper) :
    ∃ E : ℝ, 0 < E ∧ ∀ᶠ x : ℝ in atTop,
      (∏ p ∈ oddPrimes (sieveScale x), (1 - 1 / (p : ℝ))) ≤ E / Real.log x := by
  obtain ⟨G, hG, he⟩ := hM
  refine ⟨2000 * G, by positivity, ?_⟩
  filter_upwards [sieveScale_tendsto.eventually he, eventual_cutoff_order,
    eventually_gt_atTop (1 : ℝ)] with x he hx hx1
  rw [odd_euler_product hx.2.2]
  have hlog : Real.log (sieveScale x) = (1 / 1000 : ℝ) * Real.log x :=
    Real.log_rpow (zero_lt_one.trans hx1) _
  calc
    _ ≤ 2 * (G / Real.log (sieveScale x)) := mul_le_mul_of_nonneg_left he (by norm_num)
    _ = _ := by rw [hlog]; ring

/-- The actual finite prime set inherits the classical block estimate. -/
theorem odd_prime_block_bound {C₀ : ℝ}
    (hblock : ∀ v : ℝ, 1 < v →
      (∑ p ∈ (Nat.primesLE ⌊v ^ 2⌋₊).filter (fun p : ℕ => v < (p : ℝ)),
        1 / (p : ℝ)) ≤ C₀)
    (z : ℝ) (v : ℝ) (hv : 1 < v) :
    (∑ p ∈ (oddPrimes z).filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
      1 / (p : ℝ)) ≤ C₀ := by
  apply le_trans _ (hblock v hv)
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro p hp
    have hodd := (Finset.mem_erase.mp (Finset.mem_filter.mp hp).1).2
    have hprime := (Nat.mem_primesLE.mp hodd).2
    have hwindow := (Finset.mem_filter.mp hp).2
    exact Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor hwindow.2, hprime⟩, hwindow.1⟩
  · intros
    positivity

/-- A convenient concrete modulus range containing all depth-two products. -/
noncomputable def sieveModuli (x : ℝ) : Finset ℕ := Finset.Icc 1 ⌊x ^ (2 / 100 : ℝ)⌋₊

theorem remainder_product_mem_moduli {x : ℝ} (hx : 1 ≤ x)
    (T : Finset ℕ) {S : Finset ℕ}
    (hS : S ∈ remainderSubsets (oddPrimes (sieveScale x) \ T)
      ((sieveScale x) ^ (10 : ℕ))) :
    (∏ p ∈ S, p) ∈ sieveModuli x := by
  have hx0 : 0 < x := zero_lt_one.trans_le hx
  have hsub := Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1
  have hprime : ∀ p ∈ S, p.Prime := by
    intro p hp
    have hm := (Finset.mem_sdiff.mp (hsub hp)).1
    exact ((mem_oddPrimes (Real.rpow_nonneg hx0.le _)).mp hm).1
  have hpos : 0 < ∏ p ∈ S, p := Finset.prod_pos (fun p hp => (hprime p hp).pos)
  have hbound := (Finset.mem_filter.mp hS).2
  have hpower : (sieveScale x) ^ (10 : ℕ) ≤ x ^ (2 / 100 : ℝ) := by
    rw [sieveScale, ← Real.rpow_natCast, ← Real.rpow_mul hx0.le]
    apply Real.rpow_le_rpow_of_exponent_le hx
    norm_num
  exact Finset.mem_Icc.mpr ⟨hpos, Nat.le_floor (hbound.trans hpower)⟩

/-- The classical divisor moment is transferred to the exact modulus set
used by the pair sieve. -/
theorem eventual_moduli_moment (hD : ClassicalDivisorSquareMoment) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ x : ℝ in atTop,
      (∑ ℓ ∈ sieveModuli x, (ℓ.divisors.card : ℝ) ^ 2) ≤
        D * x ^ (2 / 100 : ℝ) * (Real.log x) ^ (3 : ℕ) := by
  obtain ⟨D, hD, he⟩ := hD
  refine ⟨D, hD, ?_⟩
  filter_upwards [(tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 2 / 100)).eventually he,
    eventually_gt_atTop (1 : ℝ)] with x he hx
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hL : 0 < Real.log x := Real.log_pos hx
  apply he.trans
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  have hlog0 : 0 ≤ Real.log (x ^ (2 / 100 : ℝ)) := by
    rw [Real.log_rpow hx0]
    positivity
  apply pow_le_pow_left₀ hlog0
  rw [Real.log_rpow hx0]
  nlinarith

/-- The exact odd prime divisors omitted for an enlarged cofactor. -/
noncomputable def omittedPrimes (z : ℝ) (r : ℕ) : Finset ℕ :=
  oddPrimes z ∩ r.primeFactors

/-- Outside the omitted prime divisors, the progression modulus is a unit
at every sieving prime. The only prime factor of the allowed `c` is two. -/
theorem coprime_outside_omitted {c r p : ℕ} {z : ℝ} (hc : c = 2 ∨ c = 4)
    (hr : 0 < r) (hz : 0 ≤ z)
    (hp : p ∈ oddPrimes z \ omittedPrimes z r) : (c * r).Coprime p := by
  have hpodd := ((mem_oddPrimes hz).mp (Finset.mem_sdiff.mp hp).1)
  have hprime := hpodd.1
  have hpn : ¬ p ∈ r.primeFactors := by
    intro hn
    exact (Finset.mem_sdiff.mp hp).2
      (Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp hp).1, hn⟩)
  have hpr : ¬ p ∣ r := by
    intro hd
    exact hpn (Nat.mem_primeFactors.mpr ⟨hprime, hd, hr.ne'⟩)
  have hp2 : ¬ p ∣ 2 := Nat.not_dvd_of_pos_of_lt (by norm_num) (by omega)
  have hcop2 : p.Coprime 2 := hprime.coprime_iff_not_dvd.mpr hp2
  have hcopc : p.Coprime c := by
    rcases hc with rfl | rfl
    · exact hcop2
    · simpa using hcop2.pow_right 2
  exact (hcopc.mul_right (hprime.coprime_iff_not_dvd.mpr hpr)).symm

/-- The local-product constant is fixed before the number and locations of
the marked bands. The defining cap `τ≤1` suffices for one absolute omission
factor; no bound for the marking weight is introduced. -/
theorem actual_localProduct_bound (hM : ClassicalMertensUpper) :
    ∃ C : ℝ, 0 < C ∧ ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ),
      (∀ i ∈ I, (1 / 10 : ℝ) ≤ a i) → ∀ τ : ℝ, 0 < τ → τ ≤ 1 →
      ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
        MarkedCofactorEstimate.boundedCofactors (MarkedCofactorEstimate.markedPrimes I a x)
          (MarkedCofactorEstimate.unmarkedCofactors I a ε Y τ x) (x ^ (11 / 100 : ℝ)),
        localProduct (oddPrimes (sieveScale x) \ omittedPrimes (sieveScale x) r)
          (pairDensity (roughCutoff (W x))) ≤
            C / Real.log x * (eulerV (W x)) ^ 2 := by
  obtain ⟨E, hE, he⟩ := eventual_odd_euler_upper hM
  refine ⟨4 * Real.exp 28 * E, by positivity, ?_⟩
  intro ι I a ha τ hτ hτmax
  filter_upwards [he, eventual_cutoff_order,
    MarkedOmission.eventual_reciprocal_cap I a (11 / 100) (by norm_num) ha τ hτ,
    eventually_gt_atTop (1 : ℝ)] with x he hscale hrec hx
  intro ε Y r hr
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hcap : (∑ p ∈ omittedPrimes (sieveScale x) r, 1 / (p : ℝ)) ≤ 2 := by
    have hs : (∑ p ∈ omittedPrimes (sieveScale x) r, 1 / (p : ℝ)) ≤
        ∑ p ∈ r.primeFactors, 1 / (p : ℝ) :=
      Finset.sum_le_sum_of_subset_of_nonneg Finset.inter_subset_right (fun _ _ _ => by positivity)
    exact hs.trans ((hrec ε Y r hr).trans (by linarith))
  have hprod := normalized_localProduct_le (oddPrimes (sieveScale x))
    (omittedPrimes (sieveScale x) r) Finset.inter_subset_left (roughCutoff (W x))
    (fun p hp => ((mem_oddPrimes (by linarith : 0 ≤ sieveScale x)).mp hp).2.1)
    (show 0 ≤ E / Real.log x by positivity)
    (show 0 ≤ 2 * eulerV (W x) by positivity [RoughCompanion.eulerV_pos (W x)])
    hcap he (le_of_eq (odd_rough_euler_product hscale.1 hscale.2.1))
  convert hprod using 1 <;> norm_num <;> ring

/-- The lower Mertens bound is strong enough that `V(W) log x` tends beyond
one. This is the comparison needed to absorb the lattice remainder. -/
theorem eventual_euler_log_ge_one (hM : RoughCompanion.ClassicalMertensLower) :
    ∀ᶠ x : ℝ in atTop, 1 ≤ eulerV (W x) * Real.log x := by
  obtain ⟨c, hc, hM⟩ := hM
  have hlim := (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 19 / 25)).comp
    Real.tendsto_log_atTop
  have he : ∀ᶠ x : ℝ in atTop, (Real.log x) ^ (-(19 / 25 : ℝ)) < c :=
    (tendsto_order.1 hlim).2 _ hc
  filter_upwards [RoughCompanion.W_tendsto.eventually hM, he,
    eventually_gt_atTop (1 : ℝ)] with x hMx he hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hp : 0 < (Real.log x) ^ (6 / 25 : ℝ) := Real.rpow_pos_of_pos hL _
  have hratio : (Real.log x) ^ (6 / 25 : ℝ) / Real.log x < c := by
    calc
      _ = (Real.log x) ^ ((6 / 25 : ℝ) - 1) := by
        rw [Real.rpow_sub hL, Real.rpow_one]
      _ < c := by norm_num at he ⊢; exact he
  have hpow : (Real.log x) ^ (6 / 25 : ℝ) ≤ c * Real.log x :=
    ((div_lt_iff₀ hL).mp hratio).le
  have hprod : 1 ≤ c / (Real.log x) ^ (6 / 25 : ℝ) * Real.log x := by
    rw [div_mul_eq_mul_div, le_div_iff₀ hp, one_mul]
    exact hpow
  have hMx' : c / (Real.log x) ^ (6 / 25 : ℝ) ≤ eulerV (W x) := by
    simpa only [W, Real.log_exp] using hMx
  exact hprod.trans (mul_le_mul_of_nonneg_right hMx' hL.le)

/-- The explicit lattice remainder is smaller than the normalized rough
main scale. Constants and onsets do not involve the marking intervals. -/
theorem eventual_error_normalization (hM : RoughCompanion.ClassicalMertensLower) :
    ∀ᶠ x : ℝ in atTop,
      x / (Real.log x) ^ (10 : ℕ) ≤ x / Real.log x * (eulerV (W x)) ^ 2 := by
  filter_upwards [eventual_euler_log_ge_one hM,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ)),
    eventually_gt_atTop (1 : ℝ)] with x hV hL hx
  have hLpos : 0 < Real.log x := Real.log_pos hx
  have hsq : 1 ≤ (eulerV (W x)) ^ 2 * (Real.log x) ^ 2 := by
    nlinarith [sq_nonneg (eulerV (W x) * Real.log x - 1)]
  have hinv : 1 / (Real.log x) ^ (2 : ℕ) ≤ (eulerV (W x)) ^ 2 :=
    (div_le_iff₀ (sq_pos_of_pos hLpos)).mpr (by simpa only [one_mul] using hsq)
  calc
    _ ≤ x / (Real.log x) ^ (3 : ℕ) := div_le_div_of_nonneg_left
      (zero_lt_one.trans hx).le (pow_pos hLpos 3) (pow_le_pow_right₀ hL (by norm_num : 3 ≤ 10))
    _ = (x / Real.log x) * (1 / (Real.log x) ^ (2 : ℕ)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hinv (by positivity)

end Artin.RoughPairNormalization
