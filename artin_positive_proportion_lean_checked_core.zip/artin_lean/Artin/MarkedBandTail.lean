module

public import Artin.EnlargedCofactorMass

/-!
# Rankin tails at the actual marked-band scale

The only analytic input is the classical reciprocal-prime estimate in each
band. The local geometric ratios, their uniform sum, the exponential moment,
and the stretched-exponential tail are proved from the band endpoints.
All constants precede the tail exponent and all finite integer cutoffs.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.MarkedBandTail

/-- The manuscript's closed prime band. -/
noncomputable def primeBand (a x : ℝ) : Finset ℕ :=
  (Finset.range (⌊Real.exp (2 * (Real.log x) ^ a)⌋₊ + 1)).filter
    (fun p => p.Prime ∧ Real.exp ((Real.log x) ^ a) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ a))

noncomputable def bandMass (a x : ℝ) : ℝ := ∑ p ∈ primeBand a x, 1 / (p : ℝ)

theorem primeBand_properties (a x : ℝ) {p : ℕ} (hp : p ∈ primeBand a x) :
    p.Prime ∧ Real.exp ((Real.log x) ^ a) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ a) :=
  (Finset.mem_filter.mp hp).2

/-- The floor cutoff loses no primes: membership is exactly the displayed
closed real interval together with primality. -/
theorem mem_primeBand (a x : ℝ) (p : ℕ) :
    p ∈ primeBand a x ↔ p.Prime ∧ Real.exp ((Real.log x) ^ a) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ a) := by
  constructor
  · exact primeBand_properties a x
  · intro hp
    exact Finset.mem_filter.mpr
      ⟨Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_floor hp.2.2)), hp⟩

/-- The upper endpoint proves `p^v ≤ exp 2`; it is not a moment hypothesis. -/
theorem band_exp_le {L a p : ℝ} (hL : 0 < L) (hp : 0 < p)
    (hupper : p ≤ Real.exp (2 * L ^ a)) :
    Real.exp (L ^ (-a) * Real.log p) ≤ Real.exp 2 := by
  have hlog : Real.log p ≤ 2 * L ^ a := (Real.log_le_iff_le_exp hp).mpr hupper
  have hpow : 0 < L ^ a := Real.rpow_pos_of_pos hL _
  apply Real.exp_le_exp.mpr
  rw [Real.rpow_neg hL.le]
  calc
    (L ^ a)⁻¹ * Real.log p ≤ (L ^ a)⁻¹ * (2 * L ^ a) :=
      mul_le_mul_of_nonneg_left hlog (inv_nonneg.mpr hpow.le)
    _ = 2 := by field_simp

/-- The same local ratio in the customary real-power notation. -/
theorem ratio_eq_rpow {p v : ℝ} (hp : 0 < p) :
    Real.exp (v * Real.log p) / p = p ^ (v - 1) := by
  rw [Real.rpow_sub_one hp.ne', Real.rpow_def_of_pos hp]
  rw [mul_comm v]

/-- Uniform local bounds follow solely from the lower and upper band scales.
The threshold is independent of the Rankin cutoff. -/
theorem eventual_local_ratios (P : ℝ → Finset ℕ) (amin amax B : ℝ)
    (hmin : 0 < amin)
    (hends : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax))
    (hmass : ∀ᶠ x : ℝ in atTop, (∑ p ∈ P x, 1 / (p : ℝ)) ≤ B) :
    ∀ᶠ x : ℝ in atTop,
      (0 < Real.log x) ∧
      (∀ p ∈ P x,
        Real.exp ((Real.log x) ^ (-amax) * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2) ∧
      (∑ p ∈ P x,
        Real.exp ((Real.log x) ^ (-amax) * Real.log (p : ℝ)) / (p : ℝ)) ≤
        Real.exp 2 * B := by
  have hgrowth : Tendsto (fun x : ℝ => Real.exp ((Real.log x) ^ amin)) atTop atTop :=
    Real.tendsto_exp_atTop.comp ((tendsto_rpow_atTop hmin).comp Real.tendsto_log_atTop)
  filter_upwards [hends, hmass, eventually_gt_atTop (1 : ℝ),
    hgrowth.eventually (eventually_ge_atTop (2 * Real.exp 2))] with x he hm hx hg
  have hL : 0 < Real.log x := Real.log_pos hx
  have hp : ∀ p ∈ P x, (0 : ℝ) < p := fun p hp =>
    (Real.exp_pos _).trans_le (he p hp).1
  have hloc : ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ (-amax) * Real.log (p : ℝ)) / (p : ℝ) ≤
        Real.exp 2 / (p : ℝ) := fun p hpm =>
    div_le_div_of_nonneg_right (band_exp_le hL (hp p hpm) (he p hpm).2) (hp p hpm).le
  refine ⟨hL, ?_, ?_⟩
  · intro p hpm
    refine (hloc p hpm).trans ((div_le_iff₀ (hp p hpm)).mpr ?_)
    have hh := hg.trans (he p hpm).1
    linarith
  · calc
      _ ≤ ∑ p ∈ P x, Real.exp 2 / (p : ℝ) := Finset.sum_le_sum hloc
      _ = Real.exp 2 * (∑ p ∈ P x, 1 / (p : ℝ)) := by
        rw [Finset.mul_sum]
        simp only [mul_one_div]
      _ ≤ Real.exp 2 * B := mul_le_mul_of_nonneg_left hm (Real.exp_pos _).le

/-- Normalization is uniformly bounded once every band mass is bounded below. -/
theorem normalization_le {ι : Type*} (I : Finset ι) (V : ι → ℝ)
    (v₀ : ℝ) (hv₀ : 0 < v₀) (hV : ∀ i ∈ I, v₀ ≤ V i) :
    (∏ i ∈ I, 1 / V i) ≤ (1 / v₀) ^ I.card := by
  calc
    _ ≤ ∏ _i ∈ I, 1 / v₀ := by
      apply Finset.prod_le_prod₀
      · intro i hi
        exact (one_div_pos.mpr (hv₀.trans_le (hV i hi))).le
      · intro i hi
        exact one_div_le_one_div_of_le hv₀ (hV i hi)
    _ = _ := by simp

/-- The cancellation in the Rankin exponent gives exactly `t L^(1-amax)`. -/
theorem rankin_exponent {L : ℝ} (hL : 0 < L) (a t : ℝ) :
    L ^ (-a) * (t * L) = t * L ^ (1 - a) := by
  rw [Real.rpow_neg hL.le, Real.rpow_sub hL, Real.rpow_one]
  ring

/-- Uniform moment and size-tail bounds for the actual marking weight.
The constant and even the common threshold are chosen before `t`. -/
theorem uniform_finite_moment_and_tail {ι : Type*} (I : Finset ι)
    (groups : ℝ → ι → Finset ℕ) (V : ℝ → ι → ℝ) (P : ℝ → Finset ℕ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ V x i)
    (hP : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x, p.Prime)
    (hends : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax))
    (hmass : ∀ᶠ x : ℝ in atTop, (∑ p ∈ P x, 1 / (p : ℝ)) ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ S : Finset ℕ, (∀ n ∈ S, 0 < n) → (∀ n ∈ S, n.primeFactors ⊆ P x) →
        ((∑ n ∈ S, ConcreteSelector.markingWeight I (groups x) (V x) n / (n : ℝ) *
          Real.exp ((Real.log x) ^ (-amax) * Real.log (n : ℝ))) ≤ C) ∧
        (∀ t : ℝ, (∑ n ∈ S.filter (fun n : ℕ => Real.exp (t * Real.log x) < (n : ℝ)),
          ConcreteSelector.markingWeight I (groups x) (V x) n / (n : ℝ)) ≤
          C * Real.exp (-t * (Real.log x) ^ (1 - amax))) := by
  let C := (1 / v₀) ^ I.card * Real.exp (2 * (Real.exp 2 * B))
  refine ⟨C, by dsimp [C]; positivity, ?_⟩
  filter_upwards [hV, hP, eventual_local_ratios P amin amax B hmin hends hmass]
    with x hVx hPx hx
  intro S hpos hsupp
  have hVpos : ∀ i ∈ I, 0 < V x i := fun i hi => hv₀.trans_le (hVx i hi)
  have hnorm := normalization_le I (V x) v₀ hv₀ hVx
  constructor
  · exact (MarkedPowerMass.finite_marking_weight_power_moment I (groups x) (V x)
      S (P x) (Real.exp 2 * B) ((Real.log x) ^ (-amax)) hVpos hPx hpos hsupp
      hx.2.1 hx.2.2).trans (mul_le_mul_of_nonneg_right hnorm (Real.exp_pos _).le)
  · intro t
    have ht := MarkedPowerMass.finite_marking_weight_size_tail I (groups x) (V x)
      S (P x) (Real.exp 2 * B) (t * Real.log x) ((Real.log x) ^ (-amax)) hVpos hPx
      hpos hsupp (Real.rpow_nonneg hx.1.le _) hx.2.1 hx.2.2
    rw [rankin_exponent hx.1] at ht
    refine ht.trans ?_
    calc
      _ ≤ (1 / v₀) ^ I.card * Real.exp (2 * (Real.exp 2 * B) -
          t * (Real.log x) ^ (1 - amax)) :=
        mul_le_mul_of_nonneg_right hnorm (Real.exp_pos _).le
      _ = C * Real.exp (-t * (Real.log x) ^ (1 - amax)) := by
        dsimp [C]
        rw [sub_eq_add_neg, Real.exp_add]
        simp only [neg_mul]
        ring

/-- The same scale estimate for the complete infinite marked series, with
all prime powers retained. The bound is uniform in the tail exponent. -/
theorem uniform_infinite_moment_and_tail {ι : Type*} (I : Finset ι)
    (groups : ℝ → ι → Finset ℕ) (V : ℝ → ι → ℝ) (P : ℝ → Finset ℕ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ V x i)
    (hP : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x, p.Prime)
    (hends : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax))
    (hmass : ∀ᶠ x : ℝ in atTop, (∑ p ∈ P x, 1 / (p : ℝ)) ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ((∑' n, MarkedInfiniteMass.supportedReciprocal (P x)
        (ConcreteSelector.markingWeight I (groups x) (V x)) n *
        Real.exp ((Real.log x) ^ (-amax) * Real.log (n : ℝ))) ≤ C) ∧
      (∀ t : ℝ, MarkedInfiniteMass.supportedSizeTail (P x)
        (ConcreteSelector.markingWeight I (groups x) (V x)) (x ^ t) ≤
        C * Real.exp (-t * (Real.log x) ^ (1 - amax))) := by
  let C := (1 / v₀) ^ I.card * Real.exp (2 * (Real.exp 2 * B))
  refine ⟨C, by dsimp [C]; positivity, ?_⟩
  filter_upwards [hV, hP, eventual_local_ratios P amin amax B hmin hends hmass,
    eventually_gt_atTop (0 : ℝ)] with x hVx hPx hx hxpos
  have hVpos : ∀ i ∈ I, 0 < V x i := fun i hi => hv₀.trans_le (hVx i hi)
  have hnorm := normalization_le I (V x) v₀ hv₀ hVx
  constructor
  · exact (MarkedInfiniteMass.infinite_marking_weight_moment I (groups x) (V x)
      (P x) (Real.exp 2 * B) ((Real.log x) ^ (-amax)) hVpos hPx
      hx.2.1 hx.2.2).trans (mul_le_mul_of_nonneg_right hnorm (Real.exp_pos _).le)
  · intro t
    have ht := MarkedInfiniteMass.infinite_marking_weight_size_tail I (groups x) (V x)
      (P x) (Real.exp 2 * B) (t * Real.log x) ((Real.log x) ^ (-amax)) hVpos hPx
      (Real.rpow_nonneg hx.1.le _) hx.2.1 hx.2.2
    rw [rankin_exponent hx.1] at ht
    rw [Real.rpow_def_of_pos hxpos, mul_comm (Real.log x)]
    refine ht.trans ?_
    calc
      _ ≤ (1 / v₀) ^ I.card * Real.exp (2 * (Real.exp 2 * B) -
          t * (Real.log x) ^ (1 - amax)) :=
        mul_le_mul_of_nonneg_right hnorm (Real.exp_pos _).le
      _ = C * Real.exp (-t * (Real.log x) ^ (1 - amax)) := by
        dsimp [C]
        rw [sub_eq_add_neg, Real.exp_add]
        simp only [neg_mul]
        ring

/-- The reciprocal mass of a union is at most the sum of the group masses;
no disjointness assumption is needed for this upper bound. -/
theorem reciprocal_biUnion_le {ι : Type*} (I : Finset ι) (groups : ι → Finset ℕ) :
    (∑ p ∈ I.biUnion groups, 1 / (p : ℝ)) ≤
      ∑ i ∈ I, ∑ p ∈ groups i, 1 / (p : ℝ) := by
  classical
  induction I using Finset.induction_on with
  | empty => simp
  | @insert i I hi ih =>
    rw [Finset.biUnion_insert, Finset.sum_insert hi]
    have heq := Finset.sum_union_inter (s₁ := groups i) (s₂ := I.biUnion groups)
      (f := fun p : ℕ => 1 / (p : ℝ))
    have hn : 0 ≤ ∑ p ∈ groups i ∩ I.biUnion groups, 1 / (p : ℝ) :=
      Finset.sum_nonneg (fun p hp => by positivity)
    linarith

/-- Prime-band endpoints imply the common extreme endpoint bounds. -/
theorem union_band_endpoints {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax x : ℝ) (hL : 1 ≤ Real.log x)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) :
    ∀ p ∈ I.biUnion (fun i => primeBand (a i) x),
      p.Prime ∧ Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
        (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax) := by
  classical
  intro p hp
  obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp hp
  have hh := primeBand_properties (a i) x hpi
  refine ⟨hh.1, ?_, ?_⟩
  · exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (ha i hi).1)).trans hh.2.1
  · exact hh.2.2.trans (Real.exp_le_exp.mpr
      (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hL (ha i hi).2)
        (by norm_num)))

/-- Specialization to the exact manuscript bands and their actual reciprocal
normalizations. The hypotheses `v₀ ≤ Vᵢ ≤ B` are the explicit classical
prime-band inputs. The conclusion is uniform in every integer truncation and
all tail exponents; no marked moment or marked tail is an input. -/
theorem actual_bands_finite_moment_and_tail {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ S : Finset ℕ, (∀ n ∈ S, 0 < n) →
        (∀ n ∈ S, n.primeFactors ⊆ I.biUnion (fun i => primeBand (a i) x)) →
        ((∑ n ∈ S, ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x) n / (n : ℝ) *
          Real.exp ((Real.log x) ^ (-amax) * Real.log (n : ℝ))) ≤ C) ∧
        (∀ t : ℝ, (∑ n ∈ S.filter (fun n : ℕ => x ^ t < (n : ℝ)),
          ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
            (fun i => bandMass (a i) x) n / (n : ℝ)) ≤
          C * Real.exp (-t * (Real.log x) ^ (1 - amax))) := by
  have hend : ∀ᶠ x : ℝ in atTop,
      ∀ p ∈ I.biUnion (fun i => primeBand (a i) x),
        p.Prime ∧ Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
          (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax) := by
    filter_upwards [Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ))]
      with x hx
    exact union_band_endpoints I a amin amax x hx ha
  have htotal : ∀ᶠ x : ℝ in atTop,
      (∑ p ∈ I.biUnion (fun i => primeBand (a i) x), 1 / (p : ℝ)) ≤ I.card * B := by
    filter_upwards [hclassical] with x hx
    refine (reciprocal_biUnion_le I (fun i => primeBand (a i) x)).trans ?_
    calc
      _ ≤ ∑ i ∈ I, B := Finset.sum_le_sum (fun i hi => (hx i hi).2)
      _ = _ := by simp
  obtain ⟨C, hC, hbound⟩ := uniform_finite_moment_and_tail I
    (fun x i => primeBand (a i) x) (fun x i => bandMass (a i) x)
    (fun x => I.biUnion (fun i => primeBand (a i) x)) amin amax (I.card * B) v₀
    hmin hv₀ (hclassical.mono (fun x hx i hi => (hx i hi).1))
    (hend.mono (fun x hx p hp => (hx p hp).1))
    (hend.mono (fun x hx p hp => (hx p hp).2)) htotal
  refine ⟨C, hC, ?_⟩
  filter_upwards [hbound, eventually_gt_atTop (0 : ℝ)] with x hx hxpos
  intro S hpos hsupp
  refine ⟨(hx S hpos hsupp).1, ?_⟩
  intro t
  convert (hx S hpos hsupp).2 t using 1
  rw [Real.rpow_def_of_pos hxpos, mul_comm (Real.log x)]

/-- The full infinite-series form of the manuscript's prime-band Rankin
estimate follows from the ordinary band reciprocal bounds. -/
theorem actual_bands_infinite_moment_and_tail {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ((∑' n, MarkedInfiniteMass.supportedReciprocal
        (I.biUnion (fun i => primeBand (a i) x))
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) n *
        Real.exp ((Real.log x) ^ (-amax) * Real.log (n : ℝ))) ≤ C) ∧
      (∀ t : ℝ, MarkedInfiniteMass.supportedSizeTail
        (I.biUnion (fun i => primeBand (a i) x))
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) (x ^ t) ≤
        C * Real.exp (-t * (Real.log x) ^ (1 - amax))) := by
  have hend : ∀ᶠ x : ℝ in atTop,
      ∀ p ∈ I.biUnion (fun i => primeBand (a i) x),
        p.Prime ∧ Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
          (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax) := by
    filter_upwards [Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ))]
      with x hx
    exact union_band_endpoints I a amin amax x hx ha
  apply uniform_infinite_moment_and_tail I
    (fun x i => primeBand (a i) x) (fun x i => bandMass (a i) x)
    (fun x => I.biUnion (fun i => primeBand (a i) x)) amin amax (I.card * B) v₀
    hmin hv₀ (hclassical.mono (fun x hx i hi => (hx i hi).1))
    (hend.mono (fun x hx p hp => (hx p hp).1))
    (hend.mono (fun x hx p hp => (hx p hp).2))
  filter_upwards [hclassical] with x hx
  refine (reciprocal_biUnion_le I (fun i => primeBand (a i) x)).trans ?_
  calc
    _ ≤ ∑ i ∈ I, B := Finset.sum_le_sum (fun i hi => (hx i hi).2)
    _ = _ := by simp

/-- Distinct fixed exponents separate the bands as `x` tends to infinity. -/
theorem eventual_band_separation (a b : ℝ) (hab : a < b) :
    ∀ᶠ x : ℝ in atTop,
      Real.exp (2 * (Real.log x) ^ a) < Real.exp ((Real.log x) ^ b) := by
  have hgrowth : Tendsto (fun x : ℝ => (Real.log x) ^ (b - a)) atTop atTop :=
    (tendsto_rpow_atTop (sub_pos.mpr hab)).comp Real.tendsto_log_atTop
  filter_upwards [hgrowth.eventually (eventually_gt_atTop (2 : ℝ)),
    eventually_gt_atTop (1 : ℝ)] with x hx hxone
  have hL : 0 < Real.log x := Real.log_pos hxone
  apply Real.exp_lt_exp.mpr
  calc
    2 * (Real.log x) ^ a < (Real.log x) ^ (b - a) * (Real.log x) ^ a :=
      mul_lt_mul_of_pos_right hx (Real.rpow_pos_of_pos hL a)
    _ = (Real.log x) ^ b := by
      rw [← Real.rpow_add hL]
      congr 1
      ring

/-- A finite family with distinct band exponents is eventually disjoint. -/
theorem eventual_bands_disjoint {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (hinj : Set.InjOn a (I : Set ι)) :
    ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, ∀ j ∈ I, i ≠ j →
      Disjoint (primeBand (a i) x) (primeBand (a j) x) := by
  apply (I.eventually_all).mpr
  intro i hi
  apply (I.eventually_all).mpr
  intro j hj
  by_cases hij : i = j
  · exact Filter.Eventually.of_forall (fun x h => (h hij).elim)
  have hne : a i ≠ a j := fun h => hij (hinj hi hj h)
  have hordered (b c : ℝ) (hbc : b < c) :
      ∀ᶠ x : ℝ in atTop, Disjoint (primeBand b x) (primeBand c x) := by
    filter_upwards [eventual_band_separation b c hbc] with x hx
    apply Finset.disjoint_left.mpr
    intro p hpb hpc
    have hb := (primeBand_properties b x hpb).2.2
    have hc := (primeBand_properties c x hpc).2.1
    exact (not_le_of_gt hx) (hc.trans hb)
  rcases lt_or_gt_of_ne hne with hab | hba
  · exact (hordered (a i) (a j) hab).mono (fun x hx _ => hx)
  · exact (hordered (a j) (a i) hba).mono (fun x hx _ => hx.symm)

/-- The actual infinite marked mass lies between one and a uniform constant.
Both disjointness and the lower bound are deductions for the concrete bands;
only the classical two-sided reciprocal-band estimates are assumptions. -/
theorem actual_bands_mass_bounds {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (B v₀ : ℝ) (hv₀ : 0 < v₀) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      1 ≤ MarkedInfiniteMass.supportedMass (I.biUnion (fun i => primeBand (a i) x))
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) ∧
      MarkedInfiniteMass.supportedMass (I.biUnion (fun i => primeBand (a i) x))
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) ≤ C := by
  classical
  let C := (1 / v₀) ^ I.card * Real.exp (2 * (I.card * B))
  refine ⟨C, by dsimp [C]; positivity, ?_⟩
  filter_upwards [hclassical, eventual_bands_disjoint I a hinj] with x hx hd
  have hprime : ∀ p ∈ I.biUnion (fun i => primeBand (a i) x), p.Prime := by
    intro p hp
    obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp hp
    exact (primeBand_properties (a i) x hpi).1
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hx i hi).1
  have htotal : (∑ p ∈ I.biUnion (fun i => primeBand (a i) x), 1 / (p : ℝ)) ≤
      I.card * B := by
    refine (reciprocal_biUnion_le I (fun i => primeBand (a i) x)).trans ?_
    calc
      _ ≤ ∑ i ∈ I, B := Finset.sum_le_sum (fun i hi => (hx i hi).2)
      _ = _ := by simp
  constructor
  · apply MarkedInfiniteMass.marking_mass_ge_one I
      (fun i => primeBand (a i) x) (fun i => bandMass (a i) x) _ hprime
    · intro i hi p hp
      exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩
    · exact hd
    · exact hV
    · intro i hi
      exact le_rfl
  · refine (MarkedInfiniteMass.marking_mass_le I
      (fun i => primeBand (a i) x) (fun i => bandMass (a i) x) _ hV hprime).trans ?_
    refine (mul_le_mul_of_nonneg_right
      (normalization_le I (fun i => bandMass (a i) x) v₀ hv₀
        (fun i hi => (hx i hi).1)) (Real.exp_pos _).le).trans ?_
    exact mul_le_mul_of_nonneg_left
      (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left htotal (by norm_num)))
      (by positivity)

/-- Actual marked/unmarked products beyond a size cutoff. The outer sum is
over the finite set of natural-number cofactors and the inner series retains
all marked prime powers. -/
noncomputable def supportedProductTail (R P : Finset ℕ) (W : ℕ → ℝ) (X : ℝ) : ℝ :=
  ∑ r ∈ R, (∑' s : ℕ, if X < (s : ℝ) * (r : ℝ) then
    MarkedInfiniteMass.supportedReciprocal P W s else 0) / (r : ℝ)

/-- The cutoff implication `sr > U²` and `r ≤ U` gives `s > U`, and therefore
the full product tail is bounded by the cofactor mass times the marked tail. -/
theorem supportedProductTail_le (R P : Finset ℕ) (W : ℕ → ℝ) (U : ℝ)
    (hU : 0 ≤ U) (hR : ∀ r ∈ R, (r : ℝ) ≤ U) (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (MarkedInfiniteMass.supportedReciprocal P W)) :
    supportedProductTail R P W (U * U) ≤
      (∑ r ∈ R, 1 / (r : ℝ)) * MarkedInfiniteMass.supportedSizeTail P W U := by
  classical
  unfold supportedProductTail
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro r hr
  have hpoint : ∀ s : ℕ,
      (if U * U < (s : ℝ) * (r : ℝ) then
        MarkedInfiniteMass.supportedReciprocal P W s else 0) ≤
      (if U < (s : ℝ) then MarkedInfiniteMass.supportedReciprocal P W s else 0) := by
    intro s
    split_ifs with hprod hs hs
    · exact le_rfl
    · have hle : (s : ℝ) * (r : ℝ) ≤ U * U :=
        mul_le_mul (le_of_not_gt hs) (hR r hr) (Nat.cast_nonneg r) hU
      exact (not_lt_of_ge hle hprod).elim
    · exact MarkedInfiniteMass.supportedReciprocal_nonneg P W hW s
    · exact le_rfl
  have hs₁ : Summable (fun s : ℕ => if U * U < (s : ℝ) * (r : ℝ) then
      MarkedInfiniteMass.supportedReciprocal P W s else 0) := by
    apply (hsum.indicator {s : ℕ | U * U < (s : ℝ) * (r : ℝ)}).congr
    intro s
    simp only [Set.indicator_apply, Set.mem_ofPred_eq]
  have hs₂ : Summable (fun s : ℕ => if U < (s : ℝ) then
      MarkedInfiniteMass.supportedReciprocal P W s else 0) := by
    apply (hsum.indicator {s : ℕ | U < (s : ℝ)}).congr
    intro s
    simp only [Set.indicator_apply, Set.mem_ofPred_eq]
  have hb := div_le_div_of_nonneg_right (Summable.tsum_le_tsum hpoint hs₁ hs₂)
    (Nat.cast_nonneg r)
  simpa only [MarkedInfiniteMass.supportedSizeTail, one_div_mul_eq_div] using hb

/-- Full §4 product-tail estimate for the actual unmarked cofactor family.
The constant is selected before the three parameters `ε`, `Y`, and `τ`; the
only analytic assumptions remain reciprocal-prime bounds on the marked bands. -/
theorem uniform_infinite_cofactor_tail {ι : Type*} (I : Finset ι)
    (groups : ℝ → ι → Finset ℕ) (V : ℝ → ι → ℝ) (P : ℝ → Finset ℕ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ V x i)
    (hP : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x, p.Prime)
    (hends : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax))
    (hmass : ∀ᶠ x : ℝ in atTop, (∑ p ∈ P x, 1 / (p : ℝ)) ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ ε Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      supportedProductTail
        (CofactorAsymptotics.cofactors (CofactorAsymptotics.scalePrimes P ε Y x)
          (Real.exp (ε * Real.log x / 2)) τ)
        (P x) (ConcreteSelector.markingWeight I (groups x) (V x)) (x ^ ε) ≤
        CofactorAsymptotics.scaleMass P ε Y τ x *
          (C * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := by
  obtain ⟨C, hC, hc⟩ := uniform_infinite_moment_and_tail I groups V P amin amax B v₀
    hmin hv₀ hV hP hends hmass
  refine ⟨C, hC, ?_⟩
  intro ε Y τ
  filter_upwards [hc, hV, hP, eventually_gt_atTop (0 : ℝ)] with x hx hVx hPx hxpos
  let R := CofactorAsymptotics.cofactors (CofactorAsymptotics.scalePrimes P ε Y x)
    (Real.exp (ε * Real.log x / 2)) τ
  have hVpos : ∀ i ∈ I, 0 < V x i := fun i hi => hv₀.trans_le (hVx i hi)
  have hU : x ^ (ε / 2) = Real.exp (ε * Real.log x / 2) := by
    rw [Real.rpow_def_of_pos hxpos]
    congr 1
    ring
  have hR : ∀ r ∈ R, (r : ℝ) ≤ x ^ (ε / 2) := by
    intro r hr
    rw [hU]
    exact CofactorAsymptotics.cofactor_le _ _ _ hr
  have hsq : x ^ (ε / 2) * x ^ (ε / 2) = x ^ ε := by
    rw [← Real.rpow_add hxpos]
    congr 1
    ring
  have hb := supportedProductTail_le R (P x)
    (ConcreteSelector.markingWeight I (groups x) (V x)) (x ^ (ε / 2))
    (Real.rpow_nonneg hxpos.le _) hR
    (fun n => (ConcreteSelector.markingWeight_bounds I (groups x) (V x) n hVpos).1)
    (MarkedInfiniteMass.summable_marking_weight I (groups x) (V x) (P x) hVpos hPx)
  rw [hsq] at hb
  exact hb.trans (mul_le_mul_of_nonneg_left (hx.2 (ε / 2))
    (Finset.sum_nonneg (fun r hr => by positivity)))

/-- Product-tail specialization to the exact prime bands, with their actual
normalizing reciprocal sums and actual cofactor mass `H₀`. -/
theorem actual_bands_infinite_cofactor_tail {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ ε Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      supportedProductTail
        (CofactorAsymptotics.cofactors
          (CofactorAsymptotics.scalePrimes
            (fun z => I.biUnion (fun i => primeBand (a i) z)) ε Y x)
          (Real.exp (ε * Real.log x / 2)) τ)
        (I.biUnion (fun i => primeBand (a i) x))
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) (x ^ ε) ≤
        CofactorAsymptotics.scaleMass
          (fun z => I.biUnion (fun i => primeBand (a i) z)) ε Y τ x *
          (C * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := by
  have hend : ∀ᶠ x : ℝ in atTop,
      ∀ p ∈ I.biUnion (fun i => primeBand (a i) x),
        p.Prime ∧ Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
          (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax) := by
    filter_upwards [Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ))]
      with x hx
    exact union_band_endpoints I a amin amax x hx ha
  apply uniform_infinite_cofactor_tail I
    (fun x i => primeBand (a i) x) (fun x i => bandMass (a i) x)
    (fun x => I.biUnion (fun i => primeBand (a i) x)) amin amax (I.card * B) v₀
    hmin hv₀ (hclassical.mono (fun x hx i hi => (hx i hi).1))
    (hend.mono (fun x hx p hp => (hx p hp).1))
    (hend.mono (fun x hx p hp => (hx p hp).2))
  filter_upwards [hclassical] with x hx
  refine (reciprocal_biUnion_le I (fun i => primeBand (a i) x)).trans ?_
  calc
    _ ≤ ∑ i ∈ I, B := Finset.sum_le_sum (fun i hi => (hx i hi).2)
    _ = _ := by simp

/-- Each actual unmarked cofactor is positive and has no marked prime
factor. This proves the hypotheses of the unique-factor reindexing theorem. -/
theorem unmarked_cofactors_disjoint (P : Finset ℕ) (Y Z R τ : ℝ)
    (hP : ∀ p ∈ P, p.Prime) :
    ∀ r ∈ CofactorAsymptotics.cofactors (CofactorAsymptotics.unmarkedPrimes P Y Z) R τ,
      r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r := by
  intro r hr
  have hprimes : ∀ p ∈ CofactorAsymptotics.unmarkedPrimes P Y Z, p.Prime :=
    fun p hp => CofactorAsymptotics.unmarkedPrimes_prime P Y Z hp
  refine ⟨(CofactorAsymptotics.cofactor_pos _ hprimes _ _ hr).ne', ?_⟩
  intro p hp hpr
  have hm := CofactorAsymptotics.prime_dvd_cofactor_mem _ hprimes _ _ hr (hP p hp) hpr
  exact (Finset.mem_filter.mp hm).2.2.2.2 hp

/-- Transfer of the factor-pair tail to the series over distinct actual
natural numbers. Unique marked/unmarked decomposition prevents overcounting. -/
theorem enlarged_cofactor_tail_eq (P : Finset ℕ) (W : ℕ → ℝ) (Y Z R τ X : ℝ)
    (hP : ∀ p ∈ P, p.Prime) (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (MarkedInfiniteMass.supportedReciprocal P W)) :
    EnlargedCofactorMass.enlargedSizeTail P
      (CofactorAsymptotics.cofactors (CofactorAsymptotics.unmarkedPrimes P Y Z) R τ) W X =
    supportedProductTail
      (CofactorAsymptotics.cofactors (CofactorAsymptotics.unmarkedPrimes P Y Z) R τ) P W X :=
  EnlargedCofactorMass.enlargedSizeTail_eq P _ W X
    (unmarked_cofactors_disjoint P Y Z R τ hP) hW hsum

/-- Uniform §4 tail over distinct actual enlarged natural cofactors.
The constant is fixed before the cofactor parameters `ε`, `Y`, and `τ`. -/
theorem uniform_enlarged_cofactor_tail {ι : Type*} (I : Finset ι)
    (groups : ℝ → ι → Finset ℕ) (V : ℝ → ι → ℝ) (P : ℝ → Finset ℕ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ V x i)
    (hP : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x, p.Prime)
    (hends : ∀ᶠ x : ℝ in atTop, ∀ p ∈ P x,
      Real.exp ((Real.log x) ^ amin) ≤ (p : ℝ) ∧
      (p : ℝ) ≤ Real.exp (2 * (Real.log x) ^ amax))
    (hmass : ∀ᶠ x : ℝ in atTop, (∑ p ∈ P x, 1 / (p : ℝ)) ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ ε Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      EnlargedCofactorMass.enlargedSizeTail (P x)
        (CofactorAsymptotics.cofactors (CofactorAsymptotics.scalePrimes P ε Y x)
          (Real.exp (ε * Real.log x / 2)) τ)
        (ConcreteSelector.markingWeight I (groups x) (V x)) (x ^ ε) ≤
        CofactorAsymptotics.scaleMass P ε Y τ x *
          (C * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := by
  obtain ⟨C, hC, hc⟩ := uniform_infinite_cofactor_tail I groups V P amin amax B v₀
    hmin hv₀ hV hP hends hmass
  refine ⟨C, hC, ?_⟩
  intro ε Y τ
  filter_upwards [hc ε Y τ, hV, hP] with x hx hVx hPx
  have hVpos : ∀ i ∈ I, 0 < V x i := fun i hi => hv₀.trans_le (hVx i hi)
  rw [show EnlargedCofactorMass.enlargedSizeTail (P x)
      (CofactorAsymptotics.cofactors (CofactorAsymptotics.scalePrimes P ε Y x)
        (Real.exp (ε * Real.log x / 2)) τ)
      (ConcreteSelector.markingWeight I (groups x) (V x)) (x ^ ε) = _ from
    enlarged_cofactor_tail_eq (P x) (ConcreteSelector.markingWeight I (groups x) (V x))
      Y (Real.exp (ε * Real.log x / 8)) (Real.exp (ε * Real.log x / 2)) τ (x ^ ε) hPx
      (fun n => (ConcreteSelector.markingWeight_bounds I (groups x) (V x) n hVpos).1)
      (MarkedInfiniteMass.summable_marking_weight I (groups x) (V x) (P x) hVpos hPx)]
  exact hx

/-- Concrete prime-band form of the full tail estimate over distinct actual
integers `r=s*r₀`, not a formal product model. -/
theorem actual_bands_enlarged_cofactor_tail {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ ε Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      EnlargedCofactorMass.enlargedSizeTail (I.biUnion (fun i => primeBand (a i) x))
        (CofactorAsymptotics.cofactors
          (CofactorAsymptotics.scalePrimes
            (fun z => I.biUnion (fun i => primeBand (a i) z)) ε Y x)
          (Real.exp (ε * Real.log x / 2)) τ)
        (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
          (fun i => bandMass (a i) x)) (x ^ ε) ≤
        CofactorAsymptotics.scaleMass
          (fun z => I.biUnion (fun i => primeBand (a i) z)) ε Y τ x *
          (C * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := by
  obtain ⟨C, hC, hc⟩ := actual_bands_infinite_cofactor_tail I a amin amax B v₀ hmin hv₀
    ha hclassical
  refine ⟨C, hC, ?_⟩
  intro ε Y τ
  filter_upwards [hc ε Y τ, hclassical] with x hx hVx
  have hVpos : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hprime : ∀ p ∈ I.biUnion (fun i => primeBand (a i) x), p.Prime := by
    intro p hp
    obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp hp
    exact (primeBand_properties (a i) x hpi).1
  rw [show EnlargedCofactorMass.enlargedSizeTail
      (I.biUnion (fun i => primeBand (a i) x))
      (CofactorAsymptotics.cofactors
        (CofactorAsymptotics.scalePrimes (fun z => I.biUnion (fun i => primeBand (a i) z)) ε Y x)
        (Real.exp (ε * Real.log x / 2)) τ)
      (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x)
        (fun i => bandMass (a i) x)) (x ^ ε) = _ from
    enlarged_cofactor_tail_eq (I.biUnion (fun i => primeBand (a i) x))
      (ConcreteSelector.markingWeight I (fun i => primeBand (a i) x) (fun i => bandMass (a i) x))
      Y (Real.exp (ε * Real.log x / 8)) (Real.exp (ε * Real.log x / 2)) τ (x ^ ε) hprime
      (fun n => (ConcreteSelector.markingWeight_bounds I (fun i => primeBand (a i) x)
        (fun i => bandMass (a i) x) n hVpos).1)
      (MarkedInfiniteMass.summable_marking_weight I (fun i => primeBand (a i) x)
        (fun i => bandMass (a i) x) _ hVpos hprime)]
  exact hx

/-- Positivity of `1-amax` gives genuine decay for every fixed positive `t`. -/
theorem rankin_decay_tendsto (amax t : ℝ) (hmax : amax < 1) (ht : 0 < t) :
    Tendsto (fun x : ℝ => Real.exp (-t * (Real.log x) ^ (1 - amax)))
      atTop (nhds 0) := by
  have hgrowth : Tendsto (fun x : ℝ => t * (Real.log x) ^ (1 - amax)) atTop atTop :=
    Filter.Tendsto.const_mul_atTop ht
      ((tendsto_rpow_atTop (sub_pos.mpr hmax)).comp Real.tendsto_log_atTop)
  simpa only [Function.comp_def, neg_mul] using
    Real.tendsto_exp_neg_atTop_nhds_zero.comp hgrowth

end Artin.MarkedBandTail
