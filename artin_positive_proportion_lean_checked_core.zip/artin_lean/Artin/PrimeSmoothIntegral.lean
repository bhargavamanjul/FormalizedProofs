module

public import Artin.LogarithmicIntegralCells
public import Artin.SmoothQuadrature

/-!
# The continuous main term of smooth prime sums

The logarithmic-integral increments are converted to the actual continuous
smooth integral with a uniform quadrature error.
-/

@[expose] public section

open scoped BigOperators
open MeasureTheory

namespace Artin.PrimeSmoothIntegral

open PrimeDistribution

/-- The two clipped initial Li cells vanish, so the discrete model is exactly
the sum of the genuine cells from two onwards. -/
theorem weightedModel_eq_sum_cells (q N : ℕ) (hN : 2 ≤ N) (w : ℕ → ℝ) :
    weightedModel q N w logarithmicIntegral =
      (∑ n ∈ Finset.Ico 2 N,
        w n * (∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), (Real.log t)⁻¹)) /
          (q.totient : ℝ) := by
  unfold weightedModel
  simp_rw [← mul_div_assoc]
  rw [← Finset.sum_div]
  congr 1
  have hlow : (∑ n ∈ Finset.range 2,
      w n * (logarithmicIntegral (n + 1) - logarithmicIntegral n)) = 0 := by
    simp [Finset.sum_range_succ, logarithmicIntegral_zero]
  rw [← Finset.sum_range_add_sum_Ico
    (fun n => w n * (logarithmicIntegral (n + 1) - logarithmicIntegral n)) hN,
    hlow, zero_add]
  apply Finset.sum_congr rfl
  intro n hn
  rw [logarithmicIntegral_succ_sub n (Finset.mem_Ico.mp hn).1]

/-- The exact analytic smooth main term before the totient normalization. -/
noncomputable def smoothIntegral (Ψ : ℝ → ℝ) (a b : ℝ) (N : ℕ) : ℝ :=
  ∫ t in (2 : ℝ)..(N : ℝ), Ψ (a * t + b) / Real.log t

/-- Replacing sampled smooth weights inside Li increments by their actual
continuous values costs at most the rescaled interval length times `K/log 2`. -/
theorem weightedModel_smoothIntegral_error (q N : ℕ) (hN : 2 ≤ N)
    (Ψ : ℝ → ℝ) {a b K : ℝ} (ha : 0 ≤ a) (hK : 0 ≤ K)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|) :
    |weightedModel q N (fun n => Ψ (a * n + b)) logarithmicIntegral -
        smoothIntegral Ψ a b N / (q.totient : ℝ)| ≤
      ((N : ℝ) * a * K / Real.log 2) / (q.totient : ℝ) := by
  have hK' : 0 ≤ K * a := mul_nonneg hK ha
  have hcell := sum_unit_cell_error (fun t => Ψ (a * t + b))
    (fun t => (Real.log t)⁻¹) N hN hK' (affine_abs_lipschitz Ψ ha hLip)
    (fun n hn => invlog_intervalIntegrable
      (by exact_mod_cast (Finset.mem_Ico.mp hn).1)
      (by exact_mod_cast Nat.le_succ n))
    (fun t ht => invlog_abs_le ht.1)
  have hnonneg : 0 ≤ (K * a) * (Real.log 2)⁻¹ :=
    mul_nonneg hK' (inv_nonneg.mpr (Real.log_pos (by norm_num : (1 : ℝ) < 2)).le)
  have hcount : ((N - 2 : ℕ) : ℝ) ≤ N := by exact_mod_cast Nat.sub_le N 2
  have he : |(∑ n ∈ Finset.Ico 2 N,
        Ψ (a * n + b) * (∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), (Real.log t)⁻¹)) -
        smoothIntegral Ψ a b N| ≤ (N : ℝ) * a * K / Real.log 2 := by
    calc
      _ ≤ (N - 2 : ℕ) * ((K * a) * (Real.log 2)⁻¹) := by
        simpa only [smoothIntegral, div_eq_mul_inv] using hcell
      _ ≤ (N : ℝ) * ((K * a) * (Real.log 2)⁻¹) :=
        mul_le_mul_of_nonneg_right hcount hnonneg
      _ = _ := by ring
  rw [weightedModel_eq_sum_cells q N hN, ← sub_div, abs_div]
  have hφ : |(q.totient : ℝ)| = (q.totient : ℝ) := abs_of_nonneg (Nat.cast_nonneg q.totient)
  rw [hφ]
  exact div_le_div_of_nonneg_right he (Nat.cast_nonneg q.totient)

/-- Bounded affine length gives a uniform error, including its exact totient
normalization. This conclusion assumes no weighted prime estimate. -/
theorem weightedModel_smoothIntegral_error_uniform (q N : ℕ) (hN : 2 ≤ N)
    (Ψ : ℝ → ℝ) {a b K : ℝ} (ha : 0 ≤ a) (hK : 0 ≤ K)
    (hNa : (N : ℝ) * a ≤ 3)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|) :
    |weightedModel q N (fun n => Ψ (a * n + b)) logarithmicIntegral -
        smoothIntegral Ψ a b N / (q.totient : ℝ)| ≤
      (3 * K / Real.log 2) / (q.totient : ℝ) := by
  apply (weightedModel_smoothIntegral_error q N hN Ψ ha hK hLip).trans
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg q.totient)
  apply div_le_div_of_nonneg_right _ (Real.log_pos (by norm_num : (1 : ℝ) < 2)).le
  exact mul_le_mul_of_nonneg_right hNa hK

/-- The original quotient-affine weight, ready for `s = c*r`. -/
theorem weightedModel_quotient_integral_error (q N : ℕ) (hN : 2 ≤ N)
    (Ψ : ℝ → ℝ) {s x K : ℝ} (hs : 0 ≤ s) (hx : 0 < x) (hK : 0 ≤ K)
    (hNs : (N : ℝ) * s ≤ 3 * x)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|) :
    |weightedModel q N (fun n => Ψ ((s * n + 1) / x)) logarithmicIntegral -
        (∫ t in (2 : ℝ)..(N : ℝ), Ψ ((s * t + 1) / x) / Real.log t) /
          (q.totient : ℝ)| ≤ (3 * K / Real.log 2) / (q.totient : ℝ) := by
  have ha : 0 ≤ s / x := div_nonneg hs hx.le
  have hNa : (N : ℝ) * (s / x) ≤ 3 := by
    rw [← mul_div_assoc]
    exact (div_le_iff₀ hx).mpr hNs
  have he := weightedModel_smoothIntegral_error_uniform q N hN Ψ
    (b := 1 / x) ha hK hNa hLip
  have hid (t : ℝ) : s / x * t + 1 / x = (s * t + 1) / x := by ring
  simpa only [smoothIntegral, hid] using he

end Artin.PrimeSmoothIntegral
