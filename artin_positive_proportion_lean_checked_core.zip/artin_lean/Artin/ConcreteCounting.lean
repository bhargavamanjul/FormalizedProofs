module

public import Artin.CandidateBridge
public import Artin.OrderExceptions
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Tactic.Ring

/-!
# Counting the actual arithmetic exceptions

This file connects the structured-candidate argument with the proved integer
product estimate. Only the candidate lower bound and the small-index upper
bound remain hypotheses. The small-order exceptional set is bounded here,
without an analytic assumption.

The ambient set can be the primes in `(x, 2x]`; the proof needs only that its
members are at least `x`. The exponent is real, and negative integer bases are
included through `Admissible`.
-/

@[expose] public section

namespace Artin

/-- Explicit bound for the large-factor exceptional set. -/
theorem smallOrderException_card_le (a : ℤ) (ha : Admissible a)
    (R : ℕ) (s : Finset ℕ) {x ε : ℝ} (hx : 1 < x)
    (hambient : ∀ p ∈ s, x ≤ (p : ℝ)) (hR : (R : ℝ) ≤ x ^ ε) :
    (filteredCard s (SmallOrderException a R) : ℝ) ≤
      16 * Real.log (a.natAbs + 1 : ℝ) * x ^ (2 * ε) / Real.log x := by
  classical
  let exceptions := s.filter (SmallOrderException a R)
  have hcutoff : ((4 * R : ℕ) : ℝ) ≤ 4 * x ^ ε := by
    push_cast
    exact mul_le_mul_of_nonneg_left hR (by norm_num)
  have hbound := small_order_primes_card_le_of_cutoff
    (S := exceptions) (M := 4 * R) ha.natAbs_gt_one hx hcutoff (by
      intro p hp
      obtain ⟨hps, hpex⟩ := Finset.mem_filter.mp hp
      exact ⟨hpex.1, hambient p hps, hpex.2.1, hpex.2.2⟩)
  have hpow : (x ^ ε) ^ 2 = x ^ (2 * ε) := by
    rw [mul_comm (2 : ℝ) ε, Real.rpow_mul (by linarith : 0 ≤ x), Real.rpow_two]
  have heq : (4 * x ^ ε) ^ 2 * Real.log (a.natAbs + 1 : ℝ) / Real.log x =
      16 * Real.log (a.natAbs + 1 : ℝ) * x ^ (2 * ε) / Real.log x := by
    rw [← hpow]
    ring
  rw [heq] at hbound
  exact hbound

/-- The final finite arithmetic count. The order-exception upper bound is
proved, rather than included among the two remaining estimate hypotheses. -/
theorem primitive_count_after_explicit_order_bound
    (a : ℤ) (ha : Admissible a) (Y R : ℕ) (s : Finset ℕ)
    {x ε candidateLower smallUpper : ℝ} (hx : 1 < x)
    (hambient : ∀ p ∈ s, x ≤ (p : ℝ)) (hR : (R : ℝ) ≤ x ^ ε)
    (hcandidate : candidateLower ≤ (filteredCard s (StructuredCandidate a Y R) : ℝ))
    (hsmall : (filteredCard s (SmallIndexObstruction a Y R) : ℝ) ≤ smallUpper) :
    candidateLower - smallUpper -
        16 * Real.log (a.natAbs + 1 : ℝ) * x ^ (2 * ε) / Real.log x ≤
      (filteredCard s (IsPrimitiveRootAt a) : ℝ) := by
  exact primitive_count_from_candidate_estimates a Y R s hcandidate hsmall
    (smallOrderException_card_le a ha R s hx hambient hR)

end Artin
