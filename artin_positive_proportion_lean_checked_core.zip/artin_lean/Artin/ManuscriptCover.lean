module

public import Artin.ManuscriptTail
public import Artin.NonresidueProgression
public import Artin.RoughFactorization

/-!
# The actual prime, composite, and discarded-cofactor cover

Prime weights in the fixed nonresidue progression with a small enlarged
cofactor belong to the concrete survivor set.  Reindexing the complementary
prime weights shows that their entire mass is bounded by the already proved
discarded-cofactor contribution.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.ManuscriptCover

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate MarkedBandTail
  ManuscriptMass ManuscriptTail

/-- The actual invariant weight, exposed as a function on the integers for
the prime/composite decomposition. -/
noncomputable def integerWeight {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (d : ℕ) : ℝ :=
  arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
    (fun i => bandMass (a i) x) (markedPrimes I a x) c
    (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) d

/-- The actual arithmetic survivor set, including the fixed quadratic
nonresidue condition and the eventual enlarged-cofactor cutoff. -/
noncomputable def survivors {ι : Type*} (base : ℤ) (I : Finset ι) (a : ι → ℝ)
    (c : ℕ) (ε Y τ x : ℝ) : Finset ℕ :=
  selectedPrimeSurvivors base (markedPrimes I a x) c
    (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) ε x

/-- Smooth prime weights excluded from the actual survivor set. -/
noncomputable def rejectedPrimeMass {ι : Type*} (base : ℤ) (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) : ℝ :=
  ∑ d ∈ Finset.Icc 2 ⌊2 * x⌋₊,
    if d.Prime ∧ d ∉ survivors base I a c ε Y τ x
      then integerWeight I a c M u ε Y τ x d else 0

/-- The actual rough integers remaining after the least-prime-factor sieve. -/
noncomputable def roughIntegers (κ x : ℝ) : Finset ℕ := by
  classical
  exact (Finset.Icc 2 ⌊2 * x⌋₊).filter (fun d =>
    ∀ p : ℕ, p.Prime → p ∣ d → x ^ (1 / 2 - κ) < (p : ℝ))

noncomputable def roughMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ κ x : ℝ) : ℝ :=
  ∑ d ∈ roughIntegers κ x, integerWeight I a c M u ε Y τ x d

/-- The composite part of the actual rough sum. The existing arithmetic
factorization theorem identifies its members as near-square-root semiprimes. -/
noncomputable def roughCompositeMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ κ x : ℝ) : ℝ :=
  ∑ d ∈ (roughIntegers κ x).filter (fun d => ¬ d.Prime),
    integerWeight I a c M u ε Y τ x d

noncomputable def survivorMass {ι : Type*} (base : ℤ) (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) : ℝ :=
  ∑ p ∈ survivors base I a c ε Y τ x, integerWeight I a c M u ε Y τ x p

theorem integerWeight_nonneg {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) (d : ℕ) :
    0 ≤ integerWeight I a c M u ε Y τ x d :=
  (arithmeticWeight_bounds M u (smoothWeight x) I _ _ _ c _ _ d
    (smoothWeight_bounds x d) hV).1

/-- A prime with small enlarged cofactor is an actual survivor. The fixed
progression supplies nonsquareness; it is not imposed by dropping weights. -/
theorem survivor_of_small_predecessor {base : ℤ}
    (D : NonresidueProgression.Progression base) (P U : Finset ℕ)
    {x ε Qmin : ℝ} {r Q : ℕ} (hx : 0 < x)
    (hcP : ∀ p ∈ P, ¬ p ∣ D.c) (hQP : ∀ p ∈ P, ¬ p ∣ Q)
    (hr : 0 < r) (hrstrip : strip P r ∈ U) (hQ : Q.Prime) (hlarge : Qmin < (Q : ℝ))
    (hprime : (D.c * r * Q + 1).Prime)
    (hprog : (D.c * r * Q + 1) % D.M = D.u)
    (hΨ : smoothWeight x (D.c * r * Q + 1) ≠ 0) (hsize : (r : ℝ) ≤ x ^ ε) :
    D.c * r * Q + 1 ∈ selectedPrimeSurvivors base P D.c U Qmin ε x := by
  classical
  have hc : D.c ≠ 0 := by rcases D.c_choice with h | h <;> omega
  have hstrip : strip P (D.c * r * Q) = D.c * strip P r * Q := by
    rw [strip_mul P (mul_ne_zero hc hr.ne') hQ.ne_zero, strip_mul P hc hr.ne',
      strip_eq_self_of_avoids P hc hcP, strip_eq_self_of_avoids P hQ.ne_zero hQP]
  have hpart : markedPart P (D.c * r * Q) = markedPart P r := by
    rw [markedPart_mul P (mul_ne_zero hc hr.ne') hQ.ne_zero, markedPart_mul P hc hr.ne',
      markedPart_eq_one_of_avoids P hcP, markedPart_eq_one_of_avoids P hQP,
      one_mul, mul_one]
  have hs := PositiveBump.weight_support hΨ
  have hl : x < ((D.c * r * Q + 1 : ℕ) : ℝ) := by
    simpa using (lt_div_iff₀ hx).mp hs.1
  have hu : ((D.c * r * Q + 1 : ℕ) : ℝ) ≤ 2 * x :=
    ((div_lt_iff₀ hx).mp hs.2).le
  have hmod : Nat.ModEq D.M (D.c * r * Q + 1) D.u := by
    change (D.c * r * Q + 1) % D.M = D.u % D.M
    rw [hprog, Nat.mod_eq_of_lt D.u_lt_M]
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_filter.mpr ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor hu, hprime⟩, hl⟩,
    D.nonresidue _ hprime hmod, strip P r, Q, ?_, ?_⟩
  · exact ⟨hrstrip, hQ, hlarge, by simpa only [Nat.add_sub_cancel] using hstrip⟩
  · simpa only [Nat.add_sub_cancel, hpart, markedPart_mul_strip P hr.ne'] using Nat.le_floor hsize

/-- Prime-progression sums are monotone in the smooth factor. -/
theorem primeProgressionSum_mono (c M u r : ℕ) (Qs : Finset ℕ) (Ψ Φ : ℕ → ℝ)
    (h : ∀ d, Ψ d ≤ Φ d) :
    primeProgressionSum c M u Qs Ψ r ≤ primeProgressionSum c M u Qs Φ r := by
  apply Finset.sum_le_sum
  intro Q hQ
  split_ifs
  · exact h _
  · exact le_rfl

/-- Multiplying the smooth factor by an indicator multiplies the full
arithmetic weight by exactly the same indicator. -/
theorem arithmeticWeight_indicator {ι : Type*}
    (M u c : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P U : Finset ℕ) (Qmin : ℝ) (E : ℕ → Prop) [DecidablePred E] (d : ℕ) :
    arithmeticWeight M u (fun n => if E n then Ψ n else 0) I groups V P c U Qmin d =
      if E d then arithmeticWeight M u Ψ I groups V P c U Qmin d else 0 := by
  by_cases h : E d <;> simp [arithmeticWeight, h]

/-- Rejected prime weights can only come from the discarded enlarged
cofactors. All support assertions and the fixed progression are used here. -/
theorem rejectedPrimeMass_le_discardedMass {base : ℤ}
    (D : NonresidueProgression.Progression base)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ) (ε Y τ x Z : ℝ)
    (hx : 2 ≤ x) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ D.c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    rejectedPrimeMass base I a D.c D.M D.u ε Y τ x ≤
      discardedMass I a D.c D.M D.u ε Y τ x := by
  classical
  let P := markedPrimes I a x
  let U := unmarkedCofactors I a ε Y τ x
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  let S := boundedCofactors P U (2 * x)
  let R := boundedCofactors P U (x ^ ε)
  let E := fun d : ℕ => d.Prime ∧ d ∉ survivors base I a D.c ε Y τ x
  let Φ := fun d : ℕ => if E d then smoothWeight x d else 0
  have hc : 0 < D.c := by rcases D.c_choice with h | h <;> omega
  have hg : ∀ i ∈ I, primeBand (a i) x ⊆ P := by
    intro i hi p hp
    exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩
  have hΦ : ∀ d, Φ d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ 2 * x := by
    intro d hd
    by_cases hE : E d
    · exact smoothWeight_support hx d (by simpa [Φ, hE] using hd)
    · exact False.elim (hd (by simp [Φ, hE]))
  have heq : rejectedPrimeMass base I a D.c D.M D.u ε Y τ x =
      ∑ r ∈ S, marking I a x r * primeProgressionSum D.c D.M D.u Qs Φ r := by
    have hh := WeightSupport.ambient_weight_sum_eq_real D.M D.u D.c (2 * x) Φ I
      (fun i => primeBand (a i) x) (fun i => bandMass (a i) x) P U
      (by positivity) hc hcut
      (fun p hp => ⟨markedPrimes_prime I a x p hp, hP p hp⟩) hg hcP
      (fun r hr => ⟨Nat.pos_of_ne_zero (unmarkedCofactors_avoid I a ε Y τ x r hr).1,
        (unmarkedCofactors_avoid I a ε Y τ x r hr).2⟩) hU hΦ
    simpa only [Φ, arithmeticWeight_indicator, rejectedPrimeMass, E, integerWeight,
      marking, S, P, U, Qs] using hh
  have hsmall : ∀ r ∈ S, r ∈ R → primeProgressionSum D.c D.M D.u Qs Φ r = 0 := by
    intro r hrs hrr
    have hr := (mem_boundedCofactors P U (x ^ ε) r).mp hrr
    apply Finset.sum_eq_zero
    intro Q hQQ
    have hQ := WeightSupport.mem_boundedLargePrimes.mp hQQ
    by_cases hprog : (D.c * r * Q + 1) % D.M = D.u
    · simp only [hprog, ite_true]
      by_contra hn
      have hE : E (D.c * r * Q + 1) := by
        by_contra hh
        exact hn (by simp [Φ, hh])
      have hΨ : smoothWeight x (D.c * r * Q + 1) ≠ 0 := by
        simpa [Φ, hE] using hn
      have hsurv := survivor_of_small_predecessor D P U (by linarith) hcP
        (large_prime_avoids_marked P
          (fun p hp => ⟨markedPrimes_prime I a x p hp, (hP p hp).trans hcut⟩)
          hQ.1 hQ.2.2) hr.1 hr.2.1 hQ.1 hQ.2.2 hE.1 hprog hΨ hr.2.2
      exact hE.2 hsurv
    · simp [hprog]
  have hrestrict : (∑ r ∈ S, marking I a x r * primeProgressionSum D.c D.M D.u Qs Φ r) =
      ∑ r ∈ S \ R, marking I a x r * primeProgressionSum D.c D.M D.u Qs Φ r := by
    symm
    apply Finset.sum_subset Finset.sdiff_subset
    intro r hrs hrnot
    have hrr : r ∈ R := by
      by_contra hn
      exact hrnot (Finset.mem_sdiff.mpr ⟨hrs, hn⟩)
    rw [hsmall r hrs hrr, mul_zero]
  rw [heq, hrestrict]
  apply Finset.sum_le_sum
  intro r hr
  apply mul_le_mul_of_nonneg_left ?_ (markingWeight_bounds I _ _ r hV).1
  apply primeProgressionSum_mono
  intro d
  by_cases hE : E d
  · simp [Φ, hE]
  · simpa [Φ, hE] using (smoothWeight_bounds x d).1

/-- Elementary weighted covering by retained primes, composites, and
excluded primes, with all sums taken over actual finite sets. -/
theorem finite_prime_composite_cover (S T V : Finset ℕ) (w : ℕ → ℝ)
    (hST : S ⊆ T) (hW : ∀ d, 0 ≤ w d) :
    (∑ d ∈ S, w d) ≤ (∑ d ∈ V, w d) +
      (∑ d ∈ S.filter (fun d => ¬ d.Prime), w d) +
      ∑ d ∈ T, if d.Prime ∧ d ∉ V then w d else 0 := by
  classical
  have hpoint : (∑ d ∈ S, w d) ≤
      (∑ d ∈ S.filter (fun d => d ∈ V), w d) +
      (∑ d ∈ S.filter (fun d => ¬ d.Prime), w d) +
      ∑ d ∈ S, if d.Prime ∧ d ∉ V then w d else 0 := by
    simp only [Finset.sum_filter, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro d hd
    by_cases hV : d ∈ V <;> by_cases hp : d.Prime <;> simp [hV, hp]
    exact hW d
  have hfirst : (∑ d ∈ S.filter (fun d => d ∈ V), w d) ≤ ∑ d ∈ V, w d := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro d hd
      exact (Finset.mem_filter.mp hd).2
    · exact fun d _ _ => hW d
  have hlast : (∑ d ∈ S, if d.Prime ∧ d ∉ V then w d else 0) ≤
      ∑ d ∈ T, if d.Prime ∧ d ∉ V then w d else 0 := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hST
    intro d _ _
    split_ifs
    · exact hW d
    · exact le_rfl
  linarith

/-- The actual rough sum is covered by the concrete prime survivors, the
actual rough composites, and the proved discarded-cofactor contribution. -/
theorem rough_prime_composite_tail_cover {base : ℤ}
    (D : NonresidueProgression.Progression base)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ) (ε Y τ κ x Z : ℝ)
    (hx : 2 ≤ x) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ D.c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    roughMass I a D.c D.M D.u ε Y τ κ x ≤
      survivorMass base I a D.c D.M D.u ε Y τ x +
        roughCompositeMass I a D.c D.M D.u ε Y τ κ x +
          discardedMass I a D.c D.M D.u ε Y τ x := by
  classical
  have hcover := finite_prime_composite_cover (roughIntegers κ x) (Finset.Icc 2 ⌊2 * x⌋₊)
    (survivors base I a D.c ε Y τ x) (integerWeight I a D.c D.M D.u ε Y τ x)
    (Finset.filter_subset _ _) (integerWeight_nonneg I a D.c D.M D.u ε Y τ x hV)
  have htail := rejectedPrimeMass_le_discardedMass D I a ε Y τ x Z hx hcut hP hcP hU hV
  change roughMass I a D.c D.M D.u ε Y τ κ x ≤
    survivorMass base I a D.c D.M D.u ε Y τ x +
      roughCompositeMass I a D.c D.M D.u ε Y τ κ x +
        rejectedPrimeMass base I a D.c D.M D.u ε Y τ x at hcover
  linarith

/-- All support conditions in the weighted cover hold at the actual scales.
The common threshold works for every roughness parameter `κ`. -/
theorem eventually_rough_prime_composite_tail_cover {base : ℤ}
    (D : NonresidueProgression.Progression base)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, 0 < bandMass (a i) x)
    (ε Y τ : ℝ) (hε : ε ≤ 1 / 100) :
    ∀ᶠ x : ℝ in atTop, ∀ κ : ℝ,
      roughMass I a D.c D.M D.u ε Y τ κ x ≤
        survivorMass base I a D.c D.M D.u ε Y τ x +
          roughCompositeMass I a D.c D.M D.u ε Y τ κ x +
            discardedMass I a D.c D.M D.u ε Y τ x := by
  have hc : 0 < D.c := by rcases D.c_choice with h | h <;> omega
  filter_upwards [MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax D.c (1 / 2)
      hmin hmax (by norm_num) ha,
    MarkedScaleSupport.eventual_marked_not_dvd I a amin amax hmin hmax ha D.c hc,
    hV, eventually_ge_atTop (2 : ℝ)] with x hP hcP hVx hx
  have hx1 : 1 ≤ x := by linarith
  intro κ
  exact rough_prime_composite_tail_cover D I a ε Y τ κ x (x ^ (1 / 2 : ℝ)) hx
    (Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num))
    (fun p hp => (hP p hp).2.2) hcP
    (fun r hr p hp hpr => MarkedScaleSupport.unmarked_prime_divisor_le I a ε Y τ (1 / 2)
      hx1 (by linarith) hr hp hpr) hVx

/-- The composite term in the cover consists of actual products of two
primes in the narrow strip, including the possibility of a prime square. -/
theorem roughComposite_semiprime_support {κ x : ℝ} {d : ℕ}
    (hx : 1 ≤ x) (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) (hκ : κ ≤ 1 / 100)
    (hd : d ∈ (roughIntegers κ x).filter (fun d => ¬ d.Prime)) :
    ∃ m n : ℕ, m.Prime ∧ n.Prime ∧ m * n = d ∧
      x ^ (1 / 2 - κ) < (m : ℝ) ∧ (m : ℝ) ≤ 2 * x ^ (1 / 2 + κ) ∧
      x ^ (1 / 2 - κ) < (n : ℝ) ∧ (n : ℝ) ≤ 2 * x ^ (1 / 2 + κ) := by
  classical
  obtain ⟨hd, hprime⟩ := Finset.mem_filter.mp hd
  obtain ⟨hd, hrough⟩ := Finset.mem_filter.mp hd
  obtain ⟨hd2, hdupper⟩ := Finset.mem_Icc.mp hd
  have hsize : (d : ℝ) ≤ 2 * x := by
    exact (by exact_mod_cast hdupper : (d : ℝ) ≤ (⌊2 * x⌋₊ : ℝ)).trans
      (Nat.floor_le (by linarith))
  exact RoughFactorization.semiprime_in_narrow_support hx hlarge hκ hd2 hprime hsize hrough

/-- The survivor set has the exact arithmetic support required in the
candidate-data constructor, at the manuscript's actual cofactor scales. -/
theorem eventually_survivors_support {base : ℤ}
    (D : NonresidueProgression.Progression base)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (ε Y τ : ℝ) (hY : 0 ≤ Y) :
    ∀ᶠ x : ℝ in atTop, ∀ p ∈ survivors base I a D.c ε Y τ x,
      p ∈ ambientPrimes x ∧ StructuredCandidate base ⌊Y⌋₊ ⌊x ^ ε⌋₊ p := by
  filter_upwards [MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax Y (1 / 2)
    hmin hmax (by norm_num) ha, eventually_gt_atTop (2 : ℝ)] with x hP hx
  intro p hp
  exact selectedPrimeSurvivors_support_from_cofactors hx hY D.c_choice
    (fun q hq => (hP q hq).2.1) hp

/-- The marking is bounded only at the final conversion to an unweighted
prime count. Its fixed bound depends on the chosen marking family. -/
theorem integerWeight_uniform_bound {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x v₀ : ℝ) (hv₀ : 0 < v₀)
    (hV : ∀ i ∈ I, v₀ ≤ bandMass (a i) x) (d : ℕ) :
    integerWeight I a c M u ε Y τ x d ≤ ∏ _i ∈ I, 1 / v₀ := by
  have hVp : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hV i hi)
  have hb : integerWeight I a c M u ε Y τ x d ≤ ∏ i ∈ I, 1 / bandMass (a i) x :=
    (arithmeticWeight_bounds M u (smoothWeight x) I _ _ _ c _ _ d
      (smoothWeight_bounds x d) hVp).2
  apply hb.trans
  apply Finset.prod_le_prod₀
  · intro i hi
    exact div_nonneg (by norm_num) (hVp i hi).le
  · intro i hi
    exact one_div_le_one_div_of_le hv₀ (hV i hi)

end Artin.ManuscriptCover
