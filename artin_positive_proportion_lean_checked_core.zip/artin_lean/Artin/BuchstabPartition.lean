module

public import Artin.MarkedSource
public import Artin.RoughFactorization
public import Artin.CandidateSieve
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
public import Mathlib.Topology.UniformSpace.HeineCantor
public import Mathlib.Tactic.FieldSimp

/-!
# A finite Buchstab partition and the least-prime cover

The finite partition below is selected from continuity on a compact rectangle.
No Riemann-sum bound or desired partition is an external hypothesis.  The only
Buchstab input in the eventual specialization is continuity, nonnegativity,
and the classical integral identity for the actual density.
-/

@[expose] public section

open MeasureTheory
open scoped BigOperators

namespace Artin.BuchstabPartition

/-- Equally spaced points in logarithmic coordinates. -/
noncomputable def grid (A B : ℝ) (n i : ℕ) : ℝ :=
  A + (B - A) * (i : ℝ) / n

theorem grid_zero (A B : ℝ) (n : ℕ) : grid A B n 0 = A := by
  simp [grid]

theorem grid_last (A B : ℝ) {n : ℕ} (hn : 0 < n) : grid A B n n = B := by
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
  simp [grid, mul_div_cancel_right₀ _ hn0]

theorem grid_step (A B : ℝ) (n i : ℕ) :
    grid A B n (i + 1) - grid A B n i = (B - A) / n := by
  simp only [grid, Nat.cast_add, Nat.cast_one]
  ring

theorem grid_strictMono {A B : ℝ} (hAB : A < B) {n : ℕ} (hn : 0 < n) :
    StrictMono (grid A B n) := by
  intro i j hij
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn
  have hij' : (i : ℝ) < j := by exact_mod_cast hij
  dsimp [grid]
  simpa only [add_comm] using add_lt_add_left (div_lt_div_of_pos_right
    (mul_lt_mul_of_pos_left hij' (sub_pos.mpr hAB)) hn0) A

theorem grid_mem {A B : ℝ} (hAB : A < B) {n : ℕ} (hn : 0 < n)
    {i : ℕ} (hi : i ≤ n) : grid A B n i ∈ Set.Icc A B := by
  have hmono := (grid_strictMono hAB hn).monotone
  constructor
  · simpa only [grid_zero] using hmono (Nat.zero_le i)
  · simpa only [grid_last A B hn] using hmono hi

/-- Any continuous two-variable kernel admits a finite upper partition.
Each coefficient bounds the full vertical section of its bin.  Its total
logarithmic mass is within any prescribed tolerance of the diagonal integral.
The statement deliberately returns explicit majorants; they also bound the
suprema used in the manuscript. -/
theorem exists_upper_partition (F : ℝ × ℝ → ℝ) {A B η : ℝ}
    (hAB : A < B) (hη : 0 < η)
    (hF : ContinuousOn F (Set.Icc A B ×ˢ Set.Icc A B)) :
    ∃ n : ℕ, 0 < n ∧ ∃ coeff : ℕ → ℝ,
      (∀ i < n, ∀ t ∈ Set.Icc (grid A B n i) (grid A B n (i + 1)),
        F (grid A B n i, t) ≤ coeff i) ∧
      (∑ i ∈ Finset.range n, coeff i *
        (grid A B n (i + 1) - grid A B n i)) ≤
        (∫ t in A..B, F (t, t)) + η := by
  let e : ℝ := η / (2 * (B - A + 1))
  have he : 0 < e := by dsimp [e]; positivity
  have huc := (isCompact_Icc.prod isCompact_Icc).uniformContinuousOn_of_continuous hF
  obtain ⟨δ, hδ, hclose⟩ := (Metric.uniformContinuousOn_iff_le.mp huc) e he
  obtain ⟨n, hnlarge⟩ := exists_nat_gt ((B - A) / δ)
  have hn : 0 < n := by
    have : (0 : ℝ) < n := (div_pos (sub_pos.mpr hAB) hδ).trans hnlarge
    exact_mod_cast this
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn
  have hmesh : (B - A) / n < δ := by
    apply (div_lt_iff₀ hn0).mpr
    have hh := (div_lt_iff₀ hδ).mp hnlarge
    nlinarith
  let coeff : ℕ → ℝ := fun i => F (grid A B n i, grid A B n i) + e
  have hdiag : ContinuousOn (fun t : ℝ => F (t, t)) (Set.Icc A B) :=
    hF.comp (continuous_id.prodMk continuous_id).continuousOn (fun _ ht => ⟨ht, ht⟩)
  have hpair : ∀ i < n, ∀ t ∈ Set.Icc (grid A B n i) (grid A B n (i + 1)),
      F (grid A B n i, t) ≤ coeff i ∧ coeff i ≤ F (t, t) + 2 * e := by
    intro i hi t ht
    have hi0 := grid_mem hAB hn (Nat.le_of_lt hi)
    have hi1 := grid_mem hAB hn (Nat.succ_le_of_lt hi)
    have htAB : t ∈ Set.Icc A B := ⟨hi0.1.trans ht.1, ht.2.trans hi1.2⟩
    have hd : dist (grid A B n i) t ≤ δ := by
      rw [Real.dist_eq, abs_of_nonpos (sub_nonpos.mpr ht.1)]
      have hs := grid_step A B n i
      linarith [ht.2]
    have hc₁ := hclose (grid A B n i, t) ⟨hi0, htAB⟩
      (grid A B n i, grid A B n i) ⟨hi0, hi0⟩
      (by simpa only [dist_prod_same_left, dist_comm] using hd)
    have hc₂ := hclose (grid A B n i, grid A B n i) ⟨hi0, hi0⟩
      (t, t) ⟨htAB, htAB⟩ (by simpa only [Prod.dist_eq, max_self] using hd)
    rw [Real.dist_eq] at hc₁ hc₂
    dsimp [coeff]
    constructor <;> linarith [(abs_le.mp hc₁).2, (abs_le.mp hc₂).2]
  have hci : ∀ i < n, IntervalIntegrable (fun t : ℝ => F (t, t) + 2 * e)
      volume (grid A B n i) (grid A B n (i + 1)) := by
    intro i hi
    apply ((hdiag.add continuousOn_const).mono ?_).intervalIntegrable_of_Icc
      ((grid_strictMono hAB hn).monotone (Nat.le_succ i))
    intro t ht
    exact ⟨(grid_mem hAB hn (Nat.le_of_lt hi)).1.trans ht.1,
      ht.2.trans (grid_mem hAB hn (Nat.succ_le_of_lt hi)).2⟩
  have hsum := intervalIntegral.sum_integral_adjacent_intervals hci
  rw [grid_zero, grid_last A B hn] at hsum
  refine ⟨n, hn, coeff, fun i hi t ht => (hpair i hi t ht).1, ?_⟩
  calc
    _ ≤ ∑ i ∈ Finset.range n,
        ∫ t in (grid A B n i)..(grid A B n (i + 1)), F (t, t) + 2 * e := by
      apply Finset.sum_le_sum
      intro i hi
      have hi' := Finset.mem_range.mp hi
      have hm := intervalIntegral.integral_mono_on
        ((grid_strictMono hAB hn).monotone (Nat.le_succ i))
        (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => coeff i)
          volume (grid A B n i) (grid A B n (i + 1)))
        (hci i hi') (fun t ht => (hpair i hi' t ht).2)
      simpa only [intervalIntegral.integral_const, smul_eq_mul, mul_comm] using hm
    _ = ∫ t in A..B, F (t, t) + 2 * e := hsum
    _ = (∫ t in A..B, F (t, t)) + (B - A) * (2 * e) := by
      rw [intervalIntegral.integral_add (hdiag.intervalIntegrable_of_Icc hAB.le)
        intervalIntegrable_const, intervalIntegral.integral_const, smul_eq_mul]
    _ ≤ (∫ t in A..B, F (t, t)) + η := by
      have hden : 0 < 2 * (B - A + 1) := by linarith
      have heq : e * (2 * (B - A + 1)) = η := by
        dsimp [e]
        exact div_mul_cancel₀ _ hden.ne'
      nlinarith

/-- The actual two-variable density after the elementary change of variables
`t = exp u`. -/
noncomputable def logKernel (z : ℝ × ℝ) : ℝ :=
  MarkedSource.density (Real.exp z.1) (1 - Real.exp z.2)

/-- Classical Buchstab facts for the exact simplex density of (10.11).
These are source hypotheses, not axioms. The identity is the standard
Buchstab identity after substituting `t = exp u`; it does not assert anything
about finite partitions or arithmetic bin counts. -/
structure ClassicalBuchstabFacts : Prop where
  continuous : ∀ b : ℝ, 0 < b → b < 1 / 2 →
    ContinuousOn logKernel
      (Set.Icc (Real.log b) (Real.log (1 / 2)) ×ˢ
        Set.Icc (Real.log b) (Real.log (1 / 2)))
  nonnegative : ∀ γ s : ℝ, 0 < γ → γ ≤ s → 0 ≤ MarkedSource.density γ s
  integral_identity : ∀ b : ℝ, 0 < b → b < 1 / 2 →
    (∫ u in Real.log b..Real.log (1 / 2), logKernel (u, u)) =
      MarkedSource.density b 1 - 1

/-- A finite exponent partition with coefficients majorizing the complete
density section of each bin. The logarithmic upper sum has the manuscript's
required cancellation bound. -/
structure DensityPartition (b c η : ℝ) where
  bins : ℕ
  bins_pos : 0 < bins
  endpoint : ℕ → ℝ
  endpoint_zero : endpoint 0 = b
  endpoint_last : endpoint bins = c
  increasing : StrictMono endpoint
  positive : ∀ i, 0 < endpoint i
  coefficient : ℕ → ℝ
  coefficient_nonnegative : ∀ i < bins, 0 ≤ coefficient i
  majorant : ∀ i < bins, ∀ t ∈ Set.Icc (endpoint i) (endpoint (i + 1)),
    MarkedSource.density (endpoint i) (1 - t) ≤ coefficient i
  total_bound : (∑ i ∈ Finset.range bins,
    coefficient i * Real.log (endpoint (i + 1) / endpoint i)) ≤
      MarkedSource.density b 1 - 1 + η

/-- Select the fixed finite partition from the classical continuity and
integral identity. In particular, taking `η = 1/20` supplies the missing
partition premise in the finite Buchstab subtraction theorem. -/
theorem exists_densityPartition (classicalFacts : ClassicalBuchstabFacts)
    {b c η : ℝ} (hb : 0 < b) (hbc : b < c) (hc : c ≤ 1 / 2) (hη : 0 < η) :
    Nonempty (DensityPartition b c η) := by
  have hc0 : 0 < c := hb.trans hbc
  have hbhalf : b < 1 / 2 := hbc.trans_le hc
  have hAB : Real.log b < Real.log c := Real.log_lt_log hb hbc
  have hBH : Real.log c ≤ Real.log (1 / 2) := Real.log_le_log hc0 hc
  have hrect := classicalFacts.continuous b hb hbhalf
  have hsub : Set.Icc (Real.log b) (Real.log c) ×ˢ
      Set.Icc (Real.log b) (Real.log c) ⊆
      Set.Icc (Real.log b) (Real.log (1 / 2)) ×ˢ
      Set.Icc (Real.log b) (Real.log (1 / 2)) := by
    intro z hz
    exact ⟨⟨hz.1.1, hz.1.2.trans hBH⟩, ⟨hz.2.1, hz.2.2.trans hBH⟩⟩
  obtain ⟨n, hn, coeff, hmajor, hsum⟩ := exists_upper_partition logKernel hAB hη
    (hrect.mono hsub)
  let t : ℕ → ℝ := grid (Real.log b) (Real.log c) n
  let endpoint : ℕ → ℝ := fun i => Real.exp (t i)
  have hmono : StrictMono endpoint := Real.exp_strictMono.comp (grid_strictMono hAB hn)
  have hzero : endpoint 0 = b := by simp [endpoint, t, grid_zero, Real.exp_log hb]
  have hlast : endpoint n = c := by simp [endpoint, t, grid_last _ _ hn, Real.exp_log hc0]
  have hdiagonal : ContinuousOn (fun u : ℝ => logKernel (u, u))
      (Set.Icc (Real.log b) (Real.log (1 / 2))) :=
    hrect.comp (continuous_id.prodMk continuous_id).continuousOn (fun _ hu => ⟨hu, hu⟩)
  have hleft : IntervalIntegrable (fun u : ℝ => logKernel (u, u)) volume
      (Real.log b) (Real.log c) := (hdiagonal.mono (show Set.Icc (Real.log b) (Real.log c) ⊆
      Set.Icc (Real.log b) (Real.log (1 / 2)) from
      fun _ hu => ⟨hu.1, hu.2.trans hBH⟩)).intervalIntegrable_of_Icc hAB.le
  have hright : IntervalIntegrable (fun u : ℝ => logKernel (u, u)) volume
      (Real.log c) (Real.log (1 / 2)) := (hdiagonal.mono (show Set.Icc (Real.log c) (Real.log (1 / 2)) ⊆
      Set.Icc (Real.log b) (Real.log (1 / 2)) from
      fun _ hu => ⟨hAB.le.trans hu.1, hu.2⟩)).intervalIntegrable_of_Icc hBH
  have hright0 : 0 ≤ ∫ u in Real.log c..Real.log (1 / 2), logKernel (u, u) := by
    apply intervalIntegral.integral_nonneg hBH
    intro u hu
    apply classicalFacts.nonnegative _ _ (Real.exp_pos _)
    have h := Real.exp_le_exp.mpr hu.2
    rw [Real.exp_log (by norm_num : (0 : ℝ) < 1 / 2)] at h
    linarith
  have hintegral : (∫ u in Real.log b..Real.log c, logKernel (u, u)) ≤
      MarkedSource.density b 1 - 1 := by
    have hadd := intervalIntegral.integral_add_adjacent_intervals hleft hright
    rw [classicalFacts.integral_identity b hb hbhalf] at hadd
    linarith
  have hmajor' : ∀ i < n, ∀ v ∈ Set.Icc (endpoint i) (endpoint (i + 1)),
      MarkedSource.density (endpoint i) (1 - v) ≤ coeff i := by
    intro i hi v hv
    have hv0 : 0 < v := (Real.exp_pos _).trans_le hv.1
    have hl : Real.log v ∈ Set.Icc (t i) (t (i + 1)) := by
      constructor
      · have h := Real.log_le_log (Real.exp_pos (t i)) hv.1
        simpa only [endpoint, Real.log_exp] using h
      · have h := Real.log_le_log hv0 hv.2
        simpa only [endpoint, Real.log_exp] using h
    have h := hmajor i hi (Real.log v) hl
    simpa only [logKernel, Real.exp_log hv0] using h
  refine ⟨⟨n, hn, endpoint, hzero, hlast, hmono, fun i => Real.exp_pos _,
    coeff, ?_, hmajor', ?_⟩⟩
  · intro i hi
    have hi1 : endpoint i ≤ c := by
      simpa only [hlast] using hmono.monotone (Nat.le_of_lt hi)
    have hnonneg := classicalFacts.nonnegative (endpoint i) (1 - endpoint i)
      (Real.exp_pos _) (by linarith)
    exact hnonneg.trans (hmajor' i hi (endpoint i)
      ⟨le_rfl, hmono.monotone (Nat.le_succ i)⟩)
  · have hlog : ∀ i, Real.log (endpoint (i + 1) / endpoint i) =
        t (i + 1) - t i := by
      intro i
      rw [Real.log_div (Real.exp_ne_zero _) (Real.exp_ne_zero _)]
      simp only [Real.log_exp]
    simp only [hlog]
    exact hsum.trans (by linarith)

/-- Every point between the first and last endpoint belongs to a bin.
This induction does not require a choice of a least real-valued index. -/
theorem exists_bin {cut : ℕ → ℝ} {n : ℕ} {r : ℝ}
    (hfirst : cut 0 < r) (hlast : r ≤ cut n) :
    ∃ i < n, cut i < r ∧ r ≤ cut (i + 1) := by
  induction n with
  | zero => exact (not_lt_of_ge hlast hfirst).elim
  | succ n ih =>
      by_cases hr : r ≤ cut n
      · obtain ⟨i, hi, hleft, hright⟩ := ih hr
        exact ⟨i, Nat.lt_succ_of_lt hi, hleft, hright⟩
      · exact ⟨n, Nat.lt_succ_self n, lt_of_not_ge hr, hlast⟩

/-- Roughness is expressed in terms of actual prime divisors. -/
def IsRough (z : ℝ) (d : ℕ) : Prop :=
  ∀ p : ℕ, p.Prime → p ∣ d → z < (p : ℝ)

/-- The exact factor condition counted by a Buchstab bin. The complementary
factor may contain the distinguished prime again, so prime squares are kept. -/
def InBin (lo hi : ℝ) (d : ℕ) : Prop :=
  ∃ p m : ℕ, p.Prime ∧ lo < (p : ℝ) ∧ (p : ℝ) ≤ hi ∧
    m * p = d ∧ IsRough lo m

/-- The least prime factor gives an actual bin factorization for every
integer removed when the roughness threshold increases. -/
theorem least_prime_cover {cut : ℕ → ℝ} {n d : ℕ}
    (hd : 2 ≤ d) (hfirst : IsRough (cut 0) d)
    (hlast : ¬ IsRough (cut n) d) :
    ∃ i < n, InBin (cut i) (cut (i + 1)) d := by
  have hdp : (Nat.minFac d).Prime := Nat.minFac_prime (by omega)
  have hdiv : Nat.minFac d ∣ d := Nat.minFac_dvd d
  have hlow : cut 0 < (Nat.minFac d : ℝ) := hfirst _ hdp hdiv
  have hupp : (Nat.minFac d : ℝ) ≤ cut n := by
    by_contra hn
    apply hlast
    intro p hp hpd
    have hmin : Nat.minFac d ≤ p := Nat.minFac_le_of_dvd hp.two_le hpd
    exact (lt_of_not_ge hn).trans_le (by exact_mod_cast hmin)
  obtain ⟨i, hi, hleft, hright⟩ := exists_bin hlow hupp
  refine ⟨i, hi, Nat.minFac d, d / Nat.minFac d, hdp, hleft, hright,
    Nat.div_mul_cancel hdiv, ?_⟩
  intro p hp hpm
  have hpd : p ∣ d := hpm.trans (Nat.div_dvd_of_dvd hdiv)
  have hmin : Nat.minFac d ≤ p := Nat.minFac_le_of_dvd hp.two_le hpd
  exact hleft.trans_le (by exact_mod_cast hmin)

/-- Actual finite rough-number and bin masses, with arbitrary nonnegative
weights. These sums retain the marked weights without a supremum bound. -/
noncomputable def roughMass (D : Finset ℕ) (w : ℕ → ℝ) (z : ℝ) : ℝ := by
  classical
  exact ∑ d ∈ D, if IsRough z d then w d else 0

noncomputable def binMass (D : Finset ℕ) (w : ℕ → ℝ) (lo hi : ℝ) : ℝ := by
  classical
  exact ∑ d ∈ D, if InBin lo hi d then w d else 0

/-- The combinatorial subtraction inequality for the actual finite weighted
sets. Every nonsurvivor is charged to one bin using its least prime factor. -/
theorem weighted_least_prime_cover (D : Finset ℕ) (w : ℕ → ℝ)
    (cut : ℕ → ℝ) (n : ℕ) (hD : ∀ d ∈ D, 2 ≤ d)
    (hw : ∀ d ∈ D, 0 ≤ w d) :
    roughMass D w (cut 0) ≤ roughMass D w (cut n) +
      ∑ i ∈ Finset.range n, binMass D w (cut i) (cut (i + 1)) := by
  classical
  unfold roughMass binMass
  rw [Finset.sum_comm (s := Finset.range n) (t := D), ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro d hd
  have hsum0 : 0 ≤ ∑ i ∈ Finset.range n,
      if InBin (cut i) (cut (i + 1)) d then w d else 0 :=
    Finset.sum_nonneg (fun i _ => by split_ifs <;> positivity [hw d hd])
  by_cases hfirst : IsRough (cut 0) d
  · simp only [ite_eq_left hfirst]
    by_cases hlast : IsRough (cut n) d
    · simp only [ite_eq_left hlast]
      linarith
    · simp only [ite_eq_right hlast, zero_add]
      obtain ⟨i, hi, hbin⟩ := least_prime_cover (hD d hd) hfirst hlast
      have hsingle := Finset.single_le_sum
        (f := fun j => if InBin (cut j) (cut (j + 1)) d then w d else 0)
        (fun j (_hj : j ∈ Finset.range n) => by split_ifs <;> positivity [hw d hd])
        (Finset.mem_range.mpr hi)
      simpa only [ite_eq_left hbin] using hsingle
  · simp only [ite_eq_right hfirst]
    split_ifs <;> linarith [hw d hd]

/-- The exact density supremum occurring in the manuscript's bin coefficient. -/
noncomputable def densitySup (lo hi : ℝ) : ℝ :=
  sSup ((fun t : ℝ => MarkedSource.density lo (1 - t)) '' Set.Icc lo hi)

theorem densitySup_le {lo hi C : ℝ} (hlohi : lo ≤ hi)
    (hC : ∀ t ∈ Set.Icc lo hi, MarkedSource.density lo (1 - t) ≤ C) :
    densitySup lo hi ≤ C := by
  apply csSup_le
  · exact ⟨_, lo, ⟨le_rfl, hlohi⟩, rfl⟩
  · rintro y ⟨t, ht, rfl⟩
    exact hC t ht

/-- The selected majorants also give the upper-supremum sum written in the
paper, with precisely the logarithmic bin lengths. -/
theorem DensityPartition.supremum_total_bound {b c η : ℝ}
    (P : DensityPartition b c η) :
    (∑ i ∈ Finset.range P.bins,
      densitySup (P.endpoint i) (P.endpoint (i + 1)) *
        Real.log (P.endpoint (i + 1) / P.endpoint i)) ≤
      MarkedSource.density b 1 - 1 + η := by
  apply le_trans _ P.total_bound
  apply Finset.sum_le_sum
  intro i hi
  have hinc := P.increasing.monotone (Nat.le_succ i)
  apply mul_le_mul_of_nonneg_right
    (densitySup_le hinc (P.majorant i (Finset.mem_range.mp hi)))
  exact Real.log_nonneg ((one_le_div (P.positive i)).mpr hinc)

/-- A completely explicit finite version of the manuscript's double factor
sum. The product weight is retained, and repeated prime factors are allowed. -/
noncomputable def factorBinMass (N : ℕ) (w : ℕ → ℝ) (lo hi : ℝ) : ℝ := by
  classical
  exact ∑ pm ∈ (Finset.range (N + 1)).product (Finset.range (N + 1)),
    if pm.1.Prime ∧ lo < (pm.1 : ℝ) ∧ (pm.1 : ℝ) ≤ hi ∧ IsRough lo pm.2
    then w (pm.2 * pm.1) else 0

open scoped Classical in
theorem factorBinMass_eq_double_sum (N : ℕ) (w : ℕ → ℝ) (lo hi : ℝ) :
    factorBinMass N w lo hi =
      ∑ p ∈ Finset.range (N + 1), ∑ m ∈ Finset.range (N + 1),
        if p.Prime ∧ lo < (p : ℝ) ∧ (p : ℝ) ≤ hi ∧ IsRough lo m
        then w (m * p) else 0 := by
  classical
  exact Finset.sum_product _ _ _

/-- The existential bin count is bounded by the actual double factor sum.
The proof covers its integers by the product image, and accounts correctly
for possible multiple factorizations by nonnegativity. -/
theorem binMass_le_factorBinMass (D : Finset ℕ) (w : ℕ → ℝ) (N : ℕ)
    (lo hi : ℝ) (hD : ∀ d ∈ D, 2 ≤ d ∧ d ≤ N) (hw : ∀ d, 0 ≤ w d) :
    binMass D w lo hi ≤ factorBinMass N w lo hi := by
  classical
  let pairs := ((Finset.range (N + 1)).product (Finset.range (N + 1))).filter
    (fun pm : ℕ × ℕ => pm.1.Prime ∧ lo < (pm.1 : ℝ) ∧
      (pm.1 : ℝ) ≤ hi ∧ IsRough lo pm.2)
  let products := pairs.image (fun pm => pm.2 * pm.1)
  have hsub : D.filter (InBin lo hi) ⊆ products := by
    intro d hd
    obtain ⟨hdD, p, m, hp, hlo, hhi, heq, hmrough⟩ := Finset.mem_filter.mp hd
    have hd0 := (hD d hdD).1
    have hdN := (hD d hdD).2
    have hm : 1 ≤ m := by
      by_contra hh
      have hm0 : m = 0 := by omega
      simp only [hm0, zero_mul] at heq
      omega
    have hpN : p ≤ N := by nlinarith [hp.two_le]
    have hmN : m ≤ N := by nlinarith [hp.two_le]
    apply Finset.mem_image.mpr
    refine ⟨(p, m), ?_, heq⟩
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_product.mpr ⟨Finset.mem_range.mpr (by omega),
      Finset.mem_range.mpr (by omega)⟩, hp, hlo, hhi, hmrough⟩
  have h₁ : (∑ d ∈ D.filter (InBin lo hi), w d) ≤ ∑ d ∈ products, w d :=
    Finset.sum_le_sum_of_subset_of_nonneg hsub (fun d _ _ => hw d)
  have h₂ : (∑ d ∈ products, w d) ≤ ∑ pm ∈ pairs, w (pm.2 * pm.1) :=
    Finset.sum_image_le_of_nonneg (fun d _ => hw d)
  simpa only [binMass, factorBinMass, pairs, Finset.sum_filter] using h₁.trans h₂

/-- The actual rough-number subtraction into the finite double sums to
which marked replacement is applied. No bin-cover estimate is assumed. -/
theorem weighted_factor_bin_cover (D : Finset ℕ) (w : ℕ → ℝ)
    (cut : ℕ → ℝ) (n N : ℕ) (hD : ∀ d ∈ D, 2 ≤ d ∧ d ≤ N)
    (hw : ∀ d, 0 ≤ w d) :
    roughMass D w (cut 0) ≤ roughMass D w (cut n) +
      ∑ i ∈ Finset.range n, factorBinMass N w (cut i) (cut (i + 1)) := by
  apply (weighted_least_prime_cover D w cut n (fun d hd => (hD d hd).1)
    (fun d _ => hw d)).trans
  apply add_le_add_right
  exact Finset.sum_le_sum (fun i _ => binMass_le_factorBinMass D w N _ _ hD hw)

/-- Apply the existing limiting subtraction to the actual rough and factor
sums. The finite partition and the combinatorial cover are proved above;
only the initial-sieve and marked-bin analytic estimates remain premises.
The partition is fixed before the scale variable, as required for a common
eventual threshold over its finitely many bins. -/
theorem rough_lower_of_actual_bin_estimates {b c B E errorS errorD : ℝ}
    (P : DensityPartition b c (1 / 20))
    (D : ℝ → Finset ℕ) (w : ℝ → ℕ → ℝ) (N : ℝ → ℕ)
    (mass e₀ : ℝ → ℝ) (errors : ℕ → ℝ → ℝ)
    (hDensity : MarkedSource.density b 1 ≤ B * (1 + errorD))
    (herror : B * (errorS + errorD) ≤ 1 / 10)
    (hE : 1 ≤ E) (hlocal : (E - 1) * (MarkedSource.density b 1 + 1) ≤ 1 / 10)
    (he₀ : Filter.Tendsto e₀ Filter.atTop (nhds 0))
    (herrors : ∀ i < P.bins, Filter.Tendsto (errors i) Filter.atTop (nhds 0))
    (hmass : ∀ᶠ x in Filter.atTop, 0 ≤ mass x)
    (hD : ∀ᶠ x in Filter.atTop, ∀ d ∈ D x, 2 ≤ d ∧ d ≤ N x)
    (hw : ∀ᶠ x in Filter.atTop, ∀ d, 0 ≤ w x d)
    (hinitial : ∀ᶠ x in Filter.atTop,
      (B * (1 - errorS) + e₀ x) * mass x ≤ roughMass (D x) (w x) (x ^ b))
    (hbins : ∀ i < P.bins, ∀ᶠ x in Filter.atTop,
      factorBinMass (N x) (w x) (x ^ P.endpoint i) (x ^ P.endpoint (i + 1)) ≤
        (E * (densitySup (P.endpoint i) (P.endpoint (i + 1)) *
          Real.log (P.endpoint (i + 1) / P.endpoint i)) + errors i x) * mass x) :
    ∃ e : ℝ → ℝ, Filter.Tendsto e Filter.atTop (nhds 0) ∧
      ∀ᶠ x in Filter.atTop,
        ((3 : ℝ) / 4 + e x) * mass x ≤ roughMass (D x) (w x) (x ^ c) := by
  apply Artin.buchstab_finite_partition_subtraction (Finset.range P.bins)
    hDensity herror hE hlocal P.supremum_total_bound he₀
    (fun i hi => herrors i (Finset.mem_range.mp hi)) hmass hinitial
    (fun i hi => hbins i (Finset.mem_range.mp hi))
  filter_upwards [hD, hw] with x hd hwx
  simpa only [P.endpoint_zero, P.endpoint_last] using
    weighted_factor_bin_cover (D x) (w x) (fun i => x ^ P.endpoint i)
      P.bins (N x) hd hwx

end Artin.BuchstabPartition
