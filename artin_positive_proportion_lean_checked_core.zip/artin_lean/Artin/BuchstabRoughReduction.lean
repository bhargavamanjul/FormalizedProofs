module

public import Artin.BuchstabBinEstimate

/-!
# One marking threshold for the fixed partition and finite subtraction
-/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace Artin.BuchstabRoughReduction

open MarkedSource RoughCompanion SemiprimeMR BuchstabMR BuchstabBoxes
  BuchstabBinEstimate BuchstabPartition

/-- A proved bin estimate, packaged for selecting a common number of marks.
This predicate is not an accepted source: the theorem below constructs it
from the explicit dyadic and source application. -/
def BinEstimate {K : ℕ} (bands : Bands K) (M u : ℕ) (Ψ : ℝ → ℝ)
    (γ γ' C₀ : ℝ) : Prop :=
  ∀ η : ℝ, 0 < η → ∃ C : ℝ, 0 < C ∧
    ∀ᶠ x : ℝ in atTop, ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (N : ℕ),
      factorBinMass N (actualWeight bands M u Ψ x c allowed Qmin) (x ^ γ) (x ^ γ') ≤
        (C₀ + η) / (Real.log x * eulerV (W x)) *
          conditionedMass (ambient x) (primeBin x γ γ')
            (actualWeight bands M u Ψ x c allowed Qmin) (W x) +
        C * x * (Real.log x) ^ (-5 : ℝ)

/-- The maximum over the fixed finite partition chooses `K₀` before every
marking, tolerance, and cofactor-selector parameter. -/
theorem partition_bin_estimates_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hcontinuity : ClassicalDensityContinuity)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨsmooth : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {b κ tolerance : ℝ} (hb : 0 < b) (hκ : 0 < κ)
    (P : DensityPartition b (1 / 2 - κ) tolerance) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ bands : Bands K,
      ∀ i : Fin P.bins,
        BinEstimate bands M u Ψ (P.endpoint i) (P.endpoint (i + 1)) (P.coefficient i) := by
  classical
  have each : ∀ i : Fin P.bins, ∃ K₀ : ℕ, 1 ≤ K₀ ∧
      ∀ K : ℕ, K₀ ≤ K → ∀ bands : Bands K,
        BinEstimate bands M u Ψ (P.endpoint i) (P.endpoint (i + 1)) (P.coefficient i) := by
    intro i
    have hbg : b ≤ P.endpoint i := by
      simpa only [P.endpoint_zero] using P.increasing.monotone (Nat.zero_le i.val)
    have hgg := P.increasing.monotone (Nat.le_succ i.val)
    have hgupper : P.endpoint (i + 1) ≤ 1 / 2 - κ := by
      simpa only [P.endpoint_last] using P.increasing.monotone (Nat.succ_le_of_lt i.isLt)
    exact actual_bin_upper_from_sources h102 h103 hbands hFourier hcontinuity
      M u hu hunit Ψ hΨsmooth hΨ hsupport b κ (P.endpoint i) (P.endpoint (i + 1))
      (P.coefficient i) hb hκ hbg hgg hgupper (P.coefficient_nonnegative i i.isLt)
      (P.majorant i i.isLt)
  choose threshold hthreshold hbin using each
  let K₀ := Finset.univ.sup threshold
  have hle : ∀ i : Fin P.bins, threshold i ≤ K₀ :=
    fun i => Finset.le_sup (Finset.mem_univ i)
  refine ⟨K₀, (hthreshold ⟨0, P.bins_pos⟩).trans (hle _), ?_⟩
  intro K hK bands i
  exact hbin i K ((hle i).trans hK) bands

/-- Finite subtraction with the numerical margin exposed. All errors may
depend on the fixed arithmetic parameters; the finite partition is chosen
before their scale variable. -/
theorem finite_subtraction_with_margin {ι : Type*} (I : Finset ι)
    (mass initial rough e₀ : ℝ → ℝ) (bins errors : ι → ℝ → ℝ)
    (coeff : ι → ℝ) {B E : ℝ}
    (hmargin : (3 : ℝ) / 4 ≤ B - E * ∑ i ∈ I, coeff i)
    (he₀ : Tendsto e₀ atTop (𝓝 0))
    (herrors : ∀ i ∈ I, Tendsto (errors i) atTop (𝓝 0))
    (hmass : ∀ᶠ x in atTop, 0 ≤ mass x)
    (hinitial : ∀ᶠ x in atTop, (B + e₀ x) * mass x ≤ initial x)
    (hbins : ∀ i ∈ I, ∀ᶠ x in atTop, bins i x ≤ (E * coeff i + errors i x) * mass x)
    (hcover : ∀ᶠ x in atTop, initial x ≤ rough x + ∑ i ∈ I, bins i x) :
    ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧
      ∀ᶠ x in atTop, ((3 : ℝ) / 4 + e x) * mass x ≤ rough x := by
  let e := fun x => e₀ x - ∑ i ∈ I, errors i x
  have hsumzero : Tendsto (fun x => ∑ i ∈ I, errors i x) atTop (𝓝 0) := by
    simpa only [Finset.sum_const_zero] using tendsto_finsetSum I herrors
  have he : Tendsto e atTop (𝓝 0) := by
    simpa only [e, sub_zero] using he₀.sub hsumzero
  have hbins' : ∀ᶠ x in atTop, ∀ i ∈ I,
      bins i x ≤ (E * coeff i + errors i x) * mass x :=
    (eventually_all_finset I).2 hbins
  refine ⟨e, he, ?_⟩
  filter_upwards [hmass, hinitial, hbins', hcover] with x hm hi hb hc
  have hsum := Finset.sum_le_sum hb
  have hsum' : (∑ i ∈ I, bins i x) ≤
      (E * ∑ i ∈ I, coeff i + ∑ i ∈ I, errors i x) * mass x := by
    calc
      _ ≤ (∑ i ∈ I, (E * coeff i + errors i x)) * mass x := by
        rw [Finset.sum_mul]
        exact hsum
      _ = _ := by rw [Finset.sum_add_distrib, ← Finset.mul_sum]
  have hbound := mul_le_mul_of_nonneg_right hmargin hm
  dsimp [e]
  nlinarith only [hbound, hi, hsum', hc]

end Artin.BuchstabRoughReduction
