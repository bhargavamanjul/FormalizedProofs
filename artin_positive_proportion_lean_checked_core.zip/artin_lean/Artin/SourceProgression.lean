module

public import Artin.NonresidueProgression

/-!
# The permitted progression input is already a cited theorem

OpenAI, *Primitive roots for every admissible integer base* (4 October 2026),
Lemma 2.4, states the required progression, including all conditions (2.1).
The source's residue class is represented by its canonical natural number
`u < M`. This is a transcription of that cited finite residue-class result,
not an assumption about the manuscript's new sieve or positive proportion.

The independent partial Jacobi construction remains in
`NonresidueProgression`, but completing it is unnecessary under the user's
permission to accept the cited Lemma 2.4. No global axiom is declared here.
-/

@[expose] public section
namespace Artin.NonresidueProgression

/-- The cited nonresidue progression theorem, with a canonical representative.
The source also specifies M and asserts `p ∤ a`; neither strengthening is
needed by the manuscript and both are omitted here. -/
def SourceLemma2_4 : Prop :=
  ∀ a : ℤ, Admissible a → ∃ M c u : ℕ,
    0 < M ∧ 8 ∣ M ∧ u < M ∧ (c = 2 ∨ c = 4) ∧
    Nat.Coprime u M ∧ c ∣ u - 1 ∧
    Nat.Coprime ((u - 1) / c) (M / c) ∧
    ∀ (p : ℕ) (hp : p.Prime), Nat.ModEq M p u →
      @legendreSym p ⟨hp⟩ a = -1

/-- The accepted Legendre-symbol statement supplies precisely the actual
progression used by the weight. Conversion to nonsquareness is proved by
Mathlib's finite-field characterization of the Legendre symbol. -/
theorem progression_of_source (source : SourceLemma2_4) {a : ℤ} (ha : Admissible a) :
    Nonempty (Progression a) := by
  obtain ⟨M, c, u, hM, h8, hu, hc, hunit, hdiv, hquot, hsign⟩ := source a ha
  refine ⟨⟨M, c, u, hu, hM, h8, hc, hunit, hdiv, hquot, ?_⟩⟩
  intro p hp hpu
  let : Fact p.Prime := ⟨hp⟩
  exact (legendreSym.eq_neg_one_iff p).mp (hsign p hp hpu)

end Artin.NonresidueProgression
