module

public import Artin.CofactorAsymptotics
public import Artin.ConcreteSelector
public import Mathlib.Data.Nat.Factorization.Basic

/-!
# Reciprocal moments of actual marked-supported integers

The finite exponent box is obtained from the given finite set of integers.
Unique factorization embeds the integers into that box, so the geometric
Euler-product estimate bounds actual integer mass, retaining all prime powers.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.MarkedPowerMass

theorem supported_product {P : Finset ℕ} {n : ℕ} (hn : 0 < n)
    (hs : n.primeFactors ⊆ P) : (∏ p ∈ P, p ^ n.factorization p) = n := by
  classical
  calc
    (∏ p ∈ P, p ^ n.factorization p) =
        ∏ p ∈ n.primeFactors, p ^ n.factorization p := by
      symm
      apply Finset.prod_subset hs
      intro p hp hpn
      have hz : n.factorization p = 0 := Finsupp.notMem_support_iff.mp hpn
      simp [hz]
    _ = n := (Nat.prod_primeFactors_pow_factorization (Nat.ne_of_gt hn)).symm

theorem supported_exp_ratio_product (P : Finset ℕ) (n : ℕ) (v : ℝ)
    (hp : ∀ p ∈ P, Nat.Prime p) (hn : 0 < n) (hs : n.primeFactors ⊆ P) :
    (∏ p ∈ P, (Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ^ n.factorization p) =
      Real.exp (v * Real.log (n : ℝ)) / (n : ℝ) := by
  have hprod : (∏ p ∈ P, (p : ℝ) ^ n.factorization p) = (n : ℝ) := by
    exact_mod_cast supported_product hn hs
  have hlog : (∑ p ∈ P, (n.factorization p : ℝ) * Real.log (p : ℝ)) =
      Real.log (n : ℝ) := by
    rw [← hprod, Real.log_prod]
    · simp only [Real.log_pow]
    · intro p hpm
      exact pow_ne_zero _ (Nat.cast_ne_zero.mpr (hp p hpm).ne_zero)
  simp_rw [div_pow]
  rw [Finset.prod_div_distrib, hprod]
  congr 1
  simp_rw [← Real.exp_nat_mul]
  rw [← Real.exp_sum]
  congr 1
  calc
    (∑ p ∈ P, (n.factorization p : ℝ) * (v * Real.log (p : ℝ))) =
        v * (∑ p ∈ P, (n.factorization p : ℝ) * Real.log (p : ℝ)) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro p hp
      ring
    _ = v * Real.log (n : ℝ) := by rw [hlog]


/-- A finite family admits one exponent cutoff for every allowed prime. -/
theorem exists_exponent_cutoff (S P : Finset ℕ) :
    ∃ M : ℕ, ∀ n ∈ S, ∀ p ∈ P, n.factorization p < M := by
  refine ⟨S.sup (fun n => P.sup n.factorization) + 1, ?_⟩
  intro n hn p hp
  have hp' : n.factorization p ≤ P.sup n.factorization := Finset.le_sup hp
  have hn' : P.sup n.factorization ≤ S.sup (fun n => P.sup n.factorization) :=
    Finset.le_sup (f := fun n => P.sup n.factorization) hn
  omega

/-- The restricted factorization still determines every positive supported
integer, with no squarefreeness assumption. -/
theorem restricted_factorization_injective (S P : Finset ℕ)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P) :
    Function.Injective (fun n : S => fun p : P => n.val.factorization p.val) := by
  intro n m h
  apply Subtype.ext
  apply Nat.eq_of_factorization_eq (hpos n.val n.property).ne'
    (hpos m.val m.property).ne'
  intro p
  by_cases hp : p ∈ P
  · exact congrFun h ⟨p, hp⟩
  · have hn : n.val.factorization p = 0 := by
      apply Finsupp.notMem_support_iff.mp
      rw [Nat.support_factorization]
      exact fun hh => hp (hsupport n.val n.property hh)
    have hm : m.val.factorization p = 0 := by
      apply Finsupp.notMem_support_iff.mp
      rw [Nat.support_factorization]
      exact fun hh => hp (hsupport m.val m.property hh)
    rw [hn, hm]

/-- The actual factorization vectors of the finite family are dominated by
the complete finite exponent box. -/
theorem factorization_product_sum_le (S P : Finset ℕ) (r : ℕ → ℝ)
    (M : ℕ) (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P)
    (hcutoff : ∀ n ∈ S, ∀ p ∈ P, n.factorization p < M)
    (hr : ∀ p ∈ P, 0 ≤ r p) :
    (∑ n ∈ S, ∏ p ∈ P, r p ^ n.factorization p) ≤
      ∑ e : P → Fin M, ∏ p : P, r p.val ^ (e p).val := by
  classical
  let encode : S → (P → Fin M) := fun n p =>
    ⟨n.val.factorization p.val, hcutoff n.val n.property p.val p.property⟩
  have hinj : Function.Injective encode := by
    intro n m h
    apply restricted_factorization_injective S P hpos hsupport
    funext p
    exact congrArg Fin.val (congrFun h p)
  calc
    (∑ n ∈ S, ∏ p ∈ P, r p ^ n.factorization p) =
        ∑ n : S, ∏ p : P, r p.val ^ (encode n p).val := by
      change (∑ n ∈ S, ∏ p ∈ P, r p ^ n.factorization p) =
        ∑ n : S, ∏ p : P, r p.val ^ n.val.factorization p.val
      calc
        _ = ∑ n : S, ∏ p ∈ P, r p ^ n.val.factorization p :=
          (Finset.sum_coe_sort S (fun n => ∏ p ∈ P, r p ^ n.factorization p)).symm
        _ = _ := by
          apply Finset.sum_congr rfl
          intro n hn
          exact (Finset.prod_coe_sort P (fun p => r p ^ n.val.factorization p)).symm
    _ = ∑ e ∈ Finset.univ.image encode, ∏ p : P, r p.val ^ (e p).val := by
      rw [Finset.sum_image]
      exact fun n _ m _ h => hinj h
    _ ≤ ∑ e : P → Fin M, ∏ p : P, r p.val ^ (e p).val := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      intro e he hne
      exact Finset.prod_nonneg (fun p hp => pow_nonneg (hr p.val p.property) _)

/-- Uniform exponential reciprocal moment for an actual finite set of positive
integers supported on `P`. The exponent cutoff is derived from `S`, and the
bound is independent of both that cutoff and the size of `S`. -/
theorem finite_supported_power_moment (S P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P)
    (hW₀ : 0 ≤ W₀) (hW : ∀ n ∈ S, W n ≤ W₀)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S, W n / (n : ℝ) * Real.exp (v * Real.log (n : ℝ))) ≤
      W₀ * Real.exp (2 * B) := by
  classical
  obtain ⟨M, hM⟩ := exists_exponent_cutoff S P
  let r : ℕ → ℝ := fun p => Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)
  have hr : ∀ p ∈ P, 0 ≤ r p := fun p hp => by
    dsimp [r]
    positivity
  have hbox := factorization_product_sum_le S P r M hpos hsupport hM hr
  have hbound := CofactorAsymptotics.bounded_power_moment
    (fun p : P => r p.val) M (fun _ => W₀) W₀ B hW₀ (fun _ => le_rfl)
    (fun p => hr p.val p.property) (fun p => hratio p.val p.property) ?_
  · calc
      (∑ n ∈ S, W n / (n : ℝ) * Real.exp (v * Real.log (n : ℝ))) ≤
          ∑ n ∈ S, W₀ * (Real.exp (v * Real.log (n : ℝ)) / (n : ℝ)) := by
        apply Finset.sum_le_sum
        intro n hn
        calc
          W n / (n : ℝ) * Real.exp (v * Real.log (n : ℝ)) =
              W n * (Real.exp (v * Real.log (n : ℝ)) / (n : ℝ)) := by ring
          _ ≤ W₀ * (Real.exp (v * Real.log (n : ℝ)) / (n : ℝ)) :=
            mul_le_mul_of_nonneg_right (hW n hn) (by positivity)
      _ = W₀ * (∑ n ∈ S, ∏ p ∈ P, r p ^ n.factorization p) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro n hn
        rw [show (∏ p ∈ P, r p ^ n.factorization p) =
          Real.exp (v * Real.log (n : ℝ)) / (n : ℝ) from
            supported_exp_ratio_product P n v hP (hpos n hn) (hsupport n hn)]
      _ ≤ W₀ * (∑ e : P → Fin M, ∏ p : P, r p.val ^ (e p).val) :=
        mul_le_mul_of_nonneg_left hbox hW₀
      _ = ∑ e : P → Fin M, W₀ * ∏ p : P, r p.val ^ (e p).val :=
        Finset.mul_sum _ _ _
      _ ≤ W₀ * Real.exp (2 * B) := hbound
  · calc
      (∑ p : P, r p.val) = ∑ p ∈ P, r p := Finset.sum_coe_sort P r
      _ ≤ B := hB

/-- Rankin's bound for the reciprocal mass of actual supported integers.
All prime powers are retained, and no mass estimate is assumed. -/
theorem finite_supported_rankin (S P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B T v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n ∈ S, 0 ≤ W n)
    (hW : ∀ n ∈ S, W n ≤ W₀) (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S.filter (fun n : ℕ => T < Real.log (n : ℝ)), W n / (n : ℝ)) ≤
      W₀ * Real.exp (2 * B - v * T) := by
  have hmoment := finite_supported_power_moment S P W W₀ B v hP hpos
    hsupport hW₀ hW hratio hB
  have hrankin := CofactorAsymptotics.finite_rankin S
    (fun n => W n / (n : ℝ)) (fun n => Real.log (n : ℝ)) T v hv
    (fun n hn => div_nonneg (hWnonneg n hn) (Nat.cast_nonneg n))
  calc
    (∑ n ∈ S.filter (fun n : ℕ => T < Real.log (n : ℝ)), W n / (n : ℝ)) ≤
        Real.exp (-v * T) *
          (∑ n ∈ S, W n / (n : ℝ) * Real.exp (v * Real.log (n : ℝ))) := hrankin
    _ ≤ Real.exp (-v * T) * (W₀ * Real.exp (2 * B)) :=
      mul_le_mul_of_nonneg_left hmoment (Real.exp_pos _).le
    _ = W₀ * Real.exp (2 * B - v * T) := by
      rw [sub_eq_add_neg, Real.exp_add]
      simp only [neg_mul]
      ring

/-- The actual normalized marking product has a uniform prime-power
exponential moment. Only local prime-ratio bounds are assumed. -/
theorem finite_marking_weight_power_moment {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (S P : Finset ℕ) (B v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S, ConcreteSelector.markingWeight I groups V n / (n : ℝ) *
      Real.exp (v * Real.log (n : ℝ))) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B) := by
  apply finite_supported_power_moment S P (ConcreteSelector.markingWeight I groups V)
    (∏ i ∈ I, 1 / V i) B v hP hpos hsupport
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n hn
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2
  · exact hratio
  · exact hB

/-- Rankin's reciprocal tail estimate for the actual normalized marking
product, uniformly over every finite supported integer family. -/
theorem finite_marking_weight_rankin {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (S P : Finset ℕ) (B T v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P) (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S.filter (fun n : ℕ => T < Real.log (n : ℝ)),
      ConcreteSelector.markingWeight I groups V n / (n : ℝ)) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B - v * T) := by
  apply finite_supported_rankin S P (ConcreteSelector.markingWeight I groups V)
    (∏ i ∈ I, 1 / V i) B T v hP hpos hsupport
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n hn
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n hn
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2
  · exact hv
  · exact hratio
  · exact hB

/-- The same marked tail bound with the actual size cutoff `exp T`. -/
theorem finite_marking_weight_size_tail {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (S P : Finset ℕ) (B T v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p)
    (hpos : ∀ n ∈ S, 0 < n)
    (hsupport : ∀ n ∈ S, n.primeFactors ⊆ P) (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S.filter (fun n : ℕ => Real.exp T < (n : ℝ)),
      ConcreteSelector.markingWeight I groups V n / (n : ℝ)) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B - v * T) := by
  have hfilter : S.filter (fun n : ℕ => Real.exp T < (n : ℝ)) =
      S.filter (fun n : ℕ => T < Real.log (n : ℝ)) := by
    apply Finset.filter_congr
    intro n hn
    exact (Real.lt_log_iff_exp_lt (by exact_mod_cast hpos n hn)).symm
  rw [hfilter]
  exact finite_marking_weight_rankin I groups V S P B T v hV hP hpos
    hsupport hv hratio hB

end Artin.MarkedPowerMass
