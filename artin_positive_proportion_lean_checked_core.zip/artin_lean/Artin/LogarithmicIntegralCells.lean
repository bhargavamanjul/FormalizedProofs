module

public import Artin.PrimeDistribution

/-!
# Elementary cells of the logarithmic integral

The logarithmic-integral increments are actual interval integrals.  The
normalization at two makes the two initial cells vanish.
-/

@[expose] public section

open MeasureTheory

namespace Artin.PrimeDistribution

/-- The inverse logarithm has no singularity on intervals above two. -/
theorem invlog_intervalIntegrable {A B : ℝ} (hA : 2 ≤ A) (hAB : A ≤ B) :
    IntervalIntegrable (fun t : ℝ => (Real.log t)⁻¹) volume A B := by
  apply ContinuousOn.intervalIntegrable_of_Icc hAB
  intro t ht
  have htpos : 0 < t := by linarith [ht.1]
  have htlog : 0 < Real.log t := Real.log_pos (by linarith [ht.1])
  exact ((Real.continuousAt_log htpos.ne').inv₀ htlog.ne').continuousWithinAt

/-- A fixed bound for the inverse-logarithm density on the normalized range. -/
theorem invlog_abs_le {t : ℝ} (ht : 2 ≤ t) :
    |(Real.log t)⁻¹| ≤ (Real.log 2)⁻¹ := by
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlog : Real.log 2 ≤ Real.log t := Real.log_le_log (by norm_num) ht
  rw [abs_of_nonneg (inv_nonneg.mpr (hlog2.le.trans hlog))]
  exact (inv_le_inv₀ (hlog2.trans_le hlog) hlog2).mpr hlog

@[simp] theorem logarithmicIntegral_one : logarithmicIntegral 1 = 0 := by
  norm_num [logarithmicIntegral]

@[simp] theorem logarithmicIntegral_two : logarithmicIntegral 2 = 0 := by
  simp [logarithmicIntegral]

/-- Each cell above two is exactly the corresponding logarithmic-integral increment. -/
theorem logarithmicIntegral_succ_sub (n : ℕ) (hn : 2 ≤ n) :
    logarithmicIntegral (n + 1) - logarithmicIntegral n =
      ∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), (Real.log t)⁻¹ := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hns : (2 : ℝ) ≤ (n + 1 : ℕ) := by exact_mod_cast (hn.trans (Nat.le_succ n))
  simp only [logarithmicIntegral, max_eq_right hn', max_eq_right hns]
  exact intervalIntegral.integral_interval_sub_left
    (invlog_intervalIntegrable le_rfl hns) (invlog_intervalIntegrable le_rfl hn')

end Artin.PrimeDistribution
