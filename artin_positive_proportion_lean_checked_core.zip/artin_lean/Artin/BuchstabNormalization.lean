module

public import Artin.BuchstabBinEstimate

/-!
# Normalization of a Buchstab bin

The replacement and conditioned-sieve estimates are combined explicitly.
The logarithmic replacement error is absorbed using the positive lower
bound for the actual normalizing mass. The resulting vanishing error is
an explicit nonnegative function, rather than an additional hypothesis.
-/

@[expose] public section

open Filter

namespace Artin.BuchstabNormalization

/-- The two independently small multiplicative perturbations can be made
arbitrarily small after fixing the bin coefficient. -/
theorem exists_small_coefficient {E C₀ ℓ ρ : ℝ}
    (hE : 0 < E) (hC₀ : 0 ≤ C₀) (hℓ : 0 ≤ ℓ) (hρ : 0 < ρ) :
    ∃ δ : ℝ, 0 < δ ∧
      (C₀ + δ) * (1 + δ) * E * ℓ ≤ E * C₀ * ℓ + ρ / 2 := by
  let B := E * ℓ * (C₀ + 2)
  have hB : 0 ≤ B := mul_nonneg (mul_nonneg hE.le hℓ) (by linarith)
  let δ := min 1 (ρ / (2 * (B + 1)))
  have hδ : 0 < δ := lt_min (by norm_num) (div_pos hρ (by linarith))
  have hδ1 : δ ≤ 1 := min_le_left _ _
  have hδsmall : δ * (2 * (B + 1)) ≤ ρ :=
    (le_div_iff₀ (by linarith : 0 < 2 * (B + 1))).mp (min_le_right _ _)
  have hδB : δ * B ≤ ρ / 2 := by nlinarith
  have hδsq : δ ^ 2 ≤ δ := by nlinarith
  have hEL : 0 ≤ E * ℓ := mul_nonneg hE.le hℓ
  have herr : (C₀ + δ) * (1 + δ) * E * ℓ ≤ E * C₀ * ℓ + δ * B := by
    dsimp [B]
    nlinarith [mul_nonneg (show 0 ≤ δ - δ ^ 2 by nlinarith) hEL]
  exact ⟨δ, hδ, herr.trans (by linarith)⟩

/-- An `x/log^5 x` error is negligible relative to `S*X/log x` when
`X` has the required lower bound `A₀*x/log x`. -/
theorem eventually_log_error_le {S A₀ C ρ : ℝ} (X : ℝ → ℝ)
    (hS : 0 < S) (hA₀ : 0 < A₀) (_hC : 0 ≤ C) (hρ : 0 < ρ)
    (hX : ∀ᶠ x : ℝ in atTop, A₀ * x / Real.log x ≤ X x) :
    ∀ᶠ x : ℝ in atTop,
      C * x * (Real.log x) ^ (-5 : ℝ) ≤ ρ * (S * X x / Real.log x) := by
  have hlim : Tendsto (fun x : ℝ => C / (S * A₀) * (Real.log x) ^ (-3 : ℝ))
      atTop (nhds 0) := by
    have hh := (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 3)).comp
      Real.tendsto_log_atTop
    simpa only [Function.comp_def, mul_zero] using tendsto_const_nhds.mul hh
  have hsmall := (tendsto_order.1 hlim).2 ρ hρ
  filter_upwards [hX, hsmall, eventually_gt_atTop (1 : ℝ)] with x hx he hx1
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx1
  have hmass : S * A₀ * x / (Real.log x) ^ 2 ≤ S * X x / Real.log x := by
    have hm := mul_le_mul_of_nonneg_left hx hS.le
    have hd := div_le_div_of_nonneg_right hm hL.le
    convert hd using 1; ring
  have hbase : 0 ≤ S * A₀ * x / (Real.log x) ^ 2 := by positivity
  have heq : C * x * (Real.log x) ^ (-5 : ℝ) =
      (C / (S * A₀) * (Real.log x) ^ (-3 : ℝ)) *
        (S * A₀ * x / (Real.log x) ^ 2) := by
    have h5 : (Real.log x) ^ (-5 : ℝ) = ((Real.log x) ^ 5)⁻¹ := by
      rw [show (-5 : ℝ) = -(5 : ℝ) by norm_num, Real.rpow_neg hL.le]
      norm_cast
    have h3 : (Real.log x) ^ (-3 : ℝ) = ((Real.log x) ^ 3)⁻¹ := by
      rw [show (-3 : ℝ) = -(3 : ℝ) by norm_num, Real.rpow_neg hL.le]
      norm_cast
    rw [h5, h3]
    field_simp
  rw [heq]
  exact (mul_le_mul_of_nonneg_right he.le hbase).trans
    (mul_le_mul_of_nonneg_left hmass hρ.le)

/-- The precise coefficient follows from the actual replacement and
conditioned-sieve step estimates. Their perturbation parameters are chosen
before the scale, and no vanishing bin error is assumed. -/
theorem eventually_bin_normalized {S E A₀ C₀ ℓ : ℝ}
    (T H X V : ℝ → ℝ) (hS : 0 < S) (hE : 0 < E) (hA₀ : 0 < A₀)
    (hC₀ : 0 ≤ C₀) (hℓ : 0 ≤ ℓ)
    (hV : ∀ᶠ x : ℝ in atTop, 0 < V x)
    (hX : ∀ᶠ x : ℝ in atTop, A₀ * x / Real.log x ≤ X x)
    (hcond : ∀ δ : ℝ, 0 < δ → ∀ᶠ x : ℝ in atTop,
      H x ≤ (1 + δ) * E * S * X x * V x * ℓ)
    (hbin : ∀ δ : ℝ, 0 < δ → ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      T x ≤ (C₀ + δ) / (Real.log x * V x) * H x +
        C * x * (Real.log x) ^ (-5 : ℝ)) :
    ∀ ρ : ℝ, 0 < ρ → ∀ᶠ x : ℝ in atTop,
      T x ≤ (E * C₀ * ℓ + ρ) * (S * X x / Real.log x) := by
  intro ρ hρ
  obtain ⟨δ, hδ, hcoef⟩ := exists_small_coefficient hE hC₀ hℓ hρ
  obtain ⟨C, hC, hbin'⟩ := hbin δ hδ
  have herr := eventually_log_error_le X hS hA₀ hC.le
    (show 0 < ρ / 2 by linarith) hX
  filter_upwards [hbin', hcond δ hδ, hV, hX, herr, eventually_gt_atTop (1 : ℝ)]
    with x hxbin hxcond hxV hxX hxerr hx1
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx1
  have hX0 : 0 < X x := (div_pos (mul_pos hA₀ hx0) hL).trans_le hxX
  have hnormal : 0 ≤ S * X x / Real.log x := by positivity
  have hquot : 0 ≤ (C₀ + δ) / (Real.log x * V x) := by positivity
  have hcancel : (C₀ + δ) / (Real.log x * V x) *
      ((1 + δ) * E * S * X x * V x * ℓ) =
      ((C₀ + δ) * (1 + δ) * E * ℓ) * (S * X x / Real.log x) := by
    field_simp
  calc
    T x ≤ (C₀ + δ) / (Real.log x * V x) * H x +
        C * x * (Real.log x) ^ (-5 : ℝ) := hxbin
    _ ≤ (C₀ + δ) / (Real.log x * V x) *
        ((1 + δ) * E * S * X x * V x * ℓ) +
        (ρ / 2) * (S * X x / Real.log x) :=
      add_le_add (mul_le_mul_of_nonneg_left hxcond hquot) hxerr
    _ = (((C₀ + δ) * (1 + δ) * E * ℓ) + ρ / 2) *
        (S * X x / Real.log x) := by rw [hcancel]; ring
    _ ≤ (E * C₀ * ℓ + ρ) * (S * X x / Real.log x) :=
      mul_le_mul_of_nonneg_right (by linarith) hnormal

/-- An explicit nonnegative error extracted from an upper asymptotic bound. -/
noncomputable def binError (T B : ℝ → ℝ) (a : ℝ) (x : ℝ) : ℝ :=
  max 0 (T x / B x - a)

theorem binError_nonneg (T B : ℝ → ℝ) (a x : ℝ) : 0 ≤ binError T B a x :=
  le_max_left _ _

/-- The upper bound with arbitrary positive accuracy is equivalent to a
single explicit vanishing upper error when the normalizer is positive. -/
theorem binError_tendsto {T B : ℝ → ℝ} {a : ℝ}
    (hB : ∀ᶠ x : ℝ in atTop, 0 < B x)
    (hupper : ∀ ρ : ℝ, 0 < ρ → ∀ᶠ x : ℝ in atTop,
      T x ≤ (a + ρ) * B x) :
    Tendsto (binError T B a) atTop (nhds 0) := by
  apply tendsto_order.2
  constructor
  · intro b hb
    exact Eventually.of_forall (fun x => hb.trans_le (binError_nonneg T B a x))
  · intro b hb
    filter_upwards [hB, hupper (b / 2) (by linarith)] with x hxB hx
    have hquot : T x / B x ≤ a + b / 2 := (div_le_iff₀ hxB).mpr hx
    have herr : binError T B a x ≤ b / 2 := by
      apply max_le (by linarith)
      linarith
    exact herr.trans_lt (by linarith)

theorem eventually_binError_bound {T B : ℝ → ℝ} {a : ℝ}
    (hB : ∀ᶠ x : ℝ in atTop, 0 < B x) :
    ∀ᶠ x : ℝ in atTop, T x ≤ (a + binError T B a x) * B x := by
  filter_upwards [hB] with x hxB
  have he := le_max_right (0 : ℝ) (T x / B x - a)
  apply (div_le_iff₀ hxB).mp
  change T x / B x ≤ a + max 0 (T x / B x - a)
  linarith

/-- The complete normalized bin estimate with a proved vanishing error.
This is the form consumed by the finite Buchstab subtraction. -/
theorem exists_vanishing_bin_error {S E A₀ C₀ ℓ : ℝ}
    (T H X V : ℝ → ℝ) (hS : 0 < S) (hE : 0 < E) (hA₀ : 0 < A₀)
    (hC₀ : 0 ≤ C₀) (hℓ : 0 ≤ ℓ)
    (hV : ∀ᶠ x : ℝ in atTop, 0 < V x)
    (hX : ∀ᶠ x : ℝ in atTop, A₀ * x / Real.log x ≤ X x)
    (hcond : ∀ δ : ℝ, 0 < δ → ∀ᶠ x : ℝ in atTop,
      H x ≤ (1 + δ) * E * S * X x * V x * ℓ)
    (hbin : ∀ δ : ℝ, 0 < δ → ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      T x ≤ (C₀ + δ) / (Real.log x * V x) * H x +
        C * x * (Real.log x) ^ (-5 : ℝ)) :
    ∃ e : ℝ → ℝ, (∀ x, 0 ≤ e x) ∧ Tendsto e atTop (nhds 0) ∧
      ∀ᶠ x : ℝ in atTop,
        T x ≤ (E * C₀ * ℓ + e x) * (S * X x / Real.log x) := by
  let B := fun x => S * X x / Real.log x
  have hB : ∀ᶠ x : ℝ in atTop, 0 < B x := by
    filter_upwards [hX, eventually_gt_atTop (1 : ℝ)] with x hx hx1
    have hx0 : 0 < x := by linarith
    have hL := Real.log_pos hx1
    have hX0 := (div_pos (mul_pos hA₀ hx0) hL).trans_le hx
    exact div_pos (mul_pos hS hX0) hL
  refine ⟨binError T B (E * C₀ * ℓ), binError_nonneg T B _, ?_,
    eventually_binError_bound hB⟩
  apply binError_tendsto hB
  exact eventually_bin_normalized T H X V hS hE hA₀ hC₀ hℓ hV hX hcond hbin

end Artin.BuchstabNormalization
