module

public import Mathlib.Analysis.SpecialFunctions.Log.Base
public import Mathlib.Data.Int.Interval
public import Mathlib.Data.Finset.Prod
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring
public meta import Lean.Elab.Tactic.Omega

/-!
# A finite dyadic cover of the hyperbolic strip

The strip `x < m*n ≤ 2*x` meets at most three dyadic rectangles for each
first-coordinate dyadic interval. The cover and its index set are constructed
explicitly, with a logarithmic bound for a prescribed factor range.
-/

@[expose] public section

namespace Artin.DyadicBoxes

noncomputable def dyadicIndex (t : ℝ) : ℤ := ⌊Real.logb 2 t⌋

def InBin (a : ℤ) (t : ℝ) : Prop := (2 : ℝ) ^ a ≤ t ∧ t < (2 : ℝ) ^ (a + 1)

theorem dyadicIndex_inBin {t : ℝ} (ht : 0 < t) : InBin (dyadicIndex t) t := by
  constructor
  · have h := (Real.le_logb_iff_rpow_le (by norm_num : (1 : ℝ) < 2) ht).mp
      (Int.floor_le (Real.logb 2 t))
    simpa [dyadicIndex, Real.rpow_intCast] using h
  · have h := (Real.logb_lt_iff_lt_rpow (by norm_num : (1 : ℝ) < 2) ht).mp
      (Int.lt_floor_add_one (Real.logb 2 t))
    change t < (2 : ℝ) ^ (⌊Real.logb 2 t⌋ + 1)
    rw [← Real.rpow_intCast]
    simpa only [Int.cast_add, Int.cast_one] using h

theorem dyadicIndex_mono {s t : ℝ} (hs : 0 < s) (hst : s ≤ t) :
    dyadicIndex s ≤ dyadicIndex t :=
  Int.floor_mono (Real.logb_le_logb_of_le (by norm_num) hs hst)

/-- The two dyadic exponents have only three possible sums. -/
theorem dyadicIndex_sum_bounds {x m n : ℝ} (hx : 0 < x) (hm : 0 < m)
    (hn : 0 < n) (hlo : x < m * n) (hhi : m * n ≤ 2 * x) :
    -1 ≤ dyadicIndex m + dyadicIndex n - dyadicIndex x ∧
      dyadicIndex m + dyadicIndex n - dyadicIndex x ≤ 1 := by
  have hl := Real.logb_lt_logb (by norm_num : (1 : ℝ) < 2) hx hlo
  have hu := Real.logb_le_logb_of_le (by norm_num : (1 : ℝ) < 2)
    (mul_pos hm hn) hhi
  rw [Real.logb_mul hm.ne' hn.ne'] at hl hu
  rw [Real.logb_mul (by norm_num : (2 : ℝ) ≠ 0) hx.ne',
    Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2)] at hu
  have hmf := Int.floor_le (Real.logb 2 m)
  have hnf := Int.floor_le (Real.logb 2 n)
  have hxf := Int.floor_le (Real.logb 2 x)
  have hmc := Int.lt_floor_add_one (Real.logb 2 m)
  have hnc := Int.lt_floor_add_one (Real.logb 2 n)
  have hxc := Int.lt_floor_add_one (Real.logb 2 x)
  have h₁ : (dyadicIndex x : ℝ) < dyadicIndex m + dyadicIndex n + 2 := by
    dsimp [dyadicIndex]
    linarith
  have h₂ : (dyadicIndex m : ℝ) + dyadicIndex n < dyadicIndex x + 2 := by
    dsimp [dyadicIndex]
    linarith
  have h₁' : dyadicIndex x < dyadicIndex m + dyadicIndex n + 2 := by
    exact_mod_cast h₁
  have h₂' : dyadicIndex m + dyadicIndex n < dyadicIndex x + 2 := by
    exact_mod_cast h₂
  omega

/-- Three possible second-coordinate exponents for every first exponent. -/
def boxIndices (A B c : ℤ) : Finset (ℤ × ℤ) :=
  (Finset.Icc A B ×ˢ Finset.Icc (-1 : ℤ) 1).image
    (fun ij => (ij.1, c - ij.1 + ij.2))

theorem mem_boxIndices {A B c a b : ℤ} :
    (a, b) ∈ boxIndices A B c ↔ A ≤ a ∧ a ≤ B ∧ -1 ≤ a + b - c ∧ a + b - c ≤ 1 := by
  simp only [boxIndices, Finset.mem_image, Finset.mem_product, Finset.mem_Icc,
    Prod.exists, Prod.mk.injEq]
  constructor
  · rintro ⟨u, t, ⟨⟨huA, huB⟩, ⟨htlo, hthi⟩⟩, hua, hutb⟩
    omega
  · rintro ⟨haA, haB, hblo, hbhi⟩
    exact ⟨a, a + b - c, ⟨⟨haA, haB⟩, ⟨hblo, hbhi⟩⟩, rfl, by omega⟩

theorem boxIndices_card (A B c : ℤ) :
    (boxIndices A B c).card = 3 * (B + 1 - A).toNat := by
  have hi : Function.Injective (fun ij : ℤ × ℤ => (ij.1, c - ij.1 + ij.2)) := by
    rintro ⟨a, b⟩ ⟨a', b'⟩ hpq
    simp only [Prod.mk.injEq] at hpq ⊢
    omega
  rw [boxIndices, Finset.card_image_of_injective _ hi, Finset.card_product, Int.card_Icc,
    Int.card_Icc]
  norm_num [Nat.mul_comm]

/-- An actual finite cover, with no cover or pair-count assumption. -/
theorem exists_box {L U x m n : ℝ} (hL : 0 < L) (hx : 0 < x)
    (hmL : L ≤ m) (hmU : m ≤ U) (hn : 0 < n)
    (hlo : x < m * n) (hhi : m * n ≤ 2 * x) :
    ∃ ab ∈ boxIndices (dyadicIndex L) (dyadicIndex U) (dyadicIndex x),
      InBin ab.1 m ∧ InBin ab.2 n := by
  have hm : 0 < m := hL.trans_le hmL
  refine ⟨(dyadicIndex m, dyadicIndex n), ?_, dyadicIndex_inBin hm, dyadicIndex_inBin hn⟩
  rw [mem_boxIndices]
  exact ⟨dyadicIndex_mono hL hmL, dyadicIndex_mono hm hmU,
    dyadicIndex_sum_bounds hx hm hn hlo hhi⟩

/-- The number of rectangles is linear in the logarithmic factor width. -/
theorem boxIndices_card_le_log_width {L U : ℝ} (hL : 0 < L) (hLU : L ≤ U)
    (c : ℤ) :
    ((boxIndices (dyadicIndex L) (dyadicIndex U) c).card : ℝ) ≤
      3 * (Real.logb 2 U - Real.logb 2 L + 2) := by
  have hi := dyadicIndex_mono hL hLU
  have hc : ((Finset.Icc (dyadicIndex L) (dyadicIndex U)).card : ℝ) =
      (dyadicIndex U : ℝ) + 1 - dyadicIndex L := by
    exact_mod_cast Int.card_Icc_of_le _ _ (by omega : dyadicIndex L ≤ dyadicIndex U + 1)
  have hcard : ((boxIndices (dyadicIndex L) (dyadicIndex U) c).card : ℝ) =
      3 * ((dyadicIndex U : ℝ) + 1 - dyadicIndex L) := by
    rw [boxIndices_card, Nat.cast_mul, ← Int.card_Icc, hc]
    norm_num
  rw [hcard]
  have hu := Int.floor_le (Real.logb 2 U)
  have hl := Int.lt_floor_add_one (Real.logb 2 L)
  dsimp [dyadicIndex]
  linarith

/-- The concrete index set for the narrow factor range in the application. -/
noncomputable def narrowBoxIndices (x κ : ℝ) : Finset (ℤ × ℤ) :=
  boxIndices (dyadicIndex (x ^ ((1 : ℝ) / 2 - κ)))
    (dyadicIndex (2 * x ^ ((1 : ℝ) / 2 + κ))) (dyadicIndex x)

theorem narrowBoxIndices_card_le {x κ : ℝ} (hx : 1 ≤ x) (hκ : 0 ≤ κ) :
    ((narrowBoxIndices x κ).card : ℝ) ≤ 6 * κ * (Real.log x / Real.log 2) + 9 := by
  have hx0 : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have hL := Real.rpow_pos_of_pos hx0 ((1 : ℝ) / 2 - κ)
  have hU := Real.rpow_pos_of_pos hx0 ((1 : ℝ) / 2 + κ)
  have hLU : x ^ ((1 : ℝ) / 2 - κ) ≤ 2 * x ^ ((1 : ℝ) / 2 + κ) := by
    have hpow := Real.rpow_le_rpow_of_exponent_le hx
      (by linarith : (1 : ℝ) / 2 - κ ≤ 1 / 2 + κ)
    linarith
  have h := boxIndices_card_le_log_width hL hLU (dyadicIndex x)
  rw [Real.logb_mul (by norm_num : (2 : ℝ) ≠ 0) hU.ne',
    Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2),
    Real.logb_rpow_eq_mul_logb_of_pos hx0,
    Real.logb_rpow_eq_mul_logb_of_pos hx0] at h
  change ((narrowBoxIndices x κ).card : ℝ) ≤ _ at h
  convert h using 1
  dsimp [Real.logb]
  ring

theorem exists_narrowBox {x κ m n : ℝ} (hx : 0 < x)
    (hmL : x ^ ((1 : ℝ) / 2 - κ) ≤ m)
    (hmU : m ≤ 2 * x ^ ((1 : ℝ) / 2 + κ)) (hn : 0 < n)
    (hlo : x < m * n) (hhi : m * n ≤ 2 * x) :
    ∃ ab ∈ narrowBoxIndices x κ, InBin ab.1 m ∧ InBin ab.2 n :=
  exists_box (Real.rpow_pos_of_pos hx _) hx hmL hmU hn hlo hhi

/-- Every rectangle in the constructed cover has area comparable to `x`. -/
theorem boxIndices_product_bounds {A B a b : ℤ} {x : ℝ} (hx : 0 < x)
    (hab : (a, b) ∈ boxIndices A B (dyadicIndex x)) :
    x / 4 ≤ (2 : ℝ) ^ a * (2 : ℝ) ^ b ∧
      (2 : ℝ) ^ a * (2 : ℝ) ^ b ≤ 2 * x := by
  have hs := (mem_boxIndices.mp hab).2.2
  have hbin := dyadicIndex_inBin hx
  have hlo : (2 : ℝ) ^ (dyadicIndex x - 1) ≤ (2 : ℝ) ^ a * (2 : ℝ) ^ b := by
    rw [← zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0)]
    exact zpow_le_zpow_right₀ (by norm_num) (by omega)
  have hhi : (2 : ℝ) ^ a * (2 : ℝ) ^ b ≤ (2 : ℝ) ^ (dyadicIndex x + 1) := by
    rw [← zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0)]
    exact zpow_le_zpow_right₀ (by norm_num) (by omega)
  have hnext : (2 : ℝ) ^ (dyadicIndex x + 1) = 2 * (2 : ℝ) ^ dyadicIndex x := by
    rw [zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0)]
    norm_num [mul_comm]
  have hprev : (2 : ℝ) ^ (dyadicIndex x - 1) = (2 : ℝ) ^ dyadicIndex x / 2 := by
    rw [zpow_sub₀ (by norm_num : (2 : ℝ) ≠ 0)]
    norm_num
  rw [hnext] at hhi
  rw [hprev] at hlo
  rcases hbin with ⟨hbinlo, hbinhi⟩
  rw [hnext] at hbinhi
  constructor <;> linarith

theorem narrowBoxIndices_product_bounds {x κ : ℝ} {ab : ℤ × ℤ} (hx : 0 < x)
    (hab : ab ∈ narrowBoxIndices x κ) :
    x / 4 ≤ (2 : ℝ) ^ ab.1 * (2 : ℝ) ^ ab.2 ∧
      (2 : ℝ) ^ ab.1 * (2 : ℝ) ^ ab.2 ≤ 2 * x :=
  boxIndices_product_bounds hx hab

/-- Moving from a selected point to its full bin costs at most a factor two. -/
theorem bin_endpoint_bounds {a : ℤ} {m : ℝ} (hm : InBin a m) :
    m / 2 < (2 : ℝ) ^ a ∧ (2 : ℝ) ^ (a + 1) ≤ 2 * m := by
  have he : (2 : ℝ) ^ (a + 1) = 2 * (2 : ℝ) ^ a := by
    rw [zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0)]
    norm_num [mul_comm]
  rcases hm with ⟨hlo, hhi⟩
  rw [he] at hhi ⊢
  constructor <;> linarith

theorem bin_endpoint_bounds_of_range {a : ℤ} {L U m : ℝ}
    (hm : InBin a m) (hL : L ≤ m) (hU : m ≤ U) :
    L / 2 < (2 : ℝ) ^ a ∧ (2 : ℝ) ^ (a + 1) ≤ 2 * U := by
  have h := bin_endpoint_bounds hm
  constructor <;> linarith

/-- Explicit large-`x` slack absorbs the dyadic bin endpoints into the fixed
factor range `[x^0.46, x^0.54]`. -/
theorem bin_endpoint_bounds_narrow {a : ℤ} {x κ m : ℝ}
    (hx : 1 ≤ x) (hκ : κ ≤ (1 : ℝ) / 100)
    (hlarge : 8 ≤ x ^ ((3 : ℝ) / 100)) (hm : InBin a m)
    (hmL : x ^ ((1 : ℝ) / 2 - κ) ≤ m)
    (hmU : m ≤ 2 * x ^ ((1 : ℝ) / 2 + κ)) :
    x ^ ((46 : ℝ) / 100) ≤ (2 : ℝ) ^ a ∧
      (2 : ℝ) ^ (a + 1) ≤ x ^ ((54 : ℝ) / 100) := by
  have hx0 : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have h46 := Real.rpow_pos_of_pos hx0 ((46 : ℝ) / 100)
  have h51 := Real.rpow_pos_of_pos hx0 ((51 : ℝ) / 100)
  have hlo := Real.rpow_le_rpow_of_exponent_le hx
    (by linarith : (49 : ℝ) / 100 ≤ 1 / 2 - κ)
  have hhi := Real.rpow_le_rpow_of_exponent_le hx
    (by linarith : (1 : ℝ) / 2 + κ ≤ 51 / 100)
  have h49 : x ^ ((49 : ℝ) / 100) =
      x ^ ((46 : ℝ) / 100) * x ^ ((3 : ℝ) / 100) := by
    rw [← Real.rpow_add hx0]
    norm_num
  have h54 : x ^ ((54 : ℝ) / 100) =
      x ^ ((51 : ℝ) / 100) * x ^ ((3 : ℝ) / 100) := by
    rw [← Real.rpow_add hx0]
    norm_num
  have hlarge46 := mul_le_mul_of_nonneg_left hlarge h46.le
  have hlarge51 := mul_le_mul_of_nonneg_left hlarge h51.le
  have hb := bin_endpoint_bounds hm
  rw [h49] at hlo
  rw [h54]
  constructor <;> nlinarith

theorem bin_subset_fixed_range {a : ℤ} {x κ m : ℝ}
    (hx : 1 ≤ x) (hκ : κ ≤ (1 : ℝ) / 100)
    (hlarge : 8 ≤ x ^ ((3 : ℝ) / 100)) (hm : InBin a m)
    (hmL : x ^ ((1 : ℝ) / 2 - κ) ≤ m)
    (hmU : m ≤ 2 * x ^ ((1 : ℝ) / 2 + κ)) :
    ∀ t, InBin a t → x ^ ((46 : ℝ) / 100) ≤ t ∧ t ≤ x ^ ((54 : ℝ) / 100) := by
  have hb := bin_endpoint_bounds_narrow hx hκ hlarge hm hmL hmU
  intro t ht
  exact ⟨hb.1.trans ht.1, ht.2.le.trans hb.2⟩

theorem narrowBoxIndices_card_le_constant {x κ : ℝ} (hx : 1 ≤ x) (hκ : 0 ≤ κ) :
    ((narrowBoxIndices x κ).card : ℝ) ≤
      (6 / Real.log 2 + 9) * (κ * Real.log x + 1) := by
  have ht : 0 ≤ κ * Real.log x := mul_nonneg hκ (Real.log_nonneg hx)
  have hC : 0 ≤ (6 : ℝ) / Real.log 2 :=
    div_nonneg (by norm_num) (Real.log_pos (by norm_num : (1 : ℝ) < 2)).le
  calc
    ((narrowBoxIndices x κ).card : ℝ) ≤ 6 * κ * (Real.log x / Real.log 2) + 9 :=
      narrowBoxIndices_card_le hx hκ
    _ = (6 / Real.log 2) * (κ * Real.log x) + 9 := by ring
    _ ≤ _ := by nlinarith

end Artin.DyadicBoxes
