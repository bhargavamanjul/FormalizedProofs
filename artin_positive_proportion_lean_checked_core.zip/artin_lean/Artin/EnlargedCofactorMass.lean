module

public import Artin.MarkedInfiniteMass
public import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Infinite mass over distinct enlarged natural cofactors

The positive integer itself is the index of the series. Its unique marked
part and stripped part identify the permitted disjoint-support factorization.
Injectivity of multiplication justifies the product identity and tail change
of variables without counting an integer more than once.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.EnlargedCofactorMass

open ConcreteSelector MarkedInfiniteMass

/-- The positive integers supported on the marked prime set. -/
abbrev SupportedNaturals (P : Finset ℕ) := {n : ℕ // 0 < n ∧ n.primeFactors ⊆ P}

/-- The weight at the actual enlarged integer, using its unique stripped
cofactor to test membership in the permitted unmarked family. -/
noncomputable def enlargedReciprocal (P U : Finset ℕ) (W : ℕ → ℝ) (n : ℕ) : ℝ :=
  if 0 < n ∧ strip P n ∈ U then W (markedPart P n) / (n : ℝ) else 0

/-- Full reciprocal mass over distinct enlarged natural numbers. -/
noncomputable def enlargedMass (P U : Finset ℕ) (W : ℕ → ℝ) : ℝ :=
  ∑' n, enlargedReciprocal P U W n

/-- The actual enlarged-integer size tail. -/
noncomputable def enlargedSizeTail (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ) : ℝ :=
  ∑' n : ℕ, if X < (n : ℝ) then enlargedReciprocal P U W n else 0

theorem supported_prime_divisor (P : Finset ℕ) (s : SupportedNaturals P)
    (q : ℕ) (hq : q.Prime) (hqs : q ∣ s.val) : q ∈ P :=
  s.property.2 (hq.mem_primeFactors hqs s.property.1.ne')

/-- The factorization is injective even with all marked prime powers. -/
theorem product_injective (P U : Finset ℕ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r) :
    Function.Injective (fun z : U × SupportedNaturals P => z.2.val * z.1.val) := by
  intro z w heq
  obtain ⟨hs, hr⟩ := MarkedCofactorMass.factor_pair_unique P
    z.2.property.1.ne' (hU z.1 z.1.property).1
    w.2.property.1.ne' (hU w.1 w.1.property).1
    (supported_prime_divisor P z.2) (supported_prime_divisor P w.2)
    (hU z.1 z.1.property).2 (hU w.1 w.1.property).2 heq
  exact Prod.ext (Subtype.ext hr) (Subtype.ext hs)

/-- Evaluation at a permitted factor pair recovers the marked factor. -/
theorem enlargedReciprocal_product (P U : Finset ℕ) (W : ℕ → ℝ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r)
    (r : U) (s : SupportedNaturals P) :
    enlargedReciprocal P U W (s.val * r.val) = supportedReciprocal P W s.val / (r.val : ℝ) := by
  have hr := hU r r.property
  have hpos : 0 < s.val * r.val := Nat.mul_pos s.property.1 (Nat.pos_of_ne_zero hr.1)
  have hstrip : strip P (s.val * r.val) = r.val := by
    rw [strip_mul_supported P s.property.1.ne' hr.1 (supported_prime_divisor P s),
      strip_eq_self_of_avoids P hr.1 hr.2]
  have hmark := MarkedCofactorMass.markedPart_product P s.property.1.ne' hr.1
    (supported_prime_divisor P s) hr.2
  simp [enlargedReciprocal, hpos, hstrip, r.property, hmark,
    supportedReciprocal, s.property, Nat.cast_mul, div_div]

/-- A nonzero enlarged term arises from its actual unique factor pair. -/
theorem enlarged_support_in_range (P U : Finset ℕ) (W : ℕ → ℝ) (F : ℕ → ℝ) :
    Function.support (fun n => enlargedReciprocal P U W n * F n) ⊆
      Set.range (fun z : U × SupportedNaturals P => z.2.val * z.1.val) := by
  intro n hn
  by_cases h : 0 < n ∧ strip P n ∈ U
  · refine ⟨(⟨strip P n, h.2⟩,
      ⟨markedPart P n, markedPart_pos P h.1.ne', ?_⟩), markedPart_mul_strip P h.1.ne'⟩
    rw [primeFactors_markedPart]
    exact Finset.inter_subset_right
  · exact False.elim (hn (by simp [enlargedReciprocal, h]))

/-- Subtype restriction removes only terms which are already zero. -/
theorem tsum_supported_subtype (P : Finset ℕ) (W F : ℕ → ℝ) :
    (∑' s : SupportedNaturals P, supportedReciprocal P W s.val * F s.val) =
      ∑' s : ℕ, supportedReciprocal P W s * F s := by
  apply tsum_subtype_eq_of_support_subset
    (s := {n : ℕ | 0 < n ∧ n.primeFactors ⊆ P})
    (f := fun n => supportedReciprocal P W n * F n)
  intro n hn
  by_contra h
  change ¬ (0 < n ∧ n.primeFactors ⊆ P) at h
  exact hn (by simp [supportedReciprocal, h])

/-- All permitted factor-pair terms are summable, also after multiplying by
any weight between zero and one, such as a size-tail indicator. -/
theorem summable_pair_weight (P U : Finset ℕ) (W F : ℕ → ℝ)
    (hW : ∀ n, 0 ≤ W n) (hS : Summable (supportedReciprocal P W))
    (hF : ∀ n, 0 ≤ F n ∧ F n ≤ 1) :
    Summable (fun z : U × SupportedNaturals P =>
      (supportedReciprocal P W z.2.val * F (z.2.val * z.1.val)) / (z.1.val : ℝ)) := by
  have hnonneg : 0 ≤ (fun z : U × SupportedNaturals P =>
      (supportedReciprocal P W z.2.val * F (z.2.val * z.1.val)) / (z.1.val : ℝ)) := by
    intro z
    exact div_nonneg
      (mul_nonneg (supportedReciprocal_nonneg P W hW z.2.val) (hF _).1)
      (Nat.cast_nonneg z.1.val)
  apply (summable_prod_of_nonneg hnonneg).mpr
  refine ⟨?_, Summable.of_finite⟩
  intro r
  have hinner : Summable (fun s : SupportedNaturals P =>
      supportedReciprocal P W s.val * F (s.val * r.val)) := by
    apply Summable.of_nonneg_of_le (f := fun s : SupportedNaturals P => supportedReciprocal P W s.val)
    · intro s
      exact mul_nonneg (supportedReciprocal_nonneg P W hW s.val) (hF _).1
    · intro s
      exact mul_le_of_le_one_right (supportedReciprocal_nonneg P W hW s.val) (hF _).2
    · exact hS.subtype (fun n => 0 < n ∧ n.primeFactors ⊆ P)
  exact hinner.div_const (r.val : ℝ)

/-- Reindexing a convergent series by the unique enlarged integer. -/
theorem enlarged_weighted_tsum_eq (P U : Finset ℕ) (W F : ℕ → ℝ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hW : ∀ n, 0 ≤ W n) (hS : Summable (supportedReciprocal P W))
    (hF : ∀ n, 0 ≤ F n ∧ F n ≤ 1) :
    (∑' n, enlargedReciprocal P U W n * F n) =
      ∑ r ∈ U, (∑' s, supportedReciprocal P W s * F (s * r)) / (r : ℝ) := by
  have hreindex := (product_injective P U hU).tsum_eq (enlarged_support_in_range P U W F)
  rw [← hreindex]
  have hpair := summable_pair_weight P U W F hW hS hF
  calc
    _ = ∑' z : U × SupportedNaturals P,
        (supportedReciprocal P W z.2.val * F (z.2.val * z.1.val)) / (z.1.val : ℝ) := by
      apply tsum_congr
      intro z
      rw [enlargedReciprocal_product P U W hU z.1 z.2]
      ring
    _ = ∑' r : U, ∑' s : SupportedNaturals P,
        (supportedReciprocal P W s.val * F (s.val * r.val)) / (r.val : ℝ) := hpair.tsum_prod
    _ = ∑' r : U, (∑' s : ℕ, supportedReciprocal P W s * F (s * r.val)) / (r.val : ℝ) := by
      apply tsum_congr
      intro r
      rw [tsum_div_const, tsum_supported_subtype P W (fun s => F (s * r.val))]
    _ = _ := Finset.tsum_subtype U (fun r =>
      (∑' s : ℕ, supportedReciprocal P W s * F (s * r)) / (r : ℝ))

/-- The series over actual enlarged natural numbers converges. -/
theorem summable_enlargedReciprocal (P U : Finset ℕ) (W : ℕ → ℝ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hW : ∀ n, 0 ≤ W n) (hS : Summable (supportedReciprocal P W)) :
    Summable (enlargedReciprocal P U W) := by
  apply (product_injective P U hU).summable_iff ?_ |>.mp
  · have hs := summable_pair_weight P U W (fun _ => 1) hW hS (fun _ => ⟨zero_le_one, le_rfl⟩)
    apply hs.congr
    intro z
    simp only [mul_one, Function.comp_apply]
    exact (enlargedReciprocal_product P U W hU z.1 z.2).symm
  · intro n hn
    by_contra hne
    apply hn
    exact enlarged_support_in_range P U W (fun _ => 1) (by simpa using hne)

/-- The exact identity `J = J_P H_0`, with `J` indexed by distinct enlarged
natural numbers and all prime powers retained in the marked part. -/
theorem enlarged_mass_eq (P U : Finset ℕ) (W : ℕ → ℝ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hW : ∀ n, 0 ≤ W n) (hS : Summable (supportedReciprocal P W)) :
    enlargedMass P U W = supportedMass P W * (∑ r ∈ U, 1 / (r : ℝ)) := by
  have h := enlarged_weighted_tsum_eq P U W (fun _ => 1) hU hW hS
    (fun _ => ⟨zero_le_one, le_rfl⟩)
  simp only [mul_one] at h
  rw [enlargedMass, h, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  change supportedMass P W / (r : ℝ) = supportedMass P W * (1 / (r : ℝ))
  ring

/-- The actual enlarged-integer size tail equals its uniquely indexed
factor-pair series. This is the change of variables used in Rankin's bound. -/
theorem enlargedSizeTail_eq (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r)
    (hW : ∀ n, 0 ≤ W n) (hS : Summable (supportedReciprocal P W)) :
    enlargedSizeTail P U W X =
      ∑ r ∈ U, (∑' s : ℕ, if X < (s : ℝ) * (r : ℝ) then
        supportedReciprocal P W s else 0) / (r : ℝ) := by
  have h := enlarged_weighted_tsum_eq P U W (fun n => if X < (n : ℝ) then 1 else 0)
    hU hW hS (fun n => by split_ifs <;> norm_num)
  simpa [enlargedSizeTail, mul_ite, Nat.cast_mul] using h

/-- With the manuscript's marking weight, the enlarged term is exactly the
weight of the actual integer, divided by that integer. -/
theorem enlarged_marking_reciprocal_eq {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P U : Finset ℕ)
    (hgroups : ∀ i ∈ I, groups i ⊆ P) (n : ℕ) :
    enlargedReciprocal P U (markingWeight I groups V) n =
      if 0 < n ∧ strip P n ∈ U then markingWeight I groups V n / (n : ℝ) else 0 := by
  unfold enlargedReciprocal
  rw [markingWeight_markedPart I groups V P n hgroups]

/-- Exact product identity for the actual convergent marking series. -/
theorem enlarged_marking_mass_eq {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P U : Finset ℕ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, p.Prime)
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r) :
    enlargedMass P U (markingWeight I groups V) =
      supportedMass P (markingWeight I groups V) * (∑ r ∈ U, 1 / (r : ℝ)) :=
  enlarged_mass_eq P U _ hU
    (fun n => (markingWeight_bounds I groups V n hV).1)
    (summable_marking_weight I groups V P hV hP)

/-- Enlarging by all marked prime powers preserves the entire reciprocal
mass of the unmarked cofactor family. -/
theorem enlarged_marking_mass_ge {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P U : Finset ℕ)
    (hP : ∀ p ∈ P, p.Prime) (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i ≤ ∑ p ∈ groups i, 1 / (p : ℝ))
    (hU : ∀ r ∈ U, r ≠ 0 ∧ ∀ p ∈ P, ¬ p ∣ r) :
    (∑ r ∈ U, 1 / (r : ℝ)) ≤ enlargedMass P U (markingWeight I groups V) := by
  rw [enlarged_marking_mass_eq I groups V P U hV hP hU]
  have hlower := marking_mass_ge_one I groups V P hP hgroups hdisjoint hV hVsum
  have hnonneg : 0 ≤ ∑ r ∈ U, 1 / (r : ℝ) := Finset.sum_nonneg (fun r hr => by positivity)
  simpa only [one_mul] using mul_le_mul_of_nonneg_right hlower hnonneg

/-- The Section 4 product identity for the actual bounded squarefree
unmarked cofactors and every positive marked prime power. -/
theorem enlarged_mass_with_actual_cofactors {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P T : Finset ℕ) (R τ : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, p.Prime)
    (hT : ∀ p ∈ T, p.Prime) (hdisjoint : Disjoint P T) :
    enlargedMass P (CofactorAsymptotics.cofactors T R τ) (markingWeight I groups V) =
      supportedMass P (markingWeight I groups V) * CofactorAsymptotics.mass T R τ := by
  exact enlarged_marking_mass_eq I groups V P _ hV hP
    (MarkedCofactorMass.unmarked_cofactors_avoid P T hP hT hdisjoint R τ)

end Artin.EnlargedCofactorMass
