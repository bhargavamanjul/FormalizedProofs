module

public import Artin.BuchstabSieve
public import Artin.SieveLattice
public import Artin.EnlargedCofactorMass
public import Artin.MarkedCriterion
public import Artin.WeightSupport
public import Artin.RoughCompanion
public import Mathlib.Data.Nat.Pairing

/-!
# The block sieve on the actual two-variable lattice array

Pairs are encoded only to match the natural-number indexing in the cited
block sieve. Intersections are the concrete CRT boxes of `SieveLattice`, and
their errors are therefore proved lattice errors. The sieve constant is
chosen before the cofactor, cutoff, box, or marking weights.
-/

@[expose] public section
open scoped BigOperators
namespace Artin.RoughPairSieve
open BuchstabSieve SieveLattice

/-- A fixed, lossless encoding of the two lattice coordinates. -/
def encode (z : ℕ × ℕ) : ℕ := Nat.pair z.1 z.2

theorem encode_injective : Function.Injective encode := by
  intro z w h
  have hh := congrArg Nat.unpair h
  simpa only [encode, Nat.unpair_pair] using hh

noncomputable def encoded (A : Finset (ℕ × ℕ)) : Finset ℕ := A.image encode

theorem encoded_filter (A : Finset (ℕ × ℕ)) (P : ℕ × ℕ → Prop) [DecidablePred P] :
    (encoded A).filter (fun n => P (Nat.unpair n)) = encoded (A.filter P) := by
  classical
  ext n
  simp only [encoded, Finset.mem_filter, Finset.mem_image]
  constructor
  · rintro ⟨⟨z, hz, rfl⟩, hP⟩
    exact ⟨z, ⟨hz, by simpa only [encode, Nat.unpair_pair] using hP⟩, rfl⟩
  · rintro ⟨z, ⟨hz, hP⟩, rfl⟩
    exact ⟨⟨z, hz, rfl⟩, by simpa only [encode, Nat.unpair_pair] using hP⟩

theorem encoded_card (A : Finset (ℕ × ℕ)) : (encoded A).card = A.card :=
  Finset.card_image_of_injective _ encode_injective

/-- The actual prime-local equations on a natural lattice pair. -/
def pairBad (cutoff : ℕ → Bool) (p : ℕ) (z : ℕ × ℕ) : Prop :=
  localBad cutoff p ((z.1 : ZMod p), (z.2 : ZMod p))

/-- The base array consists of the actual box points with `mn = 1 mod k`. -/
noncomputable def pairArray (k : ℕ) [NeZero k] (M₁ M₂ : ℝ) : Finset (ℕ × ℕ) :=
  natSieveBox (Nat.coprime_one_right k) (by simp : Squarefree 1)
    (fun _ => false) M₁ (2 * M₁) M₂ (2 * M₂)

theorem mem_pairArray (k : ℕ) [NeZero k] {M₁ M₂ : ℝ}
    (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) (z : ℕ × ℕ) :
    z ∈ pairArray k M₁ M₂ ↔
      M₁ ≤ (z.1 : ℝ) ∧ (z.1 : ℝ) < 2 * M₁ ∧
      M₂ ≤ (z.2 : ℝ) ∧ (z.2 : ℝ) < 2 * M₂ ∧
      (z.1 : ZMod k) * (z.2 : ZMod k) = 1 := by
  rw [pairArray, mem_natSieveBox _ _ _ h₁ h₂, mem_sieveBox]
  simp

/-- The finite set remaining after the actual local exclusions. -/
noncomputable def siftedPairs (k : ℕ) [NeZero k] (cutoff : ℕ → Bool)
    (P : Finset ℕ) (M₁ M₂ : ℝ) : Finset (ℕ × ℕ) := by
  classical
  exact (pairArray k M₁ M₂).filter (fun z => ∀ p ∈ P, ¬ pairBad cutoff p z)

theorem encoded_siftedMass (k : ℕ) [NeZero k] (cutoff : ℕ → Bool)
    (P : Finset ℕ) (M₁ M₂ : ℝ) :
    siftedMass (encoded (pairArray k M₁ M₂)) (fun _ => 1)
      (fun p n => pairBad cutoff p (Nat.unpair n)) P =
      ((siftedPairs k cutoff P M₁ M₂).card : ℝ) := by
  classical
  unfold siftedMass siftedPairs
  rw [encoded_filter _ (fun z => ∀ p ∈ P, ¬ pairBad cutoff p z)]
  simp only [Finset.sum_const, nsmul_eq_mul, mul_one, encoded_card]

/-- Prime-local density derived from the finite-field counts. -/
noncomputable def pairDensity (cutoff : ℕ → Bool) (p : ℕ) : ℝ :=
  (SquarefreeRho.localCount cutoff p : ℝ) / (p : ℝ) ^ 2

theorem pairDensity_nonneg (cutoff : ℕ → Bool) (p : ℕ) :
    0 ≤ pairDensity cutoff p := by unfold pairDensity; positivity

theorem pairDensity_le_larger (cutoff : ℕ → Bool) {p : ℕ} (hp : 3 ≤ p) :
    pairDensity cutoff p ≤ (3 * (p : ℝ) - 2) / (p : ℝ) ^ 2 := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have hp1 : 1 ≤ p := by omega
  have hp2 : 2 ≤ 3 * p := by omega
  unfold pairDensity SquarefreeRho.localCount
  split_ifs
  · rw [Nat.cast_sub hp2]; push_cast; exact le_rfl
  · rw [Nat.cast_sub hp1]; push_cast
    apply div_le_div_of_nonneg_right _ (sq_nonneg _)
    linarith

theorem pairDensity_bounds (cutoff : ℕ → Bool) {p : ℕ} (hp : 3 ≤ p) :
    0 ≤ pairDensity cutoff p ∧ pairDensity cutoff p ≤ 1 - (2 / 9 : ℝ) := by
  refine ⟨pairDensity_nonneg cutoff p, ?_⟩
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have h := (pairDensity_le_larger cutoff hp).trans
    (SemiprimeSieve.local_density_le_seven_ninths hpR)
  norm_num at h ⊢
  exact h

theorem pairDensity_le_three_div (cutoff : ℕ → Bool) {p : ℕ} (hp : 3 ≤ p) :
    pairDensity cutoff p ≤ 3 / (p : ℝ) := by
  have hpR : (0 : ℝ) < p := by exact_mod_cast (show 0 < p by omega)
  exact (pairDensity_le_larger cutoff hp).trans
    (SemiprimeSieve.local_density_le_three_div hpR)

/-- An ordinary reciprocal-prime block bound gives the source local condition
simultaneously for every roughness cutoff and every cofactor. -/
theorem pairDensity_localConditions (P : Finset ℕ) (cutoff : ℕ → Bool)
    (C₀ : ℝ) (hP : ∀ p ∈ P, 3 ≤ p)
    (hblock : ∀ v : ℝ, 1 < v →
      (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
        1 / (p : ℝ)) ≤ C₀) :
    LocalConditions P (pairDensity cutoff) (2/9) (3 * C₀) := by
  refine ⟨fun p hp => pairDensity_bounds cutoff (hP p hp), ?_⟩
  intro v hv
  calc
    _ ≤ ∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
        3 / (p : ℝ) := Finset.sum_le_sum (fun p hp =>
      pairDensity_le_three_div cutoff (hP p (Finset.mem_filter.mp hp).1))
    _ = 3 * ∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
        1 / (p : ℝ) := by rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intros; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (hblock v hv) (by norm_num)

/-- For a subset of the sieving primes, the density product is the actual
squarefree CRT density, including the empty subset. -/
theorem pairDensity_product (S : Finset ℕ) (hS : ∀ p ∈ S, p.Prime)
    (cutoff : ℕ → Bool) :
    (∏ p ∈ S, pairDensity cutoff p) =
      (SquarefreeRho.rho cutoff (∏ p ∈ S, p) : ℝ) /
        ((∏ p ∈ S, p : ℕ) : ℝ) ^ 2 := by
  rw [SquarefreeRho.rho, Nat.primeFactors_prod hS]
  simp only [pairDensity, Finset.prod_div_distrib, Finset.prod_pow,
    Nat.cast_prod]

/-- The abstract source intersection is exactly the concrete CRT lattice
box. This is the key bridge, rather than an assumed distribution estimate. -/
theorem encoded_intersectionMass (k : ℕ) [NeZero k]
    (S : Finset ℕ) (hS : ∀ p ∈ S, p.Prime)
    (hcop : k.Coprime (∏ p ∈ S, p)) (cutoff : ℕ → Bool)
    {M₁ M₂ : ℝ} (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) :
    let ℓ := ∏ p ∈ S, p
    letI : NeZero ℓ := ⟨Finset.prod_ne_zero_iff.mpr (fun p hp => (hS p hp).ne_zero)⟩
    intersectionMass (encoded (pairArray k M₁ M₂)) (fun _ => 1)
      (fun p n => pairBad cutoff p (Nat.unpair n)) S =
      ((natSieveBox hcop (Cofactor.prime_subset_product_squarefree S hS)
        cutoff M₁ (2 * M₁) M₂ (2 * M₂)).card : ℝ) := by
  classical
  dsimp only
  let : NeZero (∏ p ∈ S, p) :=
    ⟨Finset.prod_ne_zero_iff.mpr (fun p hp => (hS p hp).ne_zero)⟩
  unfold intersectionMass
  rw [encoded_filter _ (fun z => ∀ p ∈ S, pairBad cutoff p z)]
  simp only [Finset.sum_const, nsmul_eq_mul, mul_one, encoded_card]
  apply congrArg (fun A : Finset (ℕ × ℕ) => (A.card : ℝ))
  ext z
  rw [Finset.mem_filter, mem_pairArray k h₁ h₂,
    mem_natSieveBox _ _ _ h₁ h₂, mem_sieveBox]
  simp only [pairBad, Int.cast_natCast]
  constructor
  · rintro ⟨⟨hL₁, hU₁, hL₂, hU₂, hbase⟩, hbad⟩
    exact ⟨hL₁, hU₁, hL₂, hU₂, hbase, fun p => hbad p (by simpa only [Nat.primeFactors_prod hS] using p.property)⟩
  · rintro ⟨hL₁, hU₁, hL₂, hU₂, hbase, hbad⟩
    exact ⟨⟨hL₁, hU₁, hL₂, hU₂, hbase⟩, fun p hp => hbad ⟨p, by simpa only [Nat.primeFactors_prod hS] using hp⟩⟩

/-- The source remainder is bounded by a sum of proved lattice discrepancies.
Distinct prime subsets have distinct product moduli, so the sum has no extra
multiplicity. -/
theorem pair_blockRemainder_le (k : ℕ) [NeZero k]
    (P moduli : Finset ℕ) (cutoff : ℕ → Bool) (D : ℝ)
    (hP : ∀ p ∈ P, p.Prime ∧ k.Coprime p)
    (hmoduli : ∀ S ∈ remainderSubsets P D, (∏ p ∈ S, p) ∈ moduli)
    {M₁ M₂ : ℝ} (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) :
    blockRemainder (encoded (pairArray k M₁ M₂)) (fun _ => 1)
      (fun p n => pairBad cutoff p (Nat.unpair n)) P (pairDensity cutoff)
      (M₁ * M₂ * k.totient / (k : ℝ) ^ 2) D ≤
      ∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2 *
        (M₁ + M₂ + (k : ℝ) * ℓ) := by
  classical
  unfold blockRemainder
  calc
    _ ≤ ∑ S ∈ remainderSubsets P D,
        (((∏ p ∈ S, p).divisors.card : ℝ) ^ 2 *
          (M₁ + M₂ + (k : ℝ) * (∏ p ∈ S, p : ℕ))) := by
      apply Finset.sum_le_sum
      intro S hS
      have hsub : S ⊆ P := Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1
      have hSP : ∀ p ∈ S, p.Prime := fun p hp => (hP p (hsub hp)).1
      have hcop : k.Coprime (∏ p ∈ S, p) :=
        Nat.Coprime.prod_right (fun p hp => (hP p (hsub hp)).2)
      let : NeZero (∏ p ∈ S, p) :=
        ⟨Finset.prod_ne_zero_iff.mpr (fun p hp => (hSP p hp).ne_zero)⟩
      rw [encoded_intersectionMass k S hSP hcop cutoff h₁ h₂,
        pairDensity_product S hSP cutoff]
      exact nat_dyadic_sieveBox_error hcop
        (Cofactor.prime_subset_product_squarefree S hSP) cutoff h₁ h₂
    _ ≤ _ := by
      apply Finset.sum_le_sum_of_injOn (fun S : Finset ℕ => ∏ p ∈ S, p)
      · intro S hS T hT he
        exact Cofactor.prime_subset_product_injective P (fun p hp => (hP p hp).1)
          (Finset.mem_filter.mp hS).1 (Finset.mem_filter.mp hT).1 he
      · intro ℓ hℓ
        obtain ⟨S, hS, rfl⟩ := Finset.mem_image.mp hℓ
        exact hmoduli S hS
      · intro S hS
        exact le_rfl
      · intro ℓ hℓ hnot
        positivity

/-- The actual two-variable upper sieve. Its one constant precedes all boxes,
cofactors, roughness cutoffs, and marking data. Its only arithmetic inputs are
the classical reciprocal-prime block bound and the stated finite modulus
range; every individual lattice discrepancy has already been proved. -/
theorem source_pair_upper (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧
    ∀ (k : ℕ) [NeZero k] (P moduli : Finset ℕ) (cutoff : ℕ → Bool)
      (z M₁ M₂ : ℝ),
      2 ≤ z → 0 ≤ M₁ → 0 ≤ M₂ →
      (∀ p ∈ P, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ z ∧ k.Coprime p) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / (p : ℝ)) ≤ C₀) →
      (∀ S ∈ remainderSubsets P (z ^ (10 : ℕ)), (∏ p ∈ S, p) ∈ moduli) →
      ((siftedPairs k cutoff P M₁ M₂).card : ℝ) ≤
        C * ((M₁ * M₂ * k.totient / (k : ℝ) ^ 2) *
          localProduct P (pairDensity cutoff)) +
        C * ∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2 *
          (M₁ + M₂ + (k : ℝ) * ℓ) := by
  obtain ⟨C, hC, H₀, hs⟩ := source (2/9) (3 * C₀) (by norm_num)
  refine ⟨C, hC, ?_⟩
  intro k inst P moduli cutoff z M₁ M₂ hz h₁ h₂ hP hblock hmoduli
  have hsource := (hs (encoded (pairArray k M₁ M₂)) P (fun _ => 1)
    (fun p n => pairBad cutoff p (Nat.unpair n)) (pairDensity cutoff)
    (M₁ * M₂ * k.totient / (k : ℝ) ^ 2) z
    (by intros; norm_num) (by positivity) hz
    (fun p hp => ⟨(hP p hp).1, (hP p hp).2.2.1⟩)
    (pairDensity_localConditions P cutoff C₀ (fun p hp => (hP p hp).2.1)
      hblock)).2
  rw [encoded_siftedMass] at hsource
  exact hsource.trans (add_le_add le_rfl (mul_le_mul_of_nonneg_left
    (pair_blockRemainder_le k P moduli cutoff (z ^ (10 : ℕ))
      (fun p hp => ⟨(hP p hp).1, (hP p hp).2.2.2⟩) hmoduli h₁ h₂) hC.le))

/-- Sum a pair estimate with its reciprocal cofactor mass intact. This step
never replaces a marking weight by a supremum depending on the marks. -/
theorem weighted_pair_sum_le (R : Finset ℕ) (t B : ℕ → ℝ)
    {A J : ℝ} (hA : 0 ≤ A) (ht : ∀ r ∈ R, 0 ≤ t r)
    (hB : ∀ r ∈ R, B r ≤ A / (r : ℝ))
    (hJ : (∑ r ∈ R, t r / (r : ℝ)) ≤ J) :
    (∑ r ∈ R, t r * B r) ≤ A * J := by
  calc
    _ ≤ ∑ r ∈ R, t r * (A / (r : ℝ)) :=
      Finset.sum_le_sum (fun r hr => mul_le_mul_of_nonneg_left (hB r hr) (ht r hr))
    _ = A * ∑ r ∈ R, t r / (r : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intros
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hJ hA

/-- The cost of removing the cofactor primes is uniform in the marking
parameter. Only their reciprocal mass enters. -/
theorem omitted_localProduct_le (P T : Finset ℕ) (hT : T ⊆ P)
    (cutoff : ℕ → Bool) (hP : ∀ p ∈ P, 3 ≤ p) {τ : ℝ}
    (hmass : (∑ p ∈ T, 1 / (p : ℝ)) ≤ τ) :
    localProduct (P \ T) (pairDensity cutoff) ≤
      Real.exp ((27/2 : ℝ) * τ) * localProduct P (pairDensity cutoff) := by
  have hgap : ∀ p ∈ P, 0 < 1 - pairDensity cutoff p := by
    intro p hp
    have hh := (pairDensity_bounds cutoff (hP p hp)).2
    linarith
  have hn : (∏ p ∈ T, (1 - pairDensity cutoff p)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun p hp => (hgap p (hT hp)).ne')
  have hidentity : localProduct (P \ T) (pairDensity cutoff) =
      localProduct P (pairDensity cutoff) *
        ∏ p ∈ T, (1 - pairDensity cutoff p)⁻¹ := by
    unfold localProduct
    rw [Finset.prod_inv_distrib, ← Finset.prod_sdiff hT,
      mul_assoc, mul_inv_cancel₀ hn, mul_one]
  rw [hidentity]
  have hu := SemiprimeSieve.omitted_product_le_exp T (fun p : ℕ => (p : ℝ))
    (pairDensity cutoff)
    (fun p hp => by exact_mod_cast (show 0 < p by have := hP p (hT hp); omega))
    (fun p hp => by have hh := (pairDensity_bounds cutoff (hP p (hT hp))).2; linarith)
    (fun p hp => pairDensity_le_three_div cutoff (hP p (hT hp))) hmass
  simpa only [localProduct, mul_comm] using mul_le_mul_of_nonneg_left hu
    (Finset.prod_nonneg (fun p hp => (hgap p hp).le))

/-- The actual marked cofactor weights sum against reciprocal cofactors to
at most the full convergent mass `J`; no bound for individual weights appears. -/
theorem weighted_pair_sum_le_full_mass (R P U : Finset ℕ) (W B : ℕ → ℝ)
    {A : ℝ} (hA : 0 ≤ A)
    (hR : ∀ r ∈ R, 0 < r ∧ ConcreteSelector.strip P r ∈ U)
    (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (EnlargedCofactorMass.enlargedReciprocal P U W))
    (hB : ∀ r ∈ R, B r ≤ A / (r : ℝ)) :
    (∑ r ∈ R, W (ConcreteSelector.markedPart P r) * B r) ≤
      A * EnlargedCofactorMass.enlargedMass P U W := by
  apply weighted_pair_sum_le R (fun r => W (ConcreteSelector.markedPart P r)) B
    hA (fun r _ => hW _) hB
  have hb := hsum.sum_le_tsum R (fun n _ => by
    unfold EnlargedCofactorMass.enlargedReciprocal
    split_ifs <;> first | exact div_nonneg (hW _) (Nat.cast_nonneg _) | exact le_rfl)
  have he : (∑ r ∈ R, EnlargedCofactorMass.enlargedReciprocal P U W r) =
      ∑ r ∈ R, W (ConcreteSelector.markedPart P r) / (r : ℝ) := by
    apply Finset.sum_congr rfl
    intro r hr
    simp [EnlargedCofactorMass.enlargedReciprocal, (hR r hr).1, (hR r hr).2]
  rw [he] at hb
  exact hb

/-- Genuine rough factors of a prime predecessor survive the local pair
sieve. Primes dividing the fixed progression/cofactor modulus are simply
omitted, which is permissible for an upper bound. -/
theorem prime_predecessor_not_pairBad {k Q p : ℕ} {z : ℕ × ℕ} {W : ℝ}
    (cutoff : ℕ → Bool) (hp : p.Prime) (hpk : k.Coprime p)
    (hQ : Q.Prime) (hpQ : p < Q) (heq : z.1 * z.2 = k * Q + 1)
    (hm : MarkedCriterion.IsRough W z.1) (hn : MarkedCriterion.IsRough W z.2)
    (hcutoff : cutoff p = true → (p : ℝ) ≤ W) :
    ¬ pairBad cutoff p z := by
  have hone : ¬ (z.1 : ZMod p) * (z.2 : ZMod p) = 1 := by
    intro hh
    have he : ((k * Q + 1 : ℕ) : ZMod p) = 1 := by
      rw [← heq, Nat.cast_mul]
      exact hh
    have hzero : ((k * Q : ℕ) : ZMod p) = 0 := by
      simpa only [Nat.cast_add, Nat.cast_one, add_eq_right] using he
    have hd : p ∣ k * Q := (ZMod.natCast_eq_zero_iff _ _).mp hzero
    have hpQ' : p ∣ Q := (hp.dvd_mul.mp hd).resolve_left
      (hp.coprime_iff_not_dvd.mp hpk.symm)
    have hsame := (Nat.prime_dvd_prime_iff_eq hp hQ).mp hpQ'
    omega
  unfold pairBad localBad
  split_ifs with hc
  · rintro (hh | hh)
    · exact hone hh
    · have hd : p ∣ z.1 * z.2 := by
        apply (ZMod.natCast_eq_zero_iff _ _).mp
        simpa only [Nat.cast_mul] using hh
      rcases hp.dvd_mul.mp hd with hm' | hn'
      · exact not_lt_of_ge (hcutoff hc) (hm p hp hm')
      · exact not_lt_of_ge (hcutoff hc) (hn p hp hn')
  · exact hone

/-- Explicit local density, with natural subtraction converted correctly. -/
theorem pairDensity_formula (cutoff : ℕ → Bool) {p : ℕ} (hp : 3 ≤ p) :
    pairDensity cutoff p =
      if cutoff p then (3 * (p : ℝ) - 2) / (p : ℝ) ^ 2
      else ((p : ℝ) - 1) / (p : ℝ) ^ 2 := by
  have hp1 : 1 ≤ p := by omega
  have hp2 : 2 ≤ 3 * p := by omega
  unfold pairDensity SquarefreeRho.localCount
  split_ifs
  · rw [Nat.cast_sub hp2]; push_cast; rfl
  · rw [Nat.cast_sub hp1]; push_cast; rfl

/-- Both local factors are controlled by ordinary Euler factors and a
convergent positive correction. -/
theorem local_factor_upper (cutoff : ℕ → Bool) {p : ℕ} (hp : 3 ≤ p) :
    1 - pairDensity cutoff p ≤
      ((1 - 1 / (p : ℝ)) *
        (if cutoff p then (1 - 1 / (p : ℝ)) ^ 2 else 1)) *
        Real.exp (1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have hp1 : 1 < (p : ℝ) := by linarith
  have hbase : 0 ≤ 1 - 1 / (p : ℝ) := by
    have hh : 1 / (p : ℝ) ≤ 1 := (div_le_one (by linarith)).2 (by linarith)
    linarith
  have he : 1 ≤ Real.exp (1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
    apply Real.one_le_exp_iff.mpr
    positivity
  rw [pairDensity_formula cutoff hp]
  split_ifs with hc
  · rw [SemiprimeSieve.local_factor_below hp1]
    have hf : 1 - 1 / ((p : ℝ) - 1) ^ 2 ≤ 1 := by
      have hh : 0 ≤ 1 / ((p : ℝ) - 1) ^ 2 := by positivity
      linarith
    have hh := mul_le_mul_of_nonneg_left hf (pow_nonneg hbase 3)
    calc
      _ ≤ (1 - 1 / (p : ℝ)) ^ 3 := by simpa only [mul_one] using hh
      _ ≤ _ := by
        have hm := mul_le_mul_of_nonneg_left he (pow_nonneg hbase 3)
        nlinarith only [hm]
  · rw [SemiprimeSieve.local_factor_above hp1]
    simpa only [mul_one, add_comm] using mul_le_mul_of_nonneg_left
      (Real.add_one_le_exp (1 / ((p : ℝ) * ((p : ℝ) - 1)))) hbase

/-- The complete local product is bounded by two elementary Euler products.
Only the summable correction remains; it has no cofactor or marking dependence. -/
theorem localProduct_euler_upper (P : Finset ℕ) (cutoff : ℕ → Bool)
    (hP : ∀ p ∈ P, 3 ≤ p) :
    localProduct P (pairDensity cutoff) ≤
      ((∏ p ∈ P, (1 - 1 / (p : ℝ))) *
        (∏ p ∈ P.filter (fun p => cutoff p = true), (1 - 1 / (p : ℝ))) ^ 2) *
        Real.exp (∑ p ∈ P, 1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
  classical
  calc
    _ ≤ ∏ p ∈ P, (((1 - 1 / (p : ℝ)) *
        (if cutoff p then (1 - 1 / (p : ℝ)) ^ 2 else 1)) *
        Real.exp (1 / ((p : ℝ) * ((p : ℝ) - 1)))) := by
      apply Finset.prod_le_prod₀
      · intro p hp
        have hh := (pairDensity_bounds cutoff (hP p hp)).2
        linarith
      · exact fun p hp => local_factor_upper cutoff (hP p hp)
    _ = _ := by
      rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib, ← Real.exp_sum]
      congr 2
      rw [Finset.prod_ite, Finset.prod_const_one, mul_one, Finset.prod_pow]

/-- A telescoping sum bounds the correction factor without an analytic input. -/
theorem telescoping_reciprocal (N : ℕ) :
    (∑ n ∈ Finset.range N, 1 / (((n : ℝ) + 1) * ((n : ℝ) + 2))) =
      1 - 1 / ((N : ℝ) + 1) := by
  induction N with
  | zero => norm_num
  | succ N ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    have h1 : (N : ℝ) + 1 ≠ 0 := by positivity
    have h2 : (N : ℝ) + 2 ≠ 0 := by positivity
    field_simp
    ring

/-- Every finite correction product is bounded by the same absolute constant,
regardless of which primes occur. The stronger statement needs only `p≥2`. -/
theorem correction_sum_le_one (P : Finset ℕ) (hP : ∀ p ∈ P, 2 ≤ p) :
    (∑ p ∈ P, 1 / ((p : ℝ) * ((p : ℝ) - 1))) ≤ 1 := by
  have hsum : (∑ p ∈ P, 1 / ((p : ℝ) * ((p : ℝ) - 1))) ≤
      ∑ n ∈ Finset.range (P.sup id),
        1 / (((n : ℝ) + 1) * ((n : ℝ) + 2)) := by
    apply Finset.sum_le_sum_of_injOn (fun p : ℕ => p - 2)
    · intro p hp q hq he
      have hp2 := hP p hp
      have hq2 := hP q hq
      dsimp at he
      omega
    · intro n hn
      obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hn
      have hle : p ≤ P.sup id := Finset.le_sup (f := id) hp
      have hp2 := hP p hp
      rw [Finset.mem_range]
      omega
    · intro p hp
      have hp2 := hP p hp
      have he : ((p - 2 : ℕ) : ℝ) = (p : ℝ) - 2 := by
        rw [Nat.cast_sub hp2]; norm_num
      rw [he]
      have hh : ((p : ℝ) - 2 + 1) * ((p : ℝ) - 2 + 2) =
          (p : ℝ) * ((p : ℝ) - 1) := by ring
      rw [hh]
    · intro n hn hnot
      positivity
  rw [telescoping_reciprocal] at hsum
  have hn : 0 ≤ 1 / (((P.sup id : ℕ) : ℝ) + 1) := by positivity
  linarith

/-- The normalized local sieve product follows directly from two ordinary
Euler-product estimates. All correction and omitted-prime factors are explicit. -/
theorem normalized_localProduct_le (P T : Finset ℕ) (hT : T ⊆ P)
    (cutoff : ℕ → Bool) (hP : ∀ p ∈ P, 3 ≤ p) {τ E V : ℝ}
    (hE : 0 ≤ E) (_hV : 0 ≤ V)
    (hmass : (∑ p ∈ T, 1 / (p : ℝ)) ≤ τ)
    (hEuler : (∏ p ∈ P, (1 - 1 / (p : ℝ))) ≤ E)
    (hRough : (∏ p ∈ P.filter (fun p => cutoff p = true),
      (1 - 1 / (p : ℝ))) ≤ V) :
    localProduct (P \ T) (pairDensity cutoff) ≤
      Real.exp ((27/2 : ℝ) * τ + 1) * E * V ^ 2 := by
  have hbase : ∀ p ∈ P, 0 ≤ 1 - 1 / (p : ℝ) := by
    intro p hp
    have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hP p hp
    have hh : 1 / (p : ℝ) ≤ 1 := (div_le_one (by linarith)).2 (by linarith)
    linarith
  have hprod : 0 ≤ ∏ p ∈ P, (1 - 1 / (p : ℝ)) :=
    Finset.prod_nonneg hbase
  have hrough : 0 ≤ ∏ p ∈ P.filter (fun p => cutoff p = true),
      (1 - 1 / (p : ℝ)) :=
    Finset.prod_nonneg (fun p hp => hbase p (Finset.mem_filter.mp hp).1)
  have hsq := mul_self_le_mul_self hrough hRough
  have heuler :
      ((∏ p ∈ P, (1 - 1 / (p : ℝ))) *
        (∏ p ∈ P.filter (fun p => cutoff p = true), (1 - 1 / (p : ℝ))) ^ 2) ≤
        E * V ^ 2 := by
    apply mul_le_mul hEuler
    · simpa only [pow_two] using hsq
    · positivity
    · exact hE
  have hcor : Real.exp (∑ p ∈ P, 1 / ((p : ℝ) * ((p : ℝ) - 1))) ≤
      Real.exp 1 := Real.exp_le_exp.mpr
        (correction_sum_le_one P (fun p hp => by have := hP p hp; omega))
  calc
    _ ≤ Real.exp ((27/2 : ℝ) * τ) * localProduct P (pairDensity cutoff) :=
      omitted_localProduct_le P T hT cutoff hP hmass
    _ ≤ Real.exp ((27/2 : ℝ) * τ) * ((E * V ^ 2) * Real.exp 1) := by
      apply mul_le_mul_of_nonneg_left _ (Real.exp_nonneg _)
      apply (localProduct_euler_upper P cutoff hP).trans
      exact mul_le_mul heuler hcor (Real.exp_nonneg _) (by positivity)
    _ = _ := by rw [Real.exp_add]; ring

/-- The actual pair count, made total at modulus zero only for convenient
finite cofactor sums. Every application below has positive modulus. -/
noncomputable def pairCount (k : ℕ) (cutoff : ℕ → Bool) (P : Finset ℕ)
    (M₁ M₂ : ℝ) : ℝ :=
  if h : k = 0 then 0 else
    letI : NeZero k := ⟨h⟩
    ((siftedPairs k cutoff P M₁ M₂).card : ℝ)

theorem pairCount_eq (k : ℕ) [NeZero k] (cutoff : ℕ → Bool)
    (P : Finset ℕ) (M₁ M₂ : ℝ) :
    pairCount k cutoff P M₁ M₂ = ((siftedPairs k cutoff P M₁ M₂).card : ℝ) := by
  simp only [pairCount, dite_eq_right (NeZero.ne k)]

/-- The progression mass is at most the box area divided by its modulus. -/
theorem lattice_main_mass_le (k : ℕ) [NeZero k] {M₁ M₂ H : ℝ}
    (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) (hH : M₁ * M₂ ≤ H) :
    M₁ * M₂ * k.totient / (k : ℝ) ^ 2 ≤ H / (k : ℝ) := by
  have hk : (0 : ℝ) < k := by exact_mod_cast NeZero.pos k
  have ht : (k.totient : ℝ) ≤ k := by exact_mod_cast Nat.totient_le k
  calc
    _ ≤ M₁ * M₂ * (k : ℝ) / (k : ℝ) ^ 2 :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left ht (mul_nonneg h₁ h₂))
        (sq_nonneg _)
    _ = M₁ * M₂ / (k : ℝ) := by field_simp
    _ ≤ _ := div_le_div_of_nonneg_right hH hk.le

/-- The depth-two pair sieve summed with the actual marking weights and
normalized by full `J`. Only ordinary Euler-product bounds and a divisor-
moment bound on the displayed lattice remainder remain as scalar inputs.
The source constant is chosen before all marking and cofactor data. -/
theorem source_weighted_full_mass_upper (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧
    ∀ (c : ℕ) (R P U marks moduli : Finset ℕ) (T : ℕ → Finset ℕ)
      (W : ℕ → ℝ) (cutoff : ℕ → Bool) (z M₁ M₂ H τ E V B : ℝ),
      0 < c → 2 ≤ z → 0 ≤ M₁ → 0 ≤ M₂ → M₁ * M₂ ≤ H →
      0 ≤ E → 0 ≤ V → 0 ≤ B →
      (∀ r ∈ R, 0 < r ∧ ConcreteSelector.strip marks r ∈ U) →
      (∀ n, 0 ≤ W n) →
      Summable (EnlargedCofactorMass.enlargedReciprocal marks U W) →
      (∀ p ∈ P, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ z) →
      (∀ r ∈ R, T r ⊆ P) →
      (∀ r ∈ R, ∀ p ∈ P \ T r, (c * r).Coprime p) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / (p : ℝ)) ≤ C₀) →
      (∀ r ∈ R, (∑ p ∈ T r, 1 / (p : ℝ)) ≤ τ) →
      ((∏ p ∈ P, (1 - 1 / (p : ℝ))) ≤ E) →
      ((∏ p ∈ P.filter (fun p => cutoff p = true), (1 - 1 / (p : ℝ))) ≤ V) →
      (∀ r ∈ R, ∀ S ∈ remainderSubsets (P \ T r) (z ^ (10 : ℕ)),
        (∏ p ∈ S, p) ∈ moduli) →
      (∀ r ∈ R, (∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2 *
        (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ)) ≤ B / (r : ℝ)) →
      (∑ r ∈ R, W (ConcreteSelector.markedPart marks r) *
        pairCount (c * r) cutoff (P \ T r) M₁ M₂) ≤
      (C * (H / (c : ℝ) * (Real.exp ((27/2 : ℝ) * τ + 1) * E * V ^ 2) + B)) *
        EnlargedCofactorMass.enlargedMass marks U W := by
  obtain ⟨C, hC, hs⟩ := source_pair_upper source C₀
  refine ⟨C, hC, ?_⟩
  intro c R P U marks moduli T W cutoff z M₁ M₂ H τ E V B
    hc hz h₁ h₂ hH hE hV hB hR hW hsum hP hT hcop hblock hτ hEuler hRough hmoduli herr
  have hH0 : 0 ≤ H := (mul_nonneg h₁ h₂).trans hH
  have hcR : (0 : ℝ) < c := by exact_mod_cast hc
  let F : ℝ := Real.exp ((27/2 : ℝ) * τ + 1) * E * V ^ 2
  have hF : 0 ≤ F := by dsimp [F]; positivity
  apply weighted_pair_sum_le_full_mass R marks U W
    (fun r => pairCount (c * r) cutoff (P \ T r) M₁ M₂)
    (show 0 ≤ C * (H / (c : ℝ) * F + B) by positivity) hR hW hsum
  intro r hr
  let : NeZero (c * r) := ⟨(Nat.mul_pos hc (hR r hr).1).ne'⟩
  have hrR : (0 : ℝ) < r := by exact_mod_cast (hR r hr).1
  have hsubset : P \ T r ⊆ P := Finset.sdiff_subset
  have hblock' : ∀ v : ℝ, 1 < v →
      (∑ p ∈ (P \ T r).filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
        1 / (p : ℝ)) ≤ C₀ := by
    intro v hv
    apply le_trans _ (hblock v hv)
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · exact Finset.filter_subset_filter _ hsubset
    · intros
      positivity
  have hsource := hs (c * r) (P \ T r) moduli cutoff z M₁ M₂ hz h₁ h₂
    (fun p hp => ⟨(hP p (hsubset hp)).1, (hP p (hsubset hp)).2.1,
      (hP p (hsubset hp)).2.2, hcop r hr p hp⟩) hblock' (hmoduli r hr)
  have hpbound := normalized_localProduct_le P (T r) (hT r hr) cutoff
    (fun p hp => (hP p hp).2.1) hE hV (hτ r hr) hEuler hRough
  have hmain :
      (M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2) *
        localProduct (P \ T r) (pairDensity cutoff) ≤
      (H / (c : ℝ) * F) / (r : ℝ) := by
    calc
      _ ≤ (M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2) * F :=
        mul_le_mul_of_nonneg_left hpbound (by positivity)
      _ ≤ (H / ((c * r : ℕ) : ℝ)) * F :=
        mul_le_mul_of_nonneg_right (lattice_main_mass_le (c * r) h₁ h₂ hH) hF
      _ = _ := by push_cast; field_simp
  rw [pairCount_eq]
  calc
    _ ≤ _ := hsource
    _ ≤ C * ((H / (c : ℝ) * F) / (r : ℝ)) + C * (B / (r : ℝ)) :=
      add_le_add (mul_le_mul_of_nonneg_left hmain hC.le)
        (mul_le_mul_of_nonneg_left (herr r hr) hC.le)
    _ = _ := by ring

/-- The actual CRT lattice remainder has the required uniform power saving
once the classical divisor-square moment is supplied. Its threshold and
constant have no marking parameter. -/
theorem lattice_remainder_eventually_small (c : ℕ) (hc : 0 < c)
    {D η : ℝ} (hD : 0 < D) (hη : 0 < η) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ r : ℕ,
      0 < r → (r : ℝ) ≤ x ^ (11/100 : ℝ) →
      ∀ M₁ M₂ : ℝ, 0 ≤ M₁ → 0 ≤ M₂ →
      M₁ + M₂ ≤ 2 * x ^ (54/100 : ℝ) →
      ∀ moduli : Finset ℕ,
      (∀ ℓ ∈ moduli, (ℓ : ℝ) ≤ x ^ (2/100 : ℝ)) →
      ((∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2) ≤
        D * x ^ (2/100 : ℝ) * (Real.log x) ^ 3) →
      (∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2 *
        (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ)) ≤
        η * (x / (r : ℝ)) / (Real.log x) ^ 10 := by
  have hcR : (0 : ℝ) < c := by exact_mod_cast hc
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast hc
  have he := SemiprimeSieve.error_eventually_small_uniform
    (show 0 < 2 * (c : ℝ) * D by positivity) hη
  filter_upwards [he, Filter.eventually_ge_atTop (1 : ℝ)] with x hx hx1
  intro r hr hrx M₁ M₂ h₁ h₂ hM moduli hmoduli hmoment
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  let E : ℕ → ℝ := fun ℓ => (ℓ.divisors.card : ℝ) ^ 2 *
    (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ)
  have hE : ∀ ℓ ∈ moduli, |E ℓ| ≤
      (c : ℝ) * (ℓ.divisors.card : ℝ) ^ 2 * (M₁ + M₂ + (r : ℝ) * ℓ) := by
    intro ℓ hℓ
    dsimp [E]
    rw [abs_of_nonneg (by positivity)]
    have hh : M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ ≤
        (c : ℝ) * (M₁ + M₂ + (r : ℝ) * ℓ) := by
      push_cast
      have hh := mul_le_mul_of_nonneg_right hc1 (add_nonneg h₁ h₂)
      nlinarith only [hh]
    calc
      _ ≤ (ℓ.divisors.card : ℝ) ^ 2 *
          ((c : ℝ) * (M₁ + M₂ + (r : ℝ) * ℓ)) :=
        mul_le_mul_of_nonneg_left hh (sq_nonneg _)
      _ = _ := by ring
  have hm := SemiprimeSieve.lattice_error_moment_bound moduli E
    (fun ℓ => (ℓ.divisors.card : ℝ) ^ 2) (fun ℓ : ℕ => (ℓ : ℝ))
    hx1 hrR.le hcR.le hD.le (add_nonneg h₁ h₂) hM
    (fun _ _ => sq_nonneg _) hmoduli hE hmoment
  have hactual : (∑ ℓ ∈ moduli, |E ℓ|) =
      (∑ ℓ ∈ moduli, (ℓ.divisors.card : ℝ) ^ 2 *
        (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ)) := by
    apply Finset.sum_congr rfl
    intros
    dsimp [E]
    rw [abs_of_nonneg (by positivity)]
  rw [hactual] at hm
  exact hm.trans (hx (r : ℝ) hrR hrx)

/-- Total version of the sifted pair set, for indexing by all natural cofactors. -/
noncomputable def pairSet (k : ℕ) (cutoff : ℕ → Bool) (P : Finset ℕ)
    (M₁ M₂ : ℝ) : Finset (ℕ × ℕ) :=
  if h : k = 0 then ∅ else
    letI : NeZero k := ⟨h⟩
    siftedPairs k cutoff P M₁ M₂

theorem pairSet_eq (k : ℕ) [NeZero k] (cutoff : ℕ → Bool)
    (P : Finset ℕ) (M₁ M₂ : ℝ) :
    pairSet k cutoff P M₁ M₂ = siftedPairs k cutoff P M₁ M₂ := by
  simp only [pairSet, dite_eq_right (NeZero.ne k)]

theorem pairSet_card (k : ℕ) (cutoff : ℕ → Bool)
    (P : Finset ℕ) (M₁ M₂ : ℝ) :
    ((pairSet k cutoff P M₁ M₂).card : ℝ) = pairCount k cutoff P M₁ M₂ := by
  unfold pairSet pairCount
  split_ifs <;> simp

/-- Every nonzero rough-pair weight is bounded by one actual cofactor term.
The cofactor is reconstructed from the selector, with all marked prime powers
retained, and its `x^0.11` bound follows from the large prime predecessor. -/
theorem actualWeight_pair_witness {ι : Type*}
    (M u c : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (marks allowed : Finset ℕ) (sieving : ℕ → Finset ℕ) (cutoff : ℕ → Bool)
    {x Qmin W M₁ M₂ : ℝ} (hx : 1 ≤ x) (hc : c = 2 ∨ c = 4)
    (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂)
    (hQmin : x ^ (9/10 : ℝ) ≤ Qmin)
    (hmarks : ∀ p ∈ marks, p.Prime ∧ p ≠ 2 ∧ (p : ℝ) ≤ Qmin)
    (hgroups : ∀ i ∈ I, groups i ⊆ marks) (hV : ∀ i ∈ I, 0 < V i)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ marks, ¬ p ∣ r)
    (hΨ : ∀ d, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d, Ψ d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ 2 * x)
    (hprimes : ∀ r ∈ MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ)),
      ∀ p ∈ sieving r, p.Prime ∧ (p : ℝ) ≤ Qmin ∧ (c * r).Coprime p ∧
        (cutoff p = true → (p : ℝ) ≤ W))
    {z : ℕ × ℕ}
    (hbox : M₁ ≤ (z.1 : ℝ) ∧ (z.1 : ℝ) < 2 * M₁ ∧
      M₂ ≤ (z.2 : ℝ) ∧ (z.2 : ℝ) < 2 * M₂)
    (hm : MarkedCriterion.IsRough W z.1) (hn : MarkedCriterion.IsRough W z.2)
    (hw : ConcreteSelector.arithmeticWeight M u Ψ I groups V marks c allowed Qmin (z.1 * z.2) ≠ 0) :
    ∃ r ∈ MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ)),
      z ∈ pairSet (c * r) cutoff (sieving r) M₁ M₂ ∧
      ConcreteSelector.arithmeticWeight M u Ψ I groups V marks c allowed Qmin (z.1 * z.2) ≤
        ConcreteSelector.markingWeight I groups V (ConcreteSelector.markedPart marks r) := by
  classical
  have hsmooth := WeightSupport.smooth_ne_zero_of_weight_ne_zero M u Ψ I groups V
    marks allowed c Qmin (z.1 * z.2) hw
  have hselected := (ConcreteSelector.arithmeticWeight_ne_zero_support M u Ψ I groups V
    marks c allowed Qmin (z.1 * z.2) hw).2
  obtain ⟨r, Q, hr, hrallowed, hQ, hlarge, heq⟩ :=
    WeightSupport.selected_predecessor (hsupport _ hsmooth).1 hallowed hselected
  have hcpos : 0 < c := by rcases hc with rfl | rfl <;> norm_num
  have hbound := CofactorRepresentation.cofactor_bound_eleven_hundredths hx hc
    (by rw [← heq]; exact (hsupport _ hsmooth).2) (hQmin.trans_lt hlarge)
  have hrR : r ∈ MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ)) :=
    (MarkedCofactorEstimate.mem_boundedCofactors _ _ _ _).mpr ⟨hr, hrallowed, hbound⟩
  let : NeZero (c * r) := ⟨(Nat.mul_pos hcpos hr).ne'⟩
  refine ⟨r, hrR, ?_, ?_⟩
  · rw [pairSet_eq, siftedPairs, Finset.mem_filter]
    constructor
    · rw [mem_pairArray (c * r) h₁ h₂]
      refine ⟨hbox.1, hbox.2.1, hbox.2.2.1, hbox.2.2.2, ?_⟩
      have he : ((z.1 * z.2 : ℕ) : ZMod (c * r)) =
          ((c * r * Q + 1 : ℕ) : ZMod (c * r)) := congrArg (fun n : ℕ => (n : ZMod (c * r))) heq
      have hcr : (c : ZMod (c * r)) * (r : ZMod (c * r)) = 0 := by
        rw [← Nat.cast_mul, ZMod.natCast_self]
      simpa only [Nat.cast_mul, Nat.cast_add, Nat.cast_one, hcr,
        zero_mul, zero_add] using he
    · intro p hp
      have hpp := hprimes r hrR p hp
      apply prime_predecessor_not_pairBad cutoff hpp.1 hpp.2.2.1 hQ
        (by exact_mod_cast hpp.2.1.trans_lt hlarge) heq hm hn hpp.2.2.2
  · rw [heq, CofactorRepresentation.arithmeticWeight_at_predecessor M u Ψ I groups V
      marks allowed hcpos.ne' hr.ne' hQ hlarge hgroups
      (CofactorRepresentation.two_or_four_avoids_marked marks hc
        (fun p hp => ⟨(hmarks p hp).1, (hmarks p hp).2.1⟩))
      (CofactorRepresentation.large_prime_avoids_marked marks
        (fun p hp => ⟨(hmarks p hp).1, (hmarks p hp).2.2⟩) hQ hlarge) hrallowed,
      ConcreteSelector.markingWeight_markedPart I groups V marks r hgroups]
    have ht := (ConcreteSelector.markingWeight_bounds I groups V r hV).1
    split_ifs
    · exact (mul_le_mul_of_nonneg_left (hΨ _).2 ht).trans_eq (mul_one _)
    · simpa only [mul_zero] using ht

/-- Nonnegative cofactor weights may cover the same lattice point more than
once in an upper bound. No uniqueness or multiplicity loss is needed. -/
theorem finite_weighted_cover (A : Finset (ℕ × ℕ)) (R : Finset ℕ)
    (w : ℕ × ℕ → ℝ) (t : ℕ → ℝ) (S : ℕ → Finset (ℕ × ℕ))
    (ht : ∀ r ∈ R, 0 ≤ t r)
    (hcover : ∀ z ∈ A, w z ≠ 0 → ∃ r ∈ R, z ∈ S r ∧ w z ≤ t r) :
    (∑ z ∈ A, w z) ≤ ∑ r ∈ R, t r * ((S r).card : ℝ) := by
  classical
  have hpoint : ∀ z ∈ A, w z ≤ ∑ r ∈ R, if z ∈ S r then t r else 0 := by
    intro z hz
    by_cases hw : w z = 0
    · rw [hw]
      apply Finset.sum_nonneg
      intro r hr
      split_ifs <;> first | exact ht r hr | exact le_rfl
    · obtain ⟨r, hr, hzS, hwt⟩ := hcover z hz hw
      apply hwt.trans
      have hs := Finset.single_le_sum
        (s := R) (f := fun r => if z ∈ S r then t r else 0)
        (fun r hr => by split_ifs <;> first | exact ht r hr | exact le_rfl) hr
      simpa only [ite_eq_left hzS] using hs
  calc
    _ ≤ ∑ z ∈ A, ∑ r ∈ R, if z ∈ S r then t r else 0 := Finset.sum_le_sum hpoint
    _ = ∑ r ∈ R, ∑ z ∈ A, if z ∈ S r then t r else 0 := Finset.sum_comm
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro r hr
      calc
        _ = ∑ z ∈ A.filter (fun z => z ∈ S r), t r := by rw [Finset.sum_filter]
        _ ≤ ∑ z ∈ S r, t r := by
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro z hz
            exact (Finset.mem_filter.mp hz).2
          · intros
            exact ht r hr
        _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul]; ring

/-- The literal rough-pair sum of the manuscript's arithmetic weight is
bounded by the actual cofactor pair arrays. This supplies the missing bridge
between marked replacement and the two-variable upper sieve. -/
theorem actualWeight_rough_pairMass_le {ι : Type*}
    (A B : Finset ℕ) (M u c : ℕ) (Ψ : ℕ → ℝ)
    (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (marks allowed : Finset ℕ) (sieving : ℕ → Finset ℕ) (cutoff : ℕ → Bool)
    {x Qmin W M₁ M₂ : ℝ} (hx : 1 ≤ x) (hc : c = 2 ∨ c = 4)
    (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂)
    (hQmin : x ^ (9/10 : ℝ) ≤ Qmin)
    (hmarks : ∀ p ∈ marks, p.Prime ∧ p ≠ 2 ∧ (p : ℝ) ≤ Qmin)
    (hgroups : ∀ i ∈ I, groups i ⊆ marks) (hV : ∀ i ∈ I, 0 < V i)
    (hallowed : ∀ r ∈ allowed, 0 < r ∧ ∀ p ∈ marks, ¬ p ∣ r)
    (hΨ : ∀ d, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d, Ψ d ≠ 0 → 2 ≤ d ∧ (d : ℝ) ≤ 2 * x)
    (hprimes : ∀ r ∈ MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ)),
      ∀ p ∈ sieving r, p.Prime ∧ (p : ℝ) ≤ Qmin ∧ (c * r).Coprime p ∧
        (cutoff p = true → (p : ℝ) ≤ W))
    (hA : ∀ m ∈ A, M₁ ≤ (m : ℝ) ∧ (m : ℝ) < 2 * M₁)
    (hB : ∀ n ∈ B, M₂ ≤ (n : ℝ) ∧ (n : ℝ) < 2 * M₂) :
    SemiprimeReplacement.pairMass A B
      (ConcreteSelector.arithmeticWeight M u Ψ I groups V marks c allowed Qmin)
      (RoughCompanion.realRoughIndicator W) (RoughCompanion.realRoughIndicator W) ≤
    ∑ r ∈ MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ)),
      ConcreteSelector.markingWeight I groups V (ConcreteSelector.markedPart marks r) *
        pairCount (c * r) cutoff (sieving r) M₁ M₂ := by
  classical
  let w := ConcreteSelector.arithmeticWeight M u Ψ I groups V marks c allowed Qmin
  let R := MarkedCofactorEstimate.boundedCofactors marks allowed (x ^ (11/100 : ℝ))
  have hh := finite_weighted_cover (A.product B) R
    (fun z => w (z.1 * z.2) * RoughCompanion.realRoughIndicator W z.1 *
      RoughCompanion.realRoughIndicator W z.2)
    (fun r => ConcreteSelector.markingWeight I groups V (ConcreteSelector.markedPart marks r))
    (fun r => pairSet (c * r) cutoff (sieving r) M₁ M₂)
    (fun r _ => (ConcreteSelector.markingWeight_bounds I groups V
      (ConcreteSelector.markedPart marks r) hV).1) ?_
  · rw [Finset.product_eq_sprod, Finset.sum_product A B] at hh
    simpa only [pairSet_card, SemiprimeReplacement.pairMass, w, R] using hh
  intro z hz hnz
  obtain ⟨hmA, hnB⟩ := Finset.mem_product.mp hz
  have hm : MarkedCriterion.IsRough W z.1 := by
    by_contra h
    simp [RoughCompanion.realRoughIndicator, h] at hnz
  have hn : MarkedCriterion.IsRough W z.2 := by
    by_contra h
    simp [RoughCompanion.realRoughIndicator, h] at hnz
  have hw : w (z.1 * z.2) ≠ 0 := by
    simpa only [RoughCompanion.realRoughIndicator, ite_eq_left hm, ite_eq_left hn, mul_one] using hnz
  obtain ⟨r, hr, hzS, hwt⟩ := actualWeight_pair_witness M u c Ψ I groups V marks allowed
    sieving cutoff hx hc h₁ h₂ hQmin hmarks hgroups hV hallowed hΨ hsupport hprimes
    ⟨(hA z.1 hmA).1, (hA z.1 hmA).2, (hB z.2 hnB).1, (hB z.2 hnB).2⟩ hm hn hw
  refine ⟨r, hr, hzS, ?_⟩
  simpa only [RoughCompanion.realRoughIndicator, ite_eq_left hm, ite_eq_left hn, mul_one, w] using hwt

end Artin.RoughPairSieve
