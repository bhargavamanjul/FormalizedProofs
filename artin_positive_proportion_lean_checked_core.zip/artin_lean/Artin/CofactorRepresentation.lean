module

public import Artin.MarkedCofactorMass

/-!
# Uniqueness of the predecessor representation and actual progression sums

The large prime is recovered from the integer, because every prime divisor
of the cofactor lies below its cutoff. This justifies reindexing the integer
weight by the cofactor and the large prime, without counting multiplicities.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.CofactorRepresentation

open ConcreteSelector

/-- A prime above the cofactor's prime-factor cutoff cannot divide it. -/
theorem large_prime_not_dvd {r Q : ℕ} {Z : ℝ}
    (hsmall : ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hQ : Q.Prime) (hlarge : Z < (Q : ℝ)) : ¬ Q ∣ r := by
  intro hdiv
  exact (not_lt_of_ge (hsmall Q hQ hdiv)) hlarge

/-- The prime and its cofactor are uniquely determined. No squarefreeness
assumption is needed for the small-prime cofactor. -/
theorem large_prime_factor_unique {r r' Q Q' : ℕ} {Z : ℝ}
    (hQ : Q.Prime) (hQ' : Q'.Prime) (hlarge : Z < (Q : ℝ))
    (hsmall' : ∀ p : ℕ, p.Prime → p ∣ r' → (p : ℝ) ≤ Z)
    (heq : r * Q = r' * Q') : r = r' ∧ Q = Q' := by
  have hdiv : Q ∣ r' * Q' := by rw [← heq]; exact Nat.dvd_mul_left Q r
  have hQQ' : Q ∣ Q' := (hQ.dvd_mul.mp hdiv).resolve_left
    (large_prime_not_dvd hsmall' hQ hlarge)
  have hsame : Q = Q' := (Nat.prime_dvd_prime_iff_eq hQ hQ').mp hQQ'
  refine ⟨?_, hsame⟩
  rw [hsame] at heq
  exact Nat.eq_of_mul_eq_mul_right hQ'.pos heq

/-- The selector's large-prime witness is unique, including after repeated
marked primes have been stripped. -/
theorem selection_witness_unique {P allowed : Finset ℕ} {c h r r' Q Q' : ℕ}
    {Z Qmin : ℝ} (hc : 0 < c) (hcut : Z ≤ Qmin)
    (hsmall : ∀ r ∈ allowed, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hw : SelectionWitness P c allowed Qmin h r Q)
    (hw' : SelectionWitness P c allowed Qmin h r' Q') : r = r' ∧ Q = Q' := by
  have heq : c * (r * Q) = c * (r' * Q') := by
    simpa only [Nat.mul_assoc] using hw.2.2.2.symm.trans hw'.2.2.2
  exact large_prime_factor_unique hw.2.1 hw'.2.1 (hcut.trans_lt hw.2.2.1)
    (hsmall r' hw'.1) (Nat.eq_of_mul_eq_mul_left hc heq)

/-- The exact map used in the progression count. -/
def predecessorValue (c : ℕ) (rQ : ℕ × ℕ) : ℕ := c * rQ.1 * rQ.2 + 1

noncomputable def predecessorIntegers (c : ℕ) (R Qs : Finset ℕ) : Finset ℕ :=
  (R ×ˢ Qs).image (predecessorValue c)

/-- Different eligible cofactor/prime pairs produce different integers. -/
theorem predecessorValue_injective (c : ℕ) (R Qs : Finset ℕ) {Z : ℝ}
    (hc : 0 < c)
    (hR : ∀ r ∈ R, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hQ : ∀ Q ∈ Qs, Q.Prime ∧ Z < (Q : ℝ)) :
    Set.InjOn (predecessorValue c) (↑(R ×ˢ Qs) : Set (ℕ × ℕ)) := by
  intro z hz z' hz' heq
  obtain ⟨hzR, hzQ⟩ := Finset.mem_product.mp hz
  obtain ⟨hz'R, hz'Q⟩ := Finset.mem_product.mp hz'
  have heq' : c * (z.1 * z.2) = c * (z'.1 * z'.2) := by
    simpa only [predecessorValue, Nat.add_left_inj, Nat.mul_assoc] using heq
  obtain ⟨hr, hq⟩ := large_prime_factor_unique (hQ z.2 hzQ).1 (hQ z'.2 hz'Q).1
    (hQ z.2 hzQ).2 (hR z'.1 hz'R) (Nat.eq_of_mul_eq_mul_left hc heq')
  exact Prod.ext hr hq

/-- An actual weighted integer sum equals its progression sum over distinct
cofactors and prime witnesses. No multiplicity constant is lost. -/
theorem sum_predecessorIntegers (c : ℕ) (R Qs : Finset ℕ) (w : ℕ → ℝ) {Z : ℝ}
    (hc : 0 < c)
    (hR : ∀ r ∈ R, ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hQ : ∀ Q ∈ Qs, Q.Prime ∧ Z < (Q : ℝ)) :
    (∑ d ∈ predecessorIntegers c R Qs, w d) =
      ∑ r ∈ R, ∑ Q ∈ Qs, w (c * r * Q + 1) := by
  classical
  rw [predecessorIntegers, Finset.sum_image (predecessorValue_injective c R Qs hc hR hQ),
    Finset.sum_product]
  rfl

/-- A large prime avoids the marked set when its members lie below the
large-prime cutoff. -/
theorem large_prime_avoids_marked (P : Finset ℕ) {Q : ℕ} {Qmin : ℝ}
    (hP : ∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ Qmin)
    (hQ : Q.Prime) (hlarge : Qmin < (Q : ℝ)) : ∀ p ∈ P, ¬ p ∣ Q := by
  intro p hp hdiv
  have heq := (Nat.prime_dvd_prime_iff_eq (hP p hp).1 hQ).mp hdiv
  have hle := (hP p hp).2
  rw [heq] at hle
  exact (not_lt_of_ge hle) hlarge

/-- The power of two in the fixed progression avoids all odd marked primes. -/
theorem two_or_four_avoids_marked (P : Finset ℕ) {c : ℕ}
    (hc : c = 2 ∨ c = 4) (hP : ∀ p ∈ P, p.Prime ∧ p ≠ 2) :
    ∀ p ∈ P, ¬ p ∣ c := by
  intro p hp hdiv
  exact (hP p hp).2 (Artin.prime_dvd_two_or_four (hP p hp).1 hc hdiv)

/-- On a represented integer, the concrete selector is one and the marking
weight is the cofactor's marking weight. Thus the remaining weight is exactly
the smooth progression weight on the prime variable. -/
theorem arithmeticWeight_at_predecessor {ι : Type*}
    (M u : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P allowed : Finset ℕ) {c r Q : ℕ} {Qmin : ℝ}
    (hc : c ≠ 0) (hr : r ≠ 0) (hQ : Q.Prime) (hlarge : Qmin < (Q : ℝ))
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hcP : ∀ p ∈ P, ¬ p ∣ c) (hQP : ∀ p ∈ P, ¬ p ∣ Q)
    (hr₀ : strip P r ∈ allowed) :
    arithmeticWeight M u Ψ I groups V P c allowed Qmin (c * r * Q + 1) =
      markingWeight I groups V r *
        (if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0) := by
  classical
  have hstrip : strip P (c * r * Q) = c * strip P r * Q := by
    rw [strip_mul P (mul_ne_zero hc hr) hQ.ne_zero, strip_mul P hc hr,
      strip_eq_self_of_avoids P hc hcP, strip_eq_self_of_avoids P hQ.ne_zero hQP]
  have hsel : Selected P c allowed Qmin (c * r * Q) :=
    ⟨strip P r, Q, hr₀, hQ, hlarge, hstrip⟩
  have hpart : markedPart P (c * r * Q) = markedPart P r := by
    rw [markedPart_mul P (mul_ne_zero hc hr) hQ.ne_zero, markedPart_mul P hc hr,
      markedPart_eq_one_of_avoids P hcP, markedPart_eq_one_of_avoids P hQP,
      one_mul, mul_one]
  have hweight : markingWeight I groups V (c * r * Q) = markingWeight I groups V r := by
    rw [← markingWeight_markedPart I groups V P _ hgroups, hpart,
      markingWeight_markedPart I groups V P _ hgroups]
  simp only [arithmeticWeight, Nat.add_sub_cancel, selector, hsel, ite_true, mul_one, hweight]
  split_ifs <;> ring

/-- The actual prime progression sum `A_r`, with an arbitrary finite prime
cutoff and the manuscript's smooth weight evaluated at the represented integer. -/
noncomputable def primeProgressionSum (c M u : ℕ) (Qs : Finset ℕ) (Ψ : ℕ → ℝ)
    (r : ℕ) : ℝ :=
  ∑ Q ∈ Qs, if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0

/-- The finite form of `X₀ = Σ_r t_r A_r` for the concrete arithmetic weight.
All support and uniqueness assertions are proved by the preceding lemmas. -/
theorem arithmeticWeight_sum_eq {ι : Type*}
    (M u c : ℕ) (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P allowed R Qs : Finset ℕ) {Z Qmin : ℝ}
    (hc : 0 < c) (hcut : Z ≤ Qmin)
    (hP : ∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ Qmin)
    (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hcP : ∀ p ∈ P, ¬ p ∣ c)
    (hR : ∀ r ∈ R, r ≠ 0 ∧ strip P r ∈ allowed ∧
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hQ : ∀ Q ∈ Qs, Q.Prime ∧ Qmin < (Q : ℝ)) :
    (∑ d ∈ predecessorIntegers c R Qs,
      arithmeticWeight M u Ψ I groups V P c allowed Qmin d) =
      ∑ r ∈ R, markingWeight I groups V r * primeProgressionSum c M u Qs Ψ r := by
  rw [sum_predecessorIntegers c R Qs _ hc (fun r hr => (hR r hr).2.2)
    (fun Q hq => ⟨(hQ Q hq).1, hcut.trans_lt (hQ Q hq).2⟩)]
  apply Finset.sum_congr rfl
  intro r hr
  rw [primeProgressionSum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro Q hq
  exact arithmeticWeight_at_predecessor M u Ψ I groups V P allowed hc.ne'
    (hR r hr).1 (hQ Q hq).1 (hQ Q hq).2 hgroups hcP
    (large_prime_avoids_marked P hP (hQ Q hq).1 (hQ Q hq).2) (hR r hr).2.1

/-- The large prime forces the entire cofactor to be small, before its finer
tail cutoff is imposed. For `γ=0.9` this even gives `r≤x^0.1`. -/
theorem cofactor_bound_of_large_prime {c r Q : ℕ} {x γ : ℝ}
    (hx : 0 < x) (hc : 2 ≤ c)
    (hsize : ((c * r * Q + 1 : ℕ) : ℝ) ≤ 2 * x)
    (hlarge : x ^ γ < (Q : ℝ)) : (r : ℝ) ≤ x ^ (1 - γ) := by
  have hcR : (2 : ℝ) ≤ c := by exact_mod_cast hc
  have hr0 : (0 : ℝ) ≤ r := Nat.cast_nonneg _
  have hQ0 : (0 : ℝ) ≤ Q := Nat.cast_nonneg _
  have hprod : (r : ℝ) * Q ≤ x := by
    push_cast at hsize
    nlinarith [mul_nonneg (by linarith : 0 ≤ (c : ℝ) - 2) (mul_nonneg hr0 hQ0)]
  have hpow : x ^ (1 - γ) * x ^ γ = x := by
    rw [← Real.rpow_add hx]
    simp
  apply (mul_le_mul_iff_of_pos_right (Real.rpow_pos_of_pos hx γ)).mp
  rw [hpow]
  exact (mul_le_mul_of_nonneg_left hlarge.le hr0).trans hprod

theorem cofactor_bound_eleven_hundredths {c r Q : ℕ} {x : ℝ}
    (hx : 1 ≤ x) (hc : c = 2 ∨ c = 4)
    (hsize : ((c * r * Q + 1 : ℕ) : ℝ) ≤ 2 * x)
    (hlarge : x ^ (9 / 10 : ℝ) < (Q : ℝ)) :
    (r : ℝ) ≤ x ^ (11 / 100 : ℝ) := by
  have hc2 : 2 ≤ c := by rcases hc with rfl | rfl <;> omega
  exact (cofactor_bound_of_large_prime (by linarith) hc2 hsize hlarge).trans
    (Real.rpow_le_rpow_of_exponent_le hx (by norm_num))

end Artin.CofactorRepresentation
