module

public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Ring

/-!
# Exact affine changes of variable

These interval-integral identities are unconditional in the integrand.  The
affine slope is positive, and its inverse gives the exact Jacobian factor.
-/

@[expose] public section

open MeasureTheory

namespace Artin.PrimeDistribution

/-- Exact pullback by the affine map occurring in the prime variable. -/
theorem integral_affine_pullback (Ψ : ℝ → ℝ) {x s A B : ℝ}
    (hx : 0 < x) (hs : 0 < s) :
    (∫ t in ((x * A - 1) / s)..((x * B - 1) / s), Ψ ((s * t + 1) / x)) =
      (x / s) * (∫ y in A..B, Ψ y) := by
  have ha (y : ℝ) : (s / x) * ((x * y - 1) / s) + 1 / x = y := by
    field_simp
    ring
  have hf (t : ℝ) : (s * t + 1) / x = (s / x) * t + 1 / x := by ring
  simp_rw [hf]
  rw [intervalIntegral.integral_comp_mul_add Ψ (div_ne_zero hs.ne' hx.ne'), ha, ha]
  simp [div_eq_mul_inv]

/-- The same pullback keeps the logarithmic density exactly. -/
theorem integral_affine_pullback_div_log (Ψ : ℝ → ℝ) {x s A B : ℝ}
    (hx : 0 < x) (hs : 0 < s) :
    (∫ t in ((x * A - 1) / s)..((x * B - 1) / s),
      Ψ ((s * t + 1) / x) / Real.log t) =
      (x / s) * (∫ y in A..B, Ψ y / Real.log ((x * y - 1) / s)) := by
  have hinv (t : ℝ) : (x * ((s * t + 1) / x) - 1) / s = t := by
    field_simp
    ring
  convert integral_affine_pullback
    (fun y => Ψ y / Real.log ((x * y - 1) / s)) hx hs using 1
  simp only [hinv]

/-- A function supported on an inner closed interval has the same integral
on every enclosing interval.  No integrability premise is needed. -/
theorem integral_restrict_of_zero_outside (f : ℝ → ℝ) {a b lo hi : ℝ}
    (ha : a ≤ lo) (hinner : lo ≤ hi) (hb : hi ≤ b)
    (hzero : ∀ t, t ∉ Set.Icc lo hi → f t = 0) :
    (∫ t in a..b, f t) = ∫ t in lo..hi, f t := by
  rw [intervalIntegral.integral_of_le (ha.trans (hinner.trans hb)),
    intervalIntegral.integral_of_le hinner,
    ← integral_Icc_eq_integral_Ioc, ← integral_Icc_eq_integral_Ioc]
  exact setIntegral_eq_of_subset_of_forall_sdiff_eq_zero measurableSet_Icc
    (Set.Icc_subset_Icc ha hb) (fun t ht => hzero t ht.2)

end Artin.PrimeDistribution
