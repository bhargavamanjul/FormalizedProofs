module

public import Artin.RoughPairNormalization
public import Artin.ManuscriptMass

/-!
# The normalized rough-pair bound for the actual arithmetic weight

The sieve, local Euler products, omission bounds, lattice remainder, full
marked mass, and literal selector support are assembled here. The final
constant is fixed before every marking choice and every small parameter.
-/

@[expose] public section
open scoped BigOperators
open Filter

namespace Artin.ActualRoughPair

open RoughPairNormalization RoughPairSieve BuchstabSieve MarkedCofactorEstimate
  ConcreteSelector EnlargedCofactorMass ManuscriptMass

/-- The actual per-cofactor lattice pair bound, uniformly in all eligible
boxes and cofactors. All constants precede every marking parameter. -/
theorem uniform_pairCount_bound (source : SourceLemma11_1)
    (hBlock : ClassicalPrimeBlockBound) (hUpper : ClassicalMertensUpper)
    (hLower : RoughCompanion.ClassicalMertensLower) (hDiv : ClassicalDivisorSquareMoment)
    {c : ℕ} (hc : c = 2 ∨ c = 4) :
    ∃ C : ℝ, 0 < C ∧ ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ),
      (∀ i ∈ I, (1 / 10 : ℝ) ≤ a i) → ∀ τ : ℝ, 0 < τ → τ ≤ 1 →
      ∀ᶠ x : ℝ in atTop, ∀ ε Y M₁ M₂ : ℝ,
      0 ≤ M₁ → 0 ≤ M₂ → M₁ * M₂ ≤ 2 * x →
      M₁ + M₂ ≤ 2 * x ^ (54 / 100 : ℝ) →
      ∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (x ^ (11 / 100 : ℝ)),
      pairCount (c * r) (roughCutoff (MarkedSource.W x))
        (oddPrimes (sieveScale x) \ omittedPrimes (sieveScale x) r) M₁ M₂ ≤
        C * x / r / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2 := by
  obtain ⟨C₀, hC₀, hblock⟩ := hBlock
  obtain ⟨C, hC, hs⟩ := source_pair_upper source C₀
  obtain ⟨D, hD, hlocal⟩ := actual_localProduct_bound hUpper
  obtain ⟨E, hE, hmoment⟩ := eventual_moduli_moment hDiv
  have hcpos : 0 < c := by rcases hc with rfl | rfl <;> norm_num
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast hcpos
  refine ⟨C * (2 * D + 1), by positivity, ?_⟩
  intro ι I a ha τ hτ hτmax
  filter_upwards [hlocal I a ha τ hτ hτmax, hmoment,
    lattice_remainder_eventually_small c hcpos hE (by norm_num : (0 : ℝ) < 1),
    eventual_error_normalization hLower, eventual_cutoff_order,
    eventually_ge_atTop (2 : ℝ)] with x hl hm he hn hz hx
  intro ε Y M₁ M₂ h₁ h₂ harea hsum r hr
  obtain ⟨hrpos, _, hrange⟩ := (mem_boundedCofactors _ _ _ r).mp hr
  let : NeZero (c * r) := ⟨(Nat.mul_pos hcpos hrpos).ne'⟩
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos (by linarith)
  have hr0 : (0 : ℝ) < r := by exact_mod_cast hrpos
  let P := oddPrimes (sieveScale x) \ omittedPrimes (sieveScale x) r
  have hz0 : 0 ≤ sieveScale x := by linarith [hz.2.2]
  have hP : ∀ p ∈ P, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ sieveScale x ∧ (c * r).Coprime p := by
    intro p hp
    have hh := (mem_oddPrimes hz0).mp (Finset.mem_sdiff.mp hp).1
    exact ⟨hh.1, hh.2.1, hh.2.2, coprime_outside_omitted hc hrpos hz0 hp⟩
  have hblocks : ∀ v : ℝ, 1 < v →
      (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2), 1 / (p : ℝ)) ≤ C₀ := by
    intro v hv
    apply le_trans _ (odd_prime_block_bound hblock (sieveScale x) v hv)
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset_filter _ Finset.sdiff_subset)
    intros
    positivity
  have hb := hs (c * r) P (sieveModuli x) (roughCutoff (MarkedSource.W x))
    (sieveScale x) M₁ M₂ hz.2.2 h₁ h₂ hP hblocks
    (fun S hS => remainder_product_mem_moduli hx1 (omittedPrimes (sieveScale x) r) hS)
  have herr := he r hrpos hrange M₁ M₂ h₁ h₂ hsum (sieveModuli x)
    (fun ℓ hℓ => (by
      have hb := (Finset.mem_Icc.mp hℓ).2
      exact (Nat.cast_le.mpr hb).trans (Nat.floor_le (by positivity)))) hm
  have herr' : (∑ ℓ ∈ sieveModuli x, (ℓ.divisors.card : ℝ) ^ 2 *
      (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ)) ≤
      (x / r / Real.log x) * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2 := by
    calc
      _ ≤ (x / r) / (Real.log x) ^ (10 : ℕ) := by simpa using herr
      _ = (x / (Real.log x) ^ (10 : ℕ)) / r := by ring
      _ ≤ (x / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2) / r :=
        div_le_div_of_nonneg_right hn hr0.le
      _ = _ := by ring
  have hmain : M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2 ≤ 2 * x / r := by
    apply (lattice_main_mass_le (c * r) h₁ h₂ harea).trans
    apply div_le_div_of_nonneg_left (by positivity) hr0
    push_cast
    nlinarith [mul_le_mul_of_nonneg_right hc1 hr0.le]
  have hpbound := hl ε Y r hr
  have hmain' : (M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2) *
      localProduct P (pairDensity (roughCutoff (MarkedSource.W x))) ≤
      (2 * x / r) * (D / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2) := by
    calc
      _ ≤ (M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2) *
          (D / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2) :=
        mul_le_mul_of_nonneg_left hpbound (by positivity)
      _ ≤ _ := mul_le_mul_of_nonneg_right hmain (by positivity)
  rw [pairCount_eq]
  exact hb.trans ((add_le_add (mul_le_mul_of_nonneg_left hmain' hC.le)
    (mul_le_mul_of_nonneg_left herr' hC.le)).trans_eq (by ring))

/-- The manuscript's complete rough-pair estimate for its literal arithmetic
weight. The one constant depends only on the fixed progression and the
displayed classical inputs, and precedes every marking and small parameter. -/
theorem actual_rough_pair_bound (source : SourceLemma11_1)
    (hBlock : ClassicalPrimeBlockBound) (hUpper : ClassicalMertensUpper)
    (hLower : RoughCompanion.ClassicalMertensLower) (hDiv : ClassicalDivisorSquareMoment)
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : c = 2 ∨ c = 4)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀) :
    ∃ C : ℝ, 0 < C ∧ ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ)
      (amax Bv v₀ : ℝ), amax < 1 → 0 < v₀ →
      (∀ i ∈ I, (1 / 10 : ℝ) ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I,
        v₀ ≤ MarkedBandTail.bandMass (a i) x ∧ MarkedBandTail.bandMass (a i) x ≤ Bv) →
      ∀ ε : ℝ, 0 < ε → ε ≤ 1 / 100 → ∀ Y : ℝ, (M₀ : ℝ) ≤ Y →
      ∀ τ : ℝ, 0 < τ → τ ≤ 1 → ∀ᶠ x : ℝ in atTop,
      ∀ M₁ M₂ : ℝ, 0 ≤ M₁ → 0 ≤ M₂ → M₁ * M₂ ≤ 2 * x →
      M₁ + M₂ ≤ 2 * x ^ (54 / 100 : ℝ) → ∀ A B : Finset ℕ,
      (∀ m ∈ A, M₁ ≤ (m : ℝ) ∧ (m : ℝ) < 2 * M₁) →
      (∀ n ∈ B, M₂ ≤ (n : ℝ) ∧ (n : ℝ) < 2 * M₂) →
      SemiprimeReplacement.pairMass A B
        (arithmeticWeight (c * M₀) (c * v + 1) (smoothWeight x) I
          (fun i => MarkedBandTail.primeBand (a i) x) (fun i => MarkedBandTail.bandMass (a i) x)
          (markedPrimes I a x) c (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)))
        (RoughCompanion.realRoughIndicator (MarkedSource.W x))
        (RoughCompanion.realRoughIndicator (MarkedSource.W x)) ≤
      C * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x *
        (MarkedSource.eulerV (MarkedSource.W x)) ^ 2 := by
  obtain ⟨D, hD, hpairs⟩ := uniform_pairCount_bound source hBlock hUpper hLower hDiv hc
  have hc2 : 2 ≤ c := by rcases hc with rfl | rfl <;> norm_num
  have hcpos : 0 < c := by omega
  have hl := (constants_positive c M₀ hcpos (NeZero.pos M₀)).1
  refine ⟨D / lowerConstant c M₀, by positivity, ?_⟩
  intro ι I a amax Bv v₀ hmax hv₀ ha hinj hclassical ε hε hεmax Y hY τ hτ hτmax
  filter_upwards [hpairs I a (fun i hi => (ha i hi).1) τ hτ hτmax,
    actual_full_mass_comparison hPNT hc2 hu hv I a (1 / 10) amax Bv v₀
      (by norm_num) hmax hv₀ ha hinj hclassical ε hε hεmax Y hY τ,
    MarkedScaleSupport.eventual_marked_prime_bounds I a (1 / 10) amax 2 (9 / 10)
      (by norm_num) hmax (by norm_num) ha,
    hclassical, eventually_ge_atTop (2 : ℝ)] with x hpx hmass hmarks hVx hx
  intro M₁ M₂ h₁ h₂ harea hsum A B hA hB
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos (by linarith)
  have hV : ∀ i ∈ I, 0 < MarkedBandTail.bandMass (a i) x :=
    fun i hi => hv₀.trans_le (hVx i hi).1
  let marks := markedPrimes I a x
  let U := unmarkedCofactors I a ε Y τ x
  let R := boundedCofactors marks U (x ^ (11 / 100 : ℝ))
  let T := fun r => oddPrimes (sieveScale x) \ omittedPrimes (sieveScale x) r
  have hR : ∀ r ∈ R, 0 < r ∧ strip marks r ∈ U := by
    intro r hr
    have hh := (mem_boundedCofactors marks U _ r).mp hr
    exact ⟨hh.1, hh.2.1⟩
  have hz0 : 0 ≤ sieveScale x := Real.rpow_nonneg hx0.le _
  have hzQ : sieveScale x ≤ x ^ (9 / 10 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num)
  have hprimes : ∀ r ∈ R, ∀ p ∈ T r, p.Prime ∧ (p : ℝ) ≤ x ^ (9 / 10 : ℝ) ∧
      (c * r).Coprime p ∧ (roughCutoff (MarkedSource.W x) p = true → (p : ℝ) ≤ MarkedSource.W x) := by
    intro r hr p hp
    have hh := (mem_oddPrimes hz0).mp (Finset.mem_sdiff.mp hp).1
    exact ⟨hh.1, hh.2.2.trans hzQ, coprime_outside_omitted hc (hR r hr).1 hz0 hp,
      by simpa [roughCutoff]⟩
  have hdom := actualWeight_rough_pairMass_le A B (c * M₀) (c * v + 1) c (smoothWeight x)
    I (fun i => MarkedBandTail.primeBand (a i) x) (fun i => MarkedBandTail.bandMass (a i) x)
    marks U T (roughCutoff (MarkedSource.W x)) hx1 hc h₁ h₂ le_rfl
    (fun p hp => ⟨(hmarks p hp).1, by
      have hh := (hmarks p hp).2.1
      intro heq; simpa [heq] using hh, (hmarks p hp).2.2⟩)
    (fun i hi p hp => Finset.mem_biUnion.mpr ⟨i, hi, hp⟩) hV
    (MarkedScaleSupport.unmarked_positive_avoid I a ε Y τ x)
    (smoothWeight_bounds x) (smoothWeight_support hx) hprimes hA hB
  have hW : ∀ n, 0 ≤ marking I a x n := fun n => (markingWeight_bounds I _ _ n hV).1
  have hs : Summable (enlargedReciprocal marks U (marking I a x)) :=
    summable_enlargedReciprocal _ _ _ (unmarkedCofactors_avoid I a ε Y τ x) hW
      (MarkedInfiniteMass.summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have hweighted := weighted_pair_sum_le_full_mass R marks U (marking I a x)
    (fun r => pairCount (c * r) (roughCutoff (MarkedSource.W x)) (T r) M₁ M₂)
    (show 0 ≤ D * x / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2 by positivity)
    hR hW hs (by
      intro r hr
      have hh := hpx ε Y M₁ M₂ h₁ h₂ harea hsum r hr
      convert hh using 1 <;> ring)
  have htotal := hdom.trans hweighted
  have hconvert : (D * x / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2) *
      fullMass I a ε Y τ x =
      (D / lowerConstant c M₀) * (lowerConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x) *
        (MarkedSource.eulerV (MarkedSource.W x)) ^ 2 := by
    field_simp
    <;> ring
  change _ ≤ (D * x / Real.log x * (MarkedSource.eulerV (MarkedSource.W x)) ^ 2) *
    fullMass I a ε Y τ x at htotal
  rw [hconvert] at htotal
  exact htotal.trans (mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left hmass.1 (div_nonneg hD.le hl.le)) (sq_nonneg _))

end Artin.ActualRoughPair
