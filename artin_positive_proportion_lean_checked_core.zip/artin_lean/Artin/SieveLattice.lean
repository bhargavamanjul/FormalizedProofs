module

public import Artin.LatticeBoxes
public import Artin.SemiprimeSieve
public import Artin.SquarefreeRho
public import Mathlib.Data.ZMod.QuotientRing
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Fintype.Pi

/-!
# The concrete squarefree CRT intersection in the semiprime sieve

The bad set is defined by its actual local equations. Its cardinal is proved
by CRT, not supplied as a distribution assumption.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.SieveLattice

instance primeFactor_neZero (ℓ : ℕ) (p : ℓ.primeFactors) : NeZero (p : ℕ) :=
  ⟨(Nat.prime_of_mem_primeFactors p.2).ne_zero⟩

theorem primeFactors_pairwise_coprime (ℓ : ℕ) :
    Pairwise (Function.onFun Nat.Coprime (fun p : ℓ.primeFactors => (p : ℕ))) := by
  intro p q hpq
  exact (Nat.coprime_primes (Nat.prime_of_mem_primeFactors p.2)
    (Nat.prime_of_mem_primeFactors q.2)).mpr (Subtype.coe_ne_coe.mpr hpq)

/-- Squarefree CRT, with one coordinate for each actual prime divisor. -/
noncomputable def squarefreeCRT {ℓ : ℕ} (hℓ : Squarefree ℓ) :
    ZMod ℓ ≃+* ∀ p : ℓ.primeFactors, ZMod (p : ℕ) :=
  (ZMod.ringEquivCongr (show ℓ = ∏ p : ℓ.primeFactors, (p : ℕ) by
    exact (Nat.prod_primeFactors_of_squarefree hℓ).symm.trans
      (Finset.prod_coe_sort ℓ.primeFactors (fun p : ℕ => p)).symm)).trans
      (ZMod.prodEquivPi (fun p : ℓ.primeFactors => (p : ℕ)) (primeFactors_pairwise_coprime ℓ))

/-- Apply the squarefree CRT to the two integer coordinates. -/
noncomputable def squarefreePairCRT {ℓ : ℕ} (hℓ : Squarefree ℓ) :
    (ZMod ℓ × ZMod ℓ) ≃ ∀ p : ℓ.primeFactors, ZMod (p : ℕ) × ZMod (p : ℕ) where
  toFun a p := (squarefreeCRT hℓ a.1 p, squarefreeCRT hℓ a.2 p)
  invFun b := ((squarefreeCRT hℓ).symm (fun p => (b p).1),
    (squarefreeCRT hℓ).symm (fun p => (b p).2))
  left_inv a := by simp
  right_inv b := by funext p; simp

theorem squarefreePairCRT_intCast {ℓ : ℕ} (hℓ : Squarefree ℓ) (m n : ℤ)
    (p : ℓ.primeFactors) :
    squarefreePairCRT hℓ ((m : ZMod ℓ), (n : ZMod ℓ)) p =
      ((m : ZMod (p : ℕ)), (n : ZMod (p : ℕ))) := by
  change (squarefreeCRT hℓ (m : ZMod ℓ) p,
    squarefreeCRT hℓ (n : ZMod ℓ) p) = _
  simp

/-- `cutoff p` records whether the extra roughness exclusion is active. -/
def localBad (cutoff : ℕ → Bool) (p : ℕ) (a : ZMod p × ZMod p) : Prop :=
  if cutoff p then a.1 * a.2 = 1 ∨ a.1 * a.2 = 0 else a.1 * a.2 = 1

instance localBad_decidable (cutoff : ℕ → Bool) (p : ℕ)
    (a : ZMod p × ZMod p) : Decidable (localBad cutoff p a) := by
  unfold localBad
  infer_instance

theorem localBad_card (cutoff : ℕ → Bool) (p : ℕ) [Fact p.Prime] :
    Fintype.card {a : ZMod p × ZMod p // localBad cutoff p a} =
      if cutoff p then 3 * p - 2 else p - 1 := by
  classical
  cases h : cutoff p
  · simpa [localBad, h] using SemiprimeSieve.onePairs_card p
  · simpa [localBad, h] using SemiprimeSieve.forbidden_card p

/-- All local bad conditions imposed simultaneously. -/
noncomputable def badResidues {ℓ : ℕ} [NeZero ℓ] (hℓ : Squarefree ℓ)
    (cutoff : ℕ → Bool) : Finset (ZMod ℓ × ZMod ℓ) := by
  classical
  exact Finset.univ.filter (fun a => ∀ p : ℓ.primeFactors,
    localBad cutoff p (squarefreePairCRT hℓ a p))

theorem mem_badResidues {ℓ : ℕ} [NeZero ℓ] (hℓ : Squarefree ℓ)
    (cutoff : ℕ → Bool) (a : ZMod ℓ × ZMod ℓ) :
    a ∈ badResidues hℓ cutoff ↔ ∀ p : ℓ.primeFactors,
      localBad cutoff p (squarefreePairCRT hℓ a p) := by
  classical
  simp [badResidues]

/-- The multiplicative local density is the exact number of CRT classes. -/
theorem badResidues_card {ℓ : ℕ} [NeZero ℓ] (hℓ : Squarefree ℓ)
    (cutoff : ℕ → Bool) :
    (badResidues hℓ cutoff).card =
      ∏ p ∈ ℓ.primeFactors, (if cutoff p then 3 * p - 2 else p - 1) := by
  classical
  let e : {a : ZMod ℓ × ZMod ℓ // ∀ p : ℓ.primeFactors,
      localBad cutoff p (squarefreePairCRT hℓ a p)} ≃
      ∀ p : ℓ.primeFactors, {a : ZMod (p : ℕ) × ZMod (p : ℕ) // localBad cutoff p a} :=
    ((squarefreePairCRT hℓ).subtypeEquiv (fun _ => Iff.rfl)).trans Equiv.subtypePiEquivPi
  have hc : (badResidues hℓ cutoff).card =
      Fintype.card {a : ZMod ℓ × ZMod ℓ // ∀ p : ℓ.primeFactors,
        localBad cutoff p (squarefreePairCRT hℓ a p)} := by
    unfold badResidues
    exact (Fintype.card_subtype _).symm
  rw [hc, Fintype.card_congr e, Fintype.card_pi]
  calc
    _ = ∏ p : ℓ.primeFactors, (if cutoff p then 3 * (p : ℕ) - 2 else (p : ℕ) - 1) := by
      apply Finset.prod_congr rfl
      intro p hp
      let : Fact (p : ℕ).Prime := ⟨Nat.prime_of_mem_primeFactors p.2⟩
      exact localBad_card cutoff p
    _ = _ := Finset.prod_coe_sort ℓ.primeFactors
      (fun p : ℕ => if cutoff p then 3 * p - 2 else p - 1)

theorem badResidues_card_eq_rho {ℓ : ℕ} [NeZero ℓ] (hℓ : Squarefree ℓ)
    (cutoff : ℕ → Bool) :
    (badResidues hℓ cutoff).card = SquarefreeRho.rho cutoff ℓ := by
  simpa only [SquarefreeRho.rho, SquarefreeRho.localCount] using badResidues_card hℓ cutoff

/-- The actual intersection of all bad conditions in the given box. -/
noncomputable def sieveBox {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    (L₁ U₁ L₂ U₂ : ℝ) : Finset (ℤ × ℤ) :=
  LatticeBoxes.boxPoints (k * ℓ)
    (LatticeBoxes.crtResidues h (LatticeBoxes.productOneResidues k)
      (badResidues hℓ cutoff)) L₁ U₁ L₂ U₂

/-- Membership records the original progression and each prime-local equation. -/
theorem mem_sieveBox {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {L₁ U₁ L₂ U₂ : ℝ} {n : ℤ × ℤ} :
    n ∈ sieveBox h hℓ cutoff L₁ U₁ L₂ U₂ ↔
      L₁ ≤ (n.1 : ℝ) ∧ (n.1 : ℝ) < U₁ ∧
      L₂ ≤ (n.2 : ℝ) ∧ (n.2 : ℝ) < U₂ ∧
      (n.1 : ZMod k) * (n.2 : ZMod k) = 1 ∧
      ∀ p : ℓ.primeFactors,
        localBad cutoff p ((n.1 : ZMod (p : ℕ)), (n.2 : ZMod (p : ℕ))) := by
  simp only [sieveBox, LatticeBoxes.mem_crt_box, mem_badResidues,
    squarefreePairCRT_intCast]

/-- The complete Section 8 lattice estimate. All local cardinalities and the
boundary error have been proved from the defining congruences. -/
theorem sieveBox_error {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : L₁ ≤ U₁) (h₂ : L₂ ≤ U₂) :
    |((sieveBox h hℓ cutoff L₁ U₁ L₂ U₂).card : ℝ) -
      ((U₁ - L₁) * (U₂ - L₂) * k.totient / (k : ℝ) ^ 2) *
        ((SquarefreeRho.rho cutoff ℓ : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      (ℓ.divisors.card : ℝ) ^ 2 *
        ((U₁ - L₁) + (U₂ - L₂) + (k : ℝ) * ℓ) := by
  have ht : ((badResidues hℓ cutoff).card : ℝ) ≤ (ℓ.divisors.card : ℝ) ^ 2 * ℓ := by
    rw [badResidues_card_eq_rho]
    exact SquarefreeRho.rho_le_divisors_sq_mul_real cutoff hℓ
  simpa only [sieveBox, badResidues_card_eq_rho] using
    LatticeBoxes.crt_box_error_of_card_le h (badResidues hℓ cutoff) h₁ h₂ (by positivity) ht

/-- For dyadic boxes the main mass is exactly `M₁ M₂ φ(k)/k² · g(ℓ)`. -/
theorem dyadic_sieveBox_error {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {M₁ M₂ : ℝ} (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) :
    |((sieveBox h hℓ cutoff M₁ (2 * M₁) M₂ (2 * M₂)).card : ℝ) -
      (M₁ * M₂ * k.totient / (k : ℝ) ^ 2) *
        ((SquarefreeRho.rho cutoff ℓ : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      (ℓ.divisors.card : ℝ) ^ 2 * (M₁ + M₂ + (k : ℝ) * ℓ) := by
  have he := sieveBox_error h hℓ cutoff (show M₁ ≤ 2 * M₁ by linarith)
    (show M₂ ≤ 2 * M₂ by linarith)
  simpa only [show 2 * M₁ - M₁ = M₁ by ring, show 2 * M₂ - M₂ = M₂ by ring] using he

/-- With `k = cr`, the fixed progression contributes only the fixed constant `c`.
In particular the bound is uniform in `r`, `ℓ`, and the marking data. -/
theorem cofactor_dyadic_sieveBox_error {c r ℓ : ℕ} [NeZero c] [NeZero r] [NeZero ℓ]
    (h : (c * r).Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {M₁ M₂ : ℝ} (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) :
    |((sieveBox h hℓ cutoff M₁ (2 * M₁) M₂ (2 * M₂)).card : ℝ) -
      (M₁ * M₂ * (c * r).totient / ((c * r : ℕ) : ℝ) ^ 2) *
        ((SquarefreeRho.rho cutoff ℓ : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      (c : ℝ) * (ℓ.divisors.card : ℝ) ^ 2 * (M₁ + M₂ + (r : ℝ) * ℓ) := by
  have hc : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  have hsum : M₁ + M₂ ≤ (c : ℝ) * (M₁ + M₂) := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hc) (add_nonneg h₁ h₂)]
  calc
    _ ≤ (ℓ.divisors.card : ℝ) ^ 2 * (M₁ + M₂ + ((c * r : ℕ) : ℝ) * ℓ) :=
      dyadic_sieveBox_error h hℓ cutoff h₁ h₂
    _ ≤ (ℓ.divisors.card : ℝ) ^ 2 *
        ((c : ℝ) * (M₁ + M₂) + ((c * r : ℕ) : ℝ) * ℓ) :=
      mul_le_mul_of_nonneg_left (add_le_add hsum le_rfl) (sq_nonneg _)
    _ = _ := by push_cast; ring

/-- Nonnegative boxes may equivalently be counted as pairs of natural numbers. -/
noncomputable def natSieveBox {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    (L₁ U₁ L₂ U₂ : ℝ) : Finset (ℕ × ℕ) :=
  (sieveBox h hℓ cutoff L₁ U₁ L₂ U₂).image (fun n => (n.1.toNat, n.2.toNat))

theorem sieveBox_nonneg {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : 0 ≤ L₁) (h₂ : 0 ≤ L₂)
    {n : ℤ × ℤ} (hn : n ∈ sieveBox h hℓ cutoff L₁ U₁ L₂ U₂) :
    0 ≤ n.1 ∧ 0 ≤ n.2 := by
  have hm := (mem_sieveBox h hℓ cutoff).mp hn
  constructor
  · exact_mod_cast h₁.trans hm.1
  · exact_mod_cast h₂.trans hm.2.2.1

theorem natSieveBox_card {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : 0 ≤ L₁) (h₂ : 0 ≤ L₂) :
    (natSieveBox h hℓ cutoff L₁ U₁ L₂ U₂).card =
      (sieveBox h hℓ cutoff L₁ U₁ L₂ U₂).card := by
  apply Finset.card_image_of_injOn
  intro m hm n hn heq
  obtain ⟨hm₁, hm₂⟩ := sieveBox_nonneg h hℓ cutoff h₁ h₂ hm
  obtain ⟨hn₁, hn₂⟩ := sieveBox_nonneg h hℓ cutoff h₁ h₂ hn
  have he₁ := congrArg Prod.fst heq
  have he₂ := congrArg Prod.snd heq
  apply Prod.ext <;> dsimp at he₁ he₂ <;> omega

theorem mem_natSieveBox {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : 0 ≤ L₁) (h₂ : 0 ≤ L₂) {n : ℕ × ℕ} :
    n ∈ natSieveBox h hℓ cutoff L₁ U₁ L₂ U₂ ↔
      ((n.1 : ℤ), (n.2 : ℤ)) ∈ sieveBox h hℓ cutoff L₁ U₁ L₂ U₂ := by
  classical
  rw [natSieveBox, Finset.mem_image]
  constructor
  · rintro ⟨m, hm, rfl⟩
    obtain ⟨hm₁, hm₂⟩ := sieveBox_nonneg h hℓ cutoff h₁ h₂ hm
    simpa only [Int.toNat_of_nonneg hm₁, Int.toNat_of_nonneg hm₂] using hm
  · intro hn
    exact ⟨_, hn, by simp⟩

/-- The same completely proved discrepancy for the natural-number pairs used
in the semiprime factorization. -/
theorem nat_dyadic_sieveBox_error {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (hℓ : Squarefree ℓ) (cutoff : ℕ → Bool)
    {M₁ M₂ : ℝ} (h₁ : 0 ≤ M₁) (h₂ : 0 ≤ M₂) :
    |((natSieveBox h hℓ cutoff M₁ (2 * M₁) M₂ (2 * M₂)).card : ℝ) -
      (M₁ * M₂ * k.totient / (k : ℝ) ^ 2) *
        ((SquarefreeRho.rho cutoff ℓ : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      (ℓ.divisors.card : ℝ) ^ 2 * (M₁ + M₂ + (k : ℝ) * ℓ) := by
  rw [natSieveBox_card h hℓ cutoff h₁ h₂]
  exact dyadic_sieveBox_error h hℓ cutoff h₁ h₂

end Artin.SieveLattice
