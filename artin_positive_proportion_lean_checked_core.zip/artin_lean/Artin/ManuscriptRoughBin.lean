module

public import Artin.ConditionedAssembly
public import Artin.BuchstabRoughReduction
public import Artin.BuchstabNormalization
public import Artin.ManuscriptSemiprime

/-!
# The normalized bin bound for the literal manuscript weight

The marked replacement theorem, the conditioned block sieve, and the
positive lower scale of the actual base mass are combined here.  The
vanishing error is derived, not supplied as an analytic assumption.
-/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace Artin.ManuscriptRoughBin

open MarkedSource MarkedBandTail MarkedCofactorEstimate ManuscriptDistribution
  ManuscriptMass ManuscriptCover InitialSieve ClassicalSieveNormalization
  BuchstabPartition BuchstabRoughReduction BuchstabBoxes BuchstabBinEstimate

theorem actual_bin_normalized
    (source : BuchstabSieve.SourceLemma11_1) (C₀ : ℝ) (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    (hbands : ClassicalBandMass) (hbandUpper : ManuscriptSemiprime.ClassicalBandUpperMass)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ γ γ' τ S_M Cbin : ℝ} (hε : 0 < ε) (hεκ : ε < κ)
    (hκ : κ < 1 / 100) (hεγ : ε < γ) (hγγ' : γ < γ')
    (hγ' : γ' ≤ 1 / 2 - κ) (hτ : 0 < τ)
    (hLocal : MertensLocalSource (c * M₀) S_M)
    (hEuler : ClassicalEulerMertens) (hPrime : ClassicalShiftedPrimeMertens)
    {K : ℕ} (bands : Bands K) (hCbin : 0 ≤ Cbin)
    (hbin : BinEstimate bands (c * M₀) (c * v + 1) PositiveBump.weight γ γ' Cbin)
    (Y : ℝ) (hY : (M₀ : ℝ) ≤ Y) :
    ∃ e : ℝ → ℝ, (∀ x, 0 ≤ e x) ∧ Tendsto e atTop (𝓝 0) ∧
      ∀ᶠ x : ℝ in atTop,
        factorBinMass ⌊2 * x⌋₊
          (integerWeight Finset.univ bands.exponent c (c * M₀) (c * v + 1) ε Y τ x)
          (x ^ γ) (x ^ γ') ≤
          (Real.exp (20 * τ) * Cbin * Real.log (γ' / γ) + e x) *
            (S_M * baseMass Finset.univ bands.exponent
              c (c * M₀) (c * v + 1) ε Y τ x / Real.log x) := by
  classical
  have hv₀ : 0 < Real.log 2 / 2 := by positivity
  have hclassical := ManuscriptSemiprime.classical_band_bounds hbands hbandUpper bands
  have ha := ManuscriptSemiprime.band_exponent_bounds bands
  have hinj := ManuscriptSemiprime.band_exponent_injective bands
  obtain ⟨A₀, hA₀, hX⟩ := ManuscriptMassLower.actual_baseMass_has_positive_lower_scale
    hPNT hc hu hv Finset.univ bands.exponent (1/10) (1/5) (2 * Real.log 2)
    (Real.log 2 / 2) (by norm_num) (by norm_num) hv₀ ha hinj hclassical
    hε (by linarith) hY hτ.le
  let w := fun x => integerWeight Finset.univ bands.exponent
    c (c * M₀) (c * v + 1) ε Y τ x
  let T := fun x => factorBinMass ⌊2 * x⌋₊ (w x) (x ^ γ) (x ^ γ')
  let H := fun x => BuchstabMR.conditionedMass (ambient x) (primeBin x γ γ') (w x) (W x)
  let X := fun x => baseMass Finset.univ bands.exponent c (c * M₀) (c * v + 1) ε Y τ x
  have hcond : ∀ δ : ℝ, 0 < δ → ∀ᶠ x : ℝ in atTop,
      H x ≤ (1 + δ) * Real.exp (20 * τ) * S_M * X x * eulerV (W x) *
        Real.log (γ' / γ) := by
    intro δ hδ
    exact ConditionedAssembly.actual_conditionedMass_bin_upper source C₀ hBlock hBV hPNT hTot
      hc hu hv huM hε hεκ hκ hεγ hγγ' hγ' hδ hτ hLocal hEuler hPrime
      Finset.univ bands.exponent (1/10) (1/5) (2 * Real.log 2) (Real.log 2 / 2)
      (by norm_num) (by norm_num) hv₀ ha hinj hclassical Y hY
  have hreplace : ∀ δ : ℝ, 0 < δ → ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      T x ≤ (Cbin + δ) / (Real.log x * eulerV (W x)) * H x +
        C * x * (Real.log x) ^ (-5 : ℝ) := by
    intro δ hδ
    obtain ⟨C, hC, he⟩ := hbin δ hδ
    refine ⟨C, hC, ?_⟩
    filter_upwards [he] with x hx
    have hh := hx c (unmarkedCofactors Finset.univ bands.exponent ε Y τ x)
      (x ^ (9 / 10 : ℝ)) ⌊2 * x⌋₊
    change factorBinMass _ (ManuscriptSemiprime.weight bands c _ _ ε Y τ x) _ _ ≤
      _ * BuchstabMR.conditionedMass _ _
        (ManuscriptSemiprime.weight bands c _ _ ε Y τ x) _ + _ at hh
    rw [ManuscriptSemiprime.weight_eq] at hh
    exact hh
  have hγ : 0 < γ := hε.trans hεγ
  have hlog : 0 ≤ Real.log (γ' / γ) :=
    Real.log_nonneg ((le_div_iff₀ hγ).mpr (by simpa using hγγ'.le))
  exact BuchstabNormalization.exists_vanishing_bin_error T H X (fun x => eulerV (W x))
    hLocal.1 (Real.exp_pos _) hA₀ hCbin hlog
    (Eventually.of_forall (fun x => RoughCompanion.eulerV_pos (W x))) hX hcond hreplace

end Artin.ManuscriptRoughBin
