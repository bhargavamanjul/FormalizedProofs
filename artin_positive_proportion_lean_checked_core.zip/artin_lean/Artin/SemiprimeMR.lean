module

public import Artin.RoughCompanion

/-!
# Both marked replacements for the actual semiprime weight

The two error estimates are deductions from the accepted source criterion,
source cancellation theorem, classical band mass and Fourier inversion.  The
second application transposes the dyad family and uses the already replaced
coefficient as its companion.  The number of active dyads may grow with `x`.
-/

@[expose] public section

open Filter
open scoped BigOperators

namespace Artin.SemiprimeMR

open MarkedSource SemiprimeReplacement RoughCompanion

/-- The exact arithmetic weight; only an abbreviation for the construction
already used by the candidate-counting argument. -/
noncomputable def actualWeight {K : ℕ} (b : Bands K) (M u : ℕ) (Ψ : ℝ → ℝ)
    (x : ℝ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) : ℕ → ℝ :=
  ConcreteSelector.arithmeticWeight M u (fun d => Ψ ((d : ℝ) / x))
    Finset.univ (b.group x) (b.mass x) (b.primes x) c allowed Qmin

/-- Both whole dyads lie in the factor support on which the prime and
simplex-density identifications are valid. -/
def FactorWindow {J : Type} (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop) : Prop :=
  ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
    x ^ (46 / 100 : ℝ) ≤ Hm x j ∧ 2 * Hm x j ≤ x ^ (54 / 100 : ℝ) ∧
    x ^ (46 / 100 : ℝ) ≤ Hn x j ∧ 2 * Hn x j ≤ x ^ (54 / 100 : ℝ)

theorem ScaleFamily_swap {J : Type} {δ c₁ c₂ : ℝ} {Hm Hn : ℝ → J → ℝ}
    {active : ℝ → J → Prop} (h : ScaleFamily δ c₁ c₂ Hm Hn active) :
    ScaleFamily δ c₁ c₂ Hn Hm active := by
  filter_upwards [h] with x hx j hj
  obtain ⟨hm, hn, hmδ, hnδ, hlo, hhi⟩ := hx j hj
  exact ⟨hn, hm, hnδ, hmδ, by simpa only [mul_comm] using hlo,
    by simpa only [mul_comm] using hhi⟩

theorem FactorWindow_swap {J : Type} {Hm Hn : ℝ → J → ℝ}
    {active : ℝ → J → Prop} (h : FactorWindow Hm Hn active) :
    FactorWindow Hn Hm active := by
  filter_upwards [h] with x hx j hj
  obtain ⟨hm, hm', hn, hn'⟩ := hx j hj
  exact ⟨hn, hn', hm, hm'⟩

/-- The concrete support inequalities imply the exact source exponent
window, with one threshold for all active dyads. -/
theorem FactorWindow_log {J : Type} {Hm Hn : ℝ → J → ℝ}
    {active : ℝ → J → Prop} (h : FactorWindow Hm Hn active) :
    ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      (46 / 100 : ℝ) ≤ Real.log (Hm x j) / Real.log x ∧
      Real.log (2 * Hm x j) / Real.log x ≤ (54 / 100 : ℝ) := by
  filter_upwards [h, eventually_gt_atTop (1 : ℝ)] with x hx hxx j hj
  obtain ⟨hlo, hhi, _, _⟩ := hx j hj
  have hx0 : 0 < x := by linarith
  have hL := Real.log_pos hxx
  have hH := (Real.rpow_pos_of_pos hx0 (46 / 100 : ℝ)).trans_le hlo
  constructor
  · apply (le_div_iff₀ hL).mpr
    have hh := Real.log_le_log (Real.rpow_pos_of_pos hx0 (46 / 100 : ℝ)) hlo
    simpa only [Real.log_rpow hx0] using hh
  · apply (div_le_iff₀ hL).mpr
    have hh := Real.log_le_log (by positivity : 0 < 2 * Hm x j) hhi
    simpa only [Real.log_rpow hx0] using hh

/-- Exact conversion from the complex source sum to the actual real
replacement error. -/
theorem discrepancy_sum_eq_pairMass {x : ℝ} (hx : 1 < x)
    (s t : Finset ℕ) (w β : ℕ → ℝ)
    (hs : ∀ m ∈ s, x ^ (46 / 100 : ℝ) ≤ (m : ℝ) ∧
      (m : ℝ) ≤ x ^ (54 / 100 : ℝ)) :
    (∑ m ∈ s, ∑ n ∈ t, discrepancy (2 / 5) x m * (β n : ℂ) * (w (m * n) : ℂ)) =
      (pairMass s t w (fun m => primeIndicator m - primeModel x m) β : ℂ) := by
  unfold pairMass
  push_cast
  apply Finset.sum_congr rfl
  intro m hm
  apply Finset.sum_congr rfl
  intro n hn
  rw [discrepancy_eq_prime_sub_model hx (hs m hm).1 (hs m hm).2]
  push_cast
  ring

theorem pairMass_swap (s t : Finset ℕ) (w α β : ℕ → ℝ) :
    pairMass t s w α β = pairMass s t w β α := by
  unfold pairMass
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  apply Finset.sum_congr rfl
  intro n hn
  rw [Nat.mul_comm n m]
  ring

/-- Two applications of the previously proved actual-weight MR theorem.
These are simultaneous error bounds for all active dyads, all interval
subboxes, and all actual cofactor selectors. -/
theorem two_errors_of_MRFamilies {J : Type} {K M : ℕ} (b : Bands K)
    (u : ℕ) (hu : u < M) (Ψ : ℝ → ℝ)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop)
    (hMertens : ClassicalMertensLower) (hwindow : FactorWindow Hm Hn active)
    (hMR₁ : UniformMRFamily b M (u : ZMod M) (fun y => (Ψ y : ℂ))
      (2 / 5) 6 Hm Hn active)
    (hMR₂ : UniformMRFamily b M (u : ZMod M) (fun y => (Ψ y : ℂ))
      (2 / 5) 6 Hn Hm active) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → IntervalInDyad (Hn x j) t →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
          (fun m => primeIndicator m - primeModel x m) primeIndicator| ≤
          C * x * (Real.log x) ^ (-6 : ℝ) ∧
        |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
          (primeModel x) (fun n => primeIndicator n - primeModel x n)| ≤
          C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨C₁, hC₁, he₁⟩ := actualArithmeticWeight_MRFamily b u hu Ψ (2 / 5) 6
    Hm Hn active hMR₁
  obtain ⟨C₂, hC₂, he₂⟩ := actualArithmeticWeight_MRFamily b u hu Ψ (2 / 5) 6
    Hn Hm active hMR₂
  refine ⟨C₁ + C₂, add_pos hC₁ hC₂, ?_⟩
  filter_upwards [he₁, he₂, hwindow,
    eventually_prime_boundedRough (by norm_num : (0 : ℝ) < 46 / 100),
    eventually_primeModel_boundedRough hMertens (by norm_num : (0 : ℝ) < 46 / 100),
    eventually_gt_atTop (1 : ℝ)] with x hex₁ hex₂ hw hprime hmodel hx
  intro j hj s t hs ht c allowed Qmin
  have hws : ∀ m ∈ s, x ^ (46 / 100 : ℝ) ≤ (m : ℝ) ∧
      (m : ℝ) ≤ x ^ (54 / 100 : ℝ) := by
    intro m hm
    exact ⟨(hw j hj).1.trans (hs.inDyad m hm).1,
      (hs.inDyad m hm).2.trans (hw j hj).2.1⟩
  have hwt : ∀ n ∈ t, x ^ (46 / 100 : ℝ) ≤ (n : ℝ) ∧
      (n : ℝ) ≤ x ^ (54 / 100 : ℝ) := by
    intro n hn
    exact ⟨(hw j hj).2.2.1.trans (ht.inDyad n hn).1,
      (ht.inDyad n hn).2.trans (hw j hj).2.2.2⟩
  have h₁ := hex₁ j hj s t hs ht.inDyad (fun n => (primeIndicator n : ℂ))
    (hprime t (fun n hn => (hwt n hn).1)) c allowed Qmin
  have h₂ := hex₂ j hj t s ht hs.inDyad (fun m => (primeModel x m : ℂ))
    (hmodel s (fun m hm => (hws m hm).1)) c allowed Qmin
  change ‖∑ m ∈ s, ∑ n ∈ t, discrepancy (2 / 5) x m * (primeIndicator n : ℂ) *
    (actualWeight b M u Ψ x c allowed Qmin (m * n) : ℂ)‖ ≤ _ at h₁
  change ‖∑ n ∈ t, ∑ m ∈ s, discrepancy (2 / 5) x n * (primeModel x m : ℂ) *
    (actualWeight b M u Ψ x c allowed Qmin (n * m) : ℂ)‖ ≤ _ at h₂
  rw [discrepancy_sum_eq_pairMass hx s t _ _ hws,
    Complex.norm_real, Real.norm_eq_abs] at h₁
  rw [discrepancy_sum_eq_pairMass hx t s _ _ hwt, pairMass_swap,
    Complex.norm_real, Real.norm_eq_abs] at h₂
  have hx0 : 0 ≤ x := by linarith
  have hL0 : 0 ≤ (Real.log x) ^ (-6 : ℝ) := Real.rpow_nonneg (Real.log_pos hx).le _
  constructor
  · exact h₁.trans (by gcongr; linarith)
  · exact h₂.trans (by gcongr; linarith)

/-- The source-to-two-errors theorem.  `K₀` is fixed before the marked
groups and before the entire growing dyad family.  The conclusion contains
the literal replacement errors, not an assumed bound for those errors. -/
theorem two_errors_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hMertens : ClassicalMertensLower)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨ : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (δ c₁ c₂ : ℝ) (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active → FactorWindow Hm Hn active →
      ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → IntervalInDyad (Hn x j) t →
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
          |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
            (fun m => primeIndicator m - primeModel x m) primeIndicator| ≤
            C * x * (Real.log x) ^ (-6 : ℝ) ∧
          |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
            (primeModel x) (fun n => primeIndicator n - primeModel x n)| ≤
            C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := uniformMRFamilies_of_sources h102 h103 hbands hFourier
    M (u : ZMod M) hunit (fun y => (Ψ y : ℂ)) hΨ
    (2 / 5) (46 / 100) (54 / 100) δ c₁ c₂
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) hδ hc₁ hc₂
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b J Hm Hn active hscale hwindow
  exact two_errors_of_MRFamilies b u hu Ψ Hm Hn active hMertens hwindow
    (hK K hKK b J Hm Hn active hscale (FactorWindow_log hwindow))
    (hK K hKK b J Hn Hm active (ScaleFamily_swap hscale)
      (FactorWindow_log (FactorWindow_swap hwindow)))

end Artin.SemiprimeMR
