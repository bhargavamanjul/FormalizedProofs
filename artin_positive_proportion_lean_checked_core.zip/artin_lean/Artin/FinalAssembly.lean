module

public import Artin.Parameters

/-!
# Conditional assembly of the quantitative lower bound

This module proves the parameter-selection and limiting deduction from the
manuscript's final analytic estimate. That estimate is an explicit theorem
argument, not an axiom, not a cited result, and not a claim that the preceding
analytic parts of the manuscript have been formalized.

The function `f N x` is arbitrary. The predicate `Q N` may later be instantiated
with the exact formal definition of `QRH(N)`. We do not assume `Q N` for every
width. To apply the theorem to primitive-root counts, the displayed analytic
estimate must first be proved for those actual counts from the accepted
external results.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- The exact analytic estimate required by the final assembly. The quantifiers
allow the vanishing error and the eventual threshold to depend on `N`, `ε`,
and `Y`. The constants `A`, `C`, `Y₀`, and `ε₀` are fixed before `N`.

This is only a definition of a proposition; no instance of it is assumed
globally or supplied by an axiom. -/
def FinalAnalyticEstimateOn (Q : ℝ → Prop) (f : ℝ → ℝ → ℝ)
    (A C Y₀ ε₀ : ℝ) : Prop :=
  ∀ N : ℝ, 2 ≤ N → Q N → ∀ ε Y : ℝ,
    0 < ε → ε < ε₀ → ε < 1 / N → 2 * ε < 1 → Y₀ ≤ Y → 1 < Y →
      ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧
        ∀ᶠ x : ℝ in atTop,
          ((A * ε - C / Y) / Real.log Y + e x) * (x / Real.log x) ≤ f N x

/-- A uniform quantitative lower bound, conditional on the explicitly
displayed final analytic estimate. In particular, the positive constant `c`
is independent of `N`; only the eventual threshold may depend on `N`. -/
theorem quantitative_bound_of_final_analytic_estimate_on
    (Q : ℝ → Prop) (f : ℝ → ℝ → ℝ) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : FinalAnalyticEstimateOn Q f A C Y₀ ε₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → Q N →
      ∀ᶠ x : ℝ in atTop, (c / (N * Real.log N)) * x / Real.log x ≤ f N x := by
  obtain ⟨θ, D, c, _hθ, _hD, hc, hparams⟩ :=
    exists_uniform_parameters A C Y₀ ε₀ hA hC hY₀ hε₀
  refine ⟨c, hc, ?_⟩
  intro N hN hQ
  obtain ⟨hε, hεsmall, hεδ, h2ε, hY, hY1, hbalance⟩ := hparams N hN
  obtain ⟨e, he, hcount⟩ :=
    hEst N hN hQ (θ / N) (D * N) hε hεsmall hεδ h2ε hY hY1
  have hNp : 0 < N := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 2) hN
  have hlogNp : 0 < Real.log N := Real.log_pos (by linarith)
  have hk : 0 < c / (N * Real.log N) := by positivity
  have hbalance' : 2 * (c / (N * Real.log N)) ≤
      (A * (θ / N) - C / (D * N)) / Real.log (D * N) := by
    convert hbalance using 1; ring_nf
  have hscale : ∀ᶠ x : ℝ in atTop, 0 ≤ x / Real.log x := by
    filter_upwards [eventually_ge_atTop (2 : ℝ)] with x hx
    have hxpos : 0 < x := by linarith
    have hxlog : 0 < Real.log x := Real.log_pos (by linarith)
    exact (div_pos hxpos hxlog).le
  have hfinal := eventually_lower_bound_from_vanishing_error hk hbalance' he hscale hcount
  filter_upwards [hfinal] with x hx
  simpa only [div_eq_mul_inv, mul_assoc] using hx

/-- Specializing the conditional assembly to `N = 6000` gives a positive
eventual lower coefficient. This theorem still requires `hEst`; it is not a
formalization of the primitive-root theorem by itself. -/
theorem positive_bound_at_6000_of_final_analytic_estimate_on
    (Q : ℝ → Prop) (f : ℝ → ℝ → ℝ) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : FinalAnalyticEstimateOn Q f A C Y₀ ε₀) (h6000 : Q 6000) :
    ∃ η : ℝ, 0 < η ∧ ∀ᶠ x : ℝ in atTop, η * x / Real.log x ≤ f 6000 x := by
  obtain ⟨c, hc, hbound⟩ :=
    quantitative_bound_of_final_analytic_estimate_on Q f A C Y₀ ε₀ hA hC hY₀ hε₀ hEst
  refine ⟨c / ((6000 : ℝ) * Real.log 6000), ?_, hbound 6000 (by norm_num) h6000⟩
  have hlog : 0 < Real.log (6000 : ℝ) := Real.log_pos (by norm_num)
  positivity

/-- Unguarded estimates are the special case in which the guard is `True`.
This definition makes no global assertion that such estimates hold. -/
abbrev FinalAnalyticEstimate (f : ℝ → ℝ → ℝ) (A C Y₀ ε₀ : ℝ) : Prop :=
  FinalAnalyticEstimateOn (fun _ => True) f A C Y₀ ε₀

/-- An optional unguarded corollary. For the manuscript's quantitative result,
the guarded theorem above is the appropriate interface. -/
theorem quantitative_bound_of_final_analytic_estimate
    (f : ℝ → ℝ → ℝ) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : FinalAnalyticEstimate f A C Y₀ ε₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N →
      ∀ᶠ x : ℝ in atTop, (c / (N * Real.log N)) * x / Real.log x ≤ f N x := by
  obtain ⟨c, hc, hb⟩ := quantitative_bound_of_final_analytic_estimate_on
    (fun _ => True) f A C Y₀ ε₀ hA hC hY₀ hε₀ hEst
  exact ⟨c, hc, fun N hN => hb N hN True.intro⟩

end Artin
