module

public import Artin.Cofactor
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-!
# Elementary bounds and finite Euler identities for marked weights

The count factor is `n / 2^(n-1)` for natural `n`; this equals zero at `n = 0`
and equals `n * 2^(1-n)` for positive `n`.  The finite combinatorial identities
below do not assert convergence of an infinite series or an infinite Euler
product.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.MarkedWeights

/-- The multiplicity factor in a single marked prime group. -/
noncomputable def countFactor (n : ℕ) : ℝ := (n : ℝ) / (2 : ℝ) ^ (n - 1)

@[simp] theorem countFactor_zero : countFactor 0 = 0 := by
  simp [countFactor]

@[simp] theorem countFactor_one : countFactor 1 = 1 := by
  norm_num [countFactor]

theorem count_le_two_pow (n : ℕ) : n + 1 ≤ 2 ^ n := by
  induction n with
  | zero => norm_num
  | succ n ih =>
      rw [pow_succ]
      omega

theorem countFactor_nonneg (n : ℕ) : 0 ≤ countFactor n := by
  unfold countFactor
  positivity

/-- The boundedness used to dominate the marked weight by a constant. -/
theorem countFactor_le_one (n : ℕ) : countFactor n ≤ 1 := by
  cases n with
  | zero => simp
  | succ n =>
      have h : ((n + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ n := by
        exact_mod_cast count_le_two_pow n
      have hp : 0 < (2 : ℝ) ^ n := by positivity
      simp only [countFactor, Nat.add_sub_cancel]
      exact (div_le_one hp).mpr h

/-- Each group is normalized by its reciprocal-prime mass `V`. -/
noncomputable def groupWeight (n : ℕ) (V : ℝ) : ℝ := countFactor n / V

theorem groupWeight_nonneg (n : ℕ) {V : ℝ} (hV : 0 < V) :
    0 ≤ groupWeight n V := div_nonneg (countFactor_nonneg n) hV.le

theorem groupWeight_le (n : ℕ) {V : ℝ} (hV : 0 < V) :
    groupWeight n V ≤ 1 / V := by
  simpa only [groupWeight, div_eq_mul_inv, one_mul] using
    mul_le_mul_of_nonneg_right (countFactor_le_one n) (inv_nonneg.mpr hV.le)

/-- Product bound, uniform in the prime multiplicities. -/
theorem marked_product_bounds {ι : Type*} (s : Finset ι) (n : ι → ℕ) (V : ι → ℝ)
    (hV : ∀ i ∈ s, 0 < V i) :
    0 ≤ (∏ i ∈ s, groupWeight (n i) (V i)) ∧
      (∏ i ∈ s, groupWeight (n i) (V i)) ≤ ∏ i ∈ s, (1 / V i) := by
  constructor
  · exact Finset.prod_nonneg fun i hi => groupWeight_nonneg (n i) (hV i hi)
  · exact Finset.prod_le_prod₀
      (fun i hi => groupWeight_nonneg (n i) (hV i hi))
      (fun i hi => groupWeight_le (n i) (hV i hi))

/-- Multiplying the formal derivative monomial by its parameter restores the
original monomial, including the empty-subset case. -/
theorem mul_card_monomial (t : ℝ) (n : ℕ) :
    t * ((n : ℝ) * t ^ (n - 1)) = t ^ n * (n : ℝ) := by
  cases n with
  | zero => simp
  | succ n =>
      simp only [Nat.succ_sub_one, pow_succ, Nat.cast_add, Nat.cast_one]
      ring

/-- The finite Euler-product differentiation identity, proved through weighted
subset moments.  Positivity restrictions are sufficient for the application
at `t = 1/2` and reciprocal prime weights. -/
theorem finite_marked_euler {ι : Type*} [DecidableEq ι] (s : Finset ι) (u : ι → ℝ)
    (t : ℝ) (ht : 0 < t) (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ v ∈ s.powerset, (v.card : ℝ) * t ^ (v.card - 1) * (∏ i ∈ v, u i)) =
      ∑ i ∈ s, u i * ∏ j ∈ s.erase i, (1 + t * u j) := by
  classical
  have htu : ∀ i ∈ s, 0 ≤ t * u i := fun i hi => mul_nonneg ht.le (hu i hi)
  have hm := Cofactor.subset_moment s (fun i => t * u i) (fun _ => (1 : ℝ)) htu
  have hleft :
      t * (∑ v ∈ s.powerset,
        (v.card : ℝ) * t ^ (v.card - 1) * (∏ i ∈ v, u i)) =
      ∑ v ∈ s.powerset, (∏ i ∈ v, t * u i) * (∑ _i ∈ v, (1 : ℝ)) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro v hv
    rw [Finset.prod_mul_distrib, Finset.prod_const]
    simp only [Finset.sum_const, nsmul_eq_mul, mul_one]
    calc
      t * ((v.card : ℝ) * t ^ (v.card - 1) * (∏ i ∈ v, u i)) =
          (t * ((v.card : ℝ) * t ^ (v.card - 1))) * (∏ i ∈ v, u i) := by ring
      _ = (t ^ v.card * (v.card : ℝ)) * (∏ i ∈ v, u i) := by
        rw [mul_card_monomial]
      _ = (t ^ v.card * (∏ i ∈ v, u i)) * (v.card : ℝ) := by ring
  have hright :
      (∏ i ∈ s, (1 + t * u i)) *
        (∑ i ∈ s, (t * u i) / (1 + t * u i) * 1) =
      t * (∑ i ∈ s, u i * ∏ j ∈ s.erase i, (1 + t * u j)) := by
    rw [Finset.mul_sum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    have hp : 1 + t * u i ≠ 0 := by nlinarith [htu i hi]
    have hprod := Finset.mul_prod_erase s (fun j => 1 + t * u j) hi
    rw [← hprod]
    field_simp [hp]
  have heq : t * (∑ v ∈ s.powerset,
        (v.card : ℝ) * t ^ (v.card - 1) * (∏ i ∈ v, u i)) =
      t * (∑ i ∈ s, u i * ∏ j ∈ s.erase i, (1 + t * u j)) :=
    hleft.trans (hm.trans hright)
  exact mul_left_cancel₀ (ne_of_gt ht) heq

/-- Specialization at the damping parameter `1/2` used in the manuscript. -/
theorem finite_marked_euler_half {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (u : ι → ℝ) (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ v ∈ s.powerset, countFactor v.card * (∏ i ∈ v, u i)) =
      ∑ i ∈ s, u i * ∏ j ∈ s.erase i, (1 + u j / 2) := by
  have h := finite_marked_euler s u (1 / 2) (by norm_num) hu
  simpa [countFactor, div_pow, div_eq_mul_inv, mul_comm] using h

/-- The singleton terms alone give the elementary marked-mass lower bound. -/
theorem finite_marked_mass_ge_sum {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (u : ι → ℝ) (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ i ∈ s, u i) ≤ ∑ v ∈ s.powerset, countFactor v.card * (∏ i ∈ v, u i) := by
  rw [finite_marked_euler_half s u hu]
  apply Finset.sum_le_sum
  intro i hi
  have hprod : 1 ≤ ∏ j ∈ s.erase i, (1 + u j / 2) := by
    apply Finset.one_le_prod₀
    intro j hj
    have hj0 := hu j (Finset.mem_of_mem_erase hj)
    linarith
  simpa only [mul_one] using mul_le_mul_of_nonneg_left hprod (hu i hi)

/-- A finite normalized marked mass is at least one whenever its normalization
does not exceed the singleton mass. -/
theorem finite_normalized_marked_mass_ge_one {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (u : ι → ℝ) (hu : ∀ i ∈ s, 0 ≤ u i)
    (V : ℝ) (hV : 0 < V) (hVsum : V ≤ ∑ i ∈ s, u i) :
    1 ≤ (∑ v ∈ s.powerset, countFactor v.card * (∏ i ∈ v, u i)) / V := by
  apply (le_div_iff₀ hV).mpr
  simpa only [one_mul] using hVsum.trans (finite_marked_mass_ge_sum s u hu)

end Artin.MarkedWeights
