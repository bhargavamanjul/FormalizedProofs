module

public import Artin.Arithmetic
public import Mathlib.NumberTheory.LegendreSymbol.JacobiSymbol
public import Mathlib.Data.Nat.ChineseRemainder
public import Mathlib.Algebra.Squarefree.Basic
public import Mathlib.Tactic.NormNum.LegendreSymbol
public import Mathlib.Tactic.NormNum.Prime

/-!
# Fixed quadratic-nonresidue progressions

The Jacobi-symbol period is the proved quadratic-reciprocity theorem in
Mathlib. The progression arithmetic below is elementary: the permitted class
modulo eight selects `c=2` or `c=4`, and avoiding residues zero and one at the
odd modulus primes proves the two coprimality conditions.

The general construction takes an explicit finite Jacobi-symbol seed.
The seven exceptional signed squarefree bases are handled unconditionally.
Existence of a compatible seed for every admissible integer is not claimed.
-/

@[expose] public section

namespace Artin.NonresidueProgression

/-- The actual fixed progression data required in §2 of the manuscript. -/
structure Progression (a : ℤ) where
  M : ℕ
  c : ℕ
  u : ℕ
  u_lt_M : u < M
  M_pos : 0 < M
  eight_dvd : 8 ∣ M
  c_choice : c = 2 ∨ c = 4
  unit : Nat.Coprime u M
  predecessor_dvd : c ∣ u - 1
  quotient_unit : Nat.Coprime ((u - 1) / c) (M / c)
  nonresidue : ∀ p : ℕ, p.Prime → Nat.ModEq M p u → ¬ IsSquare (a : ZMod p)

/-- The reduced representative has the exact form used in the progression
sums: `M=c*M₀`, `u=c*v+1`, and `v` is a reduced class modulo `M₀`. -/
theorem Progression.normal_form {a : ℤ} (D : Progression a) :
    ∃ M₀ v : ℕ, D.M = D.c * M₀ ∧ D.u = D.c * v + 1 ∧
      v < M₀ ∧ Nat.Coprime v M₀ := by
  have hc8 : D.c ∣ 8 := by
    rcases D.c_choice with hc | hc <;> rw [hc] <;> decide
  have hcM : D.c ∣ D.M := hc8.trans D.eight_dvd
  have hM : D.M = D.c * (D.M / D.c) := (Nat.mul_div_cancel' hcM).symm
  have huone : 1 ≤ D.u := by
    by_contra h
    have hu : D.u = 0 := by omega
    have hMone : D.M = 1 := by simpa only [hu, Nat.coprime_zero_left] using D.unit
    have h8 := D.eight_dvd
    rw [hMone] at h8
    norm_num at h8
  have hu : D.u = D.c * ((D.u - 1) / D.c) + 1 := by
    rw [Nat.mul_div_cancel' D.predecessor_dvd]
    omega
  refine ⟨D.M / D.c, (D.u - 1) / D.c, hM, hu, ?_, D.quotient_unit⟩
  by_contra hn
  have hh := Nat.mul_le_mul_left D.c (le_of_not_gt hn)
  have hult := D.u_lt_M
  omega

/-- Admissibility supplies a genuine signed squarefree part different from
one and a nonzero square factor. This is the reduction used by the residue
selection argument; it does not assert that the general seed has been built. -/
theorem admissible_squarefree_decomposition (a : ℤ) (ha : Artin.Admissible a) :
    ∃ d t : ℤ, a = d * t ^ 2 ∧ Squarefree d ∧ d ≠ 1 ∧ t ≠ 0 := by
  obtain ⟨t, d, htd, hd⟩ := exists_sq_mul_squarefree a
  refine ⟨d, t, by rw [← htd]; ring, hd, ?_, ?_⟩
  · intro hd1
    apply ha.1
    refine ⟨t, ?_⟩
    rw [← htd, hd1]
    ring
  · intro ht
    have ha0 : a = 0 := by rw [← htd, ht]; ring
    exact ha.1 (ha0.symm ▸ IsSquare.zero)

/-- Multiplying the base by a square preserves the constructed progression
once the square factor's prime support is contained in the fixed modulus. -/
theorem Progression.mul_square {d : ℤ} (D : Progression d) (t : ℤ)
    (hsupport : ∀ p : ℕ, p.Prime → p ∣ t.natAbs → p ∣ D.M) :
    Nonempty (Progression (d * t ^ 2)) := by
  refine ⟨⟨D.M, D.c, D.u, D.u_lt_M, D.M_pos, D.eight_dvd, D.c_choice, D.unit,
    D.predecessor_dvd, D.quotient_unit, ?_⟩⟩
  intro p hp hpu
  let : Fact p.Prime := ⟨hp⟩
  have ht : (t : ZMod p) ≠ 0 := by
    intro hz
    have hpt : (p : ℤ) ∣ t := (ZMod.intCast_zmod_eq_zero_iff_dvd t p).mp hz
    have hpM := hsupport p hp (Int.natCast_dvd.mp hpt)
    have hmod : p % p = D.u % p := hpu.of_dvd hpM
    have hpu' : p ∣ D.u := Nat.dvd_of_mod_eq_zero (by simpa only [Nat.mod_self] using hmod.symm)
    exact Nat.not_coprime_of_dvd_of_dvd hp.one_lt hpu' hpM D.unit
  apply (legendreSym.eq_neg_one_iff p).mp
  rw [legendreSym.mul, legendreSym.sq_one' p ht, mul_one]
  exact (legendreSym.eq_neg_one_iff p).mpr (D.nonresidue p hp hpu)

/-- The three permitted classes modulo eight have exact predecessor
2-adic part two or four. -/
theorem exists_two_part (u : ℕ) (hu : u % 8 = 3 ∨ u % 8 = 5 ∨ u % 8 = 7) :
    ∃ c : ℕ, (c = 2 ∨ c = 4) ∧ c ∣ 8 ∧ c ∣ u - 1 ∧ ((u - 1) / c) % 2 = 1 := by
  rcases hu with hu | hu | hu
  · refine ⟨2, Or.inl rfl, by decide, ?_, ?_⟩
    · exact Nat.dvd_of_mod_eq_zero (by omega)
    · omega
  · refine ⟨4, Or.inr rfl, by decide, ?_, ?_⟩
    · exact Nat.dvd_of_mod_eq_zero (by omega)
    · omega
  · refine ⟨2, Or.inl rfl, by decide, ?_, ?_⟩
    · exact Nat.dvd_of_mod_eq_zero (by omega)
    · omega

/-- Avoiding zero at each odd modulus prime and choosing an odd class modulo
eight makes the progression reduced. -/
theorem residue_coprime (M u : ℕ)
    (hu : u % 8 = 3 ∨ u % 8 = 5 ∨ u % 8 = 7)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → u % q ≠ 0) :
    Nat.Coprime u M := by
  apply Nat.coprime_of_dvd
  intro q hq hqu hqM
  by_cases hq2 : q = 2
  · subst q
    have hh := Nat.mod_eq_zero_of_dvd hqu
    omega
  · exact havoid q hq hq2 hqM (Nat.mod_eq_zero_of_dvd hqu)

/-- Avoiding one at every odd modulus prime, together with the exact two-part,
makes the quotient progression reduced. -/
theorem quotient_coprime (M u c : ℕ) (hcM : c ∣ M) (hcu : c ∣ u - 1)
    (huone : 1 ≤ u) (hodd : ((u - 1) / c) % 2 = 1)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → u % q ≠ 1) :
    Nat.Coprime ((u - 1) / c) (M / c) := by
  apply Nat.coprime_of_dvd
  intro q hq hqu hqM
  by_cases hq2 : q = 2
  · subst q
    have hh := Nat.mod_eq_zero_of_dvd hqu
    omega
  · have hqMd : q ∣ M := hqM.trans (Nat.div_dvd_of_dvd hcM)
    have hqud : q ∣ u - 1 := hqu.trans (Nat.div_dvd_of_dvd hcu)
    have heq : Nat.ModEq q 1 u := (Nat.modEq_iff_dvd' huone).mpr hqud
    apply havoid q hq hq2 hqMd
    simpa only [Nat.ModEq, Nat.mod_eq_of_lt hq.one_lt] using heq.symm

/-- Quadratic reciprocity transfers a finite Jacobi-symbol certificate to
every prime of the progression. This uses Mathlib's proved period theorem,
not a hypothesis asserting nonresiduacity on the progression. -/
theorem nonresidue_of_jacobi_seed (a : ℤ) (M u : ℕ) (h8 : 8 ∣ M)
    (hperiod : 4 * a.natAbs ∣ M)
    (hu : u % 8 = 3 ∨ u % 8 = 5 ∨ u % 8 = 7)
    (hsign : jacobiSym a u = -1)
    (p : ℕ) (hp : p.Prime) (hpu : Nat.ModEq M p u) :
    ¬ IsSquare (a : ZMod p) := by
  let : Fact p.Prime := ⟨hp⟩
  have hmod8 : p % 8 = u % 8 := hpu.of_dvd h8
  have hp2 : p ≠ 2 := by omega
  have huodd : Odd u := Nat.odd_iff.mpr (by omega)
  apply (legendreSym.eq_neg_one_iff p).mp
  calc
    legendreSym p a = jacobiSym a p := jacobiSym.legendreSym.to_jacobiSym p a
    _ = jacobiSym a (p % (4 * a.natAbs)) := jacobiSym.mod_right a (hp.odd_of_ne_two hp2)
    _ = jacobiSym a (u % (4 * a.natAbs)) := congrArg (jacobiSym a) (hpu.of_dvd hperiod)
    _ = jacobiSym a u := (jacobiSym.mod_right a huodd).symm
    _ = -1 := hsign

/-- Elementary assembly from a finite Jacobi seed. All progression properties
are proved, including exact two-part and both reducedness conditions. -/
theorem exists_progression_of_jacobi_seed (a : ℤ) (M u : ℕ) (hM : 0 < M)
    (h8 : 8 ∣ M) (hperiod : 4 * a.natAbs ∣ M)
    (hu : u % 8 = 3 ∨ u % 8 = 5 ∨ u % 8 = 7)
    (havoid : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → u % q ≠ 0 ∧ u % q ≠ 1)
    (hsign : jacobiSym a u = -1) : Nonempty (Progression a) := by
  let v := u % M
  have hv : v % 8 = 3 ∨ v % 8 = 5 ∨ v % 8 = 7 := by
    dsimp [v]
    rwa [Nat.mod_mod_of_dvd u h8]
  have havoidv : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ M → v % q ≠ 0 ∧ v % q ≠ 1 := by
    intro q hq hq2 hqM
    dsimp [v]
    rw [Nat.mod_mod_of_dvd u hqM]
    exact havoid q hq hq2 hqM
  have hvsign : jacobiSym a v = -1 := by
    have huo : Odd u := Nat.odd_iff.mpr (by omega)
    have hvo : Odd v := Nat.odd_iff.mpr (by omega)
    rw [jacobiSym.mod_right a hvo]
    dsimp [v]
    rw [Nat.mod_mod_of_dvd u hperiod, ← jacobiSym.mod_right a huo]
    exact hsign
  obtain ⟨c, hc, hc8, hcu, hodd⟩ := exists_two_part v hv
  refine ⟨⟨M, c, v, Nat.mod_lt u hM, hM, h8, hc,
    residue_coprime M v hv (fun q hq hq2 hqM => (havoidv q hq hq2 hqM).1), hcu, ?_, ?_⟩⟩
  · exact quotient_coprime M v c (hc8.trans h8) hcu (by omega) hodd
      (fun q hq hq2 hqM => (havoidv q hq hq2 hqM).2)
  · exact nonresidue_of_jacobi_seed a M v h8 hperiod hv hvsign

/-- At an odd prime at least five, both quadratic signs occur away from
zero and one. The positive sign is supplied by four; a finite-field nonsquare
supplies the negative sign. -/
theorem both_signs_away_from_zero_one (q : ℕ) (hq : q.Prime) (hq5 : 5 ≤ q)
    (e : ℤ) (he : e = 1 ∨ e = -1) :
    ∃ r : ℕ, r < q ∧ r ≠ 0 ∧ r ≠ 1 ∧ @legendreSym q ⟨hq⟩ r = e := by
  let : Fact q.Prime := ⟨hq⟩
  rcases he with rfl | rfl
  · refine ⟨4, by omega, by decide, by decide, ?_⟩
    have htwo : (2 : ZMod q) ≠ 0 := by
      intro h
      have hd : q ∣ 2 := (ZMod.natCast_eq_zero_iff 2 q).mp h
      have hh := Nat.le_of_dvd (by decide : 0 < 2) hd
      omega
    have htwo' : ((2 : ℤ) : ZMod q) ≠ 0 := by simpa using htwo
    simpa using legendreSym.sq_one' q (a := 2) htwo'
  · obtain ⟨z, hz⟩ := FiniteField.exists_nonsquare (F := ZMod q)
      (by rw [ZMod.ringChar_zmod_n]; omega)
    have hz0 : z ≠ 0 := fun h => hz (h.symm ▸ IsSquare.zero)
    have hz1 : z ≠ 1 := fun h => hz (h.symm ▸ IsSquare.one)
    refine ⟨z.val, ZMod.val_lt z, ?_, ?_, ?_⟩
    · intro h
      apply hz0
      rw [← ZMod.natCast_zmod_val z, h, Nat.cast_zero]
    · intro h
      apply hz1
      rw [← ZMod.natCast_zmod_val z, h, Nat.cast_one]
    · apply (legendreSym.eq_neg_one_iff q).mpr
      simpa only [Int.cast_natCast, ZMod.natCast_zmod_val] using hz

/-- CRT realizes arbitrary chosen residues at all odd group primes while
independently prescribing the class modulo eight. -/
theorem exists_crt_residues (P : Finset ℕ) (r : ℕ → ℕ) (b : ℕ)
    (hP : ∀ q ∈ P, q.Prime ∧ q ≠ 2) :
    ∃ u : ℕ, Nat.ModEq 8 u b ∧ ∀ q ∈ P, Nat.ModEq q u (r q) := by
  classical
  have h8P : 8 ∉ P := by
    intro h
    exact (by decide : ¬ Nat.Prime 8) (hP 8 h).1
  have hc8 (q : ℕ) (hq : q ∈ P) : Nat.Coprime 8 q := by
    have hco : Nat.Coprime 2 q :=
      (Nat.coprime_primes Nat.prime_two (hP q hq).1).mpr (hP q hq).2.symm
    simpa using hco.pow_left 3
  let residues : ℕ → ℕ := fun q => if q = 8 then b else r q
  have hnonzero : ∀ q ∈ insert 8 P, q ≠ 0 := by
    intro q hq
    rcases Finset.mem_insert.mp hq with rfl | hq
    · decide
    · exact (hP q hq).1.ne_zero
  have hpair : Set.Pairwise (insert 8 P : Finset ℕ) (Function.onFun Nat.Coprime id) := by
    intro i hi j hj hij
    rcases Finset.mem_insert.mp hi with rfl | hi
    · have hjP : j ∈ P := (Finset.mem_insert.mp hj).resolve_left hij.symm
      exact hc8 j hjP
    · rcases Finset.mem_insert.mp hj with rfl | hj
      · exact (hc8 i hi).symm
      · exact (Nat.coprime_primes (hP i hi).1 (hP j hj).1).mpr hij
  let u := Nat.chineseRemainderOfFinset residues id (insert 8 P) hnonzero hpair
  refine ⟨u.val, ?_, ?_⟩
  · simpa only [residues, reduceIte, id_eq] using u.property 8 (Finset.mem_insert_self _ _)
  · intro q hq
    have hq8 : q ≠ 8 := fun h => h8P (h ▸ hq)
    simpa [residues, hq8] using u.property q (Finset.mem_insert_of_mem hq)

theorem odd_prime_not_dvd_eight (q : ℕ) (hq : q.Prime) (hq2 : q ≠ 2) : ¬ q ∣ 8 := by
  intro hq8
  have hqle : q ≤ 8 := Nat.le_of_dvd (by decide : 0 < 8) hq8
  interval_cases q <;> norm_num at *

theorem odd_prime_dvd_twenty_four (q : ℕ) (hq : q.Prime) (hq2 : q ≠ 2)
    (hq24 : q ∣ 24) : q = 3 := by
  have hqle : q ≤ 24 := Nat.le_of_dvd (by decide : 0 < 24) hq24
  interval_cases q <;> norm_num at *

/-- Direct verification of all seven exceptional signed squarefree entries
in the manuscript's table. These conclusions have no unproved reciprocity
or progression-existence assumption. -/
theorem exceptional_progressions (d : ℤ)
    (hd : d = -1 ∨ d = 2 ∨ d = -2 ∨ d = 3 ∨ d = -3 ∨ d = 6 ∨ d = -6) :
    Nonempty (Progression d) := by
  have h8 (u : ℕ) : ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ 8 → u % q ≠ 0 ∧ u % q ≠ 1 := by
    intro q hq hq2 hq8
    exact (odd_prime_not_dvd_eight q hq hq2 hq8).elim
  have h24 (u : ℕ) (hu : u % 3 = 2) :
      ∀ q : ℕ, q.Prime → q ≠ 2 → q ∣ 24 → u % q ≠ 0 ∧ u % q ≠ 1 := by
    intro q hq hq2 hq24
    have heq := odd_prime_dvd_twenty_four q hq hq2 hq24
    subst q
    omega
  rcases hd with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact exists_progression_of_jacobi_seed (-1) 8 3 (by decide) (by decide) (by norm_num)
      (by decide) (h8 3) (by norm_num)
  · exact exists_progression_of_jacobi_seed 2 8 3 (by decide) (by decide) (by norm_num)
      (by decide) (h8 3) (by norm_num)
  · exact exists_progression_of_jacobi_seed (-2) 8 7 (by decide) (by decide) (by norm_num)
      (by decide) (h8 7) (by norm_num)
  · exact exists_progression_of_jacobi_seed 3 24 5 (by decide) (by decide) (by norm_num)
      (by decide) (h24 5 (by decide)) (by norm_num)
  · exact exists_progression_of_jacobi_seed (-3) 24 5 (by decide) (by decide) (by norm_num)
      (by decide) (h24 5 (by decide)) (by norm_num)
  · exact exists_progression_of_jacobi_seed 6 24 11 (by decide) (by decide) (by norm_num)
      (by decide) (h24 11 (by decide)) (by norm_num)
  · exact exists_progression_of_jacobi_seed (-6) 24 23 (by decide) (by decide) (by norm_num)
      (by decide) (h24 23 (by decide)) (by norm_num)

end Artin.NonresidueProgression
