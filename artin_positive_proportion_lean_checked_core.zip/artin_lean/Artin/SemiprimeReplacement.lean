module

public import Artin.MarkedSource
public import Artin.DyadicBoxes
public import Artin.SemiprimeSieve
public import Artin.RoughFactorization

/-!
# The two replacements in a semiprime box

The replacement errors below are the explicit finite sums to which MR must
be applied. They are not accepted as an independent classical theorem. This
module proves their telescoping, and the cancellation of the two roughness
factors without using a pointwise bound for the marking weight.
-/

@[expose] public section
namespace Artin.SemiprimeReplacement

open scoped BigOperators

/-- No product of two or more primes contributes to the source density
when the logarithmic size is below twice the roughness exponent. -/
theorem densityTerm_eq_zero_of_two_mul {γ s : ℝ} (hγ : 0 ≤ γ)
    (hs : s < 2 * γ) (j : ℕ) : MarkedSource.densityTerm γ s (j + 2) = 0 := by
  have he : {t : Fin (j + 1) → ℝ | (∀ i, γ ≤ t i) ∧ (∑ i, t i) ≤ s - γ} = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro t ht
    have hsingle : t 0 ≤ ∑ i, t i := Finset.single_le_sum
      (fun i _ => hγ.trans (ht.1 i)) (Finset.mem_univ (0 : Fin (j + 1)))
    have hzero := ht.1 0
    have hsum := ht.2
    linarith
  simp [MarkedSource.densityTerm, he]

/-- In particular the exact source simplex density equals `1/s` on the
semiprime factor range; no Buchstab identification is needed for this fact. -/
theorem density_eq_inv_of_two_mul {γ s : ℝ} (hγ : 0 ≤ γ) (hs : s < 2 * γ) :
    MarkedSource.density γ s = s⁻¹ := by
  unfold MarkedSource.density
  rw [tsum_eq_single 1]
  · rfl
  · intro j hj
    cases j with
    | zero => rfl
    | succ j =>
      cases j with
      | zero => exact False.elim (hj rfl)
      | succ j => exact densityTerm_eq_zero_of_two_mul hγ hs j

/-- Below the square of the roughness threshold, every nontrivial rough
integer is itself prime. -/
theorem prime_of_rough_below_square {d : ℕ} {R : ℝ} (hd : 2 ≤ d) (hR : 0 ≤ R)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ d → R < (p : ℝ))
    (hsize : (d : ℝ) ≤ R ^ 2) : d.Prime := by
  by_contra hp
  obtain ⟨m, n, hm, hn, heq⟩ := (Nat.not_prime_iff_exists_mul_eq hd).mp hp
  obtain ⟨hm2, hn2⟩ := RoughFactorization.proper_factors_ge_two hd hm hn heq
  have hmR := RoughFactorization.rough_divisor_gt hrough hm2 (heq ▸ dvd_mul_right m n)
  have hnR := RoughFactorization.rough_divisor_gt hrough hn2 (heq ▸ dvd_mul_left n m)
  have heq' : (m : ℝ) * n = d := by exact_mod_cast heq
  have hprod : R ^ 2 < (m : ℝ) * n := by
    rw [pow_two]
    gcongr
  linarith

/-- In the fixed semiprime dyads, the rough indicator at `x^0.4` is exactly
the prime indicator, including its zero values on composites. -/
theorem rough_iff_prime_on_factor_support {x : ℝ} {n : ℕ} (hx : 1 < x)
    (hlo : x ^ (46 / 100 : ℝ) ≤ (n : ℝ))
    (hhi : (n : ℝ) ≤ x ^ (54 / 100 : ℝ)) :
    MarkedCriterion.IsRough (x ^ (2 / 5 : ℝ)) n ↔ n.Prime := by
  have hx0 : 0 < x := by linarith
  have hn1 : (1 : ℝ) < n :=
    (Real.one_lt_rpow hx (by norm_num : (0 : ℝ) < 46 / 100)).trans_le hlo
  have hn2 : 2 ≤ n := by exact_mod_cast hn1
  have hlow : x ^ (2 / 5 : ℝ) < (n : ℝ) :=
    (Real.rpow_lt_rpow_of_exponent_lt hx (by norm_num : (2 / 5 : ℝ) < 46 / 100)).trans_le hlo
  have hsquare : (n : ℝ) ≤ (x ^ (2 / 5 : ℝ)) ^ 2 := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hx0.le]
    exact hhi.trans (Real.rpow_le_rpow_of_exponent_le hx.le (by norm_num))
  constructor
  · intro h
    exact prime_of_rough_below_square hn2 (Real.rpow_nonneg hx0.le _) h hsquare
  · intro hp p hpp hpn
    have heq := (Nat.prime_dvd_prime_iff_eq hpp hp).mp hpn
    simpa [heq] using hlow

/-- The manuscript's stated value `D₀.₄(s)=1/s` on every whole factor dyad. -/
theorem density_on_factor_support {x : ℝ} {n : ℕ} (hx : 1 < x)
    (hhi : (n : ℝ) ≤ x ^ (54 / 100 : ℝ)) (hn : 0 < n) :
    MarkedSource.density (2 / 5) (Real.log n / Real.log x) =
      (Real.log n / Real.log x)⁻¹ := by
  apply density_eq_inv_of_two_mul (by norm_num)
  have hlog := Real.log_le_log (by exact_mod_cast hn) hhi
  rw [Real.log_rpow (by linarith : 0 < x)] at hlog
  have hL := Real.log_pos hx
  apply (div_lt_iff₀ hL).mpr
  nlinarith

/-- A bilinear sum over an actual finite box of natural factors. -/
noncomputable def pairMass (A B : Finset ℕ) (w α β : ℕ → ℝ) : ℝ :=
  ∑ m ∈ A, ∑ n ∈ B, w (m * n) * α m * β n

/-- The two errors add exactly to the difference between the initial and
twice-replaced sums.  The second companion coefficient is the first replaced
coefficient, as required when applying MR a second time. -/
theorem two_replacement_identity (A B : Finset ℕ) (w p q f g : ℕ → ℝ) :
    pairMass A B w p q - pairMass A B w f g =
      pairMass A B w (fun m => p m - f m) q +
        pairMass A B w f (fun n => q n - g n) := by
  unfold pairMass
  rw [← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro m _
  rw [← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro n _
  ring

/-- The proved triangle inequality for the two actual replacement sums. -/
theorem pairMass_le_after_two_replacements (A B : Finset ℕ) (w p q f g : ℕ → ℝ)
    {E₁ E₂ : ℝ}
    (h₁ : |pairMass A B w (fun m => p m - f m) q| ≤ E₁)
    (h₂ : |pairMass A B w f (fun n => q n - g n)| ≤ E₂) :
    pairMass A B w p q ≤ pairMass A B w f g + E₁ + E₂ := by
  have heq := two_replacement_identity A B w p q f g
  have hb := (abs_add_le (pairMass A B w (fun m => p m - f m) q)
    (pairMass A B w f (fun n => q n - g n))).trans (add_le_add h₁ h₂)
  have h := (le_abs_self (pairMass A B w p q - pairMass A B w f g)).trans
    (by rw [heq])
  linarith

/-- The exact replacement coefficient for prime factors near the square root. -/
noncomputable def roughPrimeModel (rough : ℕ → ℝ) (V : ℝ) (n : ℕ) : ℝ :=
  rough n / (V * Real.log n)

/-- Two logarithmic denominators and the box rough-pair estimate give a
constant independent of the marks: the factor `V²` cancels exactly. -/
theorem roughPrimeModel_pairMass_le (A B : Finset ℕ) (w rough : ℕ → ℝ)
    {V L σ C X₀ : ℝ} (hV : 0 < V) (hL : 0 < L) (hσ : 0 < σ)
    (hw : ∀ m ∈ A, ∀ n ∈ B, 0 ≤ w (m * n))
    (hr : ∀ n, 0 ≤ rough n)
    (hA : ∀ m ∈ A, σ * L ≤ Real.log m)
    (hB : ∀ n ∈ B, σ * L ≤ Real.log n)
    (hpairs : pairMass A B w rough rough ≤ C * X₀ * V ^ 2) :
    pairMass A B w (roughPrimeModel rough V) (roughPrimeModel rough V) ≤
      C * X₀ / (σ ^ 2 * L ^ 2) := by
  have hden : 0 < (V * (σ * L)) ^ 2 := by positivity
  have hb : pairMass A B w (roughPrimeModel rough V) (roughPrimeModel rough V) ≤
      pairMass A B w rough rough / (V * (σ * L)) ^ 2 := by
    unfold pairMass
    rw [Finset.sum_div]
    apply Finset.sum_le_sum
    intro m hm
    rw [Finset.sum_div]
    apply Finset.sum_le_sum
    intro n hn
    have hml : 0 < Real.log m := lt_of_lt_of_le (mul_pos hσ hL) (hA m hm)
    have hnl : 0 < Real.log n := lt_of_lt_of_le (mul_pos hσ hL) (hB n hn)
    have hf : roughPrimeModel rough V m ≤ rough m / (V * (σ * L)) :=
      div_le_div_of_nonneg_left (hr m) (by positivity)
        (mul_le_mul_of_nonneg_left (hA m hm) hV.le)
    have hg : roughPrimeModel rough V n ≤ rough n / (V * (σ * L)) :=
      div_le_div_of_nonneg_left (hr n) (by positivity)
        (mul_le_mul_of_nonneg_left (hB n hn) hV.le)
    have h := mul_le_mul hf hg
      (div_nonneg (hr n) (mul_nonneg hV.le hnl.le))
      (div_nonneg (hr m) (by positivity))
    have hh := mul_le_mul_of_nonneg_left h (hw m hm n hn)
    convert hh using 1 <;> ring
  refine hb.trans ?_
  calc
    pairMass A B w rough rough / (V * (σ * L)) ^ 2 ≤
        C * X₀ * V ^ 2 / (V * (σ * L)) ^ 2 :=
      div_le_div_of_nonneg_right hpairs hden.le
    _ = C * X₀ / (σ ^ 2 * L ^ 2) := by field_simp

/-- Complete numerical consequence of the two replacements in one box,
with no marking bound and no number of marks in the main coefficient. -/
theorem semiprime_box_after_two_replacements (A B : Finset ℕ)
    (w prime rough : ℕ → ℝ) {V L σ C X₀ E₁ E₂ : ℝ}
    (hV : 0 < V) (hL : 0 < L) (hσ : 0 < σ)
    (hw : ∀ m ∈ A, ∀ n ∈ B, 0 ≤ w (m * n))
    (hr : ∀ n, 0 ≤ rough n)
    (hA : ∀ m ∈ A, σ * L ≤ Real.log m)
    (hB : ∀ n ∈ B, σ * L ≤ Real.log n)
    (hpairs : pairMass A B w rough rough ≤ C * X₀ * V ^ 2)
    (h₁ : |pairMass A B w (fun m => prime m - roughPrimeModel rough V m) prime| ≤ E₁)
    (h₂ : |pairMass A B w (roughPrimeModel rough V)
      (fun n => prime n - roughPrimeModel rough V n)| ≤ E₂) :
    pairMass A B w prime prime ≤ C * X₀ / (σ ^ 2 * L ^ 2) + E₁ + E₂ := by
  have h := pairMass_le_after_two_replacements A B w prime prime _ _ h₁ h₂
  have hb := roughPrimeModel_pairMass_le A B w rough hV hL hσ hw hr hA hB hpairs
  linarith

end Artin.SemiprimeReplacement
