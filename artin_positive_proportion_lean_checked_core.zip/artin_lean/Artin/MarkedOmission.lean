module

public import Artin.MarkedScaleSupport
public import Artin.BuchstabSieve
public import Artin.SemiprimeSieve

/-!
# Uniform reciprocal mass of omitted cofactor primes

The defining unmarked cofactor condition supplies a reciprocal-prime sum at
most `τ`.  Marked prime powers contribute a uniform quantity tending to zero,
because their prime divisors are large and the full integer has bounded
logarithmic size.  The resulting local-product loss is independent of the
number of marked bands.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.MarkedOmission

open ConcreteSelector MarkedCofactorEstimate MarkedBandTail CofactorAsymptotics

/-- The reciprocal-prime condition on subset products is exactly the same
condition on prime divisors of the resulting natural number. -/
theorem cofactor_prime_reciprocal_le (S : Finset ℕ) (hS : ∀ p ∈ S, p.Prime)
    (R τ : ℝ) {r : ℕ} (hr : r ∈ cofactors S R τ) :
    (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ τ := by
  classical
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hr
  have htp : ∀ p ∈ t, p.Prime :=
    fun p hp => hS p ((Finset.mem_powerset.mp (Finset.mem_filter.mp ht).1) hp)
  rw [Nat.primeFactors_prod htp]
  exact (Finset.mem_filter.mp ht).2.2

/-- In particular, every actual unmarked cofactor carries reciprocal-prime
mass at most its defining cap. -/
theorem unmarked_reciprocal_le {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) {r : ℕ} (hr : r ∈ unmarkedCofactors I a ε Y τ x) :
    (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ τ :=
  cofactor_prime_reciprocal_le _ (fun _p hp => unmarkedPrimes_prime _ _ _ hp) _ τ hr

/-- Prime-divisor mass is subadditive under the exact marked/stripped
factorization. Multiplicities of marked primes cause no extra loss. -/
theorem reciprocal_le_marked_add_stripped (P : Finset ℕ) {r : ℕ} (hr : 0 < r) :
    (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤
      (∑ p ∈ (markedPart P r).primeFactors, 1 / (p : ℝ)) +
      (∑ p ∈ (strip P r).primeFactors, 1 / (p : ℝ)) := by
  have hh := Finset.sum_union_inter
    (s₁ := (markedPart P r).primeFactors) (s₂ := (strip P r).primeFactors)
    (f := fun p : ℕ => 1 / (p : ℝ))
  rw [← Nat.primeFactors_mul (markedPart_pos P hr.ne').ne' (strip_pos P hr.ne').ne',
    markedPart_mul_strip P hr.ne'] at hh
  have hn : 0 ≤ ∑ p ∈ (markedPart P r).primeFactors ∩ (strip P r).primeFactors,
      1 / (p : ℝ) := Finset.sum_nonneg (fun _ _ => by positivity)
  linarith

/-- A marked part cannot exceed its positive original integer. -/
theorem markedPart_le (P : Finset ℕ) {r : ℕ} (hr : 0 < r) : markedPart P r ≤ r := by
  apply Nat.le_of_dvd hr
  exact ⟨strip P r, (markedPart_mul_strip P hr.ne').symm⟩

/-- The manuscript's lower band exponent gives the explicit lower endpoint
for every prime divisor of the full marked part. -/
theorem marked_part_prime_lower {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    {x : ℝ} (hL : 1 ≤ Real.log x) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (r : ℕ) : ∀ p ∈ (markedPart (markedPrimes I a x) r).primeFactors,
      Real.exp ((Real.log x) ^ (1 / 10 : ℝ)) ≤ (p : ℝ) := by
  intro p hp
  rw [primeFactors_markedPart] at hp
  obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp (Finset.mem_inter.mp hp).2
  exact (Real.exp_le_exp.mpr (Real.rpow_le_rpow_of_exponent_le hL (ha i hi))).trans
    (primeBand_properties (a i) x hpi).2.1

/-- An explicit error term, uniform in every actual enlarged cofactor up to
`x^C`, follows from its marked/stripped factorization. -/
theorem enlarged_reciprocal_bound {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ C x : ℝ) (hC : 0 ≤ C) (hx : 1 < x) (hL : 1 ≤ Real.log x)
    (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i) {r : ℕ}
    (hr : r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C)) :
    (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ τ + markedDivisorError C x := by
  have hh := (mem_boundedCofactors _ _ _ r).mp hr
  have hm := marked_prime_divisor_bound (markedPart (markedPrimes I a x) r) C x
    (markedPart_pos _ hh.1.ne') hC hx
    ((by exact_mod_cast markedPart_le (markedPrimes I a x) hh.1 :
      (markedPart (markedPrimes I a x) r : ℝ) ≤ r).trans hh.2.2)
    (marked_part_prime_lower I a hL ha r)
  have hu := unmarked_reciprocal_le I a ε Y τ x hh.2.1
  have hs := reciprocal_le_marked_add_stripped (markedPrimes I a x) hh.1
  linarith

/-- The common threshold precedes the unmarked cofactor parameters and all
integers in the growing cofactor family. -/
theorem eventual_reciprocal_bound {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (C : ℝ) (hC : 0 ≤ C) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (η : ℝ) (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y τ : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C),
      (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ τ + η := by
  filter_upwards [(markedDivisorError_tendsto C).eventually_lt_const hη,
    eventually_gt_atTop (1 : ℝ),
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ))] with x he hx hL
  intro ε Y τ r hr
  exact (enlarged_reciprocal_bound I a ε Y τ C x hC hx hL ha hr).trans
    (by linarith)

/-- The convenient cap `2τ`, still with no dependence on the number of bands
in its constant and no pointwise bound on the marking weight. -/
theorem eventual_reciprocal_cap {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (C : ℝ) (hC : 0 ≤ C) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (τ : ℝ) (hτ : 0 < τ) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C),
      (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ 2 * τ := by
  filter_upwards [eventual_reciprocal_bound I a C hC ha τ hτ] with x hx
  intro ε Y r hr
  simpa only [two_mul] using hx ε Y τ r hr

/-- Any finite collection of distinct prime divisors has no more reciprocal
mass than the full prime-divisor set. -/
theorem reciprocal_prime_divisors_le (S : Finset ℕ) {r : ℕ} (hr : 0 < r)
    (hS : ∀ p ∈ S, p.Prime ∧ p ∣ r) :
    (∑ p ∈ S, 1 / (p : ℝ)) ≤ ∑ p ∈ r.primeFactors, 1 / (p : ℝ) := by
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro p hp
    exact (hS p hp).1.mem_primeFactors (hS p hp).2 hr.ne'
  · intro p _ _
    positivity

/-- Primes omitted because they divide the cofactor, including restriction
away from any fixed modulus, satisfy the actual uniform cap. -/
theorem eventual_omitted_reciprocal_cap {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (C : ℝ) (hC : 0 ≤ C) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (τ : ℝ) (hτ : 0 < τ) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C),
      ∀ S : Finset ℕ, (∀ p ∈ S, p.Prime) → ∀ M : ℕ,
      (∑ p ∈ S.filter (fun p => p ∣ r ∧ ¬ p ∣ M), 1 / (p : ℝ)) ≤ 2 * τ := by
  filter_upwards [eventual_reciprocal_cap I a C hC ha τ hτ] with x hx
  intro ε Y r hr S hS M
  have hrpos := ((mem_boundedCofactors _ _ _ r).mp hr).1
  apply (reciprocal_prime_divisors_le _ hrpos ?_).trans (hx ε Y r hr)
  intro p hp
  have hh := Finset.mem_filter.mp hp
  exact ⟨hS p hh.1, hh.2.1⟩

/-- The actual one-dimensional sieve local product loses at most `exp(20τ)`
for every growing cofactor and every finite sieve-prime set simultaneously. -/
theorem eventual_cofactor_localProduct_bounds {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (C : ℝ) (hC : 0 ≤ C) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (τ : ℝ) (hτ : 0 < τ) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C),
      ∀ S : Finset ℕ, ∀ M : ℕ, (∀ p ∈ S, 3 ≤ p) → (∀ p ∈ S, p.Prime) →
      (∀ p ∈ S, ¬ p ∣ M) →
      (∏ p ∈ S, LocalSieveProducts.sieveFactor p) ≤
        BuchstabSieve.localProduct S (BuchstabSieve.cofactorDensity M r) ∧
      BuchstabSieve.localProduct S (BuchstabSieve.cofactorDensity M r) ≤
        Real.exp (20 * τ) * ∏ p ∈ S, LocalSieveProducts.sieveFactor p := by
  filter_upwards [eventual_reciprocal_cap I a C hC ha τ hτ] with x hx
  intro ε Y r hr S M hS3 hS hM
  have hrpos := ((mem_boundedCofactors _ _ _ r).mp hr).1
  have hrec : (∑ p ∈ S.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ 2 * τ := by
    apply (reciprocal_prime_divisors_le _ hrpos ?_).trans (hx ε Y r hr)
    intro p hp
    have hh := Finset.mem_filter.mp hp
    exact ⟨hS p hh.1, hh.2⟩
  have hh := BuchstabSieve.cofactor_localProduct_bounds S M r hS3 hS hM hrec
  have heq : 10 * (2 * τ) = 20 * τ := by ring
  rwa [heq] at hh

/-- The two-variable local-factor correction is uniformly at most
`exp(27τ)` for every subset of the cofactor's prime divisors. -/
theorem eventual_semiprime_omitted_product {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (C : ℝ) (hC : 0 ≤ C) (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i)
    (τ : ℝ) (hτ : 0 < τ) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ C),
      ∀ S : Finset ℕ, S ⊆ r.primeFactors → ∀ g : ℕ → ℝ,
      (∀ p ∈ S, g p ≤ 7 / 9) → (∀ p ∈ S, g p ≤ 3 / (p : ℝ)) →
      (∏ p ∈ S, (1 - g p)⁻¹) ≤ Real.exp (27 * τ) := by
  filter_upwards [eventual_reciprocal_cap I a C hC ha τ hτ] with x hx
  intro ε Y r hr S hS g hg hgj
  have hrec : (∑ p ∈ S, 1 / (p : ℝ)) ≤ 2 * τ :=
    (Finset.sum_le_sum_of_subset_of_nonneg hS (fun p _ _ => by positivity)).trans (hx ε Y r hr)
  have hh := SemiprimeSieve.omitted_product_le_exp S (fun p : ℕ => (p : ℝ)) g
    (fun p hp => by exact_mod_cast (Nat.prime_of_mem_primeFactors (hS hp)).pos)
    hg hgj hrec
  have heq : (27 / 2 : ℝ) * (2 * τ) = 27 * τ := by ring
  rwa [heq] at hh

/-- The same cap holds over the full ambient range `r ≤ 2x`, so it can be
used before imposing any of the smaller cofactor truncations. -/
theorem eventual_reciprocal_cap_two_mul {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ha : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i) (τ : ℝ) (hτ : 0 < τ) :
    ∀ᶠ x : ℝ in atTop, ∀ ε Y : ℝ, ∀ r ∈
      boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x),
      (∑ p ∈ r.primeFactors, 1 / (p : ℝ)) ≤ 2 * τ := by
  filter_upwards [eventual_reciprocal_cap I a 2 (by norm_num) ha τ hτ,
    eventually_ge_atTop (2 : ℝ)] with x hx hx2
  intro ε Y r hr
  apply hx ε Y r
  have hbound : 2 * x ≤ x ^ (2 : ℝ) := by
    rw [Real.rpow_two]
    nlinarith
  exact WeightSupport.marked_boundedCofactors_mono _ _ hbound hr

end Artin.MarkedOmission
