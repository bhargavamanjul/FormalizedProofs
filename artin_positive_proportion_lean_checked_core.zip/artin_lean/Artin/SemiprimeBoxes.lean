module

public import Artin.SemiprimeMR

/-!
# The actual growing dyad family for semiprime replacement

The scales and active indices below are the explicit dyadic cover already
constructed in `DyadicBoxes`.  Their source scale and support hypotheses are
proved here, including boxes at the ends of the cover.
-/

@[expose] public section
open Filter
open scoped BigOperators

namespace Artin.SemiprimeBoxes

open DyadicBoxes MarkedSource SemiprimeMR SemiprimeReplacement RoughCompanion

noncomputable def leftScale (_x : ℝ) (ab : ℤ × ℤ) : ℝ := (2 : ℝ) ^ ab.1
noncomputable def rightScale (_x : ℝ) (ab : ℤ × ℤ) : ℝ := (2 : ℝ) ^ ab.2

def active (κ x : ℝ) (ab : ℤ × ℤ) : Prop := ab ∈ narrowBoxIndices x κ

/-- The natural points in the half-open dyad, represented as the closed
integer interval required by the source theorem. -/
noncomputable def dyadIntegers (H : ℝ) : Finset ℕ :=
  Finset.Icc ⌈H⌉₊ (⌈2 * H⌉₊ - 1)

theorem mem_dyadIntegers {H : ℝ} (hH : 0 < H) (n : ℕ) :
    n ∈ dyadIntegers H ↔ H ≤ (n : ℝ) ∧ (n : ℝ) < 2 * H := by
  have hc : 0 < ⌈2 * H⌉₊ := Nat.ceil_pos.mpr (by positivity)
  simp only [dyadIntegers, Finset.mem_Icc, ← Nat.ceil_le, ← Nat.lt_ceil]
  omega

theorem dyadIntegers_interval {H : ℝ} (hH : 0 < H) :
    IntervalInDyad H (dyadIntegers H) := by
  refine ⟨⌈H⌉₊, ⌈2 * H⌉₊ - 1, rfl, Nat.le_ceil H, ?_⟩
  have hc : 0 < ⌈2 * H⌉₊ := Nat.ceil_pos.mpr (by positivity)
  exact ((Nat.lt_ceil).mp (by omega : ⌈2 * H⌉₊ - 1 < ⌈2 * H⌉₊)).le

/-- All boxes in the explicit index set, including unused boundary boxes,
have factor scales in fixed enlarged bounds. -/
theorem narrow_scale_bounds {x κ : ℝ} {ab : ℤ × ℤ} (hx : 1 ≤ x)
    (hκ : κ ≤ (1 : ℝ) / 100) (hab : ab ∈ narrowBoxIndices x κ) :
    x ^ (49 / 100 : ℝ) / 2 ≤ leftScale x ab ∧
    leftScale x ab ≤ 2 * x ^ (51 / 100 : ℝ) ∧
    x ^ (49 / 100 : ℝ) / 8 ≤ rightScale x ab ∧
    rightScale x ab ≤ 4 * x ^ (51 / 100 : ℝ) := by
  have hx0 : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have hm0 : 0 < leftScale x ab := zpow_pos (by norm_num) _
  have hn0 : 0 < rightScale x ab := zpow_pos (by norm_num) _
  have h49 : 0 < x ^ (49 / 100 : ℝ) := Real.rpow_pos_of_pos hx0 _
  have h51 : 0 < x ^ (51 / 100 : ℝ) := Real.rpow_pos_of_pos hx0 _
  have hproduct : x ^ (49 / 100 : ℝ) * x ^ (51 / 100 : ℝ) = x := by
    rw [← Real.rpow_add hx0]
    norm_num
  have hindices := (mem_boxIndices.mp hab)
  have hL := dyadicIndex_inBin (Real.rpow_pos_of_pos hx0 ((1 : ℝ) / 2 - κ))
  have hU := dyadicIndex_inBin (show 0 < 2 * x ^ ((1 : ℝ) / 2 + κ) by positivity)
  have hlo : x ^ (49 / 100 : ℝ) / 2 ≤ leftScale x ab := by
    have hp := Real.rpow_le_rpow_of_exponent_le hx
      (by linarith : (49 / 100 : ℝ) ≤ 1 / 2 - κ)
    have hh := (bin_endpoint_bounds hL).1
    have hz : (2 : ℝ) ^ dyadicIndex (x ^ ((1 : ℝ) / 2 - κ)) ≤ leftScale x ab :=
      zpow_le_zpow_right₀ (by norm_num) hindices.1
    linarith
  have hhi : leftScale x ab ≤ 2 * x ^ (51 / 100 : ℝ) := by
    have hp := Real.rpow_le_rpow_of_exponent_le hx
      (by linarith : (1 : ℝ) / 2 + κ ≤ 51 / 100)
    have hz : leftScale x ab ≤
        (2 : ℝ) ^ dyadicIndex (2 * x ^ ((1 : ℝ) / 2 + κ)) :=
      zpow_le_zpow_right₀ (by norm_num) hindices.2.1
    exact hz.trans (hU.1.trans (by linarith))
  have harea := narrowBoxIndices_product_bounds hx0 hab
  change x / 4 ≤ leftScale x ab * rightScale x ab ∧
    leftScale x ab * rightScale x ab ≤ 2 * x at harea
  refine ⟨hlo, hhi, ?_, ?_⟩
  · have hh := mul_le_mul_of_nonneg_right hhi hn0.le
    nlinarith [harea.1]
  · have hh := mul_le_mul_of_nonneg_right hlo hn0.le
    nlinarith [harea.2]

/-- A single threshold works for every active box in the actual growing
cover.  Its whole support lies in `[x^0.46,x^0.54]`. -/
theorem narrow_factorWindow {κ : ℝ} (hκ : κ ≤ (1 : ℝ) / 100) :
    FactorWindow leftScale rightScale (active κ) := by
  have hg := (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 3 / 100)).eventually_ge_atTop 8
  filter_upwards [hg, eventually_ge_atTop (1 : ℝ)] with x hxlarge hx ab hab
  have hx0 : 0 < x := lt_of_lt_of_le zero_lt_one hx
  obtain ⟨hmlo, hmhi, hnlo, hnhi⟩ := narrow_scale_bounds hx hκ hab
  have h46 : 0 < x ^ (46 / 100 : ℝ) := Real.rpow_pos_of_pos hx0 _
  have h51 : 0 < x ^ (51 / 100 : ℝ) := Real.rpow_pos_of_pos hx0 _
  have h49 : x ^ (49 / 100 : ℝ) =
      x ^ (46 / 100 : ℝ) * x ^ (3 / 100 : ℝ) := by
    rw [← Real.rpow_add hx0]
    norm_num
  have h54 : x ^ (54 / 100 : ℝ) =
      x ^ (51 / 100 : ℝ) * x ^ (3 / 100 : ℝ) := by
    rw [← Real.rpow_add hx0]
    norm_num
  have hlarge46 := mul_le_mul_of_nonneg_left hxlarge h46.le
  have hlarge51 := mul_le_mul_of_nonneg_left hxlarge h51.le
  rw [h49] at hmlo hnlo
  rw [h54]
  exact ⟨by nlinarith, by nlinarith, by nlinarith, by nlinarith⟩

/-- The exact source scale hypotheses for the growing explicit cover. -/
theorem narrow_scaleFamily {κ : ℝ} (hκ : κ ≤ (1 : ℝ) / 100) :
    ScaleFamily (46 / 100) (1 / 4) 2 leftScale rightScale (active κ) := by
  filter_upwards [narrow_factorWindow hκ, eventually_ge_atTop (1 : ℝ)]
    with x hw hx ab hab
  have hp : 1 ≤ x ^ (46 / 100 : ℝ) := Real.one_le_rpow hx (by norm_num)
  obtain ⟨hm, _, hn, _⟩ := hw ab hab
  have ha := narrowBoxIndices_product_bounds (lt_of_lt_of_le zero_lt_one hx) hab
  exact ⟨hp.trans hm, hp.trans hn, hm, hn, by simpa [leftScale, rightScale, div_eq_mul_inv,
    mul_comm] using ha.1, ha.2⟩

/-- The two literal errors for the actual half-open boxes.  The number of
marks is chosen even before the narrow-strip parameter `κ`. -/
theorem narrow_two_errors_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hMertens : ClassicalMertensLower)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨ : SmoothCompactWeight (fun y => (Ψ y : ℂ))) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ κ : ℝ, κ ≤ (1 : ℝ) / 100 →
      ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ ab ∈ narrowBoxIndices x κ,
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
          |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
            (actualWeight b M u Ψ x c allowed Qmin)
            (fun m => primeIndicator m - primeModel x m) primeIndicator| ≤
            C * x * (Real.log x) ^ (-6 : ℝ) ∧
          |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
            (actualWeight b M u Ψ x c allowed Qmin)
            (primeModel x) (fun n => primeIndicator n - primeModel x n)| ≤
            C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := two_errors_from_sources h102 h103 hbands hFourier hMertens
    M u hu hunit Ψ hΨ (46 / 100) (1 / 4) 2 (by norm_num) (by norm_num) (by norm_num)
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b κ hκ
  obtain ⟨C, hC, he⟩ := hK K hKK b (ℤ × ℤ) leftScale rightScale (active κ)
    (narrow_scaleFamily hκ) (narrow_factorWindow hκ)
  refine ⟨C, hC, ?_⟩
  filter_upwards [he] with x hx ab hab c allowed Qmin
  exact hx ab hab _ _ (dyadIntegers_interval (zpow_pos (by norm_num) _))
    (dyadIntegers_interval (zpow_pos (by norm_num) _)) c allowed Qmin

/-- Nonnegativity of the actual weight needs only nonnegativity of the
fixed smooth bump; no pointwise marking bound enters the main term. -/
theorem actualWeight_nonneg {K : ℕ} (b : Bands K) (M u : ℕ) (Ψ : ℝ → ℝ)
    (hΨ : ∀ y, 0 ≤ Ψ y) (x : ℝ) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (d : ℕ) :
    0 ≤ actualWeight b M u Ψ x c allowed Qmin d := by
  have hm : 0 ≤ ConcreteSelector.markingWeight Finset.univ (b.group x) (b.mass x) (d - 1) := by
    apply Finset.prod_nonneg
    intro i hi
    exact div_nonneg (MarkedWeights.countFactor_nonneg _)
      (Finset.sum_nonneg (fun p _ => inv_nonneg.mpr (Nat.cast_nonneg p)))
  unfold actualWeight ConcreteSelector.arithmeticWeight
  split_ifs
  · exact mul_nonneg (mul_nonneg (hΨ _) (ConcreteSelector.selector_bounds _ _ _ _ _).1) hm
  · exact le_rfl

/-- A rough-pair bound combines with the two proved MR errors on one of
the actual boxes, cancelling the two Mertens factors exactly. -/
theorem prime_box_bound {K M : ℕ} (b : Bands K) (u : ℕ) (Ψ : ℝ → ℝ)
    (hΨ : ∀ y, 0 ≤ Ψ y) {x A X₀ E : ℝ} {ab : ℤ × ℤ}
    (hx : 1 < x)
    (hw : x ^ (46 / 100 : ℝ) ≤ leftScale x ab ∧
      x ^ (46 / 100 : ℝ) ≤ rightScale x ab)
    (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ)
    (hpairs : pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
      (actualWeight b M u Ψ x c allowed Qmin)
      (realRoughIndicator (W x)) (realRoughIndicator (W x)) ≤
      A * X₀ * (eulerV (W x)) ^ 2)
    (he₁ : |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
      (actualWeight b M u Ψ x c allowed Qmin)
      (fun m => primeIndicator m - primeModel x m) primeIndicator| ≤ E)
    (he₂ : |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
      (actualWeight b M u Ψ x c allowed Qmin)
      (primeModel x) (fun n => primeIndicator n - primeModel x n)| ≤ E) :
    pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
      (actualWeight b M u Ψ x c allowed Qmin) primeIndicator primeIndicator ≤
      A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) + 2 * E := by
  have hlog : ∀ H : ℝ, x ^ (46 / 100 : ℝ) ≤ H → 0 < H →
      ∀ n ∈ dyadIntegers H, (46 / 100 : ℝ) * Real.log x ≤ Real.log n := by
    intro H hlo hH n hn
    have hh := Real.log_le_log (Real.rpow_pos_of_pos (by linarith : 0 < x) (46 / 100 : ℝ))
      (hlo.trans ((mem_dyadIntegers hH n).mp hn).1)
    simpa only [Real.log_rpow (by linarith : 0 < x)] using hh
  have h := semiprime_box_after_two_replacements
    (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
    (actualWeight b M u Ψ x c allowed Qmin) primeIndicator (realRoughIndicator (W x))
    (eulerV_pos _) (Real.log_pos hx) (by norm_num : (0 : ℝ) < 46 / 100)
    (fun m hm n hn => actualWeight_nonneg b M u Ψ hΨ x c allowed Qmin _)
    (realRoughIndicator_nonneg _)
    (hlog _ hw.1 (zpow_pos (by norm_num) _))
    (hlog _ hw.2 (zpow_pos (by norm_num) _)) hpairs he₁ he₂
  convert h using 1; ring

/-- The actual sum over the finite dyadic cover.  Repeated representations
may only enlarge this quantity, including when the integer is a prime square. -/
noncomputable def primeCoverMass (x κ : ℝ) (w : ℕ → ℝ) : ℝ :=
  ∑ ab ∈ narrowBoxIndices x κ,
    pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
      w primeIndicator primeIndicator

/-- Sum the one-box upper bounds over the explicitly constructed cover. -/
theorem prime_cover_bound {K M : ℕ} (b : Bands K) (u : ℕ) (Ψ : ℝ → ℝ)
    (hΨ : ∀ y, 0 ≤ Ψ y) {x κ A X₀ E : ℝ}
    (hx : 1 < x) (hκ : 0 ≤ κ) (hA : 0 ≤ A) (hX₀ : 0 ≤ X₀) (hE : 0 ≤ E)
    (hw : ∀ ab ∈ narrowBoxIndices x κ,
      x ^ (46 / 100 : ℝ) ≤ leftScale x ab ∧
      x ^ (46 / 100 : ℝ) ≤ rightScale x ab)
    (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ)
    (hpairs : ∀ ab ∈ narrowBoxIndices x κ,
      pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
        (actualWeight b M u Ψ x c allowed Qmin)
        (realRoughIndicator (W x)) (realRoughIndicator (W x)) ≤
        A * X₀ * (eulerV (W x)) ^ 2)
    (he : ∀ ab ∈ narrowBoxIndices x κ,
      |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
        (actualWeight b M u Ψ x c allowed Qmin)
        (fun m => primeIndicator m - primeModel x m) primeIndicator| ≤ E ∧
      |pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
        (actualWeight b M u Ψ x c allowed Qmin)
        (primeModel x) (fun n => primeIndicator n - primeModel x n)| ≤ E) :
    primeCoverMass x κ (actualWeight b M u Ψ x c allowed Qmin) ≤
      (6 / Real.log 2 + 9) * (κ * Real.log x + 1) *
        (A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) + 2 * E) := by
  have hone : ∀ ab ∈ narrowBoxIndices x κ,
      pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
        (actualWeight b M u Ψ x c allowed Qmin) primeIndicator primeIndicator ≤
        A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) + 2 * E := by
    intro ab hab
    exact prime_box_bound b u Ψ hΨ hx (hw ab hab) c allowed Qmin
      (hpairs ab hab) (he ab hab).1 (he ab hab).2
  calc
    primeCoverMass x κ (actualWeight b M u Ψ x c allowed Qmin) ≤
        ((narrowBoxIndices x κ).card : ℝ) *
          (A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) + 2 * E) := by
      simpa only [primeCoverMass, Finset.sum_const, nsmul_eq_mul] using Finset.sum_le_sum hone
    _ ≤ _ := mul_le_mul_of_nonneg_right (narrowBoxIndices_card_le_constant hx.le hκ)
      (by positivity)

/-- The concrete summed MR conclusion.  The sole remaining estimate supplied
to this theorem is the separately proved rough-pair sieve bound; neither
replacement error nor a dyadic-cover hypothesis is assumed. -/
theorem narrow_prime_cover_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hMertens : ClassicalMertensLower)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨ : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ0 : ∀ y, 0 ≤ Ψ y) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ κ : ℝ, 0 ≤ κ → κ ≤ (1 : ℝ) / 100 →
      ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
        ∀ A X₀ : ℝ, 0 ≤ A → 0 ≤ X₀ →
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        (∀ ab ∈ narrowBoxIndices x κ,
          pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
            (actualWeight b M u Ψ x c allowed Qmin)
            (realRoughIndicator (W x)) (realRoughIndicator (W x)) ≤
            A * X₀ * (eulerV (W x)) ^ 2) →
        primeCoverMass x κ (actualWeight b M u Ψ x c allowed Qmin) ≤
          (6 / Real.log 2 + 9) * (κ * Real.log x + 1) *
            (A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) +
              2 * C * x * (Real.log x) ^ (-6 : ℝ)) := by
  obtain ⟨K₀, hK₀, hK⟩ := narrow_two_errors_from_sources h102 h103 hbands hFourier
    hMertens M u hu hunit Ψ hΨ
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b κ hκ0 hκ
  obtain ⟨C, hC, he⟩ := hK K hKK b κ hκ
  refine ⟨C, hC, ?_⟩
  filter_upwards [he, narrow_factorWindow hκ, eventually_gt_atTop (1 : ℝ)]
    with x hex hw hx
  intro A X₀ hA hX₀ c allowed Qmin hpairs
  have h := prime_cover_bound b u Ψ hΨ0 hx hκ0 hA hX₀
    (by positivity [Real.log_pos hx] : 0 ≤ C * x * (Real.log x) ^ (-6 : ℝ))
    (fun ab hab => ⟨(hw ab hab).1, (hw ab hab).2.2.1⟩)
    c allowed Qmin hpairs (fun ab hab => hex ab hab c allowed Qmin)
  convert h using 1; ring

end Artin.SemiprimeBoxes
