module

public import Artin.ManuscriptRoughBin
public import Artin.BuchstabParameters
public import Artin.BuchstabFiniteCover

/-!
# The original rough-mass lower estimate, derived from the accepted sources

The cutoff, local tolerance, finite density partition, and common marking
threshold are chosen before the cofactor parameters.  The initial lower
sieve and every normalized bin estimate concern the literal manuscript
weight.  The least-prime cover then gives the required positive margin.
-/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace Artin.ManuscriptRough

open MarkedSource MarkedBandTail MarkedCofactorEstimate ManuscriptDistribution
  ManuscriptMass ManuscriptCover InitialSieve ClassicalSieveNormalization
  BuchstabPartition BuchstabRoughReduction BuchstabParameters

/-- The full rough lower estimate with all original analytic steps proved.
Only the cited replacement and block-sieve statements and the explicitly
listed classical prime and Buchstab facts enter as hypotheses. -/
theorem actual_rough_lower_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (source : BuchstabSieve.SourceLemma11_1)
    (hbands : ClassicalBandMass) (hbandUpper : ManuscriptSemiprime.ClassicalBandUpperMass)
    (hFourier : ClassicalFourierInversion) (hcontinuity : BuchstabMR.ClassicalDensityContinuity)
    (facts : ClassicalBuchstabFacts) (rapid : ClassicalBuchstabRapid)
    (C₀ : ℝ) (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    (hEuler : ClassicalEulerMertens) (hPrime : ClassicalShiftedPrimeMertens)
    {c M₀ v : ℕ} [NeZero M₀] (hc : c = 2 ∨ c = 4)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {S_M κ : ℝ} (hLocal : MertensLocalSource (c * M₀) S_M)
    (hκ : 0 < κ) (hκsmall : κ < 1 / 100) :
    ∃ τ ε₀ : ℝ, 0 < τ ∧ τ < 1 / 100 ∧ 0 < ε₀ ∧ ε₀ ≤ κ ∧ ε₀ < 1 / 100 ∧
      ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ bands : Bands K,
      ∀ ε : ℝ, 0 < ε → ε < ε₀ → ∀ Y : ℝ, (M₀ : ℝ) ≤ Y →
      ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧ ∀ᶠ x : ℝ in atTop,
        ((3 : ℝ) / 4 * S_M - e x) *
          (baseMass Finset.univ bands.exponent c (c * M₀) (c * v + 1) ε Y τ x /
            Real.log x) ≤
          ManuscriptCover.roughMass Finset.univ bands.exponent
            c (c * M₀) (c * v + 1) ε Y τ κ x := by
  classical
  have hc2 : 2 ≤ c := by rcases hc with rfl | rfl <;> norm_num
  have hM2 : 2 ∣ c * M₀ :=
    dvd_mul_of_dvd_left (by rcases hc with rfl | rfl <;> norm_num) _
  let : NeZero (c * M₀) := ⟨(Nat.mul_pos (by omega) (NeZero.pos M₀)).ne'⟩
  obtain ⟨C_s, b₀, _hCs, hb₀, _hb₀small, hinitial⟩ :=
    actual_initial_lower_normalized_uniform source C₀ hBlock
  obtain ⟨b, τ, hb, hbb₀, hbsmall, _hbwidth, hτ, hτsmall, ⟨P⟩, hmargin⟩ :=
    exists_fixed_parameters facts rapid C_s hb₀ hκ hκsmall
  obtain ⟨K₀, hK₀, hbins⟩ := partition_bin_estimates_from_sources
    h102 h103 hbands hFourier hcontinuity (c * M₀) (c * v + 1) hu
    ((ZMod.isUnit_iff_coprime _ _).mpr huM) PositiveBump.weight
    PositiveBump.weight_marked_source
    (fun y => ⟨PositiveBump.weight_nonneg y, PositiveBump.weight_le_one y⟩)
    (fun _ hy => PositiveBump.weight_eq_zero_of_not_mem_Icc hy) hb hκ P
  refine ⟨τ, min b κ, hτ, hτsmall, lt_min hb hκ, min_le_right _ _,
    (min_le_left _ _).trans_lt hbsmall, K₀, hK₀, ?_⟩
  intro K hK bands ε hε hεsmall Y hY
  have hεb : ε < b := hεsmall.trans_le (min_le_left _ _)
  have hεκ : ε < κ := hεsmall.trans_le (min_le_right _ _)
  have hv₀ : 0 < Real.log 2 / 2 := by positivity
  have hclassical := ManuscriptSemiprime.classical_band_bounds hbands hbandUpper bands
  have ha := ManuscriptSemiprime.band_exponent_bounds bands
  have hinj := ManuscriptSemiprime.band_exponent_injective bands
  obtain ⟨e₀, he₀, hinitial'⟩ := hinitial b hb hbb₀ hBV hPNT hTot
    hc2 hu hv huM hε hεκ hκsmall S_M hLocal
  have hi := hinitial' Finset.univ bands.exponent (1/10) (1/5)
    (2 * Real.log 2) (Real.log 2 / 2) (by norm_num) (by norm_num) hv₀
    ha hinj hclassical Y hY τ hτ
  let X := fun x => baseMass Finset.univ bands.exponent c (c * M₀) (c * v + 1) ε Y τ x
  let mass := fun x => S_M * X x / Real.log x
  let initial := fun x => SiftedSupport.siftedBaseMass Finset.univ bands.exponent
    c (c * M₀) (c * v + 1) ε Y τ x (sievePrimes (c * M₀) (x ^ b))
  let rough := fun x => ManuscriptCover.roughMass Finset.univ bands.exponent
    c (c * M₀) (c * v + 1) ε Y τ κ x
  let bins := fun (i : Fin P.bins) (x : ℝ) => factorBinMass ⌊2 * x⌋₊
    (integerWeight Finset.univ bands.exponent c (c * M₀) (c * v + 1) ε Y τ x)
    (x ^ P.endpoint i) (x ^ P.endpoint (i.val + 1))
  let coeff := fun i : Fin P.bins =>
    P.coefficient i * Real.log (P.endpoint (i.val + 1) / P.endpoint i)
  let B := Real.exp (-Real.eulerMascheroniConstant) / b *
    (1 - C_s * Real.exp (-(1 / 20 : ℝ) / b))
  have hbin : ∀ i : Fin P.bins, ∃ e : ℝ → ℝ,
      Tendsto e atTop (𝓝 0) ∧ ∀ᶠ x : ℝ in atTop,
        bins i x ≤ (Real.exp (20 * τ) * coeff i + e x) * mass x := by
    intro i
    have hbg : b ≤ P.endpoint i := by
      simpa only [P.endpoint_zero] using P.increasing.monotone (Nat.zero_le i.val)
    have hγγ' : P.endpoint i < P.endpoint (i.val + 1) :=
      P.increasing (Nat.lt_succ_self i.val)
    have hγ' : P.endpoint (i.val + 1) ≤ 1 / 2 - κ := by
      simpa only [P.endpoint_last] using P.increasing.monotone (Nat.succ_le_of_lt i.isLt)
    obtain ⟨e, _henonneg, he, hbound⟩ := ManuscriptRoughBin.actual_bin_normalized
      source C₀ hBlock hBV hPNT hTot hbands hbandUpper hc2 hu hv huM
      hε hεκ hκsmall (hεb.trans_le hbg) hγγ' hγ' hτ hLocal hEuler hPrime
      bands (P.coefficient_nonnegative i i.isLt) (hbins K hK bands i) Y hY
    refine ⟨e, he, ?_⟩
    simpa only [bins, coeff, mass, X, mul_assoc] using hbound
  choose errors herrors herrbound using hbin
  have hcoeff : ∑ i : Fin P.bins, coeff i ≤ density b 1 - 1 + 1 / 20 := by
    calc
      _ = ∑ i ∈ Finset.range P.bins,
          P.coefficient i * Real.log (P.endpoint (i + 1) / P.endpoint i) :=
        Fin.sum_univ_eq_sum_range _ _
      _ ≤ _ := P.total_bound
  have hmargin' : (3 : ℝ) / 4 ≤ B - Real.exp (20 * τ) * ∑ i : Fin P.bins, coeff i := by
    have hh := mul_le_mul_of_nonneg_left hcoeff (Real.exp_pos (20 * τ)).le
    dsimp [B]
    linarith
  have hmass : ∀ᶠ x : ℝ in atTop, 0 ≤ mass x := by
    filter_upwards [hclassical, eventually_gt_atTop (1 : ℝ)] with x hx hx1
    have hV : ∀ i ∈ (Finset.univ : Finset (Fin K)), 0 < bandMass (bands.exponent i) x :=
      fun i hi => hv₀.trans_le (hx i hi).1
    have hX := baseMass_nonneg Finset.univ bands.exponent
      c (c * M₀) (c * v + 1) ε Y τ x hV
    exact div_nonneg (mul_nonneg hLocal.1.le hX) (Real.log_pos hx1).le
  have hi' : ∀ᶠ x : ℝ in atTop, (B + e₀ x) * mass x ≤ initial x := by
    filter_upwards [hi] with x hx
    change mass x * (B + e₀ x) ≤ initial x at hx
    rwa [mul_comm] at hx
  have hc' : ∀ᶠ x : ℝ in atTop, initial x ≤ rough x + ∑ i : Fin P.bins, bins i x :=
    BuchstabFiniteCover.actual_finite_cover hbands bands
      c (c * M₀) (c * v + 1) ε Y τ hM2 huM P
  obtain ⟨e, he, hrough⟩ := finite_subtraction_with_margin Finset.univ
    mass initial rough e₀ bins errors coeff hmargin' he₀
    (fun i _ => herrors i) hmass hi' (fun i _ => herrbound i) hc'
  refine ⟨fun x => -S_M * e x, ?_, ?_⟩
  · simpa only [mul_zero] using tendsto_const_nhds.mul he
  · filter_upwards [hrough] with x hx
    convert hx using 1
    dsimp [mass, X, rough]
    ring

end Artin.ManuscriptRough
