module

public import Artin.Cofactor
public import Artin.CandidateSieve
public import Artin.SieveDistribution
public import Artin.LocalSieveProducts
public import Mathlib.Data.Nat.GCD.BigOperators
public import Mathlib.Data.Nat.Totient

/-!
# The block-sieve source and its concrete cofactor application

`SourceLemma11_1` is the finite weighted block sieve in the cited paper. Its
constants are chosen using only the local gap and the block-sum bound, before
any cofactor, marking weight, array or depth. Everything after that declaration
is a proved application. The remainder is indexed by actual squarefree product
moduli, with no multiplicity or divisor-function loss.
-/

@[expose] public section
open scoped BigOperators
namespace Artin.BuchstabSieve

noncomputable def intersectionMass (A : Finset ℕ) (w : ℕ → ℝ)
    (bad : ℕ → ℕ → Prop) (S : Finset ℕ) : ℝ := by
  classical
  exact ∑ a ∈ A.filter (fun a => ∀ p ∈ S, bad p a), w a

noncomputable def siftedMass (A : Finset ℕ) (w : ℕ → ℝ)
    (bad : ℕ → ℕ → Prop) (P : Finset ℕ) : ℝ := by
  classical
  exact ∑ a ∈ A.filter (fun a => ∀ p ∈ P, ¬ bad p a), w a

noncomputable def localProduct (P : Finset ℕ) (g : ℕ → ℝ) : ℝ :=
  ∏ p ∈ P, (1 - g p)

noncomputable def remainderSubsets (P : Finset ℕ) (D : ℝ) : Finset (Finset ℕ) := by
  classical
  exact P.powerset.filter (fun S => ((∏ p ∈ S, p : ℕ) : ℝ) ≤ D)

noncomputable def blockRemainder (A : Finset ℕ) (w : ℕ → ℝ)
    (bad : ℕ → ℕ → Prop) (P : Finset ℕ) (g : ℕ → ℝ) (X D : ℝ) : ℝ :=
  ∑ S ∈ remainderSubsets P D,
    |intersectionMass A w bad S - X * ∏ p ∈ S, g p|

/-- The local hypotheses in source (11.1). They concern only primes in `P`. -/
def LocalConditions (P : Finset ℕ) (g : ℕ → ℝ) (η C₀ : ℝ) : Prop :=
  (∀ p ∈ P, 0 ≤ g p ∧ g p ≤ 1 - η) ∧
  ∀ v : ℝ, 1 < v → (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2), g p) ≤ C₀

/-- Exactly the two conclusions of cited Lemma 11.1, with the harmless choice
of one common positive constant for its two error bounds. Products of distinct
primes index the intersections, so multiplicativity is built in. -/
def SourceLemma11_1 : Prop :=
  ∀ η C₀ : ℝ, 0 < η → ∃ C : ℝ, 0 < C ∧ ∃ H₀ : ℕ,
    ∀ (A P : Finset ℕ) (w : ℕ → ℝ) (bad : ℕ → ℕ → Prop)
      (g : ℕ → ℝ) (X z : ℝ),
      (∀ a ∈ A, 0 ≤ w a) → 0 ≤ X → 2 ≤ z →
      (∀ p ∈ P, p.Prime ∧ (p : ℝ) ≤ z) → LocalConditions P g η C₀ →
      (∀ H : ℕ, Even H → H₀ ≤ H →
        |siftedMass A w bad P - X * localProduct P g| ≤
          C * Real.exp (-(H : ℝ)) * (X * localProduct P g) +
          C * blockRemainder A w bad P g X (z ^ (4 * H + 2))) ∧
      siftedMass A w bad P ≤ C * (X * localProduct P g) +
        C * blockRemainder A w bad P g X (z ^ (10 : ℕ))

/-- All conditions on a finite set of distinct primes are equivalent to the
single product divisibility condition. -/
theorem prime_product_dvd_iff (S : Finset ℕ) (hS : ∀ p ∈ S, p.Prime) (n : ℕ) :
    (∏ p ∈ S, p) ∣ n ↔ ∀ p ∈ S, p ∣ n := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | @insert p S hp ih =>
    have hpP := hS p (Finset.mem_insert_self p S)
    have hSP : ∀ q ∈ S, q.Prime := fun q hq => hS q (Finset.mem_insert_of_mem hq)
    have hcop : p.Coprime (∏ q ∈ S, q) := by
      apply Nat.Coprime.prod_right
      intro q hq
      exact (Nat.coprime_primes hpP (hSP q hq)).2 (by intro he; exact hp (he ▸ hq))
    rw [Finset.prod_insert hp]
    constructor
    · intro h q hq
      rcases Finset.mem_insert.mp hq with rfl | hq
      · exact dvd_trans (dvd_mul_right _ _) h
      · exact (ih hSP).mp (dvd_trans (dvd_mul_left _ _) h) q hq
    · intro h
      exact hcop.mul_dvd_of_dvd_of_dvd (h p (Finset.mem_insert_self _ _))
        ((ih hSP).mpr (fun q hq => h q (Finset.mem_insert_of_mem hq)))

noncomputable def divisorMass (A : Finset ℕ) (w : ℕ → ℝ)
    (f : ℕ → ℕ) (d : ℕ) : ℝ :=
  ∑ a ∈ A.filter (fun a => d ∣ f a), w a

theorem intersectionMass_eq_divisorMass (A S : Finset ℕ) (w : ℕ → ℝ)
    (f : ℕ → ℕ) (hS : ∀ p ∈ S, p.Prime) :
    intersectionMass A w (fun p a => p ∣ f a) S =
      divisorMass A w f (∏ p ∈ S, p) := by
  classical
  unfold intersectionMass divisorMass
  congr 1
  ext a
  simp only [Finset.mem_filter, prime_product_dvd_iff S hS]

/-- Injectivity removes all multiplicities when one reindexes the source
remainder by its squarefree product modulus. -/
theorem subset_error_sum_le (P moduli : Finset ℕ) (D : ℝ) (error : ℕ → ℝ)
    (hP : ∀ p ∈ P, p.Prime)
    (hmoduli : ∀ S ∈ remainderSubsets P D, (∏ p ∈ S, p) ∈ moduli) :
    (∑ S ∈ remainderSubsets P D, |error (∏ p ∈ S, p)|) ≤
      ∑ d ∈ moduli, |error d| := by
  apply Finset.sum_le_sum_of_injOn (fun S : Finset ℕ => ∏ p ∈ S, p)
  · intro S hS T hT he
    exact Cofactor.prime_subset_product_injective P hP
      (Finset.mem_filter.mp hS).1 (Finset.mem_filter.mp hT).1 he
  · intro d hd
    obtain ⟨S, hS, rfl⟩ := Finset.mem_image.mp hd
    exact hmoduli S hS
  · intro S _
    exact le_rfl
  · intro d _ _
    exact abs_nonneg _

/-- The actual cofactor local density at a prime. -/
noncomputable def cofactorDensity (M r p : ℕ) : ℝ :=
  if p ∣ M * r then 0 else 1 / ((p : ℝ) - 1)

/-- The fixed gap `η = 1/2` is valid at every odd sieving prime and every
cofactor. In particular it is independent of the number of marks. -/
theorem cofactorDensity_bounds (M r p : ℕ) (hp : 3 ≤ p) :
    0 ≤ cofactorDensity M r p ∧ cofactorDensity M r p ≤ 1 - (1/2 : ℝ) := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  unfold cofactorDensity
  split_ifs
  · norm_num
  · have hden : 0 < (p : ℝ) - 1 := by linarith
    constructor
    · positivity
    · apply (div_le_iff₀ hden).2
      linarith

/-- A single classical reciprocal-prime block estimate suffices for all
cofactors simultaneously; deleting local densities can only decrease a sum. -/
theorem cofactorDensity_localConditions (P : Finset ℕ) (M r : ℕ) (C₀ : ℝ)
    (hP : ∀ p ∈ P, 3 ≤ p)
    (hblock : ∀ v : ℝ, 1 < v →
      (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
        1 / ((p : ℝ) - 1)) ≤ C₀) :
    LocalConditions P (cofactorDensity M r) (1/2) C₀ := by
  refine ⟨fun p hp => cofactorDensity_bounds M r p (hP p hp), ?_⟩
  intro v hv
  refine (Finset.sum_le_sum (fun p hp => ?_)).trans (hblock v hv)
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hP p (Finset.mem_filter.mp hp).1
  have hden : 0 < (p : ℝ) - 1 := by linarith
  unfold cofactorDensity
  split_ifs
  · positivity
  · exact le_rfl

/-- The local product is exactly the ordinary product with the primes
already dividing `M*r` removed. -/
theorem cofactor_localProduct (P : Finset ℕ) (M r : ℕ) :
    localProduct P (cofactorDensity M r) =
      ∏ p ∈ P.filter (fun p => ¬ p ∣ M * r), LocalSieveProducts.sieveFactor p := by
  classical
  unfold localProduct cofactorDensity LocalSieveProducts.sieveFactor
  rw [Finset.prod_filter]
  apply Finset.prod_congr rfl
  intro p hp
  split_ifs <;> simp_all

/-- The manuscript's local-product comparison, with no mark-dependent
constant: only the reciprocal sum of omitted cofactor primes occurs. -/
theorem cofactor_localProduct_bounds (P : Finset ℕ) (M r : ℕ) {τ : ℝ}
    (hP : ∀ p ∈ P, 3 ≤ p)
    (hprime : ∀ p ∈ P, p.Prime)
    (hM : ∀ p ∈ P, ¬ p ∣ M)
    (htail : (∑ p ∈ P.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ τ) :
    (∏ p ∈ P, LocalSieveProducts.sieveFactor p) ≤ localProduct P (cofactorDensity M r) ∧
    localProduct P (cofactorDensity M r) ≤
      Real.exp (10 * τ) * ∏ p ∈ P, LocalSieveProducts.sieveFactor p := by
  classical
  have hset : P.filter (fun p => ¬ p ∣ M * r) = P \ P.filter (fun p => p ∣ r) := by
    ext p
    simp only [Finset.mem_filter, Finset.mem_sdiff]
    constructor
    · rintro ⟨hp, hn⟩
      exact ⟨hp, fun hr => hn (dvd_mul_of_dvd_right hr.2 _)⟩
    · rintro ⟨hp, hn⟩
      refine ⟨hp, ?_⟩
      intro hd
      rcases (hprime p hp).dvd_mul.mp hd with hm | hr
      · exact hM p hp hm
      · exact hn ⟨hp, hr⟩
  rw [cofactor_localProduct, hset]
  exact ⟨(LocalSieveProducts.omitted_product_bounds P _ (Finset.filter_subset _ _) hP).1,
    LocalSieveProducts.omitted_product_le_of_reciprocal_mass P _
      (Finset.filter_subset _ _) hP htail⟩



/-- Summing the block estimate over cofactors preserves its universal
constants. This is where the lower local bound is used for the initial sieve
and the upper local bound for each conditioned upper sieve. -/
theorem weighted_block_bounds (R : Finset ℕ) (t X S V E : ℕ → ℝ)
    {C ρ V₀ T : ℝ} (hC : 0 ≤ C) (hρ : 0 ≤ ρ) (hsmall : C * ρ ≤ 1)
    (ht : ∀ r ∈ R, 0 ≤ t r) (hX : ∀ r ∈ R, 0 ≤ X r)
    (hlower : ∀ r ∈ R, V₀ ≤ V r) (hupper : ∀ r ∈ R, V r ≤ T * V₀)
    (hsieve : ∀ r ∈ R, |S r - X r * V r| ≤ C * ρ * (X r * V r) + C * E r) :
    (1 - C * ρ) * V₀ * (∑ r ∈ R, t r * X r) - C * (∑ r ∈ R, t r * E r) ≤
      ∑ r ∈ R, t r * S r ∧
    (∑ r ∈ R, t r * S r) ≤
      (1 + C * ρ) * T * V₀ * (∑ r ∈ R, t r * X r) + C * (∑ r ∈ R, t r * E r) := by
  have hlow : ∀ r ∈ R, (1 - C * ρ) * V₀ * X r - C * E r ≤ S r := by
    intro r hr
    have hh := (abs_le.mp (hsieve r hr)).1
    have hv := mul_le_mul_of_nonneg_left (hlower r hr) (hX r hr)
    have hv' := mul_le_mul_of_nonneg_left hv (sub_nonneg.mpr hsmall)
    nlinarith only [hh, hv']
  have hupp : ∀ r ∈ R, S r ≤ (1 + C * ρ) * T * V₀ * X r + C * E r := by
    intro r hr
    have hh := (abs_le.mp (hsieve r hr)).2
    have hv := mul_le_mul_of_nonneg_left (hupper r hr) (hX r hr)
    have hv' := mul_le_mul_of_nonneg_left hv (by positivity : 0 ≤ 1 + C * ρ)
    nlinarith only [hh, hv']
  constructor
  · calc
      _ = ∑ r ∈ R, t r * ((1 - C * ρ) * V₀ * X r - C * E r) := by
        simp_rw [mul_sub, Finset.sum_sub_distrib, Finset.mul_sum]
        congr 1 <;> apply Finset.sum_congr rfl <;> intros <;> ring
      _ ≤ _ := Finset.sum_le_sum (fun r hr => mul_le_mul_of_nonneg_left (hlow r hr) (ht r hr))
  · calc
      _ ≤ ∑ r ∈ R, t r * ((1 + C * ρ) * T * V₀ * X r + C * E r) :=
        Finset.sum_le_sum (fun r hr => mul_le_mul_of_nonneg_left (hupp r hr) (ht r hr))
      _ = _ := by
        simp_rw [mul_add, Finset.sum_add_distrib, Finset.mul_sum]
        congr 1 <;> apply Finset.sum_congr rfl <;> intros <;> ring

/-- The accepted block theorem gives one pair of constants for *all* actual
predecessor arrays and all marking weights. The constants are selected before
`M`, `c`, the prime set and the cofactor family, hence cannot depend on `K`.
The only distribution errors used are the concrete intersection errors. -/
theorem source_weighted_cofactor_bounds (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧ ∃ H₀ : ℕ,
    ∀ (R P : Finset ℕ) (M c : ℕ) (A : ℕ → Finset ℕ)
      (w : ℕ → ℕ → ℝ) (t X : ℕ → ℝ) (z τ : ℝ) (H : ℕ),
      2 ≤ z → Even H → H₀ ≤ H → C * Real.exp (-(H : ℝ)) ≤ 1 →
      (∀ r ∈ R, 0 ≤ t r) → (∀ r ∈ R, 0 ≤ X r) →
      (∀ r ∈ R, ∀ Q ∈ A r, 0 ≤ w r Q) →
      (∀ p ∈ P, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ z ∧ ¬ p ∣ M) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / ((p : ℝ) - 1)) ≤ C₀) →
      (∀ r ∈ R, (∑ p ∈ P.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ τ) →
      let V₀ := ∏ p ∈ P, LocalSieveProducts.sieveFactor p
      let S := fun r => siftedMass (A r) (w r) (fun p Q => p ∣ c * r * Q + 1) P
      let E := fun r => blockRemainder (A r) (w r) (fun p Q => p ∣ c * r * Q + 1)
        P (cofactorDensity M r) (X r) (z ^ (4 * H + 2))
      ((1 - C * Real.exp (-(H : ℝ))) * V₀ * (∑ r ∈ R, t r * X r) -
          C * (∑ r ∈ R, t r * E r) ≤ ∑ r ∈ R, t r * S r) ∧
      ((∑ r ∈ R, t r * S r) ≤
        (1 + C * Real.exp (-(H : ℝ))) * Real.exp (10 * τ) * V₀ *
          (∑ r ∈ R, t r * X r) + C * (∑ r ∈ R, t r * E r)) := by
  obtain ⟨C, hC, H₀, hsource⟩ := source (1/2) C₀ (by norm_num)
  refine ⟨C, hC, H₀, ?_⟩
  intro R P M c A w t X z τ H hz hH hH₀ hsmall ht hX hw hP hblock hτ
  apply weighted_block_bounds R t X _ (fun r => localProduct P (cofactorDensity M r)) _
    hC.le (Real.exp_nonneg _) hsmall ht hX
  · intro r hr
    exact (cofactor_localProduct_bounds P M r (fun p hp => (hP p hp).2.1)
      (fun p hp => (hP p hp).1) (fun p hp => (hP p hp).2.2.2) (hτ r hr)).1
  · intro r hr
    exact (cofactor_localProduct_bounds P M r (fun p hp => (hP p hp).2.1)
      (fun p hp => (hP p hp).1) (fun p hp => (hP p hp).2.2.2) (hτ r hr)).2
  · intro r hr
    exact (hsource (A r) P (w r) (fun p Q => p ∣ c * r * Q + 1)
      (cofactorDensity M r) (X r) z (hw r hr) (hX r hr) hz
      (fun p hp => ⟨(hP p hp).1, (hP p hp).2.2.1⟩)
      (cofactorDensity_localConditions P M r C₀ (fun p hp => (hP p hp).2.1) hblock)).1 H hH hH₀



/-- Euler's totient on a squarefree prime product, with its real-valued
form suitable for the sieve density. -/
theorem totient_prime_product (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) :
    ((∏ p ∈ P, p).totient : ℝ) = ∏ p ∈ P, ((p : ℝ) - 1) := by
  classical
  induction P using Finset.induction_on with
  | empty => simp
  | @insert p P hp ih =>
    have hpP := hP p (Finset.mem_insert_self _ _)
    have hPP : ∀ q ∈ P, q.Prime := fun q hq => hP q (Finset.mem_insert_of_mem hq)
    have hcop : p.Coprime (∏ q ∈ P, q) := by
      apply Nat.Coprime.prod_right
      intro q hq
      exact (Nat.coprime_primes hpP (hPP q hq)).2 (by intro he; exact hp (he ▸ hq))
    rw [Finset.prod_insert hp, Nat.totient_mul hcop, Nat.cast_mul,
      Nat.totient_prime hpP, Nat.cast_sub hpP.one_le, Nat.cast_one,
      Finset.prod_insert hp, ih hPP]

noncomputable def productDensity (M r d : ℕ) : ℝ :=
  if d.Coprime (M * r) then 1 / (d.totient : ℝ) else 0

/-- The prime-level local factors multiply to exactly the manuscript's
`1_{(d,Mr)=1}/φ(d)`, not an independent formal density variable. -/
theorem cofactorDensity_product (P : Finset ℕ) (M r : ℕ)
    (hP : ∀ p ∈ P, p.Prime) :
    (∏ p ∈ P, cofactorDensity M r p) = productDensity M r (∏ p ∈ P, p) := by
  classical
  unfold productDensity
  by_cases hc : (∏ p ∈ P, p).Coprime (M * r)
  · rw [ite_eq_left hc]
    have hn : ∀ p ∈ P, ¬ p ∣ M * r := by
      intro p hp
      exact (hP p hp).coprime_iff_not_dvd.mp ((Nat.coprime_prod_left_iff.mp hc) p hp)
    calc
      (∏ p ∈ P, cofactorDensity M r p) = ∏ p ∈ P, (1 / ((p : ℝ) - 1)) := by
        apply Finset.prod_congr rfl
        intro p hp
        simp [cofactorDensity, hn p hp]
      _ = 1 / (∏ p ∈ P, ((p : ℝ) - 1)) := by
        simp only [one_div, Finset.prod_inv_distrib]
      _ = _ := by rw [totient_prime_product P hP]
  · rw [ite_eq_right hc]
    have hn : ¬ ∀ p ∈ P, p.Coprime (M * r) := by
      simpa only [Nat.coprime_prod_left_iff] using hc
    push Not at hn
    obtain ⟨p, hp, hnc⟩ := hn
    have hd : p ∣ M * r := by
      by_contra hh
      exact hnc ((hP p hp).coprime_iff_not_dvd.mpr hh)
    exact Finset.prod_eq_zero hp (by simp [cofactorDensity, hd])

/-- The block-sieve remainder for the actual predecessor array is bounded by
the exact BV sum, over any modulus set containing the needed prime products.
No divisor multiplicity is inserted. -/
theorem predecessor_blockRemainder_le (A P moduli : Finset ℕ)
    (w : ℕ → ℝ) (M c r : ℕ) (X D : ℝ)
    (hP : ∀ p ∈ P, p.Prime)
    (hmoduli : ∀ S ∈ remainderSubsets P D, (∏ p ∈ S, p) ∈ moduli) :
    blockRemainder A w (fun p Q => p ∣ c * r * Q + 1)
      P (cofactorDensity M r) X D ≤
      ∑ d ∈ moduli, |divisorMass A w (fun Q => c * r * Q + 1) d -
        productDensity M r d * X| := by
  unfold blockRemainder
  calc
    _ = ∑ S ∈ remainderSubsets P D,
        |divisorMass A w (fun Q => c * r * Q + 1) (∏ p ∈ S, p) -
          productDensity M r (∏ p ∈ S, p) * X| := by
      apply Finset.sum_congr rfl
      intro S hS
      have hSP : ∀ p ∈ S, p.Prime := fun p hp =>
        hP p ((Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1) hp)
      rw [intersectionMass_eq_divisorMass A S w _ hSP, cofactorDensity_product S M r hSP]
      rw [mul_comm X]
    _ ≤ _ := subset_error_sum_le P moduli D
      (fun d => divisorMass A w (fun Q => c * r * Q + 1) d - productDensity M r d * X)
      hP hmoduli



/-- Conditioning on one further prime produces the exact product modulus. -/
theorem conditioned_intersectionMass (A S : Finset ℕ) (w : ℕ → ℝ)
    (f : ℕ → ℕ) {n : ℕ} (hn : n.Prime) (hnS : n ∉ S)
    (hS : ∀ p ∈ S, p.Prime) :
    intersectionMass (A.filter (fun a => n ∣ f a)) w (fun p a => p ∣ f a) S =
      divisorMass A w f (n * ∏ p ∈ S, p) := by
  classical
  have hprime : ∀ p ∈ insert n S, p.Prime := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hp
    · exact hn
    · exact hS p hp
  have hdiv := prime_product_dvd_iff (insert n S) hprime
  unfold intersectionMass divisorMass
  congr 1
  ext a
  simp only [Finset.mem_filter]
  have hh := hdiv (f a)
  rw [Finset.prod_insert hnS] at hh
  simpa only [Finset.mem_insert, forall_eq_or_imp, ← and_assoc] using
    (and_congr Iff.rfl hh.symm)

/-- The conditional main mass is precisely `X/(n-1)`. -/
theorem conditioned_density (S : Finset ℕ) (M r : ℕ) {n : ℕ}
    (hn : n.Prime) (hnS : n ∉ S) (hnMr : ¬ n ∣ M * r)
    (hS : ∀ p ∈ S, p.Prime) :
    productDensity M r (n * ∏ p ∈ S, p) =
      (1 / ((n : ℝ) - 1)) * ∏ p ∈ S, cofactorDensity M r p := by
  classical
  have hprime : ∀ p ∈ insert n S, p.Prime := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hp
    · exact hn
    · exact hS p hp
  have hh := cofactorDensity_product (insert n S) M r hprime
  rw [Finset.prod_insert hnS, Finset.prod_insert hnS] at hh
  simpa only [cofactorDensity, ite_false, hnMr] using hh.symm

/-- Every prime divisor of a product of primes from the small set is small. -/
theorem prime_product_small_factors (S : Finset ℕ) (W : ℕ)
    (hprime : ∀ p ∈ S, p.Prime) (hW : ∀ p ∈ S, p ≤ W) :
    HasSmallPrimeFactors W (∏ p ∈ S, p) := by
  intro p hp hpdvd
  have hz : (∏ q ∈ S, q) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun q hq => (hprime q hq).ne_zero)
  have hm : p ∈ (∏ q ∈ S, q).primeFactors := Nat.mem_primeFactors.mpr ⟨hp, hpdvd, hz⟩
  rw [Nat.primeFactors_prod hprime] at hm
  exact hW p hm

/-- All pairs (one large prime, one small prime subset) have distinct product
moduli. This is the exact combinatorial reason the conditioned error sum has
no multiplicity weight. -/
theorem conditioned_subset_product_injective (N P : Finset ℕ) (D : ℝ) (W : ℕ)
    (hN : ∀ n ∈ N, n.Prime ∧ W < n)
    (hP : ∀ p ∈ P, p.Prime ∧ p ≤ W) :
    Set.InjOn (fun z : ℕ × Finset ℕ => z.1 * ∏ p ∈ z.2, p)
      ((N.product (remainderSubsets P D)) : Set (ℕ × Finset ℕ)) := by
  intro a ha b hb he
  obtain ⟨haN, haS⟩ := Finset.mem_product.mp ha
  obtain ⟨hbN, hbS⟩ := Finset.mem_product.mp hb
  have hsuba : a.2 ⊆ P := Finset.mem_powerset.mp (Finset.mem_filter.mp haS).1
  have hsubb : b.2 ⊆ P := Finset.mem_powerset.mp (Finset.mem_filter.mp hbS).1
  have hsmallA := prime_product_small_factors a.2 W
    (fun p hp => (hP p (hsuba hp)).1) (fun p hp => (hP p (hsuba hp)).2)
  have hsmallB := prime_product_small_factors b.2 W
    (fun p hp => (hP p (hsubb hp)).1) (fun p hp => (hP p (hsubb hp)).2)
  obtain ⟨heN, heS⟩ := large_prime_smooth_product_injective
    (hN a.1 haN).1 (hN b.1 hbN).1 (hN a.1 haN).2 (hN b.1 hbN).2
    hsmallA hsmallB he
  refine Prod.ext heN ?_
  exact Cofactor.prime_subset_product_injective P (fun p hp => (hP p hp).1)
    (Finset.mem_filter.mp haS).1 (Finset.mem_filter.mp hbS).1 heS

/-- Sum the errors from all conditioned block sieves against a single BV
modulus sum. Both the intersections and their main terms are proved to match
that sum exactly. -/
theorem conditioned_blockRemainder_sum_le (A N P moduli : Finset ℕ)
    (w : ℕ → ℝ) (f : ℕ → ℕ) (M r W : ℕ) (X D : ℝ)
    (hN : ∀ n ∈ N, n.Prime ∧ W < n ∧ ¬ n ∣ M * r)
    (hP : ∀ p ∈ P, p.Prime ∧ p ≤ W)
    (hmoduli : ∀ n ∈ N, ∀ S ∈ remainderSubsets P D, n * (∏ p ∈ S, p) ∈ moduli) :
    (∑ n ∈ N, blockRemainder (A.filter (fun a => n ∣ f a)) w
      (fun p a => p ∣ f a) P (cofactorDensity M r) (X / ((n : ℝ) - 1)) D) ≤
      ∑ d ∈ moduli, |divisorMass A w f d - productDensity M r d * X| := by
  classical
  have hrewrite : (∑ n ∈ N, blockRemainder (A.filter (fun a => n ∣ f a)) w
      (fun p a => p ∣ f a) P (cofactorDensity M r) (X / ((n : ℝ) - 1)) D) =
      ∑ z ∈ (N ×ˢ remainderSubsets P D),
        |divisorMass A w f (z.1 * ∏ p ∈ z.2, p) -
          productDensity M r (z.1 * ∏ p ∈ z.2, p) * X| := by
    rw [Finset.sum_product N (remainderSubsets P D)
      (fun z : ℕ × Finset ℕ => |divisorMass A w f (z.1 * ∏ p ∈ z.2, p) -
        productDensity M r (z.1 * ∏ p ∈ z.2, p) * X|)]
    apply Finset.sum_congr rfl
    intro n hn
    unfold blockRemainder
    apply Finset.sum_congr rfl
    intro S hS
    have hsub : S ⊆ P := Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1
    have hnS : n ∉ S := by
      intro hh
      exact not_le_of_gt (hN n hn).2.1 ((hP n (hsub hh)).2)
    have hSP : ∀ p ∈ S, p.Prime := fun p hp => (hP p (hsub hp)).1
    rw [conditioned_intersectionMass A S w f (hN n hn).1 hnS hSP,
      conditioned_density S M r (hN n hn).1 hnS (hN n hn).2.2 hSP]
    congr 2
    ring
  rw [hrewrite]
  apply Finset.sum_le_sum_of_injOn (fun z : ℕ × Finset ℕ => z.1 * ∏ p ∈ z.2, p)
  · exact conditioned_subset_product_injective N P D W
      (fun n hn => ⟨(hN n hn).1, (hN n hn).2.1⟩) hP
  · intro d hd
    obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hd
    obtain ⟨hn, hS⟩ := Finset.mem_product.mp hz
    exact hmoduli z.1 hn z.2 hS
  · intro z _
    exact le_rfl
  · intro d _ _
    exact abs_nonneg _



/-- The full conditioned upper-sieve application. The source constants precede
all arithmetic data; its remainder is bounded by the *one* displayed BV sum.
This does not assume the manuscript's conditioned estimate. The later prime
harmonic-sum and Mertens applications operate on the explicit main term here. -/
theorem source_conditioned_upper (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧ ∃ H₀ : ℕ,
    ∀ (A N P moduli : Finset ℕ) (w : ℕ → ℝ) (f : ℕ → ℕ)
      (M r W : ℕ) (X z : ℝ) (H : ℕ),
      2 ≤ z → Even H → H₀ ≤ H → 0 ≤ X →
      (∀ a ∈ A, 0 ≤ w a) →
      (∀ n ∈ N, n.Prime ∧ W < n ∧ ¬ n ∣ M * r) →
      (∀ p ∈ P, p.Prime ∧ 3 ≤ p ∧ p ≤ W ∧ (p : ℝ) ≤ z) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ P.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / ((p : ℝ) - 1)) ≤ C₀) →
      (∀ n ∈ N, ∀ S ∈ remainderSubsets P (z ^ (4 * H + 2)),
        n * (∏ p ∈ S, p) ∈ moduli) →
      (∑ n ∈ N, siftedMass (A.filter (fun a => n ∣ f a)) w
        (fun p a => p ∣ f a) P) ≤
      (1 + C * Real.exp (-(H : ℝ))) * X * localProduct P (cofactorDensity M r) *
        (∑ n ∈ N, 1 / ((n : ℝ) - 1)) +
      C * (∑ d ∈ moduli, |divisorMass A w f d - productDensity M r d * X|) := by
  obtain ⟨C, hC, H₀, hsource⟩ := source (1/2) C₀ (by norm_num)
  refine ⟨C, hC, H₀, ?_⟩
  intro A N P moduli w f M r W X z H hz hH hH₀ hX hw hN hP hblock hmoduli
  let E := fun n => blockRemainder (A.filter (fun a => n ∣ f a)) w
    (fun p a => p ∣ f a) P (cofactorDensity M r) (X / ((n : ℝ) - 1))
      (z ^ (4 * H + 2))
  have hpoint : ∀ n ∈ N, siftedMass (A.filter (fun a => n ∣ f a)) w
      (fun p a => p ∣ f a) P ≤
      (1 + C * Real.exp (-(H : ℝ))) * (X / ((n : ℝ) - 1)) *
        localProduct P (cofactorDensity M r) + C * E n := by
    intro n hn
    have hnR : (2 : ℝ) ≤ n := by exact_mod_cast (hN n hn).1.two_le
    have hden : 0 < (n : ℝ) - 1 := by linarith
    have hs := (hsource (A.filter (fun a => n ∣ f a)) P w (fun p a => p ∣ f a)
      (cofactorDensity M r) (X / ((n : ℝ) - 1)) z
      (fun a ha => hw a (Finset.mem_filter.mp ha).1) (div_nonneg hX hden.le) hz
      (fun p hp => ⟨(hP p hp).1, (hP p hp).2.2.2⟩)
      (cofactorDensity_localConditions P M r C₀ (fun p hp => (hP p hp).2.1)
        hblock)).1 H hH hH₀
    have hh := (abs_le.mp hs).2
    dsimp [E]
    nlinarith only [hh]
  have hsum := Finset.sum_le_sum hpoint
  have herr := conditioned_blockRemainder_sum_le A N P moduli w f M r W X
    (z ^ (4 * H + 2)) hN (fun p hp => ⟨(hP p hp).1, (hP p hp).2.2.1⟩) hmoduli
  calc
    _ ≤ ∑ n ∈ N, ((1 + C * Real.exp (-(H : ℝ))) * (X / ((n : ℝ) - 1)) *
        localProduct P (cofactorDensity M r) + C * E n) := hsum
    _ = (1 + C * Real.exp (-(H : ℝ))) * X * localProduct P (cofactorDensity M r) *
        (∑ n ∈ N, 1 / ((n : ℝ) - 1)) + C * (∑ n ∈ N, E n) := by
      rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro n hn
      ring
    _ ≤ _ := add_le_add le_rfl (mul_le_mul_of_nonneg_left herr hC.le)



/-- The even depth chosen in the manuscript's initial sieve. -/
noncomputable def initialDepth (b : ℝ) : ℕ := 2 * ⌊1 / (40 * b)⌋₊

theorem initialDepth_even (b : ℝ) : Even (initialDepth b) := by
  exact even_two_mul _

/-- The floor incurs only a bounded loss in depth. -/
theorem initialDepth_bounds {b : ℝ} (hb : 0 < b) :
    1 / (20 * b) - 2 ≤ (initialDepth b : ℝ) ∧
    (initialDepth b : ℝ) ≤ 1 / (20 * b) := by
  have hf := Nat.floor_le (by positivity : 0 ≤ 1 / (40 * b))
  have hg := Nat.lt_floor_add_one (1 / (40 * b))
  have hh : 2 * (1 / (40 * b)) = 1 / (20 * b) := by ring
  unfold initialDepth
  push_cast
  constructor <;> nlinarith

/-- Thus the block exponential error has the advertised `exp(-c/b)` form
with absolute `c=1/20`; changing the depth floor changes only the constant. -/
theorem initialDepth_exponential_bound {b C : ℝ} (hb : 0 < b) (hC : 0 ≤ C) :
    C * Real.exp (-(initialDepth b : ℝ)) ≤
      (C * Real.exp 2) * Real.exp (-(1/20 : ℝ) / b) := by
  have hh := (initialDepth_bounds hb).1
  have he : -(initialDepth b : ℝ) ≤ 2 - (1/20 : ℝ) / b := by
    have hrat : 1 / (20 * b) = (1/20 : ℝ) / b := by ring
    rw [hrat] at hh
    linarith
  calc
    _ ≤ C * Real.exp (2 - (1/20 : ℝ) / b) :=
      mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr he) hC
    _ = _ := by simp only [sub_eq_add_neg, Real.exp_add, neg_div, mul_assoc]

/-- Any fixed source threshold on depth is met by making the initial cutoff
small, before introducing any marking parameters. -/
theorem initialDepth_ge {b : ℝ} {H₀ : ℕ} (hb : 0 < b)
    (hsmall : b ≤ 1 / (40 * ((H₀ : ℝ) + 1))) : H₀ ≤ initialDepth b := by
  have hd : 0 < 40 * ((H₀ : ℝ) + 1) := by positivity
  have hmul := (le_div_iff₀ hd).mp hsmall
  have hbound : (H₀ : ℝ) ≤ 1 / (40 * b) := by
    apply (le_div_iff₀ (by positivity : 0 < 40 * b)).2
    nlinarith
  have hfloor := Nat.le_floor hbound
  exact hfloor.trans (by unfold initialDepth; omega)

/-- The actual initial sieve remainder range lies below `x^(1/5+2b)`.
This verifies the exponent calculation before the BV application. -/
theorem initialDepth_modulus_bound {x b : ℝ} (hx : 1 ≤ x) (hb : 0 < b) :
    (x ^ b) ^ (4 * initialDepth b + 2) ≤ x ^ ((1/5 : ℝ) + 2 * b) := by
  rw [← Real.rpow_natCast, ← Real.rpow_mul (by linarith : 0 ≤ x)]
  apply Real.rpow_le_rpow_of_exponent_le hx
  have hh := (initialDepth_bounds hb).2
  have hmul := (le_div_iff₀ (by positivity : 0 < 20 * b)).mp hh
  push_cast
  nlinarith

end Artin.BuchstabSieve
