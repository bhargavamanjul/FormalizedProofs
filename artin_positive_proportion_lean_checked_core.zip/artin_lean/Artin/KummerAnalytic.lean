module

public import Artin.SmallIndexUnion
public import Artin.DedekindHypothesis
public import Mathlib.FieldTheory.SplittingField.Construction

/-!
# Uniform Kummer estimates from the smoothed explicit formula

This file proves the deduction of the individual power-residue estimate,
and hence the actual small-index union bound, from the separately stated
number-field inputs. The input package gives the exact smoothed explicit
formula, a summable family of absolute Mellin weights, the zero-free bound,
and the degree, discriminant, and positive split-prime contribution.

The fields count the actual predicates from `SmallIndexUnion`; there is no
assumed individual splitting estimate. Constants and the threshold are
common to every eligible `q`, so summation over a growing range is valid.

The package is not asserted to exist. In particular, this file does not
construct the analytic continuation or zero multiset of Dedekind zeta, or
prove the Kummer splitting criterion. Those are the remaining interfaces to
the accepted classical theorems and the arithmetic of the actual fields.
-/

@[expose] public section

namespace Artin

open Filter
open scoped BigOperators Topology

/-- Precise sufficient number-field inputs for the family
`K_q = ℚ(ζ_q, a^(1/q))`. The values `degree` and `logDiscriminant` represent
`[K_q : ℚ]` and `log |Disc K_q|`. The common smoothing has Mellin mass `m`;
`C` bounds both its total absolute zero weight and its remainder.

`Zero q` indexes nontrivial zeros with multiplicity. The function `beta`
records their real parts, and `weight` their absolute Mellin weights.
`idealSum`, `zeroSum`, and `remainder` are the real quantities in the
smoothed explicit formula. The `dominance` field is the positive
contribution of the actual power-residue primes; establishing it requires
the Kummer splitting criterion.

The universal threshold and constants occur before `q` and `N`.
Constructing this structure is a proof obligation, not an axiom. -/
structure KummerSmoothedInputs (Q : ℝ → Prop) (a : ℤ)
    (m C Y₀ : ℝ) where
  threshold : ℝ
  degree : ℕ → ℕ
  logDiscriminant : ℕ → ℝ
  Zero : ℕ → Type
  beta : (q : ℕ) → Zero q → ℝ
  weight : (q : ℕ) → Zero q → ℝ
  idealSum : ℕ → ℝ → ℝ
  zeroSum : ℕ → ℝ → ℝ
  remainder : ℕ → ℝ → ℝ
  degree_eq : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → degree q = q * (q - 1)
  normalized_discriminant : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    logDiscriminant q / (degree q : ℝ) ≤
      2 * Real.log (q : ℝ) + Real.log (a.natAbs : ℝ)
  weight_nonneg : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → ∀ ρ, 0 ≤ weight q ρ
  weight_summable : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → Summable (weight q)
  weight_mass : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    (∑' ρ, weight q ρ) ≤ C * (logDiscriminant q + degree q)
  zero_free : ∀ N : ℝ, 2 ≤ N → Q N → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) → ∀ ρ, beta q ρ ≤ 1 - 1 / N
  dominance : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      (degree q : ℝ) * Real.log x * powerResidueCount a q x ≤ idealSum q x
  formula : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      idealSum q x = m * x - zeroSum q x + remainder q x
  zero_triangle : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      |zeroSum q x| ≤ ∑' ρ, x ^ beta q ρ * weight q ρ
  remainder_bound : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      |remainder q x| ≤ C * (degree q : ℝ) * Real.log x

/-- The degree identity, in the real form used by the explicit formula. -/
theorem KummerSmoothedInputs.degree_real_eq
    {Q : ℝ → Prop} {a : ℤ} {m C Y₀ : ℝ}
    (data : KummerSmoothedInputs Q a m C Y₀)
    {q : ℕ} (hq : q.Prime) (hY : Y₀ < (q : ℝ)) :
    (data.degree q : ℝ) = (q : ℝ) * ((q : ℝ) - 1) := by
  rw [data.degree_eq q hq hY, Nat.cast_mul, Nat.cast_sub hq.one_le, Nat.cast_one]

/-- The actual power-residue count satisfies the uniform individual bound.
The coefficient `3` accounts for the archimedean remainder uniformly for
all `N ≥ 2`; no threshold depending on the individual field is introduced. -/
theorem individualPowerResidueEstimate_of_smoothed_inputs
    {Q : ℝ → Prop} {a : ℤ} {m C Y₀ : ℝ}
    (hC : 0 ≤ C) (data : KummerSmoothedInputs Q a m C Y₀) :
    IndividualPowerResidueEstimate Q a m C (Real.log (a.natAbs : ℝ) + 3) Y₀ := by
  intro N hN hQ
  filter_upwards [eventually_gt_atTop (max 1 data.threshold)] with x hx
  have hx1 : 1 < x := (le_max_left _ _).trans_lt hx
  have hxT : data.threshold ≤ x := (le_max_right _ _).trans hx.le
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx1
  have hN0 : 0 < N := by linarith
  have hδ : 1 / N ≤ (1 : ℝ) / 2 := by
    apply (div_le_iff₀ hN0).2
    linarith
  intro q hq hY
  have hdegree := data.degree_real_eq hq hY
  have hq1 : (1 : ℝ) < q := by exact_mod_cast hq.one_lt
  have hn : 0 < (data.degree q : ℝ) := by rw [hdegree]; positivity
  have hbound := splitting_from_smoothed_inputs
    (data.beta q) (data.weight q) hn hx1 hδ hC
    (data.dominance x hx1 hxT q hq hY)
    (data.formula x hx1 hxT q hq hY)
    (data.zero_free N hN hQ q hq hY)
    (data.weight_nonneg q hq hY)
    (data.weight_summable q hq hY)
    (data.weight_mass q hq hY)
    (data.zero_triangle x hx1 hxT q hq hY)
    (data.remainder_bound x hx1 hxT q hq hY)
  have hcoef : 0 ≤ C * x ^ (1 - 1 / N) / Real.log x := by positivity
  calc
    powerResidueCount a q x ≤
        m * x / ((data.degree q : ℝ) * Real.log x) +
          C * x ^ (1 - 1 / N) / Real.log x *
            (data.logDiscriminant q / (data.degree q : ℝ) + 3) := hbound
    _ ≤ m * x / ((data.degree q : ℝ) * Real.log x) +
          C * x ^ (1 - 1 / N) / Real.log x *
            (2 * Real.log (q : ℝ) + Real.log (a.natAbs : ℝ) + 3) := by
      exact add_le_add le_rfl (mul_le_mul_of_nonneg_left
        (add_le_add (data.normalized_discriminant q hq hY) le_rfl) hcoef)
    _ = (m * (x / Real.log x)) * (1 / ((q : ℝ) * ((q : ℝ) - 1))) +
          (C * x ^ (1 - 1 / N) / Real.log x) *
            (2 * Real.log (q : ℝ) + (Real.log (a.natAbs : ℝ) + 3)) := by
      rw [hdegree]
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

/-- Close the small-index estimate from the explicit smoothed number-field
inputs and the separately accepted classical reciprocal-prime tail.
Chebyshev's bound, the moving finite union, the normalization by the field
degree, and the uniform summation are all proved in this dependency chain. -/
theorem smallIndexEstimate_of_smoothed_inputs_and_tail
    {Q : ℝ → Prop} {a : ℤ} {m C Y₀ H : ℝ}
    (hm : 0 ≤ m) (hC : 0 ≤ C)
    (data : KummerSmoothedInputs Q a m C Y₀)
    (htail : ReciprocalPrimeTail H) :
    SmallIndexEstimate Q a (m * H) Y₀ := by
  apply smallIndexEstimate_of_individual_and_tail Q a m C
    (Real.log (a.natAbs : ℝ) + 3) H Y₀ hm hC
  · have h := Real.log_natCast_nonneg a.natAbs
    linarith
  · exact individualPowerResidueEstimate_of_smoothed_inputs hC data
  · exact htail


/-- The concrete Kummer field, realized as the splitting field of
`X^q - a` over `ℚ`. For nonzero `a`, this is the usual field
`ℚ(ζ_q, a^(1/q))`. No choice of a complex root is needed. -/
abbrev KummerField (a : ℤ) (q : ℕ) : Type :=
  (Polynomial.X ^ q - Polynomial.C (a : ℚ)).SplittingField

/-- Splitting fields of rational polynomials are actual number fields.
This uses the finite-dimensional instance already proved in mathlib. -/
noncomputable instance kummerField_numberField (a : ℤ) (q : ℕ) :
    NumberField (KummerField a q) :=
  NumberField.of_module_finite ℚ (KummerField a q)

/-- Actual degree of the chosen Kummer splitting field. -/
noncomputable def kummerDegree (a : ℤ) (q : ℕ) : ℕ :=
  Module.finrank ℚ (KummerField a q)

/-- Actual logarithm of the absolute number-field discriminant. -/
noncomputable def kummerLogDiscriminant (a : ℤ) (q : ℕ) : ℝ :=
  Real.log ((NumberField.discr (KummerField a q)).natAbs : ℝ)

/-- Sufficient analytic inputs for the concrete splitting fields `KummerField a q`.

Unlike `KummerSmoothedInputs`, this package has no abstract QRH guard and
no independent real-part function. Its zeros are complex numbers at which
the actual field's specified continued Dedekind zeta vanishes. Its degree
and discriminant are mathlib's actual number-field invariants.

The remaining fields state the classical degree/discriminant computation,
positivity from the Kummer splitting criterion, and the smoothed explicit
formula with its absolute Mellin-weight and remainder bounds. It asserts no
individual splitting estimate or small-index conclusion. Constructing this
package from the accepted classical results remains a proof obligation;
accepting the entire package would also accept the unformalized specializations.

The intended ideal/zero/remainder quantities and absolute Mellin weights
come from the smoothed formula for one fixed positive test function. They
are not yet defined by those analytic expressions here, and the zero family
is not required here to exhaust all zeros. The constructor must establish
the displayed formula and bounds for its chosen quantities. Their uniform
constants precede both `N` and `q`.
-/
structure ClassicalKummerInputs (a : ℤ) (m C Y₀ : ℝ) where
  threshold : ℝ
  continuation : ∀ q : ℕ, DedekindContinuation (KummerField a q)
  Zero : ℕ → Type
  zero : ∀ q : ℕ, Zero q → ℂ
  nontrivial : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    ∀ ρ, IsNontrivialDedekindZero (continuation q) (zero q ρ)
  weight : ∀ q : ℕ, Zero q → ℝ
  idealSum : ℕ → ℝ → ℝ
  zeroSum : ℕ → ℝ → ℝ
  remainder : ℕ → ℝ → ℝ
  degree_eq : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    kummerDegree a q = q * (q - 1)
  normalized_discriminant : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    kummerLogDiscriminant a q / (kummerDegree a q : ℝ) ≤
      2 * Real.log (q : ℝ) + Real.log (a.natAbs : ℝ)
  weight_nonneg : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → ∀ ρ, 0 ≤ weight q ρ
  weight_summable : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) → Summable (weight q)
  weight_mass : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    (∑' ρ, weight q ρ) ≤ C * (kummerLogDiscriminant a q + kummerDegree a q)
  dominance : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      (kummerDegree a q : ℝ) * Real.log x * powerResidueCount a q x ≤ idealSum q x
  formula : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      idealSum q x = m * x - zeroSum q x + remainder q x
  zero_triangle : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      |zeroSum q x| ≤ ∑' ρ, x ^ (zero q ρ).re * weight q ρ
  remainder_bound : ∀ x : ℝ, 1 < x → threshold ≤ x → ∀ q : ℕ,
    q.Prime → Y₀ < (q : ℝ) →
      |remainder q x| ≤ C * (kummerDegree a q : ℝ) * Real.log x

/-- The actual Dedekind QRH hypothesis supplies the only missing zero bound
in the classical smoothed formula package. Every other field is preserved
verbatim; neither a splitting estimate nor its conclusion is assumed. -/
noncomputable def ClassicalKummerInputs.toSmoothedInputs
    {a : ℤ} {m C Y₀ : ℝ} (data : ClassicalKummerInputs a m C Y₀) :
    KummerSmoothedInputs DedekindQRH a m C Y₀ where
  threshold := data.threshold
  degree := kummerDegree a
  logDiscriminant := kummerLogDiscriminant a
  Zero := data.Zero
  beta := fun q ρ => (data.zero q ρ).re
  weight := data.weight
  idealSum := data.idealSum
  zeroSum := data.zeroSum
  remainder := data.remainder
  degree_eq := data.degree_eq
  normalized_discriminant := data.normalized_discriminant
  weight_nonneg := data.weight_nonneg
  weight_summable := data.weight_summable
  weight_mass := data.weight_mass
  zero_free := by
    intro N _hN hQRH q hq hY ρ
    exact hQRH.2 (KummerField a q) (data.continuation q)
      (data.zero q ρ) (data.nontrivial q hq hY ρ)
  dominance := data.dominance
  formula := data.formula
  zero_triangle := data.zero_triangle
  remainder_bound := data.remainder_bound

/-- The small-index estimate for the actual QRH statement and actual
Kummer fields, from the explicitly enumerated sufficient analytic inputs. -/
theorem smallIndexEstimate_of_classicalKummerInputs
    {a : ℤ} {m C Y₀ H : ℝ}
    (hm : 0 ≤ m) (hC : 0 ≤ C)
    (data : ClassicalKummerInputs a m C Y₀)
    (htail : ReciprocalPrimeTail H) :
    SmallIndexEstimate DedekindQRH a (m * H) Y₀ :=
  smallIndexEstimate_of_smoothed_inputs_and_tail hm hC data.toSmoothedInputs htail

end Artin
