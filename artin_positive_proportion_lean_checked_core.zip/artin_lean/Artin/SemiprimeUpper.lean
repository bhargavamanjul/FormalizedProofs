module

public import Artin.SemiprimeCover

/-!
# The semiprime upper bound after the rough-pair sieve

This assembles the proved actual cover, both source-based marked
replacements, and the logarithmic error absorption.  The rough-pair sieve
estimate is a separate explicit input at this assembly stage.  Its main
constant, and consequently the final semiprime constant, precedes every
marking and the strip width `κ`.
-/

@[expose] public section
open Filter
open scoped BigOperators

namespace Artin.SemiprimeUpper

open DyadicBoxes MarkedSource SemiprimeMR SemiprimeReplacement RoughCompanion
  SemiprimeBoxes SemiprimeCover

noncomputable def boxConstant : ℝ := 6 / Real.log 2 + 9

theorem boxConstant_pos : 0 < boxConstant := by
  unfold boxConstant
  positivity [Real.log_pos (by norm_num : (1 : ℝ) < 2)]

/-- The final main coefficient depends only on the rough-pair coefficient,
not on the number of marking groups or the width of the semiprime strip. -/
noncomputable def upperConstant (A : ℝ) : ℝ :=
  2 * boxConstant * A / (46 / 100 : ℝ) ^ 2 + 1

theorem upperConstant_pos {A : ℝ} (hA : 0 ≤ A) : 0 < upperConstant A := by
  unfold upperConstant
  positivity [boxConstant_pos]

/-- Explicit numerical absorption, using only `X₀ ≥ m*x/log x`.
The stronger actual main-mass estimate is not needed at this final step. -/
theorem absorb_box_bound {A C m κ x L X₀ : ℝ}
    (hA : 0 ≤ A) (hC : 0 ≤ C) (hm : 0 < m) (hκ : 0 < κ)
    (hx : 0 ≤ x) (hL : 0 < L) (hwidth : 1 ≤ κ * L)
    (herror : 4 * boxConstant * C ≤ m * L ^ 3)
    (hmain : m * x / L ≤ X₀) :
    boxConstant * (κ * L + 1) *
      (A * X₀ / ((46 / 100 : ℝ) ^ 2 * L ^ 2) + 2 * C * x * L ^ (-6 : ℝ)) ≤
      upperConstant A * κ * X₀ / L := by
  have hX₀ : 0 ≤ X₀ := (div_nonneg (mul_nonneg hm.le hx) hL.le).trans hmain
  have hpow : L ^ (-6 : ℝ) = (L ^ (6 : ℕ))⁻¹ := by
    rw [Real.rpow_neg hL.le]
    norm_num
  have hσ : (46 / 100 : ℝ) ^ 2 ≠ 0 := by norm_num
  have hcoef : 4 * boxConstant * C / L ^ 3 ≤ m :=
    (div_le_iff₀ (pow_pos hL 3)).mpr herror
  have hrest : 0 ≤ A * X₀ / ((46 / 100 : ℝ) ^ 2 * L ^ 2) +
      2 * C * x * L ^ (-6 : ℝ) := by positivity
  calc
    boxConstant * (κ * L + 1) *
        (A * X₀ / ((46 / 100 : ℝ) ^ 2 * L ^ 2) + 2 * C * x * L ^ (-6 : ℝ)) ≤
        boxConstant * (2 * κ * L) *
          (A * X₀ / ((46 / 100 : ℝ) ^ 2 * L ^ 2) + 2 * C * x * L ^ (-6 : ℝ)) := by
      apply mul_le_mul_of_nonneg_right _ hrest
      exact mul_le_mul_of_nonneg_left (by linarith) boxConstant_pos.le
    _ = (2 * boxConstant * A / (46 / 100 : ℝ) ^ 2) * κ * X₀ / L +
        (4 * boxConstant * C / L ^ 3) * (κ * x / L ^ 2) := by
      rw [hpow]
      field_simp
      ring
    _ ≤ (2 * boxConstant * A / (46 / 100 : ℝ) ^ 2) * κ * X₀ / L +
        m * (κ * x / L ^ 2) := by
      exact add_le_add (le_refl _) (mul_le_mul_of_nonneg_right hcoef
        (by positivity : 0 ≤ κ * x / L ^ 2))
    _ ≤ (2 * boxConstant * A / (46 / 100 : ℝ) ^ 2) * κ * X₀ / L + κ * X₀ / L := by
      apply add_le_add (le_refl _)
      have hh := mul_le_mul_of_nonneg_left hmain (div_nonneg hκ.le hL.le)
      convert hh using 1 <;> ring
    _ = upperConstant A * κ * X₀ / L := by unfold upperConstant; ring

/-- All restrictions used in error absorption have one eventual threshold;
the main coefficient remains independent of `m,C,κ`. -/
theorem eventually_absorb_box_bound {A C m κ : ℝ}
    (hA : 0 ≤ A) (hC : 0 ≤ C) (hm : 0 < m) (hκ : 0 < κ) :
    ∀ᶠ x : ℝ in atTop, ∀ X₀ : ℝ, m * x / Real.log x ≤ X₀ →
      boxConstant * (κ * Real.log x + 1) *
        (A * X₀ / ((46 / 100 : ℝ) ^ 2 * (Real.log x) ^ 2) +
          2 * C * x * (Real.log x) ^ (-6 : ℝ)) ≤
        upperConstant A * κ * X₀ / Real.log x := by
  have hwidth := Real.tendsto_log_atTop.eventually_ge_atTop (1 / κ)
  have hpower := ((tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 3)).comp
    Real.tendsto_log_atTop).eventually_ge_atTop (4 * boxConstant * C / m)
  filter_upwards [hwidth, hpower, eventually_gt_atTop (1 : ℝ)] with x hL hp hx X₀ hmain
  apply absorb_box_bound hA hC hm hκ (by linarith) (Real.log_pos hx) ?_ ?_ hmain
  · have hh := (div_le_iff₀ hκ).mp hL
    nlinarith
  · have hh := (div_le_iff₀ hm).mp hp
    norm_num at hh
    nlinarith

/-- End-to-end semiprime assembly. The rough-pair estimate and weak main
mass lower bound remain explicit, separately proved premises. All marked
replacement errors, whole-box support conditions, cover multiplicities,
and their absorption have been discharged. -/
theorem semiprime_upper_from_sources_and_rough_pairs
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hMertens : ClassicalMertensLower)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨ : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ0 : ∀ y, 0 ≤ Ψ y) (A : ℝ) (hA : 0 ≤ A) :
    ∃ C₂ : ℝ, 0 < C₂ ∧ ∃ K₀ : ℕ, 1 ≤ K₀ ∧
      ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ κ : ℝ, 0 < κ → κ ≤ (1 : ℝ) / 100 →
      ∀ (c : ℕ) (allowed : ℝ → Finset ℕ) (Qmin X₀ : ℝ → ℝ),
      (∃ m : ℝ, 0 < m ∧ ∀ᶠ x : ℝ in atTop, m * x / Real.log x ≤ X₀ x) →
      (∀ᶠ x : ℝ in atTop, ∀ ab ∈ narrowBoxIndices x κ,
        pairMass (dyadIntegers (leftScale x ab)) (dyadIntegers (rightScale x ab))
          (actualWeight b M u Ψ x c (allowed x) (Qmin x))
          (realRoughIndicator (W x)) (realRoughIndicator (W x)) ≤
          A * X₀ x * (eulerV (W x)) ^ 2) →
      ∀ᶠ x : ℝ in atTop,
        roughCompositeMass x κ (actualWeight b M u Ψ x c (allowed x) (Qmin x)) ≤
          C₂ * κ * X₀ x / Real.log x := by
  obtain ⟨K₀, hK₀, hK⟩ := narrow_prime_cover_from_sources h102 h103 hbands hFourier
    hMertens M u hu hunit Ψ hΨ hΨ0
  refine ⟨upperConstant A, upperConstant_pos hA, K₀, hK₀, ?_⟩
  intro K hKK b κ hκ0 hκ c allowed Qmin X₀ hmain hpairs
  obtain ⟨m, hm, hmass⟩ := hmain
  obtain ⟨C, hC, he⟩ := hK K hKK b κ hκ0.le hκ
  filter_upwards [he, hpairs, hmass, eventually_roughCompositeMass_le_primeCoverMass,
    eventually_absorb_box_bound hA hC.le hm hκ0, eventually_gt_atTop (1 : ℝ)]
    with x hex hp hxmass hcover habs hx
  have hX₀ : 0 ≤ X₀ x :=
    (div_nonneg (mul_nonneg hm.le (by linarith)) (Real.log_pos hx).le).trans hxmass
  have hfirst := hcover κ hκ (actualWeight b M u Ψ x c (allowed x) (Qmin x))
    (actualWeight_nonneg b M u Ψ hΨ0 x c (allowed x) (Qmin x))
  have hsecond := hex A (X₀ x) hA hX₀ c (allowed x) (Qmin x) hp
  exact (hfirst.trans hsecond).trans (habs (X₀ x) hxmass)

end Artin.SemiprimeUpper
