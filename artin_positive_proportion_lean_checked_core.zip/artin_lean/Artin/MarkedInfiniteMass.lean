module

public import Artin.MarkedPowerMass
public import Artin.MarkedCofactorMass
public import Artin.MarkedMultigroupMass
public import Mathlib.Topology.Algebra.InfiniteSum.Real
public import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Infinite reciprocal mass of the actual marked-supported integers

The finite prime-power bounds imply convergence of the genuine series over
positive natural numbers. All powers of each marked prime are retained.
-/

@[expose] public section

open scoped BigOperators Topology
open Filter

namespace Artin.MarkedInfiniteMass

/-- Reciprocal weight of a positive integer supported on the given primes. -/
noncomputable def supportedReciprocal (P : Finset ℕ) (W : ℕ → ℝ) (n : ℕ) : ℝ :=
  if 0 < n ∧ n.primeFactors ⊆ P then W n / (n : ℝ) else 0

/-- The full supported reciprocal mass, including every positive prime power. -/
noncomputable def supportedMass (P : Finset ℕ) (W : ℕ → ℝ) : ℝ :=
  ∑' n, supportedReciprocal P W n

/-- The actual size tail of the supported reciprocal mass. -/
noncomputable def supportedSizeTail (P : Finset ℕ) (W : ℕ → ℝ) (R : ℝ) : ℝ :=
  ∑' n : ℕ, if R < (n : ℝ) then supportedReciprocal P W n else 0

theorem supportedReciprocal_nonneg (P : Finset ℕ) (W : ℕ → ℝ)
    (hW : ∀ n, 0 ≤ W n) (n : ℕ) : 0 ≤ supportedReciprocal P W n := by
  unfold supportedReciprocal
  split_ifs
  · exact div_nonneg (hW n) (Nat.cast_nonneg n)
  · exact le_rfl

/-- Restricting a finite sum to its actual supported integers is exact. -/
theorem finite_supported_moment_eq (S P : Finset ℕ) (W : ℕ → ℝ) (v : ℝ) :
    (∑ n ∈ S, supportedReciprocal P W n * Real.exp (v * Real.log (n : ℝ))) =
      ∑ n ∈ S.filter (fun n => 0 < n ∧ n.primeFactors ⊆ P),
        W n / (n : ℝ) * Real.exp (v * Real.log (n : ℝ)) := by
  classical
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro n hn
  simp only [supportedReciprocal]
  split_ifs <;> simp

/-- Every finite partial exponential moment has one bound independent of the
partial sum, obtained by unique factorization and finite geometric sums. -/
theorem finite_supported_moment_bound (S P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hW : ∀ n, W n ≤ W₀)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑ n ∈ S, supportedReciprocal P W n * Real.exp (v * Real.log (n : ℝ))) ≤
      W₀ * Real.exp (2 * B) := by
  rw [finite_supported_moment_eq]
  apply MarkedPowerMass.finite_supported_power_moment _ P W W₀ B v hP
  · intro n hn
    exact (Finset.mem_filter.mp hn).2.1
  · intro n hn
    exact (Finset.mem_filter.mp hn).2.2
  · exact hW₀
  · intro n hn
    exact hW n
  · exact hratio
  · exact hB

/-- Convergence of the actual prime-power exponential moment. -/
theorem summable_supported_moment (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    Summable (fun n => supportedReciprocal P W n * Real.exp (v * Real.log (n : ℝ))) := by
  apply summable_of_sum_le
    (fun n => mul_nonneg (supportedReciprocal_nonneg P W hWnonneg n) (Real.exp_pos _).le)
  intro S
  exact finite_supported_moment_bound S P W W₀ B v hP hW₀ hW hratio hB

/-- The infinite exponential moment satisfies the same uniform bound. -/
theorem tsum_supported_moment_le (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑' n, supportedReciprocal P W n * Real.exp (v * Real.log (n : ℝ))) ≤
      W₀ * Real.exp (2 * B) := by
  apply Real.tsum_le_of_sum_le
    (fun n => mul_nonneg (supportedReciprocal_nonneg P W hWnonneg n) (Real.exp_pos _).le)
  intro S
  exact finite_supported_moment_bound S P W W₀ B v hP hW₀ hW hratio hB

/-- At exponent zero every prime has geometric ratio at most one half. -/
theorem prime_zero_ratio_le_half {p : ℕ} (hp : p.Prime) :
    Real.exp (0 * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2 := by
  simp only [zero_mul, Real.exp_zero]
  exact one_div_le_one_div_of_le (by norm_num) (by exact_mod_cast hp.two_le)

/-- Convergence requires only bounded nonnegative weights and a finite prime
support, and places no squarefreeness restriction on the integer. -/
theorem summable_supportedReciprocal (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀) :
    Summable (supportedReciprocal P W) := by
  have h := summable_supported_moment P W W₀ (∑ p ∈ P, 1 / (p : ℝ)) 0
    hP hW₀ hWnonneg hW (fun p hp => prime_zero_ratio_le_half (hP p hp)) (by simp)
  simpa using h

/-- An explicit finite upper bound for the full reciprocal mass. -/
theorem supportedMass_le (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀) :
    supportedMass P W ≤ W₀ * Real.exp (2 * ∑ p ∈ P, 1 / (p : ℝ)) := by
  have h := tsum_supported_moment_le P W W₀ (∑ p ∈ P, 1 / (p : ℝ)) 0
    hP hW₀ hWnonneg hW (fun p hp => prime_zero_ratio_le_half (hP p hp)) (by simp)
  simpa [supportedMass] using h

/-- Convergence by the ordinary increasing integer cutoff. -/
theorem tendsto_supported_partial_sums (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀) :
    Tendsto (fun N => ∑ n ∈ Finset.range N, supportedReciprocal P W n)
      atTop (𝓝 (supportedMass P W)) :=
  (summable_supportedReciprocal P W W₀ hP hW₀ hWnonneg hW).hasSum.tendsto_sum_nat

/-- The genuinely infinite reciprocal tail tends to zero. -/
theorem tendsto_supported_tail_zero (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀) :
    Tendsto (fun N => ∑' n, supportedReciprocal P W (n + N)) atTop (𝓝 0) := by
  have hs := summable_supportedReciprocal P W W₀ hP hW₀ hWnonneg hW
  have htail (N : ℕ) : (∑' n, supportedReciprocal P W (n + N)) =
      supportedMass P W - ∑ n ∈ Finset.range N, supportedReciprocal P W n := by
    have h := hs.sum_add_tsum_nat_add N
    dsimp [supportedMass]
    linarith
  simp_rw [htail]
  simpa using (tendsto_const_nhds (x := supportedMass P W)).sub
    (tendsto_supported_partial_sums P W W₀ hP hW₀ hWnonneg hW)

/-- Rankin's estimate for the complete infinite reciprocal tail. -/
theorem infinite_supported_rankin (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B T v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀)
    (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑' n : ℕ, if T < Real.log (n : ℝ) then supportedReciprocal P W n else 0) ≤
      W₀ * Real.exp (2 * B - v * T) := by
  classical
  apply Real.tsum_le_of_sum_le
  · intro n
    change 0 ≤ (if T < Real.log (n : ℝ) then supportedReciprocal P W n else 0)
    split_ifs
    · exact supportedReciprocal_nonneg P W hWnonneg n
    · exact le_rfl
  · intro S
    rw [← Finset.sum_filter]
    have hrankin := CofactorAsymptotics.finite_rankin S
      (supportedReciprocal P W) (fun n => Real.log (n : ℝ)) T v hv
      (fun n hn => supportedReciprocal_nonneg P W hWnonneg n)
    calc
      _ ≤ Real.exp (-v * T) * (∑ n ∈ S,
          supportedReciprocal P W n * Real.exp (v * Real.log (n : ℝ))) := hrankin
      _ ≤ Real.exp (-v * T) * (W₀ * Real.exp (2 * B)) :=
        mul_le_mul_of_nonneg_left
          (finite_supported_moment_bound S P W W₀ B v hP hW₀ hW hratio hB)
          (Real.exp_pos _).le
      _ = W₀ * Real.exp (2 * B - v * T) := by
        rw [sub_eq_add_neg, Real.exp_add]
        simp only [neg_mul]
        ring

/-- The complete supported mass beyond the actual integer size `exp T`. -/
theorem infinite_supported_size_tail (P : Finset ℕ) (W : ℕ → ℝ)
    (W₀ B T v : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (hW₀ : 0 ≤ W₀) (hWnonneg : ∀ n, 0 ≤ W n) (hW : ∀ n, W n ≤ W₀)
    (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    supportedSizeTail P W (Real.exp T) ≤ W₀ * Real.exp (2 * B - v * T) := by
  have heq : (fun n : ℕ => if Real.exp T < (n : ℝ) then supportedReciprocal P W n else 0) =
      (fun n : ℕ => if T < Real.log (n : ℝ) then supportedReciprocal P W n else 0) := by
    funext n
    by_cases hn : 0 < n ∧ n.primeFactors ⊆ P
    · have hnpos : 0 < (n : ℝ) := by exact_mod_cast hn.1
      simp only [(Real.lt_log_iff_exp_lt hnpos).symm]
    · simp [supportedReciprocal, hn]
  unfold supportedSizeTail
  rw [heq]
  exact infinite_supported_rankin P W W₀ B T v hP hW₀ hWnonneg hW hv hratio hB

/-- Absolute convergence of the actual normalized marking series. -/
theorem summable_marking_weight {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p) :
    Summable (supportedReciprocal P (ConcreteSelector.markingWeight I groups V)) := by
  apply summable_supportedReciprocal P _ (∏ i ∈ I, 1 / V i) hP
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2

/-- Uniform upper bound for the actual normalized marking series. -/
theorem marking_mass_le {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p) :
    supportedMass P (ConcreteSelector.markingWeight I groups V) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * ∑ p ∈ P, 1 / (p : ℝ)) := by
  apply supportedMass_le P _ (∏ i ∈ I, 1 / V i) hP
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2

/-- The actual normalized marking series has a bounded exponential moment. -/
theorem infinite_marking_weight_moment {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ) (B v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑' n, supportedReciprocal P (ConcreteSelector.markingWeight I groups V) n *
      Real.exp (v * Real.log (n : ℝ))) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B) := by
  apply tsum_supported_moment_le P _ (∏ i ∈ I, 1 / V i) B v hP
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2
  · exact hratio
  · exact hB

/-- Rankin's estimate for all actual marked-supported prime powers. -/
theorem infinite_marking_weight_rankin {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ) (B T v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p) (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    (∑' n : ℕ, if T < Real.log (n : ℝ) then
      supportedReciprocal P (ConcreteSelector.markingWeight I groups V) n else 0) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B - v * T) := by
  apply infinite_supported_rankin P _ (∏ i ∈ I, 1 / V i) B T v hP
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2
  · exact hv
  · exact hratio
  · exact hB

/-- Infinite marked mass beyond an actual integer size threshold. -/
theorem infinite_marking_weight_size_tail {ι : Type*} (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ) (B T v : ℝ)
    (hV : ∀ i ∈ I, 0 < V i) (hP : ∀ p ∈ P, Nat.Prime p) (hv : 0 ≤ v)
    (hratio : ∀ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ) ≤ 1 / 2)
    (hB : (∑ p ∈ P, Real.exp (v * Real.log (p : ℝ)) / (p : ℝ)) ≤ B) :
    supportedSizeTail P (ConcreteSelector.markingWeight I groups V) (Real.exp T) ≤
      (∏ i ∈ I, 1 / V i) * Real.exp (2 * B - v * T) := by
  apply infinite_supported_size_tail P _ (∏ i ∈ I, 1 / V i) B T v hP
  · exact Finset.prod_nonneg (fun i hi => (one_div_pos.mpr (hV i hi)).le)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).2
  · exact hv
  · exact hratio
  · exact hB

/-- Every finite subfamily of actual supported integers contributes at most
the full convergent reciprocal mass. -/
theorem finite_sum_le_supportedMass (P S : Finset ℕ) (W : ℕ → ℝ)
    (hWnonneg : ∀ n, 0 ≤ W n) (hsummable : Summable (supportedReciprocal P W))
    (hS : ∀ n ∈ S, 0 < n ∧ n.primeFactors ⊆ P) :
    (∑ n ∈ S, W n / (n : ℝ)) ≤ supportedMass P W := by
  have heq : (∑ n ∈ S, W n / (n : ℝ)) = ∑ n ∈ S, supportedReciprocal P W n := by
    apply Finset.sum_congr rfl
    intro n hn
    simp [supportedReciprocal, hS n hn]
  rw [heq]
  exact hsummable.sum_le_tsum S (fun n hn => supportedReciprocal_nonneg P W hWnonneg n)

/-- The manuscript's full marked reciprocal mass is at least one. The finite
subfamily choosing one prime from each disjoint group already has that mass. -/
theorem marking_mass_ge_one {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ)
    (hP : ∀ p ∈ P, Nat.Prime p) (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i ≤ ∑ p ∈ groups i, 1 / (p : ℝ)) :
    1 ≤ supportedMass P (ConcreteSelector.markingWeight I groups V) := by
  have hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime :=
    fun i hi p hp => hP p (hgroups i hi hp)
  refine (MarkedMultigroupMass.singleton_marking_mass_ge_one I groups V
    hprime hdisjoint hV hVsum).trans ?_
  apply finite_sum_le_supportedMass P (MarkedMultigroupMass.singletonMarked I groups)
  · intro n
    exact (ConcreteSelector.markingWeight_bounds I groups V n hV).1
  · exact summable_marking_weight I groups V P hV hP
  · intro n hn
    obtain ⟨hnzero, hnsupport⟩ := MarkedMultigroupMass.singletonMarked_supported I groups hprime n hn
    refine ⟨Nat.pos_of_ne_zero hnzero, ?_⟩
    intro p hp
    have hpU := hnsupport p (Nat.prime_of_mem_primeFactors hp) (Nat.dvd_of_mem_primeFactors hp)
    obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp hpU
    exact hgroups i hi hpi

/-- The actual multiple-group mass is a finite real number bounded below by
one and above by an explicit finite Euler-product bound. -/
theorem marking_mass_bounds {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) (V : ι → ℝ) (P : Finset ℕ)
    (hP : ∀ p ∈ P, Nat.Prime p) (hgroups : ∀ i ∈ I, groups i ⊆ P)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i ≤ ∑ p ∈ groups i, 1 / (p : ℝ)) :
    1 ≤ supportedMass P (ConcreteSelector.markingWeight I groups V) ∧
      supportedMass P (ConcreteSelector.markingWeight I groups V) ≤
        (∏ i ∈ I, 1 / V i) * Real.exp (2 * ∑ p ∈ P, 1 / (p : ℝ)) :=
  ⟨marking_mass_ge_one I groups V P hP hgroups hdisjoint hV hVsum,
    marking_mass_le I groups V P hV hP⟩

end Artin.MarkedInfiniteMass
