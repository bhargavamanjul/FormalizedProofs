module

public import Artin.Arithmetic
public import Artin.FinalAssembly
public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Positivity

/-!
# Actual prime counts and passage from dyadic counts to relative proportion

The finite sets here use the actual multiplicative-order predicate in ZMod.
The dyadic estimate remains an explicit hypothesis. The conversion to a
positive proportion of primes is proved using mathlib's Chebyshev upper bound,
so no prime number theorem is an additional input to this step.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

noncomputable def primitivePrimesUpTo (a : ℤ) (x : ℝ) : Finset ℕ := by
  classical
  exact (Nat.primesLE ⌊x⌋₊).filter (IsPrimitiveRootAt a)

noncomputable def dyadicPrimitivePrimes (a : ℤ) (x : ℝ) : Finset ℕ := by
  classical
  exact (primitivePrimesUpTo a (2 * x)).filter (fun p => x < (p : ℝ))

noncomputable def primitiveCount (a : ℤ) (x : ℝ) : ℝ :=
  (primitivePrimesUpTo a x).card

noncomputable def dyadicPrimitiveCount (a : ℤ) (x : ℝ) : ℝ :=
  (dyadicPrimitivePrimes a x).card

/-- A positive eventual lower proportion, relative to all primes. This property
does not assert that a limiting Artin density exists. -/
def HasPositivePrimeProportion (a : ℤ) : Prop :=
  ∃ d : ℝ, 0 < d ∧ ∀ᶠ x : ℝ in atTop,
    d * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ primitiveCount a x

theorem dyadic_count_le_global (a : ℤ) (x : ℝ) :
    dyadicPrimitiveCount a (x / 2) ≤ primitiveCount a x := by
  classical
  unfold dyadicPrimitiveCount primitiveCount dyadicPrimitivePrimes
  have heq : 2 * (x / 2) = x := by ring
  rw [heq]
  exact_mod_cast Finset.card_filter_le (primitivePrimesUpTo a x)
    (fun p => x / 2 < (p : ℝ))

/-- The analytic scale loses at most a factor two when the dyadic interval is
`(x/2,x]`. -/
theorem half_scale_lower_bound {x : ℝ} (hx : 4 ≤ x) :
    x / (2 * Real.log x) ≤ (x / 2) / Real.log (x / 2) := by
  have hxp : 0 < x := by linarith
  have hhalf : 1 < x / 2 := by linarith
  have hloghalf : 0 < Real.log (x / 2) := Real.log_pos hhalf
  have hlogx : 0 < Real.log x := Real.log_pos (by linarith)
  have hlogle : Real.log (x / 2) ≤ Real.log x :=
    Real.log_le_log (by linarith) (by linarith)
  calc
    x / (2 * Real.log x) = (x / 2) / Real.log x := by ring
    _ ≤ (x / 2) / Real.log (x / 2) :=
      div_le_div_of_nonneg_left (by positivity) hloghalf hlogle

/-- A dyadic lower bound gives an actual positive proportion. The classical
prime-counting upper bound is already a proved mathlib theorem. -/
theorem relative_bound_of_dyadic_bound (a : ℤ) {d : ℝ} (hd : 0 < d)
    (hdyadic : ∀ᶠ x : ℝ in atTop,
      d * (x / Real.log x) ≤ dyadicPrimitiveCount a x) :
    ∀ᶠ x : ℝ in atTop,
      (d / (2 * (Real.log 4 + 1))) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
        ≤ primitiveCount a x := by
  obtain ⟨x₀, hx₀⟩ := (eventually_atTop.1 hdyadic)
  have hB : 0 < Real.log (4 : ℝ) + 1 := by
    have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
    linarith
  filter_upwards [eventually_ge_atTop (max 4 (2 * x₀)),
    Chebyshev.eventually_primeCounting_le (show (0 : ℝ) < 1 by norm_num)] with x hx hpi
  have hx4 : 4 ≤ x := le_trans (le_max_left _ _) hx
  have hxhalf : x₀ ≤ x / 2 := by
    have := le_trans (le_max_right _ _) hx
    linarith
  have hscaled := mul_le_mul_of_nonneg_left (half_scale_lower_bound hx4) hd.le
  have hpi' := mul_le_mul_of_nonneg_left hpi
    (show 0 ≤ d / (2 * (Real.log 4 + 1)) by positivity)
  have heq : d / (2 * (Real.log 4 + 1)) *
      ((Real.log 4 + 1) * x / Real.log x) = d * (x / (2 * Real.log x)) := by
    field_simp
  rw [heq] at hpi'
  exact hpi'.trans (hscaled.trans ((hx₀ (x / 2) hxhalf).trans
    (dyadic_count_le_global a x)))

theorem positive_prime_proportion_of_dyadic_bound (a : ℤ)
    (h : ∃ d : ℝ, 0 < d ∧ ∀ᶠ x : ℝ in atTop,
      d * (x / Real.log x) ≤ dyadicPrimitiveCount a x) :
    HasPositivePrimeProportion a := by
  obtain ⟨d, hd, hdyadic⟩ := h
  refine ⟨d / (2 * (Real.log 4 + 1)), ?_, relative_bound_of_dyadic_bound a hd hdyadic⟩
  have : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  positivity

/-- The final quantitative implication for the actual primitive-root counts.
The analytic estimate is still an explicit hypothesis: this theorem must not
be presented as a proof that the manuscript's cited inputs imply that estimate.
The positive constant is chosen before the zero-free parameter `N`. -/
theorem quantitative_prime_proportion_of_analytic_estimate
    (a : ℤ) (Q : ℝ → Prop) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hEst : FinalAnalyticEstimateOn Q (fun _ x => dyadicPrimitiveCount a x)
      A C Y₀ ε₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → Q N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ primitiveCount a x := by
  obtain ⟨c, hc, hbound⟩ := quantitative_bound_of_final_analytic_estimate_on
    Q (fun _ x => dyadicPrimitiveCount a x) A C Y₀ ε₀ hA hC hY₀ hε₀ hEst
  have hB : 0 < 2 * (Real.log (4 : ℝ) + 1) := by
    have := Real.log_pos (show (1 : ℝ) < 4 by norm_num)
    positivity
  refine ⟨c / (2 * (Real.log 4 + 1)), div_pos hc hB, ?_⟩
  intro N hN hQ
  have hNp : 0 < N := by linarith
  have hlog : 0 < Real.log N := Real.log_pos (by linarith)
  have hd : 0 < c / (N * Real.log N) := by positivity
  have hdyadic : ∀ᶠ x : ℝ in atTop,
      (c / (N * Real.log N)) * (x / Real.log x) ≤ dyadicPrimitiveCount a x := by
    simpa only [mul_div_assoc] using hbound N hN hQ
  have hb := relative_bound_of_dyadic_bound a hd hdyadic
  have heq : (c / (N * Real.log N)) / (2 * (Real.log 4 + 1)) =
      (c / (2 * (Real.log 4 + 1))) / (N * Real.log N) := by ring
  simpa only [heq] using hb

end Artin
