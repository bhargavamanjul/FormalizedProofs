module

public import Artin.ManuscriptMass

/-!
# The discarded enlarged-cofactor tail at arbitrary logarithmic accuracy

The tail is measured against the full reciprocal mass, not just its unmarked
factor.  Combining this with the actual unsieved mass comparison gives
negligibility relative to the original arithmetic weight, with any prescribed
coefficient and logarithmic power.  The selector itself is never truncated.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.ManuscriptTail

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate
  EnlargedCofactorMass MarkedInfiniteMass MarkedBandTail
  FullMassComparison ManuscriptMass

/-- The actual enlarged cofactors discarded only after applying marked
replacement to the full invariant weight. -/
noncomputable def discardedCofactors {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) : Finset ℕ :=
  boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x) \
    boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε)

/-- Their actual contribution to the cofactor expansion of the original
integer weight. The marking remains inside the sum. -/
noncomputable def discardedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) : ℝ :=
  ∑ r ∈ discardedCofactors I a ε Y τ x,
    marking I a x r * primeProgressionSum c M u
      (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))) (smoothWeight x) r

/-- The complementary actual contribution from enlarged cofactors at most
`x^ε`, after the original full weight has been formed. -/
noncomputable def retainedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) : ℝ :=
  ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
    marking I a x r * primeProgressionSum c M u
      (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))) (smoothWeight x) r

/-- Exact finite partition, once the established support conditions identify
the original integer weight with its complete cofactor expansion. -/
theorem baseMass_partition {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z : ℝ) (hx : 2 ≤ x) (hc : 0 < c)
    (hε : ε ≤ 1) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z) :
    baseMass I a c M u ε Y τ x =
      retainedMass I a c M u ε Y τ x + discardedMass I a c M u ε Y τ x := by
  have hg : ∀ i ∈ I, primeBand (a i) x ⊆ markedPrimes I a x := by
    intro i hi p hp
    exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩
  have hXT : x ^ ε ≤ 2 * x := by
    calc
      x ^ ε ≤ x ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith) hε
      _ = x := Real.rpow_one x
      _ ≤ 2 * x := by linarith
  have heq := baseMass_eq_cofactorPrimeMass I a c M u ε Y τ x Z hx hc hcut hP hcP hU
  rw [heq]
  have hsum := (Finset.sum_sdiff (FullMassComparison.boundedCofactors_mono
    (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) hXT)
    (f := fun r => marking I a x r * primeProgressionSum c M u
      (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))) (smoothWeight x) r)).symm
  simpa only [cofactorPrimeMass, retainedMass, discardedMass, discardedCofactors,
    marking, markingWeight_markedPart I _ _ _ _ hg, add_comm] using hsum

/-- The actual scales supply the partition conditions without any analytic
prime-distribution input or extra selector-support hypothesis. -/
theorem eventually_baseMass_partition {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (c M u : ℕ) (hc : 0 < c) (ε Y τ : ℝ) (hε : ε ≤ 1 / 100) :
    ∀ᶠ x : ℝ in atTop,
      baseMass I a c M u ε Y τ x =
        retainedMass I a c M u ε Y τ x + discardedMass I a c M u ε Y τ x := by
  filter_upwards [MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax c (1 / 2)
      hmin hmax (by norm_num) ha,
    MarkedScaleSupport.eventual_marked_not_dvd I a amin amax hmin hmax ha c hc,
    eventually_ge_atTop (2 : ℝ)] with x hP hcP hx
  have hx1 : 1 ≤ x := by linarith
  exact baseMass_partition I a c M u ε Y τ x (x ^ (1 / 2 : ℝ)) hx hc (by linarith)
    (Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num))
    (fun p hp => (hP p hp).2.2) hcP
    (fun r hr p hp hpr => MarkedScaleSupport.unmarked_prime_divisor_le I a ε Y τ (1 / 2)
      hx1 (by linarith) hr hp hpr)

/-- The actual distinct-integer reciprocal tail is smaller than any fixed
multiple of `J / (log x)^A`. The onset may depend on the marking family;
the coefficient on the right is freely prescribed. -/
theorem actual_tail_le_full_over_log_power {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∀ A η : ℝ, 0 < η → ∀ ε : ℝ, 0 < ε → ∀ Y τ : ℝ,
      ∀ᶠ x : ℝ in atTop,
        enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
          (marking I a x) (x ^ ε) ≤
        η * fullMass I a ε Y τ x / (Real.log x) ^ A := by
  obtain ⟨C, hC, hmass⟩ := actual_bands_mass_bounds I a B v₀ hv₀ hinj hclassical
  obtain ⟨Ct, hCt, htail⟩ := actual_bands_enlarged_cofactor_tail I a amin amax B v₀
    hmin hv₀ ha hclassical
  intro A η hη ε hε Y τ
  have hdecay := WeightedTail.eventually_tail_le_log_power A (Ct / η)
    (t := ε / 2) (b := 1 - amax) (by positivity) (by linarith)
  filter_upwards [hmass, htail ε Y τ, hclassical, hdecay,
    eventually_gt_atTop (1 : ℝ)] with x hm ht hv hd hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hv i hi).1
  have hH : 0 ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
    unfold CofactorAsymptotics.scaleMass CofactorAsymptotics.mass
    exact Finset.sum_nonneg (fun n hn => by positivity)
  have hfull : CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x ≤
      fullMass I a ε Y τ x := by
    rw [fullMass, full_mass_eq I a ε Y τ x hV]
    simpa only [one_mul, markedPrimes, marking] using mul_le_mul_of_nonneg_right hm.1 hH
  have hd' : Ct * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax)) ≤
      η / (Real.log x) ^ A := by
    calc
      _ = η * ((Ct / η) * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := by
        field_simp
      _ ≤ η * (Real.log x) ^ (-A) := mul_le_mul_of_nonneg_left hd hη.le
      _ = η / (Real.log x) ^ A := by rw [Real.rpow_neg hL.le]; ring
  calc
    _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x *
        (Ct * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := ht
    _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x *
        (η / (Real.log x) ^ A) := mul_le_mul_of_nonneg_left hd' hH
    _ ≤ fullMass I a ε Y τ x * (η / (Real.log x) ^ A) :=
      mul_le_mul_of_nonneg_right hfull (by positivity)
    _ = _ := by ring

/-- The cofactor expression defining the discarded contribution obeys the
proved elementary bound by `x` times its actual reciprocal tail. -/
theorem discardedMass_le_reciprocal_tail {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (hx : 2 ≤ x) (hc : 2 ≤ c)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    discardedMass I a c M u ε Y τ x ≤
      x * enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (marking I a x) (x ^ ε) := by
  have hW : ∀ n, 0 ≤ marking I a x n := fun n => (markingWeight_bounds I _ _ n hV).1
  have hsum : Summable (enlargedReciprocal (markedPrimes I a x)
      (unmarkedCofactors I a ε Y τ x) (marking I a x)) :=
    summable_enlargedReciprocal _ _ _ (unmarkedCofactors_avoid I a ε Y τ x) hW
      (summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have ht := WeightedTail.weighted_tail_le_enlarged_tail
    (discardedCofactors I a ε Y τ x)
    (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
    (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
    (marking I a x) (smoothWeight x) (c := c) (M := M) (u := u)
    (x := x) (X := x ^ ε) (by linarith) hc (by
      intro r hr
      obtain ⟨hs, hn⟩ := Finset.mem_sdiff.mp hr
      obtain ⟨hp, hu, ht⟩ := (mem_boundedCofactors _ _ _ r).mp hs
      refine ⟨hp, hu, lt_of_not_ge ?_⟩
      intro hle
      exact hn ((mem_boundedCofactors _ _ _ r).mpr ⟨hp, hu, hle⟩))
    hW hsum (fun Q hQ => (WeightSupport.mem_boundedLargePrimes.mp hQ).1.pos)
    (smoothWeight_bounds x) (smoothWeight_zero_above hx)
  have hg : ∀ i ∈ I, primeBand (a i) x ⊆ markedPrimes I a x := by
    intro i hi p hp
    exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩
  simpa only [discardedMass, marking, markingWeight_markedPart I _ _ _ _ hg] using ht

/-- The discarded mass is nonnegative; this retains the actual marking
rather than estimating it by a family-dependent supremum. -/
theorem discardedMass_nonneg {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    0 ≤ discardedMass I a c M u ε Y τ x := by
  apply Finset.sum_nonneg
  intro r hr
  exact mul_nonneg (markingWeight_bounds I _ _ r hV).1
    (primeProgressionSum_nonneg c M u _ _ (fun d => (smoothWeight_bounds x d).1) r)

/-- Arbitrary logarithmic accuracy for the actual discarded contribution,
now normalized by the original full invariant integer mass `X₀`.
Only the cited fixed-modulus PNT and the classical band bounds are inputs. -/
theorem actual_discardedMass_le_base_over_log_power
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∀ A η : ℝ, 0 < η → ∀ ε : ℝ, 0 < ε → ε ≤ 1 / 100 →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, ∀ᶠ x : ℝ in atTop,
        discardedMass I a c (c * M₀) (c * v + 1) ε Y τ x ≤
          η * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A := by
  have hlow : 0 < lowerConstant c M₀ :=
    (constants_positive c M₀ (by omega) (NeZero.pos M₀)).1
  intro A η hη ε hε hεmax Y hY τ
  filter_upwards [actual_tail_le_full_over_log_power I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical (A + 1) (η * lowerConstant c M₀)
      (mul_pos hη hlow) ε hε Y τ,
    actual_full_mass_comparison hPNT hc hu hv I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical ε hε hεmax Y hY τ,
    hclassical, eventually_ge_atTop (2 : ℝ)] with x htail hmass hVx hx
  have hx0 : 0 ≤ x := by linarith
  have hL : 0 < Real.log x := Real.log_pos (by linarith)
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hpow : (Real.log x) ^ (A + 1) = (Real.log x) ^ A * Real.log x := by
    rw [Real.rpow_add hL]; simp
  calc
    _ ≤ x * enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (marking I a x) (x ^ ε) :=
      discardedMass_le_reciprocal_tail I a c (c * M₀) (c * v + 1) ε Y τ x hx hc hV
    _ ≤ x * ((η * lowerConstant c M₀) * fullMass I a ε Y τ x /
        (Real.log x) ^ (A + 1)) := mul_le_mul_of_nonneg_left htail hx0
    _ = η * (lowerConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x) /
        (Real.log x) ^ A := by rw [hpow]; ring
    _ ≤ _ := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hmass.1 hη.le)
      (Real.rpow_pos_of_pos hL A).le

end Artin.ManuscriptTail
