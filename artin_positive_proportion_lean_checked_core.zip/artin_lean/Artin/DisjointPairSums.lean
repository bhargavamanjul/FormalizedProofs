module

public import Artin.BuchstabMR

/-!
# Disjoint box sums and prime-divisor conditioning

The finite union removes the dyadic decomposition before estimating the
conditioned mass. In particular the estimate has no factor counting boxes.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.DisjointPairSums

open RoughCompanion SemiprimeReplacement BuchstabMR

/-- The set of ordered factor pairs in a finite family of boxes. -/
noncomputable def boxUnion {J : Type*} (I : Finset J)
    (S T : J → Finset ℕ) : Finset (ℕ × ℕ) := by
  classical
  exact I.biUnion (fun j => S j ×ˢ T j)

/-- The weighted sum over an arbitrary finite set of factor pairs. -/
noncomputable def weightedPairs (P : Finset (ℕ × ℕ))
    (w α β : ℕ → ℝ) : ℝ :=
  ∑ p ∈ P, w (p.1 * p.2) * α p.1 * β p.2

theorem weightedPairs_product (s t : Finset ℕ) (w α β : ℕ → ℝ) :
    weightedPairs (s ×ˢ t) w α β = pairMass s t w α β := by
  simp only [weightedPairs, Finset.sum_product, pairMass]

/-- Pairwise disjoint boxes give an exact sum over their union. -/
theorem sum_pairMass_eq_union {J : Type*} (I : Finset J)
    (S T : J → Finset ℕ) (w α β : ℕ → ℝ)
    (hdisj : Set.PairwiseDisjoint (↑I) (fun j => S j ×ˢ T j)) :
    (∑ j ∈ I, pairMass (S j) (T j) w α β) =
      weightedPairs (boxUnion I S T) w α β := by
  classical
  unfold boxUnion weightedPairs
  rw [Finset.sum_biUnion hdisj]
  apply Finset.sum_congr rfl
  intro j hj
  exact (weightedPairs_product (S j) (T j) w α β).symm

/-- Coverage of the nonzero support is enough for comparison of two
finite nonnegative weighted sums. -/
theorem sum_le_of_support_cover {A : Type*} (P Q : Finset A) (F : A → ℝ)
    (hF : ∀ a, 0 ≤ F a)
    (hcover : ∀ a ∈ P, F a ≠ 0 → a ∈ Q) :
    (∑ a ∈ P, F a) ≤ ∑ a ∈ Q, F a := by
  classical
  let P' := P.filter (fun a => F a ≠ 0)
  have heq : (∑ a ∈ P, F a) = ∑ a ∈ P', F a := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro a ha
    split_ifs with h
    · rfl
    · exact not_ne_iff.mp h
  rw [heq]
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro a ha
    exact hcover a (Finset.mem_filter.mp ha).1 (Finset.mem_filter.mp ha).2
  · intro a ha hnot
    exact hF a

/-- A support cover by disjoint boxes bounds a source pair sum by the sum
of box masses. The cover need only include pairs with nonzero weight. -/
theorem weightedPairs_le_sum_pairMass {J : Type*} (P : Finset (ℕ × ℕ))
    (I : Finset J) (S T : J → Finset ℕ) (w α β : ℕ → ℝ)
    (hdisj : Set.PairwiseDisjoint (↑I) (fun j => S j ×ˢ T j))
    (hw : ∀ d, 0 ≤ w d) (hα : ∀ m, 0 ≤ α m) (hβ : ∀ n, 0 ≤ β n)
    (hcover : ∀ p ∈ P, w (p.1 * p.2) * α p.1 * β p.2 ≠ 0 →
      ∃ j ∈ I, p.1 ∈ S j ∧ p.2 ∈ T j) :
    weightedPairs P w α β ≤ ∑ j ∈ I, pairMass (S j) (T j) w α β := by
  classical
  rw [sum_pairMass_eq_union I S T w α β hdisj]
  apply sum_le_of_support_cover P (boxUnion I S T)
    (fun p => w (p.1 * p.2) * α p.1 * β p.2)
    (fun p => mul_nonneg (mul_nonneg (hw _) (hα _)) (hβ _))
  intro p hp hne
  obtain ⟨j, hj, hm, hn⟩ := hcover p hp hne
  exact Finset.mem_biUnion.mpr ⟨j, hj, Finset.mem_product.mpr ⟨hm, hn⟩⟩

/-- Remembering the prime divisor makes the factor-to-integer map
injective. Equality of the products alone would not suffice. -/
theorem divisor_product_injective {P : Finset (ℕ × ℕ)}
    (hpositive : ∀ p ∈ P, 0 < p.2) :
    Set.InjOn (fun p : ℕ × ℕ => (p.2, p.1 * p.2)) (↑P) := by
  intro p hp q hq heq
  have hn : p.2 = q.2 := congrArg Prod.fst heq
  have hm : p.1 = q.1 := by
    have he : p.1 * p.2 = q.1 * q.2 := congrArg Prod.snd heq
    rw [← hn] at he
    exact Nat.eq_of_mul_eq_mul_right (hpositive p hp) he
  exact Prod.ext hm hn

/-- Arbitrary finite factor pairs inject into the literal conditioned
integer sum. This is where the potential dyadic multiplicity disappears. -/
theorem weightedPairs_le_conditionedMass (P : Finset (ℕ × ℕ))
    (D T : Finset ℕ) (w : ℕ → ℝ) (y : ℝ)
    (hw : ∀ d, 0 ≤ w d)
    (hT : ∀ p ∈ P, p.2 ∈ T)
    (hrough : ∀ p ∈ P, p.2.Prime → MarkedCriterion.IsRough y p.2)
    (hsupport : ∀ p ∈ P, w (p.1 * p.2) ≠ 0 → p.1 * p.2 ∈ D) :
    weightedPairs P w (realRoughIndicator y) primeIndicator ≤
      conditionedMass D T w y := by
  classical
  let F : ℕ × ℕ → ℝ := fun p => w (p.1 * p.2) *
    realRoughIndicator y p.1 * primeIndicator p.2
  let P' := P.filter (fun p => F p ≠ 0)
  let Q := (T ×ˢ D).filter (fun q => q.1.Prime ∧ q.1 ∣ q.2)
  let G : ℕ × ℕ → ℝ := fun q => w q.2 * realRoughIndicator y q.2
  have hprime : ∀ p ∈ P', p.2.Prime := by
    intro p hp
    obtain ⟨hpP, hne⟩ := Finset.mem_filter.mp hp
    by_contra hh
    exact hne (by simp [F, primeIndicator, hh])
  have hFsum : weightedPairs P w (realRoughIndicator y) primeIndicator =
      ∑ p ∈ P', F p := by
    unfold weightedPairs
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro p hp
    change F p = if F p ≠ 0 then F p else 0
    split_ifs with h
    · rfl
    · exact not_ne_iff.mp h
  have hmap : P'.image (fun p => (p.2, p.1 * p.2)) ⊆ Q := by
    intro q hq
    obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hq
    obtain ⟨hpP, hne⟩ := Finset.mem_filter.mp hp
    have hwp : w (p.1 * p.2) ≠ 0 := by
      intro hz
      exact hne (by simp [F, hz])
    exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr
      ⟨hT p hpP, hsupport p hpP hwp⟩, hprime p hp, dvd_mul_left p.2 p.1⟩
  have hterm : ∀ p ∈ P', F p = G (p.2, p.1 * p.2) := by
    intro p hp
    have hpP := (Finset.mem_filter.mp hp).1
    have hpr := hprime p hp
    simp only [F, G, primeIndicator, ite_eq_left hpr, mul_one]
    rw [realRoughIndicator_mul_of_rough (hrough p hpP hpr)]
  have hinj := divisor_product_injective (P := P')
    (fun p hp => (hprime p hp).pos)
  have hQsum : (∑ q ∈ Q, G q) = conditionedMass D T w y := by
    unfold Q conditionedMass
    rw [Finset.sum_filter, Finset.sum_product]
    apply Finset.sum_congr rfl
    intro n hn
    by_cases hp : n.Prime
    · simp only [hp, true_and, ite_true]
      rw [Finset.sum_filter]
    · simp [hp]
  rw [hFsum]
  calc
    _ = ∑ p ∈ P', G (p.2, p.1 * p.2) := Finset.sum_congr rfl hterm
    _ = ∑ q ∈ P'.image (fun p => (p.2, p.1 * p.2)), G q :=
      (Finset.sum_image hinj).symm
    _ ≤ ∑ q ∈ Q, G q := Finset.sum_le_sum_of_subset_of_nonneg hmap
      (fun q _ _ => mul_nonneg (hw _) (realRoughIndicator_nonneg _ _))
    _ = _ := hQsum

/-- The total rough mass of disjoint boxes is bounded by a single
conditioned integer sum, with no factor equal to the number of boxes. -/
theorem sum_pairMass_le_conditionedMass {J : Type*} (I : Finset J)
    (S T : J → Finset ℕ) (D Tall : Finset ℕ) (w : ℕ → ℝ) (y : ℝ)
    (hdisj : Set.PairwiseDisjoint (↑I) (fun j => S j ×ˢ T j))
    (hw : ∀ d, 0 ≤ w d)
    (hT : ∀ j ∈ I, T j ⊆ Tall)
    (hrough : ∀ j ∈ I, ∀ n ∈ T j, n.Prime → MarkedCriterion.IsRough y n)
    (hsupport : ∀ j ∈ I, ∀ m ∈ S j, ∀ n ∈ T j,
      w (m * n) ≠ 0 → m * n ∈ D) :
    (∑ j ∈ I, pairMass (S j) (T j) w (realRoughIndicator y) primeIndicator) ≤
      conditionedMass D Tall w y := by
  classical
  rw [sum_pairMass_eq_union I S T w _ _ hdisj]
  apply weightedPairs_le_conditionedMass _ D Tall w y hw
  · intro p hp
    obtain ⟨j, hj, hp⟩ := Finset.mem_biUnion.mp hp
    exact hT j hj (Finset.mem_product.mp hp).2
  · intro p hp hprime
    obtain ⟨j, hj, hp⟩ := Finset.mem_biUnion.mp hp
    exact hrough j hj p.2 (Finset.mem_product.mp hp).2 hprime
  · intro p hp hne
    obtain ⟨j, hj, hp⟩ := Finset.mem_biUnion.mp hp
    obtain ⟨hm, hn⟩ := Finset.mem_product.mp hp
    exact hsupport j hj p.1 hm p.2 hn hne

end Artin.DisjointPairSums
