module

public import Artin.BuchstabPartition
public import Artin.SemiprimeMR

/-!
# Marked replacement in an actual Buchstab bin

The companion is the actual prime indicator. Its boundedness and rough
support are proved uniformly from the lower dyad scale. The source criterion
therefore supplies the displayed replacement error, which is not an input.
-/

@[expose] public section

open Filter
open scoped BigOperators

namespace Artin.BuchstabMR

open MarkedSource RoughCompanion SemiprimeReplacement SemiprimeMR

/-- The real-valued Buchstab replacement coefficient. -/
noncomputable def roughModel (γ x : ℝ) (m : ℕ) : ℝ :=
  density γ (Real.log m / Real.log x) / (Real.log x * eulerV (W x)) *
    realRoughIndicator (W x) m

theorem discrepancy_eq_rough_sub_model (γ x : ℝ) (m : ℕ) :
    discrepancy γ x m =
      ((realRoughIndicator (x ^ γ) m - roughModel γ x m : ℝ) : ℂ) := by
  unfold discrepancy MarkedCriterion.roughDiscrepancy roughModel
  rw [← realRoughIndicator_cast, ← realRoughIndicator_cast]
  push_cast
  rfl

/-- The source discrepancy sum is exactly the difference between the two
actual real weighted factor sums. -/
theorem discrepancy_sum_eq_difference (γ x : ℝ) (s t : Finset ℕ)
    (w β : ℕ → ℝ) :
    (∑ m ∈ s, ∑ n ∈ t,
      discrepancy γ x m * (β n : ℂ) * (w (m * n) : ℂ)) =
      ((pairMass s t w (realRoughIndicator (x ^ γ)) β -
        pairMass s t w (roughModel γ x) β : ℝ) : ℂ) := by
  unfold pairMass
  rw [← Finset.sum_sub_distrib]
  push_cast
  apply Finset.sum_congr rfl
  intro m hm
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  rw [discrepancy_eq_rough_sub_model]
  push_cast
  ring

/-- The prime companion gives a valid MR application on every active dyad,
with a common error constant and threshold. -/
theorem bin_error_of_MRFamily {J : Type} {K M : ℕ} (b : Bands K)
    (u : ℕ) (hu : u < M) (Ψ : ℝ → ℝ) (γ δ c₁ c₂ : ℝ) (hδ : 0 < δ)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hMR : UniformMRFamily b M (u : ZMod M) (fun y => (Ψ y : ℂ))
      γ 6 Hm Hn active) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
            (realRoughIndicator (x ^ γ)) primeIndicator -
          pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
            (roughModel γ x) primeIndicator| ≤ C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨C, hC, herror⟩ := actualArithmeticWeight_MRFamily b u hu Ψ γ 6
    Hm Hn active hMR
  refine ⟨C, hC, ?_⟩
  filter_upwards [herror, hscale, eventually_prime_boundedRough hδ]
    with x hx hsc hprime
  intro j hj s t hs ht c allowed Qmin
  have htlow : ∀ n ∈ t, x ^ δ ≤ (n : ℝ) :=
    fun n hn => (hsc j hj).2.2.2.1.trans (ht n hn).1
  have h := hx j hj s t hs ht (fun n => (primeIndicator n : ℂ))
    (hprime t htlow) c allowed Qmin
  change ‖∑ m ∈ s, ∑ n ∈ t, discrepancy γ x m * (primeIndicator n : ℂ) *
    (actualWeight b M u Ψ x c allowed Qmin (m * n) : ℂ)‖ ≤ _ at h
  rw [discrepancy_sum_eq_difference, Complex.norm_real, Real.norm_eq_abs] at h
  exact h

/-- The exact cited-source-to-bin-error deduction. The number of marks is
chosen before the dyad family, and the bound is uniform over all interval
subboxes and all invariant cofactor selectors. -/
theorem bin_error_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨ : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (γ sLo sHi δ c₁ c₂ : ℝ)
    (hγ : 0 < γ) (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active →
      (∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        sLo ≤ Real.log (Hm x j) / Real.log x ∧
        Real.log (2 * Hm x j) / Real.log x ≤ sHi) →
      ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
          |pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
              (realRoughIndicator (x ^ γ)) primeIndicator -
            pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
              (roughModel γ x) primeIndicator| ≤
            C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := uniformMRFamilies_of_sources h102 h103 hbands hFourier
    M (u : ZMod M) hunit (fun y => (Ψ y : ℂ)) hΨ
    γ sLo sHi δ c₁ c₂ hγ hγs hs hs1 hδ hc₁ hc₂
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b J Hm Hn active hscale hexp
  exact bin_error_of_MRFamily b u hu Ψ γ δ c₁ c₂ hδ Hm Hn active hscale
    (hK K hKK b J Hm Hn active hscale hexp)

/-- The logarithmic displacement caused by `x ≤ mn ≤ 2x`, with both
factors positive. The upper error is the actual `log 2 / log x`. -/
theorem factor_log_displacement {x m n : ℝ} (hx : 1 < x)
    (hm : 0 < m) (hn : 0 < n) (hlow : x ≤ m * n) (hupp : m * n ≤ 2 * x) :
    0 ≤ Real.log m / Real.log x - (1 - Real.log n / Real.log x) ∧
      Real.log m / Real.log x - (1 - Real.log n / Real.log x) ≤
        Real.log 2 / Real.log x := by
  have hL : 0 < Real.log x := Real.log_pos hx
  have hx0 : 0 < x := by linarith
  have hl := Real.log_le_log hx0 hlow
  rw [Real.log_mul hm.ne' hn.ne'] at hl
  have hu := Real.log_le_log (mul_pos hm hn) hupp
  rw [Real.log_mul hm.ne' hn.ne', Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hx0.ne'] at hu
  have hsum : Real.log m / Real.log x + Real.log n / Real.log x =
      (Real.log m + Real.log n) / Real.log x := by ring
  have hlo : 1 ≤ Real.log m / Real.log x + Real.log n / Real.log x := by
    rw [hsum, le_div_iff₀ hL, one_mul]
    exact hl
  have hhi : Real.log m / Real.log x + Real.log n / Real.log x ≤
      1 + Real.log 2 / Real.log x := by
    rw [hsum, div_le_iff₀ hL]
    calc
      _ ≤ Real.log 2 + Real.log x := hu
      _ = _ := by field_simp; ring
  constructor <;> linarith

/-- Continuity makes the density replacement uniform over *all* products
in the support and all prime locations in one fixed bin. This proves the
small displacement step rather than assuming a density-error estimate. -/
theorem eventually_density_bin_majorant {γ γ' C η : ℝ}
    (hη : 0 < η)
    (hcont : ContinuousOn (density γ) (Set.Icc (1 - γ') (2 - γ)))
    (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C) :
    ∀ᶠ x : ℝ in atTop, ∀ m n : ℝ,
      0 < m → 0 < n → x ≤ m * n → m * n ≤ 2 * x →
      x ^ γ ≤ n → n ≤ x ^ γ' → density γ (Real.log m / Real.log x) ≤ C + η := by
  have huc := isCompact_Icc.uniformContinuousOn_of_continuous hcont
  obtain ⟨δ, hδ, hclose⟩ := (Metric.uniformContinuousOn_iff_le.mp huc) η hη
  have hratio : Tendsto (fun x : ℝ => Real.log 2 / Real.log x) atTop (nhds 0) :=
    tendsto_const_nhds.div_atTop Real.tendsto_log_atTop
  have hsmall : ∀ᶠ x : ℝ in atTop, Real.log 2 / Real.log x < min δ 1 :=
    (tendsto_order.1 hratio).2 _ (lt_min hδ (by norm_num))
  filter_upwards [hsmall, eventually_gt_atTop (1 : ℝ)] with x hs hx
  intro m n hm hn hprod hprod' hnlo hnhi
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx
  have hnlog : Real.log n / Real.log x ∈ Set.Icc γ γ' := by
    constructor
    · apply (le_div_iff₀ hL).mpr
      have h := Real.log_le_log (Real.rpow_pos_of_pos hx0 γ) hnlo
      simpa only [Real.log_rpow hx0] using h
    · apply (div_le_iff₀ hL).mpr
      have h := Real.log_le_log hn hnhi
      simpa only [Real.log_rpow hx0] using h
  have hd := factor_log_displacement hx hm hn hprod hprod'
  have hv : 1 - Real.log n / Real.log x ∈ Set.Icc (1 - γ') (2 - γ) := by
    constructor <;> linarith [hnlog.1, hnlog.2]
  have hu : Real.log m / Real.log x ∈ Set.Icc (1 - γ') (2 - γ) := by
    constructor
    · linarith [hnlog.2, hd.1]
    · have hs1 := hs.trans_le (min_le_right δ 1)
      linarith [hnlog.1, hd.2]
  have hdist : dist (Real.log m / Real.log x) (1 - Real.log n / Real.log x) ≤ δ := by
    rw [Real.dist_eq, abs_of_nonneg hd.1]
    exact hd.2.trans ((hs.trans_le (min_le_left δ 1)).le)
  have he := hclose _ hu _ hv hdist
  rw [Real.dist_eq] at he
  linarith [(abs_le.mp he).2, hbin _ hnlog]

/-- The standard continuity input names the actual simplex density and its
natural open domain; it contains no assertion about arithmetic bin counts. -/
def ClassicalDensityContinuity : Prop :=
  ∀ γ : ℝ, 0 < γ → ContinuousOn (density γ) (Set.Ioi γ)

theorem eventually_density_bin_majorant_from_classical
    (hcontinuity : ClassicalDensityContinuity) {γ γ' C η : ℝ}
    (hγ : 0 < γ) (hgap : γ + γ' < 1) (hη : 0 < η)
    (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C) :
    ∀ᶠ x : ℝ in atTop, ∀ m n : ℝ,
      0 < m → 0 < n → x ≤ m * n → m * n ≤ 2 * x →
      x ^ γ ≤ n → n ≤ x ^ γ' → density γ (Real.log m / Real.log x) ≤ C + η := by
  apply eventually_density_bin_majorant hη _ hbin
  apply (hcontinuity γ hγ).mono
  intro s hs
  change γ < s
  linarith [hs.1]

/-- The density majorant multiplies the actual conditioned rough mass.
No bound on the size of the marked weight is introduced. -/
theorem model_pairMass_le (s t : Finset ℕ) (w : ℕ → ℝ) {γ x C : ℝ}
    (hden : 0 < Real.log x * eulerV (W x)) (hw : ∀ d, 0 ≤ w d)
    (hD : ∀ m ∈ s, ∀ n ∈ t, w (m * n) ≠ 0 →
      density γ (Real.log m / Real.log x) ≤ C) :
    pairMass s t w (roughModel γ x) primeIndicator ≤
      C / (Real.log x * eulerV (W x)) *
        pairMass s t w (realRoughIndicator (W x)) primeIndicator := by
  unfold pairMass
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro m hm
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro n hn
  by_cases hz : w (m * n) = 0
  · simp [hz]
  · have hprime0 : 0 ≤ primeIndicator n := by
      unfold primeIndicator
      split <;> norm_num
    have hfactor : 0 ≤ w (m * n) * realRoughIndicator (W x) m * primeIndicator n :=
      mul_nonneg (mul_nonneg (hw _) (realRoughIndicator_nonneg _ _)) hprime0
    have hq := div_le_div_of_nonneg_right (hD m hm n hn hz) hden.le
    unfold roughModel
    calc
      _ = (w (m * n) * realRoughIndicator (W x) m * primeIndicator n) *
          (density γ (Real.log m / Real.log x) / (Real.log x * eulerV (W x))) := by ring
      _ ≤ (w (m * n) * realRoughIndicator (W x) m * primeIndicator n) *
          (C / (Real.log x * eulerV (W x))) := mul_le_mul_of_nonneg_left hq hfactor
      _ = _ := by ring

theorem actualWeight_product_support {K M : ℕ} (b : Bands K) (u : ℕ)
    (Ψ : ℝ → ℝ) (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {x : ℝ} (hx : 0 < x) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) {d : ℕ}
    (hweight : actualWeight b M u Ψ x c allowed Qmin d ≠ 0) :
    x ≤ (d : ℝ) ∧ (d : ℝ) ≤ 2 * x := by
  have hψ : Ψ ((d : ℝ) / x) ≠ 0 := by
    intro hz
    unfold actualWeight ConcreteSelector.arithmeticWeight at hweight
    split_ifs at hweight <;> simp_all
  have hmem : (d : ℝ) / x ∈ Set.Icc (1 : ℝ) 2 := by
    by_contra hh
    exact hψ (hsupport _ hh)
  exact ⟨by simpa only [one_mul] using (le_div_iff₀ hx).mp hmem.1,
    (div_le_iff₀ hx).mp hmem.2⟩

/-- Nonnegativity of the actual marked arithmetic weight holds uniformly
for all cofactors and selectors after the ordinary band-mass threshold. -/
theorem eventually_actualWeight_nonneg (hbands : ClassicalBandMass)
    {K M : ℕ} (b : Bands K) (u : ℕ) (Ψ : ℝ → ℝ)
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1) :
    ∀ᶠ x : ℝ in atTop, ∀ c allowed Qmin d,
      0 ≤ actualWeight b M u Ψ x c allowed Qmin d := by
  filter_upwards [hbands K b] with x hx c allowed Qmin d
  apply (ConcreteSelector.arithmeticWeight_bounds M u (fun d => Ψ ((d : ℝ) / x))
    Finset.univ (b.group x) (b.mass x) (b.primes x) c allowed Qmin d
    (hΨ _) ?_).1
  intro i hi
  exact (div_pos (Real.log_pos (by norm_num : (1 : ℝ) < 2)) (by norm_num)).trans_le (hx i)

/-- The bin bound after marked replacement and density continuity. Its main
term is the actual conditioned `W`-rough prime-divisor sum. This is uniform
over all active dyads and cofactor selectors. The remaining sieve task is
to estimate this conditioned sum and to assemble the actual dyadic cover. -/
theorem bin_upper_of_MRFamily {J : Type} {K M : ℕ} (b : Bands K)
    (u : ℕ) (hu : u < M) (Ψ : ℝ → ℝ)
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    (hbands : ClassicalBandMass) (hcontinuity : ClassicalDensityContinuity)
    (γ γ' δ c₁ c₂ C₀ η : ℝ) (hγ : 0 < γ) (hgap : γ + γ' < 1)
    (hδ : 0 < δ) (hη : 0 < η)
    (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C₀)
    (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop)
    (hscale : ScaleFamily δ c₁ c₂ Hm Hn active)
    (hMR : UniformMRFamily b M (u : ZMod M) (fun y => (Ψ y : ℂ))
      γ 6 Hm Hn active) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
      ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
      (∀ n ∈ t, x ^ γ ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ') →
      ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
        pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
            (realRoughIndicator (x ^ γ)) primeIndicator ≤
          (C₀ + η) / (Real.log x * eulerV (W x)) *
            pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
              (realRoughIndicator (W x)) primeIndicator +
          C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨C, hC, herror⟩ := bin_error_of_MRFamily b u hu Ψ γ δ c₁ c₂ hδ
    Hm Hn active hscale hMR
  refine ⟨C, hC, ?_⟩
  filter_upwards [herror, hscale, eventually_actualWeight_nonneg hbands b u Ψ hΨ,
    eventually_density_bin_majorant_from_classical hcontinuity hγ hgap hη hbin,
    eventually_gt_atTop (1 : ℝ)] with x herr hsc hw hD hx
  intro j hj s t hs ht htbin c allowed Qmin
  have hw' := hw c allowed Qmin
  have hmodel := model_pairMass_le s t (actualWeight b M u Ψ x c allowed Qmin)
    (γ := γ) (C := C₀ + η) (mul_pos (Real.log_pos hx) (eulerV_pos _)) hw' (by
      intro m hm n hn hwne
      have hm1 : (1 : ℝ) ≤ m := (hsc j hj).1.trans (hs.inDyad m hm).1
      have hn1 : (1 : ℝ) ≤ n := (hsc j hj).2.1.trans (ht n hn).1
      have hprod := actualWeight_product_support b u Ψ hsupport
        (by linarith : 0 < x) c allowed Qmin hwne
      have hprod' : x ≤ (m : ℝ) * n ∧ (m : ℝ) * n ≤ 2 * x := by
        simpa only [Nat.cast_mul] using hprod
      exact hD m n (by linarith) (by linarith) hprod'.1 hprod'.2
        (htbin n hn).1 (htbin n hn).2)
  have he := (abs_le.mp (herr j hj s t hs ht c allowed Qmin)).2
  linarith

theorem isRough_mul_iff (y : ℝ) (m n : ℕ) :
    MarkedCriterion.IsRough y (m * n) ↔
      MarkedCriterion.IsRough y m ∧ MarkedCriterion.IsRough y n := by
  constructor
  · intro h
    exact ⟨fun p hp hpm => h p hp (hpm.trans (dvd_mul_right m n)),
      fun p hp hpn => h p hp (hpn.trans (dvd_mul_left n m))⟩
  · rintro ⟨hm, hn⟩ p hp hpd
    rcases hp.dvd_mul.mp hpd with hpm | hpn
    · exact hm p hp hpm
    · exact hn p hp hpn

theorem realRoughIndicator_mul_of_rough {y : ℝ} {n : ℕ}
    (hn : MarkedCriterion.IsRough y n) (m : ℕ) :
    realRoughIndicator y (m * n) = realRoughIndicator y m := by
  classical
  simp only [realRoughIndicator, isRough_mul_iff, hn, and_true]

/-- A fixed positive prime divisor introduces no multiplicity in the
complementary variable. Only the nonzero support must belong to the ambient
integer set. -/
theorem sum_multiples_le (s D : Finset ℕ) (F : ℕ → ℝ) {n : ℕ}
    (hn : 0 < n) (hF : ∀ d, 0 ≤ F d)
    (hsupport : ∀ m ∈ s, F (m * n) ≠ 0 → m * n ∈ D) :
    (∑ m ∈ s, F (m * n)) ≤ ∑ d ∈ D.filter (fun d => n ∣ d), F d := by
  classical
  let s' := s.filter (fun m => F (m * n) ≠ 0)
  have hsum : (∑ m ∈ s, F (m * n)) = ∑ m ∈ s', F (m * n) := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro m hm
    split_ifs with hne
    · rfl
    · exact not_ne_iff.mp hne
  have hinj : Set.InjOn (fun m : ℕ => m * n) (↑s' : Set ℕ) := by
    intro m hm m' hm' heq
    exact Nat.eq_of_mul_eq_mul_right hn heq
  have hsub : s'.image (fun m => m * n) ⊆ D.filter (fun d => n ∣ d) := by
    intro d hd
    obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hd
    obtain ⟨hms, hmne⟩ := Finset.mem_filter.mp hm
    exact Finset.mem_filter.mpr ⟨hsupport m hms hmne, dvd_mul_left n m⟩
  rw [hsum, ← Finset.sum_image hinj]
  exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun d _ _ => hF d)

/-- The actual prime-divisor-conditioned rough sum on an ambient integer
set. This is the quantity estimated by the conditioned block sieve. -/
noncomputable def conditionedMass (D t : Finset ℕ) (w : ℕ → ℝ) (y : ℝ) : ℝ :=
  ∑ n ∈ t, if n.Prime then
    ∑ d ∈ D.filter (fun d => n ∣ d), w d * realRoughIndicator y d else 0

/-- The conditioned sum in the MR bound is bounded by the literal
prime-divisor-conditioned integer sum, without a multiplicity factor. -/
theorem rough_pairMass_le_conditionedMass (s t D : Finset ℕ) (w : ℕ → ℝ) (y : ℝ)
    (hw : ∀ d, 0 ≤ w d)
    (ht : ∀ n ∈ t, n.Prime → MarkedCriterion.IsRough y n)
    (hsupport : ∀ m ∈ s, ∀ n ∈ t, w (m * n) ≠ 0 → m * n ∈ D) :
    pairMass s t w (realRoughIndicator y) primeIndicator ≤ conditionedMass D t w y := by
  classical
  unfold pairMass conditionedMass
  rw [Finset.sum_comm]
  apply Finset.sum_le_sum
  intro n hn
  by_cases hp : n.Prime
  · simp only [primeIndicator, ite_eq_left hp, mul_one]
    have hr := ht n hn hp
    have heq : (∑ m ∈ s, w (m * n) * realRoughIndicator y m) =
        ∑ m ∈ s, w (m * n) * realRoughIndicator y (m * n) := by
      apply Finset.sum_congr rfl
      intro m hm
      rw [realRoughIndicator_mul_of_rough hr]
    rw [heq]
    apply sum_multiples_le s D (fun d => w d * realRoughIndicator y d) hp.pos
      (fun d => mul_nonneg (hw d) (realRoughIndicator_nonneg y d))
    intro m hm hne
    apply hsupport m hm n hn
    exact fun hz => hne (by simp [hz])
  · simp [primeIndicator, hp]

/-- Summing the simultaneous replacement errors costs only the number of
actual dyads. This is valid for a growing finite family. -/
theorem finite_replacement_error {J : Type*} (I : Finset J)
    (original model : J → ℝ) {E : ℝ}
    (herror : ∀ j ∈ I, |original j - model j| ≤ E) :
    |(∑ j ∈ I, original j) - ∑ j ∈ I, model j| ≤ (I.card : ℝ) * E := by
  rw [← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ j ∈ I, |original j - model j| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _j ∈ I, E := Finset.sum_le_sum herror
    _ = _ := by simp

/-- The advertised loss of one power of the logarithm when the dyadic
cover has `O(log x)` members. The identity uses real powers throughout. -/
theorem finite_replacement_error_log {J : Type*} (I : Finset J)
    (original model : J → ℝ) {A C x : ℝ}
    (hx : 1 < x) (hC : 0 ≤ C) (hcard : (I.card : ℝ) ≤ A * Real.log x)
    (herror : ∀ j ∈ I, |original j - model j| ≤ C * x * (Real.log x) ^ (-6 : ℝ)) :
    |(∑ j ∈ I, original j) - ∑ j ∈ I, model j| ≤
      A * C * x * (Real.log x) ^ (-5 : ℝ) := by
  have hL : 0 < Real.log x := Real.log_pos hx
  have he : 0 ≤ C * x * (Real.log x) ^ (-6 : ℝ) := by positivity
  apply (finite_replacement_error I original model herror).trans
  calc
    _ ≤ (A * Real.log x) * (C * x * (Real.log x) ^ (-6 : ℝ)) :=
      mul_le_mul_of_nonneg_right hcard he
    _ = A * C * x * (Real.log x) ^ (-5 : ℝ) := by
      have hp : Real.log x * (Real.log x) ^ (-6 : ℝ) =
          (Real.log x) ^ (-5 : ℝ) := by
        simpa only [Real.rpow_one, show (1 : ℝ) + -6 = -5 by norm_num] using
          (Real.rpow_add hL (1 : ℝ) (-6 : ℝ)).symm
      calc
        _ = A * C * x * (Real.log x * (Real.log x) ^ (-6 : ℝ)) := by ring
        _ = _ := by rw [hp]

/-- The complete source-to-bin main-term reduction for fixed source exponent
windows. The source facts choose `K₀` before the growing dyad family and
before the density-continuity tolerance. No marked replacement error is a
premise of this theorem. -/
theorem bin_upper_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hcontinuity : ClassicalDensityContinuity)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨsmooth : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    (γ γ' sLo sHi δ c₁ c₂ C₀ : ℝ)
    (hγ : 0 < γ) (hgap : γ + γ' < 1)
    (hγs : γ < sLo) (hs : sLo < sHi) (hs1 : sHi < 1)
    (hδ : 0 < δ) (hc₁ : 0 < c₁) (hc₂ : 0 < c₂)
    (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C₀) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∀ (J : Type) (Hm Hn : ℝ → J → ℝ) (active : ℝ → J → Prop),
      ScaleFamily δ c₁ c₂ Hm Hn active →
      (∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        sLo ≤ Real.log (Hm x j) / Real.log x ∧
        Real.log (2 * Hm x j) / Real.log x ≤ sHi) →
      ∀ η : ℝ, 0 < η →
      ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, ∀ j, active x j →
        ∀ s t : Finset ℕ, IntervalInDyad (Hm x j) s → InDyad (Hn x j) t →
        (∀ n ∈ t, x ^ γ ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ γ') →
        ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ),
          pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
              (realRoughIndicator (x ^ γ)) primeIndicator ≤
            (C₀ + η) / (Real.log x * eulerV (W x)) *
              pairMass s t (actualWeight b M u Ψ x c allowed Qmin)
                (realRoughIndicator (W x)) primeIndicator +
            C * x * (Real.log x) ^ (-6 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := uniformMRFamilies_of_sources h102 h103 hbands hFourier
    M (u : ZMod M) hunit (fun y => (Ψ y : ℂ)) hΨsmooth
    γ sLo sHi δ c₁ c₂ hγ hγs hs hs1 hδ hc₁ hc₂
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK b J Hm Hn active hscale hexp η hη
  exact bin_upper_of_MRFamily b u hu Ψ hΨ hsupport hbands hcontinuity
    γ γ' δ c₁ c₂ C₀ η hγ hgap hδ hη hbin Hm Hn active hscale
    (hK K hKK b J Hm Hn active hscale hexp)

end Artin.BuchstabMR
