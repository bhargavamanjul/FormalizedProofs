module

public import Artin.MarkedCofactorEstimate
public import Artin.WeightSupport

/-!
# Actual prime support at the marked and unmarked scales

The prime-band endpoints imply that every marked prime eventually exceeds
any fixed bound and lies below every fixed positive power of `x`.  The
unmarked cofactor prime bounds follow directly from their defining finite
prime set.  No distribution theorem is used in these support statements.
-/

@[expose] public section

open Filter

namespace Artin.MarkedScaleSupport

open MarkedBandTail MarkedCofactorEstimate

/-- Sublinear powers of `log x` give endpoints smaller than any positive
power of `x`. -/
theorem eventual_band_upper (a δ : ℝ) (ha : a < 1) (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop, Real.exp (2 * (Real.log x) ^ a) ≤ x ^ δ := by
  have hgrowth : Tendsto (fun x : ℝ => (Real.log x) ^ (1 - a)) atTop atTop :=
    (tendsto_rpow_atTop (sub_pos.mpr ha)).comp Real.tendsto_log_atTop
  filter_upwards [hgrowth.eventually (eventually_ge_atTop (2 / δ)),
    eventually_gt_atTop (1 : ℝ)] with x hg hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have htwo : 2 ≤ δ * (Real.log x) ^ (1 - a) := by
    have h := (div_le_iff₀ hδ).mp hg
    simpa only [mul_comm] using h
  rw [Real.rpow_def_of_pos (zero_lt_one.trans hx)]
  apply Real.exp_le_exp.mpr
  calc
    2 * (Real.log x) ^ a ≤ (δ * (Real.log x) ^ (1 - a)) * (Real.log x) ^ a :=
      mul_le_mul_of_nonneg_right htwo (Real.rpow_nonneg hL.le a)
    _ = Real.log x * δ := by
      rw [mul_assoc, ← Real.rpow_add hL]
      simp
      ring

/-- All actual marked primes eventually lie between any fixed lower
bound and any fixed positive power of `x`. -/
theorem eventual_marked_prime_bounds {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax F δ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hδ : 0 < δ)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) :
    ∀ᶠ x : ℝ in atTop, ∀ p ∈ markedPrimes I a x,
      p.Prime ∧ F < (p : ℝ) ∧ (p : ℝ) ≤ x ^ δ := by
  have hlower : Tendsto (fun x : ℝ => Real.exp ((Real.log x) ^ amin)) atTop atTop :=
    Real.tendsto_exp_atTop.comp ((tendsto_rpow_atTop hmin).comp Real.tendsto_log_atTop)
  filter_upwards [hlower.eventually (eventually_gt_atTop F),
    eventual_band_upper amax δ hmax hδ,
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop (1 : ℝ))] with x hlo hup hL
  intro p hp
  have hh := union_band_endpoints I a amin amax x hL ha p hp
  exact ⟨hh.1, hlo.trans_le hh.2.1, hh.2.2.trans hup⟩

/-- A prime dividing an actual unmarked cofactor lies in the defining
interval and is absent from the marked bands. -/
theorem unmarked_prime_divisor_bounds {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) {r p : ℕ} (hr : r ∈ unmarkedCofactors I a ε Y τ x)
    (hp : p.Prime) (hpr : p ∣ r) :
    Y < (p : ℝ) ∧ (p : ℝ) ≤ Real.exp (ε * Real.log x / 8) ∧
      p ∉ markedPrimes I a x := by
  have hm := CofactorAsymptotics.prime_dvd_cofactor_mem
    (CofactorAsymptotics.scalePrimes (markedPrimes I a) ε Y x)
    (fun q hq => CofactorAsymptotics.unmarkedPrimes_prime _ _ _ hq)
    (Real.exp (ε * Real.log x / 2)) τ hr hp hpr
  exact (Finset.mem_filter.mp hm).2.2

/-- Exponential and real-power notation define the same unmarked cutoff. -/
theorem unmarked_cutoff_eq_rpow {x : ℝ} (hx : 0 < x) (ε : ℝ) :
    Real.exp (ε * Real.log x / 8) = x ^ (ε / 8) := by
  rw [Real.rpow_def_of_pos hx]
  congr 1
  ring

/-- The exact support statement in real-power notation. -/
theorem unmarked_prime_divisor_bounds_rpow {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ : ℝ) {x : ℝ} (hx : 0 < x) {r p : ℕ}
    (hr : r ∈ unmarkedCofactors I a ε Y τ x) (hp : p.Prime) (hpr : p ∣ r) :
    Y < (p : ℝ) ∧ (p : ℝ) ≤ x ^ (ε / 8) ∧ p ∉ markedPrimes I a x := by
  simpa only [unmarked_cutoff_eq_rpow hx] using
    unmarked_prime_divisor_bounds I a ε Y τ x hr hp hpr

/-- Unmarked cofactors have the same prime-factor bound at any larger
exponent, including the common support bound used for reindexing. -/
theorem unmarked_prime_divisor_le {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ δ : ℝ) {x : ℝ} (hx : 1 ≤ x) (hεδ : ε / 8 ≤ δ) {r p : ℕ}
    (hr : r ∈ unmarkedCofactors I a ε Y τ x) (hp : p.Prime) (hpr : p ∣ r) :
    (p : ℝ) ≤ x ^ δ :=
  (unmarked_prime_divisor_bounds_rpow I a ε Y τ (zero_lt_one.trans_le hx) hr hp hpr).2.1.trans
    (Real.rpow_le_rpow_of_exponent_le hx hεδ)

/-- The prime-factor formulation used in support arguments is a direct
consequence of the divisor formulation. -/
theorem unmarked_primeFactors_bounds {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ : ℝ) {x : ℝ} (hx : 0 < x) {r p : ℕ}
    (hr : r ∈ unmarkedCofactors I a ε Y τ x) (hp : p ∈ r.primeFactors) :
    Y < (p : ℝ) ∧ (p : ℝ) ≤ x ^ (ε / 8) ∧ p ∉ markedPrimes I a x :=
  unmarked_prime_divisor_bounds_rpow I a ε Y τ hx hr
    (Nat.prime_of_mem_primeFactors hp) (Nat.dvd_of_mem_primeFactors hp)

/-- Each prime band is contained in the actual marked-prime union. -/
theorem primeBand_subset_markedPrimes {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (x : ℝ) {i : ι} (hi : i ∈ I) : primeBand (a i) x ⊆ markedPrimes I a x := by
  intro p hp
  exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩

/-- The unmarked cofactor family supplies the exact positivity and
avoidance hypotheses of exhaustive predecessor reindexing. -/
theorem unmarked_positive_avoid {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      0 < r ∧ ∀ p ∈ markedPrimes I a x, ¬ p ∣ r := by
  intro r hr
  have hh := unmarkedCofactors_avoid I a ε Y τ x r hr
  exact ⟨Nat.pos_of_ne_zero hh.1, hh.2⟩

/-- Marked primes eventually avoid any fixed positive coefficient. -/
theorem eventual_marked_not_dvd {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (c : ℕ) (hc : 0 < c) :
    ∀ᶠ x : ℝ in atTop, ∀ p ∈ markedPrimes I a x, ¬ p ∣ c := by
  filter_upwards [eventual_marked_prime_bounds I a amin amax c 1 hmin hmax
    (by norm_num) ha] with x hx
  intro p hp hpc
  have hle : (p : ℝ) ≤ c := by exact_mod_cast Nat.le_of_dvd hc hpc
  exact (not_lt_of_ge hle) (hx p hp).2.1

/-- Every actual enlarged cofactor is eventually a unit modulo a fixed
positive modulus below `Y`, uniformly in its finite size cutoff. -/
theorem eventual_enlarged_coprime {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax ε Y τ : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (M : ℕ)
    (hM : 0 < M) (hMY : (M : ℝ) ≤ Y) :
    ∀ᶠ x : ℝ in atTop, ∀ X : ℝ, ∀ r ∈
      MarkedCofactorEstimate.boundedCofactors (markedPrimes I a x)
        (unmarkedCofactors I a ε Y τ x) X, r.Coprime M := by
  filter_upwards [eventual_marked_prime_bounds I a amin amax Y 1 hmin hmax
    (by norm_num) ha] with x hx
  intro X r hr
  exact WeightSupport.marked_boundedCofactors_coprime hM hMY
    (fun p hp => (hx p hp).2.1)
    (fun u hu p hp hpu => (unmarked_prime_divisor_bounds I a ε Y τ x hu hp hpu).1) hr

/-- The complete enlarged cofactor, including every marked prime power,
has no prime divisor above `x^δ`; the statement is uniform in its cutoff. -/
theorem eventual_enlarged_prime_bound {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax ε Y τ δ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hδ : 0 < δ)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hεδ : ε / 8 ≤ δ) :
    ∀ᶠ x : ℝ in atTop, ∀ X : ℝ, ∀ r ∈
      MarkedCofactorEstimate.boundedCofactors (markedPrimes I a x)
        (unmarkedCofactors I a ε Y τ x) X,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ x ^ δ := by
  filter_upwards [eventual_marked_prime_bounds I a amin amax Y δ hmin hmax hδ ha,
    eventually_ge_atTop (1 : ℝ)] with x hx hxone
  intro X r hr p hp hpr
  exact WeightSupport.marked_boundedCofactors_prime_bound
    (fun q hq => (hx q hq).2.2)
    (fun u hu q hq hqu => unmarked_prime_divisor_le I a ε Y τ δ hxone hεδ hu hq hqu)
    hr p hp hpr

end Artin.MarkedScaleSupport
