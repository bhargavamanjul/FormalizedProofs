module

public import Artin.SmallIndexUnion

/-!
# The reciprocal-prime tail from Chebyshev's bound

The proof is finite. Split a prime set at twice its least member, use
Chebyshev for the lower block, and induct on the strict upper subset.
This proves the reciprocal tail with the absolute constant `8 * log 4`.
-/

@[expose] public section

namespace Artin

open scoped BigOperators

private theorem reciprocal_prime_block_bound (s : Finset ℕ) {r : ℝ}
    (hr : 2 ≤ r) (hprime : ∀ q ∈ s, q.Prime)
    (hlower : ∀ q ∈ s, r ≤ (q : ℝ))
    (hupper : ∀ q ∈ s, (q : ℝ) ≤ 2 * r) :
    ∑ q ∈ s, 1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤
      4 * Real.log 4 / (r * Real.log r) := by
  have hr0 : 0 < r := by linarith
  have hlr : 0 < Real.log r := Real.log_pos (by linarith)
  have hco : 0 ≤ 2 / (r ^ 2 * Real.log r) := by positivity
  calc
    ∑ q ∈ s, 1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤
        ∑ q ∈ s, (2 / (r ^ 2 * Real.log r)) * Real.log (q : ℝ) := by
      apply Finset.sum_le_sum
      intro q hq
      have hqr := hlower q hq
      have hq2 : 2 ≤ (q : ℝ) := hr.trans hqr
      have hq0 : 0 < (q : ℝ) := by linarith
      have hd : 0 < (q : ℝ) * ((q : ℝ) - 1) :=
        mul_pos hq0 (by linarith)
      have hsq : r ^ 2 ≤ (q : ℝ) ^ 2 := by nlinarith
      have hden : r ^ 2 ≤ 2 * ((q : ℝ) * ((q : ℝ) - 1)) := by
        nlinarith [mul_nonneg (show 0 ≤ (q : ℝ) by positivity)
          (show 0 ≤ (q : ℝ) - 2 by linarith)]
      have hlog : Real.log r ≤ Real.log (q : ℝ) := Real.log_le_log hr0 hqr
      calc
        1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤ 2 / r ^ 2 := by
          apply (div_le_div_iff₀ hd (by positivity)).2
          nlinarith
        _ = (2 / (r ^ 2 * Real.log r)) * Real.log r := by
          field_simp
        _ ≤ _ := mul_le_mul_of_nonneg_left hlog hco
    _ = (2 / (r ^ 2 * Real.log r)) * (∑ q ∈ s, Real.log (q : ℝ)) := by
      rw [Finset.mul_sum]
    _ ≤ (2 / (r ^ 2 * Real.log r)) * (Real.log 4 * (2 * r)) :=
      mul_le_mul_of_nonneg_left
        (sum_log_primes_le s (by positivity) hprime hupper) hco
    _ = 4 * Real.log 4 / (r * Real.log r) := by
      field_simp
      ring

private theorem reciprocal_prime_tail_le (s : Finset ℕ) :
    ∀ Y : ℝ, 1 < Y → (∀ q ∈ s, q.Prime) →
      (∀ q ∈ s, Y ≤ (q : ℝ)) →
      ∑ q ∈ s, 1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤
        (8 * Real.log 4) / (Y * Real.log Y) := by
  classical
  refine Finset.strongInductionOn s ?_
  intro s ih Y hY hprime hlower
  have hY0 : 0 < Y := by linarith
  have hlogY : 0 < Real.log Y := Real.log_pos hY
  have hC : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  by_cases hs : s.Nonempty
  · let p := s.min' hs
    have hp : p ∈ s := Finset.min'_mem s hs
    have hp2 : 2 ≤ (p : ℝ) := by exact_mod_cast (hprime p hp).two_le
    have hp0 : 0 < (p : ℝ) := by linarith
    have hp1 : 1 < (p : ℝ) := by linarith
    have hlogp : 0 < Real.log (p : ℝ) := Real.log_pos hp1
    have hmin : ∀ q ∈ s, (p : ℝ) ≤ (q : ℝ) := by
      intro q hq
      exact_mod_cast Finset.min'_le s q hq
    let lo := s.filter (fun q : ℕ => (q : ℝ) ≤ 2 * (p : ℝ))
    let hi := s.filter (fun q : ℕ => ¬ (q : ℝ) ≤ 2 * (p : ℝ))
    have hhi : hi ⊂ s := by
      apply Finset.filter_ssubset.mpr
      exact ⟨p, hp, by push Not; linarith⟩
    have hlow := reciprocal_prime_block_bound lo hp2
      (fun q hq => hprime q (Finset.mem_filter.mp hq).1)
      (fun q hq => hmin q (Finset.mem_filter.mp hq).1)
      (fun q hq => (Finset.mem_filter.mp hq).2)
    have hhigh := ih hi hhi (2 * (p : ℝ)) (by linarith)
      (fun q hq => hprime q (Finset.mem_filter.mp hq).1)
      (fun q hq => (lt_of_not_ge (Finset.mem_filter.mp hq).2).le)
    have hlog2p : Real.log (p : ℝ) ≤ Real.log (2 * (p : ℝ)) :=
      Real.log_le_log hp0 (by linarith)
    have hhigh' :
        (8 * Real.log 4) / (2 * (p : ℝ) * Real.log (2 * (p : ℝ))) ≤
          4 * Real.log 4 / ((p : ℝ) * Real.log (p : ℝ)) := by
      calc
        _ ≤ (8 * Real.log 4) / (2 * (p : ℝ) * Real.log (p : ℝ)) := by
          apply div_le_div_of_nonneg_left (by positivity) (by positivity)
          exact mul_le_mul_of_nonneg_left hlog2p (by positivity)
        _ = _ := by ring
    have hsum :
        ∑ q ∈ s, 1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤
          (8 * Real.log 4) / ((p : ℝ) * Real.log (p : ℝ)) := by
      calc
        _ = (∑ q ∈ lo, 1 / ((q : ℝ) * ((q : ℝ) - 1))) +
            ∑ q ∈ hi, 1 / ((q : ℝ) * ((q : ℝ) - 1)) := by
          exact (Finset.sum_filter_add_sum_filter_not _ _ _).symm
        _ ≤ 4 * Real.log 4 / ((p : ℝ) * Real.log (p : ℝ)) +
            4 * Real.log 4 / ((p : ℝ) * Real.log (p : ℝ)) :=
          add_le_add hlow (hhigh.trans hhigh')
        _ = _ := by ring
    apply hsum.trans
    apply div_le_div_of_nonneg_left (by positivity) (by positivity)
    exact mul_le_mul (hlower p hp) (Real.log_le_log hY0 (hlower p hp))
      hlogY.le hp0.le
  · have hempty : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hs
    subst s
    simp only [Finset.sum_empty]
    positivity

/-- Chebyshev's proved logarithmic prime bound gives the finite reciprocal
prime tail with an explicit absolute constant. -/
theorem reciprocalPrimeTail_eight_log_four : ReciprocalPrimeTail (8 * Real.log 4) := by
  intro Y hY s hprime hlower
  exact reciprocal_prime_tail_le s Y hY hprime (fun q hq => (hlower q hq).le)

/-- The classical reciprocal-prime tail requires no additional analytic axiom. -/
theorem exists_reciprocalPrimeTail : ∃ H : ℝ, 0 < H ∧ ReciprocalPrimeTail H := by
  refine ⟨8 * Real.log 4, ?_, reciprocalPrimeTail_eight_log_four⟩
  have : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  positivity

/-- The small-index estimate now needs only the individual Kummer input;
the reciprocal-prime summation is discharged by the theorem above. -/
theorem smallIndexEstimate_of_individual
    (Q : ℝ → Prop) (a : ℤ) (m E A Y₀ : ℝ)
    (hm : 0 ≤ m) (hE : 0 ≤ E) (hA : 0 ≤ A)
    (hindividual : IndividualPowerResidueEstimate Q a m E A Y₀) :
    SmallIndexEstimate Q a (m * (8 * Real.log 4)) Y₀ := by
  exact smallIndexEstimate_of_individual_and_tail Q a m E A (8 * Real.log 4) Y₀
    hm hE hA hindividual reciprocalPrimeTail_eight_log_four

end Artin
