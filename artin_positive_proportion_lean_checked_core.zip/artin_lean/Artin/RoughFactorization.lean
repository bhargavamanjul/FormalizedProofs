module

public import Mathlib.Data.Nat.Prime.Basic
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Tactic.GCongr
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

/-!
# The actual rough-composite cover

A composite whose prime divisors are larger than a real cutoff is a product
of two primes if its size is at most the cube of that cutoff. The quantitative
corollaries put both prime factors into the exponent ranges used in Section 8.
-/

@[expose] public section

open Filter

namespace Artin.RoughFactorization

/-- The prime-divisor condition bounds every nontrivial divisor, not just primes. -/
theorem rough_divisor_gt {d n : ℕ} {R : ℝ}
    (hrough : ∀ p : ℕ, p.Prime → p ∣ d → R < (p : ℝ))
    (hn : 2 ≤ n) (hnd : n ∣ d) : R < (n : ℝ) := by
  obtain ⟨p, hp, hpn⟩ := Nat.exists_prime_and_dvd (by omega : n ≠ 1)
  have hnp : p ≤ n := Nat.le_of_dvd (by omega) hpn
  exact (hrough p hp (hpn.trans hnd)).trans_le (by exact_mod_cast hnp)

/-- Proper factors in a factorization of an integer at least two are nontrivial. -/
theorem proper_factors_ge_two {d m n : ℕ} (hd : 2 ≤ d)
    (hm : m < d) (hn : n < d) (heq : m * n = d) : 2 ≤ m ∧ 2 ≤ n := by
  constructor
  · by_contra h
    have hm' : m = 0 ∨ m = 1 := by omega
    rcases hm' with rfl | rfl <;> simp_all
  · by_contra h
    have hn' : n = 0 ∨ n = 1 := by omega
    rcases hn' with rfl | rfl <;> simp_all

/-- Three nontrivial factors contradict the cube-size bound. -/
theorem no_three_factors {d u v w : ℕ} {R : ℝ}
    (hR : 0 ≤ R) (hrough : ∀ p : ℕ, p.Prime → p ∣ d → R < (p : ℝ))
    (hd : (d : ℝ) ≤ R ^ 3) (hu : 2 ≤ u) (hv : 2 ≤ v) (hw : 2 ≤ w)
    (heq : u * v * w = d) : False := by
  have huD : u ∣ d := heq ▸ dvd_mul_of_dvd_left (dvd_mul_right u v) w
  have hvD : v ∣ d := heq ▸ dvd_mul_of_dvd_left (dvd_mul_left v u) w
  have hwD : w ∣ d := heq ▸ dvd_mul_left w (u * v)
  have hRu := rough_divisor_gt hrough hu huD
  have hRv := rough_divisor_gt hrough hv hvD
  have hRw := rough_divisor_gt hrough hw hwD
  have heq' : (u : ℝ) * v * w = d := by exact_mod_cast heq
  have hlt : R ^ 3 < (u : ℝ) * v * w := by
    calc
      R ^ 3 = R * R * R := by ring
      _ < (u : ℝ) * v * w := by gcongr
  linarith

/-- An actual factor of a sufficiently small rough composite must be prime. -/
theorem factor_prime {d m n : ℕ} {R : ℝ}
    (hR : 0 ≤ R) (hrough : ∀ p : ℕ, p.Prime → p ∣ d → R < (p : ℝ))
    (hd : (d : ℝ) ≤ R ^ 3) (hm : 2 ≤ m) (hn : 2 ≤ n)
    (heq : m * n = d) : m.Prime := by
  by_contra hprime
  obtain ⟨u, v, hum, hvm, huv⟩ := (Nat.not_prime_iff_exists_mul_eq hm).mp hprime
  obtain ⟨hu, hv⟩ := proper_factors_ge_two hm hum hvm huv
  exact no_three_factors hR hrough hd hu hv hn (by rw [huv, heq])

/-- Exact semiprime factorization, including prime squares. -/
theorem semiprime_of_rough {d : ℕ} {R : ℝ}
    (hd2 : 2 ≤ d) (hcomposite : ¬ d.Prime) (hR : 0 ≤ R)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ d → R < (p : ℝ))
    (hd : (d : ℝ) ≤ R ^ 3) :
    ∃ m n : ℕ, m.Prime ∧ n.Prime ∧ m * n = d ∧ R < (m : ℝ) ∧ R < (n : ℝ) := by
  obtain ⟨m, n, hm, hn, heq⟩ := (Nat.not_prime_iff_exists_mul_eq hd2).mp hcomposite
  obtain ⟨hm2, hn2⟩ := proper_factors_ge_two hd2 hm hn heq
  have hmp := factor_prime hR hrough hd hm2 hn2 heq
  have hnp := factor_prime hR hrough hd hn2 hm2 (by rwa [mul_comm])
  exact ⟨m, n, hmp, hnp, heq,
    hrough m hmp (heq ▸ dvd_mul_right m n),
    hrough n hnp (heq ▸ dvd_mul_left n m)⟩

/-- The fixed exponent margins imply the cube bound needed above. -/
theorem cutoff_cube_bound {x : ℝ} (hx : 1 ≤ x)
    (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) :
    2 * x ≤ (x ^ (49 / 100 : ℝ)) ^ 3 := by
  have hx0 : 0 < x := by linarith
  have hg : 2 ≤ x ^ (47 / 100 : ℝ) := hlarge.trans
    (Real.rpow_le_rpow_of_exponent_le hx (by norm_num))
  calc
    2 * x ≤ x ^ (47 / 100 : ℝ) * x := mul_le_mul_of_nonneg_right hg hx0.le
    _ = x ^ (147 / 100 : ℝ) := by
      rw [show (147 / 100 : ℝ) = 47 / 100 + 1 by norm_num,
        Real.rpow_add hx0, Real.rpow_one]
    _ = (x ^ (49 / 100 : ℝ)) ^ 3 := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hx0.le]
      norm_num

/-- Each factor has the required upper support once the complementary factor
is rough. -/
theorem factor_upper {x : ℝ} {m n d : ℕ} (hx : 1 ≤ x)
    (hlarge : 2 ≤ x ^ (3 / 100 : ℝ))
    (heq : m * n = d) (hd : (d : ℝ) ≤ 2 * x)
    (hn : x ^ (49 / 100 : ℝ) ≤ (n : ℝ)) :
    (m : ℝ) ≤ x ^ (54 / 100 : ℝ) := by
  have hx0 : 0 < x := by linarith
  have hR : 0 < x ^ (49 / 100 : ℝ) := Real.rpow_pos_of_pos hx0 _
  have hid : x ^ (3 / 100 : ℝ) * x =
      x ^ (54 / 100 : ℝ) * x ^ (49 / 100 : ℝ) := by
    rw [← Real.rpow_add hx0,
      show (54 / 100 + 49 / 100 : ℝ) = 3 / 100 + 1 by norm_num,
      Real.rpow_add hx0, Real.rpow_one]
  apply (mul_le_mul_iff_left₀ hR).mp
  calc
    (m : ℝ) * x ^ (49 / 100 : ℝ) ≤ (m : ℝ) * n :=
      mul_le_mul_of_nonneg_left hn (Nat.cast_nonneg _)
    _ = (d : ℝ) := by exact_mod_cast heq
    _ ≤ 2 * x := hd
    _ ≤ x ^ (3 / 100 : ℝ) * x := mul_le_mul_of_nonneg_right hlarge hx0.le
    _ = _ := hid

/-- The precise prime-factor support used by the semiprime sieve. The lower
bound is slightly stronger than needed, leaving room for dyadic boxes. -/
theorem semiprime_in_fixed_support {x κ : ℝ} {d : ℕ}
    (hx : 1 ≤ x) (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) (hκ : κ ≤ 1 / 100)
    (hd2 : 2 ≤ d) (hcomposite : ¬ d.Prime) (hd : (d : ℝ) ≤ 2 * x)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ d → x ^ (1 / 2 - κ) < (p : ℝ)) :
    ∃ m n : ℕ, m.Prime ∧ n.Prime ∧ m * n = d ∧
      x ^ (46 / 100 : ℝ) ≤ (m : ℝ) ∧ (m : ℝ) ≤ x ^ (54 / 100 : ℝ) ∧
      x ^ (46 / 100 : ℝ) ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ (54 / 100 : ℝ) := by
  have hx0 : 0 < x := by linarith
  have hcut : x ^ (49 / 100 : ℝ) ≤ x ^ (1 / 2 - κ) :=
    Real.rpow_le_rpow_of_exponent_le hx (by linarith)
  have hr : ∀ p : ℕ, p.Prime → p ∣ d → x ^ (49 / 100 : ℝ) < (p : ℝ) :=
    fun p hp hpd => hcut.trans_lt (hrough p hp hpd)
  obtain ⟨m, n, hmp, hnp, heq, hm, hn⟩ := semiprime_of_rough hd2 hcomposite
    (Real.rpow_nonneg hx0.le _) hr (hd.trans (cutoff_cube_bound hx hlarge))
  have hlow : x ^ (46 / 100 : ℝ) ≤ x ^ (49 / 100 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
  exact ⟨m, n, hmp, hnp, heq,
    hlow.trans hm.le, factor_upper hx hlarge heq hd hn.le,
    hlow.trans hn.le, factor_upper hx hlarge (by rwa [mul_comm]) hd hm.le⟩

/-- One threshold for `x` works simultaneously for every `κ ≤ 0.01` and every
rough composite in the required range. -/
theorem eventually_semiprime_in_fixed_support :
    ∀ᶠ x : ℝ in atTop, ∀ κ : ℝ, κ ≤ 1 / 100 → ∀ d : ℕ,
      2 ≤ d → ¬ d.Prime → (d : ℝ) ≤ 2 * x →
      (∀ p : ℕ, p.Prime → p ∣ d → x ^ (1 / 2 - κ) < (p : ℝ)) →
      ∃ m n : ℕ, m.Prime ∧ n.Prime ∧ m * n = d ∧
        x ^ (46 / 100 : ℝ) ≤ (m : ℝ) ∧ (m : ℝ) ≤ x ^ (54 / 100 : ℝ) ∧
        x ^ (46 / 100 : ℝ) ≤ (n : ℝ) ∧ (n : ℝ) ≤ x ^ (54 / 100 : ℝ) := by
  have hg := (tendsto_rpow_atTop (show (0 : ℝ) < 3 / 100 by norm_num)).eventually_ge_atTop 2
  filter_upwards [eventually_ge_atTop (1 : ℝ), hg] with x hx hlarge
  intro κ hκ d hd2 hcomposite hd hrough
  exact semiprime_in_fixed_support hx hlarge hκ hd2 hcomposite hd hrough

/-- Division by the complementary rough factor gives the narrow upper bound,
whose logarithmic width tends to zero with `κ`. -/
theorem factor_upper_narrow {x κ : ℝ} {m n d : ℕ} (hx : 0 < x)
    (heq : m * n = d) (hd : (d : ℝ) ≤ 2 * x)
    (hn : x ^ (1 / 2 - κ) ≤ (n : ℝ)) :
    (m : ℝ) ≤ 2 * x ^ (1 / 2 + κ) := by
  have hR : 0 < x ^ (1 / 2 - κ) := Real.rpow_pos_of_pos hx _
  have hid : (2 * x ^ (1 / 2 + κ)) * x ^ (1 / 2 - κ) = 2 * x := by
    rw [mul_assoc, ← Real.rpow_add hx]
    have hs : (1 / 2 + κ) + (1 / 2 - κ) = (1 : ℝ) := by ring
    rw [hs, Real.rpow_one]
  apply (mul_le_mul_iff_left₀ hR).mp
  calc
    (m : ℝ) * x ^ (1 / 2 - κ) ≤ (m : ℝ) * n :=
      mul_le_mul_of_nonneg_left hn (Nat.cast_nonneg _)
    _ = (d : ℝ) := by exact_mod_cast heq
    _ ≤ 2 * x := hd
    _ = _ := hid.symm

/-- The actual narrow semiprime strip. This retains `κ`, as needed to bound
the number of dyadic boxes by a constant times `κ log x + 1`. -/
theorem semiprime_in_narrow_support {x κ : ℝ} {d : ℕ}
    (hx : 1 ≤ x) (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) (hκ : κ ≤ 1 / 100)
    (hd2 : 2 ≤ d) (hcomposite : ¬ d.Prime) (hd : (d : ℝ) ≤ 2 * x)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ d → x ^ (1 / 2 - κ) < (p : ℝ)) :
    ∃ m n : ℕ, m.Prime ∧ n.Prime ∧ m * n = d ∧
      x ^ (1 / 2 - κ) < (m : ℝ) ∧ (m : ℝ) ≤ 2 * x ^ (1 / 2 + κ) ∧
      x ^ (1 / 2 - κ) < (n : ℝ) ∧ (n : ℝ) ≤ 2 * x ^ (1 / 2 + κ) := by
  obtain ⟨m, n, hmp, hnp, heq, _, _, _, _⟩ :=
    semiprime_in_fixed_support hx hlarge hκ hd2 hcomposite hd hrough
  have hm := hrough m hmp (heq ▸ dvd_mul_right m n)
  have hn := hrough n hnp (heq ▸ dvd_mul_left n m)
  have hx0 : 0 < x := by linarith
  exact ⟨m, n, hmp, hnp, heq, hm, factor_upper_narrow hx0 heq hd hn.le,
    hn, factor_upper_narrow hx0 (by rwa [mul_comm]) hd hm.le⟩

end Artin.RoughFactorization
