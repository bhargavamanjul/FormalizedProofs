module

public import Artin.MarkedBandTail

/-!
# The complete truncated marked-cofactor estimate

The ordinary classical prime estimates imply a large reciprocal sum over
actual distinct enlarged integers below `x^ε`. The marked mass and its tail
are derived from the concrete bands, and the tail is removed using convergence
and an exact finite-sum decomposition. Constants are chosen before the
cofactor parameters; only the eventual threshold depends on them.
-/

@[expose] public section

open scoped BigOperators Topology
open Filter

namespace Artin.MarkedCofactorEstimate

open ConcreteSelector MarkedInfiniteMass EnlargedCofactorMass MarkedBandTail

/-- The actual finite family of enlarged positive integers up to `X`. -/
noncomputable def boundedCofactors (P U : Finset ℕ) (X : ℝ) : Finset ℕ :=
  (Finset.range (⌊X⌋₊ + 1)).filter
    (fun n => 0 < n ∧ strip P n ∈ U ∧ (n : ℝ) ≤ X)

/-- Finite reciprocal mass over distinct actual enlarged natural numbers. -/
noncomputable def boundedMass (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ) : ℝ :=
  ∑ n ∈ boundedCofactors P U X, W (markedPart P n) / (n : ℝ)

theorem mem_boundedCofactors (P U : Finset ℕ) (X : ℝ) (n : ℕ) :
    n ∈ boundedCofactors P U X ↔ 0 < n ∧ strip P n ∈ U ∧ (n : ℝ) ≤ X := by
  constructor
  · intro hn
    exact (Finset.mem_filter.mp hn).2
  · intro hn
    exact Finset.mem_filter.mpr
      ⟨Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_floor hn.2.2)), hn⟩

/-- The finite mass is the small-integer part of the convergent series. -/
theorem boundedMass_eq_tsum (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ) :
    boundedMass P U W X =
      ∑' n : ℕ, if (n : ℝ) ≤ X then enlargedReciprocal P U W n else 0 := by
  classical
  rw [tsum_eq_sum (s := boundedCofactors P U X)]
  · apply Finset.sum_congr rfl
    intro n hn
    have hh := (mem_boundedCofactors P U X n).mp hn
    simp [enlargedReciprocal, hh.1, hh.2.1, hh.2.2]
  · intro n hn
    by_cases hx : (n : ℝ) ≤ X
    · have hno : ¬ (0 < n ∧ strip P n ∈ U) := by
        intro hh
        exact hn ((mem_boundedCofactors P U X n).mpr ⟨hh.1, hh.2, hx⟩)
      simp [hx, enlargedReciprocal, hno]
    · simp [hx]

/-- The finite cutoff and the genuine infinite tail partition the mass. -/
theorem boundedMass_add_tail (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ)
    (hsum : Summable (enlargedReciprocal P U W)) :
    boundedMass P U W X + enlargedSizeTail P U W X = enlargedMass P U W := by
  classical
  have hlo : Summable (fun n : ℕ => if (n : ℝ) ≤ X then enlargedReciprocal P U W n else 0) := by
    apply (hsum.indicator {n : ℕ | (n : ℝ) ≤ X}).congr
    intro n
    simp only [Set.indicator_apply, Set.mem_ofPred_eq]
  have hhi : Summable (fun n : ℕ => if X < (n : ℝ) then enlargedReciprocal P U W n else 0) := by
    apply (hsum.indicator {n : ℕ | X < (n : ℝ)}).congr
    intro n
    simp only [Set.indicator_apply, Set.mem_ofPred_eq]
  rw [boundedMass_eq_tsum, enlargedSizeTail, ← Summable.tsum_add hlo hhi]
  apply tsum_congr
  intro n
  by_cases hn : (n : ℝ) ≤ X
  · simp [hn, not_lt_of_ge hn]
  · simp [hn, lt_of_not_ge hn]

/-- A tail at most half the unmarked mass leaves at least half that mass
among the actual enlarged integers below the cutoff. -/
theorem boundedMass_ge_half (P U : Finset ℕ) (W : ℕ → ℝ) (X H : ℝ)
    (hsum : Summable (enlargedReciprocal P U W))
    (hfull : H ≤ enlargedMass P U W) (htail : enlargedSizeTail P U W X ≤ H / 2) :
    H / 2 ≤ boundedMass P U W X := by
  have heq := boundedMass_add_tail P U W X hsum
  linarith

/-- Finite truncation never increases nonnegative reciprocal mass. -/
theorem boundedMass_le_full (P U : Finset ℕ) (W : ℕ → ℝ) (X : ℝ)
    (hW : ∀ n, 0 ≤ W n) (hsum : Summable (enlargedReciprocal P U W)) :
    boundedMass P U W X ≤ enlargedMass P U W := by
  have htail : 0 ≤ enlargedSizeTail P U W X := by
    apply tsum_nonneg
    intro n
    unfold enlargedReciprocal
    split_ifs
    · exact div_nonneg (hW _) (Nat.cast_nonneg _)
    · exact le_rfl
    · exact le_rfl
  have heq := boundedMass_add_tail P U W X hsum
  linarith

/-- The union of the exact manuscript prime bands. -/
noncomputable def markedPrimes {ι : Type*} (I : Finset ι) (a : ι → ℝ) (x : ℝ) : Finset ℕ :=
  I.biUnion (fun i => primeBand (a i) x)

/-- The actual normalized manuscript marking weight. -/
noncomputable def marking {ι : Type*} (I : Finset ι) (a : ι → ℝ) (x : ℝ) : ℕ → ℝ :=
  markingWeight I (fun i => primeBand (a i) x) (fun i => bandMass (a i) x)

/-- The actual squarefree unmarked cofactors at the Section 4 scales. -/
noncomputable def unmarkedCofactors {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) : Finset ℕ :=
  CofactorAsymptotics.cofactors (CofactorAsymptotics.scalePrimes (markedPrimes I a) ε Y x)
    (Real.exp (ε * Real.log x / 2)) τ

/-- The finite marked-cofactor reciprocal mass below the actual cutoff `x^ε`. -/
noncomputable def truncatedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (ε Y τ x : ℝ) : ℝ :=
  boundedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) (x ^ ε)

theorem markedPrimes_prime {ι : Type*} (I : Finset ι) (a : ι → ℝ) (x : ℝ) :
    ∀ p ∈ markedPrimes I a x, p.Prime := by
  intro p hp
  obtain ⟨i, hi, hpi⟩ := Finset.mem_biUnion.mp hp
  exact (primeBand_properties (a i) x hpi).1

theorem unmarkedCofactors_avoid {ι : Type*} (I : Finset ι) (a : ι → ℝ) (ε Y τ x : ℝ) :
    ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      r ≠ 0 ∧ ∀ p ∈ markedPrimes I a x, ¬ p ∣ r :=
  unmarked_cofactors_disjoint (markedPrimes I a x) Y (Real.exp (ε * Real.log x / 8))
    (Real.exp (ε * Real.log x / 2)) τ (markedPrimes_prime I a x)

/-- Actual full enlarged mass equals the marked mass times `H₀`. -/
theorem full_mass_eq {ι : Type*} (I : Finset ι) (a : ι → ℝ) (ε Y τ x : ℝ)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) =
      supportedMass (markedPrimes I a x) (marking I a x) *
        CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x :=
  enlarged_marking_mass_eq I _ _ _ _ hV (markedPrimes_prime I a x)
    (unmarkedCofactors_avoid I a ε Y τ x)

/-- The reciprocal marking weight in the finite sum is evaluated at the
actual enlarged integer, so this is the manuscript's distinct-integer sum. -/
theorem truncatedMass_eq {ι : Type*} (I : Finset ι) (a : ι → ℝ) (ε Y τ x : ℝ) :
    truncatedMass I a ε Y τ x =
      ∑ n ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
        marking I a x n / (n : ℝ) := by
  unfold truncatedMass boundedMass
  apply Finset.sum_congr rfl
  intro n hn
  rw [marking, markingWeight_markedPart I _ _ _ n]
  intro i hi p hp
  exact Finset.mem_biUnion.mpr ⟨i, hi, hp⟩

/-- Removing all enlarged integers above `x^ε` retains at least half the
unmarked mass. Both comparison constants are independent of `ε`, `Y`, and `τ`;
no marked-tail estimate appears among the assumptions. -/
theorem uniform_retained_mass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∃ C : ℝ, 0 < C ∧ ∀ ε : ℝ, 0 < ε → ∀ Y τ : ℝ,
      ∀ᶠ x : ℝ in atTop,
        CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x / 2 ≤
          truncatedMass I a ε Y τ x ∧
        truncatedMass I a ε Y τ x ≤
          C * CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
  obtain ⟨C, hC, hmass⟩ := actual_bands_mass_bounds I a B v₀ hv₀ hinj hclassical
  obtain ⟨Ct, hCt, htail⟩ := actual_bands_enlarged_cofactor_tail I a amin amax B v₀
    hmin hv₀ ha hclassical
  refine ⟨C, hC, ?_⟩
  intro ε hε Y τ
  have hdecay : Tendsto (fun x : ℝ => Ct * Real.exp (-(ε / 2) *
      (Real.log x) ^ (1 - amax))) atTop (𝓝 0) := by
    simpa using (rankin_decay_tendsto amax (ε / 2) hmax (by positivity)).const_mul Ct
  filter_upwards [hmass, htail ε Y τ, hclassical,
    hdecay.eventually_lt_const (by norm_num : (0 : ℝ) < 1 / 2)] with x hm ht hVx hsmall
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hW : ∀ n, 0 ≤ marking I a x n :=
    fun n => (markingWeight_bounds I _ _ n hV).1
  have hs := summable_enlargedReciprocal (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
    (marking I a x) (unmarkedCofactors_avoid I a ε Y τ x) hW
    (summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have hH : 0 ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
    unfold CofactorAsymptotics.scaleMass CofactorAsymptotics.mass
    exact Finset.sum_nonneg (fun n hn => by positivity)
  have hfull : CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x ≤
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) := by
    rw [full_mass_eq I a ε Y τ x hV]
    simpa only [one_mul, markedPrimes, marking] using mul_le_mul_of_nonneg_right hm.1 hH
  have hupper : enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
      (marking I a x) ≤ C * CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
    rw [full_mass_eq I a ε Y τ x hV]
    exact mul_le_mul_of_nonneg_right hm.2 hH
  have htailhalf : enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
      (marking I a x) (x ^ ε) ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x / 2 := by
    refine ht.trans ?_
    calc
      _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x * (1 / 2) :=
        mul_le_mul_of_nonneg_left hsmall.le hH
      _ = _ := by ring
  exact ⟨boundedMass_ge_half _ _ _ _ _ hs hfull htailhalf,
    (boundedMass_le_full _ _ _ _ hW hs).trans hupper⟩

/-- The actual band union has uniformly bounded reciprocal-prime mass. -/
theorem markedPrimes_mass_le {ι : Type*} (I : Finset ι) (a : ι → ℝ) (B : ℝ)
    (hclassical : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, bandMass (a i) x ≤ B) :
    ∀ᶠ x : ℝ in atTop, (∑ p ∈ markedPrimes I a x, 1 / (p : ℝ)) ≤ I.card * B := by
  filter_upwards [hclassical] with x hx
  refine (reciprocal_biUnion_le I (fun i => primeBand (a i) x)).trans ?_
  calc
    _ ≤ ∑ i ∈ I, B := Finset.sum_le_sum (fun i hi => hx i hi)
    _ = _ := by simp

/-- Section 4's required large reciprocal sum after the actual size cutoff.
The only analytic assumptions are ordinary undeleted prime estimates and
classical reciprocal-band estimates. The lower constant is fixed before
`ε`, `τ`, and `Y`; the threshold may depend on all three. -/
theorem uniform_truncated_mass_lower_from_classical {ι : Type*}
    (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ c Y₀ : ℝ)
    (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀) (hc : 0 < c) (hY₀ : 1 < Y₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (hmertens : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c * Real.log Z / Real.log Y ≤
        ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ)))
    (hlogmoment : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
        Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ (4 / 3 : ℝ) * Real.log Z) :
    ∃ A : ℝ, 0 < A ∧ ∀ ε : ℝ, 0 < ε → ∀ τ : ℝ, 0 < τ →
      ∀ Y : ℝ, Y₀ ≤ Y → 10 / τ ≤ Y → ∀ᶠ x : ℝ in atTop,
        A * ε * Real.log x / Real.log Y ≤ truncatedMass I a ε Y τ x := by
  obtain ⟨A, hA, hH⟩ := CofactorAsymptotics.uniform_mass_lower_from_classical
    (markedPrimes I a) c (I.card * B) Y₀ hc hY₀
    (markedPrimes_mass_le I a B (hclassical.mono (fun x hx i hi => (hx i hi).2)))
    hmertens hlogmoment
  obtain ⟨C, hC, hretain⟩ := uniform_retained_mass I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical
  refine ⟨A / 2, by positivity, ?_⟩
  intro ε hε τ hτ Y hY hcut
  filter_upwards [hH ε hε τ hτ Y hY hcut, hretain ε hε Y τ] with x hx hr
  calc
    A / 2 * ε * Real.log x / Real.log Y = (A * ε * Real.log x / Real.log Y) / 2 := by ring
    _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x / 2 := by linarith
    _ ≤ truncatedMass I a ε Y τ x := hr.1

/-- The upper `H₀` comparison follows from the ordinary undeleted Mertens
product upper bound; deleting primes and imposing cofactor restrictions can
only lower the mass. The constant does not depend on the cofactor parameters. -/
theorem uniform_unmarked_mass_upper (marked : ℝ → Finset ℕ) (c Y₀ : ℝ)
    (hmertens : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ))) ≤
        c * Real.log Z / Real.log Y) :
    ∀ ε : ℝ, 0 < ε → ∀ Y : ℝ, Y₀ ≤ Y → ∀ τ : ℝ,
      ∀ᶠ x : ℝ in atTop, CofactorAsymptotics.scaleMass marked ε Y τ x ≤
        (c / 8) * ε * Real.log x / Real.log Y := by
  intro ε hε Y hY τ
  filter_upwards [(CofactorAsymptotics.cofactor_scale_tendsto ε hε).eventually (hmertens Y hY)]
    with x hx
  have hprime : ∀ p ∈ CofactorAsymptotics.scalePrimes marked ε Y x, p.Prime :=
    fun p hp => CofactorAsymptotics.unmarkedPrimes_prime _ _ _ hp
  have hmass := CofactorAsymptotics.mass_le_euler (CofactorAsymptotics.scalePrimes marked ε Y x)
    hprime (Real.exp (ε * Real.log x / 2)) τ
  have hdelete : (∏ p ∈ CofactorAsymptotics.scalePrimes marked ε Y x, (1 + 1 / (p : ℝ))) ≤
      ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y (Real.exp (ε * Real.log x / 8)),
        (1 + 1 / (p : ℝ)) := by
    unfold CofactorAsymptotics.scalePrimes
    rw [CofactorAsymptotics.unmarkedPrimes_eq_sdiff]
    apply Finset.prod_le_prod_of_subset_of_one_le₀ Finset.sdiff_subset
    · intro p hp
      positivity
    · intro p hp hnot
      have hn : 0 ≤ 1 / (p : ℝ) := by positivity
      linarith
  refine (hmass.trans hdelete).trans ?_
  calc
    _ ≤ c * Real.log (Real.exp (ε * Real.log x / 8)) / Real.log Y := hx
    _ = _ := by rw [Real.log_exp]; ring

/-- Complete finite marked-cofactor estimate at the manuscript scales.
All constants precede `ε`, `τ`, and `Y`; only classical ordinary-prime and
band reciprocal estimates are assumed. The finite sum is over distinct
actual integers bounded by `x^ε`, and retains at least half of `H₀`. -/
theorem uniform_truncated_mass_bounds_from_classical {ι : Type*}
    (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ c₁ c₂ Y₀ : ℝ)
    (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (hc₁ : 0 < c₁) (hc₂ : 0 < c₂) (hY₀ : 1 < Y₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (hmertens_lower : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c₁ * Real.log Z / Real.log Y ≤
        ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ)))
    (hmertens_upper : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ))) ≤
        c₂ * Real.log Z / Real.log Y)
    (hlogmoment : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
        Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ (4 / 3 : ℝ) * Real.log Z) :
    ∃ A C : ℝ, 0 < A ∧ 0 < C ∧
      ∀ ε : ℝ, 0 < ε → ∀ τ : ℝ, 0 < τ → ∀ Y : ℝ, Y₀ ≤ Y → 10 / τ ≤ Y →
        ∀ᶠ x : ℝ in atTop,
          CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x / 2 ≤ truncatedMass I a ε Y τ x ∧
          A * ε * Real.log x / Real.log Y ≤ truncatedMass I a ε Y τ x ∧
          truncatedMass I a ε Y τ x ≤ C * ε * Real.log x / Real.log Y := by
  obtain ⟨A, hA, hlower⟩ := uniform_truncated_mass_lower_from_classical I a amin amax B v₀ c₁ Y₀
    hmin hmax hv₀ hc₁ hY₀ ha hinj hclassical hmertens_lower hlogmoment
  obtain ⟨D, hD, hretain⟩ := uniform_retained_mass I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical
  refine ⟨A, D * c₂ / 8, hA, by positivity, ?_⟩
  intro ε hε τ hτ Y hY hcut
  filter_upwards [hlower ε hε τ hτ Y hY hcut, hretain ε hε Y τ,
    uniform_unmarked_mass_upper (markedPrimes I a) c₂ Y₀ hmertens_upper ε hε Y hY τ]
    with x hl hr hu
  refine ⟨hr.1, hl, hr.2.trans ?_⟩
  calc
    D * CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x ≤
        D * ((c₂ / 8) * ε * Real.log x / Real.log Y) := mul_le_mul_of_nonneg_left hu hD.le
    _ = D * c₂ / 8 * ε * Real.log x / Real.log Y := by ring

/-- The stronger retention bound needed for a main-mass comparison with a
constant independent of the number of marks. The discarded mass is at most
half `H₀`, which is at most half the full enlarged mass `J`; no upper bound
for the marked mass is used to obtain the factor one half. -/
theorem uniform_retained_full_mass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∀ ε : ℝ, 0 < ε → ∀ Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) / 2 ≤
        truncatedMass I a ε Y τ x := by
  obtain ⟨C, hC, hmass⟩ := actual_bands_mass_bounds I a B v₀ hv₀ hinj hclassical
  obtain ⟨Ct, hCt, htail⟩ := actual_bands_enlarged_cofactor_tail I a amin amax B v₀
    hmin hv₀ ha hclassical
  intro ε hε Y τ
  have hdecay : Tendsto (fun x : ℝ => Ct * Real.exp (-(ε / 2) *
      (Real.log x) ^ (1 - amax))) atTop (𝓝 0) := by
    simpa using (rankin_decay_tendsto amax (ε / 2) hmax (by positivity)).const_mul Ct
  filter_upwards [hmass, htail ε Y τ, hclassical,
    hdecay.eventually_lt_const (by norm_num : (0 : ℝ) < 1 / 2)] with x hm ht hVx hsmall
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hW : ∀ n, 0 ≤ marking I a x n := fun n => (markingWeight_bounds I _ _ n hV).1
  have hs := summable_enlargedReciprocal (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
    (marking I a x) (unmarkedCofactors_avoid I a ε Y τ x) hW
    (summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have hH : 0 ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
    unfold CofactorAsymptotics.scaleMass CofactorAsymptotics.mass
    exact Finset.sum_nonneg (fun n hn => by positivity)
  have hfull : CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x ≤
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) := by
    rw [full_mass_eq I a ε Y τ x hV]
    simpa only [one_mul, markedPrimes, marking] using mul_le_mul_of_nonneg_right hm.1 hH
  have htailhalf : enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
      (marking I a x) (x ^ ε) ≤
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) / 2 := by
    refine ht.trans ?_
    calc
      _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x * (1 / 2) :=
        mul_le_mul_of_nonneg_left hsmall.le hH
      _ ≤ enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) / 2 := by
        linarith
  exact boundedMass_ge_half _ _ _ _ _ hs le_rfl htailhalf

end Artin.MarkedCofactorEstimate
