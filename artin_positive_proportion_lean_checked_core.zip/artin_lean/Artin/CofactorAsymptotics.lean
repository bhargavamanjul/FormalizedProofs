module

public import Artin.Cofactor
public import Artin.OrderExceptions
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Order.Filter.AtTopBot.Basic
public import Mathlib.Algebra.Order.Floor.Semiring
public import Mathlib.Algebra.BigOperators.Intervals
public import Mathlib.Algebra.BigOperators.Fin
public import Mathlib.Algebra.Field.GeomSum
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FunProp

/-!
# Actual squarefree cofactor mass from classical prime estimates

The cofactor family here consists of natural numbers, not abstract weights.
Its lower bound is derived from Euler products and two prime moments. The final
asymptotic theorem keeps the Mertens constant outside the quantifiers over the
small exponent and the lower prime cutoff. Classical prime estimates are
explicit hypotheses; the cofactor-mass conclusion is not a hypothesis.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.CofactorAsymptotics

/-- The actual allowed prime set, with an arbitrary finite marked set deleted. -/
noncomputable def unmarkedPrimes (marked : Finset ℕ) (Y Z : ℝ) : Finset ℕ :=
  (Finset.range (⌊Z⌋₊ + 1)).filter
    (fun p => Nat.Prime p ∧ Y < (p : ℝ) ∧ (p : ℝ) ≤ Z ∧ p ∉ marked)

theorem unmarkedPrimes_prime (marked : Finset ℕ) (Y Z : ℝ)
    {p : ℕ} (hp : p ∈ unmarkedPrimes marked Y Z) : Nat.Prime p := by
  classical
  exact (Finset.mem_filter.mp hp).2.1

/-- Subsets surviving the size and reciprocal-prime constraints. -/
noncomputable def goodSubsets (s : Finset ℕ) (R τ : ℝ) : Finset (Finset ℕ) :=
  s.powerset.filter (fun t => ((∏ p ∈ t, p : ℕ) : ℝ) ≤ R ∧
    (∑ p ∈ t, 1 / (p : ℝ)) ≤ τ)

/-- The permitted natural-number cofactors, with no multiplicity. -/
noncomputable def cofactors (s : Finset ℕ) (R τ : ℝ) : Finset ℕ :=
  (goodSubsets s R τ).image (fun t => ∏ p ∈ t, p)

/-- The manuscript's unmarked reciprocal cofactor mass. -/
noncomputable def mass (s : Finset ℕ) (R τ : ℝ) : ℝ :=
  ∑ r ∈ cofactors s R τ, 1 / (r : ℝ)

/-- Conversion from subset weights to the sum over actual integers. -/
theorem mass_eq_subset_sum (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) :
    mass s R τ = ∑ t ∈ goodSubsets s R τ, ∏ p ∈ t, 1 / (p : ℝ) := by
  classical
  unfold mass cofactors
  rw [Finset.sum_image]
  · apply Finset.sum_congr rfl
    intro t ht
    exact (Cofactor.reciprocal_product t).symm
  · intro t ht v hv h
    exact Cofactor.prime_subset_product_injective s hs
      (Finset.mem_filter.mp ht).1 (Finset.mem_filter.mp hv).1 h

/-- These are squarefree integers, as required by the manuscript. -/
theorem cofactor_squarefree (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) {r : ℕ} (hr : r ∈ cofactors s R τ) : Squarefree r := by
  classical
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hr
  apply Cofactor.prime_subset_product_squarefree
  intro p hp
  exact hs p ((Finset.mem_powerset.mp (Finset.mem_filter.mp ht).1) hp)

theorem cofactor_le (s : Finset ℕ) (R τ : ℝ) {r : ℕ}
    (hr : r ∈ cofactors s R τ) : (r : ℝ) ≤ R := by
  classical
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hr
  exact (Finset.mem_filter.mp ht).2.1

/-- Logarithmic size really is the sum of the prime logarithms. -/
theorem log_prime_product (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p) :
    Real.log ((∏ p ∈ s, p : ℕ) : ℝ) = ∑ p ∈ s, Real.log (p : ℝ) := by
  rw [Nat.cast_prod]
  apply Real.log_prod
  intro p hp
  exact_mod_cast (hs p hp).ne_zero

/-- Prime-product size and its additive logarithmic restriction are equivalent. -/
theorem prime_product_le_iff (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R : ℝ) (hR : 0 < R) :
    ((∏ p ∈ s, p : ℕ) : ℝ) ≤ R ↔
      (∑ p ∈ s, Real.log (p : ℝ)) ≤ Real.log R := by
  have hprod : (0 : ℝ) < ((∏ p ∈ s, p : ℕ) : ℝ) := by
    exact_mod_cast Finset.prod_pos (fun p hp => (hs p hp).pos)
  rw [← log_prime_product s hs]
  exact (Real.log_le_log_iff hprod hR).symm

/-- The finite cofactor lower bound with the exact two prime moments exposed. -/
theorem mass_ge_half_euler (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) (hR : 1 < R) (hτ : 0 < τ)
    (hlog : (∑ p ∈ s, Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ Real.log R / 3)
    (hrec : (∑ p ∈ s, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ))) ≤ τ / 10) :
    (1 / 2 : ℝ) * (∏ p ∈ s, (1 + 1 / (p : ℝ))) ≤ mass s R τ := by
  classical
  have hp : ∀ p ∈ s, (0 : ℝ) < p := by
    intro p hp
    exact_mod_cast (hs p hp).pos
  have h := Cofactor.half_euler_product_with_two_constraints s
    (fun p => 1 / (p : ℝ)) (fun p => Real.log (p : ℝ))
    (fun p => 1 / (p : ℝ)) (Real.log R) τ
    (Real.log_pos hR) hτ
    (fun p hp' => (one_div_pos.mpr (hp p hp')).le)
    (fun p hp' => Real.log_nonneg (by exact_mod_cast (hs p hp').one_le))
    (fun p hp' => (one_div_pos.mpr (hp p hp')).le) ?_ ?_
  · rw [mass_eq_subset_sum s hs]
    convert h using 1
    congr 1
    apply Finset.filter_congr
    intro t ht
    have htp : ∀ p ∈ t, Nat.Prime p :=
      fun p hp' => hs p ((Finset.mem_powerset.mp ht) hp')
    rw [← prime_product_le_iff t htp R (by linarith)]
  · calc
      (∑ p ∈ s, (1 / (p : ℝ)) / (1 + 1 / (p : ℝ)) * Real.log (p : ℝ)) =
          ∑ p ∈ s, Real.log (p : ℝ) / ((p : ℝ) + 1) := by
        apply Finset.sum_congr rfl
        intro p hp'
        rw [Cofactor.reciprocal_marginal (p : ℝ) (hp p hp')]
        ring
      _ ≤ Real.log R / 3 := hlog
  · convert hrec using 1
    apply Finset.sum_congr rfl
    intro p hp'
    rw [Cofactor.reciprocal_marginal (p : ℝ) (hp p hp')]

/-- Removing restrictions can only increase the reciprocal mass. -/
theorem mass_le_euler (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) : mass s R τ ≤ ∏ p ∈ s, (1 + 1 / (p : ℝ)) := by
  classical
  rw [mass_eq_subset_sum s hs, ← Cofactor.subset_euler_product]
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
    (fun t ht _ => Finset.prod_nonneg (fun p hp => by positivity))

/-- The elementary telescoping bound underlying the reciprocal-divisor moment.
No analytic prime-sum estimate is required for this restriction. -/
theorem reciprocal_moment_le (s : Finset ℕ) (m : ℕ) (hm : 0 < m)
    (hs : ∀ p ∈ s, m ≤ p) :
    (∑ p ∈ s, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ))) ≤ 1 / (m : ℝ) := by
  classical
  let n := max m (s.sup id + 1)
  have hmn : m ≤ n := le_max_left _ _
  have hsub : s ⊆ Finset.Ico m n := by
    intro p hp
    refine Finset.mem_Ico.mpr ⟨hs p hp, ?_⟩
    have hps : p ≤ s.sup id := Finset.le_sup (f := id) hp
    exact lt_of_lt_of_le (by omega : p < s.sup id + 1) (le_max_right _ _)
  have hsum :
      (∑ p ∈ Finset.Ico m n, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ))) =
        1 / (m : ℝ) - 1 / (n : ℝ) := by
    have ht := Finset.sum_Ico_sub (fun p : ℕ => -(1 / (p : ℝ))) hmn
    convert ht using 1
    · apply Finset.sum_congr rfl
      intro p hp
      have hpm : m ≤ p := (Finset.mem_Ico.mp hp).1
      have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast (show p ≠ 0 by omega)
      have hp1 : (p : ℝ) + 1 ≠ 0 := by positivity
      simp only [Nat.cast_add, Nat.cast_one]
      field_simp
      ring
    · ring
  calc
    (∑ p ∈ s, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ))) ≤
        ∑ p ∈ Finset.Ico m n, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ)) :=
      Finset.sum_le_sum_of_subset_of_nonneg hsub (fun p hp _ => by positivity)
    _ = 1 / (m : ℝ) - 1 / (n : ℝ) := hsum
    _ ≤ 1 / (m : ℝ) := sub_le_self _ (by positivity)

/-- A real lower cutoff gives a uniform reciprocal moment at most `1/Y`. -/
theorem reciprocal_moment_le_inv_cutoff (s : Finset ℕ) (Y : ℝ) (hY : 0 < Y)
    (hs : ∀ p ∈ s, Y < (p : ℝ)) :
    (∑ p ∈ s, (1 / ((p : ℝ) + 1)) * (1 / (p : ℝ))) ≤ 1 / Y := by
  have h := reciprocal_moment_le s (⌊Y⌋₊ + 1) (by omega) (fun p hp =>
    Nat.succ_le_iff.mpr ((Nat.floor_lt hY.le).mpr (hs p hp)))
  refine h.trans ?_
  apply one_div_le_one_div_of_le hY
  have hf := Nat.lt_floor_add_one Y
  simpa only [Nat.cast_add, Nat.cast_one] using hf.le

/-- The cofactor bound with only the logarithmic prime moment as an input;
the reciprocal-prime moment is now proved by telescoping. -/
theorem mass_ge_half_euler_of_cutoff (s : Finset ℕ)
    (hs : ∀ p ∈ s, Nat.Prime p) (Y R τ : ℝ)
    (hY : 0 < Y) (hR : 1 < R) (hτ : 0 < τ)
    (hcutoff : 10 / τ ≤ Y) (hprimes : ∀ p ∈ s, Y < (p : ℝ))
    (hlog : (∑ p ∈ s, Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ Real.log R / 3) :
    (1 / 2 : ℝ) * (∏ p ∈ s, (1 + 1 / (p : ℝ))) ≤ mass s R τ := by
  apply mass_ge_half_euler s hs R τ hR hτ hlog
  refine (reciprocal_moment_le_inv_cutoff s Y hY hprimes).trans ?_
  apply (div_le_iff₀ hY).mpr
  have hh : 10 ≤ Y * τ := (div_le_iff₀ hτ).mp hcutoff
  nlinarith

/-- The precise prime set used at scale `x`. Marked prime sets may depend on `x`. -/
noncomputable def scalePrimes (marked : ℝ → Finset ℕ) (ε Y x : ℝ) : Finset ℕ :=
  unmarkedPrimes (marked x) Y (Real.exp (ε * Real.log x / 8))

/-- The natural-number cofactor mass at the manuscript's two exponential scales. -/
noncomputable def scaleMass (marked : ℝ → Finset ℕ) (ε Y τ x : ℝ) : ℝ :=
  mass (scalePrimes marked ε Y x) (Real.exp (ε * Real.log x / 2)) τ

/-- Uniform asymptotic lower cofactor mass from the classical Mertens product
and logarithmic prime-moment estimates. The constant `c/16` is fixed before
`ε`, `Y`, and `τ`; only the eventual threshold depends on those parameters.

The product hypothesis is the ordinary Mertens lower bound after deleting the
fixed number of marked bands. The other hypothesis is the classical estimate
`sum log p / (p+1) ≤ (4/3) log Z`. Neither is a cofactor-mass hypothesis. -/
theorem uniform_mass_lower_bound
    (marked : ℝ → Finset ℕ) (c Y₀ : ℝ) (hc : 0 < c) (hY₀ : 1 < Y₀)
    (hproduct : ∀ ε : ℝ, 0 < ε → ∀ Y : ℝ, Y₀ ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        c * Real.log (Real.exp (ε * Real.log x / 8)) / Real.log Y ≤
          ∏ p ∈ scalePrimes marked ε Y x, (1 + 1 / (p : ℝ)))
    (hmoment : ∀ ε : ℝ, 0 < ε → ∀ Y : ℝ, Y₀ ≤ Y →
      ∀ᶠ x : ℝ in atTop,
        (∑ p ∈ scalePrimes marked ε Y x,
          Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤
          (4 / 3 : ℝ) * Real.log (Real.exp (ε * Real.log x / 8))) :
    ∃ A : ℝ, 0 < A ∧ ∀ ε : ℝ, 0 < ε → ∀ τ : ℝ, 0 < τ →
      ∀ Y : ℝ, Y₀ ≤ Y → 10 / τ ≤ Y →
        ∀ᶠ x : ℝ in atTop,
          A * ε * Real.log x / Real.log Y ≤ scaleMass marked ε Y τ x := by
  refine ⟨c / 16, by positivity, ?_⟩
  intro ε hε τ hτ Y hY hcutoff
  filter_upwards [hproduct ε hε Y hY, hmoment ε hε Y hY,
    eventually_ge_atTop (2 : ℝ)] with x hprod hmoment hx
  have hx1 : 1 < x := by linarith
  have hYp : 0 < Y := by linarith
  have hR : 1 < Real.exp (ε * Real.log x / 2) := by
    rw [Real.one_lt_exp_iff]
    positivity [Real.log_pos hx1]
  have hprimes : ∀ p ∈ scalePrimes marked ε Y x, Nat.Prime p :=
    fun p hp => unmarkedPrimes_prime _ _ _ hp
  have hcut : ∀ p ∈ scalePrimes marked ε Y x, Y < (p : ℝ) := by
    intro p hp
    exact (Finset.mem_filter.mp hp).2.2.1
  have hmoment' :
      (∑ p ∈ scalePrimes marked ε Y x, Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤
        Real.log (Real.exp (ε * Real.log x / 2)) / 3 := by
    rw [Real.log_exp] at hmoment ⊢
    linarith
  have hmass := mass_ge_half_euler_of_cutoff (scalePrimes marked ε Y x)
    hprimes Y (Real.exp (ε * Real.log x / 2)) τ hYp hR hτ hcutoff hcut hmoment'
  unfold scaleMass
  calc
    c / 16 * ε * Real.log x / Real.log Y =
        (1 / 2 : ℝ) * (c * Real.log (Real.exp (ε * Real.log x / 8)) / Real.log Y) := by
      rw [Real.log_exp]
      ring
    _ ≤ (1 / 2 : ℝ) * (∏ p ∈ scalePrimes marked ε Y x, (1 + 1 / (p : ℝ))) :=
      mul_le_mul_of_nonneg_left hprod (by norm_num)
    _ ≤ mass (scalePrimes marked ε Y x) (Real.exp (ε * Real.log x / 2)) τ := hmass

/-- A finite Euler product is bounded by the exponential of its reciprocal mass. -/
theorem euler_le_exp_sum {ι : Type*} (s : Finset ι) (u : ι → ℝ)
    (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∏ i ∈ s, (1 + u i)) ≤ Real.exp (∑ i ∈ s, u i) := by
  rw [Real.exp_sum]
  apply Finset.prod_le_prod₀
  · intro i hi
    linarith [hu i hi]
  · intro i hi
    simpa only [add_comm] using Real.add_one_le_exp (u i)

/-- Deleting marked primes costs at most an exponential in their reciprocal mass.
This proves the marked-band deduction from the ordinary Mertens product. -/
theorem euler_delete_lower {ι : Type*} [DecidableEq ι]
    (s marked : Finset ι) (u : ι → ℝ) (B : ℝ)
    (hu : ∀ i ∈ s, 0 ≤ u i) (hB : (∑ i ∈ s ∩ marked, u i) ≤ B) :
    Real.exp (-B) * (∏ i ∈ s, (1 + u i)) ≤
      ∏ i ∈ s \ marked, (1 + u i) := by
  have hpartition :
      (∏ i ∈ s \ marked, (1 + u i)) * (∏ i ∈ s ∩ marked, (1 + u i)) =
        ∏ i ∈ s, (1 + u i) := by
    rw [← Finset.prod_union, Finset.sdiff_union_inter]
    apply Finset.disjoint_left.mpr
    intro i hi hi'
    exact (Finset.mem_sdiff.mp hi).2 (Finset.mem_inter.mp hi').2
  have hm : (∏ i ∈ s ∩ marked, (1 + u i)) ≤ Real.exp B :=
    (euler_le_exp_sum (s ∩ marked) u
      (fun i hi => hu i (Finset.mem_inter.mp hi).1)).trans (Real.exp_le_exp.mpr hB)
  have hp : 0 ≤ ∏ i ∈ s \ marked, (1 + u i) := by
    apply Finset.prod_nonneg
    intro i hi
    linarith [hu i (Finset.mem_sdiff.mp hi).1]
  have hh := mul_le_mul_of_nonneg_left hm hp
  rw [hpartition] at hh
  have hd : (∏ i ∈ s, (1 + u i)) / Real.exp B ≤
      ∏ i ∈ s \ marked, (1 + u i) := (div_le_iff₀ (Real.exp_pos B)).mpr hh
  simpa [Real.exp_neg, div_eq_mul_inv, mul_comm] using hd

/-- Unmarked primes are exactly the ordinary prime interval minus the marked set. -/
theorem unmarkedPrimes_eq_sdiff (marked : Finset ℕ) (Y Z : ℝ) :
    unmarkedPrimes marked Y Z = unmarkedPrimes ∅ Y Z \ marked := by
  classical
  ext p
  simp [unmarkedPrimes, and_assoc, and_left_comm, and_comm]

/-- The scale `Z = exp(ε log x/8)` tends to infinity for every fixed positive ε. -/
theorem cofactor_scale_tendsto (ε : ℝ) (hε : 0 < ε) :
    Tendsto (fun x : ℝ => Real.exp (ε * Real.log x / 8)) atTop atTop := by
  have h := Real.tendsto_exp_atTop.comp
    (Filter.Tendsto.const_mul_atTop (show 0 < ε / 8 by positivity) Real.tendsto_log_atTop)
  convert h using 1
  ext x
  congr 1
  ring

/-- Full uniform cofactor lower bound from the ordinary, undeleted classical
prime estimates and a bounded total reciprocal mass of the marked prime bands.
This version does not assume any Mertens estimate for a custom prime family. -/
theorem uniform_mass_lower_from_classical
    (marked : ℝ → Finset ℕ) (c B Y₀ : ℝ) (hc : 0 < c) (hY₀ : 1 < Y₀)
    (hmarked : ∀ᶠ x : ℝ in atTop, (∑ p ∈ marked x, 1 / (p : ℝ)) ≤ B)
    (hmertens : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c * Real.log Z / Real.log Y ≤
        ∏ p ∈ unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ)))
    (hlogmoment : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ unmarkedPrimes ∅ Y Z, Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤
        (4 / 3 : ℝ) * Real.log Z) :
    ∃ A : ℝ, 0 < A ∧ ∀ ε : ℝ, 0 < ε → ∀ τ : ℝ, 0 < τ →
      ∀ Y : ℝ, Y₀ ≤ Y → 10 / τ ≤ Y →
        ∀ᶠ x : ℝ in atTop,
          A * ε * Real.log x / Real.log Y ≤ scaleMass marked ε Y τ x := by
  apply uniform_mass_lower_bound marked (c * Real.exp (-B)) Y₀ (by positivity) hY₀
  · intro ε hε Y hY
    filter_upwards [(cofactor_scale_tendsto ε hε).eventually (hmertens Y hY), hmarked]
      with x hprod hmark
    let Z := Real.exp (ε * Real.log x / 8)
    have hsub :
        (∑ p ∈ unmarkedPrimes ∅ Y Z ∩ marked x, 1 / (p : ℝ)) ≤ B := by
      refine (Finset.sum_le_sum_of_subset_of_nonneg Finset.inter_subset_right
        (fun p hp _ => ?_)).trans hmark
      positivity
    have hdel := euler_delete_lower (unmarkedPrimes ∅ Y Z) (marked x)
      (fun p => 1 / (p : ℝ)) B (fun p hp => by positivity) hsub
    rw [← unmarkedPrimes_eq_sdiff] at hdel
    unfold scalePrimes
    calc
      c * Real.exp (-B) * Real.log Z / Real.log Y =
          Real.exp (-B) * (c * Real.log Z / Real.log Y) := by ring
      _ ≤ Real.exp (-B) * (∏ p ∈ unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ))) :=
        mul_le_mul_of_nonneg_left hprod (Real.exp_pos _).le
      _ ≤ ∏ p ∈ unmarkedPrimes (marked x) Y Z, (1 + 1 / (p : ℝ)) := hdel
  · intro ε hε Y hY
    filter_upwards [(cofactor_scale_tendsto ε hε).eventually (hlogmoment Y hY)]
      with x hmom
    refine le_trans ?_ hmom
    unfold scalePrimes
    rw [unmarkedPrimes_eq_sdiff]
    apply Finset.sum_le_sum_of_subset_of_nonneg Finset.sdiff_subset
    intro p hp _
    have hprime := unmarkedPrimes_prime ∅ Y (Real.exp (ε * Real.log x / 8)) hp
    apply div_nonneg
    · exact Real.log_nonneg (by exact_mod_cast hprime.one_le)
    · positivity

/-- Finite Rankin inequality in exponential form. It applies directly to
`f n = log n`, including weights built from all permitted prime powers. -/
theorem finite_rankin {ι : Type*} (s : Finset ι) (w f : ι → ℝ)
    (T v : ℝ) (hv : 0 ≤ v) (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s.filter (fun i => T < f i), w i) ≤
      Real.exp (-v * T) * (∑ i ∈ s, w i * Real.exp (v * f i)) := by
  classical
  have hh : Real.exp (v * T) * (∑ i ∈ s.filter (fun i => T < f i), w i) ≤
      ∑ i ∈ s, w i * Real.exp (v * f i) := by
    rw [Finset.sum_filter, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    by_cases h : T < f i
    · simp only [h, ite_true]
      have hexp := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left h.le hv)
      nlinarith [mul_le_mul_of_nonneg_left hexp (hw i hi)]
    · simp only [h, ite_false, mul_zero]
      positivity [hw i hi, Real.exp_pos (v * f i)]
  have hd : (∑ i ∈ s.filter (fun i => T < f i), w i) ≤
      (∑ i ∈ s, w i * Real.exp (v * f i)) / Real.exp (v * T) :=
    (le_div_iff₀ (Real.exp_pos (v * T))).mpr (by simpa only [mul_comm] using hh)
  simpa [neg_mul, Real.exp_neg, div_eq_mul_inv, mul_comm] using hd

/-- The exponential moment of squarefree product weights is its exact Euler product. -/
theorem subset_exponential_moment {ι : Type*} (s : Finset ι) (u f : ι → ℝ) (v : ℝ) :
    (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * Real.exp (v * ∑ i ∈ t, f i)) =
      ∏ i ∈ s, (1 + u i * Real.exp (v * f i)) := by
  rw [← Cofactor.subset_euler_product]
  apply Finset.sum_congr rfl
  intro t ht
  rw [Finset.mul_sum, Real.exp_sum, Finset.prod_mul_distrib]

/-- Rankin's squarefree-product tail bound with no unproved independence assertion. -/
theorem subset_rankin {ι : Type*} (s : Finset ι) (u f : ι → ℝ) (T v : ℝ)
    (hv : 0 ≤ v) (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ t ∈ s.powerset.filter (fun t => T < ∑ i ∈ t, f i), ∏ i ∈ t, u i) ≤
      Real.exp (-v * T) * (∏ i ∈ s, (1 + u i * Real.exp (v * f i))) := by
  have h := finite_rankin s.powerset (fun t => ∏ i ∈ t, u i)
    (fun t => ∑ i ∈ t, f i) T v hv (fun t ht =>
      Finset.prod_nonneg (fun i hi => hu i ((Finset.mem_powerset.mp ht) hi)))
  simpa only [subset_exponential_moment] using h

/-- The geometric-series bound, uniform in the exponent cutoff. -/
theorem truncated_geometric_le (r : ℝ) (hr : 0 ≤ r) (hr1 : r < 1) (M : ℕ) :
    (∑ k ∈ Finset.range M, r ^ k) ≤ 1 / (1 - r) := by
  apply (le_div_iff₀ (by linarith : 0 < 1 - r)).mpr
  rw [geom_sum_mul_neg]
  exact sub_le_self _ (pow_nonneg hr M)

/-- All prime powers up to any finite exponent cutoff have the exact product
of local geometric sums. This is the finite Euler-product identity needed for
marked supported integers, where exponents are not restricted to zero or one. -/
theorem finite_power_euler {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r : ι → ℝ) (M : ℕ) :
    (∑ e : ι → Fin M, ∏ i, r i ^ (e i).val) =
      ∏ i, ∑ k ∈ Finset.range M, r i ^ k := by
  calc
    (∑ e : ι → Fin M, ∏ i, r i ^ (e i).val) = ∏ i, ∑ k : Fin M, r i ^ k.val :=
      (Fintype.prod_sum (fun i (k : Fin M) => r i ^ k.val)).symm
    _ = ∏ i, ∑ k ∈ Finset.range M, r i ^ k := by
      apply Finset.prod_congr rfl
      intro i hi
      exact Fin.sum_univ_eq_sum_range (fun k => r i ^ k) M

/-- Uniform finite geometric Euler-product bound, retaining every prime power. -/
theorem finite_power_geometric_upper {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r : ι → ℝ) (M : ℕ) (hr : ∀ i, 0 ≤ r i) (hr1 : ∀ i, r i < 1) :
    (∑ e : ι → Fin M, ∏ i, r i ^ (e i).val) ≤
      ∏ i, 1 / (1 - r i) := by
  rw [finite_power_euler]
  apply Finset.prod_le_prod₀
  · intro i hi
    exact Finset.sum_nonneg (fun k hk => pow_nonneg (hr i) k)
  · intro i hi
    exact truncated_geometric_le (r i) (hr i) (hr1 i) M

/-- A local geometric factor is exponentially bounded for `r ≤ 1/2`. -/
theorem geometric_factor_le_exp (r : ℝ) (hr : 0 ≤ r) (hr2 : r ≤ 1 / 2) :
    1 / (1 - r) ≤ Real.exp (2 * r) := by
  have hden : 0 < 1 - r := by linarith
  have helem : 1 / (1 - r) ≤ 1 + 2 * r := by
    apply (div_le_iff₀ hden).mpr
    nlinarith
  exact helem.trans (by simpa only [add_comm] using Real.add_one_le_exp (2 * r))

/-- Marked weights bounded by `W₀` have uniformly bounded prime-power moments
as soon as the sum of the local ratios is bounded. The constants are independent
of the exponent cutoff and the number of permitted prime powers. -/
theorem bounded_power_moment {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r : ι → ℝ) (M : ℕ) (W : (ι → Fin M) → ℝ) (W₀ B : ℝ)
    (hW₀ : 0 ≤ W₀) (hW : ∀ e, W e ≤ W₀)
    (hr : ∀ i, 0 ≤ r i) (hr2 : ∀ i, r i ≤ 1 / 2)
    (hB : (∑ i, r i) ≤ B) :
    (∑ e : ι → Fin M, W e * ∏ i, r i ^ (e i).val) ≤
      W₀ * Real.exp (2 * B) := by
  have hlocal : (∏ i, 1 / (1 - r i)) ≤ Real.exp (2 * B) := by
    calc
      (∏ i, 1 / (1 - r i)) ≤ ∏ i, Real.exp (2 * r i) := by
        apply Finset.prod_le_prod₀
        · intro i hi
          apply one_div_nonneg.mpr
          linarith [hr2 i]
        · intro i hi
          exact geometric_factor_le_exp (r i) (hr i) (hr2 i)
      _ = Real.exp (2 * ∑ i, r i) := by rw [Finset.mul_sum, Real.exp_sum]
      _ ≤ Real.exp (2 * B) := Real.exp_le_exp.mpr (by linarith)
  calc
    (∑ e : ι → Fin M, W e * ∏ i, r i ^ (e i).val) ≤
        ∑ e : ι → Fin M, W₀ * ∏ i, r i ^ (e i).val := by
      apply Finset.sum_le_sum
      intro e he
      exact mul_le_mul_of_nonneg_right (hW e)
        (Finset.prod_nonneg (fun i hi => pow_nonneg (hr i) _))
    _ = W₀ * (∑ e : ι → Fin M, ∏ i, r i ^ (e i).val) := (Finset.mul_sum _ _ _).symm
    _ ≤ W₀ * (∏ i, 1 / (1 - r i)) :=
      mul_le_mul_of_nonneg_left
        (finite_power_geometric_upper r M hr (fun i => by linarith [hr2 i])) hW₀
    _ ≤ W₀ * Real.exp (2 * B) := mul_le_mul_of_nonneg_left hlocal hW₀

/-- A set of prime divisors above `T` has reciprocal mass controlled by the
logarithmic size of the integer. This is uniform in the integer and its support. -/
theorem prime_divisor_reciprocal_bound (S : Finset ℕ) (n : ℕ) (T : ℝ)
    (hn : 0 < n) (hT : 1 < T)
    (hS : ∀ p ∈ S, Nat.Prime p ∧ p ∣ n ∧ T ≤ (p : ℝ)) :
    (∑ p ∈ S, 1 / (p : ℝ)) ≤ Real.log (n : ℝ) / (Real.log T * T) := by
  have hTp : 0 < T := by linarith
  have hcard := Artin.prime_divisors_card_le hn hT hS
  calc
    (∑ p ∈ S, 1 / (p : ℝ)) ≤ ∑ _p ∈ S, 1 / T := by
      apply Finset.sum_le_sum
      intro p hp
      exact one_div_le_one_div_of_le hTp (hS p hp).2.2
    _ = (S.card : ℝ) / T := by simp [div_eq_mul_inv]
    _ ≤ (Real.log (n : ℝ) / Real.log T) / T :=
      div_le_div_of_nonneg_right hcard hTp.le
    _ = Real.log (n : ℝ) / (Real.log T * T) := by ring

/-- The explicit uniform error for marked prime divisors; the power `9/10`
comes from dividing the available logarithmic size by the smallest prime log. -/
noncomputable def markedDivisorError (C x : ℝ) : ℝ :=
  C * (Real.log x) ^ (9 / 10 : ℝ) * Real.exp (-((Real.log x) ^ (1 / 10 : ℝ)))

/-- Actual prime-factor reciprocal sums satisfy the manuscript's uniform `o(1)`
majorant whenever the integer is at most `x^C` and every factor is in a marked band. -/
theorem marked_prime_divisor_bound (n : ℕ) (C x : ℝ)
    (hn : 0 < n) (_hC : 0 ≤ C) (hx : 1 < x) (hnx : (n : ℝ) ≤ x ^ C)
    (hmarked : ∀ p ∈ n.primeFactors,
      Real.exp ((Real.log x) ^ (1 / 10 : ℝ)) ≤ (p : ℝ)) :
    (∑ p ∈ n.primeFactors, 1 / (p : ℝ)) ≤ markedDivisorError C x := by
  have hL : 0 < Real.log x := Real.log_pos hx
  have ht : 0 < (Real.log x) ^ (1 / 10 : ℝ) := Real.rpow_pos_of_pos hL _
  have hT : 1 < Real.exp ((Real.log x) ^ (1 / 10 : ℝ)) :=
    Real.one_lt_exp_iff.mpr ht
  have hbound := prime_divisor_reciprocal_bound n.primeFactors n
    (Real.exp ((Real.log x) ^ (1 / 10 : ℝ))) hn hT (fun p hp =>
      ⟨(Nat.mem_primeFactors.mp hp).1, (Nat.mem_primeFactors.mp hp).2.1, hmarked p hp⟩)
  have hlog : Real.log (n : ℝ) ≤ C * Real.log x := by
    have hnp : (0 : ℝ) < n := by exact_mod_cast hn
    have hh := Real.log_le_log hnp hnx
    rwa [Real.log_rpow (by linarith : 0 < x)] at hh
  refine hbound.trans ?_
  rw [Real.log_exp]
  have hden : 0 < (Real.log x) ^ (1 / 10 : ℝ) * Real.exp ((Real.log x) ^ (1 / 10 : ℝ)) :=
    mul_pos ht (Real.exp_pos _)
  calc
    Real.log (n : ℝ) /
        ((Real.log x) ^ (1 / 10 : ℝ) * Real.exp ((Real.log x) ^ (1 / 10 : ℝ))) ≤
        (C * Real.log x) /
        ((Real.log x) ^ (1 / 10 : ℝ) * Real.exp ((Real.log x) ^ (1 / 10 : ℝ))) :=
      div_le_div_of_nonneg_right hlog hden.le
    _ = markedDivisorError C x := by
      unfold markedDivisorError
      have hp : (9 / 10 : ℝ) = 1 - 1 / 10 := by norm_num
      rw [hp, Real.rpow_sub hL, Real.rpow_one, Real.exp_neg]
      ring

/-- The preceding bound tends to zero for every fixed `C`. -/
theorem markedDivisorError_tendsto (C : ℝ) :
    Tendsto (markedDivisorError C) atTop (nhds 0) := by
  have ht : Tendsto (fun x : ℝ => (Real.log x) ^ (1 / 10 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 1 / 10)).comp Real.tendsto_log_atTop
  have hh := ((Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero 9).comp ht).const_mul C
  simp only [mul_zero] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  unfold markedDivisorError
  have hL := (Real.log_pos hx).le
  have hp : ((Real.log x) ^ (1 / 10 : ℝ)) ^ (9 : ℕ) =
      (Real.log x) ^ (9 / 10 : ℝ) := by
    rw [← Real.rpow_mul_natCast hL]
    norm_num
  dsimp only [Function.comp_def]
  rw [hp]
  ring

/-- Uniformity over all marked cofactors, not merely a pointwise limit for each
integer. This is the quantifier order needed to omit marked factors in the sieve. -/
theorem marked_prime_divisor_mass_uniform (C : ℝ) (hC : 0 ≤ C) :
    ∀ η : ℝ, 0 < η → ∀ᶠ x : ℝ in atTop,
      ∀ n : ℕ, 0 < n → (n : ℝ) ≤ x ^ C →
        (∀ p ∈ n.primeFactors,
          Real.exp ((Real.log x) ^ (1 / 10 : ℝ)) ≤ (p : ℝ)) →
        (∑ p ∈ n.primeFactors, 1 / (p : ℝ)) < η := by
  intro η hη
  filter_upwards [(markedDivisorError_tendsto C).eventually_lt_const hη,
    eventually_gt_atTop (1 : ℝ)] with x herror hx
  intro n hn hnx hmarked
  exact (marked_prime_divisor_bound n C x hn hC hx hnx hmarked).trans_lt herror

/-- Every actual cofactor is positive. -/
theorem cofactor_pos (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) {r : ℕ} (hr : r ∈ cofactors s R τ) : 0 < r := by
  classical
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hr
  apply Finset.prod_pos
  intro p hp
  exact (hs p ((Finset.mem_powerset.mp (Finset.mem_filter.mp ht).1) hp)).pos

/-- A prime divisor of an actual cofactor belongs to its allowed prime set. -/
theorem prime_dvd_cofactor_mem (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p)
    (R τ : ℝ) {r q : ℕ} (hr : r ∈ cofactors s R τ)
    (hq : q.Prime) (hqr : q ∣ r) : q ∈ s := by
  classical
  obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hr
  have htp : ∀ p ∈ t, p.Prime :=
    fun p hp => hs p ((Finset.mem_powerset.mp (Finset.mem_filter.mp ht).1) hp)
  have hpos : 0 < ∏ p ∈ t, p := Finset.prod_pos (fun p hp => (htp p hp).pos)
  have hmem := hq.mem_primeFactors hqr hpos.ne'
  rw [Nat.primeFactors_prod htp] at hmem
  exact (Finset.mem_powerset.mp (Finset.mem_filter.mp ht).1) hmem

end Artin.CofactorAsymptotics
