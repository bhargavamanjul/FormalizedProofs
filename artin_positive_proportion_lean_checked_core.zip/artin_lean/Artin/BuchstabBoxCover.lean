module

public import Artin.BuchstabBoxes
public import Artin.DisjointPairSums

/-!
# The disjoint dyadic cover of the actual Buchstab factor sum

Only nonzero product weights need to be covered. The support condition
selects the explicit strip indices, and half-open dyads prevent repeated
ordered factor pairs.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.BuchstabBoxCover

open RoughCompanion SemiprimeReplacement BuchstabBoxes DisjointPairSums

/-- A real number belongs to at most one half-open dyadic interval. -/
theorem inBin_unique {a b : ℤ} {t : ℝ}
    (ha : DyadicBoxes.InBin a t) (hb : DyadicBoxes.InBin b t) : a = b := by
  rcases lt_trichotomy a b with hab | hab | hab
  · have hpow : (2 : ℝ) ^ (a + 1) ≤ (2 : ℝ) ^ b :=
      zpow_le_zpow_right₀ (by norm_num) (by omega)
    exact False.elim ((not_lt_of_ge (hpow.trans hb.1)) ha.2)
  · exact hab
  · have hpow : (2 : ℝ) ^ (b + 1) ≤ (2 : ℝ) ^ a :=
      zpow_le_zpow_right₀ (by norm_num) (by omega)
    exact False.elim ((not_lt_of_ge (hpow.trans ha.1)) hb.2)

/-- Distinct half-open integer dyads are disjoint. -/
theorem natDyad_disjoint {a b : ℤ} (hab : a ≠ b) :
    Disjoint (natDyad a) (natDyad b) := by
  apply Finset.disjoint_left.mpr
  intro m hm hn
  exact hab (inBin_unique (mem_natDyad.mp hm) (mem_natDyad.mp hn))

/-- The actual complementary dyads and prime boxes form disjoint sets of
ordered factor pairs. This holds on every finite index set. -/
theorem boxes_pairwiseDisjoint (x γ γ' : ℝ) (I : Finset (ℤ × ℤ)) :
    Set.PairwiseDisjoint (↑I)
      (fun ab => natDyad ab.2 ×ˢ primeBox x γ γ' ab) := by
  intro ab hab cd hcd hne
  apply Finset.disjoint_left.mpr
  intro p hp hq
  obtain ⟨hpm, hpn⟩ := Finset.mem_product.mp hp
  obtain ⟨hqm, hqn⟩ := Finset.mem_product.mp hq
  have hm : ab.2 = cd.2 := inBin_unique (mem_natDyad.mp hpm) (mem_natDyad.mp hqm)
  have hn : ab.1 = cd.1 := inBin_unique
    (mem_natDyad.mp (Finset.mem_filter.mp hpn).2)
    (mem_natDyad.mp (Finset.mem_filter.mp hqn).2)
  exact hne (Prod.ext hn hm)

/-- The pair set uses complementary-factor-first order, matching the
marked-replacement convention. Roughness remains in the summand. -/
noncomputable def factorPairs (N : ℕ) (lo hi : ℝ) : Finset (ℕ × ℕ) := by
  classical
  exact ((Finset.range (N + 1)) ×ˢ (Finset.range (N + 1))).filter
    (fun mn => mn.2.Prime ∧ lo < (mn.2 : ℝ) ∧ (mn.2 : ℝ) ≤ hi)

theorem factorBinMass_eq_weightedPairs (N : ℕ) (w : ℕ → ℝ) (lo hi : ℝ) :
    BuchstabPartition.factorBinMass N w lo hi =
      weightedPairs (factorPairs N lo hi) w (realRoughIndicator lo) primeIndicator := by
  classical
  rw [BuchstabPartition.factorBinMass_eq_double_sum]
  unfold weightedPairs factorPairs
  rw [Finset.sum_filter, Finset.sum_product, Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  apply Finset.sum_congr rfl
  intro n hn
  have hrough : BuchstabPartition.IsRough lo m ↔ MarkedCriterion.IsRough lo m := Iff.rfl
  simp only [hrough]
  by_cases hp : n.Prime <;> by_cases hlo : lo < (n : ℝ) <;>
    by_cases hhi : (n : ℝ) ≤ hi <;> by_cases hr : MarkedCriterion.IsRough lo m <;>
    simp [hp, hlo, hhi, hr, realRoughIndicator, primeIndicator]

/-- Every nonzero factor-bin summand belongs to its actual dyadic box. -/
theorem factorPairs_support_cover {x γ γ' : ℝ} (hx : 0 < x) (N : ℕ)
    (w : ℕ → ℝ)
    (hsupport : ∀ d, w d ≠ 0 → x ≤ (d : ℝ) ∧ (d : ℝ) ≤ 2 * x)
    {p : ℕ × ℕ} (hp : p ∈ factorPairs N (x ^ γ) (x ^ γ'))
    (hne : w (p.1 * p.2) * realRoughIndicator (x ^ γ) p.1 * primeIndicator p.2 ≠ 0) :
    ∃ ab ∈ indices x γ γ', p.1 ∈ natDyad ab.2 ∧ p.2 ∈ primeBox x γ γ' ab := by
  classical
  have hfilter := (Finset.mem_filter.mp hp).2
  have hweight : w (p.1 * p.2) ≠ 0 := by
    intro hz
    exact hne (by simp [hz])
  have hprod := hsupport _ hweight
  have hm : (0 : ℝ) < p.1 := by
    have hm0 : p.1 ≠ 0 := by
      intro hz
      simp only [hz, zero_mul, Nat.cast_zero] at hprod
      linarith [hprod.1]
    exact_mod_cast Nat.pos_of_ne_zero hm0
  have hn : (0 : ℝ) < p.2 := by exact_mod_cast hfilter.1.pos
  have hprod' : x ≤ (p.1 : ℝ) * p.2 ∧ (p.1 : ℝ) * p.2 ≤ 2 * x := by
    simpa only [Nat.cast_mul] using hprod
  obtain ⟨ab, hab, hmab, hnab⟩ := exists_box hx hm hn hfilter.2.1.le hfilter.2.2
    hprod'.1 hprod'.2
  refine ⟨ab, hab, mem_natDyad.mpr hmab, ?_⟩
  apply Finset.mem_filter.mpr
  exact ⟨(mem_primeBin hx).mpr hfilter, mem_natDyad.mpr hnab⟩

/-- The full original Buchstab factor sum is bounded by its actual finite
family of boxes. Neither the cover nor disjointness is an extra premise. -/
theorem factorBinMass_le_sum_boxes {x γ γ' : ℝ} (hx : 0 < x) (N : ℕ)
    (w : ℕ → ℝ) (hw : ∀ d, 0 ≤ w d)
    (hsupport : ∀ d, w d ≠ 0 → x ≤ (d : ℝ) ∧ (d : ℝ) ≤ 2 * x) :
    BuchstabPartition.factorBinMass N w (x ^ γ) (x ^ γ') ≤
      ∑ ab ∈ indices x γ γ', pairMass (natDyad ab.2) (primeBox x γ γ' ab)
        w (realRoughIndicator (x ^ γ)) primeIndicator := by
  classical
  rw [factorBinMass_eq_weightedPairs]
  apply weightedPairs_le_sum_pairMass _ (indices x γ γ')
    (fun ab => natDyad ab.2) (primeBox x γ γ') w
    (realRoughIndicator (x ^ γ)) primeIndicator
    (boxes_pairwiseDisjoint x γ γ' _) hw (realRoughIndicator_nonneg _) ?_ ?_
  · intro n
    unfold primeIndicator
    split_ifs <;> norm_num
  · intro p hp hne
    exact factorPairs_support_cover hx N w hsupport hp hne

/-- Every prime in an actual bin is rough at any lower sieve cutoff. -/
theorem primeBox_isRough {x γ γ' y : ℝ} (hx : 0 < x) (hy : y ≤ x ^ γ)
    {ab : ℤ × ℤ} {n : ℕ} (hn : n ∈ primeBox x γ γ' ab) :
    MarkedCriterion.IsRough y n := by
  have hb := primeBox_bounds hx ab hn
  intro p hp hpn
  have heq : p = n := (Nat.prime_dvd_prime_iff_eq hp hb.1).mp hpn
  rw [heq]
  exact hy.trans_lt hb.2.1

/-- Once the dyads are recombined, their total replacement mass is bounded
by the literal prime-divisor-conditioned mass over the actual prime bin. -/
theorem sum_boxes_le_conditionedMass {x γ γ' y : ℝ} (hx : 0 < x)
    (hy : y ≤ x ^ γ) (D : Finset ℕ) (w : ℕ → ℝ) (hw : ∀ d, 0 ≤ w d)
    (hsupport : ∀ d, w d ≠ 0 → d ∈ D) :
    (∑ ab ∈ indices x γ γ', pairMass (natDyad ab.2) (primeBox x γ γ' ab)
      w (realRoughIndicator y) primeIndicator) ≤
      BuchstabMR.conditionedMass D (primeBin x γ γ') w y := by
  classical
  apply sum_pairMass_le_conditionedMass _ _ _ D (primeBin x γ γ') w y
    (boxes_pairwiseDisjoint x γ γ' _) hw
  · intro ab hab
    exact Finset.filter_subset _ _
  · intro ab hab n hn _hprime
    exact primeBox_isRough hx hy hn
  · intro ab hab m hm n hn hne
    exact hsupport (m * n) hne

end Artin.BuchstabBoxCover
