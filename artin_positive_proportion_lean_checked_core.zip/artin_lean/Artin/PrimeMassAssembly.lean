module

public import Artin.PrimeMainMass
public import Artin.PrimeDistribution
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-!
# Uniform positive mass of the actual prime sums

This module assembles the fixed-modulus prime number theorem, the proved
quadrature formula, and the actual positive integral of the fixed weight.
The cutoff, support conditions, and error absorption are uniform throughout
the growing range of cofactors. No marking parameter occurs in its constants.
-/

@[expose] public section

open Filter MeasureTheory

namespace Artin.PrimeMassAssembly

open PrimeDistribution PrimeMainMass

/-- A concrete integer cutoff containing the entire affine support. -/
noncomputable def primeCutoff (x s : ℝ) : ℕ := ⌈2 * x / s⌉₊

theorem primeCutoff_bounds {x s : ℝ} (hx : 0 < x) (hs : 0 < s)
    (hsx : s ≤ x) :
    2 ≤ primeCutoff x s ∧
      (2 * x - 1) / s ≤ (primeCutoff x s : ℝ) ∧
      (primeCutoff x s : ℝ) * s ≤ 3 * x := by
  have hnonneg : 0 ≤ 2 * x / s := by positivity
  have hlo : 2 * x / s ≤ (primeCutoff x s : ℝ) := Nat.le_ceil _
  have htwo : (2 : ℝ) ≤ 2 * x / s := (le_div_iff₀ hs).mpr (by linarith)
  have hhi : (primeCutoff x s : ℝ) < 2 * x / s + 1 := Nat.ceil_lt_add_one hnonneg
  refine ⟨by exact_mod_cast htwo.trans hlo, ?_, ?_⟩
  · exact (div_le_div_of_nonneg_right (by linarith) hs.le).trans hlo
  · have hmul := mul_lt_mul_of_pos_right hhi hs
    have hid : (2 * x / s + 1) * s = 2 * x + s := by field_simp
    rw [hid] at hmul
    linarith

/-- All support conditions hold with one threshold for the whole cofactor
range. The deliberately generous exponent leaves room for every fixed `c`. -/
theorem eventually_affine_support_conditions {c : ℝ} (hc : 1 ≤ c) :
    ∀ᶠ x : ℝ in atTop, ∀ r : ℝ,
      1 ≤ r → r ≤ x ^ (1 / 100 : ℝ) →
        1 < x ∧ 1 ≤ c * r ∧ c * r ≤ x ∧
          2 ≤ x ^ (9 / 10 : ℝ) ∧
          c * r * x ^ (9 / 10 : ℝ) < x - 1 := by
  have hc0 : 0 < c := zero_lt_one.trans_le hc
  have hpow : ∀ᶠ x : ℝ in atTop, 2 * c ≤ x ^ (9 / 100 : ℝ) :=
    (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 9 / 100)).eventually
      (eventually_ge_atTop _)
  have hlarge : ∀ᶠ x : ℝ in atTop, 2 ≤ x ^ (9 / 10 : ℝ) :=
    (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 9 / 10)).eventually
      (eventually_ge_atTop _)
  filter_upwards [hpow, hlarge, eventually_gt_atTop (2 : ℝ)] with x hp hl hx
  intro r hr hrange
  have hx0 : 0 < x := by linarith
  have hcr : 1 ≤ c * r := by nlinarith
  have hprod : c * r * x ^ (9 / 10 : ℝ) ≤ x / 2 := by
    have h := mul_le_mul hp hrange (by linarith : 0 ≤ r)
      (Real.rpow_nonneg hx0.le _)
    have hh := mul_le_mul_of_nonneg_right h (Real.rpow_nonneg hx0.le (9 / 10))
    have hid : (x ^ (9 / 100 : ℝ) * x ^ (1 / 100 : ℝ)) *
        x ^ (9 / 10 : ℝ) = x := by
      rw [← Real.rpow_add hx0, ← Real.rpow_add hx0]
      norm_num
    rw [hid] at hh
    nlinarith
  have hsx : c * r ≤ x := by
    have hmul := mul_le_mul_of_nonneg_left (show (1 : ℝ) ≤ x ^ (9 / 10 : ℝ) by linarith)
      (by positivity : 0 ≤ c * r)
    nlinarith
  exact ⟨by linarith, hcr, hsx, hl, by linarith⟩

/-- The bounded affine interval has a variation bound depending only on
the chosen fixed weight. -/
theorem primeCutoff_variation (Ψ : ℝ → ℝ) {B K x s : ℝ}
    (hx : 0 < x) (hs : 0 < s) (hsx : s ≤ x) (hK : 0 ≤ K)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|)
    (hB : ∀ y, |Ψ y| ≤ B) :
    variation (fun n : ℕ => Ψ ((s * n + 1) / x)) (primeCutoff x s) ≤ B + 3 * K := by
  have hNs := (primeCutoff_bounds hx hs hsx).2.2
  have hNa : (primeCutoff x s : ℝ) * (s / x) ≤ 3 := by
    rw [← mul_div_assoc]
    exact (div_le_iff₀ hx).mpr hNs
  have h := variation_affine_uniform Ψ (primeCutoff x s)
    (b := 1 / x) (div_nonneg hs.le hx.le) hK hNa hLip (hB _)
  have hid (n : ℕ) : s / x * n + 1 / x = (s * n + 1) / x := by ring
  simpa only [hid, mul_comm K 3] using h

/-- Every fixed quadrature error is negligible compared with the prime mass,
simultaneously for all cofactors in the allowed range. -/
theorem eventually_constant_le_massScale {D η : ℝ} (hD : 0 ≤ D) (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop, ∀ r : ℝ, 0 < r → r ≤ x ^ (1 / 100 : ℝ) →
      D ≤ η * (x / r) / Real.log x := by
  have hlo := isLittleO_log_rpow_rpow_atTop (1 : ℝ)
    (show (0 : ℝ) < 99 / 100 by norm_num)
  have he := hlo.def (show 0 < η / (D + 1) by positivity)
  filter_upwards [he, eventually_gt_atTop (1 : ℝ)] with x he hx
  intro r hr hrange
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have he' : Real.log x ≤ η / (D + 1) * x ^ (99 / 100 : ℝ) := by
    simpa only [Real.rpow_one, Real.norm_of_nonneg hL.le,
      Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _)] using he
  have hmul := mul_le_mul hrange he' hL.le (Real.rpow_nonneg hx0.le _)
  have hid : x ^ (1 / 100 : ℝ) * (η / (D + 1) * x ^ (99 / 100 : ℝ)) =
      η / (D + 1) * x := by
    rw [mul_left_comm, ← Real.rpow_add hx0]
    norm_num
  rw [hid] at hmul
  have hscaled : D * (r * Real.log x) ≤ η * x := by
    have hm := (le_div_iff₀ (show 0 < D + 1 by positivity)).mp
      (show r * Real.log x ≤ η * x / (D + 1) by simpa only [div_mul_eq_mul_div] using hmul)
    nlinarith [mul_pos hr hL]
  apply (le_div_iff₀ hL).mpr
  rw [← mul_div_assoc]
  apply (le_div_iff₀ hr).mpr
  nlinarith

/-- The prime count with the actual residue condition and affine weight. -/
noncomputable def primeMass (c M₀ v : ℕ) (Ψ : ℝ → ℝ) (x : ℝ) (r : ℕ) : ℝ :=
  CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
    ((Finset.range (primeCutoff x ((c : ℝ) * r))).filter Nat.Prime)
    (fun d => Ψ ((d : ℝ) / x)) r

/-- Every nonzero sampled weight lies simultaneously in the moving affine
cutoff and in the common large-prime interval used by the full selector. -/
theorem nonzero_sample_bounds (Ψ : ℝ → ℝ)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {c r Q : ℕ} {x Qmin : ℝ} (hx : 0 < x)
    (hs : 1 ≤ (c : ℝ) * r)
    (hscale : (c : ℝ) * r * Qmin < x - 1)
    (hne : Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x) ≠ 0) :
    Q < primeCutoff x ((c : ℝ) * r) ∧ Q ≤ ⌊2 * x⌋₊ ∧ Qmin < (Q : ℝ) := by
  have hy : (((c * r * Q + 1 : ℕ) : ℝ) / x) ∈ Set.Icc (1 : ℝ) 2 := by
    by_contra hout
    exact hne (hsupport _ hout)
  have hlo := (le_div_iff₀ hx).mp hy.1
  have hhi := (div_le_iff₀ hx).mp hy.2
  push_cast at hlo hhi
  have hs0 : 0 < (c : ℝ) * r := zero_lt_one.trans_le hs
  have hQ0 : (0 : ℝ) ≤ Q := Nat.cast_nonneg Q
  refine ⟨?_, ?_, ?_⟩
  · apply Nat.lt_ceil.mpr
    apply (lt_div_iff₀ hs0).mpr
    nlinarith
  · apply Nat.le_floor
    nlinarith [mul_le_mul_of_nonneg_right hs hQ0]
  · by_contra hnot
    have hh := mul_le_mul_of_nonneg_left (le_of_not_gt hnot) hs0.le
    nlinarith

/-- The individual affine cutoff equals the one common prime set needed by
the ambient-weight decomposition. This is an exact equality, not a tail
estimate or a change to the invariant selector. -/
theorem primeMass_eq_common_sum {c M₀ v r : ℕ} (Ψ : ℝ → ℝ)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {x Qmin : ℝ} (hx : 0 < x) (hs : 1 ≤ (c : ℝ) * r)
    (hscale : (c : ℝ) * r * Qmin < x - 1) :
    primeMass c M₀ v Ψ x r =
      CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
        ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => Qmin < (Q : ℝ)))
        (fun d => Ψ ((d : ℝ) / x)) r := by
  classical
  unfold primeMass CofactorRepresentation.primeProgressionSum
  apply Finset.sum_congr_of_eq_on_inter
  · intro Q hQ hnot
    by_contra hne
    have hw : Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x) ≠ 0 := by
      intro hzero
      simp only [hzero, ite_self] at hne
      exact hne trivial
    obtain ⟨_, hb, hlarge⟩ := nonzero_sample_bounds Ψ hsupport hx hs hscale hw
    exact hnot (Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨hb, (Finset.mem_filter.mp hQ).2⟩, hlarge⟩)
  · intro Q hQ hnot
    by_contra hne
    have hw : Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x) ≠ 0 := by
      intro hzero
      simp only [hzero, ite_self] at hne
      exact hne trivial
    obtain ⟨hcut, _, _⟩ := nonzero_sample_bounds Ψ hsupport hx hs hscale hw
    exact hnot (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hcut,
      (Nat.mem_primesLE.mp (Finset.mem_filter.mp hQ).1).2⟩)
  · intro Q _ _
    rfl

/-- Divisibility constraints do not change the exact cutoff identity. -/
theorem sievedPrimeSum_eq_common_sum {c M u r ℓ : ℕ} (Ψ : ℝ → ℝ)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {x Qmin : ℝ} (hx : 0 < x) (hs : 1 ≤ (c : ℝ) * r)
    (hscale : (c : ℝ) * r * Qmin < x - 1) :
    PrimeProgressions.sievedPrimeSum c M u ℓ
        ((Finset.range (primeCutoff x ((c : ℝ) * r))).filter Nat.Prime)
        (fun d => Ψ ((d : ℝ) / x)) r =
      PrimeProgressions.sievedPrimeSum c M u ℓ
        ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => Qmin < (Q : ℝ)))
        (fun d => Ψ ((d : ℝ) / x)) r := by
  classical
  unfold PrimeProgressions.sievedPrimeSum
  apply Finset.sum_congr_of_eq_on_inter
  · intro Q hQ hnot
    by_contra hne
    have hw : Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x) ≠ 0 := by
      intro hzero
      simp only [hzero, ite_self] at hne
      exact hne trivial
    obtain ⟨_, hb, hlarge⟩ := nonzero_sample_bounds Ψ hsupport hx hs hscale hw
    exact hnot (Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨hb, (Finset.mem_filter.mp hQ).2⟩, hlarge⟩)
  · intro Q hQ hnot
    by_contra hne
    have hw : Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x) ≠ 0 := by
      intro hzero
      simp only [hzero, ite_self] at hne
      exact hne trivial
    obtain ⟨hcut, _, _⟩ := nonzero_sample_bounds Ψ hsupport hx hs hscale hw
    exact hnot (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hcut,
      (Nat.mem_primesLE.mp (Finset.mem_filter.mp hQ).1).2⟩)
  · intro Q _ _
    rfl

/-- Fixed-modulus PNT gives positive mass uniformly in every small cofactor.
Both displayed constants depend only on the fixed progression and weight,
and are chosen before any marking parameters. -/
theorem uniform_primeMass_bounds (hPNT : FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ) (hΨ0 : ∀ y, 0 ≤ Ψ y)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {B K : ℝ} (hB : 0 < B) (hK : 0 ≤ K)
    (hbound : ∀ y, |Ψ y| ≤ B)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|)
    (hμ : 0 < weightMass Ψ) :
    ∀ᶠ x : ℝ in atTop, ∀ r : ℕ,
      0 < r → (r : ℝ) ≤ x ^ (1 / 100 : ℝ) → r.Coprime M₀ →
      weightMass Ψ / (4 * c * (M₀.totient : ℝ)) * ((x / r) / Real.log x) ≤
        primeMass c M₀ v Ψ x r ∧
      primeMass c M₀ v Ψ x r ≤
        (2 * weightMass Ψ / ((c : ℝ) * M₀.totient)) * ((x / r) / Real.log x) := by
  have hc : (0 : ℝ) < c := by exact_mod_cast NeZero.pos c
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  have hφ : (0 : ℝ) < M₀.totient := by
    exact_mod_cast Nat.totient_pos.mpr (NeZero.pos M₀)
  let α : ℝ := weightMass Ψ / (4 * c * (M₀.totient : ℝ))
  have hα : 0 < α := by dsimp [α]; positivity
  let D : ℝ := (3 * K / Real.log 2) / (M₀.totient : ℝ)
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hV : 0 < B + 3 * K := by positivity
  obtain ⟨C, hC, hP⟩ := hPNT.uniform_cofactors hu hv
    (A := 2) (by norm_num) hV
  have hlog : ∀ᶠ x : ℝ in atTop, 2 * C / α ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop _)
  have hquad := eventually_constant_le_massScale hD (show 0 < α / 2 by positivity)
  filter_upwards [hP, eventually_affine_support_conditions hc1, hlog, hquad]
    with x hP hsupportx hlog hquad
  intro r hr hrange hrM
  have hr0 : (0 : ℝ) < r := by exact_mod_cast hr
  have hr1 : (1 : ℝ) ≤ r := by exact_mod_cast hr
  obtain ⟨hx, hs, hsx, hlarge, hscale⟩ := hsupportx r hr1 hrange
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hs0 : 0 < (c : ℝ) * r := mul_pos hc hr0
  let N := primeCutoff x ((c : ℝ) * r)
  obtain ⟨hN2, hNlow, hNs⟩ := primeCutoff_bounds hx0 hs0 hsx
  have hNhigh : (N : ℝ) ≤ 3 * x / ((c : ℝ) * r) :=
    (le_div_iff₀ hs0).mpr hNs
  have hsample : (fun Q : ℕ => Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x)) =
      (fun Q : ℕ => Ψ ((((c : ℝ) * r) * Q + 1) / x)) := by
    funext Q
    push_cast
    rfl
  have hvar : variation (fun Q : ℕ => Ψ (((c * r * Q + 1 : ℕ) : ℝ) / x)) N ≤
      B + 3 * K := by
    rw [hsample]
    exact primeCutoff_variation Ψ hx0 hs0 hsx hK hLip hbound
  have hp := hP r hr hrange hrM N hNhigh (fun d => Ψ ((d : ℝ) / x)) hvar
  rw [hsample] at hp
  have hq := PrimeSmoothIntegral.weightedModel_quotient_integral_error M₀ N hN2
    Ψ hs0.le hx0 hK hNs hLip
  have hi := smooth_integral_bounds Ψ hΨ hΨ0 hsupport N hx hs hlarge hscale.le hNlow
  let I : ℝ := (∫ t in (2 : ℝ)..(N : ℝ),
    Ψ ((((c : ℝ) * r) * t + 1) / x) / Real.log t) / (M₀.totient : ℝ)
  let t : ℝ := (x / r) / Real.log x
  have ht : 0 < t := by dsimp [t]; positivity
  have hIlow : 2 * α * t ≤ I := by
    have hh := div_le_div_of_nonneg_right hi.1 hφ.le
    convert hh using 1 <;> dsimp [α, t, I] <;> field_simp <;> ring
  have hIhigh : I ≤ (40 / 9 : ℝ) * α * t := by
    have hh := div_le_div_of_nonneg_right hi.2 hφ.le
    convert hh using 1 <;> dsimp [α, t, I] <;> field_simp <;> ring
  have hcL : C ≤ α / 2 * Real.log x := by
    have hh := (div_le_iff₀ hα).mp hlog
    nlinarith
  have hpSmall : C * (x / r) / (Real.log x) ^ (2 : ℝ) ≤ α / 2 * t := by
    rw [Real.rpow_two]
    calc
      _ = C * ((x / r) / (Real.log x) ^ (2 : ℕ)) := by ring
      _ ≤ (α / 2 * Real.log x) * ((x / r) / (Real.log x) ^ (2 : ℕ)) :=
        mul_le_mul_of_nonneg_right hcL (by positivity)
      _ = α / 2 * t := by dsimp [t]; field_simp
  have hqSmall : D ≤ α / 2 * t := by
    simpa only [t, mul_div_assoc] using hquad r hr0 hrange
  have herror : |primeMass c M₀ v Ψ x r - I| ≤ α * t := by
    have hh := (abs_sub_le (primeMass c M₀ v Ψ x r)
      (weightedModel M₀ N (fun Q : ℕ => Ψ ((((c : ℝ) * r) * Q + 1) / x))
        logarithmicIntegral) I).trans (add_le_add hp hq)
    have hh' : |primeMass c M₀ v Ψ x r - I| ≤
        C * (x / r) / (Real.log x) ^ (2 : ℝ) + D := hh
    linarith
  obtain ⟨heLow, heHigh⟩ := abs_le.mp herror
  constructor
  · change α * t ≤ _
    linarith
  · have htarget : (2 * weightMass Ψ / ((c : ℝ) * M₀.totient)) * t = 8 * α * t := by
      dsimp [α]
      field_simp
      ring
    change primeMass c M₀ v Ψ x r ≤ (2 * weightMass Ψ / ((c : ℝ) * M₀.totient)) * t
    rw [htarget]
    nlinarith [mul_pos hα ht]

/-- The same uniform comparison on the common actual large-prime set. -/
theorem uniform_common_primeSum_bounds (hPNT : FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ) (hΨ0 : ∀ y, 0 ≤ Ψ y)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {B K : ℝ} (hB : 0 < B) (hK : 0 ≤ K)
    (hbound : ∀ y, |Ψ y| ≤ B)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|)
    (hμ : 0 < weightMass Ψ) :
    ∀ᶠ x : ℝ in atTop, ∀ r : ℕ,
      0 < r → (r : ℝ) ≤ x ^ (1 / 100 : ℝ) → r.Coprime M₀ →
      let A := CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1)
        ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => x ^ (9 / 10 : ℝ) < (Q : ℝ)))
        (fun d => Ψ ((d : ℝ) / x)) r
      weightMass Ψ / (4 * c * (M₀.totient : ℝ)) * ((x / r) / Real.log x) ≤ A ∧
        A ≤ (2 * weightMass Ψ / ((c : ℝ) * M₀.totient)) * ((x / r) / Real.log x) := by
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  filter_upwards [uniform_primeMass_bounds hPNT hu hv Ψ hΨ hΨ0 hsupport
    hB hK hbound hLip hμ, eventually_affine_support_conditions hc1] with x hm hs
  intro r hr hrange hrM
  obtain ⟨hx, hs, _, _, hscale⟩ := hs r (by exact_mod_cast hr) hrange
  have heq := primeMass_eq_common_sum (M₀ := M₀) (v := v) Ψ hsupport
    (zero_lt_one.trans hx) hs hscale
  simpa only [heq] using hm r hr hrange hrM

end Artin.PrimeMassAssembly
