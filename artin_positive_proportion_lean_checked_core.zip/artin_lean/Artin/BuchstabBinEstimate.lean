module

public import Artin.BuchstabBoxCover

/-!
# The actual bin estimate reduced to one conditioned integer sum

This module sums the source-derived estimates over the explicit disjoint
dyadic family. The main mass is counted only once; only the replacement
error pays the logarithmic number of boxes.
-/

@[expose] public section

open Filter
open scoped BigOperators

namespace Artin.BuchstabBinEstimate

open MarkedSource RoughCompanion SemiprimeReplacement SemiprimeMR BuchstabMR
  BuchstabBoxes BuchstabBoxCover DisjointPairSums

noncomputable def ambient (x : ℝ) : Finset ℕ := Finset.Icc 2 ⌊2 * x⌋₊

theorem actualWeight_mem_ambient {K M : ℕ} (bands : Bands K) (u : ℕ)
    (Ψ : ℝ → ℝ) (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {x : ℝ} (hx : 1 < x) (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) {d : ℕ}
    (hweight : actualWeight bands M u Ψ x c allowed Qmin d ≠ 0) : d ∈ ambient x := by
  have hd := actualWeight_product_support bands u Ψ hsupport (by linarith : 0 < x)
    c allowed Qmin hweight
  apply Finset.mem_Icc.mpr
  have hd1 : (1 : ℝ) < d := hx.trans_le hd.1
  have hd1' : 1 < d := by exact_mod_cast hd1
  exact ⟨hd1', Nat.le_floor hd.2⟩

/-- The error sum for the actual family, with its proved logarithmic
cardinality bound. -/
theorem box_error_sum_le {x γ γ' C : ℝ} (hx : 1 < x) (hlog : 1 ≤ Real.log x)
    (hγγ' : γ ≤ γ') (hwidth : γ' - γ ≤ 1) (hC : 0 ≤ C) :
    ((indices x γ γ').card : ℝ) * (C * x * (Real.log x) ^ (-6 : ℝ)) ≤
      ((3 / Real.log 2 + 6) * C) * x * (Real.log x) ^ (-5 : ℝ) := by
  have hE : 0 ≤ C * x * (Real.log x) ^ (-6 : ℝ) := by positivity
  have he := finite_replacement_error_log (indices x γ γ')
    (fun _ => C * x * (Real.log x) ^ (-6 : ℝ)) (fun _ => 0)
    hx hC (indices_card_le_log hx.le hlog hγγ' hwidth)
    (fun _ _ => by simp only [sub_zero, abs_of_nonneg hE]; exact le_rfl)
  simpa only [Finset.sum_const, Finset.sum_const_zero, sub_zero,
    nsmul_eq_mul, mul_zero, sub_zero,
    abs_of_nonneg (mul_nonneg (Nat.cast_nonneg _) hE)] using he

/-- The original bin sum is bounded by one literal conditioned integer
sum plus `O(x/log^5 x)`. All dyadic-cover, disjointness, cardinality, source
window, density-continuity, and marked-replacement steps are proved.
The only remaining analytic step for the manuscript's normalized bin bound
is the conditioned-sieve estimate for `conditionedMass`. -/
theorem actual_bin_upper_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (hbands : ClassicalBandMass) (hFourier : ClassicalFourierInversion)
    (hcontinuity : ClassicalDensityContinuity)
    (M : ℕ) [NeZero M] (u : ℕ) (hu : u < M) (hunit : IsUnit (u : ZMod M))
    (Ψ : ℝ → ℝ) (hΨsmooth : SmoothCompactWeight (fun y => (Ψ y : ℂ)))
    (hΨ : ∀ y, Ψ y ∈ Set.Icc (0 : ℝ) 1)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    (b κ γ γ' C₀ : ℝ) (hb : 0 < b) (hκ : 0 < κ)
    (hbg : b ≤ γ) (hγγ' : γ ≤ γ') (hupper : γ' ≤ 1 / 2 - κ)
    (hC₀ : 0 ≤ C₀) (hbin : ∀ t ∈ Set.Icc γ γ', density γ (1 - t) ≤ C₀) :
    ∃ K₀ : ℕ, 1 ≤ K₀ ∧ ∀ K : ℕ, K₀ ≤ K → ∀ bands : Bands K,
      ∀ η : ℝ, 0 < η → ∃ C : ℝ, 0 < C ∧
      ∀ᶠ x : ℝ in atTop, ∀ (c : ℕ) (allowed : Finset ℕ) (Qmin : ℝ) (N : ℕ),
        BuchstabPartition.factorBinMass N (actualWeight bands M u Ψ x c allowed Qmin)
            (x ^ γ) (x ^ γ') ≤
          (C₀ + η) / (Real.log x * eulerV (W x)) *
            conditionedMass (ambient x) (primeBin x γ γ')
              (actualWeight bands M u Ψ x c allowed Qmin) (W x) +
          C * x * (Real.log x) ^ (-5 : ℝ) := by
  obtain ⟨K₀, hK₀, hK⟩ := actual_box_bounds_from_sources h102 h103 hbands hFourier
    hcontinuity M u hu hunit Ψ hΨsmooth hΨ hsupport b κ γ γ' C₀
    hb hκ hbg hγγ' hupper hbin
  refine ⟨K₀, hK₀, ?_⟩
  intro K hKK bands η hη
  obtain ⟨C, hC, hboxes⟩ := hK K hKK bands η hη
  have hA : 0 < (3 / Real.log 2 + 6 : ℝ) := by
    have h2 := Real.log_pos (by norm_num : (1 : ℝ) < 2)
    positivity
  refine ⟨(3 / Real.log 2 + 6) * C, mul_pos hA hC, ?_⟩
  have hγ : 0 < γ := hb.trans_le hbg
  filter_upwards [hboxes, eventually_actualWeight_nonneg hbands bands u Ψ hΨ,
    eventually_prime_boundedRough hγ, Real.tendsto_log_atTop.eventually_ge_atTop 1,
    eventually_gt_atTop (1 : ℝ)] with x hbox hw hprime hlog hx
  intro c allowed Qmin N
  let w := actualWeight bands M u Ψ x c allowed Qmin
  have hw0 : ∀ d, 0 ≤ w d := hw c allowed Qmin
  have hx0 : 0 < x := by linarith
  have hweightSupport : ∀ d, w d ≠ 0 → x ≤ (d : ℝ) ∧ (d : ℝ) ≤ 2 * x :=
    fun d hd => actualWeight_product_support bands u Ψ hsupport hx0 c allowed Qmin hd
  have hrough : ∀ ab ∈ indices x γ γ', ∀ n ∈ primeBox x γ γ' ab,
      n.Prime → MarkedCriterion.IsRough (W x) n := by
    intro ab hab n hn hp
    have hcoeff := hprime (primeBox x γ γ' ab)
      (fun k hk => (primeBox_bounds hx0 ab hk).2.1.le) n hn
    exact hcoeff.2 (by simp [primeIndicator, hp])
  have hcond := sum_pairMass_le_conditionedMass (indices x γ γ')
    (fun ab => natDyad ab.2) (primeBox x γ γ') (ambient x) (primeBin x γ γ') w (W x)
    (boxes_pairwiseDisjoint x γ γ' _) hw0
    (fun ab _ => Finset.filter_subset _ _) hrough (by
      intro ab hab m hm n hn hne
      exact actualWeight_mem_ambient bands u Ψ hsupport hx c allowed Qmin hne)
  have hsum := Finset.sum_le_sum (fun ab hab => hbox ab hab c allowed Qmin)
  have hcoef : 0 ≤ (C₀ + η) / (Real.log x * eulerV (W x)) := by
    exact div_nonneg (by linarith) (mul_pos (Real.log_pos hx) (eulerV_pos _)).le
  have he := box_error_sum_le hx hlog hγγ' (by linarith : γ' - γ ≤ 1) hC.le
  apply (factorBinMass_le_sum_boxes hx0 N w hw0 hweightSupport).trans
  calc
    _ ≤ (C₀ + η) / (Real.log x * eulerV (W x)) *
        (∑ ab ∈ indices x γ γ', pairMass (natDyad ab.2) (primeBox x γ γ' ab)
          w (realRoughIndicator (W x)) primeIndicator) +
        ((indices x γ γ').card : ℝ) * (C * x * (Real.log x) ^ (-6 : ℝ)) := by
      simp only [Finset.sum_add_distrib, Finset.sum_const, nsmul_eq_mul] at hsum
      rw [← Finset.mul_sum] at hsum
      exact hsum
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hcond hcoef) he

end Artin.BuchstabBinEstimate
