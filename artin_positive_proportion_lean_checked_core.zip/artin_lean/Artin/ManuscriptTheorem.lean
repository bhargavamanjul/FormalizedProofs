module

public import Artin.AcceptedSieveSources
public import Artin.ManuscriptCandidateAssembly
public import Artin.SourceKummer
public import Artin.ManuscriptRough

/-!
# The manuscript theorem from the agreed external inputs

The source boundary is explicit: accepted cited statements and classical
analytic facts are theorem arguments. Original sieve estimates are proved
in the imported development and must not be inserted as source fields.
-/

@[expose] public section
open Filter
open scoped Topology

namespace Artin

/-- The final analytic reduction with a proved candidate estimate and the
literal cited arithmetic statements, retaining their exceptional cutoff. -/
theorem quantitative_prime_proportion_of_candidate_and_sources
    (a : ℤ) (ha : Admissible a)
    {C₀ Y₀ ε₀ A Bm R T : ℝ}
    (hC₀ : 0 < C₀) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (candidate : CandidateEstimate a C₀ Y₀ ε₀)
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hfield : SourceKummer.SourceLemma9_1FieldBounds)
    (hsplit : SourceKummer.SourceLemma2_3Splitting) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ primitiveCount a x := by
  obtain ⟨Y₁, _, hsmall⟩ := SourceKummer.exists_smallIndexEstimate_of_sources ha
    hexists hA hBm hR hcount hdecay hformula hfield hsplit
    reciprocalPrimeTail_eight_log_four
  have hmass := fixedSplittingSmoothing_mass_pos
  have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  apply quantitative_prime_proportion_of_two_estimates a ha DedekindQRH
    C₀ (fixedSplittingSmoothing.mass * (8 * Real.log 4)) (max Y₀ Y₁) ε₀
    hC₀ (by positivity) (hY₀.trans_le (le_max_left _ _)) hε₀
  · intro ε Y hε hεmax hY hYone
    exact candidate ε Y hε hεmax ((le_max_left Y₀ Y₁).trans hY) hYone
  · intro N hN hQRH ε Y hε hεmax hY hYone
    exact hsmall N hN hQRH ε Y hε hεmax ((le_max_right Y₀ Y₁).trans hY) hYone

/-- The original candidate-prime estimate, with no intermediate sieve
estimate among its hypotheses. The coefficient and both fixed cutoffs are
chosen before `ε,Y` and the later zero-free width. -/
theorem candidate_estimate_of_accepted_sources
    (sources : AcceptedSieveSources) (a : ℤ) (ha : Admissible a) :
    ∃ C Y₀ ε₀ : ℝ, 0 < C ∧ 0 < Y₀ ∧ 0 < ε₀ ∧ CandidateEstimate a C Y₀ ε₀ := by
  obtain ⟨D⟩ := NonresidueProgression.progression_of_source sources.source2_4 ha
  obtain ⟨M₀, v, hM, hu, _, hv⟩ := D.normal_form
  have hM₀ : 0 < M₀ := by
    have hp := D.M_pos
    rw [hM] at hp
    exact Nat.pos_of_mul_pos_left hp
  let : NeZero M₀ := ⟨hM₀.ne'⟩
  have hc : 2 ≤ D.c := by rcases D.c_choice with h | h <;> omega
  have hu' : D.c * v + 1 < D.c * M₀ := by simpa only [hM, hu] using D.u_lt_M
  have hunit : (D.c * v + 1).Coprime (D.c * M₀) := by simpa only [hM, hu] using D.unit
  have hM2 : 2 ∣ D.M := dvd_trans (by norm_num : 2 ∣ 8) D.eight_dvd
  obtain ⟨S, hLocal⟩ := sources.localMertens D.M D.M_pos hM2
  have hS : 0 < S := hLocal.1
  rw [hM] at hLocal
  obtain ⟨c₀, Yc, hc₀, hYc, hmertens, hmoment⟩ := sources.cofactorProducts
  obtain ⟨C₂, hC₂, Ks, hKs, hsieve⟩ :=
    ManuscriptCandidateAssembly.candidate_reduction_from_sources
      sources.source10_2 sources.source10_3 sources.source11_1 sources.bandLower sources.bandUpper
      sources.fourier sources.primeBlock sources.mertensUpper sources.mertensLower
      sources.divisorSquareMoment sources.fixedModulusPNT D c₀ Yc hc₀ hYc hmertens hmoment
  obtain ⟨κ, hκ, hκsmall, hκloss⟩ := exists_semiprime_width hS hC₂.le
  obtain ⟨Cblock, _, hBlock⟩ := sources.initialPrimeBlock
  obtain ⟨τ, ε₀, hτ, hτsmall, hε₀, hε₀κ, hε₀small, Kr, hKr, hrough⟩ :=
    ManuscriptRough.actual_rough_lower_from_sources
      sources.source10_2 sources.source10_3 sources.source11_1 sources.bandLower sources.bandUpper
      sources.fourier sources.densityContinuity sources.buchstabFacts sources.buchstabRapid
      Cblock hBlock sources.bombieriVinogradov sources.fixedModulusPNT sources.reciprocalTotient
      sources.eulerMertens sources.shiftedPrimeMertens D.c_choice hu' hv hunit hLocal hκ hκsmall
  let K := max Ks Kr
  let bands := ManuscriptCandidateAssembly.standardBands K
  obtain ⟨c, d, B, hcpos, hd, hB, hdata⟩ := hsieve K (le_max_left _ _) bands
  let Y₀ := max Yc (max (D.M : ℝ) (10 / τ))
  have hY₀ : 0 < Y₀ := (by linarith : 0 < Yc).trans_le (le_max_left _ _)
  refine ⟨S * c * d / (2 * B), Y₀, ε₀, by positivity, hY₀, hε₀, ?_⟩
  apply candidate_estimate_of_intermediate_sieve_data hS hcpos hd hB hκloss.le
  intro ε Y hε hεmax hY hYone
  have hYclassic : Yc ≤ Y := (le_max_left _ _).trans hY
  have hYM : (D.M : ℝ) ≤ Y := (le_max_left _ _).trans ((le_max_right _ _).trans hY)
  have hYτ : 10 / τ ≤ Y := (le_max_right _ _).trans ((le_max_right _ _).trans hY)
  have hM₀M : M₀ ≤ D.M := by rw [hM]; nlinarith
  have hYM₀ : (M₀ : ℝ) ≤ Y := (by exact_mod_cast hM₀M : (M₀ : ℝ) ≤ D.M).trans hYM
  obtain ⟨e, he, hr⟩ := hrough K (le_max_right _ _) bands ε hε hεmax Y hYM₀
  rw [← hM, ← hu] at hr
  exact hdata κ hκ hκsmall.le τ hτ (by linarith) ε hε (hεmax.trans hε₀small).le
    Y hYclassic hYM hYτ S e he hr

/-- The quantitative manuscript conclusion, relative only to the agreed
cited and classical statements. The positive constant precedes every real
zero-free parameter `N≥2`. No candidate, rough, bin, semiprime, or splitting
count estimate is an external premise. -/
theorem quantitative_prime_proportion_of_accepted_sources
    (sources : AcceptedSieveSources) (a : ℤ) (ha : Admissible a)
    {A Bm R T : ℝ} (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hfield : SourceKummer.SourceLemma9_1FieldBounds)
    (hsplit : SourceKummer.SourceLemma2_3Splitting) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ primitiveCount a x := by
  obtain ⟨C, Y₀, ε₀, hC, hY₀, hε₀, candidate⟩ := candidate_estimate_of_accepted_sources sources a ha
  exact quantitative_prime_proportion_of_candidate_and_sources a ha hC hY₀ hε₀ candidate
    hexists hA hBm hR hcount hdecay hformula hfield hsplit

/-- The cited `N=6000` zero-free result gives the title's positive lower
proportion, relative to the exact accepted source/classical inputs. -/
theorem positive_prime_proportion_at_6000_of_accepted_sources
    (sources : AcceptedSieveSources) (a : ℤ) (ha : Admissible a)
    {A Bm R T : ℝ} (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hfield : SourceKummer.SourceLemma9_1FieldBounds)
    (hsplit : SourceKummer.SourceLemma2_3Splitting)
    (qrh6000 : DedekindQRH 6000) : HasPositivePrimeProportion a := by
  obtain ⟨c, hc, hb⟩ := quantitative_prime_proportion_of_accepted_sources sources a ha
    hexists hA hBm hR hcount hdecay hformula hfield hsplit
  refine ⟨c / ((6000 : ℝ) * Real.log 6000), ?_, hb 6000 (by norm_num) qrh6000⟩
  have hlog : 0 < Real.log (6000 : ℝ) := Real.log_pos (by norm_num)
  positivity

end Artin
