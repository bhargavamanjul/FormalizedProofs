module

public import Artin.CandidateSieve
public import Artin.KummerAnalytic
public import Artin.ReciprocalPrimeTail

/-!
# The quantitative conclusion with the actual Dedekind QRH hypothesis

The zero-free guard here is the continued Dedekind zeta hypothesis for actual
number fields. The Kummer fields are actual rational splitting fields. The
reciprocal-prime tail is proved in this project from mathlib's Chebyshev bound.

This remains a conditional reduction: `sieve` contains intermediate estimates
which must still be obtained by applying the accepted marked criterion, BV,
and block sieve to the actual arithmetic objects. `kummer` lists sufficient
uniform explicit-formula and Kummer algebra inputs, whose specialization
from the accepted classical statements also remains to be proved. Neither package
is asserted to exist by this file. In particular, this is not yet a proof of
the manuscript theorem solely from the cited external results.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- The constant is fixed before `N`, and the conclusion counts actual
primitive-root primes. All unproved input packages remain visible arguments. -/
theorem quantitative_prime_proportion_of_sieve_and_kummer_data
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B m C Y₀ ε₀ : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hm : 0 < m) (hC : 0 ≤ C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (kummer : ClassicalKummerInputs a m C Y₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ primitiveCount a x := by
  have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  exact quantitative_prime_proportion_of_two_estimates a ha DedekindQRH
    (S * c₀ * d / (2 * B)) (m * (8 * Real.log 4)) Y₀ ε₀
    (by positivity) (by positivity) hY₀ hε₀
    (candidate_estimate_of_intermediate_sieve_data hS hc₀ hd hB hk sieve)
    (smallIndexEstimate_of_classicalKummerInputs hm.le hC kummer
      reciprocalPrimeTail_eight_log_four)

/-- The cited width `1/6000` yields positive lower proportion once the
remaining sieve and classical Kummer inputs have been supplied. The QRH
theorem is an explicit permitted-source argument, not an unstated axiom. -/
theorem positive_prime_proportion_at_6000_of_sieve_and_kummer_data
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B m C Y₀ ε₀ : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hm : 0 < m) (hC : 0 ≤ C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (kummer : ClassicalKummerInputs a m C Y₀)
    (qrh6000 : DedekindQRH 6000) : HasPositivePrimeProportion a := by
  obtain ⟨c, hc, hb⟩ := quantitative_prime_proportion_of_sieve_and_kummer_data
    a ha hS hc₀ hd hB hm hC hY₀ hε₀ hk sieve kummer
  refine ⟨c / ((6000 : ℝ) * Real.log 6000), ?_, hb 6000 (by norm_num) qrh6000⟩
  have hlog : 0 < Real.log (6000 : ℝ) := Real.log_pos (by norm_num)
  positivity

end Artin
