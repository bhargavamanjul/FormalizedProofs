module

public import Mathlib.Topology.MetricSpace.Lipschitz
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.NormNum
public meta import Lean.Elab.Tactic.Omega

/-!
# Passing from the discrete logarithmic-integral model to a smooth integral

The quadrature error comes from the Lipschitz variation inside actual unit
intervals. It is independent of any prime-distribution estimate.
-/

@[expose] public section

open scoped BigOperators
open MeasureTheory

namespace Artin.PrimeSmoothIntegral

theorem continuous_of_abs_lipschitz (w : ℝ → ℝ) {K : ℝ} (hK : 0 ≤ K)
    (hw : ∀ u v, |w u - w v| ≤ K * |u - v|) : Continuous w := by
  have h : LipschitzWith ⟨K, hK⟩ w := LipschitzWith.of_dist_le_mul (by
    intro u v
    change |w u - w v| ≤ K * |u - v|
    exact hw u v)
  exact h.continuous

/-- Left-endpoint quadrature on one unit interval, with an integrable kernel. -/
theorem unit_cell_error (w g : ℝ → ℝ) {A K C : ℝ} (hK : 0 ≤ K)
    (hw : ∀ u v, |w u - w v| ≤ K * |u - v|)
    (hg : IntervalIntegrable g volume A (A + 1))
    (hgbound : ∀ t ∈ Set.Icc A (A + 1), |g t| ≤ C) :
    |w A * (∫ t in A..A + 1, g t) - ∫ t in A..A + 1, w t * g t| ≤ K * C := by
  have hwc := continuous_of_abs_lipschitz w hK hw
  have hfg := hg.continuousOn_mul hwc.continuousOn
  have hid : w A * (∫ t in A..A + 1, g t) - (∫ t in A..A + 1, w t * g t) =
      ∫ t in A..A + 1, (w A - w t) * g t := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_sub
      (hg.const_mul (w A)) hfg]
    congr 1
    funext t
    ring
  rw [hid]
  have h := intervalIntegral.norm_integral_le_of_norm_le_const
    (f := fun t => (w A - w t) * g t) (a := A) (b := A + 1) (C := K * C) (by
      intro t ht
      rw [Set.uIoc_of_le (by linarith : A ≤ A + 1)] at ht
      have ht' : t ∈ Set.Icc A (A + 1) := ⟨ht.1.le, ht.2⟩
      have hdist : |A - t| ≤ 1 := by
        rw [abs_sub_comm, abs_of_nonneg (sub_nonneg.mpr ht'.1)]
        linarith [ht'.2]
      have hd : |w A - w t| ≤ K := (hw A t).trans (by nlinarith)
      rw [Real.norm_eq_abs, abs_mul]
      exact mul_le_mul hd (hgbound t ht') (abs_nonneg _) hK)
  simpa only [Real.norm_eq_abs, add_sub_cancel_left, abs_one, mul_one] using h

/-- A finite sum of unit-cell quadrature errors has no hidden point-count
or prime-count hypothesis. -/
theorem sum_unit_cell_error (w g : ℝ → ℝ) (N : ℕ) (hN : 2 ≤ N)
    {K C : ℝ} (hK : 0 ≤ K)
    (hw : ∀ u v, |w u - w v| ≤ K * |u - v|)
    (hg : ∀ n ∈ Finset.Ico 2 N,
      IntervalIntegrable g volume (n : ℝ) ((n + 1 : ℕ) : ℝ))
    (hgbound : ∀ t ∈ Set.Icc (2 : ℝ) (N : ℝ), |g t| ≤ C) :
    |(∑ n ∈ Finset.Ico 2 N,
        w n * (∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), g t)) -
        ∫ t in (2 : ℝ)..(N : ℝ), w t * g t| ≤ (N - 2 : ℕ) * (K * C) := by
  have hwc := continuous_of_abs_lipschitz w hK hw
  have hfg : ∀ n ∈ Finset.Ico 2 N,
      IntervalIntegrable (fun t => w t * g t) volume (n : ℝ) ((n + 1 : ℕ) : ℝ) :=
    fun n hn => (hg n hn).continuousOn_mul hwc.continuousOn
  have hsum := intervalIntegral.sum_integral_adjacent_intervals_Ico
    (a := fun n : ℕ => (n : ℝ)) hN (fun n hn => hfg n (Finset.mem_Ico.mpr hn))
  change (∑ n ∈ Finset.Ico 2 N,
      ∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), w t * g t) =
        ∫ t in (2 : ℝ)..(N : ℝ), w t * g t at hsum
  rw [← hsum, ← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ n ∈ Finset.Ico 2 N,
        |w n * (∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), g t) -
          ∫ t in (n : ℝ)..((n + 1 : ℕ) : ℝ), w t * g t| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _n ∈ Finset.Ico 2 N, K * C := by
      apply Finset.sum_le_sum
      intro n hn
      have hn' := Finset.mem_Ico.mp hn
      have hg' : IntervalIntegrable g volume (n : ℝ) ((n : ℝ) + 1) := by
        simpa only [Nat.cast_add, Nat.cast_one] using hg n hn
      have hb : ∀ t ∈ Set.Icc (n : ℝ) ((n : ℝ) + 1), |g t| ≤ C := by
        intro t ht
        apply hgbound t
        constructor
        · exact (by exact_mod_cast hn'.1 : (2 : ℝ) ≤ n).trans ht.1
        · have hnu : (n : ℝ) + 1 ≤ N := by exact_mod_cast Nat.succ_le_of_lt hn'.2
          exact ht.2.trans hnu
      simpa only [Nat.cast_add, Nat.cast_one] using unit_cell_error w g hK hw hg' hb
    _ = _ := by simp

/-- An affine rescaling multiplies the Lipschitz constant by its slope. -/
theorem affine_abs_lipschitz (Ψ : ℝ → ℝ) {a b K : ℝ} (ha : 0 ≤ a)
    (hLip : ∀ u v : ℝ, |Ψ u - Ψ v| ≤ K * |u - v|) :
    ∀ u v : ℝ, |Ψ (a * u + b) - Ψ (a * v + b)| ≤ (K * a) * |u - v| := by
  intro u v
  have h := hLip (a * u + b) (a * v + b)
  have he : a * u + b - (a * v + b) = a * (u - v) := by ring
  simpa only [he, abs_mul, abs_of_nonneg ha, mul_assoc] using h

end Artin.PrimeSmoothIntegral
