module

public import Artin.ClassicalFormula
public import Mathlib.FieldTheory.KummerPolynomial
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic

/-!
# Elementary Kummer arithmetic before the classical algebra boundary

The exceptional prime range can be chosen concretely. For `q > |a| > 1`,
`a` cannot be a q-th power in ℚ; hence `X^q-a` is irreducible for prime q.
These deductions use no unproved Kummer facts.
-/

@[expose] public section

namespace Artin

/-- A coarse but completely explicit exceptional cutoff: a nonunit integer
cannot be a rational q-th power when q exceeds its absolute value. -/
theorem rat_pow_ne_int_of_natAbs_lt {a : ℤ} {q : ℕ}
    (ha : 1 < a.natAbs) (hq : a.natAbs < q) (b : ℚ) : b ^ q ≠ (a : ℚ) := by
  intro h
  have hnum : b.num ^ q = a := by simpa using congrArg Rat.num h
  have habs : b.num.natAbs ^ q = a.natAbs := by
    simpa only [Int.natAbs_pow] using congrArg Int.natAbs hnum
  have hb : 1 < b.num.natAbs := by
    by_contra hh
    have hle : b.num.natAbs ≤ 1 := by omega
    have hhpow := Nat.pow_le_pow_left hle q
    rw [habs, one_pow] at hhpow
    omega
  have hlarge : q < b.num.natAbs ^ q := q.lt_pow_self hb
  rw [habs] at hlarge
  omega

/-- The irreducibility assertion in manuscript §10, with an explicit finite
exceptional range instead of an unspecified greatest common divisor of valuations. -/
theorem kummerPolynomial_irreducible {a : ℤ} {q : ℕ}
    (ha : Admissible a) (hq : q.Prime) (hlarge : a.natAbs < q) :
    Irreducible (Polynomial.X ^ q - Polynomial.C (a : ℚ)) :=
  X_pow_sub_C_irreducible_of_prime hq
    (rat_pow_ne_int_of_natAbs_lt ha.natAbs_gt_one hlarge)

/-- Irreducibility already forces q to divide the actual splitting-field degree. -/
theorem prime_dvd_kummerDegree {a : ℤ} {q : ℕ}
    (ha : Admissible a) (hq : q.Prime) (hlarge : a.natAbs < q) :
    q ∣ kummerDegree a q := by
  have h := Polynomial.Irreducible.natDegree_dvd_finrank (kummerPolynomial_irreducible ha hq hlarge)
    (Polynomial.SplittingField.splits (Polynomial.X ^ q - Polynomial.C (a : ℚ)))
  rw [Polynomial.natDegree_X_pow_sub_C] at h
  exact h

/-- The residue obstruction itself excludes all exceptional rational primes:
p is greater than q and cannot divide a. In particular the classical
splitting criterion does not need an unrecorded ramification exception. -/
theorem powerResidueObstruction_unramified_conditions {a : ℤ} {q p : ℕ}
    (hq : q.Prime) (h : PowerResidueObstruction a q p) :
    q < p ∧ ¬ (p : ℤ) ∣ a := by
  have hqle : q ≤ p - 1 := Nat.le_of_dvd (Nat.sub_pos_of_lt h.1.one_lt) h.2.1
  have hexp : 0 < (p - 1) / q := Nat.div_pos hqle hq.pos
  have hane : (a : ZMod p) ≠ 0 := by
    let : Fact p.Prime := ⟨h.1⟩
    intro hz
    have heq := h.2.2
    rw [hz, zero_pow (Nat.ne_of_gt hexp)] at heq
    exact zero_ne_one heq
  exact ⟨hqle.trans_lt (Nat.sub_lt h.1.pos Nat.one_pos), residue_ne_zero_iff.mp hane⟩

/-- The precise remaining degree theorem. The irreducibility premise is
proved above, rather than hidden inside an unspecified exceptional-prime set.
See Pollack, *Bounded gaps between primes with a given primitive root*,
§3.3.1, p. 8, for the classical Kummer degree argument. -/
def ClassicalKummerDegree : Prop :=
  ∀ (a : ℤ) (q : ℕ), q.Prime → q ≠ 2 →
    Irreducible (Polynomial.X ^ q - Polynomial.C (a : ℚ)) →
      kummerDegree a q = q * (q - 1)

/-- Nonzero prime ideals of a prescribed absolute norm. -/
abbrev PrimeIdealsOfNorm (K : Type) [Field K] [NumberField K] (p : ℕ) :=
  {P : DedekindPrimeIdeal K // Ideal.absNorm P.1 = p}

/-- Pointwise complete splitting, in its ordinary ideal-count formulation.
This is the exact Dedekind--Kummer arithmetic input, not a prime-count estimate.
Pollack §3.3.1, p. 8 identifies its two residue conditions with complete splitting. -/
def ClassicalKummerSplitting : Prop :=
  ∀ (a : ℤ) (q p : ℕ), q.Prime → q ≠ 2 →
    PowerResidueObstruction a q p →
      Nat.card (PrimeIdealsOfNorm (KummerField a q) p) = kummerDegree a q

/-- Pointwise splitting determines distinct ideals simultaneously for all
obstruction primes: equality of ideals forces equality of their norms. -/
noncomputable def splitPrimeIdealEmbedding {a : ℤ} {q : ℕ}
    (hsplit : ∀ p, PowerResidueObstruction a q p →
      Nat.card (PrimeIdealsOfNorm (KummerField a q) p) = kummerDegree a q) :
    ({p : ℕ // PowerResidueObstruction a q p} × Fin (kummerDegree a q)) ↪
      DedekindPrimeIdeal (KummerField a q) := by
  classical
  have hn : kummerDegree a q ≠ 0 := Module.finrank_pos.ne'
  have hfinite : ∀ p : {p : ℕ // PowerResidueObstruction a q p},
      Finite (PrimeIdealsOfNorm (KummerField a q) p) := fun p =>
    Nat.finite_of_card_ne_zero (by rw [hsplit p p.2]; exact hn)
  let e : ∀ p : {p : ℕ // PowerResidueObstruction a q p},
      Fin (kummerDegree a q) ≃ PrimeIdealsOfNorm (KummerField a q) p := fun p =>
    have := hfinite p
    (Finite.equivFinOfCardEq (hsplit p p.2)).symm
  refine ⟨fun v => (e v.1 v.2).1, ?_⟩
  intro u v huv
  have hp : u.1 = v.1 := by
    apply Subtype.ext
    have hnorm := congrArg (fun P : DedekindPrimeIdeal (KummerField a q) =>
      Ideal.absNorm P.1) huv
    exact (e u.1 u.2).2.symm.trans (hnorm.trans (e v.1 v.2).2)
  rcases u with ⟨p, i⟩
  rcases v with ⟨p', j⟩
  dsimp only at hp
  subst p'
  exact congrArg (fun k => (p, k)) ((e p).injective (Subtype.ext huv))

theorem splitPrimeIdealEmbedding_norm {a : ℤ} {q : ℕ}
    (hsplit : ∀ p, PowerResidueObstruction a q p →
      Nat.card (PrimeIdealsOfNorm (KummerField a q) p) = kummerDegree a q)
    (p : {p : ℕ // PowerResidueObstruction a q p}) (j : Fin (kummerDegree a q)) :
    Ideal.absNorm (splitPrimeIdealEmbedding hsplit (p, j)).1 = p.1 := by
  have : Finite (PrimeIdealsOfNorm (KummerField a q) p) :=
    Nat.finite_of_card_ne_zero (by rw [hsplit p p.2]; exact Module.finrank_pos.ne')
  unfold splitPrimeIdealEmbedding
  exact (Finite.equivFinOfCardEq (hsplit p p.2)).symm j |>.property

/-- The integer discriminant estimate supplied by the standard pure-field,
cyclotomic-field and compositum discriminant theorems. The logarithmic
normalization is proved below, so it is not part of this algebraic input. -/
def ClassicalKummerPolynomialDiscriminant : Prop :=
  ∀ (a : ℤ) (q : ℕ), 1 < a.natAbs → q.Prime → q ≠ 2 →
    Irreducible (Polynomial.X ^ q - Polynomial.C (a : ℚ)) →
      (NumberField.discr (KummerField a q)).natAbs ≤
        (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1) * (q ^ (q - 2)) ^ q

theorem normalizedDiscriminant_of_polynomial_bound {a : ℤ} {q : ℕ}
    (ha : 1 < a.natAbs) (hq : q.Prime)
    (hdegree : kummerDegree a q = q * (q - 1))
    (hbound : (NumberField.discr (KummerField a q)).natAbs ≤
      (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1) * (q ^ (q - 2)) ^ q) :
    kummerLogDiscriminant a q / (kummerDegree a q : ℝ) ≤
      2 * Real.log (q : ℝ) + Real.log (a.natAbs : ℝ) := by
  have hq0 : (0 : ℝ) < q := by exact_mod_cast hq.pos
  have hq1 : (1 : ℝ) < q := by exact_mod_cast hq.one_lt
  have ha0 : (0 : ℝ) < a.natAbs := by exact_mod_cast (by omega : 0 < a.natAbs)
  have hreal : ((NumberField.discr (KummerField a q)).natAbs : ℝ) ≤
      ((q : ℝ) ^ q * (a.natAbs : ℝ) ^ (q - 1)) ^ (q - 1) *
        ((q : ℝ) ^ (q - 2)) ^ q := by exact_mod_cast hbound
  have hD : (0 : ℝ) < (NumberField.discr (KummerField a q)).natAbs := by
    exact_mod_cast Int.natAbs_pos.mpr (NumberField.discr_ne_zero (KummerField a q))
  have hlog := Real.log_le_log hD hreal
  rw [Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow,
    Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow,
    Real.log_pow] at hlog
  have hn : 0 < (kummerDegree a q : ℝ) := by
    rw [hdegree, Nat.cast_mul, Nat.cast_sub hq.one_le, Nat.cast_one]
    positivity
  apply (div_le_iff₀ hn).2
  unfold kummerLogDiscriminant
  rw [hdegree, Nat.cast_mul, Nat.cast_sub hq.one_le, Nat.cast_one]
  rw [Nat.cast_sub hq.one_le, Nat.cast_one,
    Nat.cast_sub hq.two_le, Nat.cast_ofNat] at hlog
  have hqlog : 0 ≤ Real.log (q : ℝ) := (Real.log_pos hq1).le
  have halog : 0 ≤ Real.log (a.natAbs : ℝ) := Real.log_natCast_nonneg _
  nlinarith [mul_nonneg (show 0 ≤ (q : ℝ) - 1 by linarith) halog,
    mul_nonneg hq0.le hqlog]

/-- The old arithmetic package is constructed from three separate classical
algebra theorems. Its exceptional threshold is now explicitly `|a|`.
Irreducibility, logarithmic normalization, and the global ideal embedding
are genuine deductions, rather than fields accepted in a single package. -/
noncomputable def kummerArithmeticFacts_of_classical {a : ℤ} (ha : Admissible a)
    (hdegree : ClassicalKummerDegree)
    (hdiscr : ClassicalKummerPolynomialDiscriminant)
    (hsplit : ClassicalKummerSplitting) :
    KummerArithmeticFacts a (a.natAbs : ℝ) := by
  have hlarge : ∀ q : ℕ, (a.natAbs : ℝ) < q → a.natAbs < q := fun q h => by
    exact_mod_cast h
  have hodd : ∀ q : ℕ, (a.natAbs : ℝ) < q → q ≠ 2 := fun q h => by
    have := ha.natAbs_gt_one
    have := hlarge q h
    omega
  refine {
    degree_eq := fun q hq hY => hdegree a q hq (hodd q hY)
      (kummerPolynomial_irreducible ha hq (hlarge q hY))
    normalized_discriminant := ?_
    splitIdeals := fun q hq hY => splitPrimeIdealEmbedding
      (fun p hp => hsplit a q p hq (hodd q hY) hp)
    split_norm := ?_ }
  · intro q hq hY
    exact normalizedDiscriminant_of_polynomial_bound ha.natAbs_gt_one hq
      (hdegree a q hq (hodd q hY) (kummerPolynomial_irreducible ha hq (hlarge q hY)))
      (hdiscr a q ha.natAbs_gt_one hq (hodd q hY)
        (kummerPolynomial_irreducible ha hq (hlarge q hY)))
  · intro q hq hY p j
    exact splitPrimeIdealEmbedding_norm _ p j

/-- Complete classical input interface for admissible a: no abstract Kummer
package, unknown smoothing, or unspecified exceptional threshold is an argument. -/
theorem smallIndexEstimate_of_separate_classical_results
    {a : ℤ} (ha : Admissible a) {A B R T H : ℝ}
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing B)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hdegree : ClassicalKummerDegree)
    (hdiscr : ClassicalKummerPolynomialDiscriminant)
    (hsplit : ClassicalKummerSplitting) (htail : ReciprocalPrimeTail H) :
    SmallIndexEstimate DedekindQRH a (fixedSplittingSmoothing.mass * H) (a.natAbs : ℝ) :=
  smallIndexEstimate_of_classical_theorems hexists fixedSplittingSmoothing hA hB hR
    hcount hdecay hformula (kummerArithmeticFacts_of_classical ha hdegree hdiscr hsplit) htail

end Artin
