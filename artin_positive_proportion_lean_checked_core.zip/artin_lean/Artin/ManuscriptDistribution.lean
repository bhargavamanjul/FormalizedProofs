module

public import Artin.PrimeMassAssembly
public import Artin.PositiveBump
public import Artin.WeightSupport
public import Artin.ManuscriptMass

/-!
# Distribution of the concrete manuscript weight

The classical inputs are unweighted Bombieri--Vinogradov and the elementary
reciprocal-totient estimate. The smoothing, common prime cutoff, varying
cofactors, and recentering at the actual prime mass are proved here.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.ManuscriptDistribution

open PrimeDistribution PrimeMassAssembly

/-- A standard elementary estimate, recorded as an explicit classical input. -/
def ReciprocalTotientSource : Prop :=
  ∃ G : ℝ, 0 < G ∧ ∀ᶠ x : ℝ in atTop,
    (∑ ℓ ∈ Finset.Icc 1 ⌊x⌋₊, 1 / (ℓ.totient : ℝ)) ≤ G * Real.log x

/-- Recentered BV on the common large-prime set, for arbitrary nonnegative
cofactor weights. The constant is chosen before the finite cofactor family. -/
theorem common_weighted_distribution
    (hBV : BombieriVinogradovSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero c] [NeZero M₀]
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (hA : 0 < A) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ R s : Finset ℕ,
      (∀ r ∈ R, 0 < r ∧ (r : ℝ) ≤ x ^ ε ∧ r.Coprime M₀) →
      (∀ ℓ ∈ s, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2)) → 1 ∈ s →
      ∀ t : ℕ → ℝ, (∀ r ∈ R, 0 ≤ t r) →
      let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
      let Ψ := fun d : ℕ => PositiveBump.weight ((d : ℝ) / x)
      (∑ r ∈ R, t r * ∑ ℓ ∈ s,
        |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ Qs Ψ r -
          sieveDensity (c * M₀) r ℓ *
            CofactorRepresentation.primeProgressionSum c (c * M₀) (c * v + 1) Qs Ψ r|) ≤
        C * x / (Real.log x) ^ A * ∑ r ∈ R, t r / r := by
  obtain ⟨K, hK, hLip⟩ := PositiveBump.weight_abs_sub_le
  obtain ⟨G, hG, hTot⟩ := hTot
  have hV : 0 < 1 + 3 * K := by positivity
  obtain ⟨C, hC, he⟩ := hBV.weighted_recentered hu hv huM hε hεκ hκ hA hV hG.le
  have hc1 : (1 : ℝ) ≤ c := by exact_mod_cast NeZero.pos c
  have hc : (0 : ℝ) < c := by exact_mod_cast NeZero.pos c
  refine ⟨C, hC, ?_⟩
  filter_upwards [he, hTot, eventually_affine_support_conditions hc1,
    eventually_gt_atTop (1 : ℝ)] with x he hTot hxscale hx
  intro R s hR hs hone t ht
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hsmall (r : ℕ) (hr : r ∈ R) : (r : ℝ) ≤ x ^ (1 / 100 : ℝ) :=
    (hR r hr).2.1.trans (Real.rpow_le_rpow_of_exponent_le hx.le (hεκ.trans hκ).le)
  have hcut (r : ℕ) (hr : r ∈ R) :
      1 ≤ (c : ℝ) * r ∧ (c : ℝ) * r ≤ x ∧
        (c : ℝ) * r * x ^ (9 / 10 : ℝ) < x - 1 := by
    have hh := hxscale r (by exact_mod_cast (hR r hr).1) (hsmall r hr)
    exact ⟨hh.2.1, hh.2.2.1, hh.2.2.2.2⟩
  have hN : ∀ r ∈ R, (primeCutoff x ((c : ℝ) * r) : ℝ) ≤
      3 * x / ((c : ℝ) * r) := by
    intro r hr
    have hs0 : 0 < (c : ℝ) * r := zero_lt_one.trans_le (hcut r hr).1
    exact (le_div_iff₀ hs0).mpr (primeCutoff_bounds hx0 hs0 (hcut r hr).2.1).2.2
  have hvar : ∀ r ∈ R,
      variation (fun Q : ℕ => PositiveBump.weight (((c * r * Q + 1 : ℕ) : ℝ) / x))
        (primeCutoff x ((c : ℝ) * r)) ≤ 1 + 3 * K := by
    intro r hr
    have hh := primeCutoff_variation PositiveBump.weight hx0
      (zero_lt_one.trans_le (hcut r hr).1) (hcut r hr).2.1 hK hLip
      PositiveBump.weight_abs_le_one
    convert hh using 1 <;> congr 2 <;> funext Q <;> push_cast <;> rfl
  have hmodsub : s ⊆ Finset.Icc 1 ⌊x⌋₊ := by
    intro ℓ hℓ
    refine Finset.mem_Icc.mpr ⟨(hs ℓ hℓ).1, Nat.le_floor ?_⟩
    calc
      (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2) := (hs ℓ hℓ).2
      _ ≤ x ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hx.le (by linarith)
      _ = x := Real.rpow_one x
  have hsum : ∀ r ∈ R, (∑ ℓ ∈ s, sieveDensity (c * M₀) r ℓ) ≤ G * Real.log x := by
    intro r _
    exact (sieveDensity_sum_le_reciprocal_totients _ _ _).trans
      ((Finset.sum_le_sum_of_subset_of_nonneg hmodsub (fun _ _ _ => by positivity)).trans hTot)
  have hh := he R s hR hs hone t ht (fun r => primeCutoff x ((c : ℝ) * r)) hN
    (fun d : ℕ => PositiveBump.weight ((d : ℝ) / x)) hvar hsum
  convert hh using 1
  apply Finset.sum_congr rfl
  intro r hr
  congr 1
  apply Finset.sum_congr rfl
  intro ℓ hℓ
  rw [sievedPrimeSum_eq_common_sum PositiveBump.weight
    (fun _ hy => PositiveBump.weight_eq_zero_of_not_mem_Icc hy) hx0 (hcut r hr).1 (hcut r hr).2.2]
  have hbase := primeMass_eq_common_sum (M₀ := M₀) (v := v) PositiveBump.weight
    (fun _ hy => PositiveBump.weight_eq_zero_of_not_mem_Icc hy) hx0 (hcut r hr).1 (hcut r hr).2.2
  simpa only [primeMass, WeightSupport.boundedLargePrimes] using congrArg
    (fun A => |PrimeProgressions.sievedPrimeSum c (c * M₀) (c * v + 1) ℓ
      ((Nat.primesLE ⌊2 * x⌋₊).filter (fun Q => x ^ (9 / 10 : ℝ) < (Q : ℝ)))
      (fun d => PositiveBump.weight ((d : ℝ) / x)) r - sieveDensity (c * M₀) r ℓ * A|)
    hbase.symm

open MarkedCofactorEstimate MarkedBandTail EnlargedCofactorMass ManuscriptMass

/-- The actual sum of absolute distribution errors over the small enlarged
cofactors. The prime set and weight agree with the full unsieved mass. -/
noncomputable def smallCofactorError {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (s : Finset ℕ) : ℝ :=
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
    marking I a x r * ∑ ℓ ∈ s,
      |PrimeProgressions.sievedPrimeSum c M u ℓ Qs (smoothWeight x) r -
        sieveDensity M r ℓ *
          CofactorRepresentation.primeProgressionSum c M u Qs (smoothWeight x) r|

/-- Weighted Bombieri--Vinogradov for the actual manuscript cofactors,
normalized by the original full arithmetic mass `X₀`. The constant precedes
all choices of marking intervals and all their cardinalities. -/
theorem actual_distribution_relative_to_baseMass
    (hBV : BombieriVinogradovSource) (hPNT : FixedModulusPNTSource)
    (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (hA : 0 < A) :
    ∃ C : ℝ, 0 < C ∧ ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ)
      (amin amax B v₀ : ℝ),
      0 < amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop,
        ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, ∀ᶠ x : ℝ in atTop,
      ∀ s : Finset ℕ,
        (∀ ℓ ∈ s, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2)) → 1 ∈ s →
        smallCofactorError I a c (c * M₀) (c * v + 1) ε Y τ x s ≤
          C * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A := by
  have hcpos : 0 < c := by omega
  letI : NeZero c := ⟨hcpos.ne'⟩
  obtain ⟨C, hC, he⟩ := common_weighted_distribution hBV hTot hu hv huM
    hε hεκ hκ (show 0 < A + 1 by linarith)
  have hlow : 0 < lowerConstant c M₀ :=
    (constants_positive c M₀ hcpos (NeZero.pos M₀)).1
  refine ⟨C / lowerConstant c M₀, by positivity, ?_⟩
  intro ι I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical Y hY τ
  have hεmax : ε ≤ 1 / 100 := (hεκ.trans hκ).le
  filter_upwards [he,
    actual_full_mass_comparison hPNT hc hu hv I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical ε hε hεmax Y hY τ,
    MarkedScaleSupport.eventual_enlarged_coprime I a amin amax ε Y τ hmin hmax ha
      M₀ (NeZero.pos M₀) hY,
    hclassical, eventually_gt_atTop (1 : ℝ)] with x he hmass hcop hVx hx
  intro s hs hone
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hL : 0 < Real.log x := Real.log_pos hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x :=
    fun i hi => hv₀.trans_le (hVx i hi).1
  have hW : ∀ n, 0 ≤ marking I a x n :=
    fun n => (ConcreteSelector.markingWeight_bounds I _ _ n hV).1
  let R := boundedCofactors (markedPrimes I a x)
    (unmarkedCofactors I a ε Y τ x) (x ^ ε)
  have hR : ∀ r ∈ R, 0 < r ∧ (r : ℝ) ≤ x ^ ε ∧ r.Coprime M₀ := by
    intro r hr
    have hh := (mem_boundedCofactors _ _ _ _).mp hr
    exact ⟨hh.1, hh.2.2, hcop _ r hr⟩
  have herr : smallCofactorError I a c (c * M₀) (c * v + 1) ε Y τ x s ≤
      C * x / (Real.log x) ^ (A + 1) * truncatedMass I a ε Y τ x := by
    dsimp only [smallCofactorError, ManuscriptMass.smoothWeight]
    rw [truncatedMass_eq]
    exact he R s hR hs hone (marking I a x) (fun r _ => hW r)
  have hsum : Summable (enlargedReciprocal (markedPrimes I a x)
      (unmarkedCofactors I a ε Y τ x) (marking I a x)) :=
    summable_enlargedReciprocal _ _ _ (unmarkedCofactors_avoid I a ε Y τ x) hW
      (MarkedInfiniteMass.summable_marking_weight I _ _ _ hV (markedPrimes_prime I a x))
  have htrunc : truncatedMass I a ε Y τ x ≤ fullMass I a ε Y τ x :=
    boundedMass_le_full _ _ _ _ hW hsum
  calc
    smallCofactorError I a c (c * M₀) (c * v + 1) ε Y τ x s
      ≤ C * x / (Real.log x) ^ (A + 1) * truncatedMass I a ε Y τ x := herr
    _ ≤ C * x / (Real.log x) ^ (A + 1) * fullMass I a ε Y τ x :=
      mul_le_mul_of_nonneg_left htrunc (by positivity)
    _ = (C / lowerConstant c M₀) *
        (lowerConstant c M₀ * x / Real.log x * fullMass I a ε Y τ x) /
          (Real.log x) ^ A := by
      rw [Real.rpow_add hL, Real.rpow_one]
      field_simp
    _ ≤ (C / lowerConstant c M₀) *
        baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hmass.1 (by positivity))
        (Real.rpow_nonneg hL.le A)

end Artin.ManuscriptDistribution
