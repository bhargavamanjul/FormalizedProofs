module

public import Artin.PrimeSmoothIntegral
public import Artin.AffineIntegral
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.GCongr

/-!
# Positive mass of the smooth prime main term

All comparisons below concern actual interval integrals. Uniform bounds on
the logarithm preserve the exact unweighted mass of the fixed smooth weight.
-/

@[expose] public section

open MeasureTheory

namespace Artin.PrimeMainMass

/-- A positive weight divided by the logarithm preserves its exact integral
mass, up to the supplied uniform logarithmic bounds. -/
theorem integral_div_log_bounds (f : ℝ → ℝ) {A B lo hi : ℝ}
    (hA : 2 ≤ A) (hAB : A ≤ B) (hf : ContinuousOn f (Set.Icc A B))
    (hf0 : ∀ t ∈ Set.Icc A B, 0 ≤ f t) (hlo : 0 < lo)
    (hlog : ∀ t ∈ Set.Icc A B, lo ≤ Real.log t ∧ Real.log t ≤ hi) :
    (∫ t in A..B, f t) / hi ≤ (∫ t in A..B, f t / Real.log t) ∧
      (∫ t in A..B, f t / Real.log t) ≤ (∫ t in A..B, f t) / lo := by
  have hfi : IntervalIntegrable f volume A B := hf.intervalIntegrable_of_Icc hAB
  have hci : ContinuousOn (fun t => (Real.log t)⁻¹) (Set.Icc A B) := by
    intro t ht
    have htpos : 0 < t := by linarith [ht.1]
    exact ((Real.continuousAt_log htpos.ne').inv₀
      (hlo.trans_le (hlog t ht).1).ne').continuousWithinAt
  have hfrac : IntervalIntegrable (fun t => f t / Real.log t) volume A B := by
    simpa only [div_eq_mul_inv] using hfi.mul_continuousOn
      (by simpa only [Set.uIcc_of_le hAB] using hci)
  have hil := intervalIntegral.integral_mono_on hAB (hfi.div_const hi) hfrac
    (fun t ht => div_le_div_of_nonneg_left (hf0 t ht)
      (hlo.trans_le (hlog t ht).1) (hlog t ht).2)
  have hiu := intervalIntegral.integral_mono_on hAB hfrac (hfi.div_const lo)
    (fun t ht => div_le_div_of_nonneg_left (hf0 t ht) hlo (hlog t ht).1)
  simpa only [intervalIntegral.integral_div] using And.intro hil hiu

/-- An explicit pair of endpoint conditions gives the standard logarithmic
comparison throughout the full affine support interval. -/
theorem affine_support_log_bounds {x s : ℝ} (hx : 1 < x) (hs : 1 ≤ s)
    (hlarge : 2 ≤ x ^ ((9 : ℝ) / 10))
    (hscale : s * x ^ ((9 : ℝ) / 10) ≤ x - 1) :
    2 ≤ (x - 1) / s ∧
      ∀ t ∈ Set.Icc ((x - 1) / s) ((2 * x - 1) / s),
        (9 : ℝ) / 10 * Real.log x ≤ Real.log t ∧ Real.log t ≤ 2 * Real.log x := by
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hs0 : 0 < s := zero_lt_one.trans_le hs
  have hlow : x ^ ((9 : ℝ) / 10) ≤ (x - 1) / s := by
    apply (le_div_iff₀ hs0).mpr
    simpa only [mul_comm] using hscale
  refine ⟨hlarge.trans hlow, ?_⟩
  intro t ht
  have ht0 : 0 < t := (by norm_num : (0 : ℝ) < 2).trans_le
    (hlarge.trans (hlow.trans ht.1))
  constructor
  · have h := Real.log_le_log (Real.rpow_pos_of_pos hx0 _) (hlow.trans ht.1)
    simpa only [Real.log_rpow hx0] using h
  · have hnum : 0 ≤ 2 * x - 1 := by linarith
    have hdiv : (2 * x - 1) / s ≤ 2 * x - 1 := by
      simpa only [div_one] using div_le_div_of_nonneg_left hnum zero_lt_one hs
    have hsq : 2 * x - 1 ≤ x ^ (2 : ℕ) := by nlinarith [sq_nonneg (x - 1)]
    have h := Real.log_le_log ht0 (ht.2.trans (hdiv.trans hsq))
    simpa only [Real.log_pow, Nat.cast_ofNat] using h

/-- A fixed interval of positivity gives a strictly positive actual mass. -/
theorem integral_mass_pos (Ψ : ℝ → ℝ) {α β ψ₀ : ℝ}
    (hΨ : ContinuousOn Ψ (Set.Icc α β)) (hαβ : α < β) (hψ : 0 < ψ₀)
    (hpositive : ∀ y ∈ Set.Icc α β, ψ₀ ≤ Ψ y) :
    0 < ∫ y in α..β, Ψ y := by
  have h := intervalIntegral.integral_mono_on hαβ.le
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => ψ₀) volume α β)
    (hΨ.intervalIntegrable_of_Icc hαβ.le) hpositive
  rw [intervalIntegral.integral_const] at h
  exact (mul_pos (sub_pos.mpr hαβ) hψ).trans_le (by simpa only [smul_eq_mul] using h)

/-- The fixed smooth weight's exact mass. -/
noncomputable def weightMass (Ψ : ℝ → ℝ) : ℝ := ∫ y in (1 : ℝ)..2, Ψ y

theorem weightMass_pos (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ)
    (hΨ0 : ∀ y, 0 ≤ Ψ y) {α β ψ₀ : ℝ}
    (hα : 1 ≤ α) (hαβ : α < β) (hβ : β ≤ 2) (hψ : 0 < ψ₀)
    (hpositive : ∀ y ∈ Set.Icc α β, ψ₀ ≤ Ψ y) : 0 < weightMass Ψ := by
  have hm := intervalIntegral.integral_mono_interval (μ := volume) hα hαβ.le hβ
    (Filter.Eventually.of_forall hΨ0)
    (hΨ.intervalIntegrable (1 : ℝ) 2)
  exact (integral_mass_pos Ψ hΨ.continuousOn hαβ hψ hpositive).trans_le hm

/-- A uniform bound on the fixed weight bounds its exact mass. -/
theorem weightMass_le (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ) {B : ℝ}
    (hB : ∀ y ∈ Set.Icc (1 : ℝ) 2, Ψ y ≤ B) : weightMass Ψ ≤ B := by
  have h := intervalIntegral.integral_mono_on (by norm_num : (1 : ℝ) ≤ 2)
    (hΨ.intervalIntegrable 1 2)
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => B) volume 1 2) hB
  simpa only [weightMass, intervalIntegral.integral_const, smul_eq_mul,
    show (2 : ℝ) - 1 = 1 by norm_num, one_mul] using h

/-- The affine support integral is comparable to `x/(s log x)`, with its
fixed coefficient given by the genuine mass of `Ψ`. -/
theorem affine_support_integral_bounds (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ)
    (hΨ0 : ∀ y, 0 ≤ Ψ y) {x s : ℝ} (hx : 1 < x) (hs : 1 ≤ s)
    (hlarge : 2 ≤ x ^ ((9 : ℝ) / 10))
    (hscale : s * x ^ ((9 : ℝ) / 10) ≤ x - 1) :
    (x / s) * weightMass Ψ / (2 * Real.log x) ≤
        (∫ t in ((x - 1) / s)..((2 * x - 1) / s),
          Ψ ((s * t + 1) / x) / Real.log t) ∧
      (∫ t in ((x - 1) / s)..((2 * x - 1) / s),
          Ψ ((s * t + 1) / x) / Real.log t) ≤
        (x / s) * weightMass Ψ / (((9 : ℝ) / 10) * Real.log x) := by
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hs0 : 0 < s := zero_lt_one.trans_le hs
  obtain ⟨hA, hlog⟩ := affine_support_log_bounds hx hs hlarge hscale
  have hAB : (x - 1) / s ≤ (2 * x - 1) / s :=
    div_le_div_of_nonneg_right (by linarith) hs0.le
  have hc : Continuous (fun t : ℝ => Ψ ((s * t + 1) / x)) :=
    hΨ.comp (((continuous_const.mul continuous_id).add continuous_const).div_const x)
  have h := integral_div_log_bounds (fun t => Ψ ((s * t + 1) / x)) hA hAB
    hc.continuousOn (fun t _ => hΨ0 _) (mul_pos (by norm_num) (Real.log_pos hx)) hlog
  have hmass : (∫ t in ((x - 1) / s)..((2 * x - 1) / s), Ψ ((s * t + 1) / x)) =
      (x / s) * weightMass Ψ := by
    simpa only [mul_one, mul_comm x 2, weightMass] using
      PrimeDistribution.integral_affine_pullback (A := 1) (B := 2) Ψ hx0 hs0
  simpa only [hmass] using h

/-- The complete main integral has the same positive mass once the interval
contains the support. All constants depend only on the fixed weight. -/
theorem smooth_integral_bounds (Ψ : ℝ → ℝ) (hΨ : Continuous Ψ)
    (hΨ0 : ∀ y, 0 ≤ Ψ y)
    (hsupport : ∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0)
    {x s : ℝ} (N : ℕ) (hx : 1 < x) (hs : 1 ≤ s)
    (hlarge : 2 ≤ x ^ ((9 : ℝ) / 10))
    (hscale : s * x ^ ((9 : ℝ) / 10) ≤ x - 1)
    (hN : (2 * x - 1) / s ≤ N) :
    (x / s) * weightMass Ψ / (2 * Real.log x) ≤
        (∫ t in (2 : ℝ)..(N : ℝ), Ψ ((s * t + 1) / x) / Real.log t) ∧
      (∫ t in (2 : ℝ)..(N : ℝ), Ψ ((s * t + 1) / x) / Real.log t) ≤
        (x / s) * weightMass Ψ / (((9 : ℝ) / 10) * Real.log x) := by
  have hx0 : 0 < x := zero_lt_one.trans hx
  have hs0 : 0 < s := zero_lt_one.trans_le hs
  have hA := (affine_support_log_bounds hx hs hlarge hscale).1
  have hAB : (x - 1) / s ≤ (2 * x - 1) / s :=
    div_le_div_of_nonneg_right (by linarith) hs0.le
  have hzero : ∀ t, t ∉ Set.Icc ((x - 1) / s) ((2 * x - 1) / s) →
      Ψ ((s * t + 1) / x) / Real.log t = 0 := by
    intro t ht
    have hout : (s * t + 1) / x ∉ Set.Icc (1 : ℝ) 2 := by
      intro hy
      apply ht
      constructor
      · apply (div_le_iff₀ hs0).mpr
        have h := (le_div_iff₀ hx0).mp hy.1
        nlinarith
      · apply (le_div_iff₀ hs0).mpr
        have h := (div_le_iff₀ hx0).mp hy.2
        nlinarith
    rw [hsupport _ hout, zero_div]
  rw [PrimeDistribution.integral_restrict_of_zero_outside
    (fun t => Ψ ((s * t + 1) / x) / Real.log t) hA hAB hN hzero]
  exact affine_support_integral_bounds Ψ hΨ hΨ0 hx hs hlarge hscale

end Artin.PrimeMainMass
