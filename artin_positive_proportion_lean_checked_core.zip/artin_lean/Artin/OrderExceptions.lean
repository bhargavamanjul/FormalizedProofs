module

public import Artin.Arithmetic
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Algebra.Order.Ring.Basic
public import Mathlib.Order.Interval.Finset.Nat

/-!
# Primes of small multiplicative order

The elementary product argument of Section 11. This file uses no external
analytic theorem. It proves an explicit bound, with constant
`Real.log (a.natAbs + 1)`, for any finite set of primes at least `x` at which
the multiplicative order of `a` is at most `M`.
-/

open scoped BigOperators

@[expose] public section

namespace Artin

/-- The integer whose prime divisors contain all small-order exceptions. -/
def orderExceptionProduct (a : ℤ) (M : ℕ) : ℕ :=
  ∏ j ∈ Finset.Icc 1 M, (a ^ j - 1).natAbs

theorem power_sub_one_natAbs_pos {a : ℤ} (ha : 1 < a.natAbs)
    {j : ℕ} (hj : 0 < j) : 0 < (a ^ j - 1).natAbs := by
  apply Nat.pos_of_ne_zero
  intro hz
  have hzero : a ^ j - 1 = 0 := Int.natAbs_eq_zero.mp hz
  have hone : a ^ j = 1 := sub_eq_zero.mp hzero
  have habs : a.natAbs ^ j = 1 := by
    simpa only [Int.natAbs_pow, Int.natAbs_one] using congrArg Int.natAbs hone
  have hgt : 1 < a.natAbs ^ j := one_lt_pow' ha hj.ne'
  omega

theorem orderExceptionProduct_pos {a : ℤ} (ha : 1 < a.natAbs) (M : ℕ) :
    0 < orderExceptionProduct a M := by
  apply Finset.prod_pos
  intro j hj
  exact power_sub_one_natAbs_pos ha (Finset.mem_Icc.mp hj).1

theorem power_sub_one_natAbs_le {a : ℤ} {j : ℕ} (hj : 0 < j) :
    (a ^ j - 1).natAbs ≤ (a.natAbs + 1) ^ j := by
  calc
    (a ^ j - 1).natAbs ≤ a.natAbs ^ j + 1 := by
      simpa only [Int.natAbs_pow, Int.natAbs_one] using Int.natAbs_sub_le (a ^ j) 1
    _ ≤ (a.natAbs + 1) ^ j := by
      simpa only [one_pow] using
        (pow_add_pow_le (Nat.zero_le a.natAbs) (Nat.zero_le 1) hj.ne')

theorem orderExceptionProduct_le (a : ℤ) (M : ℕ) :
    orderExceptionProduct a M ≤ (a.natAbs + 1) ^ (M * M) := by
  have hfactor : ∀ j ∈ Finset.Icc 1 M,
      (a ^ j - 1).natAbs ≤ (a.natAbs + 1) ^ M := by
    intro j hj
    obtain ⟨hjpos, hjle⟩ := Finset.mem_Icc.mp hj
    exact (power_sub_one_natAbs_le hjpos).trans
      (pow_le_pow_right₀ (by omega : 1 ≤ a.natAbs + 1) hjle)
  calc
    orderExceptionProduct a M ≤
        ∏ j ∈ Finset.Icc 1 M, (a.natAbs + 1) ^ M := by
      exact Finset.prod_le_prod hfactor
    _ = (a.natAbs + 1) ^ (M * M) := by
      simp [pow_mul, Nat.card_Icc]

/-- Distinct prime divisors of a nonzero integer cannot have total logarithm
larger than the logarithm of that integer. -/
theorem prime_divisors_card_mul_log_le {S : Finset ℕ} {n : ℕ} {x : ℝ}
    (hn : 0 < n) (hx : 0 < x)
    (hS : ∀ p ∈ S, p.Prime ∧ p ∣ n ∧ x ≤ (p : ℝ)) :
    (S.card : ℝ) * Real.log x ≤ Real.log (n : ℝ) := by
  have hsub : S ⊆ n.primeFactors := by
    intro p hp
    exact (hS p hp).1.mem_primeFactors (hS p hp).2.1 hn.ne'
  have hdvd : (∏ p ∈ S, p) ∣ n :=
    (Finset.prod_dvd_prod_of_subset S n.primeFactors id hsub).trans
      (Nat.prod_primeFactors_dvd n)
  have hpPos : ∀ p ∈ S, 0 < (p : ℝ) := by
    intro p hp
    exact_mod_cast (hS p hp).1.pos
  have hprodPos : 0 < ∏ p ∈ S, (p : ℝ) := Finset.prod_pos hpPos
  calc
    (S.card : ℝ) * Real.log x = ∑ p ∈ S, Real.log x := by simp
    _ ≤ ∑ p ∈ S, Real.log (p : ℝ) := by
      apply Finset.sum_le_sum
      intro p hp
      exact Real.log_le_log hx (hS p hp).2.2
    _ = Real.log (∏ p ∈ S, (p : ℝ)) := by
      symm
      exact Real.log_prod (fun p hp => (hpPos p hp).ne')
    _ ≤ Real.log (n : ℝ) := by
      apply Real.log_le_log hprodPos
      rw [← Nat.cast_prod]
      exact_mod_cast Nat.le_of_dvd hn hdvd

theorem prime_divisors_card_le {S : Finset ℕ} {n : ℕ} {x : ℝ}
    (hn : 0 < n) (hx : 1 < x)
    (hS : ∀ p ∈ S, p.Prime ∧ p ∣ n ∧ x ≤ (p : ℝ)) :
    (S.card : ℝ) ≤ Real.log (n : ℝ) / Real.log x := by
  exact (le_div_iff₀ (Real.log_pos hx)).mpr
    (prime_divisors_card_mul_log_le hn (lt_trans zero_lt_one hx) hS)

/-- The finite-field order identifies one factor of the integer product. -/
theorem prime_dvd_orderExceptionProduct {a : ℤ} {p M : ℕ}
    (hp : p.Prime) (ha : (a : ZMod p) ≠ 0)
    (hM : orderOf (a : ZMod p) ≤ M) : p ∣ orderExceptionProduct a M := by
  let j := orderOf (a : ZMod p)
  have hj : j ∈ Finset.Icc 1 M :=
    Finset.mem_Icc.mpr ⟨residue_order_pos hp ha, hM⟩
  have hcast : ((a ^ j - 1 : ℤ) : ZMod p) = 0 := by
    simp only [Int.cast_sub, Int.cast_pow, Int.cast_one, j,
      pow_orderOf_eq_one, sub_self]
  have hdivInt : (p : ℤ) ∣ a ^ j - 1 :=
    (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp hcast
  have hdiv : p ∣ (a ^ j - 1).natAbs :=
    Int.natCast_dvd_natCast.mp (Int.dvd_natAbs.mpr hdivInt)
  exact hdiv.trans (Finset.dvd_prod_of_mem (fun k => (a ^ k - 1).natAbs) hj)

/-- An explicit version of the small-order exceptional-prime estimate.
The bound is valid for negative as well as positive integer bases. -/
theorem small_order_primes_card_le {a : ℤ} {S : Finset ℕ} {M : ℕ} {x : ℝ}
    (ha : 1 < a.natAbs) (hx : 1 < x)
    (hS : ∀ p ∈ S, p.Prime ∧ x ≤ (p : ℝ) ∧
      (a : ZMod p) ≠ 0 ∧ orderOf (a : ZMod p) ≤ M) :
    (S.card : ℝ) ≤
      (M : ℝ) ^ 2 * Real.log (a.natAbs + 1 : ℝ) / Real.log x := by
  have hfirst : (S.card : ℝ) ≤
      Real.log (orderExceptionProduct a M : ℝ) / Real.log x := by
    apply prime_divisors_card_le (orderExceptionProduct_pos ha M) hx
    intro p hp
    obtain ⟨hpp, hpx, hpa, hpM⟩ := hS p hp
    exact ⟨hpp, prime_dvd_orderExceptionProduct hpp hpa hpM, hpx⟩
  have hlog : Real.log (orderExceptionProduct a M : ℝ) ≤
      (M : ℝ) ^ 2 * Real.log (a.natAbs + 1 : ℝ) := by
    calc
      Real.log (orderExceptionProduct a M : ℝ) ≤
          Real.log ((a.natAbs + 1 : ℝ) ^ (M * M)) := by
        apply Real.log_le_log
        · exact_mod_cast orderExceptionProduct_pos ha M
        · exact_mod_cast orderExceptionProduct_le a M
      _ = (M : ℝ) ^ 2 * Real.log (a.natAbs + 1 : ℝ) := by
        rw [Real.log_pow]
        push_cast
        ring
  exact hfirst.trans (div_le_div_of_nonneg_right hlog (Real.log_pos hx).le)

/-- A real cutoff may be used after choosing any natural-number cutoff below it. -/
theorem small_order_primes_card_le_of_cutoff {a : ℤ} {S : Finset ℕ}
    {M : ℕ} {x T : ℝ} (ha : 1 < a.natAbs) (hx : 1 < x)
    (hMT : (M : ℝ) ≤ T)
    (hS : ∀ p ∈ S, p.Prime ∧ x ≤ (p : ℝ) ∧
      (a : ZMod p) ≠ 0 ∧ orderOf (a : ZMod p) ≤ M) :
    (S.card : ℝ) ≤ T ^ 2 * Real.log (a.natAbs + 1 : ℝ) / Real.log x := by
  refine (small_order_primes_card_le ha hx hS).trans ?_
  have hbase : 1 < (a.natAbs + 1 : ℝ) := by exact_mod_cast (by omega : 1 < a.natAbs + 1)
  apply div_le_div_of_nonneg_right _ (Real.log_pos hx).le
  apply mul_le_mul_of_nonneg_right _ (Real.log_pos hbase).le
  exact pow_le_pow_left₀ (Nat.cast_nonneg M) hMT 2

end Artin
