module

public import Artin.Counting
public import Mathlib.Data.Nat.Prime.Basic
public import Mathlib.Algebra.Order.BigOperators.Ring.Finset
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Analysis.SpecialFunctions.Exp
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.Positivity

/-!
# Distribution errors and conditioned sieve moduli

The analytic input to `weighted_distribution_of_direct_errors` is a bound for
prime progression counts around their integral main terms. The replacement of
that main term by the actual unsieved count is proved here, including its loss
of the sum of the local densities. The conditioned sieve modulus map is proved
injective; its error summation therefore introduces no multiplicity factor.
-/

open scoped BigOperators
@[expose] public section
namespace Artin

/-- Replacing an analytic main term `I` by the actual mass `A` costs the base
error times the total local density. -/
theorem distribution_error_recenter {ι : Type*} (s : Finset ι)
    (count density : ι → ℝ) (A I : ℝ)
    (hg : ∀ d ∈ s, 0 ≤ density d) :
    (∑ d ∈ s, |count d - density d * A|) ≤
      (∑ d ∈ s, |count d - density d * I|) +
      |I - A| * ∑ d ∈ s, density d := by
  calc
    (∑ d ∈ s, |count d - density d * A|) ≤
        ∑ d ∈ s, (|count d - density d * I| + |I - A| * density d) := by
      apply Finset.sum_le_sum
      intro d hd
      calc
        |count d - density d * A| =
            |(count d - density d * I) + density d * (I - A)| := by ring_nf
        _ ≤ |count d - density d * I| + |density d * (I - A)| := abs_add_le _ _
        _ = |count d - density d * I| + |I - A| * density d := by
          rw [abs_mul, abs_of_nonneg (hg d hd)]; ring
    _ = _ := by rw [Finset.sum_add_distrib, Finset.mul_sum]

/-- If the modulus-one term occurs in the source bound, it already bounds the
base error; no separate fixed-modulus theorem is needed for recentering. -/
theorem base_error_le_direct_sum {ι : Type*} (s : Finset ι)
    (count density : ι → ℝ) {d₀ : ι} (hd₀ : d₀ ∈ s)
    (A I : ℝ) (hcount : count d₀ = A) (hdensity : density d₀ = 1) :
    |I - A| ≤ ∑ d ∈ s, |count d - density d * I| := by
  calc
    |I - A| = |count d₀ - density d₀ * I| := by
      rw [hcount, hdensity, one_mul, abs_sub_comm]
    _ ≤ _ := Finset.single_le_sum (fun d _ ↦ abs_nonneg (count d - density d * I)) hd₀

/-- The concrete finite form of the loss incurred in §5: at most `1 + G`,
where `G` bounds the sum of the local densities. -/
theorem distribution_error_of_direct_bound {ι : Type*} (s : Finset ι)
    (count density : ι → ℝ) {d₀ : ι} (hd₀ : d₀ ∈ s)
    (A I B G : ℝ) (hcount : count d₀ = A) (hdensity : density d₀ = 1)
    (hg : ∀ d ∈ s, 0 ≤ density d)
    (hG : ∑ d ∈ s, density d ≤ G)
    (hB : (∑ d ∈ s, |count d - density d * I|) ≤ B) :
    (∑ d ∈ s, |count d - density d * A|) ≤ (1 + G) * B := by
  have hg₀ : 0 ≤ ∑ d ∈ s, density d := Finset.sum_nonneg hg
  have hbase := (base_error_le_direct_sum s count density hd₀ A I hcount hdensity).trans hB
  have hB₀ : 0 ≤ B := (Finset.sum_nonneg (fun _ _ ↦ abs_nonneg _)).trans hB
  calc
    _ ≤ (∑ d ∈ s, |count d - density d * I|) +
        |I - A| * ∑ d ∈ s, density d := distribution_error_recenter s count density A I hg
    _ ≤ B + B * G := add_le_add hB (mul_le_mul hbase hG hg₀ hB₀)
    _ = (1 + G) * B := by ring

/-- Weighted summation preserves the harmonic cofactor mass. The source input
is the usual direct BV error at scale `x/r`, with all constants independent of
`r`; the theorem proves the conversion to the manuscript's recentered errors. -/
theorem weighted_distribution_of_direct_errors {ι : Type*}
    (cofactors : Finset ℕ) (moduli : Finset ι) (t : ℕ → ℝ)
    (count density : ℕ → ι → ℝ) (mass integral : ℕ → ℝ)
    {d₀ : ι} (hd₀ : d₀ ∈ moduli) (x E G : ℝ)
    (ht : ∀ r ∈ cofactors, 0 ≤ t r)
    (hcount : ∀ r ∈ cofactors, count r d₀ = mass r)
    (hdensity : ∀ r ∈ cofactors, density r d₀ = 1)
    (hg : ∀ r ∈ cofactors, ∀ d ∈ moduli, 0 ≤ density r d)
    (hG : ∀ r ∈ cofactors, ∑ d ∈ moduli, density r d ≤ G)
    (hsource : ∀ r ∈ cofactors,
      (∑ d ∈ moduli, |count r d - density r d * integral r|) ≤ x / r * E) :
    (∑ r ∈ cofactors, t r * ∑ d ∈ moduli, |count r d - density r d * mass r|) ≤
      (1 + G) * x * E * ∑ r ∈ cofactors, t r / r := by
  calc
    _ ≤ ∑ r ∈ cofactors, t r * ((1 + G) * (x / r * E)) := by
      apply Finset.sum_le_sum
      intro r hr
      exact mul_le_mul_of_nonneg_left
        (distribution_error_of_direct_bound moduli (count r) (density r) hd₀
          (mass r) (integral r) (x / r * E) G (hcount r hr) (hdensity r hr)
          (hg r hr) (hG r hr) (hsource r hr)) (ht r hr)
    _ = _ := by rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro r _; ring

/-- Absorb the single logarithmic recentering loss. Taking the direct BV
exponent one larger therefore recovers any requested logarithmic exponent. -/
theorem absorb_distribution_log_loss {L E C : ℝ} (hL : 1 ≤ L) (hE : 0 ≤ E) :
    (1 + C * L) * (E / L) ≤ (1 + C) * E := by
  have hL₀ : 0 < L := lt_of_lt_of_le zero_lt_one hL
  rw [← mul_div_assoc]
  apply (div_le_iff₀ hL₀).2
  nlinarith

/-- The fully summed recentered error has the form `constant * x * E * J`,
with no dependence on the number or weights of the cofactors. In applications
`E = (log x)⁻ᴬ` and `J = ∑ r, t r / r`. -/
theorem weighted_distribution_with_log_loss {ι : Type*}
    (cofactors : Finset ℕ) (moduli : Finset ι) (t : ℕ → ℝ)
    (count density : ℕ → ι → ℝ) (mass integral : ℕ → ℝ)
    {d₀ : ι} (hd₀ : d₀ ∈ moduli) (x E L C : ℝ)
    (hx : 0 ≤ x) (hE : 0 ≤ E) (hL : 1 ≤ L)
    (ht : ∀ r ∈ cofactors, 0 ≤ t r)
    (hcount : ∀ r ∈ cofactors, count r d₀ = mass r)
    (hdensity : ∀ r ∈ cofactors, density r d₀ = 1)
    (hg : ∀ r ∈ cofactors, ∀ d ∈ moduli, 0 ≤ density r d)
    (hG : ∀ r ∈ cofactors, ∑ d ∈ moduli, density r d ≤ C * L)
    (hsource : ∀ r ∈ cofactors,
      (∑ d ∈ moduli, |count r d - density r d * integral r|) ≤ x / r * (E / L)) :
    (∑ r ∈ cofactors, t r * ∑ d ∈ moduli, |count r d - density r d * mass r|) ≤
      (1 + C) * x * E * ∑ r ∈ cofactors, t r / r := by
  have hJ : 0 ≤ ∑ r ∈ cofactors, t r / r :=
    Finset.sum_nonneg (fun r hr ↦ div_nonneg (ht r hr) (Nat.cast_nonneg r))
  have h := weighted_distribution_of_direct_errors cofactors moduli t count density
    mass integral hd₀ x (E / L) (C * L) ht hcount hdensity hg hG hsource
  refine h.trans ?_
  calc
    (1 + C * L) * x * (E / L) * (∑ r ∈ cofactors, t r / r) =
        ((1 + C * L) * (E / L)) * (x * (∑ r ∈ cofactors, t r / r)) := by ring
    _ ≤ ((1 + C) * E) * (x * (∑ r ∈ cofactors, t r / r)) :=
      mul_le_mul_of_nonneg_right (absorb_distribution_log_loss hL hE) (mul_nonneg hx hJ)
    _ = _ := by ring

/-- The strict exponent margin used to invoke BV at the varying prime scale
`T ≍ x/r`. All fixed factors can eventually be absorbed in this positive gap. -/
theorem bv_scale_exponent_gap {ε κ : ℝ} (hε : 0 < ε) (hεκ : ε < κ) :
    (1 - ε) * (1 / 2 - (κ - ε) / 4) - (1 / 2 - κ / 2) =
      (κ - ε) * (1 + ε) / 4 ∧
    0 < (1 - ε) * (1 / 2 - (κ - ε) / 4) - (1 / 2 - κ / 2) := by
  have hid : (1 - ε) * (1 / 2 - (κ - ε) / 4) - (1 / 2 - κ / 2) =
      (κ - ε) * (1 + ε) / 4 := by ring
  refine ⟨hid, ?_⟩
  rw [hid]
  exact div_pos (mul_pos (sub_pos.mpr hεκ) (by linarith)) (by norm_num)

/-- A concrete modulus-range conversion at the actual prime scale `x/(c*r)`.
The fixed factors `M` and `c` are paid from the positive exponent margin; this
makes the uniformity in all cofactors `r ≤ x^ε` explicit. -/
theorem bv_modulus_range {x r c M D ε α β : ℝ}
    (hx : 0 < x) (hr : 0 < r) (hc : 0 < c) (hM : 0 ≤ M)
    (hβ : 0 ≤ β) (hrange : r ≤ x ^ ε) (hD : D ≤ x ^ α)
    (hmargin : M * c ^ β ≤ x ^ ((1 - ε) * β - α)) :
    M * D ≤ (x / (c * r)) ^ β := by
  have hxp : 0 < x ^ ε := Real.rpow_pos_of_pos hx ε
  have hcp : 0 < c ^ β := Real.rpow_pos_of_pos hc β
  have hT : x ^ (1 - ε) / c ≤ x / (c * r) := by
    rw [Real.rpow_sub hx, Real.rpow_one]
    calc
      x / x ^ ε / c ≤ (x / r) / c :=
        div_le_div_of_nonneg_right (div_le_div_of_nonneg_left hx.le hr hrange) hc.le
      _ = x / (c * r) := by ring
  calc
    M * D ≤ M * x ^ α := mul_le_mul_of_nonneg_left hD hM
    _ ≤ x ^ ((1 - ε) * β) / c ^ β := by
      apply (le_div_iff₀ hcp).2
      have hm := mul_le_mul_of_nonneg_right hmargin (Real.rpow_nonneg hx.le α)
      calc
        M * x ^ α * c ^ β = (M * c ^ β) * x ^ α := by ring
        _ ≤ x ^ ((1 - ε) * β - α) * x ^ α := hm
        _ = x ^ ((1 - ε) * β) := by
          rw [← Real.rpow_add hx]
          congr 1
          ring
    _ = (x ^ (1 - ε) / c) ^ β := by
      rw [Real.div_rpow (Real.rpow_nonneg hx.le _) hc.le, ← Real.rpow_mul hx.le]
    _ ≤ (x / (c * r)) ^ β :=
      Real.rpow_le_rpow (div_nonneg (Real.rpow_nonneg hx.le _) hc.le) hT hβ

/-- Once the exponent gap is positive, the modulus inequality holds beyond
one threshold simultaneously for every permitted cofactor and modulus. -/
theorem eventually_bv_modulus_range {c M ε α β : ℝ}
    (hc : 0 < c) (hM : 0 ≤ M) (hβ : 0 ≤ β)
    (hgap : 0 < (1 - ε) * β - α) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ r D : ℝ,
      0 < r → r ≤ x ^ ε → D ≤ x ^ α → M * D ≤ (x / (c * r)) ^ β := by
  have hm : ∀ᶠ x : ℝ in Filter.atTop,
      M * c ^ β ≤ x ^ ((1 - ε) * β - α) :=
    (tendsto_rpow_atTop hgap).eventually (Filter.eventually_ge_atTop _)
  have hx : ∀ᶠ x : ℝ in Filter.atTop, 0 < x := Filter.eventually_gt_atTop 0
  filter_upwards [hm, hx] with x hmx hxx
  intro r D hr hrange hD
  exact bv_modulus_range hxx hr hc hM hβ hrange hD hmx

/-- The manuscript's specific exponents, including the fixed progression
modulus, satisfy the BV range uniformly over all `r ≤ x^ε`. -/
theorem eventually_manuscript_bv_range {c M ε κ : ℝ}
    (hc : 0 < c) (hM : 0 ≤ M) (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ r D : ℝ,
      0 < r → r ≤ x ^ ε → D ≤ x ^ (1 / 2 - κ / 2) →
      M * D ≤ (x / (c * r)) ^ (1 / 2 - (κ - ε) / 4) := by
  exact eventually_bv_modulus_range hc hM (by linarith)
    (bv_scale_exponent_gap hε hεκ).2

/-- Pointwise prime-count comparisons sum against arbitrary nonnegative
cofactor weights with precisely their harmonic mass. -/
theorem weighted_mass_comparison (cofactors : Finset ℕ) (t mass : ℕ → ℝ)
    (x L low high : ℝ) (ht : ∀ r ∈ cofactors, 0 ≤ t r)
    (hlow : ∀ r ∈ cofactors, low * x / r / L ≤ mass r)
    (hhigh : ∀ r ∈ cofactors, mass r ≤ high * x / r / L) :
    low * x / L * (∑ r ∈ cofactors, t r / r) ≤ ∑ r ∈ cofactors, t r * mass r ∧
    (∑ r ∈ cofactors, t r * mass r) ≤ high * x / L * ∑ r ∈ cofactors, t r / r := by
  constructor
  · rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro r hr
    calc
      low * x / L * (t r / r) = t r * (low * x / r / L) := by ring
      _ ≤ t r * mass r := mul_le_mul_of_nonneg_left (hlow r hr) (ht r hr)
  · rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro r hr
    calc
      t r * mass r ≤ t r * (high * x / r / L) :=
        mul_le_mul_of_nonneg_left (hhigh r hr) (ht r hr)
      _ = high * x / L * (t r / r) := by ring

/-- A number all of whose prime divisors are at most `W`. This formulation also
handles prime powers, so the injectivity below does not require squarefreeness. -/
def HasSmallPrimeFactors (W m : ℕ) : Prop := ∀ p : ℕ, p.Prime → p ∣ m → p ≤ W

/-- The large prime in a large-prime times smooth-number factorization is
unique. This is the precise absence of multiplicity in the conditioned BV sum. -/
theorem large_prime_smooth_product_injective {W n₁ n₂ l₁ l₂ : ℕ}
    (hn₁ : n₁.Prime) (hn₂ : n₂.Prime) (hW₁ : W < n₁) (_hW₂ : W < n₂)
    (_hl₁ : HasSmallPrimeFactors W l₁) (hl₂ : HasSmallPrimeFactors W l₂)
    (heq : n₁ * l₁ = n₂ * l₂) : n₁ = n₂ ∧ l₁ = l₂ := by
  have hdiv : n₁ ∣ n₂ * l₂ := heq ▸ (dvd_mul_right n₁ l₁)
  have heqn : n₁ = n₂ := by
    rcases hn₁.dvd_mul.mp hdiv with h | h
    · exact (Nat.prime_dvd_prime_iff_eq hn₁ hn₂).mp h
    · exact False.elim ((not_le_of_gt hW₁) (hl₂ n₁ hn₁ h))
  constructor
  · exact heqn
  · exact Nat.eq_of_mul_eq_mul_left hn₁.pos (by simpa only [← heqn] using heq)

/-- Sum the conditioned errors by their product modulus once, with no divisor
weight. The target modulus set may contain additional moduli. -/
theorem conditioned_error_sum_le (pairs : Finset (ℕ × ℕ)) (moduli : Finset ℕ)
    (W : ℕ) (error : ℕ → ℝ)
    (hpair : ∀ z ∈ pairs, z.1.Prime ∧ W < z.1 ∧ HasSmallPrimeFactors W z.2)
    (hmoduli : ∀ z ∈ pairs, z.1 * z.2 ∈ moduli) :
    (∑ z ∈ pairs, |error (z.1 * z.2)|) ≤ ∑ d ∈ moduli, |error d| := by
  apply Finset.sum_le_sum_of_injOn (fun z : ℕ × ℕ ↦ z.1 * z.2)
  · intro a ha b hb hab
    have ha' := hpair a ha
    have hb' := hpair b hb
    obtain ⟨h₁, h₂⟩ := large_prime_smooth_product_injective
      ha'.1 hb'.1 ha'.2.1 hb'.2.1 ha'.2.2 hb'.2.2 hab
    exact Prod.ext h₁ h₂
  · intro d hd
    obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hd
    exact hmoduli z hz
  · intro z _
    exact le_rfl
  · intro d _ _
    exact abs_nonneg _

end Artin
