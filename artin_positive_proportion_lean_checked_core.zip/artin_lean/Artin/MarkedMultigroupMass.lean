module

public import Artin.MarkedCofactorMass
public import Mathlib.Algebra.BigOperators.Ring.Finset

/-!
# A finite normalized mass for all marked prime groups

Choose exactly one prime from each of the disjoint marked groups. These choices
give distinct positive natural numbers, each with precisely one prime divisor
in every group. Their reciprocal marking mass is the product of the normalized
reciprocal-prime sums, and is therefore at least one.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.MarkedMultigroupMass

open ConcreteSelector

/-- Actual integers obtained by choosing one prime from each marked group. -/
noncomputable def singletonMarked {ι : Type*} [DecidableEq ι] (I : Finset ι)
    (groups : ι → Finset ℕ) : Finset ℕ :=
  (Fintype.piFinset (fun i : I => groups i)).image (fun f => ∏ i, f i)

variable {ι : Type*} [DecidableEq ι] (I : Finset ι) (groups : ι → Finset ℕ)

omit [DecidableEq ι] in
/-- A chosen product is positive. -/
theorem choice_product_pos
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (f : I → ℕ) (hf : ∀ i : I, f i ∈ groups i) : 0 < ∏ i, f i := by
  exact Finset.prod_pos (fun i _ => (hprime i i.property (f i) (hf i)).pos)

/-- A prime from one group dividing a chosen product is that group's choice. -/
theorem prime_in_group_dvd_choice
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (f : I → ℕ) (hf : ∀ i : I, f i ∈ groups i)
    (i : I) {q : ℕ} (hq : q ∈ groups i) (hdvd : q ∣ ∏ j, f j) : q = f i := by
  classical
  have hqprime := hprime i i.property q hq
  obtain ⟨j, _, hj⟩ := (hqprime.prime.dvd_finsetProd_iff f).mp hdvd
  have heq : q = f j :=
    (Nat.prime_dvd_prime_iff_eq hqprime (hprime j j.property (f j) (hf j))).mp hj
  have hij : i = j := by
    by_contra hne
    have hne' : (i : ι) ≠ j := fun h => hne (Subtype.ext h)
    exact Finset.disjoint_left.mp (hdisjoint i i.property j j.property hne')
      hq (heq ▸ hf j)
  simpa [hij] using heq

/-- Disjoint prime groups make the product map injective on the choices. -/
theorem choice_product_injective
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j)) :
    Set.InjOn (fun f : I → ℕ => ∏ i, f i)
      (↑(Fintype.piFinset (fun i : I => groups i)) : Set (I → ℕ)) := by
  classical
  intro f hf g hg heq
  have hf' := Fintype.mem_piFinset.mp hf
  have hg' := Fintype.mem_piFinset.mp hg
  funext i
  apply prime_in_group_dvd_choice I groups hprime hdisjoint g hg' i (hf' i)
  change (∏ i, f i) = ∏ i, g i at heq
  rw [← heq]
  exact Finset.dvd_prod_of_mem f (Finset.mem_univ i)

/-- Each group has exactly one distinct prime divisor in a chosen product. -/
theorem primeCount_choice_product
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (f : I → ℕ) (hf : ∀ i : I, f i ∈ groups i) (i : I) :
    primeCount (groups i) (∏ j, f j) = 1 := by
  classical
  have hset : (∏ j, f j).primeFactors ∩ groups i = {f i} := by
    ext q
    constructor
    · intro hq
      obtain ⟨hqf, hqg⟩ := Finset.mem_inter.mp hq
      exact Finset.mem_singleton.mpr (prime_in_group_dvd_choice I groups
        hprime hdisjoint f hf i hqg (Nat.dvd_of_mem_primeFactors hqf))
    · intro hq
      have heq := Finset.mem_singleton.mp hq
      subst q
      exact Finset.mem_inter.mpr ⟨(hprime i i.property (f i) (hf i)).mem_primeFactors
        (Finset.dvd_prod_of_mem f (Finset.mem_univ i))
        (choice_product_pos I groups hprime f hf).ne', hf i⟩
  unfold primeCount
  rw [hset]
  simp

/-- Chosen integers are positive and supported on the union of the groups. -/
theorem singletonMarked_supported
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime) :
    ∀ s ∈ singletonMarked I groups,
      s ≠ 0 ∧ ∀ q : ℕ, q.Prime → q ∣ s → q ∈ I.biUnion groups := by
  classical
  intro s hs
  obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp hs
  have hf' := Fintype.mem_piFinset.mp hf
  refine ⟨(choice_product_pos I groups hprime f hf').ne', ?_⟩
  intro q hq hdvd
  obtain ⟨i, _, hi⟩ := (hq.prime.dvd_finsetProd_iff f).mp hdvd
  have heq : q = f i :=
    (Nat.prime_dvd_prime_iff_eq hq (hprime i i.property (f i) (hf' i))).mp hi
  exact Finset.mem_biUnion.mpr ⟨i, i.property, heq ▸ hf' i⟩

/-- The exact reciprocal mass, summed over distinct natural numbers. -/
theorem singleton_marking_mass (V : ι → ℝ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j)) :
    (∑ s ∈ singletonMarked I groups, markingWeight I groups V s / (s : ℝ)) =
      ∏ i ∈ I, (∑ p ∈ groups i, 1 / (p : ℝ)) / V i := by
  classical
  unfold singletonMarked
  rw [Finset.sum_image (choice_product_injective I groups hprime hdisjoint)]
  calc
    (∑ f ∈ Fintype.piFinset (fun i : I => groups i),
        markingWeight I groups V (∏ i, f i) / ((∏ i, f i : ℕ) : ℝ)) =
        ∑ f ∈ Fintype.piFinset (fun i : I => groups i),
          ∏ i, (1 / (f i : ℝ)) / V i := by
      apply Finset.sum_congr rfl
      intro f hf
      have hf' := Fintype.mem_piFinset.mp hf
      have hw : markingWeight I groups V (∏ i, f i) = ∏ i : I, 1 / V i := by
        rw [markingWeight, ← Finset.prod_coe_sort]
        apply Finset.prod_congr rfl
        intro i _
        rw [primeCount_choice_product I groups hprime hdisjoint f hf' i]
        simp [MarkedWeights.groupWeight]
      rw [hw, Nat.cast_prod, ← Finset.prod_div_distrib]
      apply Finset.prod_congr rfl
      intro i _
      ring
    _ = ∏ i : I, (∑ p ∈ groups i, 1 / (p : ℝ)) / V i := by
      rw [← Finset.prod_univ_sum (fun i : I => groups i)
        (fun i p => (1 / (p : ℝ)) / V i)]
      apply Finset.prod_congr rfl
      intro i _
      exact (Finset.sum_div _ _ _).symm
    _ = _ := Finset.prod_coe_sort I (fun i => (∑ p ∈ groups i, 1 / (p : ℝ)) / V i)

/-- With the reciprocal-prime normalizations, these choices contribute exactly one. -/
theorem singleton_marking_mass_eq_one (V : ι → ℝ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i = ∑ p ∈ groups i, 1 / (p : ℝ)) :
    (∑ s ∈ singletonMarked I groups, markingWeight I groups V s / (s : ℝ)) = 1 := by
  rw [singleton_marking_mass I groups V hprime hdisjoint]
  apply Finset.prod_eq_one
  intro i hi
  rw [← hVsum i hi]
  exact div_self (hV i hi).ne'

/-- Singleton choices already supply normalized mass at least one. -/
theorem singleton_marking_mass_ge_one (V : ι → ℝ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i ≤ ∑ p ∈ groups i, 1 / (p : ℝ)) :
    1 ≤ ∑ s ∈ singletonMarked I groups, markingWeight I groups V s / (s : ℝ) := by
  rw [singleton_marking_mass I groups V hprime hdisjoint]
  apply Finset.one_le_prod₀
  intro i hi
  exact (one_le_div (hV i hi)).mpr (hVsum i hi)

/-- Any larger finite family inherits the normalized mass lower bound. -/
theorem supported_marking_mass_ge_one (V : ι → ℝ) (S : Finset ℕ)
    (hprime : ∀ i ∈ I, ∀ p ∈ groups i, p.Prime)
    (hdisjoint : ∀ i ∈ I, ∀ j ∈ I, i ≠ j → Disjoint (groups i) (groups j))
    (hV : ∀ i ∈ I, 0 < V i)
    (hVsum : ∀ i ∈ I, V i ≤ ∑ p ∈ groups i, 1 / (p : ℝ))
    (hS : singletonMarked I groups ⊆ S) :
    1 ≤ ∑ s ∈ S, markingWeight I groups V s / (s : ℝ) := by
  refine (singleton_marking_mass_ge_one I groups V hprime hdisjoint hV hVsum).trans ?_
  apply Finset.sum_le_sum_of_subset_of_nonneg hS
  intro s hs _
  exact div_nonneg (markingWeight_bounds I groups V s hV).1 (Nat.cast_nonneg _)

end Artin.MarkedMultigroupMass
