module

public import Artin.Arithmetic
public import Artin.Counting

/-!
# From structured candidates to primitive-root primes

This file closes the finite logical deduction in Section 11. It does not assert
the analytic lower bound for the candidate set or either exceptional-set upper
bound: these are explicit hypotheses of the final counting theorem.

The cutoffs `Y` and `R` are natural numbers. A later analytic application may
choose `R = floor(x^ε)` and adjust the fixed cutoff `Y` by rounding.
-/

@[expose] public section

namespace Artin

/-- The arithmetic structure of a candidate. The additional progression,
interval, and size conditions used to construct candidates can be imposed by
restricting the ambient finite set; they are unnecessary for this deduction. -/
def StructuredCandidate (a : ℤ) (Y R p : ℕ) : Prop :=
  p.Prime ∧ p ≠ 2 ∧ (a : ZMod p) ≠ 0 ∧ ¬ IsSquare (a : ZMod p) ∧
  ∃ c r Q : ℕ,
    (c = 2 ∨ c = 4) ∧ 0 < r ∧ Q.Prime ∧ r ≤ R ∧
    p - 1 = c * r * Q ∧
    (∀ q : ℕ, q.Prime → q ∣ r → q ≠ 2 → Y < q)

/-- An index obstruction at a prime between the two cutoffs. -/
def SmallIndexObstruction (a : ℤ) (Y R p : ℕ) : Prop :=
  p.Prime ∧ ∃ q : ℕ, q.Prime ∧ Y < q ∧ q ≤ R ∧ q ∣ p - 1 ∧
    (a : ZMod p) ^ ((p - 1) / q) = 1

/-- The exceptional set coming from the large prime factor of the predecessor. -/
def SmallOrderException (a : ℤ) (R p : ℕ) : Prop :=
  p.Prime ∧ (a : ZMod p) ≠ 0 ∧ orderOf (a : ZMod p) ≤ 4 * R

theorem structuredCandidate_cover {a : ℤ} {Y R p : ℕ}
    (hcandidate : StructuredCandidate a Y R p) :
    IsPrimitiveRootAt a p ∨ SmallIndexObstruction a Y R p ∨
      SmallOrderException a R p := by
  classical
  by_cases hprimitive : IsPrimitiveRootAt a p
  · exact Or.inl hprimitive
  rcases hcandidate with ⟨hp, hp2, ha, hns, c, r, Q, hc, hr, hQ,
    hrR, hfactor, hrough⟩
  rcases candidate_exception_dichotomy hp ha hp2 hns hc hr hQ hfactor hrough
    hprimitive with hsmall | hlarge
  · obtain ⟨q, hq, hqY, hqr, hqdvd, hqpow⟩ := hsmall
    exact Or.inr (Or.inl ⟨hp, q, hq, hqY, hqr.trans hrR, hqdvd, hqpow⟩)
  · have hc4 : c ≤ 4 := by rcases hc with rfl | rfl <;> omega
    refine Or.inr (Or.inr ⟨hp, ha, ?_⟩)
    calc
      orderOf (a : ZMod p) ≤ c * r := hlarge
      _ ≤ 4 * r := Nat.mul_le_mul_right r hc4
      _ ≤ 4 * R := Nat.mul_le_mul_left 4 hrR

/-- The large-factor exceptional set really does divide the product from the
arithmetic module, with one common bound for every candidate. -/
theorem smallOrderException_dvd_product {a : ℤ} {R p : ℕ}
    (h : SmallOrderException a R p) :
    (p : ℤ) ∣ smallOrderProduct a (4 * R) := by
  exact small_order_dvd_product h.1 h.2.1 h.2.2

theorem filteredCard_mono {α : Type*} {s t : Finset α}
    (hst : s ⊆ t) (P : α → Prop) : filteredCard s P ≤ filteredCard t P := by
  classical
  apply Finset.card_le_card
  intro i hi
  have hi' := Finset.mem_filter.mp hi
  exact Finset.mem_filter.mpr ⟨hst hi'.1, hi'.2⟩

/-- Exact finite candidate-to-prime counting. All three analytic estimates are
visible hypotheses. The conclusion counts primitive-root primes in the whole
ambient set, not just in the candidate subset. -/
theorem primitive_count_from_candidate_estimates (a : ℤ) (Y R : ℕ)
    (s : Finset ℕ) {candidateLower smallUpper orderUpper : ℝ}
    (hcandidate : candidateLower ≤ (filteredCard s (StructuredCandidate a Y R) : ℝ))
    (hsmall : (filteredCard s (SmallIndexObstruction a Y R) : ℝ) ≤ smallUpper)
    (horder : (filteredCard s (SmallOrderException a R) : ℝ) ≤ orderUpper) :
    candidateLower - smallUpper - orderUpper ≤
      (filteredCard s (IsPrimitiveRootAt a) : ℝ) := by
  classical
  let candidates := s.filter (StructuredCandidate a Y R)
  have hsubset : candidates ⊆ s := Finset.filter_subset _ _
  have hcandidate' : candidateLower ≤ (candidates.card : ℝ) := hcandidate
  have hsmall' : (filteredCard candidates (SmallIndexObstruction a Y R) : ℝ)
      ≤ smallUpper := by
    exact (Nat.cast_le.mpr (filteredCard_mono hsubset _)).trans hsmall
  have horder' : (filteredCard candidates (SmallOrderException a R) : ℝ)
      ≤ orderUpper := by
    exact (Nat.cast_le.mpr (filteredCard_mono hsubset _)).trans horder
  have hfinite := count_after_two_exceptional_sets candidates
    (IsPrimitiveRootAt a) (SmallIndexObstruction a Y R) (SmallOrderException a R)
    (by
      intro p hp
      exact structuredCandidate_cover (Finset.mem_filter.mp hp).2)
    hcandidate' hsmall' horder'
  exact hfinite.trans (Nat.cast_le.mpr (filteredCard_mono hsubset _))

end Artin
