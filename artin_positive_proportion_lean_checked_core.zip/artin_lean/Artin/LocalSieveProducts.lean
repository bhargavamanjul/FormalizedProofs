module

public import Artin.Parameters
public import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
public import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.FieldSimp

/-!
# Omitting cofactor primes from the sieve product

This is the finite local-factor calculation in Section 6.  The set of omitted
primes may vary with the cofactor.  Only its reciprocal mass enters the bound;
there is no dependence on the number of marked groups or omitted primes.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.LocalSieveProducts

noncomputable def sieveFactor (p : ℕ) : ℝ := 1 - 1 / ((p : ℝ) - 1)

theorem sieveFactor_pos {p : ℕ} (hp : 3 ≤ p) : 0 < sieveFactor p := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  dsimp [sieveFactor]
  have : 1 / ((p : ℝ) - 1) < 1 := (div_lt_one (by linarith)).2 (by linarith)
  linarith

theorem sieveFactor_le_one {p : ℕ} (hp : 3 ≤ p) : sieveFactor p ≤ 1 := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  dsimp [sieveFactor]
  have hden : (0 : ℝ) < (p : ℝ) - 1 := by linarith
  have : 0 ≤ 1 / ((p : ℝ) - 1) := by positivity
  linarith

theorem inverse_sieveFactor {p : ℕ} (hp : 3 ≤ p) :
    (sieveFactor p)⁻¹ = 1 + 1 / ((p : ℝ) - 2) := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have h1 : (p : ℝ) - 1 ≠ 0 := by linarith
  have h2 : (p : ℝ) - 2 ≠ 0 := by linarith
  have hf : sieveFactor p = ((p : ℝ) - 2) / ((p : ℝ) - 1) := by
    dsimp [sieveFactor]
    field_simp [h1]
    ring
  rw [hf, inv_div]
  field_simp [h2]
  ring

theorem inverse_sieveFactor_le_exp {p : ℕ} (hp : 3 ≤ p) :
    (sieveFactor p)⁻¹ ≤ Real.exp (10 / (p : ℝ)) := by
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have hp0 : (0 : ℝ) < p := by linarith
  have hp2 : (0 : ℝ) < (p : ℝ) - 2 := by linarith
  rw [inverse_sieveFactor hp]
  have hdiv : 1 / ((p : ℝ) - 2) ≤ 10 / (p : ℝ) := by
    apply (div_le_div_iff₀ hp2 hp0).2
    nlinarith
  calc
    1 + 1 / ((p : ℝ) - 2) ≤ 1 + 10 / (p : ℝ) := by linarith
    _ ≤ Real.exp (10 / (p : ℝ)) := by simpa [add_comm] using Real.add_one_le_exp (10 / (p : ℝ))

theorem omitted_product_identity (S T : Finset ℕ) (hT : T ⊆ S)
    (hS : ∀ p ∈ S, 3 ≤ p) :
    (∏ p ∈ S \ T, sieveFactor p) =
      (∏ p ∈ S, sieveFactor p) * ∏ p ∈ T, (sieveFactor p)⁻¹ := by
  have hn : (∏ p ∈ T, sieveFactor p) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun p hp => ne_of_gt (sieveFactor_pos (hS p (hT hp))))
  rw [Finset.prod_inv_distrib]
  rw [← Finset.prod_sdiff hT, mul_assoc, mul_inv_cancel₀ hn, mul_one]

/-- Removing local factors increases the product, but by at most the
exponential of ten times the reciprocal mass of the removed primes. -/
theorem omitted_product_bounds (S T : Finset ℕ) (hT : T ⊆ S)
    (hS : ∀ p ∈ S, 3 ≤ p) :
    (∏ p ∈ S, sieveFactor p) ≤ (∏ p ∈ S \ T, sieveFactor p) ∧
    (∏ p ∈ S \ T, sieveFactor p) ≤
      Real.exp (10 * ∑ p ∈ T, 1 / (p : ℝ)) * ∏ p ∈ S, sieveFactor p := by
  have hbase : 0 ≤ ∏ p ∈ S, sieveFactor p :=
    Finset.prod_nonneg (fun p hp => (sieveFactor_pos (hS p hp)).le)
  have hinv : 1 ≤ ∏ p ∈ T, (sieveFactor p)⁻¹ := by
    apply Finset.one_le_prod₀
    intro p hp
    exact (one_le_inv₀ (sieveFactor_pos (hS p (hT hp)))).2 (sieveFactor_le_one (hS p (hT hp)))
  have hupper : (∏ p ∈ T, (sieveFactor p)⁻¹) ≤
      Real.exp (10 * ∑ p ∈ T, 1 / (p : ℝ)) := by
    calc
      (∏ p ∈ T, (sieveFactor p)⁻¹) ≤ ∏ p ∈ T, Real.exp (10 / (p : ℝ)) :=
        Finset.prod_le_prod₀ (fun p hp => le_of_lt (inv_pos.mpr (sieveFactor_pos (hS p (hT hp)))))
          (fun p hp => inverse_sieveFactor_le_exp (hS p (hT hp)))
      _ = Real.exp (10 * ∑ p ∈ T, 1 / (p : ℝ)) := by
        rw [← Real.exp_sum, Finset.mul_sum]
        congr 1
        apply Finset.sum_congr rfl
        intro p hp
        ring
  rw [omitted_product_identity S T hT hS]
  constructor
  · simpa using mul_le_mul_of_nonneg_left hinv hbase
  · simpa [mul_comm] using mul_le_mul_of_nonneg_left hupper hbase

/-- The estimate is uniform over every omitted set with the given mass cap. -/
theorem omitted_product_le_of_reciprocal_mass (S T : Finset ℕ) (hT : T ⊆ S)
    (hS : ∀ p ∈ S, 3 ≤ p) {τ : ℝ}
    (hmass : (∑ p ∈ T, 1 / (p : ℝ)) ≤ τ) :
    (∏ p ∈ S \ T, sieveFactor p) ≤
      Real.exp (10 * τ) * ∏ p ∈ S, sieveFactor p := by
  apply (omitted_product_bounds S T hT hS).2.trans
  exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (by linarith))
    (Finset.prod_nonneg (fun p hp => (sieveFactor_pos (hS p hp)).le))

end Artin.LocalSieveProducts
