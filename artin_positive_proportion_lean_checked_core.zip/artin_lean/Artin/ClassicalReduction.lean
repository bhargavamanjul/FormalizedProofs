module

public import Artin.KummerArithmetic
public import Artin.ManuscriptReduction

/-!
# Quantitative conclusion with the actual classical formula objects

This endpoint replaces the former explicit-formula package by its proved
construction from actual Mellin transforms, ideal sums, and zeta zeros with
multiplicity.  The candidate-sieve construction and the exact Kummer algebra
remain explicit obligations.  In particular, this is not yet an endpoint
whose only premises are the accepted references.
-/

@[expose] public section
namespace Artin

open Filter
open scoped Topology

/-- Enlarging the exceptional cutoff preserves every Kummer arithmetic
statement; this lets the sieve choose its own larger fixed threshold. -/
noncomputable def KummerArithmeticFacts.mono {a : ℤ} {Y₁ Y₂ : ℝ}
    (arith : KummerArithmeticFacts a Y₁) (hY : Y₁ ≤ Y₂) :
    KummerArithmeticFacts a Y₂ where
  degree_eq := fun q hq hlarge => arith.degree_eq q hq (hY.trans_lt hlarge)
  normalized_discriminant := fun q hq hlarge =>
    arith.normalized_discriminant q hq (hY.trans_lt hlarge)
  splitIdeals := fun q hq hlarge => arith.splitIdeals q hq (hY.trans_lt hlarge)
  split_norm := fun q hq hlarge p j => arith.split_norm q hq (hY.trans_lt hlarge) p j

/-- The final constant precedes the zero-free parameter.  All analytic
formula inputs have their actual definitions in `ClassicalFormula`. -/
theorem quantitative_prime_proportion_of_sieve_and_classical_formulas
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B Y₀ ε₀ A Bm R T : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀) (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (arith : KummerArithmeticFacts a Y₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ primitiveCount a x := by
  exact quantitative_prime_proportion_of_sieve_and_kummer_data a ha
    hS hc₀ hd hB fixedSplittingSmoothing_mass_pos (by positivity) hY₀ hε₀ hk sieve
    (classicalKummerInputs_of_classical hexists fixedSplittingSmoothing
      hA hBm hR hcount hdecay hformula arith)

/-- The width `1/6000` specialization, with the same visible source boundary. -/
theorem positive_prime_proportion_at_6000_of_sieve_and_classical_formulas
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B Y₀ ε₀ A Bm R T : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀) (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (arith : KummerArithmeticFacts a Y₀)
    (qrh6000 : DedekindQRH 6000) : HasPositivePrimeProportion a := by
  obtain ⟨c, hc, hb⟩ := quantitative_prime_proportion_of_sieve_and_classical_formulas
    a ha hS hc₀ hd hB hY₀ hε₀ hk sieve hexists hA hBm hR hcount hdecay hformula arith
  refine ⟨c / ((6000 : ℝ) * Real.log 6000), ?_, hb 6000 (by norm_num) qrh6000⟩
  have hlog : 0 < Real.log (6000 : ℝ) := Real.log_pos (by norm_num)
  positivity

/-- All specialized Kummer data are constructed from separately stated
classical results.  The only manuscript-specific data package still present
is the candidate sieve; it is deliberately not labeled a cited theorem. -/
theorem quantitative_prime_proportion_of_sieve_and_separate_classical_results
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B Y₀ ε₀ A Bm R T : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hY₀ : (a.natAbs : ℝ) ≤ Y₀)
    (hε₀ : 0 < ε₀) (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hdegree : ClassicalKummerDegree)
    (hdiscr : ClassicalKummerPolynomialDiscriminant)
    (hsplit : ClassicalKummerSplitting) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ primitiveCount a x := by
  have hY : (0 : ℝ) < a.natAbs := by exact_mod_cast (by have := ha.natAbs_gt_one; omega)
  exact quantitative_prime_proportion_of_sieve_and_classical_formulas a ha
    hS hc₀ hd hB (hY.trans_le hY₀) hε₀ hk sieve hexists hA hBm hR hcount hdecay hformula
    ((kummerArithmeticFacts_of_classical ha hdegree hdiscr hsplit).mono hY₀)

end Artin
