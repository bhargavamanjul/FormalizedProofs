module

public import Artin.MarkedCofactorEstimate
public import Artin.WeightedTail
public import Artin.SieveDistribution

/-!
# From uniform prime progression counts to the full marked mass

The full marking is retained throughout. The small-cofactor part uses its
actual reciprocal mass; the remaining part is bounded by the convergent
distinct-integer tail. In particular the comparison constants below do not
depend on a supremum for the marking weight or on its number of groups.
-/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.FullMassComparison

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate
  EnlargedCofactorMass MarkedInfiniteMass MarkedBandTail

/-- The actual cofactor expansion of the total smoothed integer weight. -/
noncomputable def cofactorPrimeMass (c M u : ℕ) (Qs P U : Finset ℕ)
    (Ψ : ℕ → ℝ) (W : ℕ → ℝ) (X : ℝ) : ℝ :=
  ∑ r ∈ boundedCofactors P U X,
    W (markedPart P r) * primeProgressionSum c M u Qs Ψ r

theorem boundedCofactors_mono (P U : Finset ℕ) {X T : ℝ} (h : X ≤ T) :
    boundedCofactors P U X ⊆ boundedCofactors P U T := by
  intro r hr
  obtain ⟨hr, hu, hx⟩ := (mem_boundedCofactors P U X r).mp hr
  exact (mem_boundedCofactors P U T r).mpr ⟨hr, hu, hx.trans h⟩

theorem primeProgressionSum_nonneg (c M u : ℕ) (Qs : Finset ℕ) (Ψ : ℕ → ℝ)
    (hΨ : ∀ d, 0 ≤ Ψ d) (r : ℕ) :
    0 ≤ primeProgressionSum c M u Qs Ψ r := by
  apply Finset.sum_nonneg
  intro Q hQ
  split_ifs
  · exact hΨ _
  · exact le_rfl

/-- A finite cutoff larger than the retained cutoff contains its full
positive main mass. -/
theorem cofactorPrimeMass_lower (c M u : ℕ) (Qs P U : Finset ℕ)
    (Ψ W : ℕ → ℝ) {x L low X T : ℝ}
    (hXT : X ≤ T) (hW : ∀ n, 0 ≤ W n) (hΨ : ∀ d, 0 ≤ Ψ d)
    (hAr : ∀ r ∈ boundedCofactors P U X,
      low * x / r / L ≤ primeProgressionSum c M u Qs Ψ r) :
    low * x / L * boundedMass P U W X ≤ cofactorPrimeMass c M u Qs P U Ψ W T := by
  have hsmall : low * x / L * boundedMass P U W X ≤
      cofactorPrimeMass c M u Qs P U Ψ W X := by
    unfold boundedMass cofactorPrimeMass
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro r hr
    calc
      low * x / L * (W (markedPart P r) / r) =
          W (markedPart P r) * (low * x / r / L) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (hAr r hr) (hW _)
  refine hsmall.trans ?_
  apply Finset.sum_le_sum_of_subset_of_nonneg (boundedCofactors_mono P U hXT)
  intro r hr hnot
  exact mul_nonneg (hW _) (primeProgressionSum_nonneg c M u Qs Ψ hΨ r)

/-- The full upper mass is the small-cofactor prime bound plus the genuine
enlarged-integer tail. This does not replace the marking by its maximum. -/
theorem cofactorPrimeMass_upper (c M u : ℕ) (Qs P U : Finset ℕ)
    (Ψ W : ℕ → ℝ) {x L high X T : ℝ}
    (hx : 0 ≤ x) (hL : 0 < L) (hhigh : 0 ≤ high) (hc : 2 ≤ c)
    (hXT : X ≤ T) (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (enlargedReciprocal P U W))
    (hQ : ∀ Q ∈ Qs, 0 < Q)
    (hΨ : ∀ d, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d : ℕ, 2 * x < (d : ℝ) → Ψ d = 0)
    (hAr : ∀ r ∈ boundedCofactors P U X,
      primeProgressionSum c M u Qs Ψ r ≤ high * x / r / L) :
    cofactorPrimeMass c M u Qs P U Ψ W T ≤
      high * x / L * enlargedMass P U W + x * enlargedSizeTail P U W X := by
  classical
  let R := boundedCofactors P U X
  let S := boundedCofactors P U T
  have hRS : R ⊆ S := boundedCofactors_mono P U hXT
  have hsmall : cofactorPrimeMass c M u Qs P U Ψ W X ≤
      high * x / L * enlargedMass P U W := by
    calc
      _ ≤ high * x / L * boundedMass P U W X := by
        unfold cofactorPrimeMass boundedMass
        rw [Finset.mul_sum]
        apply Finset.sum_le_sum
        intro r hr
        calc
          _ ≤ W (markedPart P r) * (high * x / r / L) :=
            mul_le_mul_of_nonneg_left (hAr r hr) (hW _)
          _ = _ := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (boundedMass_le_full P U W X hW hsum)
        (by positivity)
  have htail := WeightedTail.weighted_tail_le_enlarged_tail (S \ R) Qs P U W Ψ
    hx hc (X := X) (M := M) (u := u) (by
      intro r hr
      obtain ⟨hs, hn⟩ := Finset.mem_sdiff.mp hr
      obtain ⟨hp, hu, ht⟩ := (mem_boundedCofactors P U T r).mp hs
      refine ⟨hp, hu, lt_of_not_ge ?_⟩
      intro hle
      exact hn ((mem_boundedCofactors P U X r).mpr ⟨hp, hu, hle⟩))
    hW hsum hQ hΨ hsupport
  have heq : cofactorPrimeMass c M u Qs P U Ψ W T =
      cofactorPrimeMass c M u Qs P U Ψ W X +
      ∑ r ∈ S \ R, W (markedPart P r) * primeProgressionSum c M u Qs Ψ r := by
    simpa only [cofactorPrimeMass, R, S, add_comm] using
      (Finset.sum_sdiff hRS (f := fun r =>
        W (markedPart P r) * primeProgressionSum c M u Qs Ψ r)).symm
  rw [heq]
  exact add_le_add hsmall htail

/-- The decisive full-`J` comparison. The factor `1/2` comes from retention
of the entire marked mass, so no constant depending on the marks appears. -/
theorem full_mass_comparison (c M u : ℕ) (Qs P U : Finset ℕ)
    (Ψ W : ℕ → ℝ) {x L low high X T : ℝ}
    (hx : 0 ≤ x) (hL : 0 < L) (hlow : 0 ≤ low) (hhigh : 0 ≤ high) (hc : 2 ≤ c)
    (hXT : X ≤ T) (hW : ∀ n, 0 ≤ W n)
    (hsum : Summable (enlargedReciprocal P U W))
    (hQ : ∀ Q ∈ Qs, 0 < Q)
    (hΨ : ∀ d, 0 ≤ Ψ d ∧ Ψ d ≤ 1)
    (hsupport : ∀ d : ℕ, 2 * x < (d : ℝ) → Ψ d = 0)
    (hAr : ∀ r ∈ boundedCofactors P U X,
      low * x / r / L ≤ primeProgressionSum c M u Qs Ψ r ∧
      primeProgressionSum c M u Qs Ψ r ≤ high * x / r / L)
    (hretain : enlargedMass P U W / 2 ≤ boundedMass P U W X)
    (htail : enlargedSizeTail P U W X ≤ enlargedMass P U W / L) :
    (low / 2) * x / L * enlargedMass P U W ≤ cofactorPrimeMass c M u Qs P U Ψ W T ∧
    cofactorPrimeMass c M u Qs P U Ψ W T ≤
      (high + 1) * x / L * enlargedMass P U W := by
  constructor
  · calc
      _ = low * x / L * (enlargedMass P U W / 2) := by ring
      _ ≤ low * x / L * boundedMass P U W X :=
        mul_le_mul_of_nonneg_left hretain (by positivity)
      _ ≤ _ := cofactorPrimeMass_lower c M u Qs P U Ψ W hXT hW
        (fun d => (hΨ d).1) (fun r hr => (hAr r hr).1)
  · calc
      _ ≤ high * x / L * enlargedMass P U W + x * enlargedSizeTail P U W X :=
        cofactorPrimeMass_upper c M u Qs P U Ψ W hx hL hhigh hc hXT hW hsum
          hQ hΨ hsupport (fun r hr => (hAr r hr).2)
      _ ≤ high * x / L * enlargedMass P U W + x * (enlargedMass P U W / L) :=
        add_le_add le_rfl (mul_le_mul_of_nonneg_left htail hx)
      _ = _ := by ring

/-- The actual band tail is eventually at most `J / log x`, with coefficient
one independent of the marking family. Only its onset depends on that family. -/
theorem actual_tail_le_full_over_log {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) :
    ∀ ε : ℝ, 0 < ε → ∀ Y τ : ℝ, ∀ᶠ x : ℝ in atTop,
      enlargedSizeTail (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (marking I a x) (x ^ ε) ≤
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
        (marking I a x) / Real.log x := by
  obtain ⟨C, hC, hmass⟩ := actual_bands_mass_bounds I a B v₀ hv₀ hinj hclassical
  obtain ⟨Ct, hCt, htail⟩ := actual_bands_enlarged_cofactor_tail I a amin amax B v₀
    hmin hv₀ ha hclassical
  intro ε hε Y τ
  have hdecay := WeightedTail.eventually_tail_le_log_power 1 Ct
    (t := ε / 2) (b := 1 - amax) (by positivity) (by linarith)
  filter_upwards [hmass, htail ε Y τ, hclassical, hdecay,
    eventually_gt_atTop (1 : ℝ)] with x hm ht hv hd hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hv i hi).1
  have hH : 0 ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x := by
    unfold CofactorAsymptotics.scaleMass CofactorAsymptotics.mass
    exact Finset.sum_nonneg (fun n hn => by positivity)
  have hfull : CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x ≤
      enlargedMass (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (marking I a x) := by
    rw [full_mass_eq I a ε Y τ x hV]
    simpa only [one_mul, markedPrimes, marking] using mul_le_mul_of_nonneg_right hm.1 hH
  have hd' : Ct * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax)) ≤
      1 / Real.log x := by simpa only [Real.rpow_neg_one, one_div] using hd
  calc
    _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x *
        (Ct * Real.exp (-(ε / 2) * (Real.log x) ^ (1 - amax))) := ht
    _ ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x / Real.log x := by
      simpa only [mul_one_div] using mul_le_mul_of_nonneg_left hd' hH
    _ ≤ _ := div_le_div_of_nonneg_right hfull (Real.log_pos hx).le

end Artin.FullMassComparison
