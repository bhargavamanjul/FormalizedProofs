module

public import Artin.AnalyticReduction
public import Artin.Splitting

/-!
# The small-index union and its analytic summation

This file proves the finite union reduction and the deduction of the actual
`SmallIndexEstimate` from individual power-residue estimates and the classical
reciprocal-prime tail. Neither analytic input is declared as an axiom.

The individual estimate must hold simultaneously for all eligible `q` at a
given sufficiently large `x`. A separate eventual statement for each fixed
`q` would not suffice for the moving range `q ≤ x ^ ε`.
-/

@[expose] public section

namespace Artin

open Filter
open scoped BigOperators Topology

/-- The finite prime range which can divide a small index. -/
noncomputable def primeIndexWindow (Y R : ℕ) : Finset ℕ := by
  classical
  exact (Nat.primesLE R).filter (fun q => Y < q)

theorem mem_primeIndexWindow {Y R q : ℕ} :
    q ∈ primeIndexWindow Y R ↔ q.Prime ∧ Y < q ∧ q ≤ R := by
  classical
  simp only [primeIndexWindow, Finset.mem_filter, Nat.mem_primesLE]
  tauto

/-- The individual obstruction associated to `q`; primality of `q` is
imposed by the finite index window. -/
def PowerResidueObstruction (a : ℤ) (q p : ℕ) : Prop :=
  p.Prime ∧ q ∣ p - 1 ∧ (a : ZMod p) ^ ((p - 1) / q) = 1

/-- Count the actual power-residue obstructions in `(x,2*x]`. -/
noncomputable def powerResidueCount (a : ℤ) (q : ℕ) (x : ℝ) : ℝ :=
  (filteredCard (ambientPrimes x) (PowerResidueObstruction a q) : ℝ)

theorem smallIndexObstruction_iff (a : ℤ) (Y R p : ℕ) :
    SmallIndexObstruction a Y R p ↔
      ∃ q ∈ primeIndexWindow Y R, PowerResidueObstruction a q p := by
  simp only [SmallIndexObstruction, mem_primeIndexWindow, PowerResidueObstruction]
  aesop

/-- An exact finite union bound. The exceptional primes are counted only
once on the left, even when several distinct `q` divide their index. -/
theorem smallIndex_filteredCard_le_sum (a : ℤ) (Y R : ℕ) (s : Finset ℕ) :
    filteredCard s (SmallIndexObstruction a Y R) ≤
      ∑ q ∈ primeIndexWindow Y R, filteredCard s (PowerResidueObstruction a q) := by
  classical
  have heq : s.filter (SmallIndexObstruction a Y R) =
      (primeIndexWindow Y R).biUnion (fun q => s.filter (PowerResidueObstruction a q)) := by
    ext p
    simp only [Finset.mem_filter, Finset.mem_biUnion,
      smallIndexObstruction_iff]
    aesop
  simpa only [filteredCard, heq] using
    (Finset.card_biUnion_le (s := primeIndexWindow Y R)
      (t := fun q => s.filter (PowerResidueObstruction a q)))

/-- The same union bound with the manuscript's real cutoffs. -/
theorem smallIndexCount_le_sum (a : ℤ) (ε Y x : ℝ) :
    smallIndexCount a ε Y x ≤
      ∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊, powerResidueCount a q x := by
  have h := smallIndex_filteredCard_le_sum a ⌊Y⌋₊ ⌊x ^ ε⌋₊ (ambientPrimes x)
  simp only [smallIndexCount, powerResidueCount]
  exact_mod_cast h

/-- Rounding introduces no loss: the integral prime window is precisely
the range `Y < q ≤ x ^ ε`, as far as its members are concerned. -/
theorem primeIndexWindow_real_bounds {ε Y x : ℝ} {q : ℕ}
    (hx : 0 ≤ x) (hq : q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊) :
    q.Prime ∧ Y < (q : ℝ) ∧ (q : ℝ) ≤ x ^ ε := by
  obtain ⟨hprime, hlower, hupper⟩ := mem_primeIndexWindow.mp hq
  exact ⟨hprime, Nat.lt_of_floor_lt hlower,
    (Nat.cast_le.mpr hupper).trans (Nat.floor_le (Real.rpow_nonneg hx ε))⟩

/-- Pointwise summation, retaining the logarithm in the error denominator.
Chebyshev's estimate for the logarithmic prime sum is proved in mathlib and
is supplied through `sum_splitting_bounds_for_primes`. -/
theorem smallIndexCount_le_of_individual_bounds
    (a : ℤ) {ε Y x δ m E A H : ℝ}
    (hx : 1 < x) (hm : 0 ≤ m) (hE : 0 ≤ E) (hA : 0 ≤ A)
    (hindividual : ∀ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊,
      powerResidueCount a q x ≤
        (m * (x / Real.log x)) * (1 / ((q : ℝ) * ((q : ℝ) - 1))) +
          (E * x ^ (1 - δ) / Real.log x) * (2 * Real.log (q : ℝ) + A))
    (htail : ∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊,
      1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤ H / (Y * Real.log Y)) :
    smallIndexCount a ε Y x ≤
      ((m * H) / (Y * Real.log Y)) * (x / Real.log x) +
        (E * (2 * Real.log 4 + A)) * x ^ (1 - δ + ε) / Real.log x := by
  have hx0 : 0 < x := by linarith
  have hlog : 0 < Real.log x := Real.log_pos hx
  have hsum := sum_splitting_bounds_for_primes
    (primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊)
    (fun q => powerResidueCount a q x)
    (fun q => 1 / ((q : ℝ) * ((q : ℝ) - 1)))
    (M := m * (x / Real.log x)) (E := E * x ^ (1 - δ) / Real.log x)
    (H := H / (Y * Real.log Y)) (A := A) (T := x ^ ε)
    (by positivity) (by positivity) hA (Real.rpow_nonneg hx0.le ε)
    (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).1)
    (fun q hq => (primeIndexWindow_real_bounds hx0.le hq).2.2)
    hindividual htail
  have hpow := splitting_error_power_identity hx0 δ ε (2 * Real.log 4 + A)
  calc
    smallIndexCount a ε Y x ≤
        ∑ q ∈ primeIndexWindow ⌊Y⌋₊ ⌊x ^ ε⌋₊, powerResidueCount a q x :=
      smallIndexCount_le_sum a ε Y x
    _ ≤ (m * (x / Real.log x)) * (H / (Y * Real.log Y)) +
        (E * x ^ (1 - δ) / Real.log x) * ((2 * Real.log 4 + A) * x ^ ε) := hsum
    _ = ((m * H) / (Y * Real.log Y)) * (x / Real.log x) +
        (E * (2 * Real.log 4 + A)) * x ^ (1 - δ + ε) / Real.log x := by
      calc
        _ = ((m * H) / (Y * Real.log Y)) * (x / Real.log x) +
            E * ((x ^ (1 - δ) / Real.log x) * ((2 * Real.log 4 + A) * x ^ ε)) := by ring
        _ = _ := by rw [hpow]; ring

/-- The uniform individual estimate needed from the Kummer splitting
argument. This is a definition of an input, not an asserted theorem.
Its constants precede `N`, and the threshold is simultaneous in `q`. -/
def IndividualPowerResidueEstimate (Q : ℝ → Prop) (a : ℤ)
    (m E A Y₀ : ℝ) : Prop :=
  ∀ N : ℝ, 2 ≤ N → Q N → ∀ᶠ x : ℝ in atTop,
    ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
      powerResidueCount a q x ≤
        (m * (x / Real.log x)) * (1 / ((q : ℝ) * ((q : ℝ) - 1))) +
          (E * x ^ (1 - 1 / N) / Real.log x) * (2 * Real.log (q : ℝ) + A)

/-- The classical reciprocal-prime tail in a finite form. Quantification
over arbitrary finite prime sets avoids hidden convergence conventions. -/
def ReciprocalPrimeTail (H : ℝ) : Prop :=
  ∀ Y : ℝ, 1 < Y → ∀ s : Finset ℕ,
    (∀ q ∈ s, q.Prime) → (∀ q ∈ s, Y < (q : ℝ)) →
      ∑ q ∈ s, 1 / ((q : ℝ) * ((q : ℝ) - 1)) ≤ H / (Y * Real.log Y)

/-- The actual small-index estimate follows from two separately exposed
inputs: the uniform individual Kummer estimate and the classical reciprocal
prime tail. No small-index bound is assumed by this theorem. -/
theorem smallIndexEstimate_of_individual_and_tail
    (Q : ℝ → Prop) (a : ℤ) (m E A H Y₀ : ℝ)
    (hm : 0 ≤ m) (hE : 0 ≤ E) (hA : 0 ≤ A)
    (hindividual : IndividualPowerResidueEstimate Q a m E A Y₀)
    (htail : ReciprocalPrimeTail H) :
    SmallIndexEstimate Q a (m * H) Y₀ := by
  intro N hN hQ ε Y _hε _hεδ hY hY1
  refine ⟨E * (2 * Real.log 4 + A), ?_⟩
  filter_upwards [hindividual N hN hQ, eventually_gt_atTop (1 : ℝ)] with x hi hx
  have hx0 : 0 ≤ x := by linarith
  apply smallIndexCount_le_of_individual_bounds a hx hm hE hA
  · intro q hq
    have hb := primeIndexWindow_real_bounds hx0 hq
    exact hi q hb.1 (hY.trans_lt hb.2.1)
  · exact htail Y hY1 _
      (fun q hq => (primeIndexWindow_real_bounds hx0 hq).1)
      (fun q hq => (primeIndexWindow_real_bounds hx0 hq).2.1)

end Artin
