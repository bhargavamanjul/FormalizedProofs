module

public import Artin.MarkedSource
public import Artin.PrimeMainMass
public import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
public import Mathlib.Analysis.Calculus.ContDiff.RCLike

/-!
# One fixed positive smooth weight

The smooth weight is constructed from mathlib's real bump function.  Its
centre and radii are fixed numerical constants, independent of the arithmetic
parameters and the marked prime groups.  The same real function supplies the
positive prime main mass and, after the usual complex inclusion, the smooth
weight required by marked replacement.
-/

@[expose] public section

namespace Artin.PositiveBump

/-- A bump centred at `3/2`, equal to one on radius `1/8`, with support of
radius `1/4`. -/
noncomputable def bump : ContDiffBump (3 / 2 : ℝ) where
  rIn := 1 / 8
  rOut := 1 / 4
  rIn_pos := by norm_num
  rIn_lt_rOut := by norm_num

/-- The actual fixed real weight used in the analytic argument. -/
noncomputable def weight : ℝ → ℝ := bump

theorem weight_contDiff :
    ContDiff ℝ (↑(⊤ : ℕ∞) : WithTop ℕ∞) weight :=
  bump.contDiff

theorem weight_continuous : Continuous weight := bump.continuous

theorem weight_hasCompactSupport : HasCompactSupport weight := bump.hasCompactSupport

theorem weight_nonneg (y : ℝ) : 0 ≤ weight y := bump.nonneg

theorem weight_le_one (y : ℝ) : weight y ≤ 1 := bump.le_one

theorem weight_abs_le_one (y : ℝ) : |weight y| ≤ 1 := by
  rw [abs_of_nonneg (weight_nonneg y)]
  exact weight_le_one y

theorem weight_support : Function.support weight ⊆ Set.Ioo (1 : ℝ) 2 := by
  intro y hy
  change y ∈ Function.support (bump : ℝ → ℝ) at hy
  rw [bump.support_eq] at hy
  change dist y (3 / 2 : ℝ) < 1 / 4 at hy
  rw [Real.dist_eq, abs_lt] at hy
  exact ⟨by linarith [hy.1], by linarith [hy.2]⟩

theorem weight_eq_zero_of_not_mem_Icc {y : ℝ} (hy : y ∉ Set.Icc (1 : ℝ) 2) :
    weight y = 0 := by
  by_contra hn
  exact hy (Set.Ioo_subset_Icc_self (weight_support hn))

theorem weight_eq_one {y : ℝ} (hy : y ∈ Set.Icc (11 / 8 : ℝ) (13 / 8)) :
    weight y = 1 := by
  apply bump.one_of_mem_closedBall
  change dist y (3 / 2 : ℝ) ≤ 1 / 8
  rw [Real.dist_eq, abs_le]
  constructor <;> linarith [hy.1, hy.2]

theorem weightMass_pos : 0 < Artin.PrimeMainMass.weightMass weight := by
  apply Artin.PrimeMainMass.weightMass_pos weight weight_continuous weight_nonneg
    (α := 11 / 8) (β := 13 / 8) (ψ₀ := 1)
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · intro y hy
    rw [weight_eq_one hy]

theorem weightMass_le_one : Artin.PrimeMainMass.weightMass weight ≤ 1 :=
  Artin.PrimeMainMass.weightMass_le weight weight_continuous (fun y _ => weight_le_one y)

theorem weight_lipschitz : ∃ K : NNReal, LipschitzWith K weight := by
  exact ContDiff.lipschitzWith_of_hasCompactSupport weight_hasCompactSupport
    weight_contDiff (by simp)

theorem weight_abs_sub_le : ∃ K : ℝ, 0 ≤ K ∧
    ∀ u v : ℝ, |weight u - weight v| ≤ K * |u - v| := by
  obtain ⟨K, hK⟩ := weight_lipschitz
  refine ⟨K, K.coe_nonneg, ?_⟩
  intro u v
  simpa only [Real.dist_eq] using hK.dist_le_mul u v

/-- The complex inclusion is exactly the smooth compact weight required by
the accepted marked-replacement source. -/
theorem weight_marked_source :
    Artin.MarkedSource.SmoothCompactWeight (fun y => (weight y : ℂ)) := by
  refine ⟨Complex.ofRealCLM.contDiff.comp weight_contDiff, ?_, ?_⟩
  · exact weight_hasCompactSupport.comp_left (g := fun y : ℝ => (y : ℂ)) (by simp)
  · intro y hy
    apply weight_support
    change (weight y : ℂ) ≠ 0 at hy
    change weight y ≠ 0
    exact fun hz => hy (by simp [hz])

/-- A single concrete weight simultaneously satisfies all analytic interfaces;
there is no additional smooth-weight existence hypothesis. -/
theorem exists_fixed_weight : ∃ Ψ : ℝ → ℝ, ∃ K : ℝ, 0 ≤ K ∧
    Continuous Ψ ∧
    (∀ y, 0 ≤ Ψ y) ∧
    (∀ y, |Ψ y| ≤ 1) ∧
    (∀ y, y ∉ Set.Icc (1 : ℝ) 2 → Ψ y = 0) ∧
    (∀ u v, |Ψ u - Ψ v| ≤ K * |u - v|) ∧
    0 < Artin.PrimeMainMass.weightMass Ψ ∧
    Artin.MarkedSource.SmoothCompactWeight (fun y => (Ψ y : ℂ)) := by
  obtain ⟨K, hK, hLip⟩ := weight_abs_sub_le
  exact ⟨weight, K, hK, weight_continuous, weight_nonneg, weight_abs_le_one,
    fun _ hy => weight_eq_zero_of_not_mem_Icc hy, hLip,
    weightMass_pos, weight_marked_source⟩

end Artin.PositiveBump
