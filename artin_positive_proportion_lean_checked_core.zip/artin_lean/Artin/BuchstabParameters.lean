module

public import Artin.BuchstabPartition
public import Artin.CandidateSieve
public import Mathlib.NumberTheory.Harmonic.EulerMascheroni

/-!
# Fixed parameters for the actual Buchstab density

The only new source input here is the classical rapid convergence estimate
for the exact simplex density.  The sieve cutoff, local-product tolerance,
and finite partition are then chosen before any marking or cofactor data.
-/

@[expose] public section

namespace Artin.BuchstabParameters

/-- Classical rapid convergence of the actual Buchstab density.  The
constants concern only the classical density, with no arithmetic weights or
marking parameters in the assertion. -/
def ClassicalBuchstabRapid : Prop :=
  ∃ C_d c_d b_D : ℝ, 0 < C_d ∧ 0 < c_d ∧ 0 < b_D ∧
    ∀ b : ℝ, 0 < b → b < b_D →
      MarkedSource.density b 1 ≤
        Real.exp (-Real.eulerMascheroniConstant) / b *
          (1 + C_d * Real.exp (-c_d / b))

/-- Choose the cutoff and local tolerance for a width already fixed by the
two-variable sieve.  The resulting partition is a partition of the actual
Buchstab density.  Every choice precedes the later parameters `ε`, `Y`, and
the number of marks. -/
theorem exists_fixed_parameters
    (classicalFacts : BuchstabPartition.ClassicalBuchstabFacts)
    (rapid : ClassicalBuchstabRapid)
    (C_s : ℝ) {b₀ κ : ℝ} (hb₀ : 0 < b₀)
    (hκ : 0 < κ) (hκsmall : κ < 1 / 100) :
    ∃ b τ : ℝ,
      0 < b ∧ b < b₀ ∧ b < 1 / 100 ∧ b < 1 / 2 - κ ∧
      0 < τ ∧ τ < 1 / 100 ∧
      Nonempty (BuchstabPartition.DensityPartition b (1 / 2 - κ) (1 / 20)) ∧
      (3 : ℝ) / 4 ≤
        Real.exp (-Real.eulerMascheroniConstant) / b *
          (1 - C_s * Real.exp (-(1 / 20) / b)) -
        Real.exp (20 * τ) * (MarkedSource.density b 1 - 1 + 1 / 20) := by
  obtain ⟨C_d, c_d, b_D, _, hc_d, hb_D, hD⟩ := rapid
  have hwidth : 0 < (1 : ℝ) / 2 - κ := by linarith
  obtain ⟨b, hb, hbsmall, herror⟩ :=
    exists_initial_sieve_cutoff
      (Real.exp (-Real.eulerMascheroniConstant)) C_s C_d
      (by norm_num : (0 : ℝ) < 1 / 20) hc_d
      (lt_min hb₀ (lt_min hb_D
        (lt_min (by norm_num : (0 : ℝ) < 1 / 100) hwidth)))
  have hbb₀ : b < b₀ := hbsmall.trans_le (min_le_left _ _)
  have hbrest : b < min b_D (min (1 / 100) (1 / 2 - κ)) :=
    hbsmall.trans_le (min_le_right _ _)
  have hbb_D : b < b_D := hbrest.trans_le (min_le_left _ _)
  have hbrest' : b < min (1 / 100) (1 / 2 - κ) :=
    hbrest.trans_le (min_le_right _ _)
  have hb100 : b < 1 / 100 := hbrest'.trans_le (min_le_left _ _)
  have hbwidth : b < 1 / 2 - κ := hbrest'.trans_le (min_le_right _ _)
  obtain ⟨τ', hτ', hτ'small, hlocal⟩ :=
    exists_local_product_tolerance (MarkedSource.density b 1)
      (by norm_num : (0 : ℝ) < 1 / 50)
  let τ := τ' / 2
  have hτ : 0 < τ := by dsimp [τ]; positivity
  have hτsmall : τ < 1 / 100 := by dsimp [τ]; linarith
  have hexp : Real.exp (20 * τ) = Real.exp (10 * τ') := by
    congr 1
    dsimp [τ]
    ring
  refine ⟨b, τ, hb, hbb₀, hb100, hbwidth, hτ, hτsmall, ?_, ?_⟩
  · exact BuchstabPartition.exists_densityPartition classicalFacts hb hbwidth
      (by linarith) (by norm_num)
  · rw [hexp]
    exact buchstab_subtraction_margin (hD b hb hbb_D) herror.le
      (Real.one_le_exp (by positivity)) hlocal.le

end Artin.BuchstabParameters
