module

public import Artin.ConditionedSieve
public import Artin.ManuscriptCover
public import Artin.OrderExceptions

/-! # Original conditioned weights and their discarded-cofactor tail -/

@[expose] public section
open scoped BigOperators Topology
open Filter

namespace Artin.ConditionedSupport

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate MarkedBandTail
  ManuscriptMass ManuscriptTail ManuscriptCover BuchstabSieve ConditionedSieve

/-- The original integer weight with a prime-divisor condition and the
finite small-prime exclusions. No enlarged-cofactor truncation is imposed. -/
noncomputable def conditionedBaseMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (N S : Finset ℕ) : ℝ :=
  ∑ n ∈ N, siftedMass ((Finset.Icc 2 ⌊2 * x⌋₊).filter (fun d => n ∣ d))
    (integerWeight I a c M u ε Y τ x) (fun p d => p ∣ d) S

/-- The literal rough-integer conditioned sum appearing in the manuscript. -/
noncomputable def roughConditionedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (N : Finset ℕ) : ℝ := by
  classical
  exact ∑ n ∈ N, ∑ d ∈ (Finset.Icc 2 ⌊2 * x⌋₊).filter
    (fun d => n ∣ d ∧ MarkedCriterion.IsRough (MarkedSource.W x) d),
      integerWeight I a c M u ε Y τ x d

noncomputable def conditionedMask (n : ℕ) (S : Finset ℕ) (Ψ : ℕ → ℝ) (d : ℕ) : ℝ := by
  classical
  exact if n ∣ d ∧ ∀ p ∈ S, ¬ p ∣ d then Ψ d else 0

/-- Distinct prime divisors in a bin above `x^b` have bounded multiplicity
`2/b` on the product support. This loses no power of the logarithm. -/
theorem bin_prime_divisor_card_le (N : Finset ℕ) {b x : ℝ} {d : ℕ}
    (hx : 2 ≤ x) (hb : 0 < b) (hd : 0 < d) (hsize : (d : ℝ) ≤ 2 * x)
    (hN : ∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ)) :
    ((N.filter (fun n => n ∣ d)).card : ℝ) ≤ 2 / b := by
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos (by linarith)
  have hh := Artin.prime_divisors_card_mul_log_le
    (S := N.filter (fun n => n ∣ d)) hd (Real.rpow_pos_of_pos hx0 b)
    (fun p hp => ⟨(hN p (Finset.mem_filter.mp hp).1).1,
      (Finset.mem_filter.mp hp).2, (hN p (Finset.mem_filter.mp hp).1).2⟩)
  rw [Real.log_rpow hx0] at hh
  have hlogd : Real.log (d : ℝ) ≤ 2 * Real.log x := by
    calc
      _ ≤ Real.log (2 * x) := Real.log_le_log (by exact_mod_cast hd) hsize
      _ = Real.log 2 + Real.log x := Real.log_mul (by norm_num) hx0.ne'
      _ ≤ _ := by linarith [Real.log_le_log (by norm_num : (0 : ℝ) < 2) hx]
  apply (le_div_iff₀ hb).mpr
  apply (mul_le_mul_iff_of_pos_right hL).mp
  nlinarith only [hh, hlogd]

theorem conditioned_integer_identity {ι : Type*} (D S : Finset ℕ) (n M u c : ℕ)
    (Ψ : ℕ → ℝ) (I : Finset ι) (groups : ι → Finset ℕ) (V : ι → ℝ)
    (P U : Finset ℕ) (Qmin : ℝ) :
    siftedMass (D.filter (fun d => n ∣ d))
      (arithmeticWeight M u Ψ I groups V P c U Qmin) (fun p d => p ∣ d) S =
      ∑ d ∈ D, arithmeticWeight M u (conditionedMask n S Ψ) I groups V P c U Qmin d := by
  classical
  unfold siftedMass
  simp only [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro d hd
  unfold arithmeticWeight conditionedMask
  split_ifs <;> simp_all

theorem conditioned_progression_identity (Qs S : Finset ℕ) (n c M u r : ℕ) (Ψ : ℕ → ℝ) :
    primeProgressionSum c M u Qs (conditionedMask n S Ψ) r =
      siftedMass (Qs.filter (fun Q => n ∣ c * r * Q + 1))
        (InitialSieve.arrayWeight c M u Ψ r) (fun p Q => p ∣ c * r * Q + 1) S := by
  classical
  unfold primeProgressionSum siftedMass
  simp only [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro Q hQ
  unfold conditionedMask InitialSieve.arrayWeight
  split_ifs <;> simp_all

/-- Exact cofactor expansion for the original conditioned integer weight. -/
theorem conditionedBaseMass_eq {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z : ℝ) (N S : Finset ℕ) (hx : 2 ≤ x) (hc : 0 < c)
    (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z) :
    conditionedBaseMass I a c M u ε Y τ x N S =
      ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x),
        marking I a x r * ∑ n ∈ N,
          siftedMass ((WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))).filter
            (fun Q => n ∣ c * r * Q + 1))
            (InitialSieve.arrayWeight c M u (smoothWeight x) r)
            (fun p Q => p ∣ c * r * Q + 1) S := by
  classical
  unfold conditionedBaseMass
  have hn : ∀ n : ℕ,
      siftedMass ((Finset.Icc 2 ⌊2 * x⌋₊).filter (fun d => n ∣ d))
        (integerWeight I a c M u ε Y τ x) (fun p d => p ∣ d) S =
      ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x),
        marking I a x r *
          siftedMass ((WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))).filter
            (fun Q => n ∣ c * r * Q + 1))
            (InitialSieve.arrayWeight c M u (smoothWeight x) r)
            (fun p Q => p ∣ c * r * Q + 1) S := by
    intro n
    unfold integerWeight
    rw [conditioned_integer_identity]
    have hmasked : ∀ d : ℕ, conditionedMask n S (smoothWeight x) d ≠ 0 →
        2 ≤ d ∧ (d : ℝ) ≤ 2 * x := by
      intro d hd
      apply smoothWeight_support hx d
      intro hz
      exact hd (by simp [conditionedMask, hz])
    rw [WeightSupport.ambient_weight_sum_eq_real M u c (2 * x)
      (conditionedMask n S (smoothWeight x)) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x)
      (by positivity) hc hcut (fun p hp => ⟨markedPrimes_prime I a x p hp, hP p hp⟩)
      (fun i hi p hp => Finset.mem_biUnion.mpr ⟨i, hi, hp⟩) hcP
      (MarkedScaleSupport.unmarked_positive_avoid I a ε Y τ x) hU hmasked]
    apply Finset.sum_congr rfl
    intro r hr
    rw [conditioned_progression_identity]
    rfl
  simp_rw [hn]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro r hr
  rw [Finset.mul_sum]

/-- Dropping the small-prime exclusions costs at most the actual number of
prime divisors in the conditioning interval. -/
theorem conditioned_array_le (Qs N S : Finset ℕ) (c M u r : ℕ)
    {x b : ℝ} (hx : 2 ≤ x) (hb : 0 < b)
    (hN : ∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ)) :
    (∑ n ∈ N, siftedMass (Qs.filter (fun Q => n ∣ c * r * Q + 1))
      (InitialSieve.arrayWeight c M u (smoothWeight x) r)
      (fun p Q => p ∣ c * r * Q + 1) S) ≤
      (2 / b) * primeProgressionSum c M u Qs (smoothWeight x) r := by
  classical
  let f := InitialSieve.arrayWeight c M u (smoothWeight x) r
  have hf : ∀ Q, 0 ≤ f Q := by
    intro Q
    unfold f InitialSieve.arrayWeight
    split_ifs
    · exact (smoothWeight_bounds x _).1
    · exact le_rfl
  calc
    _ ≤ ∑ n ∈ N, ∑ Q ∈ Qs.filter (fun Q => n ∣ c * r * Q + 1), f Q := by
      apply Finset.sum_le_sum
      intro n hn
      unfold siftedMass
      rw [Finset.sum_filter]
      apply Finset.sum_le_sum
      intro Q hQ
      split_ifs
      · exact le_rfl
      · exact hf Q
    _ = ∑ Q ∈ Qs, ((N.filter (fun n => n ∣ c * r * Q + 1)).card : ℝ) * f Q := by
      simp only [Finset.sum_filter]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro Q hQ
      rw [← Finset.sum_filter]
      simp
    _ ≤ ∑ Q ∈ Qs, (2 / b) * f Q := by
      apply Finset.sum_le_sum
      intro Q hQ
      by_cases hz : f Q = 0
      · simp [hz]
      · have hΨ : smoothWeight x (c * r * Q + 1) ≠ 0 := by
          intro hh
          exact hz (by simp [f, InitialSieve.arrayWeight, hh])
        have hs := smoothWeight_support hx _ hΨ
        exact mul_le_mul_of_nonneg_right (bin_prime_divisor_card_le N hx hb (by omega) hs.2 hN) (hf Q)
    _ = _ := by rw [← Finset.mul_sum]; rfl

/-- The original conditioned mass differs from the retained-cofactor mass
by at most the multiplicity `2/b` times the actual discarded mass. -/
theorem conditionedBaseMass_le_retained {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x Z b : ℝ) (N S : Finset ℕ) (hx : 2 ≤ x) (hc : 0 < c)
    (hε : ε ≤ 1) (hb : 0 < b) (hcut : Z ≤ x ^ (9 / 10 : ℝ))
    (hP : ∀ p ∈ markedPrimes I a x, (p : ℝ) ≤ Z)
    (hcP : ∀ p ∈ markedPrimes I a x, ¬ p ∣ c)
    (hU : ∀ r ∈ unmarkedCofactors I a ε Y τ x,
      ∀ p : ℕ, p.Prime → p ∣ r → (p : ℝ) ≤ Z)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x)
    (hN : ∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ)) :
    conditionedBaseMass I a c M u ε Y τ x N S ≤
      retainedConditionedMass I a c M u ε Y τ x N S +
        (2 / b) * discardedMass I a c M u ε Y τ x := by
  classical
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  let F := fun r : ℕ => ∑ n ∈ N,
    siftedMass (Qs.filter (fun Q => n ∣ c * r * Q + 1))
      (InitialSieve.arrayWeight c M u (smoothWeight x) r)
      (fun p Q => p ∣ c * r * Q + 1) S
  let R := boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε)
  let T := boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (2 * x)
  have hXT : x ^ ε ≤ 2 * x := by
    calc
      x ^ ε ≤ x ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith) hε
      _ = x := Real.rpow_one x
      _ ≤ 2 * x := by linarith
  have hRT : R ⊆ T := FullMassComparison.boundedCofactors_mono _ _ hXT
  have heq : conditionedBaseMass I a c M u ε Y τ x N S =
      retainedConditionedMass I a c M u ε Y τ x N S +
        ∑ r ∈ T \ R, marking I a x r * F r := by
    rw [conditionedBaseMass_eq I a c M u ε Y τ x Z N S hx hc hcut hP hcP hU]
    change (∑ r ∈ T, marking I a x r * F r) =
      (∑ r ∈ R, marking I a x r * F r) + ∑ r ∈ T \ R, marking I a x r * F r
    exact (Finset.sum_sdiff hRT (f := fun r => marking I a x r * F r)).symm.trans (add_comm _ _)
  have htail : (∑ r ∈ T \ R, marking I a x r * F r) ≤
      (2 / b) * discardedMass I a c M u ε Y τ x := by
    unfold discardedMass discardedCofactors
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro r hr
    calc
      _ ≤ marking I a x r * ((2 / b) * primeProgressionSum c M u Qs (smoothWeight x) r) :=
        mul_le_mul_of_nonneg_left (conditioned_array_le Qs N S c M u r hx hb hN)
          (markingWeight_bounds I _ _ r hV).1
      _ = _ := by ring
  rw [heq]
  exact add_le_add le_rfl htail

/-- A `W`-rough integer avoids every sieving prime at most `W`. Thus the
literal conditioned sum is bounded by the finite-sieve version. -/
theorem roughConditionedMass_le_conditioned {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (N S : Finset ℕ)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x)
    (hS : ∀ p ∈ S, p.Prime ∧ (p : ℝ) ≤ MarkedSource.W x) :
    roughConditionedMass I a c M u ε Y τ x N ≤ conditionedBaseMass I a c M u ε Y τ x N S := by
  classical
  apply Finset.sum_le_sum
  intro n hn
  unfold siftedMass
  simp only [Finset.sum_filter]
  apply Finset.sum_le_sum
  intro d hd
  by_cases h : n ∣ d ∧ MarkedCriterion.IsRough (MarkedSource.W x) d
  · have havoid : ∀ p ∈ S, ¬ p ∣ d := by
      intro p hp hpd
      exact (not_lt_of_ge (hS p hp).2) (h.2 p (hS p hp).1 hpd)
    simp only [if_pos h, if_pos h.1]
    rw [if_pos havoid]
  · simp only [h, ite_false]
    split_ifs <;> first | exact integerWeight_nonneg I a c M u ε Y τ x hV d | exact le_rfl

/-- The exact support and multiplicity conditions hold eventually at the
actual scales, uniformly for every finite conditioning interval and sieve. -/
theorem eventually_conditionedBaseMass_le_retained {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax : ℝ) (hmin : 0 < amin) (hmax : amax < 1)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax)
    (hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, 0 < bandMass (a i) x)
    (c M u : ℕ) (hc : 0 < c) (ε Y τ b : ℝ) (hε : ε ≤ 1 / 100) (hb : 0 < b) :
    ∀ᶠ x : ℝ in atTop, ∀ N S : Finset ℕ,
      (∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ)) →
      conditionedBaseMass I a c M u ε Y τ x N S ≤
        retainedConditionedMass I a c M u ε Y τ x N S +
          (2 / b) * discardedMass I a c M u ε Y τ x := by
  filter_upwards [MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax c (1 / 2)
      hmin hmax (by norm_num) ha,
    MarkedScaleSupport.eventual_marked_not_dvd I a amin amax hmin hmax ha c hc,
    hV, eventually_ge_atTop (2 : ℝ)] with x hP hcP hVx hx
  have hx1 : 1 ≤ x := by linarith
  intro N S hN
  exact conditionedBaseMass_le_retained I a c M u ε Y τ x (x ^ (1 / 2 : ℝ)) b N S hx hc
    (by linarith) hb (Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num))
    (fun p hp => (hP p hp).2.2) hcP
    (fun r hr p hp hpr => MarkedScaleSupport.unmarked_prime_divisor_le I a ε Y τ (1 / 2)
      hx1 (by linarith) hr hp hpr) hVx hN

/-- Removing the original large-cofactor contribution from a conditioned
rough sum costs arbitrarily many powers of the logarithm, uniformly over
the entire varying conditioning interval and the chosen small-prime sieve. -/
theorem actual_roughConditionedMass_le_retained
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (amin amax B v₀ : ℝ) (hmin : 0 < amin) (hmax : amax < 1) (hv₀ : 0 < v₀)
    (ha : ∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop,
      ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (A b : ℝ) (hb : 0 < b) (ε Y τ : ℝ)
    (hε : 0 < ε) (hεmax : ε ≤ 1 / 100) (hY : (M₀ : ℝ) ≤ Y) :
    ∀ᶠ x : ℝ in atTop, ∀ N S : Finset ℕ,
      (∀ n ∈ N, n.Prime ∧ x ^ b ≤ (n : ℝ)) →
      (∀ p ∈ S, p.Prime ∧ (p : ℝ) ≤ MarkedSource.W x) →
      roughConditionedMass I a c (c * M₀) (c * v + 1) ε Y τ x N ≤
        retainedConditionedMass I a c (c * M₀) (c * v + 1) ε Y τ x N S +
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A := by
  have hV : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I, 0 < bandMass (a i) x :=
    hclassical.mono (fun x hx i hi => hv₀.trans_le (hx i hi).1)
  filter_upwards [eventually_conditionedBaseMass_le_retained I a amin amax hmin hmax ha hV
      c (c * M₀) (c * v + 1) (by omega) ε Y τ b hεmax hb,
    actual_discardedMass_le_base_over_log_power hPNT hc hu hv I a amin amax B v₀
      hmin hmax hv₀ ha hinj hclassical A (b / 2) (by positivity) ε hε hεmax Y hY τ,
    hV] with x hfull htail hVx
  intro N S hN hS
  have hmul : (2 / b) * discardedMass I a c (c * M₀) (c * v + 1) ε Y τ x ≤
      baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A := by
    have hh := mul_le_mul_of_nonneg_left htail (show 0 ≤ 2 / b by positivity)
    convert hh using 1 <;> field_simp
  exact (roughConditionedMass_le_conditioned I a c (c * M₀) (c * v + 1) ε Y τ x N S hVx hS).trans
    ((hfull N S hN).trans (add_le_add le_rfl hmul))

end Artin.ConditionedSupport
