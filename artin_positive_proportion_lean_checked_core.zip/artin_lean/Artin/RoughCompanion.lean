module

public import Artin.SemiprimeReplacement

/-!
# The companion coefficients in the two semiprime replacements

The only analytic input here is the classical lower Mertens bound for the
actual finite Euler product.  It implies, uniformly over the whole factor
window, that the replaced coefficient is bounded by one.  Both original and
replaced coefficients have the precise rough support required by MR.
-/

@[expose] public section

open Filter

namespace Artin.RoughCompanion

/-- A weak classical Mertens lower bound, with the actual Euler product. -/
def ClassicalMertensLower : Prop :=
  ∃ c : ℝ, 0 < c ∧ ∀ᶠ y : ℝ in atTop, c / Real.log y ≤ MarkedSource.eulerV y

theorem eulerV_pos (y : ℝ) : 0 < MarkedSource.eulerV y := by
  unfold MarkedSource.eulerV
  apply Finset.prod_pos
  intro p hp
  have hpprime := (Nat.mem_primesLE.mp hp).2
  have hp1 : (1 : ℝ) < p := by exact_mod_cast hpprime.one_lt
  have hi : (p : ℝ)⁻¹ < 1 := inv_lt_one_of_one_lt₀ hp1
  linarith

/-- The real version of the source's rough indicator. -/
noncomputable def realRoughIndicator (y : ℝ) (n : ℕ) : ℝ := by
  classical
  exact if MarkedCriterion.IsRough y n then 1 else 0

/-- The actual prime indicator, used as the first companion. -/
noncomputable def primeIndicator (n : ℕ) : ℝ := if n.Prime then 1 else 0

/-- The actual coefficient after replacing one prime factor. -/
noncomputable def primeModel (x : ℝ) (n : ℕ) : ℝ :=
  SemiprimeReplacement.roughPrimeModel (realRoughIndicator (MarkedSource.W x))
    (MarkedSource.eulerV (MarkedSource.W x)) n

theorem realRoughIndicator_nonneg (y : ℝ) (n : ℕ) : 0 ≤ realRoughIndicator y n := by
  classical
  unfold realRoughIndicator
  split <;> norm_num

theorem realRoughIndicator_le_one (y : ℝ) (n : ℕ) : realRoughIndicator y n ≤ 1 := by
  classical
  unfold realRoughIndicator
  split <;> norm_num

theorem realRoughIndicator_cast (y : ℝ) (n : ℕ) :
    (realRoughIndicator y n : ℂ) = MarkedCriterion.roughIndicator y n := by
  classical
  simp only [realRoughIndicator, MarkedCriterion.roughIndicator]
  split <;> norm_num

theorem primeModel_rough_support {x : ℝ} {n : ℕ} (hn : primeModel x n ≠ 0) :
    MarkedCriterion.IsRough (MarkedSource.W x) n := by
  classical
  by_contra h
  simp [primeModel, SemiprimeReplacement.roughPrimeModel, realRoughIndicator, h] at hn

theorem W_tendsto : Tendsto MarkedSource.W atTop atTop :=
  Real.tendsto_exp_atTop.comp
    ((tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 6 / 25)).comp
      Real.tendsto_log_atTop)

/-- Mertens supplies a common onset for every natural factor above a fixed
positive power of `x`; this onset is independent of the dyad and the marks. -/
theorem eventually_denominator_ge_one (hM : ClassicalMertensLower)
    {δ : ℝ} (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop, ∀ n : ℕ, x ^ δ ≤ (n : ℝ) →
      1 ≤ MarkedSource.eulerV (MarkedSource.W x) * Real.log n := by
  obtain ⟨c, hc, hM⟩ := hM
  have hlim := (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 19 / 25)).comp
    Real.tendsto_log_atTop
  have he : ∀ᶠ x : ℝ in atTop, (Real.log x) ^ (-(19 / 25 : ℝ)) < c * δ :=
    (tendsto_order.1 hlim).2 _ (mul_pos hc hδ)
  filter_upwards [W_tendsto.eventually hM, he, eventually_gt_atTop (1 : ℝ)]
    with x hMx hex hx n hn
  have hL : 0 < Real.log x := Real.log_pos hx
  have hx0 : 0 < x := by linarith
  have hp : 0 < (Real.log x) ^ (6 / 25 : ℝ) := Real.rpow_pos_of_pos hL _
  have hn0 : (0 : ℝ) < n := (Real.rpow_pos_of_pos hx0 δ).trans_le hn
  have hnlog : δ * Real.log x ≤ Real.log n := by
    have h := Real.log_le_log (Real.rpow_pos_of_pos hx0 δ) hn
    rw [Real.log_rpow hx0] at h
    nlinarith
  have hratio : (Real.log x) ^ (6 / 25 : ℝ) / Real.log x < c * δ := by
    calc
      (Real.log x) ^ (6 / 25 : ℝ) / Real.log x =
          (Real.log x) ^ ((6 / 25 : ℝ) - 1) := by rw [Real.rpow_sub hL, Real.rpow_one]
      _ < c * δ := by norm_num at hex ⊢; exact hex
  have hpow : (Real.log x) ^ (6 / 25 : ℝ) ≤ c * (δ * Real.log x) := by
    have h := (div_lt_iff₀ hL).mp hratio
    nlinarith
  have hprod : 1 ≤ c / (Real.log x) ^ (6 / 25 : ℝ) * (δ * Real.log x) := by
    rw [div_mul_eq_mul_div, le_div_iff₀ hp, one_mul]
    exact hpow
  have hMx' : c / (Real.log x) ^ (6 / 25 : ℝ) ≤
      MarkedSource.eulerV (MarkedSource.W x) := by
    simpa only [MarkedSource.W, Real.log_exp] using hMx
  calc
    1 ≤ c / (Real.log x) ^ (6 / 25 : ℝ) * (δ * Real.log x) := hprod
    _ ≤ MarkedSource.eulerV (MarkedSource.W x) * Real.log n :=
      mul_le_mul hMx' hnlog (mul_nonneg hδ.le hL.le)
        ((div_pos hc hp).le.trans hMx')

theorem primeModel_mem_Icc {x : ℝ} {n : ℕ}
    (hden : 1 ≤ MarkedSource.eulerV (MarkedSource.W x) * Real.log n) :
    primeModel x n ∈ Set.Icc (0 : ℝ) 1 := by
  have hd : 0 < MarkedSource.eulerV (MarkedSource.W x) * Real.log n := by linarith
  constructor
  · exact div_nonneg (realRoughIndicator_nonneg _ _) hd.le
  · exact (div_le_one hd).mpr ((realRoughIndicator_le_one _ _).trans hden)

/-- The second, replaced companion satisfies the exact MR interface on
every finite subset of the factor window, with one threshold for all sets. -/
theorem eventually_primeModel_boundedRough (hM : ClassicalMertensLower)
    {δ : ℝ} (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop, ∀ t : Finset ℕ,
      (∀ n ∈ t, x ^ δ ≤ (n : ℝ)) →
      MarkedSource.BoundedRoughCoefficient x t (fun n => (primeModel x n : ℂ)) := by
  filter_upwards [eventually_denominator_ge_one hM hδ] with x hx t ht n hn
  have hm := primeModel_mem_Icc (hx n (ht n hn))
  constructor
  · simpa only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hm.1] using hm.2
  · intro hne
    apply primeModel_rough_support
    exact fun hz => hne (by simp [hz])

/-- The original prime companion also satisfies MR's exact support and norm
conditions uniformly over finite subsets of the same factor window. -/
theorem eventually_prime_boundedRough {δ : ℝ} (hδ : 0 < δ) :
    ∀ᶠ x : ℝ in atTop, ∀ t : Finset ℕ,
      (∀ n ∈ t, x ^ δ ≤ (n : ℝ)) →
      MarkedSource.BoundedRoughCoefficient x t (fun n => (primeIndicator n : ℂ)) := by
  have hcut := MarkedCriterion.rough_cutoff_le_power
    (κ := 6 / 25) (γ := δ / 2) (by norm_num) (by positivity : 0 < δ / 2)
  filter_upwards [hcut, eventually_gt_atTop (1 : ℝ)] with x hcutx hx t ht n hn
  constructor
  · simp only [primeIndicator]
    split <;> norm_num
  · intro hne p hp hpn
    have hnprime : n.Prime := by
      by_contra hh
      simp [primeIndicator, hh] at hne
    have hpn' : p = n := (Nat.prime_dvd_prime_iff_eq hp hnprime).mp hpn
    have hlt : x ^ (δ / 2) < (n : ℝ) :=
      (Real.rpow_lt_rpow_of_exponent_lt hx (by linarith : δ / 2 < δ)).trans_le (ht n hn)
    simpa only [hpn', MarkedSource.W] using hcutx.trans_lt hlt

/-- On the complete factor window, the exact source discrepancy is precisely
the prime indicator minus the replacement model.  This identifies the
coefficient to which MR is applied, rather than introducing a new error. -/
theorem discrepancy_eq_prime_sub_model {x : ℝ} {n : ℕ} (hx : 1 < x)
    (hlo : x ^ (46 / 100 : ℝ) ≤ (n : ℝ))
    (hhi : (n : ℝ) ≤ x ^ (54 / 100 : ℝ)) :
    MarkedSource.discrepancy (2 / 5) x n =
      ((primeIndicator n - primeModel x n : ℝ) : ℂ) := by
  classical
  have hx0 : 0 < x := by linarith
  have hn0 : 0 < n := by
    exact_mod_cast (Real.rpow_pos_of_pos hx0 (46 / 100 : ℝ)).trans_le hlo
  have hL : Real.log x ≠ 0 := (Real.log_pos hx).ne'
  have hdensity := SemiprimeReplacement.density_on_factor_support hx hhi hn0
  have hrough := SemiprimeReplacement.rough_iff_prime_on_factor_support hx hlo hhi
  have hfactor :
      (Real.log n / Real.log x)⁻¹ /
        (Real.log x * MarkedSource.eulerV (MarkedSource.W x)) =
      (MarkedSource.eulerV (MarkedSource.W x) * Real.log n)⁻¹ := by
    simp only [div_eq_mul_inv, mul_inv, inv_inv]
    calc
      (Real.log n)⁻¹ * Real.log x *
          ((Real.log x)⁻¹ * (MarkedSource.eulerV (MarkedSource.W x))⁻¹) =
          (Real.log x * (Real.log x)⁻¹) *
            ((MarkedSource.eulerV (MarkedSource.W x))⁻¹ * (Real.log n)⁻¹) := by ring
      _ = _ := by rw [mul_inv_cancel₀ hL, one_mul]
  unfold MarkedSource.discrepancy MarkedCriterion.roughDiscrepancy
  rw [hdensity]
  change MarkedCriterion.roughIndicator (x ^ (2 / 5 : ℝ)) n -
      ((Real.log n / Real.log x)⁻¹ /
        (Real.log x * MarkedSource.eulerV (MarkedSource.W x)) : ℝ) *
          MarkedCriterion.roughIndicator (MarkedSource.W x) n = _
  rw [hfactor, ← realRoughIndicator_cast (MarkedSource.W x) n]
  have hp : MarkedCriterion.roughIndicator (x ^ (2 / 5 : ℝ)) n =
      (primeIndicator n : ℂ) := by
    simp only [MarkedCriterion.roughIndicator, primeIndicator, hrough]
    split <;> norm_num
  rw [hp]
  simp only [primeModel, SemiprimeReplacement.roughPrimeModel,
    Complex.ofReal_sub, Complex.ofReal_div, Complex.ofReal_inv]
  ring

end Artin.RoughCompanion
