module

public import Artin.ManuscriptDistribution
public import Artin.ManuscriptTail
public import Artin.MarkedOmission
public import Artin.SiftedSupport
public import Artin.ManuscriptCover
public import Mathlib.NumberTheory.Harmonic.EulerMascheroni

/-!
# The initial block sieve for the actual manuscript cofactors

The source constants are chosen before the marking family.  The predecessor
array is the actual large-prime progression sum, and its intersection errors
are the concrete Bombieri--Vinogradov errors already proved for that family.
-/

@[expose] public section

open scoped BigOperators
open Filter

namespace Artin.InitialSieve

open ConcreteSelector CofactorRepresentation MarkedCofactorEstimate
  MarkedBandTail ManuscriptMass ManuscriptTail ManuscriptDistribution BuchstabSieve FullMassComparison

noncomputable def arrayWeight (c M u : ℕ) (Ψ : ℕ → ℝ) (r Q : ℕ) : ℝ :=
  if (c * r * Q + 1) % M = u then Ψ (c * r * Q + 1) else 0

/-- The exact sifted contribution of the retained enlarged cofactors. -/
noncomputable def retainedSiftedMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (S : Finset ℕ) : ℝ :=
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
    marking I a x r * siftedMass Qs (arrayWeight c M u (smoothWeight x) r)
      (fun p Q => p ∣ c * r * Q + 1) S

/-- Divisor intersections of the actual predecessor array are precisely the
prime sums used by the proved distribution theorem. -/
theorem divisorMass_eq_sievedPrimeSum (Qs : Finset ℕ) (c M u r d : ℕ) (Ψ : ℕ → ℝ) :
    divisorMass Qs (arrayWeight c M u Ψ r) (fun Q => c * r * Q + 1) d =
      PrimeProgressions.sievedPrimeSum c M u d Qs Ψ r := by
  classical
  unfold divisorMass PrimeProgressions.sievedPrimeSum
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro Q _
  simp only [arrayWeight]
  split_ifs <;> simp_all

/-- The actual weighted block remainder is bounded by the actual weighted
BV sum, without a divisor multiplicity or a supremum of the marking weight. -/
theorem weighted_blockRemainder_le {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x D : ℝ) (S moduli : Finset ℕ)
    (hV : ∀ i ∈ I, 0 < bandMass (a i) x)
    (hS : ∀ p ∈ S, p.Prime)
    (hmoduli : ∀ T ∈ remainderSubsets S D, (∏ p ∈ T, p) ∈ moduli) :
    (let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ));
      ∑ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
        marking I a x r * blockRemainder Qs (arrayWeight c M u (smoothWeight x) r)
          (fun p Q => p ∣ c * r * Q + 1) S (cofactorDensity M r)
          (primeProgressionSum c M u Qs (smoothWeight x) r) D) ≤
      smallCofactorError I a c M u ε Y τ x moduli := by
  unfold smallCofactorError
  apply Finset.sum_le_sum
  intro r hr
  apply mul_le_mul_of_nonneg_left _ (markingWeight_bounds I _ _ r hV).1
  have hh := predecessor_blockRemainder_le
    (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))) S moduli
    (arrayWeight c M u (smoothWeight x) r) M c r
    (primeProgressionSum c M u
      (WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ)))
      (smoothWeight x) r) D hS hmoduli
  simpa only [divisorMass_eq_sievedPrimeSum, productDensity, PrimeDistribution.sieveDensity] using hh

/-- A finite source application with every weight, main mass and error term
already specialized to the concrete manuscript objects. -/
theorem source_retained_lower (source : SourceLemma11_1) (C₀ : ℝ) :
    ∃ C : ℝ, 0 < C ∧ ∃ H₀ : ℕ,
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (c M u : ℕ)
        (ε Y τ x z : ℝ) (S moduli : Finset ℕ) (H : ℕ),
      (∀ i ∈ I, 0 < bandMass (a i) x) →
      2 ≤ z → Even H → H₀ ≤ H → C * Real.exp (-(H : ℝ)) ≤ 1 →
      (∀ p ∈ S, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ z ∧ ¬ p ∣ M) →
      (∀ v : ℝ, 1 < v →
        (∑ p ∈ S.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
          1 / ((p : ℝ) - 1)) ≤ C₀) →
      (∀ r ∈ boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε),
        (∑ p ∈ S.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ 2 * τ) →
      (∀ T ∈ remainderSubsets S (z ^ (4 * H + 2)), (∏ p ∈ T, p) ∈ moduli) →
      (1 - C * Real.exp (-(H : ℝ))) * (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          retainedMass I a c M u ε Y τ x -
        C * smallCofactorError I a c M u ε Y τ x moduli ≤
      retainedSiftedMass I a c M u ε Y τ x S := by
  obtain ⟨C, hC, H₀, he⟩ := source_weighted_cofactor_bounds source C₀
  refine ⟨C, hC, H₀, ?_⟩
  intro ι I a c M u ε Y τ x z S moduli H hV hz hH hH₀ hsmall hS hblock hτ hmoduli
  let R := boundedCofactors (markedPrimes I a x) (unmarkedCofactors I a ε Y τ x) (x ^ ε)
  let Qs := WeightSupport.boundedLargePrimes ⌊2 * x⌋₊ (x ^ (9 / 10 : ℝ))
  let X := primeProgressionSum c M u Qs (smoothWeight x)
  let E := fun r => blockRemainder Qs (arrayWeight c M u (smoothWeight x) r)
    (fun p Q => p ∣ c * r * Q + 1) S (cofactorDensity M r) (X r) (z ^ (4 * H + 2))
  have hl := (he R S M c (fun _ => Qs) (arrayWeight c M u (smoothWeight x))
    (marking I a x) X z (2 * τ) H hz hH hH₀ hsmall
    (fun r _ => (markingWeight_bounds I _ _ r hV).1)
    (fun r _ => primeProgressionSum_nonneg c M u Qs (smoothWeight x)
      (fun d => (smoothWeight_bounds x d).1) r)
    (fun r _ Q _ => by
      dsimp only [arrayWeight]
      split_ifs
      · exact (smoothWeight_bounds x _).1
      · exact le_rfl)
    hS hblock hτ).1
  have herr : (∑ r ∈ R, marking I a x r * E r) ≤
      smallCofactorError I a c M u ε Y τ x moduli :=
    weighted_blockRemainder_le I a c M u ε Y τ x _ S moduli hV
      (fun p hp => (hS p hp).1) hmoduli
  have hmul := mul_le_mul_of_nonneg_left herr hC.le
  change (1 - C * Real.exp (-(H : ℝ))) * (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
      retainedMass I a c M u ε Y τ x - C * (∑ r ∈ R, marking I a x r * E r) ≤
      retainedSiftedMass I a c M u ε Y τ x S at hl
  linarith

/-- The actual odd sieve primes outside the fixed progression modulus. -/
noncomputable def sievePrimes (M : ℕ) (z : ℝ) : Finset ℕ :=
  (Nat.primesLE ⌊z⌋₊).filter (fun p => 3 ≤ p ∧ ¬ p ∣ M)

theorem sievePrimes_properties (M : ℕ) {z : ℝ} (hz : 0 ≤ z) {p : ℕ}
    (hp : p ∈ sievePrimes M z) :
    p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ z ∧ ¬ p ∣ M := by
  have hh := Finset.mem_filter.mp hp
  have hp' := Nat.mem_primesLE.mp hh.1
  exact ⟨hp'.2, hh.2.1,
    (by exact_mod_cast hp'.1 : (p : ℝ) ≤ ⌊z⌋₊).trans (Nat.floor_le hz), hh.2.2⟩

/-- The standard uniform reciprocal-prime estimate on quadratic intervals.
It is an ordinary prime estimate, stated for arbitrary finite subcollections
so that deleting primes dividing the progression modulus requires no new input. -/
def PrimeBlockSource (C₀ : ℝ) : Prop :=
  ∀ S : Finset ℕ, (∀ p ∈ S, p.Prime ∧ 3 ≤ p) → ∀ v : ℝ, 1 < v →
    (∑ p ∈ S.filter (fun p : ℕ => v < (p : ℝ) ∧ (p : ℝ) ≤ v ^ 2),
      1 / ((p : ℝ) - 1)) ≤ C₀

/-- Every source remainder modulus for the manuscript's initial depth lies
inside the proved BV range. -/
theorem initial_remainder_moduli {x b κ : ℝ} (hx : 1 ≤ x) (hb : 0 < b)
    (hbsmall : b < 1 / 100) (hκ : κ < 1 / 100) (S : Finset ℕ)
    (hS : ∀ p ∈ S, p.Prime) :
    ∀ T ∈ remainderSubsets S ((x ^ b) ^ (4 * initialDepth b + 2)),
      (∏ p ∈ T, p) ∈ Finset.Icc 1 ⌊x ^ (1 / 2 - κ / 2)⌋₊ := by
  intro T hT
  have hh := Finset.mem_filter.mp hT
  apply Finset.mem_Icc.mpr
  refine ⟨?_, Nat.le_floor ?_⟩
  · exact Finset.prod_pos (fun p hp =>
      (hS p ((Finset.mem_powerset.mp hh.1) hp)).pos)
  · exact hh.2.trans ((initialDepth_modulus_bound hx hb).trans
      (Real.rpow_le_rpow_of_exponent_le hx (by linarith)))

/-- The actual initial sieve lower bound, with an arbitrarily high power of
`log x` in the remainder. Both constants are chosen before every marking
family. The only analytic inputs are the cited block theorem, classical
prime-block estimate, unweighted BV, fixed-modulus PNT, reciprocal-totient
estimate, and the ordinary band-mass bounds. -/
theorem actual_initial_lower_uniform
    (source : SourceLemma11_1) (C₀ : ℝ) (hBlock : PrimeBlockSource C₀) :
    ∃ Cs : ℝ, 0 < Cs ∧ ∃ H₀ : ℕ,
      ∀ (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100) (hA : 0 < A),
      ∃ E : ℝ, 0 < E ∧
      ∀ b : ℝ, 0 < b → b < 1 / 100 → H₀ ≤ initialDepth b →
      Cs * Real.exp (-(initialDepth b : ℝ)) ≤ 1 →
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ),
      (1 / 10 : ℝ) ≤ amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → ∀ᶠ x : ℝ in atTop,
      let S := sievePrimes (c * M₀) (x ^ b)
      (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x -
        E * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A ≤
      SiftedSupport.siftedBaseMass I a c (c * M₀) (c * v + 1) ε Y τ x S := by
  obtain ⟨Cs, hCs, H₀, hs⟩ := source_retained_lower source C₀
  refine ⟨Cs, hCs, H₀, ?_⟩
  intro hBV hPNT hTot c M₀ v inst hc hu hv huM ε κ A hε hεκ hκ hA
  obtain ⟨Cd, hCd, hd⟩ := actual_distribution_relative_to_baseMass hBV hPNT hTot
    hc hu hv huM hε hεκ hκ hA
  refine ⟨Cs * Cd + 1, by positivity, ?_⟩
  intro b hb hbsmall hH₀ hsmall ι I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical Y hY τ hτ
  have hminpos : 0 < amin := by linarith
  have hεmax : ε ≤ 1 / 100 := (hεκ.trans hκ).le
  have hcpos : 0 < c := by omega
  have ha' : ∀ i ∈ I, (1 / 10 : ℝ) ≤ a i := fun i hi => hmin.trans (ha i hi).1
  filter_upwards [hd I a amin amax B v₀ hminpos hmax hv₀ ha hinj hclassical Y hY τ,
    MarkedOmission.eventual_reciprocal_cap I a ε hε.le ha' τ hτ,
    eventually_baseMass_partition I a amin amax hminpos hmax ha
      c (c * M₀) (c * v + 1) hcpos ε Y τ hεmax,
    actual_discardedMass_le_base_over_log_power hPNT hc hu hv I a amin amax B v₀
      hminpos hmax hv₀ ha hinj hclassical A 1 (by norm_num) ε hε hεmax Y hY τ,
    MarkedScaleSupport.eventual_marked_prime_bounds I a amin amax c (1 / 2)
      hminpos hmax (by norm_num) ha,
    MarkedScaleSupport.eventual_marked_not_dvd I a amin amax hminpos hmax ha c hcpos,
    (tendsto_rpow_atTop hb).eventually (eventually_ge_atTop (2 : ℝ)),
    hclassical, eventually_ge_atTop (2 : ℝ)]
    with x hdist homit hpartition htail hP hcP hxb hVx hx
  let S := sievePrimes (c * M₀) (x ^ b)
  let moduli := Finset.Icc 1 ⌊x ^ (1 / 2 - κ / 2)⌋₊
  have hx1 : 1 ≤ x := by linarith
  have hx0 : 0 < x := by linarith
  have hD0 : 0 ≤ x ^ (1 / 2 - κ / 2) := Real.rpow_nonneg hx0.le _
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hS : ∀ p ∈ S, p.Prime ∧ 3 ≤ p ∧ (p : ℝ) ≤ x ^ b ∧ ¬ p ∣ c * M₀ :=
    fun p hp => sievePrimes_properties (c * M₀) (Real.rpow_nonneg hx0.le _) hp
  have hmod : ∀ ℓ ∈ moduli, 0 < ℓ ∧ (ℓ : ℝ) ≤ x ^ (1 / 2 - κ / 2) := by
    intro ℓ hℓ
    have hh := Finset.mem_Icc.mp hℓ
    exact ⟨hh.1, (by exact_mod_cast hh.2 : (ℓ : ℝ) ≤ ⌊x ^ (1 / 2 - κ / 2)⌋₊).trans
      (Nat.floor_le hD0)⟩
  have hone : 1 ∈ moduli := by
    refine Finset.mem_Icc.mpr ⟨le_rfl, Nat.le_floor ?_⟩
    simpa only [Nat.cast_one] using
      (Real.one_le_rpow hx1 (show (0 : ℝ) ≤ 1 / 2 - κ / 2 by linarith))
  have herr := hdist moduli hmod hone
  have hrec : ∀ r ∈ boundedCofactors (markedPrimes I a x)
      (unmarkedCofactors I a ε Y τ x) (x ^ ε),
      (∑ p ∈ S.filter (fun p => p ∣ r), 1 / (p : ℝ)) ≤ 2 * τ := by
    intro r hr
    have hrpos := ((mem_boundedCofactors _ _ _ r).mp hr).1
    refine (MarkedOmission.reciprocal_prime_divisors_le _ hrpos ?_).trans (homit ε Y r hr)
    intro p hp
    have hh := Finset.mem_filter.mp hp
    exact ⟨(hS p hh.1).1, hh.2⟩
  have hlower := hs I a c (c * M₀) (c * v + 1) ε Y τ x (x ^ b) S moduli
    (initialDepth b) hV hxb (initialDepth_even b) hH₀ hsmall hS
    (hBlock S (fun p hp => ⟨(hS p hp).1, (hS p hp).2.1⟩)) hrec
    (initial_remainder_moduli hx1 hb hbsmall hκ S (fun p hp => (hS p hp).1))
  have hretained : retainedSiftedMass I a c (c * M₀) (c * v + 1) ε Y τ x S ≤
      SiftedSupport.siftedBaseMass I a c (c * M₀) (c * v + 1) ε Y τ x S :=
    SiftedSupport.retained_sifted_le I a c (c * M₀) (c * v + 1) ε Y τ x
      (x ^ (1 / 2 : ℝ)) S hx hcpos (by linarith)
      (Real.rpow_le_rpow_of_exponent_le hx1 (by norm_num))
      (fun p hp => (hP p hp).2.2) hcP
      (fun r hr p hp hpr => MarkedScaleSupport.unmarked_prime_divisor_le I a ε Y τ (1 / 2)
        hx1 (by linarith) hr hp hpr) hV
  have hV0 : 0 ≤ ∏ p ∈ S, LocalSieveProducts.sieveFactor p :=
    Finset.prod_nonneg (fun p hp => (LocalSieveProducts.sieveFactor_pos (hS p hp).2.1).le)
  have hV1 : (∏ p ∈ S, LocalSieveProducts.sieveFactor p) ≤ 1 :=
    Finset.prod_le_one₀ (fun p hp => (LocalSieveProducts.sieveFactor_pos (hS p hp).2.1).le)
      (fun p hp => LocalSieveProducts.sieveFactor_le_one (hS p hp).2.1)
  have hα0 : 0 ≤ (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
      (∏ p ∈ S, LocalSieveProducts.sieveFactor p) := mul_nonneg (by linarith) hV0
  have hα1 : (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
      (∏ p ∈ S, LocalSieveProducts.sieveFactor p) ≤ 1 := by
    have hh : 1 - Cs * Real.exp (-(initialDepth b : ℝ)) ≤ 1 := by
      have hn : 0 ≤ Cs * Real.exp (-(initialDepth b : ℝ)) := by positivity
      linarith
    exact (mul_le_mul_of_nonneg_right hh hV0).trans (by simpa using hV1)
  have htail0 := discardedMass_nonneg I a c (c * M₀) (c * v + 1) ε Y τ x hV
  have htailα := mul_le_mul_of_nonneg_right hα1 htail0
  have herror := mul_le_mul_of_nonneg_left herr hCs.le
  simp only [one_mul] at htail htailα
  change (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
      (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
      baseMass I a c (c * M₀) (c * v + 1) ε Y τ x -
      (Cs * Cd + 1) * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A ≤ _
  calc
    _ = ((1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          retainedMass I a c (c * M₀) (c * v + 1) ε Y τ x -
          Cs * smallCofactorError I a c (c * M₀) (c * v + 1) ε Y τ x moduli) +
        (((1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p)) *
          discardedMass I a c (c * M₀) (c * v + 1) ε Y τ x -
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A) +
        (Cs * smallCofactorError I a c (c * M₀) (c * v + 1) ε Y τ x moduli -
          Cs * (Cd * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A)) := by
            rw [hpartition]
            ring
    _ ≤ _ := by linarith only [hlower, hretained, htail, htailα, herror]

/-- Fixed-parameter specialization of the uniform source-constant theorem. -/
theorem actual_initial_lower
    (source : SourceLemma11_1) (C₀ : ℝ) (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ A : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100) (hA : 0 < A) :
    ∃ Cs E : ℝ, 0 < Cs ∧ 0 < E ∧ ∃ H₀ : ℕ,
      ∀ b : ℝ, 0 < b → b < 1 / 100 → H₀ ≤ initialDepth b →
      Cs * Real.exp (-(initialDepth b : ℝ)) ≤ 1 →
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ),
      (1 / 10 : ℝ) ≤ amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → ∀ᶠ x : ℝ in atTop,
      let S := sievePrimes (c * M₀) (x ^ b)
      (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
          (∏ p ∈ S, LocalSieveProducts.sieveFactor p) *
          baseMass I a c (c * M₀) (c * v + 1) ε Y τ x -
        E * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ A ≤
      SiftedSupport.siftedBaseMass I a c (c * M₀) (c * v + 1) ε Y τ x S := by
  obtain ⟨Cs, hCs, H₀, he⟩ := actual_initial_lower_uniform source C₀ hBlock
  obtain ⟨E, hE, he⟩ := he hBV hPNT hTot hc hu hv huM hε hεκ hκ hA
  exact ⟨Cs, E, hCs, hE, H₀, he⟩

/-- The ordinary local sieve product `V_M(z)` appearing in the manuscript. -/
noncomputable def localSieveProduct (M : ℕ) (z : ℝ) : ℝ :=
  ∏ p ∈ sievePrimes M z, LocalSieveProducts.sieveFactor p

/-- Precisely the classical Mertens asymptotic for this actual finite
product. `S_M` is the positive fixed-modulus constant, not a candidate density
or a hypothesis on any marked weight. -/
def MertensLocalSource (M : ℕ) (S_M : ℝ) : Prop :=
  0 < S_M ∧ Tendsto (fun z : ℝ => Real.log z * localSieveProduct M z) atTop
    (nhds (S_M * Real.exp (-Real.eulerMascheroniConstant)))

/-- Substituting `z=x^b` supplies the precise factor `1/b`. -/
theorem localSieveProduct_scale_tendsto (M : ℕ) (S_M : ℝ)
    (hM : MertensLocalSource M S_M) {b : ℝ} (hb : 0 < b) :
    Tendsto (fun x : ℝ => Real.log x * localSieveProduct M (x ^ b)) atTop
      (nhds (S_M * Real.exp (-Real.eulerMascheroniConstant) / b)) := by
  have hh := (hM.2.comp (tendsto_rpow_atTop hb)).div_const b
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (0 : ℝ)] with x hx
  dsimp only [Function.comp_def]
  rw [Real.log_rpow hx]
  field_simp

/-- An explicit error function tending to zero. It depends on the fixed
sieve constants and modulus, but not on any marking family. -/
noncomputable def initialError (Cs E S_M b : ℝ) (M : ℕ) (x : ℝ) : ℝ :=
  (1 - Cs * Real.exp (-(initialDepth b : ℝ))) *
    (Real.log x * localSieveProduct M (x ^ b) / S_M -
      Real.exp (-Real.eulerMascheroniConstant) / b) - E / (S_M * Real.log x)

theorem initialError_tendsto (Cs E S_M : ℝ) (M : ℕ)
    (hM : MertensLocalSource M S_M) {b : ℝ} (hb : 0 < b) :
    Tendsto (initialError Cs E S_M b M) atTop (nhds 0) := by
  have hscale := (localSieveProduct_scale_tendsto M S_M hM hb).div_const S_M
  have hcancel : (S_M * Real.exp (-Real.eulerMascheroniConstant) / b) / S_M =
      Real.exp (-Real.eulerMascheroniConstant) / b := by field_simp [hM.1.ne']
  rw [hcancel] at hscale
  have hfirst := (hscale.sub_const (Real.exp (-Real.eulerMascheroniConstant) / b)).const_mul
    (1 - Cs * Real.exp (-(initialDepth b : ℝ)))
  have hsecond : Tendsto (fun x : ℝ => E / (S_M * Real.log x)) atTop (nhds 0) := by
    have hh := (tendsto_inv_atTop_zero.comp Real.tendsto_log_atTop).const_mul (E / S_M)
    simpa only [mul_zero, div_eq_mul_inv, mul_inv_rev, Function.comp_def, mul_assoc, mul_comm,
      mul_left_comm] using hh
  unfold initialError
  simpa only [sub_self, mul_zero, sub_zero] using hfirst.sub hsecond

/-- A sufficiently small cutoff meets both genuine source depth conditions.
The choice is made before any marking family or cofactor parameter. -/
theorem exists_initial_cutoff (Cs : ℝ) (hCs : 0 < Cs) (H₀ : ℕ) :
    ∃ b₀ : ℝ, 0 < b₀ ∧ b₀ ≤ 1 / 100 ∧ ∀ b : ℝ, 0 < b → b < b₀ →
      H₀ ≤ initialDepth b ∧ Cs * Real.exp (-(initialDepth b : ℝ)) ≤ 1 := by
  let H₁ := max H₀ ⌈Real.log Cs⌉₊
  let b₀ : ℝ := min (1 / 100) (1 / (40 * ((H₁ : ℝ) + 1)))
  refine ⟨b₀, by dsimp [b₀]; positivity, min_le_left _ _, ?_⟩
  intro b hb hbb
  have hdepth : H₁ ≤ initialDepth b := initialDepth_ge hb
    (hbb.le.trans (min_le_right _ _))
  refine ⟨(le_max_left _ _).trans hdepth, ?_⟩
  have hlog : Real.log Cs ≤ (initialDepth b : ℝ) :=
    (Nat.le_ceil (Real.log Cs)).trans (by exact_mod_cast (le_max_right H₀ _).trans hdepth)
  calc
    Cs * Real.exp (-(initialDepth b : ℝ)) =
        Real.exp (Real.log Cs - (initialDepth b : ℝ)) := by
      rw [Real.exp_sub, Real.exp_log hCs, div_eq_mul_inv, Real.exp_neg]
    _ ≤ Real.exp 0 := Real.exp_le_exp.mpr (by linarith)
    _ = 1 := Real.exp_zero

/-- Exact normalization of the finite lower-bound expression. -/
theorem initial_normalization_identity (Cs E S_M b : ℝ) (M : ℕ) {x : ℝ}
    (hS : 0 < S_M) (hx : 1 < x) (X : ℝ) :
    (S_M * X / Real.log x) *
      (Real.exp (-Real.eulerMascheroniConstant) / b *
        (1 - Cs * Real.exp (-(initialDepth b : ℝ))) + initialError Cs E S_M b M x) =
    (1 - Cs * Real.exp (-(initialDepth b : ℝ))) * localSieveProduct M (x ^ b) * X -
      E * X / (Real.log x) ^ (2 : ℝ) := by
  have hL : 0 < Real.log x := Real.log_pos hx
  unfold initialError
  rw [Real.rpow_two]
  field_simp
  ring

theorem baseMass_nonneg {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (hV : ∀ i ∈ I, 0 < bandMass (a i) x) :
    0 ≤ baseMass I a c M u ε Y τ x := by
  apply Finset.sum_nonneg
  intro d hd
  exact (arithmeticWeight_bounds M u (smoothWeight x) I _ _ _ c _ _ d
    (smoothWeight_bounds x d) hV).1

/-- The initial lower bound in the exact normalization of the manuscript.
There are fixed positive sieve constants and a sufficiently small positive
cutoff; for every such `b`, an explicit marking-independent error tends to
zero. The exponent constant is `1/20`. -/
theorem actual_initial_lower_normalized_uniform
    (source : SourceLemma11_1) (C₀ : ℝ) (hBlock : PrimeBlockSource C₀) :
    ∃ C_s b₀ : ℝ, 0 < C_s ∧ 0 < b₀ ∧ b₀ ≤ 1 / 100 ∧
      ∀ b : ℝ, 0 < b → b < b₀ →
      ∀ (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (S_M : ℝ) (hMertens : MertensLocalSource (c * M₀) S_M), ∃ error : ℝ → ℝ,
      Tendsto error atTop (nhds 0) ∧
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ),
      (1 / 10 : ℝ) ≤ amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → ∀ᶠ x : ℝ in atTop,
      (S_M * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / Real.log x) *
        (Real.exp (-Real.eulerMascheroniConstant) / b *
          (1 - C_s * Real.exp (-(1 / 20 : ℝ) / b)) + error x) ≤
      SiftedSupport.siftedBaseMass I a c (c * M₀) (c * v + 1) ε Y τ x
        (sievePrimes (c * M₀) (x ^ b)) := by
  obtain ⟨Cs, hCs, H₀, he⟩ := actual_initial_lower_uniform source C₀ hBlock
  obtain ⟨b₀, hb₀, hb₀small, hcutoff⟩ := exists_initial_cutoff Cs hCs H₀
  refine ⟨Cs * Real.exp 2, b₀, by positivity, hb₀, hb₀small, ?_⟩
  intro b hb hbb hBV hPNT hTot c M₀ v inst hc hu hv huM ε κ hε hεκ hκ S_M hMertens
  obtain ⟨E, _hE, he⟩ := he hBV hPNT hTot hc hu hv huM hε hεκ hκ (A := 2) (by norm_num)
  have hdepth := hcutoff b hb hbb
  refine ⟨initialError Cs E S_M b (c * M₀), initialError_tendsto Cs E S_M (c * M₀) hMertens hb, ?_⟩
  intro ι I a amin amax B v₀ hmin hmax hv₀ ha hinj hclassical Y hY τ hτ
  filter_upwards [he b hb (hbb.trans_le hb₀small) hdepth.1 hdepth.2 I a amin amax B v₀
    hmin hmax hv₀ ha hinj hclassical Y hY τ hτ,
    hclassical, eventually_gt_atTop (1 : ℝ)] with x hlower hVx hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hbase := baseMass_nonneg I a c (c * M₀) (c * v + 1) ε Y τ x hV
  have hcoeff := mul_le_mul_of_nonneg_left (sub_le_sub_left (initialDepth_exponential_bound hb hCs.le) 1)
    (show 0 ≤ Real.exp (-Real.eulerMascheroniConstant) / b by positivity)
  have hfront : 0 ≤ S_M * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / Real.log x :=
    div_nonneg (mul_nonneg hMertens.1.le hbase) (Real.log_pos hx).le
  calc
    _ ≤ (S_M * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / Real.log x) *
        (Real.exp (-Real.eulerMascheroniConstant) / b *
          (1 - Cs * Real.exp (-(initialDepth b : ℝ))) +
          initialError Cs E S_M b (c * M₀) x) :=
      mul_le_mul_of_nonneg_left (by linarith only [hcoeff]) hfront
    _ = (1 - Cs * Real.exp (-(initialDepth b : ℝ))) * localSieveProduct (c * M₀) (x ^ b) *
        baseMass I a c (c * M₀) (c * v + 1) ε Y τ x -
        E * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / (Real.log x) ^ (2 : ℝ) :=
      initial_normalization_identity Cs E S_M b (c * M₀) hMertens.1 hx _
    _ ≤ _ := hlower

/-- Fixed-parameter specialization; the preceding theorem exposes the
stronger order in which the cutoff precedes `ε`, `Y`, and all markings. -/
theorem actual_initial_lower_normalized
    (source : SourceLemma11_1) (C₀ : ℝ) (hBlock : PrimeBlockSource C₀)
    (hBV : PrimeDistribution.BombieriVinogradovSource)
    (hPNT : PrimeDistribution.FixedModulusPNTSource) (hTot : ReciprocalTotientSource)
    {c M₀ v : ℕ} [NeZero M₀] (hc : 2 ≤ c)
    (hu : c * v + 1 < c * M₀) (hv : v.Coprime M₀)
    (huM : (c * v + 1).Coprime (c * M₀))
    {ε κ : ℝ} (hε : 0 < ε) (hεκ : ε < κ) (hκ : κ < 1 / 100)
    (S_M : ℝ) (hMertens : MertensLocalSource (c * M₀) S_M) :
    ∃ C_s b₀ : ℝ, 0 < C_s ∧ 0 < b₀ ∧ b₀ ≤ 1 / 100 ∧
      ∀ b : ℝ, 0 < b → b < b₀ → ∃ error : ℝ → ℝ,
      Tendsto error atTop (nhds 0) ∧
      ∀ {ι : Type*} (I : Finset ι) (a : ι → ℝ) (amin amax B v₀ : ℝ),
      (1 / 10 : ℝ) ≤ amin → amax < 1 → 0 < v₀ →
      (∀ i ∈ I, amin ≤ a i ∧ a i ≤ amax) → Set.InjOn a (I : Set ι) →
      (∀ᶠ x : ℝ in atTop, ∀ i ∈ I, v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B) →
      ∀ Y : ℝ, (M₀ : ℝ) ≤ Y → ∀ τ : ℝ, 0 < τ → ∀ᶠ x : ℝ in atTop,
      (S_M * baseMass I a c (c * M₀) (c * v + 1) ε Y τ x / Real.log x) *
        (Real.exp (-Real.eulerMascheroniConstant) / b *
          (1 - C_s * Real.exp (-(1 / 20 : ℝ) / b)) + error x) ≤
      SiftedSupport.siftedBaseMass I a c (c * M₀) (c * v + 1) ε Y τ x
        (sievePrimes (c * M₀) (x ^ b)) := by
  obtain ⟨Cs, b₀, hCs, hb₀, hb₀small, he⟩ :=
    actual_initial_lower_normalized_uniform source C₀ hBlock
  refine ⟨Cs, b₀, hCs, hb₀, hb₀small, ?_⟩
  intro b hb hbb
  exact he b hb hbb hBV hPNT hTot hc hu hv huM hε hεκ hκ S_M hMertens

/-- A nonzero weight lies in the prescribed reduced progression, so it
cannot have a prime divisor dividing the fixed modulus. -/
theorem weight_avoids_modulus {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) (huM : u.Coprime M) {d p : ℕ}
    (hw : arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) c
      (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) d ≠ 0)
    (hp : p.Prime) (hpd : p ∣ d) : ¬ p ∣ M := by
  intro hpM
  have hres := (arithmeticWeight_ne_zero_support M u (smoothWeight x) I _ _ _ c _ _ d hw).1
  have hpu : p ∣ u := by
    rw [← hres]
    exact (Nat.dvd_mod_iff hpM).mpr hpd
  apply hp.not_dvd_one
  simpa only [huM.gcd_eq_one] using Nat.dvd_gcd hpu hpM

/-- On the support of the actual weight, deleting the modulus primes and
`2` from the sieve leaves exactly the usual least-prime-factor condition. -/
theorem prime_rough_iff_on_weight {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) {z : ℝ} (hz : 0 ≤ z)
    (hM2 : 2 ∣ M) (huM : u.Coprime M) {d : ℕ}
    (hw : arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) c
      (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) d ≠ 0) :
    (∀ p ∈ sievePrimes M z, ¬ p ∣ d) ↔
      (∀ p : ℕ, p.Prime → p ∣ d → z < (p : ℝ)) := by
  constructor
  · intro hrough p hp hpd
    by_contra hle
    have hpM := weight_avoids_modulus I a c M u ε Y τ x huM hw hp hpd
    have hp3 : 3 ≤ p := by
      have hp2 := hp.two_le
      have hne : p ≠ 2 := by rintro rfl; exact hpM hM2
      omega
    have hmem : p ∈ sievePrimes M z := Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor (le_of_not_gt hle), hp⟩, hp3, hpM⟩
    exact hrough p hmem hpd
  · intro hrough p hp hpd
    have hh := sievePrimes_properties M hz hp
    exact (not_lt_of_ge hh.2.2.1) (hrough p hh.1 hpd)

noncomputable def primeRoughIntegers (z x : ℝ) : Finset ℕ := by
  classical
  exact (Finset.Icc 2 ⌊2 * x⌋₊).filter (fun d =>
    ∀ p : ℕ, p.Prime → p ∣ d → z < (p : ℝ))

/-- The lower bound just proved concerns the full actual rough integer
weight, not a weakened roughness condition missing fixed primes. -/
theorem siftedBaseMass_eq_prime_rough_sum {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ x : ℝ) {z : ℝ} (hz : 0 ≤ z)
    (hM2 : 2 ∣ M) (huM : u.Coprime M) :
    SiftedSupport.siftedBaseMass I a c M u ε Y τ x (sievePrimes M z) =
      ∑ d ∈ primeRoughIntegers z x,
        ManuscriptCover.integerWeight I a c M u ε Y τ x d := by
  classical
  unfold SiftedSupport.siftedBaseMass siftedMass primeRoughIntegers
  rw [Finset.sum_filter, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hw : arithmeticWeight M u (smoothWeight x) I (fun i => primeBand (a i) x)
      (fun i => bandMass (a i) x) (markedPrimes I a x) c
      (unmarkedCofactors I a ε Y τ x) (x ^ (9 / 10 : ℝ)) d = 0
  · simp only [ManuscriptCover.integerWeight, hw, ite_self]
  · simp only [prime_rough_iff_on_weight I a c M u ε Y τ x hz hM2 huM hw,
      ManuscriptCover.integerWeight]

/-- In particular, the endpoint after Buchstab subtraction is exactly the
rough mass used by the prime/composite survivor cover. -/
theorem siftedBaseMass_eq_roughMass {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ κ x : ℝ) (hx : 0 ≤ x)
    (hM2 : 2 ∣ M) (huM : u.Coprime M) :
    SiftedSupport.siftedBaseMass I a c M u ε Y τ x
      (sievePrimes M (x ^ (1 / 2 - κ))) =
      ManuscriptCover.roughMass I a c M u ε Y τ κ x :=
  siftedBaseMass_eq_prime_rough_sum I a c M u ε Y τ x (Real.rpow_nonneg hx _) hM2 huM

end Artin.InitialSieve
