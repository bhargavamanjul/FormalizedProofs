module

public import Artin.InitialSieve
public import Artin.BuchstabRoughReduction

/-!
# The finite subtraction for the manuscript's literal integer weights

The initial sifted sum is exactly a rough-integer sum on the reduced
progression. The least-prime-factor cover then relates it to the terminal
rough sum and the same finite factor sums used by marked replacement.
-/

@[expose] public section

open Filter
open scoped BigOperators

namespace Artin.BuchstabFiniteCover

open MarkedSource BuchstabPartition

/-- The exact finite inequality, before any analytic estimate is inserted.
The reduced progression restores all fixed primes omitted from the sieve. -/
theorem siftedBaseMass_le_roughMass_add_bins {ι : Type*}
    (I : Finset ι) (a : ι → ℝ) (c M u : ℕ) (ε Y τ x : ℝ)
    {b₀ κ tolerance : ℝ} (P : DensityPartition b₀ (1 / 2 - κ) tolerance)
    (hx : 0 ≤ x) (hM2 : 2 ∣ M) (huM : u.Coprime M)
    (hw : ∀ d, 0 ≤ ManuscriptCover.integerWeight I a c M u ε Y τ x d) :
    SiftedSupport.siftedBaseMass I a c M u ε Y τ x
        (InitialSieve.sievePrimes M (x ^ b₀)) ≤
      ManuscriptCover.roughMass I a c M u ε Y τ κ x +
      ∑ i : Fin P.bins,
        factorBinMass ⌊2 * x⌋₊ (ManuscriptCover.integerWeight I a c M u ε Y τ x)
          (x ^ P.endpoint i) (x ^ P.endpoint (i.val + 1)) := by
  classical
  rw [InitialSieve.siftedBaseMass_eq_prime_rough_sum I a c M u ε Y τ x
    (Real.rpow_nonneg hx _) hM2 huM]
  rw [Fin.sum_univ_eq_sum_range (fun i =>
    factorBinMass ⌊2 * x⌋₊ (ManuscriptCover.integerWeight I a c M u ε Y τ x)
      (x ^ P.endpoint i) (x ^ P.endpoint (i + 1))) ]
  have hcover := weighted_factor_bin_cover (Finset.Icc 2 ⌊2 * x⌋₊)
    (ManuscriptCover.integerWeight I a c M u ε Y τ x)
    (fun i => x ^ P.endpoint i) P.bins ⌊2 * x⌋₊
    (fun d hd => Finset.mem_Icc.mp hd) hw
  simpa only [BuchstabPartition.roughMass, P.endpoint_zero, P.endpoint_last,
    ManuscriptCover.roughMass, ManuscriptCover.roughIntegers,
    InitialSieve.primeRoughIntegers, Finset.sum_filter, BuchstabPartition.IsRough] using hcover

/-- The ordinary positive band-mass bound gives nonnegativity of every
actual manuscript integer weight, uniformly over the cofactor parameters. -/
theorem eventually_integerWeight_nonneg (hbands : ClassicalBandMass)
    {K : ℕ} (bands : Bands K) :
    ∀ᶠ x : ℝ in atTop, ∀ (c M u : ℕ) (ε Y τ : ℝ) (d : ℕ),
      0 ≤ ManuscriptCover.integerWeight Finset.univ bands.exponent c M u ε Y τ x d := by
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  filter_upwards [hbands K bands] with x hx c M u ε Y τ d
  apply ManuscriptCover.integerWeight_nonneg
  intro i hi
  have hi' : Real.log 2 / 2 ≤ MarkedBandTail.bandMass (bands.exponent i) x := by
    simpa only [bands.mass_eq_markedBandTail x i] using hx i
  exact (half_pos hlog).trans_le hi'

/-- The actual initial-sieve mass is covered by the terminal manuscript
rough mass and the finite bins of the fixed density partition. Only the
classical band positivity input is needed for this eventual formulation. -/
theorem actual_finite_cover (hbands : ClassicalBandMass)
    {K : ℕ} (bands : Bands K) (c M u : ℕ) (ε Y τ : ℝ)
    (hM2 : 2 ∣ M) (huM : u.Coprime M)
    {b₀ κ tolerance : ℝ} (P : DensityPartition b₀ (1 / 2 - κ) tolerance) :
    ∀ᶠ x : ℝ in atTop,
      SiftedSupport.siftedBaseMass Finset.univ bands.exponent c M u ε Y τ x
          (InitialSieve.sievePrimes M (x ^ b₀)) ≤
        ManuscriptCover.roughMass Finset.univ bands.exponent c M u ε Y τ κ x +
        ∑ i : Fin P.bins,
          factorBinMass ⌊2 * x⌋₊
            (ManuscriptCover.integerWeight Finset.univ bands.exponent c M u ε Y τ x)
            (x ^ P.endpoint i) (x ^ P.endpoint (i.val + 1)) := by
  filter_upwards [eventually_integerWeight_nonneg hbands bands,
    eventually_ge_atTop (0 : ℝ)] with x hx hx0
  exact siftedBaseMass_le_roughMass_add_bins Finset.univ bands.exponent
    c M u ε Y τ x P hx0 hM2 huM (hx c M u ε Y τ)

end Artin.BuchstabFiniteCover
