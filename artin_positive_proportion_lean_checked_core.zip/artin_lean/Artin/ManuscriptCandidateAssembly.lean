module

public import Artin.ManuscriptCover
public import Artin.ManuscriptSemiprime
public import Artin.CandidateSieve

/-!
# Connecting the literal manuscript weights to the candidate theorem

All finite sets and masses below are the actual arithmetic objects.  The
remaining rough lower estimate is displayed explicitly when it is used; it
is an original deduction, not a newly accepted analytic source.
-/

@[expose] public section
open Filter
open scoped BigOperators Topology

namespace Artin.ManuscriptCandidateAssembly

open MarkedSource MarkedBandTail MarkedCofactorEstimate ManuscriptMass ManuscriptCover

/-- The two independently defined actual weights agree exactly. -/
theorem semiprime_weight_eq {K : ℕ} (b : Bands K)
    (c M u : ℕ) (ε Y τ x : ℝ) :
    ManuscriptSemiprime.weight b c M u ε Y τ x =
      integerWeight Finset.univ b.exponent c M u ε Y τ x :=
  ManuscriptSemiprime.weight_eq b c M u ε Y τ x

/-- The larger finite integer interval in the cover contributes nothing
below `x`, because the fixed smooth bump is supported in `(1,2)`. -/
theorem composite_mass_eq {ι : Type*} (I : Finset ι) (a : ι → ℝ)
    (c M u : ℕ) (ε Y τ κ : ℝ) {x : ℝ} (hx : 1 < x) :
    roughCompositeMass I a c M u ε Y τ κ x =
      SemiprimeCover.roughCompositeMass x κ (integerWeight I a c M u ε Y τ x) := by
  classical
  unfold roughCompositeMass SemiprimeCover.roughCompositeMass
  symm
  apply Finset.sum_subset_zero_on_sdiff
  · intro d hd
    obtain ⟨hdI, hdprime, hdrough⟩ := Finset.mem_filter.mp hd
    obtain ⟨hdlo, hdhi⟩ := Finset.mem_Icc.mp hdI
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨?_, hdhi⟩, hdrough⟩, hdprime⟩
    have hf : 1 ≤ ⌊x⌋₊ := Nat.le_floor (by simpa using hx.le)
    omega
  · intro d hdiff
    obtain ⟨hd, hnot⟩ := Finset.mem_sdiff.mp hdiff
    obtain ⟨hdr, hdprime⟩ := Finset.mem_filter.mp hd
    obtain ⟨hdI, hdrough⟩ := Finset.mem_filter.mp hdr
    have hdhi := (Finset.mem_Icc.mp hdI).2
    have hdlo : d ≤ ⌊x⌋₊ := by
      by_contra hn
      apply hnot
      exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨by omega, hdhi⟩, hdprime, hdrough⟩
    have hdx : (d : ℝ) ≤ x := (by exact_mod_cast hdlo : (d : ℝ) ≤ ⌊x⌋₊).trans
      (Nat.floor_le (by linarith))
    have hΨ : smoothWeight x d = 0 := by
      by_contra hn
      have hh := PositiveBump.weight_support hn
      have hdgt : x < (d : ℝ) := by simpa using (lt_div_iff₀ (by linarith : 0 < x)).mp hh.1
      linarith
    simp [integerWeight, ConcreteSelector.arithmeticWeight, hΨ]
  · intro d hd
    rfl

/-- Full harmonic mass has the required logarithmic lower bound.  The
coefficient is chosen before every cofactor parameter, from ordinary
undeleted Mertens and logarithmic-moment estimates. -/
theorem actual_harmonic_mass_lower {ι : Type*}
    (I : Finset ι) (a : ι → ℝ) (B v₀ c₀ Y₀ : ℝ)
    (hv₀ : 0 < v₀) (hc₀ : 0 < c₀) (hY₀ : 1 < Y₀)
    (hinj : Set.InjOn a (I : Set ι))
    (hclassical : ∀ᶠ x : ℝ in atTop, ∀ i ∈ I,
      v₀ ≤ bandMass (a i) x ∧ bandMass (a i) x ≤ B)
    (hmertens : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c₀ * Real.log Z / Real.log Y ≤
        ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ)))
    (hlogmoment : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
        Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ (4 / 3 : ℝ) * Real.log Z) :
    ∃ d : ℝ, 0 < d ∧ ∀ ε : ℝ, 0 < ε → ∀ τ : ℝ, 0 < τ →
      ∀ Y : ℝ, Y₀ ≤ Y → 10 / τ ≤ Y → ∀ᶠ x : ℝ in atTop,
        d * ε * Real.log x / Real.log Y ≤ fullMass I a ε Y τ x := by
  obtain ⟨d, hd, hmass⟩ := CofactorAsymptotics.uniform_mass_lower_from_classical
    (markedPrimes I a) c₀ (I.card * B) Y₀ hc₀ hY₀
    (markedPrimes_mass_le I a B (hclassical.mono (fun x hx i hi => (hx i hi).2)))
    hmertens hlogmoment
  obtain ⟨C, hC, hmarked⟩ := MarkedBandTail.actual_bands_mass_bounds I a B v₀
    hv₀ hinj hclassical
  refine ⟨d, hd, ?_⟩
  intro ε hε τ hτ Y hY hYτ
  filter_upwards [hmass ε hε τ hτ Y hY hYτ, hmarked, hclassical,
    eventually_ge_atTop (1 : ℝ)] with x hmassx hmarkedx hVx hx
  have hV : ∀ i ∈ I, 0 < bandMass (a i) x := fun i hi => hv₀.trans_le (hVx i hi).1
  have hH := ManuscriptMassLower.scaleMass_ge_one hε.le hτ.le hx (marked := markedPrimes I a)
    (Y := Y)
  unfold fullMass
  rw [full_mass_eq I a ε Y τ x hV]
  have hh := mul_le_mul_of_nonneg_right hmarkedx.1 (by linarith :
    0 ≤ CofactorAsymptotics.scaleMass (markedPrimes I a) ε Y τ x)
  exact hmassx.trans (by simpa only [one_mul, markedPrimes, marking] using hh)

/-- Explicitly choose the manuscript's strictly ordered exponents after
fixing the number of marked groups. This also proves the band family exists. -/
noncomputable def standardBands (K : ℕ) : Bands K where
  exponent i := 1 / 10 + ((i.val : ℝ) + 1) / (10 * ((K : ℝ) + 1))
  increasing := by
    intro i j hij
    have hij' : (i.val : ℝ) < j.val := by exact_mod_cast hij
    have hf : ((i.val : ℝ) + 1) / (10 * ((K : ℝ) + 1)) <
        ((j.val : ℝ) + 1) / (10 * ((K : ℝ) + 1)) :=
      div_lt_div_of_pos_right (by linarith) (by positivity)
    dsimp only
    linarith
  lower := by
    intro i
    have hp : 0 < ((i.val : ℝ) + 1) / (10 * ((K : ℝ) + 1)) := by positivity
    linarith
  upper := by
    intro i
    have hi : (i.val : ℝ) < K := by exact_mod_cast i.isLt
    have hd : 0 < 10 * ((K : ℝ) + 1) := by positivity
    have hf : ((i.val : ℝ) + 1) / (10 * ((K : ℝ) + 1)) < 1 / 10 := by
      apply (div_lt_iff₀ hd).mpr
      linarith
    linarith

/-- The fixed marking bound used only when removing the weights. -/
noncomputable def weightBound (K : ℕ) : ℝ :=
  ∏ _i ∈ (Finset.univ : Finset (Fin K)), 1 / (Real.log 2 / 2)

theorem weightBound_pos (K : ℕ) : 0 < weightBound K := by
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  exact Finset.prod_pos (fun _ _ => by positivity)

/-- Assemble every actual arithmetic field of `CandidateSieveData`.  The
rough estimate and semiprime estimate are intermediate premises here, not
accepted sources; the next reduction supplies the latter from its checked
source-derived theorem. -/
theorem candidate_data_of_actual_estimates
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    (hbands : ClassicalBandMass) (hbandUpper : ManuscriptSemiprime.ClassicalBandUpperMass)
    {base : ℤ} (D : NonresidueProgression.Progression base)
    {M₀ v : ℕ} [NeZero M₀] (hM : D.M = D.c * M₀) (hu : D.u = D.c * v + 1)
    (hv : v.Coprime M₀) {K : ℕ} (b : Bands K)
    {S C₂ κ d ε Y τ : ℝ} (hC₂ : 0 ≤ C₂)
    (hε : 0 < ε) (hεmax : ε ≤ 1 / 100) (hY : (M₀ : ℝ) ≤ Y)
    (e : ℝ → ℝ) (he : Tendsto e atTop (𝓝 0))
    (hrough : ∀ᶠ x : ℝ in atTop,
      ((3 / 4 : ℝ) * S - e x) *
        (baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x) ≤
      roughMass Finset.univ b.exponent D.c D.M D.u ε Y τ κ x)
    (hsemi : ∀ᶠ x : ℝ in atTop,
      SemiprimeCover.roughCompositeMass x κ
        (ManuscriptSemiprime.weight b D.c D.M D.u ε Y τ x) ≤
      C₂ * κ * baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x)
    (hJ : ∀ᶠ x : ℝ in atTop,
      d * ε * Real.log x / Real.log Y ≤ fullMass Finset.univ b.exponent ε Y τ x) :
    Nonempty (CandidateSieveData base S C₂ κ (lowerConstant D.c M₀) d (weightBound K) ε Y) := by
  classical
  have hc : 2 ≤ D.c := by rcases D.c_choice with h | h <;> omega
  have hu' : D.c * v + 1 < D.c * M₀ := by simpa only [hM, hu] using D.u_lt_M
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hb := ManuscriptSemiprime.classical_band_bounds hbands hbandUpper b
  have hVp : ∀ᶠ x : ℝ in atTop, ∀ i ∈ (Finset.univ : Finset (Fin K)),
      0 < bandMass (b.exponent i) x :=
    hb.mono (fun x hx i hi => (by positivity : 0 < Real.log 2 / 2).trans_le (hx i hi).1)
  have hnonneg : ∀ᶠ x : ℝ in atTop,
      0 ≤ baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x := by
    filter_upwards [hVp] with x hV
    exact Finset.sum_nonneg (fun n hn => integerWeight_nonneg _ _ _ _ _ _ _ _ _ hV n)
  have hmass := actual_full_mass_comparison hPNT hc hu' hv Finset.univ b.exponent
    (1 / 10) (1 / 5) (2 * Real.log 2) (Real.log 2 / 2) (by norm_num) (by norm_num)
    (by positivity) (ManuscriptSemiprime.band_exponent_bounds b)
    (ManuscriptSemiprime.band_exponent_injective b) hb ε hε hεmax Y hY τ
  have htail := ManuscriptTail.actual_discardedMass_le_base_over_log_power hPNT hc hu' hv
    Finset.univ b.exponent (1 / 10) (1 / 5) (2 * Real.log 2) (Real.log 2 / 2)
    (by norm_num) (by norm_num) (by positivity) (ManuscriptSemiprime.band_exponent_bounds b)
    (ManuscriptSemiprime.band_exponent_injective b) hb 2 1 (by norm_num) ε hε hεmax Y hY τ
  rw [← hM, ← hu] at hmass htail
  refine ⟨{
    primes := fun x => survivors base Finset.univ b.exponent D.c ε Y τ x
    weights := fun x => integerWeight Finset.univ b.exponent D.c D.M D.u ε Y τ x
    mainMass := fun x => baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x
    harmonicMass := fun x => fullMass Finset.univ b.exponent ε Y τ x
    roughMass := fun x => roughMass Finset.univ b.exponent D.c D.M D.u ε Y τ κ x
    semiprimeMass := fun x => roughCompositeMass Finset.univ b.exponent D.c D.M D.u ε Y τ κ x
    tailMass := fun x => ManuscriptTail.discardedMass Finset.univ b.exponent D.c D.M D.u ε Y τ x
    roughError := e
    semiprimeError := fun _ => 0
    tailError := fun x => 1 / Real.log x
    roughError_zero := he
    semiprimeError_zero := tendsto_const_nhds
    tailError_zero := by simpa only [one_div, Function.comp_def] using tendsto_inv_atTop_zero.comp Real.tendsto_log_atTop
    mainMass_nonneg := hnonneg
    weights_bounded := ?_
    support := ?_
    rough_lower := hrough
    semiprime_upper := ?_
    tail_upper := ?_
    cover := ?_
    mainMass_lower := ?_
    harmonicMass_lower := hJ }⟩
  · filter_upwards [hb] with x hV p hp
    exact integerWeight_uniform_bound Finset.univ b.exponent D.c D.M D.u ε Y τ x
      (Real.log 2 / 2) (by positivity) (fun i hi => (hV i hi).1) p
  · exact eventually_survivors_support D Finset.univ b.exponent (1 / 10) (1 / 5)
      (by norm_num) (by norm_num) (ManuscriptSemiprime.band_exponent_bounds b) ε Y τ
      ((by positivity : (0 : ℝ) ≤ M₀).trans hY)
  · filter_upwards [hsemi, hnonneg, eventually_gt_atTop (1 : ℝ)] with x hs hn hx
    rw [composite_mass_eq _ _ _ _ _ _ _ _ _ hx, ← semiprime_weight_eq] 
    have hL : 0 < Real.log x := Real.log_pos hx
    have hbase : 0 ≤ baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x :=
      div_nonneg hn hL.le
    have hcL : 0 ≤ C₂ / Real.log x := div_nonneg hC₂ hL.le
    have hh := mul_nonneg hcL hbase
    calc
      _ ≤ C₂ * κ * baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x := hs
      _ ≤ _ := by
        have heq : (C₂ * (κ + 1 / Real.log x) + 0) *
            (baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x) =
            C₂ * κ * baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x +
            C₂ / Real.log x * (baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x) := by ring
        rw [heq]
        exact le_add_of_nonneg_right hh
  · filter_upwards [htail] with x hx
    simp only [one_mul, Real.rpow_two] at hx
    convert hx using 1 <;> ring
  · exact (eventually_rough_prime_composite_tail_cover D Finset.univ b.exponent
      (1 / 10) (1 / 5) (by norm_num) (by norm_num) (ManuscriptSemiprime.band_exponent_bounds b)
      hVp ε Y τ hεmax).mono (fun x hx => hx κ)
  · filter_upwards [hmass] with x hx
    convert hx.1 using 1 <;> ring

/-- Source-derived reduction to the one remaining actual rough lower
bound.  In particular, no semiprime, tail, support, main-mass or harmonic-mass
estimate is assumed. All counting constants precede `ε,Y` and hence `N`.
This is a reduction, not an assertion that the rough lower bound holds. -/
theorem candidate_reduction_from_sources
    (h102 : SourceLemma10_2) (h103 : SourceProposition10_3)
    (h11 : BuchstabSieve.SourceLemma11_1)
    (hbands : ClassicalBandMass) (hbandUpper : ManuscriptSemiprime.ClassicalBandUpperMass)
    (hFourier : ClassicalFourierInversion)
    (hBlock : RoughPairNormalization.ClassicalPrimeBlockBound)
    (hMertensUpper : RoughPairNormalization.ClassicalMertensUpper)
    (hMertensLower : RoughCompanion.ClassicalMertensLower)
    (hDiv : RoughPairNormalization.ClassicalDivisorSquareMoment)
    (hPNT : PrimeDistribution.FixedModulusPNTSource)
    {base : ℤ} (D : NonresidueProgression.Progression base)
    (c₀ Y₀ : ℝ) (hc₀ : 0 < c₀) (hY₀ : 1 < Y₀)
    (hmertens : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      c₀ * Real.log Z / Real.log Y ≤
        ∏ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z, (1 + 1 / (p : ℝ)))
    (hlogmoment : ∀ Y : ℝ, Y₀ ≤ Y → ∀ᶠ Z : ℝ in atTop,
      (∑ p ∈ CofactorAsymptotics.unmarkedPrimes ∅ Y Z,
        Real.log (p : ℝ) / ((p : ℝ) + 1)) ≤ (4 / 3 : ℝ) * Real.log Z) :
    ∃ C₂ : ℝ, 0 < C₂ ∧ ∃ K₀ : ℕ, 1 ≤ K₀ ∧
      ∀ K : ℕ, K₀ ≤ K → ∀ b : Bands K,
      ∃ c d B : ℝ, 0 < c ∧ 0 < d ∧ 0 < B ∧
      ∀ κ : ℝ, 0 < κ → κ ≤ 1 / 100 →
      ∀ τ : ℝ, 0 < τ → τ ≤ 1 →
      ∀ ε : ℝ, 0 < ε → ε ≤ 1 / 100 →
      ∀ Y : ℝ, Y₀ ≤ Y → (D.M : ℝ) ≤ Y → 10 / τ ≤ Y →
      ∀ S : ℝ, ∀ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) →
      (∀ᶠ x : ℝ in atTop,
        ((3 / 4 : ℝ) * S - e x) *
          (baseMass Finset.univ b.exponent D.c D.M D.u ε Y τ x / Real.log x) ≤
        roughMass Finset.univ b.exponent D.c D.M D.u ε Y τ κ x) →
      Nonempty (CandidateSieveData base S C₂ κ c d B ε Y) := by
  obtain ⟨M₀, v, hM, hu, hvlt, hv⟩ := D.normal_form
  have hM₀ : 0 < M₀ := by
    have hp := D.M_pos
    rw [hM] at hp
    exact Nat.pos_of_mul_pos_left hp
  let : NeZero M₀ := ⟨hM₀.ne'⟩
  have hc : 2 ≤ D.c := by rcases D.c_choice with h | h <;> omega
  have hu' : D.c * v + 1 < D.c * M₀ := by simpa only [hM, hu] using D.u_lt_M
  have hunit : (D.c * v + 1).Coprime (D.c * M₀) := by simpa only [hM, hu] using D.unit
  obtain ⟨C₂, hC₂, K₀, hK₀, hs⟩ := ManuscriptSemiprime.actual_semiprime_upper
    h102 h103 h11 hbands hbandUpper hFourier hBlock hMertensUpper hMertensLower hDiv
    hPNT D.c_choice hu' hv hunit
  refine ⟨C₂, hC₂, K₀, hK₀, ?_⟩
  intro K hK b
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hb := ManuscriptSemiprime.classical_band_bounds hbands hbandUpper b
  obtain ⟨d, hd, hJ⟩ := actual_harmonic_mass_lower Finset.univ b.exponent
    (2 * Real.log 2) (Real.log 2 / 2) c₀ Y₀ (by positivity) hc₀ hY₀
    (ManuscriptSemiprime.band_exponent_injective b) hb hmertens hlogmoment
  refine ⟨lowerConstant D.c M₀, d, weightBound K,
    (constants_positive D.c M₀ (by omega) hM₀).1, hd, weightBound_pos K, ?_⟩
  intro κ hκ hκmax τ hτ hτmax ε hε hεmax Y hY hYM hYτ S e he hr
  have hM₀M : M₀ ≤ D.M := by rw [hM]; nlinarith
  have hYM₀ : (M₀ : ℝ) ≤ Y := (by exact_mod_cast hM₀M : (M₀ : ℝ) ≤ D.M).trans hYM
  have hsemi := hs K hK b κ hκ hκmax ε hε hεmax Y hYM₀ τ hτ hτmax
  rw [← hM, ← hu] at hsemi
  exact candidate_data_of_actual_estimates hPNT hbands hbandUpper D hM hu hv b hC₂.le
    hε hεmax hYM₀ e he hr hsemi (hJ ε hε τ hτ Y hY hYτ)

end Artin.ManuscriptCandidateAssembly
