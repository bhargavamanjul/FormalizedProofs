module

public import Artin.MarkedReplacement
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Tactic.GCongr

/-!
# Twisting the source coefficient criterion

`CoefficientCancellation` is the normalized character-transform hypothesis
(10.6) of the cited Artin paper's Lemma 10.2, with its quantification over every
fixed modulus exponent, frequency exponent, and accuracy, and with uniformity
in all subintervals. It is a predicate, not an axiom or a proof of cancellation.
The lemmas here verify the fixed-character and archimedean twisting operations
used to adapt that source criterion to a fixed arithmetic progression.
-/

open scoped BigOperators
open Filter
open Artin.MarkedReplacement
@[expose] public section
namespace Artin.MarkedCriterion

/-- The normalized-transform bound from the source, written without division
by the dyad scale. Positivity of that scale is imposed by its application. -/
def CoefficientCancellation (α : ℝ → ℕ → ℂ) (Hm X : ℝ → ℝ) : Prop :=
  ∀ A₀ B A : ℝ, 0 < A₀ → 0 < B → 0 < A →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ lo hi k : ℕ, Hm x ≤ lo → (hi : ℝ) ≤ 2 * Hm x →
      0 < k → (k : ℝ) ≤ (Real.log x) ^ A₀ →
      ∀ χ : DirichletCharacter ℂ k, ∀ t : ℝ,
      |t| ≤ 2 * X x * (Real.log x) ^ B →
      ‖∑ n ∈ Finset.Icc lo hi, α x n * χ (n : ZMod k) * archimedeanPhase t n‖ ≤
        C * Hm x * (Real.log x) ^ (-A)

/-- Enlarging the logarithmic modulus exponent by one absorbs the fixed
progression modulus. No constant here depends on the varying character. -/
theorem logarithmic_lcm_bound {M k : ℕ} {L A₀ : ℝ}
    (hL : 0 < L) (hM : (M : ℝ) ≤ L) (hk : (k : ℝ) ≤ L ^ A₀) :
    (Nat.lcm M k : ℝ) ≤ L ^ (A₀ + 1) := by
  have hprod : (Nat.lcm M k : ℝ) ≤ (M : ℝ) * k := by
    exact_mod_cast lcm_modulus_le M k
  calc
    _ ≤ (M : ℝ) * k := hprod
    _ ≤ L * L ^ A₀ := mul_le_mul hM hk (Nat.cast_nonneg _) hL.le
    _ = L ^ (A₀ + 1) := by rw [Real.rpow_add_one hL.ne']; ring

/-- A shift of size at most `L` is absorbed by increasing the source frequency
exponent by one. -/
theorem logarithmic_frequency_shift {L X B t v : ℝ}
    (hL : 2 ≤ L) (hX : 1 ≤ X) (hB : 0 ≤ B)
    (ht : |t| ≤ 2 * X * L ^ B) (hv : |v| ≤ L) :
    |t + v| ≤ 2 * X * L ^ (B + 1) := by
  have hL₀ : 0 < L := by linarith
  have hp : 1 ≤ L ^ B := Real.one_le_rpow (by linarith) hB
  have hXp : 1 ≤ X * L ^ B := one_le_mul_of_one_le_of_one_le hX hp
  calc
    |t + v| ≤ |t| + |v| := abs_add_le _ _
    _ ≤ 2 * X * L ^ B + L := add_le_add ht hv
    _ ≤ 2 * X * L ^ (B + 1) := by
      rw [Real.rpow_add_one hL₀.ne']
      nlinarith

/-- The phases combine by adding frequencies. -/
theorem archimedeanPhase_add (v t : ℝ) (n : ℕ) :
    archimedeanPhase (v+t) n = archimedeanPhase v n * archimedeanPhase t n := by
  unfold archimedeanPhase
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

/-- On units of the common modulus, mathlib's product character has exactly
the required pointwise value. -/
theorem product_character_apply {M k n : ℕ}
    (χ : DirichletCharacter ℂ M) (ψ : DirichletCharacter ℂ k)
    (hn : Nat.Coprime n (Nat.lcm M k)) :
    χ.mul ψ (n : ZMod (Nat.lcm M k)) = χ (n : ZMod M) * ψ (n : ZMod k) := by
  have hχ := DirichletCharacter.changeLevel_eq_cast_of_dvd χ
    (Nat.dvd_lcm_left M k) (ZMod.unitOfCoprime n hn)
  have hψ := DirichletCharacter.changeLevel_eq_cast_of_dvd ψ
    (Nat.dvd_lcm_right M k) (ZMod.unitOfCoprime n hn)
  simp only [ZMod.coe_unitOfCoprime] at hχ hψ
  rw [ZMod.cast_natCast (Nat.dvd_lcm_left M k)] at hχ
  rw [ZMod.cast_natCast (Nat.dvd_lcm_right M k)] at hψ
  simp only [DirichletCharacter.mul, MulChar.mul_apply, hχ, hψ]

/-- The actual twisted character transform is an untwisted transform at the
product character and shifted frequency. It suffices to know coprimality only
where the coefficient is nonzero. -/
theorem twisted_transform_eq {M k : ℕ} (s : Finset ℕ) (α : ℕ → ℂ)
    (χ : DirichletCharacter ℂ M) (ψ : DirichletCharacter ℂ k) (v t : ℝ)
    (hunit : ∀ n ∈ s, α n ≠ 0 → Nat.Coprime n (Nat.lcm M k)) :
    (∑ n ∈ s, ((α n * χ (n : ZMod M)) * archimedeanPhase v n) *
      ψ (n : ZMod k) * archimedeanPhase t n) =
    ∑ n ∈ s, α n * χ.mul ψ (n : ZMod (Nat.lcm M k)) * archimedeanPhase (t+v) n := by
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hα : α n = 0
  · simp [hα]
  rw [product_character_apply χ ψ (hunit n hn hα), archimedeanPhase_add]
  ring

/-- Rough support ensures that every logarithmic modulus is a unit modulus
on the nonzero coefficients once that modulus is below the roughness cutoff. -/
theorem rough_coprime {n k : ℕ} {W : ℝ} (hk : 0 < k) (hkW : (k : ℝ) ≤ W)
    (hn : ∀ p : ℕ, p.Prime → p ∣ n → W < (p : ℝ)) : Nat.Coprime n k := by
  apply Nat.coprime_of_dvd
  intro p hp hpn hpk
  have hpk' : (p : ℝ) ≤ k := by exact_mod_cast Nat.le_of_dvd hk hpk
  exact (not_lt_of_ge (hpk'.trans hkW)) (hn p hp hpn)

/-- The unit-support fact needed by logarithmic-modulus twists. For rough
coefficients this follows from their prime-divisor support and the growth of
`W`; it is an arithmetic condition, not a cancellation estimate. -/
def EventuallyUnitSupport (α : ℝ → ℕ → ℂ) : Prop :=
  ∀ A₀ : ℝ, 0 < A₀ → ∀ᶠ x : ℝ in atTop,
    ∀ n k : ℕ, α x n ≠ 0 → 0 < k → (k : ℝ) ≤ (Real.log x) ^ A₀ → Nat.Coprime n k

/-- Source cancellation after every fixed-modulus character twist and every
archimedean shift of size at most `log x`, with one common constant and threshold
for all those twists and all coefficient subintervals. -/
def UniformTwistedCancellation (α : ℝ → ℕ → ℂ) (Hm X : ℝ → ℝ) (M : ℕ) : Prop :=
  ∀ A₀ B A : ℝ, 0 < A₀ → 0 < B → 0 < A →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ χ : DirichletCharacter ℂ M, ∀ v : ℝ, |v| ≤ Real.log x →
      ∀ lo hi k : ℕ, Hm x ≤ lo → (hi : ℝ) ≤ 2 * Hm x →
      0 < k → (k : ℝ) ≤ (Real.log x) ^ A₀ →
      ∀ ψ : DirichletCharacter ℂ k, ∀ t : ℝ,
      |t| ≤ 2 * X x * (Real.log x) ^ B →
      ‖∑ n ∈ Finset.Icc lo hi,
        ((α x n * χ (n : ZMod M)) * archimedeanPhase v n) *
          ψ (n : ZMod k) * archimedeanPhase t n‖ ≤
        C * Hm x * (Real.log x) ^ (-A)

/-- The actual quantifier-preserving adaptation of (10.6): both source
exponents are enlarged by one before applying the source estimate. Neither
the accuracy nor the constant is allowed to vary with the selector or twist. -/
theorem coefficient_cancellation_twist {α : ℝ → ℕ → ℂ} {Hm X : ℝ → ℝ} {M : ℕ}
    (hM : 0 < M) (hsource : CoefficientCancellation α Hm X)
    (hunit : EventuallyUnitSupport α) (hX : ∀ᶠ x : ℝ in atTop, 1 ≤ X x) :
    UniformTwistedCancellation α Hm X M := by
  intro A₀ B A hA₀ hB hA
  obtain ⟨C, hC, hcan⟩ := hsource (A₀+1) (B+1) A (by linarith) (by linarith) hA
  have hu := hunit (A₀+1) (by linarith)
  have hL : ∀ᶠ x : ℝ in atTop, max (M : ℝ) 2 ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop _)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hcan, hu, hX, hL] with x hcanx hux hXx hLx
  intro χ v hv lo hi k hlo hhi hk hkL ψ t ht
  have hL₂ : 2 ≤ Real.log x := (le_max_right _ _).trans hLx
  have hML : (M : ℝ) ≤ Real.log x := (le_max_left _ _).trans hLx
  have hq : 0 < Nat.lcm M k := Nat.pos_of_ne_zero (Nat.lcm_ne_zero hM.ne' hk.ne')
  have hqL := logarithmic_lcm_bound (by linarith : 0 < Real.log x) hML hkL
  rw [twisted_transform_eq (Finset.Icc lo hi) (α x) χ ψ v t
    (fun n _ hn => hux n (Nat.lcm M k) hn hq hqL)]
  exact hcanx lo hi (Nat.lcm M k) hlo hhi hq hqL (χ.mul ψ) (t+v)
    (logarithmic_frequency_shift hL₂ hXx hB.le ht hv)

/-- Recover unit support directly from roughness and the fact that the
roughness cutoff eventually dominates each fixed power of `log x`. -/
theorem eventually_unit_support_of_rough {α : ℝ → ℕ → ℂ} {W : ℝ → ℝ}
    (hrough : ∀ᶠ x : ℝ in atTop, ∀ n : ℕ, α x n ≠ 0 →
      ∀ p : ℕ, p.Prime → p ∣ n → W x < (p : ℝ))
    (hW : ∀ A₀ : ℝ, 0 < A₀ → ∀ᶠ x : ℝ in atTop, (Real.log x) ^ A₀ ≤ W x) :
    EventuallyUnitSupport α := by
  intro A₀ hA₀
  filter_upwards [hrough, hW A₀ hA₀] with x hroughx hWx
  intro n k hn hk hkL
  exact rough_coprime hk (hkL.trans hWx) (hroughx n hn)

/-- Every fixed logarithmic modulus lies below the actual rough cutoff.
This is proved from mathlib's exponential-versus-power limit. -/
theorem logarithmic_power_le_rough_cutoff (A κ : ℝ) (hκ : 0 < κ) :
    ∀ᶠ x : ℝ in atTop, (Real.log x) ^ A ≤ Real.exp ((Real.log x) ^ κ) := by
  have hlim := (tendsto_exp_div_rpow_atTop (A / κ)).comp
    ((tendsto_rpow_atTop hκ).comp Real.tendsto_log_atTop)
  have he : ∀ᶠ x : ℝ in atTop,
      1 ≤ Real.exp ((Real.log x) ^ κ) / ((Real.log x) ^ κ) ^ (A / κ) :=
    hlim.eventually (eventually_ge_atTop 1)
  have hL : ∀ᶠ x : ℝ in atTop, 0 < Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_gt_atTop 0)
  filter_upwards [he, hL] with x hex hLx
  have hp : 0 < ((Real.log x) ^ κ) ^ (A / κ) :=
    Real.rpow_pos_of_pos (Real.rpow_pos_of_pos hLx κ) _
  have h := (le_div_iff₀ hp).mp hex
  have hid : ((Real.log x) ^ κ) ^ (A / κ) = (Real.log x) ^ A := by
    rw [← Real.rpow_mul hLx.le]
    congr 1
    field_simp
  simpa only [one_mul, hid] using h

/-- The rough cutoff is also eventually below every fixed positive power of
`x`, as needed to support the discrepancy on `W`-rough integers. -/
theorem rough_cutoff_le_power {κ γ : ℝ} (hκ : κ < 1) (hγ : 0 < γ) :
    ∀ᶠ x : ℝ in atTop, Real.exp ((Real.log x) ^ κ) ≤ x ^ γ := by
  have hlim := (tendsto_rpow_neg_atTop (by linarith : 0 < 1 - κ)).comp
    Real.tendsto_log_atTop
  have he : ∀ᶠ x : ℝ in atTop, (Real.log x) ^ (-(1 - κ)) < γ :=
    (tendsto_order.1 hlim).2 γ hγ
  have hx : ∀ᶠ x : ℝ in atTop, 1 < x := eventually_gt_atTop 1
  filter_upwards [he, hx] with x hex hxx
  have hL : 0 < Real.log x := Real.log_pos hxx
  have hx₀ : 0 < x := by linarith
  have he' : (Real.log x) ^ κ / Real.log x < γ := by
    calc
      (Real.log x) ^ κ / Real.log x = (Real.log x) ^ (κ - 1) := by
        rw [Real.rpow_sub hL, Real.rpow_one]
      _ < γ := by simpa only [neg_sub] using hex
  rw [Real.rpow_def_of_pos hx₀]
  apply Real.exp_le_exp.mpr
  have h := (div_lt_iff₀ hL).mp he'
  nlinarith

/-- The rough-indicator convention, including `1`, whose prime-divisor
condition is vacuous. All coefficient dyads in the source are positive. -/
def IsRough (y : ℝ) (n : ℕ) : Prop :=
  ∀ p : ℕ, p.Prime → p ∣ n → y < (p : ℝ)

noncomputable def roughIndicator (y : ℝ) (n : ℕ) : ℂ := by
  classical
  exact if IsRough y n then 1 else 0

/-- The actual difference of rough sequences in (10.13), before the phase
and interval restrictions. `density` is the cited continuous density `Dγ` and
`V` is the classical rough-number Euler product; neither is estimated here. -/
noncomputable def roughDiscrepancy (density V : ℝ → ℝ) (γ κ x : ℝ) (n : ℕ) : ℂ :=
  roughIndicator (x ^ γ) n -
    ((density (Real.log n / Real.log x) /
      (Real.log x * V (Real.exp ((Real.log x) ^ κ))) : ℝ) : ℂ) *
      roughIndicator (Real.exp ((Real.log x) ^ κ)) n

theorem roughDiscrepancy_support (density V : ℝ → ℝ) (γ κ x : ℝ) (n : ℕ)
    (hcutoff : Real.exp ((Real.log x) ^ κ) ≤ x ^ γ)
    (hn : roughDiscrepancy density V γ κ x n ≠ 0) :
    IsRough (Real.exp ((Real.log x) ^ κ)) n := by
  classical
  by_contra hrough
  have hrough' : ¬ IsRough (x ^ γ) n := by
    intro h
    apply hrough
    intro p hp hpn
    exact hcutoff.trans_lt (h p hp hpn)
  simp [roughDiscrepancy, roughIndicator, hrough, hrough'] at hn

/-- Unit support for the precise rough discrepancy, including the source's
cutoff `κ = 0.24`. No cancellation theorem is used in this deduction. -/
theorem roughDiscrepancy_unit_support (density V : ℝ → ℝ) {γ κ : ℝ}
    (hγ : 0 < γ) (hκ₀ : 0 < κ) (hκ₁ : κ < 1) :
    EventuallyUnitSupport (roughDiscrepancy density V γ κ) := by
  apply eventually_unit_support_of_rough (W := fun x => Real.exp ((Real.log x) ^ κ))
  · filter_upwards [rough_cutoff_le_power hκ₁ hγ] with x hx
    intro n hn
    exact roughDiscrepancy_support density V γ κ x n hx hn
  · intro A₀ _hA₀
    exact logarithmic_power_le_rough_cutoff A₀ κ hκ₀

/-- This is the precise adaptation of the transform result proved inside
Proposition 10.3. The accepted source input is its full character-transform
cancellation statement, not the desired marked bilinear conclusion. -/
theorem rough_discrepancy_uniform_twists (density V : ℝ → ℝ)
    {γ κ : ℝ} {Hm X : ℝ → ℝ} {M : ℕ}
    (hγ : 0 < γ) (hκ₀ : 0 < κ) (hκ₁ : κ < 1) (hM : 0 < M)
    (hsource : CoefficientCancellation (roughDiscrepancy density V γ κ) Hm X)
    (hX : ∀ᶠ x : ℝ in atTop, 1 ≤ X x) :
    UniformTwistedCancellation (roughDiscrepancy density V γ κ) Hm X M :=
  coefficient_cancellation_twist hM hsource
    (roughDiscrepancy_unit_support density V hγ hκ₀ hκ₁) hX

/-- A fixed character and any permitted varying frequency retain the
source's coefficient criterion. The stronger preceding theorem records that
the constants are uniform across the entire collection of twists. -/
theorem twisted_coefficient_cancellation {α : ℝ → ℕ → ℂ} {Hm X : ℝ → ℝ}
    {M : ℕ} (h : UniformTwistedCancellation α Hm X M)
    (χ : DirichletCharacter ℂ M) (v : ℝ → ℝ)
    (hv : ∀ᶠ x : ℝ in atTop, |v x| ≤ Real.log x) :
    CoefficientCancellation
      (fun x n => (α x n * χ (n : ZMod M)) * archimedeanPhase (v x) n) Hm X := by
  intro A₀ B A hA₀ hB hA
  obtain ⟨C, hC, hc⟩ := h A₀ B A hA₀ hB hA
  refine ⟨C, hC, ?_⟩
  filter_upwards [hc, hv] with x hx hvx
  exact hx χ (v x) hvx

/-- The coefficient supremum bound, another explicit hypothesis of Lemma
10.2, is preserved without any loss under both twists. -/
theorem twisted_coefficient_norm {M : ℕ} (χ : DirichletCharacter ℂ M)
    (α : ℕ → ℂ) (v : ℝ) (n : ℕ) :
    ‖(α n * χ (n : ZMod M)) * archimedeanPhase v n‖ ≤ ‖α n‖ := by
  rw [norm_mul, archimedeanPhase_norm, mul_one, norm_mul]
  simpa using mul_le_mul_of_nonneg_left (χ.norm_le_one _) (norm_nonneg (α n))

/-- Any support condition possessed by the original coefficient is preserved,
including its roughness and subinterval restrictions. -/
theorem twisted_coefficient_support {M : ℕ} (χ : DirichletCharacter ℂ M)
    (α : ℕ → ℂ) (v : ℝ) (P : ℕ → Prop)
    (hα : ∀ n, α n ≠ 0 → P n) (n : ℕ)
    (hn : (α n * χ (n : ZMod M)) * archimedeanPhase v n ≠ 0) : P n := by
  apply hα n
  intro hzero
  simp [hzero] at hn

end Artin.MarkedCriterion
