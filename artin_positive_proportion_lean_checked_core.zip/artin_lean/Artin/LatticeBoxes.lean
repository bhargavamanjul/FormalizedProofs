module

public import Mathlib.Data.Int.Interval
public import Mathlib.Algebra.Order.Archimedean.Real.Basic
public import Mathlib.Data.Nat.Totient
public import Mathlib.Data.Finset.Prod
public import Mathlib.Algebra.BigOperators.Group.Finset.Basic
public import Mathlib.Algebra.Order.BigOperators.Group.Finset
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.GCongr
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

/-!
# Counting residue classes in real boxes

The finite sets below consist of actual integer lattice points.  Ceiling
endpoints give the uniform boundary error; disjoint residue classes and CRT
then give the two-variable sieve's main term.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.LatticeBoxes

/-- Integers in the half-open interval with the specified residue. -/
noncomputable def residueInterval (q : ℕ) (a : ZMod q) (L U : ℝ) : Finset ℤ :=
  (Finset.Ico ⌈L⌉ ⌈U⌉).filter (fun n => (n : ZMod q) = a)

theorem mem_residueInterval {q : ℕ} {a : ZMod q} {L U : ℝ} {n : ℤ} :
    n ∈ residueInterval q a L U ↔ L ≤ (n : ℝ) ∧ (n : ℝ) < U ∧ (n : ZMod q) = a := by
  simp only [residueInterval, Finset.mem_filter, Finset.mem_Ico, Int.ceil_le, Int.lt_ceil]
  tauto

/-- The progression is a translate and dilation of an integer interval. -/
theorem residueInterval_eq_image (q : ℕ) [NeZero q] (a : ZMod q) (L U : ℝ) :
    residueInterval q a L U =
      (Finset.Ico ⌈(L - a.val) / q⌉ ⌈(U - a.val) / q⌉).image
        (fun t : ℤ => (a.val : ℤ) + q * t) := by
  classical
  have hq : (0 : ℝ) < q := by exact_mod_cast NeZero.pos q
  ext n
  rw [mem_residueInterval, Finset.mem_image]
  constructor
  · rintro ⟨hL, hU, ha⟩
    obtain ⟨t, rfl⟩ := (ZMod.intCast_eq_iff q n a).mp ha
    refine ⟨t, ?_, rfl⟩
    rw [Finset.mem_Ico, Int.ceil_le, Int.lt_ceil]
    push_cast at hL hU
    constructor
    · exact (div_le_iff₀ hq).mpr (by nlinarith)
    · exact (lt_div_iff₀ hq).mpr (by nlinarith)
  · rintro ⟨t, ht, rfl⟩
    rw [Finset.mem_Ico, Int.ceil_le, Int.lt_ceil] at ht
    have hL := (div_le_iff₀ hq).mp ht.1
    have hU := (lt_div_iff₀ hq).mp ht.2
    refine ⟨?_, ?_, (ZMod.intCast_eq_iff q _ a).mpr ⟨t, rfl⟩⟩ <;>
      push_cast <;> nlinarith

/-- A single residue has at most one point of boundary discrepancy. -/
theorem residueInterval_error (q : ℕ) [NeZero q] (a : ZMod q)
    {L U : ℝ} (hLU : L ≤ U) :
    |((residueInterval q a L U).card : ℝ) - (U - L) / q| ≤ 1 := by
  classical
  have hq : (0 : ℝ) < q := by exact_mod_cast NeZero.pos q
  have hi : Function.Injective (fun t : ℤ => (a.val : ℤ) + q * t) := by
    intro t s h
    exact mul_left_cancel₀ (by exact_mod_cast (NeZero.ne q)) (add_left_cancel h)
  rw [residueInterval_eq_image, Finset.card_image_of_injective _ hi]
  have hmono : ⌈(L - (a.val : ℝ)) / q⌉ ≤ ⌈(U - (a.val : ℝ)) / q⌉ :=
    Int.ceil_mono (div_le_div_of_nonneg_right (sub_le_sub_right hLU _) hq.le)
  have hc := Int.card_Ico_of_le _ _ hmono
  have hc' : ((Finset.Ico ⌈(L - (a.val : ℝ)) / q⌉
      ⌈(U - (a.val : ℝ)) / q⌉).card : ℝ) =
      (⌈(U - (a.val : ℝ)) / q⌉ : ℝ) - ⌈(L - (a.val : ℝ)) / q⌉ := by
    exact_mod_cast hc
  rw [hc']
  have hl := Int.le_ceil ((L - (a.val : ℝ)) / q)
  have hl' := Int.ceil_lt_add_one ((L - (a.val : ℝ)) / q)
  have hu := Int.le_ceil ((U - (a.val : ℝ)) / q)
  have hu' := Int.ceil_lt_add_one ((U - (a.val : ℝ)) / q)
  have hd : (U - L) / (q : ℝ) =
      (U - a.val) / q - (L - a.val) / q := by ring
  rw [hd, abs_le]
  constructor <;> linarith

/-- One residue rectangle. -/
noncomputable def residueBox (q : ℕ) (a : ZMod q × ZMod q)
    (L₁ U₁ L₂ U₂ : ℝ) : Finset (ℤ × ℤ) :=
  residueInterval q a.1 L₁ U₁ ×ˢ residueInterval q a.2 L₂ U₂

theorem mem_residueBox {q : ℕ} {a : ZMod q × ZMod q}
    {L₁ U₁ L₂ U₂ : ℝ} {n : ℤ × ℤ} :
    n ∈ residueBox q a L₁ U₁ L₂ U₂ ↔
      L₁ ≤ (n.1 : ℝ) ∧ (n.1 : ℝ) < U₁ ∧
      L₂ ≤ (n.2 : ℝ) ∧ (n.2 : ℝ) < U₂ ∧
      ((n.1 : ZMod q), (n.2 : ZMod q)) = a := by
  simp only [residueBox, Finset.mem_product, mem_residueInterval, Prod.ext_iff]
  tauto

/-- Multiplying two one-dimensional counts costs only perimeter plus one. -/
theorem product_error {a b u v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v)
    (ha : |a - u| ≤ 1) (hb : |b - v| ≤ 1) :
    |a * b - u * v| ≤ u + v + 1 := by
  have hid : a * b - u * v = (a - u) * v + (b - v) * u + (a - u) * (b - v) := by ring
  rw [hid]
  calc
    _ ≤ |(a - u) * v| + |(b - v) * u| + |(a - u) * (b - v)| :=
      (abs_add_le _ _).trans (add_le_add (abs_add_le _ _) le_rfl)
    _ = |a - u| * v + |b - v| * u + |a - u| * |b - v| := by
      rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg hu, abs_of_nonneg hv]
    _ ≤ 1 * v + 1 * u + 1 * 1 := by gcongr
    _ = u + v + 1 := by ring

theorem residueBox_error (q : ℕ) [NeZero q] (a : ZMod q × ZMod q)
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : L₁ ≤ U₁) (h₂ : L₂ ≤ U₂) :
    |((residueBox q a L₁ U₁ L₂ U₂).card : ℝ) -
      (U₁ - L₁) * (U₂ - L₂) / (q : ℝ) ^ 2| ≤
      ((U₁ - L₁) + (U₂ - L₂)) / q + 1 := by
  have hq : (0 : ℝ) ≤ q := Nat.cast_nonneg q
  have h := product_error (div_nonneg (sub_nonneg.mpr h₁) hq)
    (div_nonneg (sub_nonneg.mpr h₂) hq)
    (residueInterval_error q a.1 h₁) (residueInterval_error q a.2 h₂)
  simpa [residueBox, Finset.card_product, Nat.cast_mul, ← add_div,
    div_mul_div_comm, ← pow_two] using h

/-- The actual integer points with residue in a prescribed finite set. -/
noncomputable def boxPoints (q : ℕ) (s : Finset (ZMod q × ZMod q))
    (L₁ U₁ L₂ U₂ : ℝ) : Finset (ℤ × ℤ) :=
  s.biUnion (fun a => residueBox q a L₁ U₁ L₂ U₂)

theorem mem_boxPoints {q : ℕ} {s : Finset (ZMod q × ZMod q)}
    {L₁ U₁ L₂ U₂ : ℝ} {n : ℤ × ℤ} :
    n ∈ boxPoints q s L₁ U₁ L₂ U₂ ↔
      L₁ ≤ (n.1 : ℝ) ∧ (n.1 : ℝ) < U₁ ∧
      L₂ ≤ (n.2 : ℝ) ∧ (n.2 : ℝ) < U₂ ∧
      ((n.1 : ZMod q), (n.2 : ZMod q)) ∈ s := by
  classical
  simp only [boxPoints, Finset.mem_biUnion, mem_residueBox]
  constructor
  · rintro ⟨a, ha, h₁, h₂, h₃, h₄, rfl⟩
    exact ⟨h₁, h₂, h₃, h₄, ha⟩
  · rintro ⟨h₁, h₂, h₃, h₄, hs⟩
    exact ⟨_, hs, h₁, h₂, h₃, h₄, rfl⟩

theorem boxPoints_card (q : ℕ) (s : Finset (ZMod q × ZMod q))
    (L₁ U₁ L₂ U₂ : ℝ) :
    (boxPoints q s L₁ U₁ L₂ U₂).card =
      ∑ a ∈ s, (residueBox q a L₁ U₁ L₂ U₂).card := by
  classical
  apply Finset.card_biUnion
  intro a ha b hb hab
  apply Finset.disjoint_left.mpr
  intro n hna hnb
  have hna' := (mem_residueBox.mp hna).2.2.2.2
  have hnb' := (mem_residueBox.mp hnb).2.2.2.2
  exact hab (hna'.symm.trans hnb')

/-- Uniform lattice error for any residue set, proved by counting its actual
integer points. No distribution or sieve estimate is a hypothesis. -/
theorem boxPoints_error (q : ℕ) [NeZero q] (s : Finset (ZMod q × ZMod q))
    {L₁ U₁ L₂ U₂ : ℝ} (h₁ : L₁ ≤ U₁) (h₂ : L₂ ≤ U₂) :
    |((boxPoints q s L₁ U₁ L₂ U₂).card : ℝ) -
      s.card * ((U₁ - L₁) * (U₂ - L₂) / (q : ℝ) ^ 2)| ≤
      s.card * (((U₁ - L₁) + (U₂ - L₂)) / q + 1) := by
  classical
  rw [boxPoints_card, Nat.cast_sum]
  calc
    _ = |∑ a ∈ s, (((residueBox q a L₁ U₁ L₂ U₂).card : ℝ) -
        (U₁ - L₁) * (U₂ - L₂) / (q : ℝ) ^ 2)| := by
      rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]
    _ ≤ ∑ a ∈ s, |((residueBox q a L₁ U₁ L₂ U₂).card : ℝ) -
        (U₁ - L₁) * (U₂ - L₂) / (q : ℝ) ^ 2| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _a ∈ s, (((U₁ - L₁) + (U₂ - L₂)) / q + 1) := by
      exact Finset.sum_le_sum (fun a _ => residueBox_error q a h₁ h₂)
    _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul]

/-- Product-one pairs over any commutative ring are in bijection with units. -/
def productOneEquivUnits (R : Type*) [CommRing R] :
    {a : R × R // a.1 * a.2 = 1} ≃ Rˣ where
  toFun a := Units.mkOfMulEqOne a.1.1 a.1.2 a.2
  invFun u := ⟨(u, ↑u⁻¹), Units.mul_inv u⟩
  left_inv a := by apply Subtype.ext; rfl
  right_inv u := by apply Units.ext; rfl

theorem productOne_card (k : ℕ) [NeZero k] :
    Fintype.card {a : ZMod k × ZMod k // a.1 * a.2 = 1} = k.totient := by
  rw [Fintype.card_congr (productOneEquivUnits (ZMod k)), ZMod.card_units_eq_totient]

/-- CRT in two coordinates, with both projections recorded. -/
noncomputable def pairCRT {k ℓ : ℕ} (h : k.Coprime ℓ) :
    (ZMod (k * ℓ) × ZMod (k * ℓ)) ≃
      (ZMod k × ZMod k) × (ZMod ℓ × ZMod ℓ) :=
  ((ZMod.chineseRemainder h).toEquiv.prodCongr
    (ZMod.chineseRemainder h).toEquiv).trans (Equiv.prodProdProdComm _ _ _ _)

/-- The combined classes are the inverse CRT image of the Cartesian product. -/
noncomputable def crtResidues {k ℓ : ℕ} (h : k.Coprime ℓ)
    (s : Finset (ZMod k × ZMod k)) (t : Finset (ZMod ℓ × ZMod ℓ)) :
    Finset (ZMod (k * ℓ) × ZMod (k * ℓ)) :=
  (s ×ˢ t).map (pairCRT h).symm.toEmbedding

theorem crtResidues_card {k ℓ : ℕ} (h : k.Coprime ℓ)
    (s : Finset (ZMod k × ZMod k)) (t : Finset (ZMod ℓ × ZMod ℓ)) :
    (crtResidues h s t).card = s.card * t.card := by
  simp [crtResidues]

theorem mem_crtResidues {k ℓ : ℕ} (h : k.Coprime ℓ)
    {s : Finset (ZMod k × ZMod k)} {t : Finset (ZMod ℓ × ZMod ℓ)}
    {a : ZMod (k * ℓ) × ZMod (k * ℓ)} :
    a ∈ crtResidues h s t ↔ (pairCRT h a).1 ∈ s ∧ (pairCRT h a).2 ∈ t := by
  classical
  simp [crtResidues]

/-- The prescribed progression `mn = 1 (mod k)`. -/
noncomputable def productOneResidues (k : ℕ) [NeZero k] :
    Finset (ZMod k × ZMod k) := Finset.univ.filter (fun a => a.1 * a.2 = 1)

theorem productOneResidues_card (k : ℕ) [NeZero k] :
    (productOneResidues k).card = k.totient := by
  classical
  rw [← productOne_card k]
  exact (Fintype.card_subtype _).symm

theorem pairCRT_intCast {k ℓ : ℕ} (h : k.Coprime ℓ) (m n : ℤ) :
    pairCRT h ((m : ZMod (k * ℓ)), (n : ZMod (k * ℓ))) =
      (((m : ZMod k), (n : ZMod k)), ((m : ZMod ℓ), (n : ZMod ℓ))) := by
  change (((ZMod.chineseRemainder h (m : ZMod (k * ℓ))).1,
      (ZMod.chineseRemainder h (n : ZMod (k * ℓ))).1),
    ((ZMod.chineseRemainder h (m : ZMod (k * ℓ))).2,
      (ZMod.chineseRemainder h (n : ZMod (k * ℓ))).2)) = _
  simp

/-- These are exactly the box points satisfying both the original progression
and the additional sieve conditions modulo `ℓ`. -/
theorem mem_crt_box {k ℓ : ℕ} [NeZero k] (h : k.Coprime ℓ)
    {t : Finset (ZMod ℓ × ZMod ℓ)} {L₁ U₁ L₂ U₂ : ℝ} {n : ℤ × ℤ} :
    n ∈ boxPoints (k * ℓ) (crtResidues h (productOneResidues k) t) L₁ U₁ L₂ U₂ ↔
      L₁ ≤ (n.1 : ℝ) ∧ (n.1 : ℝ) < U₁ ∧
      L₂ ≤ (n.2 : ℝ) ∧ (n.2 : ℝ) < U₂ ∧
      (n.1 : ZMod k) * (n.2 : ZMod k) = 1 ∧
      ((n.1 : ZMod ℓ), (n.2 : ZMod ℓ)) ∈ t := by
  classical
  rw [mem_boxPoints, mem_crtResidues, pairCRT_intCast]
  simp [productOneResidues]

/-- The manuscript's CRT main term and its original lattice-counting error,
for any actual collection of extra forbidden residue pairs. -/
theorem crt_box_error {k ℓ : ℕ} [NeZero k] [NeZero ℓ] (h : k.Coprime ℓ)
    (t : Finset (ZMod ℓ × ZMod ℓ)) {L₁ U₁ L₂ U₂ : ℝ}
    (h₁ : L₁ ≤ U₁) (h₂ : L₂ ≤ U₂) :
    |((boxPoints (k * ℓ) (crtResidues h (productOneResidues k) t)
        L₁ U₁ L₂ U₂).card : ℝ) -
      ((U₁ - L₁) * (U₂ - L₂) * k.totient / (k : ℝ) ^ 2) *
        ((t.card : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      (k.totient : ℝ) * t.card *
        (((U₁ - L₁) + (U₂ - L₂)) / ((k : ℝ) * ℓ) + 1) := by
  have he := boxPoints_error (k * ℓ) (crtResidues h (productOneResidues k) t) h₁ h₂
  rw [crtResidues_card, productOneResidues_card, Nat.cast_mul, Nat.cast_mul] at he
  convert he using 1; congr 1; ring

/-- Divisor-weight local geometry removes the apparently large modulus factor
from the lattice discrepancy. The sole extra hypothesis is a finite local
cardinality bound, never a target pair-count estimate. -/
theorem crt_box_error_of_card_le {k ℓ : ℕ} [NeZero k] [NeZero ℓ]
    (h : k.Coprime ℓ) (t : Finset (ZMod ℓ × ZMod ℓ))
    {L₁ U₁ L₂ U₂ D : ℝ} (h₁ : L₁ ≤ U₁) (h₂ : L₂ ≤ U₂)
    (_hD : 0 ≤ D) (ht : (t.card : ℝ) ≤ D * ℓ) :
    |((boxPoints (k * ℓ) (crtResidues h (productOneResidues k) t)
        L₁ U₁ L₂ U₂).card : ℝ) -
      ((U₁ - L₁) * (U₂ - L₂) * k.totient / (k : ℝ) ^ 2) *
        ((t.card : ℝ) / (ℓ : ℝ) ^ 2)| ≤
      D * ((U₁ - L₁) + (U₂ - L₂) + (k : ℝ) * ℓ) := by
  have hk : (0 : ℝ) < k := by exact_mod_cast NeZero.pos k
  have hl : (0 : ℝ) < ℓ := by exact_mod_cast NeZero.pos ℓ
  have hφ : (k.totient : ℝ) ≤ k := by exact_mod_cast Nat.totient_le k
  calc
    _ ≤ (k.totient : ℝ) * t.card *
        (((U₁ - L₁) + (U₂ - L₂)) / ((k : ℝ) * ℓ) + 1) :=
      crt_box_error h t h₁ h₂
    _ ≤ (k : ℝ) * (D * ℓ) *
        (((U₁ - L₁) + (U₂ - L₂)) / ((k : ℝ) * ℓ) + 1) := by
      apply mul_le_mul_of_nonneg_right
      · exact mul_le_mul hφ ht (Nat.cast_nonneg _) hk.le
      · exact add_nonneg (div_nonneg (add_nonneg (sub_nonneg.mpr h₁)
          (sub_nonneg.mpr h₂)) (mul_nonneg hk.le hl.le)) (by norm_num)
    _ = _ := by field_simp

end Artin.LatticeBoxes
