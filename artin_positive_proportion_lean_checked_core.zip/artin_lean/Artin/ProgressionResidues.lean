module

public import Mathlib.FieldTheory.Finite.Basic
public import Mathlib.Data.ZMod.Basic
public import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-!
# The progression and its single forbidden reduced residue

These finite statements provide the local arithmetic for Section 5. They
identify the unique residue removed by a prime not dividing the cofactor,
show that no residue is removed when it divides the cofactor, and combine
the resulting class with the fixed progression by CRT.
-/

@[expose] public section

namespace Artin.ProgressionResidues

theorem linear_sieve_equation {F : Type*} [Field F] {k y : F} (hk : k ≠ 0) :
    k * y + 1 = 0 ↔ y = -(k⁻¹) := by
  constructor
  · intro h
    apply (mul_left_cancel₀ hk)
    rw [mul_neg, mul_inv_cancel₀ hk]
    exact eq_neg_of_add_eq_zero_left h
  · rintro rfl
    simp [hk]

theorem linear_sieve_residue_nonzero {F : Type*} [Field F] {k : F} (hk : k ≠ 0) :
    -(k⁻¹) ≠ 0 := neg_ne_zero.mpr (inv_ne_zero hk)

theorem no_sieve_residue {F : Type*} [Field F] {k : F} (hk : k = 0) :
    ¬ ∃ y : F, k * y + 1 = 0 := by
  simp [hk]

/-- Exactly one of the `p-1` reduced residues is removed. -/
theorem forbidden_reduced_card (p : ℕ) [Fact p.Prime]
    (k : ZMod p) (hk : k ≠ 0) :
    Fintype.card {y : ZMod p // y ≠ 0 ∧ k * y + 1 = 0} = 1 := by
  classical
  have heq : (fun y : ZMod p => y ≠ 0 ∧ k * y + 1 = 0) =
      (fun y => y = -(k⁻¹)) := by
    funext y
    apply propext
    rw [linear_sieve_equation hk]
    exact ⟨And.right, fun h => ⟨h ▸ linear_sieve_residue_nonzero hk, h⟩⟩
  calc
    _ = Fintype.card {y : ZMod p // y = -(k⁻¹)} :=
      Fintype.card_congr (Equiv.subtypeEquivRight (fun y => congrFun heq y ▸ Iff.rfl))
    _ = 1 := Fintype.card_subtype_eq _

theorem reduced_card (p : ℕ) [Fact p.Prime] :
    Fintype.card {y : ZMod p // y ≠ 0} = p - 1 := by
  classical
  rw [Fintype.card_subtype_compl, Fintype.card_subtype_eq, ZMod.card]

/-- The local density is the exact fraction `1/(p-1)`. -/
theorem local_density (p : ℕ) [Fact p.Prime]
    (k : ZMod p) (hk : k ≠ 0) :
    (Fintype.card {y : ZMod p // y ≠ 0 ∧ k * y + 1 = 0} : ℝ) /
      (Fintype.card {y : ZMod p // y ≠ 0} : ℝ) = 1 / ((p : ℝ) - 1) := by
  rw [forbidden_reduced_card p k hk, reduced_card, Nat.cast_sub (Fact.out : p.Prime).one_le]
  simp

/-- CRT combines the fixed progression and the cofactor sieve class
uniquely. Both projections are specified, so no multiplicity can enter the
subsequent progression count. -/
theorem existsUnique_crt_sieve_residue {M p : ℕ} (hMp : M.Coprime p)
    [Fact p.Prime] (u : ZMod M) (k : ZMod p) (hk : k ≠ 0) :
    ∃! z : ZMod (M * p),
      (ZMod.chineseRemainder hMp z).1 = u ∧
      k * (ZMod.chineseRemainder hMp z).2 + 1 = 0 := by
  refine ⟨(ZMod.chineseRemainder hMp).symm (u, -(k⁻¹)), ?_, ?_⟩
  · simp [hk]
  · intro z hz
    apply (ZMod.chineseRemainder hMp).injective
    simp only [RingEquiv.apply_symm_apply]
    exact Prod.ext hz.1 ((linear_sieve_equation hk).mp hz.2)

/-- The combined progression is reduced; this is the hypothesis needed by
the progression form of Bombieri--Vinogradov. -/
theorem crt_sieve_residue_isUnit {M p : ℕ} (hMp : M.Coprime p)
    [Fact p.Prime] (u : ZMod M) (hu : IsUnit u) (k : ZMod p) (hk : k ≠ 0) :
    IsUnit ((ZMod.chineseRemainder hMp).symm (u, -(k⁻¹))) := by
  have hv : IsUnit (-(k⁻¹)) := isUnit_iff_ne_zero.mpr (linear_sieve_residue_nonzero hk)
  exact (Prod.isUnit_iff.mpr ⟨hu, hv⟩).map (ZMod.chineseRemainder hMp).symm.toMonoidHom

end Artin.ProgressionResidues
