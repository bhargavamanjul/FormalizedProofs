module

public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.BigOperators.Group.Finset.Powerset
public import Mathlib.Basic.Real.Basic
public import Mathlib.Data.Nat.Squarefree
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-!
# The finite cofactor-mass calculation

This file proves the combinatorial core of Section 4 of the manuscript.  Weights
are actual real-valued functions on a finite set.  All Euler-product and Markov
identities here are proved, rather than assumed.

The analytic estimates for prime sums and the asymptotic Euler product are not
supplied by this module.  In particular these finite results alone do not prove
the entire cofactor lemma or the candidate-prime lower bound.
-/

@[expose] public section

open scoped BigOperators

namespace Artin.Cofactor

variable {ι : Type*}

/-- Finite weighted Markov inequality, with a strict upper tail. -/
theorem weighted_markov (s : Finset ι) (w f : ι → ℝ) (R : ℝ)
    (hw : ∀ i ∈ s, 0 ≤ w i) (hf : ∀ i ∈ s, 0 ≤ f i) :
    R * (∑ i ∈ s.filter (fun i => R < f i), w i) ≤
      ∑ i ∈ s, w i * f i := by
  classical
  rw [Finset.sum_filter, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  by_cases h : R < f i
  · simp only [ite_eq_left h]
    nlinarith [hw i hi]
  · simp only [ite_eq_right h, mul_zero]
    exact mul_nonneg (hw i hi) (hf i hi)

/-- An element outside either tail satisfies both constraints. -/
theorem mass_le_good_add_tails (s : Finset ι) (w f g : ι → ℝ) (R T : ℝ)
    (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s, w i) ≤
      (∑ i ∈ s.filter (fun i => f i ≤ R ∧ g i ≤ T), w i) +
      (∑ i ∈ s.filter (fun i => R < f i), w i) +
      (∑ i ∈ s.filter (fun i => T < g i), w i) := by
  classical
  simp only [Finset.sum_filter]
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro i hi
  by_cases hf : f i ≤ R
  · by_cases hg : g i ≤ T
    · simp [hf, hg, not_lt_of_ge hf, not_lt_of_ge hg]
    · simp [hf, hg, not_lt_of_ge hf, lt_of_not_ge hg]
  · by_cases hg : g i ≤ T
    · simp [hf, hg, lt_of_not_ge hf, not_lt_of_ge hg]
    · simp only [hf, hg, false_and, ite_false, lt_of_not_ge hf,
        lt_of_not_ge hg, ite_true, zero_add]
      linarith [hw i hi]

/-- Two moment bounds preserve the indicated fraction of the total mass.
No probability-space infrastructure or independence assumption is needed. -/
theorem mass_two_constraints (s : Finset ι) (w f g : ι → ℝ)
    (R T α β : ℝ) (hR : 0 < R) (hT : 0 < T)
    (hw : ∀ i ∈ s, 0 ≤ w i) (hf : ∀ i ∈ s, 0 ≤ f i)
    (hg : ∀ i ∈ s, 0 ≤ g i)
    (hF : (∑ i ∈ s, w i * f i) ≤ R * (α * ∑ i ∈ s, w i))
    (hG : (∑ i ∈ s, w i * g i) ≤ T * (β * ∑ i ∈ s, w i)) :
    (1 - α - β) * (∑ i ∈ s, w i) ≤
      ∑ i ∈ s.filter (fun i => f i ≤ R ∧ g i ≤ T), w i := by
  classical
  have hbadF : (∑ i ∈ s.filter (fun i => R < f i), w i) ≤
      α * ∑ i ∈ s, w i := by
    have h := (weighted_markov s w f R hw hf).trans hF
    nlinarith
  have hbadG : (∑ i ∈ s.filter (fun i => T < g i), w i) ≤
      β * ∑ i ∈ s, w i := by
    have h := (weighted_markov s w g T hw hg).trans hG
    nlinarith
  have hcover := mass_le_good_add_tails s w f g R T hw
  nlinarith

/-- The numerical choice used in Section 4: a size moment at most one third of
its cutoff and a reciprocal-divisor moment at most one tenth retain half the mass. -/
theorem half_mass_two_constraints (s : Finset ι) (w f g : ι → ℝ)
    (R T : ℝ) (hR : 0 < R) (hT : 0 < T)
    (hw : ∀ i ∈ s, 0 ≤ w i) (hf : ∀ i ∈ s, 0 ≤ f i)
    (hg : ∀ i ∈ s, 0 ≤ g i)
    (hF : (∑ i ∈ s, w i * f i) ≤ R * ((1 / 3 : ℝ) * ∑ i ∈ s, w i))
    (hG : (∑ i ∈ s, w i * g i) ≤ T * ((1 / 10 : ℝ) * ∑ i ∈ s, w i)) :
    (1 / 2 : ℝ) * (∑ i ∈ s, w i) ≤
      ∑ i ∈ s.filter (fun i => f i ≤ R ∧ g i ≤ T), w i := by
  classical
  have h := mass_two_constraints s w f g R T (1/3) (1/10) hR hT hw hf hg hF hG
  have hmass : 0 ≤ ∑ i ∈ s, w i := Finset.sum_nonneg hw
  nlinarith

/-- Sum of multiplicative subset weights equals the Euler product. -/
theorem subset_euler_product (s : Finset ι) (u : ι → ℝ) :
    (∑ t ∈ s.powerset, ∏ i ∈ t, u i) = ∏ i ∈ s, (1 + u i) := by
  exact (Finset.prod_one_add s).symm

/-- Adding one allowed prime gives an exact recurrence for the first moment. -/
theorem subset_moment_insert [DecidableEq ι] (s : Finset ι) (a : ι)
    (ha : a ∉ s) (u f : ι → ℝ) :
    (∑ t ∈ (insert a s).powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, f i)) =
      (1 + u a) * (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, f i)) +
      (u a * f a) * (∑ t ∈ s.powerset, ∏ i ∈ t, u i) := by
  rw [Finset.sum_powerset_insert ha]
  have hins :
      (∑ t ∈ s.powerset, (∏ i ∈ insert a t, u i) * (∑ i ∈ insert a t, f i)) =
      (u a * f a) * (∑ t ∈ s.powerset, ∏ i ∈ t, u i) +
      u a * (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, f i)) := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro t ht
    have hat : a ∉ t := fun h => ha ((Finset.mem_powerset.mp ht) h)
    rw [Finset.prod_insert hat, Finset.sum_insert hat]
    ring
  rw [hins]
  ring

/-- Exact first moments for multiplicative subset weights.  The marginal
probability of including `i` is `u i / (1 + u i)`. -/
theorem subset_moment (s : Finset ι) (u f : ι → ℝ)
    (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, f i)) =
      (∏ i ∈ s, (1 + u i)) * (∑ i ∈ s, u i / (1 + u i) * f i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      have hua := hu a (Finset.mem_insert_self a s)
      have hus : ∀ i ∈ s, 0 ≤ u i := fun i hi => hu i (Finset.mem_insert_of_mem hi)
      have hne : 1 + u a ≠ 0 := by linarith
      rw [subset_moment_insert s a ha u f, ih hus, subset_euler_product,
        Finset.prod_insert ha, Finset.sum_insert ha]
      field_simp [hne]
      ring

/-- In particular, the Euler-product measure with reciprocal weights has
marginal `1 / (q + 1)`, as in Section 4. -/
theorem reciprocal_marginal (q : ℝ) (hq : 0 < q) :
    (1 / q) / (1 + 1 / q) = 1 / (q + 1) := by
  have hq0 : q ≠ 0 := ne_of_gt hq
  have hq1 : q + 1 ≠ 0 := by linarith
  field_simp [hq0, hq1]

/-- The exact finite form of the unmarked cofactor selection in Section 4.
Taking `u q = 1/q`, `f q = log q`, and `g q = 1/q` gives the two restrictions
used there.  The only remaining hypotheses are the two explicit prime-sum
estimates; the retained-mass conclusion is proved here. -/
theorem half_euler_product_with_two_constraints (s : Finset ι) (u f g : ι → ℝ)
    (R T : ℝ) (hR : 0 < R) (hT : 0 < T)
    (hu : ∀ i ∈ s, 0 ≤ u i) (hf : ∀ i ∈ s, 0 ≤ f i)
    (hg : ∀ i ∈ s, 0 ≤ g i)
    (hF : (∑ i ∈ s, u i / (1 + u i) * f i) ≤ R / 3)
    (hG : (∑ i ∈ s, u i / (1 + u i) * g i) ≤ T / 10) :
    (1 / 2 : ℝ) * (∏ i ∈ s, (1 + u i)) ≤
      ∑ t ∈ s.powerset.filter
        (fun t => (∑ i ∈ t, f i) ≤ R ∧ (∑ i ∈ t, g i) ≤ T),
        ∏ i ∈ t, u i := by
  classical
  have hmass : 0 ≤ ∏ i ∈ s, (1 + u i) := by
    apply Finset.prod_nonneg
    intro i hi
    linarith [hu i hi]
  have hw : ∀ t ∈ s.powerset, 0 ≤ ∏ i ∈ t, u i := by
    intro t ht
    exact Finset.prod_nonneg fun i hi => hu i ((Finset.mem_powerset.mp ht) hi)
  have hfs : ∀ t ∈ s.powerset, 0 ≤ ∑ i ∈ t, f i := by
    intro t ht
    exact Finset.sum_nonneg fun i hi => hf i ((Finset.mem_powerset.mp ht) hi)
  have hgs : ∀ t ∈ s.powerset, 0 ≤ ∑ i ∈ t, g i := by
    intro t ht
    exact Finset.sum_nonneg fun i hi => hg i ((Finset.mem_powerset.mp ht) hi)
  have hFm : (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, f i)) ≤
      R * ((1 / 3 : ℝ) * ∑ t ∈ s.powerset, ∏ i ∈ t, u i) := by
    rw [subset_moment s u f hu, subset_euler_product]
    nlinarith [mul_le_mul_of_nonneg_left hF hmass]
  have hGm : (∑ t ∈ s.powerset, (∏ i ∈ t, u i) * (∑ i ∈ t, g i)) ≤
      T * ((1 / 10 : ℝ) * ∑ t ∈ s.powerset, ∏ i ∈ t, u i) := by
    rw [subset_moment s u g hu, subset_euler_product]
    nlinarith [mul_le_mul_of_nonneg_left hG hmass]
  have h := half_mass_two_constraints s.powerset (fun t => ∏ i ∈ t, u i)
    (fun t => ∑ i ∈ t, f i) (fun t => ∑ i ∈ t, g i) R T hR hT
    hw hfs hgs hFm hGm
  simpa only [subset_euler_product] using h

/-- Distinct finite subsets of primes give distinct squarefree cofactors. -/
theorem prime_subset_product_injective (s : Finset ℕ)
    (hs : ∀ p ∈ s, Nat.Prime p) :
    Set.InjOn (fun t : Finset ℕ => ∏ p ∈ t, p) (s.powerset : Set (Finset ℕ)) := by
  intro t ht v hv h
  have htprime : ∀ p ∈ t, Nat.Prime p :=
    fun p hp => hs p ((Finset.mem_powerset.mp ht) hp)
  have hvprime : ∀ p ∈ v, Nat.Prime p :=
    fun p hp => hs p ((Finset.mem_powerset.mp hv) hp)
  have heq := congrArg Nat.primeFactors h
  simpa only [Nat.primeFactors_prod htprime, Nat.primeFactors_prod hvprime] using heq

/-- Every prime-subset product is squarefree. -/
theorem prime_subset_product_squarefree (s : Finset ℕ)
    (hs : ∀ p ∈ s, Nat.Prime p) : Squarefree (∏ p ∈ s, p) := by
  refine Finset.squarefree_prod_of_pairwise_isCoprime (fun p hp q hq hpq => ?_)
    (fun p hp => (hs p hp).squarefree)
  simp only [← Nat.coprime_iff_isRelPrime]
  exact (Nat.coprime_primes (hs p hp) (hs q hq)).mpr hpq

/-- Reciprocal subset weights are exactly the reciprocal of the cofactor. -/
theorem reciprocal_product (s : Finset ℕ) :
    (∏ p ∈ s, (1 / (p : ℝ))) = 1 / ((∏ p ∈ s, p : ℕ) : ℝ) := by
  simp only [one_div, Nat.cast_prod, Finset.prod_inv_distrib]

end Artin.Cofactor
