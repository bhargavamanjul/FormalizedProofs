module

public import Artin.ConcreteCounting
public import Artin.Density

/-!
# Reduction to two concrete analytic estimates

This module proves the closing arithmetic and asymptotic deduction for the
actual primitive-root prime counts. Two intermediate estimates are
explicit hypotheses in this modular reduction: `CandidateEstimate` and `SmallIndexEstimate`.

Neither estimate is an axiom or an accepted cited theorem. Their derivations
from the agreed external inputs are completed downstream in
`Artin.candidate_estimate_of_accepted_sources` and `SourceKummer.exists_smallIndexEstimate_of_sources`.
The source-only endpoint is in `Artin/ManuscriptTheorem.lean`.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- The actual primes in the dyadic interval `(x, 2*x]`. -/
noncomputable def ambientPrimes (x : ℝ) : Finset ℕ := by
  classical
  exact (Nat.primesLE ⌊2 * x⌋₊).filter (fun p => x < (p : ℝ))

theorem ambientPrimes_lower_bound {x : ℝ} {p : ℕ}
    (hp : p ∈ ambientPrimes x) : x ≤ (p : ℝ) := by
  classical
  exact (Finset.mem_filter.mp hp).2.le

/-- Filtering the dyadic ambient set counts precisely the primitive-root
primes used in the density module. -/
theorem ambient_primitive_count_eq (a : ℤ) (x : ℝ) :
    (filteredCard (ambientPrimes x) (IsPrimitiveRootAt a) : ℝ) =
      dyadicPrimitiveCount a x := by
  classical
  unfold filteredCard ambientPrimes dyadicPrimitiveCount dyadicPrimitivePrimes
    primitivePrimesUpTo
  rw [Finset.filter_comm]

/-- The concrete, unweighted candidate count. The earlier sieve construction
may impose extra conditions, so its candidate set can be smaller than this
one. The closing arithmetic deduction needs only this displayed structure. -/
noncomputable def structuredCandidateCount (a : ℤ) (ε Y x : ℝ) : ℝ :=
  (filteredCard (ambientPrimes x)
    (StructuredCandidate a ⌊Y⌋₊ ⌊x ^ ε⌋₊) : ℝ)

/-- The concrete union of small-index obstructions, counted without
multiplicity over the possible prime divisors of the index. -/
noncomputable def smallIndexCount (a : ℤ) (ε Y x : ℝ) : ℝ :=
  (filteredCard (ambientPrimes x)
    (SmallIndexObstruction a ⌊Y⌋₊ ⌊x ^ ε⌋₊) : ℝ)

/-- Intermediate bridge 1: the uniform candidate lower bound.

The constants `A`, `Y₀`, and `ε₀` precede the choices of `ε` and `Y`. The
vanishing error and eventual threshold may depend on those choices. This
definition states a proof obligation; it supplies no proof or axiom. -/
def CandidateEstimate (a : ℤ) (A Y₀ ε₀ : ℝ) : Prop :=
  ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
    ∃ e : ℝ → ℝ, Tendsto e atTop (𝓝 0) ∧
      ∀ᶠ x : ℝ in atTop,
        (A * ε / Real.log Y + e x) * (x / Real.log x) ≤
          structuredCandidateCount a ε Y x

/-- Intermediate bridge 2: the small-index upper bound from splitting
estimates. The guard `Q N` is intended to represent the zero-free hypothesis
of width `1/N`; it is not assumed for every width.

The count is an actual finite set of primes, and the power error has the
unnormalized exponent appearing in Section 10. The constant multiplying that
power error may depend on all parameters chosen before `x`. This definition
states a proof obligation; it supplies no proof or axiom. -/
def SmallIndexEstimate (Q : ℝ → Prop) (a : ℤ) (C Y₀ : ℝ) : Prop :=
  ∀ N : ℝ, 2 ≤ N → Q N → ∀ ε Y : ℝ,
    0 < ε → ε < 1 / N → Y₀ ≤ Y → 1 < Y →
      ∃ C₁ : ℝ, ∀ᶠ x : ℝ in atTop,
        smallIndexCount a ε Y x ≤
          (C / (Y * Real.log Y)) * (x / Real.log x) +
            C₁ * x ^ (1 - 1 / N + ε) / Real.log x

/-- The two displayed estimates imply the exact final analytic estimate.
The large-factor exceptions are bounded by the proved integer-product
argument, rather than supplied as a third analytic hypothesis. -/
theorem final_analytic_estimate_of_two_estimates
    (a : ℤ) (ha : Admissible a) (Q : ℝ → Prop) (A C Y₀ ε₀ : ℝ)
    (hCandidates : CandidateEstimate a A Y₀ ε₀)
    (hSmall : SmallIndexEstimate Q a C Y₀) :
    FinalAnalyticEstimateOn Q (fun _ x => dyadicPrimitiveCount a x) A C Y₀ ε₀ := by
  intro N hN hQ ε Y hε hε₀ hεδ h2ε hY hY1
  obtain ⟨e₀, he₀, hcandidates⟩ := hCandidates ε Y hε hε₀ hY hY1
  obtain ⟨C₁, hsmall⟩ := hSmall N hN hQ ε Y hε hεδ hY hY1
  let B : ℝ := 16 * Real.log (a.natAbs + 1 : ℝ)
  let e : ℝ → ℝ := fun x => e₀ x -
    (C₁ * x ^ (-(1 / N) + ε) + B * x ^ (2 * ε - 1))
  have he : Tendsto e atTop (𝓝 0) := by
    have herr := tendsto_exception_error_zero hεδ h2ε C₁ B
    simpa only [e, sub_zero] using he₀.sub herr
  refine ⟨e, he, ?_⟩
  filter_upwards [hcandidates, hsmall, eventually_ge_atTop (2 : ℝ)] with x hc hs hx
  have hx1 : 1 < x := by linarith
  have hxp : 0 < x := by linarith
  have hR : (⌊x ^ ε⌋₊ : ℝ) ≤ x ^ ε := Nat.floor_le (Real.rpow_nonneg hxp.le ε)
  have hcount := primitive_count_after_explicit_order_bound a ha
    ⌊Y⌋₊ ⌊x ^ ε⌋₊ (ambientPrimes x) hx1
    (fun _ hp => ambientPrimes_lower_bound hp) hR hc hs
  rw [ambient_primitive_count_eq] at hcount
  have hpower₁ : x ^ (1 - 1 / N + ε) = x ^ (-(1 / N) + ε) * x := by
    have hexp : 1 - 1 / N + ε = (-(1 / N) + ε) + 1 := by ring
    rw [hexp, Real.rpow_add hxp, Real.rpow_one]
  have hpower₂ : x ^ (2 * ε) = x ^ (2 * ε - 1) * x := by
    calc
      x ^ (2 * ε) = x ^ ((2 * ε - 1) + 1) := by congr 1; ring
      _ = x ^ (2 * ε - 1) * x := by rw [Real.rpow_add hxp, Real.rpow_one]
  rw [hpower₁, hpower₂] at hcount
  have heq :
      ((A * ε - C / Y) / Real.log Y + e x) * (x / Real.log x) =
      (A * ε / Real.log Y + e₀ x) * (x / Real.log x) -
        ((C / (Y * Real.log Y)) * (x / Real.log x) +
          C₁ * (x ^ (-(1 / N) + ε) * x) / Real.log x) -
        16 * Real.log (a.natAbs + 1 : ℝ) *
          (x ^ (2 * ε - 1) * x) / Real.log x := by
    dsimp [e, B]
    ring
  rw [heq]
  exact hcount

/-- The two-estimate reduction: an actual quantitative lower proportion of
primitive-root primes, conditional on the two explicitly named intermediate
manuscript estimates. The constant `c` is independent of `N`.

This is a conditional reduction theorem, not a proof of either analytic
estimate from the cited literature. -/
theorem quantitative_prime_proportion_of_two_estimates
    (a : ℤ) (ha : Admissible a) (Q : ℝ → Prop) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hCandidates : CandidateEstimate a A Y₀ ε₀)
    (hSmall : SmallIndexEstimate Q a C Y₀) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → Q N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ)
          ≤ primitiveCount a x := by
  exact quantitative_prime_proportion_of_analytic_estimate a Q A C Y₀ ε₀
    hA hC hY₀ hε₀
    (final_analytic_estimate_of_two_estimates a ha Q A C Y₀ ε₀ hCandidates hSmall)

/-- At `N = 6000`, the same two intermediate estimates and the particular guard
`Q 6000` imply a positive proportion for the actual prime counts. -/
theorem positive_prime_proportion_at_6000_of_two_estimates
    (a : ℤ) (ha : Admissible a) (Q : ℝ → Prop) (A C Y₀ ε₀ : ℝ)
    (hA : 0 < A) (hC : 0 < C) (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀)
    (hCandidates : CandidateEstimate a A Y₀ ε₀)
    (hSmall : SmallIndexEstimate Q a C Y₀) (h6000 : Q 6000) :
    HasPositivePrimeProportion a := by
  obtain ⟨c, hc, hb⟩ := quantitative_prime_proportion_of_two_estimates a ha Q
    A C Y₀ ε₀ hA hC hY₀ hε₀ hCandidates hSmall
  refine ⟨c / ((6000 : ℝ) * Real.log 6000), ?_, hb 6000 (by norm_num) h6000⟩
  have hlog : 0 < Real.log (6000 : ℝ) := Real.log_pos (by norm_num)
  positivity

end Artin
