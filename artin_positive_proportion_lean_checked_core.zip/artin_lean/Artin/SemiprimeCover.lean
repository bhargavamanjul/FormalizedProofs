module

public import Artin.SemiprimeBoxes
public import Mathlib.Data.Finset.Sigma

/-!
# Weighted rough composites are covered by the explicit prime boxes

The cover is proved for the actual integers and nonnegative weights.  No
factorization count is assumed.  Prime squares are included, and any repeated
representation only enlarges the upper bound.
-/

@[expose] public section
open Filter
open scoped BigOperators

namespace Artin.SemiprimeCover

open DyadicBoxes MarkedSource SemiprimeMR SemiprimeReplacement RoughCompanion SemiprimeBoxes

/-- A finite cover by prime pairs gives the corresponding weighted bound,
without requiring uniqueness of representations or disjointness of boxes. -/
theorem weighted_prime_pair_cover (D : Finset ℕ) (w : ℕ → ℝ) (x κ : ℝ)
    (hw : ∀ d, 0 ≤ w d)
    (hcover : ∀ d ∈ D, ∃ ab ∈ narrowBoxIndices x κ,
      ∃ m ∈ dyadIntegers (leftScale x ab), ∃ n ∈ dyadIntegers (rightScale x ab),
        m.Prime ∧ n.Prime ∧ m * n = d) :
    (∑ d ∈ D, w d) ≤ primeCoverMass x κ w := by
  classical
  let pairs : Finset (Sigma fun _ab : ℤ × ℤ => ℕ × ℕ) :=
    (narrowBoxIndices x κ).sigma (fun ab =>
      ((dyadIntegers (leftScale x ab)).product (dyadIntegers (rightScale x ab))).filter
        (fun mn => mn.1.Prime ∧ mn.2.Prime))
  let products : Finset ℕ := pairs.image (fun z => z.2.1 * z.2.2)
  have hsub : D ⊆ products := by
    intro d hd
    obtain ⟨ab, hab, m, hm, n, hn, hmp, hnp, heq⟩ := hcover d hd
    apply Finset.mem_image.mpr
    refine ⟨⟨ab, (m, n)⟩, ?_, heq⟩
    exact Finset.mem_sigma.mpr ⟨hab,
      Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hm, hn⟩, hmp, hnp⟩⟩
  have h₁ : (∑ d ∈ D, w d) ≤ ∑ d ∈ products, w d :=
    Finset.sum_le_sum_of_subset_of_nonneg hsub (fun d _ _ => hw d)
  have h₂ : (∑ d ∈ products, w d) ≤ ∑ z ∈ pairs, w (z.2.1 * z.2.2) :=
    Finset.sum_image_le_of_nonneg (fun d _ => hw d)
  have hid : (∑ z ∈ pairs, w (z.2.1 * z.2.2)) = primeCoverMass x κ w := by
    dsimp only [pairs, primeCoverMass]
    rw [Finset.sum_sigma]
    apply Finset.sum_congr rfl
    intro ab hab
    rw [Finset.sum_filter]
    change (∑ mn ∈ dyadIntegers (leftScale x ab) ×ˢ dyadIntegers (rightScale x ab),
      if mn.1.Prime ∧ mn.2.Prime then w (mn.1 * mn.2) else 0) = _
    rw [Finset.sum_product]
    unfold pairMass
    apply Finset.sum_congr rfl
    intro m hm
    apply Finset.sum_congr rfl
    intro n hn
    by_cases hmp : m.Prime <;> by_cases hnp : n.Prime <;>
      simp [primeIndicator, hmp, hnp]
  exact (h₁.trans h₂).trans_eq hid

/-- Actual rough composites in `(x,2x]` admit a prime-pair representation
in the explicitly constructed narrow box cover. -/
theorem rough_composite_prime_pair_cover {x κ : ℝ} {d : ℕ}
    (hx : 1 < x) (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) (hκ : κ ≤ 1 / 100)
    (hdlo : x < (d : ℝ)) (hdhi : (d : ℝ) ≤ 2 * x)
    (hdprime : ¬ d.Prime) (hrough : MarkedCriterion.IsRough (x ^ (1 / 2 - κ)) d) :
    ∃ ab ∈ narrowBoxIndices x κ,
      ∃ m ∈ dyadIntegers (leftScale x ab), ∃ n ∈ dyadIntegers (rightScale x ab),
        m.Prime ∧ n.Prime ∧ m * n = d := by
  have hd2 : 2 ≤ d := by exact_mod_cast (hx.trans hdlo)
  obtain ⟨m, n, hmp, hnp, heq, hmlo, hmhi, hnlo, hnhi⟩ :=
    RoughFactorization.semiprime_in_narrow_support hx.le hlarge hκ
      hd2 hdprime hdhi hrough
  have heqr : (m : ℝ) * n = d := by exact_mod_cast heq
  obtain ⟨ab, hab, hm, hn⟩ := exists_narrowBox (n := (n : ℝ)) (by linarith : 0 < x)
    hmlo.le hmhi (by exact_mod_cast hnp.pos) (by simpa only [heqr] using hdlo)
      (by simpa only [heqr] using hdhi)
  refine ⟨ab, hab, m, ?_, n, ?_, hmp, hnp, heq⟩
  · rw [mem_dyadIntegers (show 0 < leftScale x ab from zpow_pos (by norm_num) _)]
    refine ⟨hm.1, ?_⟩
    simpa only [leftScale, zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0), zpow_one,
      mul_comm] using hm.2
  · rw [mem_dyadIntegers (show 0 < rightScale x ab from zpow_pos (by norm_num) _)]
    refine ⟨hn.1, ?_⟩
    simpa only [rightScale, zpow_add₀ (by norm_num : (2 : ℝ) ≠ 0), zpow_one,
      mul_comm] using hn.2

/-- The actual finite set of rough composites in the dyadic interval. -/
noncomputable def roughCompositeIntegers (x κ : ℝ) : Finset ℕ := by
  classical
  exact (Finset.Icc (⌊x⌋₊ + 1) ⌊2 * x⌋₊).filter
    (fun d => ¬ d.Prime ∧ MarkedCriterion.IsRough (x ^ (1 / 2 - κ)) d)

noncomputable def roughCompositeMass (x κ : ℝ) (w : ℕ → ℝ) : ℝ :=
  ∑ d ∈ roughCompositeIntegers x κ, w d

theorem roughCompositeMass_le_primeCoverMass {x κ : ℝ} (w : ℕ → ℝ)
    (hw : ∀ d, 0 ≤ w d) (hx : 1 < x)
    (hlarge : 2 ≤ x ^ (3 / 100 : ℝ)) (hκ : κ ≤ 1 / 100) :
    roughCompositeMass x κ w ≤ primeCoverMass x κ w := by
  classical
  apply weighted_prime_pair_cover _ w x κ hw
  intro d hd
  obtain ⟨hdIcc, hdprime, hdrough⟩ := Finset.mem_filter.mp hd
  obtain ⟨hdlo, hdhi⟩ := Finset.mem_Icc.mp hdIcc
  have hlo : x < (d : ℝ) := (Nat.floor_lt (by linarith : 0 ≤ x)).mp (by omega)
  have hhi : (d : ℝ) ≤ 2 * x := (Nat.le_floor_iff (by linarith : 0 ≤ 2 * x)).mp hdhi
  exact rough_composite_prime_pair_cover hx hlarge hκ hlo hhi hdprime hdrough

theorem eventually_roughCompositeMass_le_primeCoverMass :
    ∀ᶠ x : ℝ in atTop, ∀ κ : ℝ, κ ≤ 1 / 100 →
      ∀ w : ℕ → ℝ, (∀ d, 0 ≤ w d) →
        roughCompositeMass x κ w ≤ primeCoverMass x κ w := by
  have hg := (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 3 / 100)).eventually_ge_atTop 2
  filter_upwards [hg, eventually_gt_atTop (1 : ℝ)] with x hlarge hx κ hκ w hw
  exact roughCompositeMass_le_primeCoverMass w hw hx hlarge hκ

end Artin.SemiprimeCover
