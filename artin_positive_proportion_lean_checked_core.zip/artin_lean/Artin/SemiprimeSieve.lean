module

public import Mathlib.FieldTheory.Finite.Basic
public import Mathlib.Data.Fintype.Sum
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

/-!
# Local geometry and uniform error for the two-variable semiprime sieve

These results prove the actual finite-field counts behind Section 8. They do
not assume the desired pair-count estimate. The asymptotic remainder estimates
are uniform over the growing range of cofactors, so no dependence on the
number of marked intervals is introduced.
-/

@[expose] public section

open scoped BigOperators
open Filter Asymptotics

namespace Artin.SemiprimeSieve

/-- The modular pairs forbidden by the primality of `(mn - 1) / k`. -/
abbrev onePairs (F : Type*) [Field F] := {z : F × F // z.1 * z.2 = 1}

/-- The modular pairs forbidden when both factors must be rough. -/
abbrev zeroPairs (F : Type*) [Field F] := {z : F × F // z.1 * z.2 = 0}

/-- Every pair with product one is uniquely `(u, u⁻¹)`. -/
def onePairsEquiv (F : Type*) [Field F] : onePairs F ≃ {x : F // x ≠ 0} where
  toFun z := ⟨z.1.1, fun h => by simpa [h] using z.2⟩
  invFun x := ⟨(x.1, x.1⁻¹), mul_inv_cancel₀ x.2⟩
  left_inv z := by
    apply Subtype.ext
    apply Prod.ext
    · rfl
    · exact inv_eq_of_mul_eq_one_right z.2
  right_inv x := by rfl

/-- The zero-product locus is the vertical axis and the punctured horizontal axis. -/
noncomputable def zeroPairsEquiv (F : Type*) [Field F] :
    zeroPairs F ≃ F ⊕ {x : F // x ≠ 0} := by
  classical
  exact {
    toFun := fun z => if h : z.1.1 = 0 then Sum.inl z.1.2 else Sum.inr ⟨z.1.1, h⟩
    invFun := fun z => match z with
      | Sum.inl y => ⟨(0, y), by simp⟩
      | Sum.inr x => ⟨(x.1, 0), by simp⟩
    left_inv := by
      intro z
      dsimp
      split_ifs with h
      · apply Subtype.ext
        exact Prod.ext h.symm rfl
      · apply Subtype.ext
        exact Prod.ext rfl ((mul_eq_zero.mp z.2).resolve_left h).symm
    right_inv := by
      intro z
      cases z with
      | inl y => simp
      | inr x => simp [x.2] }

theorem onePairs_card (p : ℕ) [Fact p.Prime] :
    Fintype.card (onePairs (ZMod p)) = p - 1 := by
  classical
  rw [Fintype.card_congr (onePairsEquiv (ZMod p)),
    Fintype.card_subtype_compl, Fintype.card_subtype_eq, ZMod.card]

theorem zeroPairs_card (p : ℕ) [Fact p.Prime] :
    Fintype.card (zeroPairs (ZMod p)) = 2 * p - 1 := by
  classical
  rw [Fintype.card_congr (zeroPairsEquiv (ZMod p)), Fintype.card_sum,
    Fintype.card_subtype_compl, Fintype.card_subtype_eq, ZMod.card]
  have h := (Fact.out : p.Prime).one_lt
  omega

/-- The two sieving conditions never overlap. -/
theorem conditions_disjoint {F : Type*} [Field F] (z : F × F) :
    ¬ (z.1 * z.2 = 1 ∧ z.1 * z.2 = 0) := by
  rintro ⟨h1, h0⟩
  exact one_ne_zero (h1.symm.trans h0)

/-- Exact cardinality of the union of both forbidden loci. -/
theorem forbidden_card (p : ℕ) [Fact p.Prime] :
    Fintype.card {z : ZMod p × ZMod p // z.1 * z.2 = 1 ∨ z.1 * z.2 = 0}
      = 3 * p - 2 := by
  classical
  let e : {z : ZMod p × ZMod p // z.1 * z.2 = 1 ∨ z.1 * z.2 = 0} ≃
      onePairs (ZMod p) ⊕ zeroPairs (ZMod p) :=
    subtypeOrEquiv _ _ (fun _ h1 h0 z hz =>
      conditions_disjoint z ⟨h1 z hz, h0 z hz⟩)
  rw [Fintype.card_congr e, Fintype.card_sum, onePairs_card, zeroPairs_card]
  have h := (Fact.out : p.Prime).one_lt
  omega

/-- The surviving local factor below the roughness cutoff. -/
theorem local_factor_below {j : ℝ} (hj : 1 < j) :
    1 - (3 * j - 2) / j ^ 2 =
      (1 - 1 / j) ^ 3 * (1 - 1 / (j - 1) ^ 2) := by
  have hj0 : j ≠ 0 := by linarith
  have hj1 : j - 1 ≠ 0 := by linarith
  field_simp
  ring

/-- The surviving local factor above the roughness cutoff. -/
theorem local_factor_above {j : ℝ} (hj : 1 < j) :
    1 - (j - 1) / j ^ 2 =
      (1 - 1 / j) * (1 + 1 / (j * (j - 1))) := by
  have hj0 : j ≠ 0 := by linarith
  have hj1 : j - 1 ≠ 0 := by linarith
  field_simp
  ring

/-- The maximal local density is attained at the first sieving prime, three. -/
theorem local_density_le_seven_ninths {j : ℝ} (hj : 3 ≤ j) :
    (3 * j - 2) / j ^ 2 ≤ 7 / 9 := by
  have hj0 : 0 < j ^ 2 := by positivity
  apply (div_le_iff₀ hj0).2
  have hprod : 0 ≤ (j - 3) * (7 * j - 6) :=
    mul_nonneg (by linarith) (by linarith)
  nlinarith

theorem local_density_le_three_div {j : ℝ} (hj : 0 < j) :
    (3 * j - 2) / j ^ 2 ≤ 3 / j := by
  apply (div_le_div_iff₀ (sq_pos_of_pos hj) hj).2
  nlinarith

/-- The polynomial error, multiplied by the cofactor, saves a fixed power
uniformly throughout the entire permitted cofactor range. -/
theorem error_power_bound {x r : ℝ} (hx : 1 ≤ x)
    (hr : 0 ≤ r) (hrx : r ≤ x ^ (11 / 100 : ℝ)) :
    r * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) ≤
      2 * x ^ (67 / 100 : ℝ) := by
  have hx0 : 0 < x := by linarith
  calc
    r * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) ≤
        x ^ (11 / 100 : ℝ) *
          (x ^ (56 / 100 : ℝ) + x ^ (11 / 100 : ℝ) * x ^ (4 / 100 : ℝ)) := by
      apply mul_le_mul hrx
      · exact add_le_add_right (mul_le_mul_of_nonneg_right hrx (Real.rpow_nonneg hx0.le _)) _
      · positivity
      · positivity
    _ = x ^ (67 / 100 : ℝ) + x ^ (26 / 100 : ℝ) := by
      rw [mul_add, ← mul_assoc, ← Real.rpow_add hx0,
        ← Real.rpow_add hx0, ← Real.rpow_add hx0]
      norm_num
    _ ≤ 2 * x ^ (67 / 100 : ℝ) := by
      have h := Real.rpow_le_rpow_of_exponent_le hx
        (show (26 / 100 : ℝ) ≤ 67 / 100 by norm_num)
      linarith

/-- Every fixed constant in the lattice-counting remainder is absorbed uniformly
in `r`. The outer threshold depends on `C, η`, but there is no number-of-marks
parameter and no loss arising from a bound for the marking weight. -/
theorem error_eventually_small_uniform {C η : ℝ} (hC : 0 < C) (hη : 0 < η) :
    ∀ᶠ x : ℝ in atTop, ∀ r : ℝ, 0 < r → r ≤ x ^ (11 / 100 : ℝ) →
      C * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) * (Real.log x) ^ 3 ≤
        η * (x / r) / (Real.log x) ^ 10 := by
  have hlo := isLittleO_log_rpow_rpow_atTop ((13 : ℕ) : ℝ)
    (show (0 : ℝ) < 33 / 100 by norm_num)
  have he := hlo.def (show 0 < η / (2 * C) by positivity)
  filter_upwards [he, eventually_gt_atTop (1 : ℝ)] with x hlog hx
  intro r hr hrx
  have hx0 : 0 < x := by linarith
  have hL : 0 < Real.log x := Real.log_pos hx
  have hlog' : (Real.log x) ^ 13 ≤ η / (2 * C) * x ^ (33 / 100 : ℝ) := by
    rw [← Real.rpow_natCast]
    simpa only [Real.norm_of_nonneg (Real.rpow_nonneg hL.le _),
      Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _)] using hlog
  have hpower := error_power_bound hx.le hr.le hrx
  have hmult :
      (r * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ))) * (Real.log x) ^ 13 ≤
        (2 * x ^ (67 / 100 : ℝ)) * (η / (2 * C) * x ^ (33 / 100 : ℝ)) :=
    mul_le_mul hpower hlog' (by positivity) (by positivity)
  have hid : (2 * x ^ (67 / 100 : ℝ)) *
      (η / (2 * C) * x ^ (33 / 100 : ℝ)) = (η / C) * x := by
    calc
      _ = (η / C) * (x ^ (67 / 100 : ℝ) * x ^ (33 / 100 : ℝ)) := by ring
      _ = (η / C) * x := by rw [← Real.rpow_add hx0]; norm_num
  rw [hid] at hmult
  apply (le_div_iff₀ (pow_pos hL 10)).2
  rw [mul_assoc, ← pow_add, ← mul_div_assoc]
  apply (le_div_iff₀ hr).2
  have hm := mul_le_mul_of_nonneg_left hmult hC.le
  have hc : C * (η / C * x) = η * x := by field_simp
  rw [hc] at hm
  convert hm using 1
  ring

/-- A local omitted-prime factor, with an absolute constant. This version works
for either choice of local density, and avoids any pointwise marking bound. -/
theorem omitted_factor_le_exp {j g : ℝ} (hj : 0 < j)
    (hg : g ≤ 7 / 9) (hgj : g ≤ 3 / j) :
    (1 - g)⁻¹ ≤ Real.exp ((27 / 2 : ℝ) / j) := by
  have hgap : 0 < 1 - g := by linarith
  have hfrac : g / (1 - g) ≤ (27 / 2 : ℝ) / j := by
    apply (div_le_div_iff₀ hgap hj).2
    have hjg : g * j ≤ 3 := (le_div_iff₀ hj).mp hgj
    nlinarith
  calc
    (1 - g)⁻¹ = 1 + g / (1 - g) := by field_simp; ring
    _ ≤ 1 + (27 / 2 : ℝ) / j := by linarith
    _ ≤ Real.exp ((27 / 2 : ℝ) / j) := by
      simpa [add_comm] using Real.add_one_le_exp ((27 / 2 : ℝ) / j)

/-- The cost of deleting any finite collection of primes is controlled by its
reciprocal sum, uniformly in the number of marks and the number of primes. -/
theorem omitted_product_le_exp {α : Type*} (s : Finset α) (j g : α → ℝ)
    (hj : ∀ i ∈ s, 0 < j i) (hg : ∀ i ∈ s, g i ≤ 7 / 9)
    (hgj : ∀ i ∈ s, g i ≤ 3 / j i) {τ : ℝ}
    (hrec : ∑ i ∈ s, 1 / j i ≤ τ) :
    (∏ i ∈ s, (1 - g i)⁻¹) ≤ Real.exp ((27 / 2 : ℝ) * τ) := by
  calc
    (∏ i ∈ s, (1 - g i)⁻¹) ≤
        ∏ i ∈ s, Real.exp ((27 / 2 : ℝ) / j i) := by
      apply Finset.prod_le_prod₀
      · intro i hi
        exact inv_nonneg.mpr (by have := hg i hi; linarith)
      · intro i hi
        exact omitted_factor_le_exp (hj i hi) (hg i hi) (hgj i hi)
    _ = Real.exp ((27 / 2 : ℝ) * ∑ i ∈ s, 1 / j i) := by
      rw [← Real.exp_sum, Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro i hi
      ring
    _ ≤ Real.exp ((27 / 2 : ℝ) * τ) :=
      Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hrec (by norm_num))

/-- Sum the actual lattice errors once a divisor-square moment is supplied.
The classical divisor estimate enters only through the explicit `hdiv` input. -/
theorem sum_lattice_errors {α : Type*} (s : Finset α) (E w t : α → ℝ)
    {C M r T D : ℝ} (hC : 0 ≤ C) (hM : 0 ≤ M) (hr : 0 ≤ r)
    (hT : 0 ≤ T) (hw : ∀ i ∈ s, 0 ≤ w i)
    (ht : ∀ i ∈ s, t i ≤ T)
    (hE : ∀ i ∈ s, |E i| ≤ C * w i * (M + r * t i))
    (hdiv : ∑ i ∈ s, w i ≤ D) :
    (∑ i ∈ s, |E i|) ≤ C * D * (M + r * T) := by
  calc
    (∑ i ∈ s, |E i|) ≤ ∑ i ∈ s, C * w i * (M + r * T) := by
      apply Finset.sum_le_sum
      intro i hi
      exact (hE i hi).trans (mul_le_mul_of_nonneg_left
        (add_le_add_right (mul_le_mul_of_nonneg_left (ht i hi) hr) M)
        (mul_nonneg hC (hw i hi)))
    _ = C * (∑ i ∈ s, w i) * (M + r * T) := by
      rw [← Finset.sum_mul, ← Finset.mul_sum]
    _ ≤ C * D * (M + r * T) := by
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hdiv hC)
        (add_nonneg hM (mul_nonneg hr hT))

/-- In the manuscript's ranges, the classical divisor-square moment and the
lattice error bound give the asserted polynomial remainder with an explicit
constant. This is the exact reduction to the uniform absorption theorem above. -/
theorem lattice_error_moment_bound {α : Type*} (s : Finset α) (E w t : α → ℝ)
    {x r C D M : ℝ} (hx : 1 ≤ x) (hr : 0 ≤ r) (hC : 0 ≤ C) (hD : 0 ≤ D)
    (hM : 0 ≤ M) (hMx : M ≤ 2 * x ^ (54 / 100 : ℝ))
    (hw : ∀ i ∈ s, 0 ≤ w i) (ht : ∀ i ∈ s, t i ≤ x ^ (2 / 100 : ℝ))
    (hE : ∀ i ∈ s, |E i| ≤ C * w i * (M + r * t i))
    (hdiv : (∑ i ∈ s, w i) ≤ D * x ^ (2 / 100 : ℝ) * (Real.log x) ^ 3) :
    (∑ i ∈ s, |E i|) ≤
      (2 * C * D) * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) *
        (Real.log x) ^ 3 := by
  have hx0 : 0 < x := by linarith
  have hL : 0 ≤ Real.log x := Real.log_nonneg hx
  have h0254 : x ^ (2 / 100 : ℝ) * x ^ (54 / 100 : ℝ) = x ^ (56 / 100 : ℝ) := by
    rw [← Real.rpow_add hx0]; norm_num
  have h0202 : x ^ (2 / 100 : ℝ) * x ^ (2 / 100 : ℝ) = x ^ (4 / 100 : ℝ) := by
    rw [← Real.rpow_add hx0]; norm_num
  calc
    (∑ i ∈ s, |E i|) ≤
        C * (D * x ^ (2 / 100 : ℝ) * (Real.log x) ^ 3) *
          (M + r * x ^ (2 / 100 : ℝ)) :=
      sum_lattice_errors s E w t hC hM hr (by positivity) hw ht hE hdiv
    _ ≤ C * (D * x ^ (2 / 100 : ℝ) * (Real.log x) ^ 3) *
          (2 * x ^ (54 / 100 : ℝ) + r * x ^ (2 / 100 : ℝ)) :=
      mul_le_mul_of_nonneg_left (add_le_add_left hMx _) (by positivity)
    _ = C * D * (2 * x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) *
          (Real.log x) ^ 3 := by
      calc
        _ = C * D *
            (2 * (x ^ (2 / 100 : ℝ) * x ^ (54 / 100 : ℝ)) +
              r * (x ^ (2 / 100 : ℝ) * x ^ (2 / 100 : ℝ))) *
            (Real.log x) ^ 3 := by ring
        _ = _ := by rw [h0254, h0202]
    _ ≤ (2 * C * D) * (x ^ (56 / 100 : ℝ) + r * x ^ (4 / 100 : ℝ)) *
          (Real.log x) ^ 3 := by
      have hp : 0 ≤ C * D * r * x ^ (4 / 100 : ℝ) * (Real.log x) ^ 3 := by positivity
      nlinarith

end Artin.SemiprimeSieve
