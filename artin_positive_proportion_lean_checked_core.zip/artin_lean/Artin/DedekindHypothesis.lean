module

public import Mathlib.NumberTheory.NumberField.DedekindZeta
public import Mathlib.Analysis.Complex.CauchyIntegral
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Normed.Module.Connected

/-!
# The Dedekind zero-free hypothesis uses analytic continuation

Mathlib's `NumberField.dedekindZeta` is currently the defining Dirichlet
series. Like `LSeries`, it takes the totalized value zero wherever the
series is not absolutely summable. It must therefore NOT be used directly
as the meromorphic Dedekind zeta function in the critical strip.

We specify the continued function by agreement on `Re s > 1`, holomorphy
away from `1`, and its known nonzero residue at `1`. Its existence is the
classical analytic-continuation theorem, retained as an explicit input.
The QRH statement below includes this existence, avoiding a vacuous
universal statement over nonexistent continuations. No continuation or
zero-free theorem is asserted by this file.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- The classical meromorphic continuation for an actual number field.
The value assigned at the pole itself is immaterial. -/
structure DedekindContinuation (K : Type*) [Field K] [NumberField K] where
  zeta : ℂ → ℂ
  agrees_on_halfPlane : ∀ s : ℂ, 1 < s.re →
    zeta s = NumberField.dedekindZeta K s
  holomorphic : DifferentiableOn ℂ zeta ({1}ᶜ : Set ℂ)
  residue : Tendsto (fun s : ℂ => (s - 1) * zeta s) (𝓝[≠] 1)
    (𝓝 (NumberField.dedekindZeta_residue K : ℂ))

/-- The continuation's prescribed residue is nonzero, by the class-number
formula already proved in mathlib. -/
theorem DedekindContinuation.residue_nonzero
    {K : Type*} [Field K] [NumberField K] (_Z : DedekindContinuation K) :
    (NumberField.dedekindZeta_residue K : ℂ) ≠ 0 := by
  exact_mod_cast NumberField.dedekindZeta_residue_ne_zero K

/-- Agreement on the defining half-plane determines the continuation
uniquely away from its pole, by the complex identity theorem. -/
theorem DedekindContinuation.eq_of_ne_one
    {K : Type*} [Field K] [NumberField K]
    (Z W : DedekindContinuation K) {s : ℂ} (hs : s ≠ 1) :
    Z.zeta s = W.zeta s := by
  have hf := Z.holomorphic.analyticOnNhd isOpen_compl_singleton
  have hg := W.holomorphic.analyticOnNhd isOpen_compl_singleton
  have hconn : IsPreconnected ({1}ᶜ : Set ℂ) :=
    (isConnected_compl_singleton_of_one_lt_rank (by simp) (1 : ℂ)).isPreconnected
  have hmem : (2 : ℂ) ∈ ({1}ᶜ : Set ℂ) := by norm_num
  have hV : {z : ℂ | 1 < z.re} ∈ 𝓝 (2 : ℂ) :=
    (Complex.continuous_re.isOpen_preimage _ isOpen_Ioi).mem_nhds (by norm_num)
  have heq : Z.zeta =ᶠ[𝓝 (2 : ℂ)] W.zeta := by
    filter_upwards [hV] with z hz
    exact (Z.agrees_on_halfPlane z hz).trans (W.agrees_on_halfPlane z hz).symm
  exact hf.eqOn_of_preconnected_of_eventuallyEq hg hconn hmem heq
    (by simpa using hs)

/-- The classical existence theorem, stated as an external proof obligation
rather than declared as an axiom. Number fields here live in `Type 0`, which
suffices for all explicitly constructed finite extensions of `ℚ`. -/
def DedekindContinuationExists : Prop :=
  ∀ (K : Type) [Field K] [NumberField K], Nonempty (DedekindContinuation K)

/-- A nontrivial zero means an actual zero of the continued function in the
open critical strip. The zero-indexing used in explicit formulas may repeat
such zeros to encode multiplicity. -/
def IsNontrivialDedekindZero
    {K : Type*} [Field K] [NumberField K] (Z : DedekindContinuation K) (s : ℂ) : Prop :=
  0 < s.re ∧ s.re < 1 ∧ Z.zeta s = 0

/-- QRH of width `1/N` for every actual number field. Existence of the
continued functions is included so the hypothesis cannot hold merely
because the continuation type is empty. The critical-strip condition is
on the continued functions, never on the raw totalized Dirichlet series. -/
def DedekindQRH (N : ℝ) : Prop :=
  DedekindContinuationExists ∧
    ∀ (K : Type) [Field K] [NumberField K] (Z : DedekindContinuation K)
      (s : ℂ), IsNontrivialDedekindZero Z s → s.re ≤ 1 - 1 / N

/-- The ordinary formulation, choosing one continued zeta function per
field, implies the universal formulation above. Uniqueness justifies the
passage, so the QRH interface asks for no stronger zero-free result. -/
theorem dedekindQRH_of_one_continuation_each {N : ℝ}
    (h : ∀ (K : Type) [Field K] [NumberField K],
      ∃ Z : DedekindContinuation K, ∀ s : ℂ,
        IsNontrivialDedekindZero Z s → s.re ≤ 1 - 1 / N) :
    DedekindQRH N := by
  constructor
  · intro K _ _
    obtain ⟨Z, _⟩ := h K
    exact ⟨Z⟩
  · intro K _ _ Z s hs
    obtain ⟨W, hW⟩ := h K
    apply hW s
    refine ⟨hs.1, hs.2.1, ?_⟩
    have hsne : s ≠ 1 := by
      intro heq
      have hlt := hs.2.1
      simp [heq] at hlt
    rw [← Z.eq_of_ne_one W hsne]
    exact hs.2.2

/-- Extract a continued function from the explicitly supplied classical
existence statement. This uses ordinary classical choice, not an axiom
asserting analytic continuation. -/
noncomputable def chooseDedekindContinuation
    (hexists : DedekindContinuationExists)
    (K : Type) [Field K] [NumberField K] : DedekindContinuation K :=
  Classical.choice (hexists K)

/-- Restrict the global hypothesis to any indexed list of actual zeros of
one number field. Repetition of zeros is allowed. -/
theorem dedekindQRH_bounds_zero_family
    {N : ℝ} (hQRH : DedekindQRH N)
    (K : Type) [Field K] [NumberField K] (Z : DedekindContinuation K)
    {ι : Type*} (zero : ι → ℂ)
    (hzero : ∀ ρ, IsNontrivialDedekindZero Z (zero ρ)) :
    ∀ ρ, (zero ρ).re ≤ 1 - 1 / N := by
  intro ρ
  exact hQRH.2 K Z (zero ρ) (hzero ρ)

/-- Restrict QRH simultaneously to a family of actual number fields and
its zeros. This is the exact quantifier order required by the Kummer
explicit-formula input; it is uniform in the prime parameter `q`.

To use it for the manuscript, construct `K q = ℚ(ζ_q, a^(1/q))` and prove
that the zero family in its explicit formula consists of these actual
nontrivial zeros. No claim of that construction is built into this lemma. -/
theorem dedekindQRH_bounds_numberField_family
    {N Y₀ : ℝ} (hQRH : DedekindQRH N)
    (K : ℕ → Type) [∀ q, Field (K q)] [∀ q, NumberField (K q)]
    (Z : ∀ q, DedekindContinuation (K q))
    {ι : ℕ → Type*} (zero : ∀ q, ι q → ℂ)
    (hzero : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
      ∀ ρ, IsNontrivialDedekindZero (Z q) (zero q ρ)) :
    ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
      ∀ ρ, (zero q ρ).re ≤ 1 - 1 / N := by
  intro q hq hY ρ
  exact hQRH.2 (K q) (Z q) (zero q ρ) (hzero q hq hY ρ)

end Artin
