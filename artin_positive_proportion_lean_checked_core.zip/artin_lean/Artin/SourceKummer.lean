module

public import Artin.ClassicalReduction

/-!
# The cited Kummer field bounds with their actual exceptional cutoff

The OpenAI paper *Primitive roots for every admissible integer base*
(4 October 2026), Lemma 9.1, equation (9.1), printed pages 60--61,
gives the degree and exact integer discriminant bound used here. Its
quantifier is "for every sufficiently large prime q", for each fixed a.
We preserve that quantifier instead of attributing a stronger global
irreducibility theorem to the source. The proof cites Neukirch [19],
Chapter I, §10 and Chapter III, §2, for the discriminant formulas.

Lemma 2.3, equation (2.5), printed page 6, gives the complete-splitting
criterion outside aq. Its ideal-count formulation below retains those
exceptions explicitly. Neither contract assumes a prime-count estimate.
-/

@[expose] public section
open Filter

namespace Artin.SourceKummer

/-- The field-arithmetic part of cited Lemma 9.1, with the source's eventual
prime cutoff and its literal integer discriminant bound. The source's
zero-free assertion is not needed or included in this arithmetic contract. -/
def SourceLemma9_1FieldBounds : Prop :=
  ∀ a : ℤ, 1 < a.natAbs → ∃ Q₀ : ℕ, ∀ q : ℕ, q.Prime → Q₀ < q →
    kummerDegree a q = q * (q - 1) ∧
      (NumberField.discr (KummerField a q)).natAbs ≤
        q ^ (q * (q - 2)) * (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1)

/-- The forward splitting implication in cited Lemma 2.3. Complete splitting
in this Galois splitting field means that the degree many primes above p
all have norm p; the conclusion uses precisely that ideal-count formulation.
For prime p and q, the two explicit exclusions are equivalent to p∤aq. -/
def SourceLemma2_3Splitting : Prop :=
  ∀ (a : ℤ) (q p : ℕ), a ≠ 0 → q.Prime → p.Prime →
    ¬ (p : ℤ) ∣ a → p ≠ q →
    q ∣ p - 1 → (a : ZMod p) ^ ((p - 1) / q) = 1 →
      Nat.card (PrimeIdealsOfNorm (KummerField a q) p) = kummerDegree a q

/-- The polynomial/cyclotomic form already used by the development is
exactly the same integer bound, with its factors reordered. -/
theorem discriminant_bound_rearranged {a : ℤ} {q : ℕ}
    (h : (NumberField.discr (KummerField a q)).natAbs ≤
      q ^ (q * (q - 2)) * (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1)) :
    (NumberField.discr (KummerField a q)).natAbs ≤
      (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1) * (q ^ (q - 2)) ^ q := by
  have he : q ^ (q * (q - 2)) * (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1) =
      (q ^ q * a.natAbs ^ (q - 1)) ^ (q - 1) * (q ^ (q - 2)) ^ q := by
    rw [← pow_mul, Nat.mul_comm (q - 2) q]
    exact mul_comm _ _
  exact h.trans_eq he

/-- The residue obstruction proves every exceptional-prime exclusion in
Lemma 2.3; none is hidden in a uniform splitting-count assumption. -/
theorem obstruction_ideal_count (source : SourceLemma2_3Splitting)
    {a : ℤ} {q p : ℕ} (hq : q.Prime) (hp : PowerResidueObstruction a q p) :
    Nat.card (PrimeIdealsOfNorm (KummerField a q) p) = kummerDegree a q := by
  obtain ⟨hqp, hpa⟩ := powerResidueObstruction_unramified_conditions hq hp
  have ha : a ≠ 0 := by
    intro ha
    exact hpa (ha ▸ dvd_zero _)
  exact source a q p ha hq hp.1 hpa (ne_of_gt hqp) hp.2.1 hp.2.2

/-- In particular the previously exposed splitting contract follows from
the cited splitting test. The unused odd-prime restriction only weakens it. -/
theorem classicalKummerSplitting_of_source (source : SourceLemma2_3Splitting) :
    ClassicalKummerSplitting := by
  intro a q p hq _ hp
  exact obstruction_ideal_count source hq hp

/-- The actual arithmetic package follows from the cited field bounds at
a fixed enlarged threshold. This does not assume that the source's onset
is `|a|`, nor does it assume a bound with a field-dependent constant. -/
theorem exists_kummerArithmeticFacts_of_sources {a : ℤ} (ha : Admissible a)
    (hfield : SourceLemma9_1FieldBounds) (hsplit : SourceLemma2_3Splitting) :
    ∃ Y₀ : ℝ, (a.natAbs : ℝ) ≤ Y₀ ∧ Nonempty (KummerArithmeticFacts a Y₀) := by
  obtain ⟨Q₀, hQ⟩ := hfield a ha.natAbs_gt_one
  let Y₀ : ℝ := max (a.natAbs : ℝ) (Q₀ : ℝ)
  have hlarge : ∀ q : ℕ, Y₀ < (q : ℝ) → Q₀ < q := by
    intro q hq
    exact_mod_cast (le_max_right (a.natAbs : ℝ) (Q₀ : ℝ)).trans_lt hq
  refine ⟨Y₀, le_max_left _ _, ⟨{
    degree_eq := fun q hq hY => (hQ q hq (hlarge q hY)).1
    normalized_discriminant := ?_
    splitIdeals := fun q hq _ => splitPrimeIdealEmbedding
      (fun p hp => obstruction_ideal_count hsplit hq hp)
    split_norm := ?_ }⟩⟩
  · intro q hq hY
    have hh := hQ q hq (hlarge q hY)
    exact normalizedDiscriminant_of_polynomial_bound ha.natAbs_gt_one hq hh.1
      (discriminant_bound_rearranged hh.2)
  · intro q hq hY p j
    exact splitPrimeIdealEmbedding_norm _ p j

/-- The small-index estimate with the source's fixed eventual arithmetic
cutoff and the separately accepted classical analytic formulas. -/
theorem exists_smallIndexEstimate_of_sources
    {a : ℤ} (ha : Admissible a) {A B R T H : ℝ}
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing B)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hfield : SourceLemma9_1FieldBounds) (hsplit : SourceLemma2_3Splitting)
    (htail : ReciprocalPrimeTail H) :
    ∃ Y₀ : ℝ, (a.natAbs : ℝ) ≤ Y₀ ∧
      SmallIndexEstimate DedekindQRH a (fixedSplittingSmoothing.mass * H) Y₀ := by
  obtain ⟨Y₀, hY₀, ⟨arith⟩⟩ := exists_kummerArithmeticFacts_of_sources ha hfield hsplit
  exact ⟨Y₀, hY₀, smallIndexEstimate_of_classical_theorems hexists fixedSplittingSmoothing
    hA hB hR hcount hdecay hformula arith htail⟩

/-- Enlarging the fixed sieve threshold absorbs the cited arithmetic onset.
Thus the final reduction needs only the literal source field bounds, not
the stronger globally quantified degree/discriminant contracts. -/
theorem quantitative_prime_proportion_of_sieve_and_sources
    (a : ℤ) (ha : Admissible a)
    {S C₂ κ c₀ d B Y₀ ε₀ A Bm R T : ℝ}
    (hS : 0 < S) (hc₀ : 0 < c₀) (hd : 0 < d) (hB : 0 < B)
    (hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀) (hk : C₂ * κ ≤ S / 8)
    (sieve : ∀ ε Y : ℝ, 0 < ε → ε < ε₀ → Y₀ ≤ Y → 1 < Y →
      Nonempty (CandidateSieveData a S C₂ κ c₀ d B ε Y))
    (hexists : DedekindContinuationExists)
    (hA : 0 ≤ A) (hBm : 0 ≤ Bm) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay fixedSplittingSmoothing Bm)
    (hformula : ClassicalSmoothedExplicitFormula fixedSplittingSmoothing R T)
    (hfield : SourceLemma9_1FieldBounds) (hsplit : SourceLemma2_3Splitting) :
    ∃ c : ℝ, 0 < c ∧ ∀ N : ℝ, 2 ≤ N → DedekindQRH N →
      ∀ᶠ x : ℝ in atTop,
        (c / (N * Real.log N)) * (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ primitiveCount a x := by
  obtain ⟨Y₁, hY₁, ⟨arith⟩⟩ := exists_kummerArithmeticFacts_of_sources ha hfield hsplit
  exact quantitative_prime_proportion_of_sieve_and_classical_formulas a ha
    hS hc₀ hd hB (hY₀.trans_le (le_max_left Y₀ Y₁)) hε₀ hk
    (fun ε Y hε hεmax hY hYone => sieve ε Y hε hεmax
      ((le_max_left Y₀ Y₁).trans hY) hYone)
    hexists hA hBm hR hcount hdecay hformula
    (arith.mono (le_max_right Y₀ Y₁))

end Artin.SourceKummer
