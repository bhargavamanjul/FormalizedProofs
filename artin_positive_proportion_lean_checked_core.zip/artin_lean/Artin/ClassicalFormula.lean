module

public import Artin.KummerAnalytic
public import Artin.DedekindZeroOrder
public import Mathlib.Analysis.MellinTransform
public import Mathlib.Analysis.Analytic.Order
public import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
public import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# Concrete objects and the classical explicit-formula boundary

The accepted analytic facts in this file concern the actual Dedekind continuation,
its zeros with analytic multiplicity, prime ideals, and a Mellin transform.
The absolute zero-weight estimate and the triangle inequality are deductions.
No theorem here asserts the accepted facts, and no global axioms are added.
-/

@[expose] public section

namespace Artin

open scoped BigOperators Topology ContDiff

/-- Nonzero prime integral ideals of the actual ring of integers. -/
abbrev DedekindPrimeIdeal (K : Type) [Field K] [NumberField K] :=
  {P : Ideal (NumberField.RingOfIntegers K) // P.IsPrime ∧ P ≠ ⊥}

/-- One fixed positive compactly supported smoothing, as in manuscript §10. -/
structure SplittingSmoothing where
  f : ℝ → ℝ
  smooth : ContDiff ℝ ∞ f
  nonneg : ∀ t, 0 ≤ f t
  supported : Function.support f ⊆ Set.Ioo (1 / 2) 3
  majorizes : ∀ t ∈ Set.Icc (1 : ℝ) 2, 1 ≤ f t

noncomputable def SplittingSmoothing.mellin (f : SplittingSmoothing) (s : ℂ) : ℂ :=
  _root_.mellin (fun t => (f.f t : ℂ)) s

noncomputable def SplittingSmoothing.mass (f : SplittingSmoothing) : ℝ :=
  (f.mellin 1).re

/-- A concrete choice of the smoothing; its existence is proved in mathlib
by the smooth bump construction on the real line. -/
noncomputable def fixedSplittingSmoothing : SplittingSmoothing := by
  let b : ContDiffBump (3 / 2 : ℝ) := ⟨1 / 2, 1, by norm_num, by norm_num⟩
  refine ⟨b, b.contDiff, b.nonneg', ?_, ?_⟩
  · intro t ht
    rw [b.support_eq] at ht
    have h : |t - 3 / 2| < 1 := by simpa [Real.dist_eq, b] using ht
    have h' := abs_lt.mp h
    constructor <;> linarith
  · intro t ht
    have h : t ∈ Metric.closedBall (3 / 2 : ℝ) b.rIn := by
      simp only [Metric.mem_closedBall, Real.dist_eq, b]
      rw [abs_le]
      constructor <;> linarith [ht.1, ht.2]
    exact (b.one_of_mem_closedBall h).ge

/-- The actual prime-ideal-power contribution. Summing over `k : ℕ` means
positive powers `k + 1`, each with von Mangoldt weight `log N(P)`. -/
noncomputable def idealPrimePowerTerm (K : Type) [Field K] [NumberField K]
    (f : SplittingSmoothing) (x : ℝ) (v : DedekindPrimeIdeal K × ℕ) : ℝ :=
  Real.log (Ideal.absNorm v.1.1 : ℝ) *
    f.f ((Ideal.absNorm v.1.1 : ℝ) ^ (v.2 + 1) / x)

noncomputable def smoothedIdealSum (K : Type) [Field K] [NumberField K]
    (f : SplittingSmoothing) (x : ℝ) : ℝ :=
  ∑' v, idealPrimePowerTerm K f x v

/-- This index contains every nontrivial zero, repeated exactly its analytic
order. It is not an arbitrary family of some zeros. -/
abbrev DedekindZeroIndex {K : Type} [Field K] [NumberField K]
    (Z : DedekindContinuation K) :=
  Σ s : {s : ℂ // IsNontrivialDedekindZero Z s}, Fin (analyticOrderNatAt Z.zeta s)

def DedekindZeroIndex.point {K : Type} [Field K] [NumberField K]
    {Z : DedekindContinuation K} (ρ : DedekindZeroIndex Z) : ℂ := ρ.1.1

/-- Every nontrivial zero is represented by the multiplicity index. -/
theorem DedekindZeroIndex.covers {K : Type} [Field K] [NumberField K]
    {Z : DedekindContinuation K} {s : ℂ} (hs : IsNontrivialDedekindZero Z s) :
    ∃ ρ : DedekindZeroIndex Z, ρ.point = s := by
  have hsne : s ≠ 1 := by intro h; simpa [h] using hs.2.1
  have ha : AnalyticAt ℂ Z.zeta s :=
    Z.holomorphic.analyticOnNhd isOpen_compl_singleton s (by simpa using hsne)
  have ho : 0 < analyticOrderNatAt Z.zeta s :=
    ENat.toNat_pos ((ha.analyticOrderAt_ne_zero).2 hs.2.2) (Z.analyticOrderAt_ne_top hsne)
  exact ⟨⟨⟨s, hs⟩, ⟨0, ho⟩⟩, rfl⟩

/-- Dyadic height shell, including the low zeros in shell zero. -/
noncomputable def zeroHeightShell {K : Type} [Field K] [NumberField K]
    {Z : DedekindContinuation K} (ρ : DedekindZeroIndex Z) : ℕ :=
  ⌊Real.log (1 + |ρ.point.im|) / Real.log 2⌋₊

noncomputable def mellinZeroWeight (f : SplittingSmoothing) {K : Type}
    [Field K] [NumberField K] {Z : DedekindContinuation K}
    (ρ : DedekindZeroIndex Z) : ℝ := ‖f.mellin ρ.point‖

noncomputable def mellinZeroTerm (f : SplittingSmoothing) (x : ℝ) {K : Type}
    [Field K] [NumberField K] {Z : DedekindContinuation K}
    (ρ : DedekindZeroIndex Z) : ℂ := (x : ℂ) ^ ρ.point * f.mellin ρ.point

noncomputable def smoothedZeroSum (f : SplittingSmoothing) (x : ℝ) {K : Type}
    [Field K] [NumberField K] (Z : DedekindContinuation K) : ℝ :=
  (∑' ρ : DedekindZeroIndex Z, mellinZeroTerm f x ρ).re

/-- Defining the remainder by the actual formula's difference eliminates any
free choice of a remainder. The classical formula is its asserted bound. -/
noncomputable def smoothedRemainder (K : Type) [Field K] [NumberField K]
    (f : SplittingSmoothing) (Z : DedekindContinuation K) (x : ℝ) : ℝ :=
  smoothedIdealSum K f x - f.mass * x + smoothedZeroSum f x Z

/-- Quantitative dyadic specialization of the uniform zero-counting theorem.
`A` is absolute and independent of the number field and the strip width.
The loose `4^k` bound follows from `N_K(T) ≪ (T+1)(log |D|+n log(T+3))`.
Finiteness is included because `Nat.card` alone would be zero for infinite sets. -/
def ClassicalDyadicZeroCount (A : ℝ) : Prop :=
  ∀ (K : Type) [Field K] [NumberField K] (Z : DedekindContinuation K) (k : ℕ),
    Finite {ρ : DedekindZeroIndex Z // zeroHeightShell ρ = k} ∧
    (Nat.card {ρ : DedekindZeroIndex Z // zeroHeightShell ρ = k} : ℝ) ≤
      A * (Real.log ((NumberField.discr K).natAbs : ℝ) + Module.finrank ℚ K) * 4 ^ k

/-- A dyadic form of cubic vertical Mellin decay for this one fixed smoothing.
It involves actual Mellin integrals, and no number-field count or target bound. -/
def ClassicalMellinDecay (f : SplittingSmoothing) (B : ℝ) : Prop :=
  ∀ s : ℂ, 0 ≤ s.re → s.re ≤ 1 →
    ‖f.mellin s‖ ≤ B * (1 / 8 : ℝ) ^ ⌊Real.log (1 + |s.im|) / Real.log 2⌋₊

/-- A finite-shell summation lemma. Counting grows by `4^k`, whereas individual
weights decay by `8^-k`; their total is bounded by a geometric series. -/
theorem weight_mass_of_dyadic_count {ι : Type} (shell : ι → ℕ) (w : ι → ℝ)
    {D B : ℝ} (hB : 0 ≤ B) (hw : ∀ i, 0 ≤ w i)
    (hfinite : ∀ k, Finite {i // shell i = k})
    (hcount : ∀ k, (Nat.card {i // shell i = k} : ℝ) ≤ D * 4 ^ k)
    (hdecay : ∀ i, w i ≤ B * (1 / 8 : ℝ) ^ shell i) :
    Summable w ∧ (∑' i, w i) ≤ 2 * D * B := by
  classical
  let F : ℕ → ℝ := fun k => ∑' i : {i // shell i = k}, w i
  have hFnonneg : ∀ k, 0 ≤ F k := fun k => tsum_nonneg (fun i => hw i)
  have hbound : ∀ k, F k ≤ (D * B) * (1 / 2 : ℝ) ^ k := by
    intro k
    let := hfinite k
    let := Fintype.ofFinite {i // shell i = k}
    calc
      F k ≤ ∑' _i : {i // shell i = k}, B * (1 / 8 : ℝ) ^ k := by
        apply ((hasSum_fintype _).summable).tsum_le_tsum (fun i => ?_) ((hasSum_fintype _).summable)
        simpa only [i.property] using hdecay i
      _ = (Nat.card {i // shell i = k} : ℝ) * (B * (1 / 8 : ℝ) ^ k) := by
        simp [tsum_fintype, Nat.card_eq_fintype_card]
      _ ≤ (D * 4 ^ k) * (B * (1 / 8 : ℝ) ^ k) :=
        mul_le_mul_of_nonneg_right (hcount k) (by positivity)
      _ = (D * B) * (1 / 2 : ℝ) ^ k := by
        rw [show (1 / 2 : ℝ) = 4 * (1 / 8) by norm_num, mul_pow]
        ring
  have hgeom : Summable (fun k : ℕ => (D * B) * (1 / 2 : ℝ) ^ k) :=
    (summable_geometric_of_abs_lt_one (by norm_num : |(1 / 2 : ℝ)| < 1)).mul_left _
  have hF : Summable F := Summable.of_nonneg_of_le hFnonneg hbound hgeom
  have hs : Summable w := by
    apply (summable_partition hw (s := fun k => {i | shell i = k}) ?_).2
    · refine ⟨?_, hF⟩
      intro k
      change Summable (fun i : {i // shell i = k} => w i)
      let := hfinite k
      let := Fintype.ofFinite {i // shell i = k}
      exact (hasSum_fintype _).summable
    · intro i
      exact ⟨shell i, rfl, fun _ h => h.symm⟩
  refine ⟨hs, ?_⟩
  have heq : (∑' i, w i) = ∑' k, F k := by
    exact (hs.hasSum.tsum_fiberwise shell).tsum_eq.symm
  rw [heq]
  calc
    (∑' k, F k) ≤ ∑' k : ℕ, (D * B) * (1 / 2 : ℝ) ^ k :=
      hF.tsum_le_tsum hbound hgeom
    _ = 2 * D * B := by
      rw [tsum_mul_left, tsum_geometric_of_abs_lt_one (by norm_num : |(1 / 2 : ℝ)| < 1)]
      norm_num
      ring

/-- The actual Mellin zero series is absolutely summable, and taking its real
part obeys the triangle inequality used by the splitting argument. -/
theorem smoothedZeroSum_triangle (f : SplittingSmoothing) {K : Type}
    [Field K] [NumberField K] (Z : DedekindContinuation K) {x : ℝ}
    (hx : 1 < x) (hw : Summable (mellinZeroWeight f (Z := Z))) :
    |smoothedZeroSum f x Z| ≤
      ∑' ρ : DedekindZeroIndex Z, x ^ ρ.point.re * mellinZeroWeight f ρ := by
  have hx0 : 0 < x := by linarith
  have hvar : Summable (fun ρ : DedekindZeroIndex Z =>
      x ^ ρ.point.re * mellinZeroWeight f ρ) := by
    apply Summable.of_nonneg_of_le (fun ρ => mul_nonneg (Real.rpow_nonneg hx0.le _) (norm_nonneg _)) _ (hw.mul_left x)
    intro ρ
    apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
    simpa only [Real.rpow_one, DedekindZeroIndex.point] using Real.rpow_le_rpow_of_exponent_le hx.le ρ.1.2.2.1.le
  have hnorm : ∀ ρ : DedekindZeroIndex Z,
      ‖mellinZeroTerm f x ρ‖ = x ^ ρ.point.re * mellinZeroWeight f ρ := by
    intro ρ
    simp [mellinZeroTerm, mellinZeroWeight,
      Complex.norm_cpow_eq_rpow_re_of_pos hx0]
  have hn : Summable (fun ρ : DedekindZeroIndex Z => ‖mellinZeroTerm f x ρ‖) :=
    hvar.congr (fun ρ => (hnorm ρ).symm)
  calc
    |smoothedZeroSum f x Z| ≤ ‖∑' ρ : DedekindZeroIndex Z, mellinZeroTerm f x ρ‖ :=
      Complex.abs_re_le_norm _
    _ ≤ ∑' ρ : DedekindZeroIndex Z, ‖mellinZeroTerm f x ρ‖ := norm_tsum_le_tsum_norm hn
    _ = _ := tsum_congr hnorm

/-- Precise accepted smoothed explicit formula: the remainder is the defined
difference of actual ideal and zero sums. The threshold and constant precede
all number fields. Absolute convergence of the ideal sum is explicit. -/
def ClassicalSmoothedExplicitFormula (f : SplittingSmoothing) (R T : ℝ) : Prop :=
  ∀ (K : Type) [Field K] [NumberField K] (Z : DedekindContinuation K),
    ∀ x : ℝ, 1 < x → T ≤ x →
      Summable (idealPrimePowerTerm K f x) ∧
      |smoothedRemainder K f Z x| ≤ R * (Module.finrank ℚ K : ℝ) * Real.log x

/-- Exact algebraic specialization still required at the source boundary:
the Kummer degree/discriminant calculation and the complete-splitting
criterion, expressed as distinct prime ideals of norm `p`. This is much
stronger information than an asserted inequality for a prime count. -/
structure KummerArithmeticFacts (a : ℤ) (Y₀ : ℝ) where
  degree_eq : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    kummerDegree a q = q * (q - 1)
  normalized_discriminant : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    kummerLogDiscriminant a q / (kummerDegree a q : ℝ) ≤
      2 * Real.log (q : ℝ) + Real.log (a.natAbs : ℝ)
  splitIdeals : ∀ q : ℕ, q.Prime → Y₀ < (q : ℝ) →
    ({p : ℕ // PowerResidueObstruction a q p} × Fin (kummerDegree a q)) ↪
      DedekindPrimeIdeal (KummerField a q)
  split_norm : ∀ (q : ℕ) (hq : q.Prime) (hY : Y₀ < (q : ℝ)) p j,
    Ideal.absNorm (splitIdeals q hq hY (p, j)).1 = p.1

theorem idealPrimePowerTerm_nonneg (K : Type) [Field K] [NumberField K]
    (f : SplittingSmoothing) (x : ℝ) (v : DedekindPrimeIdeal K × ℕ) :
    0 ≤ idealPrimePowerTerm K f x v :=
  mul_nonneg (Real.log_natCast_nonneg _) (f.nonneg _)

/-- Positivity and the prime ideals supplied by complete splitting give the
manuscript's domination inequality; this inequality is proved, not accepted. -/
theorem idealSum_dominates_powerResidueCount {a : ℤ} {Y₀ : ℝ}
    (arith : KummerArithmeticFacts a Y₀) (f : SplittingSmoothing)
    {q : ℕ} (hq : q.Prime) (hY : Y₀ < (q : ℝ)) {x : ℝ} (hx : 1 < x)
    (hs : Summable (idealPrimePowerTerm (KummerField a q) f x)) :
    (kummerDegree a q : ℝ) * Real.log x * powerResidueCount a q x ≤
      smoothedIdealSum (KummerField a q) f x := by
  classical
  let S := (ambientPrimes x).filter (PowerResidueObstruction a q)
  let J := {p // p ∈ S} × Fin (kummerDegree a q)
  let e : J → DedekindPrimeIdeal (KummerField a q) × ℕ := fun v =>
    (arith.splitIdeals q hq hY (⟨v.1.1, (Finset.mem_filter.mp v.1.2).2⟩, v.2), 0)
  have he : Function.Injective e := by
    intro u v huv
    have h := (arith.splitIdeals q hq hY).injective (congrArg Prod.fst huv)
    apply Prod.ext
    · exact Subtype.ext (congrArg (fun t => t.1.1) h)
    · exact congrArg (fun t : {p : ℕ // PowerResidueObstruction a q p} × Fin (kummerDegree a q) => t.2) h
  have hterm : ∀ v : J, Real.log x ≤ idealPrimePowerTerm (KummerField a q) f x (e v) := by
    intro v
    have hp : v.1.1 ∈ ambientPrimes x := (Finset.mem_filter.mp v.1.2).1
    have hx0 : 0 < x := by linarith
    have hlow : x ≤ (v.1.1 : ℝ) := ambientPrimes_lower_bound hp
    have hupp : (v.1.1 : ℝ) ≤ 2 * x := by
      have hp' := Nat.mem_primesLE.mp (Finset.mem_filter.mp hp).1
      exact (Nat.cast_le.mpr hp'.1).trans (Nat.floor_le (by positivity))
    have hlog : Real.log x ≤ Real.log (v.1.1 : ℝ) := Real.log_le_log hx0 hlow
    have hf : 1 ≤ f.f ((v.1.1 : ℝ) / x) :=
      f.majorizes _ ⟨(le_div_iff₀ hx0).2 (by simpa using hlow),
        (div_le_iff₀ hx0).2 hupp⟩
    change Real.log x ≤ Real.log (Ideal.absNorm (e v).1.1 : ℝ) * _
    simp only [e, arith.split_norm, zero_add, pow_one]
    calc
      Real.log x ≤ Real.log (v.1.1 : ℝ) := hlog
      _ ≤ Real.log (v.1.1 : ℝ) * f.f ((v.1.1 : ℝ) / x) := by
        exact le_mul_of_one_le_right (Real.log_natCast_nonneg _) hf
  have hsum : (∑' _v : J, Real.log x) ≤ smoothedIdealSum (KummerField a q) f x :=
    ((hasSum_fintype _).summable).tsum_le_tsum_of_inj e he (fun v _ => idealPrimePowerTerm_nonneg _ f x v) hterm hs
  simpa [J, S, powerResidueCount, filteredCard, tsum_fintype, mul_comm,
    mul_left_comm, mul_assoc] using hsum

/-- Construct the former sufficient package from three individually stated
classical analytic theorems and the exact Kummer arithmetic facts. The mass
bound, domination and triangle estimate are proved above. -/
noncomputable def classicalKummerInputs_of_classical
    {a : ℤ} {Y₀ A B R T : ℝ}
    (hexists : DedekindContinuationExists) (f : SplittingSmoothing)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay f B)
    (hformula : ClassicalSmoothedExplicitFormula f R T)
    (arith : KummerArithmeticFacts a Y₀) :
    ClassicalKummerInputs a f.mass (2 * A * B + R) Y₀ := by
  let Z : ∀ q, DedekindContinuation (KummerField a q) :=
    fun q => chooseDedekindContinuation hexists (KummerField a q)
  have hweights : ∀ q, Summable (mellinZeroWeight f (Z := Z q)) ∧
      (∑' ρ : DedekindZeroIndex (Z q), mellinZeroWeight f ρ) ≤
        (2 * A * B) * (kummerLogDiscriminant a q + kummerDegree a q) := by
    intro q
    have h := weight_mass_of_dyadic_count (zeroHeightShell (Z := Z q))
      (mellinZeroWeight f) hB (fun _ => norm_nonneg _)
      (fun k => (hcount (KummerField a q) (Z q) k).1)
      (fun k => (hcount (KummerField a q) (Z q) k).2)
      (fun ρ => hdecay ρ.point ρ.1.2.1.le ρ.1.2.2.1.le)
    refine ⟨h.1, ?_⟩
    convert h.2 using 1
    unfold kummerLogDiscriminant kummerDegree
    ring
  refine {
    threshold := T
    continuation := Z
    Zero := fun q => DedekindZeroIndex (Z q)
    zero := fun _ ρ => ρ.point
    nontrivial := fun _ _ _ ρ => ρ.1.2
    weight := fun _ ρ => mellinZeroWeight f ρ
    idealSum := fun q x => smoothedIdealSum (KummerField a q) f x
    zeroSum := fun q x => smoothedZeroSum f x (Z q)
    remainder := fun q x => smoothedRemainder (KummerField a q) f (Z q) x
    degree_eq := arith.degree_eq
    normalized_discriminant := arith.normalized_discriminant
    weight_nonneg := fun _ _ _ _ => norm_nonneg _
    weight_summable := fun q _ _ => (hweights q).1
    weight_mass := ?_
    dominance := ?_
    formula := ?_
    zero_triangle := ?_
    remainder_bound := ?_ }
  · intro q _ _
    refine (hweights q).2.trans ?_
    have hD : 0 ≤ kummerLogDiscriminant a q + (kummerDegree a q : ℝ) :=
      add_nonneg (Real.log_natCast_nonneg _) (Nat.cast_nonneg _)
    exact mul_le_mul_of_nonneg_right (le_add_of_nonneg_right hR) hD
  · intro x hx hT q hq hY
    exact idealSum_dominates_powerResidueCount arith f hq hY hx
      (hformula (KummerField a q) (Z q) x hx hT).1
  · intro x _ _ q _ _
    unfold smoothedRemainder
    ring
  · intro x hx _ q _ _
    exact smoothedZeroSum_triangle f (Z q) hx (hweights q).1
  · intro x hx hT q _ _
    refine (hformula (KummerField a q) (Z q) x hx hT).2.trans ?_
    have hAB : 0 ≤ 2 * A * B := by positivity
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (le_add_of_nonneg_left hAB) (Nat.cast_nonneg _))
      (Real.log_pos hx).le

theorem SplittingSmoothing.mass_nonneg (f : SplittingSmoothing) : 0 ≤ f.mass := by
  simp only [SplittingSmoothing.mass, SplittingSmoothing.mellin, _root_.mellin,
    sub_self, Complex.cpow_zero, one_smul]
  rw [integral_complex_ofReal]
  simpa using MeasureTheory.integral_nonneg (fun t => f.nonneg t)

/-- The smoothing mass is strictly positive: the function is nonnegative,
compactly supported in the positive half-line, and at least one at 1. -/
theorem SplittingSmoothing.mass_pos (f : SplittingSmoothing) : 0 < f.mass := by
  simp only [SplittingSmoothing.mass, SplittingSmoothing.mellin, _root_.mellin,
    sub_self, Complex.cpow_zero, one_smul]
  rw [integral_complex_ofReal, Complex.ofReal_re]
  rw [MeasureTheory.setIntegral_eq_integral_of_forall_compl_eq_zero (fun t ht => ?_)]
  · apply f.smooth.continuous.integral_pos_of_hasCompactSupport_nonneg_nonzero
      (x := (1 : ℝ))
    · apply HasCompactSupport.of_support_subset_isCompact isCompact_Icc
      intro t ht
      exact ⟨(f.supported ht).1.le, (f.supported ht).2.le⟩
    · exact f.nonneg
    · have h := f.majorizes 1 ⟨le_rfl, by norm_num⟩
      linarith
  · by_contra h
    have hpos := (f.supported h).1
    have hnot : ¬ (0 : ℝ) < t := ht
    linarith

theorem fixedSplittingSmoothing_mass_pos : 0 < fixedSplittingSmoothing.mass :=
  fixedSplittingSmoothing.mass_pos

/-- The actual small-index bound with every accepted analytic statement
visible as a theorem argument. The smoothing mass is fixed and nonnegative. -/
theorem smallIndexEstimate_of_classical_theorems
    {a : ℤ} {Y₀ A B R T H : ℝ}
    (hexists : DedekindContinuationExists) (f : SplittingSmoothing)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hR : 0 ≤ R)
    (hcount : ClassicalDyadicZeroCount A)
    (hdecay : ClassicalMellinDecay f B)
    (hformula : ClassicalSmoothedExplicitFormula f R T)
    (arith : KummerArithmeticFacts a Y₀) (htail : ReciprocalPrimeTail H) :
    SmallIndexEstimate DedekindQRH a (f.mass * H) Y₀ :=
  smallIndexEstimate_of_classicalKummerInputs f.mass_nonneg (by positivity)
    (classicalKummerInputs_of_classical hexists f hA hB hR hcount hdecay hformula arith) htail

end Artin
