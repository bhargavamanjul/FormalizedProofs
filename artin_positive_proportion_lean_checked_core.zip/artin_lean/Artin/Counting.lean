module

public import Mathlib.Algebra.Order.BigOperators.Group.Finset
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Basic.Real.Basic
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum

/-!
# Finite weighted counting for the Artin argument

These are exact finite inequalities.  They do not assume any analytic estimate,
and do not by themselves establish the manuscript's candidate-prime estimate.
Their intended uses are the harmonic-mass truncations in Section 4 and the
successive subtractions in Sections 7--11.
-/

open scoped BigOperators

@[expose] public section

namespace Artin

noncomputable def filteredCard {α : Type*} (s : Finset α) (P : α → Prop) : ℕ := by
  classical
  exact (s.filter P).card

noncomputable def weightedCount {α : Type*} (s : Finset α) (w : α → ℝ)
    (P : α → Prop) : ℝ := by
  classical
  exact ∑ i ∈ s.filter P, w i

/-- A bounded nonnegative weight may be removed at the cost of its pointwise
upper bound. Nonnegativity is not actually needed for this particular step. -/
theorem weighted_sum_le_card_mul {α : Type*} (s : Finset α) (w : α → ℝ)
    (B : ℝ) (hB : ∀ i ∈ s, w i ≤ B) :
    (∑ i ∈ s, w i) ≤ (s.card : ℝ) * B := by
  calc
    (∑ i ∈ s, w i) ≤ ∑ _i ∈ s, B := Finset.sum_le_sum hB
    _ = (s.card : ℝ) * B := by simp

/-- Convert a lower bound on a finite weighted sum into a counting bound. -/
theorem weighted_count_lower_bound {α : Type*} (s : Finset α) (w : α → ℝ)
    {B : ℝ} (hB : 0 < B) (hupper : ∀ i ∈ s, w i ≤ B) :
    (∑ i ∈ s, w i) / B ≤ (s.card : ℝ) := by
  exact (div_le_iff₀ hB).2 (weighted_sum_le_card_mul s w B hupper)

/-- A union bound with weights. The four sets are allowed to overlap. -/
theorem weighted_cover_four {α : Type*} (s : Finset α) (w : α → ℝ)
    (P Q R T : α → Prop) (hpositive : ∀ i ∈ s, 0 ≤ w i)
    (hcover : ∀ i ∈ s, P i ∨ Q i ∨ R i ∨ T i) :
    (∑ i ∈ s, w i) ≤
      weightedCount s w P + weightedCount s w Q +
      weightedCount s w R + weightedCount s w T := by
  classical
  simp only [weightedCount, Finset.sum_filter]
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro i hi
  have hw := hpositive i hi
  have hc := hcover i hi
  by_cases hp : P i <;> by_cases hq : Q i <;>
    by_cases hr : R i <;> by_cases ht : T i <;> simp_all
  all_goals
    have hnonneg := hpositive i hi
    linarith

/-- The finite bookkeeping behind the least-factor, semiprime, and cofactor-tail
subtractions. The estimates `hinitial`, `hfirst`, `hsecond`, and `hthird` remain
explicit hypotheses; they are not asserted as analytic facts here. -/
theorem count_after_three_weighted_losses {α : Type*}
    (s : Finset α) (w : α → ℝ) (candidate first second third : α → Prop)
    {B initial loss₁ loss₂ loss₃ : ℝ}
    (hB : 0 < B) (hpositive : ∀ i ∈ s, 0 ≤ w i)
    (hupper : ∀ i ∈ s, w i ≤ B)
    (hcover : ∀ i ∈ s, candidate i ∨ first i ∨ second i ∨ third i)
    (hinitial : initial ≤ ∑ i ∈ s, w i)
    (hfirst : weightedCount s w first ≤ loss₁)
    (hsecond : weightedCount s w second ≤ loss₂)
    (hthird : weightedCount s w third ≤ loss₃) :
    (initial - loss₁ - loss₂ - loss₃) / B ≤
      (filteredCard s candidate : ℝ) := by
  classical
  simp only [filteredCard]
  have hcover' := weighted_cover_four s w candidate first second third
    hpositive hcover
  have hweight : weightedCount s w candidate ≤
      ((s.filter candidate).card : ℝ) * B := by
    apply weighted_sum_le_card_mul
    intro i hi
    exact hupper i (Finset.mem_filter.mp hi).1
  apply (div_le_iff₀ hB).2
  linarith

/-- Cardinality version of the final two exceptional-prime subtractions. -/
theorem count_after_two_exceptional_sets {α : Type*}
    (s : Finset α) (good small large : α → Prop)
    {initial smallBound largeBound : ℝ}
    (hcover : ∀ i ∈ s, good i ∨ small i ∨ large i)
    (hinitial : initial ≤ (s.card : ℝ))
    (hsmall : (filteredCard s small : ℝ) ≤ smallBound)
    (hlarge : (filteredCard s large : ℝ) ≤ largeBound) :
    initial - smallBound - largeBound ≤ (filteredCard s good : ℝ) := by
  classical
  have h := count_after_three_weighted_losses s (fun _ ↦ (1 : ℝ))
    good small large (fun _ ↦ False) (B := 1)
    (initial := initial) (loss₁ := smallBound) (loss₂ := largeBound) (loss₃ := 0)
    (by norm_num) (by simp) (by simp)
    (by intro i hi; rcases hcover i hi with hg | hs | hl
        · exact Or.inl hg
        · exact Or.inr (Or.inl hs)
        · exact Or.inr (Or.inr (Or.inl hl)))
    (by simpa using hinitial)
    (by simpa [weightedCount, filteredCard] using hsmall)
    (by simpa [weightedCount, filteredCard] using hlarge)
    (by simp [weightedCount])
  simpa using h

/-- Finite weighted Markov inequality in the exact form used to discard large
cofactors. The moment function may be `log r` or a reciprocal-prime sum. -/
theorem weighted_markov {α : Type*} (s : Finset α) (w f : α → ℝ)
    {T : ℝ} (hT : 0 < T) (hw : ∀ i ∈ s, 0 ≤ w i)
    (hf : ∀ i ∈ s, 0 ≤ f i) :
    weightedCount s w (fun i ↦ T < f i) ≤ (∑ i ∈ s, w i * f i) / T := by
  classical
  apply (le_div_iff₀ hT).2
  simp only [weightedCount, Finset.sum_filter, Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i hi
  by_cases hif : T < f i
  · simp only [ite_eq_left hif]
    exact mul_le_mul_of_nonneg_left hif.le (hw i hi)
  · simp only [ite_eq_right hif, zero_mul]
    exact mul_nonneg (hw i hi) (hf i hi)

/-- Two Markov truncations retain the original weighted mass less their two
moment bounds. This is the finite probabilistic step in the cofactor lemma. -/
theorem mass_after_two_markov_truncations {α : Type*}
    (s : Finset α) (w f g : α → ℝ) {R T : ℝ}
    (hR : 0 < R) (hT : 0 < T)
    (hw : ∀ i ∈ s, 0 ≤ w i)
    (hf : ∀ i ∈ s, 0 ≤ f i) (hg : ∀ i ∈ s, 0 ≤ g i) :
    (∑ i ∈ s, w i) - (∑ i ∈ s, w i * f i) / R -
      (∑ i ∈ s, w i * g i) / T ≤
      weightedCount s w (fun i ↦ f i ≤ R ∧ g i ≤ T) := by
  classical
  have hcover := weighted_cover_four s w (fun i ↦ f i ≤ R ∧ g i ≤ T)
    (fun i ↦ R < f i) (fun i ↦ T < g i) (fun _ ↦ False) hw (by
      intro i _hi
      by_cases hr : f i ≤ R
      · by_cases ht : g i ≤ T
        · exact Or.inl ⟨hr, ht⟩
        · exact Or.inr (Or.inr (Or.inl (lt_of_not_ge ht)))
      · exact Or.inr (Or.inl (lt_of_not_ge hr)))
  have hfalse : weightedCount s w (fun _ ↦ False) = 0 := by
    simp [weightedCount]
  have hr := weighted_markov s w f hR hw hf
  have ht := weighted_markov s w g hT hw hg
  rw [hfalse] at hcover
  linarith

/-- The explicit `3/4` margin in Section 7. Here `B = exp(-γ_E)/b`,
`D = D_b(1)`, and `E = exp(10τ)`. This checks the numerical bookkeeping after
the analytic sieve and Buchstab bounds have actually been supplied. -/
theorem buchstab_subtraction_margin {B D E errorS errorD : ℝ}
    (hD : D ≤ B * (1 + errorD))
    (herror : B * (errorS + errorD) ≤ 1 / 10)
    (hE : 1 ≤ E) (hlocal : (E - 1) * (D + 1) ≤ 1 / 10) :
    (3 : ℝ) / 4 ≤ B * (1 - errorS) - E * (D - 1 + 1 / 20) := by
  have hlocal' : (E - 1) * (D - 19 / 20) ≤ 1 / 10 := by
    nlinarith
  nlinarith

/-- The remaining margin after semiprimes and the cofactor tail are removed.
The small error budget is explicit instead of being hidden in an `o(1)`. -/
theorem semiprime_removal_margin {mass rough semiprime retained tail e₁ e₂ : ℝ}
    (hrough : (3 / 4 : ℝ) * mass - e₁ ≤ rough)
    (hsemiprime : semiprime ≤ (1 / 8 : ℝ) * mass + e₂)
    (hcover : rough ≤ retained + semiprime + tail)
    (herrors : e₁ + e₂ + tail ≤ (1 / 8 : ℝ) * mass) :
    (1 / 2 : ℝ) * mass ≤ retained := by
  linarith

end Artin
