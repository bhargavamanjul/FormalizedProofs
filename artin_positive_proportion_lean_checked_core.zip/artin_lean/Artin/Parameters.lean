module

public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Topology.Algebra.Order.Field
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Convert

/-!
# The uniform parameter choice in Section 11

The results in this file are proved in Lean. No analytic number-theory input
is assumed here. In particular the constant `c` is chosen before the real
parameter `N`, as required for the manuscript's quantitative assertion.
-/

@[expose] public section

namespace Artin

open Filter
open scoped Topology

/-- A bound on `log (D * N)` whose coefficient is independent of `N`. -/
theorem log_mul_uniform_bound {D N : ℝ} (hD : 1 ≤ D) (hN : 2 ≤ N) :
    Real.log (D * N) ≤ (1 + Real.log D / Real.log 2) * Real.log N := by
  have hDp : 0 < D := lt_of_lt_of_le zero_lt_one hD
  have hNp : 0 < N := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 2) hN
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogD : 0 ≤ Real.log D := Real.log_nonneg hD
  have hlogN : Real.log (2 : ℝ) ≤ Real.log N :=
    Real.log_le_log (by norm_num) hN
  have hmul := mul_le_mul_of_nonneg_left hlogN (div_nonneg hlogD hlog2.le)
  have hcancel : (Real.log D / Real.log 2) * Real.log 2 = Real.log D :=
    div_mul_cancel₀ _ (ne_of_gt hlog2)
  rw [hcancel] at hmul
  rw [Real.log_mul (ne_of_gt hDp) (ne_of_gt hNp)]
  nlinarith

/-- The harmless logarithmic change of normalization discussed in Section 12. -/
theorem log_two_mul_bounds {N : ℝ} (hN : 2 ≤ N) :
    Real.log N ≤ Real.log (2 * N) ∧ Real.log (2 * N) ≤ 2 * Real.log N := by
  have hNp : 0 < N := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 2) hN
  have hh : Real.log (2 : ℝ) ≤ Real.log N :=
    Real.log_le_log (by norm_num) hN
  refine ⟨Real.log_le_log hNp (by linarith), ?_⟩
  rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) (ne_of_gt hNp)]
  linarith

/-- Explicit choices which leave a factor of two to absorb a vanishing error.

`A`, `C`, `Y₀`, and `ε₀` are fixed first. The witnesses `θ`, `D`, and `c`
depend only on those four constants. The threshold in a later asymptotic
application is allowed to depend on `N`.
-/
theorem exists_uniform_parameters
    (A C Y₀ ε₀ : ℝ) (hA : 0 < A) (_hC : 0 < C)
    (_hY₀ : 0 < Y₀) (hε₀ : 0 < ε₀) :
    ∃ θ D c : ℝ, 0 < θ ∧ 0 < D ∧ 0 < c ∧
      ∀ N : ℝ, 2 ≤ N →
        0 < θ / N ∧ θ / N < ε₀ ∧ θ / N < 1 / N ∧
        2 * (θ / N) < 1 ∧ Y₀ ≤ D * N ∧ 1 < D * N ∧
        2 * c / (N * Real.log N) ≤
          (A * (θ / N) - C / (D * N)) / Real.log (D * N) := by
  let θ : ℝ := min ε₀ 1 / 2
  have hθp : 0 < θ := by
    dsimp [θ]
    exact div_pos (lt_min hε₀ zero_lt_one) (by norm_num)
  have hθε : θ < ε₀ := by
    have hh : min ε₀ 1 ≤ ε₀ := min_le_left _ _
    dsimp [θ]
    linarith
  have hθ1 : θ < 1 := by
    have hh : min ε₀ 1 ≤ 1 := min_le_right _ _
    dsimp [θ]
    linarith
  let D : ℝ := max (max 2 Y₀) (4 * C / (A * θ))
  have hD2 : 2 ≤ D := le_trans (le_max_left _ _) (le_max_left _ _)
  have hDY : Y₀ ≤ D := le_trans (le_max_right _ _) (le_max_left _ _)
  have hDlarge : 4 * C / (A * θ) ≤ D := le_max_right _ _
  have hDp : 0 < D := lt_of_lt_of_le (by norm_num) hD2
  have hAθ : 0 < A * θ := mul_pos hA hθp
  have hCD : C / D ≤ A * θ / 4 := by
    have hlarge : 4 * C ≤ D * (A * θ) := (div_le_iff₀ hAθ).mp hDlarge
    apply (div_le_iff₀ hDp).mpr
    nlinarith
  let B : ℝ := 1 + Real.log D / Real.log 2
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlogD : 0 ≤ Real.log D := Real.log_nonneg (by linarith)
  have hBp : 0 < B := by
    dsimp [B]
    positivity
  let c : ℝ := A * θ / (4 * B)
  have hcp : 0 < c := div_pos hAθ (by positivity)
  refine ⟨θ, D, c, hθp, hDp, hcp, ?_⟩
  intro N hN
  have hNp : 0 < N := lt_of_lt_of_le (by norm_num) hN
  have hN1 : 1 ≤ N := by linarith
  have hlogNp : 0 < Real.log N := Real.log_pos (by linarith)
  have hεp : 0 < θ / N := div_pos hθp hNp
  have hεθ : θ / N ≤ θ := (div_le_iff₀ hNp).mpr (by nlinarith)
  have hε1N : θ / N < 1 / N := (div_lt_div_iff_of_pos_right hNp).mpr hθ1
  have h2ε : 2 * (θ / N) < 1 := by
    have hh : θ / N < 1 / 2 := (div_lt_iff₀ hNp).mpr (by nlinarith)
    linarith
  have hDle : D ≤ D * N := by nlinarith
  have hDN1 : 1 < D * N := by nlinarith
  have hlogDNp : 0 < Real.log (D * N) := Real.log_pos hDN1
  have hlogbound : Real.log (D * N) ≤ B * Real.log N :=
    log_mul_uniform_bound (by linarith) hN
  have hnum : A * θ / (2 * N) ≤ A * (θ / N) - C / (D * N) := by
    have hh : A * θ / 2 ≤ A * θ - C / D := by linarith
    have hhN := (div_le_div_iff_of_pos_right hNp).mpr hh
    convert hhN using 1 <;> ring_nf
  have hbound : (A * θ / (2 * N)) / (B * Real.log N) ≤
      (A * (θ / N) - C / (D * N)) / Real.log (D * N) := by
    calc
      (A * θ / (2 * N)) / (B * Real.log N) ≤
          (A * θ / (2 * N)) / Real.log (D * N) :=
        div_le_div_of_nonneg_left (by positivity) hlogDNp hlogbound
      _ ≤ (A * (θ / N) - C / (D * N)) / Real.log (D * N) :=
        (div_le_div_iff_of_pos_right hlogDNp).mpr hnum
  have hident : 2 * c / (N * Real.log N) =
      (A * θ / (2 * N)) / (B * Real.log N) := by
    dsimp [c]
    ring_nf
  refine ⟨hεp, lt_of_le_of_lt hεθ hθε, hε1N, h2ε,
    le_trans hDY hDle, hDN1, ?_⟩
  rw [hident]
  exact hbound

/-- A vanishing additive error can absorb at most half a positive main
coefficient, eventually. This does not assert any analytic estimate. -/
theorem eventually_half_coefficient {ι : Type*} {l : Filter ι}
    {e : ι → ℝ} {k : ℝ} (hk : 0 < k) (he : Tendsto e l (𝓝 0)) :
    ∀ᶠ x in l, k ≤ 2 * k + e x := by
  have hh : ∀ᶠ x in l, -k < e x :=
    (tendsto_order.1 he).1 (-k) (by linarith)
  filter_upwards [hh] with x hx
  linarith

/-- The abstract final subtraction step, after the candidate and exceptional
counts have been proved elsewhere. All hypotheses are displayed explicitly. -/
theorem eventually_lower_bound_from_vanishing_error
    {ι : Type*} {l : Filter ι} {f scale e : ι → ℝ} {k main : ℝ}
    (hk : 0 < k) (hmain : 2 * k ≤ main)
    (he : Tendsto e l (𝓝 0))
    (hscale : ∀ᶠ x in l, 0 ≤ scale x)
    (hcount : ∀ᶠ x in l, (main + e x) * scale x ≤ f x) :
    ∀ᶠ x in l, k * scale x ≤ f x := by
  filter_upwards [eventually_half_coefficient hk he, hscale, hcount] with x hx hs hf
  exact le_trans (mul_le_mul_of_nonneg_right (by linarith) hs) hf

/-- The two normalized power errors in Sections 10--11 vanish under exactly
the inequalities used in the manuscript. Their multiplicative constants may
be arbitrary fixed real numbers. -/
theorem tendsto_exception_error_zero {δ ε : ℝ} (hεδ : ε < δ)
    (h2ε : 2 * ε < 1) (C₁ C₂ : ℝ) :
    Tendsto (fun x : ℝ => C₁ * x ^ (-δ + ε) + C₂ * x ^ (2 * ε - 1))
      atTop (𝓝 0) := by
  have h₁ : -δ + ε = -(δ - ε) := by ring
  have h₂ : 2 * ε - 1 = -(1 - 2 * ε) := by ring
  have t₁ : Tendsto (fun x : ℝ => x ^ (-δ + ε)) atTop (𝓝 0) := by
    rw [h₁]
    exact tendsto_rpow_neg_atTop (by linarith)
  have t₂ : Tendsto (fun x : ℝ => x ^ (2 * ε - 1)) atTop (𝓝 0) := by
    rw [h₂]
    exact tendsto_rpow_neg_atTop (by linarith)
  simpa using (t₁.const_mul C₁).add (t₂.const_mul C₂)

end Artin
