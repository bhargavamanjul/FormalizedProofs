# Artin positive proportion: Lean formalization

**Status: incomplete, with a compiled and audited development.** This project formalizes the 12 October 2026 manuscript *Every nonsquare integer not equal to −1 is a primitive root for a positive proportion of primes*. The original deductions proved so far are checked by Lean. The final candidate estimate has not yet been derived solely from the permitted references.

## Build

Lean 4.35.0 and mathlib commit `56a005855ea17e0b0958f73ec801ae140b0a1679` are pinned.

```sh
lake exe cache get
lake build
python3 scripts/audit.py
```

The archive includes sources and verification logs, not the large toolchain or mathlib cache. The verification environment uses the executable-path compatibility shim documented in `compat/README.md`; a normal installation uses the commands above. The shim does not change Lean's kernel.

## Completed deductions

- Actual `ZMod` primitive roots, order and index, the nonresidue implication, candidate exception dichotomy, small-order prime product bound, and dyadic-to-global prime proportion. `SourceProgression` applies the cited Lemma 2.4 to supply the required fixed progression.
- The actual marked prime-power series: convergence, mass at least one, exact distinct-integer factorization, and the stretched-exponential tail. The finite truncation retains at least half the full marked mass. Ordinary Mertens/moment inputs yield the required cofactor mass of order `ε log x / log Y`.
- The marked-replacement adaptation from separated source Lemma 10.2, Proposition 10.3, Fourier and prime-band inputs. Its number of marks is chosen before the dyad/coefficient family; one error constant works across growing active dyadic collections. Exact identities connect the source weights to the concrete arithmetic weight.
- Unique predecessor factorization, actual progression sums, composite-modulus CRT, reducedness, vanishing bad-modulus terms, exact totient normalization, and a crude progression bound for the weighted tail.
- Discrete partial summation for actual prime sums and the progression/BV conversions recorded in `PrimeDistribution`. The candidate construction still needs their full asymptotic assembly.
- Actual CRT lattice counts and errors, squarefree local residue products, natural factor boxes, and a dyadic cover with `O(κ log x + 1)` boxes. The two-replacement algebra cancels the roughness factors without a marking-weight bound.
- The block-sieve source specialization to predecessor arrays, exact local densities, and injective conditioned remainder conversion. The Buchstab partition and the complete sieve applications remain to be assembled.
- Actual continued Dedekind zeta functions, finite analytic zero multiplicities, ideal prime-power sums, Mellin transforms, and their convergence/explicit-formula deductions. A concrete smoothing has proved positive mass. For `q > |a|`, rational arithmetic and mathlib prove irreducibility. Separate classical degree, discriminant and splitting contracts construct the former Kummer input package.
- The reciprocal-prime tail from Chebyshev, parameter choices before `N`, and the quantitative `c / (N log N)` conclusion from the displayed intermediate estimates.

These are conditional deductions where a source theorem is supplied as an argument. They do not assert that every displayed source contract has already been entered as an accepted declaration. See the source ledgers for precise hypotheses and attribution limits.

## Current endpoint and remaining work

`Artin.quantitative_prime_proportion_of_sieve_and_separate_classical_results` in `Artin/ClassicalReduction.lean` counts actual primitive-root primes and uses the actual `DedekindQRH` predicate. Its constant is positive and fixed before every real `N ≥ 2`.

It now constructs the Kummer formula package from separate statements about actual objects. It still requires `CandidateSieveData`, which contains original manuscript estimates and **is not an accepted external theorem**. The general progression is already the cited source Lemma 2.4; `SourceProgression` now exposes and applies that permitted input. Remaining work includes full BV/PNT and local-product assembly, Buchstab bin bounds and partition, the two-variable upper sieve and its MR applications, and conversion to the actual candidate set. The exact discriminant bound also needs its accepted-source match or a proof from the underlying classical algebra theorems.

The stronger full-mass truncation is essential: comparing only to the unmarked mass could introduce a number-of-marks dependence into the semiprime constant. Also, a cutoff on the full marked cofactor must not be inserted into the invariant selector; it is imposed afterward with the proved tail bound.

See `docs/proof-map.md`, `docs/remaining-obligations.md`, and the separate marked, Kummer and sieve source contracts. There is no proved impossibility result; equally, the unchecked assembly has not been certified free of further issues.

The `N=6000` specialization remains conditional on that assembly and the exact permitted external statements. The conclusion is a positive **lower proportion**, not the existence or value of the Artin density. Replacing `log(2N)` by `log N` only changes an absolute constant for `N ≥ 2`, as proved in `Parameters`.

## Verification and trust boundary

`Audit.lean` prints dependencies of every exported project theorem, and `scripts/audit.py` rejects axioms beyond `propext`, `Classical.choice`, and `Quot.sound`. The logs, theorem count, toolchain version and source hashes are in `verification/`.

There are no `sorry`, custom axioms, or `native_decide` proofs. This validates the proved implications; it does not discharge their hypotheses. In particular, passing the axiom audit is not a claim that the manuscript theorem is complete.

Mathlib's raw `NumberField.dedekindZeta` is the defining Dirichlet series and is totalized outside its convergence region. The project correctly specifies its analytic continuation, including existence, before formulating QRH. Nontrivial zeros are in the open critical strip; the usual half-plane formulation also uses classical boundary nonvanishing.

The manuscript source is unchanged in `sources/manuscript_12_october_2026.tex`.

SHA-256: `9fa11d43a8b4ad1b9b8c051e7683719c00f25f2338d63a33ae538d745dab4db6`.
