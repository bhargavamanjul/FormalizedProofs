# Artin positive proportion: Lean formalization

**Complete relative to the agreed cited and classical inputs.** The original deductions of the 12 October 2026 manuscript are now connected to the final theorem. `CandidateSieveData`, the candidate estimate, the rough lower bound, the bin estimates, the semiprime bound and the splitting-count estimate are all derived; none is an accepted premise of the final endpoint.

The external results remain explicit Lean hypotheses. This project checks the deductions from their precise stated interfaces; it does not independently formalize or certify the cited papers.

## Final results

The main file is [`Artin/ManuscriptTheorem.lean`](Artin/ManuscriptTheorem.lean).

- `Artin.candidate_estimate_of_accepted_sources` derives the actual candidate-prime estimate from `AcceptedSieveSources`.
- `Artin.quantitative_prime_proportion_of_accepted_sources` proves: for every admissible integer `a`, there is a constant `c>0`, fixed before every real `N≥2`, such that `DedekindQRH N` implies, for all sufficiently large `x`,

  `primitiveCount a x ≥ (c / (N * log N)) * primeCounting (floor x)`.

- `Artin.positive_prime_proportion_at_6000_of_accepted_sources` specializes the cited width `1/6000` to `HasPositivePrimeProportion a`.

The counts concern actual primes and multiplicative order in `ZMod p`. “Admissible” means nonsquare and unequal to −1. The conclusion is a positive **lower proportion**, not the existence or value of the limiting Artin density. No optimality of the constant is asserted. Replacing `log(2N)` by `log N` only changes an absolute constant for `N≥2`, as proved in `Parameters`.

## Accepted inputs

[`Artin/AcceptedSieveSources.lean`](Artin/AcceptedSieveSources.lean) lists the cited progression, marked criterion, rough-discrepancy cancellation and block sieve, together with ordinary classical prime, Fourier and Buchstab facts. Its fields include no original manuscript estimate.

The remaining final-theorem arguments are the actual Dedekind continuation, classical zero counting, Mellin decay and smoothed explicit formula, and the literal Kummer field/splitting statements in [`Artin/SourceKummer.lean`](Artin/SourceKummer.lean). Source Lemma 9.1's exact discriminant formula was located, and its “sufficiently large prime” cutoff is preserved. The fixed exceptional cutoff is enlarged before `N` is chosen. QRH at the chosen width is a separate explicit input.

See [`docs/accepted-inputs.md`](docs/accepted-inputs.md) and the detailed source ledgers for all interfaces and attribution limits.

## Main completed steps

1. Construct the actual positive smooth bump, nonresidue progression, invariant selector and marked weights. Prove exhaustive support and unique predecessor factorization.
2. Prove the full marked harmonic mass, cofactor retention, and arbitrarily strong logarithmic tails. Fixed-modulus PNT and BV give `X₀ ≍ xJ/log x` and the weighted distribution error, with the required uniform constants.
3. Prove the initial sieve and the full conditioned upper sieve, including growing depth, modulus range, omission factors, discarded-cofactor multiplicity and ordinary Mertens normalization.
4. Construct the finite Buchstab partition, disjoint dyadic bin cover and uniform source-derived replacement estimates. Normalize the errors, choose the parameters and subtract the bins to obtain the actual rough lower bound.
5. Apply the actual two-variable CRT sieve and preserve the full cofactor mass to prove `C X₀ V(W)²`, with `C` independent of all marks. Two actual replacement steps and the narrow dyadic cover give the required semiprime bound.
6. Construct all fields of the actual candidate data and remove the bounded marking weights. Combine the candidate estimate with the source-derived small-index estimate and the proved large-order exception bound.
7. Pass from dyadic intervals to the positive lower proportion of actual primitive-root primes, with a constant fixed before `N`.

The full proof map is [`docs/proof-map.md`](docs/proof-map.md).

## Build and audit

Lean **4.35.0** and mathlib commit `56a005855ea17e0b0958f73ec801ae140b0a1679` are pinned.

```sh
lake exe cache get
lake build
python3 scripts/audit.py
```

The archive contains project sources, source ledgers and verification logs, not the large toolchain or mathlib cache. The verification environment used the executable-path compatibility shim documented in `compat/README.md`; a normal installation uses the commands above. The shim does not change Lean's kernel.

`Audit.lean` checks every exported project theorem and records the final interfaces. The audit permits only `propext`, `Classical.choice`, and `Quot.sound`; it rejects additional axiom dependencies. There are no `sorry`, added axioms or `native_decide` proofs. The build result, theorem inventory, toolchain version and source hashes are in `verification/summary.json` and the associated logs.

The original manuscript is unchanged in `sources/manuscript_12_october_2026.tex`.
SHA-256: `9fa11d43a8b4ad1b9b8c051e7683719c00f25f2338d63a33ae538d745dab4db6`.
